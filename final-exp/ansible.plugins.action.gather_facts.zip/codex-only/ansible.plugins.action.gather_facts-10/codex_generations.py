

# Generated at 2022-06-23 07:57:57.565036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    # return the _get_module_args()
    assert isinstance(am._get_module_args, object)
    # return the _combine_task_result()
    assert isinstance(am._combine_task_result, object)
    # return the run()
    assert isinstance(am.run, object)

# Generated at 2022-06-23 07:58:10.298208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create objects from all classes involved in run method
    task_vars = {
        'ansible_facts_parallel': 'True',
        'ansible_facts': {
            'network_os': 'ios',
            '_ansible_facts_gathered': 'True'
        }
    }

    # Use ContextDict for test purpose.
    task_vars = ContextDict(task_vars)

    task_vars['ansible_facts_parallel'] = 'True'

    import ansible.plugins.loader as loader_mod

    task_loader = loader_mod.TaskLoader()
    module_loader = loader_mod.ModuleLoader()
    action_plugin_loader = loader_mod.ActionPluginLoader()

    # Create object of class ActionModule

# Generated at 2022-06-23 07:58:11.760358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up
    # test
    obj = ActionModule()

    # assert
    assert obj is not None

# Generated at 2022-06-23 07:58:21.745989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    ActionModule.BYPASS_HOST_LOOP = True
    C.HOST_KEY_CHECKING = False

    # Create task result
    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=VariableManager(),
        loader=None,
        passwords=dict(vault_pass='secret'),
        stdout_callback='default',
    )


# Generated at 2022-06-23 07:58:24.347029
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create ActionModule object to unit test
    action_module = ActionModule()

    # set up params used to create ActionModule object
    tmp = None
    task_vars = None

    # call run method of ActionModule with params
    result = action_module.run(tmp, task_vars)

    # test that the result is empty
    assert result == {}

# Generated at 2022-06-23 07:58:33.393509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test ActionModule object
    mod = ActionModule()
  
    # Create a test result object
    res = {}
    
    # Create a test task object
    task = {}
    task['args'] = {}
    task['args']['method'] = 'setup'
    
    # Create a test task_vars object
    vars = {}
    
    # Create actual result
    actual = mod.run(res, vars)
    expected = {}
    assert actual == expected, "Actual result: %s\n    Expected result: %s" % (actual, expected)

# Generated at 2022-06-23 07:58:34.272547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # its constructor
    assert True

# Generated at 2022-06-23 07:58:36.107964
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Normal case
  a = ActionModule(None, None, None, None, None, None, None)
  assert isinstance(a, ActionModule)

# Generated at 2022-06-23 07:58:39.470063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate an ActionModule object
    action_module = ActionModule()

    # invoke method run
    result = action_module.run()

    assert 'msg' not in result

# Generated at 2022-06-23 07:58:54.413011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the code that executes in the method run of class ActionModule
    _task = object()

    _shared_loader_obj = object()

    config = object()
    config = {'FACTS_MODULES': ['ansible.legacy.setup']}

    _connection = object()
    _connection = {'_load_name': 'test_load_name'}

    display = object()
    display = {'warning': lambda *args: print(args)}

    result = {'ansible_facts': {}}
    result['ansible_facts']['_ansible_facts_gathered'] = True
    result['_ansible_verbose_override'] = True

    tmp = object()
    task_vars = {'ansible_facts': {}}

# Generated at 2022-06-23 07:59:04.118091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_args = {
        'filter': '*',
        'gather_subset': 'all'
    }

    task_vars = {
        'ansible_facts_parallel': True,
        'hostvars': {
            'localhost': {
                'ansible_facts': {
                    'network_os': 'junos'
                }
            }
        }
    }


# Generated at 2022-06-23 07:59:13.623516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mocker.patch allows you to replace anything in sys.modules
    from ansible.module_utils.common._collections_compat import collections
    import sys
    import unit_tests.modules.test_ansible_module_unit

    # This is like the __init__ function of a class
    def __init__(self):
        self.argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list'),  # options of gather_subset
        )

    # Making a copy of the original class
    OriginalModule = unit_tests.modules.test_ansible_module_unit.AnsibleModule
    # Replace the original module with your new one
    unit_tests.modules.test_ansible_module_unit.AnsibleModule = __init__
    # Replace the original collections with the mock

# Generated at 2022-06-23 07:59:21.196928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    a = ActionModule(None, args)
    from ansible.module_utils.common.removed import removed_module
    result = a.run()
    assert result['failed'] == True
    assert result['msg'] == "Facts modules were removed in Ansible 2.13, please use the setup module instead"
    assert result['deprecations'] == [{'msg': "Facts modules were removed in Ansible 2.13, please use the setup module instead", 'version': '2.13'}]

# Generated at 2022-06-23 07:59:29.238044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils import basic
    module_stub = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    module_stub.config = {}

    # Call run method of ActionModule
    am = ActionModule(module_stub, 'setup', {})

    # test with parallel=None and len(modules) >= 1
    module_stub.config = {
        'FACTS_MODULES': ['setup']
    }
    am.run({}, {})

    # test with parallel=True and with failed and skipped modules
    module_stub.config = {
        'FACTS_MODULES': ['setup', 'facts']
    }
    am.run({}, {})

   

# Generated at 2022-06-23 07:59:38.775349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule

    Test Cases:
    1. When all modules are skipped
    2. When all modules fails
    3. When all modules successfully executed

    Steps:
    1. Setup test environment having 2 modules `one` and `two`.
    2. Call run with tmp, task_vars with gathered facts.
    3. assert that result has ansible_facts
    '''

    # Setup Test
    class Mock_ActionBase(ActionBase):
        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=False):
            results = {}
            if module_name in ['ansible.legacy.setup']:
                results['fact'] = 'success'
            else:
                results['fact'] = 'fail'
           

# Generated at 2022-06-23 07:59:50.733243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = {}
    results['ansible_job_id'] = '1502860207.2572135'
    results['started'] = 0
    results['finished'] = 0
    results['delta'] = '0:00:00.012129'
    results['cmd'] = '/usr/bin/python /home/ansible/.ansible/tmp/ansible-tmp-1502860208.4-88592526841921/setup.py'
    results['message'] = 'no output returned from module'
    results['rc'] = 0
    results['stdout'] = ''
    results['stdout_lines'] = ''
    results['stderr'] = ''
    results['stderr_lines'] = ''
    results['ansible_facts'] = {'_ansible_facts_gathered': True}

# Generated at 2022-06-23 08:00:02.170118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a ActionModule object (i.e. `setup` action plugin)
    action_module = ActionModule(
        task=dict(
            action=dict(
                module_name='setup',
                module_args=dict(
                    gather_subset='!config',
                    filter='ansible_distribution*'
                )
            )
        )
    )

    # Create a ActionBase object
    action_base = ActionBase(
        task=dict(
            action=dict(
                module_name='setup',
                module_args=dict(
                )
            )
        )
    )

    # Parameter `task_vars` is required by `self.run()`
    task_vars = dict()

    # Invoke method `self.run()`

# Generated at 2022-06-23 08:00:03.539505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:00:04.466198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

# Generated at 2022-06-23 08:00:15.481580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = {
        '_get_action_args' : lambda: {},
        '_shell' : { 'tmpdir': '' },
        '_connection' : 'connection',
        '_load_name' : '_load_name'
    }
    task = {
        'args' : { 'parallel': False, 'ping': 'ping' },
        '_parent' : {
            '_play' : {
                '_action_groups' : ['action_groups']
            }
        },
        'collections' : ['collections']
    }
    data = {
        'verbosity' : 2,
        'action_plugins' : ['action_plugins'],
        'connection_plugins' : ['connection_plugins'],
        'shell_plugins' : ['shell_plugins']
    }
    action_module

# Generated at 2022-06-23 08:00:23.692998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._connection = "network_cli"
    mod._task = {
        "args": {
            "cacheable": True,
            "network_os": "junos",
            "facts_module": "junos.junos",
            "gather_subset": [
                "!all",
                "!min"
            ]
        }
    }

    mod._shared_loader_obj = {
        "collections": [],
        "options": {}
    }

    mod._templar = None
    mod._shared_loader_obj["module_loader"] = {
        "find_plugin_with_context": lambda module_name, collection_list=None: print("hello")
    }

    # ActionBase.run returns a dict
    #print(mod.run())


test_

# Generated at 2022-06-23 08:00:29.455757
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO:
    # test dependency on ansible.legacy.async_status which has been
    # removed. See how to mock plugins without installing them
    # https://stackoverflow.com/a/57775485/548792
    pass

# Generated at 2022-06-23 08:00:36.961161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock context and task
    mock_context = MagicMock()
    mock_context.connection = MagicMock()
    mock_connection = mock_context.connection.return_value
    mock_context.plugin_loader = MagicMock()

    mock_loader = mock_context.plugin_loader.return_value

    mock_task = MagicMock()
    mock_task.args = {}
    mock_task.args['module_defaults'] = {}
    mock_task._parent = MagicMock()
    mock_task._parent._play = MagicMock()
    mock_task._parent._play._action_groups = {}
    mock_task.args['gather_subset'] = ['all']
    mock_task.args['gather_timeout'] = 3
    mock_task.args['filter'] = '*'
   

# Generated at 2022-06-23 08:00:40.174422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule(loader=None, shared_loader_obj=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, task_vars=None)

test_ActionModule()

# Generated at 2022-06-23 08:00:50.905269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.v2_task_result import TaskResult as TaskResult2
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.action.setup import ActionModule as SetupActionModule
    from ansible.plugins.action.ping import ActionModule as PingActionModule

    # Set up the mock loader so we can get a test lookup at the end
    fake_plugin_dir = os.path.join(C.DEFAULT_MODULE_PATH, "../test/unit/plugins/tmp_modules")
    add_all_plugin_dirs([fake_plugin_dir])

    # Reset any global vars in the constants module
    C

# Generated at 2022-06-23 08:00:55.142250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestAction(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestAction, self).run(tmp, task_vars)

    constructed = TestAction()
    expected = 'TestAction'
    actual = constructed._name
    assert actual == expected

# Generated at 2022-06-23 08:01:01.461436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    current_players = C.config.get_config_value('CONNECTION_FACTS_MODULES', variables={})
    if 'ansible.legacy.setup' not in current_players['local']:
        C.config.set_config_value('CONNECTION_FACTS_MODULES', 'ansible.legacy.setup', variables={})

    actionModule = ActionModule()
    assert actionModule.run(tmp=None, task_vars={}) != {}

# Generated at 2022-06-23 08:01:12.304177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = dict(
        setup_hostname="test_host",
        setup_host_setup="test_host_setup",
        setup_hostname_fact="test_hostname_fact"
    )


# Generated at 2022-06-23 08:01:15.579788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run(['setup'], { 'gather_subset': 'all' }, ['network_cli']) == {'_ansible_facts_gathered': True, '_ansible_verbose_override': True, 'ansible_facts': {}}

# Generated at 2022-06-23 08:01:16.398062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:01:28.101585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.setup import ActionModule as setup_action_module
    import json
    import pytest

    data = '{"msg": "The following modules failed to execute: "}'
    result = json.loads(data)
    assert result == {"msg": "The following modules failed to execute: "}

    module_loader, shared_loader, paths, _ = basic._setup_loader()
    tmp_path = '/tmp'
    connection = basic.Connection('ssh')
    play_context = basic.PlayContext()
    task_vars = {}

# Generated at 2022-06-23 08:01:32.523043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import play
    from ansible.playbook.task import Task

    g_play = play.Play()
    g_task = Task()
    g_task._role = None
    g_loader = 'test_loader'

    am = ActionModule(g_task, g_loader)

    assert am._supports_check_mode is True

# Generated at 2022-06-23 08:01:33.131611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:01:42.024878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_path = os.path.realpath('ansible/plugins/modules/setup.py')
    modules = {'setup': module_path}
    m = type('ModuleLoader', (object,), dict(get_all_plugin_loaders=lambda x: [type('Loader', (object,), dict(get_module_paths=lambda x: modules))]))
    # instantiate class ActionModule using a parameterized constructor
    action_module = ActionModule({}, play_context=dict(modules=m))
    task = type('Task', (object,), dict(args={'parallel': False}))
    action_module._task = task
    action_module._connection = type('Connection', (object,), dict(load_name='network_cli'))
    action_module.run()

# Generated at 2022-06-23 08:01:53.767946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test setup
    connection = MagicMock()
    connection._shell = MagicMock(tmpdir='/tmp/test')
    connection._load_name = 'network_cli'

    task_vars = {
        'ansible_connection': connection,
        'ansible_facts': {},
    }

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-23 08:02:02.799848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def mock_execute_module(mod_name, mod_args, task_vars, wrap_async):
        res = {}
        if wrap_async:
            res['ansible_job_id'] = 'xyz123'
            res['results_file'] = 'xyz456'
        else:
            res['finished'] = 1
        return res

    def mock_load_name():
        return 'mock_load_name'

    def mock_get_config_value(value, variables):
        if value == 'FACTS_MODULES':
            return ['ansible.legacy.setup', 'mock_fact']
        elif value == 'CONNECTION_FACTS_MODULES':
            return {'mock_load_name': 'mock_conn_fact'}

# Generated at 2022-06-23 08:02:14.593518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    global module_executor

    # Create a temporary object of ActionModule class

    loader = DataLoader()
    playbooks = ['./test/unittests/ansible_test/test_action_module.yml']
    passwords = {}

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 08:02:27.076496
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def _execute_module(self, module_name, module_args, task_vars=dict(),
                        wrap_async=True, notify=None, persist_files=False,
                        cache_key=None, allow_extras=False,
                        delete_remote_tmp=True, remote_tmp_dir=None,
                        module_state=None):
        print(module_name)
        print(module_args)


# Generated at 2022-06-23 08:02:34.421288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible import context
    import ansible.plugins.loader
    from ansible.plugins.loader import find_plugins
    from ansible.utils.vars import merge_hash

    # setup
    modules = ['ansible.module_utils.facts.system.distribution']

    # setting _shared_loader_obj for ansible.module_utils.facts.system.distribution.DistributionFactModule
    context.CLIARGS['module_path'] = ''
    distributions = find_plugins("ansible.module_utils.facts.system.distribution", "Distribution")
    dist_classes = {}
    for dist in distributions:
        dist_classes.update(dist.load_plugins())
    DistributionFactModule._shared_loader_obj = ansible.plugins

# Generated at 2022-06-23 08:02:41.932858
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()

    assert not action._supports_check_mode

    assert action._connection is None
    assert action._templar is None
    assert action._loader is None
    assert action._shared_loader_obj is None
    assert action._display.verbosity == 3
    assert not action._display.deprecated
    assert not action._display.deprecated_warning
    assert not action._display.stderr
    assert action._display.stdout
    assert action._display.verbosity == 3
    assert not action._display.warn

    assert action.action_class == 'setup'
    assert not action.force_handlers
    assert action.poll_interval == 15

# Generated at 2022-06-23 08:02:48.738317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None
    assert a.connection is None
    assert a._display is not None
    assert a._shared_loader_obj is None
    assert a._templar is not None
    assert a._task is None
    assert a._loader is None
    assert a._supports_check_mode is True
    assert a._supports_async is False
    assert a._loop is None
    assert a._async_version is None
    assert a._async_poll_interval is None

# Generated at 2022-06-23 08:02:53.040131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.run() == {'ansible_facts': {}, 'ansible_facts_gathered': True, 'ansible_verbose_override': True}

# Generated at 2022-06-23 08:02:53.642037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule == ActionModule

# Generated at 2022-06-23 08:03:03.003758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from importlib import import_module
    from itertools import product
    from unittest.mock import Mock, patch

    # We need to import this to get the constants that we will use in the
    # tests, we will mock the actual methods to get those values
    action = import_module('ansible.plugins.action.setup')

    # We will use the same arguments for each test
    task_vars = {'foo': 'bar'}
    display = Mock()
    display.display = True

    # Patch the action configuration variable and the constants of this module
    action_config = Mock()
    action_config.get_config_value = Mock(return_value=True)

    import_module('ansible.constants').config = action_config

    action.C._ACTION_SETUP = ['action_module', 'setup_plugin']

# Generated at 2022-06-23 08:03:05.266197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    runner = ActionModule(None, None, None, None, None, None)
    assert ActionModule is not None


# Generated at 2022-06-23 08:03:15.865350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        # takes a list of fact modules to run
        facts_module=['setup'],
        # when enabled, fact collection runs in parallel
        # parallel=True,
        # when enabled, the ansible_facts dict from the ansible.facts module will be added to ansible_facts
        # local_fact=True,
    )

    # Setup Fixtures

# Generated at 2022-06-23 08:03:25.622927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup class ActionModule and variables
    fact_module = 'ansible.legacy.setup'
    task_vars = {}
    task = {}
    task._parent = {}
    task._parent._play = {}
    task._parent._play._action_groups = {}
    
    # Create class
    setup = ActionModule(task, task_vars)

    # Get module arguments
    mod_args = setup._get_module_args(fact_module, task_vars)

    # Create task result
    task_result = {}
    task_result['ansible_facts'] = {}
    task_result['warnings'] = []
    task_result['deprecations'] = []
    
    # Create result

# Generated at 2022-06-23 08:03:37.100205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.stdout_callback import AdHocCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    import ansible.utils.vars

    # Create the task
    task = Task()
    task._role = None
    task.action = 'setup'
    task.args = {}

    # Create the play
    play = Play()
    play.hosts = 'host_name'
    play.name = '~test_play'
    play.task_include('test_action')

    # Create the inventory
    inventory

# Generated at 2022-06-23 08:03:47.552623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    import ansible.executor.task_queue_manager
    import ansible.plugins.action.setup
    import ansible.plugins.loader

    # calling constructor of class ansible.plugins.action.setup.ActionModule
    obj = ansible.plugins.action.setup.ActionModule()

    # calling constructor of class 
    # ansible.executor.task_queue_manager.TaskQueueManager
    tqm = ansible.executor.task_queue_manager.TaskQueueManager()

    # calling constructor of class ansible.plugins.loader.ActionModuleLoader
    loader = ansible.plugins.loader.ActionModuleLoader(tqm)

    # calling constructor of class 
    # ansible.executor.module_common.ModuleReplacer
    replace_module = ansible.executor.module_common.ModuleReplacer

# Generated at 2022-06-23 08:03:52.472482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_collections.ansible.community.plugins.module_utils.facts.collector.base import BaseFactCollector
    from ansible.plugins.loader import connection_loader

    mock_task_vars = dict(
        ansible_facts=dict(),
        ansible_check_mode=False,
        ansible_verbosity=0
    )

    mock_action = ActionModule(
        task=dict(action=dict(module_name='setup')),
        connection=connection_loader.get('network_cli'),
        templar=None,
        shared_loader_obj=None,
        play_context=None,
        loader=None,
        templar_available=False,
        task_vars=mock_task_vars
    )


# Generated at 2022-06-23 08:04:04.573555
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:04:05.211462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:04:07.095292
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert(am._supports_check_mode==True)


# Generated at 2022-06-23 08:04:13.783317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create fixture
    fixture = ActionModule()
    # Create test variables
    tmp = ['/tmp/ansible-tmp-1383301996.45-217227808219399/', '/tmp/ansible-tmp-1383301996.45-217227808219399/']
    task_vars = {'ansible_facts_parallel': None}
    # Run test
    result = fixture.run(tmp, task_vars)
    # Check expected result
    assert result['ansible_facts'] == {}
    # Destroy fixture
    fixture = None

# Generated at 2022-06-23 08:04:14.904443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:04:15.756485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:04:25.933995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        args = dict()

    class MockPlay(object):
        class MockActionGroups(object):
            action_groups = dict()

        action_groups = MockActionGroups()

    class MockPlayContext(object):
        pass

    class MockLoader(object):
        pass

    class MockTemplar(object):
        pass

    class MockTaskVars(object):
        pass

    mock_task = MockTask()
    mock_play = MockPlay()
    mock_play_context = MockPlayContext()
    mock_loader = MockLoader()
    mock_templar = MockTemplar()
    mock_task_vars = MockTaskVars()

    from ansible.plugins.action import ActionModule

# Generated at 2022-06-23 08:04:26.868527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:04:34.398202
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # No module specified should throw error
    # TODO: Replace these with a mock object when possible
    params = [
        {
            'tmp': None,
            'task_vars': {},
            'expected_result': {},
        },
    ]

    for param in params:
        # TODO: Replace this with a mock object when possible
        module = ActionModule()

        result = module.run(**param)

        # Ensure function returns the expected results
        assert result == param['expected_result'], 'Result does not match expected_result'

# Generated at 2022-06-23 08:04:35.154778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:04:35.704151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-23 08:04:46.494933
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct a mock task
    task_vars = { "ansible_linux": "test value", "ansible_all_ipv4_addresses": ["172.1.1.1"] }
    task = MagicMock()
    task.args = {}
    task._parent = MagicMock()
    task._parent._play = MagicMock()
    task._parent._play._action_groups = {}

    # Construct a mock templar
    templar = MagicMock()
    templar._available_variables = task_vars

    # Construct a mock connection
    connection = MagicMock()
    connection._load_name = "test_connection"

    # Construct a mock connection factory
    connection_factory = MagicMock()

    # Construct a mock play context
    play_context = MagicMock()

    #

# Generated at 2022-06-23 08:04:57.074591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_loader, fake_inventory, fake_variable_manager = FakeModuleLoader(), FakeInventory(), FakeVariableManager()
    fake_loader.add_collection('stdlib')
    fake_loader.add_collection('community.general')
    fake_loader.add_collection('ansible.legacy')
    fake_loader.add_collection('my.custom')
    action_module = ActionModule(
        FakeTask(),
        connection=FakeConnection(),
        play_context=FakePlayContext(),
        loader=fake_loader,
        templar=fake_variable_manager,
        shared_loader_obj=fake_loader
    )

    return True



# Generated at 2022-06-23 08:04:57.946622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act = ActionModule()



# Generated at 2022-06-23 08:05:07.804455
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeTask(object):
        def __init__(self, action, args):
            self.action = action
            self.args = args

    class FakeExecutor(object):
        def __init__(self, action):
            self._action = action

    class FakePlayContext(object):
        def __init__(self, action):
            self.connection = action
            self.become = None
            self.become_user = None
            self.become_method = None
            self.remote_addr = None
            self.remote_user = None

    class FakePlay(object):
        def __init__(self, action):
            self.action = action

    class FakeDisplay(object):
        def __init__(self, action):
            self._action = action


# Generated at 2022-06-23 08:05:14.935556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We are testing the constructor of ActionModule
    # We import the required modules
    import ansible.utils.vars
    import ansible.plugins.loader
    import ansible.executor.module_common
    import ansible.executor.task_queue_manager

    # We create an object of the InMemoryDataManager which has the required stub functions
    my_data_manager = ansible.utils.vars.InMemoryDataManager()

    # We create an object of the SharedPluginLoaderObj with required stub functions
    my_loader = ansible.plugins.loader.SharedPluginLoaderObj()

    # We create an object of the arguments for the ActionBase with required arguments

# Generated at 2022-06-23 08:05:24.890478
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock the module's `sanitize_facts` method to not modify the facts, and run the tests.
    def dummy_sanitize_facts(self, facts):
        return facts

    ActionModule._sanitize_facts = dummy_sanitize_facts

    from ansible.module_utils.ansible_modlib.test import AnsibleExitJson
    from ansible.module_utils.ansible_modlib.test import AnsibleFailJson

    from ansible.plugins.action.setup import ActionModule as ActionModule_setup

    from pytest import fixture

    from test.unit.plugins.utils import set_module_args, AnsibleExitJsonArgSpecMatcher, AnsibleFailJsonArgSpecMatcher


# Generated at 2022-06-23 08:05:26.167376
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert False

# Generated at 2022-06-23 08:05:36.600543
# Unit test for constructor of class ActionModule
def test_ActionModule():
  aneg = { 'gather_subset': [ 'all' ],
    'gather_network_resources': [ 'all' ],
    'gather_timeout': [ '10' ] }
  t = dict(
      name='setup',
      action='setup',
      args=aneg,
      notify=dict(),
      register=dict()
    )
  task = dict(
    run_once=False,
    name='setup',
    action=t,
    tags=[],
    when=[]
  )

# Generated at 2022-06-23 08:05:38.766682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('ActionModule class')
    print(ActionModule)
    print(ActionModule.run)

# Generated at 2022-06-23 08:05:40.583007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:05:41.587010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:05:51.016072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )

    assert isinstance(action, ActionBase)
    assert hasattr(action, 'run')
    assert hasattr(action, '_execute_module')
    assert hasattr(action, '_remove_tmp_path')
    assert hasattr(action, '_supports_check_mode')
    assert hasattr(action, '_supports_async')
    assert hasattr(action, '_shared_loader_obj')
    assert hasattr(action, '_loader')
    assert hasattr(action, '_tmp_path')
    assert hasattr(action, 'runner')

# Generated at 2022-06-23 08:06:01.516710
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class FakeConnection(object):
        _load_name = 'local'

    class FakeTask(object):

        def __init__(self, args_value, module_defaults_value, module_path_value):
            self.args = args_value
            self.module_defaults = module_defaults_value
            self._parent = FakeModulePath(module_path_value)

    class FakeModulePath(object):
        def __init__(self, module_path_value):
            self._play = FakePlay(module_path_value)

    class FakePlay(object):
        def __init__(self, module_path_value):
            self._context = FakeActionGroups(module_path_value)

    class FakeActionGroups(object):
        def __init__(self, module_path_value):
            self._

# Generated at 2022-06-23 08:06:09.115298
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class FakeModule(object):
        def find_plugin_with_context(name, collection_list):
            return name

        def resolve_fqcn(name):
            return name

    # Create the object ActionModule and call its run() method
    self = ActionModule(None, FakeModule(), None)
    self._task = FakeModule()
    self._task._parent = FakeModule()
    self._task._parent._play = FakeModule()
    self._task._parent._play._action_groups = dict()
    self._task.args = dict()
    self._task.args['network_os'] = 'ios'
    self._task.collections = list()
    self._templar = FakeModule()
    self._shared_loader_obj = FakeModule()
    self._connection = FakeModule()
    self._connection._load_name

# Generated at 2022-06-23 08:06:13.942786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for empty module name
    try:
        action_module = ActionModule('', '', '', '', '', '', {})
        assert False
    except Exception:
        assert True

    # test for a valid module name
    try:
        action_module = ActionModule('test_module', '', '', '', '', '', {})
        assert True
    except Exception:
        assert False



# Generated at 2022-06-23 08:06:15.744329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Stub for unit tests
    pass

# Generated at 2022-06-23 08:06:26.091917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    from ansible.parsing.dataloader import DataLoader

    action_mod = ActionModule()
    task_q_m = TaskQueueManager(loader=DataLoader(), passwords={})
    host = Host(name="dummy")
    host.set_variable('ansible_ssh_host','localhost')

# Generated at 2022-06-23 08:06:36.555379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
    )
    role = Role()
    block = Block(role=role)
    task = Task(block=block)
    action = ActionModule(task, tqm._variables)

    assert action.task is task
    assert action._templar is tqm._variables

# Generated at 2022-06-23 08:06:37.516804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:06:47.537564
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:06:59.938658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup

    # We create a mock of the class ActionModule
    action_module_mock = ansible.plugins.action.setup.ActionModule('test_ActionModule_run')
    # We create a mock of the class ActionBase
    action_base_mock = ansible.plugins.action.ActionBase('test_ActionModule_run')
    # We create a result object
    result = {'ansible_facts': {'_ansible_facts_gathered': False}}

    # We create a list object and populate it to be used as the parameter 'modules' by the run method
    modules_list = ['ansible.legacy.setup', 'ansible.legacy.setup']
    # We create a list object and populate it to be used as the parameter 'result' by the combine_task_result method
    result

# Generated at 2022-06-23 08:07:09.010452
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create a loader
    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create datastructure that represents our play, including tasks

# Generated at 2022-06-23 08:07:21.082356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager

    loader = get_all_plugin_loaders()['action']
    obj = loader.get('setup', task=None, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)

    ansible_ssh_host = 'test_host'
    host = 'test_host'
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host(host=host, ansible_host=ansible_ssh_host)

# Generated at 2022-06-23 08:07:31.079837
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import pytz
    from datetime import datetime, timedelta

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins, reduce
    from ansible.module_utils._text import to_text

    from ansible.plugins.action.setup import ActionModule as am
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory2
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory3


# Generated at 2022-06-23 08:07:41.122721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants
    import ansible.utils.vars
    import ansible.plugins.action
    import ansible.executor.module_common
    import ansible.module_utils.parsing.convert_bool

    my_env = dict(os.environ)
    my_env["ANSIBLE_NOCOWS"] = '1'
    my_env["ANSIBLE_CONFIG"] = './test/units/plugins/modules/setup/.ansible.cfg'
    my_env["ANSIBLE_FORCE_COLOR"] = 'false'

    my_cmd_run_args = dict()
    my_cmd_run_args["stdin"] = None
    my_cmd_run_args["stdout"] = None
    my_cmd_run_args["stderr"] = None
    my_cmd_run

# Generated at 2022-06-23 08:07:44.842667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, dict(filter='ansible_distribution'), 'action_plugin', 'setup', 'localhost')
    assert a.argspec is not None

# Generated at 2022-06-23 08:07:45.498375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:07:47.222084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert not hasattr(obj, "plugins")

# Generated at 2022-06-23 08:07:54.279754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(generate_file='tests/unit/executor/ansible_modules/action_plugins/test_action_plugin.py'),
        connection=object(),
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Check type of 'action_module'
    assert isinstance(action_module, ActionModule)

