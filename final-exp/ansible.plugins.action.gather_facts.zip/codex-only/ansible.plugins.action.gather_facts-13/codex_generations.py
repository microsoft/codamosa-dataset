

# Generated at 2022-06-23 07:57:49.588667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-23 07:58:01.640810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import merge_hash
    #from ansible.execution.task_executor import TaskExecutor
    #from ansible.executor.task_result import TaskResult

    loader = action_loader._create_loader([])

    module = loader.get('set_fact', basedir=None)

    task = module._instantiate()
    task_section = {
        'action': 'set_fact',
        'args': {}
    }
    task._load_task_data(task_section)
    set_

# Generated at 2022-06-23 07:58:09.541436
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    modules = ['ansible.legacy.freebsd.setup', 'ansible.legacy.sunos.setup']
    class_action_module = ActionModule()

    tmp = None
    task_vars = {}
    expected_result = {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}
    result = class_action_module.run(tmp, task_vars, modules)
    assert result == expected_result

# Generated at 2022-06-23 07:58:18.852656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._display.warning = print
    C.config.set('FACTS_MODULES', ['smart'])
    C.config.set('CONNECTION_FACTS_MODULES', { 'network_os': 'ansible.legacy.network_setup' })
    actionModule._task.args['network_os'] = 'ios'
    actionModule._connection = mock()
    actionModule._connection._load_name = 'ios'
    actionModule.run(tmp='/tmp/', task_vars={})

# Unit tests for method _get_module_argsof class ActionModule

# Generated at 2022-06-23 07:58:20.387608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-23 07:58:27.244160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This will test the run method of the class ActionModule.
    """
    from ansible.module_utils.facts.facts import Facts
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.parsing.convert_bool import boolean
    import ansible.utils.plugin_docs as plugin_docs

    module_args = dict(gather_subset='all')
    module_name = 'setup'
    task_vars = dict(ansible_facts=dict(network_os='nxos'))
    tmp = dict(results_file='/fake/path')
    with pytest.raises(SystemExit):
        ActionModule(module_name, module_args, tmp).run(tmp, task_vars)

    # Test for no exception raised when gather_subset is set

# Generated at 2022-06-23 07:58:29.463797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.vars

    tmp = ansible.utils.vars.AnsibleVars(dict())
    task_vars = ansible.utils.vars.AnsibleVars(dict())

    ActionModule(tmp, task_vars)

# Generated at 2022-06-23 07:58:31.333175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test __init__
    action_module = ActionModule()

    assert action_module is not None


# Generated at 2022-06-23 07:58:38.848913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up mocks
    tmp = None
    task_vars = None

    # set up ActionModule object
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # set up run method parameters
    tmp = None
    task_vars = dict(ansible_facts=dict())
    task_vars.get('ansible_facts', {})['network_os'] = 'ios_xr'

    # run the method
    result = action_module.run(tmp, task_vars)

    # assert for what we expect
    assert result['ansible_facts'] == dict(_ansible_facts_gathered=True)

# Generated at 2022-06-23 07:58:53.576322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.cli.adhoc import AdHocCLI
    from ansible.plugins.loader import ConnectionLoader, ModuleLoader
    from ansible.utils.vars import combine_vars

    class Host:
        def __init__(self):
            self.name = 'host'
            self.vars = dict()
            self.groups = []
            self.groups_list = []

    class Task:
        def __init__(self):
            self.args = dict()
            self.module_defaults = dict()
            self._parent = self

# Generated at 2022-06-23 07:59:01.215401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AnsibleModule() is needed for global vars
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader

    mod = action_loader.get('setup', class_only=True)

    test_task = {
        'action': 'setup',
        'args': {
            'filter': 'ansible_os_family'
        }
    }

    task_vars = dict(
        ansible_facts=dict(
            ansible_os_family='RedHat'
        ),
        ansible_facts_gathered='smart'
    )

    task_vars = mod._init_global_vars(task_vars, ImmutableDict(test_task))

# Generated at 2022-06-23 07:59:11.108992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy
    import json
    import os
    import sys
    import unittest

    class FakeVarsModule():
        def __init__(self, fake_vars):
            self.fake_vars = fake_vars

        def get_vars(self, loader, path, entities, cache=True):
            return self.fake_vars

    # Fake display.
    class FakeDisplay():
        def __init__(self):
            self.verbosity = 0
            self.display_args = []

        def verbose(self, msg):
            self.display_args.append(msg)

    class FakeOptionsModule():
        def __init__(self, verbosity):
            self.connection = ''
            self.module_path = ''
            self.forks = 0
            self.become = None
            self

# Generated at 2022-06-23 07:59:20.510542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dummy_task = DummyTask()
    dummy_task.action = 'setup'
    dummy_task.vars = {"ansible_facts_parallel": True}

    params = {'parallel': True, 'network_os': 'cisco_ios', 'gather_subset': '!all', 'gather_timeout': 60, 'filter': 'ansible_distribution*'}
    params['_ansible_verbose_override'] = False
    params['ansible_check_mode'] = False
    params['ansible_batch_size'] = 5
    params['ansible_facts'] = {}

    test_action = ActionModule(dummy_task, params)
    test_action._shared_loader_obj = DummySharedLoaderObj()

    test_action.run(None, None)


# Generated at 2022-06-23 07:59:28.723553
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Connection_Connection(object):
        def __init__(self, connection, load_name):
            self._connection = connection
            self._load_name = load_name

    class Task_Task(object):
        def __init__(self, module_defaults, args, collections):
            self._module_defaults = module_defaults
            self._args = args
            self._collections = collections


# Generated at 2022-06-23 07:59:29.460460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule().run(None, None)

# Generated at 2022-06-23 07:59:34.282224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _create_mock_action(task_args):
        action = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=MockSharedLoaderObj())
        action._shared_loader_obj._vars_cache = {'hostvars': {'all': {}}}
        action._task._parent._play._action_groups = {}
        action._task._parent._play._action_groups['setup'] = {}
        action._task._parent._play._action_groups['setup']['gather_facts'] = 'smart'
        action._task.args = task_args
        return action


# Generated at 2022-06-23 07:59:45.042656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    context.CLIARGS = context.CLIARGS._replace(module_path=['/to/mymodules'])

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'host1',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=dict(filter='ansible_distribution')))
        ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

    tqm = None
    callback = ResultsCollector()

# Generated at 2022-06-23 07:59:52.210156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts import Facts
    from ansible.executor.task_result import TaskResult
    
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._execute_module = lambda module_name, module_args, task_vars, wrap_async: TaskResult(
        host=None,
        task=None,
        return_data=dict(ansible_facts=Facts(dict(test=True)).get_facts())
    )

    task_vars = dict()
    tmp = None
    result = action_module.run(tmp, task_vars)

    assert isinstance(result, dict)

# Generated at 2022-06-23 07:59:59.290122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constants = type('test_constants', (object,), {'DEFAULT_HASH_BEHAVIOUR': 'replace'})()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-23 08:00:01.123136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assert setUp does not raise some exception
    assert True

# Generated at 2022-06-23 08:00:03.813744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module != None

# Generated at 2022-06-23 08:00:14.012058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module = ActionModule(None, None)
	action_module.action_name = 'setup'
	action_module._task.args = {'gather_subset':['all'], 'filter':"*"}
	action_module._task.module_defaults = {'gather_subset': ['all'], 'filter': "*", 'gather_timeout': 10}
	action_module._task._parent._play._action_groups = ['all']
	action_module._shared_loader_obj.module_loader.find_plugin_with_context = lambda fact_module, collection_list=action_module._task.collections: action_module._shared_loader_obj.module_loader.get(fact_module)

# Generated at 2022-06-23 08:00:15.834656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-23 08:00:17.943028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None


# Generated at 2022-06-23 08:00:27.213514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
        Unit test for method run of class ActionModule
    '''

    from ansible.module_utils import basic
    from ansible.utils.vars import merge_hash
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    tempdir = '/path/to/temp'
    def __getattr__(name):
        return None

    def get_vault_password(*args, **kwargs):
        return ''

    # function _write_line
    @staticmethod
    def _write_line(data, output_path, launcher_config=None, verbose=False):
        # Do nothing
        pass


# Generated at 2022-06-23 08:00:29.245158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:00:39.137414
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action import ActionBase
    from ansible.executor.module_common import get_action_args_with_defaults

    action = ActionModule({'module_args': {'a': 1, 'b': 2}})

    resolved = action._shared_loader_obj.module_loader.find_plugin('ping').resolved_fqcn

    module_args = get_action_args_with_defaults(resolved, {'a': 1, 'b': 2, 'name': 'controller-1'}, {})

    assert module_args == {'data': 'hello world', 'a': 1, 'b': 2, 'name': 'controller-1'}


# Generated at 2022-06-23 08:00:39.816779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:00:42.730040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run Functionality of class ActionModule')
    print('TODO: Implement Automation Unit Test')
    # module = ActionModule()
    # module.run(tmp, task_vars)
    return True

# Generated at 2022-06-23 08:00:47.011156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object of ActionModule
    act = ActionModule(None, {}, {'templar': None, 'shared_loader_obj': None})
    result = act.run(None, {})
    assert result == {'ansible_facts': {}, 'ansible_facts_gathered': True, '_ansible_verbose_override': True}

# Generated at 2022-06-23 08:00:48.527328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:00:56.763732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tmp=None
    task_vars=None

    # Act
    result = action_module.run(tmp=None, task_vars=None)
    # Assert
    assert (result['ansible_facts']['_ansible_facts_gathered'] == True)
    assert (result['ansible_facts']['_ansible_facts_gathered'] == True)

# Generated at 2022-06-23 08:01:07.525541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    import ansible.executor.task_queue_manager
    import ansible.executor.play_iterator
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.utils.vars
    import ansible.template.template
    import ansible.executor.module_common
    import ansible.utils.vars
    import ansible.parsing.dataloader
    import ansible.vars.hostvars
    import ansible.vars.unsafe_proxy

    host = ansible.inventory.host.Host(name="fakehost")
    host.set_variable("ansible_connection", "local")

    tqm = None


# Generated at 2022-06-23 08:01:16.922515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    # Set up test input parameters for module ActionModule

# Generated at 2022-06-23 08:01:28.635918
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_task = MagicMock()
    mock_task.args = {'parallel': None}

    mock_loader = MagicMock()
    mock_loader.find_plugin_with_context = MagicMock(return_value='ansible.legacy.setup')

    mock_execute_module = MagicMock()
    mock_execute_module.return_value = {
        'failed': False,
        'ansible_facts': {
            'fact1': 'value1',
            'fact2': 'value2'
        }
    }

    mock_connection = MagicMock()
    mock_connection._load_name = 'smart'

    mock_display = MagicMock()
    mock_templar = MagicMock()

    mock_task._parent = MagicMock()
    mock_task._parent._play = Magic

# Generated at 2022-06-23 08:01:39.210150
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()


# Generated at 2022-06-23 08:01:43.210657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of ActionModule and check various properties
    action_module = ActionModule.__new__(ActionModule)
    assert isinstance(action_module, ActionBase) is True
    assert action_module._supports_check_mode is True
    assert action_module._shared_loader_obj is not None

# Generated at 2022-06-23 08:01:44.474048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    A = ActionModule()
    assert True

# Generated at 2022-06-23 08:01:56.366420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    for fact_module in ['ansible_current_user', 'ansible_os_family', 'ansible_distribution', 'ansible_default_ipv4', 'ansible_env']:
        task_vars[fact_module] = 'default value'

    action_module = ActionModule()
    action_module._task = ActionModule.TaskClass()
    action_module._task.args = {}
    action_module._task.parser = ActionModule.TaskClass.ParserClass()
    action_module._connection = ActionModule.ConnectionClass()
    action_module._task.action = 'setup'
    action_module._task._parent = ActionModule.TaskClass()
    action_module._task._parent._play = ActionModule.TaskClass()
    action_module._task._parent._play._action_groups

# Generated at 2022-06-23 08:02:05.024605
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_self = MagicMock()
    mock_self._task.args = {'a': 'b'}
    mock_self._task.collections = []
    mock_self._task.module_defaults = []
    mock_self._shared_loader_obj = MagicMock()
    mock_self._shared_loader_obj.module_loader = MagicMock()
    mock_self._shared_loader_obj.module_loader.find_plugin_with_context.return_value = MagicMock()
    mock_self._shared_loader_obj.module_loader.find_plugin_with_context.return_value.resolved_fqcn = MagicMock()
    mock_self._templar = MagicMock()
    mock_self._task._parent._play._action_groups = []
    mock_self._supports

# Generated at 2022-06-23 08:02:06.308327
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:02:17.610514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader
    import ansible.plugins.action.setup
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.executor.task_queue_manager

    # Create required classes

# Generated at 2022-06-23 08:02:19.437867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(cls='ActionModule', task=None)


# Generated at 2022-06-23 08:02:29.896864
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:02:37.850798
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:02:46.933330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = 'ansible.plugins.loader.ActionModule'
    mock_task = 'ansible.executor.task_executor.TaskExecutor'
    mock_display = 'ansible.utils.display.Display'

    am = ActionModule(loader=mock_loader, task=mock_task, connection='None', play_context='None',
                      loader_internal_var='None', variable_manager='None', template_ds='None',
                      shared_loader_obj='None', templar='None', lookup_loader='None')
    assert am.__module__ == 'ansible.plugins.action.setup'


# Generated at 2022-06-23 08:02:48.975420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.run()
    assert True

# Generated at 2022-06-23 08:02:55.120828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.compat.tests.mock as mock
    from ansible.compat.six.moves import builtins
    m = mock.mock_open()
    with mock.patch.multiple(builtins, open=m, raw_input=lambda x: '5'):
        action = ActionModule()
    assert isinstance(action, ActionModule)



# Generated at 2022-06-23 08:02:59.799975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    class MockTask:
        def __init__(self):
            self.args = dict()
            self._parent = MockPlay()
    class MockPlay:
        def __init__(self):
            self._action_groups = []
    class MockExecutor:
        def __init__(self):
            self._module_name = 'setup'
            self._loader = 'ExecutorLoader'
            self._templar = 'Templar'
            self._shared_loader_obj = 'ExecutorLoaderObj'
            self._task = MockTask()

    class MockConnection:
        def __init__(self):
            self._shell = 'ShellJson'

    # Mock Executor
    executor = MockExecutor()
    executor._task._parent._play._action_groups.append('all')
    executor

# Generated at 2022-06-23 08:03:07.576482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    class FakeConnection(object):
        def __init__(self):
            self.results_dir = '/tmp'
        def __getattr__(self, attr):
            return None

    class FakeTask(object):
        def __init__(self):
            self._parent = None
            self.args = {
                'network_os': 'test',
                'parallel': False,
            }
            self.module_defaults = {}
            self._action_groups = []
            self.collections = []

# Generated at 2022-06-23 08:03:08.593138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-23 08:03:17.920705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing run method of class ActionModule
    """

    # test with ansible_facts_parallel as None
    # args = [None, None, None]
    # args[0].args = {'parallel': None, 'network_os': 'ios'}
    # args[1] = {'ansible_facts': {'network_os': 'ios'}, 'ansible_facts_parallel': None}
    # args[2] = {'ansible_facts': {}}
    # result = ActionModule.run(ActionModule, *args)
    # assert result['ansible_facts']['_ansible_facts_gathered'] == True

    # test with ansible_facts_parallel as False
    # args = [None, None, None]
    # args[0].args = {'parallel': False

# Generated at 2022-06-23 08:03:26.405028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_text
    from ansible.module_utils.connection import Connection

    class Mock_Task:

        def __init__(self, name, play_context, args):
            self.name = name
            self.play_context = play_context
            self.args = args

    class Mock_PlayContext:

        def __init__(self):
            self.check_mode = False

        def set_check_mode(self):
            self.check_mode = True

    class Mock_Display:

        def __init__(self):
            self.errors = 0

        def error(self, msg):
            self.errors += 1

    # set up variables to pass to instantiation of action_plugin

# Generated at 2022-06-23 08:03:29.663732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.playbook.play_context import PlayContext

    # Create an instance of class ActionModule
    action_obj = Actio

# Generated at 2022-06-23 08:03:34.306980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.setup
    am = ansible.plugins.action.setup.ActionModule(load_name='fact', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None,
                                                   action_loader=None)

# Generated at 2022-06-23 08:03:45.478541
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.setup import ActionModule as setup

    # Without setup module
    action_module = action_loader.get('setup', class_only=True)()
    result = action_module.run(task_vars={'ansible_facts': {'network_os': 'ios'}})
    assert len(result['ansible_facts']) > 10  # must have some results

    result = action_module.run(task_vars={'ansible_facts': {'network_os': 'iosxr'}})
    assert len(result['ansible_facts']) > 10  # must have some results


# Generated at 2022-06-23 08:03:49.420805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    import ansible.plugins.loader
    assert isinstance(ansible.plugins.action.ActionModule, object)
    assert ansible.plugins.action.ActionModule.__name__ == 'ActionModule'
    assert ansible.plugins.action.ActionModule.__module__ == 'ansible.plugins.action'

# Generated at 2022-06-23 08:03:51.172255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__bases__ == (ActionBase,)



# Generated at 2022-06-23 08:04:02.826753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    import ansible.constants as C

    C.HOST_KEY_CHECKING=False

    playground = 'tests/playbooks/legacy_setup/'
    inventory = 'tests/inventory/hosts'
    test_hosts = ['test_host']

    loader = DataLoader()

    def mock_any(self):
        return True


# Generated at 2022-06-23 08:04:13.095963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest

    from ansible.errors import AnsibleError
    from ansible.executor.module_common import _TRANSFORM_COMPAT
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.parsing.convert_bool import boolean

    # create mocks
    task_vars = {}
    tmp = None
    wrap_async = True # this is the important one
    fact_module = "ansible.legacy.setup"

    # params required to create action module

# Generated at 2022-06-23 08:04:14.410773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:04:25.411571
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # unit test for action module facts without non-core module
    module = ActionModule(
        'setup',
        dict(
            args=dict(
                test_parameter=dict(
                    default=True,
                    type='boolean',
                    required=False
                )
            )
        ),
        True,
        dict(),
        None
    )
    job_result = dict()
    module._execute_module = lambda module_name, module_args, task_vars, wrap_async: (
        dict(
            failed=False,
            skipped=False,
            ansible_facts=dict(
                ansible_interpreter=dict(
                    ansible_version=2.0
                )
            )
        )
    )
    module._display.vvvv = lambda msg: print(msg)

# Generated at 2022-06-23 08:04:36.434214
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.executor.task_queue_manager
    import ansible.module_utils.facts.hardware
    import ansible.plugins.loader
    import ansible.utils.context_objects
    import ansible.utils.vars

    # Create a temporary directory to use for the async files
    from tempfile import mkdtemp
    tmp = mkdtemp()

    task_vars = {u'ansible_facts_parallel': 'yes', u'module_setup': True, u'ansible_network_os': u'eos'}

    # Set up a fake Executor for this
    def _shared_loader_obj_mock():
        return None

    def _display_mock(msg, color=None, stderr=False, screen_only=False, log_only=False):
        pass


# Generated at 2022-06-23 08:04:46.081405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play

    task_vars = dict(
        ansible_facts=dict(
            command_warnings=[]
        ),
        setup_module_args=[]
    )
    play_source = dict(
        name="myplay",
        hosts=["myhost"],
        gather_facts='no',
        tasks=[
            dict(action=dict(module="setup", args=dict(filter='*')))
        ]
    )
    play = Play().load(play_source, variable_manager={'hostvars': {'myhost': task_vars}}, loader=None)


# Generated at 2022-06-23 08:04:47.732413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t.__doc__ is not None

# Generated at 2022-06-23 08:04:48.575873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert instance

# Generated at 2022-06-23 08:04:59.763124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts.hardware.base import FactsHardwareBase

    os_name = "windows"
    host_name = "test_host"
    task_vars = {"test_key1" : "test_value1", "test_key2" : "test_value2"}
    module_name = "some_module"
    module_path = "some_module_path"
    task_action = "some_task_action"
    task_args = {"test_key3" : "test_value3", "test_key4" : "test_value4"}
    fake_play = "some_play"

    fake_play_context = "some_play_context"
    fake_action_plugin = "some_action_plugin"
    fake_loader = "some_loader"
    fake_templ

# Generated at 2022-06-23 08:05:11.514904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare
    import unittest
    import __builtin__
    from collections import namedtuple

    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.executor.task_result import TaskResult

    class TestActionModule(ActionModule):
        def _get_module_args(self, fact_module, task_vars):
            return {'fact_module': fact_module}
        def _combine_task_result(self, result, task_result):
            return {'result_name': 'result', 'task_result': task_result}

    class TestTaskResult(TaskResult):
        def __init__(self, **kwargs):
            self.__dict__

# Generated at 2022-06-23 08:05:13.859432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = ActionModule()
    assert f.run() is None

# Generated at 2022-06-23 08:05:14.641464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:05:24.728808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate ActionModule
    dummy_connection = MagicMock()
    dummy_task_executor = MagicMock()
    dummy_task = MagicMock()
    dummy_task._parent = MagicMock()
    dummy_task._parent._play = MagicMock()
    dummy_task_executor.loader = MagicMock
    dummy_task_executor.shared_loader_obj = MagicMock
    dummy_task_executor.host_vars = {}
    dummy_task_executor.host = MagicMock
    dummy_play_context = MagicMock()
    dummy_play_context.connection = 'local'
    dummy_play_context.network_os = None
    dummy_play_context.remote_addr = "localhost"
    dummy_play_context.remote_user = "root"
    dummy_play

# Generated at 2022-06-23 08:05:26.598012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 08:05:37.318459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.stats.stats import AggregateStats
    from ansible.utils.vars import load_extra_vars
    import json


# Generated at 2022-06-23 08:05:39.204637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(connection=None, action=None, task=None)

# Generated at 2022-06-23 08:05:47.544079
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    modArgs = {'path': 'test/path'}
    modArgs['module_setup'] = 0
    tmp = None
    taskVars = {}
    am = ActionModule()
    am.run(tmp, taskVars, mod_args=modArgs)
    tmp = None
    taskVars = {}
    modArgs = {'path': 'test/path'}
    modArgs['module_setup'] = 1
    #am.run(tmp, taskVars, mod_args=modArgs)
    tmp = None
    taskVars = {}
    modArgs = {'path': 'test/path'}
    modArgs['module_setup'] = 2
    #am.run(tmp, taskVars, mod_args=modArgs)

# Generated at 2022-06-23 08:05:59.380514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {
        'ansible_facts': {'1': 'one'},
        'ansible_facts_parallel': None,
        'filter': None,
        'gather_subset': None,
        'gather_timeout': None
    }
    task_args = {
        'ansible_user': 'root',
        'ansible_network_os': 'ios',
        'ansible_connection': 'network_cli',
        'ansible_module_name': 'setup',
        'ansible_module_args': module_args,
        'module_defaults': {},
        'collections': []
    }
    am = ActionModule(task_args, 'root', 'setup', '/tmp', 0, '/path/playbook.yml', 1, 3, 3, 'pid')

# Generated at 2022-06-23 08:06:10.123944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json as Json
    from collections import OrderedDict

    from ansible_collections.community.general.tests.unit.compat import unittest

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils import basic
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    class Mock(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_config_value(self, *args, **kwargs):
            return 'default'


# Generated at 2022-06-23 08:06:21.266365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if C.ANSIBLE_VERSION_2:
        import ansible

        # create task
        task = ansible.playbook.task.Task()
        task._role = None
        task._task = ansible.playbook.task.Task()
        task._task._block = ansible.playbook.task.Task()
        task._task._role = None
        task._task._task = task
        task._task._block._parent = task._task
        task._task._block._role = None
        task._task._block._task = task._task
        task._parent = task._task._block
        task._role = None
        task._loader = ansible.parsing.dataloader.DataLoader()
        task._shared_loader_obj = True
        task._role_params = {}
        task._tmp = '/tmp'

# Generated at 2022-06-23 08:06:31.244214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ansible_facts_parallel not in task_vars, parallel is not in task.args
    # and number of modules are greater than one
    # so parallel will be initialized to true
    task_vars = dict()
    task_vars['play_hosts'] = ['server1']
    task_vars['_ansible_no_log'] = True
    tmp = dict()
    runner = dict()
    runner['connection'] = dict()
    runner['connection']['_load_name'] = 'local'
    runner['_task'] = dict()
    runner['_task']['args'] = dict()
    runner['_task']['action'] = dict()
    runner['_task']['collections'] = ['test']
    runner['_task']['action']['args'] = dict()
   

# Generated at 2022-06-23 08:06:40.770239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_path = 'ansible.plugins.action.setup'
    module_name = 'setup'
    action_name = 'setup'
    task = dict(action=dict(module=module_name, args=dict()))
    task_vars = dict()
    play_context = dict(check_mode=True)
    connection = dict(type='smart')
    shared_loader_obj = dict(module_loader=dict(find_plugin_with_context=dict()))
    ansible_module_class = dict(ActionBase=ActionBase)

    # test constructor with all arguments

# Generated at 2022-06-23 08:06:48.760825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    import ansible
    import ansible.module_utils.facts


# Generated at 2022-06-23 08:07:00.083509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate mock class
    conn_loader = ConnectionLoader()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    m = ActionModule(conn_loader, None, None, play_context, None, None)

    # Create object to be used as argument when calling m.run
    tmp = {}

    # Create dict to be used as task_vars
    task_vars = {}

    # This test is for method run of class ActionModule
    # The test below is for the local facts modules
    from ansible.module_utils.facts.system.bsd import FactsModule
    from ansible.module_utils.facts.system import FactsModule as GenericFactsModule
    m.supports_check_mode = True
    m._supports_async = False

# Generated at 2022-06-23 08:07:01.303290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actobj = ActionModule()
    assert actobj._supports_check_mode == True

# Generated at 2022-06-23 08:07:02.156793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:07:04.828251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(connection='connection',
                        play_context=None,
                        loader=None,
                        templar=None,
                        shared_loader_obj=None)

# Generated at 2022-06-23 08:07:16.386590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # local imports
    from ansible_module_gather_facts import ActionModule
    from ansible.module_utils.six import iteritems

    # global imports
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.action.setup import ActionModule as SetupModule
    from ansible.plugins.connection.network_cli import Connection as Connection_Network_Cli
    from ansible.module_utils.network.common.utils import dict_to_set
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from collections import namedtuple
    from io import Bytes

# Generated at 2022-06-23 08:07:27.485070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ddt = ActionModule()

    import os
    import json
    import shutil
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 08:07:29.600825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule can be called without arguments
    """
    action_module = ActionModule()
    assert type(action_module).__name__ == 'ActionModule'

# Generated at 2022-06-23 08:07:30.641603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('should return the result expected for ansible_facts_modles in parallel')
    pass

# Generated at 2022-06-23 08:07:31.097376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:07:31.632573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:07:41.696270
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:07:54.214046
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock task
    task = {
        'args': {},
        'collections': [],
        'module_defaults': [],
        'tags': {},
    }

    # mock task object
    task_obj = AnsibleTask(task=task)

    # mock connection
    connection = AnsibleConnection({})

    # set up mock loader object
    loader = AnsibleLoader({'status': True})

    # set up mock display
    display = AnsibleDisplay(verbosity=0)
