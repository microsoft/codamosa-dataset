

# Generated at 2022-06-23 07:57:51.117441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name="ansible.legacy.setup", module_args=""),),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    return action_module


# Generated at 2022-06-23 07:57:52.329321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:55.419224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(None, {})
    assert isinstance(m.run(tmp=None, task_vars={}), dict)

# Generated at 2022-06-23 07:58:05.627850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test of method run of class ActionModule:", end="")
    # Test without fail
    task_vars = {'ansible_facts': {}}
    result = {'ansible_facts': {}}
    failed = {}
    skipped = {}
    modules = ['ansible.legacy.setup']
    parallel = True
    fact_module = modules[0]
    mod_args = {}
    res = {}
    module_name = fact_module
    module_args = mod_args
    task_vars = task_vars
    wrap_async = False
    assert ActionModule._combine_task_result(result, res) == {'ansible_facts': {}}
    assert ActionModule._get_module_args(fact_module, task_vars) == {}

# Generated at 2022-06-23 07:58:08.094413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No need to test ActionModule.run as it just forwards the method call to
    # _execute_module and wraps it in a try...except. The current test coverage
    # for _execute_module is sufficient.
    pass

# Generated at 2022-06-23 07:58:09.535354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 07:58:11.765962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()

# test ignore subset

# Generated at 2022-06-23 07:58:21.466923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'testhost': {}}}
    inventory = Inventory(loader, variable_manager, host_list=['testhost'])
    variable_manager.set_inventory(inventory)

    action_module = ActionModule(
        task=dict(action=dict(module=dict(name='setup'))),
        connection=dict(),
        play_context=dict(),
        loader=loader,
        variable_manager=variable_manager,
        all_vars=dict()
    )

    assert action_module._shared_loader_obj is not None

# Generated at 2022-06-23 07:58:21.920328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:58:28.113234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_facts = {
        'a.b.c': 'd',
        'a.b.c.d': 'e',
        'a.b.c.d.e': 'f',
        'a.b.c.d.e.f': 'g'
    }

    module_facts = {
        'a.b.c': 'd',
        'a.b.c.d': 'e',
        'a.b.c.d.e': 'f',
        'a.b.c.d.e.f': 'g'
    }

    def mock_run_module():
        return {'ansible_facts': ansible_facts}

    # Module requires both '_execute_module' and '_templar'

# Generated at 2022-06-23 07:58:30.468009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: figure out how to write unit tests for this action
    fixture = ActionModule(dict())
    assert fixture.run() == {}

# Generated at 2022-06-23 07:58:31.839806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action = ActionModule()
    test_action.run()

# Generated at 2022-06-23 07:58:39.097610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_vars = {'ansible_facts_parallel' : False, 'ansible_facts': {'network_os': 'eos'}}
    args = {'parallel': True}
    task = {'args': args}
    module._task = task
    modules = ['smart', 'ansible_connection']
    module.run(None, task_vars)
    assert modules == module._task.args['module_list']
    task_vars = {'ansible_facts_parallel' : False, 'ansible_facts': {'network_os': 'eos'}}
    args = {'parallel': True}
    task = {'args': args}
    module._task = task
    modules = ['smart', 'ansible.legacy.setup']

# Generated at 2022-06-23 07:58:54.009137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # modules: ['smart', 'ansible.legacy.setup', 'ansible.legacy.network.setup']

    # create an instance of the setup class
    action_module = ActionModule()

    # create a mock task instance
    class MockTask():
        def __init__(self):
            self.args = dict()
    task = MockTask()

    # create a mock task_vars instance
    class MockTaskVars():
        def __init__(self):
            self.args = dict()
    task_vars = MockTaskVars()

    # create a dummy temp directory, so the module does not complain
    # tmp = os.path.join(os.getcwd(), 'tmp')
    tmp = os.getcwd()

    # create a test result instance

# Generated at 2022-06-23 07:58:58.099058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    An example test that illustrates the construction of an ActionModule object.
    """
    # initialize the variables and objects needed to construct the ActionModule object
    action = 'module'
    task = mock()
    shared_loader_obj = mock()
    connection = mock()
    play_context = mock()
    new_stdin = mock()

    # construct the ActionModule
    action_module = ActionModule(
        action,
        task,
        shared_loader_obj,
        connection,
        play_context,
        new_stdin
    )

# Generated at 2022-06-23 07:59:09.173390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Deprecated - ssh
    assert ActionModule(None, dict(transport='ssh'))
    # Deprecated - winrm
    assert ActionModule(None, dict(transport='winrm'))
    # Deprecated - chroot
    assert ActionModule(None, dict(transport='chroot'))
    # Deprecated - sudo
    assert ActionModule(None, dict(transport='sudo'))
    # Deprecated - chroot
    assert ActionModule(None, dict(transport='chroot'))
    # Deprecated - pipe
    assert ActionModule(None, dict(transport='pipe'))
    # Deprecated - fcntl
    assert ActionModule(None, dict(transport='fcntl'))
    # Deprecated - paramiko_ssh

# Generated at 2022-06-23 07:59:18.140272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class HostType:
        def __init__(self, verbosity):
            self.verbosity = verbosity

    class TaskType:
        def __init__(self, args, module_defaults):
            self.args = args
            self.module_defaults = module_defaults

    class ConnectionType:
        def __init__(self, tmpdir, verbosity):
            self.tmpdir = tmpdir
            self.verbosity = verbosity

    class ExecutorType:
        def __init__(self, module_name, module_args, task_vars, wrap_async):
            self.module_name = module_name
            self.module_args = module_args
            self.task_vars = task_vars
            self.wrap_async = wrap_async


# Generated at 2022-06-23 07:59:21.127606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = Connection()
    task = Task(connection=conn)
    action = ActionModule(task, tmp_path='/tmp', connection=conn)
    assert action._supports_check_mode is True

# Generated at 2022-06-23 07:59:21.742152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:59:29.612184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.facts import is_file

    print("test_ActionModule_run()")

    tmp = None
    task_vars = None
    a_obj = ActionModule(load_name='setup', task=None)

    x = a_obj.run(tmp, task_vars)
    print(x)
    assert isinstance(x, dict)
    assert is_file('/opt/ansible/s3/old/setup.py') == True
    assert 'failed' not in x.keys()
    assert x.get('ansible_facts') is not None
    assert isinstance(x['ansible_facts'], dict)

    task_vars = {'ansible_facts_parallel': False}
    x = a_obj.run(tmp, task_vars)

# Generated at 2022-06-23 07:59:31.114207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance
    inst = ActionModule('', {}, {}, False, '', '', '', '')

    # check the results
    assert inst is not None

# Generated at 2022-06-23 07:59:41.341221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    from pathlib2 import Path

    from ansible.module_utils.facts import is_disabled_all

    # Arrange
    tmp = Path('/tmp/ansible')
    tmp.mkdir(parents=True)


# Generated at 2022-06-23 07:59:49.403168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import shared_loader_obj as shared_loader_obj
    shared_loader_obj.module_loader.paths = ["/etc/ansible/plugins/modules"]
    shared_loader_obj.module_loader.module_paths = ["/etc/ansible/plugins/modules"]
    shared_loader_obj.module_loader.set_collection_path("/etc/ansible/ansible_collections")


# Generated at 2022-06-23 08:00:00.584866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class FakeTask(object):
        args = {'key': 'value'}
        _parent = None
        _play = None

    class FakeTaskParent(object):
        args = {'key': 'value'}
        _play = None

    class FakePlay(object):
        _action_groups = {'test': [1, 2, 3]}
        _action_registry = {}
        module_defaults = {}

    class FakePlayContext(PlayContext):
        pass

    class FakeOptions(object):
        pass


# Generated at 2022-06-23 08:00:12.329294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare test environment
    tmp_file = '/tmp/test_action_module_run'

    # Arrange
    _task = Mock(name='_task')
    _task.args = {'_ansible_syslog_facility': None, '_ansible_verbosity': None, '_ansible_job_id': None, '_ansible_no_log': None}
    _task._parent = Mock(name='_parent')
    _task._parent._play = Mock(name='_play')
    _task._parent._play._action_groups = []

    _connection = Mock(name='_connection')
    _connection._load_name = 'smart'
    _connection._shell = Mock(name='_shell')
    _connection._shell.tmpdir = tmp_file

    _display = Mock(name='_display')

# Generated at 2022-06-23 08:00:13.724567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_action = ActionModule()
    assert temp_action is not None

# Generated at 2022-06-23 08:00:19.419924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given a result dict, a task dict, and insertions dict,
    result = dict()
    task = dict()
    insertions = dict()
    # When action module run is called,
    test_run = ActionModule.run(result, task, insertions)
    # Then the result is not None.
    assert test_run is not None

# Generated at 2022-06-23 08:00:30.131537
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:00:37.296279
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:00:38.682935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionBase)

# Generated at 2022-06-23 08:00:48.904213
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import AnsibleVars
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    import json

    # Initialize task queue manager
    task_queue_manager = TaskQueueManager(0, "/tmp", "/tmp", None, 0, 1, 1, "/etc/ansible/hosts", 'local')

    # Create a task result
    task_result = TaskResult(host='host1', task=dict(task_name='task1', task_action='action1'))

    # Create a play context

# Generated at 2022-06-23 08:00:59.441401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.network.interfaces as interfaces
    import ansible.module_utils.facts.virtual.virtualbox as virtualbox
    import ansible.module_utils.facts.processor.cpuinfo as cpuinfo
    import ansible.module_utils.facts.system.distribution as distribution
    import ansible.module_utils.facts.system.fips as fips
    import ansible.module_utils.facts.system.pkg_mgr as pkg_mgr

    # Create an instance of arguments

# Generated at 2022-06-23 08:01:10.704106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    main()
    module_args = {}
    module_args['FACTS_MODULES'] = ['test_1', 'test_2']
    module_args['ansible_facts_parallel'] = None
    module_args['parallel'] = None
    variables = {}
    variables['ansible_facts'] = {}
    variables['ansible_facts']['network_os'] = 'dummy'
    module_args['wrap_async'] = False
    module_args['module_name'] = 'ansible.legacy.setup'
    module_args['_task'] = None
    module_args['module_args'] = {}
    module_args['module_args']['setupfile'] = None
    module_args['task_vars'] = variables
    ans = ActionModule(module_args)
    ans._

# Generated at 2022-06-23 08:01:19.361579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    class test_ActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.tmp = ''
            self.task_vars = dict()
            self.results_file = ''
            self.result = dict()

        def _execute_module(self, *args, **kwargs):
            return dict()

        def _remove_tmp_path(self, path):
            return

    am = test_ActionModule(*args, **kwargs)
    # init test
    assert am.tmp == ''
    assert am.task_vars == dict()
    assert am.results_file == ''
    assert am.result == dict()

    # run test
    am.run()

# Generated at 2022-06-23 08:01:30.502653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.task.setup import ActionModule
    import ansible.playbook.play_context
    import ansible.executor.task_queue_manager
    import ansible.executor.task_result
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.utils.vars
    test_executor = ansible.executor.task_queue_manager.TaskQueueManager(
        host_list=[],
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
        shared_loader_obj=None,
    )
    test_task_result = ansible.executor.task

# Generated at 2022-06-23 08:01:31.473410
# Unit test for constructor of class ActionModule
def test_ActionModule():
   assert ActionModule(None,None,None,None)

# Generated at 2022-06-23 08:01:32.561628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()

# Generated at 2022-06-23 08:01:41.888099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit tests for method run() in class ActionModule"""

    # Create a mock action_base object
    mock_action_base = ActionBase()

    # Create a mock connection_loader object
    mock_connection_loader = object()
    mock_connection_loader.add_connection = (lambda *_, **__: None)
    # Create a mock task object
    mock_task = object()
    mock_task.args = {}
    mock_task.args['gather_subset'] = None
    mock_task.args['gather_timeout'] = None
    mock_task.args['filter'] = None

    # Create a mock task_vars object
    mock_task_vars = object()

    # Create a mock task object
    mock_task = object()


# Generated at 2022-06-23 08:01:42.512989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:01:48.435040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=dict(), loader=object(), templar=object(), shared_loader_obj=object())
    assert action_module.run() == {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}


# Generated at 2022-06-23 08:01:59.243074
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    main_dict = {
        'hosts': {
            'hostname': {
                'hostvars': {
                    'ansible_network_os': 'ios',
                    'ansible_facts': {
                        'network_os': 'ios'
                    }
                }
            }
        }
    }


# Generated at 2022-06-23 08:02:08.986276
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:02:17.478683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.netcommon.tests.unit import run_module

    result = run_module(ActionModule, dict(
        gather_subset='all',
        gather_network_resources=['interfaces', 'vlans', 'memory', 'tcp_sockets'],
    ), result_cb=lambda result: result)

    assert result.pop('failed', False) is False
    assert result.pop('_ansible_verbose_override', False) is True
    assert result.pop('ansible_facts', {}).pop('_ansible_facts_gathered', False) is True

    # The rest should be the same as gather_network_resources

# Generated at 2022-06-23 08:02:24.754374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the AnsibleTask object with relevant parameters
    ansible_task = AnsibleTask()
    # Initialize the AnsiblePlay object with relevant parameters
    ansible_play = AnsiblePlay(ansible_task)
    # Initialize the ActionModule object with relevant parameters
    ansible_module = ActionModule(ansible_play, ansible_task, {}, {})
    # Test method run of class ActionModule
    ansible_module.run({}, [])

# Generated at 2022-06-23 08:02:32.544046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.setup import ActionModule as setup_action
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    basedir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'data')

# Generated at 2022-06-23 08:02:42.149104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import unittest

    class ActionModuleTestCase(unittest.TestCase):

        def setUp(self):
            import ansible
            self.runner = ansible.plugins.action.ActionModule({})
            self.runner._connection = FakeConnection()
            self.runner._display = FakeDisplay()
            self.runner._loader = ansible.loader.AnsibleLoader('')
            self.runner._shared_loader_obj = FakeSharedLoaderObj()
            self.runner._task = FakeTask()
            self.runner._templar = FakeTemplar()

        def tearDown(self):
            pass

        def test_run(self):
            self.runner._task.args = {
                'fact_module': [
                    'ansible.legacy.smart',
                ],
            }
            self

# Generated at 2022-06-23 08:02:51.137898
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.utils.display import Display
    from ansible.executor.stats import AggregateStats
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, fragment_loader
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager
    from ansible.vars.persistent_facts import FactManager

    display = Display()
    stats = AggregateStats()

    # Setup task_queue_manger
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable

# Generated at 2022-06-23 08:03:01.816737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    action = ActionModule()

    fake_task = Task()
    fake_task.args = {
        'gather_subset': 'all',
        'gather_timeout': 5,
        'filter': 'ansible_distribution'
    }
    fake_tqm = TaskQueueManager()

    action._task = fake_task
    action._connection = fake_tqm
    action._templar = fake_tqm
    action._shared_loader_obj = fake_tqm
    action.get_connection()

    fact_module = 'ansible.legacy.setup'

# Generated at 2022-06-23 08:03:08.737635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

    a = dict(gather_subset=['min','!config'],filter='ansible_virtualization_role == "guest"')
    b = dict(ansible_facts=dict(ansible_virtualization_role='guest'))
    c = dict(FACTS_MODULES=['smart'],CONNECTION_FACTS_MODULES=dict(network_os='ansible.legacy.net_facts'))
    d = dict(ansible_facts_parallel=False)
    e = dict(ansible_facts=dict(ansible_network_os='ios'),ansible_facts_parallel=False)
    f = dict(ansible_facts_parallel=True)

# Generated at 2022-06-23 08:03:15.936427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule('setup', {'_ansible_verbosity': 2, '_ansible_check_mode': False, '_ansible_no_log': False},
                                 {'playbook_dir': '/etc/ansible/', 'role_path': '/etc/ansible/roles', 'host_pattern': 'master'},
                                 [], ['localhost'], False)

    tmp, task_vars = '', {'foo': 'bar'}
    result = action_module.run(tmp, task_vars)

    assert type(result) == dict

# Generated at 2022-06-23 08:03:18.506582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module_obj.name == 'setup'

# Generated at 2022-06-23 08:03:21.830176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate the action plugin
    act = ActionModule()

    # Test constant defined in the class
    assert (hasattr(act, 'DEFAULT_CONFIG_DIR'))
    assert (isinstance(act.DEFAULT_CONFIG_DIR, str))

# Generated at 2022-06-23 08:03:34.140156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {}
    config['action_plugins'] = []
    config['delegate_to'] = None
    config['no_log'] = False
    config['network_os'] = None
    config['network_os_platform'] = None

    config['role_defs'] = {}
    config['vars'] = {}
    config['vars_prompt'] = {}
    config['vars_files'] = []
    config['vars_default_files'] = []
    config['hostvars'] = {}
    config['hostvars_strict'] = False
    config['playbook_dir'] = '.'
    config['play_basedir'] = '.'

    config['new_vault_id'] = None
    config['new_vault_password_file'] = None

# Generated at 2022-06-23 08:03:38.236816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, templar=None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:03:48.706399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = '{"gather_subset": ["all"], "gather_timeout": 30, "filter": "*"}'
    modules = ['ansible.legacy.file', 'ansible.legacy.file']
    config = {'FACTS_MODULES': modules}
    
    def mock_get_config_value(config, variables=None):
        return config[config]

    def mock_get_action_args_with_defaults(resolved_fact_module, mod_args, module_defaults, templar, action_groups):
        return mod_args


# Generated at 2022-06-23 08:03:49.233001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:04:00.343523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.setup'
    module_args = {}
    task_vars = {}
    tmp = None


# Generated at 2022-06-23 08:04:11.828548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins import module_loader
    import ansible.utils.vars
    from ansible.vars.manager import VariableManager

    tqm = TaskQueueManager(
        inventory={"_meta": {"hostvars": {}}},
        variable_manager=VariableManager(),
        loader=module_loader,
        options={"subset": "all"},
    )
    play = [{"hosts": ["localhost"]}]
    play_context = PlayContext(play=play, options={"subset": "all"})
    task = Task()

# Generated at 2022-06-23 08:04:24.878174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 08:04:25.373063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:04:26.327235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:04:37.867827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #print("\nTEST_ACTIONMODULE: started")
    import ansible.utils
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    # create an instance of the ActionModule object
    am = action_loader.get('setup', class_only=True)()
    #print("\nTEST_ACTIONMODULE: am = {}".format(am))

    # print all the class attributes
    for attr in dir(am):
        #print("\nTEST_ACTIONMODULE: {} = {}".format(attr, getattr(am, attr)))
        pass

    #print("\nTEST_ACTIONMODULE: completed")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:04:38.397499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:04:48.759915
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import tempfile

    from ansible.module_utils.facts.hardware.linux import distro  # noqa
    from ansible.module_utils.facts.system.linux import distro  # noqa

    class FakeModule(object):
        def __init__(self):
            self.check_mode = False
            self.no_log = False
            self.user_args = None

    class FakeConnection(object):
        def __init__(self):
            self._shell = None

        def __getattr__(self, name):
            if name == '_shell':
                return FakeShell()
            else:
                raise AttributeError('Unknown attribute named %s' % name)

    class FakeShell(object):
        def __init__(self):
            tmp = tempfile.mkdtemp()
            self

# Generated at 2022-06-23 08:04:59.761724
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestActionModule(ActionModule):
        _task = None
        _supports_check_mode = None
        _connection = None

        def _execute_module(self, module_name, module_args, tmp, task_vars, wrap_async, async_jid=None):
            pass

        def _remove_tmp_path(self, path):
            pass

    job_vars = {
        'ansible_facts_parallel': False,
        'ansible_facts': {},
        'ansible_network_os': 'ios',
        'ansible_connection': 'network_cli',
    }

    # test when FACTS_MODULES is ['smart']

# Generated at 2022-06-23 08:05:02.697224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arrange
    tmp = None
    task_vars = {}

    # act
    test_ActionModule = ActionModule()
    test_ActionModule.run(tmp, task_vars)

# Generated at 2022-06-23 08:05:12.918446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import json
    import pytest

    test_vars = {
        'ansible_loop_var': 'recurse',
        'ansible_facts_parallel': True,
        'ansible_facts': {
            'network_os': 'never_heard_of_it'
        }
    }
    test_vars.update(os.environ)
    cmd = '/tmp/ansible_test.py'
    cmd += '''
#!/usr/bin/env python
import os
import sys
import json
import getpass

sys.stdout.write('{"stdout": "Test"}\\n')
sys.stdout.flush()
'''
    with open(cmd, 'w') as fileobj:
        fileobj.write(cmd)

# Generated at 2022-06-23 08:05:23.882802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'ansible.legacy.local'
    task_vars = {}
    action_base = ActionBase()
    action_base.setup_is_verbose = False
    action_base.setup_is_dry_run = False
    action_base.setup_is_check_mode = False
    action_base.setup_is_connection_livestatus = False
    action_base.setup_is_forks = False
    action_base.setup_is_become = False
    action_base.setup_is_become_method = 'sudo'
    action_base.setup_is_become_user = 'root'
    action_base.setup_is_remote_user = 'root'
    action_base.setup_is_chroot = False

# Generated at 2022-06-23 08:05:31.488018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.task_vars = {'ansible_verbose': True}
    am._task.args = {'parallel': True}
    am._connection = FakeConnection()
    am.configuration = C
    am.configuration.config['FACTS_MODULES'] = ['test']
    am._shared_loader_obj = FakeLoader()
    am._display = FakeDisplay()
    results = am.run()
    assert results['ansible_facts']['ansible_default_ipv4']['address'] == '127.0.0.1'
    assert results['ansible_facts']['ansible_default_ipv4']['gateway'] == '10.0.0.99'

# Generated at 2022-06-23 08:05:36.464353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Need to mock a task and a connection
    task = MockTask()

    # Add args to the task
    task.args = {
        "ansible_facts_parallel": False,
    }

    # Mock the connection
    connection = MockConnection()

    # Load the action plugin
    action_plugin = ActionModule(task, connection, '/tmp/', '_ansible_tmp_', False)
    assert action_plugin



# Generated at 2022-06-23 08:05:39.253204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fail = 'fail'
    run = ActionModule
    ############
    #TODO
    ############
    pass

# Generated at 2022-06-23 08:05:41.022753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None, None, None)
    assert isinstance(act, ActionModule)

# Generated at 2022-06-23 08:05:42.685275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # we could use some testing here, but there's really no good way to test this
    # without breaking the module rule
    pass

# Generated at 2022-06-23 08:05:44.032945
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Try to load action plugin
    action_plugin = ActionModule()
    assert action_plugin

# Generated at 2022-06-23 08:05:45.294764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m


# Generated at 2022-06-23 08:05:46.168841
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True


# Generated at 2022-06-23 08:05:50.170238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, None)
    assert isinstance(action, ActionBase)
    assert action._supports_check_mode is True
    assert action._supports_async is False

# Generated at 2022-06-23 08:05:59.726376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # add method dependencies here ...
    module = ActionModule()
    module._task = None
    module._connection = None
    module._play_context = None
    module._loader = None
    module._templar = None
    module._shared_loader_obj = None
    module._action = None
    module._display = None
    module._play = None
    module._task_vars = None

    # add needed parameters here ...
    tmp = None
    task_vars = None

    # run method:
    result = module.run(tmp=None, task_vars=None)

    # assertion code here ...
    pass

# Generated at 2022-06-23 08:06:10.324577
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:06:11.480516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:06:21.763536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'ansible_facts': {'network_os': 'ios'}
    }

# Generated at 2022-06-23 08:06:23.635693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:06:31.611877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    from ansible.plugins.action.setup import ActionModule as setup_ActionModule
    from ansible.module_utils.facts.network.base import NetworkCollector
    from test.units.compat.mock import patch
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import get_action_args_with_defaults
    ActionModuleMock = collections.namedtuple('ActionModule', ['_task'])
    module_name = 'my.module_name'
    module_args = {'a': 1, 'b':2}

# Generated at 2022-06-23 08:06:33.013346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert type(am) == ActionModule

# Generated at 2022-06-23 08:06:39.865928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = os.path.join(os.path.dirname(__file__), '../action_plugins/setup.py')
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not action_module.construct_module_args(test_module)

# Generated at 2022-06-23 08:06:40.734538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.supports_check_mode

# Generated at 2022-06-23 08:06:48.647222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins import module_loader
    from ansible.utils.display import Display

    # Build test Fixture

# Generated at 2022-06-23 08:06:49.651481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()

# Generated at 2022-06-23 08:07:00.633620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor with task and connection, should be called from PlayContext
    task = ActionModule(task={'args': {'parallel': False}, 'args_template': {'parallel': '{{parallel}}'}}, connection={'_load_name': 'network_cli'})
    module = task.run()
    assert module['msg'] == 'The following modules were skipped: ansible.legacy.setup'
    assert module['changed'] == False
    assert module['skipped'] == True

    # Constructor with task and connection, should be called from PlayContext
    task = ActionModule(task={'args': {'parallel': False}, 'args_template': {'parallel': '{{parallel}}'}}, connection={'_load_name': 'network_cli'})
    module = task.run()

# Generated at 2022-06-23 08:07:12.285463
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock() is creating a mock of the super class of ActionModule, so that in the test,
    # we can check if the super class method has been called properly.
    mock = patch('ansible.plugins.action.ActionBase.run')
    mock_super = mock.start()

    # mock the config.get_config_value so that the test can pass.
    config_value = patch('ansible.plugins.action.setup.config.get_config_value')
    config_value.start()

    # assign the test data to variables, so that the test can be run and the result be checked.
    # assign the test data to variables, so that the test can be run and the result be checked.
    tmp = "test_tmp"

# Generated at 2022-06-23 08:07:14.056441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__

# Generated at 2022-06-23 08:07:15.059864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 08:07:26.361361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-23 08:07:34.677810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_executor import TaskExecutor

    # Workers
    workers = []
    for i in range(0, 3):
        worker = WorkerProcess()
        workers.append(worker)

    # Play

# Generated at 2022-06-23 08:07:36.329932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 08:07:37.024480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:07:38.641788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    print("Action Module testcase")
    action.run()

# Generated at 2022-06-23 08:07:45.702434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.self._supports_check_mode = True

    # Normal run
    am.self._task.args = {'parallel': None, 'ansible_facts_parallel': None}
    res = am.run()
    assert res.get('ansible_facts').get('_ansible_facts_gathered')



if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:07:56.884144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            test_am = TestActionModule(self._task, self._connection, self._play_context, self._loader,
                                       self._templar, self._shared_loader_obj, self._action)
            assert test_am._supports_check_mode is False
            assert test_am._connection is not None
            assert test_am._task is not None
            assert test_am._loader is not None
            assert test_am._templar is not None
            assert test_am._shared_loader_obj is not None
            assert test_am._connection._shell is not None
            assert test_am._connection._shell._shell is not None