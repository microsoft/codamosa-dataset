

# Generated at 2022-06-23 07:57:53.413859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake AnsibleOptions instance
    #
    # Returns:
    #     ansible.config.manager.AnsibleOptions: An empty AnsibleOptions object.
    def _get_options():
        return AnsibleOptions()

    # Create a fake display object
    #
    # Returns:
    #     ansible.utils.display.Display: An empty Display object.
    def _get_display():
        return Display()

    # Create a fake loader
    #
    # Returns:
    #     ansible.parsing.dataloader.DataLoader: An empty DataLoader object.
    def _get_loader():
        return DataLoader()

    # Create a fake ConfigManager
    #
    # Returns:
    #     ansible.config.manager.ConfigManager: An empty ConfigManager object.

# Generated at 2022-06-23 07:57:57.209450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(name='inventory'),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module is not None

# Generated at 2022-06-23 07:58:07.302928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_hash
    from ansible import context
    import json

    class FakeModule(object):
        def __init__(self, name, results):
            self.name = name
            self.results = results

    class FakeLoader(object):
        def find_plugin(self, name, mod_type='module', ignore_deprecated=True, check_aliases=False):
            if name == 'ansible.legacy.setup':
                return FakeModule('ansible.legacy.setup', [])
            elif name == 'fake1':
                return FakeModule('fake1', [{'_ansible_facts_gathered': True}])

# Generated at 2022-06-23 07:58:07.845947
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True is not False

# Generated at 2022-06-23 07:58:17.254088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_facts_parallel=True,
        ansible_network_os=None

    )

    tmp = '/tmp'
    action_module = ActionModule(
        {'args': dict(parallel=True)},
        task_vars=task_vars,
        connection='local',
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module.run(tmp, task_vars)

# Generated at 2022-06-23 07:58:19.141706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-23 07:58:26.614775
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:58:36.697364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    if sys.version_info < (3, 0):
        from mock import Mock
    else:
        from unittest.mock import Mock
    from ansible.executor.play_context import PlayContext

    class MockTask(object):
        def __init__(self, connection, module_defaults):
            self._task = self
            self._parent = self
            self._play = self
            self._loader = self
            self._connection = connection
            self._module_defaults = module_defaults
            self.delegate_to = None
            self.loop_control = {}
            self.register = Mock()
            self.args = {'foo': 1, 'bar': 2}
            self.collections = ['collection.foo']


# Generated at 2022-06-23 07:58:40.218962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = MockConnection()
    plugin = ActionModule(conn, 'test_task')
    assert plugin._connection == conn
    assert plugin._task == 'test_task'

# Generated at 2022-06-23 07:58:55.091804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TaskMock(object):
        def __init__(self, args):
            self.args = args

        def _get_action_args(self, task_vars):
            return self.args

    class PlayContextMock(object):
        def __init__(self, connection):
            self.connection = connection

    class PlayMock(object):
        def __init__(self, action_groups):
            self._action_groups = action_groups

    class ConnectionMock(object):
        def __init__(self, load_name):
            self._load_name = load_name

    def test_method(self, tmp=None, task_vars=None):
        return {}

    class PluginLoaderMock(object):
        def __init__(self, module_loader, collection_list):
            self.module

# Generated at 2022-06-23 07:58:55.731450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:59:07.444773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import get_all_plugin_loaders
    results = []

    def _record_result(res):
        results.append(res)

    module_loader = get_all_plugin_loaders()['action']
    action = module_loader.get('setup', '', 'ansible.plugins.action.setup')
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')
    playbook = os.path.join(src, 'playbook.yml')
    inventory = os.path.join(src, 'inventory')


# Generated at 2022-06-23 07:59:13.365790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    module_patcher, os_patcher, my_vars = get_patched_module(ActionModule)

    # Exercise
    my_module = ActionModule()

    # Verify
    assert my_module.connection
    assert my_module.task_vars

    # Cleanup
    module_patcher.stop()
    os_patcher.stop()



# Generated at 2022-06-23 07:59:22.801060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This method is manually written as the original method uses methods which we do not
    have implementation for
    """
    from ansible.module_utils.facts import collector
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action.setup import ActionModule

    from ansible.plugins.action import ActionBase

    class MockActionBase(ActionBase):
        def __init__(self, non_empty_dict):
            self.action_name = 'dummy_action'
            self.action_args = non_empty_dict
            self.connection = 'dummy_connection'
            self.transport = 'ssh'
            self.task_vars = {}
            self.tmp = 'dummy_tmp'
            self.task_vars = {}
            self.noop_action = False

    m_

# Generated at 2022-06-23 07:59:30.192426
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1
    # Create mocks and fake
    task_vars = []
    mod_args = []

    # Create test object
    result = {}
    result['ansible_facts'] = {}

    # Test execution
    am = ActionModule(None, None, None, None)
    result = am._combine_task_result(result, None)
    assert result == {'ansible_facts': {}, 'warnings': [], 'deprecations': []}

    # Test 2
    # Create mocks and fake
    task_vars = []
    mod_args = []

    # Create test object
    result = {}
    result['ansible_facts'] = {}

    # Create fake object
    fake_res = {}
    fake_res['ansible_facts'] = {'test_fact': 'test'}


# Generated at 2022-06-23 07:59:37.578072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars

    tmp = None
    task_vars = combine_vars(dict(
        ansible_facts=combine_vars(dict(
            ansible_network_os='rancidos'
        )),
        ansible_network_os='rancidos'
    ), dict(
        ansible_network_os='galacticos'
    ))

    module = ActionModule(None, None, None, None)

    module.run(tmp, task_vars)

    assert len(task_vars['ansible_facts']['_ansible_facts_gathered']) == 1

# Generated at 2022-06-23 07:59:41.037110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_dict = {"setup": None}
    result = ActionModule(my_dict, True, False)
    assert result is not None
    assert result.supports_check_mode
    assert not result.supports_async
    assert not result.delegate_to

# Generated at 2022-06-23 07:59:49.118966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.connection.ssh
    import ansible.plugins.connection.persistent_connection
    import ansible.plugins.connection.paramiko_ssh
    import ansible.plugins.connection.local
    import ansible.plugins.connection.winrm
    import ansible.plugins.loader
    import ansible.plugins.action.copy
    import ansible.plugins.action.shell
    import ansible.plugins.action.get_url

    class FakeTask(object):
        def __init__(self):
            self.args = {'name': 'test'}

        def get_args(self):
            return self.args

        def set_loader(self, loader):
            self.loader = loader

    instance = ActionModule()

    # test for connection class
    tmp = ansible.plugins.connection.ssh.Connection()


# Generated at 2022-06-23 08:00:00.330942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    ansible_facts   = dict()
    ansible_facts['fact1'] = 'value1'
    task_vars['ansible_facts'] = ansible_facts
    task_vars['ansible_facts_parallel'] = 5

    action_modules  = ['action1', 'action2']
    parallel = 'True'

    C.config.initialize()

    async_result = dict()
    async_result['ansible_job_id'] = '1234'

    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['fact2'] = 'value2'


    # setup = init()   # instance of class ActionModule
    # setup._task = 'task'
    # setup._task.args = dict()
   

# Generated at 2022-06-23 08:00:11.206726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play = Play().load({
        'name': 'Test Play',
        'hosts': 'localhost',
        'tasks': [
            Task().load({
                'action': 'setup',
                'args': {
                    'gather_subset': 'all'
                }
            })
        ]
    }, variable_manager={}, loader=None)

    # Test class constructor without call to super run() method
    action_module = ActionModule(play, play, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-23 08:00:12.086365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not hasattr(ActionModule, '__init__')

# Generated at 2022-06-23 08:00:15.387073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, None, None, None, None)._supports_check_mode()
    assert not ActionModule(None, None, None, None, None)._supports_async()
    assert ActionModule(None, None, None, None, None)._supports_undo()

# Generated at 2022-06-23 08:00:29.530129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.connection._load_name = 'httpapi'
    action_module.connection._host.get_vars = lambda: {}
    action_module.connection._shell.tmpdir = '/tmp'
    action_module._task.action = 'setup'
    action_module._task.args = {}
    action_module._task.module_defaults = {}
    action_module._task._parent = object()
    action_module._task._parent._play = object()
    action_module._task._parent._play._action_groups = []

    action_module.run()
    arg_count_msg = 'Method run of class ActionModule accepts no arguments.'
    try:
        action_module.run(1, 2)
    except:
        pass

# Generated at 2022-06-23 08:00:31.514019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ar = ActionModule()
    x = ar.run("tmp", "task_vars")
    print("x", x)
    assert True

# Generated at 2022-06-23 08:00:35.764900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    #
    # ActionBase.__init__(self, task, connection, play_context, loader, templar, shared_loader_obj)
    #
    pass

# Generated at 2022-06-23 08:00:46.086112
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # make args
    tmp = None
    task_vars = {
        'ansible_connection': 'local',
        'ansible_network_os': 'ios',
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_playbook_python': '/usr/bin/python',
        'ansible_shell_executable': '/bin/sh',
        'ansible_user_id': 'root',
        'ansible_env': {
            'HOME': '/root'
        }
    }

    # make fake setup module
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import TaskError
    from ansible.module_utils.facts import Facts
    from ansible.plugins import module_loader

# Generated at 2022-06-23 08:00:54.446703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 08:01:05.392084
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    ##################################################################
    #
    # test: setup modules run correctly
    #
    ##################################################################

    # test setup modules run correctly in serial mode

    # action = ActionModule(None, {}, None, None, None)
    action = action_loader.get('setup', play_context=PlayContext(), task=None, connection=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-23 08:01:06.983932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, {})
    #assertEqual(len(a.branch_ip), 3)

# Generated at 2022-06-23 08:01:16.442221
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # setup a fake action plugin
    class fake_action_module(ActionBase):
        class ModuleResult(object):
            def __init__(self, result):
                self.ansible_facts = result

        def __init__(self):
            self.action = "test"
            self.module_name = 'fake_module'
            self.action_loader = None
            self.runner = None
            self.delegated_vars = None

        def run(self, tmp=None, task_vars=None):
            return self.ModuleResult("1")

        def load_resources(self, keys_to_load=None):
            pass

    # setup a fake runner
    class fake_runner():
        def __init__(self):
            self.shared_loader_obj = {"module_loader": "fake_module"}


# Generated at 2022-06-23 08:01:16.968857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-23 08:01:19.498788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('ActionModule') is not None
    assert ActionModule('ActionModule')._supports_check_mode is True


# Generated at 2022-06-23 08:01:30.616128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for ActionModule.run
    '''

    module = ActionModule()

    # Test without fail and without skipped
    module._task.args = {'FACTS_MODULES': {'ansible.legacy.setup', 'ansible.legacy.ansible_distribution'}}
    module._connection._load_name = 'network_cli'
    module._execute_module = 'ansible.module_utils.facts.network_ls'

    tmp = None
    task_vars = {}
    res = module.run(tmp, task_vars)

    assert res['failed'] == False and res['skipped'] == False

    # Test with failed and skipped

# Generated at 2022-06-23 08:01:39.125348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Task()
    task._action = 'setup'
    action_module = ActionModule(task, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)
    action_module._connection = MagicMock()
    action_module._connection._load_name = 'network_cli'
    action_module._shared_loader_obj = shared_loader_obj
    action_module._templar = templar
    action_module._execute_module = MagicMock(return_value={})
    action_module._remove_tmp_path = MagicMock()
    result = action_module.run()
    assert result['failed'] == False


# Generated at 2022-06-23 08:01:46.258230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict()), 
        connection=dict(),
        templar=dict(),
        shared_loader_obj=dict(
            module_loader=dict(
                find_plugin_with_context=dict(
                    resolved_fqcn=dict()
                )
            )
        ),
        display=dict(),
        task_vars=dict()
    )

    try:
        result = action_module.run()
    except NotImplementedError:
        pass

# Generated at 2022-06-23 08:01:53.676499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection_mock = None
    task_mock = None
    loader_obj = None
    shared_loader_obj = None
    display = None

    test_module = ActionModule(connection=connection_mock,
                               task=task_mock,
                               loader=loader_obj,
                               shared_loader_obj=shared_loader_obj,
                               templar=None,
                               display=display)

    assert test_module is not None

# Generated at 2022-06-23 08:01:54.276358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:02:02.141177
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:02:03.265339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-23 08:02:15.166768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case to check the type of facts module
    class ActionModule_1(ActionModule):
        def run(self, tmp=None, task_vars=None):
            module_list = ['network_cli', 'network_cli_async', 'network_conf', 'network_httpapi_async', 'network_httpapi', 'network_rest']
            for module in module_list:
                if module == 'network_cli' or module == 'network_cli_async' or module == 'network_conf':
                    assert module in ['network_cli', 'network_cli_async', 'network_conf'], 'Facts module failed'

            return {'msg': 'success'}

    # Test case to check the content of message

# Generated at 2022-06-23 08:02:18.807740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {'ansible_facts': {}}

    assert TestActionModule is not None

# Generated at 2022-06-23 08:02:23.178576
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock module object
    fake_module = type('fake_module', (object,), {})()

    fake_module = ActionModule(fake_module)

    fake_module.run()


# Generated at 2022-06-23 08:02:24.198413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("dummy test")

# Generated at 2022-06-23 08:02:32.232783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.processor.base import ProcessorCollector
    from ansible.module_utils.facts.system.base import SystemCollector

    # setup
    constants = dict()
    constants['FACTS_MODULES'] = ['ansible.legacy.setup']
    constants['CONNECTION_FACTS_MODULES'] = {'ansible.legacy.setup':'ansible.legacy.setup'}

    setattr(C, 'config', dict())
    setattr(C, 'config', dict())
    setattr(C.config, 'get_config_value', dict())

# Generated at 2022-06-23 08:02:38.686115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define parameters
    tmp = None
    task_vars = {}
    # Start test
    module = ActionModule()
    result = module.run(tmp, task_vars)

    # Check value
    assert result['ansible_facts'] == {}
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True


# Generated at 2022-06-23 08:02:41.535091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_pass = True
    try:
        x = ActionModule()
    except Exception:
        test_pass = False
    msg = "\nConstructor of class ActionModule fails"
    assert test_pass, msg


# Generated at 2022-06-23 08:02:50.775175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup stuff
    mock_loader = DictDataLoader({})

# Generated at 2022-06-23 08:02:59.655108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule
    '''

    # set up
    task_vars = dict(ansible_connection='local', ansible_facts=dict(asdf=1, foo=2))

    # testing
    am = ActionModule(task=dict(args=dict(asdf=1)), task_vars=task_vars)
    assert am._connection is not None
    assert am._task is not None
    assert am._task.args == dict(asdf=1)
    assert am._task_vars == task_vars
    assert am._templar is not None
    assert am.display is not None
    assert am._supports_check_mode is False
    assert am._supports_async is False
    assert am._shared_loader_obj is not None

# Generated at 2022-06-23 08:03:11.377090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ModuleLoader():
        def find_plugin(self, module_name, mod_type, ignore_deprecated=False, check_aliases=False):
            plugin_class = {}
            plugin_class['plugin_name'] = 'test'
            class Plugin():
                def __init__(self, name):
                    self.name = name
                def run(self):
                    return 'function run'
                def supports_check_mode(self):
                    return True
                def get_default_vars(self):
                    return 'default vars'
            plugin = Plugin(name=module_name)
            return plugin_class, plugin

    class ModuleUtilBase():
        def __init__(self, task_vars):
            self.task_vars = task_vars


# Generated at 2022-06-23 08:03:16.361450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, '', C._HOST_VARIABLE_INTERFACE, None)
    assert am is not None

# Generated at 2022-06-23 08:03:17.115091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:03:26.153794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule. """
    # setup the test data
    test_data_path = os.path.join(os.path.dirname(__file__), 'test_data', 'test_action_module_run.json')
    with open(test_data_path, 'rb') as test_data:
        data = test_data.read()
    data = json.loads(data)

    # setup the test object
    task_vars = data["task_vars"]
    tmp = data["tmp"]
    task_vars['ansible_facts_parallel'] = data["parallel"]

    action_module = ActionModule(data["task"], data["connection"], data["play_context"], data["loader"], data["templar"], data["shared_loader_obj"])

    # make the test


# Generated at 2022-06-23 08:03:28.893389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    a.add_cleanup_file('test')
    a.run('test', {})

# Generated at 2022-06-23 08:03:30.543430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None, None)
    assert actionmodule is not None

# Generated at 2022-06-23 08:03:32.175958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:03:42.471420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import datetime
    import time
    import sys

    class MockConnection(object):

        def __init__(self):
            self.host = 'localhost'

    class MockModuleLoader(object):

        def __init__(self):
            self.resolved_fqcn = {}
            self.resolved_fqcn['setup'] = 'ansible.legacy.setup'
            self.resolved_fqcn['network_cli'] = 'ansible.legacy.connection_facts_modules.network_cli'
            self.resolved_fqcn['httpapi'] = 'ansible.legacy.connection_facts_modules.httpapi'
            self.resolved_fqcn['netconf'] = 'ansible.legacy.connection_facts_modules.netconf'



# Generated at 2022-06-23 08:03:45.697576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test used to check the constructor of ActionModule
    data = dict.fromkeys(['action', 'host', 'hostvars', 'play_context', 'shared_loader_obj'])
    ActionModule(data)

# Generated at 2022-06-23 08:03:51.998270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the class
    action_module = ActionModule()

    # Dummy values for the class variables that are accessed within the method
    _task = None
    _connection = None
    #_loader = None
    #_templar = None
    #_shared_loader_obj = None
    #_display = None
    #_supports_async = False

    # Call the method under test
    result = action_module.run()

    assert result == {'ansible_facts': {}, '_ansible_verbose_override': True, 'skipped': False}

    return

# Generated at 2022-06-23 08:03:56.217448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, connection=None, play_context=None, options=None, name=None, task=None, shared_loader_obj=None, templar=None)
    assert(action_module)

# Generated at 2022-06-23 08:03:57.665312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-23 08:04:02.105005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(1, 2, 3)
    assert x is not None

# Unit test other functions of class ActionModule
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:04:03.200052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test for run not implemented"

# Generated at 2022-06-23 08:04:06.618585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actMod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actMod is not None

# Generated at 2022-06-23 08:04:10.181698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(),
                        loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=MockSharedLoaderObj()) is not None



# Generated at 2022-06-23 08:04:14.463571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, {'task_name': 'test_action_module',
                                 'task_args': {'test': 1}},
                         None, None)

    assert module is not None
    assert module._task.name == 'test_action_module'
    assert module._task.args['test'] == 1
    assert module._supports_check_mode is True

# Generated at 2022-06-23 08:04:24.098749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    mocked = {
        '_execute_module.return_value': {'failed': False, 'skipped': False, 'ansible_facts': {'test_key': 'test_value'}, 'warnings': [], 'deprecations': []},
        '_task.action': ''
    }
    module.run(mocked)
    assert mocked['_task.action'] == 'setup'
    assert mocked['_execute_module.call_args_list'][0][1]['module_name'] == 'ansible.legacy.setup'
    assert mocked['_execute_module.call_args_list'][1][1]['wrap_async'] == False

# Generated at 2022-06-23 08:04:35.560036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest

    class TestSetup(unittest.TestCase):
        def setUp(self):
            sys.path.insert(0, os.path.abspath('.'))
            from ansible.plugins import action
            import ansible.executor.task_queue_manager

            self.worker = ansible.executor.task_queue_manager.TaskQueueManager()
            self.worker.initialize_process()

        def tearDown(self):
            # remove any temporary files
            import ansible.utils.unsafe_proxy

            ansible.utils.unsafe_proxy.AnsibleUnsafeText = ansible.utils.unsafe_proxy.AnsibleUnsafeBytes
            try:
                self.worker.finalize_process()
            except RuntimeError:
                pass


# Generated at 2022-06-23 08:04:46.368817
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    am = ActionModule()
    tmp = None
    task_vars = {}

    # Parameterize
    tmp = None
    task_vars = {}

    # Execution
    result = am.run(tmp, task_vars)

    # Verification

# Generated at 2022-06-23 08:04:47.559099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:04:59.277635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestTask():
        def __init__(self):
            self.args = {}
            self.module_defaults = {}
            self._parent = TestPlay()
    class TestPlay():
        def __init__(self):
            self._action_groups = {}

    class TestVariables():

        def __init__(self):
            self.module_defaults = {}
    class TestConnection():
        def __init__(self):
            self._load_name = 'network_cli'
    class TestSharedLoaderObj():
        def __init__(self):
            self.module_loader = TestModuleLoader()
    class TestModuleLoader():
        def __init__(self):
            self.find_plugin_with_context = FakeFindPluginWithContext()

# Generated at 2022-06-23 08:05:01.209809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, object)

# Generated at 2022-06-23 08:05:10.962022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar
    from ansible.errors import AnsibleError


# Generated at 2022-06-23 08:05:11.607800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:05:23.239264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = {'ansible_connection': 'network_cli', 'ansible_network_os': 'junos' }
    module_args = {'gather_subset': 'all'}
    host_connection = connection.CliConnection('localhost', 'test', 'test')
    host = hosts.Host(host_name='localhost', port=22, groups=['test'], vars=host_vars, connection=host_connection)
    play = Play().load(get_fixture_path(os.path.join('playbooks', 'play_test.yml')), variable_manager=VariableManager(), loader=loader)
    tqm = None
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, host_vars=host_vars)
    handler = None

# Generated at 2022-06-23 08:05:35.297117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.context import AnsibleContext

    task_vars = dict()
    play_context = dict(deprecated_connection='local')

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None, hosts=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = Task()
    task_include = TaskInclude()
    task_include._task = task
    task._task_include = task_include
    task_include._parent = task
    task._role = None

# Generated at 2022-06-23 08:05:37.036085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    A test for the method run of class ActionModule.

    """
    test_object = ActionModule()

# Generated at 2022-06-23 08:05:46.860109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    make sure a simple instance of the class can be constructed.
    """

    mock_connection = type('connection', (object,), {'_shell': type('shell', (object,), {'tmpdir': 'mock'}),
                                                     '_load_name': 'mock_load_name'})
    mock_task = type('task', (object,), {'args': {'network_os': 'mock_network_os'}})
    mock_loader = type('loader', (object,), {'module_loader': type('module_loader', (object,), {'find_plugin_with_context': lambda x, y: True})})
    mock_shared_loader_obj = type('shared_loader_obj', (object,), {'module_loader': mock_loader})

# Generated at 2022-06-23 08:05:49.993251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action.setup import ActionModule as setup_class
    setup_class.run(None)
    return

# Generated at 2022-06-23 08:05:54.355861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ci = {}
    hostvars = {}
    tmp = {}
    taskvars = {}

    # test code
    am = ActionModule(ci, hostvars, tmp, taskvars)
    res = am.run(tmp, taskvars)

    # TODO: asserts

test_ActionModule_run()

# Generated at 2022-06-23 08:05:55.646950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:05:56.538160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    success_test = ActionModule()
    assert True

# Generated at 2022-06-23 08:06:06.327379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.plugins.loader import action_loader
    from ansible.module_utils._text import to_text
    from ansible.module_utils.connection import Connection

    # Initialize module args
    module_args = dict(
        gather_subset="network",
        gather_timeout=10,
        filter="cisco"
    )

    # Initialize templar
    templar = basic.AnsibleTemplar(extra_vars=dict())

    # Initialize connection
    connection = Connection()

    # Initialize action_plugin
    action_plugin = action_loader.get('setup', connection=connection, templar=templar,
                                      shared_loader_obj=None, task_loader=None)

    # Initialize action_module
    action_module

# Generated at 2022-06-23 08:06:16.017116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init ActionModule object
    am = ActionModule(
        task=dict(
            action=dict(
                module_name='setup',
                module_args=dict()
            )
        ),
        connection=dict(
            _shell=dict(
                tmpdir=None
            )
        ),
        play_context=dict(
            check_mode=True
        ),
        loader=dict(
            _shared_loader_obj=dict(
                module_loader=dict(
                    find_plugin_with_context=dict()
                )
            )
        )
    )

    # Parameters not declared in the __init__() of the base class, because they have a different name in the 'e'
    # object returned by self._execute_module()

# Generated at 2022-06-23 08:06:16.995587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit tests go here
    pass

# Generated at 2022-06-23 08:06:26.026483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.facts.system.base import BaseFactCollector

    class TestLoader(action_loader.ActionModuleLoader):

        def get_single_plugin(self, name, plugin_type, collection_list=None):
            if name == 'base':
                return BaseFactCollector()

    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..'))
    action_loader._set_plugin_loader(TestLoader())

    a = ActionModule('setup.yml', {'parallel': False, 'gather_subset': "all"})
    assert a._connection.__class__.__name__ == 'Connection'
    assert a._supports_async
    assert a._supports

# Generated at 2022-06-23 08:06:38.071463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.play_context import PlayContext
    from ansible.context import CLIContext
    from ansible.plugins.loader import connection_loader

    t_conn = connection_loader.get('local', None, PlayContext(), CLIContext())
    module = setup(t_conn, '/')

    fake_task = easy_mock(
        args=dict(
            gather_subset=[],
            parallel=False,
            gather_timeout=10,
        ),
    )
    fake_task.module_defaults = dict(
        gather_subset=[],
        parallel=False,
        gather_timeout=10,
        filter=None,
    )

# Generated at 2022-06-23 08:06:47.782254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_executor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import FallbackModule
    from ansible.utils.vars import AnsibleVars
    from ansible.inventory import Inventory
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    import json

    import pytest

    ActionModuleClass = action_loader.get('setup')
    display = Display()
    vars_manager = VariableManager()
   

# Generated at 2022-06-23 08:06:59.938932
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    import copy

# Generated at 2022-06-23 08:07:09.162424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ExecutorFactory():
        class PlayContext():
            def __init__(self):
                self.network_os = ''
                self.connection = ''
                self.every_platform = True
                self.current_platform = ''
                self.primary_connection = ''

        class Task():
            def __init__(self):
                self.args = {}
                self.module_defaults = {}

        def __init__(self):
            self._play_context = self.PlayContext()
            self._task = self.Task()

    class ActionBase():
        def __init__(self):
            self._task = ExecutorFactory()._task
            self._templar = ''

    class ConnectionFactory():
        class Connection():
            def __init__(self):
                self._load_name = ''
                self._shell = Action

# Generated at 2022-06-23 08:07:21.300692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import collection_loader

    result = TaskResult(host=None, task=None, return_data={})
    loader = collection_loader
    context = PlayContext()
    result._host.get_vars = lambda: {}
    result._host.get_connection = lambda: {}
    result._task.action = 'setup'
    result._task.args = {}
    result._task.module_defaults = {}
    result._task.collections = []
    result._task._parent._play._action_groups = {}
    x = ActionModule(loader=loader, connection=None, task_vars=result._host.get_vars(), play_context=context)
    assert x

# Generated at 2022-06-23 08:07:22.143187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:07:23.618011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None).__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:07:32.749809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.raw import ActionModule as action_module
    # create an object of the class
    actionModObj = action_module()
    # invoke method run
    n = actionModObj.run()
    # check if the list is empty

# Generated at 2022-06-23 08:07:33.722876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:07:43.254863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import os

    from ansible.utils.display import Display

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file = open(os.path.join(tmpdir, "testf"), "wb")
    file.write("testfile")
    file.close()

    display = Display()
    test_action_module = ActionModule(is_async=False, display=display)
    result = test_action_module._get_module_args('setup', {})
    assert isinstance(result, dict)
    assert result == {'filter': '*'}
    result = test_action_module._get_module_args('ansible.legacy.setup', {})
    assert isinstance(result, dict)

# Generated at 2022-06-23 08:07:47.317749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module