

# Generated at 2022-06-23 07:57:48.296973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.config.get_config_value('CONNECTION_FACTS_MODULES', variables={}) == {}

# Generated at 2022-06-23 07:57:54.780817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    import ansible.constants as C

    play_context = PlayContext()
    play_context._prompt = "test"
    play_context.passwords = {'sshpass': 'sshpass', 'becomepass': 'becomepass'}
    play_context.network_os = {'network_os': 'network_os'}
    play_context.network_os = {'network_os': 'network_os'}

    play_context._meta_vars = {}
    play_context._meta_vars['network_os'] = 'network_os'
    play_context._

# Generated at 2022-06-23 07:57:55.672244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:57:56.815454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run method of action module
    pass

# Generated at 2022-06-23 07:58:06.990648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    config_inst = mock.Mock()
    config_inst.get_config_value.return_value = ['ansible.legacy.setup']
    list.__ge__.return_value = True
    connection_inst = mock.Mock()
    config_inst.get_config_value.return_value = ['ansible.legacy.setup']
    connection_inst.load_name = 'network_cli'
    task_vars = {'ansible_facts_parallel': '_ansible_facts_parallel'}
    task_vars_copy = task_vars.copy()
    task = mock.Mock()
    task.args = None
    task_args = {'ansible_facts': None}
    task_args_copy = task_args.copy()
    task.module_

# Generated at 2022-06-23 07:58:11.667170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest

    from ansible.plugins.action.setup import ActionModule as AModule

    am = AModule(None, None, {})
    assert isinstance(am, AModule)

# Generated at 2022-06-23 07:58:12.343223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 07:58:22.163465
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.parsing.yaml.objects import AnsibleSequence

    actionModule = ActionModule(
        task=MockTask(args={}),
        connection=MockConnection(),
        play_context=MockPlayContext(),
        loader=MockLoader(),
        shared_loader_obj=MockLoader(),
        templar=MockTemplar(),
        task_vars=MockTaskVars(),
    )

    actionModule._execute_module = MockExecuteModule(ansibleModuleResult={})

    result = actionModule.run

# Generated at 2022-06-23 07:58:22.866811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:58:24.524478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 07:58:27.581622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, "_shared_loader_obj")

# Generated at 2022-06-23 07:58:28.301789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 07:58:37.273108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import pytest
    from ansible.module_utils.facts import is_blacklisted_module

    # check the __init__ and run methods of class ActionModule
    action = ActionModule()
    assert hasattr(action, 'run')
    assert hasattr(action, '_execute_module')
    assert hasattr(action, '_remove_tmp_path')
    assert hasattr(action, '_supports_check_mode')
    assert hasattr(action, '_connection')
    assert hasattr(action, '_display')
    assert hasattr(action, '_loader')
    assert hasattr(action, '_shared_loader_obj')
    assert hasattr(action, '_task')
    assert hasattr(action, '_templar')

    # check is_blacklisted_module() method of the class

# Generated at 2022-06-23 07:58:40.023819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 07:58:54.967483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up objects required by constructor
    task_execute_connection = None
    task_loader = None
    task_shared_loader_obj = None
    task_basedir = None
    task_play_context = None
    task_new_play_context = None
    task_new_task_vars = None
    task_block = None
    task_task_vars = None
    task_templar = None
    option_view = None
    popen_sp = None
    play_context = None
    loader = None

    # execute constructor and get result

# Generated at 2022-06-23 07:58:58.734410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.FACTS_MODULES != ['setup'], "FACTS_MODULES in ansible.cfg is set to setup. That is invalid"
    assert 'ansible.legacy.setup' in C.FACTS_MODULES, "FACTS_MODULES does not contain 'ansible.legacy.setup' in ansible.cfg"

# Generated at 2022-06-23 07:59:09.588907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict(filter='ansible_distribution')))
        ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

    tqm = None

# Generated at 2022-06-23 07:59:14.737066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    module_name = 'setup'
    module_args = {}
    module_class = 'ansible.module_utils.facts.system.distribution.Distribution'
    ansible_version_info = (2, 3)
    task_done = False
    module_result = {'ansible_facts': {'distribution': 'test_distribution'}}
    action_module = ActionModule(task=None, connection=None, _new_stdin=None, module_name=module_name,
                                 module_args=module_args, module_class=module_class,
                                 task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)
    action_module._supports_check_mode = True
    action_

# Generated at 2022-06-23 07:59:22.093935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test_playbook_path', 'test_play', 'test_task', 'test_action_line', 'test_task_ds', 'test_play_ds')
    assert action_module.playbook_path == 'test_playbook_path'
    assert action_module.play == 'test_play'
    assert action_module.task == 'test_task'
    assert action_module.action_line == 'test_action_line'
    assert action_module.task_ds == 'test_task_ds'
    assert action_module.play_ds == 'test_play_ds'

# Generated at 2022-06-23 07:59:29.818175
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.facts import get_module_path
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.module_utils._text import to_bytes

    # Test the '_combine_task_result' function
    r = ActionModule._combine_task_result(
        {'ansible_facts': {'test': 'test'}},
        {
            'ansible_facts': {'test2': 'test2'},
            'warnings': ["test warning"],
            'deprecations': [{'msg': 'test deprecation'}]
        },
    )

# Generated at 2022-06-23 07:59:39.378752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the object
    action_module = ActionModule()
    # create a mock task object
    mock_task = MagicMock()
    # set task object attribute connection with a MagicMock object
    mock_task.connection = MagicMock()
    # set task object attribute args with a MagicMock object
    mock_task.args = MagicMock()
    # set task object attribute _parent with a MagicMock object
    mock_task._parent = MagicMock()
    # set task object attribute _play with a MagicMock object
    mock_task._play = MagicMock()
    # call method run of object action_module using a mock task object and 2 mock variables as arguments
    result = action_module.run(task=mock_task, tmp=MagicMock(), task_vars=MagicMock())
    # return

# Generated at 2022-06-23 07:59:47.717224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor, with a fake task that does nothing
    config = dict(
        default_vars=dict(),
    )
    shared_loader = None
    task = dict(
        action=dict(
            module_name='setup',
            args=dict(),
            async_val=None,
        ),
        name='fake task',
    )
    try:
        action = ActionModule(task, config, shared_loader)
    except:
        print('Unexpected result')
        pass
    else:
        print('Expected result')
    # Test the constructor, with a fake task that does nothing
    config = dict(
        default_vars=dict(),
    )
    shared_loader = None

# Generated at 2022-06-23 07:59:49.406045
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module = ActionModule(ActionBase(),dict(),dict())

# Generated at 2022-06-23 07:59:50.178439
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module is not None

# Generated at 2022-06-23 07:59:50.740455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:59:56.226683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, new_stdin='stdin')
    assert isinstance(am, ActionBase), "Instance is of type %s, not %s" % (type(am), ActionBase)

# Generated at 2022-06-23 07:59:57.835247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert(module)

# Generated at 2022-06-23 08:00:08.910741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task():
        def __init__(self):
            self.args = {'parallel': False}

        def set_loader(self, loader):
            self._loader = loader

    class Connection():
        def __init__(self):
            self.name = 'local'
            self.transport = 'local'

    class Display():
        def __init__(self):
            self.verbosity = 0

    class PlayContext():
        def __init__(self):
            self.connection = 'local'

    class Play():
        def __init__(self):
            self._play_context = PlayContext()

    class Options():
        def __init__(self):
            self.module_defaults = 'defaults'


# Generated at 2022-06-23 08:00:19.544022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_result
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.play

    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback='default',
    )

# Generated at 2022-06-23 08:00:30.199448
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    config_instance = Config(None, None)
    config_instance.get_config_value = MagicMock(return_value=['ansible.legacy.setup'])

    params = {
        'gather_subset': ['all'],
        'filter': 'ansible_distribution*',
        'gather_timeout': 10,
    }


# Generated at 2022-06-23 08:00:30.726239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:00:37.588422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import task as task_module
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=VariableManager(),
        loader=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=True
    )
    task = task_module.Task()
    host = task_module.Host()
    task_vars = {}
    task.set_loader(tqm._loader)
    task.args.update({'parallel': True})
    host.set_variable('ansible_network_os', 'ntp')
    am = ActionModule('setup', task, host, task_vars)
   

# Generated at 2022-06-23 08:00:47.207403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Stub some objects
    task_vars=[]
    tmp=None
    result={
        'ansible_facts': {},
        'ansible_facts_gathered': {
            '_ansible_facts_gathered': True,
            'ansible_facts': {
                'ansible_facts_gathered': False
            }
        },
        'failed': False,
        'msg': ''
    }
    # Create the object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Do the test
    res = action_module.run(tmp=tmp, task_vars=task_vars)

    # Assertions
    assert action_module._supports_check_mode == True

# Generated at 2022-06-23 08:00:54.894795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    modules = []
    modules.append('setup_test_module')
    modules.append('setup_test_module2')
    task_vars = {'ansible_facts_parallel' : True}

    #ansible_facts = {}
    #ansible_facts['network_os'] = 'ios'
    #task_vars['ansible_facts'] = ansible_facts

    action_module = ActionModule()

    FAKE_TASK_OBJ = type('Task', (object,), {'args': {}})()
    action_module._task = FAKE_TASK_OBJ

    action_module._task.args = {'gather_subset': 'all'}

    #test_result = {}
    #test_result['ansible_facts'] = {'test_fact' : 'test_

# Generated at 2022-06-23 08:00:56.761373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test')
    assert am.action == 'test'



# Generated at 2022-06-23 08:01:04.176231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = __import__('ansible')
    constants = __import__('ansible.constants')
    constants.__dict__['DEFAULT_KEEP_REMOTE_FILES'] = True
    module_loader = __import__('ansible.plugins.loader')
    shared_loader_obj = module_loader.ActionModule._shared_loader_obj
    shared_loader_obj.path_exists_cache = dict()
    shared_loader_obj.system_data_cache = dict()
    shared_loader_obj.module_utils_caches = dict()
    shared_loader_obj.module_caches = dict()
    shared_loader_obj.module_cache_ttl = 60
    shared_loader_obj.module_loader = module_loader.ActionModule._shared_loader_obj
    shared_loader_obj.find_

# Generated at 2022-06-23 08:01:11.823264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    # set defaults
    tmp = None
    task_vars = None

    # create object of class ActionModule
    actionmodule = ActionModule()

    # create an object of context manager class
    mock_context = contextlib.nested(
        mock.patch.object(actionmodule, '_load_name_from_file'),
        mock.patch.object(actionmodule, '_execute_module')
    )

    # Use the above created context manager
    with mock_context as value:
        # Calling method run() of class ActionModule
        actionmodule.run(tmp, task_vars)
        # method run() should call method _execute_module
        assert actionmodule._execute_module.called == True
        # method run() should call method _execute_module


# Generated at 2022-06-23 08:01:13.131208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule constructor"""
    assert ActionModule.__doc__

# Generated at 2022-06-23 08:01:15.035511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run of class ActionModule
    module = ActionModule()
    assert module.run() == 'not implemented'


# Generated at 2022-06-23 08:01:16.561613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am._supports_check_mode == True

# Generated at 2022-06-23 08:01:19.407997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create module
    mod = ActionModule()

    # Create a temporary task
    with AnsibleTask(action=mod) as task:
        task.run()
        print(task.result)

# Generated at 2022-06-23 08:01:22.993716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = dict(
        ansible_facts=dict(),
        ansible_facts_gathered=True,
    )
    assert test == ActionModule.run(None, dict())

# Generated at 2022-06-23 08:01:32.780948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    original_stdout = sys.stdout
    sys.stdout = StringIO()
    tmp_dir = tempfile.mkdtemp()
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'jsonfile'
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = tmp_dir
    connection_map = {'connection_param': 'ansible.legacy.setup'}
    task_vars = {'ansible_facts_parallel': False, 'ansible_network_os': 'network_os', 'ansible_facts': {'network_os': 'network_os'}, 'ansible_cache_dir': 'dir'}
    module_list = ['module_1', 'module_2']
    ansible.plugins.action.ActionModule.C.config.CON

# Generated at 2022-06-23 08:01:37.126151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    m = Mock()
    m.return_value = None
    mod.run = m

    mod.run()
    assert m.called


# Generated at 2022-06-23 08:01:39.280029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return am

# Generated at 2022-06-23 08:01:43.894573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self):
            self.args = {}
    task = Task()
    task.module_defaults = {}
    actionmod = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(actionmod, ActionModule)

# Generated at 2022-06-23 08:01:44.555830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:01:45.247759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-23 08:01:45.894870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:01:48.794979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test for method run of class ActionModule.

    :return:
    """
    pass

# Generated at 2022-06-23 08:01:59.607777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks for testing
    tmp = None
    task_vars = {}
    task_vars['ansible_network_os'] = 'asr'
    task_vars['ansible_config_file'] = ''
    task_vars['ansible_facts_parallel'] = False
    task_vars['ansible_inventory_sources'] = ['@/etc/ansible/inventory']
    task_vars['ansible_facts_gather_subset'] = ['all']

# Generated at 2022-06-23 08:02:05.378898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(
        _raw_params='',
        _uses_shell=False,
        _uses_delegate=False,
        action='setup',
        _task=None,
        _connection=None,
        _shell=None,
        _play_context=None,
        shared_loader_obj=None,
        _task_vars=dict(),
        loader=None,
        parameterize=dict(),
        _ansible_version=None,
        _display=None,
        _templar=None
    )
    setup = ActionModule(**args)
    assert isinstance(setup, ActionModule)

# Generated at 2022-06-23 08:02:16.986390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    # Create an instance of ActionModule
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test when the facts_module runs successfully

# Generated at 2022-06-23 08:02:19.254996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # _supports_check_mode = True
    assert ActionModule._supports_check_mode == True

# Generated at 2022-06-23 08:02:19.910011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:02:30.206263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.plugins.cache import FactCache
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Host, Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    
    fact_cache = FactCache()
    

# Generated at 2022-06-23 08:02:40.618451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            action=dict(
                module_name='setup'
            )
        ),
        connection=dict(
            connection=dict(
                _load_name='local'
            )
        ),
        play_context=dict(
            check_mode=True,
            network_os=None
        ),
        loader=dict(
            all_vars=dict()
        ),
        templar=dict()
    )
    module_args = action_module._get_module_args(fact_module='setup', task_vars=dict())

    assert module_args['filter'] == '*'
    assert module_args['gather_subset'] == ['all']
    assert module_args['gather_timeout'] == 10

# Generated at 2022-06-23 08:02:41.704605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-23 08:02:42.329619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:02:44.857310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:02:45.514934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:02:46.946712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    to_test = ActionModule()
    assert isinstance(to_test, ActionModule)

# Generated at 2022-06-23 08:02:58.974819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from .fixtures import setup_task_deprecation

    task, action = setup_task_deprecation()
    action._execute_module = lambda module_name, module_args, task_vars, wrap_async: {'ansible_facts': {'one': 1}}
    result = action.run(task_vars={'ansible_facts': {}})
    assert result['failed'] is False
    assert result['ansible_facts']['_ansible_facts_gathered'] is True
    assert '_ansible_verbose_override' in result
    assert result['ansible_facts']['one'] == 1

    task, action = setup_task_deprecation()

# Generated at 2022-06-23 08:03:10.575575
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.common.collections import is_sequence
    mock_tmp = '/path/to/tmp_dir'
    mock_task_vars = {
        'ansible_facts': {
            'network_os': 'ios'
        }
    }
    mock_fail_module_name = 'mock_module'
    mock_fail_results = {
        'failed': True,
        'msg': 'Failed to execute'
    }
    mock_module_name = 'ansible.legacy.setup'
    mock_results = {
        'failed': False,
        'changed': False,
        'ansible_facts': {
            'mock_var': 'mock_val'
        }
    }

    action_module = ActionModule()
    action_module._supports_check

# Generated at 2022-06-23 08:03:11.833706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 08:03:14.766778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert isinstance(am, ActionBase)
    assert hasattr(am, 'run')
    assert hasattr(am, '_get_module_args')
    assert hasattr(am, '_combine_task_result')

# Generated at 2022-06-23 08:03:25.347790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = "loader"
    mock_connection = "connection"
    mock_play_context = "play_context"
    mock_task = "task"
    mock_templar = "templar"
    mock_shared_loader_obj = "shared_loader_obj"

    action_module = ActionModule(loader=mock_loader,
                                 connection=mock_connection,
                                 play_context=mock_play_context,
                                 task=mock_task,
                                 templar=mock_templar,
                                 shared_loader_obj=mock_shared_loader_obj)

    assert action_module.loader == mock_loader
    assert action_module.connection == mock_connection
    assert action_module.play_context == mock_play_context
    assert action_module.task

# Generated at 2022-06-23 08:03:27.622737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert random.randint(1, 10) == random.randint(1, 10)

# Generated at 2022-06-23 08:03:32.175991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule with the specified arguments
    arguments = {'args': {'a': '1'}}
    obj = ActionModule(None, arguments)

    # Try to run the module_executor
    obj.run()

# Generated at 2022-06-23 08:03:33.930141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert os.path.exists("/opt/ansible_test/test_action_module.py")
    return False

# Generated at 2022-06-23 08:03:45.386847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(ansible_facts=dict(network_os=None), ansible_distribution='none', ansible_os_family='none')
    action = ActionModule(None, dict(parallel=False), load_name="ansible.legacy.setup", connection_name="ansible.legacy.local")
    action._shared_loader_obj = None
    action._task = ActionModule.Task(None, None)
    action._task._parent = ActionModule.Play(None, None)
    action._task._parent._action_groups = ['setup']
    action._task._parent._play = ActionModule.PlayAPI()
    action._task._parent._play._action_groups = ['setup']
    action._task.args = dict(parallel=None)
    action._templar = None

# Generated at 2022-06-23 08:03:46.164805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:03:47.961755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating object
    am = ActionModule(None, None, None, None)

    # Test the run() method below
    am.run()

# Generated at 2022-06-23 08:03:48.916576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    actionmodule = ActionModule()
    assert actionmodule is not None

# Generated at 2022-06-23 08:03:49.426076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:03:56.689955
# Unit test for constructor of class ActionModule
def test_ActionModule():

    connection_plugin = ConnectionPlugin()

    task = MockTask()
    task_vars = dict(
        ansible_facts=dict(
            network_os='arista_eos')
    )

    action = ActionModule(task=task, connection=connection_plugin, play_context=PlayContext())
    result = action._get_module_args("ansible.legacy.setup", task_vars)
    # Should not raise exception
    assert result is not None


# Generated at 2022-06-23 08:04:07.877294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None, transport=None):
            assert module_name == 'ansible.legacy.setup'
            assert module_args['filter'] == 'ansible_all_ipv4_addresses,ansible_all_ipv6_addresses'
            assert task_vars['ansible_facts']['_ansible_facts_gathered'] == True
            assert wrap_async is False
            return dict(ansible_facts={}, skipped=False, failed=False, msg='')

    global_vars = dict()

# Generated at 2022-06-23 08:04:15.798294
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:04:25.411340
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.executor.task_result
    import ansible.executor.task_queue_manager

    class MockTaskExecutor(ansible.executor.task_queue_manager.TaskQueueManager):

        def __init__(self):
            self.finish_barrier = False

        def load_callbacks(self):
            pass

        def run(self):
            pass

    task = ansible.executor.task_result.TaskResult()
    task._connection = {}
    task_executor = MockTaskExecutor()
    action_module = ActionModule(task, task_executor, play_context=None, shared_loader_obj=None, templar=None)

# Generated at 2022-06-23 08:04:36.433916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean

    assert (ActionModule is not None)
    assert (ActionModule.__name__ == 'ActionModule')
    assert (ActionModule.__doc__ == '\n    Support execution of arbitrary modules using Ansible module_utils.\n    This action should not be used in playbooks! Use the M(include_*) action variants instead.\n    ')

    c = Connection()
    act_mdl = ActionModule(connection=c)
    assert (act_mdl is not None)
    assert (act_mdl._supports_check_mode == True)
    assert (act_mdl._supports_async == False)

# Generated at 2022-06-23 08:04:43.730469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO: Fix implementation of test, since the module is a placeholder.
    # from ansible.plugins.action.gather_facts import ActionModule
    # import pytest
    # d = dict(constants={'action_plugins': 'some_dir'})
    # m = ActionModule(d, 'some_dir')
    # with pytest.raises(NotImplementedError):
    #    m.run()


# Generated at 2022-06-23 08:04:52.052096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.module_utils
    import ansible.module_utils.facts.c_versioninfo
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual

    modules_mock = [
        "ansible.module_utils.facts.c_versioninfo",
        "ansible.module_utils.facts.system",
        "ansible.module_utils.facts.virtual"
    ]
    a = ActionModule({}, {'local': True}, "test")
    result = a.run(None, {'ansible_facts_modules': modules_mock})
    assert result['_ansible_verbose_override'] is True
    assert result['ansible_facts']['_ansible_facts_gathered'] is True

# Generated at 2022-06-23 08:04:53.308492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    assert False

# Generated at 2022-06-23 08:04:57.713715
# Unit test for constructor of class ActionModule
def test_ActionModule():
   """
   This test is aimed at testing the constructor of AnsibleModule 
   """
   action_module = ActionModule()
   print(action_module.run(tmp=None, task_vars=None))

# Generated at 2022-06-23 08:04:58.594776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(False, False, False)

# Generated at 2022-06-23 08:04:59.471988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-23 08:05:01.289528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = Mock(spec=None)
    action_module = ActionModule(mock_connection)
    assert action_module._connection == mock_connection

# Generated at 2022-06-23 08:05:02.263731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    assert module is not None

# Generated at 2022-06-23 08:05:03.157421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-23 08:05:11.405671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test to run method run of class ActionModule
    # action_module = (ActionBase()), 'tmp' defines temporary path, 'taskvars' defines task variables
    # assert a == b returns an error if a is not equal to b
    # assert a == b returns nothing if a is equal to b
    # assert a == b returns success if a is equal to b
    action_module = ActionModule(ActionBase(), 'tmp', 'taskvars')
    result = action_module.run()
    assert result == 'The following modules were skipped: %s\n', 'failed_modules'
    assert result == 'The following modules failed to execute: %s\n', 'failed_modules'

# Generated at 2022-06-23 08:05:12.541882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:05:15.964831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockModule:
        def __init__(self, *args):
            pass

    class MockModuleLoader:
        def __init__(self, *args):
            pass

    class MockModuleFinder:
        def __init__(self, *args):
            pass

    under_test = ActionModule(MockModule, task_vars=[])

    assert under_test.run() == {}

# Generated at 2022-06-23 08:05:25.433115
# Unit test for constructor of class ActionModule
def test_ActionModule():

    tmp = None
    task_vars = {}

    # Create an instance of class ActionModule
    action = ActionModule(tmp, task_vars)
    print(action)

    # Get base class attribute '_supports_check_mode'
    supports_check_mode = action.SUPPORTS_CHECK_MODE
    print(supports_check_mode)
    # Note: above statement is equivalent to:
    #    print(action.SUPPORTS_CHECK_MODE)

    # Get an instance attribute
    task = action._task
    print(task)

    # Get a base class (ActionBase) instance attribute
    _shared_loader_obj = action._shared_loader_obj
    print(_shared_loader_obj)

    # Get a base class (ActionBase) instance attribute
    _templar = action._templar
   

# Generated at 2022-06-23 08:05:35.905702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setup_args = {
        'collection_list': [],
        'role_name': 'test-role',
        'task_name': 'setup',
    }
    setup_connection = 'setup'
    setup_task = 'setup'
    setup_action = ActionModule(setup_task, setup_connection, setup_args)
    setup_task_vars = {
        'ansible_facts': {},
        'ansible_facts_parallel': 'True',
        'ansible_network_os': 'test-network-os',
    }
    setup_result = setup_action.run(tmp='', task_vars=setup_task_vars)

    assert setup_result['ansible_facts'] == {'_ansible_facts_gathered': True}

# Generated at 2022-06-23 08:05:38.944642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global actionModule # pylint: disable=W0603
    actionModule = ActionModule('TestModule', {'name': 'TestModule'}, {'verbosity': 0})


# Generated at 2022-06-23 08:05:47.944774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Mock_Task:
        def __init__(self, args):
            self.args = args

    class Mock_Module_Utils_Get_Os_Distribution_Redhat:
        @staticmethod
        def get_distribution():
            return 'foo'

    class Mock_Module_Utils_Get_Os_Distribution:
        @staticmethod
        def get_distribution():
            return 'bar'

    class Mock_Module_Utils_Get_Distribution_Short:
        @staticmethod
        def get_distribution_short():
            return 'bar'

    class Mock_ActionBase:
        def __init__(self, task_vars):
            self._task_vars = task_vars

        def _remove_tmp_path(self, path):
            pass


# Generated at 2022-06-23 08:05:59.888134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection_info = {'network_os': 'ios'}
    mytask = 'setup'
    mytemplar = 'templar'
    myloader = 'loader'
    myshared_loader_obj = 'shared_loader_obj'
    myplay = 'play'
    mynew_stdin = 'new_stdin'
    myconnection = 'connection'
    my_play_context = 'play_context'
    mytmp = 'tmp'
    mytask_vars = {'network_os': 'ios', 'ansible_facts_parallel': False}
    my_task = '_task'
    my_connection = '_connection'
    my_loader = '_loader'
    my_shared_loader_obj = '_shared_loader_obj'

# Generated at 2022-06-23 08:06:02.427417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
    # There is no way to construct an instance of the ActionModule class because it is an abstract class

# Generated at 2022-06-23 08:06:07.576472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    example = '''
        action:
            - { module: setup, ignore_errors: no }
            - { module: file, src: /etc/foo.conf, dest: /etc/bar.conf, ignore_errors: no }
        pre_tasks:
            - { action: action_setup, ignore_errors: no }
        '''
    try:
        action_module = ActionModule(example)
    except Exception as e:
        print("Exception occured: " + str(e))

test_ActionModule()

# Generated at 2022-06-23 08:06:12.738578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    info = {}
    info['module_name'] = 'setup'
    info['module_args'] = {}
    info['wrap_async'] = True
    info['task_vars'] = {}
    info['task_vars']['ansible_facts_parallel'] = False
    info['task_vars']['ansible_network_os'] = 'junos'
    info['connection'] = {}
    info['connection']['_load_name'] = 'network_cli'
    info['task'] = {}
    info['task']['args'] = {}
    info['task']['args']['gather_network_resources'] = None
    info['task']['args']['gather_timeout'] = None
    info['task']['args']['filter'] = None

# Generated at 2022-06-23 08:06:15.433660
# Unit test for constructor of class ActionModule
def test_ActionModule():

    setup = ActionModule()

    # TODO(ztane): Setup any test data that you need here.

    # Run the constructor.
    # TODO(ztane): Pass any appropriate args to the constructor.
    setup.run()

# Generated at 2022-06-23 08:06:19.886956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader

    action = action_loader._create_context("setup", {}, None, None, {})
    ActionModule._get_module_args("setup", {})
    action._execute_module("setup", {}, {})

# Generated at 2022-06-23 08:06:23.780869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-23 08:06:29.664787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included_file import IncludedFile
    from ansible.cli import CLI

# Generated at 2022-06-23 08:06:39.307767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase

    class ActionModule(ActionBase):
        def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None, wrap_async=None):
            return dict(ansible_facts=dict(fact1="fact1"), warnings=["warn"], deprecations=["depr"])

    task_input_data = dict(
        ansible_facts=dict(fact2="fact2"),
        ansible_facts_parallel=True,
        parallel=False,
    )


# Generated at 2022-06-23 08:06:47.963942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader

    class TestActionModule(ActionModule):

        def _get_module_args(self, fact_module, task_vars):
            mod_args = self._task.args.copy()
            return mod_args

        def run(self, tmp=None, task_vars=None):
            module_name = self._task.action
            mod_args = self._task.args
            wrap_async = self._task.async_val
            res = self._execute_module(module_name=module_name, module_args=mod_args, task_vars=task_vars, wrap_async=wrap_async)
            return res

    class TestExecutor(object):

        def __init__(self):
            self.plugins = ansible.plugins.loader.ActionModuleLoader()

# Generated at 2022-06-23 08:06:50.061059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-23 08:07:04.341918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    playbook = Playbook()
    hosts = set(['127.0.0.1'])
    play_ds = Play().load(dict(
        name='test',
        hosts=hosts,
        gather_facts='no',
        tasks=[
            dict(
                action='setup'
            )
        ]
    ),
    variable_manager=playbook.get_variable_manager(), loader=playbook._loader)

    play_ds._post_validate_tasks()
    play_ds

# Generated at 2022-06-23 08:07:15.843926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import is_v2_0
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader

    config = dict(FACTS_MODULES=['ansible.legacy.setup'])
    variables = VariableManager()
    queue = TaskQueueManager(config, None, action_loader)
    queue._play = dict(play=dict(name='test', tasks=[]))

    setup_task = queue.task_factory('setup')
    setup_task._play = queue._play
    setup_task._connection = dict(connection='local')
    setup_task._parent = dict(task='setup')
   

# Generated at 2022-06-23 08:07:27.059365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # issue_17244
    # https://github.com/ansible/ansible/blob/devel/test/units/plugins/actions/test_setup.py#L60
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.result import ResultProcessor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task import HandlerTask
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 08:07:30.963214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    task = Task()
    task._parent = task
    task.action = 'setup'
    task.args = dict(a=1, b='2', c=False, d=True, e=3.3, network_os='ios', parallel=True)

    action = ActionModule(task, None, 0)
    assert type(action) == ActionModule

# Generated at 2022-06-23 08:07:32.648290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:07:40.532644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(None)
    # TODO: write unit test
    # Fake up the connection_loader and shared_loader_obj attributes
    mod.connection_loader = None
    mod.shared_loader_obj = None
    # Fake up the _task attribute
    mod._task = None
    # Fake up the _templar attribute
    mod._templar = None
    # Fake up the _connection attribute
    mod._connection = None
    # Fake up the _display attribute
    mod._display = None
    # Return a fake results dict
    return dict()


# Generated at 2022-06-23 08:07:41.744463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:07:54.238883
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from collections import namedtuple
    from ansible.executor.module_common import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    fake_connection = namedtuple('fake_connection', ['_shell', '_load_name'])
    fake_shell = namedtuple('fake_shell', ['tmpdir'])
    fake_task = namedtuple('fake_task', ['_parent', 'collections', 'args', 'module_defaults'])
    fake_play = namedtuple('fake_play', ['_action_groups'])

    def fake_remove_tmp_path(path):
        pass


    # Create a fake ActionModule object