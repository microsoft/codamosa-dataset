

# Generated at 2022-06-17 08:59:29.445835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock action module
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display, action_base)
    # Check the result
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._shared_loader_obj == shared_loader_obj
    assert action_module._templar == templar
   

# Generated at 2022-06-17 08:59:30.056942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:35.265884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = MockTask()
    # Create a mock connection
    mock_connection = MockConnection()
    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    mock_display = MockDisplay()
    # Create a mock templar
    mock_templar = MockTemplar()
    # Create a mock config
    mock_config = MockConfig()
    # Create a mock module loader
    mock_module_loader = MockModuleLoader()
    # Create a mock module finder
    mock_module_finder = MockModuleFinder()
    # Create a mock module
    mock_module = MockModule()
    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()
    # Create a mock action plugin loader
   

# Generated at 2022-06-17 08:59:46.932393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_resolver = MockModuleResolver()
    # Create a mock module finder object
    module_loader_obj = MockModuleLoaderObj()
    # Create a mock module finder object
    module

# Generated at 2022-06-17 08:59:57.814120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock result
    result = dict()
    # Create a mock modules
    modules = ['ansible.legacy.setup']
    # Create a mock parallel
    parallel = None
    # Create a mock fact_module

# Generated at 2022-06-17 09:00:07.451513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class PluginLoader
    plugin_loader = PluginLoader()

# Generated at 2022-06-17 09:00:08.343806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:00:09.909212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None)
    assert action_module._supports_check_mode == True

# Generated at 2022-06-17 09:00:15.068244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)

    # Create a mock task_vars
    task_vars = dict()
    task_vars['ansible_facts_parallel'] = None
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['network_os'] = 'ios'

    # Create a mock result
    result = dict()
    result['ansible_facts']

# Generated at 2022-06-17 09:00:16.012012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:36.467532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of TaskResult
    task_result = TaskResult()

    # Create an instance of Task
    task = Task()

    # Create an instance of PlayContext
    play_context = PlayContext()

    # Create an instance of Play
    play = Play()

    # Create an instance of Playbook
    playbook = Playbook()

    # Create an instance of Runner
    runner = Runner()

    # Create an instance of Connection
    connection = Connection()

    # Create an instance of Shell
    shell = Shell()

    # Create an instance of SharedPluginLoaderObj
    shared_plugin_loader

# Generated at 2022-06-17 09:00:46.154800
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:56.755012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task.vars = {'ansible_facts_parallel': None}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create a mock config object
    config = MockConfig()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module

# Generated at 2022-06-17 09:01:07.253359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = {
        'args': {
            'filter': '*',
            'gather_subset': 'all',
            'gather_timeout': 10,
            'parallel': False
        },
        'collections': [],
        'module_defaults': {},
        'name': 'setup'
    }

    # Create a mock connection
    mock_connection = {
        '_load_name': 'network_cli'
    }

    # Create a mock display
    mock_display = {
        'warning': lambda x: None,
        'vvvv': lambda x: None
    }

    # Create a mock shared loader object

# Generated at 2022-06-17 09:01:10.482922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:14.856256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:01:21.212237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': 'True'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock config
    config = MockConfig()
    config.get_config_value.return_value = ['ansible.legacy.setup']

    # Create a mock constants
    constants = Mock

# Generated at 2022-06-17 09:01:23.058792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None, modules=['ansible.legacy.setup', 'ansible.legacy.setup']
    # and parallel=True
    pass

# Generated at 2022-06-17 09:01:34.929148
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:43.710418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock display
    display = MockDisplay()
    # create a mock action plugin
    action_plugin = MockActionPlugin()
    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock module loader
    module_loader = MockModuleLoader()
    # create a mock module finder
    module_finder = MockModuleFinder()
    # create a mock module finder plugin
    module_finder_plugin = MockModuleFinderPlugin()
    # create a mock module finder plugin
    resolved_fqcn = MockResolved

# Generated at 2022-06-17 09:02:08.577802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:02:19.620091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:02:21.026245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:02:24.694259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:02:36.892654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader_obj, templar, display, config)
    # Create a mock task vars
    task_vars = {}
    # Create a mock tmp
    tmp = None
    # Create a mock result
    result = {'ansible_facts': {}}


# Generated at 2022-06-17 09:02:48.129847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None
    assert action_module._display is None

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, None, None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._task is None
    assert action_module._

# Generated at 2022-06-17 09:02:58.258479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:02:59.216869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:08.251750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.network_legacy
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.raw
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_find

# Generated at 2022-06-17 09:03:10.536439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:04:24.550864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task.module_defaults = {}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp/ansible-tmp-1548698856.9-255819553538963'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = MockModuleLoader()
    shared_loader_obj.module_loader.find_plugin_with_context = MockFindPluginWithContext()
    shared_loader_obj.module_loader.find_plugin_with_context.return_value = MockResolvedF

# Generated at 2022-06-17 09:04:33.542799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*',
                parallel=False
            )
        ),
        connection=dict(
            _load_name='network_cli'
        ),
        templar=None,
        shared_loader_obj=None,
        connection_loader=None,
        play_context=None,
        loader=None,
        templar_loader=None,
        task_vars=None,
        default_vars=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:04:38.020398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import OpenBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SmartOSDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import WindowsDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DarwinDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import FreeBSDDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import NetBSDDistributionFactCollector

# Generated at 2022-06-17 09:04:45.308322
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:50.711775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 09:04:55.400593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:05:06.640260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()

    # Create a mock action module
    action_module = ActionModule(task, connection)

    # Create a mock task vars
    task_vars = {
        'ansible_facts_parallel': True,
        'ansible_facts': {
            'network_os': 'ios'
        }
    }

    # Create a mock result
    result = {
        'ansible_facts': {
            '_ansible_facts_gathered': True
        },
        '_ansible_verbose_override': True
    }

    # Run the action module
    action_module.run(task_vars=task_vars)

    # Assert that the result is as expected

# Generated at 2022-06-17 09:05:10.605321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:05:18.863654
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:19.859580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-17 09:07:38.628620
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:07:51.082659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': False}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock action base object
    action_base_obj = ActionBase()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object

# Generated at 2022-06-17 09:07:59.957398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants

# Generated at 2022-06-17 09:08:11.077955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module plugin
    module_plugin = MockModulePlugin()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock config
    config = MockConfig()
    # Create a mock constants
    constants = Mock

# Generated at 2022-06-17 09:08:17.936902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_resolver
    module_resolver = MockModuleResolver()
    # Create a mock module_utils
    module_utils

# Generated at 2022-06-17 09:08:31.482974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock config
    config = MockConfig()
    # Create a mock constants
    constants = MockConstants()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a

# Generated at 2022-06-17 09:08:37.970895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.network_legacy
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.raw
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_find

# Generated at 2022-06-17 09:08:47.989647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = dict()
    # Create a mock result
    result = dict()
    # Create a mock modules
    modules = ['ansible.legacy.setup']
    # Create a mock parallel
    parallel = True
    # Create a mock fact_module

# Generated at 2022-06-17 09:08:53.985962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule()
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is False
    assert action_module._supports_become is False
    assert action_module._supports_diff is False
    assert action_module._supports_subset is False
    assert action_module._supports_tags is False
    assert action_module._supports_version is False
    assert action_module._supports_wait is False
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is False
    assert action_module._supports_become is False
    assert action_module._supports_diff is False
    assert action_module._supports_

# Generated at 2022-06-17 09:09:03.160467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Shell
    shell = Shell()

    # Create an instance of class Display
    display = Display()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create an instance of class PluginLoader
    plugin_loader = PluginLoader()

    # Create an instance of class Plugin
    plugin = Plugin()

    # Create an instance of class Play
    play = Play()

    # Create