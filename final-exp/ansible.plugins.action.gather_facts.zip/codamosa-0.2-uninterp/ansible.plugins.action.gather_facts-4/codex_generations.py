

# Generated at 2022-06-17 08:59:25.734193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with empty modules
    action_module = ActionModule()
    action_module._task = {'args': {}}
    action_module._task.args = {}
    action_module._task.args['parallel'] = None
    action_module._task._parent = {'_play': {'_action_groups': []}}
    action_module._task._parent._play._action_groups = []
    action_module._task._parent._play._action_groups.append({'name': 'setup', 'actions': []})
    action_module._task._parent._play._action_groups[0]['actions'].append({'name': 'setup', 'module_name': 'setup'})

# Generated at 2022-06-17 08:59:26.493664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:33.174807
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:46.065879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock config
    mock_config = MockConfig()

    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock module finder
    mock_module_finder = MockModuleFinder()

    # Create a mock module finder find_plugin method
    mock_module_finder

# Generated at 2022-06-17 08:59:54.881148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:00:05.184377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task vars
    task_vars = {'ansible_facts': {'network_os': 'ios'}}
    # Create a mock tmp
    tmp = '/tmp'
    # Call the run method of the action module
    result = action_module.run(tmp, task_vars)
    # Assert that the result is not None
    assert result is not None



# Generated at 2022-06-17 09:00:12.738607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:00:15.545948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 09:00:20.671355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:00:25.275941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True
    # Test with parallel=False
    pass

# Generated at 2022-06-17 09:00:48.599829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_

# Generated at 2022-06-17 09:00:52.706667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:01:02.333943
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:09.799726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True
    # Test with parallel=False
    # Test with parallel=True and module failed
    # Test with parallel=True and module skipped
    # Test with parallel=False and module failed
    # Test with parallel=False and module skipped
    pass

# Generated at 2022-06-17 09:01:22.279859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()

    # create a mock connection
    connection = MockConnection()

    # create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # create a mock templar obj
    templar_obj = MockTemplarObj()

    # create a mock display obj
    display_obj = MockDisplayObj()

    # create a mock config obj
    config_obj = MockConfigObj()

    # create a mock module loader obj
    module_loader_obj = MockModuleLoaderObj()

    # create a mock module finder obj
    module_finder_obj = MockModuleFinderObj()

    # create a mock module finder obj
    module_finder_obj = MockModuleFinderObj()

    # create a mock module finder obj
    module_finder_obj = Mock

# Generated at 2022-06-17 09:01:34.630579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = None
    task.args['gather_subset'] = None
    task.args['gather_timeout'] = None
    task.args['filter'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args['ansible_facts_parallel'] = None
    task.args

# Generated at 2022-06-17 09:01:45.906437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder

# Generated at 2022-06-17 09:01:58.419725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleF

# Generated at 2022-06-17 09:01:59.762459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:02:03.836382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am is not None

    # Test with args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-17 09:02:28.169856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:02:37.852742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    from ansible.module_utils.facts.virtual.lspci import LspciVirtual
    from ansible.module_utils.facts.virtual.lscpu import LscpuVirtual

# Generated at 2022-06-17 09:02:43.954455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_resolver = MockModuleResolver()
    # Create a mock module finder object
    module_loader_obj = MockModuleLoaderObj()
    # Create a mock module finder object
    module

# Generated at 2022-06-17 09:02:51.023637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task vars
    task_vars = {}
    # Create a mock tmp
    tmp = None
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert result is not None
    assert result is not None


# Generated at 2022-06-17 09:02:53.287157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:54.418764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:03:07.625495
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:03:18.861155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars

# Generated at 2022-06-17 09:03:28.932075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task.module_defaults = {}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock module loader object


# Generated at 2022-06-17 09:03:32.726169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module._supports_check_mode is True


# Generated at 2022-06-17 09:04:45.264228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock action_groups
   

# Generated at 2022-06-17 09:04:50.347919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:05:02.542142
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:15.102334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock templar obj
    templar = MockTemplar()
    # create a mock display obj
    display = MockDisplay()
    # create a mock config obj
    config = MockConfig()
    # create a mock module loader obj
    module_loader = MockModuleLoader()
    # create a mock module obj
    module = MockModule()
    # create a mock action plugin obj
    action_plugin = MockActionPlugin()
    # create a mock module_utils obj
    module_utils = MockModuleUtils()
    # create a mock module_utils obj
    module_utils = MockModuleUtils()
    #

# Generated at 2022-06-17 09:05:25.843092
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:35.205754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create an action module object
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Test the constructor of the action module object
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._shared_loader_obj == shared_loader_obj
    assert action_module._templar == templar
    assert action_module._display == display


# Generated at 2022-06-17 09:05:43.812068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {'ansible_facts_parallel': True}
    # Create a mock result
    result = {'ansible_facts': {}}
    # Create a mock tmp
    tmp = None
    # Call the method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert that

# Generated at 2022-06-17 09:05:53.996150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder result
    module_finder_result = MockModuleFinderResult()

    # Create a mock module finder result
    module_finder_result_resolved_

# Generated at 2022-06-17 09:06:05.966515
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:06:16.769523
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:34.780433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:08:35.581579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:08:36.159973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:48.257605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task

# Generated at 2022-06-17 09:08:51.568442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:09:00.408804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleF