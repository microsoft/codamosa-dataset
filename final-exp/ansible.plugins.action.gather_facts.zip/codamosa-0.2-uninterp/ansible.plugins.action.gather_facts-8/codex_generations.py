

# Generated at 2022-06-17 08:59:20.572873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(None, None, None, None)
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 08:59:22.553602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:59:28.021839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.win_setup
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_chocolatey
    import ansible.plugins.action.win_package
    import ansible.plugins.action.win_group
    import ansible.plugins.action.win_user
    import ansible.plugins.action.win_firewall
    import ansible.plugins.action.win_service
    import ansible.plugins.action.win_feature
    import ansible.plugins.action.win_disk_facts
    import ans

# Generated at 2022-06-17 08:59:28.636780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:41.084054
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:51.684531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock module default
    module_default = MockModuleDefault()

    # Create a mock task parent
    task_parent = Mock

# Generated at 2022-06-17 08:59:58.338655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.basic
    module_utils_basic = MockModuleUtilsBasic()

    # Create a mock module_utils.connection
    module_utils_connection = MockModuleUtilsConnection()

    #

# Generated at 2022-06-17 09:00:07.979301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    #

# Generated at 2022-06-17 09:00:13.971214
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:16.322713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:00:33.299392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {'ansible_facts_parallel': True}
    # Create a mock tmp
    tmp = 'tmp'
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert the result

# Generated at 2022-06-17 09:00:42.366205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock config
    config = MockConfig()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    module_

# Generated at 2022-06-17 09:00:55.983224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, display, templar)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock tmp
    tmp = dict()

    # Create a mock modules
    modules = ['ansible.legacy.setup']

    # Create a mock parallel
    parallel = True

    # Create a mock failed
    failed = dict()

    # Create a

# Generated at 2022-06-17 09:01:02.623576
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:05.478841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:01:07.303684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:01:12.021375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy task
    from ansible.playbook.task import Task
    task = Task()
    task._role = None
    task._parent = None
    task._play = None
    task._ds = None
    task._role = None
    task._loader = None
    task._block = None
    task._loop = None
    task._when = None
    task._always = None
    task._any_errors_fatal = None
    task._any_errors_fatal_configured = None
    task._any_errors_fatal_ignore_errors = None
    task._notify = None
    task._notified_by = None
    task._tags = None
    task._dep_chain = None
    task._loop_with_items = None
    task._loop_with_items_count = None
    task._

# Generated at 2022-06-17 09:01:14.174062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:22.956834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no modules
    task_vars = dict(
        ansible_facts_parallel=None,
        ansible_network_os=None,
        ansible_facts=dict(
            network_os=None
        )
    )

# Generated at 2022-06-17 09:01:34.890997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar_obj = MockTemplarObj()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()
    # Create a mock module
    module = MockModule()
    # Create a mock module result
    module_result = MockModuleResult()
    # Create a mock module result
    module_result2 = MockModuleResult()
    # Create a mock module result
    module_result3 = MockModuleResult()
    # Create a mock module result

# Generated at 2022-06-17 09:01:56.907265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:01:59.112468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:02:07.457234
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:17.789044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleF

# Generated at 2022-06-17 09:02:32.117901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock plugin loader object
    plugin_loader = MockPluginLoader()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock action plugin loader object
    action_plugin_loader = MockAction

# Generated at 2022-06-17 09:02:44.805356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock module
    module = MockModule()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock config object
    config = MockConfig()

    # Create a mock task_vars object
    task_vars = MockTaskVars()

    # Create a mock tmp object
    tmp = MockTmp()

    # Create a mock module_loader object
    module_loader = MockModuleLoader

# Generated at 2022-06-17 09:02:56.865516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock action plugin loader object
    action_plugin_loader = MockActionPluginLoader()
    # Create a mock cache object
    cache = MockCache()
    # Create a mock connection info object
    connection_info = MockConnectionInfo

# Generated at 2022-06-17 09:03:04.247016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:03:13.083876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._shared_loader_obj == None
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._display == None

    # Test with parameters
    am = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert am._supports_check_mode == True
    assert am._shared_loader_obj == None
    assert am._task == None
    assert am._connection == None

# Generated at 2022-06-17 09:03:20.695243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': False}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock config
    config = MockConfig()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, module_loader, shared_loader_obj, display, config)

    # Create a mock task vars

# Generated at 2022-06-17 09:04:38.633776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock templar object
    templar = MockTemplar()
    # create a mock display object
    display = MockDisplay()
    # create a mock config object
    config = MockConfig()
    # create a mock module loader object
    module_loader = MockModuleLoader()
    # create a mock module finder object
    module_finder = MockModuleFinder()
    # create a mock module finder object
    module_resolver = MockModuleResolver()
    # create a mock module finder object
    module_resolver_fqcn = MockModuleResolverFqcn()
    # create a mock module

# Generated at 2022-06-17 09:04:50.368746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module_defaults object
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups object
    action_groups = MockActionGroups()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock play object
    play = MockPlay()
    # Create a mock play_context object
    play_context = MockPlayContext()
   

# Generated at 2022-06-17 09:05:02.539519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*',
                parallel=True
            )
        ),
        connection=dict(
            _load_name='network_cli'
        ),
        task_vars=dict(
            ansible_network_os='ios'
        )
    )
    assert action_module._get_module_args('ansible.legacy.setup', dict(ansible_network_os='ios')) == dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )

# Generated at 2022-06-17 09:05:09.841106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock result
    result = MockResult()

    # Create a mock

# Generated at 2022-06-17 09:05:17.035805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()
    # Create a mock ansible module
    ansible_module = MockAnsibleModule()
    # Create a mock ansible module loader
    ansible_module_loader = MockAnsibleModuleLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils.parsing.convert_bool
   

# Generated at 2022-06-17 09:05:31.306601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of class TaskExecutor
    task_executor = TaskExecutor()

    # Create a mock of class Task
    task = Task()

    # Create a mock of class PlayContext
    play_context = PlayContext()

    # Create a mock of class Connection
    connection = Connection()

    # Create a mock of class Shell
    shell = Shell()

    # Create a mock of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Create a mock of class PluginLoader
    plugin_loader = PluginLoader()

    # Create a mock of class Plugin
    plugin = Plugin()

    # Create a mock of class AnsibleModule
    ansible_module = AnsibleModule()

    # Set the attributes of the mock of class TaskExec

# Generated at 2022-06-17 09:05:42.611716
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:53.160163
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:06:04.042084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-17 09:06:05.041198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this
    pass

# Generated at 2022-06-17 09:08:28.392575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:29.047743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:08:36.042424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert result

# Generated at 2022-06-17 09:08:36.966261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:41.746307
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:52.112287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create an action module object
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display, action_base)

    # Check if the action module object is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the action module object is an instance of ActionBase
    assert isinstance(action_module, ActionBase)



# Generated at 2022-06-17 09:09:03.057208
# Unit test for constructor of class ActionModule