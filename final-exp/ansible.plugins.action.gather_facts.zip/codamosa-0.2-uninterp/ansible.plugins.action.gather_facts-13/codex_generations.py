

# Generated at 2022-06-17 08:59:20.657582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 08:59:27.030574
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:39.575341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants
    constants = MockConstants()

    # Create a mock module_defaults
    module

# Generated at 2022-06-17 08:59:50.552294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'parallel': None}
    task.module_defaults = {}
    task.collections = []

    # Create a mock connection object
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock config object
    config = MockConfig()

    # Create a mock action base object
    action_base = ActionBase()

    # Create a mock action module object

# Generated at 2022-06-17 09:00:02.943728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule()
    assert action_module._supports_check_mode is True
    assert action_module._shared_loader_obj is not None
    assert action_module._templar is not None
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is not None
    assert action_module._display is not None
    assert action_module._task_vars is None
    assert action_module._tmp is None
    assert action_module._task_vars_tmp is None
    assert action_module._result is None
    assert action_module._task_path is None
    assert action_module._task_name is None
    assert action_module._task_deps is None
   

# Generated at 2022-06-17 09:00:14.016538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset='all',
                gather_timeout=10,
                filter='*'
            )
        ),
        connection=dict(
            _load_name='network_cli'
        ),
        task_vars=dict(
            ansible_facts_parallel=True
        )
    )
    assert action_module._get_module_args('ansible.legacy.setup', dict()) == dict()
    assert action_module._get_module_args('ansible.legacy.setup', dict(ansible_facts=dict(network_os='ios'))) == dict(
        gather_subset='all',
        gather_timeout=10,
        filter='*'
    )
    assert action_module._get_module_args

# Generated at 2022-06-17 09:00:25.223982
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:36.037291
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:48.532246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AI

# Generated at 2022-06-17 09:01:00.079919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.vars.manager import VariableManager
   

# Generated at 2022-06-17 09:01:22.470695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerOptions
    ansible_runner_options = AnsibleRunnerOptions()

    # Create an instance of AnsibleRunnerResult
    ansible_runner_result = AnsibleRunnerResult()

    # Create an instance of AnsibleRunnerResultItem
    ansible_runner_result_item = Ans

# Generated at 2022-06-17 09:01:34.708294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module object
    module = MockModule()

    # Create a mock module finder object
    module_finder = MockModuleFinder()
    module_finder.resolved_fqcn = 'ansible.legacy.setup'

    # Create a mock module finder object
    module_finder_2 = MockModuleFinder()
   

# Generated at 2022-06-17 09:01:45.946116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:01:58.417261
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:10.709525
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:11.384878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:02:12.845684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with parallel=None and len(modules) >= 1
    # test with parallel=True
    # test with parallel=False
    pass

# Generated at 2022-06-17 09:02:20.889799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict())),
        connection=dict(module_name='local', module_args=dict()),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 09:02:28.532054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am is not None

    # Test with parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-17 09:02:40.650775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:03:01.354767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:03:09.554694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of Task
    task = Task()

    # Create an instance of PlayContext
    play_context = PlayContext()

    # Create an instance of Connection
    connection = Connection()

    # Create an instance of ShellModule
    shell_module = ShellModule()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleShell
    ansible_shell = AnsibleShell()

    # Set the attributes of the AnsibleShell instance

# Generated at 2022-06-17 09:03:10.724568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:03:22.523036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution

# Generated at 2022-06-17 09:03:32.058490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution
    from ansible.module_utils.facts.system.distribution import HPUXDistribution

# Generated at 2022-06-17 09:03:41.084908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = dict(
        action=dict(
            module_name='setup',
            module_args=dict(
                filter='ansible_distribution'
            )
        )
    )

    # Create a fake play context

# Generated at 2022-06-17 09:03:51.541642
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:03:52.399953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    assert True

# Generated at 2022-06-17 09:03:59.882549
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:11.353409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder_resolved = MockModuleFinderResolved()
    # Create a mock module finder object
    module_finder_resolved_fqcn = MockModuleFinderResolvedF

# Generated at 2022-06-17 09:05:09.120505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants
    constants = MockConstants()

    # Create a mock connection_facts_modules
    connection_facts_modules = MockConnectionFactsModules()

    # Create a mock facts

# Generated at 2022-06-17 09:05:16.578247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock play object
    play

# Generated at 2022-06-17 09:05:25.889896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(
        task=dict(
            action=dict(
                module_name='setup',
                module_args=dict(
                    filter='ansible_distribution'
                )
            )
        ),
        connection=dict(
            transport='local'
        ),
        play_context=dict(
            check_mode=False,
            network_os='ios'
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # _get_module_args test
    assert module._get_module_args('setup', dict(
        ansible_facts=dict(
            network_os='ios'
        )
    )) == dict(
        filter='ansible_distribution'
    )

    # _combine_task

# Generated at 2022-06-17 09:05:36.876235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerConfig
    ansible_runner_config = AnsibleRunnerConfig()

    # Create an instance of AnsibleRunnerConfigData
    ansible_runner_config_data = AnsibleRunnerConfigData

# Generated at 2022-06-17 09:05:37.241717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:46.723455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = {
        'args': {
            'parallel': True,
            'network_os': 'ios'
        },
        'collections': [],
        'module_defaults': {},
        'module_name': 'setup'
    }

    # Create a fake connection
    connection = {
        '_load_name': 'network_cli'
    }

    # Create a fake display
    display = {
        'warning': lambda x: None,
        'vvvv': lambda x: None
    }

    # Create a fake shared loader object

# Generated at 2022-06-17 09:05:48.880327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:05:49.470373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:59.480850
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:06:08.967068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task._parent = MockTask()
    task._parent._play = MockPlay()
    task._parent._play._action_groups = {}
    task._parent._play._action_groups['setup'] = ['setup']

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock

# Generated at 2022-06-17 09:08:34.007345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.system
    import ansible.plugins.action.async_status
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.network_legacy
    import ansible.plugins.action.network_httpapi
    import ansible.plugins.action.network_netconf
    import ansible.plugins.action.network_rest
    import ansible.plugins.action.network_text
    import ansible.plugins.action.network_xml
    import ansible.plugins.action.netconf_get
    import ansible.plugins.action.netconf_get_config
    import ansible.plugins.action.netconf_edit_config
    import ansible.plugins.action.netconf_

# Generated at 2022-06-17 09:08:46.733663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 09:08:50.516195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:08:52.477164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:09:03.056041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a