

# Generated at 2022-06-17 08:59:27.651101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 08:59:28.304724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:40.771442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, loader, shared_loader_obj, templar, display)

    # Create a mock module
    module = MockModule()

    # Create a mock task_vars
    task_vars = {'ansible_facts_parallel': None, 'ansible_network_os': 'ios'}

    # Create a mock result
    result

# Generated at 2022-06-17 08:59:45.614563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-17 08:59:52.416352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:00:04.185256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude

# Generated at 2022-06-17 09:00:05.189927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement unit test
    assert True

# Generated at 2022-06-17 09:00:12.777052
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:25.006198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin

# Generated at 2022-06-17 09:00:35.968225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 09:00:55.371103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)
    # Check if the instance is created properly
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-17 09:00:56.510585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:01:02.641413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:01:14.840648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = {
        'action': {
            '__ansible_module__': 'setup',
            '__ansible_arguments__': '',
            '__ansible_action_name__': 'setup',
            '__ansible_action_wrapper__': 'ansible.legacy.actions.setup.ActionModule'
        },
        'args': {
            'filter': '*',
            'gather_subset': 'all'
        }
    }

    # Create a fake play

# Generated at 2022-06-17 09:01:17.448274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is created successfully
    assert action_module is not None

# Generated at 2022-06-17 09:01:32.209722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a task
    task = dict(
        action=dict(
            module='setup',
            args=dict(
                filter='ansible_distribution'
            )
        )
    )

    # create a task_vars
    task_vars = dict(
        ansible_facts=dict(
            ansible_distribution='Ubuntu'
        )
    )

    # create a connection
    connection = dict(
        _shell=dict(
            tmpdir='/tmp'
        ),
        _load_name='network_cli'
    )

    # create a play
    play = dict(
        _action_groups=dict(
            setup=dict(
                tasks=[task]
            )
        )
    )

    # create a play_context

# Generated at 2022-06-17 09:01:41.545561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = Mock

# Generated at 2022-06-17 09:01:46.281940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:01:58.449801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.setup
    import ansible.plugins.action.copy
    import ansible.plugins.action.ping
    import ansible.plugins.action.file
    import ansible.plugins.action.shell
    import ansible.plugins.action.raw
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_reboot
    import ansible.plugins.action.win_group
    import ansible.plugins.action.win_user
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_acl
    import ansible.plugins.action.win_package
    import ansible.plugins.action.win_chocolatey
    import ansible.plugins.action.win_feature


# Generated at 2022-06-17 09:02:10.708481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars


# Generated at 2022-06-17 09:02:37.825914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-17 09:02:43.956627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {}
    # Create a mock tmp
    tmp = None
    # Call the method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert the result

# Generated at 2022-06-17 09:02:45.098294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:02:56.971247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AI

# Generated at 2022-06-17 09:02:58.300457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:07.500044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock result
    result = MockResult()
    # Create a mock module_name
    module_name = MockModuleName()
    # Create a mock module_args
    module_args = MockModuleArgs()
    # Create a mock

# Generated at 2022-06-17 09:03:14.938472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_distribution'))),
        connection=dict(transport='local'),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 09:03:16.280697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:03:28.818899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AI

# Generated at 2022-06-17 09:03:35.729279
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:39.652578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:04:51.411888
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:57.967882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock config
    config = MockConfig()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module
    module = MockModule()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module finder find plugin with context
    module_finder_find_plugin_with_context = MockModuleFinderFindPluginWithContext()
    # Create a mock module finder find plugin
   

# Generated at 2022-06-17 09:05:07.580257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution

# Generated at 2022-06-17 09:05:18.305597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': True}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create a mock config object
    config = MockConfig()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a

# Generated at 2022-06-17 09:05:31.791005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, display, loader, templar, shared_loader_obj)

    # Test the constructor
    assert action_plugin._task == task
    assert action_plugin._connection == connection
    assert action_plugin._display == display
    assert action_plugin._loader == loader
    assert action_plugin._templar == templar
    assert action_plugin

# Generated at 2022-06-17 09:05:38.936374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.system
    import ansible.plugins.action.network
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.copy
    import ansible.plugins.action.file
    import ansible.plugins.action.raw
    import ansible.plugins.action.script
    import ansible.plugins.action.template
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file
    import ansible.plugins.action.win_find
    import ansible.plugins.action.win_get_url

# Generated at 2022-06-17 09:05:47.214787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock display
    display = MockDisplay()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock config
    config = MockConfig()
    # Create a mock shell
    shell = MockShell()
    # Create a mock async_status
    async_status = MockAsyncStatus()
    # Create a mock async_wrapper
    async_wrapper = MockAsyncWrapper()

# Generated at 2022-06-17 09:05:58.566047
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:59.099512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:28.900232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:08:39.639785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module finder
    module_resolver = MockModuleResolver()
    # Create a mock module finder
    module_resolver_fqcn = MockModuleResolverFqcn()
    # Create a

# Generated at 2022-06-17 09:08:49.865519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module loader
    mock_loader = MockModuleLoader()

    # Create a mock object for the module finder
    mock_finder = MockModuleFinder()

    # Create a mock object for the module finder
    mock_templar = MockTemplar()

    # Create a mock object for the module finder
    mock_display = MockDisplay()

    # Create a mock object for the module finder
    mock_task = MockTask()

    # Create a mock object for the module finder
    mock_connection = MockConnection()

    # Create a mock object for the module finder
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock object for the module finder
    mock_task_vars = MockTaskVars()

    # Create a mock object for the module finder
   

# Generated at 2022-06-17 09:08:54.954334
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:09:05.629688
# Unit test for constructor of class ActionModule