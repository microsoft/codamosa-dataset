

# Generated at 2022-06-17 08:59:38.097718
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:48.912881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

   

# Generated at 2022-06-17 08:59:49.821824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 08:59:50.368915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:02.759447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task.module_defaults = {}
    task.collections = []
    task._parent = MockPlay()
    task._parent._play = MockPlay()
    task._parent._play._action_groups = {}
    task._parent._play._action_groups['setup'] = ['ansible.legacy.setup']

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock connection object
    connection_obj = MockConnectionObj()

    # Create a mock module loader object
    module_loader_

# Generated at 2022-06-17 09:00:12.090398
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:25.042717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock module
    module = MockModule()

    # Create a mock module
    module_defaults = MockModuleDefaults()

# Generated at 2022-06-17 09:00:32.579425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task

# Generated at 2022-06-17 09:00:39.033538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module resolver
    module_resolver = MockModuleResolver()
    # Create a mock module spec
   

# Generated at 2022-06-17 09:00:47.142000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, display, loader, templar, action_plugin, shared_loader_obj)

    # Test the constructor
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._display == display
    assert action_module._

# Generated at 2022-06-17 09:01:08.022865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None)

    # Test with arguments

# Generated at 2022-06-17 09:01:17.715252
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:32.242516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()
    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()
    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()
    # Create an instance of AnsibleRunnerCLI
    ansible_runner_cli = AnsibleRunnerCLI()
    # Create an instance of AnsibleRunnerConfig
    ansible_runner_config = AnsibleRunnerConfig()
    # Create an instance of AnsibleRunnerConfigCLI
    ansible_runner_config_

# Generated at 2022-06-17 09:01:41.577635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_distribution'))),
        connection=dict(module_name='local', module_args=dict()),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.action['module_name'] == 'setup'
    assert action_module._task.action['module_args'] == dict(filter='ansible_distribution')
    assert action_module._connection.module_name == 'local'
    assert action_module._connection.module_args == dict()
    assert action_module._play_context.check_mode is False
    assert action_module._loader

# Generated at 2022-06-17 09:01:47.224975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test ActionModule object
    action_module = ActionModule()

    # Create a test task object
    task = {
        'args': {
            'parallel': None,
            'network_os': 'ios',
            'gather_subset': 'all',
            'gather_timeout': 10,
            'filter': '*'
        },
        'collections': [],
        'module_defaults': {},
        'module_name': 'setup'
    }

    # Create a test task_vars object
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts': {
            'network_os': 'ios'
        },
        'ansible_network_os': 'ios'
    }

    # Create a test tmp object
    tmp

# Generated at 2022-06-17 09:01:52.414273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:01:53.832385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:01:54.695487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:05.596374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:02:14.665194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars

# Generated at 2022-06-17 09:02:47.607532
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:57.985195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:03:04.429875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock config
    config = MockConfig()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader_obj, display, templar, task_vars, config)
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock module args


# Generated at 2022-06-17 09:03:10.980922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj(module_loader)

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock config
    config = MockConfig()

    # Create a mock action module
    action_

# Generated at 2022-06-17 09:03:22.554040
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:03:24.032121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:03:34.224384
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:03:41.464238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no modules
    task_vars = {}
    task_vars['ansible_facts_parallel'] = None
    C.config.set_config_value('FACTS_MODULES', [], variables=task_vars)

# Generated at 2022-06-17 09:03:51.708043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.network_legacy
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.raw
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file

# Generated at 2022-06-17 09:03:59.455346
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:52.098720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:53.481377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:05:02.572339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, display, templar)

    # Check if the action plugin is an instance of ActionModule
    assert isinstance(action_plugin, ActionModule)

    # Check if the action plugin is an instance of ActionBase
    assert isinstance(action_plugin, ActionBase)

    # Check if the action plugin is an instance of object
    assert isinstance(action_plugin, object)



# Generated at 2022-06-17 09:05:15.149614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module finder object

# Generated at 2022-06-17 09:05:20.314718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:05:32.541146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._display = Display()
    action_module._connection = Connection()
    action_module._task = Task()
    action_module._task.args = {}
    action_module._task.args['parallel'] = None
    action_module._task.args['network_os'] = None
    action_module._task.args['filter'] = None
    action_module._task.args['gather_subset'] = None
    action_module._task.args['gather_timeout'] = None
    action_module._task.args['gather_network_resources'] = None
    action_module._task.args['gather_subset'] = None
    action_module._task.args['gather_network_resources'] = None

# Generated at 2022-06-17 09:05:42.819307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.stats import AggregateStats
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 09:05:53.924453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 09:06:04.543596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a single module
    task_vars = dict(ansible_facts_parallel=False)
    tmp = None
    task = dict(args=dict(module_name='ansible.legacy.setup'))
    action_module = ActionModule(task, tmp, task_vars)
    result = action_module.run(tmp, task_vars)
    assert result['ansible_facts']
    assert result['ansible_facts']['_ansible_facts_gathered']
    assert result['ansible_facts']['ansible_local']
    assert result['ansible_facts']['ansible_local']['module_setup']
    assert result['ansible_facts']['ansible_local']['module_setup']['module_name'] == 'ansible.legacy.setup'

# Generated at 2022-06-17 09:06:09.712306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:08:28.809640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:08:29.302676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:36.229709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:08:38.497575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:08:48.247986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = {
        'args': {
            'parallel': None,
            'gather_subset': None,
            'gather_timeout': None,
            'filter': None
        },
        'collections': [],
        'module_defaults': {},
        'name': 'setup'
    }

    # Create a fake task_vars
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts': {
            'network_os': 'ios'
        }
    }

    # Create a fake config

# Generated at 2022-06-17 09:08:58.825345
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:09:09.283296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action base object
    action_base = ActionBase(task, connection, shared_loader_obj, templar, display)

    # Create a mock action module object
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Test the constructor of class ActionModule
    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module, ActionBase)