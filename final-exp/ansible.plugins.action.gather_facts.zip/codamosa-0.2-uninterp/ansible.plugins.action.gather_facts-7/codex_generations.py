

# Generated at 2022-06-17 08:59:32.656891
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:45.700970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock config object
    config = MockConfig()
    # Create a mock config object
    config_value = MockConfigValue()
    # Create a mock config object
    config_value_2 = MockConfigValue()
    # Create a mock config object
    config_value_3 = MockConfigValue()
    # Create a mock config object
    config_value_4 = MockConfigValue

# Generated at 2022-06-17 08:59:48.224101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    # Create a mock object of class ActionModule
    mock_action_module = ActionModule()
    # Test for constructor of class ActionModule
    assert mock_action_module is not None


# Generated at 2022-06-17 08:59:59.115223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-17 09:00:08.680469
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:14.688494
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:16.371246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:00:27.215908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants
    constants = MockConstants()

    # Create a mock module
    module = MockModule()

    # Create

# Generated at 2022-06-17 09:00:29.057457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:00:37.493511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock loader object
    loader_obj = MockLoaderObj()
    # Create a mock templar object
    templar_obj = MockTemplarObj()
    # Create a mock display object
    display_obj = MockDisplayObj()
    # Create a mock config object
    config_obj = MockConfigObj()
    # Create a mock module_loader object
    module_loader_obj = MockModuleLoaderObj()
    # Create a mock module_utils object
    module_utils_obj = MockModuleUtilsObj()
    # Create a mock module_utils object
    module_utils_obj = MockModuleUtilsObj()

# Generated at 2022-06-17 09:00:59.954159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task_obj = MockTask()

    # Create a mock connection object
    conn_obj = MockConnection()

    # Create a mock loader object
    loader_obj = MockLoader()

    # Create a mock display object
    display_obj = MockDisplay()

    # Create a mock templar object
    templar_obj = MockTemplar()

    # Create a mock action plugin object
    action_plugin_obj = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoader()

    # Create a mock module_utils object
    module_utils_obj = MockModuleUtils()

    # Create a mock module_loader object
    module_loader_obj = MockModuleLoader()

    # Create a mock config object
    config_obj = MockConfig()

    # Create

# Generated at 2022-06-17 09:01:08.756151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no modules
    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._task.args = {}
    action_module._task.args['parallel'] = None
    action_module._task.args['network_os'] = None
    action_module._task.args['ansible_network_os'] = None
    action_module._task.args['ansible_facts'] = {}
    action_module._task.args['ansible_facts']['network_os'] = None
    action_module._task.args['ansible_facts_parallel'] = None
    action_module._task._parent = MockTask()
    action_module._task._parent._play = MockPlay()
    action_module._task._parent._play._action_groups = {}
    action_module._task

# Generated at 2022-06-17 09:01:18.113057
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:32.313938
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:33.261268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:01:33.958927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:45.071974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:55.644611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode is True
    assert action_module._connection is None
    assert action_module._task is None
    assert action_module._loader is None
    assert action_module._play_context is None
    assert action_module._shared_loader_obj is None
    assert action_module._templar is None
    assert action_module._display is None
    assert action_module._task_vars is None
    assert action_module._tmp is None
    assert action_module._task_vars_tmp is None
    assert action_module._task_vars_tmp_file is None
    assert action_module._task_vars_tmp_file_name is None
    assert action_module._task_vars_tmp_file_path

# Generated at 2022-06-17 09:01:59.803901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object of ActionModule
    action_module = ActionModule()
    # Check if the object is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:02:11.355055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder_resolved = MockModuleFinderResolved()
    # Create a mock module finder object
    module

# Generated at 2022-06-17 09:02:33.728405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:02:45.987873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import IncludeTask
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_type import TaskType

# Generated at 2022-06-17 09:02:47.145864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:02:57.955114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock config object
    config = MockConfig()
    # Create a mock action plugin loader object
    action_plugin_loader = MockActionPluginLoader()
    # Create a mock connection plugin loader object
    connection_plugin_loader = MockConnectionPluginLoader()
    # Create a mock lookup plugin loader object
    lookup_plugin_loader = MockLookupPluginLoader()
    # Create a mock strategy plugin loader

# Generated at 2022-06-17 09:03:07.584080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock module
    module = MockModule

# Generated at 2022-06-17 09:03:10.413245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:03:13.946157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:22.875141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = 'ios'
    task.args['gather_subset'] = 'all'
    task.args['gather_timeout'] = None
    task.args['filter'] = None
    task.args['gather_network_resources'] = None
    task.args['gather_subset'] = 'all'
    task.args['gather_timeout'] = None
    task.args['filter'] = None
    task.args['gather_network_resources'] = None
    task.args['gather_subset'] = 'all'
    task.args['gather_timeout'] = None
    task.args['filter'] = None
    task.args

# Generated at 2022-06-17 09:03:30.233524
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:03:40.621762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {'ansible_facts': {'network_os': 'ios'}}
    # Create a mock tmp
    tmp = '/tmp'
    # Create a mock result
    result = {'ansible_facts': {}}
    # Create a mock modules

# Generated at 2022-06-17 09:04:52.056159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Assert that the task is the same as the one passed to the constructor
    assert action_module._task == task

    # Assert that the connection is the same as the one passed to the constructor
    assert action_module._connection == connection

    # Assert that the shared loader object is the same as the one passed to the constructor

# Generated at 2022-06-17 09:04:52.537784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:53.618280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:05:05.576210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:05:07.234720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:05:14.954551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._task = {'args': {'parallel': None}}
    action_module._task._parent = {'_play': {'_action_groups': {}}}
    action_module._task._parent._play._action_groups['setup'] = ['ansible.legacy.setup']
    action_module._task._parent._play._action_groups['gather_facts'] = ['ansible.legacy.setup']
    action_module._task.args = {'parallel': None}
    action_module._task.args.pop = lambda x: None
    action_module._task.args.get = lambda x: None
    action_module._task.args.copy = lambda: {}
    action_module._task

# Generated at 2022-06-17 09:05:18.258686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:31.789706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock resolved_fqcn
    resolved_fqcn = MockResolvedFqcn()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock task_vars
    task_

# Generated at 2022-06-17 09:05:42.641401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock action plugin object
    action_plugin = MockActionPlugin()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock resolved fact module object
    resolved_fact_module = MockResolvedFactModule()
    # Create a mock module object
    module = MockModule()
    # Create a mock module object
    module_defaults = MockModuleDefaults

# Generated at 2022-06-17 09:05:43.716749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:08:01.220410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:04.642148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:08:16.008316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock config object
    config = MockConfig()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModule

# Generated at 2022-06-17 09:08:25.096095
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:31.286102
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:08:31.980487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:08:38.340102
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:48.820913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config
    config = MockConfig()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock module
    module = Mock

# Generated at 2022-06-17 09:08:59.248368
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:09:01.002223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass