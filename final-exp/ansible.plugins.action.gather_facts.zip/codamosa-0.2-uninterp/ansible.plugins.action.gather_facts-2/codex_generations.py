

# Generated at 2022-06-17 08:59:30.042720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerConfig
    ansible_runner_config = AnsibleRunnerConfig()

    # Create an instance of AnsibleRunnerShell
    ansible_runner_shell = AnsibleRunnerShell()

    # Create an instance of AnsibleRunnerConnection
    ansible_runner_connection = AnsibleRunnerConnection

# Generated at 2022-06-17 08:59:42.332215
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:52.800274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Set attributes
    action_module._task = task
    action_module._connection = connection
    action_module._shared_loader_obj = shared_loader_obj
    action_module._templar = templar

    # Call method run
    result = action_module.run()

    # Check result

# Generated at 2022-06-17 09:00:04.461124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    task = MockTask()
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()



# Generated at 2022-06-17 09:00:12.295513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock display
    display = MockDisplay()
    # create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)
    # create a mock task_vars
    task_vars = dict()
    # create a mock tmp
    tmp = dict()
    # create a mock result
    result = dict()
    # create a mock fact_module
    fact_module = 'ansible.legacy.setup'
    # create a mock mod_args
    mod_args = dict()
    # create a mock task_result

# Generated at 2022-06-17 09:00:24.967334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 09:00:29.096108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:00:37.519118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, display, templar)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock result
    result = dict()

    # Create a mock modules
    modules = ['setup']

    # Create a mock fact_module
    fact_module = 'setup'

    # Create a mock mod_args
    mod_args = dict

# Generated at 2022-06-17 09:00:46.776372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock config
    config = MockConfig()

    # Create a mock connection_facts_modules
    connection_facts_modules = MockConnectionFactsModules()

    # Create a

# Generated at 2022-06-17 09:00:48.644523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:01:08.584193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:01:11.447910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:18.086395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am is not None

    # Test with parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-17 09:01:18.920478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:26.054968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:01:27.406033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:01:28.607751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:01:39.221115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:01:39.811360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:41.838836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 09:02:05.083887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:02:08.751258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:02:15.232916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock config
    mock_config = MockConfig()

    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module finder

# Generated at 2022-06-17 09:02:16.989834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is of type ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:02:31.836473
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:32.712535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-17 09:02:45.073895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModule

# Generated at 2022-06-17 09:02:56.936638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import SystemV
    from ansible.module_utils.facts.system.distribution import UnixDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistributionInfo

# Generated at 2022-06-17 09:03:04.293865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock config
    config = MockConfig()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj(module_loader)

    # Create a mock action_base
    action_base = MockActionBase(connection, loader, templar, task, display, config, shared_loader_obj)

    # Create a mock action_module

# Generated at 2022-06-17 09:03:04.840182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:11.488167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = type('', (), {})()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = 'ios'
    task.args['gather_subset'] = 'all'
    task.args['gather_timeout'] = None
    task.args['filter'] = None
    task.args['gather_network_resources'] = ['all']
    task.args['gather_subset'] = ['all']
    task.args['gather_timeout'] = 10
    task.args['filter'] = '*'
    task.args['gather_network_resources'] = ['all']
    task.args['gather_subset'] = ['all']
    task.args['gather_timeout'] = 10

# Generated at 2022-06-17 09:04:15.178472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:04:26.159604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:04:32.029185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True and len(modules) >= 1
    # Test with parallel=True and len(modules) < 1
    # Test with parallel=False and len(modules) >= 1
    # Test with parallel=False and len(modules) < 1
    pass

# Generated at 2022-06-17 09:04:33.210691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=True
    # Test with parallel=False
    pass

# Generated at 2022-06-17 09:04:35.489250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:04:36.622007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:04:39.213015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-17 09:04:39.984359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:04:40.704090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:06:32.180773
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:06:42.216169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of ActionBase
    assert isinstance(action_module, ActionBase)

    # Check if the instance is an instance of object
    assert isinstance(action_module, object)

    #

# Generated at 2022-06-17 09:06:43.828507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:06:50.849263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader
    shared_loader = MockSharedLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader, templar, display, config)
    # Create a mock task_vars
    task_vars = {'ansible_facts_parallel': None}
    # Create a mock tmp
    tmp = None
    # Create a mock result

# Generated at 2022-06-17 09:06:53.479034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:07:01.810683
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:07:07.164096
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:07:08.413407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:07:18.621790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock ansible connection
    connection = MockConnection()

    # Create a mock ansible module
    module = MockModule()

    # Create a mock ansible display
    display = MockDisplay()

    # Create a mock ansible templar
    templar = MockTemplar()

    # Create a mock ansible shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock ansible task object
    task_obj = MockTaskObj()

    # Create a mock ansible task object
    play_context = MockPlayContext()

    # Create a mock ansible task object
    play_context_obj = MockPlayContextObj()

    # Create a mock ansible task object
    play_context_obj.connection = connection

    # Create a mock ans

# Generated at 2022-06-17 09:07:22.185378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None