

# Generated at 2022-06-17 08:59:19.145232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:59:30.017298
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:42.333321
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:52.800370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars

# Generated at 2022-06-17 09:00:04.433636
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:05.760636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:00:13.095130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock module finder
    mock_module_finder = MockModuleFinder()

    # Create a mock module finder
    mock_module_resolver = MockModuleResolver()

    # Create a mock module finder
    mock_

# Generated at 2022-06-17 09:00:25.040769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task._parent = MockPlay()
    task._parent._play = MockPlay()
    task._parent._play._action_groups = {'all': ['setup']}
    task._parent._play._action_groups['all'].append('setup')

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock display
    display = MockDisplay()

    # Create

# Generated at 2022-06-17 09:00:32.598099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:00:37.984896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock templar object
    templar = MockTemplar()
    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, display, templar)
    # Check if the instance is created properly
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-17 09:00:50.352801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:01:00.085952
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:08.781594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups
    action_groups = MockActionGroups()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create

# Generated at 2022-06-17 09:01:09.754741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:01:11.554675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:22.539165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.win_setup
    import ansible.plugins.action.win_smart
    import ansible.plugins.action.win_wmi
    import ansible.plugins.action.win_ps
    import ansible.plugins.action.win_dsc
    import ansible.plugins.action.win_dsc_script
    import ansible.plugins.action.win_dsc_test
    import ansible.plugins.action.win_dsc_test_configuration
    import ansible.plugins.action.win_dsc_test_module
    import ansible

# Generated at 2022-06-17 09:01:34.726575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

    # Create a mock task object
    task = MockTask()

   

# Generated at 2022-06-17 09:01:45.984710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:01:58.418341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerConnection
    ansible_runner_connection = AnsibleRunnerConnection()

    # Create an instance of AnsibleRunnerShell
    ansible_runner_shell = AnsibleRunnerShell()

    # Create an instance of AnsibleRunnerNetwork
    ansible_runner_network = AnsibleRunnerNetwork

# Generated at 2022-06-17 09:02:10.707700
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:44.884701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock module_defaults object
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups object
    action_groups = MockActionGroups()

    # Create a mock play object
    play = MockPlay()

    # Create a mock

# Generated at 2022-06-17 09:02:50.681286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    action_module = ActionModule()

    # test
    result = action_module.run()

    # assert
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-17 09:02:53.239442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:02.927058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleTaskExecutor
    ansible_task_executor = AnsibleTaskExecutor()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of Ans

# Generated at 2022-06-17 09:03:12.781806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock plugin finder
    plugin_finder = MockPluginFinder()

    # Create a mock plugin loader
    plugin_loader = MockPluginLoader()

    # Create a mock shared loader object
    shared_loader_obj

# Generated at 2022-06-17 09:03:20.540702
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:03:21.399843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:22.234645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:31.870834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task with a mock connection
    task = MockTask()
    task._connection = MockConnection()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj._module_loader = module_loader

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action base
    action_base = MockActionBase()
    action_base._shared_loader_obj = shared_loader_obj
    action_base._templar = templar

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock play object
    play_obj = MockPlayObj()

    # Create a mock play context
    play_context

# Generated at 2022-06-17 09:03:41.036425
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:52.053249
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:56.638228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

# Generated at 2022-06-17 09:04:59.652083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:05:04.198094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am.__class__.__name__ == 'ActionModule'

    # Test with args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-17 09:05:12.364852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:05:13.359559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-17 09:05:23.906207
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:24.930968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:05:35.156027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            action=dict(
                module_name='setup',
                module_args=dict(
                    filter='ansible_distribution'
                )
            )
        ),
        connection=dict(
            transport='local'
        ),
        play_context=dict(
            check_mode=False
        ),
        loader=dict(
            basedir='/home/ansible/ansible'
        ),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert action_module._task.action.module_name == 'setup'
    assert action_module._task.action.module_args['filter'] == 'ansible_distribution'
    assert action_module._connection.transport == 'local'
    assert action_module._play_

# Generated at 2022-06-17 09:05:43.848919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock action base object
    action_base_obj = MockActionBaseObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock config object
    config_obj = MockConfigObj()

    # Create a mock config object
    config_obj

# Generated at 2022-06-17 09:08:11.068537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:08:21.481504
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:30.474659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, display, loader, templar)

    # Check the instance is not None
    assert action_module is not None


# Generated at 2022-06-17 09:08:37.184308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module
    module = MockModule()
    # Create a mock action groups
    action_groups = MockActionGroups()
    # Create a mock play
    play = MockPlay()
    # Create a mock parent
    parent = MockParent()
   

# Generated at 2022-06-17 09:08:41.900857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module
    module = MockModule()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module_utils
    module_utils = MockModuleUtils()
    # Create a mock module_utils
   

# Generated at 2022-06-17 09:08:44.454749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:08:46.896081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:08:58.665268
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:09:09.296084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = {'args': {'parallel': None}}
    action_module._task._parent = {'_play': {'_action_groups': {}}}
    action_module._connection = {'_load_name': 'network_cli'}
    action_module._shared_loader_obj = {'module_loader': {'find_plugin_with_context': lambda x, y: {'resolved_fqcn': 'ansible.legacy.setup'}}}
    action_module._templar = {}
    action_module._display = {'warning': lambda x: None, 'vvvv': lambda x: None}