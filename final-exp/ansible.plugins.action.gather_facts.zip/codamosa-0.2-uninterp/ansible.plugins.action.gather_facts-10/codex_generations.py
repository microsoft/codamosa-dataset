

# Generated at 2022-06-17 08:59:38.096865
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:38.612836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:59:40.139355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:59:51.053213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader
    shared_loader = MockSharedLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader, templar, display)
    # Create a mock task vars
    task_vars = {'ansible_facts_parallel': None}
    # Create a mock result
    result = {'ansible_facts': {}}
    # Create a mock tmp
    tmp = None
    # Test the run method
    action_module

# Generated at 2022-06-17 09:00:03.855778
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:11.933365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module
    module = MockModule()

    # Create a mock module result
    module_result = MockModuleResult()

    # Create a mock module result
    module_result2 = MockModuleResult()

    # Create a mock module result
    module_result3

# Generated at 2022-06-17 09:00:15.503453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:00:16.168928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:27.212461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {'ansible_facts': {}}
    # Create a mock result
    result = {'ansible_facts': {}}
    # Create a mock tmp
    tmp = '/tmp'
    # Create a mock modules
    modules = ['ansible.legacy.setup']
    # Create a mock parallel
    parallel = True
    #

# Generated at 2022-06-17 09:00:33.319469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_resolver = MockModuleResolver()
    # Create a mock module finder object
    module_loader_mgr = MockModuleLoaderMgr()
    # Create a mock module finder object


# Generated at 2022-06-17 09:00:50.926620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am is not None

    # Test with parameters
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-17 09:01:02.247302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:04.950934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:01:16.000908
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:23.648841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock loader
    loader = MockLoader()
    # create a mock display
    display = MockDisplay()
    # create a mock templar
    templar = MockTemplar()
    # create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock config
    config = MockConfig()
    # create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # create a mock action groups
    action_groups = MockActionGroups()
    # create a mock task_vars
    task_vars = MockTaskVars()
    # create a mock task_vars
    task_vars_2 = MockTaskVars()

# Generated at 2022-06-17 09:01:35.096065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module finder object

# Generated at 2022-06-17 09:01:36.297390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:45.114690
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:01:55.646162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import AI

# Generated at 2022-06-17 09:02:06.173265
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:28.076957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:39.506746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock module loader
    module_loader = MockModuleLoader()
    module_loader.find_plugin_with_context = MockModuleLoaderFindPluginWithContext()
    module_loader.find_plugin_with_context.resolved_fqcn = 'ansible.legacy.setup'

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create

# Generated at 2022-06-17 09:02:44.503378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    action_module = ActionModule()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule
    ansible_module_mock = AnsibleModuleMock()

    # create a mock for the class AnsibleModule

# Generated at 2022-06-17 09:02:47.229238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:55.112802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:02:56.330643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:03:01.476099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader
    shared_loader = MockSharedLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module resolver
    module_resolver = MockModuleResolver()
    # Create a mock module spec

# Generated at 2022-06-17 09:03:06.138457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = None
    task.args['filter'] = None
    task.args['gather_subset'] = None
    task.args['gather_timeout'] = None
    task.module_defaults = {}
    task._parent = mock.Mock()
    task._parent._play = mock.Mock()
    task._parent._play._action_groups = {}
    task.collections = []

    # Create a mock connection
    connection = mock.Mock()
    connection._load_name = 'network_cli'
    connection._shell = mock.Mock()
    connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object


# Generated at 2022-06-17 09:03:18.081401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, display, loader, templar, shared_loader_obj)

    # Check if the action plugin is an instance of ActionBase
    assert isinstance(action_plugin, ActionBase)

    # Check if the action plugin is an instance of ActionModule
    assert isinstance(action_plugin, ActionModule)

    # Check if the action plugin has the required attributes

# Generated at 2022-06-17 09:03:20.258542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-17 09:04:26.332941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:04:28.796203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:04:38.730760
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:50.436052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to use in the test
    mock_task = type('MockTask', (object,), {
        'args': {},
        '_parent': type('MockPlay', (object,), {
            '_action_groups': ['all']
        }),
        'module_defaults': {},
        'collections': []
    })()

    # Create a mock connection to use in the test
    mock_connection = type('MockConnection', (object,), {
        '_load_name': 'network_cli',
        '_shell': type('MockShell', (object,), {
            'tmpdir': '/tmp'
        }),
    })()

    # Create a mock loader to use in the test

# Generated at 2022-06-17 09:04:53.993953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:02.878925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import SuseDistribution
    from ansible.module_utils.facts.system.distribution import DebianDistribution
    from ansible.module_utils.facts.system.distribution import AlpineDistribution
    from ansible.module_utils.facts.system.distribution import OpenWrtDistribution
    from ansible.module_utils.facts.system.distribution import ArchLinuxDistribution

# Generated at 2022-06-17 09:05:15.514126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module find

# Generated at 2022-06-17 09:05:27.290429
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:36.165303
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:37.799134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:08:03.340089
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:11.679206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network
    import ansible.plugins.action.system
    import ansible.plugins.action.pkg_mgr
    import ansible.plugins.action.service
    import ansible.plugins.action.user
    import ansible.plugins.action.group
    import ansible.plugins.action.file
    import ansible.plugins.action.selinux
    import ansible.plugins.action.copy
    import ansible.plugins.action.template
    import ansible.plugins.action.async_status
    import ansible.plugins.action.debug
    import ansible.plugins.action.script
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible

# Generated at 2022-06-17 09:08:18.220224
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:31.507715
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:32.553699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:08:45.840951
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:08:58.541469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*'
            )
        ),
        connection=dict(
            _load_name='network_cli'
        ),
        task_vars=dict(
            ansible_network_os='ios'
        )
    )

    assert action_module._get_module_args('ansible.legacy.setup', dict(ansible_network_os='ios')) == dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )


# Generated at 2022-06-17 09:09:09.250341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': 'True'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder find plugin
    module_finder_find_plugin = MockModuleFinderFindPlugin()

    # Create a mock module finder find plugin