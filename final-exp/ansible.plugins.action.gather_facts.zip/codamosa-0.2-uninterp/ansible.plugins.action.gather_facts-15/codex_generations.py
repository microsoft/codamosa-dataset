

# Generated at 2022-06-17 08:59:35.335385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create an action module object
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Check if the action module object is created successfully
    assert action_module is not None



# Generated at 2022-06-17 08:59:46.970032
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:47.467962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:48.382349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:59.223547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = mock.Mock()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = None
    task.module_defaults = {}
    task._parent = mock.Mock()
    task._parent._play = mock.Mock()
    task._parent._play._action_groups = {}

    # Create a mock connection object
    connection = mock.Mock()
    connection._load_name = 'network_cli'
    connection._shell = mock.Mock()
    connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    shared_loader_obj = mock.Mock()
    shared_loader_obj.module_loader = mock.Mock()
    shared_loader_obj.module_loader.find_

# Generated at 2022-06-17 09:00:06.432954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._task = None
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None
    action_module._display = None

    # Test
    result = action_module.run()

    # Verify
    assert result == {'ansible_facts': {}, '_ansible_verbose_override': True}

# Generated at 2022-06-17 09:00:06.932579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:07.579175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:14.840511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no modules
    task_vars = dict(ansible_facts_parallel=None)
    task = dict(args=dict())
    module = ActionModule(task, task_vars)
    result = module.run(task_vars=task_vars)
    assert result['ansible_facts'] == {}
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['_ansible_verbose_override'] == True

    # Test with one module
    task_vars = dict(ansible_facts_parallel=None)
    task = dict(args=dict())
    module = ActionModule(task, task_vars)
    result = module.run(task_vars=task_vars)
    assert result['ansible_facts'] == {}
    assert result

# Generated at 2022-06-17 09:00:20.844931
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:41.892607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups
    action_groups = MockActionGroups()
    # Create a mock play
    play = MockPlay()
    # Create a mock parent
    parent = MockParent()
    # Create a mock task_vars

# Generated at 2022-06-17 09:00:44.836665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:00:48.936504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=True
    # Test with parallel=False
    pass

# Generated at 2022-06-17 09:00:49.972564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:01:00.265757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:08.831753
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:09.441935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:22.003820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task vars
    task_vars = {}
    # Create a mock tmp
    tmp = None
    # Run the method
    result = action_module.run(tmp, task_vars)
    # Assert the result

# Generated at 2022-06-17 09:01:34.544621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:45.826244
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:08.545832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:15.082955
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:18.150228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:02:32.306741
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:33.198229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:33.849847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:46.101624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_loader_obj
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create

# Generated at 2022-06-17 09:02:54.340419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task object
    task = type('', (), {})()
    task.args = {'parallel': True}
    task.module_defaults = {}
    task.collections = []

    # Create a fake connection object
    connection = type('', (), {})()
    connection._load_name = 'network_cli'

    # Create a fake shared loader object
    shared_loader_obj = type('', (), {})()
    shared_loader_obj.module_loader = type('', (), {})()
    shared_loader_obj.module_loader.find_plugin_with_context = lambda x, y: type('', (), {})()
    shared_loader_obj.module_loader.find_plugin_with_context.resolved_fqcn = 'ansible.legacy.setup'

    # Create a fake tem

# Generated at 2022-06-17 09:03:07.358228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module
    module = MockModule()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock play
    play = MockPlay()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants
    constants = MockConstants()

    #

# Generated at 2022-06-17 09:03:07.976752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:11.284031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.net_setup
    import ansible.plugins.action.net_facts
    import ansible.plugins.action.net_legacy
    import ansible.plugins.action.net_hardware
    import ansible.plugins.action.net_interfaces
    import ansible.plugins.action.net_lldp
    import ansible.plugins.action.net_l2_interface_props
    import ansible.plugins.action.net_l3_interface_props
    import ansible.plugins.action.net_l3_neighbors
    import ansible.plugins.action.net_l3_static_routes
    import ansible.plugins.action.net_l3_vrf

# Generated at 2022-06-17 09:04:24.214020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder

# Generated at 2022-06-17 09:04:34.682719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with empty modules
    action_module = ActionModule(task=dict(args=dict(modules=[])))
    result = action_module.run(task_vars=dict())
    assert result == dict(ansible_facts=dict(), ansible_facts_gathered=True, _ansible_verbose_override=True)

    # Test with one module
    action_module = ActionModule(task=dict(args=dict(modules=['ansible.legacy.setup'])))
    result = action_module.run(task_vars=dict())
    assert result == dict(ansible_facts=dict(), ansible_facts_gathered=True, _ansible_verbose_override=True)

    # Test with two modules

# Generated at 2022-06-17 09:04:38.462851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule()
    assert action_module._supports_check_mode is True

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode is True

# Generated at 2022-06-17 09:04:39.227669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)._supports_check_mode is True

# Generated at 2022-06-17 09:04:41.155809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:04:45.000874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:04:56.394424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task vars
    task_vars = {'ansible_facts': {}}
    # Create a mock result
    result = {'ansible_facts': {}}
    # Create a mock tmp
    tmp = '/tmp/ansible'
    # Create a mock modules
    modules = ['ansible.legacy.setup']
    # Create a mock parallel
    parallel = True


# Generated at 2022-06-17 09:05:00.603481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=True
    # Test with parallel=False
    # Test with skipped
    # Test with failed
    pass

# Generated at 2022-06-17 09:05:08.625883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock play
    play = MockPlay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play, loader, templar, display)

    # Test the constructor
    assert action_plugin._task == task
    assert action_plugin._connection == connection
    assert action_plugin._play == play
    assert action_plugin._loader == loader
    assert action_plugin._templar == templar
    assert action_plugin._display == display


# Generated at 2022-06-17 09:07:15.564551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock module_common
    module_common = MockModuleCommon()

    # Create a mock config
    config = MockConfig()

    # Create a mock constants
    constants = MockConstants()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils.parsing.convert_bool
    convert_bool = MockConvertBool()

    # Create a mock plugins.action.ActionBase
    action_base = MockActionBase()

    # Create

# Generated at 2022-06-17 09:07:22.675254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerConnection
    ansible_runner_connection = AnsibleRunnerConnection()

    # Create an instance of AnsibleRunnerShell
    ansible_runner_shell = AnsibleRunnerShell()

    # Create an instance of AnsibleRunnerNetwork
    ansible_runner_network = AnsibleRunnerNetwork

# Generated at 2022-06-17 09:07:31.063284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()
    # Create an instance of AnsibleTaskExecutor
    ansible_task_executor = AnsibleTaskExecutor()
    # Create an instance of AnsibleTaskExecutorResult
    ansible_task_executor_result = AnsibleTaskExecutorResult()
    # Create an instance of AnsibleTaskExecutorOptions
    ansible_task_executor_options = AnsibleTaskExecutorOptions()
    # Create an instance of AnsibleTaskExecutorOptions
    ansible_task_executor_options = AnsibleTaskExecutorOptions()
    # Create an instance of AnsibleTaskExecutor

# Generated at 2022-06-17 09:07:42.081646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock config
    config = MockConfig()

    # Create a mock connection_

# Generated at 2022-06-17 09:07:42.796042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:07:53.478899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, loader, display, templar, action_plugin, shared_loader_obj)

    # Check if the instance is created properly
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._loader == loader

# Generated at 2022-06-17 09:07:57.421676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:03.570949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder finder
    module_finder_finder = MockModuleFinderFinder()

    # Create a mock module finder finder finder
    module_finder_finder_finder = MockModuleFinderF

# Generated at 2022-06-17 09:08:15.003297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash

# Generated at 2022-06-17 09:08:24.360722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object
    mock_task = type('MockTask', (object,), {})()
    mock_task.args = {}
    mock_task.module_defaults = {}
    mock_task.collections = []
    mock_task._parent = type('MockParent', (object,), {})()
    mock_task._parent._play = type('MockPlay', (object,), {})()
    mock_task._parent._play._action_groups = {}

    # Create a mock object
    mock_connection = type('MockConnection', (object,), {})()
    mock_connection._load_name = 'network_cli'
    mock_connection._shell = type('MockShell', (object,), {})()
    mock_connection._shell.tmpdir = '/tmp'

    # Create a mock object
