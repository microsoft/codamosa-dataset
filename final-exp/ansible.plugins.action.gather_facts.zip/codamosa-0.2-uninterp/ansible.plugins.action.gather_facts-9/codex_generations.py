

# Generated at 2022-06-17 08:59:38.096072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryRedHat
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactorySuSE
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryDebian
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryAlpine
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryArch

# Generated at 2022-06-17 08:59:47.784144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 08:59:49.368975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:59:49.910696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:02.435327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no modules
    modules = []
    parallel = None
    task_vars = {}
    result = {}
    result['ansible_facts'] = {}
    failed = {}
    skipped = {}
    assert ActionModule.run(modules, parallel, task_vars, result, failed, skipped) == {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}

    # Test with modules
    modules = ['ansible.legacy.setup']
    parallel = None
    task_vars = {}
    result = {}
    result['ansible_facts'] = {}
    failed = {}
    skipped = {}

# Generated at 2022-06-17 09:00:04.551094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is created successfully
    assert action_module is not None

# Generated at 2022-06-17 09:00:12.354767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = dict(
        action=dict(
            module_name='setup',
            module_args=dict()
        )
    )

    # Create a fake play context
    play_context = dict(
        check_mode=False,
        diff=False
    )

    # Create a fake loader
    loader = dict()

    # Create a fake templar
    templar = dict()

    # Create a fake shared loader object
    shared_loader_obj = dict()

    # Create a fake connection
    connection = dict(
        _shell=dict(
            tmpdir='/tmp'
        ),
        _load_name='network_cli'
    )

    # Create a fake display
    display = dict()

    # Create a fake action base
    action_base = dict()

    # Create

# Generated at 2022-06-17 09:00:15.954415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:00:17.318546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:30.615898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:00:55.983445
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:58.835943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True
    # Test with parallel=False
    pass

# Generated at 2022-06-17 09:01:01.188607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

# Generated at 2022-06-17 09:01:02.010583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:03.291257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:01:05.635985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:01:16.696622
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:23.965145
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:35.929624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()

    # Create an instance of AnsibleRunnerCLI
    ansible_runner_cli = AnsibleRunnerCLI()

    # Create an instance of AnsibleRunnerConfig
    ansible_runner_config = AnsibleRunnerConfig()



# Generated at 2022-06-17 09:01:44.116386
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:08.036203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:14.840819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:02:21.297859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {}
    task.args['parallel'] = None
    task.args['network_os'] = 'ios'
    task.module_defaults = {}
    task.collections = []

    # Create a mock connection
    connection = mock.Mock()
    connection._load_name = 'network_cli'
    connection._shell = mock.Mock()
    connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    shared_loader_obj = mock.Mock()
    shared_loader_obj.module_loader = mock.Mock()
    shared_loader_obj.module_loader.find_plugin_with_context = mock.Mock()
    shared_loader_obj.module_loader.find_plugin_with_

# Generated at 2022-06-17 09:02:35.423803
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:43.465746
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:51.568987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock config object
    config = MockConfig()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder_resolved = MockModuleFinderResolved()
    # Create a mock module finder object


# Generated at 2022-06-17 09:02:59.010374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution

# Generated at 2022-06-17 09:02:59.576750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:08.385126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:03:10.039810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:19.683695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock config object
    config = MockConfig()
    # Create a mock action plugin object
    action_plugin = MockActionPlugin()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module object
    module = MockModule()
    # Create a mock task object
    task = MockTask()
    # Create a mock task

# Generated at 2022-06-17 09:04:32.799766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task to use for testing
    task = MockTask()

    # Create a mock connection to use for testing
    connection = MockConnection()

    # Create a mock loader to use for testing
    loader = MockLoader()

    # Create a mock display to use for testing
    display = MockDisplay()

    # Create a mock templar to use for testing
    templar = MockTemplar()

    # Create a mock action plugin to use for testing
    action_plugin = MockActionPlugin()

    # Create a mock module_loader to use for testing
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj to use for testing
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock config to use for testing
    config = MockConfig()

    # Create a mock module_utils to use for

# Generated at 2022-06-17 09:04:37.128874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True and len(modules) >= 1
    # Test with parallel=True and len(modules) < 1
    # Test with parallel=False and len(modules) >= 1
    # Test with parallel=False and len(modules) < 1
    pass

# Generated at 2022-06-17 09:04:45.399316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.net_setup
    import ansible.plugins.action.net_facts
    import ansible.plugins.action.net_legacy
    import ansible.plugins.action.net_hardware
    import ansible.plugins.action.net_interfaces
    import ansible.plugins.action.net_lldp
    import ansible.plugins.action.net_l2_interface
    import ansible.plugins.action.net_l3_interface
    import ansible.plugins.action.net_l3_neighbors
    import ansible.plugins.action.net_l3_vrrp
    import ansible.plugins.action.net_l3_static_routes

# Generated at 2022-06-17 09:04:56.638641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module resolver
    module_resolver = MockModuleResolver()

    # Create a mock module
    module = MockModule()

    # Create a mock module_utils


# Generated at 2022-06-17 09:05:06.762834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Check if the instance is of type ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance has the correct attributes
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._shared_loader_obj == shared_loader_obj
    assert action_module._

# Generated at 2022-06-17 09:05:08.433741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:10.743437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:05:15.984181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True
    assert am._shared_loader_obj is not None
    assert am._connection is not None
    assert am._task is not None
    assert am._loader is not None
    assert am._templar is not None
    assert am._display is not None

# Generated at 2022-06-17 09:05:25.865219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._task.args == {}
    assert action_module._task.module_defaults == {}
    assert action_module._task._parent._play._action_groups == {}
    assert action_module._task.collections == []
    assert action_module._task.action == 'setup'
    assert action_module._task.delegate_to == None
    assert action_module._task.delegate_facts == None
    assert action_module._task.notify == []
    assert action_module._task.loop == None
    assert action_module._task.loop_args == {}
    assert action_module._task.until == None
    assert action_module._task.retries == 3

# Generated at 2022-06-17 09:07:42.045300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import SmartOSDistribution
    from ansible.module_utils.facts.system.distribution import SunOSDistribution
    from ansible.module_utils.facts.system.distribution import WindowsDistribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import Net

# Generated at 2022-06-17 09:07:42.440027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:07:53.282138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module
    module_resolved = MockModule()

    # Create a mock module
    module_resolved_fq

# Generated at 2022-06-17 09:08:00.829887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 09:08:11.151046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    am = ActionModule()
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock display
    display = MockDisplay()
    # create a mock config
    config = MockConfig()
    # create a mock module_loader
    module_loader = MockModuleLoader()
    # create a mock module_utils
    module_utils = MockModuleUtils()
    # create a mock module_utils
    module_utils = MockModuleUtils()
    # create a mock module_utils
    module_utils = MockModuleUtils()
    # create a mock module_utils

# Generated at 2022-06-17 09:08:11.792477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:08:22.562380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import SolarisDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import NetBSDDistribution
    from ansible.module_utils.facts.system.distribution import FreeBSDDistribution
    from ansible.module_utils.facts.system.distribution import AIXDistribution

# Generated at 2022-06-17 09:08:32.302300
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:08:35.703769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True
    # Test with parallel=False
    pass

# Generated at 2022-06-17 09:08:36.439914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass