

# Generated at 2022-06-17 08:59:38.098155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.netconf
    import ansible.plugins.action.async_status

    # create a mock task

# Generated at 2022-06-17 08:59:48.273623
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:59:59.150964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock task_vars
    task_vars = {
        'ansible_facts_parallel': False,
        'ansible_facts': {
            'network_os': 'ios'
        }
    }
    # Create a mock result

# Generated at 2022-06-17 09:00:08.717306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock loader
    loader = MockLoader()
    # create a mock templar
    templar = MockTemplar()
    # create a mock display
    display = MockDisplay()
    # create a mock action plugin
    action_plugin = MockActionPlugin()
    # create a mock module plugin
    module_plugin = MockModulePlugin()
    # create a mock module loader
    module_loader = MockModuleLoader()
    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock action plugin loader
    action_plugin_loader = MockActionPluginLoader()
    # create a mock module utils plugin
    module_utils_plugin = MockModuleUtilsPlugin()


# Generated at 2022-06-17 09:00:15.524882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._supports_check_mode is True
    assert am._supports_async is True
    assert am._supports_async_timeout is True
    assert am._display is None
    assert am._connection is None
    assert am._task is None
    assert am._loader is None
    assert am._templar is None
    assert am._shared_loader_obj is None
    assert am._play_context is None
    assert am._task_vars is None
    assert am._tmp is None
    assert am._task_vars_tmp is None
    assert am._task_vars_tmp_cache is None
    assert am._task_vars_tmp_cache_key is None
    assert am._task_vars_tmp_cache_valid is None
   

# Generated at 2022-06-17 09:00:25.683138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': True}

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock module
    module = MockModule()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock config object
    config = MockConfig()

    # Create a mock action_groups object
    action_groups = MockActionGroups()

    # Create a mock play object
    play = MockPlay()
    play._action_groups = action_groups

    # Create a mock task object
    task

# Generated at 2022-06-17 09:00:36.103822
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:45.207665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

    # Test with parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:00:46.337763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:00:51.693819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module is not None

    # Test with parameters
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:01:08.679757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(dict(action='setup'))
    assert action._supports_check_mode is True

    # Test with an invalid action
    action = ActionModule(dict(action='invalid'))
    assert action._supports_check_mode is False

# Generated at 2022-06-17 09:01:18.092968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'parallel': None}
    task.args['network_os'] = None

    # Create a mock connection
    connection = MockConnection()
    connection._load_name = 'network_cli'

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._connection = connection

    # Create a mock config
    config = MockConfig()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_

# Generated at 2022-06-17 09:01:27.036193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_distribution'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['filter'] == 'ansible_distribution'

# Generated at 2022-06-17 09:01:38.015965
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:38.630340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:39.977880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:01:46.389274
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:01:58.449277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, display, loader, templar)

    # Check if the instance is of type ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance has the correct attributes
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._display == display
    assert action_module._loader == loader
    assert action_module._templar == templar

# Unit

# Generated at 2022-06-17 09:02:10.707541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleTaskExecutor
    ansible_task_executor = AnsibleTaskExecutor()

    # Create an instance of AnsibleTaskResult
    ansible_task_result = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result_1 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result_2 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result_3 = AnsibleTaskResult()

    # Create an instance of AnsibleTaskResult
    ansible_task_result_4 = AnsibleTaskResult()

# Generated at 2022-06-17 09:02:16.688312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    action_module = ActionModule()

    # create a mock task
    task = MockTask()

    # create a mock connection
    connection = MockConnection()

    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # create a mock templar object
    templar = MockTemplar()

    # create a mock display object
    display = MockDisplay()

    # create a mock config object
    config = MockConfig()

    # create a mock task vars
    task_vars = MockTaskVars()

    # create a mock tmp
    tmp = MockTmp()

    # create a mock module loader
    module_loader = MockModuleLoader()

    # create a mock module
    module = MockModule()

    # create a mock module result
   

# Generated at 2022-06-17 09:02:40.197776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-17 09:02:50.905413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder

# Generated at 2022-06-17 09:02:57.170362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = AnsibleTask()

    # Create a mock connection
    connection = AnsibleConnection()

    # Create a mock shared loader object
    shared_loader_obj = AnsibleModuleLoader()

    # Create a mock templar
    templar = AnsibleTemplar()

    # Create a mock display
    display = AnsibleDisplay()

    # Create a mock config
    config = AnsibleConfig()

    # Create a mock constants
    constants = AnsibleConstants()

    # Create a mock module loader
    module_loader = AnsibleModuleLoader()

    # Create a mock module
    module = AnsibleModule()

    # Create a mock module finder
    module_finder = AnsibleModuleFinder()

    # Create a mock module finder
    module_finder = AnsibleModuleFinder()

    # Create a

# Generated at 2022-06-17 09:02:58.997783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:03:07.749101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    # create a mock connection
    connection = MockConnection()
    # create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # create a mock templar obj
    templar = MockTemplar()
    # create a mock action base obj
    action_base = MockActionBase()
    # create a mock display obj
    display = MockDisplay()
    # create a mock config obj
    config = MockConfig()
    # create a mock config obj
    config_value = MockConfigValue()
    # create a mock config obj
    config_value_1 = MockConfigValue()
    # create a mock config obj
    config_value_2 = MockConfigValue()
    # create a mock config obj
    config_value_3 = MockConfigValue()


# Generated at 2022-06-17 09:03:18.914425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = {'args': {'parallel': None}}
    action_module._task._parent = {'_play': {'_action_groups': {}}}
    action_module._templar = {}
    action_module._shared_loader_obj = {'module_loader': {'find_plugin_with_context': lambda x, y: {'resolved_fqcn': 'resolved_fqcn'}}}
    action_module._connection = {'_load_name': '_load_name'}
    action_module._display = {'warning': lambda x: None, 'vvvv': lambda x: None}

# Generated at 2022-06-17 09:03:30.697925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock config object
    config = MockConfig()

    # Create a mock plugin loader object
    plugin_loader = MockPluginLoader()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock module finder object
    module_finder = MockModuleFinder()

    # Create a mock module utils loader object
    module_utils_loader = MockModuleUtilsLoader()

    # Create a mock connection loader object
    connection

# Generated at 2022-06-17 09:03:32.480090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:03:34.469751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:03:41.569241
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:52.113577
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:04:56.677373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module plugin
    module_plugin_2 = MockModulePlugin()

    # Create a mock module plugin
    module_plugin_3 = MockModulePlugin()

    # Create a mock module plugin
    module_plugin_4 = MockModulePlugin()

    # Create a mock module plugin
    module_plugin_5 = MockModulePlugin()

    # Create a mock module plugin

# Generated at 2022-06-17 09:05:05.682905
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:17.524381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock config
    config = MockConfig()
    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups
    action_groups = MockActionGroups()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock module_loader
    module_loader = MockModuleLoader()
    # Create

# Generated at 2022-06-17 09:05:19.415199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:05:27.590786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with parallel=None and len(modules) >= 1
    # Test with parallel=None and len(modules) < 1
    # Test with parallel=True and len(modules) >= 1
    # Test with parallel=True and len(modules) < 1
    # Test with parallel=False and len(modules) >= 1
    # Test with parallel=False and len(modules) < 1
    pass

# Generated at 2022-06-17 09:05:36.451082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create an object of class ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display, action_base)

    # Check if the object is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the object is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)



# Generated at 2022-06-17 09:05:37.080404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:05:44.004031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()

    # create a mock connection
    connection = MockConnection()

    # create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # create a mock templar obj
    templar = MockTemplar()

    # create a mock display obj
    display = MockDisplay()

    # create a mock config obj
    config = MockConfig()

    # create a mock module loader obj
    module_loader = MockModuleLoader()

    # create a mock action plugin obj
    action_plugin = MockActionPlugin()

    # create a mock module obj
    module = MockModule()

    # create a mock module obj
    module_resolved = MockModuleResolved()

    # create a mock module obj
    module_defaults = MockModuleDefaults()

    # create a

# Generated at 2022-06-17 09:05:53.996060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.action.smart
    import ansible.plugins.action.network_cli
    import ansible.plugins.action.network_legacy
    import ansible.plugins.action.netconf
    import ansible.plugins.action.httpapi
    import ansible.plugins.action.async_status
    import ansible.plugins.action.async_wrapper
    import ansible.plugins.action.raw
    import ansible.plugins.action.command
    import ansible.plugins.action.shell
    import ansible.plugins.action.script
    import ansible.plugins.action.win_command
    import ansible.plugins.action.win_shell
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file

# Generated at 2022-06-17 09:08:31.483411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_distribution'))),
        connection=dict(connection='local'),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._supports_check_mode is True
    assert action_module._task.action['module_name'] == 'setup'
    assert action_module._task.action['module_args'] == dict(filter='ansible_distribution')
    assert action_module._connection.connection == 'local'
    assert action_module._play_context.check_mode is False
    assert action_module._loader is None
    assert action_module._templ

# Generated at 2022-06-17 09:08:43.969884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all'],
                gather_timeout=10,
                filter='*'
            )
        ),
        connection=dict(
            _load_name='network_cli'
        ),
        task_vars=dict(
            ansible_network_os='ios'
        )
    )

    assert action_module._get_module_args('ansible.legacy.setup', dict()) == dict()
    assert action_module._get_module_args('ansible.legacy.setup', dict(
        ansible_network_os='ios'
    )) == dict(
        gather_subset=['all'],
        gather_timeout=10,
        filter='*'
    )
    assert action_module._get

# Generated at 2022-06-17 09:08:52.073639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module plugin
    module_plugin = MockModulePlugin()

    # Create a mock module
    module = MockModule()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = MockModuleFinder()

    # Create a mock module finder
    module_finder = Mock

# Generated at 2022-06-17 09:09:03.023156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    action_module = ActionModule()

    # create a mock task object
    task = MockTask()

    # create a mock connection object
    connection = MockConnection()

    # create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # create a mock templar object
    templar = MockTemplar()

    # create a mock display object
    display = MockDisplay()

    # set the attributes of the mock objects
    task.args = {'parallel': None}
    task.module_defaults = {}
    task.collections = []
    connection._load_name = 'network_cli'
    shared_loader_obj.module_loader = MockModuleLoader()
    shared_loader_obj.module_loader.find_plugin_with_context = Mock

# Generated at 2022-06-17 09:09:10.461928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock config
    mock_config = MockConfig()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock action plugin
    mock_action_plugin = MockActionPlugin()

    # Create a mock module_loader
    mock_module_loader = MockModuleLoader()

    # Create a mock module_utils
    mock_module_utils = MockModuleUtils()

    # Create a mock module_utils
    mock_module_utils = MockModule