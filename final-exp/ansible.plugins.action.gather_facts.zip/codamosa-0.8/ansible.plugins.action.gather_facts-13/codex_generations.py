

# Generated at 2022-06-11 11:42:20.239220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-11 11:42:26.444322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = '10.0.0.1'
    task = 'test task'
    connection = 'local'
    play_context = {}
    loader = None
    templar = None
    shared_loader_obj = None

    am = ActionModule(host, task, connection, play_context, loader, templar, shared_loader_obj)
    assert am is not None
    # unit test for method of run
    assert isinstance(am.run(tmp=None, task_vars=None), dict)

# Generated at 2022-06-11 11:42:36.197620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    import random
    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils.color import ANSIBLE_COLOR, stringc
    context.CLIARGS = {}
    context.CLIARGS['connection'] = 'smart'
    context.CLIARGS['module_path'] = random.choice(['/tmp/ansible_module_utils', '/etc/ansible/modules'])
    context.CLIARGS['color'] = random.choice([0, 1])
    context.CLIARGS['explicit'] = 'explicit'

# Generated at 2022-06-11 11:42:47.236821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.setup'
    module_args = {}
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts_parallel_value': None,
        'gather_subset': None,
        '_ansible_verbose_override': False,
        '_ansible_no_log': True,
        'ansible_facts': {},
        'ansible_version': {},
        'ansible_module_args': {},
        'ansible_module_name': 'setup',
        'ansible_job_id': '5',
        'ansible_play_id': '3L',
        'inventory_hostname': 'local'
    }

    module_action = ActionModule(None, None)
    module_

# Generated at 2022-06-11 11:42:51.996186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test is to check the instance creation of class ActionModule
    """
    module_args = dict(
        plugins=['core'],
        module_paths=['/library']
    )
    shared_loader_obj = ActionModule.load_shared_module(module_args)
    assert isinstance(shared_loader_obj, ActionModule)

# Generated at 2022-06-11 11:42:55.055978
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create instance ActionModule
    class_module = ActionModule()
    # assert class_module is instance of ActionModule
    assert isinstance(class_module, ActionModule)


# Generated at 2022-06-11 11:42:57.480036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.__class__.__name__ == 'ActionModule'



# Generated at 2022-06-11 11:43:02.187742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == {
        'ansible_facts': {},
        'ansible_facts_gathered': True,
        'ansible_facts_gathered_gather_time': 0.00,
        '_ansible_verbose_override': True
    }

# Generated at 2022-06-11 11:43:03.770447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-11 11:43:14.766369
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    # set up params
    module_name = 'setup'
    module_args = {}
    task_vars = {}
    tmp = '/path/to/tmp'

    # create a mock object for
    class MockModule(ActionBase):
        pass

    mock_module = MockModule()

    # create a mock object for
    class MockTask(object):
        def __init__(self):
            self.args = module_args
            self.module_defaults = 'module_defaults'

    mock_task = MockTask()

    # create a mock object for
    class MockTask(object):
        def __init__(self):
            self.args = module_args
            self.module_defaults = 'module_defaults'
            self._action_groups = 'action_groups'

    mock_task

# Generated at 2022-06-11 11:43:36.402732
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_action_module = ActionModule()

# Generated at 2022-06-11 11:43:45.542965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct the mock objects for task and for modules
    task_mock = MockTask()
    action_module_mock = MockActionModule()

    # Actual call to the method
    result = action_module_mock.run(tmp=None, task_vars={'ansible_facts_parallel': 'True'})

    # Asserts on the result
    assert result['failed'] is False
    assert result['skipped'] is False
    assert result['msg'] == ''
    assert result['ansible_facts']['_ansible_facts_gathered'] is True
    assert result['ansible_facts']['test_fact'] == 'test'
    assert result['ansible_facts']['test_fact2'] == 'test2'


# Mock class for task

# Generated at 2022-06-11 11:43:46.603589
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 11:43:47.280100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:43:58.871571
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ############################################################
    # Setup
    ############################################################

    module_name = "test_module"
    module_args = {"test_arg": "test_value"}
    task_vars = {"my_var1": "value1", "my_var2": "value2"}
    tmp = "/path/to/tmp"
    module_loader = None
    task_path = "some/task/path"
    wrap_async = False

    ############################################################
    # Test code
    ############################################################

    # run()
    ############################################################

    # test absent
    module_args = {}

    action = ActionModule(module_name, module_args, tmp, task_vars, module_loader, task_path, wrap_async)
    assert 'ansible_facts' in action

# Generated at 2022-06-11 11:44:10.041551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'setup'
    module_args = {}
    module_kvargs = {}
    # Mock the task object
    module_task = {}
    module_task['args'] = {}
    module_task['args']['gather_subset'] = 'network'
    module_task['args']['gather_timeout'] = 20
    module_task['args']['filter'] = 'ansible_pkg_mgr'
    module_task['args']['parallel'] = True

    # Mock the host object
    module_host = {}

    # Mock the connection object
    module_connection = {}
    module_connection['_load_name'] = 'network_cli'
    module_connection['_connection'] = None
    module_connection['_shell'] = {}

# Generated at 2022-06-11 11:44:10.708028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:44:11.366744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:44:12.198952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:18.893234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.setup as setup_module

    action = setup_module.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = action._get_module_args("ping", dict())
    assert {'data': 'ping'} == result

    result = action._combine_task_result({"deprecations": ["dep1"]}, {"deprecations": ["dep2"]})
    assert {"deprecations": ["dep1", "dep2"]} == result

# Generated at 2022-06-11 11:44:41.253978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(setup=dict(),tasks=dict()), dict(connection=dict()))
    assert isinstance(a, ActionModule)

# Generated at 2022-06-11 11:44:49.415705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class _Args:
        def __init__(self, args):
            self.args = args
            self.module_defaults = {}

    class _Task:
        def __init__(self, args):
            self.args = _Args(args)
            self._parent = _Play()
            self.collections = []

    class _Play:
        def __init__(self):
            self._action_groups = {}

    class _ActionBase:
        class _SharedLoaderObj:
            class _ModuleLoader:
                def find_plugin_with_context(self, module, collection_list=[]):
                    return ResolvedFQCN()

        def __init__(self):
            self._templar = ''
            self._shared_loader_obj = self._SharedLoaderObj()

# Generated at 2022-06-11 11:44:58.196256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult

    for action_plugin in action_loader._all_actions.keys():
        action = action_loader.get(action_plugin, class_only=True)

        if not hasattr(action, 'run') or action_plugin in ('async_status', 'debug'):
            continue
        if not hasattr(action, '_get_module_args'):
            continue

        # create a mock task object
        task = type('TaskResult', (object,), {
            'args': {},
            'collections': [],
            'module_defaults': dict(),
        })()

# Generated at 2022-06-11 11:45:08.330838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.clean import module_response_deepcopy
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    import json

    # define the module required
    mod_args_setup = dict(filter="*",ANSIBLESETUP_MODULE_SETUP=True)

    # create the needed objects to run playbook

# Generated at 2022-06-11 11:45:09.213444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    check = ActionModule()
    assert check.run()

# Generated at 2022-06-11 11:45:13.464126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for action plugin module

    :return: None
    '''
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert module is not None

# Generated at 2022-06-11 11:45:23.166931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext

    task_queue_manager = TaskQueueManager()
    task_result = TaskResult()
    play_context = PlayContext()
    action_module = ActionModule(task_queue_manager=task_queue_manager,
                                  play_context=play_context,
                                  loader=None,
                                  templar=None,
                                  shared_loader_obj=None)
    print(action_module)

    assert action_module.async_val == 2
    assert action_module.host_set == set()
    assert action_module.module_vars == dict()
    assert action_module.play_context is play_context



# Generated at 2022-06-11 11:45:35.669242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(), module_defaults=dict())),
        connection=dict(transport='ansible.legacy.local'),
        templar=None,
        shared_loader_obj=None,
        connection_loader=None,
        _play_context=None,
        new_stdin=None
    )
    assert mod.run(tmp=None, task_vars=dict()) == {
        'ansible_facts': {'_ansible_facts_gathered': True},
        '_ansible_verbose_override': True,
        'failed': False,
        'msg': None,
        'parsed': True,
        'skip_reason': None,
        'skipped': None,
    }

# Generated at 2022-06-11 11:45:46.732833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This method is unit testing for method run of class ActionModule
    """
    ##############################
    test_fact_modules = [['test1', 'test2'], ['test3', 'test4', 'test5'], ['test6']]

    ##############################
    test_module = ActionModule()
    result = {}
    result['ansible_facts'] = {}
    result = test_module._combine_task_result(result, {'ansible_facts': {'test_module': 1}, 'warnings': ['test_module'], 'deprecations': ['test_module']})
    assert result['ansible_facts'] == {'test_module': 1}
    assert result['warnings'] == ['test_module']
    assert result['deprecations'] == ['test_module']

    #################

# Generated at 2022-06-11 11:45:53.453149
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:46:49.792794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    results = list()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 11:46:52.360218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, connection=None, play_context=None,
                                            templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-11 11:46:53.848889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing with no parameters
    plugin = ActionModule(None, None, None, None, None)
    assert plugin

# Generated at 2022-06-11 11:46:54.526627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-11 11:46:55.362597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:47:03.644067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils.facts.processor.base import Processor, ProcessorCollector
    import ansible.module_utils.facts.system.base
    # Import is covered but codecov seems to be confused about modules that are
    # also datasets
    # https://github.com/codecov/codecov-python/issues/127
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    class TestHardware(Hardware):

        def __init__(self):
            self._fact = {
                'a': 'yea'
            }

        def get_facts(self):
            return self._fact


# Generated at 2022-06-11 11:47:05.612289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #mock the super.run method
    pass

# Generated at 2022-06-11 11:47:16.506666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We can't test against the ansible module here because it is a protected variable
    # To keep consistent with other tests, we will change the protected variable to public for testing
    ActionBase._shared_loader_obj = None
    ActionBase._templar = None
    a = ActionModule()
    assert a is not None
    assert a._shared_loader_obj is None
    assert a._templar is None

    # test _execute_module
    a._connection = None
    ret = a._execute_module(module_name='test_module', module_args=None, task_vars=None, wrap_async=False)
    assert ret == {}

    # test _get_module_args
    a._task = None
    ret = a._get_module_args(fact_module='test_module', task_vars=None)

# Generated at 2022-06-11 11:47:17.080932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:47:24.164835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # make sure that _task is set
    # from: https://stackoverflow.com/a/46518229/1255558
    task = MagicMock(spec=Task)
    module._task = task

    # make sure that _display is set
    display = MagicMock(spec=Display)
    module._display = display

    # make sure that _connection is set
    connection = MagicMock(spec=Connection)
    module._connection = connection

    # make sure that _loader is set
    loader = MagicMock(spec=DataLoader)
    module._loader = loader

    # make sure that _shared_loader_obj is set
    shared_loader_obj = MagicMock(spec=AnsibleCollectionLoader)
    module._shared_loader_obj = shared_loader_obj

    # make sure

# Generated at 2022-06-11 11:49:07.556095
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test empty modules
    am = ActionModule()
    am._task.args = {}
    assert am.run(tmp=None, task_vars=None) == {
        '_ansible_verbose_override': True,
        'ansible_facts': {'_ansible_facts_gathered': True},
        'changed': False,
        'failed': False,
        'invocation': {'module_args': {}},
        'msg': '',
        'skipped': True,
        'skipped_modules': {},
    }

    # Test regular modules
    am = ActionModule()
    am._task.args = {'a':1, 'b':2}

# Generated at 2022-06-11 11:49:09.581729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    env = Environment()
    plugin = ActionModule.load(None, loader=loader, templar=env.templar)

    assert plugin is not None


# Generated at 2022-06-11 11:49:11.273752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the existence of the method run
    assert hasattr(ActionModule, 'run'), "ActionModule does not have an attribute run"

# Generated at 2022-06-11 11:49:19.982587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_obj(ActionModule):
        def __init__(self, *args, **kwargs):
            self.run_calls = []
            super(ActionModule_obj, self).__init__(*args, **kwargs)

        def run(self, *args, **kwargs):
            self.run_calls.append(True)
            return super(ActionModule_obj, self).run(*args, **kwargs)

    class Executor_obj(object):
        def __init__(self, *args, **kwargs):
            self.run_calls = []

        def run(self, *args, **kwargs):
            self.run_calls.append(True)
            return b'{}'


# Generated at 2022-06-11 11:49:28.746215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    test the run method of class ActionModule.
    """
    import pytest
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.test.test_setup import TestSetupModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import context
    from collections import namedtuple


# Generated at 2022-06-11 11:49:37.181692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    internal_obj = globals()['ansible']['module_utils']['internal_lib'] = globals()['ansible']['module_utils'].get('internal_lib', Mock())
    ansible_connection = globals()['ansible']['plugins']['connection'] = globals()['ansible'].get('plugins', {}).get('connection', Mock())
    ansible_loader = globals()['ansible']['plugins']['loader'] = globals()['ansible'].get('plugins', {}).get('loader', Mock())
    ansible_module_utils = globals()['ansible']['utils'] = globals()['ansible'].get('utils', Mock())

# Generated at 2022-06-11 11:49:37.976104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 11:49:41.413347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = dict()
    module.run(task_vars=dict(),result=result)
    assert result["failed"]
    assert result["msg"] == "The following modules failed to execute: smart\n"
    assert result["failed_modules"]["smart"]["failed"]

# Generated at 2022-06-11 11:49:46.848474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    ActionModule.run(tmp, task_vars)
    '''

    # A module was specified in the playbook, but the module could not be found.
    # This could happen if a non-core module is used and the path to that module is not specified in ansible.cfg.
    # The module_utils/ directory in the same directory as the module is automatically added to the search path.
    # The path given in ansible.cfg can be a directory or a list of directories separated by the OS path separator.
    pass

# Generated at 2022-06-11 11:49:55.374543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fake "env" dict, that defines which environment variables are available inside the playbook execution
    env_dict = {'ANSIBLE_ASYNC_DIR': './async'}
    # Fake ansible options