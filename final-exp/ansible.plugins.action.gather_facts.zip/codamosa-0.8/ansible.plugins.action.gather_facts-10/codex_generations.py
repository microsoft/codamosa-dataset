

# Generated at 2022-06-11 11:42:21.917110
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule()

# Generated at 2022-06-11 11:42:22.478582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:32.211715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(
            args=dict(
                a=1,
                b='2',
                c=True,
                parallel=True
            )
        ),
        connection=dict(),
        tmp=None,
        shared_loader_obj=None,
        templar=None,
        loader=None
    )
    assert mod.task_vars == {}
    assert mod._task.args == {'a': 1, 'b': '2', 'c': True, 'parallel': True}
    assert mod._supports_check_mode == True
    assert mod.task == {'args': {'a': 1, 'b': '2', 'c': True, 'parallel': True}}
    assert mod._display is None
    assert mod.runner is None
    assert mod._connection is None

# Generated at 2022-06-11 11:42:43.805282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import time

    import pytest
    from unittest._mock import patch, Mock
    from ansible.utils import vars as ansible_vars
    from ansible import constants as ansible_constants
    from ansible.plugins.loader import action_loader
    import ansible.plugins.action.setup as action_setup
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    # Create the mocks needed for the test.
    class MockFactsModule(object):
        def __init__(self, name):
            self.name = name
            self.resolved_fqcn = name

    mock_task = Mock(spec=['args', 'module_defaults'])
    mock_task.module_defaults

# Generated at 2022-06-11 11:42:44.232357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:53.519186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.module_utils.facts.network.base import NetworkBase
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts.system.base import SystemBase
    from ansible.playbook.play_context import PlayContext

    class MyActionModule(ActionModule):
        def __init__(self):
            self._result = dict(
                ansible_facts=dict(),
                ansible_facts_gathered=True,
                _ansible_verbose_override=True,
            )

        def run(self, tmp=None, task_vars=None):
            return super(MyActionModule, self).run(tmp, task_vars)

    class MyNetworkBase(NetworkBase):
        platform = None

# Generated at 2022-06-11 11:43:04.967076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    action_module = mock.Mock(spec=ActionModule)
    fact_module = mock.Mock()
    task_vars = {"ansible_debug":True, "ansible_verbosity":3, "ansible_fact_gathering": "implicit", "ansible_module_gathering": "implicit"}
    #ansible_fact_gathering and ansible_module_gathering not present in task_vars for this task
    result = action_module.run(None, task_vars)
    #import pdb; pdb.set_trace()
    assert result['ansible_facts'] == {}
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True

# Generated at 2022-06-11 11:43:09.987333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of ActionModule called without any parameter,
    it should return the object of ActionModule class with default values.
    """

    action_module = ActionModule()
    assert action_module.__class__.__name__ == "ActionModule"
    assert action_module._supports_check_mode == True

# Generated at 2022-06-11 11:43:11.076800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-11 11:43:18.511532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    result = {}
    # Config setup
    C.config = mock.MagicMock()
    C.config.get_config_value = mock.MagicMock(return_value=[])
    # _task setup
    _task = mock.MagicMock()
    _task.args = {}
    _task.args['parallel'] = None
    _task.collections = []
    # _shared_loader_obj setup
    _shared_loader_obj = mock.MagicMock()
    _shared_loader_obj.module_loader = {}
    _shared_loader_obj.module_loader.find_plugin_with_context = mock.MagicMock(
        return_value={'resolved_fqcn': 'resolved_fqcn'})
    # _templar

# Generated at 2022-06-11 11:43:32.011380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    pass

# Generated at 2022-06-11 11:43:39.309207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import unittest

    # Initialize Ansible, if Ansible is not initialize then this test case not executed,
    # if you need to run this test case as a separate process then you need to initialize
    # Ansible before running this test case.
    try:
        import ansible
        ansible.constants.HOST_KEY_CHECKING = False
        ansible.constants.DEFAULT_KEEP_REMOTE_FILES = 0
    except Exception as e:
        print(e)
        sys.exit(1)

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 11:43:42.475116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Create a test ActionModule instance
    """
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict()
    )
    assert action._supports_check_mode is True

# Generated at 2022-06-11 11:43:45.981812
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionModule = ActionModule()
    result = actionModule.run()

    assert result == {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}

# Generated at 2022-06-11 11:43:56.680600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    from ansible.executor.task_result import TaskResult
    from ansible.executor import task_queue_manager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes

    global module
    #import pdb; pdb.set_trace()

# Generated at 2022-06-11 11:44:08.540017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = MagicMock()
    mock_connection = MagicMock()
    mock_task = MagicMock()
    mock_templar = MagicMock()

    # The local variable 'result' is not used in the constructor,
    # but it is instantiated without being assigned a value.
    # So it will be used as a mock in the unit test.
    result = MagicMock()
    action_setup = ActionModule(
        loader=mock_loader,
        connection=mock_connection,
        task=mock_task,
        templar=mock_templar,
        shared_loader_obj=None,
        result=result,
    )
    assert isinstance(action_setup, ActionModule)
    assert action_setup._loader is mock_loader
    assert action_setup._connection is mock_

# Generated at 2022-06-11 11:44:18.569290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import datetime
    import sys
    import yaml

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action import ActionBase
    from ansible.utils import context_objects as co
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash

    from ansible_collections.ansible.netcommon.plugins.action.setup import ActionModule

    class ActionModuleTest(ActionModule):

        def run(self, tmp=None, task_vars=None):
            super(ActionModuleTest, self).run(tmp, task_vars)
            return {'ansible_facts': {'test_facts': 'action_module_test'}}


# Generated at 2022-06-11 11:44:29.556618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test from action_plugin/setup.py
    module_args = dict(
        gather_subset=dict(
            default=['all'],
            type='list',
            elements='raw',
            aliases=['gather-subset'],
            metavar='<gather_subset>'
        ),
        gather_timeout=dict(
            default=10,
            type='int',
            aliases=['gather-timeout'],
            metavar='<gather_timeout>'
        ),
        filter=dict(default=None, type='str', aliases=['search']),
        network_os=dict(default=None, type='str'),
        parallel=dict(default=None, type='bool'),
    )


# Generated at 2022-06-11 11:44:30.248664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:44:32.700864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.__bases__[0].__name__ == 'ActionBase'

# Generated at 2022-06-11 11:45:06.769871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.plugins.loader import action_loader

    global_config = {
        'DEFAULT_JINJA2_NATIVE': 'True',
        # 'ANSIBLE_FACTS_CACHE_TIMEOUT': '0',
        # 'ANSIBLE_FACTS_CACHEABLE_PLUGINS': '',
        # 'ANSIBLE_FACTS_CACHEABLE_MODULES': ''
    }
    config = {
        'FACTS_MODULES': ['ansible_facts_setup', 'ansible.legacy.setup'],
        'CONNECTION_FACTS_MODULES': {'ansible.legacy.network': 'ansible.legacy.connection_network_facts'}
    }

# Generated at 2022-06-11 11:45:17.083388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_variables = {
        'ansible_facts': {
            '_ansible_facts_gathered': False,
            '_ansible_facts_gathered_with_smart': None,
        }
    }
    mock_task = {
        'args': {
            'gather_subset': 'all',
            'filter': '*',
            'gather_timeout': 10
        },
        'collections': [],
        'module_defaults': []
    }
    mock_connection = {
        '_load_name': 'ansible.cli'
    }
    mock_display = {
        'warning': lambda x: None,
        'vvvv': lambda x: None,
    }

# Generated at 2022-06-11 11:45:26.053213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import time

    from ansible.module_utils.six.moves.queue import Queue
    from ansible.plugins.action.setup import ActionModule

    def _load_module(self, name, path):
        module = {
            'ansible.legacy.setup': {'argument_spec': {}, 'main': fake_main},
            'ansible.legacy.async_status': {
                'argument_spec': {'jid': {'type': 'str'}, '_async_dir': {'type': 'str'}},
                'main': async_status
            }
        }[name]
        module['path'] = path
        return module

    def _get_connection(self):
        return None


# Generated at 2022-06-11 11:45:28.118984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    action_module = ActionModule()
    assert action_module is not None



# Generated at 2022-06-11 11:45:37.692101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = 'setup'
    shared_loader = 'ansible_loader'
    connection = 'ansible_connection'
    play_context = 'ansible_play'
    task_vars = 'ansible_task_vars'
    loader = 'ansible_loader'
    display = 'ansible_display'
    templar = 'ansible_temprar'
    action = ActionModule(task, shared_loader, connection, play_context, task_vars, loader, display, templar)

    assert action is not None

# Generated at 2022-06-11 11:45:48.367804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockHost:
        ipv4 = ''

    class MockTask:
        async_val = None
        async_enabled = None
        args = {
            'filter': None,
            'gather_timeout': None,
            'gather_subset': None,
            'parallel': None,
        }

    class MockTaskVars:
        pass

    class MockPlayContext:
        ansible_playbook_python = None
        _ssh_args = ''

    class MockConnection:
        _load_name = 'network_cli'
        tmpdir = ''

    class MockANS_CONFIG:
        config = {
            'FACTS_MODULES': {},
            'CONNECTION_FACTS_MODULES': {},
        }

    class MockSharedLoaderObj:
        pass


# Generated at 2022-06-11 11:45:59.422719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit tests for ActionModule._execute_module() '''
    import types
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system import DistributionFactRetriever
    from ansible.module_utils.facts.system.distribution_default import DistributionDefault
    from ansible.module_utils.facts.system.distribution_redhat import DistributionRedHat
    from ansible.module_utils.facts.system.distribution_suse import DistributionSUSE
    from ansible.module_utils.facts.system.distribution_gentoo import DistributionGentoo


# Generated at 2022-06-11 11:46:00.010662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  ActionModule.run()

# Generated at 2022-06-11 11:46:10.985513
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa
    # this test should be removed in ansible 3.0
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-11 11:46:12.416830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fact_module = ActionModule()

    assert fact_module.supports_check_mode is True

# Generated at 2022-06-11 11:47:18.199201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import yaml
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible_collections.ansible.netcommon.plugins.action.setup import ActionModule

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary program file
    program_file = os.path.join(tmpdir, "program")
    with open(program_file, "w") as f:
        f.write("#!/usr/bin/python -tt\n")

# Generated at 2022-06-11 11:47:24.738653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.constants as C
    import ansible.module_utils.facts.system.distribution as distro
    import ansible.module_utils.facts.puppet as puppet
    import ansible.module_utils.facts.network.base as network
    from ansible.plugins.action.setup import ActionModule as setup_action
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    mock_module = 'ansible.plugins.action.setup.ActionModule'


# Generated at 2022-06-11 11:47:31.624496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule should take following parameters.
    # self, task, connection, play_context, loader, templar, shared_loader_obj
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import PluginLoader

    # Set up parameters to be used for creating class ActionModule
    task = Task()
    connection = None
    play_context = PlayContext()
    loader = PluginLoader('')
    templar = None
    shared_loader_obj = None

    # Create object of class A

# Generated at 2022-06-11 11:47:42.332755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.compat.tests.mock as mock
    from ansible.module_utils._text import to_bytes

    from ansible.compat.tests.mock import patch
    from ansible.plugins.action import ActionModule

    orig_ActionModule_get_action_args_with_defaults = ActionModule.get_action_args_with_defaults

    def modify_get_action_args_with_defaults(self, plugin_fqcn, arg_spec, module_defaults, connection, templar, action_groups):
        default_arg_spec = orig_ActionModule_get_action_args_with_defaults(self, plugin_fqcn, arg_spec, module_defaults, connection, templar, action_groups)
        default_arg_spec['args_test'] = 'test_data'

# Generated at 2022-06-11 11:47:51.817453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'localhost'
    connection = 'local'
    tmp = '/home/tmp'
    task_vars = {}
    class Model(object):
        name = 'setup'
        args = []
        host = None
        vars = {}
        module_defaults = {}
        class task(object):
            class play(object):
                class _action_groups(object):
                    selinux = {}
                    packages = {}
    task = Model()
    class PlayContext(object):
        def __init__(self, a_vars):
            self.vars = a_vars
            self.connection = 'local'
            self._shell = None
    class ModelRunner(object):
        def __init__(self):
            self.shell = None
            self.playbook = None
            self.task = None
           

# Generated at 2022-06-11 11:48:01.258408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialising
    tasks = [{
        'use_defaults': False,
        'args': {}
    }]
    task_args = {
        'module_defaults': {
            'gather_subset': ['all'],
            'gather_network_resources': ['all'],
        },
        'action_groups': ['setup', 'gather'],
        'collections': ['ansible_collections.acme.foo'],
    }

    # Testing the case of no facts_modules
    set_module_args({})
    module = ActionModule(task=tasks, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, task_vars=task_args)

# Generated at 2022-06-11 11:48:10.118655
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock constants and loaders
    constants = dict(config=dict(get_config_value=dict(FACTS_MODULES=['test'], CONNECTION_FACTS_MODULES=dict())))

    # Mock module
    module = dict()

    # Mock display
    display = dict(vvvv=dict(return_value=None),warning=dict(return_value=None))

    # Mock task
    task_vars = dict()

    # Mock connection
    connection_load_name = 'test_connection'

    # Mock task
    task_vars = dict()

    # Mock executor
    executor_module_loader_find_plugin_with_context = dict(return_value=dict(resolved_fqcn='test_resolved_fqcn'))

    # Mock templar
    tem

# Generated at 2022-06-11 11:48:10.681581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:48:20.326912
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeSuper(object):
        _templar = 'foo'
        _task = 'bar'
        _task._parent = 'baz'
        _task._parent._play = 'qux'
        _task._parent._play._action_groups = 'foobar'
        _task._parent._play._action_groups = 'foobaz'
        _task._parent._play._action_groups = 'foobaz'
        _task._parent._play._action_groups = 'foobaz'

    class FakeConnection(object):
        _load_name = 'network_cli'

    class FakeDisplay(object):
        verbosity = 1

    class FakeModuleLoader(object):
        def find_plugin_with_context(self, name, collection_list):
            return name


# Generated at 2022-06-11 11:48:29.243739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    from ansible.utils.display import Display

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play = Play.load({}, variable_manager=variable_manager, loader=loader)
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader)
    # For ActionModule to be instantiated properly

# Generated at 2022-06-11 11:50:35.551165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-11 11:50:43.336806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult

    class Mock_ActionBase(ActionBase):
        def __init__(self, *args, **kwargs):
            super(Mock_ActionBase, self).__init__(*args, **kwargs)
            self._shared_loader_obj = None

        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            expected = ['ansible.legacy.setup']
            if wrap_async:
                expected.append('ansible.legacy.async_status')
            assert_expected = expected.pop(0)
            assert(assert_expected == module_name)
            task_result = TaskResult(dict(changed=False, failed=False, skipped=False))

# Generated at 2022-06-11 11:50:43.822924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:50:51.298843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = mock.Mock()
    task.args.copy.return_value = {'verbosity': 0, 'connection': 'local', 'gather_subset': ['all']}
    task.args = {'verbosity': 0, 'connection': 'local', 'gather_subset': ['all']}

    # create a mock task_vars
    task_vars = {}

    # create a ActionModule instance
    action_module = ActionModule(task, task_vars)

    # create a mock tmp
    tmp = mock.Mock()

    # execute the ActionModule run method
    result = action_module.run(tmp, task_vars)

    # assert result is a dict
    assert isinstance(result, dict)

    # assert result has the following keys

# Generated at 2022-06-11 11:50:57.784105
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # initialize the action module object
    action_module = ActionModule(None, None, None, None, None)

    # initialize the task variables
    task_vars = {}
    task_vars = {'ansible_network_os': 'junos', 'ansible_connection': 'network_cli'}

    # initialize the task
    task = {'args': {}}

    # initialize the module args
    module_args = {}

    # initialize the result
    result = {}

    # return results after executing the method run of class ActionModule
    return action_module.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-11 11:50:58.359936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:51:06.925977
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_execute_module = dict(
        failed=False,
        msg=''
    )

    mock_execute_module_res = dict(
        failed=False,
        msg='',
        ansible_facts={
            'hostname': 'localhost',
        }
    )

    def mock_execute(self, module_name, module_args, task_vars=None, tmp=None, wrap_async=False):
        if module_name == 'ansible_facts.test':
            return mock_execute_module
        return mock_execute_module_res

    mock_combine = dict(
        ansible_facts={
            '_ansible_facts_gathered': True,
            'hostname': 'localhost',
        },
        warnings=[],
        deprecations=[],
    )

    ActionModule._execute

# Generated at 2022-06-11 11:51:07.694928
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module is not None

# Generated at 2022-06-11 11:51:09.256921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert getattr(ActionModule, 'do_setup', False)
    assert getattr(ActionModule, 'run', False)

# Generated at 2022-06-11 11:51:17.673320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    success_res = {'failed': False, 'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}
    failure_res = {'failed': True, 'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True, 'failed_modules': {'ansible.legacy.setup': {'invocation': {'module_args': {'filter': '*'}}, 'msg': 'Test failure', 'rc': 1, 'failed': True}}}

    class SetupMock():
        def __init__(self):
            self._task = self
            self._task.args = {'gather_subset': 'all'}