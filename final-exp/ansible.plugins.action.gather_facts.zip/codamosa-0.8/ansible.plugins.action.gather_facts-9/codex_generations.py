

# Generated at 2022-06-11 11:42:30.496405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        connection=object,
        _make_tmp_path=lambda x: 'tmpdir',
        loader=object,
        _task_vars=dict(),
        _templar=object,
        _shared_loader_obj=object,
        _connection_info=dict(network_os='nxos'),
        _task=object,
        task_vars=dict(),
    )


# Generated at 2022-06-11 11:42:31.368740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-11 11:42:42.840648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_result = {
        'failed': False,
        'msg': '',
        'skipped_modules': {},
        'skipped': False,
        'ansible_facts': {
        },
        '_ansible_verbose_override': True,
        'changed': False,
        'ansible_facts_gathered': True
    }

    task_vars = {
        'ansible_facts_parallel': True
    }

    fact_module = 'ansible.legacy.setup'

    module_args = {
        'module_defaults': {},
        '_ansible_check_mode': False
    }


# Generated at 2022-06-11 11:42:43.284072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:51.625366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Task(object):
        def __init__(self):
            self.args = dict(
                parallel=None,
                module_defaults=dict(
                    cache_plugin='memory',
                    cache_timeout=3600,
                )
            )
            self.env = dict()
        def add_module_defaults(self, module_defaults):
            self.module_defaults = module_defaults
        def update_env(self, module_defaults):
            if module_defaults:
                self.env.update(dict(module_defaults=module_defaults))
    class AnsibleOptions(object):
        def __init__(self):
            self.debug = False
            self.verbosity = 0
    class Ansible(object):
        def __init__(self):
            self.options = Ansible

# Generated at 2022-06-11 11:42:52.534841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-11 11:43:03.932259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the code that is executed when the module is loaded by Ansible
    """

    class MockTask:
        args = {}
        language = 'en'
        display = {'verbosity': 1}
        _action = 'setup'
        _parent = None
        _play = None
        _collections = []
        _connection = None

    class MockPlay:
        _action_groups = {}

    class MockVarManager:
        def get_vars(self, *args, **kwargs):
            return dict()

        def get_vars_files(self, *args, **kwargs):
            return dict()

    class MockModule_loader(object):
        """ mock AnsibleModuleLoader class """
        def find_plugin(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 11:43:14.881035
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task = DummyTask()
    task2 = DummyTask()
    task2.args = {
        'parallel': None
    }
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_network_os': 'ios',
        'ansible_facts': {
            'network_os': 'ios'
        }
    }
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action2 = ActionModule(task2, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    with pytest.raises(TypeError):
        action.run(task_vars=task_vars)
   

# Generated at 2022-06-11 11:43:22.931386
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Check if class exists
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule is not None

    # Check if method run exits
    with pytest.raises(AnsibleExitJson):
        actionmodule.run()

    # Check if method run exits
    with pytest.raises(AnsibleExitJson):
        actionmodule.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 11:43:23.648294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:43:42.246545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options:
        def __init__(self):
            self.verbosity = 10
            self.check = False
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False

    class Task:
        def __init__(self):
            self.action = 'setup'
            self.args = {}
            self.module_defaults = {}

    class Play:
        def __init__(self):
            self.name = 'myplay'

    class PlayContext:
        def __init__(self):
            self.connection = 'local'

    class PlayBook:
        def __init__(self):
            self.DEFAULT_LOADER_NAME = 'loader'

    class Connection:
        def __init__(self):
            self._shell

# Generated at 2022-06-11 11:43:52.733139
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import builtins
    # Force the cwd to be the root of the repo, to make importing the
    # Modules working
    builtins.__dict__['__file__'] = __file__.replace('action_plugin/setup.py', 'setup.py')
    import json
    # Import modules here, `builtins.__file__` must be set above to avoid
    # import error
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange
    from ansible.executor.module_common import get_action_args_with_defaults

# Generated at 2022-06-11 11:44:05.351699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.system.hardware import Hardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.network import Network
    from ansible.module_utils.facts.system.facter import Facter
    from ansible.module_utils.facts.system.system import System
    from ansible.module_utils.facts.system.user import User
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.selinux import Selinux
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr

# Generated at 2022-06-11 11:44:15.620476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import MV
    facts = {'_ansible_tmpdir': '/tmp'}
    # result = {'ansible_facts': {'_ansible_facts_gathered': True}}
    res = TaskResult('/tmp', module_args={}, module_name='setup', action='setup', task=MV({'args': {'a': 'b'}}), module_msgs=[], task_result={}, but_not_everything=False)
    res.results = {'ansible_facts': {'_ansible_facts_gathered': True}}
    with open('test_result.txt', 'w') as f:
        f.write(str(res))
    return res.results

# Generated at 2022-06-11 11:44:16.517192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None)
    assert action

# Generated at 2022-06-11 11:44:17.389272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 11:44:23.247867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Checks instantiation of ActionModule
    '''
    action_module = ActionModule(
        task=dict(
            action=dict(
                module_name=''
            ),
            args=dict()
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert(action_module)
    assert(isinstance(action_module, ActionModule))

# Generated at 2022-06-11 11:44:34.697924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ShellMock():
        def __init__(self, **kwargs):
            pass

        def connect(self, **kwargs):
            pass

        def exec_command(self, cmd, **kwargs):
            pass

        def get_transport_info(self, **kwargs):
            return ('test', 'test')

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    class ExecutorMock():
        def __init__(self, **kwargs):
            pass

        def close(self):
            pass

        def noop(self):
            pass

        def get_task_vars(self, task_vars):
            return task_vars


# Generated at 2022-06-11 11:44:39.379048
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:44:47.501449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    with MockConnection(name='local') as conn:
        task_vars = dict()
        task_vars['ansible_connection'] = conn

        action = AnsibleAction(
            task=Task(action='setup', args={'filter': 'all'}, task_vars=task_vars),
            connection=conn,
            play_context=None,
            loader=None,
            templar=None,
            shared_loader_obj=None
        )

        ansible_facts = {
            'gathered_facts': {
                'ansible_all_ipv4_addresses': ['1.1.1.1', '2.2.2.2']
            }
        }

# Generated at 2022-06-11 11:45:19.675416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #setup
    tmp = None
    task_vars = {}

    # create object ActionModule
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # call run method
    res = obj.run(tmp=tmp, task_vars=task_vars)

    # check results
    assert 'ansible_facts' in res
    assert '_ansible_facts_gathered' in res['ansible_facts']
    assert 'skipped_modules' in res
    assert 'skipped' not in res
    assert 'failed' not in res
    assert '_ansible_verbose_override' in res



# Generated at 2022-06-11 11:45:20.704079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1
    

# Generated at 2022-06-11 11:45:24.242988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.actions = dict()
    am.actions.update(dict(name='setup', in_action_plugins=True))
    time.sleep(1)
    result = am.run({}, {})
    assert isinstance(result, dict)
    time.sleep(1)

# Generated at 2022-06-11 11:45:27.000871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    action = ActionModule()
    action.wrap_async = lambda x, y, z: x

# Generated at 2022-06-11 11:45:39.666974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action

    # Declare an instance of module_new
    module_new_Module = action.ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Declare an instance of module_old
    module_old_Module = action.ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Initialize parameters
    tmp = None
    task_vars = None

    # Call method run of module_new
    result = module_new_Module.run(tmp=tmp, task_vars=task_vars)

    # Call method run of module_old

# Generated at 2022-06-11 11:45:41.265151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure we can construct an empty one
    ActionModule()

# Generated at 2022-06-11 11:45:50.802999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    unit test for ActionModule.run() using a mock object
    to test the module.  The mock object is not used in any
    of the Ansible code.  This is done to make it easier to collect
    code coverage.

    :param self: the test class
    :rtype: None
    """

    # pylint: disable=too-many-lines

    # Disabling too many lines because the number of modules is large enough
    # that this test function is legitimately too long.

    from ansible.executor.module_common import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase, ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

# Generated at 2022-06-11 11:45:51.996239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule()
    AM.run()

# Generated at 2022-06-11 11:45:52.585388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:46:02.851311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_module(module_name, module_args):
        '''
        test_module is a universal stub for AnsibleModule
        '''
        raise NotImplementedError('test_module could not be stubbed for unit test')

    class MockActionModule(ActionModule):
        '''
        MockActionModule is a mock of ActionModule
        '''

        def __init__(self, *args, **kwargs):
            super(MockActionModule, self).__init__(*args, **kwargs)
            self._test_module = test_module


# Generated at 2022-06-11 11:47:05.925954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_loader = DictDataLoader({
        '/tmp/ansible_setup_module.py': '',
        '/tmp/ansible_setup_module2.py': '',
    })
    my_vars = dict(
        ansible_env=dict(
            HOME='/',
            USER='someuser',
        ),
        ansible_facts=dict(
            network_os='myos'
        ),

    )

    my_mock_module_mgr = MockModuleManager(
        module_data={
            'ansible_setup_module': '',
            'ansible_setup_module2': '',
            'ansible.legacy.async_status': '',
        },
        module_paths=['/tmp']
    )


# Generated at 2022-06-11 11:47:09.242551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    a = ansible.plugins.action.ActionModule(None, {})


# Generated at 2022-06-11 11:47:18.530440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.system import System


    # Create instance of the class "System"
    system = System()

    # Create instance of the class "Distribution"
    distribution = Distribution()

    # Create instance of the class "Facts"
    facts = Facts(system, distribution)

    # Create instance of the class "ActionModule" with parameters of temporary directory, facts instance and connection name
    action_module = ActionModule(tmpdir='/tmp', facts=facts, connection_name='local')

    # Create a variable "task_vars"
    task_vars = {}

    # Create a variable "tmp"
    tmp = None

    # Run the method "run" of the class

# Generated at 2022-06-11 11:47:24.916835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup action module
    ActionModule._display = None
    ActionModule.runner = None

    # Setup connection
    conn_class = Connection()
    conn_class._load_name = 'network_cli'

    # Setup task
    task_class = Task()
    task_class.args = {}
    task_class.args['parallel'] = "false"
    task_class.args['network_os'] = "ios"
    task_class.args['collect_facts'] = "true"

    # Setup loader
    loader_class = AnsibleLoader()
    loader_class.module_loader = ModuleLoader()

    # Setup templar
    templar_class = Templar()

    # Setup action module class
    action_class = ActionModule()
    action_class._task = task_class
    action_class._connection = conn

# Generated at 2022-06-11 11:47:33.000173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as ploader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar

    loader = ploader.ActionModuleLoader()
    task = Task()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables={})
    action_module = ActionModule(loader=loader, task=task, connection=None, play_context=play_context, templar=templar, shared_loader_obj=None)

    data = action_module.run(tmp=None,task_vars={})

    assert data is not None

# Generated at 2022-06-11 11:47:38.027476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # In order to test properties of the class which are implemented as
    # @cached_property objects, we need to set up a dummy class with those
    # properties, so that the decorators are executed.
    class DummyActionModule(ActionModule):
        pass

    obj = DummyActionModule()
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-11 11:47:41.425824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test without parallel=True
    action_module = ActionModule()
    action_module.run()
    # Test with parallel=True
    action_module = ActionModule()
    action_module.run(parallel=True)

# Generated at 2022-06-11 11:47:42.663688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run is not a valid test method
    pass

# Generated at 2022-06-11 11:47:46.984885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an object of class ActionModule with
    # specified arguments and call run method
    tmp = None
    task_vars = None

    A = ActionModule(task=None, connection=None,
        play_context=None, loader=None,
        templar=None, shared_loader_obj=None)
    A.run(tmp, task_vars)

# Generated at 2022-06-11 11:47:56.772935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host, Group
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])

# Generated at 2022-06-11 11:49:55.450456
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.plugins.action.setup import ActionModule as SetupActionModule

    t = Task()
    t.args = {'a': 1, 'b': 2}

    ma = SetupActionModule(t)
    assert ma._task.args.get('a', None) == 1

# Generated at 2022-06-11 11:49:56.930093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {}, None)
    assert action

# Generated at 2022-06-11 11:50:00.209618
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m_action_module = ActionModule()

    # Test settings
    assert m_action_module._supports_check_mode == True

    # Test call of method run
    assert m_action_module.run() == {'ansible_facts': {}, '_ansible_verbose_override': True}

# Generated at 2022-06-11 11:50:07.095571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._shared_loader_obj = {'module_loader': 'module_loader'}
    m._task = {'args': {'k': 'v'}}
    m._templar = 'templar'
    m._task._parent = {'_play': {'_action_groups': 'action_groups'}}
    m._connection = {'_load_name': 'load_name', '_shell': {'tmpdir': 'tmpdir'}}
    m._execute_module = lambda _1, **_2: {'ansible_facts': {}}
    m.run()

# Generated at 2022-06-11 11:50:16.254959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests ActionModule.run() with no failures
    # The tests are based on the source file provided by default of
    # netconf_get_facts.py
    # The original source file is available in the following URL
    # https://github.com/ansible/ansible/blob/v2.6.18/lib/ansible/plugins/action/netconf_get_facts.py

    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()

    # Mock vars return
    task_vars = {}

    # Create a ActionModule object
    action_module = ActionModule(task, connection, play_context=play_context(task_vars), loader=None, templar=None, shared_loader_obj=None)

    # Force attributes of ActionModule object


# Generated at 2022-06-11 11:50:24.440274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    # Create a connection
    C.ANSIBLE_HOST_KEY_CHECKING = False
    src_dest_pair = {}
    templar = None
    connection = None

    # Create a task_queue_manager

# Generated at 2022-06-11 11:50:29.812513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a action module with default values
    action_module = ActionModule()

    # call method run of class ActionModule
    result = action_module.run(tmp='/tmp', task_vars={'ansible_facts': {}, 'ansible_facts_parallel': False})

    # assert the return values
    assert isinstance(result, dict)
    assert 'ansible_facts' in result
    assert '_ansible_facts_gathered' in result['ansible_facts']
    assert '_ansible_verbose_override' in result

# Generated at 2022-06-11 11:50:33.721932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get the action module object
    action_module_obj = ActionModule(None, None, None, None, None, None)
    # Check if object is instance of class ActionModule
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-11 11:50:35.088583
# Unit test for constructor of class ActionModule
def test_ActionModule():

    res = ActionModule('setup')
    assert res is not None

# Generated at 2022-06-11 11:50:35.679494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True