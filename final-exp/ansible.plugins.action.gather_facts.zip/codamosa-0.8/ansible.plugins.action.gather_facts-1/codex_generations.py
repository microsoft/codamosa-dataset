

# Generated at 2022-06-11 11:42:32.094016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_facts
    from ansible.plugins.action import ActionModule
    import ansible.plugins.loader
    args = {u'parallel': True, u'gather_subset': u'all'}

# Generated at 2022-06-11 11:42:43.665939
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import mock
    import platform
    import json

    import ansible.constants as C

    # Setup test objects
    task_vars = {'ansible_facts': {'network_os': 'ios_xr'}}
    tmp = '/tmp'
    task_path = 'setup'
    private_data_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_facts_private_facts_tmp', u'private')

    # Setup mocking for ansible.utils.vars.merge_hash
    def mock_merge_hash(a, b, list_merge='append_rp'):
        assert list_merge == 'append_rp'
        assert a == {'ansible_facts': {}, 'warnings': [], 'deprecations': []}
        assert b

# Generated at 2022-06-11 11:42:51.599703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In order to test the 'run' code of class ActionModule, we need to use a valid
    # TaskExecutor, Task and Connection. A MockTaskExecutor, MockTask and MockConnection
    # will be used. The MockTaskExecutor will be used to mimic an ActionModule
    # instance and the MockTask will mimic a Task object. The MockConnection will
    # mimic an AnsibleConnection object.

    # The first step is to create ActionModule instance, called executor and set
    # all the attributes required by the 'run' method
    executor = MockTaskExecutor()

# Generated at 2022-06-11 11:43:03.234376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_self = MagicMock()
    mock_self.run = MagicMock(return_value={
        "failed": True,
        "failed_modules": {
            "ansible.legacy.setup": {
                "changed": False,
                "failed": True,
                "invocation": {
                    "module_name": "ansible.legacy.setup"
                }
            }
        },
        "msg": "The following modules failed to execute: ansible.legacy.setup\n"
    })
    mock_self._execute_module = MagicMock(return_value={"failed": True})
    mock_self._task = MagicMock()
    mock_self._task.name = "gather_facts"
    mock_self._task.args = {"parallel": None}

# Generated at 2022-06-11 11:43:14.411640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_args = {
        'ansible_connection': 'winrm',
        'ansible_user': 'Administrator',
        'ansible_host': 'localhost',
        'ansible_port': 5985,
        'ansible_network_os': 'napalm',
    }
    test_task = MockTask(args=test_args)

    # test with skip_fact_gathering=0
    test_task_vars = {
        'ansible_facts': {},
        'ansible_skip_fact_gathering': 0,
        'ansible_facts_parallel': None,
        'ansible_verbosity': 0,
    }
    test_tmp = None

# Generated at 2022-06-11 11:43:25.547709
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    TEST_CONFIG = {
        'FACTS_MODULES': ['dummy_fact_module'],
        'CONNECTION_FACTS_MODULES': {'test_network_os': 'dummy_connection_module'}
    }

    m = ActionModule()
    m._task = mock.Mock()
    m._task.args = {}
    m._task.args['network_os'] = 'test_network_os'
    m._task._parent = mock.Mock()
    m._task._parent._play = mock.Mock()
    m._task._parent._play._action_groups = ['dummy']
    m._connection = mock.Mock()
    m._connection._load_name = 'network_cli'
    m._shared_loader_obj = mock.Mock()
    m

# Generated at 2022-06-11 11:43:36.610763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule

    class MockConfig:
        def get_config_value(self, option, variables=None):
            if option == 'FACTS_MODULES':
                return ['smart', 'ansible.legacy.setup','facter','ohai','system','ec2','network','virtualization','ohai','metal','datadog','ohai', 'ping_hosts']
            elif option == 'CONNECTION_FACTS_MODULES':
                return {
                    'network_cli': 'ansible.legacy.setup'
                }
            return True

    class MockHostVars:
        def __init__(self):
            self.vars = dict()


# Generated at 2022-06-11 11:43:46.248910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockQueue(object):
        def __init__(self):
            self.results = []

        def put(self, item, block=True, maxsize=0, timeout=None):
            self.results.append(item)

    class MockTask(object):
        def __init__(self):
            self.args = {
                'filter': None,
                'gather_timeout': None,
                'gather_subset': ['all'],
                'parallel': None
            }

        def __deepcopy__(self):
            return self


# Generated at 2022-06-11 11:43:47.324107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert True is True

# Generated at 2022-06-11 11:43:49.133934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing Test')

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:44:11.259554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a ActionModule object with ansible.legacy_setup and fact modules
    modules = [
        'ansible.legacy_setup',
        'ansible.module_utils.facts.facter',
        'ansible.module_utils.facts.hardware',
        'ansible.module_utils.facts.virtual'
    ]
    module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # get the result from running the module
    res = module_obj.run(task_vars={
        'ansible_facts_parallel': False,
        'ansible_facts_parallel_override': True,
        'ansible_facts_parallel_custom_module': False
    })

    # the

# Generated at 2022-06-11 11:44:20.093686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import yaml
    import json
    import sys

    fake_action_plugin_dir = '/tmp/ansible_action_plugins_test'
    real_action_plugin_dir = './lib/ansible/plugins/action'

    os.environ['ANSIBLE_ACTION_PLUGINS'] = fake_action_plugin_dir

    try:
        from .. import action
        from ..action import ActionModule
    except:
        from ansible.plugins import action
        from ansible.plugins.action import ActionModule

    if os.path.exists(fake_action_plugin_dir):
        if os.path.isdir(fake_action_plugin_dir):
            print("Removed the old fake_action_plugin_dir: " + fake_action_plugin_dir)

# Generated at 2022-06-11 11:44:21.418946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(dict(), dict(), {}), ActionModule)

# Generated at 2022-06-11 11:44:33.029864
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Creating a mock object for the class ActionModule and setting the options
    mock_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    mock_module._connection = MagicMock(name='_connection')
    mock_module._connection._shell = MagicMock(name='_shell')
    mock_module._connection._shell.tmpdir = MagicMock(name='tmpdir')
    mock_module._connection._load_name = MagicMock(name='_load_name')

    mock_module._task = MagicMock(name='task')
    mock_module._task.args = {'parallel': False}
    mock_module._task.module_defaults = MagicMock(name='module_defaults')

    mock_module

# Generated at 2022-06-11 11:44:43.059885
# Unit test for constructor of class ActionModule
def test_ActionModule():
        # Constructor of class ActionModule
        obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_path=None, shared_loader_obj=None, templar=None, ansible_version_info=None)
        assert obj._supports_check_mode == True

        # _get_module_args() of class ActionModule
        fact_module = 'ansible.legacy.setup'
        task_vars = {'ansible_facts': {'network_os': 'ios_xr'}}
        mod_args = {'gather_subset': None, 'filter': None, 'gather_timeout': None}

# Generated at 2022-06-11 11:44:48.949027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a mock action module
    module_obj = ActionModule(task=MagicMock(), connection=MagicMock(),
                              play_context=MagicMock(), loader=MagicMock(),
                              templar=MagicMock(), shared_loader_obj=MagicMock())
    
    # Set static module properties
    module_obj._task.args = dict()
    module_obj._task.args['parallel'] = True
    C.config.set_config_value('FACTS_MODULES', ['module1', 'module2'])
    C.config.set_config_value('CONNECTION_FACTS_MODULES', dict())
    module_obj._task._parent._play._action_groups = dict()

# Generated at 2022-06-11 11:44:50.990032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {}
    action_module._task.args = {}
    action_module.run()

# Generated at 2022-06-11 11:44:59.920093
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # DEFINE PARAMETERS

    # DEFINE VARIABLES
    tasks = []
    # ASSIGN VARIABLES

    # DEFINE PARAMETERS
    module_name = "setup"
    module_args = {
        "filter": "ansible_distribution"
    }
    # ASSIGN PARAMETERS

    # DEFINE VARIABLES
    global task_vars
    task_vars = dict(ansible_facts=dict())
    # ASSIGN VARIABLES

    # DEFINE VARIABLES
    global tmp
    tmp = "setup"
    # ASSIGN VARIABLES

    # MAKE ACTIONMODULE INSTANCE

    # ASSIGN PARAMETERS
    act = ActionModule(module_name=module_name, module_args=module_args)
   

# Generated at 2022-06-11 11:45:09.970709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection:
        def __init__(self, load_name):
            self._load_name = load_name

    class Task:
        def __init__(self, module_defaults, args):
            self.module_defaults = module_defaults
            self._parent = TaskParent()
            self.args = args

    class TaskParent:
        def __init__(self):
            self._play = TaskPlay()

    class TaskPlay:
        def __init__(self):
            self._action_groups = {'u2_test': 'ansible.module_utils.facts_v1'}


# Generated at 2022-06-11 11:45:11.217679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule
    assert module

# Generated at 2022-06-11 11:45:43.815685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target = ActionModule()
    target.set_action_args({'a':'b'})
    target.set_task_args({'a':'b'})
    target.set_task({'a':'b'})
    assert target.run({'a':'b','ansible_facts_parallel': False, '_ansible_verbose_override': True}) == {'ansible_facts': {'_ansible_facts_gathered': True},
                                                                                                     'failed': False,
                                                                                                     'msg': '',
                                                                                                     'skipped': False,
                                                                                                     '_ansible_verbose_override': True}
    target = ActionModule()
    target.set_action_args({'a':'b'})
    target.set_

# Generated at 2022-06-11 11:45:51.814786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # (1) test with data for ActionBase().run()
    #     detailed testing for ActionBase().run() is out of scope for this test

    # (2) for test_execute_module(), we are not testing its functionality
    #     (which will be tested in module_utils/module_common.test_execute_module())
    #     but we can test that it is called and returns the expected results
    #     we use 'ping' test module here (no args needed) and our own function
    #     test_execute_module() to mock module execution.
    def test_execute_module(self, module_name, module_args=None, task_vars=None, wrap_async=False):
        del self
        del task_vars
        del wrap_async
        assert module_name == 'ping'

# Generated at 2022-06-11 11:46:02.097050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    host = '127.0.0.1'
    play_context = dict(port=22, remote_user='test', connection='local')

    inventory = Inventory(host_list=['localhost'])
    variable_manager = VariableManager(inventory=inventory)

# Generated at 2022-06-11 11:46:12.922216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_facts=dict(
            network_os='ios'
        )
    )
    task = dict(
        args=dict(
            network_os='ios'
        ),
        collections=[
            dict(
                collection_name='ansible_collections.someorg.network',
                collection_version=None,
                collection_namespace='someorg.network'
            )
        ]
    )
    conn = dict(
        _shell=dict(
            tmpdir=None
        ),
        _load_name='network_cli'
    )
    mock_module_loader = None

    action = ActionModule(task, conn, tmp=None, task_vars=task_vars, tempdir=None)
    action._shared_loader_obj = mock_module_loader



# Generated at 2022-06-11 11:46:16.745444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule(task=1, connection=1, play_context=1, loader=1, templar=1, shared_loader_obj=1)
    assert test_module._supports_check_mode is True

# Generated at 2022-06-11 11:46:26.543457
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    conn_loaders = ['network_cli', 'httpapi', 'netconf']


# Generated at 2022-06-11 11:46:27.152643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:46:29.292506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    # check the value of action_module.supports_check_mode
    assert action_module._supports_check_mode



# Generated at 2022-06-11 11:46:38.022226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run() Unit Test
    """
    
    # Define test inputs
    tmp = None
    task_vars = None
    
    # Define expected results
    expected_result = {
        'ansible_facts': {
            '_ansible_facts_gathered': True
        },
        '_ansible_verbose_override': True
    }
    
    # Initialize test object
    test_obj = ActionModule(
        task = mock_task(),
        connection = mock_connection(),
        play_context = mock_play_context(),
        loader = mock_loader(),
        templar = mock_templar(),
        shared_loader_obj = mock_loader_obj()
    )
    
    # Run test

# Generated at 2022-06-11 11:46:38.907479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: Write tests
    pass

# Generated at 2022-06-11 11:47:30.388919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:47:36.468317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct arguments for function run
    tmp = None
    task_vars = dict()

    # Return value of function run
    expected_result = dict()

    # Instantiate ActionModule class
    action_module_instance = ActionModule()

    # Call function run
    actual_result = action_module_instance.run(tmp, task_vars)

    # Check if results are equal
    assert actual_result == expected_result


# Generated at 2022-06-11 11:47:38.025655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Unit test for method run of class ActionModule.
    pass

# Generated at 2022-06-11 11:47:47.505480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    # Prepare test data.
    test_task = Task()
    test_task.action = 'setup'
    test_task.args = {}
    test_task._parent = Play()
    test_task._parent._parent = PlaybookExecutor()

    test_module = ActionModule(task=test_task, connection=None, play_context=None, loader=DictDataLoader({}), templar=None, shared_loader_obj=None)

    # Tests

# Generated at 2022-06-11 11:47:57.304749
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from copy import copy
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars

    # A fake object
    class Task(object):
        def __init__(self):
            self.args = {}
            self.action = 'setup'

    # A fake object
    class Connection(object):
        def __init__(self):
            self._shell = ''

        def _load_name(self):
            return 'network_cli'

    # A fake object
    class Play(object):

        def __init__(self):
            self._action_groups = []

    # A fake object
    class PlayContext(object):
        def __init__(self):
            self.module_defaults = {}

    # A fake object

# Generated at 2022-06-11 11:47:58.506572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-11 11:48:07.844088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader, module_loader
    import ansible.constants as C

    def get_connection(connection):
        return None

    class TestPlaybookExecutor(PlaybookExecutor):
        def __init__(self, inventory, loader, options, passwords, variable_manager, stdout_callback):
            self._inventory = inventory
            self._loader = loader
            self._options = options
            self._passwords = passwords
            self._variable_manager = variable_manager
            self._stdout_callback

# Generated at 2022-06-11 11:48:17.441695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock

    mock_config = mock.MagicMock()
    mock_config.get_config_value.return_value = ['ansible.legacy.osx', 'ansible.legacy.setup']
    mock_config.get_config_value('FACTS_MODULES', variables={'network_os': 'reverse_proxy'}).return_value = ['ansible.legacy.osx', 'ansible.legacy.setup']
    mock_connection = mock.MagicMock()
    mock_connection._load_name = 'network_cli'
    mock_shared_loader_obj = mock.MagicMock()
    mock_task = mock.MagicMock()
    mock_task.args = {}
    mock_task.module_defaults = {}
    mock_task.collections = []
    mock_task._

# Generated at 2022-06-11 11:48:26.450385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a connection object
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.connection import network_cli
    from ansible.connection.network_cli import Connection
    connection = connection_loader.get('network_cli', None)
    if connection is None or not isinstance(connection, (network_cli.Connection,)):
        pytest.skip("Unable to load network_cli connection plugin")
    connection_obj = Connection(connection._load_name)

    # Create a task object
    from ansible.playbook.task import Task
    task_obj = Task()
    task_obj.action = 'setup'
    task_obj.module_defaults = None
    task_obj.module_name = None

    # Create a task_vars object
    task_vars = {}

    # Test instantiation


# Generated at 2022-06-11 11:48:34.755939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from lib.Config import Config
    from lib.Connection import Connection
    from lib.Play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager._fact_cache = {'ipv6': True, 'localipv6': True, 'ipv4': False, 'virtual': False}
    config = Config(file=None, defaults=dict())

    play_context = dict()

# Generated at 2022-06-11 11:50:56.489968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-11 11:51:05.187172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test when parallel is None and module length is one
    modules = ['os']
    task_vars = {'ansible_facts_parallel':None }
    tmp = '/tmp'
    results = {}
    results['ansible_facts'] = {}

# Generated at 2022-06-11 11:51:13.444442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    context.CLIARGS = {}
    context.CLIARGS['connection'] = 'local'
    # context.CLIARGS['module_path'] = './library'
    context.CLIARGS['forks'] = 10
    context.CLIARGS['become'] = None
    context.CLIARGS['become_method'] = None
    context.CLIARGS['become_user'] = None


# Generated at 2022-06-11 11:51:19.823010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import shared_loader_obj
    import ansible.plugins.action
    import ansible.plugins.connection.network_cli
    task = ansible.plugins.action.ActionModule(None, shared_loader_obj, None, None, None)
    task._connection = ansible.plugins.connection.network_cli.Connection(None, PlayContext(None, None, None, None, None), '/root', None, None)
    result = task.run(None, None)
    assert result == TaskResult.not_implemented()

# Generated at 2022-06-11 11:51:28.004317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        fact_dir=None,
        fact_cache=None,
        fact_cache_type=None,
        ansible_facts=dict(
            network_os=None,
        )
    )

    task = dict(
        action=dict(
            module=None,
            args=dict(
                gather_subset='all',
                gather_timeout=None,
            )
        ),
        module_defaults=dict(),
        args=dict(),
        delegate_to='127.0.0.1'
    )

    action_instance = ActionModule(
        task=task,
        connection='',
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )


# Generated at 2022-06-11 11:51:29.126933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("testing ActionModule")
    assert True

# Generated at 2022-06-11 11:51:37.730590
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_plugin = None
    fake_executor = None
    fake_shell = None

    # create mock object for action_plugin
    action_plugin = ActionModule()
    action_plugin._connection = fake_shell

    # create mock object for fake_executor
    # need to do this since we are using the executor interface to access the connection plug
    # using the get_connection method
    fake_executor = ActionModule()
    fake_executor._executor = "fake"
    fake_executor._connection = fake_shell

    # create mock object for fake_shell, then assign it to action_plugin and fake_executor
    # connection
    fake_shell = ActionModule()
    fake_shell._connection_plugin = 'fake'
    fake_shell._shell = 'fake'
    fake_shell._shell_type = 'fake'

# Generated at 2022-06-11 11:51:38.224387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:51:45.552232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule(
        task=dict(
            args=dict(
                ansible_network_os='ios',
                ansible_facts={'network_os': 'ios'}
            )
        ),
        connection='network_cli',
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # check whether object has been initialized properly
    assert action_plugin._connection == 'network_cli'
    assert action_plugin._task == dict(
        args=dict(
            ansible_network_os='ios',
            ansible_facts={'network_os': 'ios'}
        )
    )
    assert action_plugin._play_context == dict(check_mode=False)
    assert action_

# Generated at 2022-06-11 11:51:52.833867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    action_module._execute_module = lambda x: dict(failed=False, msg='test')
    action_module._remove_tmp_path = lambda x: None
    action_module._task.args = dict(test_arg='test_value')
    action_module._task._parent._play._action_groups = dict()
    action_module._display.warning = lambda x: None
    res = action_module.run(tmp=None, task_vars=dict())
    assert res['ansible_facts']['_ansible_facts_gathered'] == True