

# Generated at 2022-06-11 11:42:23.459351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule

# Generated at 2022-06-11 11:42:33.171002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible import context
    from ansible.playbook.task import Task

    task_vars = dict(
        ansible_distribution='Ubuntu',
        ansible_distribution_version='14.04',
        ansible_distribution_release='trusty',
        ansible_os_family='Debian',
        ansible_facts=dict(
            os=dict(
                distro=dict(
                    id='ubuntu',
                    version='14.04',
                    major_version='14'
                )
            )
        )
    )

    mock_connection = MagicMock()
    mock_task = Task()
    mock_task.action = 'setup'


# Generated at 2022-06-11 11:42:44.861915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test run() of ActionModule
    '''

    # Test with FactModule = Command in FACTS_MODULES
    logging.getLogger('vars').setLevel('DEBUG')
    logging.getLogger('vars').propagate = False
    logging.getLogger('vars').addHandler(logging.FileHandler('unit_test.log'))
    FACTS_MODULES = ['command']
    C.config.set_config_value('FACTS_MODULES', FACTS_MODULES)
    testclass = ActionModule(connection=None, play_context=None,
                             loader=None, templar=None, shared_loader_obj=None)
    testclass._supports_check_mode = True
    tmp = None
    task_vars = None
    result = testclass

# Generated at 2022-06-11 11:42:45.550202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    abc = ActionModule()
    assert abc

# Generated at 2022-06-11 11:42:55.859669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run, checking if it returns the same results as Ansible's
    ``setup`` action plugin
    """

    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # Create Play
    play = Play().load({
        "name": "Ansible Play",
        "hosts": ["localhost"],
        "tasks": [{
            "name": "Ansible Task",
            "action": "setup",
            "local_action": "setup"
        }]
    }, DataLoader(), tmp_path="/tmp/test_ansible")

    # Create Task
    task = play.get_task("Ansible Task")

   

# Generated at 2022-06-11 11:43:07.392321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    args['verbosity'] = 3
    args['module_defaults'] = dict()
    args['module_defaults']['param1'] = 1
    args['module_defaults']['param2'] = 2
    args['module_defaults']['param3'] = 3
    args['module_defaults']['param4'] = 4
    args['module_defaults']['param5'] = 5
    args['module_defaults']['param6'] = 6

    task_vars = dict()
    task_vars['network_os'] = 'cisco_ios'
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['network_os'] = 'cisco_ios'

# Generated at 2022-06-11 11:43:16.834238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ans = ActionModule()
    ans._supports_check_mode = True
    ans._task = mock_task
    ans._tmp = '/tmp'
    ans._templar = mock_templar
    ans._execute_module = mock_execute_module
    ans._shared_loader_obj = mock_shared_loader_obj
    ans._display = mock_display
    res = ans.run(tmp=None, task_vars=mock_task_vars)
    assert len(res) == 5
    assert res.get('ansible_facts', None) == {}
    assert res.get('warnings', None) == []
    assert res.get('deprecations', None) == []
    assert res.get('ansible_facts', None) == {}

# Generated at 2022-06-11 11:43:17.479732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:43:20.175959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None)
    am.run()

if __name__ == '__main__':
    import pytest
    pytest.main("-v")

# Generated at 2022-06-11 11:43:21.733558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_result = ActionModule.run()
    assert run_result is None

# Generated at 2022-06-11 11:43:41.202642
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader

    # Dummy configuration
    task_args = {}
    task_args['name'] = 'Setup'
    task_args['action'] = 'setup'
    task_args['local_action'] = 'setup'
    task_args['version'] = 2
    task_args['args'] = {}

    # Create setup module

# Generated at 2022-06-11 11:43:51.505088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock as mock
    from ansible.plugins.action.setup import ActionModule as setup
    from ansible.executor import task_result
    
    am = setup(mock.sentinel._task, mock.sentinel._connection, mock.sentinel._play_context, mock.sentinel._loader, mock.sentinel._templar,
        mock.sentinel._shared_loader_obj)
    am._display = mock.Mock()
    am._execute_module = mock.Mock(return_value=dict(ansible_facts=dict(a=1)))
    am._remove_tmp_path = mock.Mock()
    
    # Case: use default parallel=True (len(modules) >= 1)
    task_vars = dict(ansible_facts_parallel=None)
    result = am

# Generated at 2022-06-11 11:43:52.920182
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Unit test for constructor of class ActionModule
    arg = ActionModule()

# Generated at 2022-06-11 11:44:05.489100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    resources_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'resources/')

    # test1
    task_vars = {"var1": "value1"}
    tmp = None
    action = ActionModule()
    action._task = {"action": {"__ansible_module__": "test_module"}, "args": {"test_arg1": "test_arg1_val", "test_arg2": "test_arg2_val"}}
    action._task._parent = {"_role": {"_role_path": resources_path}, "_task": {"action": {"__ansible_module__": "test_module"}, "args": {"test_arg3": "test_arg3_val", "test_arg4": "test_arg4_val"}}}

# Generated at 2022-06-11 11:44:16.095856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.network.common import get_default_subset

    task_vars = dict(
        ansible_facts=[],
        ansible_facts_parallel=None,
        ansible_network_os=None,
        ansible_facts_gathered_subset='all',
        connection_gather_subset=None,
        ansible_default_ipv4=dict(address='1.1.1.1'),
        ansible_devices=dict(mock_device=dict(interfaces=dict(Ethernet1=dict(macaddress='00:10:22:33:44:55', description='test_desc')))),
        ansible_net_hostname='hostname'
    )
    action_module = ActionModule()

# Generated at 2022-06-11 11:44:16.649251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:17.155315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:20.373168
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-11 11:44:20.983626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 11:44:21.918270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a

# Generated at 2022-06-11 11:44:50.190930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test running ActionModule.run")
    ActionModule.C._action_plugins = None
    ActionModule.setup_cache()

    # Setting up arguments for run method
    # Setting up task_vars for run method
    task_vars = {}

    # Setting up result for run method
    result = {}
    result['ansible_facts'] = {}
    result['ansible_facts']['_ansible_facts_gathered'] = True
    result['_ansible_verbose_override'] = True
    # result = {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}

    # Testing ActionModule.run()
    aModule = ActionModule()

    # Passing arguments to ActionModule.run method

# Generated at 2022-06-11 11:44:52.225918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-11 11:44:53.655193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 11:45:02.936175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.model import ModelError

    import json

    class TestWorkerProcess(WorkerProcess):
        def _load_included_file(self, include_file):
            return Task()


# Generated at 2022-06-11 11:45:13.637352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a temp file to use as stdin for the module.
    (stdin_fd, stdin_path) = tempfile.mkstemp()
    with open(stdin_path, 'w') as stdin_file:
        stdin_file.write('{"ANSIBLE_MODULE_ARGS": {}, "ANSIBLE_MODULE_CONSTANTS": {}}')
    os.close(stdin_fd)

    action = ActionModule(stdin_path, 'fake_path', 'fake_loader', 'fake_templar')

    assert isinstance(action, ActionBase)
    assert isinstance(action._task, Task)
    assert isinstance(action._shared_loader_obj, DataLoader)
    assert isinstance(action._connection, Connection)
    assert isinstance(action._play_context, PlayContext)


# Generated at 2022-06-11 11:45:23.328973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """this is a test of the ActionModule class run() method"""

    # setup parameters for test
    # a bit more complex than usual to ensure everything is set
    module_utils = 'module_utils'
    connection = MockConnection()
    templar = 'templar'
    loader = MockLoader()
    display = MockDisplay()
    task = MockTask(module_defaults='module_defaults', action_groups='action_groups')
    shared_loader_obj = MockAnsibleModule()
    shared_loader_obj.module_loader = loader
    action = ActionModule(task=task, connection=connection, templar=templar, loader=loader, display=display)
    action._shared_loader_obj = shared_loader_obj

    # set parameters needed by run()
    action.module_args = {}

# Generated at 2022-06-11 11:45:29.537608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext

    pm = ActionModule(
        task=dict(action='setup'),
        play_context=PlayContext(),
        new_stdin=None,
    )
    assert isinstance(pm, ActionModule)
    assert isinstance(pm._connection, TaskQueueManager)

# Generated at 2022-06-11 11:45:41.416107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-11 11:45:50.890730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: This is a simple test and is by no means a complete unit test.
    # It is designed to test whether the method run will return the correct
    # value under the specified conditions.
    # 1) Load a basic module and fact module into _shared_loader_obj.module_loader.
    # 2) Create a task which defines a list of fact modules to run.
    # 3) Create an action module from this task.
    # 4) Call action module.run method and verify it returns 'ansible_facts' as expected.

    # 1)
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import module_loader

    class MockModuleUtilPluginClass:
        def get_config(self, varname, variables):
            if varname == 'ACTION_LOOKUP':
                return dict()


# Generated at 2022-06-11 11:46:01.471897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a module
    module = ActionModule()

    # create a mock task
    task = {}
    task['action'] = 'setup'
    task['async'] = 0
    task['args'] = {}
    task['args']['pipeline'] = 0
    task['args']['parallel'] = 0
    task['version_added'] = ''
    task['collections'] = []
    task['vars'] = {}
    task['vars']['ansible_python_interpreter'] = '/usr/bin/python'
    task['vars']['ansible_connection'] = 'local'
    task['_ansible_no_log'] = 0
    task['delegate_to'] = ''
    task['item'] = None
    task['retries'] = 3
    task['delay']

# Generated at 2022-06-11 11:47:01.597011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # creating a mock task object
    mock_task = dict(name='mock_task', args={'arg1':'foo'})
    # creating mock connection object
    mock_connection = dict(name='mock_connection', _load_name='network_cli')
    # making a mock action object
    mock_action = dict()

    actionmod_obj = ActionModule(mock_task, mock_connection, mock_action)
    assert not actionmod_obj._task
    assert not actionmod_obj._supports_multiple_return

# Generated at 2022-06-11 11:47:13.403852
# Unit test for constructor of class ActionModule
def test_ActionModule():
	from ansible.plugins.loader import plugins
	from ansible.playbook.play_context import PlayContext
	from ansible.executor.task_queue_manager import TaskQueueManager
	from ansible.executor.process.worker import WorkerProcess
	from ansible.executor.playbook.play import Play
	from ansible.executor.playbook.task import Task
	from ansible.plugins.connection.local import Connection

	class Task:
		def __init__(self, args):
			self.args = args

	class Connection:
		def __init__(self):
			self._load_name = 'local'


# Generated at 2022-06-11 11:47:14.387400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-11 11:47:22.500256
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
   
    class MockConnection:
        def __init__(self,name):
            self._load_name = name

    class MockSharedLoaderObj:
        def __init__(self,modules):
            self.module_loader = modules

    class MockModuleLoader:
        def __init__(self,module):
            self.find_plugin_with_context = module

    class MockModule:
        def __init__(self):
            self.resolved_fqcn = "an module"

    class MockTask:
        def __init__(self,args,kargs):
            self.args = args
            self._task_vars_cache = kargs
            self.collections = ["tasks"]
            
    class MockTemplar:
        def __init__(self):
            self.template = "template"

   

# Generated at 2022-06-11 11:47:31.676685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    To check for getting the all facts for localhost
    '''
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system import platform
    from ansible.module_utils.facts.system.virtual import VirtualFactCollector

    from ansible.plugins.action import ActionModule
    from ansible.vars.manager import VariableManager

    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 11:47:32.660340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()



# Generated at 2022-06-11 11:47:43.281621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake class to hold fake variables,
    # since this module doesn't have anything to be tested
    class FakeVars:
        # the following variables are initialized with the ones in the
        # module (without the _ansible prefix)
        ansible_facts = {}
        ansible_facts_parallel = None
        ansible_verbose_override = True

    class FakeTask:
        module_defaults = None
        args = {}
        _parent = None
        _play = None
        _action_groups = None

    class FakeParent:
        def __init__(self):
            self._play = FakePlay()

    class FakePlay:
        def __init__(self):
            self._action_groups = {}

    # initialize the fake task and variables
    task_vars = FakeVars()
    task = Fake

# Generated at 2022-06-11 11:47:52.897734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import types
    import tempfile

    fd, path = tempfile.mkstemp(dir='/tmp')
    os.write(fd, "")
    os.close(fd)
    module = types.ModuleType("ansible.plugins.action.setup")
    module.ActionModule = ActionModule
    sys.modules["ansible.plugins.action.setup"] = module
    fp, pathname, description = imp.find_module("setup", [os.path.dirname(path)])
    test1 = imp.load_module("setup", fp, pathname, description)
    myobj = test1.ActionModule(None, None, None, None, None, None)
    os.remove(path)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:47:53.813666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = None
    assert a == None

# Generated at 2022-06-11 11:47:55.949976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-11 11:50:00.467294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    # Create an instance of class ActionModule
    action_module_inst = ActionModule(None, None, None, None)

    # Create a mock parameters list
    mock_tmp = None
    mock_task_vars = None

    # Call method run of ActionModule
    action_module_inst.run(mock_tmp, mock_task_vars)

# Generated at 2022-06-11 11:50:09.703907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.basic
    import ansible.plugins.action.setup
    import ansible.template
    import ansible.vars.manager
    import ansible.vars.hostvars.localhost


# Generated at 2022-06-11 11:50:10.859467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert am

# Generated at 2022-06-11 11:50:19.732171
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module_obj = 'an_object'

    # ansible.plugins.action.setup:ActionModule
    # class ActionModule(ActionBase):
    # def run(self, tmp=None, task_vars=None):

    # ansible.plugins.action.Setup:ActionModule
    import ansible.plugins.action.setup as setup
    # class ActionModule(ActionBase):
    # def run(self, tmp=None, task_vars=None):

    # prepare test data

    # prepare class instance
    action_module = setup.ActionModule(module_obj, {})

    # arguments for method run
    # tmp=None
    # task_vars=None

    # prepare test data
    # ansible.plugins.action.setup:FACTS_MODULES
    # list of modules to run and merge results into ansible

# Generated at 2022-06-11 11:50:20.677988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-11 11:50:28.403175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance = ActionModule()

    # Check no facts modules
    module_list = []
    instance.run(task_vars=dict(ansible_facts_parallel=None, config=dict(FACTS_MODULES=module_list)))

    # Check with facts modules in parallel mode
    module_list = ['Setup', 'Facts']
    instance.run(task_vars=dict(ansible_facts_parallel=True, config=dict(FACTS_MODULES=module_list)))

    # Check with facts module in non-parallel mode
    module_list = ['Setup']
    instance.run(task_vars=dict(ansible_facts_parallel=False, config=dict(FACTS_MODULES=module_list)))

    # Check with facts module in parallel mode

# Generated at 2022-06-11 11:50:37.844746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_vars = dict()
    host_vars['ansible_connection'] = 'local'
    host = Host(name='ansible-test', port=0, variables=host_vars)
    loader = DictDataLoader({
        'hosts': 'localhost',
        'vars': {
            'ansible_connection': 'local',
        }
    })
    inventory = Inventory(loader, host_list=[host])
    task = Task(action=dict(), name='ansible-test', loop=None)
    task_vars = dict()
    action_plugin = ActionModule(task=task, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:50:45.304383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """testing run method"""
    # _supports_check_mode = True
    # modules = list(C.config.get_config_value('FACTS_MODULES', variables=task_vars))

    # parallel = task_vars.pop('ansible_facts_parallel', self._task.args.pop('parallel', None))
    # if 'smart' in modules:
    #     connection_map = C.config.get_config_value('CONNECTION_FACTS_MODULES', variables=task_vars)
    #     network_os = self._task.args.get('network_os', task_vars.get('ansible_network_os', task_vars.get('ansible_facts', {}).get('network_os')))
    #     modules.extend([connection_map.get

# Generated at 2022-06-11 11:50:52.939277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with multiple modules
    set_module_args(dict(
        gather_subset='all',
        gather_timeout=10,
        filter='ansible_os_family'
    ))
    set_connection_args()
    def mocked_execute_module(module_name, module_args, task_vars):
        assert module_name.startswith('ansible.legacy')
        assert module_args['gather_subset'] == 'all'
        assert module_args['gather_timeout'] == 10
        assert module_args['filter'] == 'ansible_os_family'

# Generated at 2022-06-11 11:50:55.679017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_name=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return module