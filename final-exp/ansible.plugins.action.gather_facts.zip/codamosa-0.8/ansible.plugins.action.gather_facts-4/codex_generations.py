

# Generated at 2022-06-11 11:42:23.900528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:25.794325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am



# Generated at 2022-06-11 11:42:26.409663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:28.390990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run(ActionModule, tmp=None, task_vars=None) is not None


# Generated at 2022-06-11 11:42:29.970501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # TODO
        pass
    except TypeError as e:
        assert False

# Generated at 2022-06-11 11:42:36.248600
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    try:
        # testing with parallel = smart
        action_module.run(task_vars={'ansible_facts_parallel':'smart','ansible_module_defaults':{'gather_timeout':3,'gather_subset':'all'},'setup_cache':{'fact_list':[]},'ansible_facts':{'network_os':'ios'}}, tmp='/tmp/test_action_plugin/')
    except Exception as e:
        assert False

# Generated at 2022-06-11 11:42:47.280309
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import PlaybookExecutor


    class MockPluginLoader():
        def __init__(self):
            return

    class MockConnection():
        def __init__(self):
            return

    class MockSharedLoaderObj():
        def __init__(self):
            self.plugin_loader = MockPluginLoader()
            return

    class MockTask():
        def __init__(self):
            self._parent = PlayIterator([])
            self._parent._play = PlaybookExecutor([])
            self._parent._play._play_context

# Generated at 2022-06-11 11:42:58.439039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 11:42:59.104173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:43:10.843838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    tmp = None
    task_vars = {}

    # case 1
    result = {
        'ansible_facts': {},
        'changed': True,
        'failed': False,
        'msg': '',
        'skipped': False,
    }

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._supports_check_mode = True
    action._templar._available_variables = {}
    action._connection._new_stdin = False
    action._connection._shell = None
    action._task = None
    action._task.args = {}
    action._task.action = 'setup'

    #

# Generated at 2022-06-11 11:43:34.547195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task_vars = {'ansible_network_os': 'ios'}

  # Test method run with a different fact module (network_cli)
  action_module = ActionModule(play_context=None, new_stdin=None)
  action_module._connection = MockConnection()
  action_module._shared_loader_obj = MockSharedLoaderObj()
  action_module._task = MockTask()
  action_module._templar = MockTemplar()
  action_module._task._parent = MockPlay()
  action_module._task._parent._play = MockPlay()
  action_module._task._parent._play._action_groups = {}

  modules = list(C.config.get_config_value('FACTS_MODULES', variables=task_vars))
  connection_map = C.config.get

# Generated at 2022-06-11 11:43:43.387910
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:43:50.454948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = MockHost('/home/ansible', 'ubuntu')
    task = MockTask('test_playbook', 'test_task')
    connection = MockConnection(host)
    print('Testing ActionModule object')
    try:
        action = ActionModule(connection, task, C.DEFAULT_LOADER, C.DEFAULT_TEMPLATE)
    except Exception as e:
        print('Failed to create an ActionModule object: %s' % e)
        exit(1)
    else:
        print('ActionModule object created successfully')


# Generated at 2022-06-11 11:43:51.784911
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ActionModule.run(ActionModule, tmp=None, task_vars=None)

# Generated at 2022-06-11 11:44:04.148224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    inventory_hosts = [
        "test_host"
    ]

    inventory_path = "test/inventory"


# Generated at 2022-06-11 11:44:15.053896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play
    import ansible.playbook.task

    # Create a play to initialize the task
    play_context = ansible.playbook.play.Play()

    # Create a task for setup module
    task = ansible.playbook.task.Task()
    task._role = None
    task.action = 'setup'
    task.args = {}
    task.set_loader(None)

    # Parameters for ActionBase class
    task_vars = dict()
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None

    # Create a new object of setup class
    setup_obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert setup_obj is not None

# Generated at 2022-06-11 11:44:21.873873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock data

    # Create a mock task and context
    mock_task = mock.create_autospec(Task())
    mock_task._connection._play_context = mock.create_autospec(PlayContext())
    mock_task._shared_loader_obj = mock.create_autospec(SharedPluginLoaderObj())
    mock_task._shared_loader_obj._module_loader = mock.create_autospec(PluginLoader())

    # Create a mock task and context
    mock_task_vars = {
        'ansible_loop_var': None,
        'ansible_facts': {
            'network_os': None
        }
    }

    # Create mocks for Ansible plugins
    mock_action_base = mock.create_autospec(ActionBase())

# Generated at 2022-06-11 11:44:25.600386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_instance = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module_instance is not None


# Generated at 2022-06-11 11:44:37.351308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources=["localhost"])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader

# Generated at 2022-06-11 11:44:38.581053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = Ansi

# Generated at 2022-06-11 11:45:15.289417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake Connection class for testing
    class FakeConnection(object):
        def __init__(self):
            self._load_name = 'network_cli'

    # Create a ActionModule object for testing
    class FakeActionModule(ActionModule):
        def __init__(self):
            self._task = None
            self._connection = FakeConnection()
            self._display = None

        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            self._execute_module_flag = [module_name, module_args, task_vars, wrap_async]
            check_wrap = module_name == 'ansible.legacy.setup' and wrap_async is False

# Generated at 2022-06-11 11:45:17.852643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for build_loader
    assert ActionModule.build_loader is not None
    # test for action_loader
    assert ActionModule.action_loader is not None

# Generated at 2022-06-11 11:45:18.602390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-11 11:45:19.232112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:45:19.888283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:45:28.165657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the class
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    action_module._connection._shell = dict()
    action_module._templar = dict()

    # mock return values
    action_module._execute_module = lambda *args, **kwargs: dict(
        ansible_facts=dict(
            _ansible_facts_gathered=dict(),
            output=dict()
        ),
        warnings=dict(),
        deprecations=dict()
    )

    # run the method under test
    result = action_module.run(
        tmp=dict(),
        task_vars=dict()
    )

    # test

# Generated at 2022-06-11 11:45:29.785146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:45:36.591888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    obj = ActionModule()

    # configuration for run
    args = None
    tmp = None
    task_vars = None

    # execution of run
    result = obj.run(tmp=tmp, task_vars=task_vars)

    # assertions
    assert result['ansible_facts'] is not None
    assert result['ansible_facts'] == {}

# Generated at 2022-06-11 11:45:39.623238
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actions = ActionModule(None, dict())

    # Test with a non-existing file
    actions._execute_module(module_name="file", module_args="path=/no/existing/file", task_vars={})

# Generated at 2022-06-11 11:45:41.186838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test ActionModule success')
    assert True


# Generated at 2022-06-11 11:46:41.062108
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class Mock(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    module_utils = Mock(
        _templar=Mock(),
        _shared_loader_obj=Mock(
            module_loader=Mock(
                find_plugin_with_context=Mock(
                    resolved_fqcn='resolved fqcn'
                )
            )
        )
    )

    action_base = Mock(
        _supports_check_mode=True,
        _task=Mock(
            args={'parallel': None},
            _parent=Mock(
                _play=Mock(
                    _action_groups=True
                )
            )
        )
    )


# Generated at 2022-06-11 11:46:42.281369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass


# Generated at 2022-06-11 11:46:42.812072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:46:45.303313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._connection is not None
    assert action._templar is not None
    assert action._shared_loader_obj is not None
    assert action._display is not None

# Generated at 2022-06-11 11:46:53.657477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method `run` of class ActionModule
    """

    # Create a mock of class `ActionBase`
    class MockActionBase(ActionBase):

        def run(self, tmp=None, task_vars=None):
            return {
                'ansible_facts': {},
                '_ansible_verbose_override': True
            }

    action_base = MockActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class `Config`

# Generated at 2022-06-11 11:47:01.980514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayBookPlay
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import PluginLoader
    from ansible.utils.vars import combine_vars

    loader = PluginLoader('action', 'C.action_loader', C, 'ansible.plugins.action')


# Generated at 2022-06-11 11:47:03.529304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action._supports_check_mode is True

# Generated at 2022-06-11 11:47:15.515911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action_plugin
    from ansible.plugins.action.setup import ActionModule as setup_module

    mock_tmp_path = '/var/tmp/ansible-test-module-async-setup'
    mock_task_vars = {
        'ansible_check_mode': False,
        'ansible_diff_mode': False,
        'playbook_dir': '/var/tmp/ansible/playbook'
    }


# Generated at 2022-06-11 11:47:23.265683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with failures in multiple modules
    def _execute_module(module_name, module_args, task_vars, wrap_async):
        result = {
            'failed': False,
            'skipped': False,
            'ansible_facts': {},
        }
        if module_name in ['module_1', 'module_2']:
            result['failed'] = True
            result['msg'] = 'failed to execute'
        elif module_name in ['module_3', 'module_4']:
            result['skipped'] = True
            result['msg'] = 'failed to execute'
        return result

    tmp = None
    task_vars = {}


# Generated at 2022-06-11 11:47:32.015261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible import context
    from ansible.playbook.play_context import PlayContext

    test_action_module = ActionModule(
        TaskExecutor(PlayContext()), dict(name='setup', task='setup'))
    test_action_module.setup_task_vars()

    assert test_action_module.legacy_gather_subset == ["all"]

    # Modify gather subset list
    test_action_module.legacy_gather_subset.append("network")

    # set action_plugin to test setup
    context.CLIARGS['action_plugins'] = ['./test/unit/plugins/action']
    test_action_module.setup()

# Generated at 2022-06-11 11:49:35.407069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.supports_check_mode = True

    # without tmp, without check_mode, without parallel
    module_name = 'test_module_name'
    module_args = {'test_key': 'test_value'}
    task_vars = {'test_task_vars_key': 'test_task_vars_value'}
    am.run(None, task_vars)
    assert am.run(None, task_vars)['ansible_facts']['_ansible_facts_gathered'] == True

    # with tmp, with check_mode, with parallel
    am.supports_check_mode = False
    module_name = 'test_module_name'
    module_args = {'test_key': 'test_value'}
    task_vars

# Generated at 2022-06-11 11:49:36.231108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:49:38.147029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    # Test function is not implemented:
    # with pytest.raises(NotImplementedError):
    #     m.run()

# Generated at 2022-06-11 11:49:46.372255
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:49:51.816336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args={}),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module._supports_check_mode == True
    assert module._connection is not None
    assert module._task is not None
    assert module._loader is not None
    assert module._templar is not None
    assert module._shared_loader_obj is not None

# Generated at 2022-06-11 11:49:52.332655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:49:53.524873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None



# Generated at 2022-06-11 11:50:02.199113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.environ['ANSIBLE_CONFIG'] = './ansible.cfg'
    task_vars = {'ansible_network_os': 'eos'}
    action = ActionModule(action='', task=None, connection='ssh', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Setup certain module's config.
    # This is a hack to get around the fact that the config is loaded in the constructor and not passed in directly
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader

# Generated at 2022-06-11 11:50:11.564669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fact_module_name = 'ansible.legacy.setup'
    connection_name = 'network_cli'
    task_vars = {'ansible_facts_parallel': True}
    task_args = {}
    task_action = 'setup'
    tmp = 'tmp'
    task_add_file = '/test/test.py'
    task_add_file = '/test/test.py'
    action_base = ActionBase(fact_module_name, connection_name, task_vars, task_args, task_add_file, task_action, tmp)
    action_module = ActionModule(fact_module_name, connection_name, task_vars, task_args, task_add_file, task_action, tmp)
    assert action_module._task is action_base._task

# Generated at 2022-06-11 11:50:13.807289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None)
    assert isinstance(action, ActionModule)