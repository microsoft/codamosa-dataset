

# Generated at 2022-06-11 11:42:26.888872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    # Unit test for method run of class ActionModule
    class ActionModule_run_TestCase(unittest.TestCase):
        def setUp(self):
            pass

        # Placeholder
        def test_placeholder(self):
            pass

    unittest.main()

# Generated at 2022-06-11 11:42:33.838213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing instane of class ActionModule
    actionModule_obj = ActionModule()

    # Initializing variables for Unit test
    tmp = None
    task_vars = None

    # Calling run method of class ActionModule
    res = actionModule_obj.run(tmp, task_vars)
    assert res
    assert not res.get('failed', False)
    assert res.get('ansible_facts', {})
    assert res.get('ansible_facts', {}).get('_ansible_facts_gathered', False)
    assert res.get('_ansible_verbose_override', False)

# Generated at 2022-06-11 11:42:35.718190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    facts_module = ActionModule()
    assert facts_module is not None

# Generated at 2022-06-11 11:42:40.485805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module._supports_check_mode, bool)

# Generated at 2022-06-11 11:42:46.957214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    MOCK_MODULE_PATH = 'ansible.builtin.setup'
    MOCK_TASK_VARS = dict(ansible_facts=dict(default_ipv4='fake_ipv4', default_ipv6='fake_ipv6', ansible_all_ipv4_addresses=['fake_ipv4_1', 'fake_ipv4_2']))
    MOCK_MODULE_ARGS = dict()
    MOCK_MODULE_ARGS['filter'] = 'ansible_default_ipv4'
    MOCK_CONHOST_VARS = dict()

# Generated at 2022-06-11 11:42:49.736541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(load_name="ansible.legacy.setup", task=None, connection="local",
                       play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert obj is not None

# Generated at 2022-06-11 11:43:01.296966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.executor.task_executor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.process.connection import ConnectionProcess
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    display = Display()

# Generated at 2022-06-11 11:43:02.031592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass #TODO

# Generated at 2022-06-11 11:43:13.482004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from ansible.plugins.strategy import StrategyBase

    class AnsibleHost(object):
        def __init__(self):
            self.name = 'ansiblehost'
            self.connection_options = {'connection': 'smart'}

    class Strategy(StrategyBase):
        def __init__(self):
            pass

        def get_hosts_left(self):
            return [AnsibleHost()]


# Generated at 2022-06-11 11:43:15.168997
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # assert NoneType == None
    assert ActionModule.run('self', 'tmp', 'task_vars') is None

# Generated at 2022-06-11 11:43:32.191426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run
    """

    from ansible.plugins.action import ActionBase

    # create class object
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # invoke method
    obj.run()



# Generated at 2022-06-11 11:43:39.148494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all'],
                gather_timeout=None,
                filter=None
            )
        ),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['gather_subset'] == ['all']
    assert action_module._task.args['gather_timeout'] is None
    assert action_module._task.args['filter'] is None

# Generated at 2022-06-11 11:43:40.298592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(object, 'test', {}, 'test') is not None

# Generated at 2022-06-11 11:43:50.501626
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock os.path.exists
    def mock_path_exists(file_path):
        return True

    # Mock get_config_value
    def mock_get_config_value(name, variables):
        if name == 'CONNECTION_FACTS_MODULES':
            return {'localhost': 'ansible.legacy.setup'}

        return None

    # Mock find_plugin_with_context
    def mock_find_plugin_with_context(name, collection_list):
        class MockPluginProxy(object):
            def __init__(self, name):
                self.resolved_fqcn = name

            @property
            def object(self):
                return self

        return MockPluginProxy(name)

    # Mock boolean
    def mock_boolean(arg):
        return True

    # Mock

# Generated at 2022-06-11 11:43:51.456640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:43:55.054024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: This is intended only as an example of how a unit test might
    #       be written but is currently not executable as is.
    #       Please see AnsibleModule unit tests for more complete examples.
    assert False



# Generated at 2022-06-11 11:44:07.094268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with custom results
    test_mod_res = {
        'warnings': ['warning1', 'warning2'],
        'deprecations': ['deprecated1', 'deprecated2', 'deprecated3'],
        'ansible_facts': {
            'ansible_os_family': 'RedHat',
        },
    }
    test_task_res = {
        'warnings': ['warning3', 'warning4'],
        'deprecations': ['deprecated4', 'deprecated5'],
        'ansible_facts': {
            'ansible_os_family': 'Debian',
            'ansible_distribution': 'Centos',
        }
    }

    # test without custom results

# Generated at 2022-06-11 11:44:17.347839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """This is a unit test for the module ActionModule with the function run.
    """
    tmp = 'tmp'
    task_vars = {'ansible_facts_parallel': True}
    action_module = ActionModule('setup', {'filter': None, 'module_defaults': {}, 'module_defaults_args': []})
    res = action_module.run(tmp, task_vars)
    assert res['ansible_facts']['_ansible_facts_gathered'] == True
    assert res['_ansible_verbose_override'] == True

    # An error case
    task_vars = {'ansible_facts_parallel': True}
    action_module = ActionModule('setup', {'filter': None, 'module_defaults': {}, 'module_defaults_args': []})


# Generated at 2022-06-11 11:44:19.300696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    print(action_module.__str__())
    assert action_module.__str__() is not None

test_ActionModule()

# Generated at 2022-06-11 11:44:30.404859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    module = ActionModule()
    module._templar = None
    module._shared_loader_obj = None
    module._task = None
    module._display = None
    module._connection = None
    module._shared_loader_obj = None
    module._supports_check_mode = None
    module._supports_async = None
    module._execute_module = None
    module._remove_tmp_path = None
    module.action = None
    module.action_copy = None
    module.action_wrapper = None
    module.action_write_locks = None
    module.action_write_temps = None
    module.display = None
    module.noop_conditional = None
    module.notify_handler = None
    module.push_basedir = None
    module.set_action

# Generated at 2022-06-11 11:45:01.615610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    tmpdir_dir = 'tmpdir_dir'
    tmpdir_dir_path = 'tmpdir_dir_path'
    fact_module_setup = 'ansible.legacy.setup'
    parallel = True
    module_args = {
        "filter": "*interface",
        "gather_subset": "all"
    }

    # mock of 'ansible.legacy.setup'
    mock_module = 'ansible.legacy.setup'
    mock_module_args = {
        "filter": "*interface",
        "gather_subset": "all"
    }
    mock_module_res = {}
    mock_module_res['ansible_facts'] = {'name': 'test'}

    # create the class object using dummy parameters


# Generated at 2022-06-11 11:45:12.188030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 11:45:22.093777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.connection.smart import Connection
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-11 11:45:33.793979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        def __init__(self):
            self.args = dict()
            self.action = 'setup'
            self.cost = 0

    class MockPlay(object):
        def __init__(self):
            self.action_groups = ['gather_facts']

        def set_action_groups(self, action_groups):
            self.action_groups = action_groups

    class MockPlayContext(object):
        def __init__(self):
            self.play = MockPlay()

    class MockInventoryPlugin(object):
        def get_hosts(self):
            return ['host1']

    class MockLoader(object):
        def __init__(self):
            self.module_loader = Mock()
            self.template_loader = Mock()


# Generated at 2022-06-11 11:45:38.078994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = "localhost"
    port = 22
    user = "root"
    passwd = "root"

    connection = Connection(host, user, port, passwd)
    tpath = "/home/vagrant"

    source = "/tmp/foo"
    destination = "/tmp/bar"
    mode = str(511)

    module_name = "copy"

    module_args = {
        "src": source,
        "dest": destination,
        "mode": mode,
    }

    task_vars = {
        "ansible_ssh_user": user,
        "ansible_ssh_port": port,
        "ansible_ssh_pass": passwd,
        "ansible_ssh_host": host,
    }

    am = ActionModule(module_name, module_args, task_vars)


# Generated at 2022-06-11 11:45:48.677423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.utils.task_docs
    import ansible.plugins.action.setup
    import ansible.module_utils.facts.system.network
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.plugins.action.setup import ActionModule
    from ansible.template import Templar
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    class DataLoader():
        class path_dwim():
            basedir = os

# Generated at 2022-06-11 11:45:59.508782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Construct an instance of the class being tested.
    # Mock up the inner classes.
    class MockExecutorModuleCommon():
        def get_action_args_with_defaults(self, resolved_fact_module, mod_args, module_defaults, templar, action_groups):
            return ''

    class MockDisplay():
        def warning(self, warning):
            return ''

        def vvvv(self, vvvv):
            return ''

    class MockExecutor():
        def _executor__get_module_args(self, fact_module, task_vars):
            return ''

        def _executor__combine_task_result(self, result, task_result):
            return ''


# Generated at 2022-06-11 11:46:10.272068
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Prepare test
    _config = {'config': C, 'FACTS_MODULES': ['setup'], 'CONNECTION_FACTS_MODULES': {'ansible.legacy.setup': 'ansible.legacy.setup'}}
    _task = {'args': {}, 'module_defaults': {}, 'collections': [], '_play': {'_action_groups': {}}, 'action': 'setup'}
    _executor = {'_task': _task}
    _task_vars = {'ansible_facts_parallel': None}
    _loader = {'_shared_loader_obj': {'module_loader': {'find_plugin_with_context': lambda _: {'resolved_fqcn': 'ansible.legacy.setup'}}}}

# Generated at 2022-06-11 11:46:11.379894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule, "Failed to instantiate ActionModule"

# Generated at 2022-06-11 11:46:21.031142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test run() method of ActionModule. Accepts two scenarios
    """

    # 1st scenario - ansible_facts_parallel was not defined, modules = ['setup']
    # Result: The 1st module will run async
    tmp = None
    task_vars = {'ansible_network_os': 'eos'}
    tc_module_names = ['test1']
    host_vars = {}
    result_dict = {}
    result = {'ansible_facts': {}}
    host_vars['ansible_facts'] = result_dict

    mocker = Mocker()

# Generated at 2022-06-11 11:47:14.732356
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #Unit test for #1
    pass

# Generated at 2022-06-11 11:47:17.706667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(ansible_facts = dict(test='test'))
    action_module = ActionModule(None, dict(parallel=False), None, None, None)
    action_module.run(task_vars=task_vars)

# Generated at 2022-06-11 11:47:24.483917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    module_name = 'ansible.legacy.setup'

    run = ActionModule(None, None)
    # test with no modules
    res = run._get_module_args(module_name, None)
    assert res == {}

    # test with no modules
    res = run._get_module_args(module_name, {})
    assert res == {}

    # test with no modules
    res = run._get_module_args(module_name, {'facts_module': ''})
    assert res == {}

    # test with 1 modules
    res = run._get_module_args(module_name, {'FACTS_MODULES': 'test'})
    assert res == {}

    # test with 1 modules

# Generated at 2022-06-11 11:47:34.295444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    class MockTaskQueueManager(TaskQueueManager):
        def __init__(self):
            self.results = []
            self.saved_queue = None
            super(MockTaskQueueManager, self).__init__(None, None, None, None, None)

        def queue_task(self, host, task, task_vars=None, **kwargs):
            action_name = task.action
            action_args = task.args
            action_mod = action_loader.get(action_name, module_args=action_args)
            action_mod

# Generated at 2022-06-11 11:47:44.526331
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest.mock as mock

    class MockActionModule(ActionModule):
        def _execute_module(self, task_vars=None):
            return dict(ansible_facts=dict(test=1))

    mock_task = mock.MagicMock()
    mock_task.args = dict()
    mock_task._parent = mock.MagicMock()
    mock_task._parent._play = mock.MagicMock()
    mock_task._parent._play._action_groups = dict()
    mock_action_module = MockActionModule(mock_task, mock.MagicMock(), mock.MagicMock(), mock.MagicMock(), mock.MagicMock(), mock.MagicMock(), mock.MagicMock())

    result = mock_action_module.run(mock.MagicMock(), mock.MagicMock())

# Generated at 2022-06-11 11:47:44.958840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:47:54.620003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the case that when parallel is None and len(modules) >= 1, the parallel value is True
    action_module = ActionModule()
    action_module._task.args = dict()
    action_module._task.args['test'] = 'test'
    action_module._task.args.pop('test')
    action_module._supports_check_mode = True
    action_module.run(tmp='test', task_vars='test')
    assert action_module.run(tmp='test', task_vars='test')['ansible_facts']['_ansible_facts_gathered'] is True

    # Test the case that when parallel is None and len(modules) < 1, the parallel value is False
    action_module = ActionModule()
    action_module._task.args = dict()

# Generated at 2022-06-11 11:48:04.158314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance obj of class ActionModule
    class _ActionModule(ActionModule):
        def get_action_args_with_defaults(self, action, args, variables=None, action_groups=None):
            return 'test_action_args_with_defaults'

        def get_config_value(self, name, variables=None):
             return 'test_get_config_value'

        def get_group_variables(self, group, variables=None):
            return 'test_get_group_variables'

        def get_templar(self):
            return 'test_get_templar'

        def get_task(self):
            return 'test_get_task'

    # Expected results

# Generated at 2022-06-11 11:48:04.965825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement test
    assert True

# Generated at 2022-06-11 11:48:13.857571
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:50:21.276429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:50:25.918646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an object
    action_module_obj = ActionModule(None, None, None, None, None)
    assert action_module_obj is not None

    # Test __getattr__
    assert action_module_obj.__getattr__('_templar') is not None
    assert action_module_obj.__getattr__('_shared_loader_obj') is not None
    assert action_module_obj.__getattr__('_connection') is not None

# Generated at 2022-06-11 11:50:26.710421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-11 11:50:36.143674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader

    connection_loader.add(None, C.DEFAULT_TRANSPORT, 'ansible.legacy.connection')

    task = {'args_parser': None,
            'collections': [],
            'deprecated_tags': {},
            'module_args': {'gather_timeout': 5},
            'module_defaults': {},
            'no_log': False,
            'notify': [],
            'role': None,
            'when': []}


# Generated at 2022-06-11 11:50:43.848805
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    import io
    import sys

    class MockTemplar:

        def __init__(self):
            self.data = {}

        def template(self, data):
            if isinstance(data, list):
                return [self.template(x) for x in data]
            elif isinstance(data, dict):
                return self.template_dict(data)

            if isinstance(data, str):
                return data

        def template_dict(self, data):
            return data

    class MockModule:

        class params:

            gather_subset = None
            gather_network_resources = None
            subset = None

        @staticmethod
        def params_to_b_args(params):
            return params

        module_defaults = {}
        env_vars = {}


# Generated at 2022-06-11 11:50:44.307254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:50:51.879735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method of class ActionModule
    """
    _mock_connection = MockConnection()
    _mock_task = MockTask()
    _mock_loader = MockLoader()
    _mock_shared_loader_obj = MockSharedLoaderObj()
    _mock_display = MockDisplay()

    _mock_var_manager = MockVarManager()
    _mock_task._action = MockAction()
    _mock_task._action.args = {'parallel': 'no'}
    _mock_task._parent = MockPlay()
    _mock_task._parent._play = MockPlaybook()
    _mock_task._parent._play._action_groups = {'all':[]}
    _mock_task._parent._play._action_groups = MockActionGroups()
    _

# Generated at 2022-06-11 11:51:00.811574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants
    import ansible.utils.vars
    import ansible.plugins.action
    import res

    mod = ansible.plugins.action.ActionModule(None, None, None, None, None, None)


    # initialize the class attributes
    mod._connection = None
    mod._task = None
    mod._display = None
    mod._shared_loader_obj = res.class_loader_obj
    mod._templar = res.class_templar
    mod._remove_tmp_path = res.class_remove_tmp_path
    mod._execute_module = res.class_execute_module

    # call method run
    res.class_task_vars['ansible_facts'] = {}
    mod.run(None, res.class_task_vars)

# Generated at 2022-06-11 11:51:08.646641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ClassLoader(object):
        def find_plugin_with_context(self, mod, collection_list):
            return dict(resolved_fqcn='resolved_fqcn')

    class SharedLoaderObj(object):
        def __init__(self):
            self.module_loader = ClassLoader()

    class Task(object):
        def __init__(self):
            self.module_defaults = dict()
            self.args = dict()
            self.collections = dict()
            self._parent = ParentTask()

    class ParentTask(object):
        def __init__(self):
            self._play = Play()

    class Play(object):
        def __init__(self):
            self._action_groups = dict()

    class Connection(object):
        def __init__(self):
            self._load

# Generated at 2022-06-11 11:51:09.146131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass