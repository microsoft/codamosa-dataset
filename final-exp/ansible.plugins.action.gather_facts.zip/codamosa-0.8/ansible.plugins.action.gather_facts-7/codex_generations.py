

# Generated at 2022-06-11 11:42:22.753298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:23.303053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 11:42:26.930776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

    # Getters for attributes '_supports_check_mode' and '_supports_async'
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-11 11:42:36.688601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_facts=dict(),
        ansible_network_os='test',
        ansible_connection='test',
    )
    task = dict(
        action='setup',
        args=dict(),
    )
    am = ActionModule(task, task_vars=task_vars)
    assert am.name == 'setup'
    assert am._task.action == 'setup'
    assert am._task.args == dict()
    assert am._task.action_timeout == 30
    assert am._task.async_val == 0
    assert am._task.delegate_to == ''
    assert am._task.delegate_facts == False
    assert am._task.ignore_errors == False
    assert am._task.loop == 'default'

# Generated at 2022-06-11 11:42:44.804094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule()
  module._shared_loader_obj = object()
  module._task = object()
  module._templar = object()
  module._task._parent = object()
  module._task._parent._play = object()
  module._task._parent._play._action_groups = ["test"]
  module._execute_module = object()
  module._display = object()
  module._connection = object()
  module._connection._load_name = object()
  module._remove_tmp_path = object()
  assert module.run() == {}

# Generated at 2022-06-11 11:42:45.393925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:42:55.580421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleUndefinedVariable
    import ansible.constants as C


# Generated at 2022-06-11 11:43:02.531740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import ActionModuleLoader

    mod = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=ActionModuleLoader(),
        templar=None,
        shared_loader_obj=plugin_loader.PluginLoader()
    )

    assert mod is not None
    assert mod.name == 'setup'
    assert mod.action_type == 'setup'

# Generated at 2022-06-11 11:43:03.249904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-11 11:43:03.990905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:43:25.547609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import os
    import sys
    import copy
    import ansible.plugins.action.setup
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.network.interfaces
    setup_class = ansible.plugins.action.setup.ActionModule(mock.Mock(), mock.Mock(), 'setup')

    # Test when FACTS_MODULES is empty
    setup_class._task.args = {'test': 'test', 'test1': 'test1'}
    setup_class._task.args['test_kwarg'] = None
    setup_class._task.args['test_kwarg_1'] = None
    setup_class._task.args['test_kwarg_2'] = None

# Generated at 2022-06-11 11:43:26.140944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:43:27.049383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 11:43:29.830754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    >>> ActionModule()
    <ansible.plugins.action.setup.ActionModule object at 0x7fbf9545a0f0>
    """


# Generated at 2022-06-11 11:43:39.890251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.executor.task_result import TaskResult
    from ansible.executor.executor import get_exception_handling_execute_on_host
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    context.CLIARGS = {'verbosity': 3, 'inventory': 'dummy'}
    task = Task()
    action = action_loader.get('setup', task, connection='local', play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

    result = TaskResult(host=None, task=task)
    action._connection = get_exception_handling_execute_on_host('local')
    action._task = task
    action._shared_loader_obj = None



# Generated at 2022-06-11 11:43:50.042924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = 'localhost'
    config_data = {'ansible_connection': 'local'}
    connection = get_connection(host_name, config_data)

    # config_data = {'connection': 'network_cli'}
    config_data = {'connection': 'ssh'}

    # Prepare the test
    task = AnsibleTask({'action': {'module': 'command', 'args': 'ls'}}, connection)
    tmp = None
    task_vars = {}

    # run the test
    result = ActionModule(task, connection, tmp).run(tmp, task_vars)

    # Assertions
    assert result['failed'] == False
    assert result['skipped'] == False

    assert len(result['warnings']) == 0
    assert len(result['deprecations']) == 0

# Generated at 2022-06-11 11:43:51.356065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()

    # Exercise
    # Exercise

# Generated at 2022-06-11 11:43:52.312445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:43:54.693512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:43:55.887098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert (action_module is not None)

# Generated at 2022-06-11 11:44:16.593767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 11:44:17.792709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert type(actionModule) == ActionModule

# Generated at 2022-06-11 11:44:28.285515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A test-case which checks if the run() method in class ActionModule returns the expected result
    # when the setup module is run.
    # setup_module() creates a local variable called 'mock' which is used to mock various components
    # of Ansible which are needed to test the return value of the run() method

    # The method to be tested
    target_method = setup_module().functest()

    # We expect that the setup module will return a dictionary with the following entries

    # <class 'ansible.module_utils.facts.processor.processor'>
    assert 'ansible_processor' in target_method.get('ansible_facts', None).keys()

    # <class 'ansible.module_utils.facts.distribution.distribution'>

# Generated at 2022-06-11 11:44:29.613971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule"""

    pass

# Generated at 2022-06-11 11:44:40.525873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.plugins import module_loader
    import ansible.constants as C
    C.HOST_KEY_CHECKING=False

    class FakePlayContext(object):
        def __init__(self):
            self.network_os = None
            self.remote_addr = None

    class FakeTask(object):
        def __init__(self):
            self.args = {'parallel': None}
            self.action = 'setup'
            self.action_args = None
            self

# Generated at 2022-06-11 11:44:41.408881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:44:42.372573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._templar is not None

# Generated at 2022-06-11 11:44:46.030919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct a mock task and new ActionModule object
    am = ActionModule(None, None)
    # assert that ActionModule is an instance of ActionBase
    assert isinstance(am, ActionBase), "%r is not an instance of ActionBase" % am
    # assert that ActionModule is an instance of ActionModule
    assert isinstance(am, ActionModule), "%r is not an instance of ActionModule" % am

# Generated at 2022-06-11 11:44:48.159473
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create ActionModule instance
    ac = ActionModule(1, 1, True, False)

    # check returned
    assert ac is not None
    assert isinstance(ac, ActionModule) is True

# Generated at 2022-06-11 11:44:56.971440
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:45:40.020208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    fact_module = action_module.run()
    print("Fact module: ", fact_module)

# Generated at 2022-06-11 11:45:50.152800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    from ansible.playbook_plugins.action.setup import ActionModule

    # mock out ansible.module_utils.facts.Facts so that it can be instantiated
    import ansible.module_utils.facts
    import sys
    original_Facts = ansible.module_utils.facts.Facts
    class MockFacts:
        def __init__(self,_sys):
            pass
        def __call__(self,*args,**kwargs):
            return original_Facts(*args,**kwargs)
    sys.modules['ansible.module_utils.facts'] = MockFacts(sys)


# Generated at 2022-06-11 11:45:52.438335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  self = ActionModule()
  tmp = None
  task_vars = None
  print(self.run(tmp,task_vars))

# Generated at 2022-06-11 11:46:02.728388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = MockConnection()
    tmp = '/tmp/'
    files = {}
    loader = MockLoader()
    display = MockDisplay()

    task_vars = {}
    task_args = {}
    templar = MockTemplar()
    am = ActionModule(conn=conn, tmp=tmp, task_vars=task_vars, templar=templar, task_args=task_args, files=files, loader=loader, display=display)

    def mock_execute_module(*args, **kwargs):
        return {'ansible_facts': {'test_fact': 'test_value'}}

    am._execute_module = mock_execute_module

    result = am.run()

    assert result['ansible_facts']['test_fact'] == 'test_value'


# Mock object classes


# Generated at 2022-06-11 11:46:13.439265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.common._collections_compat import MutableMapping

    module = ActionModule()
    task_vars = {
        'ansible_facts_parallel': True,
        'ansible_facts': {
            'network_os': 'ios',
            'network_os2': 'ios2',
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        },
        'ansible_network_os': 'ios3'
    }

    # test for get_module_args method
    result = module._get_module_args('ansible.legacy.setup', task_vars)
    assert result['filter'] == 'ansible_distribution'

    result = module._get_

# Generated at 2022-06-11 11:46:24.118471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugin.action.setup import ActionModule
    from ansible.plugins.action.setup import collect_subset_facts
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-11 11:46:26.789574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # As run() uses multiple modules (setup) which require an active connection,
    # and as it is not practical to mock the connection class, the test is done
    # by skipping the tests done by the function's code
    pass

# Generated at 2022-06-11 11:46:34.711146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task = dict()
  task_vars = dict()
  facts_module = dict()
  res = dict()
  facts_module['res'] = res
  res['ansible_facts'] = dict()
  facts_module['res']['ansible_facts']['gathered_facts'] = dict()
  facts_module['res']['ansible_facts']['gathered_facts']['ansible_all_ipv4_addresses'] = ['192.168.1.1']
  facts_module['res']['ansible_facts']['_ansible_facts_gathered'] = True
  res['ansible_facts']['_ansible_facts_gathered'] = True

  task_vars['ansible_facts'] = dict()

# Generated at 2022-06-11 11:46:35.288128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 11:46:44.262302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        fake_loader = DictDataLoader({'roles/test/action_plugin.py': 'FAKE PLUGIN CODE'})
        fake_collections = ['roles/test']
        task = Task(action=dict(module='test_module'), terms=[dict(name='test')])
        task._role = Role('roles/test')
        action_plugin = ActionModule(task=task, connection=Connection(host='host_name'), play_context=PlayContext(), loader=fake_loader, shared_loader_obj=None, templar=None, ansible_version=None)
        plugin = action_plugin._shared_loader_obj.get('action_plugin')
        assert plugin._load_name == 'roles/test/action_plugin'
    except:
        assert False, 'Action module constructor test failed'

# Generated at 2022-06-11 11:48:22.355163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars={'ansible_facts_parallel': 'smart',
              'ansible_facts_parallel': 'smart',
              'ansible_facts_parallel': 'smart',
              'ansible_facts_parallel': 'smart',
              'ansible_facts_parallel': 'smart',
              'ansible_facts_parallel': 'smart'}
    task_vars['facts']='ansible.legacy.setup'
    _execute_module = ActionModule()
    _execute_module._get_module_args(task_vars)
    _execute_module._combine_task_result(task_vars)
    _execute_module.run(task_vars)

# Generated at 2022-06-11 11:48:25.394373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule('test', 'loader', 'connection', 'play_context', 'loader', 'temp_path', 'shared_loader_obj')
    assert isinstance(action_module_obj, ActionModule)



# Generated at 2022-06-11 11:48:26.868089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit tests for method run of class ActionModule
    assert True == True


# Generated at 2022-06-11 11:48:32.586905
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create an instance
    am = ActionModule()

    # create a mock task
    task = MockTask()

    # execute method
    result = am.run(tmp='/tmp', task_vars={})

    # assert result
    assert result['ansible_facts'] == {}
    assert result['warnings'] == []
    assert result['deprecations'] == []
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True


# Generated at 2022-06-11 11:48:33.089341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-11 11:48:40.436969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Module_Args():
        def __init__(self, arg):
            self.args = arg

    class Task():
        def __init__(self, mod_arg, col_list):
            self.args = mod_arg
            self.collections = col_list

    class Connection():
        def __init__(self, load_name):
            self._load_name=load_name
            self._shell = Shell()

    class Shell():
        def __init__(self):
            self.tmpdir = "/tmp"

    class Display():
        def __init__(self):
            self.verbosity = 0
            self.verbose = False

        def warning(self, msg):
            print(msg)

        def vvvv(self, msg):
            print(msg)


# Generated at 2022-06-11 11:48:42.999217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module, "ActionModule object not created"
    assert action_module._supports_check_mode, "ActionModule._supports_check_mode should be True, but it is false"

# Generated at 2022-06-11 11:48:51.187028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import merge_hash
    import json
    import sys

    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class Options(object):
        verbosity = 1
        host_key_checking = False
        inventory = ""
        listhosts = None
        subset = None
        module_paths = None
        extra_vars = [{'test': 'test', 'test2': 'test2'}]
        forks = 10
        ask_vault_pass = False
        vault_password_files = None
        new_vault

# Generated at 2022-06-11 11:49:00.989305
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import json
    import pytest

    from os.path import basename
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.setup import ActionModule as SetupActionModule
    from ansible.plugins.action.setup import ActionModuleMeta as SetupActionModuleMeta
    from ansible.utils.vars import merge_hash

    context._init_global_context(mock_unfrackpath_noop)


# Generated at 2022-06-11 11:49:04.922808
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # arrange
    setup_vars = {
        'gather_subset': '!all',
        'filter': '*'
    }

    controller = ActionModule()

    # act
    result = controller.run(tmp=None, task_vars=setup_vars)

    # assert
    assert result['ansible_facts']['_ansible_facts_gathered'] == False