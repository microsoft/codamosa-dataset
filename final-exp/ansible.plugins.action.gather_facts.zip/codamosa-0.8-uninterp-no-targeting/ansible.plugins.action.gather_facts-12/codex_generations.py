

# Generated at 2022-06-21 02:16:22.346076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:16:29.444825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.loader as plugin_loader

    loader_obj = C.loaders.all()[0]
    tmp = C.DEFAULT_LOCAL_TMP
    shared_loader_obj = plugin_loader._create_shared_loader(
        loader_obj,
        tmp
    )

    action_module_obj = ActionModule(
        shared_loader_obj=shared_loader_obj,
        connection=None,
        templar=None,
        task_vars=dict(),
        play_context=None,
        loader=loader_obj,
        templar=None,
        shared_loader_obj=shared_loader_obj
    )

    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-21 02:16:30.312950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:30.727200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:16:37.229126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for AnsibleModule
    import ansible.executor.task_result
    import ansible.executor.action_result
    import ansible.utils.display
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.vars.manager
    import ansible.task.task_include
    import ansible.parsing.dataloader
    import ansible.vars.option_lookup
    import ansible.vars.unsafe_proxy
    import ansible.utils.vars
    import ansible.inventory.manager
    import ansible.inventory.data
    import ansible.errors
    import ansible.playbook.play_context
    import ansible.plugins.loader


# Generated at 2022-06-21 02:16:38.359771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:38.856048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:40.167414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert am._supports_check_mode == True

# Generated at 2022-06-21 02:16:50.464943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conf = dict(
        module_defaults=dict(
            foo='bar',
        ),
    )
    setup = dict(
        ansible_facts=dict(
            a=1,
        )
    )
    task_vars = dict(
        a=2,
    )
    action_base_obj = ActionBase(conf, setup)
    action_module_obj = ActionModule(action_base_obj, task_vars)
    assert isinstance(action_module_obj, ActionModule)
    assert action_module_obj._task.args.get('foo', None) == 'bar'
    assert action_module_obj._task.args.get('a', None) == 2
    assert action_module_obj._task.args.get('b', None) == None

# Generated at 2022-06-21 02:16:54.599507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Empty JSON request
    request = {}
    # This will populate ansible_facts with _ansible_facts_gathered attribute as
    # True and _ansible_items placeholder for ansible_facts
    action_module = ActionModule().run(request, {})
    assert action_module['_ansible_items'] == [{'ansible_facts': {'_ansible_facts_gathered': True}}]

# Generated at 2022-06-21 02:17:13.575693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cls = ActionModule(
        task=dict(
            args=dict(
                gather_subset=['all']
            )
        ),
        connection=None
    )

    # Set variables to test method _get_module_args
    cls._task.args['filter'] = 'ansible_processor_model'
    cls._task.args['gather_subset'] = ['all']
    cls._task.args['gather_timeout'] = 30
    cls._task.module_defaults = dict(
        test=dict(
            default_param='test_param'
        )
    )


# Generated at 2022-06-21 02:17:18.143053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, dict(foo='bar'))
    assert am._templar is None
    assert am._task.args == dict(foo='bar')
    # ensure name used in action_manager._create_action is set
    assert am._name == 'setup'
    assert am._supports_async is True

# Generated at 2022-06-21 02:17:24.915930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    action_module = ActionModule('test_file.yml', [('setup.module_name', 'test.setup_module_name')], 'test_vars', 'test_templar')
    assert type(action_module) == ActionModule, 'ActionModule is not instantiated'


# Generated at 2022-06-21 02:17:34.922115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_loader = MockLoader()
    m_play = MockPlay()
    m_play.name = 'test_play'
    m_play.hosts = 'hosts'
    m_task = MockTask()
    m_task._parent = m_play
    m_task.action = 'action'
    m_task.args = {'arg': 'value'}
    m_task.loop = 'loop'
    m_task.notified_by = ['notified']
    m_task.run_once = False
    m_task._role = None
    m_task.when = 'when'
    m_task.delegate_to = 'delegate_to'
    m_task._role_name = None
    m_task._loader = m_loader

# Generated at 2022-06-21 02:17:43.832263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = {
        'ansible': {
            'factsmodules': [
                'ansible.legacy.setup',
                'ansible.legacy.network.system',
            ],
        },
    }
    task_vars = {
        'ansible_facts_parallel': False,
    }
    mock_task = {'args': {}}
    mock_task['args']['connection_facts_modules'] = {'network_cli': 'ansible.legacy.network.system'}
    mock_task['args']['facts_modules'] = ['ansible.legacy.setup', 'ansible.legacy.network.system']

    task_vars['ansible_network_os'] = 'ios'
    task_loader = load_fixture('import_playbook.yaml')
    tasks = task

# Generated at 2022-06-21 02:17:45.161533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")

# Generated at 2022-06-21 02:17:45.756611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:17:50.218745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(gather_facts="true",
                gather_subset=('all'),
                gather_timeout=10)
    task_vars = dict(ansible_facts_parallel=None)
    tmp = os.getcwd()
    myact = ActionModule(dict(args=args, task=dict(args=args)), dict(tmp=tmp, task_vars=task_vars))
    myact.run(tmp=tmp, task_vars=task_vars)

# Generated at 2022-06-21 02:18:00.062155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude

    from ansible_collections.test.test_utils.mock import patch


# Generated at 2022-06-21 02:18:10.414900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars as uvars
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action.setup import ActionModule as setup_ActionModule
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    module_loader.add_directory(os.getcwd())
    module_loader.load_all()


# Generated at 2022-06-21 02:18:31.965084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:18:43.055670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import os
    import shutil

    from ansible.plugins.action import ActionBase
    from io import StringIO
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-21 02:18:50.782237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock action_base object
    _loader_mock = mock.MagicMock()
    _tmp_path_mock = mock.MagicMock()
    _connection_mock = mock.MagicMock()
    _display_mock = mock.MagicMock()
    _task_mock = mock.MagicMock()
    _shared_loader_obj_mock = mock.MagicMock()

    def set_property(key, value):
        setattr(ActionModule, key, value)
    action_base_mock = ActionBase()
    action_base_mock.action = 'ansible.legacy.setup'
    action_base_mock.action_loader = _loader_mock
    action_base_mock.action_loader.get_basedir.return_value = _tmp_path_m

# Generated at 2022-06-21 02:18:52.358447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    pass

# Generated at 2022-06-21 02:18:55.089975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(connection=None, task=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:18:57.416828
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule._supports_async is True

    # Test __init__
    action_obj = ActionModule()

    assert action_obj._supports_check_mode is True

# Generated at 2022-06-21 02:19:06.398325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with None params
    results = {}
    action_module = ActionModule(None, results)
    assert (action_module._supports_check_mode == True)
    assert (results.get('failed') == False)
    assert (results.get('failed_modules') == {})
    assert (results.get('ansible_facts').get('_ansible_facts_gathered') == True)
    assert (results.get('_ansible_verbose_override') == True)

# Generated at 2022-06-21 02:19:08.691748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m is not None


# Generated at 2022-06-21 02:19:09.750989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 02:19:17.396541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_name='setup')
    result = module.run(None, {'FACTS_MODULES': ['ansible.module_utils.basic']})
    assert result['ansible_facts']['_ansible_facts_gathered']

    with open('test_resources/ansible-setup-plugin.txt', 'r') as input:
        expected = input.read()
        assert result['ansible_facts']['ansible_facts'] == expected

# Generated at 2022-06-21 02:20:02.884410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = run_module_with_args(ActionModule)
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-21 02:20:08.767944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    import ansible.loader
    play_context = PlayContext()
    loader = ansible.loader.DataLoader()

    # test that the class can be instantiated
    assert ActionModule(play=None, task=None, connection=None, play_context=play_context, loader=loader, templar=None)

# Generated at 2022-06-21 02:20:09.926890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(1,2)


# Generated at 2022-06-21 02:20:12.474254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    with pytest.raises(Exception):
        action_module.run()



# Generated at 2022-06-21 02:20:19.052561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection=None,
                       templar=None,
                       runner_threads=None,
                       loader=None,
                       shared_loader_obj=None,
                       connection_loader=None,
                       action_loader=None,
                       task_uuid=None,
                       task_vars=None,
                       default_vars=None,
                       task_loader=None,
                       play=None,
                       new_stdin=None,
                       task=None)
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-21 02:20:21.459502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None


# Generated at 2022-06-21 02:20:27.860754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest2 as unittest
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash

    # GIVEN: an ActionModule instance
    am = ActionModule()

    # WHEN: run method receives parameters without ansible_facts_parallel
    #       set to 'False', skips all but the first item in FACTS_MODULES
    #       and the method is called
    class MockConfig:
        def get_config_value(self, key, variables=None):
            if key == 'FACTS_MODULES':
                return ['first_plugin', 'second_plugin']
            else:
                return None

    class MockTask:
        def __init__(self):
            self.args = {}


# Generated at 2022-06-21 02:20:37.243240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import types
    # Define the class that will be used to instantiate the test object
    class MockActionBase:
        pass
    # Instantiate the mock class to be passed in.
    mock_action_base = MockActionBase()
    # Build the object
    result = ActionModule(mock_action_base)
    # Test for instance creation
    assert isinstance(result, ActionModule)
    # Test for instance attributes
    assert isinstance(result._shared_loader_obj, types.ModuleType)
    assert result._b_action._parent_class is mock_action_base
    assert result._connection is mock_action_base._connection
    assert result._task is mock_action_base._task
    assert result._loader is mock_action_base._loader
    assert result._templar is mock_action_base._templar
   

# Generated at 2022-06-21 02:20:47.094296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ModuleManager:
        def __init__(self):
            self.args = dict(
                gather_subset=[],
                gather_timeout=10,
                filter="*"
            )

    module_manager = ModuleManager()

    class Connection:
        def __init__(self):
            self._load_name = 'some_loader'

    connection = Connection()

    class Executor:
        def __init__(self):
            self.connection = connection

    executor = Executor()

    ModuleManager = ActionModule(executor, module_manager)

    # test of construction
    assert ModuleManager._supports_check_mode is False
    assert ModuleManager.connection._load_name == 'some_loader'

# Generated at 2022-06-21 02:20:49.691627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

test_ActionModule_run()

# Generated at 2022-06-21 02:22:22.665218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:22:33.262458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock action module and task
    am = ActionModule()
    am._supports_check_mode = True
    am._task = mock_task()

    # Create mock AnsibleVarLoader and set am._shared_loader_obj
    avl = AnsibleVarLoader()
    avl._task_stack = [am._task]
    am._shared_loader_obj = avl

    # Create mock AnsbileTemplar and set am._templar
    at = AnsibleTemplar()
    am._templar = at

    # Create mock PlayContext and set am._play_context
    pc = PlayContext()
    am._play_context = pc

    # Create mock AnsibleHostManager and set am._host_manager
    ah = AnsibleHostManager()
    am._host_manager = ah

    # Create mock Ansible

# Generated at 2022-06-21 02:22:44.146698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mcounter = 0
    def mock_get_system_temp_dir():
        return "/tmp/ansible_setup_payload.%d" % mcounter

    mock_self = MagicMock()
    type(mock_self).tmp = PropertyMock(side_effect=mock_get_system_temp_dir)
    type(mock_self)._supports_check_mode = False
    type(mock_self)._connection = MagicMock()
    type(mock_self)._connection._load_name = 'network_cli'
    type(mock_self)._shared_loader_obj = MagicMock(spec=['module_loader'])
    type(mock_self)._shared_loader_obj.module_loader = MagicMock()
    mock_self._shared_loader_obj.module_

# Generated at 2022-06-21 02:22:54.895508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy task
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a task object
    t = Task()
    # Create a play context object
    p = PlayContext()
    t._task_fields['context'] = 'foo'
    t._task_fields['action'] = 'setup'
    t._task_fields['module_defaults'] = False

# Generated at 2022-06-21 02:23:02.694852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.hw_firmware import HardwareFirmwareFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.virtual.base import BaseFactCollector as BaseVirtualFactCollector
    from ansible.module_utils.facts.virtual.openstack import OpenstackVirtualFactCollector
    from ansible.module_utils.facts.virtual.vmware import VMwareVirtualFactCollector
    from ansible.module_utils.facts.virtual.xenapi import XenapiVirtual

# Generated at 2022-06-21 02:23:08.111682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule class...")
    assert ActionModule(connection='connection',
                        task='task',
                        play_context='play_context',
                        loader='loader',
                        templar='templar',
                        shared_loader_obj='shared_loader_obj') is not None

# Generated at 2022-06-21 02:23:15.972127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars
    import ansible.module_utils.facts
    import ansible.plugins.loader
    import ansible.utils.unsafe_proxy
    import ansible.module_utils.facts.hardware.freebsd
    import ansible.module_utils.facts._fact_aggregator
    import ansible.module_utils.facts.virtual.xen
    import ansible.module_utils.facts.virtual.facter
    import ansible.module_utils.facts.virtual.systemd
    import ansible.module_utils.facts.network.ios
    import ansible.module_utils.facts.virtual.docker
    import ansible.module_utils.facts.virtual.openvz
    import ansible.module_utils.facts.virtual.vbox

# Generated at 2022-06-21 02:23:19.926501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader
    ansible.plugins.loader.ActionModule = ActionModule

    from ansible.plugins.loader import find_plugin, find_action
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    # load fixture
    # task = Task(
    # load_fixture('os_server_facts_task.json'),
    # )

    # task is None
    # result

# Generated at 2022-06-21 02:23:21.300624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
    )



# Generated at 2022-06-21 02:23:33.674631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {}
    data['args'] = {'a': '1', 'b': '2'}
    data['module_name'] = 'setup'
    data['module_defaults'] = {'a': '5', 'b': '6'}
    data['task_vars'] = {'a': '3', 'b': '4'}
    data['merged_args'] = {'a': '1', 'b': '2'}
    data['FACTS_MODULES_LIST'] = ['setup']
    data['CONNECTION_FACTS_MODULES'] = {'ansible.legacy.setup': 'ansible.legacy.setup'}