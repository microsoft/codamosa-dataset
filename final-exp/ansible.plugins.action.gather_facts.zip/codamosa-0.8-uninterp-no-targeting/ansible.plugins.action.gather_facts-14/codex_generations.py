

# Generated at 2022-06-21 02:16:25.372373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None, loader_object=None, templar=None, shared_loader_object=None)
    assert action._shared_loader_obj is not None

# Generated at 2022-06-21 02:16:32.009924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.ansible_modlib import ActionModule
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch
    from ansible.plugins.loader import action_loader
    from ansible_collections.ansible.misc.plugins.modules.system import __init__ as action_module
    import os
    import time

    class TestActionModule(ActionModule):
        def __init__(self):
            pass

        def _get_module_args(self, fact_module, task_vars):
            return {}

        def _combine_task_result(self, result, task_result):
            return {}

        def run(self, tmp=None, task_vars=None):
            return {}

    action_

# Generated at 2022-06-21 02:16:32.823719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:16:40.648596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock = {}
    mock['_task'] = {}
    mock['_task']['args'] = {}
    mock['_task']['args']['network_os'] = None
    mock['_task']['args']['parallel'] = None
    mock.setdefault('_display', {})
    mock['_connection'] = {}
    mock['_connection']['_shell'] = {}
    mock['_connection']['_shell']['tmpdir'] = '/tmp'
    mock['_connection']['_load_name'] = 'network_cli'
    act_mod = ActionModule()
    act_mod.run(tmp='/tmp', task_vars={})

# Generated at 2022-06-21 02:16:50.636233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Task definition:
    - local_action:
        module: setup
    """
    module_path = os.path.join('test/sanity/code/lib/ansible/modules', 'setup.py')
    module = imp.load_source('setup', module_path)

    module_args = {'gather_subset': 'all'}
    task_vars = dict(
        ansible_connection='local',
        ansible_network_os=None,
        ansible_facts=dict()
    )

    fact_module = 'setup'

    # ActionModule._get_module_args

    mod_args = get_action_args_with_defaults(
        module.ActionModule, module_args, {}, templar.Templar(),
        action_groups=['vars']
    )

# Generated at 2022-06-21 02:16:52.364236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None


# Generated at 2022-06-21 02:16:56.916672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import connection_loader

    mockConnection = connection_loader.get('local')
    module = ActionModule(mockConnection, 'setup')
    result = module.run()

    assert result['ansible_facts'] is not None
    assert result['failed_modules'] is None
    assert result['skipped_modules'] is None



# Generated at 2022-06-21 02:17:09.449216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    m = ActionModule({}, {}, {})
    m._display = {'warning': lambda x:x}
    m._shared_loader_obj = {'module_loader': {'find_plugin_with_context': lambda x, y:x}}
    m._templar = None
    m._task = {'collections': [], 'args': {'a': 'b'}}
    m._task._parent = {'_play': {'_action_groups': {}}}
    m._connection = {'_load_name': 'Test_connection', '_shell': {'tmpdir': '/tmp/ansible_test'}}

    # Part that makes the test
    m.run({'ansible_facts_parallel': None}, {'ansible_network_os': 'TestOS'})

# Generated at 2022-06-21 02:17:10.987899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:17:12.016366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 02:17:32.028919
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Tests the following actions
    #  - setup.py - parallel=None, len(modules)>=1 --> parallel = True
    #  - setup.py - parallel=None, len(modules)<1 --> parallel = False
    #  - setup.py - parallel=True, network_os='ios' --> modules = ['ansible.legacy.setup', 'ansible.legacy.ios']
    #  - setup.py - parallel=False --> modules = 'ansible.legacy.setup'

    # Test based on setup.py file

    # Test for parallel=None, len(modules)>=1
    assert ActionModule.run(ActionModule, True, True, task_vars={"testkey": "testvalue"}) == {"ansible_facts": {}}

    # Test for parallel=None, len(modules)<1

# Generated at 2022-06-21 02:17:33.429962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 02:17:42.356142
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    '''
    The job result.
    :rtype: dict
    '''

    mock_job_result = {
        'ansible_job_id': '123',
        'finished': '1'
    }

    '''
    The test variables.
    :rtype: dict
    '''

    test_vars = {
        'ansible_facts': {
            '_ansible_fact_gathered': True
        }
    }

    '''
    The module parameters.
    :rtype: dict
    '''

    module_params = {}

    '''
    The task result.
    :rtype: dict
    '''

    task_result = {
        'ansible_facts': {
            'fact_name': 'fact_value'
        }
    }


# Generated at 2022-06-21 02:17:50.490526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

    class mock_display:
        class display:
            def warning(s):
                return 's'
            warning = staticmethod(warning)
    m._display = mock_display()

    class mock_connection:
        _load_name = ""

    m._connection = mock_connection()


    class mock_task:
        class args:
            def copy(s):
                return {}
            copy = staticmethod(copy)

        def pop(s, a, b):
            return 's'
        pop = staticmethod(pop)

        class _parent:
            class _play:
                _action_groups = ''

    m._task = mock_task()



# Generated at 2022-06-21 02:18:00.176937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action_module=dict(
        action='ansible.builtin.setup', task_vars=dict(ansible_facts_parallel=False),
        FACTS_MODULES=['ansible.legacy.setup'],
        ansible_network_os=None, ansible_facts=dict(),
        ansible_loop_var='item', _ansible_module_name='setup',
        ansible_facts_module_list=['ansible.legacy.setup'],
        ansible_action='ansible.builtin.setup'
    ))
    display = {'verbosity': 1, 'verbose': True, 'command': '/bin/ls'}
    module = ActionModule(task=task, display=display)


# Generated at 2022-06-21 02:18:02.236381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-21 02:18:11.310426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor: ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    import ansible.plugins.action.setup_legacy
    import ansible.plugins.action.gather_legacy

    # create objects
    task = ansible.plugins.action.setup_legacy.ActionModule({})
    connection = ansible.plugins.action.gather_legacy.ActionModule({})
    play_context = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}

    # create ActionModule object
    obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    # test function _get_module_args
    # [1] test setup module
    import ansible.plugins.module_utils.facts.system

# Generated at 2022-06-21 02:18:21.357301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task_vars = {
        'ansible_connection': 'local',
        'ansible_network_os': 'test_os',
        'ansible_facts': {'test_info': 'information'}
    }
    mock_task = {
        'args': {'network_os': 'test_os',
                 'parallel': 1},
        'collections': ['collections1', 'collections2']
    }

    action_module = ActionModule(mock_task, mock_task_vars)

    assert action_module._connection._load_name == 'local'
    assert action_module._display._verbosity == 3
    assert action_module._task.args['network_os'] == 'test_os'
    assert action_module._task.args['parallel'] == 1
    assert action_module

# Generated at 2022-06-21 02:18:23.220433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:18:33.046198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    modules = ['os', 'setup']
    parallel = True
    action_module = ActionModule()
    action_module.task_vars = {'ansible_facts_parallel': parallel, 'ansible_facts': {'network_os': 'eos'}}
    action_module._task.args = {'network_os': 'eos'}
    action_module.action = 'setup'
    action_module._task.module_defaults = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}

# Generated at 2022-06-21 02:18:56.589483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass  # nothing to test...

# Generated at 2022-06-21 02:19:09.039900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts import collector
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.utils.vars import merge_hash
    import tempfile
    import os
    import shutil
    import json
    import time
    import pytest
    import sys
    import inspect

    # Load the module utilities

# Generated at 2022-06-21 02:19:13.083194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ This is a unit test for the constructor of ActionModule. """
    test_action_module = ActionModule(None, None)
    assert test_action_module is not None


# Generated at 2022-06-21 02:19:20.649824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test variable dictionary
    task_vars = dict()

    # Test variable dictionary
    tmp = dict()

    # Test variable dictionary
    conn = dict()

    # Test variable dictionary
    play_context = dict()

    # Test variable dictionary
    play_context['network_os'] = 'test_network_os'

    # Test variable dictionary
    play_context['verbosity'] = 5

    # Test variable dictionary
    task = dict()

    # Test variable dictionary
    task['action'] = 'setup'

    # Test variable dictionary
    task['async'] = 1

    # Test variable dictionary
    task['args'] = {}

    # Test variable dictionary
    task['delegate_to'] = ''

    # Test variable dictionary
    task['delegate_facts'] = False

    # Test variable dictionary
    task['loop'] = ''



# Generated at 2022-06-21 02:19:28.628538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Tested Constructor:
    #     def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    # Tested Methods:
    #     def run(self, tmp=None, task_vars=None):
    # Class Variables:
    #     _supports_check_mode = True

    # Test Values for Constructor
    mock_task = "mock task"
    mock_connection = "mock connection"
    mock_context = "mock context"
    mock_loader = "mock loader"
    mock_templar = "mock templar"
    mock_shared_loader_obj = "mock loader obj"

# Generated at 2022-06-21 02:19:40.809189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(ansible_network_os='ios')
    module_utils = dict(FACTS_MODULES=['ios'])
    mock_loader = None
    mock_play_context = None
    mock_task = None
    from ansible.plugins.action import ActionModule
    action_obj = ActionModule(task=mock_task, connection=mock_connection, play_context=mock_play_context, loader=mock_loader, templar=mock_templar, shared_loader_obj=mock_shared_loader_obj)
    modArgs = dict()
    modArgs = action_obj._get_module_args('ios', task_vars)
    assert modArgs == dict(), "test_ActionModule failed"


# Generated at 2022-06-21 02:19:43.827278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    task_executor = TaskExecutor(None, None)
    action_module = ActionModule(task_executor)
    assert action_module._supports_check_mode == True


# Generated at 2022-06-21 02:19:54.825769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''
    # From example /usr/share/ansible/fixes/modules/system/setup.py
    modules = [
        {
            "ansible_facts": {
                "fact1": "value1",
                "fact2": "value2"
            },
            "warnings": [
                "Warning message"
            ]
        },
        {
            "ansible_facts": {
                "fact3": "value3",
                "fact4": "value4"
            },
            "warnings": [
                "Warning message 2"
            ]
        }
    ]

    # Creation of action module object
    action_module = ActionModule()
    # Creation of result dictionary
    result = {}
    # Creation of task_vars dictionary

# Generated at 2022-06-21 02:20:01.426430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up
    class FakeDisplay(object):
        # Define property
        def __init__(self):
            self.verbosity = 0
            self.columns = 80
    class FakeModuleLoader(object):
        def find_plugin_with_context(self, module, collection_list=None):
            return ({'resolved_fqcn': module})

    class FakeTemplar(object):
        def template(self, text):
            return text
    class FakeModuleUtil(object):
        def load_params(self, params):
            return params
    class FakeTask(object):
        def __init__(self, module_defaults, args):
            self._parent = self
            self._play = self
            self._action_groups = ['all']
            self.collections = []
            self.module_default

# Generated at 2022-06-21 02:20:11.644954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # instantiate a host_manager, with dummy inventory and variable manager
    class HostManager:
        def __init__(self):
            self.inventory = 'inventory'
            self.variable_manager = 'variable_manager'

    host_manager = HostManager()

    # instantiate a variable manager, with dummy loader and inventory
    class VariableManager:
        def __init__(self):
            self.loader = 'loader'
            self.inventory = 'inventory'

    variable_manager = VariableManager()

    # define parameters so that constructor doesn't complain
    class FakeTask:
        def __init__(self):
            self.action = 'action'
            self.args = 'args'
            self.async_val = 'async_val'

            self.transport = 'transport'

# Generated at 2022-06-21 02:20:56.875762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule
    # TODO: Write test

# Generated at 2022-06-21 02:21:07.305892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # id, task, connection, play_context, loader, templar, shared_loader_obj = None
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.compat.tests import mock
    from ansible.inventory.host import Host

# Generated at 2022-06-21 02:21:17.416564
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Remove the cached ModulesResults if exists
    import os
    if os.path.exists('test/test_runner_tmp/test_module'):
        import shutil
        shutil.rmtree('test/test_runner_tmp/test_module')

    # Dummy ansible.modules.extras.system.setup for testing
    import sys

# Generated at 2022-06-21 02:21:27.079144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    # $ python -m pytest tests/unit/plugins/modules/test_setup_facts.py -s -v
    import os
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.plugins.loader import shared_loader_obj
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-21 02:21:38.064214
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:21:39.466681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 02:21:48.523624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock _execute_module and friends
    _execute_module = ActionModule._execute_module
    def mock_execute_module(module_name, module_args, task_vars, wrap_async=False):
        if module_name == 'ansible.legacy.setup':
            return {'ansible_facts': {'_ansible_setup_result': True}}
        elif module_name == 'ansible.legacy.fail':
            return {'failed': True}
        elif module_name == 'ansible.legacy.skip':
            return {'skipped': True}
        else:
            return {}

    ActionModule._execute_module = mock_execute_module

# Generated at 2022-06-21 02:21:49.870002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # just instantiate the class
    ActionModule()

# Generated at 2022-06-21 02:21:58.909495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        AnsibleRunner = ActionModule()

        res = AnsibleRunner.run()
        assert 'ansible_facts' in res and '_ansible_facts_gathered' in res['ansible_facts']
        
        res = AnsibleRunner.run(task_vars=[{}])
        assert 'ansible_facts' in res and '_ansible_facts_gathered' in res['ansible_facts']
        
        res = AnsibleRunner.run(task_vars=[{'ansible_facts_parallel':True, 'FACTS_MODULES':['self']}])
        assert 'ansible_facts' in res and '_ansible_facts_gathered' in res['ansible_facts']
        

# Generated at 2022-06-21 02:22:11.071949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        gather_subset='all',
        gather_timeout=10,
        filter='ansible_distribution'
    )
    task_vars = dict()
    action_module = ActionModule(
        task=dict(
            args=module_args,
            module_defaults=dict(),
            _parent=dict()
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._get_module_args('smart', task_vars) == dict(
        gather_subset=['!all'],
        gather_timeout=10,
        filter='ansible_distribution'
    )

# Generated at 2022-06-21 02:24:03.758328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Module imports
    from ansible_collections.ansible.netcommon.plugins.action.network import ActionModule

    # Create a fake ansible task

# Generated at 2022-06-21 02:24:04.631084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:24:14.192562
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def get_modules(self, task_vars):
        return ['ansible.builtin.setup']

    def _get_module_args(self, fact_module, task_vars):
        return {}

    def _combine_task_result(self, result, task_result):
        return {}

    def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
        return {}

    monkeypatch.setattr(ActionModule, '_get_modules', get_modules)
    monkeypatch.setattr(ActionModule, '_get_module_args', _get_module_args)
    monkeypatch.setattr(ActionModule, '_combine_task_result', _combine_task_result)

# Generated at 2022-06-21 02:24:14.827042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:24:23.844626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.module_common import ActionBase
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import merge_hash

    action = ActionModule()

    # test 1: test result['failed'] when action_name is not setup and both modules fail
    tmp1 = None
    task_vars1 = {
        'ansible_facts': {'test1': 0},
        'ansible_facts_parallel': True,
    }
    action.run(tmp=tmp1, task_vars=task_vars1)
    result1 = action.run(tmp=tmp1, task_vars=task_vars1)
    assert result1['failed'] == False
    assert result1['skipped'] == False

# Generated at 2022-06-21 02:24:33.621544
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = {}

    tmp = None
    task_vars = None

    # create a dummy class for mocking the function for this unit test
    class Dummy_ActionModule:
        def __init__(self):
            self.ansible_facts = {}
            self.ansible_facts['_ansible_facts_gathered'] = True
            self.msg = "The following modules failed to execute: %s\n" % (', '.join(failed.keys()))

    # create an instance of dummy class
    dummy_am = Dummy_ActionModule()

    # create a class object passing dummy class and
    # assign it to a variable
    dummy_am_obj = ActionModule(Dummy_ActionModule)


    # mock the function and call the run() method

# Generated at 2022-06-21 02:24:43.264931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test object
    module = ActionModule(load_name='test.module', task=MockTask(), connection=MockConnection(tmpdir='test_dir'))

    # Setup tmp directory to be returned when _remove_tmp_path() is called
    module._remove_tmp_path = MockRemoveTmpPath(tmpdir='test_dir')

    # Setup config to return the following modules when FACTS_MODULES is read
    C.config = MockConfig(FACTS_MODULES=['test1', 'test2'])

    # Setup config to return the following connection mappings when CONNECTION_FACTS_MODULES is read
    C.config = MockConfig(CONNECTION_FACTS_MODULES={'connection1': 'connection1_module', 'connection2': 'connection2_module'})

    # Setup

# Generated at 2022-06-21 02:24:48.880764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock config
    test_config = C.Config(
        port=22,
        connections=dict(
            ansible_facts=dict(
                smart='ansible.legacy.smart'
            )
        )
    )

    # Create a mock module_loader
    test_module_loader = 'ansible.plugins.loader.module_loader.ModuleLoader'
    test_module_loader.find_plugin_with_context = lambda *args, **kwargs: 'test.module'

    # Create a mock module_utils
    test_module_utils = 'module_utils'

    # Create a mock templar
    test_templar = 'templar'

    # Create a mock display
    test_display = 'display'

    # Create a mock executor
    test_executor = 'executor'



# Generated at 2022-06-21 02:24:55.037069
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:25:04.273249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import find_plugin
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    from units.mock.loader import DictDataLoader
   