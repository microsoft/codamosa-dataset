

# Generated at 2022-06-21 02:16:24.094211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:24.619996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:25.451683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:16:25.970065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:38.241222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make temp directory to store plugins
    plugin_dir = tempfile.mkdtemp()
    # copy the plugins
    ansible_dir = os.getcwd()
    src = os.path.join(ansible_dir, 'lib', 'ansible', 'plugins')
    copy_tree(src, plugin_dir)
    # add the plugin directory to plugin loader path
    C.DEFAULT_MODULE_PATH = [plugin_dir]
    C.config.initialize()
    # we have to create a basic module so the module_loader will find it
    src = os.path.join(plugin_dir, 'action', 'test_module.py')

# Generated at 2022-06-21 02:16:40.307385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,None,None,None)



# Generated at 2022-06-21 02:16:50.521454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.utils.vars import combine_vars
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError

# Generated at 2022-06-21 02:16:55.053801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Return a tuple containing:
    # - The class instance to test
    # - The class instance to test.run's first argument
    # - The class instance to test.run's second argument
    #   (or None if 2 arguments aren't supported)
    return ActionModule(None, None, {}), {}, {'_ansible_remote_tmp': '/var/tmp', 'ansible_job_id': '1234'}

# Generated at 2022-06-21 02:17:03.806023
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # pylint: disable=too-many-nested-blocks
    # pylint: disable=invalid-name

    def mock_get_module_args(fact_module, task_vars):
        if fact_module == 'ansible.legacy.setup':
            return {'filter': '*'}
        elif fact_module == 'ansible.builtin.setup':
            return {'filter': '*'}

    def mock_execute_module(module_name, module_args, task_vars, wrap_async):
        if module_name == 'ansible.legacy.setup':
            return {'failed': False, 'ansible_facts': {'gather_subset': ['all']}}

# Generated at 2022-06-21 02:17:07.505493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule(connection='connection', task='task', play_context='play_context', loader='loader',
                          templar='templar', shared_loader_obj='shared_loader_obj')
    return actmod is not None

# Generated at 2022-06-21 02:17:30.575943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader

    module_args = dict(
        _ansible_modlib=True,
        _ansible_internal_port=2222,
        _ansible_internal_host='127.0.0.1',
        _ansible_internal_endpoint='127.0.0.1',
        ansible_internal_endpoint='127.0.0.1',
        _ansible_ssh_private_key_file='/tmp/key'
    )
    task = dict(
        action=dict(
            module='setup',
            args=module_args
        )
    )

# Generated at 2022-06-21 02:17:39.252938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _fake_get_action_args_with_defaults_method(mod_args, module_defaults, templar, action_groups):
        if module_defaults and 'gather_subset' in module_defaults:
            mod_args['gather_subset'] = [module_defaults.get('gather_subset')]
        return mod_args

    def _fake_execute_module_method(self, module_name, module_args, task_vars, wrap_async):
        if module_name in self.failing_modules:
            return {'failed': True}
        elif module_name in self.skipped_modules:
            return {'skipped': True}
        else:
            return {'ansible_fact_%s' % module_name: {}}

    module_name

# Generated at 2022-06-21 02:17:49.495946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile

    opener, tmp_path = tempfile.mkstemp()

# Generated at 2022-06-21 02:17:49.970490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule)

# Generated at 2022-06-21 02:17:50.843785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    main()

# Generated at 2022-06-21 02:17:52.893306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task = None
    am.run()

# Generated at 2022-06-21 02:18:00.891335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import test.utils.ansible_runner
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import merge_hash
    #from ansible.utils.display import Display
    from ansible.plugins.action.setup import ActionModule as setup_mod
    import ansible.module_utils.parsing.convert_bool as convert_bool
    from ansible.plugins.loader import connection_loader
   

# Generated at 2022-06-21 02:18:07.497894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import tempfile
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.facts import Facts
    from ansible.constants import DEFAULT_LOCALHOST
    from ansible.plugins.loader import connection_loader

    class MyNetworkOS:
        name = 'MyNetworkOS'
        connection = 'network_cli'

    connection_loader._module_cache = {}
    connection_loader._module_commands = {}


# Generated at 2022-06-21 02:18:19.943416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_executor = MagicMock(spec=PlayExecutor)
    mock_executor._get_global_vars.return_value = {'ansible_connection': 'local'}
    mock_play = MagicMock(spec=Play)
    mock_play._load_included_file.return_value = None
    mock_play._get_handler_block.return_value = []
    mock_play.vars = dict()
    mock_play.vars['hostvars'] = dict()
    mock_play.vars['hostvars']['localhost'] = dict()
    mock_play.vars['hostvars']['localhost']['ansible_facts'] = dict()
    mock_play.vars['hostvars']['localhost']['ansible_facts']['facter'] = dict

# Generated at 2022-06-21 02:18:20.901354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()

# Generated at 2022-06-21 02:18:50.755286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockAnsibleModule:
        def __init__(self, module_name, module_args, task_vars):
            self.module_name = module_name
            self.module_args = module_args
            self.task_vars = task_vars
            self.result = None
        def __getitem__(self, key):
            return getattr(self, key)
        
    class MockTask:
        def __init__(self, mock_args):
            self.args = mock_args
            
    class MockAnsibleRunner:
        def __init__(self):
            self.result = None
        def run(self):
            self.result = True
    
    class MockTaskVars:
        def __init__(self):
            self.ansible_facts_parallel = True
            

# Generated at 2022-06-21 02:18:57.800613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ConfigMock():
        def __init__(self):
            self.config = {
                'FACTS_MODULES': ['ansible.legacy.setup', 'ansible.legacy.file_system'],
                'CONNECTION_FACTS_MODULES': {}
            }

        def get_config_value(self, key, variables):
            return self.config[key]

    import __main__
    import unittest

    class TaskMock():
        def __init__(self, args=None):
            self.args = args or dict()
            self._parent = self
            self._parent._play = self
            self._parent._play._action_groups = dict()

    class LoaderMock():
        def __init__(self):
            self.module_loader = ModuleLoaderMock()

# Generated at 2022-06-21 02:19:01.255260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:19:10.436241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('task', (object, ), {"args": {'token': "223456"}})
    mock_play_context = type('play_context', (object, ), {"connection": "network_cli"})
    mock_loader = type('loader', (object, ), {'_shared_loader': None})
    mock_templar = type('Templar', (object, ), {'template': lambda x: x, 'is_template': lambda x: False, 'available_variables': lambda x: {}})
    mock_display = type('Display', (object, ), {})
    mock_connection = type('Connection', (object, ), {'_load_name': 'network_cli', '_shell': type('shell', (object, ), {'tmpdir': "/tmp"})})


# Generated at 2022-06-21 02:19:10.968478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Not implemented")

# Generated at 2022-06-21 02:19:20.122660
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(smart=False, modules=['test'])),
        connection=dict(name='test'),
        play_context=dict(module_defaults=dict(verbose=False)),
        templar=dict(),
        shared_loader_obj=dict(module_loader=dict(
            find_plugin_with_context=lambda m, c: dict(resolved_fqcn=m))),
        loader=dict(paths=dict(
            module_utils=['/tmp/module_utils'], module_roles=[], collection_list=[])),
        display=dict(),
        _task=dict(_parent=dict(_play=dict(_action_groups=dict())))
    )
    # Expected result of action_module.run() is a fact_module, which

# Generated at 2022-06-21 02:19:23.575287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, None, None)
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-21 02:19:32.660145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_dict = dict(
         delegate_to='localhost',
         register='fact_cache_result',
         name='setup',
         run_once=True,
         _raw_params='',
         _uses_shell=False,
         _uses_delegate=False,
         _tmpdir='/tmp/ansible-tmp-1536513304.03-299557395115597',
         _task_vars=dict(),
         args=dict(),
         _ansible_check_mode=False,
         _ansible_no_log=False,
         _ansible_task_name='setup',
         _ansible_verbosity=0,
         _ansible_version='2.5.1',
         _ansiblespec='{"version": "0.0.1"}',
    )
    test_obj = Action

# Generated at 2022-06-21 02:19:34.102373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-21 02:19:43.827489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ansible.plugins.action.setup.ActionModule(connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
  result = module.run(tmp='tmp', task_vars='task_vars')
  assert result['ansible_facts'] == {}
  assert result['ansible_facts']['_ansible_facts_gathered'] == True
  assert result['_ansible_verbose_override'] == True
  assert result['failed'] == True
  assert result['failed_modules'] == failed
  assert result['msg'] == "The following modules failed to execute: %s\n" % (', '.join(failed.keys()))
  assert result['skipped'] == True
  assert result['skipped_modules'] == skipped

# Generated at 2022-06-21 02:20:37.076820
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:20:39.611843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('setup', '/tmp/foo', {}, {}, 'localhost')

# Generated at 2022-06-21 02:20:41.065311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:43.152698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None


# Generated at 2022-06-21 02:20:46.079272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of class ActionModule
    obj = ActionModule()
    # check the value of _supports_check_mode and _supports_async of the instance
    assert obj._supports_check_mode and not obj._supports_async


# Generated at 2022-06-21 02:20:57.455871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.task import Task

    loader = DataLoader()

# Generated at 2022-06-21 02:21:04.785534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule({
        'name': 'setup',
        'args': {'filter': '*'},
    }, [], [], None)
    # returns a dict with keys: ['failed_modules', 'skipped_modules', 'failed', 'ansible_facts']
    mod.run(None, {
        'groups': {'all': ['test_host']},
        '_run_did_create_tmpdir': True,
        '_ansible_tmpdir': '/tmp',
    })

# Generated at 2022-06-21 02:21:16.387570
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Some unit tests
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.template import Templar

    mytemplar = Templar(loader=None)
    mytaskvars = dict()
    mock_action_module = ActionModule(loader=None, play_context=PlayContext(), task_vars=mytaskvars)
    mock_action_module.set_loader(None)
    mock_action_module.set_shared_loader_obj(None)
    mock_action_module.set_task_vars(mytaskvars)
    mock_action_module._templar = mytemplar

    mock_action_module._execute_module = my_execute_module

# Generated at 2022-06-21 02:21:21.718117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import module_loader
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.utils.plugin_docs as plugin_docs
    import os

    module_loader.add_directory(C.DEFAULT_MODULE_PATH)

    play_context = PlayContext()

    module = module_docs.AnsibleModuleDocs('setup', '/home/cas/software/ansible-2.9.11/lib/ansible/modules/system/setup.py')
    task = dict(action=dict(module='setup'))
    tmp = '/tmp'
    task_vars = dict()

    test_obj = ActionModule(task, play_context, new_stdin=None)
    test_obj.task_vars = task_vars

# Generated at 2022-06-21 02:21:26.025528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the ActionModule class with a valid task
    action_mod = ActionModule(task=dict(action='setup', args=dict(filter='ansible_local')))
    # retrieve the task that was passed to the constructor
    task = action_mod._task
    # Assert that an _execute_module method exists which is callable
    assert hasattr(action_mod, '_execute_module')
    assert callable(getattr(action_mod, '_execute_module'))
    # Assert that attributes were set correctly
    assert isinstance(task, dict)
    assert task['action'] == "setup"
    assert task['args']['filter'] == "ansible_local"


# Generated at 2022-06-21 02:23:20.652491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    tmp = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
    )
    task = Task()
    ActionModule.run(tmp, task)

# Generated at 2022-06-21 02:23:33.389652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = "TESTING_HOSTNAME"
    tmp_path = "TESTING_TMP_PATH"
    task_vars = {'ansible_facts_parallel': False}
    action_base = ActionBase()
    action_module = ActionModule(host_name, action_base.task, action_base.connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    actual_result = action_module.run(tmp_path, task_vars)

    # assert result keys
    expected_result_keys = set(['ansible_facts', 'failed', 'failed_modules', 'msg', 'skipped', 'skipped_modules'])
    actual_result_keys = set(actual_result.keys())

# Generated at 2022-06-21 02:23:43.528610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args, AnsibleExitJson

    module = 'setup'
    python_interpreter = '/usr/bin/python'
    context = MagicMock()
    task_vars = dict()

    def async_wrapper():
        def wrapped_f(module_name, module_args, task_vars, *args, **kwargs):
            def async_status():
                def wrapped_p(module_name, module_args, task_vars, *args, **kwargs):
                    return dict(finished=1, ansible_facts=dict(date='20190922'))
                return wrapped_p

           

# Generated at 2022-06-21 02:23:54.275265
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:24:04.327443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import connection_loader

    class MyModule(object):
        def __init__(self, name='network_cli', *args, **kwargs):
            self.name = name
            self.args = kwargs
            self.collections = []
            self.action = "setup"
            self.load_name = "network_cli"
            self.parent = object()
            self.vars = {}

    mod = MyModule()
    mod.vars['ansible_facts_parallel'] = False
    mod.vars['FACTS_MODULES'] = ''
    mod.vars['CONNECTION_FACTS_MODULES'] = ''
    mod.args['network_os'] = 'eos'
    mod.args['gather_subset'] = []

# Generated at 2022-06-21 02:24:06.939016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert actionmodule, "constructor of class ActionModule failed"


# Generated at 2022-06-21 02:24:15.021244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import plugins
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash

    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {}
    plugins.add_plugin(TestActionBase, 'test_action')

    class TaskModule(object):
        def __init__(self, args):
            self.args = args

    class Task(object):
        def __init__(self, module, collections=None):
            self.module_defaults = {}
            self.module = module

# Generated at 2022-06-21 02:24:17.971430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    ActionModules with simple keys and values

    '''
    assert ActionModule() is not None



# Generated at 2022-06-21 02:24:19.776479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-21 02:24:21.817344
# Unit test for constructor of class ActionModule
def test_ActionModule():

    actionModule = ActionModule()
    assert isinstance(actionModule, ActionModule)