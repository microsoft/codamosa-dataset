

# Generated at 2022-06-21 02:16:21.000684
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule().get_action_args() == {}

# Generated at 2022-06-21 02:16:21.423251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()

# Generated at 2022-06-21 02:16:29.045526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.six as six
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    class LocalRunner():
        def __init__(self):
            self.loader = DataLoader()
            self.local_tqm = TaskQueueManager()
            self.playbook_dir = ''
            self.variable_manager = VariableManager()

# Generated at 2022-06-21 02:16:32.061388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__init__')
    assert callable(ActionModule.__init__)


# Generated at 2022-06-21 02:16:35.369558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor
    actmod = ActionModule(None, None, None, None)
    assert actmod._supports_check_mode is True

# Generated at 2022-06-21 02:16:42.354800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action

    def _create_task(collection_imports=None):
        from ansible.playbook.task import Task

        _collection_imports = collection_imports or []
        _task = Task()
        _task._parent = _task
        _task._role = None
        _task._stack = []
        _task.loop = None
        _task.collections = _collection_imports
        return _task

    def _create_task_executor(host, connection):
        from ansible.executor.task_executor import TaskExecutor


# Generated at 2022-06-21 02:16:43.779327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 02:16:48.331420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    action = TestActionModule({'PARAMETERS': {}}, mock.MagicMock(), 'tmp')
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:16:49.140458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 02:16:53.377558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._supports_check_mode == True
    assert action._supports_async == True


# Generated at 2022-06-21 02:17:06.779691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {}
    actionmodule = ActionModule(None, module_args)
    assert actionmodule is not None

# Generated at 2022-06-21 02:17:19.509423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test runs with a basic set of arguments and checks that it runs without errors
    # It doesn't test the output of the modules, only that they run
    action = ActionModule()

# Generated at 2022-06-21 02:17:21.790157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule()
    assert actmod is not None, "ActionModule creation failed"

# Generated at 2022-06-21 02:17:30.574629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init args
    tmp = None
    task_vars = {}
    # init ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # init method run
    result = action_module.run(tmp=tmp, task_vars=task_vars)
    print(result)
    assert result == {'changed': False, '_ansible_no_log': False, '_ansible_verbose_override': True, 'ansible_facts': {'_ansible_facts_gathered': True}, 'failed': False}


# Generated at 2022-06-21 02:17:38.249728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_loader, modified_paths = _create_module_loader()

    # Construct nested ActionModule
    shell = 'network_cli'
    play_context = PlayContext()

    # Make action plugin
    action_plugin = ActionModule(task=None, connection=None, play_context=play_context, loader=module_loader, templar=mock_templar, shared_loader_obj=None)
    assert isinstance(action_plugin, ActionModule)
    return action_plugin

# Generated at 2022-06-21 02:17:49.140418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test:
    import ansible.executor.task_queue_manager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.parsing.dataloader
    from ansible.executor.task_result import TaskResult
    import ansible.playbook.task
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.utils.plugin_docs
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    import ansible.vars.unsafe_proxy

    # Assert method exists.

# Generated at 2022-06-21 02:17:49.639274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:17:59.848865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    cwd = os.path.dirname(os.path.realpath(__file__))
    config_path = os.path.join(cwd, 'fixtures', 'ansible.cfg')
    os.environ['ANSIBLE_CONFIG'] = config_path

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import find_action_plugin
    from ansible.plugins.loader import find_callback_plugin
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

# Generated at 2022-06-21 02:18:10.329762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_vars(self):
        return dict()

# Generated at 2022-06-21 02:18:11.033686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-21 02:18:35.967029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test creation with no parameters
    am = ActionModule()
    assert am._supports_check_mode == True
    assert am._supports_async == False
    assert am._async_timeout == 0
    assert am._supports_async == False
    assert am._supports_consecutive_commands == False
    assert am._supports_parallel == False
    assert am._supports_persistent_connections == False
    assert am._timeout == 10
    assert am._connection is None
    assert am._task is None
    assert am._tmp is None
    assert am._display is None

# Generated at 2022-06-21 02:18:44.578393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.context import CLIContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system import SystemCollector
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    import sys

    context.CLIARGS = CLIContext()
    context.CLIARGS._load_config_file()

    display = Display()
    display.verbosity = 2
    sys.stdout = display

    am = action_loader.get('setup', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.task = dict

# Generated at 2022-06-21 02:18:47.544528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionmod is not None

# Generated at 2022-06-21 02:18:59.217367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import find_plugin_file
    from ansible.inventory import Inventory
    from collections import namedtuple
    from io import StringIO
    import json
    import pytest


# Generated at 2022-06-21 02:19:09.792039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    # The following action_plugin is used for testing.
    # class ActionModuleTest(ActionModule):
    #     def run(self, tmp=None, task_vars=None):
    #         self._supports_check_mode = True
    #         result = super(ActionModuleTest, self).run(tmp, task_vars)
    #         result['ansible_facts'] = {}
    #         result['_ansible_verbose_override'] = True
    #         return result

   

# Generated at 2022-06-21 02:19:13.364646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run()
    #assert result == "The following modules failed to execute: %s\n", (', '.join(failed.keys()))
    #assert result == "The following modules were skipped: %s\n", (', '.join(skipped.keys()))



# Generated at 2022-06-21 02:19:20.232237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create temporary file to write key value pairs into
    with tempfile.NamedTemporaryFile() as vars_file:
        vars_file.write(b'ansible_connection: happ')
        vars_file.flush()
        task_vars = dict()
        tmp = tempfile.mkdtemp()
        task = dict(action=dict(module_name='setup', module_args=dict()))
        action_module = ActionModule(task, tmp, task_vars)
        result = action_module.run(tmp, task_vars)
        assert result['ansible_facts']['ansible_connection'] == 'happ'

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:19:28.338750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Connection:
        def __init__(self):
            self._load_name = 'test_connection'
            self.tmpdir = 'test_tmpdir'

    class Task:
        def __init__(self):
            self._parent = 'test_parent'
            self.args = {'parallel': True}
            self.collections = ['test_collection']

    class SharedLoaderObj:
        def __init__(self):
            self.module_loader = 'test_module_loader'

    class Display:
        def __init__(self):
            self.vvvv = 'test_vvvv'
            self.warning = 'test_warning'

    class ActionBase:
        def __init__(self):
            self._templar = 'test_templar'
            self._task = Task()
            self

# Generated at 2022-06-21 02:19:34.856369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("===test_ActionModule_run===")
    # print("")
    action_module = ActionModule()
    action_module.task_vars = {}
    result = action_module.run(task_vars={})
    print(result)


# test_ActionModule_run()

# Generated at 2022-06-21 02:19:44.086361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance of class ActionModule
    action_module = ActionModule()

    # create fake input
    fake_task_vars = {'ansible_facts': {'os': {'name': 'solaris'}}}

    # create fake output
    fake_res = {'ansible_facts': {},
                'warnings': [],
                'deprecations': []}
    expected_res = {'ansible_facts': {'_ansible_facts_gathered': True, 'os': {'name': 'solaris'}},
                    'warnings': [],
                    'deprecations': [],
                    '_ansible_verbose_override': True}

    # fake the method _combine_task_result
    action_module._combine_task_result = lambda x, y: y

    # fake

# Generated at 2022-06-21 02:20:36.221549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Ensure correct functionality of _run method in ActionModule.
    """
    # create an instance of ActionModule to test
    action = ActionModule()

    # create a mock module to return result of _execute_module call
    module = MagicMock(return_value = {'changed': False, 'warnings': [], 'deprecations': [], 'failed': False})
    action._execute_module = module

    # create a mock _task to return args and module_defaults to test
    task = MagicMock()
    task.args = {'testarg' : 'testval', 'testarg2' : 'testval2'}
    task.module_defaults = {'testmd' : 'testmoduledefaults value'}
    action._task = task

    # create a mock _templar to return values into args from test module

# Generated at 2022-06-21 02:20:47.341161
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import os
    import tempfile
    import shutil
    import mock
    import pprint

    import ansible.module_utils.ansible_release as AR
    import ansible.utils.vars

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils.ansible_release'] = mock.Mock()
    sys.modules['ansible.module_utils.ansible_release'].ansible_version = \
        mock.Mock(return_value=AR.AnsibleVersion(full_version='2.5.5'))
    sys.modules['ansible.module_utils.ansible_release'].__version__ = '2.5.5'
    sys.modules['ansible.utils'] = mock.Mock()

# Generated at 2022-06-21 02:20:58.119561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager

    # Create new task
    task = Task()

    # Create new play and set defaults

# Generated at 2022-06-21 02:21:00.141391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='setup')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 02:21:04.861430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We are testing the constructor of class ActionModule, so we need a connection object to pass to it
    # Storing the connection object in the test_connection.py file and importing it to use it
    from test_connection import Connection

    # Initializing connection object
    conn = Connection()

    # Create the instance of ActionModule class and return the result
    action = ActionModule(conn)
    return action

# Generated at 2022-06-21 02:21:07.232727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:21:09.829821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run(tmp='abc')
    assert type(result) == dict

# Generated at 2022-06-21 02:21:11.203726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:21:14.135003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 02:21:15.967983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:23:12.992835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._remove_tmp_path = MagicMock()

    # Test case when modules is 'smart'
    m._task.args = {'network_os': 'arista_eos'}
    m._task._parent._play._action_groups = {'setup': {'gather_subset': ['all']}}
    m._connection._connection._shell.tmpdir = "/tmp"
    m._connection._load_name = 'local'
    m._task.args = {'network_os': 'arista_eos'}
    m._task.module_defaults = {}
    m._templar = {}
    m._display.vvvv = MagicMock()
    m._execute_module = MagicMock()

# Generated at 2022-06-21 02:23:13.418499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:19.147288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_text
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.executor import ActionModuleExecutor
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.module_utils.common.dict_transformations import dict_merge
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    action_plugin = action_loader.get('setup')
    executor = ActionModuleExecutor()



# Generated at 2022-06-21 02:23:20.425816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    assert ActionModule()

# Generated at 2022-06-21 02:23:23.954477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = ActionModule()
    assert c.run()

# Generated at 2022-06-21 02:23:34.553973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import json
    import tempfile
    import shutil
    import unittest
    import ansible.plugins.action.setup

    class ActionModuleFactsModuleUnitTest(unittest.TestCase):

        # Test Fixture:
        #
        # Create a temporary directory and navigate to it.
        #
        # Create two temporary files and write json data to them.
        # one file will be the ansible_job_result.txt
        # other file will be the ansible_job_status.txt
        #
        # Create a facts module, setup module and a custom module
        #
        # Write a configuration file to indicate that the setup plugin
        # is the facts module.
        #

        def setUp(self):
            # Create a temporary directory for the tasks to be executed.
            self.temp_dir = tempfile

# Generated at 2022-06-21 02:23:35.028277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:23:37.263434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_get_module_args')
    assert hasattr(ActionModule, '_combine_task_result')
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:23:41.992196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader_obj = None
    templar_obj = None
    task_obj = None
    shared_loader_obj = None
    display_obj = None
    ansible_module_obj = ActionModule(loader_obj, shared_loader_obj, templar_obj, task_obj, display_obj)

    assert ansible_module_obj._supports_check_mode == True

# Generated at 2022-06-21 02:23:44.552565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.__class__.__name__ == 'ActionModule'