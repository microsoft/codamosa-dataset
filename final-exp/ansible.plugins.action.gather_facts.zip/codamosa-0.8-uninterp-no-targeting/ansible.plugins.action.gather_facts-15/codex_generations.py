

# Generated at 2022-06-21 02:16:29.473922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a new ActionModule() object
    action_module = ActionModule()
    # Initialize a new ModuleLoader() object
    from ansible.plugins.loader import ModuleLoader
    module_loader = ModuleLoader()
    # Add a new module: 'test_module'
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_module_dir'))
    for path in module_loader._get_paths():
        module_loader.find_plugins(path)
    module_loader.set_module_name('test_module')
    # Set 'action_module' attribute: _shared_loader_obj
    action_module._shared_loader_obj = module_loader

    # Initialize a new Task() object
    from ansible.playbook.task import Task

# Generated at 2022-06-21 02:16:35.080937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_dict = {'name': 'gather_all_facts'}
    host_vars = dict()
    host_vars['hostname'] = 'server.example.com'
    host = 'server.example.com'  # Using the hostname as the `host` to avoid KeyError
    task_vars = dict()
    task_vars['hostvars'] = {'server.example.com': host_vars}
    task_vars['hostvars'][host_vars['hostname']] = host_vars
    task_vars['group_names'] = ['ungrouped']
    task_vars['groups'] = {'ungrouped': {'hosts': ['server.example.com']}}

# Generated at 2022-06-21 02:16:42.197684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # load test data
    conn = NetworkConnection()
    task_vars = {"ansible_network_os": "ios", "ansible_connection": "network_cli"}

    # create the play
    play = Play()

    # create the task
    task = Task()
    task._parent = play
    task._play = play
    task._task_vars = task_vars
    task._block = {}
    task._role = None

    # create the action
    action = ActionModule(task=task, connection=conn, play_context=PlayContext())
    action._task = task
    action._connection = conn
    action._play_context = PlayContext()
    action._loader = DictDataLoader({})
    action._templar = Templar(loader=action._loader, variables=task_vars)
    action._shared

# Generated at 2022-06-21 02:16:51.202281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make sure things are working

    # dummy store for task data
    class dummy(object):
        pass

    # test against a fake task
    task_vars = {'ansible_verbosity': 2,
                 'ansible_module_name': 'ansible.module',
                 'ansible_module_args': {'foo': 'bar'}}
    module_name = 'ansible.legacy.debug'
    task = dummy()
    task.args = {}
    task.module_defaults = {}
    task.collections = []
    task_vars = {'ansible_verbosity': 2,
                 'ansible_module_name': 'ansible.module',
                 'ansible_module_args': {'foo': 'bar'}}
    module_name = 'ansible.legacy.debug'
    task

# Generated at 2022-06-21 02:17:00.863485
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action.setup import ActionModule as setup
    from ansible.utils.vars import combine_vars

    task = DummyTask()
    connection = DummyConnection()
    task.action = 'setup'
    task.args = {
        'filter': 'ansible_distribution*',
    }
    task.tqm = {
        '_fact_cache': {},
        '_stdout_callback': None,
    }
    task._task_vars = {
        'ansible_facts_parallel': True,
        'ansible_connection': 'local',
        'ansible_inventory_sources': ['localhost'],
    }
    connection._shell.tmpdir = '/tmp'

# Generated at 2022-06-21 02:17:10.130855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = get_test_connection()
    m = get_test_module()
    m._task.args = {'test': 'arg'}

    # create an instance of the ActionModule action plugin
    a = ActionModule(c, m._task, m._connection, m._play_context, loader=m._loader, tempdir=m._templar._tempdir, shared_loader_obj=m._shared_loader_obj)

    # execute the ActionModule run method
    result = a.run(task_vars={'test_task_vars': 'test'})

    # ensure the following keys exists in the result:
    # failed, msg, skipped_modules, ansible_facts, skipped, ansible_facts_gathered, ansible_job_id, changed, _ansible_verbose_override, warnings, _ansible_

# Generated at 2022-06-21 02:17:11.062468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:17:14.940414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # line required for test to work with python 2

    print("test_ActionModule_run")

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:17:17.663139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(loader=None, task=None, connection=None, play_context=None, loader_posix=None, loader_windows=None, variable_manager=None, templar=None)

# Generated at 2022-06-21 02:17:19.129071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:17:38.911560
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod = ActionModule()

    config = C.config.get_config_value('FACTS_MODULES')
    module_name = config[0]
    mod_args = {'gather_subset': 'all'}

    parent = {'_action_groups': None, '_play': None, '_task': None, '_role': None, '_parent': None, '_loader': None, '_data': None, 'args': None, 'action': None, 'action_args': None}

# Generated at 2022-06-21 02:17:49.398265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act = ActionModule()
    act._supports_check_mode = True
    act._connection = lambda : None
    act._connection._load_name = 'local'
    act._connection._shell = lambda : None
    act._connection._shell.tmpdir = '~~~'

    act._task = lambda : None
    act._task._parent = lambda : None
    act._task._parent._play = lambda : None
    act._task._parent._play._action_groups = {'all': ['setup']}
    act._task._parent._play._delegate_to = None

    act._task.args = {'FACTS_MODULES': 'fake'}

    act._shared_loader_obj = lambda : None
    act._shared_loader_obj._loaded_plugins = []
    act._shared_loader_obj.module_

# Generated at 2022-06-21 02:17:59.789820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import yaml
    from ansible.utils.color import colorize, hostcolor
    from ansible.plugins.action import ActionModule

    module_args = dict(
        gather_subset=['!all'],
        gather_timeout=10,
        filter='ansible_distribution*',
    )

    m_config = dict(
        FACTS_MODULES = ['ansible.legacy.setup'],
        CONNECTION_FACTS_MODULES = {'ansible.legacy.local': 'ansible.legacy.setup'},
    )

    m_task = dict(
        args = module_args,
        module_defaults = {'gather_subset': '!all', 'gather_timeout': 10, 'filter': 'ansible_distribution*'},
    )

# Generated at 2022-06-21 02:18:10.299577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN the following simple task
    task = {
        "args": {
            "gather_subset": [
                "all"
            ],
            "gather_timeout": 10
        }
    }

    # GIVEN the following inventory with a single host
    inventory = {
        "localhost": {
            "hosts": [
                "localhost"
            ]
        }
    }

    # GIVEN an empty variable manager
    variable_manager = {}

    # GIVEN a single play in the play book
    play_context = {
        "play": {
            "name": "one_play"
        }
    }

    # GIVEN a single task in the play

# Generated at 2022-06-21 02:18:10.737173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:11.196521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:21.303967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.executor.task_result

    module = ansible.action.ActionModule(
        task=ansible.playbook.task.Task(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 02:18:31.965472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import six
    if six.PY3:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    else:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes as AnsibleUnsafeText

    class MockConnection(object):
        class _shell(object):
            tmpdir = 'tmpdir'

        def __init__(self, load_name):
            self._load_name = load_name

    class MockTask(object):
        class _parent(object):
            class _play(object):
                _action_groups = {}

        def __init__(self, args):
            self.args = args


# Generated at 2022-06-21 02:18:33.270094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:43.443234
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.network.ansible_nxos.facts.facts import Facts

    mock_task_obj = mock.Mock()
    mock_task_obj.run = mock.Mock()
    mock_task_obj.run.__class__ = Facts
    mock_task_obj.args = {'gather_subset':['all']}
    mock_task_obj.args['filename'] = os.path.join(
        os.path.dirname(
            os.path.dirname(__file__)),
        'ml2_conf.ini')

    action_obj = ActionModule(mock_task_obj, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    mock_task_obj.args = {}
    result = action

# Generated at 2022-06-21 02:19:04.504932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:19:09.367185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    common_args = dict(name='test', play=dict(play=None, uid='testing'))
    common_args.update(my_action='setup', module_defaults=[], task_included=False)
    task = AnsibleTask(**common_args)
    action_base = ActionBase(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_base is not None

# Generated at 2022-06-21 02:19:11.182926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:19:12.062829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:19:16.612313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-21 02:19:24.162514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # A simplistic unit test to demonstrate how to test the constructor
    class MockClass:
        pass
    task = MockClass()
    task.task_vars = dict()
    task.task_vars['role_name'] = "test_role"
    task.task_vars['username'] = "test_user"
    task.task_vars['password'] = "test_password"
    task.task_vars['timeout'] = 2
    task.task_vars['provider'] = dict()
    task.task_vars['provider']['host'] = "localhost"
    task.task_vars['provider']['port'] = 8001
    task.task_vars['provider']['username'] = "test_user"

# Generated at 2022-06-21 02:19:32.853554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result

    from ansible.module_utils.facts.system.base import (
        get_file_content, get_file_lines, get_mount_size, represents_int,
        split_file_lines, get_file_size, get_file_blocks, get_file_inode,
        get_file_uid, get_file_gid, get_file_mode, get_file_selinux
    )

    from ansible.module_utils.facts.system.distribution import distribution
    from ansible.module_utils.facts.system.distribution import get_distribution
    from ansible.module_utils.facts.system.distribution import parse_etc_os_release
    from ansible.module_utils.facts.system.distribution import parse_etc_system_release
   

# Generated at 2022-06-21 02:19:33.732713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:19:35.225941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(1, 2, 3)

# Generated at 2022-06-21 02:19:36.139881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:21.458911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert am

# Generated at 2022-06-21 02:20:22.194117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:23.059353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:28.674600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pprint
    from ansible.plugins.action.setup import ActionModule as setup_ActionModule
    from ansible.runner.return_data import ReturnData
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.executor.task_result import TaskResult
    import ansible.constants as C
    import ansible.executor.module_common as mc

    C.FACTS_MODULES = ['setup']
    C.config = MagicMock(spec=True)
    C.config.get_config_value = MagicMock(return_value='smart')
    C.config.get_config_value.return_value = ['setup']

# Generated at 2022-06-21 02:20:31.035513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # instantiate object for testing constructor
    test_module_action = ActionModule()

    # assert that run module was not called
    assert test_module_action.run_module == {}

    # assert that the fact cache did not get populated
    assert test_module_action._fact_cache == {}

    # assert empty result
    assert test_module_action.result == {}

# Generated at 2022-06-21 02:20:34.976491
# Unit test for constructor of class ActionModule
def test_ActionModule():

    success_action_module = ActionModule()

    test_module_args = dict(key1='value1', key2='value2')

    assert success_action_module._supports_check_mode == True
    assert success_action_module._task.args == {}
    assert success_action_module._connection.port == 22 
    assert success_action_module._task.name == 'setup'
    assert success_action_module._task.args == {}
    assert success_action_module._task.module_defaults == {}
    assert success_action_module._task.action_loader.get_all_actions() == ['ping', 'meta', 'setup']

# Generated at 2022-06-21 02:20:46.933989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_facts_parallel = None
    args = {'network_os': 'foobar'}
    constants = {'config': {'get_config_value': ['FACTS_MODULES', 'CONNECTION_FACTS_MODULES']}}
    constants['config']['get_config_value'][1] = 'CONNECTION_FACTS_MODULES'
    extras = {'module_loader': {'find_plugin_with_context': 'ansible.legacy.setup'}, 'templar': 'templar', 'task': {'args': args, '_parent': 'parent', '_play': {'_action_groups': '_action_groups'}}}

    generated_module_args = {'filter': 'ansible_facts.test_key'}
    generated_module_args

# Generated at 2022-06-21 02:20:57.928951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleActionFail
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.setup import ActionModule as Am
    from ansible.utils.context_objects import AnsibleContext
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import ROLE_CACHE
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.network.common.utils import load_provider

# Generated at 2022-06-21 02:21:05.469917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()
    assert action_module_obj is not None

    # check object attributes
    assert action_module_obj._supports_check_mode is True
    assert action_module_obj._display is None
    assert action_module_obj._task is None
    assert action_module_obj._connection is None
    assert action_module_obj._play_context is None
    assert action_module_obj._templar is None
    assert action_module_obj._loader is None
    assert action_module_obj._shared_loader_obj is None

# Generated at 2022-06-21 02:21:16.778030
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:23:08.022665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import shutil
    from ansible.plugins.loader import find_plugin, action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    loader = action_loader
    assert loader is not None

    # We need to remove the built-in cp module so that ansible.builtin.copy
    # is used instead.
    global _MODULE_CACHE  # pylint: disable=global-statement
    if 'copy' in _MODULE_CACHE:
        del _MODULE_CACHE['copy']
        del _MODULE_CACHE['ansible.builtin.copy']

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')

# Generated at 2022-06-21 02:23:09.765520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:23:10.960505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-21 02:23:22.658762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context

    # construct python object for class Module
    module_ = ActionModule()

    # constructor test
    assert isinstance(module_, ActionModule)

    # test __init__() is called
    module_._task.passed = False
    module_._task.failed = False
    module_._task.skipped = False
    module_._task.vars = {}
    module_._task.action = 'setup'
    module_._task.module_defaults = {'network_cli': {'gather_subset': 'all'}}
    module_._task._parent = {'_play': {'_action_groups': {'setup': ['network_cli']}}}
    module_._task.args = {}

    # call method with positional arguments
    # None

    # call method with named arguments
    #

# Generated at 2022-06-21 02:23:23.953532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:24.575722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO(showard): implement test case for test_ActionModule_run()

# Generated at 2022-06-21 02:23:33.847588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test module import
    from ansible.plugins.action.setup import ActionModule

    # Test class instantiation
    result_am = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert isinstance(result_am, ActionModule)
    assert result_am._connection is None
    assert result_am._task is None
    assert result_am._loader is None
    assert result_am._templar is None
    assert result_am._shared_loader_obj is None
    assert result_am._play_context is None

# Generated at 2022-06-21 02:23:36.850195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    assert False



# Generated at 2022-06-21 02:23:37.578550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:23:39.280057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run() == {
        "failed": False,
        "_ansible_verbose_override": True,
        "ansible_facts": {
            "_ansible_facts_gathered": True
        }
    }