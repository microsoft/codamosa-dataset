

# Generated at 2022-06-21 02:16:23.939006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('setup')

    assert am is not None

# Generated at 2022-06-21 02:16:30.746501
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiation of the class to be tested
    am = ActionModule('ActionModule module')
    am._templar = None
    am._display = 'none'
    am._shared_loader_obj = None
    am._connection = None
    am._task = None
    am._task_vars = None
    am._supports_check_mode = True
    am._delete_remote_tmp = True
    am._tmp = None
    am._remote_tmp = 'tmp/path'
    result = am.run()

    # Check result to make sure it is not empty
    assert result != {}, 'The result should not be empty'

# Run the unit test with 'python unit_test.py'
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:16:31.376903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """"""
    assert(ActionModule)

# Generated at 2022-06-21 02:16:39.347741
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.loader import shared_loader_obj
    from ansible.plugins.loader import find_plugin

    # actual data
    connection = Connection(None)
    shared_loader_obj = shared_loader_obj()
    env = Environment()
    tmp = ''
    task_vars = {}

    # data setup
    task = Task()
    task_ex = Executor(None)
    display = Display()
    _templar = Templar(config_template_path=C.ANSIBLE_TEMPLATE_DIR, shared_loader_obj=shared_loader_obj)
    connection._shell = Shell(display, shell='')
    connection._shell.tmpdir = ''

# Generated at 2022-06-21 02:16:40.170334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:16:42.432590
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Parameters
    tmp = None
    task_vars = None

    action_module = ActionModule(tmp, task_vars)

    # Call run method
    result = action_module.run(tmp, task_vars)
    
    # Assertion
    assert result is not None

# Generated at 2022-06-21 02:16:43.288998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

# Generated at 2022-06-21 02:16:46.604033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    module_name = ''
    module_args = ''
    task_vars = ''
    tmp = ''
    action_module.run(tmp, task_vars)

# Generated at 2022-06-21 02:16:53.581672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Module configuration
    basic_module_args = {
        'name': 'localhost',
        'gather_subset': 'min',
        'gather_timeout': 10,
        'filter': '*'
    }
    
    task_vars = {}

    # Create a action module instance
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Execute run method of the action module
    result = am.run(tmp=None, task_vars=task_vars)

    # Asserts
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True

# Generated at 2022-06-21 02:16:54.153689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:17:19.423661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils._text import to_bytes
    import ansible.plugins.loader


# Generated at 2022-06-21 02:17:30.664018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test variables
    task_args = {'test': False }
    task_vars = {'ansible_network_os': 'junos'}
    tmp = '/root/test'
    tmp_path_for_task_result = '/root/test/result'

    # test ActionBase.run
    action = ActionBase()
    action.connection = MockConnection()
    action.connection._shell = MockShell()
    action.connection._shell.tmpdir = tmp
    action.connection._shell._make_tmp_path.return_value = tmp_path_for_task_result
    action.connection._shell.action_write_clean.return_value = True
    action._task = MockTask(action, task_args, task_vars)
    action._task.action = 'setup'
    action._task.args = task_

# Generated at 2022-06-21 02:17:39.325922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.connection import Connection as AnsibleConnection
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.text.converters import to_text

    # TODO: refactor this when #31170 is merged
    def _mock_connection_class(connection_class=None, params=None):
        if connection_class is None:
            connection_class = AnsibleConnection

        class _TempConnectionClass(connection_class):
            if C.HAS_ATTRIBUTE:
                transport = 'network_cli'


# Generated at 2022-06-21 02:17:48.648517
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils.six import StringIO
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    temp_stdout = StringIO()
    new_task_result = TaskResult(host=None, task=None, task_fields={'name': 'module_name', 'args': 'module_args'}, stdout=temp_stdout, stderr=temp_stdout)
    new_play_context = PlayContext()
    new_play_context.become = True
    new_play_context.become_method = 'sudo'
    new_

# Generated at 2022-06-21 02:17:52.237253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:17:53.120505
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-21 02:18:00.969006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager

    class ModuleManager:
        def _write_debug_module(self, *args, **kwargs):
            pass

        def load_module_spec(self, *args, **kwargs):
            pass

        def update_module_args(self, *args, **kwargs):
            return "test_module"

        def get_module_path(self, *args, **kwargs):
            return "test_module_path"

        def _get_module_name(self, *args, **kwargs):
            return "test_module_name"


# Generated at 2022-06-21 02:18:07.605281
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:18:19.977605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = AnsibleTaskVars()
    task.args = dict(a=1, b=2, c=3)

    task_vars = dict(a=10, b=20, c=30)

    tmpdir = tempfile.mkdtemp()
    tmpdir_module = os.path.join(tmpdir, 'module')
    os.mkdir(tmpdir_module)
    os.mkdir(os.path.join(tmpdir_module, 'ansible'))
    os.mkdir(os.path.join(tmpdir_module, 'ansible', 'legacy'))

# Generated at 2022-06-21 02:18:31.344936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
      All the unit test code for class ActionModule

      To run the unit test for this method run "python -m test.units.modules.action.test_action_module test_ActionModule_run"
    """
    from words import TestExecutor
    from collections import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # First create stub objects for all the arguments
    tmp = '/tmp/ansible_test'
    task_vars = {'ansible_network_os': 'ios'}
    executor = TestExecutor()
    executor.task = namedtuple('action', ['args'])({'parallel': True})

# Generated at 2022-06-21 02:18:56.854406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(connection=None,
                                task=None,
                                play_context=None,
                                loader=None,
                                templar=None,
                                shared_loader_obj=None)

    assert(actionModule)

# Generated at 2022-06-21 02:19:06.911186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raw_executor = AnsibleRuntimeExecutor()
    action_base = ActionBase()
    action_module = ActionModule(raw_executor, action_base, "setup")
    task_vars = {}
    result = action_module.run(None, task_vars)
    assert result['_ansible_verbose_override'] is True
    assert result['ansible_facts']['_ansible_facts_gathered'] is True
    assert result['ansible_facts']['_ansible_no_log'] is True

# Generated at 2022-06-21 02:19:15.556015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base_obj = ActionBase()
    action_module_obj = ActionModule(action_base_obj._task, action_base_obj._connection, action_base_obj._play_context, action_base_obj._loader, action_base_obj._templar, action_base_obj._shared_loader_obj)
    assert action_module_obj._shared_loader_obj == action_base_obj._shared_loader_obj, "Test Case Failed"

# Generated at 2022-06-21 02:19:16.778927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._supports_check_mode is True

# Generated at 2022-06-21 02:19:24.311180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = PlaybookExec

# Generated at 2022-06-21 02:19:30.776635
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    result = module.run(tmp=None, task_vars={'ansible_facts_parallel': False, 'ansible_facts': {'network_os': 'ios_xr'}, 'ansible_connection': 'network_cli', 'connection': 'network_cli'})

    assert result['ansible_facts'] == {'_ansible_facts_gathered': True}
    assert result['warnings'] == []
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['_ansible_verbose_override'] == True


# Generated at 2022-06-21 02:19:40.014121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader, internal_loader, paths, filters = C.config._get_config_files()
    tmp_tqm = C.TaskQueueManager(
        loader=loader,
        internal_loader=internal_loader,
        variable_manager=C.VariableManager(loader=loader, variable_factories=C.get_fact_cache()),
        host_list=[C.DEFAULT_HOST_LIST],
        stdout_callback=C.Display(),
        passwords={}
    )
    action_module = ActionModule(tmp_tqm, None, 'setup')
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-21 02:19:41.843322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule({}, 'something')
    assert action_module

# Generated at 2022-06-21 02:19:50.045138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_self = 'mock_self'
    mock_loader = 'mock_loader1'
    mock_templar = 'mock_templar1'
    mock_shared_loader_obj = 'mock_shared_loader_obj1'
    mock_task = 'mock_task1'

    am = ActionModule(mock_self, mock_loader, mock_templar, mock_shared_loader_obj, mock_task)
    assert am._shared_loader_obj == mock_shared_loader_obj
    assert am._loader == mock_loader
    assert am._templar == mock_templar
    assert am._task == mock_task
    assert am._supports_check_mode is False
    assert am._supports_async is True

# Generated at 2022-06-21 02:19:58.542596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make module_loader happy
    import ansible.modules.extras
    import ansible.modules.system

    # setup test data
    _loader = 'ansible.plugins.loader.ActionModuleLoader'
    _shared_loader_obj = 'ansible.plugins.loader.ActionModuleLoader'
    _task = 'ansible.executor.task_result.TaskResult'
    _task_vars = dict()

    class PluginLoader:

        def find_plugin_with_context(self, *args, **kwargs):
            return 'ansible.modules.system.setup'

    class ActionModuleLoader:

        def __init__(self, *args, **kwargs):
            self.module_loader = PluginLoader()

    class TaskResult:

        def __init__(self, *args, **kwargs):
            self.args

# Generated at 2022-06-21 02:20:45.023477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:56.899265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	
	# Mock ansible.constants.MODULE_REQUIRE_ARGS and ansible.constants.MUST_HAVE_ONE_OF
	C.MODULE_REQUIRE_ARGS = []
	C.MUST_HAVE_ONE_OF = []
	
	# Mock ansible.constants.DEFAULT_MODULE_NAME, ansible.constants.DEFAULT_MODULE_ARGS and ansible.constants.DEFAULT_MODULE_COMPLEX_ARGS
	C.DEFAULT_MODULE_NAME = ""
	C.DEFAULT_MODULE_ARGS = ""
	C.DEFAULT_MODULE_COMPLEX_ARGS = ""
	
	# Mock ansible.constants.DEFAULT_HASH_BEHAVIOUR and ansible.plugins.action.ActionBase.DEFAULT_HASH_

# Generated at 2022-06-21 02:21:07.308729
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    import time
    import tempfile
    from io import StringIO

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.setup import ActionModule as AM
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


# Generated at 2022-06-21 02:21:08.842763
# Unit test for constructor of class ActionModule
def test_ActionModule():

    x = ActionModule()

    assert x is not None

# Generated at 2022-06-21 02:21:12.367933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = DummyTask()
    ActionModule(task, DummyConnection()).run(task_vars={'ansible_connection': 'myconnection'})


# Generated at 2022-06-21 02:21:24.835247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # module_loader is a fixture
    task_vars = {}
    module_loader = fixture_module_loader()
    fact_module = module_loader.find_plugin(
        'Ansible.ansible_facts.basic', collection_name=None
    ).resolved_fqcn
    loader = DataLoader()
    play_context = PlayContext(play=Play().load({
        'name': 'play', 'hosts': 'all'}, loader=loader),
        options=Options(connection='local'),
        passwords={})
    task = Task().load({
        'name': 'task',
        'action': {
            'module': fact_module,
            'args': {}
        }
    }, loader=loader, play=play_context)
    tmp = None


# Generated at 2022-06-21 02:21:26.169698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:21:32.915367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {}

    a = ActionModule()
    assert not isinstance(a, TestActionModule)

    a = TestActionModule()
    assert isinstance(a, TestActionModule)

# Generated at 2022-06-21 02:21:33.712423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-21 02:21:38.063407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task_result={}, task_info=None, action_gallery=None, play=None)

# Generated at 2022-06-21 02:23:27.037407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:35.843833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.virtual.osx import OSXFactCollector
    from ansible.module_utils.facts import timeout

    def execute_module_with_module_name(module_name, module_args=None, tmp=None, task_vars=None, wrap_async=False):
        if module_name == 'my_distribution':
            return DistributionFactCollector(module_name, module_args, tmp, task_vars, wrap_async).collect()

# Generated at 2022-06-21 02:23:44.198025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.executor.task_result import TaskResult

    task = mock.MagicMock()
    task.args = {}
    task._parent = mock.MagicMock()
    task._parent._play = mock.MagicMock()
    task._parent._play._action_groups = {'smart': False}

    tmplar = mock.MagicMock()

    task_vars = {'ansible_facts_parallel': False}
    modules_list = ['smart']
    C.config.DEFAULTS.DEFAULTS['FACTS_MODULES'] = modules_list
    C.config.DEFAULTS.DEFAULTS['CONNECTION_FACTS_MODULES'] = {"network_os": "ansible.legacy.setup"}
    connection = mock.MagicMock()
   

# Generated at 2022-06-21 02:23:46.683858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run the method
    # Return code:
    #    result dict
    pass

# Generated at 2022-06-21 02:23:49.271975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-21 02:23:51.041278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:24:03.023299
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Test_ActionModule(ActionModule):

        def __init__(self):
            self._supports_check_mode = True
            self._supports_async = True
            self._shared_loader_obj = None

        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
            return dict(ansible_facts=dict(fact1="value1"))

    task_vars = dict(ansible_facts=dict(fact1="value1"))

    test_act_module = Test_ActionModule()
    test_act_module._task = dict(args={'parallel': True, 'gather_timeout': 60, 'gather_subset': 'all', 'filter': None})

# Generated at 2022-06-21 02:24:13.686577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing failing module execution
    #1. No ansible_facts provided
    #2. Subset option provided which is not supported by setup module
    #3. Both async and parallel set to True

    mock_task = MagicMock()
    mock_task.args = dict()
    mock_task._parent = MagicMock()
    mock_task._parent._play = MagicMock()
    mock_task._parent._play.action_groups = dict()

    mock_self = MagicMock()
    mock_self._supports_check_mode = True
    mock_self._templar = MagicMock()
    mock_self._task = mock_task
    mock_self._display = MagicMock()
    mock_self._shared_loader_obj = MagicMock()
    mock_self._shared_loader_obj.module_loader

# Generated at 2022-06-21 02:24:19.615798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    AnsibleActionModule::run is the main method used when an action plugin
    is being run. It has been broken down into the following sub-methods:
    _get_module_args, _combine_task_result, run
    For the test to be performed, we need to simulate the call stack for a
    playbook run. This is done is the test case setup_module_factory_mocks()
    This test case calls run with various parametes to ensure the right
    values are returned. It starts with setting up the mocks, then calls
    run with various parameters and compares the return to the expected
    result.
    """

    # Setup the mocks
    from ansible.module_utils.facts.virtual.base import BaseFactCollector


# Generated at 2022-06-21 02:24:21.064752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1