

# Generated at 2022-06-21 02:16:27.441936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action=dict(module='setup'), args=dict(gather_subset=dict(all=True)))
    task_vars = dict(ansible_verbosity=2)
    tmp = None
    am = ActionModule(
        task=task,
        connection=None,
        play_context=None,  # AnsibleConnection
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = am.run(tmp, task_vars)
    assert result['failed'] is False
    assert result['ansible_facts']['_ansible_facts_gathered']



# Generated at 2022-06-21 02:16:38.846070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Run a test against the method run of class ActionModule
    """
    import os
    import tempfile
    import json
    import shutil

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'unit', 'data', 'ansible_facts')

    json_results = {}

    for test_folder in os.listdir(test_data_dir):
        base_dir = os.path.join(test_data_dir, test_folder)
        for filename in os.listdir(base_dir):
            action_base = ActionModule()
            action_base._shared_loader_obj = None
            action_base._loader = None
            action_base._templar = None
            action_base._

# Generated at 2022-06-21 02:16:49.881441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    import ansible.utils.vars as ansible_vars
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback import CallbackBase

    class MockPlayIterator(object):
        def __init__(self):
            self.items = 'test_items'

        def get_next_task_for_host(self, host, peek=False):
            # This is a mock so no need to take args
            return 'test_task'

        def __iter__(self):
            return self


# Generated at 2022-06-21 02:16:56.695614
# Unit test for constructor of class ActionModule
def test_ActionModule():

    config = C.Config()
    config._C.FACTS_MODULES = ['setup_legacy']
    config._C.CONNECTION_FACTS_MODULES = {'network': 'setup_network_legacy'}

    c = C.Connection('network')

    action = ActionModule(task=None, connection=c, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._connection._config = config
    action._task.args = {'network_os': 'network'}
    action.task_vars = {'ansible_network_os': 'network'}

    actions = action.run()

    assert actions['ansible_facts'] == {'_ansible_facts_gathered': True}

# Generated at 2022-06-21 02:17:06.512532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #instantiate mock_task to make args and task_vars available
    from mock import MagicMock

    mock_task = MagicMock()
    mock_task.args = {}
    mock_task.task_vars = {}

    #instantiate ansible action plugin to load FACTS_MODULES to modules 
    from ansible.plugins.action.setup import ActionModule
    
    action_module = ActionModule(mock_task, mock_task.args, mock_task.task_vars)

    #instantiate ansible module_utils.facts.cache to set value of 'ansible_facts_gathered'
    module_utils = __import__('ansible.module_utils.facts.cache')
    module_utils.ansible_facts_gathered = False

    #set 'FACTS_MODULES'

# Generated at 2022-06-21 02:17:19.364357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import os
    import sys
    import unittest2 as unittest

    from ansible.compat.tests.mock import call, patch, mock_open, mock_open_raise
    from ansible.compat.tests import mock

    from ansible.executor import task_result
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase

    from ansible.plugins.action.setup import ActionModule as AnsibleSetupModule

    from units.mock.loader import DictDataLoader

    # Patch methods to avoid actual loading of plugins
    _modules = {
        'setup': AnsibleSetupModule,
    }

# Generated at 2022-06-21 02:17:30.664510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils import basic
    import ansible.executor.module_common
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    def get_module_args(fact_module, task_vars):
        mod_args = {}
        resolved_fact_module = ansible.executor.module_common.get_action_args_with_defaults(
            resolved_fact_module, mod_args, task_vars['module_defaults'], basic.AnsibleModule,
            action_groups=task_vars['action_groups']
        )
        return resolved_fact_module

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)



# Generated at 2022-06-21 02:17:33.137877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-21 02:17:40.875639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestMiniAnsibleModule:

        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=None, mutually_exclusive=None,
                     supports_check_mode=False, required_together=None,
                     required_one_of=None, add_file_common_args=False,
                     supports_diff=False):
            self.argument_spec = argument_spec
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive
            self.required_together = required_together
            self.required_one_of = required_one_of
            self.supports_check_mode = supports_check_mode
            self.supports_diff = supports_diff


# Generated at 2022-06-21 02:17:49.865213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_defaults = {}
    action_groups = {}
    loader = None
    shared_loader_obj = None
    templar = None
    connection = None
    play_context = None
    new_stdin = None
    task_uuid = ''
    task_action = ''
    task_executor = ''
    task_name = ''
    task_args = {}
    task_vars = {}
    task_loader = None
    task_results = None
    ansible_pos = None
    ansible_all_vars = {}
    ansible_play_hosts = None
    ansible_version_info = None
    task = None


# Generated at 2022-06-21 02:18:07.576207
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.executor.task_queue_manager
    import ansible.executor.play_context

    connection = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=None, variable_manager=None, loader=None,
        options=ansible.config.loader.Options('test'),
        passwords=None, stdout_callback=None,
        run_tree=False, task_uuid=None,
        play_context=ansible.executor.play_context.PlayContext(
            connections=None, remote_user=None,
            remote_addr=None, become=None,
            become_method=None, become_user=None,
            verbosity=True, check=None, diff=None
        ),
        timeout=0,
        connection_info=None
    )
    task_name

# Generated at 2022-06-21 02:18:19.977425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    import re
    import json
    import random
    import unittest
    import ansible
    import ansible.plugins
    import ansible.plugins.action
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.executor.task_result
    import ansible.executor.task_queue_manager
    import ansible.utils.unicode
    import ansible.utils.display
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-21 02:18:20.974340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:23.434476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:18:24.872172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-21 02:18:26.270267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:18:28.256575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__
    assert 'action.base' == ActionModule._plugin_type

# Generated at 2022-06-21 02:18:40.590185
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test without parallel
    modules = ['redhat', 'ansible.legacy.setup']
    avm = ActionModule()
    avm.run(task_vars={'FACTS_MODULES': modules, 'ansible_facts_parallel': False})
    assert avm.run(task_vars={'FACTS_MODULES': modules, 'ansible_facts_parallel': False})['msg'] == 'The following modules failed to execute: redhat\n'

    # test with parallel
    avm.run(task_vars={'FACTS_MODULES': modules, 'ansible_facts_parallel': True})

# Generated at 2022-06-21 02:18:48.862143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Setup
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.hardware import sunos

    #Params
    tmp = None
    task_vars = ImmutableDict({'ansible_facts': {'network_os': 'juniper'},
                               'ansible_facts_parallel': None,
                               'ansible_check_mode': False})

    #Execution
    am = ActionModule()
    am._task = ImmutableDict({'args': {'network_os': 'juniper'},
                              'collections': [],
                              'module_defaults': {}})


# Generated at 2022-06-21 02:18:55.686048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = {}
    args = {}
    tmp = ''

    # TODO
    #action = ActionModule(f=f, task=f, connection=f, play_context=f, loader=f, templar=f, shared_loader_obj=f)
    #action.run(tmp=tmp, task_vars=args)



# Generated at 2022-06-21 02:19:21.941722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = "test.host.com"
    a = ActionModule()
    a.set_connection(hostname)
    a._task = {}
    a._task['start'] = 111
    result = a.run()

    assert result['failed'] == True
    assert result['msg'] == 'The following modules failed to execute: ansible_facts\n'
    assert result['failed_modules'] == {}
    assert result['skipped_modules'] == {}
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-21 02:19:29.305786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._supports_check_mode = True
    action.C = C
    action.C._config = {}
    action._templar = None
    action._loader = None
    action._shared_loader_obj = None
    action._connection = None
    action._task = None
    action._play_context = None
    action._display = None
    action._task = None
    action._templar = None
    action._task.args = None
    action._task.action = None
    action._task.action = None
    action._task.action = None
    action.C.DEFAULT_KEEP_REMOTE_FILES=None
    action.C

# Generated at 2022-06-21 02:19:41.662428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.path import unfrackpath, module_loader_find_path
    from ansible.plugins import module_loader

    collection_search_path = [os.path.sep.join(unfrackpath(__file__).split(os.path.sep)[:-3] + ['collections'])]
    loader = AnsibleCollectionLoader(None, None, unit_test=True)
    loader.set_collection_paths(collection_search_path)

    mod_path = module_loader_find_path('test.test',
                                       loader.collections,
                                       loader._module_paths)

    module_loader._add_directory(mod_path)

    # Setup data

# Generated at 2022-06-21 02:19:50.157914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    context._init_global_context(loader=loader)
    options = basic.AnsibleOptions(connection='local', module_path=['/to/mymodules'], forks=10)

# Generated at 2022-06-21 02:19:59.545335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data
    FAILED_RESULT = {
        'failed': True,
        'msg': "The following modules failed to execute: %s\n",
        'failed_modules': {},
        'ansible_facts': {}
    }

    SKIPPED_RESULT = {
        'skipped': True,
        'msg': "The following modules were skipped: %s\n",
        'skipped_modules': {},
        'ansible_facts': {}
    }

    RESULT = {
        'ansible_facts': {},
        'warnings': [],
        'deprecations': []
    }

    # Test code

    # Test failure case
    # Failed to execute Modules
    mod_run_obj = ActionModule()
    assert mod_run_obj.run() == FAILED_RES

# Generated at 2022-06-21 02:20:04.097806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Tests ActionModule's _run method
    """
    # Prepare mock objects
    am = ActionModule()
    am.run(tmp='/tmp', task_vars={})

# Generated at 2022-06-21 02:20:10.377904
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FactModule with no arguments
    module_name = "fact_module"
    fact_module = ActionModule()
    res = fact_module.run()
    assert isinstance(res, dict)
    assert 'elapsed' in res

    # FactModule with arguments
    module_name = "fact_module"
    fact_module = ActionModule()
    res = fact_module.run(module_name, 'parallel')
    assert isinstance(res, dict)
    assert 'elapsed' in res

# Generated at 2022-06-21 02:20:18.864542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.namespace import FactsNamespace
    import ansible.module_utils.facts.namespace
    ansible.module_utils.facts.namespace = None
    import ansible.module_utils.facts.legacy

    class FakeConnection:
        class _shell:
            tmpdir = None

        def __init__(self):
            self._shell = self._shell()
            self._shell.tmpdir = '/tmp/ansible'
            self._load_name = 'network_cli'

    class FakeTask:
        def __init__(self):
            self.args = {'network_os': 'fake_os'}
            self.module_defaults = {}
            self.collections = ['fake_collections']


# Generated at 2022-06-21 02:20:20.804954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_class = ActionModule()
    assert action_module_class is not None

# Generated at 2022-06-21 02:20:21.525677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:21:05.000608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:21:06.141935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 02:21:07.501836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:21:17.508717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock module, task and task_vars
    mock_module = type('module', (), {'run': ActionModule.run})
    mock_task = type('task', (), {})
    mock_task_vars = {
        'ansible_facts': {
            'network_os': 'None'
        }
    }

    # Create test object
    action_module = mock_module(mock_task, {"gather_subset": ['all'], "filter": "*"})

    # Run test
    result = action_module.run(None, mock_task_vars)

    # Check if results are correct

# Generated at 2022-06-21 02:21:22.892989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {'_ansible_check_mode': False, '_ansible_debug': False, '_ansible_diff': False, '_ansible_verbosity': 4, 'module_args': {}}
    action_module = ActionModule(d, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:21:35.689570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Options:
        module_defaults = {'module_name': 'module1', 'module_args': 'module_args1'}

    class Connection:
        _load_name = 'loader1'

    class VarsModule:
        def __init__(self, vars_val):
            self.vars_val = vars_val

        def get(self, var_name, default=None):
            return self.vars_val.get(var_name, default)

    class ActionModule1(ActionModule):
        def init_to_defaults(self):
            # test init
            self._task_vars = None
            self._task_path = 'task_path1'
            self.action = 'action1'
            self._task = 'task1'
            self._connection = Connection()
            self._

# Generated at 2022-06-21 02:21:46.655958
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    t = Task()
    t._ds = dict()
    t._ds['connection'] = ''

    t._ds['name'] = 'setup'
    t._ds['vars'] = dict()

    a = ActionModule(t)

    assert(a._do_async == False)
    assert(a._supports_async == True)

    assert(a._supports_check_mode == True)

    b = Block()
    b._ds = dict()
    b._load_name = ''

    c = ActionModule(t, b)

    assert(c._supports_async == False)

    assert(c._supports_check_mode == False)

# Generated at 2022-06-21 02:21:57.303208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_result ={
        'ansible_facts': {'test': 'test result'},
        'failed': False,
        'msg': '',
        'stdout_lines': [],
        'warnings': []
    }

    class SmartFacts:
        def find_plugin_with_context(self, name, collection_list):
            module = MagicMock(spec_set=ModuleOptions)
            module.resolved_fqcn = name
            return module

    class MockModuleLoader:
        def __init__(self):
            self.module_loader = SmartFacts()

    mock_task = MagicMock(spec_set=Task)
    mock_task._parent = MagicMock(spec_set=Play)
    mock_task._parent._play = MagicMock(spec_set=PlayContext)
   

# Generated at 2022-06-21 02:22:09.390791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_config = mock.MagicMock()
    m_config.get_config_value = mock.MagicMock(return_value=[])

    m_task = mock.MagicMock()
    m_task.args = {}
    m_task.module_defaults = {}
    m_task._parent = mock.MagicMock()
    m_play = mock.MagicMock()
    m_play._action_groups = {}
    m_task._parent._play = m_play

    m_module_loader = mock.MagicMock()
    m_shared_loader_obj = mock.MagicMock()
    m_shared_loader_obj.module_loader = m_module_loader

    m_templar = mock.MagicMock()

    m_connection = mock.MagicMock()
    m_connection._load

# Generated at 2022-06-21 02:22:20.690471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert os.environ['ANSIBLE_CALLABLE_PLUGINS'] == '/ansible/plugins/action'
    assert os.environ['ANSIBLE_LIBRARY'] == '/ansible/plugins/library'
    assert os.environ['ANSIBLE_MODULE_UTILS'] == '/ansible/plugins/module_utils'
    assert os.environ['ANSIBLE_FILTER_PLUGINS'] == '/ansible/plugins/filter'
    assert os.environ['ANSIBLE_TEST_LIBRARY'] == '/ansible/test/lib:../test/lib'
    assert os.environ['ANSIBLE_TEST_MODULE_UTILS'] == '/ansible/test/module_utils:../test/module_utils'

# Generated at 2022-06-21 02:23:59.647585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod._supports_check_mode is True
    assert isinstance(mod.run(tmp=None, task_vars=None), dict)

# Generated at 2022-06-21 02:24:00.340375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-21 02:24:01.405853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None

# Generated at 2022-06-21 02:24:03.585747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule"""
    action_module = ActionModule()



# Generated at 2022-06-21 02:24:13.862957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.utils.vars import AnsibleVars

    context.CLIARGS = {'module_path': './library'}
    task_vars = AnsibleVars()
    task_vars.update({
        'ansible_facts_parallel': True,
        'connection': 'network_cli',
        'gather_subset': 'all',
        'hosts': ['host1'],
    })
    am = ActionModule()
    am.setup(task_vars=task_vars)
    r = am.run(task_vars)
    assert 'ansible_facts' in r
    assert '_ansible_facts_gathered' in r['ansible_facts']
    assert '_ansible_verbose_override' in r


# Generated at 2022-06-21 02:24:23.708184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_action = ActionModule()
    module_action._task = {'args': {'network_os': 'junos'}, 'collections': []}
    module_action._shared_loader_obj.module_loader.filesystem_path = '~/.ansible/plugins/modules'
    module_action._connection = {'_load_name': 'ansible_ssh'}
    module_action._display = {'vvvv': print}
    module_action._task._parent = {'_play': {'_action_groups': []}}

    module_action._execute_module = lambda b,c,d,e: {'finished': 1, 'ansible_facts': {'ansible_net_hostname': 'test'}}
    result = module_action.run(None, {})

# Generated at 2022-06-21 02:24:26.581248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check the constructor of class ActionModule
    a = ActionModule()
    assert a.action_name == 'setup'

# Generated at 2022-06-21 02:24:28.536797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Method test_ActionModule_run has not been defined')

# Generated at 2022-06-21 02:24:34.829195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Load plugin as module. Ansible will load this as a plugin
    from ansible.plugins.action import ActionModule

    task_args = {}
    source = '/etc/ansible/facts.d'
    options = {'gather_subset': ['all'], 'gather_timeout': 10, 'filter': '*'}
    shared_loader_obj = None
    templar = None
    action_plugins = []
    connection = None
    play_context = None
    new_stdin = None
    loader = None

# Generated at 2022-06-21 02:24:36.970085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
