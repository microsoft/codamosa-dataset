

# Generated at 2022-06-21 02:16:29.353209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    @staticmethod
    def _is_network_os_dict(network_os_dict):
        return isinstance(network_os_dict, dict) and 'ansible_facts' in network_os_dict and 'network_os' in \
               network_os_dict['ansible_facts']

    import inspect
    from ansible.plugins.action.setup import ActionModule as AM

    # create an instance of the ActionModule class
    am = AM(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # call the run method of the class
    am.run()

# Generated at 2022-06-21 02:16:30.729009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:16:37.229164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module_name="test.unit",
                            args=dict(arg1=1, arg2=2),
                            module_defaults=dict(arg1=1, arg2=2)))
    task_vars = dict(foo="bar")

    # Test with no FACTS_MODULES set
    m = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m.run(tmp=None, task_vars=task_vars) == dict(ansible_facts=dict(_ansible_facts_gathered=True),
                                                        _ansible_verbose_override=True)

    # Test with FACTS_MODULES set to a single value
    config = C.Config

# Generated at 2022-06-21 02:16:40.094465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_action_module = ActionModule({}, {}, None)
    assert temp_action_module

# Generated at 2022-06-21 02:16:44.887588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case : constructor 테스트
    module = ActionModule()
    assert 'ActionModule' == module.__class__.__name__
    assert 'ansible.plugins.action' == module.__module__


# Generated at 2022-06-21 02:16:46.564383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO -- write unit test for ActionModule._get_module_args
    pass


# Generated at 2022-06-21 02:16:47.674784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   pass

# Generated at 2022-06-21 02:16:51.711951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 02:16:53.376515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:16:55.053737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert(type(module) == ActionModule)

# Generated at 2022-06-21 02:17:15.437944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write a more extensive unit test
    # create module, we use a non existing module, just for test purpose
    module = ActionModule(
        task=dict(action='setup'),
        connection=Mock(),
        play_context=Mock(),
        loader=dict(),
        templar=Mock(),
        shared_loader_obj=Mock()
    )

    # call method
    module.run()

# Generated at 2022-06-21 02:17:16.282556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:17:22.639214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    inventory = InventoryManager(loader=DataLoader(), sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # TODO: consider moving this to `fixtures` in coordination with the #26274 test update

# Generated at 2022-06-21 02:17:24.108963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:17:30.806378
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Initialise a test object
    action_module_object = ActionModule()

    # test with invalid values
    results = action_module_object._execute_module(module_name="invalid", module_args={}, task_vars={}, wrap_async=False)
    assert results['failed'] is True
    assert results['msg'] == "No module 'invalid' found"

    results = action_module_object._execute_module(module_name="setup", module_args={}, task_vars={}, wrap_async=False)
    assert results['failed'] is False

# Generated at 2022-06-21 02:17:31.420123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:17:40.431176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    class TestActionModule(ActionModule):
        def _get_module_args(self, fact_module, task_vars):
            return {}
        def _combine_task_result(self, result, task_result):
            return {}
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)
    C.config.get_config_value = lambda key, variables: [key]
    C.config.get_config_value.sync_cache = lambda: None

    # Test

# Generated at 2022-06-21 02:17:46.135524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module=ActionModule(task=MockTask())
    assert action_module.run() == {'changed': False, 'ansible_facts': {'_ansible_facts_gathered': True},
                                                    'failed': True, 'msg': 'The following modules failed to execute: test_module\n'}

# Generated at 2022-06-21 02:17:53.602657
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:17:57.478809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate a new instance of the object
    x = ActionModule()

    # Test that the object is an instance of ActionModule
    assert isinstance(x, ActionModule)

    # Test that the object is an instance of ActionBase
    assert isinstance(x, ActionBase)

    # Test that the object is an instance of object
    assert isinstance(x, object)

# Generated at 2022-06-21 02:18:24.549567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import StrategyBase

    class TestStrategy(StrategyBase):
        def get_hosts(self, pattern):
            return 'all'

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = load_extra_vars(loader=loader)

# Generated at 2022-06-21 02:18:33.585098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''

    ActionModule_run_instance = ActionModule()

    def mocked_execute_module(module_name, module_args, task_vars, wrap_async):
        assert module_name == 'ansible.legacy.setup'
        assert module_args == {'filter': '*', 'gather_subset': ['all']}
        assert task_vars == {}
        assert wrap_async == False
        return {'ansible_facts': {'var': 'value'}}

    setattr(ActionModule_run_instance, '_execute_module', mocked_execute_module)

    def mocked_config_get_config_value(variable, variables):
        assert variable == 'FACTS_MODULES'
        assert variables == {}

        return

# Generated at 2022-06-21 02:18:39.881563
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of class ActionModule
    class_instance = ActionModule()

    # Create helper objects for unit test
    class_instance._connection = 1
    class_instance._shared_loader_obj = 1
    class_instance.task_vars = 1
    class_instance._task = 1
    class_instance._templar = 1
    class_instance._display = 1

    # Run method and return unit test results
    return class_instance.run

# Generated at 2022-06-21 02:18:42.145776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None, None, None, None)
    assert actionModule is not None

# Generated at 2022-06-21 02:18:47.083621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate 
    module_action = ActionModule(load_name='ansible.legacy.setup', task=dict(), connection=dict())


    # call class methods
    module_action._get_module_args()
    module_action._combine_task_result()
    module_action.run()

# Generated at 2022-06-21 02:18:48.620746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-21 02:18:49.741990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:18:56.120481
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod_obj = ActionModule()

    # Test case 1 - modules is a list of modules

    modules = ['mod1', 'mod2']

    tmp = None
    task_vars = {}
    result = mod_obj.run(tmp, task_vars)

    assert result is not None
    assert isinstance(result, dict)

# Generated at 2022-06-21 02:18:58.398010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:18:59.474165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:19:46.982394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars
    import ansible.module_utils.parsing.convert_bool
    import ansible.config
    import ansible.executor.module_common
    import ansible.plugins.action
    import ansible.utils.display
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy

    # Make it possible to "pass" the module class by instantiating it, see:
    # https://stackoverflow.com/questions/28187072/creating-a-generic-object-instance-in-python
    class GenericClass():
        """ Generic class for python testing, it is created by the "pass" module """

# Generated at 2022-06-21 02:19:58.463347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = MagicMock(get_name=MagicMock())
    t = MagicMock(spec=Task)
    t.async_val = 1
    t.args = {'arg': 1}
    t.run_once = False
    t.notify = []
    t._role = None
    t._play = MagicMock()
    t._task = 'task'
    t._parent = MagicMock()
    t._parent._role = MagicMock()
    t._parent._role._role_name = 'rolename'
    t._parent._play = MagicMock()
    t._parent._play.get_variable_manager = MagicMock()

# Generated at 2022-06-21 02:19:59.832345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:20:00.713732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:02.434099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('tasks', 'action') is not None

# Generated at 2022-06-21 02:20:12.006585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit tests for method ``run`` of class ``ActionModule`` """

    # With one module that fails
    modules = ['module_fail', 'module1']
    task_vars = {'ansible_facts_parallel': False, 'ansible_facts': {}}
    result = {'failed': True, 'msg': 'The following modules failed to execute: module_fail\n'}
    jobs = {'module_fail': {'finished': 0}, 'module1': {'finished': 1}}
    # FIXME
    # mock_execute_module = mock.Mock()
    # class Mock:
    #     def __init__(self, **kwargs):
    #         self.config = {'DEFAULT_Notification': mock.DEFAULT, 'DEFAULT_RETURN': mock.DEFAULT}
    #         self.config.

# Generated at 2022-06-21 02:20:20.020602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_module_loader = Mock()
    mock_plugin_loader = Mock()
    mock_plugin_loader.find_plugin_with_context.return_value = Mock(resolved_fqcn=None)
    mock_task = Mock()
    mock_task.module_defaults = {}
    # The below is needed to not blow up on finding collection_list
    mock_task._parent = Mock()
    mock_task._parent._play = Mock()
    mock_task._parent._play._action_groups = {}
    mock_task.args = {}
    mock_task.collections = []

    mock_display = Mock()
    mock_templar = Mock()
    mock_task.args = {'network_os': None, 'parallel': False}

    mock_connector = Mock()
    mock_connector.bec

# Generated at 2022-06-21 02:20:27.791425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.utils.vars
    import ansible.plugins.action
    import ansible.vars.manager
    import ansible.utils.vars

    host = ansible.inventory.host.Host(name="test_host")
    t = ansible.playbook.task.Task()
    t.args = dict(a=1)
    t._parent = object()
    t._parent._play = object()
    t._parent._play.name = "test_play.yml"
    t._parent._play.tasks = []
    t._parent._play._action_groups = dict(test_action_group=["test_action"])
    t._parent._task_vars = dict(a=2)

# Generated at 2022-06-21 02:20:37.221167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    import ansible.plugins.loader
    import ansible.plugins.loader_factory

    class FakeModule(object):
        def __init__(self, fqcn):
            self.resolved_fqcn = fqcn

    class FakeLoader(object):
        def find_plugin_with_context(self):
            pass


    class FakeTemplar(object):
        def template(self):
            pass

    class FakePlay(object):
        def __init__(self):
            self._action_groups = {}

    class FakeTask(object):
        def __init__(self):
            self._parent = FakePlay()
            self.module_defaults = {}
            self.collections = []


# Generated at 2022-06-21 02:20:39.752099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    assert am.run() is not None

# Generated at 2022-06-21 02:22:17.755653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'host'
    connection = 'paramiko'
    task = 'task'
    task_vars = 'task_result'

    test_class = ActionModule(task, connection, task_vars, host)
    assert test_class._supports_check_mode is True

# Generated at 2022-06-21 02:22:25.035742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = {'ansible_facts': {}, 'ansible_facts_gathered': True}

    # test_action_module_multiple_modules_async
    c = {'FACTS_MODULES': ['ansible.legacy.setup', 'ansible.legacy.setup']}
    t = {'ansible_facts_parallel': False, 'ansible_network_os': 'default_network_os'}
    args = {'filter': 'ansible.legacy.setup'}
    action_module = ActionModule(c=c, t=t, args=args)
    assert action_module.run() == a

    # test_action_module_single_module_async

# Generated at 2022-06-21 02:22:26.886891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' just testing the __init__.py '''
    pass

# Generated at 2022-06-21 02:22:30.903970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.chdir(os.path.dirname(__file__) + '/../')
    action_module = ActionModule()
    action_module.run({'ansible_facts': {}})

# Generated at 2022-06-21 02:22:37.443566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test arguments
    arg_spec = dict()
    kwargs = dict(**arg_spec)
    # create mock
    mock_object = type('MockActionModule', (ActionModule,), kwargs)
    # create instance
    obj = mock_object()
    # do something with instance
    obj.run()

# Generated at 2022-06-21 02:22:45.625582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.executor.setup_facts import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import connection_loader

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.shared_loader_obj = connection_loader._shared_loader_obj
    am._loader = connection_loader
    am._templar = connection_loader._templar
    am._connection = connection_loader._connection
    am._task = TaskQueueManager(play_context=None)
    am._task._parent = TaskQueueManager(play_context=None)

# Generated at 2022-06-21 02:22:55.578853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(a=1, b=2)
    module_name = 'setup'
    job_id = '<JOB_ID>'

    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult

    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import iteritems
    from ansible.utils.vars import merge_hash
    task_result = TaskResult(dict(ansible_task_vars=dict(a=1, b=2)))
    action = ActionModule(task_result, dict(a=1, b=2), module_name, job_id)

    assert action._

# Generated at 2022-06-21 02:22:56.474761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run()")
    exit(0)

# Generated at 2022-06-21 02:23:04.894321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook

    task = Task()
    task._role = None
    task._parent = None
    task._play = None
    task._dep_chain = None


# Generated at 2022-06-21 02:23:14.801934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """This test method has been generated based on one or more Ansible task files.
    For each Ansible task file from which this method was generated, the corresponding
    task_vars file was also generated in the unit test directory.
    """
    # Convert json to pytest format
    module_name = 'ansible.builtin'