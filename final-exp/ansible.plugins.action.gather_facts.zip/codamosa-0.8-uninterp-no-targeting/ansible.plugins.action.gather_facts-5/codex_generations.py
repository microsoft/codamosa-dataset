

# Generated at 2022-06-21 02:16:29.591151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest

    from ansible.module_utils.hashivault import hashiwrapper
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.template import Templar
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
   

# Generated at 2022-06-21 02:16:39.998502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    # Create a test ActionModule
    am = ActionModule()
    am._connection = None

    # Create a test Task
    args = None
    task = Task()
    task._role = None
    task.args = args
    task.action = am
    task.block = Block()
    task.role = Role()
    task.task_immerse_cache = None
    task.task_vars = {}

    # Create PlayContext
   

# Generated at 2022-06-21 02:16:50.379365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #set up
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.executor.module_common import DEFAULT_LOADER_PLUGINS

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host('localhost')
    host.name = 'localhost'

# Generated at 2022-06-21 02:16:57.218539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection import network_cli

    class Task:
        def __init__(self):
            self.args = {'gather_subset': 'all', 'gather_timeout': 10, 'filter': 'network'}

    class ModuleLoader:
        def find_plugin(self, name, mod_type, ignore_deprecated=False):
            return 'module_fqcn'

    class SharedLoaderObj:
        def __init__(self):
            self.module_loader = ModuleLoader()

    class Connection:
        def __init__(self):
            self._load_name = 'network_cli'
            self._shell = None

    class Display:
        def __init__(self):
            self.verbosity = 1

        def verbose(self, msg):
            print(msg)


# Generated at 2022-06-21 02:17:09.505336
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create template for argument spec
    argument_spec = dict()

    # Create template for unset arguments
    unset_argument_spec = dict()

    # Create a template for ansible arguments
    ansible_argument_spec = dict(
        ansible_facts=dict(),
        ansible_facts_parallel=dict(type='bool', default=False, choices=[True, False]),
        parallel=dict(type='bool', default=None, choices=[True, False]),
        include_network_facts=dict(type='bool', default=None, choices=[True, False]),
    )

    # Create a template for ansible arguments defined in ansible.cfg

# Generated at 2022-06-21 02:17:17.602372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new instance of the ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a new task (ansible.playbook.task.Task)
    task = Task(name='test-setup', action=action_module)

    # Create a new task_vars (dict)
    task_vars = dict()

    # Set fact modules to be a string
    fact_modules = 'ansible.legacy.setup'

    # Set the configuration to be a string
    configuration = "FACTS_MODULES=[\"" + fact_modules + "\"]"

    # Create a new instance of the ConfigParser class
    configuration_parser = ConfigParser(allow_no_value=True)

   

# Generated at 2022-06-21 02:17:30.148620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock the ansible.plugins.action.ActionBase.run method
    mock_action_base = mocker.patch('ansible.plugins.action.ActionBase.run')
    mock_action_base.return_value = dict(failed=False, changed=False)

    # mock the ansible.modules.setup.ActionModule._get_module_args method
    mock_module_args = mocker.patch('ansible.modules.setup.ActionModule._get_module_args')

    module_args = dict(
        gather_subset="network",
        gather_network_resources="interfaces",
        gather_facts="false",
    )
    setup_module = ActionModule(task=dict(args=module_args))

    # execute run and assert the results
    result = setup_module.run(task_vars=dict())
   

# Generated at 2022-06-21 02:17:31.538625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:17:40.397056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    play_context = PlayContext()

    my_vars = load_extra_vars(loader=DataLoader(), options={}, args=None, private=True)

    my_inventory = InventoryManager(loader=DataLoader(), sources='')
    group = Group('test_group')
    host = Host('test_host')

# Generated at 2022-06-21 02:17:49.720641
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:18:02.052138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(1,1,1,1) is not None

# Generated at 2022-06-21 02:18:03.704431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Dummy(ActionModule):
        pass
    dummy = Dummy(None, None, None, None, None, None, None)

    assert dummy


# Generated at 2022-06-21 02:18:11.881773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test ActionModule.run() """

    # Test run of class ActionModule with a set of defaults
    fake_loader, myclass = make_fake_loader({
        'module_utils.parsing.convert_bool.boolean': fake_boolean,
    })
    myclass.set_loader(fake_loader)


# Generated at 2022-06-21 02:18:16.889261
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test the module constructor with series of invalid data types
    # Class will throw exception if invalid
    action_module1 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:18:23.380002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask(object):
        def __init__(self):
            self._ds = {}

        def __getattr__(self, name):
            return self._ds.get(name, None)

        def __setattr__(self, name, value):
            self._ds[name] = value

    class FakePlayContext(object):
        def __init__(self):
            self._ds = {}

        def __getattr__(self, name):
            return self._ds.get(name, None)

        def __setattr__(self, name, value):
            self._ds[name] = value

        def _ds(self):
            return self.__dict__

    class FakeSettings(object):
        def __init__(self):
            self._ds = {}


# Generated at 2022-06-21 02:18:33.112144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a dummy result
    result = dict()
    result['ansible_facts'] = dict();

    # create a dummy config
    config = dict()
    config['FACTS_MODULES'] = ['ansible.legacy.setup']
    config['CONNECTION_FACTS_MODULES'] = dict()
    config['CONNECTION_FACTS_MODULES']['network_os'] = 'ansible.legacy.setup'

    # create a dummy task
    task = dict()
    task['args'] = dict()
    task['collections'] = []

    # create a fake module name
    module_name = "ansible.legacy.setup"

    # create a dummy module args
    module_args = dict()

    # create a fake module_defaults
    module_defaults = dict()

# Generated at 2022-06-21 02:18:43.354520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    action = action_loader.get('setup', task=dict(action=dict(setup=dict())))
    assert action._supports_check_mode is True

    # TODO: move this to a test module
    # mock play
    action._task._parent._play = type('Play', (object, ), dict(action_groups=['setup']))

    # Mock module
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.args = kwargs

        def run(self, tmp=None, task_vars=None):
            return dict(ansible_facts=dict(foo='bar'))

    action._shared_loader_obj.module_loader.module_utils_loader.mapping['ansible.legacy.setup']

# Generated at 2022-06-21 02:18:50.885514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import builtins
    import sys
    import types

    # create a mock for the class under test
    class MockConnection():
        _load_name = 'mock'

        def __init__(self, *args):
            self.tmpdir = '/tmp/'

        def _shell(self):
            return self

        def get_option(self, *args):
            return None

        def _execute_module(self, *args, **kwargs):
            return {'failed': False}

    class Mock(ActionModule):
        def __init__(self, *args, **kwargs):
            self.module_defaults = {'test': 'yes'}
            self._shared_loader_obj = types.SimpleNamespace(module_loader=None)
            self._context = MockConnection()
            self.args = {}
            self

# Generated at 2022-06-21 02:18:57.918992
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.utils.contextmanager import InitModuleGlobalContext
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.ansible_release import __copyright__ as module_copyright
    from ansible.module_utils.ansible_release import __author__ as module_author


# Generated at 2022-06-21 02:18:58.816148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:19:31.929331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    class FakeTask:
        def __init__(self, args):
            self.args = args
        def set_loader(self, loader):
            self.loader = loader
    class FakeTaskQueueManager(TaskQueueManager):
        def __init__(self, loader):
            self._loader = loader
    class FakeLoader:
        def __init__(self):
            self._collections = []
    class FakeModule:
        def __init__(self):
            self._connection = FakeTaskQueueManager(FakeLoader())
            self._task = FakeTask({'network_os': 'ios'})

# Generated at 2022-06-21 02:19:36.499766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test function for method ActionModule.run

    :param self: Object reference
    :type self: ActionModule object
    :return: no return value
    :rtype: None
    """
    pass

# Generated at 2022-06-21 02:19:37.941732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule is not None

# Generated at 2022-06-21 02:19:40.494253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x._supports_check_mode is True

# Generated at 2022-06-21 02:19:42.842322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, None, None), ActionBase)


# Generated at 2022-06-21 02:19:50.500194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.compat.six as six
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    task_vars = dict()
    task_vars['test_var'] = 'test_value'
    task_result = TaskResult(dict())
    assert task_result.is_successful()
    task_vars['task_result'] = task_result
    result = dict()
    result['ansible_facts'] = dict()
    result['failed'] = False
    result['changed'] = False
    result['skipped'] = False
    task = dict()
    task['vars'] = task_vars
    task['tmp'] = None
    task['files'] = None
    task['action'] = dict()

# Generated at 2022-06-21 02:19:51.095375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:19:59.939289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    to_test = {
        # test_dict[1]: input to test_dict[0], which is the method/function under test
        '_get_module_args': [mod._get_module_args, 'setup', {}],
        '_combine_task_result': [mod._combine_task_result, {}, {'ansible_facts': {'test1': 'result1'}, 'warnings': ['test_warning']}],
        'run': [mod.run, None, None],
    }

# Generated at 2022-06-21 02:20:01.686130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # print('hello world');
    assert True

# Generated at 2022-06-21 02:20:08.322601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == {'failed': True, 'failed_modules': {}, 'msg': 'The following modules failed to execute: \n', 'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}

# Generated at 2022-06-21 02:21:05.713871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._connection._shell.tmpdir = "/tmp/test"
    module._display.verbosity = 5
    module._task.args = {"a": "b"}
    module._task.async_val = 10
    module._task.action = "ansible.legacy.setup"
    module._task_vars["ansible_facts_parallel"] = True
    module._task_vars["ansible_inventory_sources"] = []
    module._task_vars["_role_paths"] = ["/tmp/test"]
    module._templar._available_variables = []
    module._shared_loader_obj.module_loader.find_plugin_with_context = lambda fact_module, collection_list: fact_module

# Generated at 2022-06-21 02:21:06.901621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:21:08.431086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    assert True

# Generated at 2022-06-21 02:21:11.915788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(ActionBase._shared_loader_obj, dict(name='test_ActionModule'), dict(play_context=dict()))._task.name == 'test_ActionModule'

# Generated at 2022-06-21 02:21:12.641480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:21:13.419273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:21:25.398931
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:21:36.440621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec = {
        'ansible_facts_parallel': {'type': 'bool', 'required': False},
        'parallel': {'type': 'bool', 'required': False},
        'network_os': {'type': 'str', 'required': False},
    }

# Generated at 2022-06-21 02:21:38.064054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_test(ActionModule)

# Generated at 2022-06-21 02:21:40.163975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({'setup': ''}, {})
    assert module._supports_async is True
    assert module._supports_check_mode is True
    assert module._supports_async is module._supports_check_mode
    assert module._supports_become is False
    assert module._supports_become_methods == ['sudo', 'su']

# Generated at 2022-06-21 02:23:30.116034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:36.991169
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeTask(object):
        def __init__(self):
            self.args = {'smart': {}}
            self.module_defaults = None
            self._parent = None
            self.action = 'setup'

    class FakeTemplar(object):
        pass

    class FakeLoader(object):
        def find_plugin_with_context(self, name, collection_list=None):
            class FakeModule(object):
                def __init__(self):
                    self.resolved_fqcn = 'ansible.legacy.setup'

            return FakeModule()

    class FakeSharedLoaderObj(object):
        def __init__(self):
            self.module_loader = FakeLoader()

    class FakeExecutorVariableManager(object):
        def __init__(self):
            self._hostvars = {}

# Generated at 2022-06-21 02:23:37.765128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:38.487230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:23:41.091230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_executor = ActionModule()

# Generated at 2022-06-21 02:23:42.359606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am_obj = ActionModule()

# Generated at 2022-06-21 02:23:47.679638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_action_module is not None

# Generated at 2022-06-21 02:23:48.524566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:56.628533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Some module that returns ansible_facts
    # (needs to be a valid module to avoid `_execute_module` error)
    module = 'ansible.builtin.command'

# Generated at 2022-06-21 02:24:05.138998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import tempfile
    import base64
    import shutil
    import stat
    import subprocess
    module = mock.MagicMock()
    module.params = {
       'gather_subset': ['min'],
       'ansible_facts_parallel': False,
       'filter': 'ansible_all_ipv4_addresses',
    }
    module.run.__name__ = 'test_ActionModule_run'
    setattr(module, '_ansible_debug', True)
    setattr(module, '_ansible_verbosity', 2)
    action_plugin = ActionModule(module, 'test_ActionModule_run')
    # create a fake result directory