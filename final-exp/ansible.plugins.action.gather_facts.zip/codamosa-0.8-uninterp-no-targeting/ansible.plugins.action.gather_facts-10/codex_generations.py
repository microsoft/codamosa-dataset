

# Generated at 2022-06-21 02:16:21.028646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:16:22.073345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule({}, {})
    assert isinstance(a, type(ActionModule))

# Generated at 2022-06-21 02:16:29.648658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is used to test action module

    # import libraries
    import os
    import traceback
    import sys
    import inspect
    import types
    import time
    import json

    import ansible

    # import Ansible Plugins
    from ansible.plugins.loader import action_loader

    # import Ansible path configuration
    from ansible.config.manager import ConfigManager

    # import Ansible action base class
    from ansible.plugins.action import ActionBase

    # import Ansible exceptions
    from ansible.plugins.loader import vars_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.errors import AnsibleError
    from ansible.template import Templar

# Generated at 2022-06-21 02:16:32.129085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, {}, None)

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:16:35.299892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    task = dict(action=dict(__ansible_module__="setup.py"))
    action = ActionModule(task, dict(connection=None))
    assert action._supports_check_mode is True
    assert action._supports_async is True
    assert action._supports_become is False
    assert action._supports_diff is False



# Generated at 2022-06-21 02:16:42.334878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''test constructor of class ActionModule'''
    import ansible.plugins.action
    import ansible.plugins.loader
    import ansible.executor.task_queue_manager
    import ansible.executor.task_result
    import ansible.executor.module_common
    from ansible.executor import action_write_locks
    from ansible.utils.vars import combine_vars

    from ansible.utils.vars import combine_vars

    mock_task_result = ansible.executor.task_result.TaskResult(host=ansible.executor.module_common.TaskBase())
    task_vars = dict()


# Generated at 2022-06-21 02:16:44.266072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule'''
    pass

# Generated at 2022-06-21 02:16:45.098108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:16:53.898431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("******************")
    print("\n\nFixture test_ActionModule_run():")
    print("\n")

    import ansible.utils.vars as auvars
    import ansible.utils.unsafe_proxy as auuunsafeproxy
    import ansible.plugins.action as apa
    import ansible.executor.task_result as aetaskresult
    import ansible.module_utils.facts as aumfacts
    import ansible.module_utils.facts.system as aumfsystem

    import io
    import sys
    import unittest

    # Redirection for stdout using a buffer
    new_stdout = io.StringIO()
    sys.stdout = new_stdout

    # Variables used for the test
    module_name = 'setup'
    module_args = dict

# Generated at 2022-06-21 02:16:55.603002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=[], connection=[], play_context=[], loader=[], templar=[], shared_loader_obj=[])

# Generated at 2022-06-21 02:17:08.018485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:17:19.115535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible.plugins.action
    fact_module = 'setup'
    tmp = '/root/.ansible/tmp/ansible-tmp-1483429056.07-135717969272964/setup'
    source = '/root/.ansible/tmp/ansible-tmp-1483429056.07-135717969272964/source'
    task_vars = dict()
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_facts'] = ''
    obj = ActionModule(fact_module, tmp, source, task_vars)
    obj.run(task_vars)

# Generated at 2022-06-21 02:17:21.440907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule:test_ActionModule_run
    """
    pass

# Generated at 2022-06-21 02:17:25.211582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:17:35.037025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Test require a valid unix style path to the temporary directory
    # Also requires that TMP_DIR and Python's tempfile.gettempdir()
    # point to the same directory on the controller
    tmp = "/tmp/ansible-local"
    # Assumption that the user running the tests has access to
    # TMP_DIR and tempfile.gettempdir()
    assert(tmp == C.DEFAULT_LOCAL_TMP)
    assert(tmp == TaskQueueManager._get_local_tmp_dir())

    # create a task
    task = dict(action=dict(module="copy", args=dict(src='hello', dest='world')))

    # create a variable dictionary

# Generated at 2022-06-21 02:17:36.878638
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Default ActionModule.run() call
    with pytest.raises(Exception) as excinfo:
        (ActionModule().run())



# Generated at 2022-06-21 02:17:39.101432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:17:49.471750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test whether ``run`` method works as expected or not.
    """
    import os
    from ansible.utils.vars import merge_hash

    from ansible.plugins.action.setup import ActionModule
    from ansible.module_utils.facts import ansible_facts

    a = ActionModule(None, None)
    tmp = os.path.realpath('./fixtures/test')
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts': {'network_os': 'ios'},
        'ansible_facts_gathered': None,
        'ansible_env': {'HOME': '/Users/sdods'},
        'HOME': '/Users/sdods'
    }

    # mocks up the config.get_config_value method
    C

# Generated at 2022-06-21 02:17:57.287429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.legacy.setup as setup
    import ansible.executor.task_result as task_result
    import ansible.executor.task_queue_manager as task_queue_manager
    import types
    import os
    import sys

    # Create the class object without the constructor parameter, so it is the same as the one created in ansible, even the private parameter.
    # This is necessary since the module setting is not working in the unit test.
    ActionModule = action_plugin.ActionModule()

    # Create needed objects
    setup_module = setup.SetupModule()
    setup_module._connection = C.network.Connection('local', 1)
    setup_module._shared_loader_obj = None
    setup_module._templar = C.AnsibleTemplar()
    setup_module._task = task_result

# Generated at 2022-06-21 02:18:08.937355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(ansible_network_os='ios')
    test_ActionModule.task_vars = task_vars
    test_ActionModule.task_vars['ansible_facts'] = dict()
    connection_facts_modules = dict(ios='ios')
    C.config.CONNECTION_FACTS_MODULES = connection_facts_modules
    con = ActionModule(dict(verbosity=2, connection='network_cli', connection_user='root', connection_password='password', gather_facts='yes'),
                       dict(name='setup'), 0, '/root', '', '')
    assert (con.run(None, test_ActionModule.task_vars)['ansible_facts']['_ansible_facts_gathered'] == True)

# Generated at 2022-06-21 02:18:42.183545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task= {'id': 'test_setup_id',
                'action': 'test_setup_action',
                'args': {'key': 'value'},
                '_ansible_version': 'test_ansible_version',
                '_ansible_no_log': 'test_ansible_no_log',
                '_ansible_debug': 'test_ansible_debug',
                '_ansible_diff': 'test_ansible_diff',
                '_ansible_verbosity': 'test_ansible_verbosity'
                }
    mock_connection= {'_play_context': 'test_play_context',
                      '_play': 'test_play'
                      }
    mock_loaded_plugin_name= 'test_loaded_plugin_name'

# Generated at 2022-06-21 02:18:43.013689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:18:49.593491
# Unit test for constructor of class ActionModule
def test_ActionModule():

    _task = None
    _connection = None
    _play_context = None
    _loader = None
    _templar = None
    _shared_loader_obj = None

    module = ActionModule(_task, _connection, _play_context, _loader, _templar, _shared_loader_obj)

    assert module._task == _task
    assert module._connection == _connection
    assert module._play_context == _play_context
    assert module._loader == _loader
    assert module._templar == _templar
    assert module._shared_loader_obj == _shared_loader_obj

# Generated at 2022-06-21 02:18:59.895616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_path = os.path.join(os.path.dirname(__file__), 'test_action_module.py')
    module_name = 'test_action_module'
    module_args_valid = {
        'option': 'foo',
        'required_parameter': 'bar',
        'invalid_name': 'baz'
    }

    m = ActionModule(task=dict(action=dict(module_name=module_name)))
    m.setup()

# Generated at 2022-06-21 02:19:01.330684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" not in str(ActionModule)

# Generated at 2022-06-21 02:19:02.542244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True

# Generated at 2022-06-21 02:19:10.762855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    # setup task
    task = dict(
        action=dict(
            module='setup',
            args=dict()
        )
    )

    # setup task_vars
    task_vars = dict()

    # setup play
    play = dict(
        role=dict()
    )

    # setup play_context
    play_context = dict(
        basedir='',
    )

    # init ActionModule
    test_action_module = ActionModule(task, play, play_context, loader, templar, shared_loader_obj)

    # assert test_action_module attributes
    assert test_action_module._supports_check_mode is False
    assert test_action_module._task is task
    assert test_action_module._

# Generated at 2022-06-21 02:19:11.220010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:19:19.149853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host

    class MockModuleAction(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return {'aaa': 'bbb'}

    class MockTask(dict):
        def __init__(self):
            super(MockTask, self).__init__()
            self.args = {}

    class MockPlay(dict):
        def __init__(self):
            super(MockPlay, self).__init__()
            self._action_groups = {}

    class MockPlayContext(dict):
        def __init__(self):
            super(MockPlayContext, self).__init__()
            self._play = MockPlay

# Generated at 2022-06-21 02:19:31.116738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.module_utils.facts.virtual import VirtualCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    facts = {
        '_ansible_facts_gathered': False,
        'ansible_facts': {
            '_ansible_facts_gathered': True,
            'distribution': {
                'os_family': 'RedHat'
            }
        }
    }
    task_vars = {
        'ansible_facts': facts['ansible_facts']
    }
    action_module = ActionModule()
    action_module._display = MockDisplay()
    action_module._task = MockTask(action_module)
    action_module._task.vars = task_vars
    action_module._task.args = {}
   

# Generated at 2022-06-21 02:20:19.463038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config_data = {
        'FACTS_MODULES': ['setup'],
        'CONNECTION_FACTS_MODULES': {'_default': 'ansible.legacy.setup'},
        }

    class ActionModuleImpl(ActionModule):

        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            if module_name == 'setup':
                return {'ansible_facts': {'test1': 'foo'}, '_ansible_verbose_override': True}
            return {'ansible_facts': {'test2': 'bar'}, '_ansible_verbose_override': True}

    task_impl = {'args': dict()}
    task_impl['args']['network_os'] = 'test_os'

# Generated at 2022-06-21 02:20:20.182845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:20:25.411692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)
    assert hasattr(am, '_connection')
    assert hasattr(am, '_task')
    assert hasattr(am, '_display')
    assert hasattr(am, '_loader')
    assert hasattr(am, '_templar')
    assert hasattr(am, '_shared_loader_obj')

# Generated at 2022-06-21 02:20:36.476794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager

    output = {}
    def vvv(value):
        output['vvv'] = value
    def info(value):
        output['info'] = value
    def warning(value):
        output['warning'] = value
    def deprecate(value):
        output['deprecate'] = value
    def error(value):
        output['error'] = value

    def _get_task(fact_module, task_args, module_defaults={}, connection='network_cli'):
        play = Play()


# Generated at 2022-06-21 02:20:47.445977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This does not yet test for any actual facts being returned if desired
    # This does not test for facts modules being run
    # This does not test for parallel
    # This does test for the correct execution of tasks
    a = ActionModule({'parallel': 'False'}, {'connection': True}, {'_ansible_facts_gathered': True})
    check = a.run({'ansible_facts': {'network_os': 'testing'}}, {'ansible_network_os': 'testing'})
    for i in ['ansible_facts', 'failed', 'failed_modules', 'msg', 'skipped_modules', '_ansible_verbs_override']:
        assert i in check
    assert check['ansible_facts']['_ansible_facts_gathered'] is True

# Generated at 2022-06-21 02:20:58.149251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # false positive with constructors
    # pylint: disable=R0918
    # create an instance of ActionModule
    action_mod = ActionModule(
        task=dict(
            args=dict(
                a=1,
                b=2,
                c=3,
                d=4,
                e=5,
                f=6,
                g=7,
                h=8
            ),
            _ansible_no_log=False
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # assert that the connection is of type Connection
    assert isinstance(action_mod._connection, ActionBase._connection.__class__)

    # assert that the templar is of type Templar


# Generated at 2022-06-21 02:20:59.127275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(main.argument_spec, main.supports_check_mode)

test = None


# Generated at 2022-06-21 02:21:00.502451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:21:08.575228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.module_utils.common.network as network
    import ansible.utils.vars as ansible_vars
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import merge_hash
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.loader import shared_loader_obj
    import mock
    import os


# Generated at 2022-06-21 02:21:16.880967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dummy_self = type('dummy', (), {})

    # Test with a valid argument
    dummy_self.task_vars = {"ansible_facts_parallel": False}
    dummy_self.task_vars["ansible_facts_parallel"] = False
    act = ActionModule(dummy_self)
    assert act is not None

    # Test with invalid argument
    invalid_dict = {"ansible_facts_parallel": 'false'}
    dummy_self.task_vars = invalid_dict
    dummy_self.task_vars["ansible_facts_parallel"] = 'false'
    act = ActionModule(dummy_self)
    assert act is not None

# Generated at 2022-06-21 02:22:57.752799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:22:59.779238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:23:02.440857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-21 02:23:03.970810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # TODO: implement test
    return

# Generated at 2022-06-21 02:23:04.785758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:23:14.772983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
        'name': 'GATHERING FACTS',
        'action': 'setup',
        'args': {
            'gather_subset': ['all'],
            'filter': '*'
        }
    }
    task_vars = {
        'ansible_facts': {
            'network_os': 'Juniper',
            'ifconfig': {
                'pppoe0': {'ipv4': '192.168.25.1'},
                'em0': {'ipv4': '10.90.90.1'}
            }
        },
        'ansible_network_os': 'Juniper',
        'ansible_check_mode': False
    }

# Generated at 2022-06-21 02:23:15.619116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for new action instance
    assert ActionModule() is not None

# Generated at 2022-06-21 02:23:16.436594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:24.961556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars, load_options_vars
    loader = DataLoader()

# Generated at 2022-06-21 02:23:28.634356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing constructor with dummy values
    module = ActionModule()
    assert 'ActionModule' == module.__class__.__name__

    # Testing module.run() method
    assert False