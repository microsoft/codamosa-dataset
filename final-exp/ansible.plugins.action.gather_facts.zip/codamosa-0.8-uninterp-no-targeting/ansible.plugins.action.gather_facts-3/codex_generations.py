

# Generated at 2022-06-21 02:16:29.590755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    spec = {'run': {'type': 'object', 'properties': {'param1': {'required': False, 'type': 'string'}}}}
    task_vars = {}
    args = {}
    obj = ActionModule('test_playbook', 'test_task', {}, spec, {}, {}, task_vars, args)
    assert(obj.task_vars == task_vars)
    assert(obj.task_vars == task_vars)
    assert(obj.action_vars == args)

# Generated at 2022-06-21 02:16:31.316078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action =  ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._supports_check_mode is True

# Generated at 2022-06-21 02:16:31.954078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,None)

# Generated at 2022-06-21 02:16:40.796176
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    import ansible.plugins.loader
    import ansible.plugins.action.setup

    class TestActionModuleClass(ActionModule):
        pass

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.action = TestActionModuleClass(
                'test',
                {'a': '1', 'b': '2'},
            )
            self.action._supports_async = True
            self.action._task = ansible.plugins.loader.TaskLoader(
                None,
                {
                    'name': 'test',
                    'action': 'test',
                },
            )

# Generated at 2022-06-21 02:16:42.210089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement test_ActionModule
    pass

# Generated at 2022-06-21 02:16:42.730391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:16:49.596380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.parsing.convert_bool import boolean

    module = ActionModule()

    # Test constructor of class ActionModule
    assert isinstance(module, ActionModule)
    assert isinstance(module, ActionBase)

    # Test _get_module_args
    module._task = 'default'
    module._task = TaskResult(host='192.168.0.0', task='default', return_data={}, task_items=['default'])
    module._task.args = {'gather_subset': 'all', 'gather_timeout': 5, 'filter': 'ansible_distribution'}

# Generated at 2022-06-21 02:16:50.737684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am.run(None, None) is not None

# Generated at 2022-06-21 02:16:55.054627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    task_vars['ansible_smart_facts'] = 'default'
    task = dict()
    action = dict()
    tmp = '/tmp'
    action_module = ActionModule(task, action, tmp, task_vars, connection='network_cli', play_context={}, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None



# Generated at 2022-06-21 02:17:03.806952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options():
        _connection = None

    class Task():
        def __init__(self):
            self.args = {'network_os': 'cisco_ios'}
            self.action = 'GATHERING FACTS'
            self.module_defaults = {}
            self.collections = []

    class Host():
        def __init__(self):
            class connection():
                def __init__(self):
                    self._load_name = 'network_cli'
                pass
            self._connection = connection()


    class Play():
        def __init__(self):
            self._action_groups = []

    class TaskResult():
        def __init__(self):
            self.ansible_facts = {}
            self.warnings = {}
            self.deprecations = {}



# Generated at 2022-06-21 02:17:16.430035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionBase)
    assert action._supports_check_mode == True

# Generated at 2022-06-21 02:17:18.222741
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test imported module ActionModule
    method_run = getattr(ActionModule, ActionModule.run.__name__)
    assert callable(method_run)

# Generated at 2022-06-21 02:17:20.840004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No tests for this class yet"


# Generated at 2022-06-21 02:17:27.199041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule as AM 

    c = AM(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=MockSharedLoaderObj())

    assert c is not None

# Generated at 2022-06-21 02:17:36.515802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.module_docs_fragments
    argspec = ansible.utils.module_docs_fragments.get_action_args_spec('setup', 'action_plugins')


# Generated at 2022-06-21 02:17:47.670875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    # Check def_fqcn after initializing and without running run() method
    assert am.def_fqcn == 'ansible.legacy.setup'
    # Check for C._ACTION_SETUP
    C._ACTION_SETUP.add(am.def_fqcn)
    assert am.def_fqcn in C._ACTION_SETUP
    # Check for C._ACTION_SETUP in version 2.8
    C._ACTION_SETUP.remove(am.def_fqcn)
    C._ACTION_SETUP.add('ansible.builtin.setup')
    assert 'ansible.builtin.setup' == am.def_fqcn

# Generated at 2022-06-21 02:17:50.103525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: mock actually-used classes with unittest.mock
    pass

# Generated at 2022-06-21 02:18:00.008769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    config = C.Config(
        connection_plugin='network_cli'
    )
    loader = C.DataLoader()
    variable_manager = C.VariableManager(loader=loader, inventory=C.Inventory())
    variable_manager._extra_vars = {'ansible_network_os': 'eos'}

# Generated at 2022-06-21 02:18:10.414115
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:18:21.026874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # UnsupportedAction is a subclass of AnsibleAction
    class TestActionModule(ActionModule):
        pass

    tmp = "/tmp"
    task_vars = dict()
    test_action_module = TestActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    result = test_action_module.run(tmp=tmp, task_vars=task_vars)
    assert(result["ansible_facts"] == dict())
    assert(result["failed"] is None)
    assert(result["msg"] is None)
    assert(result["skipped"] is None)
    assert(result["skipped_modules"] is None)

# Generated at 2022-06-21 02:18:42.696333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:18:50.655718
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Mock expected parameters by a mock object
    class MockTask():
        def __init__(self):
            self._task = 'ansible.legacy.setup'
            self.args = {}
            self.module_defaults = {}
            self._parent = 'ansible.legacy.setup'
    class MockTemplar():
        def __init__(self):
            pass
        def template(self, template_data, preserve_trailing_newlines=True, escape_backslashes=True, *args, **kwargs):
            return template_data
    class MockDisplay():
        def __init__(self):
            pass
        def warning(self, warning_string):
            return warning_string
    class MockSharedLoaderObj():
        def __init__(self):
            pass

# Generated at 2022-06-21 02:18:59.944508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection()

    module = ActionModule()

    config = Config()

    config.set_config_value('FACTS_MODULES', ['smart', 'ansible.legacy.setup'])

    module._connection = connection
    module._task = Task(
        action=dict(action_data_structure=dict()),
        task_data_structure=dict(),
        loader=Loader(),
        templar=Templar(loader=Loader()),
        shared_loader_obj=Loader(),
        connection=connection,
        task_vars=dict(),
        play_context=PlayContext(),
        role_context=RoleContext(),
        loader_cache=dict(),
        config=config,
        _task_fields=dict()
    )

    module.run()

# Generated at 2022-06-21 02:19:00.819506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:19:08.483541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to test
    from ansible.plugins.action import ActionModule
    mod_obj = ActionModule(play_context=None, new_stdin=None)
    # define the test data.
    tmp = None
    task_vars = dict()
    # execute the run method with the data provided
    result = mod_obj.run(tmp=tmp, task_vars=task_vars)
    # assert if result is not as expected
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-21 02:19:09.323273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:19:10.890980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass  # no special test cases as of yet

# Generated at 2022-06-21 02:19:20.088731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init fixtures
    file_name = '/etc/ansible/facts.d/'
    if not os.path.exists(file_name):
        os.makedirs(file_name)
    f = open(file_name + "fact_facts.fact", "w")
    f.write("foo=bar")
    f.close()
    # init result
    result = {
        'ansible_facts': {
            'fact_facts': 'value'
        },
        'ansible_warnings': [],
        'ansible_deprecations': []
    }
    # inti C.config
    C.config._init_global_vars()

# Generated at 2022-06-21 02:19:28.188372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # method run of class ActionModule returns dict

    config={
        'FACTS_MODULES': ['apt', 'smart', 'ohai'],
        'CONNECTION_FACTS_MODULES': {
            'linux': 'ansible.legacy.setup'
             }
        }

    import ansible.constants as C
    import ansible.plugins.action as A
    import ansible.plugins.action.gather_facts as GF
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.ping as ping
    import ansible.plugins.connection as connection
    import ansible.plugins.loader as loader
    import ansible.module_utils.common.collections as collections_loader
    import ansible.module_utils.parsing.convert_bool as convert_bool
   

# Generated at 2022-06-21 02:19:40.926548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yml = '''---
    - hosts: localhost
      connection: local
      tasks:
        - name: dummy
          ansible.builtin.setup:
            filter: ansible_*
            gather_subset: all
    '''
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-21 02:20:24.504100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:20:28.435131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.setup as setup

    am = setup.ActionModule()
    assert am.NAME == 'setup'
    assert am._supports_check_mode is True

# Generated at 2022-06-21 02:20:38.013356
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # import needed dependencies
    import unittest
    from units.mock.loader import DictDataLoader

    # import needed classes
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    from ansible.plugins.action import ActionBase


    # set up test environment
    def setUpModule():
        pass

    # destroy test environment
    def tearDownModule():
        pass

    # set up test case
    def setUp(self):
        pass

    # destroy test case
    def tearDown(self):
        pass

    # test method

# Generated at 2022-06-21 02:20:38.411430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:20:47.898290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.distribution import DistributionFacts
    from ansible.module_utils.facts.system.system import SystemFacts
    from ansible.module_utils.facts.network.base import NetworkCollector
    import ansible.executor.task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars
    from ansible.vars.clean import module_response_deepcopy

    class MockTask(object):
        def __init__(self):
            self.action = 'setup'
            self.args = {}
            self.collections = []
            self.module_defaults = {}
            class MockParent(object):
                _play = None

# Generated at 2022-06-21 02:20:58.351932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Creates an instance of ActionModule and executes run() method of the instance """

    import unittest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.utils.vars import combine_vars

    #from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.plugins.callback import CallbackBase
    #from ansible.playbook.play_context import PlayContext
    #from ansible.executor.playbook_executor import PlaybookExecutor
    #from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    #from ansible.vars.manager import VariableManager
    #from ansible.executor.process.worker import WorkerProcess
    #from ansible.plugins.loader import plugin

# Generated at 2022-06-21 02:20:59.754893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the ActionModule class"""
    pass

# Generated at 2022-06-21 02:21:08.316631
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create an instance of class ActionModule
    am = ActionModule()

    # create an instance of class TaskExecutor
    te = TaskExecutor()

    # create an instance of class ActionModule
    am1 = ActionModule()

    # create an instance of class ActionModule
    am2 = ActionModule()

    # create an instance of class ActionBase
    ab1 = ActionBase()

    # create an instance of class ActionBase
    ab2 = ActionBase()

    # create an instance of class HostVars
    hv1 = HostVars()

    # create an instance of class PlayContext
    pc = PlayContext()

    # create an instance of class Task
    t = Task()

    # create an instance of class Play
    p = Play()

    # create an instance of class VariableManager
    vm = VariableManager()

    # create an instance of

# Generated at 2022-06-21 02:21:17.757788
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing with 1 module, no async processing
    modules = ['testmodule1']
    parallel = False
    result = {}
    tasks = [
        {
            'module': 'testmodule1',
            'args': {'arg1': 'val1'},
            'result': {'ansible_facts': {'factname': 'factvalue1'}}
        }
    ]

    # Testing with 1 module, async processing
    modules.append('testmodule2')
    parallel = True
    tasks.append(
        {
            'module': 'testmodule2',
            'args': {'arg2': 'val2'},
            'result': {'ansible_facts': {'factname': 'factvalue2'}}
        }
    )

    # Testing with multiple modules, async processing
    modules.append('testmodule3')

# Generated at 2022-06-21 02:21:27.227615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    result['ansible_facts'] = {}

    parallel = False

    modules = ["ansible.legacy.setup", "ansible.legacy.setup"]
    failed = {}
    skipped = {}
    if parallel:
        # serially execute each module
        for fact_module in modules:
            # just one module, no need for fancy async
            res = {}
            if res.get('failed', False):
                failed[fact_module] = res
            elif res.get('skipped', False):
                skipped[fact_module] = res
            else:
                result = merge_hash(result, res)

    else:
        # do it async
        jobs = {}

# Generated at 2022-06-21 02:23:12.087300
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(
        task=dict(action=dict(module='setup', args=dict())),
        connection=dict(host='localhost', port=23),
        play_context=dict()
    )

    assert module



# Generated at 2022-06-21 02:23:13.846542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(1, 1, 1)

# Generated at 2022-06-21 02:23:15.876448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 02:23:23.822661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock the connection_loader and module_loader
    connection_loader_mock = ConnectionLoader()
    module_loader_mock = ModuleLoader()

    mock_task = Task()

    # mock task._shared_loader_obj.connection_loader
    mock_task._shared_loader_obj = SharedLoaderObj()
    mock_task._shared_loader_obj.connection_loader = connection_loader_mock
    mock_task._shared_loader_obj.module_loader = module_loader_mock

    # mock task._connection
    mock_task._connection = EdgeRouter()

    # mock task.args
    mock_task.args = {}

    # mock task._parent
    mock_task._parent = Play()

    # mock task._task_fields

# Generated at 2022-06-21 02:23:34.525555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    
    # test case: success
    modules = ['ansible.legacy.setup']
    tmp=None 
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['_ansible_facts_gathered'] = False
    result = actionModule.run(tmp, task_vars)
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

    # test case: failure
    task_vars['ansible_facts']['_ansible_facts_gathered'] = False
    
    result = actionModule.run(tmp, task_vars)
    assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-21 02:23:38.442044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule
    """
    action_mod = ActionModule(
        task=dict(action=dict(module_name='test1', module_args=dict(param1='test_param'))),
        connection=dict(transport='local'),
        play_context=dict(become=False, become_method=None, become_user=None, check_mode=False,
                          diff_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_mod

# Generated at 2022-06-21 02:23:43.740554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule class
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Assert action_module is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:23:54.392399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run"""

    # preparing mocks

    # mocks for attributes ansible_facts_parallel and args from class TaskExecutionContext

    ansible_facts_parallel = 'ansible_facts_parallel'

    args = dict()

    args['parallel'] = 'parallel'
    args['network_os'] = 'network_os'

    mock_task_execution_context = type('MockTaskExecutionContext', (object,), {})
    mock_task_execution_context.ansible_facts_parallel = ansible_facts_parallel
    mock_task_execution_context.args = args

    # mocks for attributes FACTS_MODULES and CONNECTION_FACTS_MODULES from class AnsibleConfig


# Generated at 2022-06-21 02:23:55.612068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()
    am.run()

# Generated at 2022-06-21 02:24:00.878802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ModuleTest
    test = ActionModule(m, {"name": "ansible.builtin.setup"}, {})
    res = test._get_module_args(m._fqn, m.task_vars)
    assert(res == {"filter": "all"})