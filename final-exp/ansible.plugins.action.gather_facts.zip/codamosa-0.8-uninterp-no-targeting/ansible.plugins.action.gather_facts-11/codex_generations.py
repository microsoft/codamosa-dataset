

# Generated at 2022-06-21 02:16:30.670215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unit
    task_vars = {}
    # settting for test
    C._ACTION_SETUP.append('ansible.module.test_module')
    C.config.set_config_value('FACTS_MODULES', ['smart'])
    C.config.set_config_value('CONNECTION_FACTS_MODULES', {'network_os': 'ansible.module.test_module'})
    module_name = 'ansible.module.test_module'
    module_args = {'arg1': 'arg1_val1', 'arg2': 'arg2_val2'}
    task_vars['ansible_facts_parallel'] = True

# Generated at 2022-06-21 02:16:40.456845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    context.CLIARGS = context.CLIARGS._replace(module_path='')

    args = {'filter': 'ansible_distribution*'}
    tmp = '/tmp'
    task_vars = {
        'ansible_facts': {
            'ansible_distribution': 'Ubuntu',
            'ansible_distribution_version': '14.04',
            'ansible_distribution_release': 'trusty',
            'ansible_distribution_major_version': '14',
            'ansible_distribution_file_parsed': True,
        }
    }

    action_module = ActionModule()

# Generated at 2022-06-21 02:16:48.027352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import imp
    import ansible.plugins.action.setup
    action = ansible.plugins.action.setup.ActionModule(
        task=TaskStub(),
        connection=ConnectionStub(),
        play_context=PlayContextStub(),
        loader=imp.new_module('loader'),
        shared_loader_obj=imp.new_module('shared_loader_obj'),
        templar=imp.new_module('templar'))
    module_name = 'test_module'
    module_args = {'test_arg': 'test_value'}
    task_vars = TaskVarsStub()
    # Ensure run method returns a dict
    assert isinstance(action.run(module_name, module_args, task_vars), dict)



# Generated at 2022-06-21 02:16:57.913479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup')),
        connection=dict(
            _connection_plugin_path='ansible.plugins.connection',
            _connection_plugin=None,
            _connect_timeout=3,
            _connect_lock_path='/path/to/ansible/config/lock/connecting'
        ),
        play_context=dict(
            check_mode=False,
            diff=False,
            new_vault_password_file='',
            user_password_file='',
            vault_password_file='',
            verbosity=4,
            become=False,
            become_method='sudo',
            become_user='root',
            become_ask_pass=False
        )
    )
    return action_module

# Generated at 2022-06-21 02:17:09.506579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock objects
    module_args = {'path': '/nonexistent', 'state': 'absent'}
    mocker_task_args = {'module_defaults': {}, 'module_name': 'file', 'module_args': module_args}
    mocker_task = mocker.Mock(**mocker_task_args)
    mocker_task._parent._play._action_groups = {'always': {}, 'changed': {}, 'failed': {}, 'meta': {}, 'never': {}, 'success': {}}
    mocker_task_vars = {'ansible_facts': {}}

# Generated at 2022-06-21 02:17:10.936815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # just test the constructor for now
    action_module = ActionModule('setup', {})
    assert action_module

# Generated at 2022-06-21 02:17:13.078100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_class = ActionModule()
    assert hasattr(module_class,"run")

# Generated at 2022-06-21 02:17:20.303485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from copy import deepcopy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # Create a dict object to be passed as args to TaskQueueManager.
    task_queue_manager_args = dict()
    task_queue_manager_args['inventory'] = None
    task_queue_manager_args['variable_manager'] = VariableManager()
    task_queue_manager_args['loader'] = None
    task_queue_manager_args['options'] = None
    task_queue_manager_args['stdout_callback'] = None
    # Creating a TaskQueueManager instance.

# Generated at 2022-06-21 02:17:21.830780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This test case is used to test the execution of the method run() of the class ActionModule
    """
    pass

# Generated at 2022-06-21 02:17:31.410738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    C.config.initialize()
    task = Mock()
    task.args = {}
    task.action = 'setup'
    task.name = 'setup'
    task.args = {'fetch_nested': 'no'}
    task.collections = [('ansible_collections', 'ansible.builtin')]
    action_module = ActionModule(task, connection=None, play_context=Mock(), loader=None, templar=None, shared_loader_obj=Mock())
    action_module.final_q = Mock()

    # Mock default_fact_module when run() method is invoked
    class MockModule:
        def __init__(self, ansible_fact):
            self.resolved_fqcn = 'ansible.builtin.setup'
            self.ANSIBLE_

# Generated at 2022-06-21 02:17:50.581196
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test for no network_os given when network_os is required.
    def test_no_network_os():
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                     templar=None, shared_loader_obj=None)

        modules = ['smart']
        parallel = None
        task_vars = {
            'ansible_connection': 'network_cli',
            'ansible_network_os': ''
        }
        with pytest.raises(Exception) as excinfo:
            action_module._create_jobs(modules, parallel, task_vars)
        message = str(excinfo.value)
        assert message == 'Network_os is required to determine which connection plugin to use'

    # Test for no connection plugin.

# Generated at 2022-06-21 02:17:58.254408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader, module_loader
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 02:18:09.760372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_arguments = {'module': 'setup', '_uses_shell': False, '_raw_params': '', '_task_fields': ['module'],
                         'action': 'setup', 'connection': 'local', 'playbook_dir': '/usr/share/ansible',
                         'no_log': False, '_ansible_check_mode': False,
                         '_ansible_verbosity': 2, '_ansible_syslog_facility': 'LOG_USER', 'args': {}}
    action_module = ActionModule(ansible_arguments)

    # Test for _get_module_args function
    assert action_module._get_module_args('setup', {}) == {}

# Generated at 2022-06-21 02:18:19.351133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act_mod = ActionModule()

    mock_result = {
        'ansible_facts': {}
    }
    mock_task_vars = {}

    module_name = 'debug.setup'
    module_args = {'verbosity': 3, 'verbose_override': True}
    mock_task_vars['ansible_facts_gathered'] = False

    result = act_mod.run(task_vars=mock_task_vars, tmp=None)

    assert result['ansible_facts'] == {}
    assert result['_ansible_verbose_override'] is True
    assert result == mock_result

# Generated at 2022-06-21 02:18:31.019333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initializing objects for testing
    task = Task()
    task.__dict__['args'] = {'ansible_facts_parallel': False, 'parallel': False}
    task.__dict__['_play'] = Play()
    task.__dict__['_play'].__dict__['_tqm'] = TaskQueueManager()
    action_module = ActionModule()
    action_module.__dict__['_task'] = task
    action_module.__dict__['_connection'] = Connection()
    action_module.__dict__['_display'] = Display()
    action_module.__dict__['_shared_loader_obj'] = SharedPluginLoaderObj()

# Generated at 2022-06-21 02:18:42.584423
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ast
    import os
    import sys
    import json
    import subprocess
    import tempfile

    # Initialise variables for the module.
    dest_file = None
    module_name = "copy"
    module_arguments = dict()
    action_plugin_name = "copy"
    action_plugin_path = "./plugins/action"
    ansible_result = dict()
    env = dict()
    run_command = ""
    kwargs = dict()
    kwargs["ansible"] = dict()
    kwargs["ansible"]["playbook"] = dict()
    kwargs["ansible"]["playbook"]["filename"] = "test.yml"
    kwargs["ansible"]["inventory"] = dict()

# Generated at 2022-06-21 02:18:44.511743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None)
    assert type(x) == ActionModule

# Generated at 2022-06-21 02:18:48.181882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(
        task=dict(args=dict()),
        connection='ssh',
        play_context=dict(become_method='sudo'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-21 02:18:59.431011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_shell = Mock()
    mock_connection = Mock()
    mock_connection._shell = mock_shell
    mock_task = Mock()
    mock_task._parent = Mock()
    mock_task._parent._play = Mock()
    mock_task.args = {'a': 1, 'b': 2}
    mock_task.module_defaults = {'a': 'a'}
    am = ActionModule(mock_task, mock_connection, 'no_tmp', 'no_play_context', 'loader', 'templar')
    assert am._task == mock_task
    assert am._connection == mock_connection
    assert am._play_context == 'no_play_context'
    assert am._loader == 'loader'
    assert am._templar == 'templar'


# Generated at 2022-06-21 02:19:03.174354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj = ActionModule(tmp, task_vars)
    obj.run(tmp, task_vars)

# Generated at 2022-06-21 02:19:16.304147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:19:17.762908
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()
    assert isinstance(module, ActionBase)
    assert hasattr(module, 'run')

# Generated at 2022-06-21 02:19:30.764826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Test_ActionBase(ActionBase):
        def __init__(self):
            self._supports_check_mode = True
            self._connection = None
            self._task = None
            self._templar = None
            self._loader = None
            self._shared_loader_obj = None
            self._play_context = None
            self._display = None
            self._task_vars = None

    class Test_Task:
        class Test_Play:
            class Test_ActionGroups:
                pass
            action_groups = Test_ActionGroups()

        def __init__(self):
            self.args = dict()
            self._parent = Test_ActionModule.Test_Inventory.test_host
            self._play = Test_ActionModule.Test_Play.Test_Play
            self._play._action_groups

# Generated at 2022-06-21 02:19:32.230083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    print(a)

# Generated at 2022-06-21 02:19:37.308829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    log = logging.getLogger('unit_test')
    log.setLevel(logging.CRITICAL)
    # Testing the constructor of class ActionModule
    obj = ActionModule(log)
    assert isinstance(obj, ActionBase)

# Generated at 2022-06-21 02:19:40.811283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test')
    assert action_module._supports_check_mode

# Generated at 2022-06-21 02:19:49.854421
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.stats import AggregateStats

    import json
    import pytest

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

    class FakeTask(object):
        def __init__(self, name, args):
            self.name = name
            self.args = args


# Generated at 2022-06-21 02:19:58.460138
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:20:02.434658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # accessors
    assert ActionModule._get_module_args is not None
    assert ActionModule._combine_task_result is not None
    assert ActionModule.run is not None

# Generated at 2022-06-21 02:20:12.006701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import module_loader_find_plugin
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    module_name = 'setup'
    module_args = {}
    module_kwargs = {}
    wrap_async = None
    task_vars = {}
    play_context = {}
    templar = None


# Generated at 2022-06-21 02:20:37.849459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-21 02:20:47.863815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests for the constructor of the ActionModule class.

    The purpose of this test case is to test (and document) the constructor for
    the ActionModule class.

    There is a small amount of logic in the constructor that may not be
    handled by the Ansible core code.

    """
    # environment variable set to current working directory
    os.environ['ANSIBLE_LIBRARY'] = '.'

    # create a fake task (this is a minimal task)
    fake_task = {'args':
                 {
                     'parallel': True
                 },
                 'modules': [],
                 'collections': []
                 }

    # create a fake loader object (this is a minimal loader object)

# Generated at 2022-06-21 02:20:51.105396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:20:59.176043
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test ActionModule constructor"""
    return_status = 0

# Generated at 2022-06-21 02:21:08.107579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor import task_result
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager


    sampleinventory = {
        "vars": {
            "application": "test"
        },
        "all": {
            "hosts": ["test1"],
            "vars": {
                "region": "us-west-2"
            }
        },
    }

    t = Task()

# Generated at 2022-06-21 02:21:12.929959
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule(load_name='test', task=None, connection='test',
                          play_context=None, loader='test', templar='test',
                          shared_loader_obj='test')
    assert action._supports_check_mode == True

# Generated at 2022-06-21 02:21:15.272412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)



# Generated at 2022-06-21 02:21:16.113152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 02:21:19.759419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_mock = AnsibleMock()
    action_module = ActionModule(ansible_mock, ansible_mock._task)
    assert action_module

# Generated at 2022-06-21 02:21:21.830815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:22:25.352039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    action_module = ActionModule(
        task=dict(
            args=dict(
                foo='foo',
                bar=123,
                omnia='omnia',
                crescit=True
            ),
            async_val=10,
            async_poll_interval=5,
            action=dict(
                args=dict(
                    omnia='potestas',
                ),
            ),
            _ansible_no_log=True
        ),
        connection=dict(
            host=dict(
                port=22
            ),
        ),
        play_context=dict(
            port=22
        )
    )
    action_module._shared_loader_obj = None
    action_module._loader = None
    action_module._templar = None
    action

# Generated at 2022-06-21 02:22:29.090807
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    # Output within the module works when no module results are returned
    module.run()

    # Output within the module is disabled when module results are returned
    module.run()

# Generated at 2022-06-21 02:22:36.059611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import unfrackpath

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar

    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars, ensure_to_list
    from ansible.plugins.loader import lookup_loader



# Generated at 2022-06-21 02:22:38.336695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = 'dummy.plugin.loader'
    shared_loader = 'dummy.plugin.shared.loader'
    variable_manager = 'dummy.vars.manager'

    action = ActionModule(loader=loader, variable_manager=variable_manager, shared_loader=shared_loader)
    assert action._loader == loader
    assert action._shared_loader == shared_loader
    assert action._variable_manager == variable_manager

# Generated at 2022-06-21 02:22:45.922767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    data = dict(
        _connection = dict(
            _shell = dict(
                tmpdir = '/tmp'
            ),
            _load_name = 'network_cli'
        ),
        _task = dict(
            args = dict(
                gather_subset= 'all'
            ),
            module_defaults = dict(
                gather_subset= 'all'
            ),
            collections = 'test'
        ),
        _shared_loader_obj = dict(
            module_loader = dict(
                find_plugin_with_context = 'test'
            )
        )
    )

    action_module = ActionModule()
    action_module.__dict__.update(data)

    action_module._get_module_args('test', dict(ansible_network_os = 'test'))

    action

# Generated at 2022-06-21 02:22:53.720665
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:22:55.576878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)



# Generated at 2022-06-21 02:23:02.889016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_path = os.path.dirname(__file__)
    results_dir = os.getcwd()

    module_name = 'file'
    module_args = dict(path=os.path.join(module_path, 'data'))

    task_vars = dict(
        ansible_facts_gathered_result='_raw_params',
        ansible_facts_gathered_cache='_used_cache',
        ansible_facts_gathered_warnings='_warnings',
        ansible_facts_gathered_network_os='_network_os',
    )

    connection = Connection(task_vars['ansible_host'], '', '', '', '', task_vars)

# Generated at 2022-06-21 02:23:04.233994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a

# Generated at 2022-06-21 02:23:14.529017
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys

    # mock the task so we can test the method
    test_task = type("MockTask", (object,), dict(
        args=dict(
            default_facts=False
        ),
        module_defaults=dict()
    ))()

    # mock the loader so we can test the method
    class MockLoader:
        def find_plugin_with_context(self, plugin_name, collection_list):

            class MockResult:
                def __init__(self, result_1, result_2):
                    self.resolved_fqcn = result_1
                    self.name = result_2

            if plugin_name in ('ansible.legacy.setup', 'ansible.legacy.async_status'):
                return MockResult('', '')

            return MockResult(plugin_name, plugin_name)

# Generated at 2022-06-21 02:25:17.124192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod

# Generated at 2022-06-21 02:25:26.163578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with params
    action = ActionModule('TEST_MODULE', 'TEST_BASIC', 'TEST_TASK', {'TEST_K1': 'TEST_V1', 'TEST_K2': 'TEST_V2'}, {'TEST_K1': 'TEST_V1', 'TEST_K2': 'TEST_V2'}, {'TEST_K1': 'TEST_V1', 'TEST_K2': 'TEST_V2'}, 'TEST_LOADER_OBJ', 'TEST_TASK_OBJ', 'TEST_PLAYBOOK_OBJ')
    assert action._name == 'TEST_MODULE'
    assert action._display.verbosity == 3
    assert action._uses_shell is False

# Generated at 2022-06-21 02:25:28.024082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    test_module = ActionModule()

    # Assertion
    assert isinstance(test_module, ActionModule)



# Generated at 2022-06-21 02:25:30.023314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running a test to possibly see if I can find a way to test this code")
    assert 2 == 2 # <-- We probably need a better way to test

# Generated at 2022-06-21 02:25:36.832556
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Mod():
        def __init__(self):
            self.__dict__.update({'_ansible_options': Mod(), '_ansible_select_destination': 'test'})
        def _get_action_args(self):
            return dict()

    class Task():
        def __init__(self):
            self.__dict__.update({'args': dict(), '_ansible_options': Mod(), '_parent': 'test', 'module_defaults': None,
                                  'collections': [], 'action': None})
        def get_argument_spec(self, no_params=False):
            return dict()

    class Play():
        def __init__(self):
            self.__dict__.update({'_action_groups': dict(), '_action_groupings': dict()})


# Generated at 2022-06-21 02:25:43.961562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig

    action_module = ansible.plugins.action.setup.ActionModule({"mock": True}, load_provider(NetworkConfig(indent=None, contents='', running_config='')), False, '/path/to/nowhere', 'action_plugins', 'setup')

    action_module._connection._shell.tmpdir = '/tmp/test'
    action_module._display.verbosity = 4
    action_module._supports_check_mode = True
    action_module._task.action = 'setup'

# Generated at 2022-06-21 02:25:45.243404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:25:49.846048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock task object and make sure it's type is correct
    task = ActionModule(dict(a=1), dict(b=2))
    assert isinstance(task, ActionBase)

# Generated at 2022-06-21 02:25:54.173655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.setup

    results = {}
    results['ansible_facts'] = {}
    results['warnings'] = []
    results['deprecations'] = {}

    mods = ['ansible.legacy.setup', 'ansible.legacy.ping']
    t_vars = {}
    am = ansible.plugins.action.setup.ActionModule(dict(FACTS_MODULES=mods), results, t_vars)
    assert am._task.args.get('gather_subset') == 'all'

# Generated at 2022-06-21 02:26:05.123707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # mocks
    class MockTask():
        def __init__(self, args, module_defaults):
            self._parent = self
            self.args = args
            self.module_defaults = module_defaults

    class MockTaskExecutor():
        def __init__(self, connection):
            self._shell = connection
            self._connection = connection
            self._loader = self
            self._templar = self
            self._shared_loader_obj = self

    # instantiation of an ActionModule instance
    args = {
        'setup': {},
        'filter': 'ansible_distribution',
        'network_os': 'ios',
        'gather_subset': ['!all'],
        'gather_timeout': 10,
        'connection_type': 'ios',
    }
    module_default