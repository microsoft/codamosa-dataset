

# Generated at 2022-06-21 02:16:30.558260
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:16:36.618746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This will test the run method of the ActionModule class (which is the class that handles the 'setup' action)
    """
    # Setup Mogrify and set the expected results
    mock_Mogrify = Mogrify()
    mock_Mogrify.set_expected_result(True)

    # Setup the TaskExecutor with the mock Mogrify
    mock_TaskExecutor = TaskExecutor(mock_Mogrify)

    # Setup the mock TestRunner, passing in the mock TaskExecutor
    mock_Runner = TestRunner(mock_TaskExecutor)

    # Setup the mock shared loader object
    mock_shared_loader_obj = SharedLoaderObject()

    # Setup the mock playbook object, passing in the mock Runner
    mock_playbook = PlaybookObject(mock_Runner)

    # Setup the mock variable

# Generated at 2022-06-21 02:16:43.209710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    ) is not None

# Generated at 2022-06-21 02:16:53.376657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    result = dict()
    result['ansible_facts'] = dict()
    result['ansible_facts']['_ansible_facts_gathered'] = True
    result['_ansible_verbose_override'] = True
    class MockTask:
        def __init__(self):
            self.args = dict()
            self.args['parallel'] = False
            self.collections = None
    class MockConfig:
        def get_config_value(self, name, variables=None):
            return ['smart']
    class MockPlay:
        def __init__(self):
            self._action_groups = dict()
    class MockPlayContext:
        def __init__(self):
            self._play = MockPlay()
            self._play._action_groups = dict()
   

# Generated at 2022-06-21 02:16:55.147288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    TestActionModule = ActionModule(None, None)
    assert TestActionModule

# Generated at 2022-06-21 02:16:56.234681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = module_4()
    assert m.run() == 1

# Generated at 2022-06-21 02:17:05.898937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = {'name': 'localhost'}
    loader = None
    task = {'args': {}, 'action': 'setup', 'name': 'setup', 'host': host}
    task_vars = {'ansible_facts': {}}
    shared_loader_obj = {'module_loader': True}
    templar = None

    class Display:
        verbose = True
        vvvv = True
        vvvvv = True

    connection = None
    action = ActionModule(task, connection, templar, task_vars, loader)
    action._task = task
    action._job = task
    action._display = Display()
    action._shared_loader_obj = shared_loader_obj

    result = action.run(None, task_vars)

# Generated at 2022-06-21 02:17:09.385100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(
        task=dict(
            action=dict(
                default=dict()
            )
        )
    )
    assert 'action' in m._task.keys()

# Generated at 2022-06-21 02:17:20.314469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task object so we can get a handle at the action module
    from mock import Mock
    from ansible.task import Task
    from ansible.playbook import Playbook
    from ansible.playbook import Play
    from ansible.executor import module_common


# Generated at 2022-06-21 02:17:25.380452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_args = dict(
        fact_module="list_operating_systems",
        gather_subset="all",
        gather_timeout=10
    )
    task_vars = dict()
    result = dict()
    tmp = "/tmp"
    test_action_module = ActionModule(task=dict(action=dict(args=mod_args)), connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(test_action_module, ActionModule)
    assert test_action_module.run(tmp, task_vars) is not None

# Generated at 2022-06-21 02:17:47.204227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for class ActionModule
    """

# Generated at 2022-06-21 02:17:49.494292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._supports_check_mode = True
    ActionModule.run()

# Generated at 2022-06-21 02:17:56.296509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ansible_facts_parallel = None
    test_tmp = None
    test_FACTS_MODULES = None
    test_task_vars = None

    # create an instance of the class
    action_module_obj = ActionModule(connection=None, _shared_loader_obj=None, task_vars=None)
    result = action_module_obj.run(tmp=test_tmp, task_vars=test_task_vars)

    assert result == {'failed': False, '_ansible_verbose_override': True, 'ansible_facts': {'_ansible_facts_gathered': True}}



# Generated at 2022-06-21 02:18:08.869030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake task
    class FakeActionModule():
        def __init__(self, task):
            self.task = task
    class FakeTask():
        def __init__(self, args):
            self.args = args
            self.module_defaults = None
            self.collections = None
        def __getattr__(self, attr):
            class FakeParent():
                def __getattr__(self, attr):
                    if attr == '_action_groups':
                        return None
                    if attr == '_play':
                        class FakePlay():
                            def __init__(self, ags):
                                self._action_groups = None
                                if ags is not None:
                                    self._action_groups = ags

# Generated at 2022-06-21 02:18:20.591200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    log_msg = []
    def log_write(msg):
        log_msg.append(msg)
    class Config:
        class ShellUtils:
            class AsyncPoller:
                def __init__(self, *args):
                    pass
    class Task(object):
        class _Parent(object):
            class _Play(object):
                _action_groups = {}
        _parent = _Parent()
        args = {}
        module_defaults = {}
    class Connection:
        def __init__(self, *args):
            self._shell = Config.ShellUtils()
            self._load_name = 'network_cli'
        def add_async_task(self, *args):
            return { 'results_file': '', 'ansible_job_id': '0' }

# Generated at 2022-06-21 02:18:31.656037
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1:
    _task = dict(
        args=dict(
            gather_subset='network',
            gather_timeout=10,
            filter='ansible_distribution',
        ),
        collections=[],
    )
    _play_context = dict()
    _loader = None
    _templar = None
    _shared_loader_obj = dict(
        module_loader=dict(
        find_plugin_with_context=lambda fact_module, x: dict(
            resolved_fqcn='',
        ),
    ))

# Generated at 2022-06-21 02:18:32.919314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:34.945133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)

# Generated at 2022-06-21 02:18:44.199206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import unittest

    # Mock Ansible
    # class ApiModule:
    #     def __init__(self, connection):
    #         pass
    #
    # class ApiArgumentSpec:
    #     pass
    #
    # class ApiFactsModule:
    #     def get_argument_spec(self):
    #         return ApiArgumentSpec()
    #
    #     def get_all_plugin_loaders(self):
    #         return [Apimodule]
    #
    # class ApiTaskLocalContext:
    #     def __init__(self, action_module_name, task_vars):
    #         self.action_module_name = action_module_name
    #         self.task_vars = task_vars
    #
    #

# Generated at 2022-06-21 02:18:49.983406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import __main__
    setattr(__main__, 'display', object())

    am = ActionModule(loader=object(), connection=object(), play_context=object(), task=object(), shared_loader_obj=object())

    assert am._supports_check_mode is True
    assert am.called is False
    assert am.connection is not None
    assert am.play_context is not None
    assert am.task is not None
    assert am.loader is not None
    assert am._tmpdir is not None
    assert am._remote_tmpdir is None
    assert am._result is None



# Generated at 2022-06-21 02:19:18.129920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    result['ansible_facts'] = {'_ansible_facts_gathered': True}
    result['ansible_facts']['_ansible_facts_gathered'] = True
    result['_ansible_verbose_override'] = True
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True

# Generated at 2022-06-21 02:19:20.586388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-21 02:19:28.571831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test calls method run of class ActionModule to simulate results that a module returns.
    # The reason of using a test method instead of a unit test is because the ActionModule class
    #  is the base class and it is always used by other modules. So it is normalized to simulate
    #  a method 'run' in the base class.
    import json
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader
    from ansible.parsing.dataloader import Data

# Generated at 2022-06-21 02:19:41.082895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.environ['ANSIBLE_STRATEGY'] = 'debug'
    C.config.set_config_value('ANSIBLE_STRATEGY', 'debug')
    C.config.set_config_value('CONNECTION_FACTS_MODULES', 'connection_map_dict')
    C.config.set_config_value('FACTS_MODULES', ['list_fact'])
    C.config.set_config_value('ANSIBLE_NETWORK_OS', 'network_os_str')


# Generated at 2022-06-21 02:19:42.369783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct object for class ActionModule
    ActionModule()

# Generated at 2022-06-21 02:19:44.249359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Create an object for setup class
    objActMod = ActionModule()

    assert True

# Generated at 2022-06-21 02:19:55.157398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unit_test
    import ansible.plugins.action

    ansible.plugins.action.ActionModule._execute_module = unit_test.DummyExecuteModule().execute_module
    class_actionmodule = ansible.plugins.action.ActionModule(
        task={},
        connection={},
        play_context={},
        loader={},
        templar={},
        shared_loader_obj={},
    )
    result = class_actionmodule.run()

# Generated at 2022-06-21 02:19:56.501397
# Unit test for constructor of class ActionModule
def test_ActionModule():

    plugin_class = ActionModule
    plugin_obj = plugin_class()

# Generated at 2022-06-21 02:20:07.341885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = None
    task_vars = {}
    action_module = ActionModule(task, connection=None, templar=None, shared_loader_obj=None)

    tmp = None
    task_vars = {}
    result = action_module.run(tmp, task_vars)

    assert result
    assert result.get('ansible_facts')
    assert result.get('ansible_facts').get('_ansible_facts_gathered') is True
    assert result.get('_ansible_verbose_override') is True



# Generated at 2022-06-21 02:20:12.672071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run(tmp, task_vars)

# Generated at 2022-06-21 02:21:03.364641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no options
    action_module = ActionModule(None, None)
    assert action_module

    # Test with some options
    action_module = ActionModule(None, None)
    assert action_module

# Generated at 2022-06-21 02:21:05.131689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()

# Generated at 2022-06-21 02:21:14.764376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # construct mock task and connection
    task = MagicMock(Task())
    connection = MagicMock(Connection())
    action_module_run_obj = ActionModule()

    # construct args to be passed to run method
    d = {'new_key': 'new_value'}
    task_vars = {'var': 'value'}
    task_vars.update(d)
    tmp = None

    # call run method of class ActionModule
    result = action_module_run_obj.run(tmp, task_vars)

    # assert that result is a dict
    assert isinstance(result, dict)

# Generated at 2022-06-21 02:21:16.014619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action._get_module_args('fakemodule', 'faketask') == dict()

# Generated at 2022-06-21 02:21:26.418764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import action_loader
    options = namedtuple('Options', ['connection', 'module_path', 'forks',
                                     'become', 'become_method', 'become_user', 'check',
                                     'diff', 'listhosts', 'listtasks', 'listtags', 'syntax'])

# Generated at 2022-06-21 02:21:35.954170
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.connection import Connection
    from ansible.plugins.strategy.setup import StrategyModule
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.executor.module_common
    import ansible.executor.module_common

    module_executor = ansible.executor.module_common.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert module_executor.run() is None

# Generated at 2022-06-21 02:21:43.349637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    assert module.run(tmp=None, task_vars=task_vars) == {'ansible_facts': {}, 'ansible_facts_gathered': True, '_ansible_verbose_override': True}

# Generated at 2022-06-21 02:21:55.508026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TaskMock:
        args = dict(module='command', executable='shell')

    class MockTask:
        def __init__(self):
            self.args = {'module_defaults': None, 'collections': None}

    class MockPlay:
        def __init__(self):
            self.action_groups = []

    class MockParent:
        def __init__(self):
            self._play = MockPlay()

    class MockTaskVars:
        def __init__(self):
            self.as_dict = dict(ansible_facts_parallel=None)

    class MockInventory(object):
        def __init__(self):
            self.hosts = dict()

    class MockDisplay(object):
        def __init__(self):
            self.vvvv = 'verbose'


# Generated at 2022-06-21 02:21:58.001501
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-21 02:22:09.876755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    task_vars = {}
    tmp = None
    modules = []
    parallel = None

    setattr(C.config, 'get_config_value', lambda x, y: modules)
    setattr(C._config, 'get_config_value', lambda x, y: modules)
    setattr(C._config, 'get_action_plugin', lambda x, y: modules)
    setattr(C.config, 'get_action_plugin', lambda x, y: modules)
    setattr(C._options, 'module_path', lambda x, y: modules)
    setattr(C.config, 'get_action_plugin', lambda x: modules)
    setattr(C._config, 'get_action_plugin', lambda x: modules)

# Generated at 2022-06-21 02:24:04.890661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.setup import ActionModule as SetupActionModule
    from ansible.plugins.action.setup import get_action_args_with_defaults

    class Host():
        def __init__(self, name):
            self.name = name
            self.port = 1
    class Task():
        def __init__(self, host):
            self.hosts = [host]

    task = Task(Host("host.name"))
    task_vars = {'test_key': 'test_val'}

    executor = SetupActionModule()
    executor._task = task
    executor._templar = None
    executor.set_loader(None)
    executor._loader = None

# Generated at 2022-06-21 02:24:09.854991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    a = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-21 02:24:10.953113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule(None, None) is not None)

# Generated at 2022-06-21 02:24:11.664449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule

# Generated at 2022-06-21 02:24:18.175002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for p in (
        {'ansible_facts': 1, 'ansible_facts_parallel': None},
        {'ansible_facts': {'_ansible_facts_gathered': True}, 'ansible_facts_parallel': None}
    ):
        am = ActionModule(dict(), p)

# Generated at 2022-06-21 02:24:19.622128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule.run()

# Generated at 2022-06-21 02:24:31.406734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import FactsModule
    from ansible.module_utils.facts import CommandBasedModule
    from ansible.module_utils.facts import NetworkModule
    from ansible.module_utils.facts import NetconfModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import DefaultPlatformFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import DefaultPackageManagerFactCollector
    from ansible.module_utils.facts.virtual.xen import XenServerHypervisorFactCollector
    from ansible.module_utils.facts.virtual.vmware import VmwareHypervisorFactCollector


    module = ActionModule()

    # test init
    assert module._module

    # test property connection


# Generated at 2022-06-21 02:24:41.298421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # 1. Test with invalid value to fact_module
    # Error should be thrown with message 'Invalid value None passed to FACTS_MODULES'
    # AssertionError message = 'Invalid value None passed to FACTS_MODULES'
    try:
        ActionModule('None')
    except AssertionError as e:
        assert str(e) == 'Invalid value None passed to FACTS_MODULES'

    # 2. Test with valid value to fact_module
    # Test should return ActionModule object
    # isinstance(object, classinfo)
    # Return true if the object argument is an instance of the classinfo argument.
    assert isinstance(ActionModule('ansible.legacy.setup'), ActionModule)

# Generated at 2022-06-21 02:24:52.751468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

# Generated at 2022-06-21 02:25:03.488236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """

    # -------------------------------------------------------------------------------
    # Test setup
    # -------------------------------------------------------------------------------
    import ansible_collections.ansible.builtin.plugins.module_utils.basic as basic
    from ansible_collections.ansible.builtin.plugins.modules.setup import Module as setup_module
    from ansible_collections.ansible.builtin.plugins.modules.setup import ActionModule as setup_action_module

    import ansible_collections.ansible.builtin.plugins.module_utils.network.common.network as common_network
    from ansible_collections.ansible.builtin.plugins.modules.network.fortios import Module as fortios_module
    from ansible_collections.ansible.builtin.plugins.modules.network.fortios import ActionModule as fortios_action_module