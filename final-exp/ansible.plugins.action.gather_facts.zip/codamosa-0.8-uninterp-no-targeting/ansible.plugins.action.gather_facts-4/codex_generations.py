

# Generated at 2022-06-21 02:16:27.745546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = object()
    task = object()
    shared_loader_obj = object()
    loader = object()
    templar = object()

    print('test_ActionModule no args')
    a = ActionModule(conn, task, shared_loader_obj, loader, templar)

    print('test_ActionModule with args')
    a = ActionModule(conn, task, shared_loader_obj, loader, templar, 'extra arg')

# Generated at 2022-06-21 02:16:35.733500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test that class constructor function option
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task is None
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None


# Generated at 2022-06-21 02:16:48.586216
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test with parallel=None, len(modules)>=1
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    result['ansible_facts'] = {}

    assert result['ansible_facts'] == {'_ansible_facts_gathered': True}
    # assert 'rsa_private_key' in result['ansible_facts']['ansible_ssh_host_key_ecdsa_public']
    assert result['ansible_facts']['ansible_ssh_host_key_ecdsa_public'].startswith("ecdsa-sha2")
    # assert 'rsa_private_key' in result['ansible_facts']['ansible_ssh_host_key_ed25519_public']

# Generated at 2022-06-21 02:16:48.953431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:16:58.251941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    templar = dict()

    # Define data for use in test case:
    # TODO(ahmedmadsen): mock _task
    tmp = None
    task_vars = dict(
        ansible_network_os='eos',
        ansible_facts=dict(
            network_os='eos',
            ansible_net_version='13.1M-maint'
        )
    )

    class MockConnection(object):
        def __init__(self, load_name='network_cli'):
            self._load_name = load_name

        def get_host_ip(self):
            return None

        def _shell(self):
            return 'shell'


# Generated at 2022-06-21 02:17:07.634829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for ActionModule.run"""

    # Initialize a Mock of class ActionModule
    mock_ActionModule = mock.Mock(spec=ActionModule)

    # Initialize a TaskExecutor object and run method on it
    mock_TaskExecutor = object()
    action_module_run_result = mock_ActionModule.run(mock_TaskExecutor)

    mock_ActionModule.run.assert_called_once_with(mock_TaskExecutor)
    assert action_module_run_result == mock_ActionModule.run.return_value

# Generated at 2022-06-21 02:17:19.851684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests when modules is greater than 1
    C.config.set_config_value('FACTS_MODULES', ['module1', 'module2'])
    C.config.set_config_value('CONNECTION_FACTS_MODULES', dict())

    # Create the action module object
    am = ActionModule()
    am._task = dict()
    am._task['args'] = dict()
    am._task['args']['parallel'] = None
    am._task['collections'] = []
    am._task._parent = dict()
    am._task._parent._play = dict()
    am._task._parent._play._action_groups = []

    am._set_connection_info(connection_options=dict())
    am._connection._shell = dict()

# Generated at 2022-06-21 02:17:26.408686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('', (), {})
    mock_task.args = { 'network_os': 'ios' }
    mock_task._play = type('', (), {})
    mock_task._play._action_groups = set()
    mock_task._parent = mock_task
    mock_connection = type('', (), {})
    mock_connection._play = type('', (), {})
    mock_connection._play.hostvars = {}
    mock_connection._load_name = 'network_cli'
    mock_connection._shell = type('', (), {})
    mock_connection._shell.tmpdir = 'a'
    mock_task._parent._task_vars = { 'ansible_network_os': 'ios' }

    mock_loader = type('', (), {})
    mock_shared_loader_obj = type

# Generated at 2022-06-21 02:17:36.080116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the test case
    test_task = {'args': {'filter': None, 'gather_subset': ['!all', '!min'], 'gather_network_resources': ['nxos'], 'gather_timeout': 10},
                 'module_defaults': {}, 'module_vars': {}}
    test_task_vars = {}
    test_tmp = '/tmp'

    # Test with parallel = None and len(modules) >= 1
    test_modules = ['module1', 'module2']
    test_parallel = None
    test_connection = {'_load_name': 'module1'}
    test_connection_ = {'_load_name': 'module2'}

# Generated at 2022-06-21 02:17:38.521992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test', "{'test':{'data'}}", {})
    assert action_module.task_vars == ({"test": {"data"}})



# Generated at 2022-06-21 02:17:57.122642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    modules = ['ansible.legacy.setup']

    config = {'FACTS_MODULES': ['ansible.legacy.setup']}

    ansible_facts_parallel = None
    temp_parallel = True
    args_parallel = None
    parallel = None
    if args_parallel is None and len(modules) >= 1:
        parallel = False
    else:
        parallel = boolean(parallel)

    assert parallel == temp_parallel



# Generated at 2022-06-21 02:17:59.081251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am is not None

# Generated at 2022-06-21 02:18:00.090606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:10.450131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test ActionModule class constructor """
    config = {'DEFAULT_MODULE_NAME': 'command'}
    task = {'args': {}, 'action': {}, 'name': 'command'}
    task_vars = {'ansible_connection': 'local', 'ansible_version': {'full': '2.1.1'}, 'myvar': 'test var value'}
    tmp = '/tmp'
    task_path = '/task_path'
    play_context = {'become': None, 'become_method': None, 'become_user': None, 'check_mode': False, 'connection': 'local', 'diff': False, 'forks': 2, 'remote_addr': None, 'remote_user': 'root', 'verbosity': False, 'version': 1}

# Generated at 2022-06-21 02:18:16.323880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object to test
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import connection_loader, module_loader

    context = PlayContext()
    pb_exec = PlaybookExecutor([])
    tqm = TaskQueueManager(pb_exec)
    tqm._unreachable_hosts = dict()
    tqm._stats = dict()
    tqm._tqm_stdout_callback = pb_exec._tqm_stdout

# Generated at 2022-06-21 02:18:18.129486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, None) is not None

# Generated at 2022-06-21 02:18:23.001010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor of class ActionModule
    action_module = ActionModule()
    assert action_module._shared_loader_obj.module_loader.find_plugin_with_context
    assert action_module.run

# Generated at 2022-06-21 02:18:32.990021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the method run of 'ActionModule' class

    ansible_connection = "local"
    ansible_host = "localhost"
    ansible_module_name = "setup"
    ansible_module_args = {'filter': 'ansible_all_ipv4_addresses'}

    # Test for class ActionModule
    task = "setup"
    Task = type('Task', (object,), {})
    task_obj = Task()
    task_obj.action = "setup"
    task_obj.async_val = 0
    task_obj.async_seconds = 0
    task_obj.notify = []
    task_obj._pre_run_tasks = []

    # Test for class Task
    variable_manager = "variable_manager"
    loader = "loader"

# Generated at 2022-06-21 02:18:43.316084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # module under test
    am = ActionModule(None, None, None)
    # mock the 'run()' method of the super class
    am.run = lambda self, tmp=None, task_vars=None: {'ansible_facts': {}}
    # mock the '_execute_module()' method
    am._execute_module = lambda self, module_name, module_args, task_vars, wrap_async=True: {'ansible_facts': {}}
    # mock the '_shared_loader_obj' property
    am._shared_loader_obj = {}
    # mock the 'resolved_fqcn' property
    am._shared_loader_obj.module_loader = {}

# Generated at 2022-06-21 02:18:44.652175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:19:11.504920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    A test to ensure the constructor of ActionModule is working as expected.
    """
    constant_task_vars = {'ansible_check_mode': 'False', 'ansible_facts_parallel': 'True', 'ansible_module_name': 'setup', 'ansible_user_id': 'root'}
    constant_task_args = {'filter': '*', 'gather_subset': 'all'}
    constant_task_action = 'setup'
    constant_task_async_val = 16e8
    constant_task_async_timeout_val = 5
    constant_task_tags = ['not_default']


# Generated at 2022-06-21 02:19:12.214572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:19:20.457221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes

    # define module input and expected output
    conn_facts_config = {'network_cli': 'ansible.netcommon.network_cli_facts'}

    input_task = {
        'module_defaults': {},
        'args': {}
    }
    input_task_vars = {}

    output = {
        'failed': False,
        'failed_modules': {},
        'ansible_facts': {
            '_ansible_facts_gathered': True
        },
        '_ansible_verbose_override': True
    }

    # create action class object
    action_class = ActionModule()
    action_class._task = input_task
    action_class._templar = None
    action_class._connection = MockConnection()

# Generated at 2022-06-21 02:19:23.932408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Using an empty task...
    task = dict()

    # Using an empty play_context...
    play_context = dict()

    # Create an instance of class ActionModule
    action_module = ActionModule(task=task, play_context=play_context)

    assert action_module is not None

# Generated at 2022-06-21 02:19:24.779739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:19:26.242099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule()
    assert test_object is not None


# Generated at 2022-06-21 02:19:28.574604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # When no args are passed during instantiation
    action_module = ActionModule()

    # constructor ensures that it sets these variables
    assert action_module._supports_check_mode == True

# Generated at 2022-06-21 02:19:32.667754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(action='setup', task=None, connection='network_cli', play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:19:43.225680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup initial objects for the test
    # ansible_module_run is the object to be used for testing
    # _task is used to create the initial object
    # tmp, task_vars are also needed
    # _execute_module is also needed to mock a function
    tmp = "tmp"
    task_vars = dict()
    task_vars['ansible_network_os'] = "root"
    modules = ['ansible.legacy.setup']
    C.config.initialize_config_object(modules)
    _task = dict()
    _task['args'] = dict()
    ansible_module_run = ActionModule()
    ansible_module_run._task = _task
    # mocking functions

# Generated at 2022-06-21 02:19:54.784988
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ModuleTest = type('Module', (object,), {'CHECK_MODE_MSG': 'some message', 'CHECK_MODE_NONE_MSG': 'some other message'})

    module_path = ''
    task = {'args': {'asdf': 42, 'jkl': 'xyz'}, 'action': {'__ansible_module__': 'some_module', '__ansible_arguments__': ['a', 'b', 'c']}, 'name': 'setup'}

    mtm = ActionModule(task, connection=ModuleTest(), play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:20:44.533611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(module_name='ansible.builtin.setup', task=None, connection=None,
                                 play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is False
    assert action_module._supports_reload is False
    assert action_module._supports_flush is False

# Generated at 2022-06-21 02:20:46.452917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode == True

# Generated at 2022-06-21 02:20:47.764318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-21 02:20:55.813066
# Unit test for constructor of class ActionModule
def test_ActionModule():
  class Task(object):
    args = {}
  class TaskArgs(object):
    pass
  t = Task()
  t2 = TaskArgs()
  t2.args = {}
  t.args = t2
  t3 = ActionModule(t, None, {})
  print('Create an instance of ActionModule: %s' % t3)
  print('Check its class type: %s' % type(t3))

# Unit test: Invoke the run function of class ActionModule

# Generated at 2022-06-21 02:21:06.650823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    # Test for validating method "run" of class "ActionModule"
    # Test scenario:
    # Make sure ActionModule is able to execute async and sync (when parallel is "true" or "False")
    # 1. Test valid scenario when modules are executed in parallel (parallel=True)
    # 2. Test valid scenario when modules are executed in sync (parallel=False)
    """
    # initialize ActionModule object
    action_module = ActionModule()
    # initialize task
    task = object()
    action_module._task = task
    # initialize other attributes of ActionModule object
    action_module._display = None
    action_module._supports_check_mode = False
    action_module._supports_async = False
    action_module._connection = None
    action_module._loader = None
    action_module._

# Generated at 2022-06-21 02:21:17.085666
# Unit test for constructor of class ActionModule
def test_ActionModule():

    mock_parsed_module_args = {
        'gather_subset': 'all'
    }

    mock_module_args = {
        'gather_subset': 'all'
    }

    mock_display = {
        'display': {
            'vvvv': 'mock_display',
            'warning': 'mock_warning'
        }
    }

    mock_task = {
        'args': mock_module_args,
        'module_defaults': 'mock_module_defaults',
        'collections': 'mock_collections'
    }


# Generated at 2022-06-21 02:21:17.903218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:21:19.894141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    assert True

# Generated at 2022-06-21 02:21:27.168744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_distribution'))),
        connection=dict(transport='cli'),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = mod.run(tmp='/tmp', task_vars=dict(network_os='eos'))
    assert result['ansible_facts']['ansible_distribution'] == 'Arista Networks EOS'
    assert result['_ansible_verbose_override'] is True

# Generated at 2022-06-21 02:21:32.058570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Testing constructor of Claass ActionModule
    fake_task = {
        'action': 'setup',
        'args':
            {'network_os': 'eos'},
        'delegate_to': 'localhost',
        'run_once': [],
        'transport': 'ssh',
        'only_if': None,
        'any_errors_fatal': False,
        'local_action': None,
        'when': [],
        'until': [],
        'retries': 3,
        'delay': 15,
        'register': 'ansible_facts'
    }

    fake_loader = {
        'module_plugin': 'AnsibleModule',
        'module_utils_plugin': 'AnsibleModuleUtils',
        'module_loader': 'AnsibleModuleLoader'
    }



# Generated at 2022-06-21 02:23:20.983105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'setup'
    args = {}
    TaskVars = {}
    module_name = 'setup'
    result = {}
    result['failed'] = False
    result['ansible_facts'] = {}
    result['_ansible_verbose_override'] = True
    result['ansible_facts']['_ansible_facts_gathered'] = True
    result['msg'] = "The following modules were skipped: %s\n" % (', '.join([]))

# Generated at 2022-06-21 02:23:33.568194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import tempfile

    class MockTemplar(object):
        def __init__(self):
            self.vars = {}

        def template(self, value, args):
            return value

    class MockModuleLoader(object):
        def __init__(self):
            self.modules = {
                'setup': ('ansible.legacy.setup', 'setup', None),
            }

        def find_plugin_with_context(self, name, collection_list=None):
            return self.modules.get(name, None)[0]

    class MockModule(object):
        def __init__(self, module_name):
            self.name = module_name

    class MockTask(object):
        def __init__(self):
            self.vars = {}
            self.args = {}
           

# Generated at 2022-06-21 02:23:39.782849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test if we can create an instance of the class
    """
    c = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert c is not None

# Generated at 2022-06-21 02:23:45.440176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test class ActionModule
    """

    def init_mock_config():
        """
        Inits mock config
        """
        C.config = BaseConfig()
        C.config.load_settings(dict()) # load with empty config

    def init_mock_task():
        """
        Inits mock task
        """
        # pylint: disable=attribute-defined-outside-init
        self._task = MagicMock()
        self._task.args = {}
        self._task.module_defaults = {}
        self._task._parent = MagicMock()
        self._task._parent._play = MagicMock()
        self._task._parent._play._action_groups = {}

    def init_mock_connection():
        """
        Inits mock connection
        """
        # pylint:

# Generated at 2022-06-21 02:23:49.206479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '_get_module_args')
    assert hasattr(ActionModule, '_combine_task_result')
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:23:56.893654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

# Generated at 2022-06-21 02:23:58.688085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:24:00.218586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-21 02:24:01.697388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For happy path test case

    # For various error cases
    pass

# Generated at 2022-06-21 02:24:13.129927
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Mock parameters to construct object
    mock_task = {
        'id': '1234',
        'name': 'testActionModule',
        'action': 'testActionModule',
        'collections': [],
        'args': {
            'network_os': None,
        },
    }
    mock_play = {
        'strategy': 'mitogen_linear',
        'name': 'testPlay',
        'hosts': 'testhost',
        'connection': 'network_cli',
        'gather_facts': 'no',
        'tasks': [
            mock_task,
        ],
        'post_tasks': [],
        'roles': [],
    }