

# Generated at 2022-06-21 02:16:25.926141
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an action module to run setup module
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict())),
        connection=dict(module=dict(name='connection')),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # Run the setup module
    result = action_module.run(tmp=dict(), task_vars=dict())
    print(result)

# Generated at 2022-06-21 02:16:38.530448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.callback.default import CallbackModule
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import io
    import json
    import os
    import tempfile
    import pytest
   

# Generated at 2022-06-21 02:16:49.710988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.collector import FactsCollector

    # Preparing mocks
    ansible_module_post_facts = {
        'command': '/bin/echo',
        'file': '/bin/bash',
        'selinux': {'enabled': False},
        'shell': '/bin/bash',
        'system': 'Linux',
        'user': 'stest',
        'distribution': 'Debian'
    }

    ansible_facts_post_facts = {
        'system': 'Linux',
        'user': 'stest'
    }


# Generated at 2022-06-21 02:16:54.698491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # testing unset values
    assert len(ActionModule.run()) == len(ActionModule.run(None, None))
    # testing with params
    tmpdir = '/tmp/ansible'
    task_vars = {'ansible_facts': {}}
    expected = {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}
    assert ActionModule.run(tmp=tmpdir, task_vars=task_vars) == expected

# Generated at 2022-06-21 02:16:55.496136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Provided by Ansible
    pass

# Generated at 2022-06-21 02:16:58.314269
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action
    import ansible.plugins.action.setup

    a = ansible.plugins.action.setup.ActionModule('a', 'b', 'c', 'd')
    assert a

# Generated at 2022-06-21 02:17:07.665743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing _get_module_args
    _task = { 'args' : { 'timeout': 333 } }
    _result = '333'
    _fact_module = 'ansible.legacy.setup'

# Generated at 2022-06-21 02:17:18.914085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(ansible_startup_task_id=None, ansible_task_id=None, ansible_verbosity=None, ansible_version=None,
                     ansible_version_full=None, ansible_run_tags=None, ansible_play_uuid=None, ansible_play_name=None,
                     ansible_play_hosts=None)
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    x = am.run(tmp=None, task_vars=task_vars)
    print(x)

# Generated at 2022-06-21 02:17:24.180777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None)
    a._templar = None
    a._get_module_args(None, None)
    a._supports_check_mode = True
    a.run(None, None)

# Generated at 2022-06-21 02:17:34.194526
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #
    # Test to check the variable 'modules' is set as expected
    #
    # params['modules'] should be set as per config
    #
    class Config(object):
        def get_config_value(self, value, variables):
            assert value == 'FACTS_MODULES'
            return ['foo', 'bar', 'baz']
    config = Config()
    modules = ['foo', 'bar', 'baz']

    #
    # Test to check if connection is not network remote, gather_subset is ignored
    #
    # params['connection'] should be 'network_remote'
    # params['modules'] should not be 'all'
    #
    connection = 'network_remote'
    modules = ['all']


# Generated at 2022-06-21 02:17:48.904390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host1 = host(name='host1')
    task1 = task(action=dict(module='setup'), delegate_to=host1.name)
    play1 = play(hosts=[host1], tasks=[task1])
    runner1 = play1.get_runner()

    assert runner1.run() == 0

# Generated at 2022-06-21 02:17:51.930262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tm = AnsibleTask()
    action = ActionModule()
    action.run(tm, 'test')

# Generated at 2022-06-21 02:18:00.617663
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:18:10.673861
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Dummy class that implements the needed methods for testing ActionModule
    class MyTask:
        def __init__(self):
            self.args = {'gather_subset': 'all'}

        class MyPlay:
            class MyPlayContext:
                pass

            def __init__(self):
                self._action_groups = {}
                self.context = MyTask.MyPlay.MyPlayContext()

        class MyPlaybook:
            def __init__(self):
                self._entries = {}
                self.basedir = ""

        def __init__(self, name):
            self.name = name
            self._parent = MyTask.MyPlay()
            self._parent._parent = MyTask.MyPlaybook()
            self.async_val = 600


# Generated at 2022-06-21 02:18:16.785162
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create mock object for path to temprory file
    mock_tmp = '/tmp/tmp12345'

    # create mock object for module_defaults
    class mock_defaults():
        def __init__(self):
            self.icmp_timeout = 2
            self.ping_timeout = 2
            self.timeout = 2

    class mock_task():
        def __init__(self):
            self.apply_defaults = mock_defaults()

    # create mock object for task vars
    mock_task_vars = {
        'ansible_network_os': 'junos'
    }

    # create mock object for ActionBase class
    class mock_actionbase(ActionBase):
        def __init__(self):
            self.task = mock_task()

    # create mock object for shared loader object

# Generated at 2022-06-21 02:18:17.930708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:18:18.755438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 02:18:30.648022
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Declare mocks
    mock_result = {}
    mock_task_vars = {}

    # run the code
    testobj = ActionModule()
    testobj._display = mock_display
    testobj._shared_loader_obj = mock_shared_loader_obj
    testobj._templar = mock_templar
    testobj._task = mock_task
    testobj._connection = mock_connection
    testobj._remove_tmp_path = mock_remove_tmp_path
    testobj._execute_module = mock_execute_module

    res = testobj.run(mock_result, mock_task_vars)

    # assert some conditions
    # assert what was returned
    assert type(res) == dict
    assert 'ansible_facts' in res

# Generated at 2022-06-21 02:18:31.496890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:18:37.351986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that parallel is true when modules is not in config.
    task_vars = {'ansible_facts_parallel': False, 'ignore_facts': False}
    result = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run(None, task_vars)
    assert result['ansible_facts']['_ansible_facts_gathered']
    assert result['_ansible_verbose_override']

    # Test that parallel is true when modules is in config and ansible_facts_parallel is not in config.
    task_vars = {'ansible_facts_parallel': False, 'ignore_facts': False, 'ansible_facts': {}}

# Generated at 2022-06-21 02:19:09.638002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    action_obj = ActionModule(
        task=dict(action=dict(setup=dict(gather_facts='smart'))),
        connection=dict(name='network_cli', transport='network_cli', host='localhost'),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_obj._task == dict(action=dict(setup=dict(gather_facts='smart')))
    assert action_obj._connection == dict(name='network_cli', transport='network_cli', host='localhost')
    assert action_obj._play_context == dict(check_mode=False)
    assert action_obj._loader is None
    assert action_obj._templ

# Generated at 2022-06-21 02:19:19.637962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from units.mock.loader import DictDataLoader
    from units.mock.plugins.module_utils.common.process import AnsibleProcess
    from units.mock.plugins.module_utils.common.remotefilemodule import AnsibleRemoteFileModule
    from units.mock.plugins.module_utils.facts import AnsibleFactsModule

    cls = ActionModule(
        task=dict(),
        connection=None,
        _play_context=dict(),
        loader=DictDataLoader({}),
        shared_loader_obj=DictDataLoader({}),
        path_loader=DictDataLoader({}),
        templar=None,
        ansible_shell_executable="",
        shared_action_plugin=None,
        action_plugins=[AnsibleFactsModule]
    )

    assert cl

# Generated at 2022-06-21 02:19:21.338063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:19:31.378607
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # These imports are needed in order to instantiate the class.
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    task = action_loader._get_task_from_path('setup', task_vars={}, connection=action_loader._connection_loader.get('local', {}))
    executor = TaskQueueManager(task)
    executor._task = task  # Set the task in the executor
    executor.task_vars = {} # Needed to test the action plugin
    action_plugin = ActionModule(None, executor, task, connection=action_loader._connection_loader.get('local', {}))

    assert action_plugin._supports_check_mode

# Generated at 2022-06-21 02:19:42.580511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example data

    module_loader = None
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts_parallel': None,
        'ansible_facts': {
            'network_os': 'ios'
        }
    }

    # Create instance of class ActionModule and method run
    modules = ['smart']
    am = ActionModule(self, connection=None, module_loader=module_loader, task_vars=task_vars, tmp=None)
    result = am._run(tmp=None, task_vars=task_vars)
    tmp = am._get_tmp_path(result_task_vars)
    fact_module = 'ansible.legacy.setup'

    # Assert the results of test

# Generated at 2022-06-21 02:19:43.616573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:19:54.824595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import json

    module_mock = mock.Mock()
    module_mock.run.return_value = {}
    module_mock.resolved_fqcn = 'test.module'

    fake_loader = mock.Mock()
    fake_loader.find_plugin_with_context.return_value = module_mock

    # Temporary hack until templating is fixed for test_runner,
    # for now just return the arguments as a string in a dict
    fake_templar = mock.Mock()
    fake_templar.template.side_effect = lambda x: dict(args = json.dumps(x))

    fake_task = mock.Mock()
    fake_task.args = dict()
    fake_task.args['parallel'] = None
    fake_task._parent._

# Generated at 2022-06-21 02:20:01.426598
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    global module_defaults
    module_defaults = {'action': {'setup': {'filter': 'ansible_distribution*'}}}
    global tmp
    tmp = os.path.realpath("files/testcase1/")
    global task_vars
    task_vars = {'hostvars': {'host1': {'ansible_network_os': 'ios', 'ansible_distribution_version': '15.1'}}}
    global C
    C = type("C", (), {})()
    C.config = type("config", (), {})()
    C.config.get_config_value = lambda x, variables=None: module_defaults
    action_module = ActionModule()
    test_module = 'setup'


# Generated at 2022-06-21 02:20:03.967657
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule('test', 'test', 'test', 'test')
    res = module.run()

    # test run() method
    assert res['ansible_facts'] == {}
    assert res['ansible_facts']['_ansible_facts_gathered'] == True
    assert res['_ansible_verbose_override'] == True
    assert res['skipped_modules'] == {}
    assert res['failed_modules'] == {}



# Generated at 2022-06-21 02:20:12.328332
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Args():
        def __init__(self, name, test=None):
            self.name = name
            self.test = test

        def __repr__(self):
            return repr((self.name, self.test))

        def __getitem__(self, attr):
            return getattr(self, attr, None)

    class DummyModule():
        def __init__(self, name, args, result):
            self._name = name
            self.args = args
            self._result = result
            self._loaded_from = "not from a file"

        def __repr__(self):
            return repr((self._name, self.args, self._result))

        def run(self, tmp=None, task_vars=None):
            return self._result


# Generated at 2022-06-21 02:20:58.119111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None, templar=None, shared_loader_obj=None)
    assert action != None


# Generated at 2022-06-21 02:20:59.531079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    print(mod)

# Generated at 2022-06-21 02:21:09.569777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action = {'action': 'setup'}
    variable_manager = 'variable_manager'
    loader = 'loader'
    tempdir = 'tempdir'
    display = 'display'
    task_uuid = 'task_uuid'
    task = 'test_task'
    connection = 'connection'
    play_context = 'play_context'
    shared_loader_obj = 'shared_loader_obj'
    def to_safe(*args, **kwargs):
        pass
    module_compression = 'module_compression'
    passwords = {}


# Generated at 2022-06-21 02:21:18.237105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_name = 'localhost'
    config = dict(httpapi=dict(default_transport='http'))
    hostvars = dict()
    task_vars = dict()
    play_context = dict(verbosity=5)
    new_stdin = "new stdin"
    connection = 'network_cli'
    loader = 'loader'
    templar = None
    shared_loader_obj = 'shared_loader_obj'
    task = dict(action=dict(module_name='command', args=dict(cmd='ls')))

    # Initialize module and get the instance

# Generated at 2022-06-21 02:21:21.971075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None)
    assert action_module is not None
    assert action_module.run is not None

# Generated at 2022-06-21 02:21:28.730264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_queue_manager
    import ansible.playbook.task
    import ansible.vars.unsafe_proxy
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.playbook.playbook
    import ansible.executor.playbook_executor

    loading.loaders.add_directory(
        os.path.join(os.path.dirname(__file__), '../../fixtures/ansible_collections/ansible_collections/some_collection/some_ns/some_module'))

    host_inventory = ansible.inventory.manager.InventoryManager(
        hosts="localhost",
        sources="localhost,",
        loader=ansible.cli.CLI.loader
    )

   

# Generated at 2022-06-21 02:21:33.235855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod1 = {
        'result': {
            'ansible_facts': {'test_fact': 'test_value'},
            'warnings': ['Some warning %s' % i for i in range(0, 10)],
            'deprecations': ['Some deprecation %s' % i for i in range(0, 10)],
        },
        'module_name': 'test_module1',
    }

# Generated at 2022-06-21 02:21:45.842627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in that directory
    filename = os.path.join(tmpdir, "test")
    fd = os.open(filename, os.O_RDWR | os.O_CREAT)
    # Write the data
    os.write(fd, "PoC")
    # Close the file
    os.close(fd)
    # Open and read the file
    fd = os.open(filename, os.O_RDONLY)
    os.read(fd, 4096)
    ActionModule(fd, "test", tmpdir, "test")
    # Close the file
    os.close(fd)

    # Clean up
    os.remove(filename)
    os.rmdir(tmpdir)


# Generated at 2022-06-21 02:21:56.699451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_run = ActionModule._task.run
    ActionModule._task.run = lambda *args, **kwargs: None
    task_vars = dict(ansible_facts=dict(network_os='ios'))
    mod_args = dict(ansible_facts=dict(network_os='ios'))
    def run_execute_module(name, args, vars, wrap):
        if name == 'ansible.legacy.setup':
            return dict(ansible_facts=dict(test='test'))
        if name == 'ansible.legacy.async_status':
            return dict(finished=1, ansible_facts={})
    ActionModule._execute_module = run_execute_module
    modules = ['ios']

# Generated at 2022-06-21 02:21:58.795988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module.run(tmp=None, task_vars={}))

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:23:44.986605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(task=dict(action=dict(module_name='setup')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    import ansible.module_utils.facts.network.base as network_base
    assert action_module_obj._connection._load_name == 'network_cli'
    assert action_module_obj._connection.module_name == 'setup'
    assert action_module_obj._task.action['module_name'] == 'setup'
    assert action_module_obj._load_name == 'setup'

# Generated at 2022-06-21 02:23:54.694434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    class ActionModuleTest(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModuleTest, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)


# Generated at 2022-06-21 02:24:04.482356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.includes import Include
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    # TODO: add test for network_os

    # TODO: add

# Generated at 2022-06-21 02:24:14.150811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import ansible

    import ansible.utils.vars
    ansible.utils.vars.merge_hash = lambda result, filtered_res, list_merge: None

    from ansible.plugins.action.setup import ActionModule

    # fact modules to be executed
    modules = [
        'test_setup_fact_module_1',
        'test_setup_fact_module_2',
        'test_setup_fact_module_3',
    ]

    # set fake modules for testing
    for mod in modules:
        setattr(ansible.plugins.action.setup, mod, lambda result, task_vars=None: {'ansible_facts': {mod: mod}})

    # set config FACT_MODULES

# Generated at 2022-06-21 02:24:23.730752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    results = dict(
        ansible_facts=dict(),
        warnings=list(),
        deprecations=list(),
    )

    # Create ActionModule
    action_module = ActionModule()

    # Call _combine_task_result()
    results = action_module._combine_task_result(results, dict(
        ansible_facts=dict(),
        warnings=list(),
    ))

    # Assert _combine_task_result()
    assert results == dict(
        ansible_facts=dict(),
        warnings=list(),
        deprecations=list(),
    )

    # Call _combine_task_result()
    results = action_module._combine_task_result(results, dict(
        ansible_facts=dict(),
        warnings=list(),
        deprecations=list(),
    ))



# Generated at 2022-06-21 02:24:33.572757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mocks
    modules = (list())

    # Set up class
    action_module = ActionModule()
    action_module._display = Display()
    action_module._supports_check_mode = True
    action_module._task = Task()
    action_module._task._parent = Play()
    action_module._connection = Connection()
    action_module._connection._load_name = None
    action_module._shared_loader_obj = SharedPluginLoaderObj()
    action_module._shared_loader_obj._module_name = None
    action_module._task.args = dict()
    action_module._task.args['gather_subset'] = ('all',)
    action_module._task.args['gather_timeout'] = None
    action_module._task.args['filter'] = None
    action_

# Generated at 2022-06-21 02:24:41.297266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_args = dict(parallel=True, gather_subset="network")
    am = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert am._supports_check_mode == True
    am._task.args = mod_args
    assert am.run(tmp=None, task_vars=dict()) == dict(ansible_facts={'_ansible_facts_gathered': True}, _ansible_verbose_override=True)

# Generated at 2022-06-21 02:24:52.751432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule.'''

    # Construct a mock task.
    task = MockTask()

    # Construct a mock AnsibleOptions.
    ansible_options = MockAnsibleOptions()

    # Construct a mock SharedPluginLoaderObj.
    shared_loader_obj = MockSharedPluginLoaderObj()

    # Construct a mock Connection.
    connection = MockConnection()

    # Construct a mock Display.
    display = MockDisplay()

    # Construct a ActionModule object.
    am = ActionModule(task=task, connection=connection, play_context=None, loader=shared_loader_obj, templar=None, shared_loader_obj=shared_loader_obj)
    am._display = display

    # Construct a empty result with an empty dict as ansible_facts.

# Generated at 2022-06-21 02:24:54.962715
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action.setup

    # to raise exception with message: 'Cannot instantiate abstract class ActionModule'
    am = ansible.plugins.action.setup.ActionModule()

    # to raise exception with message: 'action_loader is not set'
    am.run()

# Generated at 2022-06-21 02:25:04.251127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_var = {}
    test_var['ansible_facts'] = {"test": "value"}
    test_var['ansible_facts_parallel'] = False
    test_connection = {'_shell': {'tmpdir': '/tmp'}, '_load_name': 'network_cli'}
    test_task = {'args': {'gather_subset': 'all', 'gather_timeout': 45}, 'module_defaults': {'gather_subset': 'all', 'gather_timeout': 25}, 'collections': []}
    test_display = {'vvvv': 'test'}
    test_execute_module = lambda self, mod, arg, task_vars, wrap_async: {'ansible_facts': {'test_execute_module': 'test_value'}}
    test_combine