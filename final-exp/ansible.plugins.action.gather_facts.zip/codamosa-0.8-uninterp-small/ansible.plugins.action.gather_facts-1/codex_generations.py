

# Generated at 2022-06-25 06:57:50.489900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockClass_0(object):
        def __init__(self, value):
            self._value_ = value
            self.__value = value

        def __init__(self, attribute, value):
            self._attribute_ = attribute
            self.__attribute = attribute
            self._value_ = value
            self.__value = value

        def __bool__(self):
            return self.__value

        def __getattr__(self, name):
            return self._value_

        def __init__(self, attribute, attribute, attribute, value):
            self._attribute_ = attribute
            self.__attribute = attribute
            self._attribute_ = attribute
            self.__attribute = attribute
            self._attribute_ = attribute
            self.__attribute = attribute
            self._value_ = value
            self.__value = value

       

# Generated at 2022-06-25 06:57:51.707189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here

# methods of class ActionPlugin

# Generated at 2022-06-25 06:58:02.604329
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:58:12.007430
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.ansible_modlib.network import module_utils
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.ping import ActionModule as Ping
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Creating a mock task queue manager object
    tqm_obj = TaskQueueManager(
                inventory = None,
                variable_manager = None,
                loader = None,
                options = None,
                passwords = None,
                stdout_callback = None,
                run_additional_callbacks = True,
                run_tree = False,
            )

    # Creating a mock connection object and connection loader
    conn_obj = module_utils.Connection("network_os")
    conn_loader = module_utils.Connection("network_os")

    #

# Generated at 2022-06-25 06:58:16.512390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = os.urandom(0xa).decode('utf-8')
    task_vars_0 = os.urandom(0x6).decode('utf-8')
    result_0 = test_case_0()
    ActionModule_0 = ActionModule()
    ActionModule_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:58:17.124754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_module = ActionModule()


# Generated at 2022-06-25 06:58:17.936618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:26.716000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\xb3'%\xb5\xaa[q9\xd7;\x8c_G\xe0\x10\xaa\x18\xafE\x1b"
    int_0 = 0
    int_1 = 1
    str_0 = str()
    str_1 = str()
    getattr(ActionModule(), "run")(int_0, C.config.get_config_value('FACTS_MODULES', 'CONNECTION_FACTS_MODULES'))
    getattr(ActionModule(), "run")(int_0, {bytes_0: int_0, bytes_0: int_1, str_0: int_0})

# Generated at 2022-06-25 06:58:36.257718
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:58:44.927991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x83\xb6\x80\x9f\x1a\r\x13\xb1\x01\xc2\x8f\xdf\x06\x99\xad\xda\x1b\xda\xea\x8dU0\x17\xaeQ\x81\xbd\xdd\xb0\xe2\xa2\x81`\x1a\x1d\xc5[\x9a\x8d\xd5"
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}

# Generated at 2022-06-25 06:58:59.314863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Implicitly create an instance of ActionModule
    var_0 = ActionModule()
    var_0.run()
    var_1 = ActionModule()
    var_1.run()
    var_2 = ActionModule()
    var_2.run()


# Generated at 2022-06-25 06:59:06.411885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:59:10.120608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 27196
    str_0 = 'vf8Wg=hGz^H9M94'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_1 = action_run()


# Generated at 2022-06-25 06:59:17.142434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 56901
    str_0 = ']~'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    tmp = None
    arg = None
    if arg is None:
        arg = {}
    var_0 = action_module_0.run(tmp, arg)
    assert var_0 is None
    assert isinstance(var_0, dict)
    assert {'failed', 'msg', 'failed_modules'}.issubset(var_0)


# Generated at 2022-06-25 06:59:23.015103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 31812
    str_0 = '+u'
    bool_0 = False
    action_module_1 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 06:59:24.214749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Case 0
    test_case_0()


# Generated at 2022-06-25 06:59:27.641586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 06:59:34.136423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 949
    str_0 = 'jyqN>N@!z'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    int_0 = 0
    str_0 = '_=*7nnPkB'
    var_0 = action_module_0.run(int_0, str_0)

# Generated at 2022-06-25 06:59:37.127799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(8472, 'KtRdTlJ%r', 'xI@&$pKjD' )


# Generated at 2022-06-25 06:59:38.517247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:00:07.353916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule")
    int_0 = 652
    str_0 = 'Lm'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    print('\n')


# Generated at 2022-06-25 07:00:12.146739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    # Simple test (should be able to run and return)
    test_case_0()

# Generated at 2022-06-25 07:00:18.208644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -765
    str_0 = 'fV[(Kh@!m#\mBfdz'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    test_case_0()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:00:22.612127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 87267
    str_0 = ';aQ.1D6z'
    bool_0 = True
    str_1 = '{_gvC'
    str_2 = '+w@2)&'
    bool_1 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_1, str_2, bool_1)



# Generated at 2022-06-25 07:00:24.970617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(str(ActionModule))


# Generated at 2022-06-25 07:00:34.439444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = 'setup'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    action_module_0.action_name = str_0
    action_module_0.args = {'a': {}}
    action_module_0.cache = str_0
    action_module_0.category = str_0
    action_module_0.check_mode = bool_0
    action_module_0.cp = bool_0
    action_module_0.connection = str_0
    action_module_0.delegate_to = str_0
    action_module_0.delegate_facts = bool_0
    action_module_0.display = str_

# Generated at 2022-06-25 07:00:39.657163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make sure that class initialization produces the correct instance variables
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 07:00:46.737600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7443
    str_0 = 'D:`S'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    int_0 = 8694
    str_0 = '*~$i'
    bool_0 = False
    var_0 = None
    var_1 = None
    var_0 = action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:00:47.808554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # declared case test
    test_case_0()


# Generated at 2022-06-25 07:00:55.012470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 38135
    str_0 = '%Cf^{1'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict) == 1


# Generated at 2022-06-25 07:01:43.172050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = {32603, -1074603859, 20001}
    str_0 = {' S>pL&ZfO', ' ', '~+1YfV', '+', 'XY7Vu:df!', '/$&', 'GeXdKk4'}
    bool_0 = {True, False, False}
    for i_0 in range(150, 160):
        test_case_0()


# Generated at 2022-06-25 07:01:45.630118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:01:49.020174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 96
    str_0 = '^aL'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)


# Generated at 2022-06-25 07:01:56.652070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = factory.create_int()
    str_0 = factory.create_str()
    bool_0 = factory.create_bool()
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0.run()

    # Check for expected result
    if(var_0 == result):
        test_passed = True
    else:
        test_passed = False
    assert test_passed == True, "Expected %s, got %s" % (result, var_0)

# Test case for the above test

# Generated at 2022-06-25 07:02:06.249436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the mock object which will be used throughout the testing
    action_module_0 = unittest.mock.Mock()
    action_module_0.run.return_value = True 

    # Initialize the constants to be used to test the method
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)

    # Checking for the type of the arguments of the call to run
    int_1 = 32603
    str_1 = ' S>pL&ZfO'
    bool_1 = False

# Generated at 2022-06-25 07:02:08.288829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)

# Generated at 2022-06-25 07:02:09.829314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:02:15.317213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:02:19.427029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 48768
    str_0 = '60[H>u'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0.run(None, None)
    assert var_0 == None


# Generated at 2022-06-25 07:02:25.872045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 69511
    str_0 = 'NxN d^e@+'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    tmp = 'tmp'
    task_vars = 'task_vars'
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:04:13.191179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 31818
    str_0 = 'FxU~1!Z'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    action_module_0.run(str_0)

# Generated at 2022-06-25 07:04:16.973231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 94578
    str_0 = '!D'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    str_1 = 'F'
    str_2 = 's'
    action_module_0.run(str_1, str_2)


# Generated at 2022-06-25 07:04:22.056459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = {}
    assert test_case_0() == (None, ['test_path_0'], None, None) == False

# Generated at 2022-06-25 07:04:26.614600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 56100
    str_0 = '9Jn@D]8sz'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    print(result)


# Generated at 2022-06-25 07:04:31.105661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert not result
    assert not result
    assert not result
    assert not result


# Generated at 2022-06-25 07:04:34.667468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:04:39.189611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 62187
    str_0 = 'D03'
    bool_0 = True
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0. run('A1$/*N*2r0', action_module_0)

# Generated at 2022-06-25 07:04:46.157886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp, task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_0.run(tmp, task_vars)
    task_vars = None
    action_module_0.run(tmp, task_vars)
    tmp = 'T>T=dV'
    action_module_0.run(tmp, task_vars)
    tmp = '?K3qZ'
    action_module_0.run(tmp, task_vars)
    tmp = 'd*a@R+w'
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:04:53.240904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:05:01.679305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 32603
    str_0 = ' S>pL&ZfO'
    bool_0 = False
    action_module_0 = ActionModule(int_0, str_0, bool_0, str_0, str_0, bool_0)
    dict_0 = dict()
    var_0 = action_module_0.run(dict_0)
    return var_0
