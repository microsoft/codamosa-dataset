

# Generated at 2022-06-25 06:57:48.680613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Sets up 'float_0' instance of 'float' class
    float_0 = -1499.9
    # Sets up 'str_0' instance of 'str' class
    str_0 = 's\x0bc0gAY3`[p &e'
    # Sets up 'float_1' instance of 'float' class
    float_1 = -1499.9
    # Sets up 'float_2' instance of 'float' class
    float_2 = -1499.9
    # Sets up 'bytes_0' instance of 'bytes' class
    bytes_0 = b''
    # Sets up 'bool_0' instance of 'bool' class
    bool_0 = False
    # Sets up 'action_module_0' instance of 'ActionModule' class

# Generated at 2022-06-25 06:57:57.614247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = -0.18852780225761512
    bool_0 = False
    float_1 = 0.5216719544058806
    task_vars_0 = TaskVars()
    tmp_0 = None
    tmp_0 = action_module_0.run(tmp_0, task_vars_0)
    assert False

if __name__ == '__main__':
    from ansible.module_utils.parsing.convert_bool import boolean
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:03.812669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1499.9
    str_0 = 's\x0bc0gAY3`[p &e'
    float_1 = -1499.9
    float_2 = -1499.9
    bytes_0 = b''
    bool_0 = False
    action_module_0 = ActionModule(float_0, str_0, float_0, float_0, bytes_0, bool_0)
    tmp = None
    task_vars = {}
    test_case_run_action_module_0(action_module_0, tmp, task_vars)


# Generated at 2022-06-25 06:58:12.975610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1499.9
    str_0 = 's\x0bc0gAY3`[p &e'
    bytes_0 = b''
    bool_0 = False
    action_module_0 = ActionModule(float_0, str_0, float_0, float_0, bytes_0, bool_0)
    # str return
    str_0 = action_module_0.run(-5.5, b'\x2c\x94\x96\x17\xd7\x8a\xe9\xd4\xce\x08\x8c\xc7\x82\x1a\x00\x8f\x0f')
    print('str_0: ', str_0)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 06:58:21.193807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1499.9
    str_0 = 's\x0bc0gAY3`[p &e'
    bytes_0 = b''
    bool_0 = False
    action_module_0 = ActionModule(float_0, str_0, float_0, float_0, bytes_0, bool_0)
    assert isinstance(action_module_0._display, Display) == True
    assert isinstance(action_module_0._loader, DataLoader) == True
    assert action_module_0.task_vars == {}
    assert action_module_0._supports_async == False
    assert isinstance(action_module_0._connection, ConnectionBase) == True
    assert isinstance(action_module_0._shell, ShellModule) == True

# Generated at 2022-06-25 06:58:24.946173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments:
    #  tmp (str): The path of the file that contains the temporary data
    #  task_vars (dict): The dictionary which contains the variables
    task_vars = {}

    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:32.790949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #----------------------------------------------------------------------
    # Setup
    float_0 = -1499.9
    str_0 = 's\x0bc0gAY3`[p &e'
    float_1 = -1499.9
    float_2 = -1499.9
    bytes_0 = b''
    bool_0 = False
    tmp = None
    task_vars = {}
    result = {}
    result['ansible_facts'] = {}
    #----------------------------------------------------------------------
    # Execution
    float_3 = -1499.9
    action_module_0 = ActionModule(float_0, str_0, float_1, float_2, bytes_0, bool_0)
    output_0 = action_module_0.run(tmp, task_vars)
    #----------------------------------------------------------------------
    # Testing

# Generated at 2022-06-25 06:58:40.437374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1499.9
    str_0 = 's\x0bc0gAY3`[p &e'
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, str_0, float_0, float_0, bytes_0, False)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:58:46.494156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 9.0
    str_0 = '5RK]\xc0`-w"4,*z'
    float_1 = 20.67
    float_2 = 3.0
    bytes_0 = b'\xcd\xe7\x07\x95\x14m\xde\x9c\x1a\xe7\x90\xb5\x08\x80\x94q\xab\xd5\x9d\xe4\nA\x8d4\xa4\xd2\x0c\xef'
    bool_0 = False
    action_module_0 = ActionModule(float_0, str_0, float_1, float_2, bytes_0, bool_0)
    bool_1 = True
    dict_0 = {}
    action_module

# Generated at 2022-06-25 06:58:48.320919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: Add your test here
    pass


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:59:09.806645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_0 = 'QoZT~04mYs{\u0017\u0010\\'
    host_1 = '\u0000\u0017\u0018\u000e\u0014\u001a4h\u0004\u0010\u001e\u001e'
    host_2 = '0\u0018`\u0011\u0006\u0010o\u0000\u0014\u001e\u0018'
    host_3 = '\n\u000b\u0000\u0017\u0016\u000e\u0014\u001a4h\u0004\u0010\u001e\u001e'

# Generated at 2022-06-25 06:59:13.619246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)

# Generated at 2022-06-25 06:59:14.190418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:59:25.356181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test default behavior of constructor, when called with no parameters
    action_module_0 = ActionModule()
    # Test default behavior of constructor, when called with one parameters
    action_module_1 = ActionModule(str_0)
    # Test default behavior of constructor, when called with two parameters
    action_module_2 = ActionModule(str_0, list_0)
    # Test default behavior of constructor, when called with three parameters
    action_module_3 = ActionModule(str_0, list_0, list_0)
    # Test default behavior of constructor, when called with four parameters
    action_module_4 = ActionModule(str_0, list_0, list_0, int_0)
    # Test default behavior of constructor, when called with five parameters

# Generated at 2022-06-25 06:59:28.306671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8\r\t7p'
    list_0 = []
    int_0 = 2048
    int_1 = 4
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 06:59:33.899953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'p'
    list_0 = []
    int_0 = 10
    int_1 = 10
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:59:38.814556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    list_1 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_1, int_0, int_1, bool_0)
    var_0 = action_run()
    assert var_0 == result_0

# Generated at 2022-06-25 06:59:42.886505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n   test_ActionModule_run()\n")
    action_module_0 = ActionModule(list_0, list_0, tuple_0, int_0, int_1, bool_0)
    tuple_5 = action_module_0.run(int_1, tuple_0)
    var_1 = len(tuple_5)
    print("\nRETURNED:\n\n%s" % var_1)


# Generated at 2022-06-25 06:59:45.886222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test the method run of class ActionModule')


# Generated at 2022-06-25 06:59:46.882005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:00:12.372080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    result = action_run(None, None)

    assert result['failed'] == False

# Generated at 2022-06-25 07:00:15.603012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    str_1 = '3vOB.9\rn;NDQ '
    list_1 = []
    list_2 = []
    int_2 = 1024
    int_3 = 4
    bool_1 = False
    action_module_1 = ActionModule(str_1, list_1, list_2, int_2, int_3, bool_1)
    # end test_case_0

# Generated at 2022-06-25 07:00:21.408077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_module_run(action_module_0, None, None)
    print(var_0)


# Generated at 2022-06-25 07:00:33.499837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    list_1 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_1, int_0, int_1, bool_0)
    # call _get_module_args()
    list_2 = []
    # read module_args, which is a dict

# Generated at 2022-06-25 07:00:38.778753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Running test_ActionModule_run')
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:00:44.652800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    list_1 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(var_0, list_0, list_1, int_0, int_1, bool_0)


# Generated at 2022-06-25 07:00:51.438574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    str_0 = 'Rg~mV]KP'
    list_1 = []
    int_0 = 20
    int_1 = 10
    bool_0 = False
    str_1 = 'v'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1['f'] = dict_0
    dict_1['z'] = dict_0
    dict_1['t'] = dict_0
    dict_1['t'] = dict_0
    dict_0['g'] = dict_0
    dict_0['y'] = dict_0
    dict_0['f'] = dict_0
    dict_0['x'] = dict_0
    dict_0['e'] = dict_0
    dict_0['c'] = dict_

# Generated at 2022-06-25 07:01:00.298746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    str_0 = '4yD3,L.hYBlS--t@\x16=sO'
    int_1 = 3
    list_0 = []
    list_1 = []
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, list_1, int_0, int_1, bool_0)

# Generated at 2022-06-25 07:01:06.553045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    print(action_module_0)



# Generated at 2022-06-25 07:01:10.424610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '3vOB.9\rn;NDQ '
  list_0 = []
  int_0 = 1024
  int_1 = 4
  bool_0 = False
  action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
  var_0 = action_run()
  pass

# Generated at 2022-06-25 07:01:52.261518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:01:53.035670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:02:01.070272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '3vOB.9\rn;NDQ '
    var_1 = []
    var_2 = []
    var_3 = 1024
    var_4 = 4
    var_5 = False
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = None
    var_7 = None
    action_run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:02:11.578220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run()')
    setup_mock()
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['msg'] = 'The following modules were skipped: smart\n'
    dict_0['skipped_modules'] = dict()
    dict_0['skipped_modules']['smart'] = dict()
    dict_0['skipped_modules']['smart']['ansible_job_id'] = '378666880446.2448'
    dict_0['skipped_modules']['smart']['finished'] = 0
    dict_0['skipped'] = True
    dict_0['ansible_facts']['_ansible_facts_gathered'] = True

# Generated at 2022-06-25 07:02:18.818581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case for true condition
    str_0 = 'aSZ'
    list_0 = []
    int_0 = 8
    int_1 = 4
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_module_0.get_action_args_with_defaults(action_module_0._task, action_module_0._connection)
    # test case for false condition
    str_1 = 'Q@Ft _'
    list_1 = [None, 0]
    int_2 = 2
    int_3 = 2
    bool_1 = True
    # missing test case for else condition
    # test case for true condition

# Generated at 2022-06-25 07:02:24.697777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)


# Generated at 2022-06-25 07:02:36.058687
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:02:41.781867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:02:46.031018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_module_0.run()
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    var_0 = action_module_0.run(tmp=None)

# Generated at 2022-06-25 07:02:47.318401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add tests for this method
    pass

# Generated at 2022-06-25 07:04:29.456854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test different cases of inputs
    # Test case #0
    str_1 = 'A@r\rP\n \x17.\x01o\x0eY5\x1d'
    list_1 = []
    list_2 = []
    int_2 = 1024
    int_3 = 4
    bool_1 = False
    action_module_1 = ActionModule(str_1, list_1, list_2, int_2, int_3, bool_1)
    var_1 = action_module_1.run()
    # Test case #1
    str_2 = 'k\\\x1f\x1c\x1e\n\x1f\x1f \n\x0fTq\x04'
    list_3 = []
    list_4 = []
    int

# Generated at 2022-06-25 07:04:34.576621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    assert action_module_0._connection_info.connection == 'paramiko'
    assert action_module_0._task.action == 'setup'
    assert action_module_0._task.become is False
    assert action_module_0._task.become_method is None
    assert action_module_0._task.become_user is None
    assert action_module_0._task.check_mode is False
    assert action_module_0._task.delegate_to is None
   

# Generated at 2022-06-25 07:04:39.618969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-nT^TZ{rUk8B:g#_lC'
    list_0 = []
    list_1 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_1, int_0, int_1, bool_0)
    return action_module_0


# Generated at 2022-06-25 07:04:43.232845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = '3vOB.9\rn;NDQ '
  list_0 = []
  int_0 = 1024
  int_1 = 4
  bool_0 = False
  action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
  var_0 = action_run()

# Generated at 2022-06-25 07:04:45.557148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    param0 = '\tQ*;1\x00'
    param1 = []
    param2 = []
    param3 = 2048
    param4 = 8
    param5 = True
    actionModule_0 = ActionModule(param0, param1, param2, param3, param4, param5)


# Generated at 2022-06-25 07:04:54.552908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'w<l5\x1a)uV'
    list_0 = []
    int_0 = 32768
    int_1 = 8
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    var_0 = action_module_run(action_module_0)
    var_1 = action_module_run(action_module_0)


# Generated at 2022-06-25 07:04:57.286682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:05:03.759631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3vOB.9\rn;NDQ '
    list_0 = []
    int_0 = 1024
    int_1 = 4
    bool_0 = False
    action_module_0 = ActionModule(str_0, list_0, list_0, int_0, int_1, bool_0)
    assert_true(action_module_0)
    action_module_0.action_write_locks()
    action_module_0.action_write_locks(list_0)
    action_module_0.add_to_proc_facts()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.action_run()
    action_module_0.add_to_proc_facts()
    action_module_0

# Generated at 2022-06-25 07:05:08.459928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str, list, list, int, int, bool)
    var_0 = action_module_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:05:16.411194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '3vOB.9\rn;NDQ '
    var_1 = []
    var_2 = []
    var_3 = 1024
    var_4 = 4
    var_5 = False
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = {}
    var_7 = {}
    var_8 = []
    var_9 = 'smart'
    var_9 = [var_9]
    var_7['FACTS_MODULES'] = var_9
    var_10 = {}
    var_10['ansible_network_os'] = 'ios'
    var_11 = {}
    var_10['ansible_facts'] = var_11