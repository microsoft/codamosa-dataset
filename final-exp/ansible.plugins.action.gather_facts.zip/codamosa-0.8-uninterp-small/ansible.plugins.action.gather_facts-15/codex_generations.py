

# Generated at 2022-06-25 06:57:45.517789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bytes_0 = b'T\x9b'
    bool_0 = False
    str_0 = 'i\xdc3x\x8b'
    int_0 = 438
    action_module_1 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)


# Generated at 2022-06-25 06:57:48.096852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        return False
    else:
        return True

if __name__ == '_main__':
    print(test_ActionModule())

# Generated at 2022-06-25 06:57:50.815228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# if we are running a unit test, import test cases and run them
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:57:58.371895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bytes_0 = b'+;g\x972'
    bool_0 = False
    str_0 = 't94zmw'
    int_0 = 1192
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)



if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:58:05.420984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 806
    bytes_0 = b'!T\xfe\x15\x1f\xaf\xea\xc7\x12\xc9\x8a\x1e>\xf3'
    str_0 = '6i'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['ansible_facts'] = dict_0
    dict_1['failed'] = True
    dict_1['warnings'] = list_0
    dict_1['deprecations'] = list_0
    dict_1['_ansible_verbose_override'] = True
    dict_1['_ansible_facts_gathered'] = True
    dict_1['_ansible_no_log'] = True

# Generated at 2022-06-25 06:58:09.869162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bytes_0 = b'+;g\x972'
    bool_0 = False
    str_0 = 't94zmw'
    int_0 = 1192
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)


# Generated at 2022-06-25 06:58:10.999576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:16.757978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    bytes_0 = b'0\x99\xf1\x83\x9d\xad\x8e\x1c'
    bool_0 = False
    str_0 = 't94zmw'
    int_0 = 1192
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 06:58:22.161776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bytes_0 = b'G\xee\x1d\x9ba\xfe\x1f\xff\xcd\x82\x07\xb8'
    bool_0 = False
    str_0 = 'a0doz7'
    int_0 = 17
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)

    test_case_0()


# Generated at 2022-06-25 06:58:25.770315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    bytes_0 = b'+;g\x972'
    bool_0 = False
    str_0 = 't94zmw'
    int_0 = 1192
    action_module_0 = ActionModule(list_0, bytes_0, bool_0, str_0, list_0, int_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:58:45.963872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_0 = ActionModule({
        'args': {
            'gather_subset': 'all',
            'gather_timeout': 10,
            'filter': 'ansible_*'
        },
        'module_defaults': {
            'test_testcase_1': 'test_testcase_1 default value'
        }
    })
    mod_0._remove_tmp_path('/var/folders/1j/v1_b_2ld0tv0wwszjbkvwcw0000gn/T/ansible-local-57jvihI/tmp/ansible-tmp-1537966422.916894-143550478122498/')

# Generated at 2022-06-25 06:58:48.940950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_0 = ActionModule()
    action_0.run(unittest_task_vars_dict, task_vars_dict)

unittest_task_vars_dict = dict()


# Generated at 2022-06-25 06:58:50.681939
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_base_0 = ActionBase()
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:51.943279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run test
    test_case_0()

# Generated at 2022-06-25 06:58:55.980211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Executing constructor test for class ActionModule ')
    instance = ActionModule(task=test_case_0(), connection=test_case_0(), play_context=test_case_0(), loader=test_case_0(), templar=test_case_0(), shared_loader_obj=test_case_0())


# Generated at 2022-06-25 06:58:58.195072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 06:59:01.146497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = test_case_0()
    task_vars = test_case_0()
    obj = ActionModule(tmp, task_vars)
    assert obj is not None


# Generated at 2022-06-25 06:59:09.931456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    # Constants for test case 0
    ACTION_MODULE = 'ansible.legacy.setup'
    HOST_NAME = 'ansible'
    UNIT_TEST_NAME = 'box'
    # Local variables for test case 0
    fact_module = 'ansible.legacy.setup'
    fact_filter = '*'
    gather_subset = 'all'
    gather_timeout = 10
    action_module = 'ansible.legacy.setup'
    hosts = 'ansible'
    inventory_hostname = 'box'
    module_name = 'ansible.legacy.setup'
    parallel = True
    result = None
    setup = None
    smart = 'ansible.legacy.setup'
    task_name = 'setup'
   

# Generated at 2022-06-25 06:59:12.281646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.set_task('task_5')


# Generated at 2022-06-25 06:59:13.016143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case: default arguments
    test_case_0()


# Generated at 2022-06-25 06:59:40.536091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_play_instance = None
    ansible_task_instance = None
    ansible_connection_instance = None
    ansible_loader_obj = None
    ansible_shared_obj = None
    ansible_templar_obj = None

    test_case_0()
    action_module_instance = ActionModule(ansible_play_instance, ansible_task_instance, ansible_connection_instance, ansible_loader_obj, ansible_shared_obj, ansible_templar_obj)

    # Testing whether instance created successfully.
    assert action_module_instance is not None

# Generated at 2022-06-25 06:59:45.647163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = action_module.run(tmp, task_vars)
    if res != {}:
        print('Expected: {}, but got: {}'.format({}, res))
    
if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:59:46.667255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:59:48.413433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:59:51.870486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    tmp = None
    task_vars = None
    result = a.run(tmp, task_vars)
    if result['changed'] is True:
        print("The result of run of class ActionModule is: %s." % result['changed'])


# Generated at 2022-06-25 07:00:02.812430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
    }
    am = ActionModule()
    am.setup_loader()
    am._shared_loader_obj.module_loader.find_plugin = lambda x: 'ansible_facts.setup'
    am._task.args = {
    }
    am._task._parent._play._action_groups = {}
    am._task.module_defaults = {
    }
    am._templar = play_context._loader._templar
    am._display = play_context._loader._display
    am._connection = play_context.connection
    am._task.task_vars = task_vars
    am._task._parent._play._included_file_search_path = []
    am._task._parent._play._included_files = []
    am._task._parent._play.host

# Generated at 2022-06-25 07:00:05.207038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fact_module = 'ansible.legacy.setup'
    task_vars = {}
    ActionModule(fact_module, task_vars)


# Generated at 2022-06-25 07:00:15.065775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    async_dir = './tests/action_plugins/async'
    task_vars['ansible_system'] = 'Linux'
    task_vars['ansible_distribution'] = 'Ubuntu'
    task_vars['ansible_distribution_version'] = '16.04'
    task_vars['ansible_pkg_mgr'] = 'apt'
    task_vars['ansible_kernel'] = '4.3.3-040303-generic'
    task_vars['ansible_architecture'] = 'x86_64'
    task_vars['ansible_all_ipv4_addresses'] = ['10.101.37.225']

# Generated at 2022-06-25 07:00:23.930242
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:00:25.684868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:01:12.006107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    # check return value of test_case_0
    try:
        assert True == bool_0
    except AssertionError as e:
        print(e)
        print('test_case_0() failed')
    else:
        print('test_case_0() passed')


# Generated at 2022-06-25 07:01:15.759734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    _module_mock = mock.Mock()
    _module_mock.params = bool_0
    a = ActionModule(bool_0)
    bool_2 = test_case_0()
    bool_3 = a._supports_check_mode
    if (bool_0 == bool_3):
        bool_2 = True
    return bool_2

# Generated at 2022-06-25 07:01:21.635448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = True
    task_vars = {}
    my_obj = ActionModule()
    res = my_obj.run(tmp, task_vars)
    print(res)


# Run internal tests
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:01:25.307263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We will call test_case_0 to validate correctness of following test case
    test_case_0()

    # test case step 1
    actionModule_obj = ActionModule()
    tmp = None
    task_vars = None

    actionModule_obj.run(tmp, task_vars)

# Generated at 2022-06-25 07:01:28.507216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_module_0()
    test_module_args_0()
    test_run_0()

# Generated at 2022-06-25 07:01:38.055516
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:01:46.305014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = '/var/folders/97/hj7wzlr144zb1qq8pzv1402m001rsz/T/ansible-local-22384amj/tmp'
    task_vars = {'ansible_ssh_pass': 'mysshpass'}
    action_module = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = action_module.run(tmp, task_vars)
    assert result['ansible_facts'] == {}

# Generated at 2022-06-25 07:01:48.371719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate ActionModule class
    actionModule = ActionModule()

    # Just test that the method is callable
    actionModule.run()


# Generated at 2022-06-25 07:01:54.696976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_action_module = ActionModule(task=None,connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)

    # Copy the value from test_case_0
    bool_0_copy = bool_0

    id_0 = id(obj_action_module)
    if id_0 == 5109888:
        test_case_0()


# Generated at 2022-06-25 07:01:56.152189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:03:28.122621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    kwargs = dict()
    x = ActionModule.run(**kwargs)
    assert x == True

# Generated at 2022-06-25 07:03:35.498600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = dict()
    setup_loader = dict()
    variable_manager = dict()
    loader = dict()
    templar = dict()
    task_uuid = 'task_uuid'
    args = dict()
    task_action = 'task_action'
    task_executor = dict()
    task_vars = dict()
    task = dict()
    shared_loader_obj = dict()
    result = dict()
    connection = dict()
    play_context = dict()
    new_stdin = dict()
    display = dict()

# Generated at 2022-06-25 07:03:41.309917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    fact_module = 'ansible.legacy.setup'
    mod_args = dict()
    mod_args['_ansible_no_log'] = False
    mod_args['_ansible_check_mode'] = False
    mod_args['_ansible_debug'] = False
    mod_args['_ansible_diff'] = False
    mod_args['_ansible_keep_remote_files'] = False
    mod_args['_ansible_remote_tmp'] = None
    mod_args['_ansible_shell_executable'] = None
    mod_args['_ansible_selinux_special_fs'] = False
    mod_args['_ansible_shell_type'] = 'sh'
    mod_args['_ansible_socket'] = None

# Generated at 2022-06-25 07:03:42.591917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:03:43.539166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:03:44.896298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == True


# Generated at 2022-06-25 07:03:47.623070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionBase()
    test_case_0()
    return True


# Generated at 2022-06-25 07:03:54.725933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_args = {}
    tmp = os.environ.get('TMP', '/tmp')
    task_vars = None
    action_base = ActionBase()
    action_module = ActionModule(action_base._task, action_base._connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    result = action_module.run(tmp, task_vars)
    assert result['ansible_facts'] == {'_ansible_facts_gathered': True}
    if 'failed' in result:
        assert len(result['failed_modules']) == 0
    if 'msg' in result:
        assert result['msg'] == "The following modules failed to execute: %s\n"

# Generated at 2022-06-25 07:03:56.678576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Test action module
        test_case_0()
    except Exception as e:
        print('Exception: {0}'.format(e))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:04:02.927029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = dict()
    task_0 = dict()
    play_context_0 = dict()
    loader_0 = dict()
    templar_0 = dict()
    shared_loader_obj_0 = dict()
    testActionModule = ActionModule(args_0, task_0, play_context_0, loader_0, templar_0, shared_loader_obj_0)
