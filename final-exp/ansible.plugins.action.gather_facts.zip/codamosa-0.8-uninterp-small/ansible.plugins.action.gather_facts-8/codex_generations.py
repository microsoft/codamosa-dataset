

# Generated at 2022-06-25 06:57:47.686069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = None
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(dict_0, action_module_0, bytes_0, bytes_0, action_module_0, action_module_0)
    list_1 = None
    dict_1 = {list_1: list_1, list_1: list_1, list_1: list_1}
    action_module_2 = None
    tmp_2 = action_module_1.run(dict_1, action_module_2)
    return tmp_2

# Generated at 2022-06-25 06:57:48.230013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 06:57:49.711858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = None
    tmp = None
    action_module_2 = ActionModule(None, None, None, None, None, None)
    action_module_2.run(tmp, task_vars)


# Generated at 2022-06-25 06:57:53.459554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = None
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(dict_0, action_module_0, bytes_0, bytes_0, action_module_0, action_module_0)
    tmp = None
    task_vars = None
    ret_0 = action_module_1.run(tmp, task_vars)
    ret_1 = action_module_1.run(tmp, task_vars)
    ret_1 = action_module_1.run(tmp, task_vars)

# Generated at 2022-06-25 06:58:02.909473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict_0
    action_module_0 = action_module_0
    bytes_0 = bytes_0
    action_module_1 = ActionModule(dict_0, action_module_0, bytes_0, bytes_0, action_module_0, action_module_0)
    dict_0 = dict_0
    str_0 = str()
    dict_1 = {str_0: dict_0}
    try:
        action_module_1.run(tmp=dict_1)
        action_module_1.run(tmp=dict_1, task_vars=dict_1)
        action_module_1.run(task_vars=dict_1)
        action_module_1.run()
    except:
        pass


# Generated at 2022-06-25 06:58:09.157032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = None
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(dict_0, action_module_0, bytes_0, bytes_0, action_module_0, action_module_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:58:09.991530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:10.815483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:58:11.867803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:18.299095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = None
    dict_0 = {list_0: list_0, list_0: list_0, list_0: list_0}
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(dict_0, action_module_0, bytes_0, bytes_0, action_module_0, action_module_0)
    str_0 = None
    dict_1 = None
    dict_1 = action_module_1.run(str_0, dict_1)


# Generated at 2022-06-25 06:58:29.322232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:41.091937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    action_module_0.action = 'setup'
    action_module_0.add_cleanup_callback = lambda : None
    action_module_0.run()
    action_module_0.setup_choices_play = lambda : None
    action_module_0._remove_tmp_path = lambda : None
    action_module_0._execute_play = lambda : None
    action_module_0._execute_module

# Generated at 2022-06-25 06:58:42.852004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define paramters
    tmp = None
    task_vars = {}
    # Execute function
    result = run(tmp, task_vars)


# Generated at 2022-06-25 06:58:49.267410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 9081
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)


# Generated at 2022-06-25 06:58:54.082834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_0.update({'ansible_play_hosts': ['127.0.0.1']})
    dict_0.update({'ansible_play_batch': ['0']})
    dict_0.update({'ansible_play_hosts_all': ['127.0.0.1']})
    dict_0.update({'ansible_play_failed_hosts': []})
    dict_0.update({'ansible_play_success_hosts': []})
    dict_0.update({'ansible_play_item': dict_0})
    dict_0.update({'ansible_play_hosts_count': 1})
    dict_0.update({'ansible_play_hosts_remaining': ['127.0.0.1']})
    dict_

# Generated at 2022-06-25 06:59:01.940595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)



# Generated at 2022-06-25 06:59:05.637126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 06:59:09.718336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	bool_0 = true
	bytes_0 = b'\xcc\x14R'
	int_0 = 99311
	float_0 = -845.09
	dict_0 = {}
	action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
	action_module_0.run()

# Generated at 2022-06-25 06:59:18.895588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'\n*'
    int_0 = -25
    float_0 = -484.2
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    action_module_0.run()
    action_module_0.run()

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:59:21.614534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = bool()
    bytes_0 = bytes(1)
    int_0 = int()
    float_0 = float()
    str_0 = str()
    dict_0 = dict()
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, str_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:59:51.305836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'^\xdc\x93\xec\xdd\x8e\xcc\xfb\xa3\xd7\xc0'
    int_0 = -30
    float_0 = -307.98
    int_1 = -4
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_1, dict_0)
    str_0 = action_module_0.run()
    assert str_0 == "The following modules failed to execute: %s\n"

# Generated at 2022-06-25 06:59:59.650682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = -1
    bytes_0 = b'f\xde\xa1\x06\xf2\x80\x9c\xec\x95\x8a\xce\n\xb1'
    int_0 = 6257
    float_0 = -9393.75
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_module_run()


# Generated at 2022-06-25 07:00:02.949170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:00:12.226040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    tmp_0 = None
    task_vars_0 = {}
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 is not None


# Generated at 2022-06-25 07:00:18.966123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_facts_parallel_0 = 'x'
    parallel_0 = 'z'
    FACTS_MODULES_0 = 't'
    dict_1 = {}
    dict_1['ansible_facts_parallel'] = ansible_facts_parallel_0
    dict_1['FACTS_MODULES'] = FACTS_MODULES_0
    dict_1['parallel'] = parallel_0
    dict_0 = {}
    dict_0['ansible_facts_parallel'] = ansible_facts_parallel_0
    dict_0['FACTS_MODULES'] = FACTS_MODULES_0
    dict_0['parallel'] = parallel_0
    task_vars_0 = dict_0
    parallel_1 = 'z'
    dict_2 = {}

# Generated at 2022-06-25 07:00:25.934192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input Variables
    tmp = None
    task_vars = None
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_module_0.run(tmp, task_vars)



# Generated at 2022-06-25 07:00:31.461395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    assert action_module_0._supports_check_mode == True



# Generated at 2022-06-25 07:00:42.622887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run method should return a dictionary with the following keys:
    # ansible_facts
    # failed
    # msg
    # skipped
    # skipped_modules
    # warnings
    dict_0 = {'ansible_facts': '', 'failed': '', 'msg': '', 'skipped': '', 'skipped_modules': '', 'warnings': ''}

    # run method should return a dictionary with the following keys:
    # ansible_facts (required)
    # failed (optional)
    # msg (optional)
    # skipped (optional)
    # skipped_modules (optional)
    # warnings (optional)
    dict_1 = {}

    assert isinstance(dict_1, dict), 'dict_1 is not a dict'

# Generated at 2022-06-25 07:00:51.854668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create some examples of arguments
    bool_1 = True
    bytes_1 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_1 = 3759
    float_1 = -581.28
    int_2 = 3759
    dict_1 = {}
    action_module_1 = ActionModule(bool_1, bytes_1, int_1, float_1, int_2, dict_1)
    # Call the method with a known argument
    var_0 = action_module_1.run()
    return

# Generated at 2022-06-25 07:00:56.923733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)

test_ActionModule()

# Generated at 2022-06-25 07:01:46.833701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'a\xa8\x8d\x03$\x0c\xc1\x1b\x9e'
    int_0 = -2369
    float_0 = -0.0045
    dict_0 = {}
    var_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    print(var_0.connection)
    print(var_0.display)
    print(var_0.loader)
    print(var_0.templar)
    print(var_0.name)
    print(var_0.shared_loader_obj)
    print(var_0.action_plugin_name)
    print(var_0._task)

# Generated at 2022-06-25 07:01:54.266783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)

# Generated at 2022-06-25 07:02:01.891448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)

    # Test case with arguments
    test_case_0()


# Generated at 2022-06-25 07:02:12.373755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_run()
    assert var_0 == 'None'
    bool_1 = True
    bytes_1 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_1 = 3759
    float_1 = -581.28
    dict_1 = {}

# Generated at 2022-06-25 07:02:17.924123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x7f\x00\x00\x01'
    int_0 = -1966
    float_0 = -3.8
    int_1 = -1884
    dict_0 = {}
    var_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_1, dict_0)
    var_1 = {}
    var_0.run(var_1, var_1)

# Generated at 2022-06-25 07:02:23.228428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    dict_1 = {}
    # You might want to check the return value of run
    assert action_module_0.run(dict_1) == None
    
    

# Generated at 2022-06-25 07:02:28.775725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_0()
        print('unit test: ActionModule.py: test_0() passed')
    except:
        print('unit test: ActionModule.py: test_0() failed')
    try:
        test_1()
        print('unit test: ActionModule.py: test_1() passed')
    except:
        print('unit test: ActionModule.py: test_1() failed')
    try:
        test_2()
        print('unit test: ActionModule.py: test_2() passed')
    except:
        print('unit test: ActionModule.py: test_2() failed')
    try:
        test_3()
        print('unit test: ActionModule.py: test_3() passed')
    except:
        print('unit test: ActionModule.py: test_3() failed')

# Generated at 2022-06-25 07:02:37.065898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    tmp = 'tmp'
    task_vars = dict_0
    test_case_0()

# Generated at 2022-06-25 07:02:42.003263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test variables
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:02:46.134826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Parameters with default values
    _data_loader=None
    _connection=None
    _templar=None
    _task_vars=None
    _loader=None
    _shared_loader_obj=None

    try:
        action_module_0 = ActionModule(_data_loader=_data_loader, _connection=_connection, _templar=_templar, _task_vars=_task_vars, _loader=_loader, _shared_loader_obj=_shared_loader_obj)
        print('test_ActionModule passed')
    except:
        print('test_ActionModule failed')


# Generated at 2022-06-25 07:04:22.374813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:04:31.661429
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test read of instance variable support_check_mode
    assert(action_module_0.__support_check_mode == True)
    # Test assignment of instance variable support_check_mode
    assert(action_module_0.__support_check_mode == True)

    # Test read of instance variable supports_async
    assert(action_module_0.__supports_async == True)
    # Test assignment of instance variable supports_async
    assert(action_module_0.__supports_async == True)

    # Test read of instance variable supports_async
    assert(action_module_0.__supports_async == True)
    # Test assignment of instance variable supports_async
    assert(action_module_0.__supports_async == True)

# Generated at 2022-06-25 07:04:35.746936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xad\xdc\x03\xdb'
    int_0 = -18592
    float_0 = 1.6
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)

    return 0



# Generated at 2022-06-25 07:04:40.477334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    dict_1 = {}
    dict_2 = {}
    var_0 = action_module_0._get_module_args(dict_1, dict_2)



# Generated at 2022-06-25 07:04:45.186549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\x07\xca\xf1\xfb\x04\xd2\xdd'
    int_0 = -18
    float_0 = 0.44
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:04:53.749974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)



# Generated at 2022-06-25 07:05:03.099131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -60
    # Declare a variable for assertion, used in the next assert
    var_0 = True
    # Call the constructor, with argument int_0
    action_module_0 = ActionModule(False, int_0, int_0, int_0, int_0, int_0, int_0, int_0, int_0, int_0)
    # Assert isinstance(action_module_0, ActionModule) is false
    assert_false(var_0, "isinstance(action_module_0, ActionModule)")


# Generated at 2022-06-25 07:05:09.822037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 9323
    float_0 = -0.13
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 07:05:12.455067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 07:05:15.819015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x84>k\\Yw\x8b\xb6f\xca\xa3'
    int_0 = 3759
    float_0 = -581.28
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, float_0, int_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == None
