

# Generated at 2022-06-25 06:57:45.698332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 06:57:50.773890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:57:59.670837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)
    action_module_0.set_wrapper(None)
    action_module_0.run(None, None)



# Generated at 2022-06-25 06:58:06.223532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 42.711
    set_0 = set()
    str_0 = '-'
    str_1 = 'WwO_OG'
    bytes_0 = b'\xa1\xaf\xcd\x0f'
    set_1 = set()
    bool_0 = True
    action_module_1 = ActionModule(float_0, set_0, str_0, bytes_0, set_1, bool_0)
    action_module_1.run()


# Generated at 2022-06-25 06:58:11.867684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setup
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)
    test_case_0()


# Generated at 2022-06-25 06:58:16.661115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_1 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)
    tmp_0 = dict()
    task_vars_0 = dict()
    action_module_1.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:58:21.090799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)


# Generated at 2022-06-25 06:58:29.794136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.9378503762134376
    set_0 = set()
    str_0 = '\x0c\x0cR\x1dqs%c\x14\x18\x0b\x1d'
    bytes_0 = b'\x8d\x0c\xee\xdd\xc1\xd0\xa0\x90\xd3\x9b\x93x\x92\xe1\x85\x96\xa1\x11\xb6\x99'
    set_1 = set()
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_1, bool_0)


# Generated at 2022-06-25 06:58:40.564134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3607.0
    set_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, str_0, bytes_0, set_0, bool_0)
    result = action_module_0.run(tmp=bytes_0, task_vars=set_0)
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:46.569816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = '\x04\x7f\x1a'
    dict_0 = dict()
    set_1 = {'\x1d\\\x1b\x02\x0c\x12\x07\n'}
    bytes_0 = b'\xe0\xa1z\x0c'
    float_0 = 5263.0
    list_0 = [dict_0]
    set_2 = set()
    dict_1 = {'\x17t\x1c': bytes_0}
    list_1 = [float_0]
    list_2 = [float_0]
    dict_2 = {'\x07a\x11': dict_1}

# Generated at 2022-06-25 06:59:03.042473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-\x0b\x0c\x1f\x1e\x14\x07\x05\x16'
    str_1 = 'm'
    var_0 = set()
    float_0 = 2770.0
    int_0 = 6080
    float_1 = 6327.0
    float_2 = 1080.0
    int_2 = 3234
    int_1 = 3997
    int_3 = 6927
    test_obj = ActionModule(parallel=None, tasks=[], tqm=None, callback=None, connection=None, play=None, loader=None, shared_loader_obj=None, environment=None)
    test_obj.run(tmp=None, task_vars=None)
    test_case_0()

# Generated at 2022-06-25 06:59:03.698590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:59:11.639119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    params_0 = {"meta": {"refresh_inventory": True}}

    params_1 = {"meta": {"refresh_inventory": True}, "inventory_path": "/9j1h3F"}

    params_2 = {"free_form": ["Ansible", "Tower"], "meta": {"refresh_inventory": True}, "groups": [{"children": ["all"]}, {"hosts": ["test_host", "test_host_0"]}], "inventory_path": "/9j1h3F"}


# Generated at 2022-06-25 06:59:17.731999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'zZ.Yk>\x1e!G\x1a\x1f"<LK`'
    str_1 = 'zZ.Yk>\x1e!G\x1a\x1f"<LK`'
    var_0 = set()
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    float_0 = -3607.0
    bool_0 = False
    float_1 = -3607.0
    bytes_1 = b'\xfe\xe5\x10\xa3_\xe2'
    float_0 = -3607.0
    str_2 = 'zZ.Yk>\x1e!G\x1a\x1f"<LK`'
    float

# Generated at 2022-06-25 06:59:22.418002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fact_module = 'module'
    tmp = None
    task_vars = {}
    obj = ActionModule(fact_module, tmp, task_vars)
    test_case_0()


# Generated at 2022-06-25 06:59:32.648090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_args = dict()
    mod_args['filter'] = '*'
    mod_args['gather_subset'] = 'all'
    mod_args['gather_timeout'] = '600'
    task_vars = dict()
    task_vars['ansible_network_os'] = 'ios'
    task_vars['ansible_facts_parallel'] = True
    float_0 = -3607.0
    var_0 = set()
    str_0 = '^|\x0b\x0bN:C['
    bytes_0 = b'\xfe\xe5\x10\xa3_\xe2'
    bool_0 = False
    tmp = None
    result = ActionModule().run(tmp, task_vars)

# Generated at 2022-06-25 06:59:38.406179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj = ActionModule(tmp, task_vars)

    # call method run and assert correct return values and side effects
    err = None
    try:
        obj.run(tmp, task_vars)
        assert True
    except Exception as e:
        err = e
        assert False

    # Check for exception
    assert err is None



# Generated at 2022-06-25 06:59:44.971081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = ']\t2b\x1a\x1d\x0f\x18\x02\r\r\r\r\r\r\r'
    str_1 = '\x13\x19\x11\x14\x15\x10\t\x1a\x10\x02\x02'
    str_2 = '\x10\x19\x02\x03\x0c\x10\x0b\x13\x04\x1d'
    str_3 = '\x0f\x04\x12\x17\x04\x1f\x1a\x1f\x1f\n'

# Generated at 2022-06-25 06:59:48.370724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = ActionModule()
    obj_ActionModule = ActionModule()
    # Tests for code coverage of the test case
    obj_ActionModule.run()
# End of Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:59:55.395912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -5903.0
    var_0 = map()
    str_0 = 'J)6'
    bytes_0 = b'/q|\x08\\'
    bool_0 = True
    float_1 = -311.0
    int_0 = 9
    var_1 = {}
    float_2 = 567.0
    float_3 = -3565.0
    var_2 = {'tWc%': float_2,'j': float_0,'uwA': float_0,'J': float_2,'{': float_3,'#)': float_3,'H': float_0,}
    var_3 = test_ActionModule_run
    var_4 = {'T': var_2,'c': var_2,'u': int_0,'{': var_2,}


# Generated at 2022-06-25 07:00:14.803851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 734
    float_0 = 716.77
    str_0 = 'c:\\\xc2\xa3\x16\x8c\xf1\x11\x0f\xaf\xd4\x04\x0b'
    bytes_0 = b'\x9c\xcd\xc2\x1a\x96\x06\xe7\x91o\xaa\x1cA\'\xc3\xb0\x8d\xd4\x0b\xb0\xfe\xcd\x10\x99\xab\xeb\xa8\x93'
    tuple_0 = (str_0, bytes_0)

# Generated at 2022-06-25 07:00:23.716618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    assert type(action_module_0) == ActionModule
    assert action_module_0.noop_fallbacks_to_poll is False
    assert action_module_0.connection is None
    assert action_module_0.templar is None

# Generated at 2022-06-25 07:00:33.850425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)

    assert action_module_0 is not None
    assert action_module_0._task.argument_spec is not None
    assert action_module_0._templar._available_variables is not None
    assert action_module_0._task._shared_loader_obj.module_loader._

# Generated at 2022-06-25 07:00:44.796911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)

# Generated at 2022-06-25 07:00:50.465546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Provided by user
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    test_case_0(action_module_0)


# Generated at 2022-06-25 07:00:59.503009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:01:09.908869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_module_0.task
    var_1 = action_module_0.shared_loader_obj
    var_2 = action_module_0.connection
    var_3 = action_module_0._task
    var_4 = action_module_0._shared

# Generated at 2022-06-25 07:01:15.632090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6830
    float_0 = 93.6
    str_0 = 'k&%O$2Lv\x9f'
    bytes_0 = b"\xeed\x80\x1bk\xbb\xd0\x9a\xe1\x82'\x0c\t\xdc\xc8\x86\xcc\xa3\x9a\xe8\x8c\x99\xea\xe0\x8d\x9a\xd1_\xb9\x9f\x8c\xab"
    tuple_0 = (int_0, int_0, float_0, str_0, bytes_0)

# Generated at 2022-06-25 07:01:16.703391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: create test
    pass


# Generated at 2022-06-25 07:01:25.719182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    task_vars_1 = {}
    var_0 = action_module_0.run(task_vars_1)

# Generated at 2022-06-25 07:01:51.667709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # default args
    obj = ActionModule()
    assert obj

######
# EOF

# Generated at 2022-06-25 07:01:58.456564
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:02:08.642237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables init
    int_0 = 25
    float_0 = 8443.15
    str_0 = '2nL6)a|[bR'
    bytes_0 = b'a\xc9\xbf\x7f\xf8\xc4sV\xec\xe4\x9a\x99\xc3\xd3\x9b\xcc\xf2'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_run()
    assert len(var_0) == 0
    assert var_0.get('ansible_facts') == {}
    assert var_0.get('warnings') is None


# Generated at 2022-06-25 07:02:12.240856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO: Add test for run
    assert False


# Generated at 2022-06-25 07:02:18.688220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)


# Generated at 2022-06-25 07:02:26.969797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)

    assert action_module_0 is not None
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:02:28.092191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_case_0()

# Generated at 2022-06-25 07:02:29.069706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:02:39.778947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)

# Generated at 2022-06-25 07:02:49.152644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_module__get_module_args()
    var_1 = action_module__combine_task_result()
    var_2 = action_module_run()

# Generated at 2022-06-25 07:03:50.056838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 959
    float_0 = 9658.4
    str_0 = '\x00\x1fF\xe2\x1fb\xe30\x8c\x88\x9b\x00\x1b'
    bytes_0 = b'\xd7\x1c\xbf\x07\x9d\x80\xf6\xab\xb0\xb6\x19\x86'
    tuple_0 = (bytes_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:03:58.406329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 586
    float_0 = 5809.38
    str_0 = 'Q'
    bytes_0 = b'\x9b\xc2\xa3\x91\x80\xf8\xce\x91\xde\x03\xef\xb6\xc7\xd5\xe1\xf8\xd8\x08\x1c'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    tmp = None
    task_vars = {}
    return action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:04:03.219155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Unit test for method run of class ActionModule")

    # TODO:
    # Implement unit tests for class ActionModule method run
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 07:04:09.697740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 603
    float_0 = 9677.65
    str_0 = 'Kv2C\xaa'
    bytes_0 = b'G\xe0K(\xe3\xef\xd0\xb9\xa0Z'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)


# Generated at 2022-06-25 07:04:15.678681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 554
    float_0 = 97.06
    str_0 = 'f=O'
    bytes_0 = b'X\x83\xb7j\xd1\x1f\x11\xc6\xcf\x07\x9e\xe9J\x1a\xd2\x80'
    tuple_0 = (bytes_0, str_0, int_0)
    action_module_0 = ActionModule(int_0, float_0, float_0, float_0, str_0, tuple_0)


# Generated at 2022-06-25 07:04:21.433180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    float_0 = 8.0968156
    str_0 = '\xad\x94%\x90\xac\x8f\x97\xa9\xec\x88\x0b\x8b$\x93\xec\x94\xf6\xdb'
    bytes_0 = b'\xa2\x8c\x82\n[\x96\xa9\x1b8\x93\xca\xa6\x8c\x91\x0b\x86\x16\x9f\x96\xa7\x10\x1b\x8b\xcc\xac\x19S\x9c\x8e'
    tuple_0 = (str_0, bytes_0)

# Generated at 2022-06-25 07:04:23.546122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = {}
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:04:25.557430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\nExecuting ', __name__)
    test_case_0()
    print('Finished ', __name__, '\n')

# Run all the test cases.

# Generated at 2022-06-25 07:04:31.283674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    action_module_0.run(bytes_0, tuple_0)


# Generated at 2022-06-25 07:04:32.126740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:06:24.841562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True ==  True # TODO: implement your test here


# Generated at 2022-06-25 07:06:25.737914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert func_0() # FIXME: needs better error reporting


# Generated at 2022-06-25 07:06:35.087106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    __tracebackhide__ = True
    try:
        action_module_0.run()
    except Exception:
        __tracebackhide__ = False
        raise


# Generated at 2022-06-25 07:06:41.011020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        if str(e) == 'AssertionError: One or more starting variables not provided to constructor':
            return
    assert False


# Generated at 2022-06-25 07:06:47.998052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_run()
    assert var_0.get('ansible_facts') == {}
    assert var_0.get('failed') is False
    assert var_0.get('failed_modules') == {}
    assert var_0.get('msg') is None
   

# Generated at 2022-06-25 07:06:56.612425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the class instance
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)

    action_module_0.run()


# Generated at 2022-06-25 07:06:57.908637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:07:04.803459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)

    # Test with task_vars == None
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    # del action_module_0

    # Test with task_vars == None
    action_module_1 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    #

# Generated at 2022-06-25 07:07:09.909077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    # Testing setup facts module
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    task_vars_0 = dict()
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    module_name_0 = b'ansible.legacy.setup'
    module_args_0 = dict()

# Generated at 2022-06-25 07:07:18.551354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    float_0 = 4234.666
    str_0 = '.~Iv&,T-'
    bytes_0 = b'w\xbd\x86\xc8l\x0eLp,G\xe0K(\xe3\xef\xd0\xb9\xa0Z\xd9'
    tuple_0 = (str_0, bytes_0)
    action_module_0 = ActionModule(int_0, int_0, float_0, str_0, str_0, tuple_0)
    var_0 = action_module_0.action_run()
    pass
