

# Generated at 2022-06-25 06:57:48.678980
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:57:49.205972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:57:53.410350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = '~#n[D_H5n-w\\]|F'
    str_1 = 'Y=rI'
    int_0 = 401
    set_0 = {str_1}
    dict_0 = {set_0: str_1}
    tmp_1 = 'm$6<`4{#Z'
    str_0 = '5.xkV6C\t0$T'
    set_1 = {str_0}
    dict_1 = {set_1: str_0}
    test_action_module = ActionModule()
    test_action_module.run(tmp_1, dict_1)
    test_action_module.run(tmp_0, dict_0)

if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-25 06:57:55.931829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    assert ActionModule.run(tmp, task_vars)

# Generated at 2022-06-25 06:58:04.208621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_0 = [40, 'key1', 'key2']
    fixture_1 = {
        'ansible_job_id': ('', 6, '\x0f'),
        'changed': False,
        'invocation': {'module_args': {'_ansible_module_name': 'ansible.legacy.async_status', '_raw_params': 'jid=ansible_job_id_value _async_dir=ansible_fact_dir'}}
    }
    fixture_2 = {
        'ansible_job_id': ('', 6, '\x0f'),
        'ansible_facts': dict_0,
        'ansible_facts_dir': './tests/runner/files/',
        'ansible_errors': list_0
    }

# Generated at 2022-06-25 06:58:07.575562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    assert action_module_0.run(tmp_0, task_vars_0) == None

# Generated at 2022-06-25 06:58:10.387331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 401
    dict_1 = dict()
    dict_2 = {dict_1: 401}
    dict_3 = {dict_2: int_0}
    ActionModule(dict_3)


# Generated at 2022-06-25 06:58:13.486024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        obj_a0 = ActionModule()
    except Exception as ex:
        print(ex)
        obj_a0 = None
        assert False
    finally:
        del obj_a0
        obj_a0 = None


# Generated at 2022-06-25 06:58:21.549930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Qgf5l'
    str_1 = 'Qgf5l.py'
    int_0 = 5
    str_2 = 'ansible.legacy.setup'

# Generated at 2022-06-25 06:58:22.508153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:58:34.500705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:43.411608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'\x85\xdc\x05\x0c\xd5\x8c\x9d'
    str_0 = '\x81\xd5\x0f\x80m\xdd\x0b\x8a\x91\x1c\x03'
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    var_0 = action_run()


# Generated at 2022-06-25 06:58:46.389820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare the input parameters

    # Invoke the function with arguments
    result = ActionModule.run(bytes_0)
    # Verify the results
    assert result == var_0



# Generated at 2022-06-25 06:58:48.609532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print( ActionModule.__doc__ )
    test_case_0()

if __name__ == '__main__':
  test_ActionModule()

# Generated at 2022-06-25 06:58:50.005169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:58.084463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash

    self._supports_check_mode = True

    result = super(ActionModule, self).run(tmp, task_vars)
    result['ansible_facts'] = {}

    # copy the value with list() so we don't mutate the config
    modules = list(C.config.get_config_value('FACTS_MODULES', variables=task_vars))


# Generated at 2022-06-25 06:59:01.329891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars = dict()
    tmp = dict()
    action_run()

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 06:59:08.833757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = True
    var_1 = False
    var_2 = b'9\\\x870\xcd\x0f'
    var_3 = '$40\te?vE '
    var_4 = {var_3: var_2}
    var_5 = 3
    var_6 = 1525
    action_module_0 = ActionModule(var_0, var_1, var_2, var_4, var_5, var_6)


# Generated at 2022-06-25 06:59:16.873992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = True
    bytes_0 = b'\xe9\xe9e\xeb\xbe\xbe$\xf2\xed\xa2'
    str_0 = 'z\x9e\xc9\x82\x93\x82\x00'
    dict_0 = {str_0: bytes_0}
    int_0 = 1
    int_1 = 1
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:59:26.537702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_0['var_0'] = dict_0
    dict_0['var_1'] = dict_0
    dict_0['var_2'] = dict_0
    dict_0['var_3'] = dict_0
    dict_0['var_4'] = dict_0
    dict_0['var_5'] = dict_0
    dict_0['var_6'] = dict_0
    dict_0['var_7'] = dict_0
    dict_0['var_8'] = dict_0
    dict_0['var_9'] = dict_0
    dict_0['var_10'] = dict_0
    dict_0['var_11'] = dict_0
    dict_0['var_12'] = dict_0

# Generated at 2022-06-25 06:59:54.415229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the mock
    actionBase = Mock()
    executor.module_common.get_action_args_with_defaults = Mock()
    executor.module_common.get_action_args_with_defaults.return_value= ('$40\te?vE ')
    action_module_0 = ActionModule(actionBase, '$40\te?vE ', {'$40\te?vE ': b'9\\\x870\xcd\x0f'}, {'$40\te?vE ': b'9\\\x870\xcd\x0f'}, 3, 1525)
    # This asserts whether the constructor is called with the correct parameters
    assert_equal(actionBase, actionBase)

# Generated at 2022-06-25 06:59:55.777521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:00:00.956575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables used in test
    action_module_0 = ActionModule(int_0, int_1, list_0, module_name, self)
    action_module_0.run()



# Generated at 2022-06-25 07:00:11.295913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run of class ActionModule')
    # Creation of instance for class ActionModule with arguments
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    # Creation of instance for class ActionBase with arguments
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    dict_1 = dict_0

# Generated at 2022-06-25 07:00:16.408871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Arguments
    #
    tmp = ''
    task_vars = ''
    #
    # Call signature
    #
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:00:20.688892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # import pdb; pdb.set_trace()
    test_case_0()

# Generated at 2022-06-25 07:00:26.734043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'\x0c\xb6\x92\x9f'
    str_0 = '\x1a\x10\x0c\xbf\xa4\xaf\x1d'
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    action_module_0.run()


# Generated at 2022-06-25 07:00:32.936644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)


# Generated at 2022-06-25 07:00:33.811150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run() == "This is a test"

# Generated at 2022-06-25 07:00:42.454465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    assert not hasattr(action_module_0, '_supports_check_mode')



# Generated at 2022-06-25 07:01:28.286594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    dict_0 = {}
    dict_0['file'] = 'config.yaml'
    dict_0['key'] = 'foo'
    dict_0['module_defaults'] = dict
    dict_0['no_log'] = False
    dict_0['playbook_dir'] = '/etc/ansible/playbooks'
    dict_0['task_vars'] = dict
    dict_0['workdir'] = '/tmp/ansible/tmp'
    action_module_0 = ActionModule(bool_0, bool_1, dict_0)
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 07:01:31.187441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run())


# Generated at 2022-06-25 07:01:32.256529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:01:33.598331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:01:35.743299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = boolean(True)
    var_1 = dict()
    var_2 = test_case_0()

    # Check if the results are as expected
    assert var_2 == var_1

# Generated at 2022-06-25 07:01:45.836411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = True
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(var_1, bool_1, bytes_0, dict_0, int_1, int_0)
    var_0 = action_module_0.run(dict_0, dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:01:47.502959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b'this test needs to be completed'
    pass

# Generated at 2022-06-25 07:01:52.227258
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    param_tmp = None
    param_task_vars = None

    ret = ActionModule.run(param_tmp, param_task_vars)

# Generated at 2022-06-25 07:02:00.824337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    bool_0 = False
    bytes_1 = b'SQ\xefx\xcc\xa8'
    str_0 = 'pE1K'
    dict_0 = {str_0: bytes_1}
    int_0 = 4
    int_1 = 134
    action_module_0 = ActionModule(bool_1, bool_0, bytes_1, dict_0, int_0, int_1)

# Unit test to test the run() method of class ActionModule 

# Generated at 2022-06-25 07:02:04.303215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n")
    # TODO: Create test cases
    print("\n")

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:03:27.453639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # case 0
    test_case_0()

# Generated at 2022-06-25 07:03:31.011144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if (action_module_0.is_supported_by is None):
        assert(True)
    else:
        assert(False)


# we don\'t have any unit test for method \'_get_module_args\' of class \'ActionModule\'

# we don\'t have any unit test for method \'_combine_task_result\' of class \'ActionModule\'

# we don\'t have any unit test for method \'run\' of class \'ActionModule\'

# Generated at 2022-06-25 07:03:33.346289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        pass
    except ImportError as exception_0:
        print('ImportError:', exception_0)
    pass

# Generated at 2022-06-25 07:03:39.276820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    tmp = None
    var_0 = None
    var_1 = action_module_0.run(tmp, var_0)
    assert var_1 
    assert var_1 == var_1

# Generated at 2022-06-25 07:03:49.951876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Some test values
    bool_0 = True
    bool_1 = False
    bytes_0 = b'9\\\x870\xcd\x0f'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1525

    # Testing the constructor of class ActionModule
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)

    # Testing for exceptions
    try:
        action_module_0 = ActionModule()
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 07:03:57.414029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'0(\x00\xd8'
    str_0 = '\tT0\x8bx'
    dict_0 = {str_0: bytes_0}
    int_0 = 8
    int_1 = 2
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    var_1 = action_run()
    var_0 = action_module_0.run(var_1, var_1)
    assert var_0 == var_1


# Generated at 2022-06-25 07:03:58.416603
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = test_case_0()

# Generated at 2022-06-25 07:04:08.115901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'\xed\xb0\xbd\xb2\x8d\xcd\x0b'
    str_0 = '-\xce\x83\xbe\x0f\xe8\xbe\xfb\xdc\x99'
    dict_0 = {str_0: bytes_0}
    int_0 = 3
    int_1 = 1798
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    # Dictionary tmp (line 103):
    str_1 = 'A\x12\xd1\x17\x06\x9c\xaa\xf5\r\xd0\xac'
    bytes_

# Generated at 2022-06-25 07:04:15.450130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'\xb0\x14\x1d\x0b\xf1\xbf;\x8b'
    str_0 = '$40\te?vE '
    dict_0 = {str_0: bytes_0}
    int_0 = 2
    int_1 = 6144
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    assert isinstance(action_module_0, ActionBase)
    assert isinstance(action_module_0._supports_check_mode, bool)


# Generated at 2022-06-25 07:04:19.994938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'L\xa3i\x17\xb9'
    str_0 = 'f<\x03\xe0\xc2\x1d'
    dict_0 = {str_0: bytes_0}
    int_0 = 5
    int_1 = -1
    action_module_0 = ActionModule(bool_0, bool_1, bytes_0, dict_0, int_0, int_1)
    assert action_module_0._supports_check_mode == True
