

# Generated at 2022-06-25 06:57:41.750501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 06:57:51.328482
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:02.298913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the method run() of ActionModule
    """

    # Test case 0:

    print('Test case 0:')
    str_0 = 'j}{\r4\tY9ka'
    list_0 = []
    set_0 = {str_0, str_0}
    tuple_0 = (
        str_0, (
            str_0, set_0, set_0
        )
    )
    float_0 = float()
    float_1 = float()
    float_2 = float(tuple_0)
    float_3 = float(float_1)
    float_4 = float(float_1)
    float_5 = float(float_1)
    float_6 = float(float_1)
    float_7 = float(float_1)

# Generated at 2022-06-25 06:58:11.631156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._shared_loader_obj = None
    action._display = None
    action._connection = None
    action._task = None
    action._templar = None
    action._loader = None
    action._connection = None
    action._shell = None
    action._action = None
    action._task_vars = None
    action._post_validation_task_vars = None
    action._tmp_path = "/home/mauricio/Escritorio/Ansible/proyecto-ansible/ansible/ansible-core/lib/ansible/module_utils/facts/test_module_0.py"
    action._shell_executable = None
    action._uses_shell = None
    action._always_pipeline = None
    action._async_seconds = None


# Generated at 2022-06-25 06:58:20.206092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    test_case_0()

## Unit test for before_state_reading of class ActionModule
#def test_before_state_reading():
#    obj = ActionModule()
#    obj.before_state_reading()

## Unit test for before_state_writing of class ActionModule
#def test_before_state_writing():
#    obj = ActionModule()
#    obj.before_state_writing()

## Unit test for copy_module of class ActionModule
#def test_copy_module():
#    obj = ActionModule()
#    obj.copy_module()

## Unit test for copy_module_file of class ActionModule
#def test_copy_module_file():
#    obj = ActionModule()
#    obj.copy_module_file()

## Unit test for copy_module_files

# Generated at 2022-06-25 06:58:21.940176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_0 = ActionModule()
    actionmodule_0.run(None)


# Generated at 2022-06-25 06:58:22.843575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-25 06:58:31.362751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import string
    import re
    str_0 = 'N,2d~rV<qObKtd'
    str_1 = 'FACTS_MODULES'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_2 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_3 = {str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-25 06:58:39.218631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = C.config()
    tmp = None
    task_vars = {'test': 'test'}
    assert ActionModule(obj, tmp, '_', '_').run(tmp, task_vars) == {'skipped_modules': {}, 'failed': True, 'ansible_facts': {'_ansible_facts_gathered': True}, 'msg': 'The following modules failed to execute: ansible\n', '_ansible_verbose_override': True}


# Generated at 2022-06-25 06:58:40.539918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_ActionModule = ActionModule()
    assert mock_ActionModule.run() == None


# Generated at 2022-06-25 06:58:56.127122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Some parameters for run
    tmp = None
    task_vars = None
    # Prepare local variables for run
    action_module_0 = ActionModule()
    # Invoke run
    action_module_run(action_module_0, tmp, task_vars)


# Generated at 2022-06-25 06:59:03.385513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with invalid input
    action_module_obj = ActionModule('test connection', 'test shell', 'test task', 'test loader', 'test templar', 'test display')
    result = action_module_obj.run(None, None)
    assert(result == None)

    # Test with valid input
    action_module_obj = ActionModule('test connection', 'test shell', 'test task', 'test loader', 'test templar', 'test display')
    # TODO, action_module_obj.run(None, None)

    return 0


# Generated at 2022-06-25 06:59:08.053166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_run()



# Generated at 2022-06-25 06:59:11.147675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'kA'
    bytes_1 = b'\xbe\x84\xdf\xe0\x97\x14\x1b\xaa'
    float_1 = -1414.84
    action_module_1 = ActionModule(str_1, str_1, str_1, str_1, bytes_1, float_1)
    assert action_module_1.run(tmp=None, task_vars=None).pop('ansible_facts').pop('_ansible_facts_gathered') == True



# Generated at 2022-06-25 06:59:14.162123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:59:19.640290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:59:29.039392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path_0 = ansible_config_path()
    content_0 = ansible_config_content()
    file_0 = ansible_config_dict_content()
    str_0 = 'A'
    file_1 = ansible_config_file_path()
    path_1 = ansible_config_file_content()
    bytes_0 = ansible_config_file_dict_content()
    str_1 = 'A'
    file_2 = ansible_config_file_dict_content()
    str_2 = 'A'
    str_3 = 'A'
    bytes_1 = ansible_config_file_path()
    float_0 = ansible_config_file_dict_content()
    bytes_2 = ansible_config_path()
    str_4 = 'A'
    float_1

# Generated at 2022-06-25 06:59:35.248595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Init object
    str_0 = 'W'
    bytes_0 = b'\x08F\xe6'
    float_0 = -440.72
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    # Test
    var_0 = action_module_0.run()
    print(var_0)



# Generated at 2022-06-25 06:59:41.486145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instance of class ActionModule
    action_module_0 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class ActionModule
    action_module_1 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class ActionModule
    action_module_2 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class ActionModule
    action_module_3 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class ActionModule
    action_module_4 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class ActionModule
    action_module_5 = ActionModule(str, str, str, str, bytes, float)
    # Instance of class Action

# Generated at 2022-06-25 06:59:45.366878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()
    assert type(var_0) is dict

# Generated at 2022-06-25 07:00:13.515503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule('ansible.legacy.setup', 'local', {'module_name': 'ansible.legacy.setup'}, '/home/siptmp/.vscode-server/extensions/ms-python.python-2019.12.49222/pythonFiles/ptvsd_launcher.py', 'ansible.legacy.setup', {'module_name': 'ansible.legacy.setup'}, '/tmp/', b'\x00\x00\x00\x00', {'module_name': 'ansible.legacy.setup'}))


# Generated at 2022-06-25 07:00:18.416329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 07:00:27.249689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def method_call(self, tmp=None, task_vars=None):
        result = super(ActionModule, self).run(tmp, task_vars)
        result['ansible_facts'] = {}
        modules = list(C.config.get_config_value('FACTS_MODULES', variables=task_vars))
        parallel = task_vars.pop('ansible_facts_parallel', self._task.args.pop('parallel', None))
        if 'smart' in modules:
            connection_map = C.config.get_config_value('CONNECTION_FACTS_MODULES', variables=task_vars)

# Generated at 2022-06-25 07:00:35.545504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'PlaybookV2'
    str_1 = 'TaskV2Impl'
    str_2 = 'AttributeError'
    str_3 = 'network_cli'
    bytes_0 = b'\x0f>\x05L\xf6]8C\xd2\x96\xe6\x1e\xba\x82\xee\x0b\x8b\x89\xc5\x00\xcc3\x8c'
    float_0 = -1034.0595
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, bytes_0, float_0)
    assert action_module_0 is not None



# Generated at 2022-06-25 07:00:41.409871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    assert action_module_0._task == str_0

# Generated at 2022-06-25 07:00:45.287563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:00:51.827375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '_'
    str_1 = '_'
    str_2 = '_'
    str_3 = '_'
    bytes_0 = b'/'
    float_0 = -2315.12
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, bytes_0, float_0)
    assert isinstance(action_module_0._save_as_name, str)
    assert isinstance(action_module_0.task_vars, dict)
    assert isinstance(action_module_0._checks, dict)
    assert isinstance(action_module_0.environment_string, str)
    assert isinstance(action_module_0.display, Display)
    assert isinstance(action_module_0._task, Task)

# Generated at 2022-06-25 07:00:57.439152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    action_module_0.failed_when = list()

    # Invocation
    result = action_module_0.run()

    # Verification
    assert isinstance(result, dict)

# Generated at 2022-06-25 07:00:58.005345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:01:08.672004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize args
    bytes_0 = b'\x0fF\xad\x13\x1c\x8f\x00\xc6\x7f\xbf\xa8\xfc_'
    bytes_1 = b'\x1d\x06'
    bytes_2 = b'\r\x1c'
    str_0 = '\xaa\x88[\xb3\x99\xa1\x88\x08h\x17\x1d\x9d'
    str_1 = '\xb3\xa1\xb1\x0f\x0c\x17\x9a'

# Generated at 2022-06-25 07:01:59.883157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    int_0 = action_module_0._load_name.startswith(str_0)
    bool_0 = bool(int_0)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_1)
    bool_3 = bool(bool_2)
    bool_4 = bool(bool_3)
    bool_5 = bool(bool_4)
    bool_6 = bool(bool_5)
    bool_6 = bool(bool_6)

# Generated at 2022-06-25 07:02:04.079368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x05\x1c\x1e@\x1d\x0e\x07\x1f'
    bytes_0 = b'\xf0\xe1\x8d\x9c\x89\x9f\x84\xf5\x0b\xdb\xc5\xdd\xda\x1f\x82\xed\xe3\xac\xe2\xdc\xc1'
    float_0 = -1414.84
    float_1 = 1473.07
    float_2 = -1359.32
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)

# Generated at 2022-06-25 07:02:06.843107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

if __name__ == '__main__':
    for test_method in [test_case_0]:
        test_method()

# Generated at 2022-06-25 07:02:15.825022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import shutil
    my_path = os.path.dirname(os.path.realpath(__file__)) + "/"
    shutil.copytree(my_path + "fixtures", my_path + "tmp")
    shutil.copytree(my_path + "fixtures", my_path + "tmp2")
    conf = {'FACTS_MODULES': ['copy'], 'DEFAULT_ROLES_PATH': [my_path + 'tmp/roles1', my_path + 'tmp2/roles2'], 'DEFAULT_TASKS_PATH': [my_path + 'tmp/tasks1', my_path + 'tmp2/tasks2']}
    _config_manager = ConfigManager(config_data=conf)
    _shared_loader_obj = SharedPluginLoaderObj()
    action

# Generated at 2022-06-25 07:02:16.700974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = bye()


# Generated at 2022-06-25 07:02:23.310237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    if action_module_0.run() == 0:
        assert True


# Generated at 2022-06-25 07:02:26.498815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '---'
    str_2 = 'A'
    str_3 = 'x'
    bytes_1 = b'\x1e|'
    result = ActionModule(str_1, str_2, str_3, str_3, bytes_1, None)
    assert result == None


# Generated at 2022-06-25 07:02:34.041351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    float_0 = -1414.84
    str_0 = 'A'
    bytes_0 = b'\x1e|'

    # creation test
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)

    # run test
    var = action_module_0.run(None, task_vars_0)
    assert var == None

# Generated at 2022-06-25 07:02:38.628279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    var_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_1 = None
    var_2 = None
    var_2 = var_0.run(var_1, var_2)

# Generated at 2022-06-25 07:02:41.720178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)


# Generated at 2022-06-25 07:04:29.119017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 07:04:30.847799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('A', 'A', 'A', 'A', b'\x1e|', -1414.84)
    var_0 = action_module_0.run()
    assert var_0 == None


# Generated at 2022-06-25 07:04:35.304937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:04:38.803233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'A'
    bytes_0 = b'\x1e|'
    float_0 = -1414.84
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:04:44.478436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_name = 'ansible.legacy.setup'
    mod_arg = {}
    wrap_async = False
    var_0 = action_module_run(mod_name, mod_arg, wrap_async)
    # Call to _execute_module of class ActionModule missing
    # Call to _execute_module of class ActionModule missing
    # Call to _remove_tmp_path of class ActionModule missing


# Generated at 2022-06-25 07:04:51.435788
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'A'
  bytes_0 = b'\x1e|'
  float_0 = -1414.84
  action_module_0 = ActionModule(str_0, str_0, str_0, str_0, bytes_0, float_0)
  test_case_0()
  
# The below code is a modified version of the code in the ansible.module_utils.module_docs.prepare_docs()
# function. In that function, the args are processed in the 'doc' format and they are then converted to
# the 'json' format. This version simply skips the 'doc' format and it writes the 'json' format immediately.
# The reason for this is that this version of the function does not attempt to handle the deprecated options
# and that logic is in the 'doc' format but not in the 'json

# Generated at 2022-06-25 07:04:52.083045
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Assert
    pass

# Generated at 2022-06-25 07:04:56.663549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'B'
    int_0 = -732
    str_2 = 'K'
    str_3 = 'action_module'
    str_4 = 'm'
    action_module_1 = ActionModule(str_1, str_2, str_3, str_4, bytes, int_0)
    with pytest.raises(KeyError):
        assert action_module_1.run()
        assert action_module_1.run()


# Test cases for method run of class ActionModule

# Generated at 2022-06-25 07:05:03.230843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = 'A'
    var_2 = 'A'
    var_3 = 'A'
    var_4 = 'A'
    var_5 = b'\x1e|'
    float_0 = -1414.84
    var_6 = None
    var_7 = None

    action_module_0 = ActionModule(var_1, var_2, var_3, var_4, var_5, float_0)
    var_8 = action_module_run(var_6, var_7)

# Generated at 2022-06-25 07:05:06.632445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test unit test setup
    assert True

