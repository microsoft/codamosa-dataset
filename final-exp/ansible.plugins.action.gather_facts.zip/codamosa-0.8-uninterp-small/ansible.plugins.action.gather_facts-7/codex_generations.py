

# Generated at 2022-06-25 06:57:41.947964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:57:47.028894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = '!\x1d'
    list_0 = ['setup']
    action_module_0 = ActionModule(str_0, bool_0, str_0, False, False, list_0)
    # C.config.get_config_value('FACTS_MODULES')
    # action_module_0.run()


# Generated at 2022-06-25 06:57:50.075598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule('a', False, 'a', False, False, [])
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:57:52.118967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    str_1 = '@f1\x15\x18'
    str_2 = '{.|f|@[ukv"6\x0b\x0c'
    ActionModule(str_1, bool_1, str_2, bool_1, bool_1, list())


# Generated at 2022-06-25 06:58:00.664210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    bool_0 = False
    str_0 = '{.|f|@[ukv"6\x0b\x0c'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    action_module_0.run(None, None)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:05.425691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    action_module_0 = ActionModule(tmp, task_vars)
    action_module_4 = action_module_0.run(tmp, task_vars)
    bool_0 = True
    assert(action_module_4 == bool_0)


# Generated at 2022-06-25 06:58:13.966838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # Try with good parameters
    tmp = None
    task_vars = None
    try:
        ActionModule.run(tmp, task_vars)
    except:
        assert False

    # Try with bad parameters
    tmp = None
    task_vars = None
    try:
        ActionModule.run(tmp, task_vars)
    except Exception:
        tmp = None
        task_vars = None
        try:
            ActionModule.run(tmp, task_vars)
        except Exception:
            tmp = None
            task_vars = None
            try:
                ActionModule.run(tmp, task_vars)
            except Exception:
                tmp = None
                task_vars = None

# Generated at 2022-06-25 06:58:14.959818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:22.458246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'oO>_m\t,v9'
    list_0 = ['1d{O,', 'dh^*`:|a~-L>z)\x1b', '""', '\x13)x\x1b', '&%@Wd\\']
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    assert action_module_0._supports_check_mode == bool_0
    assert isinstance(action_module_0._templar, Templar)
    assert action_module_0._shared_loader_obj is None
    assert isinstance(action_module_0._task, Task)
    assert isinstance(action_module_0._display, Display)


# Generated at 2022-06-25 06:58:23.739065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Global test cases for the module ActionModule
# Unit tests for the methods of the class ActionModule

# Generated at 2022-06-25 06:58:36.061602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare a class for testing
    class TestActionModule(ActionModule):
        pass

    # Create an instance of TestActionModule
    test_action_module = TestActionModule()

    # Test code here

# Generated at 2022-06-25 06:58:42.973167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization of test variables
    bool_0 = False
    str_0 = '=K]^N!4:@\x1fR'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:58:49.734522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '{.|f|@[ukv"6\x0b\x0c'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)

    action_module_0.run(str_0, bool_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:58:55.576003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '{.|f|@[ukv"6\x0b\x0c'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    tmp_0 = ''
    task_vars_0 = {}
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:59:04.848309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = Path('/\x7f\x07\x0fB')

# Generated at 2022-06-25 06:59:11.924636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '~'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()


# Generated at 2022-06-25 06:59:15.608707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '\x1f"\x1f\x05'
    list_0 = [bool_0]
    dict_0 = {}
    action_module_0 = ActionModule(str_0, bool_0, str_0, bool_0, bool_0, list_0)
    action_module_0.run(tmp=dict_0, task_vars=dict_0)

# Generated at 2022-06-25 06:59:25.748758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    str_0 = '7?`\x12u<6\x0c\x0b;#\x1aB'
    str_1 = '7?`\x12u<6\x0c\x0b;#\x1aB'
    str_2 = '7?`\x12u<6\x0c\x0b;#\x1aB'
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, str_1, bool_1, bool_1, list_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:59:29.698395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:59:30.681695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: set ft=python et ts=4 sw=4 :

# Generated at 2022-06-25 06:59:48.914579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None

    # Call method run of class ActionModule with args (tmp=tmp_0, task_vars=task_vars_0)
    result = ActionModule.run(ActionModule(), tmp=tmp_0, task_vars=task_vars_0)

    # Assert
    assert result == {}

# Generated at 2022-06-25 06:59:49.804706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:59:53.599272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_ActionModule.__doc__ == '''Used to load facts from a remote source'''
    # Test with verbosity greater than 3
    # Creation of object using constructor and passing parameters verbosity=4
    test_case_0()
    # Test with verbosity less than 3
    # Creation of object using constructor and passing parameters verbosity=2
    test_case_0()


# Generated at 2022-06-25 07:00:02.950236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = C.DEFAULT_MODULE_PATH
    obj.get_plugin_class(str_0)
    str_1 = '\x7f\x07\x0fB'
    obj.get_all_plugin_loaders()
    obj.get_all_plugin_loaders(str_1)
    C.DEFAULT_MODULE_PATH.get_all_plugin_names()
    obj.all()
    obj.paths()
    obj.get_all_plugin_class_names()
    C.DEFAULT_MODULE_PATH.get_plugin_loader(str_0)
    str_2 = '\x7f\x07\x0fB\x1d\x02'
    obj.get_all_plugin_names(str_2)

# Generated at 2022-06-25 07:00:10.515785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(
        {},
        {},
        {'connection': None, 'display': test_case_0, 'no_log': False, 'loader': {}, 'name': 'test_action_module', 'play_context': None, 'shared_loader_obj': {}, 'task_vars': {}, 'templar': 'test_templar'},
        None,
    )


# Generated at 2022-06-25 07:00:16.353118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test for method ActionModule.run'''
    print('Test for method ActionModule.run')
    tst1 = ActionModule()
    assert tst1._supports_check_mode == True
    tst2 = ActionModule()
    assert tst2._supports_check_mode == True


# Generated at 2022-06-25 07:00:20.529422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:00:27.524339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params_0 = {
        'parallel': True
    }
    task_vars_0 = {
        'template': 'pipeline.yml',
        'system_facts': {},
        '_ansible_loop_var': 'my_loop',
        '_ansible_module_name': 'acme_job',
        '_ansible_debug': False
    }
    tmp_0 = None

# Generated at 2022-06-25 07:00:29.313247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    assert x.run()


# Generated at 2022-06-25 07:00:38.661409
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module_name = 'legacy.FactsModule'
  task_uuid = '7ec9e3fa-5b5d-4d4d-ad84-e5e449ca5fe6'
  loader = magic_mock()
  templar = magic_mock()
  shared_loader_obj = magic_mock()
  action_base = AnsibleAction(loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)
  task = magic_mock()
  display = magic_mock()
  options = magic_mock()
  connection = magic_mock()
  task_vars = {'ansible_facts_parallel': False}
  tmp = None
  inject = {}

# Generated at 2022-06-25 07:00:58.199488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Subz4)&'
    bool_0 = True
    str_1 = 'Y;|a%c3a2'
    list_0 = [False]
    list_1 = [False]
    bytes_0 = b'`'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)


# Generated at 2022-06-25 07:00:59.098073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass


# Generated at 2022-06-25 07:01:06.279055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'VUSK,A6p+$i7yZ;'
    bool_1 = False
    str_0 = 'sQUF"Ew'
    list_0 = [bool_1]
    bytes_0 = b'd'
    action_module_0 = ActionModule(str_0, bool_1, str_1, list_0, list_0, bytes_0)
    print(action_module_0)


# Generated at 2022-06-25 07:01:07.216586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:01:13.979925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'sQUF"Ew'
    bool_0 = False
    str_1 = 'VUSK,A6p+$i7yZ;'
    list_0 = [bool_0]
    bytes_0 = b'd'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# def test_case_1():
#     str_0 = 'QvUr8$?W

# Generated at 2022-06-25 07:01:24.008530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'y~8+"`"PyvV7b_q'
    bool_0 = False
    str_1 = '_$-LKy'
    list_0 = []
    list_1 = []
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    tmp = None
    task_vars = None
    # Testing start of program
    try:
        # Calling run with arguments (tmp, task_vars)
        action_module_0.run(tmp, task_vars)
    # Testing exception raise in run
    except Exception:
        assert True
# Unit

# Generated at 2022-06-25 07:01:32.891587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'zD]\:$Q'
    bool_0 = True
    str_1 = '\r"<>Hr'
    list_0 = [str_1]
    list_1 = [bool_0]
    bytes_0 = b'y'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    print(action_module_0, end='')

    # getter for attribute '_shared_loader_obj'
    # getter for attribute '_display'
    # getter for attribute '_options'
    # getter for attribute '_task'
    # getter for attribute '_connection'
    # getter for attribute '_templar'



# Generated at 2022-06-25 07:01:35.805165
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule('sQUF"Ew', False, 'VUSK,A6p+$i7yZ;', [False], [False], b'd')
  return action_module_0


# Generated at 2022-06-25 07:01:46.832727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule with argument values
    str_0 = '''Lx`J[$OD+FcI(#1y~]Fc%_6'I'6+YHwZ'#Mb{I'^<'''

# Generated at 2022-06-25 07:01:57.434249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module_1 is an instance of class ActionModule
    str_0 = 'sQUF"Ew'
    bool_0 = False
    str_1 = 'VUSK,A6p+$i7yZ;'
    list_0 = [bool_0]
    bytes_0 = b'd'
    action_module_1 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)

    # case 1
    str_0 = 'sQUF"Ew'
    bool_0 = False
    str_1 = 'VUSK,A6p+$i7yZ;'
    list_0 = [bool_0]
    bytes_0 = b'd'

# Generated at 2022-06-25 07:02:26.408392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'hello world!'
    bytes_0 = b'hello world!'
    action_module_0 = ActionModule(str_0, True, str_0, [str_0], [str_0], bytes_0)
    result = action_module_0.run()
    if result != None:
        print('Unit test failed!')


if __name__ == '__main__':
    # Run test cases
    test_ActionModule_run()
    #test_case_0()

# Generated at 2022-06-25 07:02:30.618959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W<J8'
    bool_0 = False
    str_1 = '8%z{'
    int_0 = 0
    list_0 = [str_0, int_0, False]
    bytes_0 = b'D\x1c'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)

    # Test action_module_0._task.args
    assert action_module_0._task.args == {'foo': 'bar', 'baz': 'qux'}

    # Test action_module_0._task.action
    assert action_module_0._task.action == 'setup'

    # Test action_module_0._task._parent.get_name
    assert action_module_0

# Generated at 2022-06-25 07:02:37.752660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get an action module object
    fact_module = 'ansible.legacy.setup'
    args = '{"filter": "*"}'
    task_vars = {}
    action_module_0 = ActionModule(fact_module, args, '', [], [], b'')

    # Test the run method of the ActionModule.
    if (action_module_0.run(task_vars) == 0):
        raise Exception("The test for run of ActionModule is failed.")



# Generated at 2022-06-25 07:02:45.582338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'sQUF"Ew'
  bool_0 = False
  str_1 = 'VUSK,A6p+$i7yZ;'
  list_0 = [bool_0]
  bytes_0 = b'd'
  action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
  var_0 = None
  var_1 = action_module_0.run(var_0)
  assert var_1 != None

# Generated at 2022-06-25 07:02:50.822728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'B$/'
    bool_0 = False
    str_1 = 'Qu`3l'
    list_0 = [bool_0]
    bytes_0 = b']'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    var_0 = action_module_0._get_module_args()
    var_1 = action_module_0._combine_task_result()
    var_2 = action_module_0.run()


# Generated at 2022-06-25 07:02:57.762704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '`N&]{uN^hK'
    bool_0 = False
    str_1 = ' '
    list_0 = [bool_0]
    list_1 = [bool_0]
    bytes_0 = b'Iy'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:02:59.697451
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    for _ in range(4):
        var_0 = ActionModule()
        try:
            var_0.run()
        except:
            pass
        else:
            print("Expected Exception")


# Generated at 2022-06-25 07:03:09.118278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Rmjy:*'
    bool_0 = True
    str_1 = 'PQ{Jj8'
    list_0 = [0.4572849327231277, bool_0]
    list_1 = [bool_0]
    bytes_0 = b'],HNJWY\x17\x90%\xc7'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    assert isinstance(ActionModule, type(action_module_0))


# Generated at 2022-06-25 07:03:10.773368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    var_0 = action_module_run()

# Generated at 2022-06-25 07:03:16.736089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ':5'
    bool_0 = True
    str_1 = 'O;@]Y!Fu\\\x0c3r"BMS'
    list_0 = [str_1]

# Generated at 2022-06-25 07:04:14.366547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '7'
    bool_0 = False
    str_1 = 'n;'
    list_0 = [bool_0]
    local_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, None)
    var_0 = action_run(local_0)

# Generated at 2022-06-25 07:04:22.568236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#gI_S!S;'
    bool_0 = True
    str_1 = '7$uLf*G'
    list_0 = [bool_0]
    list_1 = [bool_0]
    bytes_0 = b'U'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    print('[+] Value of ivar _supports_check_mode of class ActionModule is:')
    print(action_module_0._supports_check_mode)
    print('---')
    print('[+] Value of ivar _task of class ActionModule is:')
    print(action_module_0._task)
    print('---')

# Generated at 2022-06-25 07:04:30.391418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'setup'
  bool_0 = True
  str_1 = 'd\x06'
  list_0 = [bool_0]
  list_1 = [bool_0]
  bytes_0 = b'\xe0\xbf'
  action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
  tmp_0 = ''
  task_vars_0 = {}
  action_module_run(action_module_0, tmp_0, task_vars_0)


# Generated at 2022-06-25 07:04:33.593878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'yQ2L_r8W'
    bool_0 = False
    str_1 = 'p!#o{Pf$'
    list_0 = [bool_0]
    bytes_0 = b'b'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:04:40.735130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize input parameters
    list_0 = [False]
    str_0 = 'CqlgQP'
    str_1 = 'LmTX6Tv'
    str_2 = 'q3d}p"n]`"W"\`'
    bytes_0 = b'F'
    action_module_0 = ActionModule(str_2, False, str_0, list_0, list_0, bytes_0)
    var_0 = action_run(action_module_0, None, None)
    var_1 = action_run(action_module_0, None, None)


# Generated at 2022-06-25 07:04:43.986692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:04:46.895931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    if (var_0.failed):
        raise RuntimeError()
    if (var_0.skipped):
        raise RuntimeError()
    if (not var_0.ansible_facts['_ansible_facts_gathered']):
        raise RuntimeError()



# Generated at 2022-06-25 07:04:52.847564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DummyClass:

        @staticmethod
        def _dummy_method(arg_0, arg_1):
            pass

        def dummy_func(self, arg_0, arg_1):
            pass

    class_0 = DummyClass()
    class_0.dummy_func()


# Generated at 2022-06-25 07:04:56.990510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:05:02.318730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#8>9m` '
    bool_0 = False
    str_1 = 'z/3'
    list_0 = [bool_0]
    list_1 = [bool_0]
    bytes_0 = b't'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)


# Generated at 2022-06-25 07:07:22.070827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-'
    bool_0 = True
    str_1 = '-*v'
    list_0 = [bool_0]
    list_1 = [False]
    bytes_0 = b'\x00'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_1, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:07:23.886707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # first unit-test
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:07:27.728112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'sQUF"Ew'
    bool_0 = False
    str_1 = 'VUSK,A6p+$i7yZ;'
    list_0 = [bool_0]
    bytes_0 = b'd'
    action_module_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)

# Generated at 2022-06-25 07:07:31.216621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 = ActionModule(str_0, bool_0, str_1, list_0, list_0, bytes_0)
    # var_0.run(tmp=None, task_vars=None)
    # var_0._get_module_args(fact_module=None, task_vars=None)
    # var_0._combine_task_result(result=None, task_result=None)
    assert True == True

