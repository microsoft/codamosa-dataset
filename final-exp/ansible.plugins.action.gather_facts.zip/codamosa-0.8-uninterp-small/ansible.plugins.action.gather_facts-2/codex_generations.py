

# Generated at 2022-06-25 06:57:42.072745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
        test_value = True
    except Exception as err:
        print(err)
        test_value = False
    assert test_value

# Generated at 2022-06-25 06:57:43.462141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test method run of class ActionModule")
    action_module_0 = ActionModule()
    action_module_0.run()
    return None


# Generated at 2022-06-25 06:57:46.566056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    test_case_0()
    assert_true(isinstance(ActionModule(tmp, task_vars), ActionModule), 'ActionModule() returned unexpected instance')


# Generated at 2022-06-25 06:57:48.485263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {"ansible_facts_parallel": False}
    tmp = None
    obj = ActionModule(task_vars=task_vars, tmp=tmp)

    result = obj.run()
    assert result is None

# Testing for the scenario when the FACTS_MODULES config is ['smart', 'setup']

# Generated at 2022-06-25 06:58:00.215098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import shared_loader_obj
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_results import TaskResult
    from ansible.utils.vars import combine_vars

    content = 'a = "b"\n'

# Generated at 2022-06-25 06:58:09.942146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {'type':'dict', 'default':'True', 'required':'False', 'no_log':'False', 'choices':'[u\'all\', u\'network\', u\'non_network\']', 'aliases':'[u\'gather_subset\']', 'name':'gather_subset'}
    str_0 = 'G`Dq}9X$'
    boolean_0 = False
    complex_0 = complex(0, 1)
    byte_0 = bytes([0, 0, 0, 32, 19, 9, 10, 25, 16, 9, 11, 4, 3, 9, 8])
    int_0 = 83
    str_1 = 'c#82M3^yt'
    list_0 = [str_1, str_1, str_1]
    set_

# Generated at 2022-06-25 06:58:16.639305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DictObject(object):
        def __init__(self, value):
            self.value = value

        def __getitem__(self, key):
            return self.value[key]

        def __repr__(self):
            return '%s(value=%r)' % (self.__class__, self.value)

    module_spec = dict(
        argument_spec=dict(
            module_name=dict(type='str'),
            module_args=dict(type='dict', default={}),
            task_vars=dict(type='dict', default={}),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-25 06:58:17.255460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:58:25.262585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = None
    task_vars = None

    # Setup mocks for test
    ActionModule()._remove_tmp_path = lambda _: None
    ActionModule()._shared_loader_obj = MockAnsibleLoader()
    ActionModule()._templar = MockTemplar()
    ActionModule()._connection = MockConnection()
    ActionModule()._display = MockDisplay()
    ActionModule()._task = MockTask()
    ActionModule()._execute_module = lambda _a, module_name, module_args, **kwargs: {'ansible_facts': {}}

    # Run action
    result = ActionModule.run(ActionModule(), tmp, task_vars)

    assert result is not None


# Generated at 2022-06-25 06:58:29.474468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionBase_0 = ActionBase()
    tmp_0 = None
    task_vars_0 = None
    actionModule_0 = ActionModule(actionBase_0, tmp_0, task_vars_0)
    test_case_0()
    actionModule_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:58:43.313616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule(self._connection, self._loader, self._templar, self._shared_loader_obj)
    result = action_module.run(tmp, task_vars)
    return result


# Generated at 2022-06-25 06:58:47.164041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t1_action_module = ActionModule()
    str_0 = 'a = "b"\n'


if __name__ == '__main__':
    print(test_case_0())
    # print(test_ActionModule())

# Generated at 2022-06-25 06:58:48.174285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()


# Generated at 2022-06-25 06:58:50.324690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get a test ActionModule object
    action_module_0 = ActionModule()
    # TODO: add test code


# Generated at 2022-06-25 06:58:53.677217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fact_module = 'ansible'
    task_vars = dict()
    actual = ActionModule(fact_module, task_vars)
    actual_0 = actual._supports_check_mode
    expected_0 = True
    assert actual_0 == expected_0


# Generated at 2022-06-25 06:59:00.803557
# Unit test for constructor of class ActionModule
def test_ActionModule():
        str_0 = 'b"foo"'
        str_1 = 'b"bar"'
        bytes_2 = b'foo'
        bytes_3 = b'bar'
        str_4 = 'b"foo"'
        str_5 = 'b"bar"'
        bytes_6 = b'foo'
        bytes_7 = b'bar'
        str_8 = 'b"foo"'
        str_9 = 'b"foo"'
        str_10 = '"foo"'
        str_11 = 'b"foo"'
        str_12 = '"foo"'
        str_13 = 'b"foo"'
        str_14 = 'b"foo"'
        str_15 = '"foo"'
        str_16 = 'b"foo"'
        str_17 = '"foo"'

# Generated at 2022-06-25 06:59:09.907576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0.__doc__)


# Generated at 2022-06-25 06:59:10.575637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()


# Generated at 2022-06-25 06:59:16.850286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a = "b"\n'
    str_1 = 'a = "b"\n'
    str_2 = 'a = "b"\n'
    str_3 = 'a = "b"\n'
    str_4 = 'a = "b"\n'
    str_5 = 'a = "b"\n'
    str_6 = 'a = "b"\n'
    str_7 = 'a = "b"\n'
    str_8 = 'a = "b"\n'
    tmp_0 = 'a = "b"\n'
    tmp_1 = 'a = "b"\n'
    tmp_2 = 'a = "b"\n'

    task_vars_0 = mock.MagicMock()
    task_v

# Generated at 2022-06-25 06:59:18.088876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:59:38.501820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '''\n'''
    str_1 = 'a = "1"\n'
    str_2 = 'a = "2"\n'
    str_3 = 'a = "3"\n'
    str_4 = 'a = "4"\n'
    str_5 = 'a = "5"\n'
    str_6 = 'a = "6"\n'
    str_7 = 'a = "7"\n'
    str_8 = 'a = "8"\n'
    str_9 = 'a = "9"\n'
    str_10 = 'a = "10"\n'
    str_11 = 'a = "11"\n'
    str_12 = 'a = "12"\n'

# Generated at 2022-06-25 06:59:45.047705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = 'aGVsbG8gd29ybGQ='
    data = base64.b64decode(data)
    dat = 'aGVsbG8gd29ybGQ='

# Generated at 2022-06-25 06:59:51.072203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In case of test_case_0
    tmp = None
    task_vars = {"ansible_facts_parallel": None, "ansible_network_os": None, "ansible_facts": {}}
    action_module = ActionModule()
    assert action_module.run(tmp, task_vars) == {'deprecations': [], 'ansible_facts': {'_ansible_facts_gathered': True}, 'warnings': [], '_ansible_verbose_override': True}

# Generated at 2022-06-25 06:59:56.802555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a = "b"\n'
    ansible_module_0 = ActionModule
    res_0 = ansible_module_0.run()
    assert res_0 == True


# Generated at 2022-06-25 07:00:05.063751
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp_0 = None
    task_vars_0 = None
    ActionModule_instance_0 = ActionModule()
    ActionModule_instance_1 = ActionModule()
    ActionModule_instance_2 = ActionModule()
    ActionModule_instance_3 = ActionModule()
    ActionModule_instance_2._display = mock_object(ActionModule_instance_2._display)
    ActionModule_instance_3._display = mock_object(ActionModule_instance_3._display)
    ActionModule_instance_2._remove_tmp_path = mock_object(ActionModule_instance_2._remove_tmp_path)
    ActionModule_instance_3._remove_tmp_path = mock_object(ActionModule_instance_3._remove_tmp_path)

# Generated at 2022-06-25 07:00:07.241061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:00:14.083423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule()

    # Testing with a positional argument
    try:
        action_module.run(tmp, task_vars)
    except TypeError as e:
        assert type(e) == type(TypeError())
    except Exception as e:
        print(e)
        assert False

    # Testing with a keyword argument
    try:
        action_module.run(tmp=tmp, task_vars=task_vars)
    except TypeError as e:
        assert type(e) == type(TypeError())
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 07:00:15.995305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mocker.patch('ansible.plugins.action.setup.ActionModule.run')
    test_case_0()


# Generated at 2022-06-25 07:00:24.610366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case for a simple module that does not have arguments
    action_module_0 = ActionModule()
    action_module_0._task.args = {}
    action_module_0.run()
    assert action_module_0._task.args == {}
    # Test case for a module that contains arguments
    action_module_0 = ActionModule()
    action_module_0._task.args = {'a': 'b'}
    action_module_0.run()
    assert action_module_0._task.args == {'a': 'b'}
    # Test case for a module that contains arguments of type dictionary
    action_module_0 = ActionModule()
    action_module_0._task.args = {'a': {'b': {'c': 'd'}}}
    action_module_0.run()
   

# Generated at 2022-06-25 07:00:26.508384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule
    assert a.run(tmp=None, task_vars=None) == None

# Generated at 2022-06-25 07:00:45.367687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule('x', 'y')
    action_module_0.set_loader(None)
    action_module_0.set_connection('x', 'y')
    action_module_0.set_module_name('z')
    action_module_0.set_module_vars({})
    action_module_0.set_module_vars_files([])
    action_module_0.set_task_vars({})
    action_module_0.set_task_vars_files([])
    action_module_0.set_options({})
    action_module_0.set_task_vars({})
    result = action_module_0.run(tmp, task_vars)
    assert result is None

# Generated at 2022-06-25 07:00:47.021286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        obj = ActionModule()
        obj.run()
    except Exception as err:
        print(err)


# Generated at 2022-06-25 07:00:48.132982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global str_0
    test_case_0()


# Generated at 2022-06-25 07:00:53.548261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule_0()
    obj_1 = ActionModule_1()
    tmp_0 = None
    fact_module_0 = 'a'
    task_vars_0 = {}
    result_0 = obj_0.run(tmp_0, task_vars_0)
    assert obj_0.run(tmp_0, task_vars_0) == result_0
    assert obj_1.run(tmp_0, task_vars_0) == result_0
    assert obj_0.run(tmp_0, task_vars_0) == result_0
    assert obj_1.run(tmp_0, task_vars_0) == result_0
    assert obj_0.run(tmp_0, task_vars_0) == result_0

# Generated at 2022-06-25 07:00:58.269762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task_vars = {'ansible_facts_parallel': True}
    result = action_module.run(None, task_vars)
    assert result['ansible_facts'] == {}

# Generated at 2022-06-25 07:00:59.891223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  b = ActionModule()
  b._task = task()
  b._task_vars = task_vars()
  b.run()


# Generated at 2022-06-25 07:01:10.046570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a = "b"\n'
    str_1 = 'a = "b"\n'
    str_2 = 'a = "b"\n'
    str_3 = 'a = "b"\n'
    str_4 = 'a = "b"\n'
    str_5 = 'a = "b"\n'
    str_6 = 'a = "b"\n'
    str_7 = 'a = "b"\n'
    str_8 = 'a = "b"\n'
    str_9 = 'a = "b"\n'
    str_10 = 'a = "b"\n'
    str_11 = 'a = "b"\n'
    str_12 = 'a = "b"\n'
    str_13

# Generated at 2022-06-25 07:01:14.759459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # From Local test

    # Test case 0
    global str_0
    str_0 = 'a = "b"\n'
    test_case_0()

    return True

if __name__ == "__main__":
    if test_ActionModule_run():
        print("test passed")
    else:
        print("test failed")

# Generated at 2022-06-25 07:01:22.191420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    t.set_task_vars({'ansible_facts': {}})
    t.set_task_args({'d': 'a', 'b': 'a', 'c': 'a', 'a': 'a', 'gather_subset': ['all'], 'gather_timeout': 2})
    t.set_task({'collections': None})
    t._remove_tmp_path = test_case_0
    t._shared_loader_obj = object()
    t._execute_module = test_case_0
    t.run()

# Generated at 2022-06-25 07:01:32.754257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars__annotations = {}
    task_vars__annotations['test_case_0'] = 'a = "b"\n'
    task_vars = {}
    task_vars['test_case_0'] = 'a = "b"\n'
    task_vars['test_case_1'] = 'a = "b"\n'
    tmp = None
    task_vars['ansible_facts_parallel'] = None
    # FIXME: self.setup_fact_cache.populate()
    
    
    
    
    
    
    
    
    
    
    # FIXME: self.setup_fact_cache.write()

# Generated at 2022-06-25 07:02:00.948202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    actionmodule_instance = ActionModule()
    params = (tmp, task_vars)
    actionmodule_instance.run(*params)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:02:01.638259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:02:12.223498
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:02:20.740366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.errors import AnsibleError
    from ansible import constants as C
    from ansible.utils.vars import merge_hash
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Playbook
    
    try:
        true
    except NameError:
        true = True
        false = False
        null = None
        import __builtin__ as builtins
    
    # AnsibleModule
    
    # Ans

# Generated at 2022-06-25 07:02:24.051533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._task.args == {}
    assert action_module._supports_check_mode == True
    assert action_module._task.action == 'setup'
    assert action_module._task.loop == 'setup'
    assert action_module._task.args == {}
    assert action_module._task.module_defaults == {}

# Generated at 2022-06-25 07:02:29.118784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args': {'a': 'b'}, 'module_name': 'action_module'}, connection={'play_context': {'extra_vars': {'a': 'b'}}, '_shell': None}, templar={'_available_variables': {'a': 'b'}, '_templar_environment': None}, loader={'_fact_cache': {'a': 'b'}}, share_loader=None, variable_manager={'_extra_vars': {'a': 'b'}})
    str_1 = str(action_module)


# Generated at 2022-06-25 07:02:39.809487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiating object of class ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    import jinja2
    loader = DataLoader()
    play_source = dict(
        name="Ansible Play 0",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='setup'), register='shell_out'), dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]
    )

# Generated at 2022-06-25 07:02:46.004159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of arguments
    arg_0 = {"FACTS_MODULES": ['a'], "ansible_facts_parallel": False, "parallel": False}

    # Create an instance of module_defaults
    module_defaults_0 = {"a": 'b'}

    # Create an instance of templar
    templar_0 = None

    # Create an instance of action_groups
    action_groups_0 = {}

    # Create an instance of task_vars
    task_vars_0 = {"b": 'c', "ansible_facts": {"network_os": 'd', "c": 'd'}, "ansible_network_os": 'd', "a": 'b'}

    # Create an instance of module_name
    module_name_0 = "a.b.c"



# Generated at 2022-06-25 07:02:53.046032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    action_plugins_dir = 'dir'
    name = 'name'
    shared_loader_obj = 'shared_loader_obj'
    task_uuid = 'task_uuid'
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    templar = 'templar'
    task = 'task'
    exit_q = 'exit_q'

    # initializing arguments
    # Initializing object
    action_module = ActionModule(action_plugins_dir, name, shared_loader_obj, task_uuid, connection, play_context, loader, templar, task, exit_q)
    assert action_module._supports_check_mode == True

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:03:00.074797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = {'proxy_url': 'https://github.com/ansible/ansible', 'gather_timeout': 'b', 'gather_subset': 'a', 'timeout': 'a', 'filter': 'b'}
    obj = ActionModule(args=args_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:03:57.903944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert str_0 == module_0.run()

# Generated at 2022-06-25 07:03:58.553509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:03:59.456246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:04:02.500288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'a = "b"\n'
    for i in range(10):
        obj_0 = ActionModule(str_0)
        if isinstance(obj_0, ActionModule):
            break

    str_1 = ' _ansible_facts_gathered'
    assert obj_0._ansible_facts_gathered == str_1


# Generated at 2022-06-25 07:04:09.134241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {'ansible_facts_parallel': None, 'network_os': None, 'filter': '*', 'gather_subset': 'all'}
    test_module_0 = ActionModule()
    test_module_0._task = {'action': 'setup'}
    test_module_0._task.args = args_0
    tmp_path_0 = '/var/folders/rz/r85r1rln1dz_p_gv27cyvdjc0000gn/T/'

# Generated at 2022-06-25 07:04:17.006247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = 'InventoryVariable(hostvars=hostvars, groups=groups, name=name)'
    host_name = 'SimpleInventoryPlugin(inventory_sources=inventory_sources, hosts_pattern=hosts_pattern, cache=cache, loader=loader, sources=sources)'
    test_connection = 'module_defaults=module_defaults'
    test_connection = 'n/a'
    test_play_context = 'play=play, options=options'
    test_play_context = 'play=play'
    test_task_vars = 'DeferredAttribute(name=task_vars, task=None, loader=loader)'
    test_task_vars = 'vars=vars, default_vars=default_vars, loader=loader'

# Generated at 2022-06-25 07:04:27.914086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    task = dict()
    task["become"] = dict()
    task["become_method"] = "sudo"
    task["become_user"] = "root"
    task["no_log"] = False
    task["vars"] = dict()
    task["block"] = dict()
    task["delegate_to"] = None
    task["delegate_facts"] = False
    task["environment"] = dict()
    task["first_available_file"] = None
    task["local_action"] = dict()
    task["name"] = "setup"
    task["notify"] = dict()
    task["register"] = "ansible_facts"
    task["retries"] = 3
    task["run_once"] = False
    task

# Generated at 2022-06-25 07:04:32.275699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Connection('docker')
    task = Task()
    host.run(task)


test_ActionModule_run()

# Generated at 2022-06-25 07:04:34.343118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # test with the following params
    params = []
    assert module.run(params) == 'expected result'



# Generated at 2022-06-25 07:04:44.671951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = 'a'
    arg_1 = 'b'
    arg_2 = 'c'
    arg_3 = 'd'
    arg_4 = 'e'
    arg_5 = 'f'
    arg_6 = 'g'
    arg_7 = 'h'
    arg_8 = 'i'
    arg_9 = 'j'
    arg_10 = 'k'
    arg_11 = 'l'
    arg_12 = 'm'
    arg_13 = 'n'
    arg_14 = 'o'
    arg_15 = 'p'
    arg_16 = 'q'
    arg_17 = 'r'
    arg_18 = 's'
    arg_19 = 't'
    arg_20 = 'u'
    arg_21 = 'y'

   

# Generated at 2022-06-25 07:05:47.553276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2954.795
    bytes_0 = b"*"
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0]
    action_module_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)
    dict_0 = action_run(float_0)
    assert dict_0.get("ansible_facts") == {}, "Expected {}, to equal {}"
    assert dict_0["ansible_facts"].get("_ansible_facts_gathered") == True, "Expected True, to equal True"

# Generated at 2022-06-25 07:05:56.326146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1500.72592
    bytes_0 = b'ro\x9f\xd8[\xbd|\xdb\xd8{^j,\xf8\xc7\x96'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0]
    action_module_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)
    assert isinstance(action_module_0, ActionModule,
                      'Expected instance of `ActionModule`')
    assert isinstance(action_module_0, ActionBase,
                      'Expected instance of `ActionBase`')
    assert action_module_0._supports_action_args == False

# Generated at 2022-06-25 07:06:01.902179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1500.72592
    bytes_0 = b'ro\x9f\xd8[\xbd|\xdb\xd8{^j,\xf8\xc7\x96'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0]
    action_module_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)
    var_0 = action_run(float_0)



# Generated at 2022-06-25 07:06:03.664443
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # initialize var to class ActionModule
  # var_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)
    # test of method ActionModule not implemented
    assert False


# Generated at 2022-06-25 07:06:11.300123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1500.72592
    bytes_0 = b'ro\x9f\xd8[\xbd|\xdb\xd8{^j,\xf8\xc7\x96'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0]
    action_module_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)
    action_run = action_module_0.run(float_0, float_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:06:18.277864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setting up test variables
    float_0 = -1500.72592
    bytes_0 = b'ro\x9f\xd8[\xbd|\xdb\xd8{^j,\xf8\xc7\x96'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0]
    action_module_0 = ActionModule(bytes_0, set_0, list_0, set_0, set_0, bytes_0)


# Generated at 2022-06-25 07:06:26.461172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_ActionModule_run.__doc__)

    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    target_0 = Test()
    try:
        action_module_0.run()  # expected exception
    except AssertionError:
        pass

    # Test for raising of exception
    if target_0.result_0[0] == 1:
        raise Exception('Raised expected exception')

    action_module_0.run()
    action_module_1.run()


# Generated at 2022-06-25 07:06:29.991494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: implement
    assert True

# Generated at 2022-06-25 07:06:35.505137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setup code
    str_0 = '5J*\xec\xe2\x99\x9c\xf5\x16\x0e\xd5\xc4\xbb\x95\x0b\x9b\x87\xda\x95\xdd\xa6\x07\x1d\x06\x13\x01\x17\x15\x00\x1d\x1b\x08\x1b\x06\x13'
    bytes_0 = b'\x15M\x8d\x1f\xfb\x85\x8d\x9aU\x00'
    float_0 = -1500.72592
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}

# Generated at 2022-06-25 07:06:39.603020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var = run(float_0)