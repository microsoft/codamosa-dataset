

# Generated at 2022-06-25 06:57:48.679230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x04/\x03'
    set_0 = set()
    int_0 = 1446
    int_1 = 1
    bytes_1 = b'\x02\x1f\x04\x1cK\x1e\x02\x16'
    list_0 = [set_0]

    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_1, bytes_1, list_0)

    list_1 = [set_0]
    dict_0 = {'gather_subset': [set_0], 'ansible_facts_parallel': [set_0]}
    tmp_0 = None
    task_vars_0 = dict_0


# Generated at 2022-06-25 06:57:50.075692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:00.940244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1b\x0c\xb4\xa8'
    set_0 = set()
    int_0 = -3643
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_0, list_0)
    bytes_1 = b'\x95\xd6\x00\x00'
    int_1 = -3643
    bytes_2 = b'\xf2\x85\xc4\x1c'
    action_module_0.run(bytes_1, int_1, tmp=bytes_2)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:10.494383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    task_vars = dict()

    print('Test case 0')
    dict_0 = dict()
    tmp = dict_0
    task_vars = dict()
    int_0 = -23847
    bytes_0 = b'\x99\x08\xcf'
    dict_0 = dict()
    list_0 = [dict_0]
    action_module_0 = ActionModule(tmp, bytes_0, int_0, int_0, tmp, list_0)
    result = action_module_0.run(tmp, task_vars)
    if result['ansible_facts']['_ansible_facts_gathered'] != True:
        raise TypeError
    if result['_ansible_verbose_override'] != True:
        raise TypeError

# Generated at 2022-06-25 06:58:18.683282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'm'
    set_0 = {b'\xba\xdd\xba\xdd'}
    bytes_1 = b'\x00\x00\x00'
    int_0 = -3448
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_1, set())
    task_vars = {"dir": "dir", "_ansible_parsed": True, "row": "row", "ansible_user_dir": "ansible_user_dir", "_ansible_no_log": True, "changed": True}
    str_0 = action_module_0.run(set_0, task_vars)
    assert str_0

# Generated at 2022-06-25 06:58:23.632275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'L\x0f\xff'
    set_0 = set()
    int_0 = -3643
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_0, list_0)
    tmp_0 = None
    task_vars_0 = None
    try:
        result = action_module_0.run(tmp_0, task_vars_0)
    except KeyError as e:
        assert type(e) == KeyError



# Generated at 2022-06-25 06:58:31.938761
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:42.682459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        bytes_0 = b'L\x0f\xff'
        set_0 = set()
        int_0 = -3643
        list_0 = [set_0]
        action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_0, list_0)

        def test_the_runner_scale_factors_of_the_module_name():
            runner_result = action_module_0.run(set_0, list_0)
            assert runner_result == {"failed": True, "msg": "The following modules failed to execute:  \n", "failed_modules": {}}
    except Exception:
        print('Exception: ' + str(Exception))
        if '_ansible_verbose_override' in runner_result:
            raise

# Generated at 2022-06-25 06:58:53.194030
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:57.637147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0e'
    set_0 = set()
    int_0 = -1
    list_0 = [bytes_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_0, list_0)
    str_0 = action_module_0.run()
    assert str_0 == '\x0e'


# Generated at 2022-06-25 06:59:10.776208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:59:15.952188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 06:59:21.393997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test: string and dict input
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    result = action_module_0.run('tmp', 'task_vars')

# Example 2
# Test: string and dict input
#            print(result)


if __name__ == '__main__':
    test_case_0()
    # test_ActionModule_run()

# Generated at 2022-06-25 06:59:22.453130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:59:26.627996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    bytes_1 = b'_'
    int_0 = 2
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_1)
    action_module_0.connection = 'tQG'
    action_module_0._remove_tmp_path = '~'
    dict_0 = dict()
    dict_0['ansible_facts'] = dict()
    dict_0['ansible_facts']['network_os'] = 'pfSense'
    dict_1 = dict()
    dict_1['ansible_facts'] = dict()
    dict_1['ansible_facts']['os'] = 'Linux'
    dict_2 = {}
    dict_2['ansible_facts'] = {}

# Generated at 2022-06-25 06:59:27.494271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:33.736811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    int_0 = 4
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    return result


# Generated at 2022-06-25 06:59:41.860835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    action_module_0.setup = MagicMock()
    action_module_0.cleanup = MagicMock()
    tmp_0 = None
    task_vars_0 = {'play_hosts_all': {'host_name': 'host', 'inventory_hostname': 'changed', 'groups': {'group_names': ['all']}, 'vars': {'ansible_connection': 'ssh'}}}
    action_module_0.run(tmp_0, task_vars_0)
    action_module_0.setup.assert_called_with()

# Generated at 2022-06-25 06:59:52.439357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'|'
    int_0 = 32
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    action_module_0._shared_loader_obj = None
    tmp_1 = b'/'
    task_vars_1 = {}
    # Run the method with required arguments
    result = action_module_0.run(tmp=tmp_1, task_vars=task_vars_1)
    assert result is None
    # Run the method with all arguments
    result = action_module_0.run(tmp_1, task_vars=task_vars_1)
    assert result is None


# Generated at 2022-06-25 06:59:58.436520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    # test_tmp = None
    # test_task_vars = None
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:00:44.566929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x97\xa5'
    int_0 = 7
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    action_module_0._remove_tmp_path(bytes_0)
    int_0 = 3
    task_vars_0 = {}
    action_module_0.run(bytes_0, task_vars_0)


# Generated at 2022-06-25 07:00:46.882784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        positive_test_result_0 = True
    except Exception as exception:
        positive_test_result_0 = False
    assert positive_test_result_0


# Generated at 2022-06-25 07:00:55.843119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    bytes_1 = b'\\'
    int_0 = 0
    int_1 = 0
    bytes_2 = b'\\'
    bytes_3 = b'\\'
    action_module_0 = ActionModule(bytes_0, bytes_1, int_0, int_1, bytes_2, bytes_3)
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0.get('ansible_facts') != None
    assert result_0 != None

# Generated at 2022-06-25 07:00:58.065546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print("It should not raise exception")
    except Exception:
        assert False

test_ActionModule()
ActionModule.run()

# Generated at 2022-06-25 07:01:02.403686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    action_module_0._supports_check_mode = True
    task_vars = {'ansible_facts_parallel': True}
    result = action_module_0.run(None, task_vars)
    assert result['ansible_facts'] == {}
    assert result['ansible_facts_gathered'] == True
    assert result['_ansible_verbose_override'] == True


# Generated at 2022-06-25 07:01:04.472541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:01:06.983982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    print('Testing started!')
    test_ActionModule()
    print('Testing finished!')

# Generated at 2022-06-25 07:01:11.312673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    tmp = None
    task_vars = None

    # Invocation
    result = action_module_0.run(tmp, task_vars)

    # Tests
    assert result is not None


# Generated at 2022-06-25 07:01:13.802050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\\'
    int_0 = 5
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_0)
    assert isinstance(action_module_0, ActionModule) == True



# Generated at 2022-06-25 07:01:23.811987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'['
    int_0 = 0
    bytes_1 = b'\\'
    action_module_0 = ActionModule(bytes_0, bytes_0, int_0, int_0, bytes_0, bytes_1)
    action_module_0._shared_loader_obj = FakeSharedPluginLoaderObj()
    action_module_0._task_vars = dict()
    action_module_0._task_vars['_failed_when_item_value'] = dict()
    action_module_0._task_vars['_failed_when_item_value']['key0'] = 'value0'
    action_module_0._connection = FakeConnectionObj()
    action_module_0._templar = FakeTemplarObj()
    dict_0 = dict()

# Generated at 2022-06-25 07:02:11.381130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a ActionModule object
    ansible_facts_parallel = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check the methods of object ansible_facts_parallel
    assert ansible_facts_parallel._get_module_args() == undefined
    assert ansible_facts_parallel._combine_task_result() == undefined
    assert ansible_facts_parallel.run() == undefined

# Generated at 2022-06-25 07:02:13.680284
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    fixture_data = {
            'task_vars': {},
        }

    results = ActionModule.run(fixture_data)
    assert results == {'failed': True}

# Generated at 2022-06-25 07:02:18.860105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule")
    print(">>>>>>>>>>>> Test case 0")
    task_vars = None
    tmp = None
    print("Test case 0 - invocation 1")
    print("Test case 0 - invocation 2")
    print("Test case 0 - invocation 3")
    print("Test case 0 - invocation 4")
    # test_ActionModule_run.test_case_0()
    print("<<<<<<<<<<<<")


# Generated at 2022-06-25 07:02:26.837731
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import sys
    import __builtin__
    fake_stdin = sys.stdin
    sys.stdin = file('/dev/null')

    try:
        act_mod_0 = ActionModule(connection = 'connection_0', templar = 'templar_0', loader = 'loader_0', shared_loader_obj = 'shared_loader_obj_0', task = 'task_0', job_vars = 'job_vars_0', play_context = 'play_context_0', check_mode = bool_0)
    finally:
        sys.stdin = fake_stdin


# Generated at 2022-06-25 07:02:32.666912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of class ActionModule
    # fact_module = None
    # task_vars = None
    action_module = ActionModule(fact_module, task_vars)

    # Method run of class ActionModule
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:02:34.673805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert True


# Generated at 2022-06-25 07:02:37.378350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test of constructor
    '''
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Unit tests for _get_module_args()

# Generated at 2022-06-25 07:02:39.612814
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module = ActionModule(None, None)
  assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:02:49.814500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing of run method: Module facter, no facter installed
    os_system_0 = os.system
    from ansible.plugins.action import ActionBase
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars, load_options_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.utils.display import Display
    import ansible.constants as C
    from ansible.executor.task_result import TaskResult
    import ansible.utils.vars as utils_vars
    from ansible.inventory.host import Host
    import ansible.utils.uns

# Generated at 2022-06-25 07:02:52.030391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments for the ActionModule.run method
    tmp = None
    task_vars = None

    instance = ActionModule()
    result = instance.run(tmp, task_vars)

    assert result
    assert result == 'action'

# Generated at 2022-06-25 07:03:52.570670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:03:54.857879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    # This is the first test case, which calls the method without arguments
    action_module_1.run()


# Generated at 2022-06-25 07:03:58.589756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:03.571094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:04:13.326395
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:04:17.915882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    assert  result is not None

# Generated at 2022-06-25 07:04:23.730894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result_0 = action_module_0.run()
    assert result_0 == {'ansible_facts': {'_ansible_facts_gathered': True}, '_ansible_verbose_override': True}


# Generated at 2022-06-25 07:04:25.772860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None

    action_module_1 = ActionModule()
    assert action_module_1 != None


# Generated at 2022-06-25 07:04:30.223851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = dict()
    result = action_module_1.run(tmp, task_vars)
    assert type(result) == dict
    assert len(result) == 4
    assert 'ansible_facts' in result
    assert 'warnings' in result
    assert 'deprecations' in result
    assert 'ansible_facts_gathered' in result['ansible_facts']


# Generated at 2022-06-25 07:04:31.834536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call the method with a test object
    action_module = ActionModule()
    result = action_module.run()
    assert type(result) is dict

# Generated at 2022-06-25 07:05:24.389622
# Unit test for constructor of class ActionModule
def test_ActionModule():
  int_1 = -3643
  dict_1 = {int_1: int_1, int_1: int_1}
  bytes_1 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
  set_1 = set()
  int_2 = -3643
  bytes_2 = b''
  list_1 = [set_1]
  action_module_1 = ActionModule(bytes_1, set_1, int_2, int_2, bytes_2, list_1)
  assert_equal(action_module_1.module_args, dict_1, 'Argument module_args of constructor call does not match instance module_args')


# Generated at 2022-06-25 07:05:32.570057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1429
    dict_0 = {int_0: int_0, int_0: int_0}
    bytes_0 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
    set_0 = set()
    int_1 = -3643
    bytes_1 = b''
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_1, int_1, bytes_1, list_0)
    return


# Generated at 2022-06-25 07:05:41.500717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {-3643: -3643, -3643: -3643}
    bytes_0 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
    set_0 = set()
    int_0 = -3643
    bytes_1 = b''
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_0, bytes_1, list_0)
    dict_1 = action_module_0.run(set_0, dict_0)


# Generated at 2022-06-25 07:05:51.496520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test of AnsibleModule.run with typical arguments
  import ansibullbot.versioners.release as release
  import ansibullbot.utils.extractors as extractors
  import ansibullbot.utils.find_modules as find_modules
  import ansibullbot.utils.files as files
  import ansibullbot.utils.text as text
  import ansibullbot.utils.github as github
  import ansibullbot.utils.discussions as discussions
  import ansibullbot.ansible.repo as repo
  import ansibullbot.ansible.release as arelease
  import ansibullbot.ansible.module_utils.facts as facts
  import ansibullbot.constants as constants
  import ansibullbot.parsers.botmetadata as botmetadata
  import ansibullbot.pars

# Generated at 2022-06-25 07:05:56.444945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1429
    dict_0 = {int_0: int_0, int_0: int_0}
    bytes_0 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
    set_0 = set()
    int_1 = -3643
    bytes_1 = b''
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_1, int_1, bytes_1, list_0)
    assert(action_module_0 is not None)


# Generated at 2022-06-25 07:06:02.966304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6307
    dict_0 = {int_0: int_0, int_0: int_0}
    bytes_0 = b'\xa1\xd8\x02\xab\x95\xa9\xc5\x8b\xca\x1c\xac\x8e\xbe\x12\x93\x9a\x06\x1d\xe6\xaf\xac\xdb\xaf\x13\x0f\x0c\xf8\xf1\x0f\xde\x8d\xfa'
    set_0 = set()
    int_1 = -5164
    bytes_1 = b''
    list_0 = [set_0]

# Generated at 2022-06-25 07:06:10.840313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1429
    dict_0 = {int_0: int_0, int_0: int_0}
    bytes_0 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
    set_0 = set()
    int_1 = -3643
    bytes_1 = b''
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_1, int_1, bytes_1, list_0)
    var_0 = action_module_0(dict_0)



# Generated at 2022-06-25 07:06:19.396555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x9a\x1a\xcf\x92\t\x81t\xfe\x90E\x92'\xaeA\x1c[\x0e\x89\xa6"
    set_0 = set()
    int_0 = -3643
    int_1 = -3643
    bytes_1 = b''
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_0, int_1, bytes_1, list_0)
    dict_0 = {int_0: int_0, int_1: int_0, int_1: int_0}
    dict_0 = action_run(dict_0)

# Generated at 2022-06-25 07:06:23.599742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 9071
    set_0 = set()
    int_1 = -5313
    int_2 = 3252
    bytes_0 = b'\x00'
    list_0 = [set_0]
    action_module_0 = ActionModule(bytes_0, set_0, int_1, int_1, bytes_0, list_0)
    assert action_module_0._task_vars == {'ansible_facts': {}}, 'assertion fails'


# Generated at 2022-06-25 07:06:29.262721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2457
    dict_0 = {int_0: int_0}
    float_0 = float(float(3691))
    bytes_0 = b'\xd9\x03\x078W\x06\x80\tQ\xeb\xc8\x9b5\xe9z0\xaa\x8e\x1e\x80\t\n\xe8\x1b\x9b\xdb\x17\xac\x0f\x80\t\xa7\xad\x8f\xb9'
    set_0 = set()
    int_1 = -6994
    dict_1 = dict()
    bytes_1 = b''
    list_0 = [dict_1]