

# Generated at 2022-06-25 06:57:43.872121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(tmp, task_vars)
    assert action_module_0 == action_module_1


# Generated at 2022-06-25 06:57:45.247169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Need to implement
    assert True == False


# Generated at 2022-06-25 06:57:51.032728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '_rvgt#RH>D=?jB"xT'
    int_0 = 20
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    str_1 = 'Tqt=N}UG`^1&N<]2GX;'
    int_1 = -66

    test_case_0()

# Generated at 2022-06-25 06:57:51.909128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:02.763886
# Unit test for constructor of class ActionModule
def test_ActionModule():
	str_0 = 'S^Wn/'
	str_1 = 'v4|N[W8K ,iXb'
	int_0 = 126
	set_0 = {int_0}
	str_2 = '_Izg`]dC'
	str_3 = 'a}0Z{G'
	str_4 = '8f0W/n'
	str_5 = 'H v*B:~C'
	action_module_0 = ActionModule(str_0, str_1, int_0, set_0, str_2, set_0)
	assert action_module_0.task_vars == set_0
	assert action_module_0.task_queue_manager == str_0
	assert action_module_0.task is None
	assert action_module_0

# Generated at 2022-06-25 06:58:06.368293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_1 = ActionModule(None, None, None, None, None, None)
    action_module_1.run(tmp, task_vars)
    pass


# Generated at 2022-06-25 06:58:10.291405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "`6\u0006"
    int_0 = 32
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 06:58:11.108525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:15.808507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:58:20.028810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'c,@|{+4n'
    int_0 = -71
    set_0 = {int_0}
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:58:41.936636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    assert action_module_0._supports_check_mode == False
    assert action_module_0._connection._shell.tmpdir == '/tmp/ansible-tmp-1526746271.76-72529969412786'
    assert action_module_0._task.module_defaults['remote_tmp'] == '/tmp/ansible-${USER}'
    assert action_module_0._task.module_defaults['local_tmp'] == '/tmp/ansible-${USER}'
    assert action_module_0._

# Generated at 2022-06-25 06:58:46.710781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with bogus values
    action_module_0 = ActionModule()
    action_module_0.run()

    # Try with valid values
    action_module_1 = ActionModule()
    action_module_1.run()



# Generated at 2022-06-25 06:58:47.788306
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:53.153768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 's'
    int_0 = 252
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_module_0.run()
    assert var_0 == None, "test_ActionModule_run: run()"


test_case_0()

# Generated at 2022-06-25 06:59:00.489273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'C[.e&v'
    var_1 = 'N~|*P'
    var_2 = 150
    var_3 = b'\xda\x8b\x83'
    var_4 = 'KvC8Szg'
    var_5 = {var_0, var_1, var_2, var_3, var_4}
    action_module_0 = ActionModule(var_1, var_3, var_2, var_0, var_0, var_5)
    var_6 = 'k(,wN<Q'
    var_7 = '\xd9\xef'
    var_8 = 'Y1Z"4'
    var_9 = 'E\'o0n'

# Generated at 2022-06-25 06:59:06.761741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)


# Generated at 2022-06-25 06:59:08.607216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 06:59:19.645572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'bE?7fOo'
    int_0 = 0
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:59:26.730296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    config_0 = C.config
    TaskVars_0 = TaskVars(config_0)
    var_0 = action_module_0._get_module_args(str_0, TaskVars_0)

# Generated at 2022-06-25 06:59:31.914175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R#'
    int_0 = 6
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0.run(set_0)


# Generated at 2022-06-25 07:00:02.753619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    str_1 = '@'
    str_2 = '0{z)~D$*#'
    byte_0 = bytearray(83)
    byte_0[0] = 52
    byte_0[1] = 53
    byte_0[2] = 52
    byte_0[3] = 54
    byte_0[4] = 55
    byte_0[5] = 50
    byte_0[6] = 52
    byte_0[7] = 49

# Generated at 2022-06-25 07:00:05.084197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'zT`'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:00:11.259382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except NameError as e:
        print(e)
        print('Method constructor of class ActionModule is not working.')
        raise Exception('Unit test failed.')


if __name__ == '__main__':
    test_ActionModule()
    print('Successful!!')

# Generated at 2022-06-25 07:00:16.814202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'U0:6I^n*mh-op$g.'
    int_0 = 110
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:00:20.040372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:00:26.248062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'Z6e:&'
    var_1 = 'J0dd*'
    var_2 = {}
    var_3 = 'u`k+p'
    var_4 = {}
    var_5 = {var_0, var_1}
    var_6 = '4QCJ'
    set_0 = {var_6}
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_7 = {}
    var_8 = action_module_0.run(var_7)
    assert var_8 is not None


# Generated at 2022-06-25 07:00:35.218015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean

    def action_run(self, tmp=None, task_vars=None):
        def boolean(self, arg, strict=False, assume_bool=True, none_value=False):
            if assume_bool:
                if arg is None:
                    return none_value
                if arg in (True, 'True', 'true', 1, '1', 'yes'):
                    return True
                if arg in (False, 'False', 'false', 0, '0', 'no'):
                    return False
                raise TypeError("unsupported type for boolean conversion: %s" % type(arg))
            return arg

        self._supports_check_mode = True

        result = super(ActionModule, self).run(tmp, task_vars)

# Generated at 2022-06-25 07:00:44.814693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    assert action_module_0.action == 'W0_02G^k_kh_na~,'
    assert action_module_0.module_name == 'W0_02G^k_kh_na~,'
    assert action_module_0.module_args == 127
    assert action_module_0.task_vars == {127}
    assert action_module_0.connection == 'W0_02G^k_kh_na~,'

# Generated at 2022-06-25 07:00:48.785401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # From test_case_0
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)

    # From test_case_1
    str_1 = 'v:_<s[h*'
    action_module_1 = ActionModule(str_1, str_1)
    action_module_1.run(task_vars=None)


# Generated at 2022-06-25 07:00:51.334080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('action_run', 'action_unfreeze_become_plugin', 'shelve', 'action', 'action_base', 'action_become_method')
    assert (action_module is not None)


# Generated at 2022-06-25 07:01:33.396744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'E(1<^FmAZG)IXI"t_5zt'
    int_0 = 194
    set_0 = {str_0, int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:01:36.132690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\\'
    int_0 = 110
    set_0 = {int_0, int_0}
    str_1 = 'Nc}1nhS2||'
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_1, set_0)
    action_module_0.run(set_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:01:40.409042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module_0 = ActionModule()



# Generated at 2022-06-25 07:01:47.545427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    str_1 = 'W0:02G^k*kh-na$m~,'
    int_1 = 127
    set_1 = {int_1}
    action_module_1 = ActionModule(str_1, str_1, int_1, set_1, str_1, set_1)
    str_2 = 'W0:02G^k*kh-na$m~,'
    int_2 = 127
    set_2 = {int_2}
    action_module_2 = ActionModule

# Generated at 2022-06-25 07:01:53.612545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)


# Generated at 2022-06-25 07:02:01.890448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}

    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0._shared_loader_obj.module_loader.find_plugin_with_context(str_0, collection_list_0=action_module_0._task.collections)
    bool_0 = action_module_0.run()


# Generated at 2022-06-25 07:02:07.838571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run()
    assert action_module_0.run()
    assert action_module_0.run()
    assert action_module_0.run()
    assert action_module_0.run()


# Generated at 2022-06-25 07:02:14.890233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule('6!KU6', 'H%cx,', 180, {130, {82}}, 'D9wxjzH', {146})
    var_1 = var_0.run()
    var_2 = var_1.assert_has_calls(call(True), call(False), call(True))

# Generated at 2022-06-25 07:02:19.051766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:02:20.465747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Actions
    action_module_0.run()

# Generated at 2022-06-25 07:03:54.588080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {
        'module_name': 'ansible.legacy.setup',
        'module_args': {
            'filter': 'ansible_default_ipv4',
            'gather_timeout': 5
        },
    }
    args_1 = {
        'module_name': 'ansible.legacy.setup',
        'module_args': {
            'filter': 'ansible_all_ipv4_addresses',
            'gather_timeout': 5
        },
    }
    args_2 = {
        'module_name': 'ansible.legacy.setup',
        'module_args': {
            'filter': 'ansible_machine_id',
            'gather_timeout': 5
        },
    }

# Generated at 2022-06-25 07:03:59.307818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = '/tmp/ansible_test/remote/'
    module_class = 'ansible.modules.system.setup'
    module_name = 'setup'
    self = 'false'
    module_path = '/etc/ansible/facts.d'
    module_defaults = ''
    action_base_0 = ActionBase()
    # Start case
    var_0 = action_base_0.run(tmp)
    # Test case

# Generated at 2022-06-25 07:04:07.971232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dTK'
    int_0 = 108
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    str_1 = 'SSB'
    set_1 = {str_1}
    str_2 = 'h<L'
    int_1 = 19
    set_2 = {int_1}
    str_3 = 'y{p'
    set_3 = {str_3}
    action_module_1 = ActionModule(str_1, str_2, int_1, set_2, str_3, set_3)
    var_0 = action_run()

# Generated at 2022-06-25 07:04:16.097675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    module_args_0 = {
        'gather_timeout': 0,
        'network_os': 'asdf',
        'gather_subset': 'min',
        'filter': '*'
    }

# Generated at 2022-06-25 07:04:26.767567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # a hack to make Ansible think the action plugin is being executed from the CLI
    # instead of a running a playbook
    os.environ["ANSIBLE_RUNNING_UNIT_TEST"] = "True"
    ansi_escapes = re.compile(r'\x1b[@-_][0-?]*[ -/]*[@-~]')

    # maps the output from the --syntax-check to the
    # expected output from the --check mode

# Generated at 2022-06-25 07:04:30.656754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dTgpvC8c=W*'
    int_0 = 141
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    str_1 = 'H]wJ*"gTT_'
    int_1 = 137
    set_1 = {int_1}

# Generated at 2022-06-25 07:04:37.676226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'z'
    int_0 = 99
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_module_0.run(None, None)
    assert var_0.get('ansible_facts') is not None
    assert var_0.get('warnings') is not None
    assert var_0.get('deprecations') is not None
    assert var_0.get('ansible_facts') == {}
    assert var_0.get('warnings') == []
    assert var_0.get('deprecations') == []
    assert var_0.get('ansible_facts') == {}

# Generated at 2022-06-25 07:04:40.345462
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule.__init__()

# Generated at 2022-06-25 07:04:42.418061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(getattr(ActionModule, "run", None)), "Method does not exist"

# Unit tests for class ActionModule

# Generated at 2022-06-25 07:04:46.064833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'W0:02G^k*kh-na$m~,'
    int_0 = 127
    set_0 = {int_0}
    action_module_0 = ActionModule(str_0, str_0, int_0, set_0, str_0, set_0)
    var_0 = action_run()
