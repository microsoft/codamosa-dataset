

# Generated at 2022-06-25 06:57:44.304826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor of class ActionModule
    ast_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(ast_ActionModule, ActionModule)


# Generated at 2022-06-25 06:57:46.347407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    tmp = None
    task_vars = None
    obj.run(tmp, task_vars)


# Generated at 2022-06-25 06:57:47.994708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_arg_name = 'fact_module'
    fact_module = 'fact_module'
    mod_args = ActionModule._get_module_args(fact_module, test_case_0)
    assert(mod_args[mod_arg_name] == fact_module)

# Generated at 2022-06-25 06:57:59.750852
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:05.069419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = ActionBase()
    actionModule_obj = ActionModule(d)
    assert actionModule_obj.name
    assert actionModule_obj._supports_check_mode == True
    assert actionModule_obj._supports_async == True
    assert actionModule_obj.connection
    assert actionModule_obj._play_context
    assert actionModule_obj._task
    assert actionModule_obj._loader
    assert actionModule_obj._templar
    assert actionModule_obj._shared_loader_obj
    assert actionModule_obj._error_on_missing_args == True


# Unit tests for _combine_task_result

# Generated at 2022-06-25 06:58:06.465644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.run()


# Generated at 2022-06-25 06:58:08.123718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:58:13.604393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = None
    task_vars = None

    # Setup object under test
    action_module = ActionModule(
        task=None,
        connection=None,
        _shell=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Invoke method
    result = action_module.run(
        tmp=tmp,
        task_vars=task_vars
    )


# Generated at 2022-06-25 06:58:15.292521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result_0 = ActionModule.run()
    assert result_0 != None


# Generated at 2022-06-25 06:58:16.177988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run()


# Generated at 2022-06-25 06:58:32.645390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equal(action_module_0.argument_spec, dict())
    assert_equal(action_module_0.default_args, dict())
    assert_equal(action_module_0.supports_check_mode, True)
    assert_equal(action_module_0.no_log, False)
    assert_equal(action_module_0.bypass_checks, True)
    assert_equal(action_module_0.deprecate_async, True)


# Generated at 2022-06-25 06:58:33.775401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:58:35.550773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None


# Generated at 2022-06-25 06:58:36.689799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)



# Generated at 2022-06-25 06:58:45.982858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = {
        '_connection': {
            '_shell': {
                'tmpdir': ''
            },
            '_load_name': ''
        },
        '_templar': {},
        '_task': {
            'args': {},
            'collections': {},
            'module_defaults': {}
        },
        '_shared_loader_obj': {
            'module_loader': {
                '_collections': {},
                'find_plugin_with_context': lambda fqcn: {
                    'resolved_fqcn': ''
                }
            }
        }
    }
    action_module_0 = ActionModule(**runner)
    action_module_0._supports_check_mode = True

# Generated at 2022-06-25 06:58:50.869869
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = ['ansible_facts_parallel', 'ansible_network_os', 'ansible_facts', 'ansible_facts_gathered']

    assert(action_module_0.run(tmp_0, task_vars_0) == 0)


# Generated at 2022-06-25 06:58:51.779239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # case 0
    test_case_0()

# Generated at 2022-06-25 06:58:55.495677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_1 = ActionModule()
        print("Test case 0: Successfully instantiated a class object ")
    except:
        print("Test case 0: Failed to instantiated a class object ")


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:58:58.747218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule()
    assert c is not None, "Failed to instantiate object of ActionModule"


# Generated at 2022-06-25 06:59:01.975140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = '/tmp'
    task_vars = {}
    retval = action_module_1.run(tmp, task_vars)
    assert retval == {}


# Generated at 2022-06-25 06:59:32.397778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" == ActionModule.__name__
    assert "ActionBase" == ActionModule.__bases__[0].__name__

    action_module_0 = ActionModule()
    assert False == action_module_0._supports_check_mode
    assert '_ansible_verbose_override' == action_module_0._result.keys()[0]
    assert '_ansible_verbose_override' == action_module_0._result_tmp.keys()[0]
    assert '_ansible_verbose_override' == action_module_0._result_rollback.keys()[0]
    assert '_ansible_verbose_override' == action_module_0._result_stdout.keys()[0]
    assert '_ansible_verbose_override' == action_

# Generated at 2022-06-25 06:59:36.341516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    action_module_0 = ActionModule()
    action_module_0._supports_check_mode = True
    result = action_module_0.run()

    # Assertion
    assert result == {'ansible_facts': {'_ansible_facts_gathered': True}, 'changed': False, '_ansible_verbose_override': True}

# Generated at 2022-06-25 06:59:37.460232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:39.148657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 06:59:44.285788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:59:49.360175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

"""def test_combine_task_result():
    action_module_0 = ActionModule()
    result = {}
    task_result = {}
    assert isinstance(action_module_0.__combine_task_result__(result, task_result), dict)"""


# Generated at 2022-06-25 06:59:55.913596
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule(connection=None,connection_loader=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    action_module_1_result = action_module_1.run(tmp=None,task_vars=None)
    assert action_module_1_result == {u'ansible_facts': {}, u'_ansible_verbose_override': True}

    # Test for a specific condition
    action_module_2 = ActionModule(connection=None,connection_loader=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    action_module_2.run(tmp=None,task_vars=None)

    #Test for the response of the method

# Generated at 2022-06-25 06:59:57.903695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nTesting constructor of class ActionModule")
    action_module = ActionModule()
    if isinstance(action_module, ActionModule) and action_module is not None:
        print("Test case 0 passed")
    else:
        print("Test case 0 failed")



# Generated at 2022-06-25 07:00:00.024438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:00:00.788344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:00:42.989056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run()

# Generated at 2022-06-25 07:00:48.285409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule().run

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:00:50.836618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(action_module_0, ActionModule), "Could not create instance of class ActionModule"

if __name__ == "__main__":
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:01:00.941325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()
    action_module_10 = ActionModule()
    action_module_11 = ActionModule()
    action_module_12 = ActionModule()
    action_module_13 = ActionModule()
    action_module_14 = ActionModule()
    action_module_15 = ActionModule()
    action_module_16 = ActionModule()
    action_module_17 = ActionModule()
   

# Generated at 2022-06-25 07:01:08.367525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()
  tmp = None
  task_vars = dict()
  task_vars['ansible_facts'] = dict()
  task_vars['ansible_facts']['network_os'] = 'ios'
  action_module_0._connection._load_name = 'network_cli'
  action_module_0._task.args = dict()
  result = action_module_0.run(tmp, task_vars)
  assert result['ansible_facts']['_ansible_facts_gathered'] == True

# Generated at 2022-06-25 07:01:12.294360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:01:14.284487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()

    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:01:15.438640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = test_case_0().run()
    assert result == 'None'

# Generated at 2022-06-25 07:01:17.474846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None

    # execute run method
    ret = action_module_0.run(tmp, task_vars)
    assert ret is None

# Generated at 2022-06-25 07:01:26.873023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.setup as ansible_plugins_action_setup
    import ansible.plugins.action.net_setup as ansible_plugins_action_net_setup
    import ansible.plugins.action.net_facts as ansible_plugins_action_net_setup
    import ansible.plugins.action.network as ansible_plugins_action_network
    import ansible.plugins.action.net_templates as ansible_plugins_action_net_templates
    import ansible.plugins.action.net_template as ansible_plugins_action_net_template

    action_module_0 = ActionModule()
    action_module_0._task = ansible_plugins_action_setup.ActionModule()
    action_module_0._task._task = ansible_plugins_action_net_setup.ActionModule()
    action

# Generated at 2022-06-25 07:02:11.692433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:02:18.885905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    prin_str = "action_module_0 = ActionModule()"
    print("Output from %s" % prin_str)
    action_module_0 = ActionModule()
    print_vars(vars(action_module_0), prin_str, "vars(action_module_0)")
    prin_str = "action_module_0._task"
    print("Output from %s" % prin_str)
    print_vars(vars(action_module_0._task), prin_str, "vars(action_module_0._task)")
    prin_str = "action_module_0._task.args"
    print("Output from %s" % prin_str)

# Generated at 2022-06-25 07:02:24.412757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert isinstance(result_0,dict)

# vim: ft=python:

# Generated at 2022-06-25 07:02:30.259188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._task.action == 'setup'
    assert action_module_0._task.blocks == []
    assert action_module_0._shared_loader_obj._exclude_access_info == False
    assert action_module_0._play_context.remote_addr == '127.0.0.1'
    assert action_module_0._play_context.password == None
    assert action_module_0._play_context.port == 22
    assert action_module_0._play_context.remote_user == 'root'
    assert action_module_0._play_context.connection == 'local'
    assert action_module_0._play_context.become == False
    assert action_module_0._play_context.become_method == 'sudo'
   

# Generated at 2022-06-25 07:02:32.352359
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()


# Generated at 2022-06-25 07:02:40.268027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # known_hosts is not used for ssh, however this
    # is only for unit testing, so we'll override it here.
    C.config.set('ssh_connection', 'ssh_args', '-F %s' % os.path.join(C.config.get('DEFAULT', 'remote_tmp'), 'ansible_ssh_config'), priority=100)
    C.config.set('ssh_connection', 'scp_if_ssh', 'True', priority=100)
    C.config.set('ssh_connection', 'persistent_command_timeout', 10, priority=100)
    C.config.set('ssh_connection', 'command_timeout', 10, priority=100)

# Generated at 2022-06-25 07:02:41.812311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    result_value_1 = action_module_1.run()
    assert (result_value_1 == None)

# Generated at 2022-06-25 07:02:43.683301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    tmp = None
    task_vars = {}
    action_module_0.run(tmp, task_vars)

    # TODO: add test cases

# Generated at 2022-06-25 07:02:45.042955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n\nunit test0: test_ActionModule()")
    test_case_0()



# Generated at 2022-06-25 07:02:48.085990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    modules = ['ansible.legacy.setup']

    tmp = None
    task_vars = ['ansible_facts_parallel', 'ansible_facts_gathered']
    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:04:29.783405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0



# Generated at 2022-06-25 07:04:30.979306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:04:37.692728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Test 1:
    # create a temporary directory and copy the module to be called by the task
    fact_module = 'ansible.legacy.setup'
    tmpdir = '/tmp/ansible-test-modules/'
    os.makedirs(tmpdir)
    module_file = tmpdir + fact_module
    plugin_path = C.get_config(C.p, C.DEFAULTS, 'action_plugins', 'ask_vault_pass').strip()
    plugin_path = plugin_path.split(',')[0].strip()
    source_file = os.path.join(os.path.dirname(plugin_path), 'setup', '__init__.py')
    os.symlink(source_file, module_file)

    # create a task with

# Generated at 2022-06-25 07:04:42.561870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert(action_module_1.__class__.__name__ == 'ActionModule')
    assert(action_module_1._supports_check_mode == True)


# Generated at 2022-06-25 07:04:46.649097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test is started')
    print('Test Case 0: Empty')
    ActionModule().run()
    print('Test Case 1: Empty String')
    ActionModule().run('')
    print('Test Case 2: Empty String + Empty String')
    ActionModule().run('', '')
    print('Test is finished')

if __name__ == "__main__":
    test_case_0()
    #test_ActionModule_run()

# Generated at 2022-06-25 07:04:55.774104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    #
    # The following test is only for INVALID parameters
    #

    #
    # The following test is only for VALID parameters
    #

    task_vars_0 = {}
    result_0 = dict()
    tmp_0 = None
    action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result_0 == action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:58.097260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert isinstance(a, ActionBase)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-25 07:05:00.789644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:05:01.541427
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:05:09.477583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object
    action_module_0 = ActionModule()
    # Create testcase dict
    testcase_dict = dict()
    # Assign values
    testcase_dict['tmp'] = None
    testcase_dict['task_vars'] = None
    # Get result
    result_0 = action_module_0.run(**testcase_dict)
    assert(result_0 == dict())
