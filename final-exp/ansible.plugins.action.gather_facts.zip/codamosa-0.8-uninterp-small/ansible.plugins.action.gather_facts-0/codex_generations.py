

# Generated at 2022-06-25 06:57:48.755319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path_0 = os.path.dirname(os.path.dirname(__file__))
    path_0 = os.path.join(path_0, 'plugins', 'action', 'setup.py')
    modules_0 = ['inventory_hostname', 'setup_module']
    result_0 = {'ansible_facts': {'_ansible_facts_gathered': True}}
    task_vars_0 = {'forks': 9, 'network_os': ''}
    result_0['ansible_facts']['_ansible_facts_gathered'] = True
    module_name_0 = 'setup_module'
    module_args_0 = {}
    wrap_async_0 = False
    module_name_1 = 'setup_module'
    module_args_1 = {}
    wrap_as

# Generated at 2022-06-25 06:57:57.663281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Uncomment the appropriate line to print a statement to the console
    #print 'a'
    #print 1

    # Initialize the variables
    tmp = None
    task_vars = None

    # Test the return value from the method
    return_value = ActionModule.run(None, None, None, None, None, None, None)

# Generated at 2022-06-25 06:57:59.671311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:58:01.750265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # var1 = dict()

    # TODO: create test case test_case_0
    # test_case_0
    # assert result == expected
    pass


# Generated at 2022-06-25 06:58:05.229642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    print(dir(action_module_0))
    tmp_0 = action_module_0.run()
    assert tmp_0 == {}

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:58:06.270557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:13.017649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'V', 'u'}
    dict_0 = {'n'}
    list_0 = []
    tuple_0 = [{'z', 'm'}]
    dict_1 = {'.'}
    dict_2 = {set_0: dict_0, list_0: tuple_0, dict_1: tuple_0}
    action_module_0 = ActionModule(dict_2, dict_0, tuple_0, set_0, dict_0, list_0)
    action_module_0.run(set_0, dict_0)


# Generated at 2022-06-25 06:58:21.224068
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:30.154609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    set_0 = {}
    tuple_0 = ()
    tuple_1 = ()
    list_0 = []
    set_1 = {}
    assert (ActionModule(dict_0, set_0, tuple_0, tuple_1, list_0, set_1) is None), "Return must be None"
    assert (ActionModule(dict_0, set_0, tuple_0, tuple_1, list_0, set_1) is None), "Return must be None"
    assert (ActionModule(dict_0, set_0, tuple_0, tuple_1, list_0, set_1) is None), "Return must be None"

# Generated at 2022-06-25 06:58:41.646138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'a': ('a', ('a', 'a')), 'l': ('a', ('a', 'a')), 'c': ('a', ('a', 'a'))}
    dict_1 = {'a': ('b', ('b', 'b')), 'l': ('b', ('b', 'b')), 'c': ('b', ('b', 'b'))}
    set_0 = {('a',), ('b',), ('c',), ('a',), ('b',), ('c',), ('a',), ('b',), ('c',), ('a',), ('b',), ('c',), ('a',), ('b',), ('c',), dict_0, dict_1}
    tuple_0 = ({'l': 'a'}, {'l': 'b'}, {'l': 'c'})


# Generated at 2022-06-25 06:58:59.847570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None

# Generated at 2022-06-25 06:59:09.833390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    assert not isinstance(action_module_0, object)

# Generated at 2022-06-25 06:59:20.965550
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    arg_0 = None
    arg_1 = var_0

# Generated at 2022-06-25 06:59:29.702035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)


# Generated at 2022-06-25 06:59:37.169333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 522.88
    str_0 = 'k%bFD~<p[Z.k_G:Ll'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '%s'
    str_2 = '~`r`Qr+x8'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_run()


# Generated at 2022-06-25 06:59:44.124934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    result = None

    # Act

# Generated at 2022-06-25 06:59:48.329439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except:
        print("Exception in try block")
        raise
    else:
        print("No exception in try block")
    finally:
        print("Finally block")
    assert var_0 in {True, False}


# Generated at 2022-06-25 06:59:55.370990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    float_1 = -2828.61

# Generated at 2022-06-25 07:00:05.158203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 0
    var_1 = 0
    var_3 = {'y' : 0, 'x' : 0, 'z' : 0, 'w' : 0}
    var_4 = {var_1 : 0, var_0 : 0, var_1 : 0, var_0 : 0}
    var_5 = '+refs/heads/%s:refs/remotes/%s/%s'
    var_6 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(var_0, var_1, var_3, var_4, var_5, var_6)
    return 0

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:00:14.389812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:00:44.610007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(0.0, 0.0, {}, {}, '+refs/heads/%s:refs/remotes/%s/%s', '<q|{8|dN{%=3Z peZw-e')
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict) == True
    assert var_0.get('failed_modules') == None
    assert len(var_0) == 4
    assert var_0.get('ansible_facts') == {'_ansible_facts_gathered': True}
    assert isinstance(var_0.get('ansible_facts'), dict) == True
    assert var_0.get('msg') == None
    assert var_0.get('skipped_modules') == None

# Generated at 2022-06-25 07:00:45.470200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid inputs
    return None

# Generated at 2022-06-25 07:00:51.564353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_run()

# Generated at 2022-06-25 07:01:01.086054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_run()



# Generated at 2022-06-25 07:01:10.189567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    action_module_0.run(float_0, dict_0)

# Generated at 2022-06-25 07:01:11.208813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == '6\n'

# Generated at 2022-06-25 07:01:13.109659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run")
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule()
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:01:22.853808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #obj = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    #assert(obj.a == float_0)

    #Test: test_case_0
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'

# Generated at 2022-06-25 07:01:32.541945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -24.86
    float_1 = float('-inf')
    dict_0 = {'y': -2.7, '{': -3.7, '*': -19.7, '_': -16.7}
    dict_1 = {'|': -5.5, 'x': -10.5, '7': -11.5, 'l': -8.5}
    str_0 = '>y7x}'
    str_1 = 'Kk/6'
    action_module_0 = ActionModule(float_0, float_1, dict_0, dict_1, str_0, str_1)
    print(action_module_0.run())

# Test for class ActionModule

# Generated at 2022-06-25 07:01:39.384329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    int_1 = None
    str_3 = '2407.N=g+$N<'
    str

# Generated at 2022-06-25 07:02:22.444389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a simple run
    test_case_0()
    # Test where we inject a variable into the hosts
    test_case_1()


# Generated at 2022-06-25 07:02:25.419552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 07:02:29.396490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0('{{ file_name }}')
    test_case_0('{{ file_name }}{{ file_name }}')
    test_case_0('')
    test_case_0('{{ file_name }}{{ file_name }}{{ file_name }}{{ file_name }}{{ file_name }}{{ file_name }}')

# Generated at 2022-06-25 07:02:31.409712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:02:40.573789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1897616.45
    str_0 = 'r$^]rh&L-#`Qi48(>?c'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '&R)M=W^/8}vj9sC(Zt+2'
    str_2 = '*NpFn1}%bZ;}55z|tYs{'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    assert action_module_0.module_name == str_2


# Generated at 2022-06-25 07:02:45.874729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_run()



# Generated at 2022-06-25 07:02:52.393479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1383.4444
    str_0 = '_|1(J5n[,h{u|rGp+'
    int_0 = None
    dict_0 = {str_0: int_0, str_0: float_0, str_0: int_0, str_0: float_0}
    list_0 = [str_0, int_0, float_0]
    str_1 = 'X:fj'
    str_2 = '5{(Pt@!|rp>'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)

    assert not action_module_0.run(list_0, int_0)

# Generated at 2022-06-25 07:02:57.946629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    assert action_module_0._task._parent._play.__class__.__name__ == 'Play'
   

# Generated at 2022-06-25 07:02:58.685269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:03:09.609314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '>VnH?F=,7gRf<c,>4Hw'
    str_2 = 'gX,}Q.T('
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    str_3 = '+refs/heads/%s:refs/remotes/%s/%s'

# Generated at 2022-06-25 07:04:50.297227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = boolean(None)
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    list_0 = [None]
    str_1 = '<q|{8|dN{%=3Z peZw-e'
    dict_0 = {str_0: module, str_0: list_0, str_0: str_1, str_0: list_0}
    action_module_0 = ActionModule(module, module, dict_0, dict_0, str_1, str_1)
    action_module_0.run()


# Generated at 2022-06-25 07:04:55.721127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.action.setup import ActionModule as ActionModuleClass

# Generated at 2022-06-25 07:04:59.640309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None
    action_module_0 = ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 07:05:03.168847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        x_0 = ActionModule()
    except:
        print("Exception caught")
        err_0 = str(sys.exc_info()[0])
        print(err_0)
        print(err_0)
        print(err_0)
        print(err_0)
        print(err_0)
        print(err_0)


# Generated at 2022-06-25 07:05:11.751476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2828.61
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_run()



# Generated at 2022-06-25 07:05:17.392401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3817.63
    str_0 = '~xaz)$YDh{z9Xc%|e'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '^mF(!mz0X!Y+\"hD{;0'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    var_0 = action_module_0.run()
    print(var_0)


# Generated at 2022-06-25 07:05:24.196454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -94.88
    int_0 = -7866
    float_1 = float_0
    str_0 = '@'
    str_1 = 'y>kP&+%c2[Cd(K9=l'
    str_2 = 'CHANGELOG.rst:CHANGELOG.rst'
    str_3 = 'R6#`H6%&|//zM'
    str_4 = 'lJ$[*)*Dqg'
    str_5 = 'H'
    str_6 = '~)?R`j^4h}4N'
    str_7 = '%s:%s'
    int_1 = None

# Generated at 2022-06-25 07:05:33.366391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -96.23
    str_0 = 'Ui4s*Z:(}zKD;0_&]YB'
    int_0 = None
    dict_0 = {str_0: float_0, str_0: int_0, str_0: float_0, str_0: int_0}
    str_1 = '+refs/heads/%s:refs/remotes/%s/%s'
    str_2 = '<q|{8|dN{%=3Z peZw-e'
    action_module_0 = ActionModule(float_0, float_0, dict_0, dict_0, str_1, str_2)
    str_3 = 'H'
    list_0 = [str_3]

# Generated at 2022-06-25 07:05:34.078779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:05:36.192499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Zero argument constructor
    action_module_0 = ActionModule()
    var_0 = action_run()