

# Generated at 2022-06-25 06:57:48.394634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b''
    bytes_1 = b'\x06\x18\x1c\x9ef\x9b`\xa0M#'
    str_0 = 'ansible_private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_1, str_0, float_0, tuple_0)

    tmp = None
    task_vars = None

    try:
        action_module_0.run(tmp, task_vars)
    except:
        pass

# Generated at 2022-06-25 06:57:48.970341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 06:57:59.388501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 809
    float_0 = 1.66
    tuple_0 = (float_0,)
    bytes_0 = b'\x9e'
    bytes_1 = b''
    str_0 = 's\x80\xda\x06\xd2\x9d\xca\xb9\x97\x82\x1d\x7e\xdb\x8d\x9e'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_1, str_0, int_0, tuple_0)

if __name__ == "__main__":
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:58:09.239069
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:58:16.188572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 558
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x1cS\xd8\x9f\x1c\xad4\x8c'
    bytes_1 = b'\xfc\x99\x9f\xcc\x98\x83\xf0\xe1u\x88M\xa0\x11\xfe\x9e\xfd\xb3\x95,\x8b1'
    str_0 = '0F\x8c\x87\x91\x0f\xae\xed\x10\x1c6'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_1, str_0, float_0, tuple_0)

# Generated at 2022-06-25 06:58:24.171688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 5009
    tuple_1 = (None,)

# Generated at 2022-06-25 06:58:32.322430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {
        'ansible_facts_parallel': None,
        'ansible_facts': {
            'network_os': 'ios',
            'network_os': 'ios'
        },
        'ansible_network_os': 'ios'
    }

    modules = [
        'ios_facts',
        'ansible.module_utils.network.ios.facts.ios_facts'
    ]
    parallel = True

    tmp = os.path.join(os.sep, 'usr', 'tmp')
    action_module_0 = ActionModule(tmp, task_vars)

    assert task_vars['network_os'] == 'ios'
    assert task_vars['ansible_facts']['network_os'] == 'ios'

# Generated at 2022-06-25 06:58:34.213218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    assert(False), "Test not implemented"


# Generated at 2022-06-25 06:58:43.876804
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:58:50.911109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b''
    bytes_1 = b'\x06\x18\x1c\x9ef\x9b`\xa0M#'
    str_0 = 'ansible_private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_1, str_0, float_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 06:59:09.125444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4791
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x1c\x1d\x14\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    var_0 = action_module_0.run(int_0)

# Generated at 2022-06-25 06:59:10.556171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert type(test_case_0()) == dict

# Generated at 2022-06-25 06:59:14.798484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2
    float_0 = 1.2
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    var_0 = action_module_0.run(float_0, int_0)

# Generated at 2022-06-25 06:59:17.076352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # payload =
    # int_0 =
    raise NotImplementedError()
    # var_0 = test_case_0()



# Generated at 2022-06-25 06:59:20.068429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:29.625042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    assert(type(action_module_0._shared_loader_obj) == type(None))
    assert(type(action_module_0._play_context) == type(None))
    assert(type(action_module_0._task) == type(None))
    assert(type(action_module_0._loader) == type(None))

# Generated at 2022-06-25 06:59:36.643757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 985669532
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'q\x10\x92]\x15\xa9\x11\x98\x82\xe8?\x91\x04\x97^'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    action_module_0.run(int_0)

# Generated at 2022-06-25 06:59:43.748054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '='
    str_1 = 'action_run'
    str_2 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    float_0 = float('0.0')
    float_1 = float('2.0')
    float_2 = float('0.0')
    float_3 = float('3.0')
    float_4 = float('6.0')
    float_5 = float('6.0')
    float_6 = float('6.0')
    float_7 = float('6.0')
    float_8 = float('6.0')
    float_9 = float('6.0')
    float_10 = float('0.0')
    float_11

# Generated at 2022-06-25 06:59:51.658810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    var_0 = action_run(int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:00:02.812688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil
    import pprint

    class AnsibleVars(object):
        def __init__(self, data):
            self.data = data

        def get(self, key, default=None):
            return self.data.get(key, default)

        def __contains__(self, key):
            return key in self.data


    class AnsibleTask(object):
        def __init__(self, data):
            self.args = data['args']
            self.module_defaults = data['module_defaults']
            self.collections = data['collections']


        def _build_vars(self, task_vars, module_defaults):
            return AnsibleVars(task_vars)


# Generated at 2022-06-25 07:00:30.845610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(('arg1', 'arg2'), 'seconds', 'ansible.legacy.plugins.action.setup.SetupModule', False,
                          'ansible.legacy.plugins.network.basic.Basic', True)
    assert module.run

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:00:32.936712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = set()
    arg_1 = None
    action_run(arg_0, arg_1)
    pass



# Generated at 2022-06-25 07:00:34.084574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:00:39.499704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_1 = None
    action_module_0 = ActionModule()
    result_0 = action_module_0.run(tmp_0, task_vars_1)
    assert result_0 == None


# Generated at 2022-06-25 07:00:45.926274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    assert len(tuple_0) == len(tuple_0)
    assert len(bytes_0) == len(bytes_0)
    assert len(str_0) == len(str_0)
    assert len(action_module_0._task) == len(tuple_0)

# Generated at 2022-06-25 07:00:50.633375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        int_0 = 3243
        float_0 = None
        tuple_0 = (float_0,)
        bytes_0 = b'\x06\x18\x1cf`\xa0M#'
        str_0 = 'ansible`private_key_file'
        action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
        var_0 = action_run(int_0)
    except:
        pass

# Generated at 2022-06-25 07:00:59.589969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (None,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    bytes_1 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    float_0 = None
    tuple_1 = (float_0,)
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_1, str_0, float_0, tuple_1)
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 07:01:09.978861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '\x93\xb2\x03\x11'
    var_1 = "tuple"
    var_2 = b'\x06\x18\x1cf`\xa0M#'
    var_3 = b'\x06\x18\x1cf`\xa0M#'
    var_4 = 'ansible`private_key_file'
    var_5 = 727.0
    var_6 = (var_5,)
    action_module_0 = ActionModule(var_6, var_2, var_3, var_4, var_5, var_6)
    var_7 = action_run(var_0)
    var_8 = "ActionModule"
    var_9 = "module"
    var_10 = "\x9a\x7a"

# Generated at 2022-06-25 07:01:15.674790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    var_0 = action_module_0.run(None, None)
    assert not (var_0['ansible_facts']['_ansible_facts_gathered'])
    assert not (var_0['failed'])
    assert not (var_0['skipped'])
    assert var_0['msg'] == "The following modules were skipped: smart\n"

# Generated at 2022-06-25 07:01:25.860628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    assert action_module_0.task is tuple_0
    assert action_module_0.connection is bytes_0
    assert action_module_0.play_context is bytes_0
    assert action_module_0.loader is str_0
    assert action_module_0.templar is float_0
    assert action_module_0.shared_loader_obj is tuple_0


# Unit test

# Generated at 2022-06-25 07:02:14.223599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generates tests for constructor of class ActionModule

# Generated at 2022-06-25 07:02:22.148878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (None,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible_inventory_directory'
    float_0 = 3243
    bool_0 = bool_0
    variable_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, bool_0)
    variable_0._task.module_defaults = {'ANSIBLE_NET_AUTH_PASS'}
    variable_0._task.module_defaults = {'ANSIBLE_BOOTSTRAP_SERVICE_NAME'}
    variable_0._task.module_defaults = {'ANSIBLE_NET_AUTH_PASS'}

# Generated at 2022-06-25 07:02:26.904771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError: ', e.args)
        print('Traceback: ' + str(e.__traceback__))
    except Exception as e:
        print('Exception: ' + str(e))
        print('Traceback: ' + str(e.__traceback__))

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:02:29.479434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None

    # Invoke method
    result = ActionModule.run(tmp_0, task_vars_0)

    assert result is None


# Generated at 2022-06-25 07:02:40.044871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = 7784
    float_1 = -35.908070
    tuple_1 = (int_1, float_1)
    bytes_1 = b'\x75\xb5\x80S\x0e\xa4\x85\xf1\x13\x81\x05\x1b\xac\x12<\x8a\x8d\xed\x94i\x02\xa1\x0f\x97'

# Generated at 2022-06-25 07:02:41.657490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create our module object and call run method
    action_module_inst = ActionModule()
    action_module_inst.run()

# Generated at 2022-06-25 07:02:43.743914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, tmp, tmp, tmp, tmp, tmp)
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:02:48.756808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:02:54.665817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data_0 = {
        "connection": "local",
        "command": "ansible-playbook",
        "argv": ["ansible-playbook", "--version"]
    }
    data_1 = [
        "ansible-playbook",
        "--version"
    ]
    with patch("ansible.utils.display.Display.display", return_value=None) as display :
        with patch("ansible.executor.task_queue_manager.TaskQueueManager._initialize_processes") as initialized :
            test_obj = ActionModule(data_0, data_1)
            test_obj.run()
            display.assert_called()
            initialized.assert_called()



# Generated at 2022-06-25 07:03:01.474146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  return

if __name__ == '__main__':
    # Unit tests for this file
    print ('\n=== Running unit tests for ansible.playbook.action.setup.py ===')
    import doctest
    doctest.testmod()

    # Run test_case_0() to test method run with the following arguments: None, None
    print ('\nTesting run(None, None)\n')
    test_case_0()

# Generated at 2022-06-25 07:04:55.049699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    int_1 = 814
    var_0 = get_action_args_with_defaults(int_1, float_0, float_0, float_0, float_0)
    float_1 = None
    var_1 = action_run(int_0)

# Generated at 2022-06-25 07:05:04.824263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible = 'ansible'
    ansible_facts = 'ansible_facts'
    ansible_facts_gathered = '_ansible_facts_gathered'
    ansible_facts_parallel = 'ansible_facts_parallel'
    ansible_job_id = 'ansible_job_id'
    ansible_network_os = 'ansible_network_os'
    ansible_verbose_override = '_ansible_verbose_override'
    async_dir = '_async_dir'
    async_status = 'ansible.legacy.async_status'
    block = 'block'
    connection_facts_modules = 'CONNECTION_FACTS_MODULES'
    deprecations = 'deprecations'
    display_warning = 'display_warning'
   

# Generated at 2022-06-25 07:05:11.510935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3243
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = 'ansible`private_key_file'
    module = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    tmp = None
    task_vars = None
    module.run(tmp, task_vars)

if __name__ == '__main__':
    try:
        test_ActionModule()
    except:
        print("Something went wrong!")
    else:
        print("Success!")

# Generated at 2022-06-25 07:05:12.166073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == True

# Generated at 2022-06-25 07:05:15.985247
# Unit test for constructor of class ActionModule
def test_ActionModule():

# Verify that calling ActionModule constructor returns instance of ActionModule class
    assert isinstance(ActionModule(), ActionModule)

# Verify that calling ActionModule constructor returns instance of ActionModule class with expected parameters
    assert isinstance(ActionModule(None, None, None, None, None, None), ActionModule)

# Verify that calling ActionModule constructor returns instance of ActionModule class with expected parameters
    assert isinstance(ActionModule(None, None, None, None, None, None), ActionModule)


# Generated at 2022-06-25 07:05:23.339290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 896
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x06\x18\x1cf`\xa0M#'
    str_0 = '0.1'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
   

# Generated at 2022-06-25 07:05:28.825204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # Init an instance of ActionModule with a mangled tmp and task_vars
    action_module_0 = ActionModule(tmp, task_vars)
    # Verify the result
    assert not action_module_0.run()

# Generated at 2022-06-25 07:05:33.697045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\xa3\xee\xb9X'
    str_0 = 'D6\xda\x95\x17\x14'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    var_0 = action_module_0.run(int_0)
    assert var_0 == None

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:05:35.662472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equal(isinstance(ActionModule, object), True)


# Generated at 2022-06-25 07:05:43.854124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 833254
    float_0 = None
    tuple_0 = (float_0,)
    bytes_0 = b'\x17\x0c|^\x1d\x04\xda\x8b\x087\x84\xbd'
    str_0 = 'ansible`private_key_file'
    action_module_0 = ActionModule(tuple_0, bytes_0, bytes_0, str_0, float_0, tuple_0)
    int_1 = 26000
    dict_0 = {}
    dict_0['ansible_facts'] = action_module_0.run(int_1, dict_0)
    return dict_0

if __name__ == "__main__":
    action_run()
    test_case_0()