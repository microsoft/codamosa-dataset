

# Generated at 2022-06-25 06:57:46.864669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    new_obj = ActionModule(True, b'\xaf\xb8', True, b'\xf9\x9a\xbb', '<L\x19\xe3S\xb0\x05', True)
    # Send invalid parameter value (mydict) for tmp
    mydict = {}
    try:
        test_result = new_obj.run(mydict, mydict)
    except TypeError:
        assert True == True


# Generated at 2022-06-25 06:57:56.683368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xbe\xf3\xd1\xa4\x1e\x897\xe1\xeb\x07'
    str_0 = '7`cL(K8"ky4s%7^T|H(W'
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)
    str_0 = '\\&<\x29'
    task_vars_0 = {str_0: bytes_0}

    result = action_module_0.run(None, task_vars_0)


# Generated at 2022-06-25 06:58:00.785411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    task_vars = {}
    tmp = None
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:58:03.937130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print('Test failed')
    else:
        print('Test passed')


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:58:10.524779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test: run
    # initialization
    bool_0 = True
    bytes_0 = b'\xbe\xf3\xd1\xa4\x1e\x897\xe1\xeb\x07'
    str_0 = '7`cL(K8"ky4s%7^T|H(W'
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)

    # method run of ActionModule
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 06:58:19.337020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xbe\xf3\xd1\xa4\x1e\x897\xe1\xeb\x07'
    str_0 = '7`cL(K8"ky4s%7^T|H(W'
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)
    bool_1 = True
    dict_0 = dict(a=1, b=2)
    dict_1 = dict(a=1, b=2)
    action_module_0.action_vars = dict_0
    action_module_0.task_vars = dict_1
    dict_2 = dict(a=1, b=2)

# Generated at 2022-06-25 06:58:27.719119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\xbe\xf3\xd1\xa4\x1e\x897\xe1\xeb\x07'
    str_0 = '7`cL(K8"ky4s%7^T|H(W'
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)
    action_module_1 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)

if __name__ == '__main__':
    test_case_0()
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 06:58:28.539919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:30.012011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:58:41.610857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\xbe\xf3\xd1\xa4\x1e\x897\xe1\xeb\x07'
    str_0 = '7`cL(K8"ky4s%7^T|H(W'
    action_module_0 = ActionModule(bool_0, bytes_0, bool_0, bytes_0, str_0, bool_0)
    tmp_0 = None
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result['ansible_facts']['_ansible_facts_gathered'] == True
    assert result['msg'] == 'The following modules were skipped: ansible.legacy.setup\n'

# Generated at 2022-06-25 06:59:00.513339
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up mock test data
    tmpValue = 'tmpValue'
    task_varsValue = 'task_varsValue'
    resultValue = {
        '_ansible_verbose_override': True,
        'ansible_facts': {'_ansible_facts_gathered': True},
        'ansible_facts_parallel': False,
        'ansible_facts_parallel_value_was_set': False,
        'failed': True,
        'failed_modules': {},
        'msg': 'msgValue',
        'skipped': True,
        'skipped_modules': {},
    }
    modulesValue = 'modulesValue'
    parallelValue = False
    parallel_value_was_setValue = False
    displayValue = 'displayValue'
    vvvvValue = 'vvvvValue'

# Generated at 2022-06-25 06:59:02.970646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_2 = tmp
    var_3 = task_vars
    str_0 = var_1.run(var_2, var_3)
    assert str_0 == 0
    pass


# Generated at 2022-06-25 06:59:05.808156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    assert ActionModule.run(tmp, task_vars) == 'Test passed'

test_case_0()

# Generated at 2022-06-25 06:59:17.172385
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_0 = mock.MagicMock()


# Generated at 2022-06-25 06:59:28.596412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'ansible_facts_parallel': 'True', 'ansible_facts': {'network_os': 'ansible.netcommon.NetworkOS', '_ansible_facts_gathered': 'True'}}
    tmp = '/var/folders/7x/yb9j0l8d39v_t7wnys21n0kw0000gn/T'
    modules = ['smart']
    connection_map = {'ansible.netcommon.NetworkOS': 'ansible.legacy.setup'}
    ansible_facts = {'network_os': 'ansible.netcommon.NetworkOS'}
    def _get_module_args(self, fact_module, task_vars):
        mod_args = self._task.args.copy()

# Generated at 2022-06-25 06:59:31.389659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing test_ActionModule()...")
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:59:37.679220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = {}
    test = ActionModule()
    result = test.run(tmp_0, task_vars_0)
    if result == None :
        test_case_0()
    else :
        print('Failed')

# Run test case
test_ActionModule_run()

# Generated at 2022-06-25 06:59:39.073141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aModule = ActionModule()
    aModule.run()

# Example of invoking run method
test_ActionModule_run()

# Generated at 2022-06-25 06:59:40.429027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:59:44.581419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(None, None)
    var_1 = var_0.run()
    assert var_1.get('_ansible_parsed') == True

    # Test method with args
    args_0 = {'module_name': 'ansible.legacy.network.ping'}
    var_0 = ActionModule(None, None)
    var_1 = var_0.run(**args_0)
    assert var_1.get('_ansible_parsed') == True

# Generated at 2022-06-25 07:00:05.039996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = {'ansible_verbose': False, 'ansible_version': {'full': '2.9.14', 'major': 2, 'minor': 9, 'revision': 14, 'string': '2.9.14'}, 'ansible_facts': {'_ansible_facts_gathered': True}}
    tmp_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:00:14.938572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    FACTS_MODULES = ['ansible.netcommon.network_facts', 'ansible.netcommon.network_template']
    default_config_file = 'ansible.cfg'
    config_paths = [os.path.dirname(default_config_file)]
    # config_paths = str(os.path.dirname(default_config_file))

# Generated at 2022-06-25 07:00:15.913040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Generated at 2022-06-25 07:00:18.045291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        raise



# Generated at 2022-06-25 07:00:25.736256
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:00:34.700878
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()
    ansible_variable_1 = {'network_os': 'ios'}
    ansible_variable_2 = {'ansible_network_os': 'ios'}
    ansible_variable_3 = {'ansible_facts': {'network_os': 'ios'}}

    # No value for ansible_network_os is provided
    # Fact modules with the name 'smart' is provided
    # The method _execute_module of class ActionModule is called
    # The method _get_module_args of class ActionModule is called
    # The method get_action_args_with_defaults of module module_common of class ModuleCommon
    # is called
    action_module_1.run(task_vars=ansible_variable_1)

    # The value ios for ansible_network

# Generated at 2022-06-25 07:00:35.975071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule() is not None)


# Generated at 2022-06-25 07:00:40.018850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None, "Class instance was not constructed"


# Generated at 2022-06-25 07:00:44.139431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0 is not None), "Error: Failed to construct object ActionModule()"

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:00:49.904038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the class ActionModule with unittest.TestCase()
    test_case_0()

# Collect all test cases in this class
test_cases_ActionModule = [
    "test_ActionModule",
]

# Construct the test suite from test_cases_ActionModule

# Generated at 2022-06-25 07:01:12.775338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:01:15.641845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None

    try:
        action_module.run(tmp, task_vars)
    except Exception as err:
        print("Test case failed: %s" % err)


# Generated at 2022-06-25 07:01:18.336714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    result = action_module_0.run(None, task_vars_0)
    print(result)

if __name__ == '__main__':
    #test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:01:22.244161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
    

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:01:23.891012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    action_module_0 = obj_0.run()

# Generated at 2022-06-25 07:01:32.874194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = {
        'ansible_network_os': 'junos',
        'ansible_facts': {'ansible_network_os': 'junos'},
        'ansible_facts_parallel': None
    }

# Generated at 2022-06-25 07:01:33.633311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run the constructor
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:01:36.731342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert C.config.get_config_value('FACTS_MODULES') == ['smart']
    assert C.config.get_config_value('CONNECTION_FACTS_MODULES') == {'network_cli': 'ansible.legacy.setup'}
    assert not C.config.get_config_value('FACTS_CACHE_ENABLED')
    assert not C.config.get_config_value('FACTS_CACHE_PLUGIN')
    assert not C.config.get_config_value('FACTS_CACHE_TIMEOUT')

# Generated at 2022-06-25 07:01:40.921595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode == True

# Generated at 2022-06-25 07:01:43.503920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = tempfile.TemporaryDirectory()
    task_vars = []
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:02:10.565365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:02:13.550109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        ActionModule.run(ActionModule, str_1)
    except:
        assert False


# Generated at 2022-06-25 07:02:15.189212
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #TODO: Verify that the run method of class ActionModule is called with the correct arguments
    assert False



# Generated at 2022-06-25 07:02:21.853728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)


# Generated at 2022-06-25 07:02:29.165664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 07:02:32.666243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except SystemExit:
        raise Exception('Unit test failed, exiting.\n')


# Generated at 2022-06-25 07:02:41.234871
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp = None
    task_vars = None

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = am.run(tmp, task_vars)

    assert res["ansible_facts"]["_ansible_facts_gathered"] == True
    assert res["failed"] == False
    assert res["_ansible_verbose_override"] == True
    assert res["ansible_facts"] == {}
    assert res["msg"] == "The following modules were skipped: ansible.setup_module_smart, ansible.legacy.setup\n"
    assert res["failed_modules"] == {}
    assert res["skipped"] == True
    assert res["skipped_modules"] == {}

# Generated at 2022-06-25 07:02:44.977360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '*]%j@'
    list_0 = None
    list_1 = [-36, str_0, str_0, list_0]
    int_0 = -62
    int_1 = -857
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 07:02:52.740930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x00\xda\xf3\xf6Q\xb6\xb5\xbb\xdcu\x12\x01\xdd~\x1f\xa5\x86_\xbc'
    str_0 = 'y-oX\x88\t)2\t\xe1\xc7f\x1b'
    int_0 = -796
    list_0 = []
    list_1 = [bytes_0, bytes_0, int_0, int_0]
    int_1 = 606
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    var_0 = type(action_module_0)

# Generated at 2022-06-25 07:02:56.532255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule with the following arguments: ansible_connection, task_vars, load_name, connection_load, display, loader
    ansible_connection_0 = None
    task_vars_0 = None
    load_name_0 = 'VR!}z'
    connection_load_0 = 'JwF0='
    display_0 = 'Se-_'
    loader_0 = None
    action_module_0 = ActionModule(ansible_connection_0, task_vars_0, load_name_0, connection_load_0, display_0, loader_0)
    # Assert that the _supports_check_mode of ActionModule is equal to True
    assert action_module_0._supports_check_mode == True



# Generated at 2022-06-25 07:03:52.791271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:03:58.455259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    action_module_0.run(bytes_0)


# Generated at 2022-06-25 07:04:08.182259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)

# Generated at 2022-06-25 07:04:11.076296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, list_0, int_1, int_1, str_0, list_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:04:16.959361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'8W\xc4\x1f\x1b4\xd8\xb4\xe4\xe0\x10\x9f\x1f\xc6\x86\x7f\x89\xfa'
    int_0 = 783
    str_0 = '=QA\x9f\x15\xac\x1b\x96\x1c\r\xbc\xfc5'
    int_1 = -2
    list_0 = None
    list_1 = [int_0, int_1, str_0]

# Generated at 2022-06-25 07:04:22.363899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    bytes_1 = b'\xd7\x8e\x99\x92\xe6\x9f\x8e\xaf'
    str_0 = '6*5@Q6h>qF;\\'
    str_1 = 'Gt\xea\xe1\xec\xe8[\xa3\xf7f\xdf\x85\x10\x90\xd7\t\x0ed\x05\x02\x14\x92\xde_'

# Generated at 2022-06-25 07:04:29.084258
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
  str_0 = '6*5@Q6h>qF;\\'
  int_0 = -789
  list_0 = None
  list_1 = [int_0, str_0, str_0, list_0]
  int_1 = -638
  # Testcase 0
  action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)

  test_case_0()

# Generated at 2022-06-25 07:04:29.635723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_0 = ActionModule()

# Generated at 2022-06-25 07:04:34.413665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    var_0 = action_run(bytes_0)



# Generated at 2022-06-25 07:04:44.698153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    var_0 = action_module_0.run(bytes_0)


# Assign result of action_run to var_0

# Generated at 2022-06-25 07:06:59.067301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_1 = '6*5@Q6h>qF;\\'
    int_2 = -789
    list_2 = None
    list_3 = [int_2, str_1, str_1, list_2]
    int_3 = -638
    action_module_1 = ActionModule(str_1, list_3, int_3, int_2, str_1, list_2)
    action_run(bytes_1)


# Generated at 2022-06-25 07:07:05.437533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    The method run() of class ActionModule represents a test case for the
    following function call:

        ActionModule.run(str_0, list_1, int_1, int_0, str_0, list_0)

    :param str_0:
    :param list_1:
    :param int_1:
    :param int_0:
    :param str_0:
    :param list_0:
    :return:
    """
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789


# Generated at 2022-06-25 07:07:14.533564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.setup import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_executor import TaskExecutor
    builder = TaskResult()
    task = Task()
    play_context = PlayContext()
    task_include = TaskInclude()
    task_executor = TaskExecutor()
    task.action = 'setup'
    task_executor.task = task
    task_executor.loader = task.loader
    task_executor._initialize_module_args(task_vars, task_args)

# Generated at 2022-06-25 07:07:20.389711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x94\x1f\x8b\xe2\xd1\xb3\xe3\xdd\xec\r\xff_V\xe6\x1b|L\xd6\xaa'
    str_0 = '6*5@Q6h>qF;\\'
    int_0 = -789
    list_0 = None
    list_1 = [int_0, str_0, str_0, list_0]
    int_1 = -638
    action_module_0 = ActionModule(str_0, list_1, int_1, int_0, str_0, list_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:07:27.217224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0()

    # test_case_1()

    test_case_0()

    # test_case_2()

    # test_case_3()

    # test_case_4()

    # test_case_5()

    # test_case_6()

    # test_case_7()

    # test_case_8()

    # test_case_9()

    # test_case_10()

    # test_case_11()


if __name__ == '__main__':
    test_ActionModule()