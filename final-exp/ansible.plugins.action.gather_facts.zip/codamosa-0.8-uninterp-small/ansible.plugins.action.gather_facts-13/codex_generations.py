

# Generated at 2022-06-25 06:57:38.509321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:57:47.070687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'ansible_facts': {}}
    str_0 = ''
    str_1 = 'D'
    bytes_0 = b'\xad\xa0\xdc\x0f\xef\xb5\xd9i0'
    float_0 = -74.7
    bool_0 = True
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, float_0, bool_0)
    action_module_0.run(bytes_0)


# Generated at 2022-06-25 06:57:54.363005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(None, None, None, None, None, None)
    action_module_2._get_module_args('giocpjh', 'ihtlj')
    action_module_2._execute_module()
    action_module_2._execute_module('dmrz', 'ejzvm', 'aorblb', 'xnxiq', 'swffaw')
    action_module_2._remove_tmp_path('vbch')

# Generated at 2022-06-25 06:58:00.130153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    dict_0 = {str_0: str_0}
    bytes_0 = b'\x9d\xda.\x88{'
    float_0 = -83.45
    bool_0 = False
    action_module_0 = ActionModule(dict_0, str_0, str_0, bytes_0, float_0, bool_0)


# Generated at 2022-06-25 06:58:09.868357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    dict_0 = {str_0: str_0}
    bytes_0 = b'\xce\xfa\x9d'
    float_0 = -711.6055
    bool_0 = True
    action_module_0 = ActionModule(dict_0, str_0, str_0, bytes_0, float_0, bool_0)
    tmp_0 = None
    task_vars_0 = dict_0
    action_module_0.run(tmp_0, task_vars_0)
    str_1 = None
    dict_1 = {str_1: str_1}
    bytes_1 = b'\xb9\x0f\x9e\x13\x91\xdc\xde\xbb'
    float_1 = -8

# Generated at 2022-06-25 06:58:12.904642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(dict_0, str_0, str_0, str_0, 0.0, False)
    action_module_0.run()

# Generated at 2022-06-25 06:58:21.128118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = b'\x9d\xea\x07\xc8\x08\xa2\xfa\x84\xf8\xfc\x9d\xfc'
    str_0 = None
    dict_0 = {str_0: str_0}
    bytes_0 = b'\x99\xc2\x82\xee\x89\xca\xa2\xb8\xe9\x09\xdd\x93\x8b\xae\xad\xba\xe7'
    float_0 = -427.52258
    bool_0 = True
    action_module_0 = ActionModule(dict_0, str_0, str_0, bytes_0, float_0, bool_0)

# Generated at 2022-06-25 06:58:26.657613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2775
    str_0 = 't\x1c'

    assert str_0 != bytes('_ansible_no_log', 'utf-8'), "str_0 != str(bytes('_ansible_no_log', 'utf-8'))"
    dict_0 = {'action': str_0, 'poll': int_0}
    dict_1 = {str_0: str_0}
    bytes_0 = b'\xef\xfc\xdbP'
    float_0 = 0.46243575783706243
    action_module_0 = ActionModule(dict_0, bytes_0, dict_1, int_0, float_0, bytes_0)

    result = action_module_0._combine_task_result(dict_1, dict_0)

   

# Generated at 2022-06-25 06:58:28.120573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test for method run of class ActionModule')

    test_case_0()

# Generated at 2022-06-25 06:58:29.644542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:58:41.201629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:41.743360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:47.448417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = test_case_0()

# End of test for method run of class ActionModule

# Standard boilerplate to call the main() function.
if __name__ == '__main__':
    test_ActionModule_run()

# End of test_ActionModule.py

# Generated at 2022-06-25 06:58:52.116074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = "ansible.legacy.actions.setup"
    
    var_2 = "ansible.module_utils.facts"
    cls_0 = get_action_args_with_defaults
    var_3 = cls_0(var_1, var_2)
    print(var_3)

test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:58:54.476256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp_0 = None
        var_0 = ActionModule.run(tmp_0)
        test_case_0()
    except Exception:
        raise


# Generated at 2022-06-25 06:58:58.559389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()
    test_case_0()


# Generated at 2022-06-25 06:59:01.476079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test')
    # tmp = None
    # task_vars = None
    # obj = ActionModule(ActionBase, tmp, task_vars)
    # test_case_0(obj)


# Generated at 2022-06-25 06:59:04.017046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:59:07.523245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()
    var_0.run(tmp=60406012557, task_vars=7280424433)
    var_0.run(task_vars=7280424433)


# Generated at 2022-06-25 06:59:09.014209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    test_case_0()


# Generated at 2022-06-25 06:59:22.159741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(isinstance(action_module, ActionBase))

# Generated at 2022-06-25 06:59:24.687518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method of class ActionModule
    """
    try:

        action_module_0 = ActionModule()
        action_module_0.run()

    except Exception:
        assert False


# Generated at 2022-06-25 06:59:34.988884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    FACT_MODULES_A = ['ansible.builtin.uname', 'ansible.builtin.virtualization', 'ansible.builtin.command_uname']

    task_args_0 = {'async': (1, None), 'parallel': (0, None), 'setup_ansible_module_args': (1, None), 'setup_ansible_module_name': (1, None)}


# Generated at 2022-06-25 06:59:36.312110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(getattr(ActionModule, '__init__', None))

# Generated at 2022-06-25 06:59:38.594432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    ret_value_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:59:39.688301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:40.744503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:43.976435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print("test_ActionModule")
    assert action_module != None



# Generated at 2022-06-25 06:59:46.456517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    action_module_obj.run()

# Generated at 2022-06-25 06:59:47.854551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None


# Generated at 2022-06-25 07:00:15.869759
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    try:
        assert isinstance(action_module_0, ActionModule)
    except AssertionError as e:
        print(e)

    action_module_1 = ActionModule()
    try:
        assert isinstance(action_module_1, ActionModule)
    except AssertionError as e:
        print(e)

    action_module_2 = ActionModule()
    try:
        assert isinstance(action_module_2, ActionModule)
    except AssertionError as e:
        print(e)

    action_module_3 = ActionModule()
    try:
        assert isinstance(action_module_3, ActionModule)
    except AssertionError as e:
        print(e)

    action_module_4 = ActionModule()

# Generated at 2022-06-25 07:00:17.344719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:00:22.116847
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    assert type(action_module_0.run()) == dict, 'Return value is not of the expected type'
    assert type(action_module_0.run(tmp=[])) == dict, 'Return value is not of the expected type'
    assert type(action_module_0.run(tmp=[], task_vars=[])) == dict, 'Return value is not of the expected type'


# Generated at 2022-06-25 07:00:24.870232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Run unit test for method run of class ActionModule")
    action_module_0 = ActionModule()
    action_module_0.run()
#
# Run unit test
#
print("Run unit test")
test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:00:27.240422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    if action_module._supports_check_mode == True:
        print("Unit test for constructor of class ActionModule: Success!")
    else:
        print("Unit test for constructor of class ActionModule: Failed!")


# Generated at 2022-06-25 07:00:29.354677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:00:34.550861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.environ["ANSIBLE_MODULE_ARGS"] = "{\"module_name\": \"\", \"module_args\": \"\"}"
    action_module_1 = ActionModule()
    action_module_1.run()
    os.environ["ANSIBLE_MODULE_ARGS"] = "{\"module_name\": \"\", \"module_args\": \"\"}"
    action_module_2 = ActionModule()
    action_module_2.run()
    
    

# Generated at 2022-06-25 07:00:35.788260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:00:39.062922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:00:41.117538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True


# Generated at 2022-06-25 07:01:08.521327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  list_0 = [{'a': 'b', 'b': 'c'}, "a string", 'another string']
  dict_0 = {'a': 'b'}

  action_module = ActionModule(list_0, True, dict_0, "a string", "another string", False)
  assert action_module.run(None, None)[0][0] == 'b'

# Generated at 2022-06-25 07:01:15.852636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Configure template data
    list_0 = [None, 'zR  ', False]
    bool_0 = True
    dict_0 = {bytes: list}
    str_0 = 'zR  '
    str_1 = 'ansible.legacy.setup'
    # Instantiate template data
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)


# Generated at 2022-06-25 07:01:18.152591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    action_module_1 = ActionModule()
    action_module_1.run()
    assert action_module_1.return_value == 0


# Generated at 2022-06-25 07:01:27.165492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x91*'
    list_0 = [bytes_0, bytes_0, bytes_0]
    bool_0 = True
    dict_0 = {bytes_0: list_0}
    str_0 = '\xa3\xe1'
    str_1 = '^@\xfc'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    tmp_0 = None
    task_vars_0 = None
    res_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:01:33.996483
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# before construct an instance of class
	# do something
	
	# create an instance of class ActionModule
	# var_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
	# then do something
	
	# test the value of var_0
	# assert var_0
	pass


# Generated at 2022-06-25 07:01:34.756677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:01:40.247773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:01:44.597604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert action_module_0.result == {}


# Generated at 2022-06-25 07:01:53.443455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [bytes_0, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    result = {}
    result['ansible_facts'] = {}
    with patch.object(ActionBase, 'run', return_value=result):
        with patch.object(ActionBase, '_execute_module', return_value={}):
            action_module_0.run(bytes_0)

# Generated at 2022-06-25 07:02:02.039544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert action_module_0._supports_check_mode == True


# Generated at 2022-06-25 07:02:54.942201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'ansible_network_os': 'junos'}
    bytes_0 = b'\xa5r[\x09'
    list_0 = [bytes_0]
    bool_0 = True
    bytes_1 = b'\xb6\x12\x9f\xd9'
    bytes_2 = b'\x0e\x81\x8a\xec'
    bytes_3 = b'\x1b\xc3\x90\x11'
    bytes_4 = b'\xb2\x93\x9a\x06'
    bytes_5 = b'\x0b\x7f\xb2Q'
    bytes_6 = b'\x03\xe4\xf4\xcd'

# Generated at 2022-06-25 07:03:00.286719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars = {}
    action_run(action_module_0, None, task_vars)
    assert action_module_0._supports_check_mode == True
    assert action_module_0.result['ansible_facts'] == {}
    assert action_module_0.modules == ['ansible.legacy.setup']

if __name__ == '__main__':
    test_case_0()
    #test_ActionModule_run()

# Generated at 2022-06-25 07:03:11.050713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)
    assert vars(action_module_0).get('_supports_check_mode') == True
   

# Generated at 2022-06-25 07:03:16.898510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    test_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert(isinstance(test_0, ActionModule))
    assert(not isinstance(test_0, list))
    assert(not isinstance(test_0, dict))

# Generated at 2022-06-25 07:03:24.518403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)
    assert var_0 is None
    tmp_0 = None
    task_vars_0 = None


# Generated at 2022-06-25 07:03:31.424281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)
    assert var_0 == None, 'Failed at test_ActionModule_run()'


# Generated at 2022-06-25 07:03:38.842852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert action_module_0._display == 'zR  '
    assert action_module_0._connection == '\x87V\xdc\x9b'

# Generated at 2022-06-25 07:03:49.557892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("Testing run")
  task_name = "Gather Facts"
  task_vars = {"foo": "baz", "task_name": task_name}
  host_name = "test_host"
  tmp_path = "/tmp/ansible"
  module_name = None
  module_args = {"filter": "facter", "gather_subset": "!all"}
  delegate_to = None
  action = "gather_facts"
  only_if = None
  async_val = None
  poll = 0
  become_user = None
  become_method = None
  become_info = None
  check_mode = False
  create_remote_tmp = None
  remote_tmp = "/path/to/remote/tmp"
  use_persistent_files = False

# Generated at 2022-06-25 07:03:57.197707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [1, 2, 3]
    bool_0 = True
    dict_0 = {}
    str_0 = str()
    str_1 = str()
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)
# def test_ActionModule_run():

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:05.999470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x93@\x1d~1\x9d'
    bytes_1 = '\xba\xcf\x0b\xdc'
    list_0 = [bytes_0, bytes_0, bytes_1]
    bool_0 = True
    dict_0 = {bytes_0: list_0}
    str_0 = '\x0b\xb3\x1a\x03'
    str_1 = '\xc9\xbb\x1e\xd0'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:05:54.120316
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import tempfile
    temp_dir = tempfile.mkdtemp()

    action_module_0 = ActionModule()
    str_0 = 'setup'
    action_module_0.run(temp_dir, str_0)

# Generated at 2022-06-25 07:05:57.052234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# End of test case
# Test case: 1


# Generated at 2022-06-25 07:06:02.966388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:06:11.328604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)
    # AssertionError: 'NegotiateService' != 'negotiate_service'

# Generated at 2022-06-25 07:06:16.714829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bool_0 = False
    dict_0 = {}
    str_0 = 'ynF '
    str_1 = 'zR  '
    bool_1 = False
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_1)
    return


# Generated at 2022-06-25 07:06:19.078124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 07:06:21.830277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    bool_0 = False
    dict_0 = {}
    str_0 = ''
    str_1 = ''
    bool_1 = False
    test_case_0(list_0, bool_0, dict_0, str_0, str_1, bool_1)


# Generated at 2022-06-25 07:06:29.185877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    assert action_module_0.is_task == True
    assert action_module_0.task_name == 'zR  '

# Generated at 2022-06-25 07:06:35.435963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x87V\xdc\x9b'
    bytes_1 = b'\xd7V{\x1b\xab\xb1\x81A\x08\x94!\xe6\xf86'
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str_1 = 'negotiate_service'
    action_module_0 = ActionModule(list_0, bool_0, dict_0, str_0, str_1, bool_0)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:06:43.900060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b':\x9e"\xf7\x1c\xaa\x14\x8f]|\xcc\x11>\xfa\x8a'
    bytes_1 = b"\xcc\x8a\x81\x9d\x9b\xecA\xe5\x06'\xc6\x1e\x98\xa7\x18\xe1\xc9\x8e\xcc\xf2\x19\x92\xf3\xac\x1d\x07\xf0\x86\xb5"
    list_0 = [bytes_1, bytes_1, bytes_1]
    bool_0 = True
    dict_0 = {bytes_1: list_0}
    str_0 = 'zR  '
    str