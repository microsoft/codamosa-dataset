

# Generated at 2022-06-11 00:47:51.513483
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:47:57.841194
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-11 00:48:10.132427
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'action': {
            'type': 'str',
            'choices': ['get', 'start']
        }
    }

    mutually_exclusive = [['action', 'invalid_parameter']]
    required_one_of = [['action']]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                            required_one_of=required_one_of)

    parameters = {
        'action': 'valid',
        'invalid_parameter': 'invalid'
    }

    result = validator.validate(parameters)
    assert len(result.errors) == 2

    for error in result.errors:
        assert isinstance(error, MutuallyExclusiveError) or isinstance(error, RequiredError)

# Generated at 2022-06-11 00:48:19.023702
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    spec = dict(
        foo=dict(type='str'),
        bar=dict(type='int'),
        baz=dict(type='list', elements='str'),
        sub=dict(type='dict',
                 options=dict(
                     field1=dict(type='str', default='ansible'),
                     field2=dict(type='int', default=123),
                     field3=dict(type='list', elements='int', default=[1, 2, 3]),
                 ),
                 mutually_exclusive=[['field2', 'field3']],
                 required_one_of=[['field1', 'field2']],
                 required_if=[['field2', 'field3', ['field2', 'field3']]]
                 )
    )


# Generated at 2022-06-11 00:48:24.268703
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator(argument_spec={
        "test": {
            "type": "int"
        }
    }).validate({
        "test": 5
    })

    assert result.validated_parameters["test"] == 5
    assert len(result.errors) == 0



# Generated at 2022-06-11 00:48:36.597927
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'src': {'type': 'str'},
        'dest': {'type': 'str'},
        'age': {'type': 'int'},
        'name': {'type': 'str', 'aliases': ['fn', 'fullname']},
    }

    mutually_exclusive = [
        ('src', 'dest'),
        ('name', 'fullname'),
    ]

    required_together = [
        {'src', 'dest'},
        {'name', 'fullname'},
    ]

    required_one_of = [
        {'src', 'dest'},
        {'name', 'fullname'},
    ]


# Generated at 2022-06-11 00:48:45.223062
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hobbies': {'type': 'list', 'elements': 'str'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    # No optional
    parameters = {'name': 'bo', 'age': '42', 'hobbies': ['golf', 'coding', 'flossing']}
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert sorted(result.validated_parameters['hobbies']) == sorted(['golf', 'coding', 'flossing'])

# Generated at 2022-06-11 00:48:47.271882
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Test that we can construct an instance of ArgumentSpecValidator class.
    """
    a = ArgumentSpecValidator({})

# Generated at 2022-06-11 00:48:56.079016
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 2
    assert 'The following mutually exclusive parameters are set: name, age' in result.error_messages
    assert "age is supposed to be an int but is actually a str" in result.error_messages


# Generated at 2022-06-11 00:49:07.923964
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Simple test cases
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == parameters

    parameters = {'name': None}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == parameters

    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:49:22.623476
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'x': {'type': 'bool'},
        'y': {'type': 'int', 'required': True},
        'z': {'type': 'str', 'deprecated': {'version': '1.0.0', 'date': '2020-01-08', 'msg': 'test'},
              'aliases': ['zz']},
    }
    mutually_exclusive = [("x", "y")]
    required_if = [("x", True, ["z"])]
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive, required_if=required_if)
    assert validator.validate({'x': True, 'y': 1, 'z': 'test'}).validated_parameters['y'] == 1

# Generated at 2022-06-11 00:49:33.371118
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    print("### MODULE ARGUMENT SPEC VALIDATOR BEGIN ###")
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.errors.messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.errors.messages)))
    valid_params = result.validated_parameters
    print(valid_params)
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-11 00:49:40.173255
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Call the function with some sample inputs and check for exceptions."""
    argument_spec = {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                    }

    self = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
        }
    # assert_raises() is not used because of the exception handling inside the validate method.
    self.validate(parameters)
    pass  # No exception raised

# Generated at 2022-06-11 00:49:51.244844
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockModule:
        def __init__(self, *args, **kwargs):
            pass

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'isAdmin': {'type': 'bool', 'default': False, 'require_when': ['name', 'admin', ['age']]}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'size': '1'
    }
    dv = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    r1 = dv.validate(parameters)

    parameters2 = {
        'name': 'admin',
        'age': '42',
        'isAdmin': 'True'
    }

# Generated at 2022-06-11 00:50:01.916640
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest

    class TestDeprecate():
        def __init__(self, version=None, date=None, collection_name=None):
            self.version = version
            self.date = date
            self.collection_name = collection_name

        def __call__(self, msg, version=None, date=None, collection_name=None):
            assert msg == "Alias 'test_alias' is deprecated. See the module docs for more information"
            assert version == '123'
            assert date == '2030-01-01'
            assert collection_name == 'ansible_collections.test_ns.test_coll'

    argument_spec = {
        'name': {'type': 'str', 'aliases': ['test_alias']},
    }


# Generated at 2022-06-11 00:50:09.544186
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import string_types

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert isinstance(result.unsupported_parameters, set)
    assert len(result.unsupported_parameters) == 0
    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 0
    assert isinstance(result.validated_parameters, dict)
    assert result

# Generated at 2022-06-11 00:50:18.863985
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_text

    msg = []

    for d in result._deprecations:
        deprecate("Alias '{name}' is deprecated. See the module docs for more information".format(name=d['name']),
                  version=d.get('version'), date=d.get('date'),
                  collection_name=d.get('collection_name'))

    for w in result._warnings:
        warn('Both option {option} and its alias {alias} are set.'.format(option=w['option'], alias=w['alias']))


# Generated at 2022-06-11 00:50:31.058877
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text

    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments, check_mutually_exclusive
    from ansible.module_utils.common.dict_transformations import recursive_diff
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import iteritems

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(TestModuleArgumentSpecValidator, self).__init__(*args, **kwargs)
            ##################################################################
            # do not remove or modify the next line
            ##################################################################

# Generated at 2022-06-11 00:50:39.295354
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create a validator based on the argument_spec.
    argument_spec = {
        'src_type': {'type': 'str', 'choices': ['foo', 'bar']},
        'src_addr': {'type': 'str'},
        'password': {'type': 'str', 'no_log': True},
        'timeout': {'type': 'int', 'default': 60},
        'port': {'type': 'int', 'default': 23},
        'users': {'type': 'list'},
        'roles': {'type': 'dict'},
    }
    mutually_exclusive = [
        ['src_addr', 'src_type'],
        ['port', 'password'],
    ]
    required_together = [
        ['src_addr', 'src_type'],
    ]


# Generated at 2022-06-11 00:50:46.454586
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [['test', 'test2']]
    required_together = [['test', 'test2']]
    argument_spec = {
        'test': {
            'type': 'str',
        },
        'test2': {
            'type': 'str',
        },
    }

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together)

    parameters = {
        'test': 'hello',
        'test2': 'hello',
    }
    result = validator.validate(parameters)
    assert len(result.errors) == 0
    assert len(result._warnings) == 0
    assert len(result._deprecations) == 0


# Generated at 2022-06-11 00:50:57.168649
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    test_parameters = {'name': 'bo'}
    test_argument_spec = {'name': {'type': 'str'}}

    test_validator = ModuleArgumentSpecValidator(test_argument_spec)

    test_validator.validate(test_parameters)

# Generated at 2022-06-11 00:51:05.296779
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert 'bo' == result.validated_parameters['name']
    assert 42 == result.validated_parameters['age']

# Generated at 2022-06-11 00:51:16.846216
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.utils import text_type
    import pytest
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments

    # set up some dummy methods to use in place of the actual methods
    def _get_legal_inputs_mock(_1, _2, _3):
        return
    def _set_defaults_mock(_1, _2, _3):
        return
    def _list_no_log_values_mock(_1, _2):
        return
    def _get_unsupported_parameters_mock(_1, _2, _3):
        return

# Generated at 2022-06-11 00:51:26.981494
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'not_a_real_choice': {'type': 'str', 'choices': ['a', 'b']},
    })

    parameters = {
        'name': 'bo',
        'age': '42',
        'not_a_real_choice': 'c',
        'unknown_field': 'hello!',
    }

    result = validator.validate(parameters)

    assert result.errors

    assert "not_a_real_choice" in result.errors[0].message
    assert "'c'" in result.errors[0].message
    assert "'a', 'b'" in result.errors[0].message


# Generated at 2022-06-11 00:51:38.867168
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    Test for constructor of class ArgumentSpecValidator
    '''

    class TestArgumentSpecValidator(ArgumentSpecValidator):
        '''
        Unit test class for module ArgumentSpecValidator
        '''
        pass


# Generated at 2022-06-11 00:51:49.302615
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import ansible.module_utils.common.json_utils
    a = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    a._name = 'test'
    a._aliases = ['alias']
    a.argument_spec = {'myparam1': {'required': True}}
    a._options_context={}
    a._result = {}
    a._socket_path=''
    a._remote_user=''
    a._remote_pass=''
    a._remote_port=''
    a._remote_addr=''
    a._ansible_module_name=''
    a._ansible_connection=''
    a._ansible_version=''
    a._ansible_module_generated_version=''
    a._result_q=''
    a._module_flags

# Generated at 2022-06-11 00:52:00.935679
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'enabled': {'type': 'bool', 'default': True},
        'age': {'type': 'int'},
        'sex': {
            'type': 'dict',
            'options': {
                'value': {'type': 'int'},
            },
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:52:11.911139
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    spec_validator = ModuleArgumentSpecValidator(
        argument_spec={'a': {'type': 'str', 'required': True},
                       'b': {'type': 'str', 'required': True},
                       'c': {'type': 'str', 'required': True}},
        mutually_exclusive=[['a', 'b'], ['a', 'c']],
        required_one_of=[['a', 'b'], ['a', 'b', 'c']],
        required_together=[['a', 'b']],
        required_by={'x': ['a', 'c']}
    )
    result = spec_validator.validate({'a': 1, 'b': 2, 'c': 3})
    assert len(result.errors) == 11

# Generated at 2022-06-11 00:52:15.454768
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-11 00:52:23.088300
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-11 00:52:38.253961
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:52:45.404647
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # create an ArgumentSpecValidator object
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    # test invalid parameters
    parameters = {
        "name": "",
        "age": "42"
    }
    actual_result = validator.validate(parameters, None, None)
    expected_result = ValidationResult({"name": "", "age": 42})
    expected_result.warnings.append({'option':'name', 'alias':'username'})

# Generated at 2022-06-11 00:52:56.439170
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params == {'name': 'bo', 'age': 42}


if __name__ == "__main__":
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-11 00:53:05.707126
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import unittest
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import RedirectWarning
    from ansible.module_utils.six import StringIO

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    test_output = StringIO()

# Generated at 2022-06-11 00:53:17.159552
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    my_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'dna': {'type': 'dict', 'options': {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }},
    }

    my_param = {
        'name': 'bo',
        'age': '42',
        'dna': {
            'name': 'bo',
            'age': '42',
        }
    }
    validator = ArgumentSpecValidator(my_spec)
    result = validator.validate(my_param)

    assert result.error_messages == []


# Generated at 2022-06-11 00:53:28.414972
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module = {}
    module['argument_spec'] = {
        'name': {'type': 'str'},
    }
    module['mutually_exclusive'] = [
        ["name", "age"]
    ]
    module['required_together'] = [
        ["name", "age"]
    ]
    module['required_one_of'] = [
        ["name", "age"]
    ]
    module['required_if'] = [
        ["name", "age"]
    ]
    module['required_by'] = {
        'name': ['age']
    }

# Generated at 2022-06-11 00:53:39.666766
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_text

    from ansible.module_utils.common.warnings import deprecation_warning, AnsibleDeprecationWarning, AnsibleWarning

    from ansible.module_utils.common._collections_compat import MutableMapping

    import ansible.module_utils.common.arg_spec as A


# Generated at 2022-06-11 00:53:41.533351
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    feed = {'argument_spec': {'key': {'type': 'str'}}}
    validator = ModuleArgumentSpecValidator(**feed)
    val = validator.validate({})
    assert val.validated_parameters == {'key': ''}



# Generated at 2022-06-11 00:53:52.742080
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeResult:
        def __init__(self):
            self.alias_warnings = []
            self.alias_deprecations = []
            self.validated_parameters = {}
            self.no_log_values = {}
            self.unsupported_parameters = {}
            self.deprecations = []
            self.warnings = []
            self.errors = []

    class FakeValidator(ModuleArgumentSpecValidator):
        def __init__(self):
            argument_spec = {}
            mutually_exclusive = []
            required_together = []
            required_one_of = []
            required_if = []
            required_by = []

            super().__init__(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-11 00:54:04.306147
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    validator.validate({})
    validator.validate({'path': '/home/testuser'})

    argument_spec = {'path': {'type': 'path', 'aliases': ['dest']}}
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate({'path': '/home/testuser'})
    validator.validate({'path': '/home/testuser', 'dest': '/home/testuser'})

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate({'name': 'testuser', 'age': '42'})
    validator.validate

# Generated at 2022-06-11 00:54:20.961016
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {}
    for deprecation in ModuleArgumentSpecValidator(dict()).validate(parameter)._deprecations:
        assert deprecation == {}

# Generated at 2022-06-11 00:54:23.929851
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-11 00:54:35.220692
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "a": {"type": "str"},
        "b": {"type": "str"},
        "c": {"type": "str"}
    }

    mutually_exclusive = [['a', 'b'], ['a', 'c']]
    required_together = [['b', 'c']]
    required_one_of = [['a', 'b']]
    required_if = [('a', 'b', ['c'])]
    required_by = {'c': ['a', 'b']}


# Generated at 2022-06-11 00:54:46.266125
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # check that deprecation warning is raised
    argument_spec = {
        'name': {'type': 'str'},
        'new_name': {'type': 'str', 'aliases': ['old_name']},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'new_name': 'bob-ob',
    }

    result = validator.validate(parameters)

    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'old_name'

    # check that warning about options and aliases is raised

# Generated at 2022-06-11 00:54:56.445524
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:55:06.213151
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {'name': {'type': 'str', 'default': 'Bob'}}

    parameters = {'name': 'Bob', 'age': 23}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    parameters = result.validated_parameters
    assert parameters['name'] == 'Bob'
    assert 'age' in parameters.keys()
    assert result.errors == []
    assert result.error_messages == []

    parameters = {'name': 'Bob', 'age': -42}

# Generated at 2022-06-11 00:55:17.466598
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {
            'type': 'dict',
            'options': {
                'street_name': {'type': 'str'},
                'house_number': {'type': 'int'},
            },
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'address': {
            'street_name': 1,
            'house_number': '42',
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:55:27.350059
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def check_no_errors(result, expected_result):
        assert result.errors == []
        assert result.validated_parameters == expected_result

    # Parameters with legal input
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    expected_result = {
        'name': 'bo',
        'age': 42,
    }

    check_no_errors(result, expected_result)

    # Parameters with illegal input

# Generated at 2022-06-11 00:55:38.048773
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""

    # simple test
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        raise AssertionError("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

    # simple test of nested arguments

# Generated at 2022-06-11 00:55:42.783174
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
            "test": {'type': 'str', 'required': True},
            "test2": {'type': 'str', 'required': True},
        }

    parameters = {
            'test': 'test',
            'test2': 'test',
        }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert set(result.validated_parameters.keys()) == set(parameters.keys())
    assert set(result.unsupported_parameters) == set()

# Generated at 2022-06-11 00:56:24.830580
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'hello', ['age']]
    ]

    required_by = {
        'name': ['name', 'age']
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator._valid_parameter_names == {'age', 'name'}
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive is None
    assert validator

# Generated at 2022-06-11 00:56:32.521539
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Method signature:
    # ArgumentSpecValidator.validate(parameters)
    # Test if validate() returns ValidationResult object

    # Setup
    class Test_ArgumentSpecValidator(ArgumentSpecValidator):

        def __init__(self):
            self.argument_spec = {
                'name': {'type': 'str'},
            }
    validator = Test_ArgumentSpecValidator()

    parameters = {
        'name': 'Jim'
    }
    # Execute
    # Test if validate() returns ValidationResult object
    val = validator.validate(parameters)
    assert isinstance(val, ValidationResult) == True


# Generated at 2022-06-11 00:56:38.458500
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    ).validate({
        'name': 'bo',
        'age': '42',
    })

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:56:49.683494
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    class FakeResult(object):
        def __init__(self, errors):
            self.errors = errors

    class FakeValidator(ArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(FakeValidator, self).__init__(*args, **kwargs)

        def validate(self, parameters):
            return FakeResult([])

    class FakeArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(FakeArgumentSpecValidator, self).__init__(*args, **kwargs)
            self.fake_validator = FakeValidator('argspec')

        def validate(self, parameters):
            return self.fake_validator.valid

# Generated at 2022-06-11 00:56:54.385614
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        {'clean': {'type': 'bool', 'aliases': ['purge']}},
        mutually_exclusive=['clean', 'purge']
    )
    result = validator.validate({'clean': True, 'purge': True})
    assert result.error_messages == ['The parameters "clean" and "purge" are mutually exclusive']



# Generated at 2022-06-11 00:56:55.481815
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    validator.validate({})

# Generated at 2022-06-11 00:56:56.977718
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "Test not implemented"


# Generated at 2022-06-11 00:57:07.597827
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.validation import check_mutually_exclusive, \
                                                       check_required_together, \
                                                       check_required_one_of, \
                                                       check_required_if, \
                                                       check_required_by

    argument_spec = dict(
        key1=dict(),
        key2=dict(),
        key3=dict(),
        key4=dict(),
        key5=dict(),
        key6=dict(),
        key7=dict(),
        key8=dict(),
        key9=dict(),
        key10=dict(),
        key11=dict(),
        key12=dict(),
        key13=dict(),
    )


# Generated at 2022-06-11 00:57:16.842004
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(spec)
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == parameters

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }



# Generated at 2022-06-11 00:57:27.143127
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test case 1: mutually_exclusive is a list of list of string
    args = [
        {"a": {'type': 'str'}},
        [['a', 'b']],
        None, None, None, None
    ]
    args_v = ModuleArgumentSpecValidator(*args)
    params = {"a": "a_string", "b": "b_string"}
    result = args_v.validate(params)
    assert not result.errors.messages

    # test case 2: mutually_exclusive is not a list of list of string
    args = [
        {"a": {'type': 'str'}},
        [['a']],
        None, None, None, None
    ]
    args_v = ModuleArgumentSpecValidator(*args)