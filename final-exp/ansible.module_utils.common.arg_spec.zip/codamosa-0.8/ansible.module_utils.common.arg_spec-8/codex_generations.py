

# Generated at 2022-06-11 00:47:52.863943
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator(
        {},
        mutually_exclusive=[['foo', 'bar']],
        required_together=[['foo', 'bar']],
        required_one_of=[['foo', 'bar']],
        required_if=[['foo', 'bar', ['bar']]],
    ).validate({'foo': '123', 'bar': '123'})

    if result.errors:
        return {"error": "validation failed" + " ".join(result.errors)}

    return result.validated_parameters

# Generated at 2022-06-11 00:48:05.154967
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:48:15.936421
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
          'testmodule_group':{
            'arg1':{
              'type':'dict',
              'aliases':[
                'testmodule_group.arg1'
              ],
              'options':{
                'arg11':{
                  'type':'str',
                  'aliases':[
                    'testmodule_group.arg1.arg11'
                  ]
                }
              }
            }
          }
        }


# Generated at 2022-06-11 00:48:27.853123
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test for mutually_exclusive, required_together and required_one_of
    argument_spec = {'state': {'type': 'str', 'choices': ['present', 'absent']},
                     'src': {'type': 'str'},
                     'dest': {'type': 'str'}}

    mutually_exclusive = [['src', 'dest']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert validator._mutually_exclusive == [['src', 'dest']]

    required_one_of = [['src', 'dest']]
    validator = ArgumentSpecValidator(argument_spec, required_one_of=required_one_of)
    assert validator._required_one_of == [['src', 'dest']]


# Generated at 2022-06-11 00:48:39.453456
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    module_arg_spec_validator = ModuleArgumentSpecValidator(
        argument_spec=argument_spec,
        mutually_exclusive=mutually_exclusive,
        required_together=required_together,
        required_one_of=required_one_of,
        required_if=required_if,
        required_by=required_by,
    )

    parameters = {
        'name': 'bo',
        'age': '42',
    }


# Generated at 2022-06-11 00:48:46.041429
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42


# Generated at 2022-06-11 00:48:55.769631
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    def check_mutually_exclusive(terms, param_name, param_value):
        if param_name == 'age':
            raise TypeError('mutually exclusive, no_log')

    mutually_exclusive = [
        [
            'age',
            'name',
        ]
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)

    errors = [MutuallyExclusiveError('mutually exclusive, no_log')]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    validator.validate(parameters)


# Unit test

# Generated at 2022-06-11 00:49:00.415092
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'foo': {'type': 'str'}}, required_one_of=[[['required_one_of_foo', 'required_one_of_bar']]])
    parameters = {'foo': 'baz'}
    assert validator.validate(parameters)


# Generated at 2022-06-11 00:49:12.467016
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.unsupported_parameters == set()
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.error_messages == []

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._warnings == []
    assert result._deprecations == []



# Generated at 2022-06-11 00:49:22.804060
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'test_str': {'type': 'str'},
        'test_int': {'type': 'int'},
        }
    mutually_exclusive = [['test_str', 'test_int']]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                            required_one_of, required_if, required_by)

    class Deprecator(object):
        def __init__(self):
            self.deprecations = []

# Generated at 2022-06-11 00:49:31.545238
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate({})

    assert len(result.warnings) == 0
    assert isinstance(result, ValidationResult)
    assert len(result.errors) == 0

# Generated at 2022-06-11 00:49:41.259820
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.collections import ImmutableDict
    import pytest

    VALIDATION_ERRORS = ModuleArgumentSpecValidator.VALIDATION_ERRORS
    NO_LOG_ERRORS = ModuleArgumentSpecValidator.NO_LOG_ERRORS

    MUTUALLY_EXCLUSIVE = [['a', 'b'], ['c', 'd']]
    REQUIRED_TOGETHER = [['a', 'b'], ['c', 'd']]
    REQUIRED_ONE_OF = [['a', 'b'], ['c', 'd']]
    REQUIRED_IF = [['a', 'b', ['c', 'd']]]

# Generated at 2022-06-11 00:49:52.825571
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Validate with success
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == parameters

    # Validate with errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased': {'type': 'str', 'aliases': ['alias']},
    }


# Generated at 2022-06-11 00:50:03.136205
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
        'emails': {'type': 'list'},
        'addresses': {'type': 'dict'},
        'aliased': {'type': 'str', 'aliases': ['alias1', 'alias2']},
        'deprecated': {'type': 'str', 'deprecated': {'version': '2.0', 'msg': 'deprecated_msg'}},
        'warn': {'type': 'str', 'aliases': ['alias']},
    })

# Generated at 2022-06-11 00:50:10.240246
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    mutually_exclusive = [['name', 'age']]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive)

    # test with valid parameters
    parameters = {
        'name': 'bo',
        'age': '42'
        }

    result = validator.validate(parameters)
    assert len(result.errors) == 0

    # test with valid parameters
    parameters = {
        'name': 'bo',
        'age': 42
        }

    result = validator.validate(parameters)
    assert len(result.errors) == 0

    # test mutually_exclusive

# Generated at 2022-06-11 00:50:16.814560
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:50:28.884556
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test case for method validate of class ModuleArgumentSpecValidator"""
    test_instance = ModuleArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    )

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = test_instance.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []



# Generated at 2022-06-11 00:50:37.834460
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    if valid_params['age'] != 42:
        sys.exit("Age is not an int")

    if valid_params['name'] != 'bo':
        sys.exit("Name is not a str")



# Generated at 2022-06-11 00:50:49.494555
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # pylint: disable=too-many-locals
    # pylint: disable=protected-access

    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments


# Generated at 2022-06-11 00:50:50.693045
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''validate(): Unit tests'''

    # Simple example unit test

    # Check that argument validation succeeds and return a valid result
    pass

# Generated at 2022-06-11 00:51:06.257964
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
	warns = []
	deprecates = []
	
	def warn(text):
		warns.append(text)
	def deprecate(text):
		deprecates.append(text)

	ModuleArgumentSpecValidator.warn = warn
	ModuleArgumentSpecValidator.deprecate = deprecate

	result = ModuleArgumentSpecValidator().validate({})
	assert not result.errors
	assert not result.warnings
	assert not result.deprecations
	assert not warns
	assert not deprecates


# Generated at 2022-06-11 00:51:12.650635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # No error occured
    assert result.errors is None

# Generated at 2022-06-11 00:51:21.345432
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42
    }



# Generated at 2022-06-11 00:51:29.249505
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class FakeModule:
        def __init__(self, **kwargs):
            self.argument_spec = kwargs

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):

        def __init__(self, *args, **kwargs):
            super(TestModuleArgumentSpecValidator, self).__init__(*args, **kwargs)

        def fake_deprecate(self, msg, version, date, collection_name):
            self.deprecate_msg = msg

        def fake_warn(self, msg):
            self.warn_msg = msg

        def get_mutually_exclusive(self):
            return self._mutually_exclusive

        def get_required_together(self):
            return self._required_together

        def get_required_one_of(self):
            return self._required_

# Generated at 2022-06-11 00:51:40.909212
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'str'}}
    parameters = {'a': '1'}

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert not result.error_messages
    assert isinstance(result.validated_parameters, dict)
    assert result.validated_parameters['a'] == '1'
    assert set(result.validated_parameters.keys()) == set(['a'])

    # Test adding a new argument
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)
   

# Generated at 2022-06-11 00:51:48.299950
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42
    }

# Generated at 2022-06-11 00:51:59.484908
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create module argument spec mock
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    # Create parameters mock
    parameters = {
        'name': 'bo',
        'age': '42'
    }

    # Create module argument spec validator mock
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Mock validate method
    result = validator.validate(parameters)

    # Asserts
    assert result.error_messages == []

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42
    }

    assert 'age' in result._no_log_values

    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:52:10.806840
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test ArgumentSpecValidator when all arguments are valid"""
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}

    mutually_exclusive = [['name', 'age']]

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [{'parameter': 'name', 'value': 20, 'parameters': ['name', 'age']}]

    required_by = {'name': ['age']}


# Generated at 2022-06-11 00:52:18.567898
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(result.error_messages))
    valid_params = result.validated_parameters

    return {
        'validated_parameters': valid_params,
        'error_messages': result.error_messages
    }



# Generated at 2022-06-11 00:52:28.652157
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Input
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }


    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)


# Generated at 2022-06-11 00:52:49.429683
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from collections import namedtuple
    class Warn():
        def __init__(self):
            self.msg = []
        def __call__(self, msg):
            self.msg.append(msg)
    class Deprecate():
        def __init__(self):
            self.msg = []
        def __call__(self, msg, version=None, date=None, collection_name=None):
            self.msg.append(msg)
    class AssertionError:
        def __init__(self, msg):
            self.msg = msg
        def __str__(self):
            return self.msg
    class RequiredError:
        def __init__(self, msg):
            self.msg = msg
        def __str__(self):
            return self.msg

# Generated at 2022-06-11 00:53:00.306603
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.validation import _check_mutually_exclusive_full
    from ansible.module_utils.common.validation import _check_required_one_of_full
    from ansible.module_utils.common.validation import _check_required_together_full
    from ansible.module_utils.common.validation import _check_required_if_full
    from ansible.module_utils.common.validation import _check_required_by_full
    import json

    argument_spec = {
        "test1": {"type": "str", "required": False},
        "test2": {"type": "str", "required": False},
        "test3": {"type": "str", "required": True},
    }

   

# Generated at 2022-06-11 00:53:03.530717
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = dict(
        state=dict(default='present', choices=['present', 'absent']),
        name=dict(required=True, type='str'),
        age=dict(type='int'),
    )

    spec_validator = ArgumentSpecValidator(argument_spec)

    parameters = dict(
        name='bo',
        age='42',
    )
    result = spec_validator.validate(parameters)

    assert result == dict(
        state='present',
        name='bo',
        age=42,
    )



# Generated at 2022-06-11 00:53:12.744756
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import unittest

    class MyTestCase(unittest.TestCase):
        def test_ModuleArgumentSpecValidator_validate_missing_name_field(self):
            argument_spec = {
                'age': {'type': 'int'},
            }
            parameters = {
                'name': 'bo',
                'age': '42',
            }

            validator = ModuleArgumentSpecValidator(argument_spec)
            result = validator.validate(parameters)

            self.assertFalse(result.error_messages)

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-11 00:53:24.312079
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # test data

# Generated at 2022-06-11 00:53:28.594415
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    test_args = {'argument_spec': {'name': {'required': True, 'type': 'str'}}}

    result = ArgumentSpecValidator(**test_args)

    assert result.argument_spec == test_args[
        'argument_spec'], "Argument spec doesn't match"



# Generated at 2022-06-11 00:53:39.934627
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    import warnings

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        validator = ModuleArgumentSpecValidator(argument_spec)
        result = validator.validate(parameters)
        if result.error_messages:
            print(sys.exit("Validation failed: {0}".format(", ".join(result.error_messages))))
        valid_params = result.validated_parameters
        # Verify some things


# Generated at 2022-06-11 00:53:50.821659
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = {}

    def deprecate(msg, version=None, date=None, collection_name=None):
        result['deprecate'] = {'msg': msg}

    def warn(msg):
        result['warn'] = {'msg': msg}

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'collection_aliases': {
            'aliases': ['c_alias'],
            'version_added': '2.9',
            'status': {'removed': '2.12'},
            'type': 'list'
        },
        'aliases': {'type': 'list', 'aliases': ['a_alias']}
    }


# Generated at 2022-06-11 00:53:56.464400
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not hasattr(result, 'errors')



# Generated at 2022-06-11 00:54:07.070718
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Simple Example
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    # Example of validate() returning an error
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 'forty-two',
    }

    valid

# Generated at 2022-06-11 00:54:32.767511
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test :func:`ansible.module_utils.common.arg_spec.ArgumentSpecValidator.validate`."""

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = dict(
        test_param=dict(
            type='str',
            choices=["a", "b", "c"],
            default="a",
        ),
    )


# Generated at 2022-06-11 00:54:40.752040
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate method of ModuleArgumentSpecValidator class"""

    # test with error
    result = ModuleArgumentSpecValidator({'name': {'required': True, 'type': 'str'}}).validate({})
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.errors.errors[0], RequiredError)
    assert result.error_messages[0] == "name is required"
    assert not result.validated_parameters
    assert not result.unsupported_parameters
    assert not result._validated_parameters
    assert not result._no_log_values
    assert not result._deprecations
    assert not result._warnings

    # test with error and deprecation

# Generated at 2022-06-11 00:54:45.254382
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name':{'type':'str'}},required_if=[['name','abc',['name']]])
    result = validator.validate({})
    assert result.errors[0].message == "One of the following is required: name"

# Generated at 2022-06-11 00:54:55.599585
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def my_deprecate(msg, version, date, collection_name):
        deprecations.append(msg)
    def my_warn(msg):
        warnings.append(msg)

    def get_validator(argspec, deps, wa):
        v = ModuleArgumentSpecValidator(argspec)
        v._deprecations = deps
        v._warnings = wa
        return v

    test_cases = dict()

    test_cases[
        "no_log_values"
    ] = {
        "validator": get_validator({"name": {"type": "str", "no_log": True}}, [], []),
        "parameters": {"name": "test"},
        "expected_deprecations": [],
        "expected_warnings": [],
    }


# Generated at 2022-06-11 00:55:02.262583
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # method validate of class ArgumentSpecValidator
    args = dict(
        argument_spec = dict(
            name = dict(type = 'str'),
            age = dict(type = 'int'),
        ),
        mutually_exclusive = [],
        required_together = [],
        required_one_of = [],
        required_if = [],
        required_by = [],
    )

    parameters = dict(
        name = 'bo',
        age = '42',
    )

    validator = ArgumentSpecValidator(**args)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:55:13.171952
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validation of ArgumentSpecValidator class."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['a', 'b'], ['c', 'd', 'e']]
    required_together = [['aa', 'ab'], ['ac', 'ad']]
    required_one_of = [['aaa', 'aab'], ['aca', 'acb']]
    required_if = [['aaa', 'f', ['f1', 'f2']], ['aca', 'g', ['g1', 'g2']]]
    required_by = {
        'aa': ['ab'],
        'ac': ['ad'],
    }

# Generated at 2022-06-11 00:55:23.921528
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create argumentspecs
    argument_spec = dict(
        x=dict(type='str'),
        y=dict(type='int'),
    )

    # create the validator
    validator = ModuleArgumentSpecValidator(argument_spec)

    # test for success
    parameters = dict(x="42")
    assert validator.validate(parameters).validated_parameters == parameters

    # test for failure
    parameters = dict(x=42)
    result = validator.validate(parameters)

    # we have a single error
    assert len(result.errors) == 1

    # and the error message contains both the parameter name, the expected and
    # the actual type
    assert "x (str)" in result.error_messages[0]
    assert "int" in result.error_messages[0]

# Generated at 2022-06-11 00:55:30.543440
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Verify that method validate of class ModuleArgumentSpecValidator returns a ValidationResult object
    """
    # Setup
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'} }
    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {'name': 'bo', 'age': '42'}

    # Test
    result = validator.validate(parameters)

    # Assert
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-11 00:55:37.765945
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec,required_one_of=[['name','age']])
    result = validator.validate(parameters)
    assert result.error_messages == ["Required one of the following: name, age."]



# Generated at 2022-06-11 00:55:43.678188
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    my_arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    my_mutually_exclusive = [['name', 'age']]
    my_required_together = [['name', 'age']]
    my_required_one_of = [['name', 'age']]
    my_required_if = [['name', 'present', ['age']]]
    my_required_by = {'name': {'age': ['present']}}
    my_validator = ArgumentSpecValidator(
        my_arg_spec,
        my_mutually_exclusive,
        my_required_together,
        my_required_one_of,
        my_required_if,
        my_required_by,
    )
    assert my_

# Generated at 2022-06-11 00:56:23.368859
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup args for argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Setup parameters for validate
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # Create a validator
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Call validate
    result = validator.validate(parameters)

    # Validate the results
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == None
    assert result.error_messages == []

# Generated at 2022-06-11 00:56:29.688385
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'str', 'aliases': ['boo']}}
    parameters = {'a': 'foo', 'b': 'bar'}
    validator = ModuleArgumentSpecValidator(module_argument_spec)
    result = validator.validate(parameters)

    assert hasattr(result, 'error_messages')
    assert result.validated_parameters == parameters

# Generated at 2022-06-11 00:56:32.910963
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # parameters = None
    # args = None
    # kwargs = None
    # expected = {'warnings': [], 'deprecations': []}
    # actual = ModuleArgumentSpecValidator(argument_spec={})
    # assert actual.validate(parameters, *args, **kwargs) == expected

    pass


# Generated at 2022-06-11 00:56:34.266752
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for AnsibleModule() method validate()"""
    assert False, "test_ModuleArgumentSpecValidator_validate not implemented"

# Generated at 2022-06-11 00:56:40.794090
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    vs = ModuleArgumentSpecValidator(
        {'x': {'aliases': ['y']}},
        [], [], [], []
    )
    r = vs.validate(dict(x='1', y='2'))
    assert len(r.errors) == 0
    assert r.validated_parameters == dict(x='1', y='2')


# Generated at 2022-06-11 00:56:51.625559
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [["name", "age"], ["name", "school"]]
    argument_spec = {"name": {"type": "str"},
                     "age": {"type": "int"},
                     "school": {"type": "list"}}
    parameters = {"name": "test"}
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)
    result = validator.validate(parameters)
    assert result.validated_parameters["name"] == "test"

    mutually_exclusive = [["name", "age"], ["name_1", "school"]]
    argument_spec = {"name": {"type": "str"},
                     "age": {"type": "int"},
                     "school": {"type": "list"}}
    parameters = {"name": "test", "age": 20}
    validator = ModuleArg

# Generated at 2022-06-11 00:56:56.154064
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argumentspec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    parameters = {'name': 'bo',
                  'age': '42'}

    validator = ModuleArgumentSpecValidator(argumentspec)
    result = validator.validate(parameters)
    assert (result.validated_parameters == {'name': 'bo', 'age': 42})
    assert (not result.errors)

# Generated at 2022-06-11 00:57:07.261893
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # test the normal case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'name' in result.validated_parameters
    assert 'age' in result.validated_parameters

    # test the error case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 'abc',
    }


# Generated at 2022-06-11 00:57:16.927397
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator({'abc': {'type': 'dict'}}).validate({'abc': 123})
    assert len(result.errors) == 1
    assert result.errors[0].message == "'abc' is not a dictionary"
    assert result.validated_parameters == {}
    result = ArgumentSpecValidator({'abc': {'type': 'dict'}}, mutually_exclusive=['abc']).validate({'abc': {'def': 'ghi'}})
    assert len(result.errors) == 1
    assert result.errors[0].message == "abc is mutually exclusive with abc"
    result = ArgumentSpecValidator({'abc': {'type': 'dict'}}, required_if=[['abc', 'ghi', ['def']]]).validate({'abc': 'ghi'})

# Generated at 2022-06-11 00:57:27.240329
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create a ModuleArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec,
        mutually_exclusive, required_together, required_one_of,
        required_if, required_by)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # validate should return instance of ValidationResult
    validation_result = validator.validate(parameters)
    assert isinstance(validation_result, ValidationResult)