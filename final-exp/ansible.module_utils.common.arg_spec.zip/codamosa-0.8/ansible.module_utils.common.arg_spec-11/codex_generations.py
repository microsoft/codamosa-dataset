

# Generated at 2022-06-11 00:47:50.838876
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # parameters shouldn't be modified
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-11 00:47:51.729650
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "Test not implemented"


# Generated at 2022-06-11 00:47:56.169266
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert len(result.errors) == 0
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0

# Generated at 2022-06-11 00:48:03.273150
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:48:14.737682
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import _mutually_exclusive_check
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      )
    result = validator.validate(parameters)

    assert type(result) == ValidationResult
    assert result.errors == [MutuallyExclusiveError('Parameters are mutually exclusive: name, age')]
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:48:26.026007
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleModuleDeprecationWarning
    import warnings
    warnings.filterwarnings('error', category=AnsibleModuleDeprecationWarning)

    collections = "a_namespace.a_collection"
    version = "foo"
    date = "habibi"
    argument_spec = {
        'deprecated_alias': {'type': 'str', 'aliases': ['ignore_this']},
        'alias': {'type': 'str', 'aliases': ['ignore_this_too']},
        'other_alias': {'type': 'str', 'aliases': ['ignore_this_too']},
    }
    parameters = {
        'deprecated_alias': True,
        'alias': True,
        'other_alias': True,
    }
    v = Module

# Generated at 2022-06-11 00:48:38.126578
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'bo', ['age']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by,
                                      )

    assert validator._mutually_exclusive

# Generated at 2022-06-11 00:48:45.505602
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'pet': {'type': 'str'},
        'aliases': {'aliases': ['c']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'pet': 'goose',
        'c': 'abcd',
        'd': 'def'
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 3

# Generated at 2022-06-11 00:48:55.334079
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for `module_utils.common.arg_spec.ModuleArgumentSpecValidator.validate`."""
    import sys
    import six

    if six.PY3:
        from unittest.mock import patch, Mock
    else:
        from mock import patch, Mock

    with patch("ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator.validate") as validate_mock:
        module_arg_spec_validator = ModuleArgumentSpecValidator("SomeArgumentSpec")
        module_arg_spec_validator.validate("SomeParameters")
        validate_mock.assert_called_once_with("SomeParameters")

    with patch("ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator.validate") as validate_mock:
        result

# Generated at 2022-06-11 00:49:07.317334
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import pytest
    validator = ArgumentSpecValidator({
        'a': {'type': 'bool'},
        'b': {'type': 'bool'},
        'c': {'type': 'bool'},
        'd': {'type': 'bool', 'default': True},
        'e': {'type': 'bool', 'default': False},
    },
        mutually_exclusive=[['a', 'b']],
        required_together=[['a', 'b']],
        required_one_of=[['a', 'b'], ['c', 'd'], ['c', 'e']],
        required_if=[['a', True, ['c', 'd']]],
        required_by=[['b', ['c', 'd']]],
    )


# Generated at 2022-06-11 00:49:20.546604
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_text

    module_argument_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)

    parameters = {'name': 'bo', 'age': '42'}

    validated_parameters = module_argument_spec_validator.validate(parameters)

    assert validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:49:21.111523
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:49:31.436646
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1: There is multiple error and all error should be displayed in ValidationResult
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name']]
    required_one_of = [['name', 'age']]
    required_if = [[['name', 'age'], 'x'], [['age'], 'y']]
    required_by = {'name': ['age']}
    parameters = {
        'name': 'bo',
        'age': '42',
        'other': 'test'
    }

# Generated at 2022-06-11 00:49:38.998910
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'some_parameter': 'a value',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    expected = set(['some_parameter', 'name', 'age'])
    assert result.unsupported_parameters == expected
    print("test_ModuleArgumentSpecValidator_validate() passed")


# Generated at 2022-06-11 00:49:42.256030
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    a = ModuleArgumentSpecValidator({'a': {}}, [["a","b"]], [])
    result = a.validate({"a": "b"})
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {"a": "b"}

# Generated at 2022-06-11 00:49:49.632772
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """test :func:`~ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator_validate`
    """
    qq = ModuleArgumentSpecValidator(argument_spec={})

    assert qq.validate({}) == {'errors': [], 'warnings': [], 'deprecations': []}


if __name__ == '__main__':
    import sys
    sys.exit(test_ModuleArgumentSpecValidator_validate())

# Generated at 2022-06-11 00:49:52.929970
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    sut = ArgumentSpecValidator(argument_spec=dict())

    parameters = dict()
    result = sut.validate(parameters)

    assert parameters == result.validated_parameters



# Generated at 2022-06-11 00:50:03.221904
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import unittest
    import sys
    import ansible.module_utils.arg_spec

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = argument_spec_utils.ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:50:10.287613
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'src': {'type': 'path', 'required': True},
        'dest': {'type': 'path', 'required': True, 'aliases': ['dst']}
    }

    mutually_exclusive = [
        ['src', 'dest']
    ]

    required_together = [
        ['src', 'dest']
    ]

    required_if = [
        ['src', 'dest']
    ]

    required_one_of = [
        ['src', 'dest']
    ]

    required_by = [
        ['src', 'dest']
    ]

    parameters = {
        'src': 'src',
        'dest': 'dest'
    }


# Generated at 2022-06-11 00:50:15.647445
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import type_validator

# Generated at 2022-06-11 00:50:32.613797
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Create the validator object
    # Create the argument_spec used for validation
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'age': {
            'type': 'int',
            'required': True
        }
    }
    # Instantiate the ArgumentSpecValidator object
    validator = ArgumentSpecValidator(argument_spec)

    # Create the parameters used for validation
    parameters = {
        'name': 'Username',
        'age': '21'
    }

    # Validate those parameters
    result = validator.validate(parameters)
    assert not result.errors
    assert result.validated_parameters['name'] == 'Username'
    assert result.validated_parameters['age'] == 21

    # Check if the

# Generated at 2022-06-11 00:50:39.724675
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class TestException(Exception):
        pass

    class TestValidationResult:
        def __init__(self, result, expected_message):
            self.expected_message = expected_message
            self.result = result

        def __eq__(self, other):
            if not isinstance(other, TestValidationResult):
                return False
            return (self.result == other.result) and (self.expected_message == other.expected_message)

    argument_spec = {"key_1": {"deprecated_aliases": ["key_1_alias"]},
                     "key_2": {"deprecated_aliases": ["key_2_alias"]}}


# Generated at 2022-06-11 00:50:46.934670
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator({
        "name": {
            "type": "str",
            "default": "bo",
            "aliases": ["alias_one"]
        },
        "age": {
            "type": "int",
            "default": 42
        }
    }).validate({"name": "bo", "age": "42"})

    assert result.validated_parameters == {"name": "bo", "age": 42}
    assert not result.errors
    assert result._deprecations == []
    assert result._warnings == []


# Generated at 2022-06-11 00:50:55.301854
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Using the example from ArgumentSpecValidator.validate above plus deprecation warnings and warnings

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:51:06.815090
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def assert_parameter_value(validated_parameters, expected_value, parameter_name):
        assert validated_parameters[parameter_name] == expected_value
        return

    def test_parameter_alias(validator, input_parameters, expected_value, parameter_name):
        result = validator.validate(input_parameters)
        assert len(result.errors) == 0
        assert_parameter_value(result.validated_parameters, expected_value, parameter_name)
        return

    def test_parameter_alias_invalid(validator, input_parameters, expected_error_msg, error_class):
        result = validator.validate(input_parameters)
        assert len(result.errors) == 1
        assert isinstance(result.errors[0], error_class)

# Generated at 2022-06-11 00:51:18.542448
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    # All of these should fail
    parameters = [
        {'name': 'bo', 'age': '42'},  # age must be an int, not a string
        {'age': 42},  # name is required
        {},  # name is required
        None,  # name is required
        {'name': 'bo'},  # age is required
        {'name': 'bo', 'age': '42', 'occupation': 'programmer'},  # occupation is not in the argument_spec
    ]

    for param in parameters:
        result = validator.validate(param)

        if not len(result.errors) == 1:
            raise Assertion

# Generated at 2022-06-11 00:51:27.899979
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:51:39.412281
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    s = ModuleArgumentSpecValidator({
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'age': {'type': 'int', 'default': 42},
    })
    p = {
        'state': 'present',
        'age': '42',
    }
    r = s.validate(p)
    assert r.validated_parameters == {
        'state': 'present',
        'age': 42,
    }
    assert not r.error_messages
    assert r._no_log_values == set()
    assert r._unsupported_parameters == set()
    assert r._deprecations == []
    assert r._warnings == []


# Generated at 2022-06-11 00:51:42.191192
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    @ArgumentSpecValidator.validate
    def my_function(name, age):
        return name, age

    my_function(name='bo', age='42')

# Generated at 2022-06-11 00:51:48.300034
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'a': {'type': 'str'}})
    assert validator.validate({'a': 'b'})
    assert validator.validate({'a': 'b', 'aliased_parameter': 'foo'})
    assert not validator.validate({'a': 42})
    assert not validator.validate({'a': 42, 'aliased_parameter': 'foo'})



# Generated at 2022-06-11 00:52:02.172978
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator = ArgumentSpecValidator({
        "name": {"type": "str"},
        "age": {"type": "int"},
    })

    parameters = {
        "name": "bo",
        "age": "12",
    }

    result = argument_spec_validator.validate(parameters)
    if len(result.error_messages) != 0:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
    valid_params = result.validated_parameters


# Generated at 2022-06-11 00:52:02.829053
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:52:13.120041
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test warn
    validator = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'gender': {'type': 'bool'},
        'race': {'type': 'str', 'aliases': ['ethnicity']},
        'spouse': {'type': 'str', 'aliases': ['partner', 'mate']},
    })

    parameters = {
        'name': 'bo',
        'age': '42',
        'gender': 'true',
        'partner': 'bob',
    }

    result = validator.validate(parameters)
    assert len(result._warnings) == 1
    assert result._warnings[0]['option'] == 'spouse'
    assert result._warn

# Generated at 2022-06-11 00:52:21.218791
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert 'bo' == result.validated_parameters['name']
    assert 42 == result.validated_parameters['age']
    assert not result.deprecations
    assert not result.warnings

# Generated at 2022-06-11 00:52:32.881410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # param is optional and default is set
    argument_spec = {'param': {'type': 'int', 'default': 42}}
    parameters = {'param': 42}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 0
    assert result.validated_parameters['param'] == 42

    # param is required and provided
    argument_spec = {'param': {'type': 'int', 'required': True}}
    parameters = {'param': 42}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 0
    assert result.validated_parameters['param'] == 42

    # param is required but not provided
    argument

# Generated at 2022-06-11 00:52:42.437131
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'key_1': {'type': 'str'},
        'key_2': {'type': 'int'},
        'key_3': {
            'type': 'list',
            'elements': 'str',
        },
    }

    parameters = {
        'key_1': 'bo',
        'key_2': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == AnsibleValidationErrorMultiple(["argument key_2 is of type <class 'int'> but we were unable to convert key_2 (42) to that type"])
    assert result.validated_parameters == {'key_1': 'bo', 'key_2': 42}


# Generated at 2022-06-11 00:52:55.223616
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'param1': {'type': 'str', 'aliases': ['p1']},
        'param2': {'type': 'str', 'aliases': ['p2']},
        'param3': {'type': 'str', 'aliases': ['p3']},
    }

    mutually_exclusive = [['param1', 'param2']]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = {'param1': 'value_1', 'param2': 'value_2'}
    result = validator.validate(parameters)

    assert 'validation of mutually exclusive options failed' in result.error_messages


# Generated at 2022-06-11 00:53:01.181516
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({'test_param': {'type': 'str'}})
    assert v.validate({'test_param': 'test_value'}).validated_parameters == {'test_param': 'test_value'}
    assert v.validate({'test_param': 'no_log_value'}).validated_parameters == {'test_param': 'no_log_value'}

# Generated at 2022-06-11 00:53:06.164629
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result is not None
    assert result.error_messages == []

# Generated at 2022-06-11 00:53:12.744583
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arguments_spec = {'a_paths': {'type': 'list'}, 'another_paths': {'type': 'list'}}
    parameters = {'a_paths': ['/etc/passwd'], 'another_paths': ['/etc/shadow']}

    validator = ModuleArgumentSpecValidator(arguments_spec)
    results = validator.validate(parameters)
    assert results.validated_parameters == parameters

# Generated at 2022-06-11 00:53:30.252045
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'collection_name': {'type': 'str', 'aliases': ['name']}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'collection_name': 'collection'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert set(result.validated_parameters.keys()) == set(parameters.keys())

# Generated at 2022-06-11 00:53:41.691258
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test ArgumentSpecValidator.validate validates parameters against the argument spec."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors, "Errors validating parameters: {}".format(result.errors)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}, \
        "Validated parameters should be coerced to the correct type: {}".format(result.validated_parameters)

# Generated at 2022-06-11 00:53:52.881583
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Test valid parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test invalid parameters
    parameters = {
        'name': 'bo',
        'not_an_age': '42',
    }
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:54:01.408908
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator.
    """
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert 'name' in result.validated_parameters
    assert not result.unsupported_parameters



# Generated at 2022-06-11 00:54:12.118773
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    result = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result2 = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    ansibleError = AnsibleValidationErrorMultiple()
    ansibleError.append(MutuallyExclusiveError('Both option name and age are set.'))
    assert result.validate(parameters).errors == ansibleError
    assert result2.validate(parameters).errors == None

# Generated at 2022-06-11 00:54:17.636699
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters.get('age') == 42
    assert not result.errors

# Generated at 2022-06-11 00:54:24.069431
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = []

    required_together = []

    required_one_of = []

    required_if = []

    required_by = []

    v = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    v.validate(parameters)

# Generated at 2022-06-11 00:54:35.356821
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for ModuleArgumentSpecValidator.validate"""
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    class ModuleArgumentSpecValidator:
        """Mock for class ModuleArgumentSpecValidator to get warnings"""
        def __init__(self, *args, **kwargs):
            super(ModuleArgumentSpecValidator, self).__init__(*args, **kwargs)

        def validate(self, parameters):
            result = super(ModuleArgumentSpecValidator, self).validate(parameters)
            self.deprecations = result._deprecations
            self.warnings = result._warnings
            return result

    # Test deprecation

# Generated at 2022-06-11 00:54:46.454620
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn

    # Should call the validate method of ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}

    # Check deprecations in the argument spec

# Generated at 2022-06-11 00:54:56.583055
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class MockValidationResult(ValidationResult):
        def __init__(self, parameters):
            ValidationResult.__init__(self, parameters)
            self._no_log_values = {'value1'}
            self._unsupported_parameters = set()
            self._validated_parameters = {'param1': {'value1': 'value1'}}
            self._deprecations = []
            self._warnings = []
            self.errors = AnsibleValidationErrorMultiple()
            self.errors.append(AliasError('An alias error'))

    class MockArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            ModuleArgumentSpecValidator.__init__(self, *args, **kwargs)

# Generated at 2022-06-11 00:55:28.960704
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mock_settings = {
        'mutually_exclusive': None,
        'required_together': None,
        'required_one_of': None,
        'required_if': None,
        'required_by': None
    }
    marker = object()
    fake_ArgumentSpecValidator_validate = lambda: marker
    with mock.patch.object(ArgumentSpecValidator, 'validate', fake_ArgumentSpecValidator_validate):
        with mock.patch.multiple('ansible.module_utils.common.warnings', deprecate=mock.Mock(), warn=mock.Mock()):
            validator = ModuleArgumentSpecValidator(None, **mock_settings)
            result = validator.validate(None)
            assert result is marker

            # The deprecation warning should be called twice,

# Generated at 2022-06-11 00:55:36.417123
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    errs = validator.validate(parameters).error_messages

    assert len(errs) == 0
    assert validator.validate(parameters).validated_parameters == parameters

# Generated at 2022-06-11 00:55:40.798795
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class MockModuleArgumentSpecValidator(ModuleArgumentSpecValidator):

        def __init__(self):
            super(MockModuleArgumentSpecValidator, self).__init__({"arg1": {"default": 42}})

    module_argument_spec_validator = MockModuleArgumentSpecValidator()
    assert module_argument_spec_validator is not None

# Generated at 2022-06-11 00:55:48.829893
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    validator = ModuleArgumentSpecValidator(
        {
            'valid_param': {'type': 'str'},
        },
        mutually_exclusive=[['valid_param', 'invalid_param1']],
        required_together=[['valid_param', 'invalid_param2']]
    )

    result = validator.validate({'valid_param': 'some value', 'invalid_param1': 'foo', 'invalid_param2': 'bar'})

    assert result.errors
    assert result.error_messages == [
        'invalid_param1 is mutually exclusive with valid_param',
        'invalid_param2 is required together with valid_param'
    ]

# Generated at 2022-06-11 00:55:58.265350
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo', # string to be converted to an integer
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        raise SystemExit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params == {'name': 'bo', 'age': 42}, "validated parameters don't match the expected output"

# Generated at 2022-06-11 00:56:07.916595
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'alias': {'type': 'str', 'aliases': ['alias_1'], 'deprecated': {'msg': 'Alias is deprecated', 'version': '1.2.3', 'collection_name': 'collection'}},
        'alias_2': {'type': 'str', 'aliases': ['alias_3']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'alias_2': 'test',
        'alias_3': 'test_2',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:56:16.090459
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Validate ModuleArgumentSpecValidator.validate()"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
        ['name'],
    ]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    result = validator.validate({'name': 'bo', 'age': '42'})
    assert result.error_messages == ["Either 'age' or 'name' (or both) are required"]

    result = validator.validate({'name': 'bo'})
    assert result.error_messages == []

# Generated at 2022-06-11 00:56:22.936847
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ArgumentSpecValidator(argument_spec).validate(parameters)
    assert result.validated_parameters == parameters
    assert result.validated_parameters != result.error_messages

# Generated at 2022-06-11 00:56:32.305419
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Case 1: Parameters does not have deprecations or warnings
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {
                'type': 'str',
            },
        },
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by=[]
    )
    assert None == validator.validate({'name': 'bo'})

    # Case 2: Parameters have deprecations or warnings

# Generated at 2022-06-11 00:56:42.619404
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # pylint: disable=import-error,unused-import
    from ansible.module_utils.basic import AnsibleModule

    # Create and validate valid parameter values
    argument_spec = {
        'host': {'type': 'str', 'required': True},
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True},
    }

    parameters = {
        'host': 'bo',
        'name': 'thelegend',
        'age': 42,
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'host': 'bo', 'name': 'thelegend', 'age': 42}

# Generated at 2022-06-11 00:57:37.909366
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for method validate of class ModuleArgumentSpecValidator"""
    from tests.unit.common.fixtures.mock_ansible_module import MockAnsibleModule
    from ansible.module_utils.common.parameters import (
        InvalidMutuallyExclusiveOption,
        InvalidRequiredTogetherOption,
        InvalidRequiredOneOfOption,
        InvalidRequiredUnlessError,
        InvalidRequiredWhenError,
        InvalidRequiredByOption,
        InvalidNoLogOption
    )

    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
        list_param=dict(type='list', elements='str'),
        dict_param=dict(type='dict', options=dict(
            name=dict(type='str'),
            age=dict(type='int'),
        ))
    )
    mutually