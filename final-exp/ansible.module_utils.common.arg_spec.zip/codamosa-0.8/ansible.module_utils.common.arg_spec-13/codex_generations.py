

# Generated at 2022-06-11 00:47:52.862987
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test ModuleArgumentSpecValidator.validate()"""
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'Validation failed: {0}'.format(", ".join(result.error_messages)) == 'Validation failed: age is of type str and we were unable to convert to int'



# Generated at 2022-06-11 00:48:05.155079
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.formatters import format_response
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.six import PY2

    '''
    For more details about this unit test, please visit:
    https://github.com/ansible/ansible/blob/devel/test/units/module_utils/common/arg_spec.py#L137-L322
    '''

    class NoLogError(Exception):
        """Raised when no_log is not set to a boolean."""

        def __init__(self, emsg):
            self.message = "no_log must be True or False: {0}".format(emsg)


# Generated at 2022-06-11 00:48:15.987215
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-11 00:48:27.911228
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'name': {'type': 'str'}})

    argument_spec = {}

    result = ArgumentSpecValidator(argument_spec).validate({})

    assert result.errors.messages == [u'The following parameters are required: name']
    assert result.validated_parameters == {}

    result = ArgumentSpecValidator(argument_spec).validate({'name': 'bo'})

    assert result.errors.messages == []
    assert result.validated_parameters == {'name': 'bo'}

    result = ArgumentSpecValidator(argument_spec).validate({'name': True})


# Generated at 2022-06-11 00:48:39.499934
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        "one": {
            "required": True,
            "type": "str",
        },
        "two": {
            "required": False,
            "aliases": ["to"],
            "type": "int",
        },
    }

    validator = ArgumentSpecValidator(spec)

    # Given an empty parameters dictionary
    result = validator.validate({})
    assert not result.validated_parameters
    assert result.error_messages == ['one is required']

    # Given a parameter dictionary with an invalid type
    parameters = {
        "one": "hello",
        "two": "42",
    }
    result = validator.validate(parameters)
    assert not result.validated_parameters
    assert result.error_messages == ['two must be int or str']



# Generated at 2022-06-11 00:48:47.710768
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.six import string_types

    argument_spec = {
      'name': {'type': 'str'},
      'age': {'type': 'int'},
      'data': {
        'type': 'dict',
        'options': {
          'key1': {'type': 'str'},
          'key2': {'type': 'str'},
          'key3': {'type': 'str'},
        },
      },
      'is_adult': {
        'type': 'bool',
        'aliases': ['adult'],
      },
      'food': {
        'type': 'list',
        'elements': 'str',
        'required': True,
      },
    }


# Generated at 2022-06-11 00:48:56.714982
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate() method of ModuleArgumentSpecValidator"""
    import sys

    mutually_exclusive = [ ['name', 'age'] ]
    required_one_of = [ ['name', 'age'] ]

    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        mutually_exclusive=mutually_exclusive,
        required_one_of=required_one_of,
    )

    parameters = {
        'name': 'bo',
    }

    result = validator.validate(parameters)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    assert result.validated_parameters

# Generated at 2022-06-11 00:49:08.580195
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # expected_value
    expected_result = {
        'errors': [],
        'validated_parameters': {
            'name': 'bo',
            'age': 42,
            'car': {'make': 'Honda', 'color': 'blue'},
            'phone': {'mobile': {'no': '+27 123456789', 'provider': 'Vodacom'}},
            'depts': [],
        }
    }

    # given_value

# Generated at 2022-06-11 00:49:19.963309
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test validate() method of class ModuleArgumentSpecValidator
    """
    argument_spec = {'state': {'required': True, 'aliases': ['status'], 'type': 'str'}}
    mutually_exclusive = [['state', 'status']]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)
    self = {'state': True, 'status': 'present'}
    result = validator.validate(self)
    assert result.error_messages == ['Only one of the following can be specified: state, status']

    argument_spec = {'state': {'required': True, 'type': 'str'}}
    mutually_exclusive = [['state', 'status']]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)

# Generated at 2022-06-11 00:49:20.965850
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(param_spec)
    validator.validate(valid_params)



# Generated at 2022-06-11 00:49:31.915307
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    r = validator.validate(parameters)

    assert r.error_messages == []

    assert r.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:49:32.599255
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    assert 0

# Generated at 2022-06-11 00:49:39.210086
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'name': 'bo', 'age': 42}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == [], "validation should not have generated any error messages"
    assert result.validated_parameters == parameters, "validation should not have changed the parameters"

# Generated at 2022-06-11 00:49:49.740139
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    a = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {
            'type': 'dict',
            'options': {
                'occupation': {'type': 'str'},
                'pets': {
                    'type': 'list',
                    'elements': 'str',
                },
            }
        }
    }

    b = {
        'name': 'bo',
        'age': '42',
        'state': {
            'occupation': 'A B C',
            'pets': ['Fido', 'Gizmo', '42'],
        }
    }

    validator = ArgumentSpecValidator(a)
    result = validator.validate(b)


# Generated at 2022-06-11 00:50:00.627511
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    legal_inputs = [
        ['a', 'b', 'c', 'd'],
        ['e', 'f', 'g', 'h', 'i'],
    ]


# Generated at 2022-06-11 00:50:08.661889
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    args = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    params = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(args)
    valres = validator.validate(params)
    assert valres.errors
    assert valres.error_messages[0] == 'invalid literal for int() with base 10: \'42\''

    args = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    params = {
        'name': 'bo',
        'age': 42,
    }

    valres = validator.validate(params)
    assert not valres.errors


# Generated at 2022-06-11 00:50:18.386786
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import json

    def assert_json_equal(expected, results):
        if not isinstance(expected, str):
            expected = json.dumps(expected, ensure_ascii=False)
        if not isinstance(results, str):
            results = json.dumps(results, ensure_ascii=False)
        assert expected == results

    class TestError(Exception):
        pass

    def deprecate_side_effect(msg, version=None, date=None, collection_name=None):
        raise TestError("Method deprecate should not be called")

    def warn_side_effect(msg):
        raise TestError("Method warn should not be called")

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

# Generated at 2022-06-11 00:50:30.571890
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = { 'name': { 'type': 'str' } }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    parameters = { 'name': 'bo' }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    result = validator.validate(parameters)

    assert result.validated_parameters == { 'name': 'bo' }

    assert result.errors == []
    assert result.error_messages == []

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-11 00:50:38.990807
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    ansible_module_args = {
        "test_deprecations": True,
        "test_warnings": True
    }


# Generated at 2022-06-11 00:50:46.286764
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Case where arguments are of type str
    parms = {'name': 'Foo'}
    arg_spec = dict(name=dict(type='str'))
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parms)
    assert result.validated_parameters['name'] == 'Foo'
    assert result.errors == []

    # Case where arguments are not of type str
    parms = {'name': 12}
    arg_spec = dict(name=dict(type='str'))
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parms)
    assert result.validated_parameters['name'] == 12
    assert result.errors != []

    # Case where required arguments are present

# Generated at 2022-06-11 00:51:03.945446
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Check that the various validation error conditions are returned
    """
    parameter_validation = ArgumentSpecValidator({
        'host': {'required': True, 'type': 'str'},
        'port': {'required': False, 'type': 'int', 'default': 25},
        'delay': {'required': False, 'type': 'int', 'default': 300}
    })

    # This should pass
    result = parameter_validation.validate({'host': 'localhost'})
    assert result.error_messages == []

    # This is missing a required parameter
    result = parameter_validation.validate({})
    assert result.error_messages == ['Missing required arguments: host']

    # This has a parameter that is not in the spec

# Generated at 2022-06-11 00:51:14.953096
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Set up some argument_spec to test with
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    # Set up parameters to pass to the validator
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Set up an instance of the argument spec validator
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Set up the expected result
    expected_result = {
        'name': 'bo',
        'age': 42,
    }

    # Call the validate method
    result = validator.validate(parameters)

    # Assert that the validated parameters are as expected
    assert result.validated_parameters == expected_result

    # Assert that the validated

# Generated at 2022-06-11 00:51:24.246711
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = dict(foo=dict(type='str', required=True))

    def validate(params):
        v = ArgumentSpecValidator(spec)
        return v.validate(params)

    result = validate(dict(foo=42))
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.errors[0], TypeError)
    assert not result.validated_parameters

    result = validate(dict(bar=42))
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.errors[0], TypeError)
    assert not result.validated_parameters

# Generated at 2022-06-11 00:51:36.007072
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # 1. Test case: When alias of an option is set, no warning should be thrown
    argument_spec = {
        'name': {'type': 'str', 'required': True, 'aliases': ['alias_of_name']},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    # 2. Test case: When alias of an option is set, warning should be thrown

# Generated at 2022-06-11 00:51:47.118504
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import unittest

    from ansible.module_utils.common.parameters import sanitize_keys

    class ArgumentSpecValidatorTest(unittest.TestCase):

        def test_validate_type_no_exist(self):

            argument_spec = {"name": {"type": "str"}}
            validator = ArgumentSpecValidator(argument_spec)

            # create an object result to work with
            parameters = {"no_exist":  "my value"}

            result = validator.validate(parameters)

            # assert the returned value
            self.assertEqual("my value", result.validated_parameters["no_exist"])

        def test_validate_type_str(self):

            argument_spec = {"name": {"type": "str"}}
            validator = ArgumentSpecValidator(argument_spec)

# Generated at 2022-06-11 00:51:56.860824
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)

    assert not result.errors

    assert result.error_messages is None

    assert 'name' in result.validated_parameters
    assert result.validated_parameters['name'] == 'bo'
    assert 'age' in result.validated_parameters
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:52:08.923136
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    msg_list = []
    msg_list.append("['name'] is required")
    msg_list.append("['vars'] is required")

    argument_spec = {
        'vars': {'type': 'dict'},
        'host': {'type': 'str'},
        'port': {'type': 'int'},
        'timeout': {'type': 'int', 'default': 10},
        'username': {'type': 'str'},
        'password': {'type': 'str', 'no_log': True},
        'no_log': {'type': 'bool', 'default': False},
    }
    parameters = {
        'port': '80',
        'no_log': 'True',
    }

    result = ArgumentSpecValidator(argument_spec).validate(parameters)


# Generated at 2022-06-11 00:52:14.804590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.error_messages == [])
    assert(result.validated_parameters['name'] == 'bo')
    assert(result.validated_parameters['age'] == 42)


# Generated at 2022-06-11 00:52:26.051850
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test exception handling in validate of ModuleArgumentSpecValidator
    """
    # pylint: disable=protected-access
    import pytest

    # Test exception handling
    # ArgumentSpecValidator
    params = {'foo': 'bar'}
    arguments = {'foo': {'type': 'int'}}
    validator = ArgumentSpecValidator(arguments)
    result = validator.validate(params)
    assert not result.errors

    # ModuleArgumentSpecValidator
    params = {'foo': 'bar'}
    arguments = {'foo': {'type': 'int', 'aliases': ['foo_alias']}}
    validator = ModuleArgumentSpecValidator(arguments)
    result = validator.validate(params)
    assert isinstance(result.errors[0], AliasError)

# Generated at 2022-06-11 00:52:37.321509
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.urls import fetch_url, ConnectionError
    from ansible.module_utils.basic import AnsibleModule, get_distribution, get_distribution_version
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils._text import to_native
    from ansible.module_utils.urls import open_url

    # test_argument_spec= {'name': {'type': 'str'},'age': {'type': 'int

# Generated at 2022-06-11 00:52:53.680662
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.arg_spec import AnsibleValidationErrorMultiple, MandatoryMissingError, MutuallyExclusiveError, NoLogError, RequiredError, UnsupportedError
    instance = ModuleArgumentSpecValidator(None, None, None, None, None, None)
    # Instantiate argument 'parameters'
    parameters = {}

    # Call method
    try:
        result = instance.validate(parameters)
    except Exception as e:
        msg = "Does not raise an exception."
        assert True, msg

    # Error messages should be empty
    assert not result.error_messages, "The error messages are not empty."
    # Deprecations should be empty
    assert not result._deprecations, "The deprecations are not empty."
    # Warn

# Generated at 2022-06-11 00:52:57.194947
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator_obj = ModuleArgumentSpecValidator()

    d = {}
    d['name'] = 'test'

    result = ModuleArgumentSpecValidator_obj.validate(d)

    assert result.validated_parameters == d

# Generated at 2022-06-11 00:53:02.986036
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }

    parameters = {
        'name': 'bo',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

    valid_params = result.validated_parameters

# Generated at 2022-06-11 00:53:03.477298
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:53:09.097121
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({"test2": {"type": "int",
                                               "default": 10},
                                     "test3": {"type": "str",
                                               "required": True}})
    result=v.validate({"test2": 15, "test3": "hey"})
    return result.validated_parameters, result.error_messages

# Generated at 2022-06-11 00:53:20.417128
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    parameter_type_error = "The parameters dictionary must be of type dict, " \
                           "but the provided parameters are of type"
    argument_spec_type_error = "The argument_spec must be of type dict, " \
                               "but the provided argument_spec is of type"

    # Test for parameters being None
    validator = ArgumentSpecValidator(argument_spec={})
    result = validator.validate(parameters=None)
    assert result.error_messages == [parameter_type_error + ' None']

    # Test for argument spec being None
    validator = ArgumentSpecValidator(argument_spec=None)
    result = validator.validate(parameters={})
    assert result.error_messages == [argument_spec_type_error + ' None']

    # Test for parameters being list instead of dict

# Generated at 2022-06-11 00:53:30.664874
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ##############################
    # ModuleArgumentSpecValidator.validate()
    ##############################
    from ansible.module_utils import basic
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys
    from collections import namedtuple

    class FakeAnsibleModule:
        case_sensitive = True
        no_log = False
        check_invalid_arguments = False
        mutually_exclusive = None
        required_together = None
        required_one_of = None
        required_if = None
        required_by = None
        add_file_common_args = False
        tags = set()
        supports_check_mode = False
        required_if_exclude = None


# Generated at 2022-06-11 00:53:35.813931
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'option': {'type': 'str'}})
    parameters = {'option': 'value'}
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters

# Generated at 2022-06-11 00:53:46.339910
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import datetime
    today = datetime.date.today()
    def validate_test(parameters,validation_result):
        test_validator = ModuleArgumentSpecValidator({},[],[[['a','b']]],[[['a','b']]],[[['a','b']]],[[['a','b']]])
        test_result = test_validator.validate(parameters)
        assert test_result.error_messages == validation_result

# Generated at 2022-06-11 00:53:49.819723
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'test': {'type': 'str'}})
    result = validator.validate({'test': 'test'})
    assert result.errors == []


# Generated at 2022-06-11 00:54:02.182602
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    path = 'ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator.validate'

    with patch(path) as mocked_validate:
        instance = ModuleArgumentSpecValidator()
        instance.validate({})

        mocked_validate.assert_called_once_with({})


# Generated at 2022-06-11 00:54:09.462389
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})

    parameters = {
        'foo': {'alias': 'bar', 'version_added': '2.2'},
        'bar': 'baz',
    }

    result = validator.validate(parameters)
    assert not result.errors
    valid_params = result.validated_parameters
    assert set(valid_params.keys()) == set(('foo', 'bar'))
    valid_params['foo'] == 'baz'
    valid_params['bar'] == 'baz'

# Generated at 2022-06-11 00:54:11.886235
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    moduleArgumentSpecValidator = ModuleArgumentSpecValidator({})
    assert not moduleArgumentSpecValidator.validate({})

# Generated at 2022-06-11 00:54:21.317335
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''Validate that the validate method of ModuleArgumentSpecValidator is properly called and works as expected.'''
    with patch.object(ModuleArgumentSpecValidator, '__init__') as ModuleArgumentSpecValidator__init__:
        # Create a mock of ArgumentSpecValidator.validate (it is called by ModuleArgumentSpecValidator.validate)
        with patch.object(ArgumentSpecValidator, 'validate') as ArgumentSpecValidator_validate:
            # Create a mock of ArgumentSpecValidator.validate's return value (a ValidationResult)
            ValidationResult_mock = MagicMock(spec=ValidationResult)
            ArgumentSpecValidator_validate.return_value = ValidationResult_mock
            argument_spec = 'argument_spec'
            instance = ModuleArgumentSpecValidator(argument_spec)


# Generated at 2022-06-11 00:54:31.413072
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import warn

    import warnings
    warnings.simplefilter('dummy')

    argument_spec = {
        'name': {'type': 'str', 'aliases': ['user']},
        'age': {'type': 'int', 'aliases': ['count']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []

# Generated at 2022-06-11 00:54:36.883504
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    # validate()
    result = validator.validate(parameters)
    assert not result.error_messages

# Generated at 2022-06-11 00:54:46.873099
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    p1 = dict(
        name='bo',
        age=42,
        lol=True,
        is_admin=True
    )

    spec = dict(
        name=dict(type='str',),
        age=dict(type='int',),
        lol=dict(type='bool',),
        is_admin=dict(type='bool', defaults='no'),
        income=dict(type='int', default='1000000')
    )

    p2 = dict(
        name='bo',
        age=42,
        lol=True,
        is_admin='yes',
        income='1000000',
    )

    assert ArgumentSpecValidator(spec).validate(p1).validated_parameters == p2

# Generated at 2022-06-11 00:54:56.982200
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit tests for class ArgumentSpecValidator, method validate """

    # pylint: disable=redefined-outer-name

    # Arguments of the test

# Generated at 2022-06-11 00:55:06.030238
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test validate method of class ModuleArgumentSpecValidator
    """

    ##
    # Setup
    ##
    # Construct argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Build parameters
    parameters = {
        'name': 'test',
        'age': '42',
    }

    ##
    # Test
    ##
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.error_messages == [])
    assert(result.validated_parameters == {'age': 42, 'name': 'test'})

# Generated at 2022-06-11 00:55:16.965192
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {
            'type': 'str',
            'required': True,
            'aliases': ['Name']
        },
        'age': {
            'type': 'int',
            'required': True,
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert not result._deprecations
    assert not result._warnings
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.unsupported_parameters

# Generated at 2022-06-11 00:55:42.147203
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    import datetime
    import sys
    import os
    import tempfile

    ##############################################################################
    # Test utils

    def create_file_with_content(content):
        fd, path = tempfile.mkstemp()
        f = os.fdopen(fd, 'w')
        f.write(to_bytes(content))
        f.close()
        return path

    def remove_file_if_exists(path):
        if os.path.isfile(path):
            os.remove(path)

    def remove_dir_if_exists(path):
        if os.path.isdir(path):
            os.rmdir(path)


# Generated at 2022-06-11 00:55:50.201817
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "foo": {"type": "str", "aliases": ["alias_foo"]},
        "bar": {"type": "str", "aliases": ["alias_bar"]},
        "baz": {
            "type": "dict",
            "options": {
                "baz1": {"type": "str", "aliases": ["alias_baz1"]},
                "baz2": {"type": "str", "aliases": ["alias_baz2"]},
            }
        }
    }


# Generated at 2022-06-11 00:56:01.164831
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    assert valid_params['name'] is 'bo'
    assert valid_params['age'] is 42

# Generated at 2022-06-11 00:56:07.729265
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Instantiate object ArgumentSpecValidator
    argument_spec_validator = ArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    # Validate parameters against spec
    result = argument_spec_validator.validate(parameters={
        'name': 'bo',
        'age': '42',
    })

    # Assert that validation succeeded
    assert not result.error_messages, result.error_messages

# Generated at 2022-06-11 00:56:09.839312
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test: method validate of class ModuleArgumentSpecValidator"""
    validator = ModuleArgumentSpecValidator({})
    result = validator.validate({})
    assert result == None

# Generated at 2022-06-11 00:56:16.091479
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.collections import ImmutableDict

    # Setup
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Test
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Verify
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-11 00:56:26.607156
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestmoduleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(TestmoduleArgumentSpecValidator, self).__init__(*args, **kwargs)

            self.argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    testmodule_argument_spec_validator = TestmoduleArgumentSpecValidator()
    result = testmodule_argument_spec_validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:56:34.527542
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestModuleArgumentSpecValidator_validate():
        def __init__(self):
            self.warn_count = 0
            self.deprecate_count = 0
            self.expected_aliases = set()

        def warn(self, str):
            if 'Both option {option} and its alias {alias} are set.'.format(option=w['option'], alias=w['alias']) in str:
                self.warn_count += 1
            else:
                raise ValueError('An unexpected warning message has been issued {}'.format(str))

        def deprecate(self, str, **kwargs):
            for k in kwargs:
                alias = 'Alias \'{name}\' is deprecated'.format(name=k)
                if alias in str:
                    self.expected_aliases.add(k)
                    self

# Generated at 2022-06-11 00:56:46.353208
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    mock_ArgumentSpecValidator_instances = [MagicMock(), MagicMock()]
    mock_argspec_validator = mock_ArgumentSpecValidator_instances[0]
    module_args = {
        'name': 'test',
        'age': 42
    }

    # Test
    test_inst = ModuleArgumentSpecValidator( {'name': {'type': 'str', 'aliases': ['test_str']}, 'age': {'type': 'int'}},
                                             ['name', 'age'],
                                             [['name', 'age']],
                                             [['name', 'age']],
                                             [['name', 42, 'age']]
                                           )
    result = test_inst.validate(module_args)

    # Verify

# Generated at 2022-06-11 00:56:48.942722
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator.validate('argument_spec', 'parameters')
    assert isinstance(result, ValidationResult)
