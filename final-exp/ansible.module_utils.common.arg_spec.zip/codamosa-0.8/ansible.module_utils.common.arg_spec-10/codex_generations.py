

# Generated at 2022-06-11 00:47:51.919023
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Example test input
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # calling the method validate from class ModuleArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    # checking if result has the expected properties

# Generated at 2022-06-11 00:48:03.667094
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    def _check_valid_arguments_and_deprecation(data):
        argument_spec = data.get('argument_spec')
        mutually_exclusive = data.get('mutually_exclusive')
        required_together = data.get('required_together')
        required_one_of = data.get('required_one_of')
        required_if = data.get('required_if')
        required_by = data.get('required_by')
        parameters = data.get('parameters')
        expected_result = data.get('expected_result')

        validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

        result = validator.validate(parameters)


# Generated at 2022-06-11 00:48:14.692200
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg_spec = dict(
        foo=dict(type='str', aliases=['foozle']),
        option1=dict(type='bool'),
        option2=dict(type='bool'),
        baz=dict(type='dict', bar=dict(type='str')),
    )

    params = dict(
        foo='test',
        option1=True,
        option2=False,
        baz=dict(sub=dict(subsub='test')),
    )

    v = ModuleArgumentSpecValidator(arg_spec=arg_spec, required_one_of=[['option1', 'option2']])
    result = v.validate(deepcopy(params))

    assert not result.errors
    assert result.validated_parameters == params

# Generated at 2022-06-11 00:48:26.026531
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator as ASV
    from ansible.module_utils.common.validation import check_mutually_exclusive as CMEx
    from ansible.module_utils.common.validation import check_required_arguments as CRA
    from ansible.module_utils.common.validation import check_required_one_of as CRO
    from ansible.module_utils.common.validation import check_required_together as CRT
    from ansible.module_utils.common.validation import check_required_if as CRIf

    patcher = patch.multiple(ASV,
                             check_mutually_exclusive=DEFAULT,
                             check_required_arguments=DEFAULT)

    patcher2 = patch.multiple(CMEx, DEFAULT=DEFAULT)
   

# Generated at 2022-06-11 00:48:38.123543
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible_collections.ntcnetmiko.ntcnetmiko.plugins.module_utils.network.ntcnetmiko.arg_spec import ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'description': {'type': 'str', 'no_log': True},
        'secret': {'type': 'str', 'no_log': True},
        'networks': {'type': 'list'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'description': 'test',
        'secret': 'test',
        'networks': ['1.2.3.4/24', '2.3.4.5/28'],
    }

# Generated at 2022-06-11 00:48:42.103848
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Method that performs unit tests for ModuleArgumentSpecValidator.validate()."""
    argument_spec_validator = ModuleArgumentSpecValidator(
        {},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={},
    )
    validated_parameters = argument_spec_validator.validate({})
    assert validated_parameters.validated_parameters == {}

# Generated at 2022-06-11 00:48:46.476847
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Parameters
    argument_spec = {
        'name': {
            'aliases': ['alias'],
            'type': 'str'
        }
    }

    parameters = {
        'name': 'bo',
        'alias': 'bo',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(parameters)

# Generated at 2022-06-11 00:48:55.257892
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = dict(
        name = dict(type = 'str'),
        age = dict(type = 'int'),
        bad_argument = dict(type = 'str')
    )
    validator = ModuleArgumentSpecValidator(argument_spec = parameters)
    result = validator.validate({'name': 'bo', 'age': '42', 'bad_argument': 'foo'})
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors[-1].method == result.errors[-1].__class__.__name__
    assert result.errors[-1].message == "bad_argument. Supported parameters include: name (aliases: full_name), age."

# Generated at 2022-06-11 00:49:07.262645
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # missing parameter
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 1
    assert result.error_messages[0] == 'age is required'

    # wrong type
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = valid

# Generated at 2022-06-11 00:49:09.411334
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validate = ModuleArgumentSpecValidator()
    validate.validate(dict(name='bo', age='42'))

# Generated at 2022-06-11 00:49:24.456953
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {'type': 'dict', 'options': {
            'street': {'type': 'str'},
            'number': {'type': 'int'}
        }},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'address'], ['address', 'age']]
    required_one_of = [['name', 'address', 'age']]
    required_if = [['name', 'joe', ['address']]]
    required_by = {'name': ['address']}

    # Tests required_by
    parameters = {
        'password': '$^*($&(##@',
    }



# Generated at 2022-06-11 00:49:27.427397
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {"name": {"type": "str"}}
    parameters = {}
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(parameters)

# Generated at 2022-06-11 00:49:38.211741
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:49:47.524808
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    NoLogError_msg = 'Incorrect argument specification in module. One or more arguments have no_log specified as a type.'

    def run_test(self, spec, params, expected_result):
        result = super(ModuleArgumentSpecValidator, self).validate(spec, params)

        if isinstance(expected_result, Exception):
            assert isinstance(result.errors[0], type(expected_result))
        else:
            assert result.error_messages == expected_result

    test_parameters = {
        'age': '42',
        'name': 'bo',
        'answer': 42,
        'tom': True,
        'sue': False,
        'foo': 'bar',
        'baz': None,
        'nonedefault': None,
    }


# Generated at 2022-06-11 00:49:56.128107
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:50:01.826923
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)
    assert result == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:50:09.492618
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def test_parameters():
        yield {'name': 'Ham', 'age': 42}
        yield {'name': 'Ham', 'age': '42'}

    def test_spec():
        yield {'name': {'type': 'str'}, 'age': {'type': 'int'}}
        yield {'name': {'type': 'str'}, 'age': {'type': 'str', 'aliases': ['old']}}

    for spec in test_spec():
        for parameters in test_parameters():
            for deprecation in (True, False):
                validator = ModuleArgumentSpecValidator(spec)
                result = validator.validate(parameters)
                assert not result.errors
                assert result.validated_parameters == {'name': 'Ham', 'age': 42}



# Generated at 2022-06-11 00:50:18.834932
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    validated_result = validator.validate(parameters)
    assert validated_result.error_messages == []
    assert validated_result.validated_parameters == {'name': 'bo', 'age': 42}
    assert validated_result._no_log_values == set()
    assert validated_result._unsupported_parameters == set()
    assert validated_result._deprecations == []
    assert validated_result._warnings == []


if __name__ == '__main__':
    test_ArgumentSpecValid

# Generated at 2022-06-11 00:50:22.099819
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test that ModuleArgumentSpecValidator.validate is tested via
    test_common_arg_spec.py::test_sanitizing_argument_spec_validation
    :return:
    """

# Generated at 2022-06-11 00:50:31.554951
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'test1': {'type': 'int', 'no_log': True},
        'test2': {'type': 'bool'},
        'test3': {'type': 'int', 'required': True},
        'test4': {'type': 'bool'},
        'test5': {'type': 'str', 'required': True}
    }

    parameters = {
        'test1': '1234',
        'test2': 'true',
        'test3': '1234'    
    }

    ModuleArgumentSpecValidator(argument_spec).validate(parameters)

# Generated at 2022-06-11 00:50:46.454845
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    #Case with deprecation
    argument_spec = {
        "param1": {"type": "str", "aliases": ["param1_alias"]}
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    parameters = {"param1_alias": "test"}
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {"param1": "test"}

    #Case with warnings

# Generated at 2022-06-11 00:50:55.789378
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate method of ArgumentSpecValidator class."""

    # case 1: test on an empty spec and arg
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive,
                                      required_together, required_one_of,
                                      required_if, required_by)
    parameters = {}
    result = validator.validate(parameters)
    assert result.errors == []
    assert result.validated_parameters == {}


    # case 2: test on an empty spec and a non-empty arg
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None


# Generated at 2022-06-11 00:51:04.412766
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={})
    parameters = {'deprecated': 'test_deprecated',
                  'alias_warnings': 'test_alias_warnings'}
    val_result = validator.validate({'deprecated': 'test_deprecated',
                                     'alias_warnings': 'test_alias_warnings'})
    assert val_result.validated_parameters.get('deprecated') == 'test_deprecated'
    assert val_result.validated_parameters.get('alias_warnings') == 'test_alias_warnings'

# Generated at 2022-06-11 00:51:15.519617
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestModule:
        def __init__(self):
            self.deprecations = []
            self.warnings = []

        def deprecate(self, msg, version=None, date=None, collection_name=None):
            self.deprecations.append((msg, version, date, collection_name))

        def warn(self, msg):
            self.warnings.append(msg)

    module_ = TestModule()
    # test1
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nam']},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-11 00:51:26.276702
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # basic ArgumentSpecValidator validation
    argument_spec = {
        'name': {
            'required': True,
            'type': 'str'
        },
        'age': {
            'type': 'int'
        },
        'state': {
            'type': 'list',
            'choices': ['present', 'absent']
        },
        'nested_list': {
            'type': 'list',
            'default': None,
            'elements': 'dict',
            'options': {
                'key': {'type': 'str'},
                'value': {'type': 'int'},
            }
        },
    }
    parameters = {
        'name': 'bo',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate

# Generated at 2022-06-11 00:51:38.261658
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import pytest

    # TODO: Should probably create a more generic class of which
    # ValidationResult is an instance.
    class MockResult(object):
        def __init__(self, result):
            self._validated_parameters = result

    def mock_validator_result(result):
        mock_validator_result.results.append(result)
        return MockResult(result)

    # TODO: Should this be a class?

# Generated at 2022-06-11 00:51:40.163848
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})

# Generated at 2022-06-11 00:51:40.819206
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:51:48.856010
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )

    parameters = dict(
        name='bo',
        age='42',
    )

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-11 00:52:00.342657
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class ExceptionWarning(Exception):
        pass

    def deprecate(msg, **kwargs):
        if "Deprecation" in msg:
            raise ExceptionWarning(msg)

    def warn(msg):
        raise ExceptionWarning(msg)

    original_warn = warn
    original_deprecate = deprecate
    original_aliases = _handle_aliases

# Generated at 2022-06-11 00:52:16.047242
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hobbies': {'type': 'list'},
        'pets': {'type': 'dict'},
        'hungry': {'type': 'bool'},
        'gender': {'type': 'bool'},
        'married': {'type': 'dict'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name']]]
    required_by = {'name': ['age', 'gender']}


# Generated at 2022-06-11 00:52:27.132352
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import unittest.mock as mock
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import MODULE_COMPLEX_ARGS
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    basic_argument_spec = {
        'argument': {
            'type': 'str',
            'default': 'default',
        },
    }


# Generated at 2022-06-11 00:52:38.431565
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    #
    # Intialize ArgumentSpecValidator
    #

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    #
    # Test validator.validate
    #

    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-11 00:52:49.090122
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'list',
            'elements': 'str',
            'aliases': ['name_alias'],  # alias_warnings is a list
            'default': [1, 2, 3]
        },
        'age': {'type': 'int', 'default': 'test'},  # RequiredDefaultError, alias_deprecations is a list
        'gender': {'type': 'str', 'no_log': True},  # list_no_log_values
        'deprecation': {'type': 'str', 'deprecated': 'deprecation_message'},  # deprecations is a list
    }
    parameters = {
        'name_alias': ['a'],
        'age': 'test'
    }
    validator = ModuleArgumentSpec

# Generated at 2022-06-11 00:53:00.011381
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "name": {
            "type": "str",
            "required": True,
            "default": "foobar"
        },
        "age": {
            "type": "int",
            "required": True,
        },
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate({'name': 'bo', 'age': '42'})
    assert result._validated_parameters == {'name': 'bo', 'age': 42}

    result = validator.validate({'name': 'bo', 'age': '42', 'invalid_param': 'bad'})
    assert result._validated_parameters == {'name': 'bo', 'age': 42}
    assert len(result.errors) == 1

# Generated at 2022-06-11 00:53:07.710109
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    def run_module():
        argument_spec = dict(
            debug=dict(type='bool', default=True),
        )
        mutually_exclusive = [['debug', 'verbose']]
        required_together = [['debug', 'verbose']]
        required_one_of = [['debug', 'verbose']]
        required_if = [['debug', True, ['verbose']]]
        required_by = dict(debug='verbose', verbose='debug')


# Generated at 2022-06-11 00:53:19.436161
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    VALID_PARAMETERS = {
        'name': 'bo',
        'age': 42
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(VALID_PARAMETERS)

    assert result.validated_parameters == VALID_PARAMETERS
    assert len(result.error_messages) == 0

    INVALID_PARAMETERS = {
        'name': 'bo',
        'age': '42'
    }

    result = validator.validate(INVALID_PARAMETERS)

    assert len(result.errors) == 1

# Generated at 2022-06-11 00:53:29.988511
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.warnings import _warnings

# Generated at 2022-06-11 00:53:36.040630
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    def deprecate(msg, **kwargs):
        assert msg == "Alias 'name' is deprecated. See the module docs for more information"
        assert kwargs == {}

    def warn(msg):
        assert msg == "Both option name and its alias age are set."

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=None,
                                            required_together=None,
                                            required_one_of=None,
                                            required_if=None,
                                            required_by=None
                                            )
    #

# Generated at 2022-06-11 00:53:46.559772
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Empty argument spec
    ArgumentSpecValidator({})
    # Non-empty argument spec
    ArgumentSpecValidator({"foo": {"type": "int"}})
    # Required mutually_exclusive is None
    a = ArgumentSpecValidator({}, mutually_exclusive=None)
    assert a._mutually_exclusive is None
    # Required mutually_exclusive is non-None
    a = ArgumentSpecValidator({}, mutually_exclusive=[[("age", "num")]])
    assert a._mutually_exclusive == [[("age", "num")]]
    # Required required_together is None
    a = ArgumentSpecValidator({}, required_together=None)
    assert a._required_together is None
    # Required required_together is non-None
    a = ArgumentSpecValidator({}, required_together=[['age', 'num']])
    assert a

# Generated at 2022-06-11 00:54:00.913495
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    from ansible.module_utils.common.warnings import MissingValidationWarning
    from ansible.module_utils.common.validation import ValidationFail
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    # create the argument spec to be used for validation
    argument_spec = {
      'src': {'required': False, 'type': 'str'},
      'dst': {'required': True, 'type': 'str'},
      'dest': {'type': 'str', 'aliases': ['dst']},
      'recursive': {'required': False, 'type': 'bool'},
      'param': {'required': False, 'type': 'int'}
    }
    # create the parameter dict to be used for validation
    parameters

# Generated at 2022-06-11 00:54:11.739787
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str', 'deprecated': {'msg': 'This is deprecated',
                                                                                       'version': '2.0',
                                                                                       'date': '2020-10-01'}}},
                                            required_by={'name': []})
    result = validator.validate({'name': 'bo'})
    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'name'
    assert result._deprecations[0]['version'] == '2.0'
    assert result._deprecations[0]['date'] == '2020-10-01'
    assert result._deprecations[0]['collection_name'] is None

# Generated at 2022-06-11 00:54:19.490888
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Sets up a mock argspec and verifies that
    """
    # create a spec and a hash
    argspec = {
        'name': {'required': True, 'type': 'str'},
        'age': {'required': False, 'type': 'str'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argspec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert result.errors == []

# Generated at 2022-06-11 00:54:29.760548
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    mut_exc = [['user', 'password'], ['user', 'login_password'], ['user', 'login_token']]
    req_if = [['state', 'present', ['login_password']], ['state', 'absent', ['login_password']]]
    req_by = {'login_password': ['user'], 'login_token': ['user']}

# Generated at 2022-06-11 00:54:39.072061
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test if the warn method is called
    """
    module_arguments = {'space': '42', 'fleet': '1337'}
    module_argument_spec = {
        'space': dict(type='str'),
        'fleet': dict(type='str'),
        'aliases': dict(type='str'),
    }
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        # Cause all warnings to always be triggered.
        result = ModuleArgumentSpecValidator(module_argument_spec).validate(module_arguments)

        # Test if the warn method is called
        assert len(w) == 1

        # Test if the alias that is used is the correct one.

# Generated at 2022-06-11 00:54:50.038380
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test for constructor of ArgumentSpecValidator"""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "kevin", ["age"]]]
    required_by = {
        "name": ["age"],
        "age": ["name"]
        }

    # Constructor

# Generated at 2022-06-11 00:54:59.361264
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.basic import AnsibleModule
    import os

    argument_spec= dict(
        name=dict(type='str', required=True),
        age=dict(type='int'),
        sex=dict(type='str', required=True, choices=['Male', 'Female']),
        married=dict(type='bool'),
        height=dict(type='float'),
        weight=dict(type='bool')
    )


    parameters=dict(
        name="Bob",
        age="42",
        sex="Male",
        married="yes",
        height="6.0",
        weight="False"
    )

    module_name = os.path.basename(__file__)
    module_args = {}
    for key, value in parameters.items():
        module_args[key]

# Generated at 2022-06-11 00:55:07.977337
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mav = ModuleArgumentSpecValidator({'test': {'type': 'dict', 'default': {}, 'aliases': ['foo']}},)
    mav.validate({'test': {'val': 'bar'}, 'foo': {'val': 'foo'}})
    mav.validate({'test': {'val': 'bar'}, 'foo': {'val': 'foo'}})
    mav.validate({'test': {'val': 'bar'}, 'foo': {'val': 'foo'}})
    print('test_ModuleArgumentSpecValidator_validate')

test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-11 00:55:14.815480
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'assume': {'type': 'bool'}}
    mutually_exclusive = [['insert', 'overwrite']]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert hasattr(validator, 'argument_spec')
    assert validator.argument_spec == argument_spec
    assert hasattr(validator, '_mutually_exclusive')
    assert validator._mutually_exclusive == mutually_exclusive

# Generated at 2022-06-11 00:55:25.289695
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    param = {
        'size': 'gib',
        'name': 'bo',
        'age': '42',
        'depth': 'other'
    }
    argument_spec = {
        'size': {'type': 'str', 'choices': ['gib', 'mib']},
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'depth': {'type': 'str', 'default': 'gib'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(param)
    #assert result.error_messages == "Value 'gib' is not valid for parameter size. Valid options: ['mib', 'gib']", "Expecting message 'Value 'gib' is not valid for parameter size

# Generated at 2022-06-11 00:55:47.315361
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  from ansible.module_utils.common.collections import is_sequence

  validator = ModuleArgumentSpecValidator({"foo": {"type": "str"}, "bar": {"type": "str"}})

  result = validator.validate({"foo": "foo_value"})
  assert isinstance(result.error_messages, list)
  assert len(result.error_messages) == 0
  assert isinstance(result.unsupported_parameters, set)
  assert len(result.unsupported_parameters) == 0
  assert isinstance(result.validated_parameters, dict)
  assert len(result.validated_parameters) == 1
  assert isinstance(result.validated_parameters["foo"], str)
  assert result.validated_parameters["foo"] == "foo_value"

  valid

# Generated at 2022-06-11 00:55:47.841186
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:55:58.179502
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({"test_key": {"type": "str", "aliases": ["test_alias"]}})
    assert v.validate({"test_key": "test_value"}).validated_parameters == {"test_key": "test_value"}
    assert v.validate({"test_alias": "test_value"}).validated_parameters == {"test_key": "test_value"}
    assert v.validate({"test_alias": "test_value", "test_key": "test_value"}).validated_parameters == {"test_key": "test_value"}


# Generated at 2022-06-11 00:56:06.293813
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test ModuleArgumentSpecValidator.validate()"""

    argument_spec = dict(name=dict(type='str'),
                         age=dict(type='int'),
                         )

    parameters = dict(name='bo',
                      age=42,
                      )

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result._warnings == []
    assert result._deprecations == []
    assert result.error_messages == []


# Generated at 2022-06-11 00:56:12.342681
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test data
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    expected_validated_parameters = {
        'name': 'bo',
        'age': 42,
    }
    # Test
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == expected_validated_parameters

# Generated at 2022-06-11 00:56:16.112500
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    with pytest.raises(TypeError) as e:
        ModuleArgumentSpecValidator().validate()
    assert e.value.args[0] == "validate() missing 1 required positional argument: 'parameters'"

    with pytest.raises(TypeError) as e:
        ModuleArgumentSpecValidator().validate('parameters', 'another_parameters')
    assert e.value.args[0] == "validate() takes 1 positional argument but 2 were given"

# Generated at 2022-06-11 00:56:27.586949
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
        ['name'],
    ]
    required_if = [
        ['name', 'age', ['name']],
    ]
    required_by = {
        'name': ['age', 'age'],
    }

    parameters = {
        'name': 'bo',
    }

# Generated at 2022-06-11 00:56:34.614744
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'date': {'type': 'datetime', 'subspec': {'format': '%m/%d/%Y'}},
        'str_list': {'type': 'list', 'subspec': {'type': 'str'}},
        'int_list': {'type': 'list', 'subspec': {'type': 'int'}},
        'bool_list': {'type': 'list', 'subspec': {'type': 'bool'}},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-11 00:56:46.341189
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator.

    It verifies that warnings are printed for alias and also deprecation warnings are printed.
    """

    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings


# Generated at 2022-06-11 00:56:55.683256
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    # testing parameter validation
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.error_messages == ['foo is required']

    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)
    assert not result.error_messages


# Generated at 2022-06-11 00:57:32.778264
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'job': {'type': 'str', 'default': 'engineer'},
        'home': {'type': 'str'},
        'children': {
            'type': 'list', 'elements': 'str'},
        'address': {
            'type': 'dict',
            'options': {
                'line1': {'type': 'str'},
                'line2': {'type': 'str'},
                'zip': {'type': 'str'},
                'town': {'type': 'str', 'default': 'Nowhere'}
                }
            }
        }
