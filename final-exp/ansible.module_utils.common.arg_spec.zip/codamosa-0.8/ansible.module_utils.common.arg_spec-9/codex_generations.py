

# Generated at 2022-06-11 00:47:47.396904
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arguments_spec = {}
    validator = ArgumentSpecValidator(arguments_spec)
    assert hasattr(validator, 'argument_spec')
    assert hasattr(validator, '_valid_parameter_names')
    assert not validator._valid_parameter_names
    assert arguments_spec == validator.argument_spec


# Generated at 2022-06-11 00:47:51.904045
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator is not None
    assert argument_spec == validator.argument_spec


# Generated at 2022-06-11 00:48:03.725407
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockModuleAnsibleModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            pass

        def deprecated(self, msg, date=None, version=None, collection_name=None):
            pass

        def no_log_values(self, value):
            pass

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None, required_one_of=None,
                     required_if=None):
            super(TestModuleArgumentSpecValidator, self).__init__(argument_spec, mutually_exclusive,
                                                                  required_together, required_one_of, required_if)


# Generated at 2022-06-11 00:48:04.672502
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:48:15.574303
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    @patch.object(ArgumentSpecValidator, 'validate')
    def test_validate(self, mocked_validate, *args, **kwargs):
        mocked_validate.return_value = None
        ModuleArgumentSpecValidator.validate("self", "parameters")
        mocked_validate.assert_called_with("self", "parameters")

    @patch("ansible.module_utils.common.warnings.warn")
    @patch("ansible.module_utils.common.warnings.deprecate")
    def test__warnings_deprecations(self, mocked_deprecate, mocked_warn, *args, **kwargs):
        result = Mock()

# Generated at 2022-06-11 00:48:23.884646
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test with deprecations
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str', 'aliases': ['myname']},
            'age':  {'type': 'int'},
        },
    )

    result = validator.validate(dict(name='bo', age='42'))

    assert result.validated_parameters == dict(name='bo', age=42)
    assert result.error_messages == []
    assert result._deprecations == [dict(name='myname')]

# Generated at 2022-06-11 00:48:35.928692
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleFallbackNotFoundError

    mvs = [
        ["type"], ["version"]
    ]

    results = []

    argument_spec = {
        "type": {"required": True, "type": "str"},
        "version": {"default": "2"},
    }

    ds = [{'type': 'test', 'version': '2'}, {'type': 'test', 'version': '2'}, {'type': 'test', 'version': '2'}, {'type': 'test', 'version': '2'}]

    class MockAnsibleModule:

        def __init__(self, d):
            self.basic_safe_params = d
            self.params = d


# Generated at 2022-06-11 00:48:40.931811
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import (
        sanitize_keys,
        sanitize_values,
    )
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # check if the result object is valid
    assert result.error_messages == []
    assert isinstance(result.validated_parameters, dict)
    assert set(result.validated_parameters.keys()) == set(['name', 'age'])

# Generated at 2022-06-11 00:48:47.645721
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {"test_key1": {"type": "int"}, "test_key2": {"type": "int"}}
    mutually_exclusive = None
    required_together = [["test_key1", "test_key2"]]
    required_one_of = None
    required_if = None
    required_by = None
    parameters = {}
    expected_errors = [
        RequiredError('At least one of the following is required: test_key1, test_key2')]


# Generated at 2022-06-11 00:48:54.516979
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'aliases': ['alias'],
            'type': 'str'},
        'age': {
            'type': 'int'}}

    parameters = {
        'name': 'bo',
        'age': '42',
        'alias': 'Koko'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-11 00:49:08.579447
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator('argument_spec',
                                         mutually_exclusive=None,
                                         required_together=None,
                                         required_one_of=None,
                                         required_if=None,
                                         required_by=None,
                                         ).validate('parameters')
    assert result is not None

# Generated at 2022-06-11 00:49:16.934779
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 1
    assert result.errors[0].message.startswith('parameter age is of type <int> but the provided value is of type <str>')



# Generated at 2022-06-11 00:49:25.171340
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types
    import json
    import sys


# Generated at 2022-06-11 00:49:36.036690
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json
    import pytest

    from ansible.module_utils.common.arg_spec import (
        DEFAULT_ARGUMENT_SPEC,
        ModuleArgumentSpecValidator,
    )

    from ansible.module_utils.common.parameters import sanitize_keys

    # Some test preparation
    argument_spec = DEFAULT_ARGUMENT_SPEC.copy()


# Generated at 2022-06-11 00:49:36.642752
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:49:44.183948
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import StringIO

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    # Capture stderr temporarily in a StringIO object
    real_stderr = sys.stderr
    out = StringIO.StringIO()
    sys.stderr = out

    # Run the actual method to be tested
    result = validator.validate(parameters)

    # Restore stderr
    sys.stderr = real_stderr

    # Get the output
    out.seek(0)
    output = out.read()

    # Check the

# Generated at 2022-06-11 00:49:56.180631
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
        'color': 'blue',
        'aliased': 'value'
    }

    d = {
        'name': dict(type='str'),
        'age': dict(type='int'),
        'color': dict(type='str', default='red'),
        'color2': dict(type='str', default='red'),
        'aliased': dict(type='str', aliases=['aliased2']),
        'state': dict(type='str', choices=['present', 'absent'])
    }

    m = {'color': ['color2']}
    r = ['color']
    o = ['state']


# Generated at 2022-06-11 00:50:05.604410
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.text.converters import to_native, to_text
    from ansible.module_utils.common.warnings import WarningsError, AnsibleWarning

# Generated at 2022-06-11 00:50:15.869815
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # should raise UserWarning with 'Both option option and its alias alias are set.' 
    msv = ModuleArgumentSpecValidator({
        'option': {'aliases': ['alias']},
    })
    msv.validate({'option': 'value', 'alias': 'value'})

    # should raise DeprecationWarning with 'Alias "alias" is deprecated.
    msv = ModuleArgumentSpecValidator({
        'option': {'aliases': ['alias'], 'deprecated': {'version': '3.11', 'date': '2020-11-22'}},
    })
    msv.validate({'option': 'value'})
    msv.validate({'option': 'value', 'alias': 'value'})

# Generated at 2022-06-11 00:50:27.600631
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'str'},
                     'b': {'type': 'str'}, 'c': {'type': 'str'},
                     'd': {'type': 'str'}}
    mutually_exclusive = [['a', 'b', 'c'], ['b', 'c']]
    required_one_of = [['a', 'b', 'c']]
    required_together = [['b', 'd']]
    required_by = {'b': ['a']}
    required_if = [('b', 'yes', ['a'])]

    parameters = {'a': 'yes', 'b': 'yes', 'c': 'yes'}


# Generated at 2022-06-11 00:50:39.617234
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'no_log': False},
        'age': {'type': 'int', 'no_log': True},
    }
    param = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(param)
    assert not result.error_messages, "AnsibleValidationErrorMultiple should be empty: {0}".format(result.error_messages)
    assert result.unsupported_parameters == {}, "unsupported_parameters should be empty: {0}".format(
        result.unsupported_parameters)

# Generated at 2022-06-11 00:50:44.133784
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:50:53.934562
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec={
        'name': {
            'required': True,
            'type': 'str',
            'aliases': ['first_name'],
        },
        'age': {
            'required': True,
            'type': 'int',
        },
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert 'name' in result.validated_parameters
    assert 'age' in result.validated_parameters
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []

# Generated at 2022-06-11 00:51:03.677531
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Make sure that alias deprecations and warnings are emitted during validation

    v = ModuleArgumentSpecValidator(argument_spec={
        'a': {'type': 'str', 'aliases': ['c']},
        'b': {'type': 'str', 'aliases': ['d']},
        'x': {'type': 'str'},
    })
    result = v.validate({'a': 'testvalue', 'b': 'testvalue', 'c': 'testvalue', 'd': 'testvalue', 'x': 'testvalue'})
    assert len(result._deprecations) == 2
    assert len(result._warnings) == 2



# Generated at 2022-06-11 00:51:14.746028
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_required_one_of
    from ansible.module_utils.basic import AnsibleModule

    # case 1: mutually exclusive
    argument_spec = dict(
        test=dict(type='int', mutually_exclusive=[["a", "b"], ["c", "d"]]))

    parameters = dict(test=10, c=1, d=2)
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []

    parameters = dict(test=10, c=1, b=2)
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result.errors[0], MutuallyExclusiveError)

    #

# Generated at 2022-06-11 00:51:25.753053
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    alias_warnings = []
    alias_deprecations = []
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {
            'type': 'str',
            'choices': ['absent', 'listed']
        }
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age']
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
        'state': 'listed'
    }

# Generated at 2022-06-11 00:51:37.755154
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    import pytest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.basic import AnsibleModule
    python_version = to_text(to_bytes(sys.version_info[0]) + to_bytes(sys.version_info[1]))
    if python_version < "27":
        pytest.skip("test_ModuleArgumentSpecValidator_validate only works with python2.7 and above")

# Generated at 2022-06-11 00:51:48.426551
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    expected_mutually_exclusive=[]
    expected_required_together=[]
    expected_required_one_of=[]
    expected_required_if=[]
    expected_required_by=[]

    actual_validator = ArgumentSpecValidator(expected_argument_spec={},
                                             mutually_exclusive=expected_mutually_exclusive,
                                             required_together=expected_required_together,
                                             required_one_of=expected_required_one_of,
                                             required_if=expected_required_if,
                                             required_by=expected_required_by)

    assert actual_validator._mutually_exclusive == expected_mutually_exclusive
    assert actual_validator._required_together == expected_required_together
    assert actual_validator._required_one_of == expected_required_one_of


# Generated at 2022-06-11 00:51:59.670746
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'hello': {'type': 'str'}})
    validator.validate(parameters={'hello': 'hello'})
    validator.validate(parameters={'hello': 'hello', 'baka': 'hello'})
    validator.validate(parameters={'hello': 'hello', 'baka': 'hello', 'baka2': 'hello'})
    validator.validate(parameters={'hello': 'hello', 'baka': 'hello', 'baka2': 'hello', 'baka3': 'hello'})
    validator.validate(parameters={'hello': 'hello', 'baka': 'hello', 'baka2': 'hello', 'baka3': 'hello', 'baka4': 'hello'})
    validator.valid

# Generated at 2022-06-11 00:52:07.653944
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:52:23.035765
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test for function ArgumentSpecValidator.validate()"""

    # ArgumentSpecValidator test
    # try to create a new instance of ArgumentSpecValidator
    validator = ArgumentSpecValidator({'name': {'type': 'str', 'default': 'foo'}, 'age': {'type': 'int', 'default': 42}})

    # handle test parameters
    parameters = {'name': 'bo', 'age': '42'}
    result = validator.validate(parameters)

    assert type(result) == ValidationResult
    assert type(result.validated_parameters) == dict
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}
    assert result.warnings == []
    assert result.deprecations == []
    assert result.errors.messages == []

    #

# Generated at 2022-06-11 00:52:34.316352
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}},
                                      mutually_exclusive=[['name', 'age']],
                                      required_together=(['name', 'age']),
                                      required_one_of=([['name'], ['age']]),
                                      required_if=[['name', 'bo', ['age']]],
                                      required_by={'age': ['name']},
                                      )
    parameters = {'name': 'bo'}
    result = validator.validate(parameters)

    assert parameters == result.validated_parameters

# Generated at 2022-06-11 00:52:43.444942
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'country': {'type': 'str'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'country': 'Uzbekistan',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert hasattr(result, 'error_messages')
    assert hasattr(result, 'validated_parameters')

    # Test AnsibleValidationErrorMultiple behavior
    # Append error message
    result.errors.append(AliasError('Test error 1'))
    assert 'Test error 1' in result.error_messages

    # Append AnsibleValidationErrorMultiple object

# Generated at 2022-06-11 00:52:55.880228
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    parameters = {
        'name': 'bo',
        'age': 'forty two',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 1

# Generated at 2022-06-11 00:53:02.898834
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test for method validate of class ArgumentSpecValidator"""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:53:14.203950
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.validated_parameters['age'] == 42 and result.validated_parameters['name'] == 'bo')

    parameters = {
        'name': 'bo',
    }

    result = validator.validate(parameters)
    assert(len(result.error_messages) == 1 and 'name' in result.error_messages[0])


# Generated at 2022-06-11 00:53:25.511418
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Vars
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    parameters = {'name': 'bo', 'age': '42'}

    result_validation = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                                    required_one_of, required_if, required_by).validate(parameters)

    # Check result is instance of ValidationResult
    assert isinstance(result_validation, ValidationResult)

    # Check attribute validation_parameters is assigned as expected
    # noinspection PyProtectedMember
    assert result_

# Generated at 2022-06-11 00:53:32.821272
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    use "mock" to simulate ModuleArgumentSpecValidator call to super's validate, and then test its validate method
    """
    parameter = {}

    argument_spec = {
        'option1': dict(type='bool')
    }

    def super_validate(self, parameters):
        return parameters

    # The following line will mock the validate method from super class
    # ArgumentSpecValidator by its super_validate method
    ModuleArgumentSpecValidator.validate = super_validate

    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec=argument_spec)

    value = module_argument_spec_validator.validate(parameter)

    assert (value == parameter)

# Generated at 2022-06-11 00:53:42.958235
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import StringIO

    warnings = StringIO()
    deprecations = StringIO()
    result = ModuleArgumentSpecValidator(
        ImmutableDict({'name': {'type': 'str'}, 'age': {'type': 'int'}}),
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None).validate({'name': 'bo', 'age': '42'})

    assert result.error_messages == []

# Generated at 2022-06-11 00:53:54.180805
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # verify success
    validator = ModuleArgumentSpecValidator({'key': {'type': 'str'}})
    parameters = {'key': 'value'}
    assert validator.validate(parameters)

    # verify failure
    # 1) raise when both 'key' and 'options' are specified
    validator = ModuleArgumentSpecValidator({'key': {'type': 'str', 'aliases': ['options']}})
    parameters = {'key': 'value', 'options': 'value'}
    result = validator.validate(parameters)
    assert result.error_messages, 'Expected one error message but got 0 messages'

# Generated at 2022-06-11 00:54:07.521456
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Method validate of class ArgumentSpecValidator
    """
    # Make sure that the method can be called
    validator = ArgumentSpecValidator({'name': {'type': 'str'}})
    result = validator.validate({'name': 'Bob'})
    assert(isinstance(result, ValidationResult))

# Generated at 2022-06-11 00:54:17.593104
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeModule(object):
        def __init__(self, validate=None, deprecate=None, warn=None):
            self.check_mode = False
            self.no_log = False
            self.validate = validate
            self.deprecate = deprecate
            self.warn = warn
            self.fail_json = lambda **kwargs: None

    module = FakeModule()
    validator = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None,
    )
    result = validator.validate({})


# Generated at 2022-06-11 00:54:24.497921
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert not result.errors, result.error_messages
    assert type(result.validated_parameters['name']) == str
    assert type(result.validated_parameters['age']) == int
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-11 00:54:35.624474
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    def test_result(validated_parameters, error_messages):
        def msg(): return ""

        def _errors():
            class Error:
                def __init__(self, msg):
                    self.msg = msg

                def __str__(self):
                    return self.msg

            class Errors:
                def __init__(self):
                    self.errors = []

                def append(self, e):
                    self.errors.append(e)

                def __getitem__(self, i):
                    return self.errors[i]

            e = Errors()
            for m in error_messages:
                e.append(Error(m))

            return e

        class Dummy:
            def __init__(self):
                self.warnings = []
                self.deprecations = []


# Generated at 2022-06-11 00:54:46.765648
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestAnsibleDeprecation(object):
        def __init__(self):
            self.messages = []

        def warn(self, msg, version=None, date=None, collection_name=None):
            self.messages.append(msg)

    class TestAnsibleModule(object):
        def __init__(self):
            self.deprecations = TestAnsibleDeprecation()
            self.warnings = []

        def fail_json(self, **kwargs):
            raise AssertionError('Unexpected call to fail_json')

    test_module = TestAnsibleModule()

    class TestObject(object):
        def __init__(self):
            self.params = {}
            self.module = test_module

    test_object = TestObject()


# Generated at 2022-06-11 00:54:56.855114
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # test mutually exclusive error
    mutually_exclusive = ['a', 'b']
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    params = {'a': True, 'b': True}
    result = validator.validate(params)
    assert len(result.error_messages) == 1
    assert result.error_messages[0].startswith('You can only choose one of a and b')

    # test required_together error
    mutually_exclusive = None
    required_together = [['a', 'c']]
    required_one_of = None
    required

# Generated at 2022-06-11 00:55:06.846956
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils.common.arg_spec import ValidationResult as _ValidationResult

    def validate(parameters, argument_spec,
                 mutually_exclusive=None,
                 required_together=None,
                 required_one_of=None,
                 required_if=None,
                 required_by=None,
                 ):

        validator = ArgumentSpecValidator(argument_spec,
                                          mutually_exclusive=mutually_exclusive,
                                          required_together=required_together,
                                          required_one_of=required_one_of,
                                          required_if=required_if,
                                          required_by=required_by,
                                          )

        return validator.validate(parameters)



# Generated at 2022-06-11 00:55:14.570348
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

    valid_params = result.validated_parameters

    assert valid_params['age'] == 42
    assert valid_params['name'] == 'bo'

# Generated at 2022-06-11 00:55:25.110092
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Invalid mutually exclusive parameters

    param_validator = ArgumentSpecValidator(
        {
            'boolean_param': {'type': 'bool'},
            'int_param': {'type': 'int'},
            'str_param': {'type': 'str'},
            'list_param': {'type': 'list'},
            'dict_param': {'type': 'dict'},
        },
        mutually_exclusive=['boolean_param', 'int_param'],
        required_together=[['boolean_param', 'int_param']]
    )

    params = {
        'boolean_param': True,
        'int_param': '1',
    }

    result = param_validator.validate(params)

    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-11 00:55:25.975068
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert ModuleArgumentSpecValidator(argument_spec={}).validate({})

# Generated at 2022-06-11 00:55:51.317621
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
        'pets': {'type': 'list', 'elements': 'dict', 'options': {
            'name': {'type': 'str'},
            'type': {'type': 'str', 'choices': ['dog', 'cat', 'bird']},
            'age': {'type': 'int'},
        }},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

# Generated at 2022-06-11 00:56:02.459606
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test method validate of class ArgumentSpecValidator.

    This test validates the method validate of class ArgumentSpecValidator.
    """
    from ansible.module_utils.common.text.converters import to_native

    argument_spec = {
        'name': {
            'type': 'str'
        },
        'age': {
            'type': 'int',
            'default': 30,
            'aliases': ['age_years']
        },
        'roles': {
            'type': 'list',
            'aliases': ['list_roles']
        },
        'zip_code': {
            'type': 'int',
            'default': None,
            'required': True
        }
    }

    mutually_exclusive = [['age', 'age_years']]

# Generated at 2022-06-11 00:56:08.928066
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_spec = {'parameter': {'type': 'int'}}
    test_parameters = {'parameter': '1'}

    test_validator = ArgumentSpecValidator(test_spec)
    test_result = test_validator.validate(test_parameters)

    assert test_result._no_log_values == set()
    assert test_result._unsupported_parameters == set()
    assert test_result._validated_parameters == {'parameter': 1}
    assert test_result.error_messages == set()


# Generated at 2022-06-11 00:56:19.340461
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def my_validation_check(parameters):
        raise TypeError("my_validation_check failed")

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'boolean': {'type': 'bool'},
        'a_list': {'type': 'list', 'choices': ['1', '2']},
        'a_dict': {'type': 'dict'},
        'a_dict_with_choices': {'type': 'dict'},
    }


# Generated at 2022-06-11 00:56:21.178597
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for method ModuleArgumentSpecValidator.validate"""
    pass


# Generated at 2022-06-11 00:56:30.957773
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator()

    args = dict(argument_spec={})
    assert validator.validate(**args) is not None

    args = dict(argument_spec={}, mutually_exclusive=[])
    assert validator.validate(**args) is not None

    args = dict(argument_spec={}, required_if=[])
    assert validator.validate(**args) is not None

    args = dict(argument_spec={}, required_by={})
    assert validator.validate(**args) is not None

    args = dict(argument_spec={}, required_together=[])
    assert validator.validate(**args) is not None

    args = dict(argument_spec={}, required_one_of=[])
    assert validator.validate(**args) is not None

    args = dict

# Generated at 2022-06-11 00:56:34.365471
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})
    result = validator.validate({'name': 'bo', 'age': '42'})

    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:56:46.265954
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json

    argument_spec = {
        'name': {'type': 'str', 'required': 'yes'},
        'age': {'type': 'int'},
        'wins': {'type': 'int', 'default': 0},
        'losses': {'type': 'int', 'default': 0},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
        'wins': 43,
        'losses': 1,
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:56:55.632884
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create object
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    # check result
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result._no_log

# Generated at 2022-06-11 00:57:06.716729
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [
        ['option1', 'option2'],
        ['option3', 'option4']
    ]
    argument_spec = {
        "option1": {"type": "str"},
        "option2": {"type": "str"},
        "option3": {"type": "str"},
        "option4": {"type": "str"},
    }
    parameters = {
        "option1": "opt1",
        "option2": "opt2",
        "option3": "opt3",
        "option4": "opt4",
    }

    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive,
    )

    result = validator.validate(parameters)

    assert len(result.error_messages) == 2