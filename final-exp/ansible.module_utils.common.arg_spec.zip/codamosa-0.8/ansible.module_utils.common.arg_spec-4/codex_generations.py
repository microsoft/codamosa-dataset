

# Generated at 2022-06-11 00:48:06.701180
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:48:12.433165
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'default': 'default_name'},
        'size': {'type': 'int'},
        'aliased_size': {'type': 'int', 'default': 0, 'aliases': ['aliased_size_for_size']},
        'container_size': {'type': 'int'},
        'collection_size': {'type': 'int'},
        'size_30': {'type': 'int'},
        'size_2': {'type': 'int'},
    }

    mutually_exclusive = [
        ['size', 'aliased_size_for_size'],
        ['size_2', None]
    ]

    required_together = [
        ['size', 'size_30']
    ]

    required_one_

# Generated at 2022-06-11 00:48:13.100094
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # todo: write unit test
    pass

# Generated at 2022-06-11 00:48:14.080518
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert ArgumentSpecValidator(argument_spec={}).validate({})

# Generated at 2022-06-11 00:48:25.538363
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class TestAnsibleModule:
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise AssertionError("fail_json() was called with:\narguments: {0}\n\nkeyword arguments: {1}".format(args, kwargs))

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(TestAnsibleModule(parameters))

    assert result is not None
    assert result._no_log_values is not None

# Generated at 2022-06-11 00:48:26.211769
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:48:33.231106
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    test_params = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(test_argument_spec)
    result = validator.validate(test_params)

    assert result.error_messages == []

# Generated at 2022-06-11 00:48:43.320739
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_if = [
        ['name', 'yes', ['age']],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_by = {'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_if=required_if,
                                      required_one_of=required_one_of,
                                      required_by=required_by,
                                      )


# Generated at 2022-06-11 00:48:53.348270
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test1 deprecate warning
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'role': {'aliases': ['role', 'roles'], 'type': 'list'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'roles': 'admin',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # test2 deprecate warning, also test3 warnning

# Generated at 2022-06-11 00:49:05.414998
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Set up a fake module to pass to ModuleArgumentSpecValidator.validate
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
    # TestModule uses the method validate of class ModuleArgumentSpecValidator, so TestModule is the object to test
    class TestModule(object):
        def __init__(self, **kwargs):
            self.argument_spec = kwargs
            self.result = None
        def fail_json(self, msg):
            raise ValueError(msg)

    # Using the arguement spec from ansible/test/units/modules/test_delegation.py

# Generated at 2022-06-11 00:49:22.285775
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # test validate() when mutually_exclusive parameters are provided
    spec = {"a": {"type": "str"}, "b": {"type": "str"}}
    params = {"a": "a", "b": "b"}
    mutex = [['param_b', 'param_a']]
    validator = ArgumentSpecValidator(spec, mutually_exclusive=mutex)
    result = validator.validate(params)
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], MutuallyExclusiveError)
    assert "{param_a} is mutually exclusive with {param_b}".format(param_a=mutex[0][0],
                                                                   param_b=mutex[0][1]) in result.error_messages

    # test validate() when mutually_exclusive parameters are not provided
    spec

# Generated at 2022-06-11 00:49:33.201087
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'color': {'type': 'list', 'elements': 'str'},
        'city': {'type': 'dict', 'options': {
            'city_name': {'type': 'str'},
            'zip_code': {'type': 'int'},
        }},
        'friends': {'type': 'list', 'elements': 'str'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'color': ['purple'],
        'city': {
            'city_name': 'Boulder',
            'zip_code': 80302,
        },
        'friends': [],
    }

    valid

# Generated at 2022-06-11 00:49:38.655303
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import os, sys
    sys.path.append(os.path.join(os.path.dirname(__file__),"..","test"))
    import test_module_utils_common_arg_spec as t
    try:
        result = t.test_ModuleArgumentSpecValidator_validate()
    except error as e:
        print(e)
    else:
        print(result)

# Generated at 2022-06-11 00:49:43.739459
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0, "validate() should return 0 errors if there are no errors"

# Generated at 2022-06-11 00:49:46.366322
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator.validate(self, parameters)
    assert result._deprecations == self.deprecations

# Generated at 2022-06-11 00:49:47.006565
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:49:58.601935
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    result = ArgumentSpecValidator(argument_spec)
    assert result.argument_spec == argument_spec

    mutually_exclusive = [
        ["name", "age"],
    ]
    result = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert result._mutually_exclusive == mutually_exclusive

    required_together = [
        ["name", "age"],
    ]
    result = ArgumentSpecValidator(argument_spec, required_together=required_together)
    assert result._required_together == required_together

    required_one_of = [
        ["name", "age"],
    ]

# Generated at 2022-06-11 00:50:06.587438
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0
    assert result._validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-11 00:50:07.311420
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:50:17.542900
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'bool'}, 'b': {'type': 'str', 'aliases': ['b_alias']}, 'c': {'type': 'bool', 'aliases': ['c_alias']}}
    parameters = {'a': False, 'b': 'string', 'b_alias': 'string', 'c_alias': False, 'd': 'unsupported_parameter'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result._warnings == [{'option': 'b', 'alias': 'b_alias'}, {'option': 'c', 'alias': 'c_alias'}]
    assert result._deprecations == []

# Generated at 2022-06-11 00:50:37.378986
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:50:49.439142
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestValidationResult(ValidationResult):
        def __init__(self, parameters):
            super(TestValidationResult, self).__init__(parameters)

        @property
        def validated_parameters(self):
            return {'test': 'test'}

        @property
        def unsupported_parameters(self):
            return set()

        @property
        def error_messages(self):
            return ['test']

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(TestModuleArgumentSpecValidator, self).__init__(*args, **kwargs)

        def validate(self, parameters):
            return TestValidationResult(parameters)


# Generated at 2022-06-11 00:50:57.682062
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'arg': {}}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)

    # Verify that class __init__ populates all input values
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._required_if == required_if
    assert validator._required_by == required_by

# Generated at 2022-06-11 00:51:09.294748
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # We currently don't have a easy way to test the deprecations so they are
    # being skipped here.
    # Once we have a better mechanism in the future this test should be updated.
    def deprecate(*args, **kwargs):
        pass

    # Unit test for warn function
    warnings = []
    def warn(msg):
        warnings.append(msg)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-11 00:51:21.154496
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator, ValidationResult

    from ansible.module_utils._text import to_bytes, to_text

    class TestClass(unittest.TestCase):
        """This is used to test the ArgumentSpecValidator validate method."""

        def test_validate(self):
            """Perform the validate test."""
            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int', 'default': 30},
                'sex': {'type': 'str', 'choices': ['Male', 'Female']},
            }

# Generated at 2022-06-11 00:51:28.287164
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Create a definition of the mapping
    argument_spec = {
                        'name': {'type': 'str'},
                        'age': {'type': 'int'},
                        'tags': {'type': 'list', 'elements': 'str'},
                    }

    # Create a mapping of the fields to values
    parameters = {'name': 'bo', 'age': '42'}

    # test method validate of class ModuleArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Prints the error messages
    for message in result.error_messages:
        print(message)

# Generated at 2022-06-11 00:51:36.422487
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockModule(object):
        def __init__(self):
            self.argument_spec = {}

    spec_validator = ModuleArgumentSpecValidator(argument_spec={})

    result = spec_validator.validate({})

    assert result == spec_validator.validate(result.validated_parameters)

    assert isinstance(result, ValidationResult)
    assert isinstance(result.error_messages, list)
    assert schema_match(result.validated_parameters, {})

# Generated at 2022-06-11 00:51:47.429780
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    from ansible.module_utils.common.parameters import sanitize_keys
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'actor': {'type': 'str', 'aliases': ['actor_name'], 'fallback': ('name', 'age')},
        'list_of_roles': {'type': 'list', 'elements': 'str'},
        'dict_of_actors': {
            'type': 'dict',
            'options': {
                'actor_name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        }
    }


# Generated at 2022-06-11 00:51:58.519344
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    class ModuleUtilsCommonArgSpecValidationModuleUtilsCommonArgSpecValidationValidationResult:

        def __init__(self, validated_parameters):
            self.validated_parameters = validated_parameters
            pass

    class ModuleUtilsCommonArgSpecValidationMutuallyExclusiveError:
        pass

    class ModuleUtilsCommonArgSpecValidationUnsupportedError:
        pass

    class ModuleUtilsCommonArgSpecValidationAnsibleValidationErrorMultiple:

        def __init__(self):
            self.errors = []

        def append(self, error):
            self.errors.append(error)

    class ModuleUtilsCommonArgSpecValidationAnsibleValidationError:

        def __init__(self, message):
            self.message = message

        def __str__(self):
            return self.message


# Generated at 2022-06-11 00:51:59.220401
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:52:13.535792
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['age'] == 42
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-11 00:52:24.833550
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    import sys
    from ansible.module_utils.six import PY3

    def mock_deprecate(msg, version=None,
                       date=None, collection_name=None,
                       added_in=None, removed_in=None,
                       collection_version=None,
                       version_added=None, version_removed=None):
        raise AssertionError('Failed: deprecate: {0}'.format(msg))

    def mock_warn(msg):
        raise AssertionError('Failed: warn: {0}'.format(msg))

    def mock_sys_exit(msg):
        raise AssertionError('Failed: sys.exit: {0}'.format(msg))

    def mock_exit(msg):
        raise AssertionError('Failed: exit: {0}'.format(msg))

# Generated at 2022-06-11 00:52:36.049641
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from textwrap import dedent
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 00:52:43.630561
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup test
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Test
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Assertions
    assert('name' in result.validated_parameters.keys())
    assert('age' in result.validated_parameters.keys())
    assert(result.validated_parameters['name'] == 'bo')
    assert(result.validated_parameters['age'] == 42)

# Generated at 2022-06-11 00:52:55.526373
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters



# Generated at 2022-06-11 00:53:05.141310
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [
        ['ansible_password', 'ansible_ssh_pass'],
        ['ansible_password', 'ansible_become_pass']
    ]

    required_together = [
        ['ansible_ssh_user', 'ansible_ssh_pass'],
        ['ansible_become', 'ansible_become_pass'],
        ['ansible_become_user', 'ansible_become_pass'],
    ]

    required_if = [
        ['ansible_become', True, ['ansible_become_user']],
    ]

    required_by = {
        'ansible_ssh_pass': ['ansible_ssh_user']
    }


# Generated at 2022-06-11 00:53:12.412782
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:53:23.886297
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'foo': {'type': 'str'}, 'bar': {'type': 'str', 'default': 'default_val'}}
    parameters = {'bar': 'user_val'}

    # Test a successful validation with valid params
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'foo': None, 'bar': 'user_val'}
    assert not result.error_messages

    # Test a failed validation with invalid params
    parameters = {'foo': 42}
    result = validator.validate(parameters)
    assert result.validated_parameters == {'foo': 42, 'bar': 'default_val'}
    assert len(result.error_messages) == 1

# Generated at 2022-06-11 00:53:28.667245
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})
    assert ArgumentSpecValidator({}, {})
    assert ArgumentSpecValidator({}, {}, {}, {}, {})
    assert ArgumentSpecValidator({}, ['a', 'b'], [['c','d']], [['a','b','c']], [['a','b','c']], {})

# Generated at 2022-06-11 00:53:36.934105
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '25',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 25}
    assert not result.unsupported_parameters



# Generated at 2022-06-11 00:54:04.794835
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    test the method validate of class ModuleArgumentSpecValidator

    :return:
    """
    import json

    argument_spec = {}
    with open('../files/argument_spec.json', mode='r', encoding='utf-8') as fp:
        argument_spec = json.load(fp)

    v = ModuleArgumentSpecValidator(argument_spec)
    print(v)

    parameters = {}
    with open('../files/parameters.json', mode='r', encoding='utf-8') as fp:
        parameters = json.load(fp)

    result = v.validate(parameters)
    print(result)
    print(result.validated_parameters)
    print(result.error_messages)
    print(result.unsupported_parameters)

# Generated at 2022-06-11 00:54:14.881267
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ["name", "age"],
    ]

    required_one_of = [
        ["name", "age"],
    ]

    required_if = [
        ["name", "Fred", ["age"]],
    ]

    required_by = {
        "age": ["name"],
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_one

# Generated at 2022-06-11 00:54:23.764984
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TypeError: _set_defaults() got an unexpected keyword argument 'False'
    # TypeError: _list_no_log_values() got an unexpected keyword argument 'False'
    # ValueError: aliases for name and age must have the same type
    # TypeError: _validate_sub_spec() got an unexpected keyword argument 'no_log_values'
    # TypeError: _handle_aliases() got an unexpected keyword argument 'alias_deprecations'
    # TypeError: _validate_argument_values() got an unexpected keyword argument 'errors'

    # TypeError: _set_defaults() got an unexpected keyword argument 'False'
    assert False

    # TypeError: _list_no_log_values() got an unexpected keyword argument 'False'
    assert False

    # ValueError: aliases for name and age must have the same type
   

# Generated at 2022-06-11 00:54:35.018815
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={
        'name': {
            'type': 'str',
        },
        'age': {
            'type': 'int',
        },
        'colors': {
            'type': 'list',
            'elements': 'str',
        },
    })

    result = validator.validate({
        'name': 'bo',
        'age': '42',
        'colors': ['red'],
    })

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
        'colors': ['red'],
    }
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-11 00:54:45.977240
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.collections import is_sequence

    def is_validated_parameters(params):
        if isinstance(params, dict):
            for (k, v) in params.items():
                if not is_sequence(v):
                    return True
                if not is_validated_parameters(v):
                    return False
            return True
        else:
            return False

    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert is_validated_parameters(result.validated_parameters)

# Generated at 2022-06-11 00:54:51.638140
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create an instance of the class
    validator = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={},
    )

    # Call the method
    result = validator.validate({})

    # Assert no errors
    assert not result.error_messages

# Generated at 2022-06-11 00:55:00.405837
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int'},
        'gender': {'type': 'str', 'choices': ['male', 'female']},
    }, required_one_of=[['name', 'age']])
    p = {'name': 'bo', 'age': '42'}
    result = validator.validate(p)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert len(result.errors) == 0
    assert len(result._validated_parameters) == 2
    p = {'gender': 'male'}
    result = validator.validate(p)
    assert len(result.errors) == 1
    assert len

# Generated at 2022-06-11 00:55:11.071443
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [{'name': 'age'}]
    required_together = [{'age': 'name'}]
    required_one_of = [{'age': 'name'}]
    required_if = {'name': 'James', 'age': [21]}
    required_by = {'James': 'age'}
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive = mutually_exclusive,
                                      required_together = required_together,
                                      required_one_of = required_one_of,
                                      required_if = required_if,
                                      required_by = required_by)
    assert validator.argument_spec == argument_spec
   

# Generated at 2022-06-11 00:55:22.064398
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Validator with no deprecation, warning and error.
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.validate(parameters).validated_parameters == {'name': 'bo', 'age': 42}

    # Validator with deprecation.
    import ansible_collections.collection_name.sub_collection.plugins.module_utils.common.arg_spec
    # Prevent deprecation messages from cluttering up the outputs
    ansible_collections.collection_name.sub_collection.plugins.module_utils.common.arg_spec

# Generated at 2022-06-11 00:55:24.548019
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator({"spec": {"type": "dict"}}).validate({"spec": {"test": "test"}})

    assert not result.errors

# Generated at 2022-06-11 00:56:06.419456
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import _get_default_arg_spec

    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = _get_default_arg_spec(None)

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-11 00:56:15.241330
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # test normal constructor
    argument_spec = {'param1': {'type': 'str'}, 'param2': {'type': 'int'}}
    mutually_exclusive = ['param1', 'param2']
    required_together = [['param1'], ['param2']]
    required_one_of = [['param1', 'param2']]
    required_if = [['param1', 'param', ['param1', 'param2']]]
    required_by = {'param1': ['param2'], 'param2': ['param1']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
   

# Generated at 2022-06-11 00:56:26.393219
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class TestException(Exception):
        def __init__(self, message, errors=None):
            super(TestException, self).__init__(message)
            self.errors = errors

    class TestValidationResult:

        def __init__(self, return_value):
            self._validated_parameters = return_value
            self._deprecations = []
            self._warnings = []
            self.errors = []

        def __getattr__(self, item):
            if item == 'validated_parameters':
                return self._validated_parameters
            if item == '_deprecations':
                return self._deprecations
            if item == '_warnings':
                return self._warnings
            if item == 'errors':
                return self.errors


# Generated at 2022-06-11 00:56:33.997844
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}, 'list': {'type': 'list'}, 'dict': {'type': 'dict'}}

    val = ArgumentSpecValidator(argument_spec)

    result = val.validate({'name': 'qiaochu', 'age': '42'})
    assert result.validated_parameters == {'name': 'qiaochu', 'age': '42'}
    assert result.error_messages == []
    assert result._warnings == []
    assert result._deprecations == []

    result = val.validate({'name': 'qiaochu', 'age': '42', 'list': 'foo'})

# Generated at 2022-06-11 00:56:45.771687
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def return_result(x):
        return x

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        _warnings = []

        def _warn(self, warning):
            self._warnings.append(warning)

        def _deprecate(self, msg, version, collection_name=None, date=None):
            self._warnings.append((msg, version, collection_name, date))

        def _debug(self, msg):
            self._warnings.append(msg)

    class AnsibleValidationErrorMultipleMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def __nonzero__(self):
            return False

        def __bool__(self):
            return False

    # check the condition that alias works correctly
    test_argument_spec

# Generated at 2022-06-11 00:56:49.465426
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={})
    result = validator.validate({})
    assert isinstance(result, ValidationResult), 'validate() must return ValidationResult object' # noqa: B303

# Generated at 2022-06-11 00:56:57.224308
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # The instance of ModuleArgumentSpecValidator uses "self" as a name for the first argument, but when calling
    # the validate method from unittest, it is not necessary to pass "self".

    # Test 1. argument_spec has options and defaults
    argument_spec = {
        'name': {'type': 'str', 'default': 'bo'},
        'age': {'type': 'int', 'default': 18},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({'name': 'john'})

    assert result.validated_parameters == {'name': 'john', 'age': 18}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

    # Test 2. argument_spec has no supported option


# Generated at 2022-06-11 00:57:04.469287
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == {'name': 'bo', 'age': 42}
    assert not result.error_messages

# Generated at 2022-06-11 00:57:14.613662
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class DummyModule():
        def __init__(self):
            self.name = 'ansible_module_debug'
            self.boolean = False
    global_argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}
    argument_spec = {
        '_ansible_module_name': {'type': 'str'},
        'boolean': {'type': 'bool', 'default': True},
    }
    dm = DummyModule()

# Generated at 2022-06-11 00:57:24.305279
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutex_group1 = ['name', 'age']
    required_if_w_params = [
        ['a', 'b', ['c', 'd']],
        ['e', 'f', ['g', 'h']],
    ]
    required_if = ['name', 'age']
    required_one_of = [['name', 'age']]
    required_together = [['name', 'age']]