

# Generated at 2022-06-11 00:47:49.844344
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:48:01.319800
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {}
    arg_spec['name'] = {'type': 'str'}
    arg_spec['age'] = {'type': 'int'}
    arg_spec['siblings'] = {'type': 'list'}
    arg_spec['dob'] = {'type': 'dict'}

    for i in range(4):
        parameters = {}
        parameters['name'] = 'bo'
        parameters['age'] = '42'
        parameters['siblings'] = ['charlie', 'miles']
        parameters['dob'] = {'month': '12', 'day': '30', 'year': '1990'}

        # simple test with no optional arguments
        validator = ArgumentSpecValidator(arg_spec)
        result = validator.validate(parameters)
        assert not result.errors


# Generated at 2022-06-11 00:48:13.139892
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._required_if == required_if
    assert validator._required_by == required_

# Generated at 2022-06-11 00:48:24.009850
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test method validate of class ModuleArgumentSpecValidator."""
    from ansible.modules.utilities.logic import is_subset
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = {
        'a': {'type': 'list'},
        'b': {'type': 'int', 'default': 42},
        'c': {'type': 'int'},
        'deprecated_a': {'type': 'list', 'deprecated': {'msg': 'a', 'version': '1.1.0', 'date': '2020-01-01'}},
    }

    mutually_exclusive = [['a', 'b']]
    required_if = [['c', 1, ['a', 'b']], ['c', 2, ['b']]]


# Generated at 2022-06-11 00:48:36.323421
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test the validate method of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    parameters = {
        'name': 'bo',
        'age': 'forty two',
    }

    result = validator.validate(parameters)

    assert len(result.errors) == 1
    assert result.validated_

# Generated at 2022-06-11 00:48:45.043335
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                                      mutually_exclusive=[['one', 'two']],
                                      required_together=[['one', 'two']],
                                      required_one_of=[['one', 'two']],
                                      required_if=[['one', 'two', ['three', 'four']]],
                                      required_by={'one': ['two'], 'two': ['one']},
                                      )

    assert validator._mutually_exclusive == [['one', 'two']]
    assert validator._required_together == [['one', 'two']]
    assert validator._required_one_of == [['one', 'two']]
    assert validator._required_if == [['one', 'two', ['three', 'four']]]
   

# Generated at 2022-06-11 00:48:54.985807
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    #
    # Test passing
    #

    argument_spec = {
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }

    required_if = [
        ['state', 'present', ['name']],
        ['state', 'absent', ['name']],
    ]

    validator = ModuleArgumentSpecValidator(argument_spec, required_if=required_if)

    parameters = {
        'name': 'bo',
    }

    result = validator.validate(parameters)


# Generated at 2022-06-11 00:49:06.655566
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        "name": {
            "type": "str",
            "required": True,
            "aliases": ["first_name", "nick_name"]
        },
        "email": {
            "type": "str",
            "required": True,
            "aliases": ["e-mail"]
        }
    }
    params = {"first_name": "John"}
    spec_validator = ArgumentSpecValidator(spec)
    result = spec_validator.validate(params)
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters["name"] == "John"
    assert "name (first_name, nick_name)" in result.error_messages
    assert "email (e-mail)" in result.error_messages

# Generated at 2022-06-11 00:49:18.135962
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator1 = ArgumentSpecValidator(argument_spec)
    parameters1 = {
        'name': 'bo',
        'age': '42',
    }
    res1 = validator1.validate(parameters1)
    res1_val = res1.validated_parameters['age']
    assert res1_val == 42

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters2 = {
        'name': 'bo',
        'age': '42',
    }

# Generated at 2022-06-11 00:49:25.739520
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Validate parameters against argument spec.
    """

    # Parameters / Deprecations / Warnings

# Generated at 2022-06-11 00:49:32.471250
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False, "Need to write unit test for class ModuleArgumentSpecValidator"

# Generated at 2022-06-11 00:49:36.420480
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Given
    parameter_validator = ModuleArgumentSpecValidator(argument_spec={})
    parameters = {}

    # When
    result = parameter_validator.validate(parameters)

    # Then
    assert result
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-11 00:49:44.057579
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:49:55.824339
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Test the case that parameters is valid.
    # Test the case that for validate_argument_types function, there is no exception.
    # Test the case that for validate_argument_values function, there is no exception.
    # Test the case that there is no error from subspec.
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    # Test the case that parameters is invalid because type is wrong.
    # Test the case that for validate_argument_types function, there is an exception.
   

# Generated at 2022-06-11 00:50:03.788791
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    _args = {'a': {'required': True, 'aliases': ['b']},
             'b': {'default': 'test'}}
    _params = {'b': True}
    _validator = ModuleArgumentSpecValidator(_args)
    result = _validator.validate(_params)
    assert 'parameter "b" cannot be used with parameter "a"' in result.error_messages
    assert "both option a and its alias b are set" in result.error_messages
    assert result.error_messages[0].startswith("parameter")
    assert result.error_messages[1].startswith("alias")

# Generated at 2022-06-11 00:50:15.515043
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'list_param': {'type': 'list', 'elements': 'str'},
        'dict_param': {'type': 'dict', 'keys': 'str'}
    }

    mutually_exclusive = [['list_param', 'dict_param']]
    required_together = [['list_param', 'dict_param']]
    parameters = {'list_param': ['abc'], 'dict_param': {'abc': 'def'}}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      )

    result = validator.validate(parameters)
    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 1


# Generated at 2022-06-11 00:50:15.978033
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:50:28.117083
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:50:37.601287
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test for method validate of class ModuleArgumentSpecValidator
    """
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class CaptureOutput(StringIO):
        """
        Capture the stderr and stdout
        """
        def __init__(self, *args, **kwargs):
            """
            Capture stderr and stdout
            """
            super(CaptureOutput, self).__init__(*args, **kwargs)
            self.stderr = StringIO()
            self.stdout = StringIO()

        def write(self, string):
            """
            Write the input string to stderr and stdout
            """
            self.stderr.write(string)
            self.stdout.write(string)



# Generated at 2022-06-11 00:50:45.818639
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    a = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int', 'default': 23}})
    result = a.validate({'name': 'bo', 'age': '42'})
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.error_messages) == 0
    assert result.validated_parameters['age'] == 23

# Generated at 2022-06-11 00:50:57.597701
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ## Testing of method validate of class ModuleArgumentSpecValidator
    ## This test case is to test the following cases:
    ## 1. Unsupported
    ## 2. Alias warning

    import pytest
    from ansible.module_utils.common.warnings import setup_warning_capture
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import StringIO

    warnings = []
    setup_warning_capture(warnings)
    test_args = {'argument_spec': {'name': {'type': 'str'}}}
    validator = ModuleArgumentSpecValidator(**test_args)
    test_parameters = {'name': 'bo', 'age': '42'}

    result = validator.validate(test_parameters)

# Generated at 2022-06-11 00:51:02.240553
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}}
    parameters = {'name': 'bo'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages

# Generated at 2022-06-11 00:51:11.587854
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import StringIO
    import sys
    results = StringIO()
    sys.stderr = results
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    try:
        validator = ModuleArgumentSpecValidator(argument_spec)
        result = validator.validate(parameters)
        assert result.validated_parameters['age'] == 42
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-11 00:51:23.336893
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json

    allowed_errors = {
        "UnsupportedError": "ansible.module_utils.common.validation.UnsupportedError(\w+)",
        "RequiredError": "ansible.module_utils.common.validation.RequiredError(\w+)",
        "MutuallyExclusiveError": "ansible.module_utils.common.validation.MutuallyExclusiveError(\w+)",
        "NoLogError": "ansible.module_utils.common.validation.NoLogError(\w+)",
        "AliasError": "ansible.module_utils.common.validation.AliasError(\w+)",
    }

    test_data = json.loads(open('tests/unit/validation/test_validation_args.json').read())

    validator = ArgumentSpecValidator(test_data["argument_spec"])

   

# Generated at 2022-06-11 00:51:35.099426
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator_validate_result = None

    # params: parameters
    parameters = {'warn_deprecated': False, 'warn_deprecated_action': 'error'}

    # params: deprecations
    deprecations = []

    # params: alias_deprecations
    alias_deprecations = []

    # create instance of class ModuleArgumentSpecValidator with arguments

# Generated at 2022-06-11 00:51:36.977728
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    x = ModuleArgumentSpecValidator('a')
    assert x.validate({'a':1})

# Generated at 2022-06-11 00:51:43.772695
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    return result
result = test_ModuleArgumentSpecValidator_validate()
print(result.error_messages)

# Generated at 2022-06-11 00:51:52.059117
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Unit test for method validate of class ModuleArgumentSpecValidator
    """
    print('############# test_ModuleArgumentSpecValidator_validate ###############')
    params = {
        'name': 'bo',
        'age': '42',
        'check': False,
        'option': 'no',
        'alias': 'yes',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'check': {'type': 'bool', 'default': True},
        'option': {'type': 'bool', 'aliases': ['alias']},
        '_internal': {'type': 'dict', 'no_log': True},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-11 00:52:04.555794
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Setup
    module_spec = {
            'one': {'type': 'str'},
            'two': {'type': 'str', 'aliases': ['second']},
            'three': {'type': 'str', 'fallback': (0, None)},
            'four': {'type': 'str', 'no_log': True},
            'five': {'type': 'str', 'no_log': False},
        }
    mutually_exclusive = ['one', 'two']
    required_together = [['three', 'four']]
    required_one_of = [['one', 'two']]
    required_if = [['one', True, ['two']]]
    required_by = {
            'one': ['two'],
        }

# Generated at 2022-06-11 00:52:13.940599
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Create argument spec for test
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    # Create validator
    validator = ArgumentSpecValidator(argument_spec,
                                 mutually_exclusive=mutually_exclusive,
                                 required_together=required_together,
                                 required_one_of=required_one_of,
                                 required_if=required_if,
                                 required_by=required_by,)

    # Make parameters with str age
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Validate parameters


# Generated at 2022-06-11 00:52:29.325300
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test call with non-deprecated alias
    spec = {'name': {'aliases': ['nickname']}}
    parameters = {'name': 'Jack'}
    val_result = ModuleArgumentSpecValidator(spec).validate(parameters)
    assert not val_result._warnings
    assert not val_result._deprecations

    # Test call with deprecated alias
    # The older 'deprecated_version' is deprecated by 'version', currently the only keyword present.
    spec = {'name': {'aliases': ['nickname'], 'deprecated_version': '2.0', 'deprecated_date': '2021-08-18',
                     'collection_name': 'not_a_collection'}}
    parameters = {'name': 'Jack'}
    val_result = ModuleArgumentSpecValidator(spec).valid

# Generated at 2022-06-11 00:52:40.070959
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeArgs:
        def __init__(self, test_arg):
            self.test_arg = test_arg

    def test_deprecations(test_case, module, deprecations):
        for d in deprecations:
            test_case.assertEqual(module.deprecations[0].msg, "Alias '{name}' is deprecated. See the module docs for more information".format(name=d['name']))


# Generated at 2022-06-11 00:52:51.747500
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    class MockError(Exception):
        pass

    class MockErrorList(list):
        def append(self, message):
            print("[MockErrorList] append")
            raise MockError("Preserved error message: {0}".format(message))

    invalid_params = dict()
    invalid_params["name"] = "bo"
    invalid_params["age"] = "42"
    invalid_params["invalid"] = "invalid"

    valid_params = dict()
    valid_params["name"] = "bo"
    valid_params["age"] = 42

    required_together_list = list()
    required_together_list.append(["name", "age"])

    required_one_of_list = list()
    required_one_of_list.append(["name", "invalid"])

    argument_spec

# Generated at 2022-06-11 00:53:02.386754
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # http://stackoverflow.com/a/34975047/171094
    # http://stackoverflow.com/a/12462776/171094
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('ansible.module_utils.common.warnings.warn') as mock_warn_warn:
        with patch('ansible.module_utils.common.warnings.deprecate') as mock_warn_deprecate:

            from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }

# Generated at 2022-06-11 00:53:13.317515
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for the ArgumentSpecValidator.validate() method.

    The test cases cover the defined behaviors for the ArgumentSpecValidator.validate() method.
    These behaviors are described in the special comments "Expected behavior", which are
    specially formatted so the test case can be detected.
    """

    test_cases = []

    # This test case checks that no errors are raised and the validated_parameters are returned.

# Generated at 2022-06-11 00:53:24.722439
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:53:29.756625
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-11 00:53:35.904954
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''
    Test class ModuleArgumentSpecValidator
    '''

    ModuleArgumentSpecValidator.__init__(self, 
    argument_spec={"host": {"type": "str", "required": True}, "name": {"type": "str", "required": True}, "dest": {"type": "path", "required": True}}, 

    mutually_exclusive=None,
    required_together=None,
    required_one_of=None,
    required_if=None,
    required_by=None,
    )

    ModuleArgumentSpecValidator.validate(self, 
    parameters={"host": ["localhost"], "dest": "/tmp/ansible_collections-0.6.1.tar.gz", "name": "ansible_collections-0.6.1.tar.gz"}, 
    )

# Generated at 2022-06-11 00:53:36.518701
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:53:41.250077
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    ).validate(
        parameters={
            'name': 'bo',
            'age': '42',
        }
    )

# Generated at 2022-06-11 00:54:04.305358
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from io import StringIO
    from sys import modules, stderr
    # Save the original stderr
    old_stderr = stderr
    stderr = StringIO()

    # DEPRECATED_ALIASES is needed for the call to set_fallbacks()
    import ansible.module_utils.common.parameters
    ansible.module_utils.common.parameters.DEPRECATED_ALIASES = {}

    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'friend': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        }
    }

    val = ModuleArgumentSpecValid

# Generated at 2022-06-11 00:54:14.470338
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'test_test': {'type': 'list', 'default': ['test'], 'elements': 'str', 'no_log': True},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'test_test': ['test', 'test'],
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'test_test': ['test', 'test']}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:54:23.446917
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'bo', ['age']]]
    required_by = {'name': ['age']}

    # 1. Test empty params
    parameters = {}
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

# Generated at 2022-06-11 00:54:34.405668
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method `validate` of class `ArgumentSpecValidator`."""

    def _create_validator(spec, *args, **kwargs):
        return ArgumentSpecValidator(spec, *args, **kwargs)

    def _validate_parameters(parameters, validator):
        return validator.validate(parameters)

    try:
        import pytest
    except ImportError:
        pytest = None

    if pytest is None:
        raise Exception("pytest is required to run this unit test")

    def _remove_keys(parameters, keys):
        for key in keys:
            try:
                del parameters[key]
            except KeyError:
                pass

    def _test_required_parameters(parameters, spec, expected_error_messages):
        validator = _create_

# Generated at 2022-06-11 00:54:41.471428
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # arrange
    from ansible.module_utils.six import string_types
    # Check expected error if type is not str or list
    argument_spec = {'name': {'type': int}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)
    parameters = {'name': 'bo'}

    # act
    result = validator.validate(parameters)
    # assert
    assert result.error_messages[0].startswith("'int' is not one of ['str'], 'NoneType'")

# Generated at 2022-06-11 00:54:52.832204
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    argument_spec_test_data = {
        'test_dict': {
            'test_dict_key': {'type': 'dict', 'options': {
                'test_dict_opt1': {'type': 'str'},
                'test_dict_opt2': {'type': 'str'},
            }},
            'test_str': {'type': 'str'},
            'test_bool': {'type': 'bool'},
        },
    }


# Generated at 2022-06-11 00:55:01.041416
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    import sys

    if not PY2:
        from io import TextIOWrapper

    class Capture(object):
        def __init__(self):
            self._stdout = None
            self._stderr = None
            self._stdout_bkp = sys.stdout
            self._stderr_bkp = sys.stderr

        @property
        def stdout(self):
            return self._stdout

        @property
        def stderr(self):
            return self._stderr

        def __enter__(self):
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            return self


# Generated at 2022-06-11 00:55:11.752379
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Arrange
    validator = ModuleArgumentSpecValidator(None)
    validator.argument_spec = {}
    parameters = {}
    validator._deprecations = []
    validator._warnings = []
    result = ValidationResult(parameters)
    result._no_log_values.update(set_fallbacks(validator.argument_spec, result._validated_parameters))
    alias_warnings = []
    alias_deprecations = []
    aliases = _handle_aliases(validator.argument_spec, result._validated_parameters, alias_warnings, alias_deprecations)
    legal_inputs = _get_legal_inputs(validator.argument_spec, result._validated_parameters, aliases)

# Generated at 2022-06-11 00:55:17.373696
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})

    result = validator.validate({'name': 'bo'})

    assert result.validated_parameters == {'name': 'bo'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-11 00:55:27.267625
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = [{'type': 'int'}]

    v = ArgumentSpecValidator(*args)
    x = v.validate(parameters={'a':1})
    assert x.validated_parameters == {'a': 1}

    args = [{'type': 'int'}]

    v = ArgumentSpecValidator(*args)
    x = v.validate(parameters={'a': '1'})
    assert x.validated_parameters == {'a': 1}

    args = [{'type': 'str'}]

    v = ArgumentSpecValidator(*args)
    x = v.validate(parameters={'a': '1'})
    assert x.validated_parameters == {'a': '1'}

    args = [{'type': 'int'}]

    v

# Generated at 2022-06-11 00:55:49.357951
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'fav_numbers': {'type': 'list', 'default': [1, 3, 5]},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'fav_numbers': [1, 2, 3, 4],
        '_ansible_no_log': True,
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-11 00:56:00.039078
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import warnings
    import sys
    import os
    sys.path.append("..")
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 00:56:00.728945
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-11 00:56:09.583618
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'one': {'type': 'str', 'required': True},
        'two': {'type': 'int', 'required': False, 'default': 42},
        'three': {'type': 'dict', 'required': False, 'default': {}},
        'four': {'type': 'str', 'required': True},
        'five': {'type': 'str', 'required': False, 'default': 'bo', 'aliases': ['six']},
        'seven.eight': {'type': 'str', 'required': True},
    }

    mutually_exclusive = [['one', 'four']]
    required_if = [
        ["one", "foo", ["two", "three"]],
        ["one", "bar", "five"],
    ]


# Generated at 2022-06-11 00:56:20.218195
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # dummies
    parameters = dict(yes=True)
    version = "1.0.0"
    date = "2020-06-26"
    collection_name = "amazon.aws"

    # prepare
    argument_spec = {'yes': {'type': 'bool', 'aliases': ['Yes']}}
    validator = ModuleArgumentSpecValidator(argument_spec)

    # run
    result = validator.validate(parameters)

    # assert
    assert result._deprecations == [{'name': 'Yes', 'version': version, 'date': date, 'collection_name': collection_name}]
    assert result._warnings == [{'option': 'yes', 'alias': 'Yes'}]


if __name__ == "__main__":
    test_ModuleArgumentSpecValidator_validate

# Generated at 2022-06-11 00:56:29.527146
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({}, required_together=None, required_one_of=None, required_by=None, argument_spec={})
    p = {'name': 'bo', 'age': '42'}

    result = v.validate(p)

    assert result.error_messages == ['Parameter "name" of type <class \'str\'> is required.', 'Parameter "age" of type <class \'str\'> is required.']
    # assert result.unsupported_parameters == None
    # assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert result.validated_parameters == {}
    assert result._warnings == []
    assert result._deprecations == []

# Generated at 2022-06-11 00:56:35.680187
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_native
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors == []

    assert 'name' in result._validated_parameters
    assert 'age' in result._validated_parameters

    assert result._validated_parameters['name'] == 'bo'


# Generated at 2022-06-11 00:56:46.651545
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['years']},
    }
    invalid_params = {
        'name': 'bo',
        'age': '',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(invalid_params)
    assert len(result.errors) == 1
    assert result.error_messages[0] == "invalid int value"
    valid_params = result.validated_parameters
    assert valid_params == {'name': 'bo', 'age': None}
    assert 'age' in validator._valid_parameter_names
    assert 'age (years)' in validator._valid_parameter_names

# Generated at 2022-06-11 00:56:52.510179
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int', 'required': True},
        'name': {'type': 'str', 'required': True},
    }

    parameters = {
        'age': '42',
        'name': 'bo',
    }

    assert ArgumentSpecValidator(argument_spec).validate(parameters).validated_parameters == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-11 00:57:01.762253
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes, to_native


    # Capture the output of the deprecate and warn functions
    class WritableObject(object):
        # pylint: disable=missing-docstring
        def __init__(self):
            self.content = []

        def write(self, st):
            self.content.append(st)

    writable_output = WritableObject()


# Generated at 2022-06-11 00:57:37.582314
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    def test_impl(parameters, expected_errs):
        params = dict(parameters)
        error_msg = "Validation failed: {0}".format(", ".join(expected_errs))
        argument_spec = dict(
            one=dict(type='str'),
            two=dict(type='int'),
            three=dict(type='bool')
        )
        validator = ArgumentSpecValidator(argument_spec)
        result = validator.validate(params)
        if result.error_messages:
            sys.exit(error_msg)

    parameters = dict(one='foo', two='1', three='true')
    expected_errs = ['\'two\' is not one of [\'bool\']']
    test_impl(parameters, expected_errs)