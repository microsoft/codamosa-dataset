

# Generated at 2022-06-11 00:47:50.338287
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import unittest

    from ansible.module_utils.common.warnings import reset_deprecations, reset_warnings
    from ansible.module_utils._text import to_bytes, to_native

    class TestModuleArgumentSpecValidator(unittest.TestCase):
        """Test class for ModuleArgumentSpecValidator"""


# Generated at 2022-06-11 00:48:01.935052
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']

    required_one_of = [['name', 'age']]

    required_if = [
        ['name', 'John', ['age']]
    ]

    obj = ArgumentSpecValidator(argument_spec=argument_spec,
                                mutually_exclusive=mutually_exclusive,
                                required_one_of=required_one_of,
                                required_if=required_if)
    assert set(obj._valid_parameter_names) == set(['name', 'age'])
    assert obj.argument_spec == argument_spec
    assert obj._mutually_exclusive == mutually_exclusive
    assert obj._required_if == required

# Generated at 2022-06-11 00:48:13.699277
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''
    Test module for ArgumentSpecValidator
    '''
    # Create a validator for argument spec

# Generated at 2022-06-11 00:48:24.926808
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import ResetWarningFilters
    from ansible.module_utils.six import StringIO

    argument_spec = {
        "name": {
            "type": "str",
            "aliases": ["name1", "name2"]
        }
    }

    mutually_exclusive = [
        ["key1", "key2"],
        ["key3", "key4"]
    ]

    required_together = [
        ["key1", "key2"],
        ["key3", "key4"]
    ]

    required_if = [
        ["key1", "key2", ["key5"]],
        ["key3", "key4", ["key6"]]
    ]


# Generated at 2022-06-11 00:48:37.261359
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # argument spec
    argument_spec = dict(
        name=dict(type=str),
        age=dict(type=int, default=42)
    )
    # parameters
    parameters = dict(name='bo', age='42')
    # mutually_exclusive
    mutually_exclusive = None
    # required_together
    required_together = None
    # required_one_of
    required_one_of = None
    # required_if
    required_if = None
    # required_by
    required_by = None


# Generated at 2022-06-11 00:48:45.104778
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    #  test ModuleArgumentSpecValidator.validate()
    module_argument_spec_validator = ModuleArgumentSpecValidator(
        mutually_exclusive=None,
        required_if=None,
        required_one_of=None,
        required_by=None,
        required_together=None
    )
    assert module_argument_spec_validator.validate({}) == {
        '_ansible_verbosity': 0,
        '_ansible_version': '2.10.0',
        '_ansible_base_dir': '/Users/joseph.leahy/dev/ansible',
        '_ansible_no_log': False,
        '_ansible_mode': 'playbook'
    }

# Generated at 2022-06-11 00:48:54.983399
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warning import warn
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.six import string_types

    error_msg = "required argument: %s"
    mutually_exclusive_msg = "parameters are mutually exclusive: %s"

    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int'},
    }

    # Test the required argument
    parameters = {
        'age': 123
    }

# Generated at 2022-06-11 00:49:07.113168
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'info': {'type': 'dict'},
    }

    mutually_exclusive = [['info']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'John', ['age']]]
    required_by = {'name': ['age'], 'age': ['name']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)

    assert isinstance(validator, ArgumentSpecValidator)
    assert validator._mutually_exclusive == mutually_exclusive
    assert valid

# Generated at 2022-06-11 00:49:14.220419
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str', 'required': True}, 'age': {'type': 'int', 'required': True}}

    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:49:23.250752
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator
    """
    # Prepare
    kwargs = {
        'argument_spec': {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    }
    instance = ModuleArgumentSpecValidator(*args, **kwargs)
    name = 'validate'
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    expected = {
        'name': 'bo', 
        'age': 42,
    }
    # Execute
    result = getattr(instance, name)(parameters)
    # Verify
    assert result.validated_parameters == expected



# Generated at 2022-06-11 00:49:27.057425
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:49:38.075909
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg_spec = dict(
        a=dict(type='int'),
        b=dict(type='int'),
        c=dict(type='int'),
        d=dict(type='int')
    )

    # required_if, required_by
    validationResult = ModuleArgumentSpecValidator(
        argument_spec=arg_spec,
        mutually_exclusive=[['a', 'b', 'c']],
        required_together=[['a', 'b', 'c']],
        required_one_of=[['a', 'b']],
        required_if=[['a', 'b', ['c']]],
        required_by=[['a', ['c', 'd']]]
    ).validate(dict(a='1', b='2', c='3', d='4'))
    assert len(validationResult.errors)

# Generated at 2022-06-11 00:49:47.169358
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    header_spec = {
        'params': {'type': 'dict'},
        'rsp': {'type': 'dict'},
    }

    rsp_specs = {
        'rsp1': {'type': 'str'},
        'rsp2': {'type': 'int'},
    }


# Generated at 2022-06-11 00:49:58.748748
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import DEFAULT_VALIDATION_ARGUMENT_SPEC

    validator = ModuleArgumentSpecValidator(DEFAULT_VALIDATION_ARGUMENT_SPEC)

    def assert_validated_parameters(parameters, **expected_values):
        result = validator.validate(parameters)
        for key, expected in expected_values.items():
            assert result.validated_parameters[key] == expected

    # test with simple argument spec
    assert_validated_parameters({'name': 'bo'}, name='bo')
    assert_validated_parameters({'age': '42'}, age=42)

    # test no_log_value

# Generated at 2022-06-11 00:50:07.547230
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def _my_argument_spec():
        return {
            'name': {'type': 'str', 'aliases': ['first_name']},
            'age': {'type': 'int'},
        }

    def _my_parameters():
        return {
            'name': 'bo',
            'age': '42',
        }

    mock_warn = 'ansible.module_utils.common.warnings.warn'
    mock_deprecate = 'ansible.module_utils.common.warnings.deprecate'

    with mock.patch(mock_warn) as my_warn:
        with mock.patch(mock_deprecate) as my_deprecate:
            validator = ModuleArgumentSpecValidator(_my_argument_spec())

# Generated at 2022-06-11 00:50:17.687125
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def mock_module_validate(self):
        self._deprecations = []
        self._warnings = []

    from unittest.mock import MagicMock

    # setup
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}},
                                            {'one': ['two', 'three']},
                                            [['one', 'two']],
                                            [['one', 'two', ['three', 'four']]])
    validator.module = MagicMock()
    validator.module.validate_deprecations_warnings = mock_module_validate
    validator.module.params = {'two': 'value2'}

    # Execute
    result = validator.validate({'two': 'value2'})

    # Assert
    assert result

# Generated at 2022-06-11 00:50:26.175460
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Test the validate method of class ArgumentSpecValidator.
    """
    # Simple test case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors
    assert len(result.errors) == 1

# Generated at 2022-06-11 00:50:36.558901
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ArgumentSpecValidator_validate testing"""
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments

    # test when everything is ok
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters, is_powershell=True)
    assert result._validated_parameters['name'] == 'bo'
    assert result._validated_parameters['age'] == 42
    assert result._

# Generated at 2022-06-11 00:50:41.898807
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                }

    parameters = {
                    'name': 'bo',
                    'age': '42',
                }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == {
                    'name': 'bo',
                    'age': 42,
                }

    assert result.errors == AnsibleValidationErrorMultiple()

    assert result.error_messages == []

# Generated at 2022-06-11 00:50:53.082320
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test the ArgumentSpecValidator.validate method."""


# Generated at 2022-06-11 00:51:11.171881
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # _deprecations contains 2 dicts with 2 separate elements each; we are testing to be sure we get all 4, not just 2
    args = (['alias1', 'alias2'], ['alias3', 'alias4'])
    dep_warns = []
    depr_warns = []
    for arg in args:
        dep_warns.append({'name': arg, 'date': 'version 0.0', 'version': 'today', 'collection_name': ''})
        depr_warns.append({'name': arg, 'date': 'version 0.0', 'version': 'today', 'collection_name': ''})

    argument_spec = {'name': {'type': 'str', 'aliases': ['alias1', 'alias2'], 'default': 'default_name'}}

# Generated at 2022-06-11 00:51:22.967881
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    class ModuleArgumentSpecValidatorTestClass(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     required_if=None, required_by=None):
            super(ModuleArgumentSpecValidatorTestClass, self).__init__(argument_spec,
                                                                       mutually_exclusive,
                                                                       required_together,
                                                                       required_one_of,
                                                                       required_if,
                                                                       required_by)
    mutually_exclusive = [['name', 'age'], ['name', 'birthday']]
    required_if = [['age', '42', ['name']]]


# Generated at 2022-06-11 00:51:23.839263
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False, "Test not implemented"

# Generated at 2022-06-11 00:51:35.812971
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
        ['state', 'absent'],
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
        ['state', 'absent'],
    ]
    required_if = [
        ['name', 'Bob', ['age']],
        ['state', 'present', ['age']],
    ]
    required_by = {
        'name': ['age'],
    }

# Generated at 2022-06-11 00:51:46.934714
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:51:57.845989
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text

    kwargs = dict()
    result = dict()
    # argument_spec for module ArgumentSpecValidator

# Generated at 2022-06-11 00:52:09.521490
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    paras = {"name": "John", "age": "42"}
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(paras)
    assert result.validated_parameters == {'name': 'John', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []
    for w in result._warnings:
        warn('Both option {option} and its alias {alias} are set.'.format(option=w['option'], alias=w['alias']))
    paras = {"name": "John", "age": "sixty"}
    result = validator.validate(paras)
    assert result.validated_

# Generated at 2022-06-11 00:52:18.109152
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Case 1: no error occurred
    argument_spec = {
        'name': {'type': 'str'},
        'age':  {'type' : 'int', 'default': 18},
    }
    parameters = {
        'name': 'bo',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages

    # Case 2: error occurred
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.error_messages
    assert len(result.error_messages) == 1
    assert "int" in result.error_messages[0]

# Generated at 2022-06-11 00:52:25.995094
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert not result.error_messages

    valid_params = result.validated_parameters

    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-11 00:52:37.220775
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator."""

    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self):
            self.basic = None
            self.check_mode = False
            self.debug = False
            self.deprecations = []
            self.fail_json = lambda **kwargs: kwargs
            self.fail_on_missing_lib = True
            self.error_msg = None
            self.log = lambda **kwargs: None
            self.no_log = []
            self.version_warning_msg = None
            self.warnings = []

        def run_command(self, cmd):
            pass

    parameters = {
        'name': 'bo',
        'age': '42',
    }

   

# Generated at 2022-06-11 00:53:03.524502
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'legal_adult': {'type': 'bool'},
        'jobs': {'type': 'list'},
        'siblings': {'type': 'dict'},
    }

    mutually_exclusive = [
        'legal_adult', ['age', 'jobs'],
    ]

    required_together = [
        ['age', 'jobs'],
    ]

    required_one_of = [
        ['legal_adult', 'siblings'],
    ]

    required_if = [
        ['name', 'bo', ['age', 'legal_adult']],
        ['name', 'bob', ['siblings', 'jobs']],
    ]


# Generated at 2022-06-11 00:53:12.254875
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'str',
            'fallback': (str, bool)
        },
        'age': {
            'type': 'int',
        }
    }
    parameters = {
        'name': ['bo', '42']
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result
    assert isinstance(result.errors, list)
    assert "must be str" in result.errors[0].message
    assert isinstance(result.errors[0], RequiredDefaultError)

# Generated at 2022-06-11 00:53:23.748804
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module = 'test_ModuleArgumentSpecValidator_validate'
    data = {
        'argument_spec': {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        'parameters': {
            'name': 'bo',
            'age': '42',
        },
        'expected_result': {
            'validated_parameters': {
                'name': 'bo',
                'age': 42,
            },
            'error_messages': [],
        },
    }

    validator = ModuleArgumentSpecValidator(data['argument_spec'])
    result = validator.validate(data['parameters'])


# Generated at 2022-06-11 00:53:32.642329
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Validate the method validate from class ModuleArgumentSpecValidator """
    from ansible.module_utils.common.warnings import RedirectWarning

    import sys
    import warnings
    import argparse

    parser = argparse.ArgumentParser(description='Test')
    parser.add_argument('--collection-name', type=str)

    args, _ = parser.parse_known_args()
    if args.collection_name:
        sys.modules['ansible_collections.' + args.collection_name + '.tests.unit.common'] = sys.modules['ansible.module_utils.common']

    # Test case 1

# Generated at 2022-06-11 00:53:43.810657
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # create a validator object - class ModuleArgumentSpecValidator
    argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
                'city': {'type': 'str'},
                'state': {'type': 'str'}
            }
    validator = ModuleArgumentSpecValidator(argument_spec)

    # actual name, age and city parameters of a person
    parameters = {
                'name': 'James',
                'age': 24,
                'city': 'New York'
            }

    # expected validation result

# Generated at 2022-06-11 00:53:52.215078
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'test': {'type': 'str', 'choices': ['test1', 'test2']}}
    parameters = {'test': 'test1'}
    parameters1 = {'test': 'test11'}
    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)
    result1 = validator.validate(parameters1)

    assert len(result.error_messages) == 0, "No error messages"
    assert len(result1.error_messages) == 1, "One error message"

# Generated at 2022-06-11 00:53:58.508300
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:54:09.417029
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors.messages) == 0

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 'abc',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate

# Generated at 2022-06-11 00:54:19.356600
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case when mutually_exclusive options are set
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'ignore_errors': 'yes',
    }
    mutually_exclusive = [["name", "age"]]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive)
    result = validator.validate(parameters)

    # Check mutually_exclusive errors
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], MutuallyExclusiveError)
    assert result.errors.messages == ['name, age are mutually exclusive']



# Generated at 2022-06-11 00:54:29.499517
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    ModuleArgumentSpecValidator.validate() Test
    """

# Generated at 2022-06-11 00:55:00.184655
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test that all deprecations and warnings are displayed in this function."""
    result = ModuleArgumentSpecValidator({'option': {'required': False}, 'alias': {'aliases': ['option']}}).validate({'option': 'opt', 'alias': 'alias'})
    assert result.errors == []
    assert result.validated_parameters == {'option': 'opt', 'alias': 'alias'}

# Unit tests for module_common._get_declared_argument_spec()

# Generated at 2022-06-11 00:55:10.691267
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }
    mutually_exclusive = []
    validator = ModuleArgumentSpecValidator(argument_spec, [], None, None, None, None, mutually_exclusive)

    # test valid case
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    # test invalid type case

# Generated at 2022-06-11 00:55:17.599570
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    val_result = validator.validate(parameters)
    assert val_result.validated_parameters['name'] == 'bo'
    assert val_result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:55:27.474658
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [
        ['server', 'product'],
        ['server', 'product_version'],
        ['product', 'product_version'],
    ]
    required_if = [
        ['product', 'os', ['product_version']],
        ['product', 'os', ['type']],
    ]
    argument_spec = {
        'server': {
            'type': 'str',
        },
        'product': {
            'type': 'str',
            'choices': ['os', 'rhel']
        },
        'product_version': {
            'type': 'str'
        },
    }

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            required_if=required_if,
                                            mutually_exclusive=mutually_exclusive)


# Generated at 2022-06-11 00:55:29.742505
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Create instance of ArgumentSpecValidator
    spec = ArgumentSpecValidator({}, [], [], [], [], {})
    assert spec

# Generated at 2022-06-11 00:55:40.357242
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: rewrite the unit test to not use a partial class
    class ansibleModule:
        def __init__(self, argument_spec, mutually_exclusive=None,
                     required_together=None, required_one_of=None,
                     required_if=None, required_by=None ):
            self._ansible_debug = True
            self.argument_spec = argument_spec
            self._ansible_mutually_exclusive = mutually_exclusive
            self._ansible_required_together = required_together
            self._ansible_required_one_of = required_one_of
            self._ansible_required_if = required_if
            self._ansible_required_by = required_by

        def exit_json(self, **kwargs):
            pass

        def fail_json(self, **kwargs):
            pass

# Generated at 2022-06-11 00:55:47.664798
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class AnsibleModule_class:
        def run_command(self, args, check_rc=True):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = AnsibleModule_class
    m = ArgumentSpecValidator({})
    result = m.validate({})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert not result.error_messages


# Generated at 2022-06-11 00:55:48.198050
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    pass

# Generated at 2022-06-11 00:55:58.598156
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:56:05.684548
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test the ArgumentSpecValidator validate method."""

    actual = ArgumentSpecValidator({'name': {'type': 'str', 'required': True}, 'age': {'type': 'int'}}).validate({'name': 'bo', 'age': '42'})
    assert(isinstance(actual, ValidationResult))
    assert(actual.validated_parameters == {'name': 'bo', 'age': 42})
    assert(actual.unsupported_parameters == set())
    assert(actual.error_messages == [])

# Generated at 2022-06-11 00:56:55.952769
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        "arg1": {"type": "str"},
        "arg2": {"type": "str"},
        "arg3": {"type": "str"},
        "arg4": {"type": "str", "required": True},
        "arg5": {
            "type": "dict",
            "argument_spec": {
                "arg6": {"type": "str"},
                "arg7": {"type": "str", "required": False}
            }
        }
    }

    mutually_exclusive = [["arg1", "arg2"]]
    required_if = [["arg1", "present", ["arg2"]],
                   ["arg2", "present", ["arg1"]]]


# Generated at 2022-06-11 00:57:04.058307
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_arg_spec_validator = ModuleArgumentSpecValidator({"foo": {"type": "bool", "deprecated": {"version": "2.2", "collection_name": 'community.general'}}},
                                                            mutually_exclusive=[],
                                                            required_together=[],
                                                            required_one_of=[],
                                                            required_if=[],
                                                            required_by=[])
    parameters = {"foo": True}
    module_arg_spec_validator.validate(parameters)
    # no exception raised

# Generated at 2022-06-11 00:57:14.326970
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    def validate_mutually_exclusive(self, parameters):
        if parameters['param1'] and parameters['param2']:
            raise TypeError('param1 and param2 cannot be used together.')

    mutually_exclusive = [
        validate_mutually_exclusive
    ]

    argument_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str'},
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = {
        'param1': 'test',
        'param2': 'test',
    }

    result = validator.validate(parameters)

    assert result.validated_parameters == {}
    assert len(result.error_messages) == 1

# Generated at 2022-06-11 00:57:23.390761
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockModuleArgumentSpecValidator:
        def warn(self, msg):
            print(msg)

        def deprecate(self, msg, version=None, date=None, collection_name=None):
            print(msg)

    import unittest

    class TestModuleArgumentSpecValidator(unittest.TestCase):
        def test_validate_Alias(self):
            argument_spec = {
                'name': {
                    'type': 'str',
                    'aliases': ['count']
                }
            }
            mutually_exclusive = None
            required_together = None
            required_one_of = None
            required_if = None
            required_by = None

            parameters = {
                'name': 'bob',
                'count': '12'
            }

            validator = ModuleArgumentSpec

# Generated at 2022-06-11 00:57:34.482221
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [['ping', 'playbook']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'baz']]
    required_if = [['foo', 'yes', ['bar', 'baz']]]
    required_by = {'bar': ['baz']}
