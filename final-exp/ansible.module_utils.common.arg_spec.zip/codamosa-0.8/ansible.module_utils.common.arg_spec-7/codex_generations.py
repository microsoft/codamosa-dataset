

# Generated at 2022-06-11 00:47:50.801119
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    #Test1
    argument_spec = {
        'test1': {'type': 'str', 'aliases': ['t1']},
    }
    mutually_exclusive = ['test1']
    required_together = [['test1']]
    required_one_of = [['test1']]
    required_if = [['test1', 'good', ['test2', 'test3']]]
    parameters = {'test1': 'good'}
    unsupported_parameters = ['test2', 'test3']
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive,required_together,
                                            required_one_of, required_if)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:48:02.144763
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def test_action(parameters, *args, **kwargs):
        validator = ArgumentSpecValidator(argument_spec)
        try:
            result = validator.validate(parameters, *args, **kwargs)
            if result.error_messages:
                raise ValueError(result.error_messages)
            return result.validated_parameters
        except ValueError as e:
            return e

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    res = test_action(parameters)

    assert parameters['name'] == 'bo'
    assert parameters['age'] == '42'

# Generated at 2022-06-11 00:48:13.955899
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None,
                     required_one_of=None, required_if=None, required_by=None,):
            super(MockModuleArgumentSpecValidator, self).__init__(argument_spec, mutually_exclusive, required_together,
                                                                  required_one_of, required_if, required_by)
        def _deprecate(self, msg):
            pass

    SPEC = {
        'arg1': {'type': 'str'},
        'arg2': {'type': 'int', 'default': 0},
    }


# Generated at 2022-06-11 00:48:25.421005
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def check_validate(parameters, expected_errors, expected_warnings):
        argument_spec = {
            'name': {'type': 'str', 'aliases': ['alternative_name']},
            'age': {'type': 'int'},
        }

        validator = ModuleArgumentSpecValidator(
            argument_spec=argument_spec,
        )

        actual_errors = []
        actual_warnings = []
        def mock_error(*args, **kwargs):
            actual_errors.append(args[0])  # pylint: disable=unsubscriptable-object

        def mock_warn(*args, **kwargs):
            actual_warnings.append(args[0])  # pylint: disable=unsubscriptable-object

        validator.validate(parameters)

        assert expected

# Generated at 2022-06-11 00:48:26.108325
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:48:38.224375
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class TestErrors:
        # Constructor
        def __init__(self):
            self.msgs = []

        def append(self, msg):
            self.msgs.append(msg)

    class TestValidator(ArgumentSpecValidator):
        def __init__(self):
            self.argument_spec = {}

    check_validation_error = "Validation error was not added to the object."
    # setup required values
    parameters = {}
    argument_spec = {}
    # setup unrequired values
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    # Test with required values
    TestValidator = TestValidator()
    TestValidator.validate(parameters)
    # Test with all values
   

# Generated at 2022-06-11 00:48:46.106919
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.arg_spec import (
        ArgumentSpecValidator,
        ModuleArgumentSpecValidator,
        ValidationResult,
    )
    from ansible.module_utils.common import warnings
    import pytest

    @pytest.fixture
    def mocker_warnings(mocker):
        mocker.patch('ansible.module_utils.common.warnings.warn')

    @pytest.fixture
    def mocker_deprecate(mocker):
        mocker.patch('ansible.module_utils.common.warnings.deprecate')


# Generated at 2022-06-11 00:48:52.115490
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:49:04.888410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'test': {'type': 'str'}}
    mutually_exclusive = [['a', 'b']]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    parameters = {'a': 'a', 'b': 'b'}
    assert validator.validate(parameters).errors == [MutuallyExclusiveError('a and b are mutually exclusive')]

    parameters = {'test': 'a'}
    assert validator.validate(parameters).errors == [], validator.validate(parameters).errors

    argument_spec = {'test': {'type': 'str', 'aliases': ['b']}}
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

# Generated at 2022-06-11 00:49:12.467722
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create test data
    argument_spec = dict(dest=dict(type='path'))
    parameters = dict(dest='/')
    dep_warnings = []
    dep_deprecations = []

    # Define behavior
    alias_warnings = dict()

    # Run test
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Verify results
    assert result.validated_parameters == dict(dest='/')



# Generated at 2022-06-11 00:49:25.846844
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg_spec_validator = ModuleArgumentSpecValidator(argument_spec={})

    # test if error raised on non dict param
    result = arg_spec_validator.validate(parameters=2)
    assert result.error_messages

# Generated at 2022-06-11 00:49:36.779450
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
        "height": {"type": "float"},
        "school": {"type": "bool"},
        "address": {"type": "dict",
                    "spec": {
                        "street": {"type": "str" },
                        "zip": {"type": "str"},
                        "state": {"type": "str", "default": "CA"},
                        "credits": {"type": "list", "default": [{"taken": 3, "grade": "A"}, {"taken": 4, "grade": "C"}] },
                    },
                    "default": {"credits": [{"taken": 4, "grade": "D"}]}},
    }

    validator = ArgumentSpecValidator(argument_spec=spec)

# Generated at 2022-06-11 00:49:44.011436
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    #Empty argument_spec is acceptable, no args are required
    ArgumentSpecValidator({})

    # check keyword arguments are valid
    ArgumentSpecValidator({}, mutually_exclusive=[['a', 'b']],
        required_together=[['a', 'b']], required_one_of=[['a', 'b']],
        required_if=[['a', 'x', ['b', 'c']]], required_by=[['a', ['b', 'c']]])

    # check mutually_exclusive requires a list of lists or a list and is not empty
    try:
        ArgumentSpecValidator({}, mutually_exclusive={})
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError, got no exception")

# Generated at 2022-06-11 00:49:55.773660
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.basic import AnsibleModule
    from textwrap import dedent

    spec = {
        "test": {
            "type": "bool",
            "default": False,
            "required": False,
        },
        "test2": {
            "type": "bool",
            "default": False,
            "required": False,
        },
        "test3": {
            "type": "bool",
            "default": False,
            "required": False,
        },
        "test4": {
            "type": "bool",
            "default": False,
            "required": False,
        },
    }

    m = AnsibleModule(spec, {'test': 'TestMe'})


# Generated at 2022-06-11 00:50:04.109381
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'str',
        },
        'age': {
            'type': 'int',
        },
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'not_supported': 'this is not supported',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == {'not_supported'}
    assert result.error_messages == []

# Generated at 2022-06-11 00:50:15.558774
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # test for the case when deprecations exist
    # The test parameters are the same as from the test case in run_tests.py
    # The deprecation elements in _deprecations look like:
    # {'collection_name': None, 'date': None, 'name': 'port', 'version': '2.9'}
    parameters = {'host': 'localhost', 'port': '443'}
    argument_spec = {
      'host': {'required': True, 'aliases': ['ansible_host', 'ansible_ssh_host']},
      'port': {'type': 'int', 'required': True, 'aliases': ['ansible_port', 'ansible_ssh_port']},
    }
    mutually_exclusive = [
        ['host', 'connection']
    ]

# Generated at 2022-06-11 00:50:27.088914
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    method validate of class ArgumentSpecValidator
    """

    from ansible.module_utils import common as module_utils_common
    from _io import StringIO

    class AnsibleModule:
        def __init__(self, argument_spec={}, mutually_exclusive=[], required_one_of=[], add_file_common_args=True, supports_check_mode=False, required_together=[]):
            # The AnsibleModule object will be passed to the validate() method
            # of the ArgumentSpecValidator object as the first parameter
            # It will also be passed to the __init__ method of the module as a named parameter,
            # usually 'self' in the argument list
            self._log = StringIO()

        def _log(self, msg, level=None):
            '''
            write a message to the log
            '''

# Generated at 2022-06-11 00:50:28.433814
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass



# Generated at 2022-06-11 00:50:33.280513
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({}, mutually_exclusive=['foo', 'bar'])
    result = validator.validate({'foo': 'a', 'bar': 'b'})
    assert result.errors
    assert len(result.errors) == 1
    assert result.errors[0].args[0] == 'Parameters foo and bar are mutually exclusive'

# Generated at 2022-06-11 00:50:40.317760
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    filename = "file.txt"


# Generated at 2022-06-11 00:50:54.206930
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    arguments = {'a': 'b'}
    argument_spec = {
        "argument_a": {"type": "str"},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    _validator = ModuleArgumentSpecValidator(argument_spec,
                                             mutually_exclusive=mutually_exclusive,
                                             required_together=required_together,
                                             required_one_of=required_one_of,
                                             required_if=required_if,
                                             required_by=required_by)

    with pytest.raises(AnsibleValidationErrorMultiple):
        _validator.validate(arguments)

# Generated at 2022-06-11 00:51:05.768188
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Validate all 3 major scenarios(required, mutually exclusive, subspec)"""
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'ip': {
            'type': 'str',
            'required': True
        },
        'option': {
            'type': 'str',
            'choices': ['one', 'two']
        },
        'nested-options': {
            'type': 'dict',
            'required': True,
            'options': {
                'type': 'dict',
                'required': True,
                'options': {
                    'foo': {
                        'type': 'str'
                    }
                }
            }
        }
    }

# Generated at 2022-06-11 00:51:12.417027
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    This function tests the validate method of ModuleArgumentSpecValidator class
    :return:
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:51:23.194527
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name"]]
    required_if = []
    required_by = {'name': ["age"]}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)

    assert 'name, age' in validator._valid_parameter_names
    assert 'name' in validator._valid_parameter_names

# Generated at 2022-06-11 00:51:28.981380
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_arg_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )
    parameters = dict(
        name='bo',
        age='42',
    )
    validator = ModuleArgumentSpecValidator(argument_spec=module_arg_spec)
    result = validator.validate(parameters=parameters)
    assert result.error_messages == []
    assert result.validated_parameters == dict(
        name='bo',
        age=42,
    )
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:51:40.707964
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [('name', 'age')]
    req_by = {'param1': ['param2', 'param3', 'param4']}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'param1': {'type': 'raw'},
        'param2': {'type': 'raw'},
        'param3': {'type': 'raw'},
        'param4': {'type': 'raw'},
    }

    # Create a validator instance
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive, required_by=req_by)

    # Check for mutually exclusive parameters
    parameters = {'name': 'bat', 'age': 42}
    result = valid

# Generated at 2022-06-11 00:51:50.475577
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import tempfile
    import shutil
    import os
    import textwrap
    import runpy
    import importlib
    import subprocess
    import io
    import contextlib
    from tempfile import TemporaryFile
    from contextlib import redirect_stdout

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    def get_generated_module(argspec, module_name, extra_options=dict()):
        '''Generate a temporary module that can be imported from a temporary directory'''
        module_name = "{0}{1}".format("ansible_module_", module_name)
        tempdir = tempfile.mkdtemp()
        test_module = os.path.join(tempdir, "{0}.py".format(module_name))


# Generated at 2022-06-11 00:52:02.653592
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert not result.unsupported_parameters
    assert not result.error_messages

    spec = {
        'name': {'type': 'list', 'elements': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validator = Module

# Generated at 2022-06-11 00:52:11.072371
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    valid_params = result.validated_parameters

    assert result.error_messages == []
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42
    assert result.unsupported_parameters == set()


# Generated at 2022-06-11 00:52:20.778638
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = dict(
        arg1=dict(type='str'),
        arg2=dict(type='str'),
        arg3=dict(type='str', required=True, no_log=True),
        arg4=dict(type='str', required=True, no_log=True),
        arg5=dict(type='dict', required=True, no_log=True, options=dict(
            subarg1=dict(type='str'),
            subarg2=dict(type='str'),
            subarg3=dict(type='str', required=True, no_log=True),
            subarg4=dict(type='str', required=True, no_log=True),
        )),
    )


# Generated at 2022-06-11 00:52:39.906340
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "testmandatory": {'required': True, 'type': 'str'},
        "testdefault": {'required': False, 'type': 'str', 'default': 'defaultval'},
        "testchoices": {'required': False, 'type': 'str', 'choices': ['choices1', 'choices2']},
        "testnestedspec": {'required': False, 'type': 'dict', 'options': {
            "test1": {'required': False, 'type': 'int'},
            "test2": {'required': False, 'type': 'str'}
        }}
    }

    mutually_exclusive = [['testdefault', 'testchoices'], ['testmandatory']]


# Generated at 2022-06-11 00:52:43.350338
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)
    assert validator is not None


# Generated at 2022-06-11 00:52:55.886183
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class ArgumentsValidator:
        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None, required_one_of=None,
                     required_if=None, required_by=None):
            self.argument_spec = argument_spec
            self._mutually_exclusive = mutually_exclusive
            self._required_together = required_together
            self._required_one_of = required_one_of
            self._required_if = required_if
            self._required_by = required_by
            self._valid_parameter_names = set()

            for key in sorted(self.argument_spec.keys()):
                self._valid_parameter_names.add(key)

        def __call__(self, *args, **kwargs):
            pass



# Generated at 2022-06-11 00:53:05.353735
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [['name', 'bo', ['age']]]

    required_by = {
        'name': ['age'],
        'age': ['name']
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)



# Generated at 2022-06-11 00:53:11.367758
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Test ModuleArgumentSpecValidator validate method
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(parameters)

# Generated at 2022-06-11 00:53:12.056210
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:53:23.619474
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    This test method expects that deprecation and warning error messages are shown when they are triggered.
    """
    message = None

    alias_warnings = []
    alias_deprecations = []
    def mock_handle_aliases(argument_spec, params, warnings, deprecations):
        warnings.extend(alias_warnings)
        deprecations.extend(alias_deprecations)
        return {}

    # Mocks
    deprecate = lambda message: None
    warn = lambda message: None
    _handle_aliases = mock_handle_aliases
    _list_no_log_values = lambda *args: None
    _get_unsupported_parameters = lambda *args: None
    check_mutually_exclusive = lambda *args: None
    check_required_arguments = lambda *args: None


# Generated at 2022-06-11 00:53:29.060112
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-11 00:53:37.869269
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit Test for method 'validate' of class ArgumentSpecValidator"""

    validArgumentSpecList = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'isActive': {'type': 'bool'},
    }
    validator = ArgumentSpecValidator(validArgumentSpecList)

    validParameters = {
        'name': 'bo',
        'age': '42',
        'isActive': True
    }
    result = validator.validate(validParameters)
    assert result.error_messages == []



# Generated at 2022-06-11 00:53:48.842460
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.parameters import (
        ARG_ATTRIBUTES,
        ARG_TYPES,
    )


# Generated at 2022-06-11 00:54:28.632850
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'example_name': 'bo',
              'example_age': '42'}

    argument_spec = {'example_name': {'type': 'str'},
                     'example_age': {'type': 'int'}}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-11 00:54:35.408152
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Argument spec validation class used by :class:`AnsibleModule`.

    This is not meant to be used outside of :class:`AnsibleModule`. Use
    :class:`ArgumentSpecValidator` instead.
    """

    module_arg_spec = {'foo': {'type': 'str'}}
    result = ModuleArgumentSpecValidator(argument_spec=module_arg_spec).validate({'foo': 'bar'})
    
    assert result is not None

# Generated at 2022-06-11 00:54:42.296590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []


# Generated at 2022-06-11 00:54:53.449723
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive

    m = ModuleArgumentSpecValidator({'name': {'type': 'str'}}, mutually_exclusive=[[]])

    class module:
        params = {}

    class my_ansible_module(module):
        def fail_json(self, **kwargs):
            print(kwargs)
            raise ValueError("Failed to validate module arguments.")

        def deprecate(self, *args, **kwargs):
            self.deprecations.append(args)

        def warn(self, *args):
            self.warnings.append(args)


# Generated at 2022-06-11 00:55:01.404584
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils import basic
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils.facts.network import NetworkPrecedence
    from ansible.module_utils.facts.system import OpenBSDKernel
    from ansible.module_utils.facts.system import OpenBSDNetwork
    from ansible.module_utils.facts.system import WindowsRegistryProvider
    from ansible.module_utils.facts.system import WindowsSystemInfoProvider
    from ansible.utils.collection_loader import AnsibleCollectionFinder
    import ansible.module_utils.connection
    import ansible.module_utils.facts
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.system
    import ansible.module_utils.six
    import ansible.module_

# Generated at 2022-06-11 00:55:07.310149
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:55:14.131227
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-11 00:55:22.414404
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-11 00:55:29.203111
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-11 00:55:39.856019
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # no_log and mutually_exclusive values must not be printed as they may contain passwords
    mutually_exclusive = [['user', 'password', 'ssh_keyfile']]
    argument_spec = {
        'name': {'required': True, 'type': 'str', 'no_log': True},
        'password': {'required': True, 'type': 'str', 'no_log': True},
        'user': {'required': True, 'type': 'str', 'no_log': True},
        'ssh_keyfile': {'required': True, 'type': 'str', 'no_log': True},
        'port': {'required': False, 'type': 'int', 'default': 22},
    }


# Generated at 2022-06-11 00:56:33.729186
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''
    :author: Akshay Khaire (akhaire)
    '''
    from ansible.module_utils.six.moves.urllib.parse import unquote
    from ansible.module_utils.urls import urlsplit, urlunsplit
    from collections import namedtuple
    import json
    import os
    import sys

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import common_arg_spec
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import common_utils
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import cookie

# Generated at 2022-06-11 00:56:42.433656
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    print(valid_params)

# Generated at 2022-06-11 00:56:53.075794
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:57:02.893190
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Test failed: Validation failed: {0}".format(", ".join(result.error_messages)))

    if result.validated_parameters['age'] != 42:
        sys.exit("Test failed: Parameter value was not coerced to int")

    valid_params = result.validated_parameters

if __name__ == '__main__':
    test_ModuleArgumentSpec

# Generated at 2022-06-11 00:57:13.544618
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Given an argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    # And a validator for that argument spec
    validator = ArgumentSpecValidator(argument_spec)
    # And parameters to validate
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # When I validate the parameters
    result = validator.validate(parameters)
    # And there were errors
    if result.error_messages:
        # Then log the first error
        raise Exception("Validation failed: {0}".format(", ".join(result.error_messages)))
    # And I get the validated parameters
    valid_params = result.validated_parameters
    # Then the validated parameters

# Generated at 2022-06-11 00:57:20.564286
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:57:31.583557
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test test_ModuleArgumentSpecValidator_validate of class ModuleArgumentSpecValidator
    # mock imports
    import datetime
    import uuid

    # mock imports
    val = datetime.datetime.now()
    mock_module_utils_common_warnings = uuid.uuid4()
    mock_module_utils_common_warnings_deprecate = uuid.uuid4()

    # Mock objects
    mock_result = MagicMock()
    mock_warn = MagicMock(return_value=mock_module_utils_common_warnings_deprecate)
    mock_dep = MagicMock(return_value=mock_module_utils_common_warnings_deprecate)
    mock_validator = MagicMock()

    # set up mocks