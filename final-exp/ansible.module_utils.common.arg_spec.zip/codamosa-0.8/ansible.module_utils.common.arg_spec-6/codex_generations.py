

# Generated at 2022-06-11 00:47:50.913687
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str', 'aliases': ['name_alias']}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._warnings == [{'option': 'name', 'alias': 'name_alias'}]
    assert result._validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []

# Generated at 2022-06-11 00:47:57.112618
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={},
                                            mutually_exclusive=[],
                                            required_together=[],
                                            required_one_of=[],
                                            required_if=[],
                                            required_by={})
    assert isinstance(validator, ModuleArgumentSpecValidator)

    parameters = {}
    assert isinstance(validator.validate(parameters), ValidationResult)

# Generated at 2022-06-11 00:48:06.037985
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        print("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert 1==1

# Generated at 2022-06-11 00:48:16.522515
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test create object and validate
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test validate with unsupported parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

# Generated at 2022-06-11 00:48:28.690018
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import NoWarnAction
    from ansible.module_utils.six import string_types
    import datetime
    import warnings
    import freezegun
    import pwd
    import sys
    import tempfile
    import os

    class TestModule(object):
        def __init__(self, argument_spec, no_log=False, mutually_exclusive=None, supports_check_mode=False, required_one_of=None, required_if=None, required_together=None, required_by=None):
            warnings.filterwarnings('ignore', category=DeprecationWarning)
            self.argument_spec = argument_spec
            self.fail_json = NoWarnAction()
            self.exit_json = NoWarnAction()
            self.no_log = no_log

# Generated at 2022-06-11 00:48:40.088936
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        argument_spec=dict(
            name=dict(type='str'),
            age=dict(type='int')
        )
    )

    # return True if real error message, not simple string
    def check_error(error_message):
        if isinstance(error_message, dict):
            return True
        return False

    # check that method validate is ok with correct parameters
    valid_params = validator.validate(parameters=dict(name='bo', age=42))
    assert valid_params.validated_parameters == dict(name='bo', age=42)
    assert valid_params.error_messages == []
    assert valid_params.unsupported_parameters == []
    assert valid_params.validated_parameters == dict(name='bo', age=42)

# Generated at 2022-06-11 00:48:48.741949
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import inspect
    import os

    class ParameterSpec:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            return str(self.__dict__)

    def run_test(test_name, args_dict, expect_results_dict):
        print("Testing %s" % test_name)
        argument_spec = dict()
        for p in args_dict['parameters']:
            argument_spec[p.name] = p.argument_spec
        mutually_exclusive = args_dict.get('mutually_exclusive')
        required_together = args_dict.get('required_together')
        required_one_of = args_dict.get('required_one_of')

# Generated at 2022-06-11 00:48:57.667994
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:49:09.411554
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # create a mutable seq
    class ModuleMock:
        def __init__(self):
            self.deprecations = []

        def deprecate(self, msg, **kwargs):
            self.deprecations.append((msg, kwargs))

    # create a mutable seq
    mutable_seq = []
    def warn(msg):
        mutable_seq.append(msg)

    validator = ModuleArgumentSpecValidator(argument_spec={
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                })

    module = ModuleMock()
    parameters = {
                    'name': 'bo',
                    'age': '42',
                 }
    result = validator.validate(parameters, module=module, warn=warn)
    assert result

# Generated at 2022-06-11 00:49:20.632835
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    a = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'something': {
            'subspec': {
                'sub_name': {'type': 'str'},
                'sub_age': {'type': 'int'},
                'sub_something': {
                    'subspec': {
                        'sub_sub_name': {'type': 'str'},
                        'sub_sub_age': {'type': 'int'},
                    }
                }
            }
        },
    })

    # Check expected inputs and outputs

# Generated at 2022-06-11 00:49:39.453133
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import (
        ModuleArgumentSpecValidator,
        ValidationResult,
    )

    import os
    import unittest

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    os.environ['ANSIBLE_DEPRECATION_WARNINGS'] = 'False'


# Generated at 2022-06-11 00:49:50.115353
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    from ansible.module_utils.tests.arg_spec.common_arg_spec_validator import DummyAnsibleModule
    # alias is required for the test, therefore creating an alias for the method validate in class ModuleArgumentSpecValidator
    ArgumentSpecValidator_validate = ArgumentSpecValidator.validate
    # creating a mock object for module class DummyAnsibleModule
    mock_DummyAnsibleModule = DummyAnsibleModule()
    # calling the method validate of class ModuleArgumentSpecValidator, so set the mock object for module class DummyAnsibleModule
    mock_DummyAnsibleModule.set_ansible_module(ModuleArgumentSpecValidator_validate)
    # input the argument spec, parameters and mutually exclusive parameters
    # For alias, alias_warnings is used as a temporary holding

# Generated at 2022-06-11 00:49:58.976974
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    assert valid_params['age'] == 42

# Generated at 2022-06-11 00:50:07.677811
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:50:15.912646
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = dict(foo=dict(type='str', required=True),
                bar=dict(type='str', default='bar'),
                baz=dict(type='str', required=False))

    validator = ArgumentSpecValidator(argument_spec=spec)

    parameters = dict(foo='1')
    result = validator.validate(parameters=parameters)

    assert result.validated_parameters == dict(foo='1', bar='bar')
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == []



# Generated at 2022-06-11 00:50:19.360483
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create an ArgumentSpecValidator object
    # pass an argument spec
    # call the validate method with some parameters and get a result
    # see if the deprecations and warnings are ok based on the parameters
    # see if the result is correct
    pass

# Generated at 2022-06-11 00:50:28.229872
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }



# Generated at 2022-06-11 00:50:37.706597
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:50:45.060681
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_args = dict(some_arg='some_value')
    module_argument_spec = dict(some_arg=dict(type='str', alias='name'),
                                name=dict())

    validator = ModuleArgumentSpecValidator(argument_spec=module_argument_spec)
    result = validator.validate(module_args)

    assert result.validated_parameters == {'name': 'some_value'}

# Generated at 2022-06-11 00:50:54.821483
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # fake parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # fake argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # create argument validator with argument spec
    validator = ModuleArgumentSpecValidator(argument_spec)
    # validate parameters
    result = validator.validate(parameters)
    # Check the number of errors
    assert len(result.error_messages)==0
    # Check the result
    assert type(result.validated_parameters)==dict
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:51:10.403469
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test deprecations
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nome']},
        'age': {'type': 'int'},
    }
    parameters = {
        'nome': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._deprecations[0] == {'name': 'nome', 'version': None, 'date': None, 'collection_name': None}
    assert result._warnings[0] == {'option': 'name', 'alias': 'nome'}

    # Test no log values

# Generated at 2022-06-11 00:51:22.271175
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    class ValidationResult_test(ValidationResult):
        def __init__(self, parameters):
            super(ValidationResult_test, self).__init__(parameters)
        def sanitize(self):
            self.validated_parameters = sanitize_keys(self.validated_parameters, self._no_log_values)

    mutually_exclusive = [['foo', 'bar']]
    argument_spec = {'foo': {'type': 'str'}, 'bar': {'type': 'str'}, 'cat': {'type': 'str', 'no_log': True}}
    parameters = {'foo': '1', 'bar': '2', 'cat': '3', 'unsupport_item': '4'}
    #

# Generated at 2022-06-11 00:51:31.254399
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.ansible.bar.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.bar.plugins.modules import test

    argument_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'int'}
    }

    parameters = {
        'param1': 'value1',
        'param2': 'value2',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    with Mock(test) as mod:
        result = validator.validate(parameters)
        assert len(result._deprecations) == 0
        assert len(result._warnings) == 0

# Generated at 2022-06-11 00:51:39.783711
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''
    Test method validate of class ArgumentSpecValidator
    '''
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:51:45.712260
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}})
    parameters = {'name': 'bo', 'age': '42'}
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-11 00:51:52.951768
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'is_old': {'type': 'bool', 'default': False},
        'cities': {'type': 'list', 'elements': 'str', 'default': ['New York', 'Tokyo']}
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age'], ['is_old', 'cities']]
    required_one_of = [['name', 'age'], ['is_old', 'cities']]
    required_if = [['name', 'bo', ['age']]]
    required_by = {'name': ['age'], 'age': ['name']}

    validator = ModuleArgumentSpecValid

# Generated at 2022-06-11 00:51:54.375700
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "This test needs to be implemented."

# Generated at 2022-06-11 00:52:06.820856
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 30},
        'password': {'type': 'str', 'no_log': True},
        'cities': {'type': 'list', 'default': ['Montreal', 'Toronto']},
        'hobbies': {'type': 'list'},
        'family': {'type': 'dict', 'options': {'father': {'type': 'str'}, 'mother': {'type': 'str'}}},
    }


# Generated at 2022-06-11 00:52:13.181318
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=['name', 'age'])

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    print(result.errors.messages)
    print(result.validated_parameters)

if __name__ == '__main__':
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-11 00:52:24.405959
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    ModuleArgumentSpecValidator.__init__ = test_ModuleArgumentSpecValidator_validate_init
    ModuleArgumentSpecValidator.__setattr__ = test_ModuleArgumentSpecValidator_validate_setattr
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    mutually_exclusive = [['name', 'age']]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

    parameters = {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-11 00:52:34.478227
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert  result.validated_parameters == parameters

# Generated at 2022-06-11 00:52:40.874322
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = dict(name=dict(type='str'), age=dict(type='int'))
    parameters = dict(name='bo', age='42')
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._validated_parameters.keys() == {'name', 'age'}
    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-11 00:52:53.017099
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter_type = dict(
        type='dict',
        options=dict(
            key=dict(required=True,type='str'),
            value=dict(required=True,type='str')
        )
    )

    mutually_exclusive = [['a', 'b']]

    required_together = [['a', 'b']]


# Generated at 2022-06-11 00:53:03.280356
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.warnings import ResetWarnings
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result.validated_parameters) == 2
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    # Test if deprecation and warning are show in the

# Generated at 2022-06-11 00:53:14.873050
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.connection import Connection
    from ansible.utils.display import Display
    from ansible.module_utils.compat.paramiko import SSHClient

    # Test with mock classes
    class MockSSHClient():
        def __init__(self):
            self.set_missing_host_key_policy = None
            self.good_creat_missing_host_key_policy = True

        def set_missing_host_key_policy(self, missing_host_key_policy):
            if self.good_creat_missing_host_key_policy:
                self.missing_host_key_policy = missing_host_key_policy

# Generated at 2022-06-11 00:53:26.104319
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    INVALID_PARAMETER_NAME = "invalid_parameter_name"
    INVALID_PARAMETER_VALUE = 'invalid_value'
    valid_parameters = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
        'key5': 2,
        'key6': 2,
        'key7': 2,
        'key8': 2,
    }

# Generated at 2022-06-11 00:53:33.821663
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Given this argument_spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased_name': {'type': 'str', 'aliases': ['alias']},
    }

    # And the argument validator
    validator = ModuleArgumentSpecValidator(argument_spec)

    # When running the validate method
    parameters = {
        'name': 'bo',
        'age': '42',
        'aliased_name': 'alias',
    }

    result = validator.validate(parameters)

    # Then no error messages should be returned
    assert len(result.error_messages) == 0, "Validation failed: {0}".format(", ".join(result.error_messages))

    # And the parameters

# Generated at 2022-06-11 00:53:39.666169
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mav = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}}, mutually_exclusive=None)
    parameters = {'name': 'bo', 'age': '42', 'address': 'Beijing'}
    result = mav.validate(parameters)
    assert len(result._unsupported_parameters) == 1

# Generated at 2022-06-11 00:53:50.523330
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # ARRANGE
    # Setup argument_spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 1}
    }

    # Setup mutually_exclusive
    mutually_exclusive = [['name', 'age']]

    # Setup required_together
    required_together = [['name', 'age']]

    # Setup required_one_of
    required_one_of = [['name']]

    # Setup required_if
    required_if = [['name', 'bo']]

    # Setup required_by
    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-11 00:53:59.316301
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # This test is not included in the test_module_common.py because it is not a public class.
    argument_spec = {
        'mymodule': {'type': 'str', 'aliases': ['yourmodule'], 'default': 'yourmodule'},
        'othermodule': {'type': 'str', 'default': 'othermodule'}
    }
    # Test a simple one
    parameters = {'mymodule': 'mymodule'}
    myvalidator = ModuleArgumentSpecValidator(argument_spec)
    r = myvalidator.validate(parameters)
    assert r.deprecations == []
    assert r.warnings == []
    assert r.validated_parameters == {'mymodule': 'mymodule'}

    # Test with deprecation
    parameters = {'yourmodule': 'mymodule'}

# Generated at 2022-06-11 00:54:15.383165
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Prepare test data
    aliased_vars = {'data': {'name': 'me', 'age': 42}}

    # Create instance of test class
    validator = ModuleArgumentSpecValidator(argument_spec={'name': {'aliases': ['data']}})

    # Call method being tested
    result = validator.validate(aliased_vars)

    # Verify results
    assert result._warnings
    assert result._warnings[0]['option'] == 'data'
    assert result._warnings[0]['alias'] == 'name'
    assert result._validated_parameters['name'] == 'me'

# Generated at 2022-06-11 00:54:24.151445
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockDeprecation:
        def __init__(self):
            self.deprecations = []
            self.warnings = []

        def deprecate(self, *args, **kwargs):
            self.deprecations.append((args, kwargs))

        def warn(self, *args, **kwargs):
            self.warnings.append((args, kwargs))

    # mock_warn = MockDeprecation()
    # @patch("ansible.module_utils.common.warnings.warn", mock_warn.warn)
    # @patch("ansible.module_utils.common.warnings.deprecate", mock_warn.deprecate)
    # def test_warn(*args, **kwargs):
    #    return mock_warn


# Generated at 2022-06-11 00:54:35.447415
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:54:41.921377
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    with pytest.raises(AliasError):
        # validation should fail when both option and its alias are set
        validator = ModuleArgumentSpecValidator({'age': {'type': 'int', 'aliases': ['age_alias']}})
        validator.validate({'age': 42, 'age_alias': 42})

    validator = ModuleArgumentSpecValidator({'age': {'type': 'int', 'aliases': ['age_alias']}})
    result = validator.validate({'age': 42})
    assert result.errors == []
    assert result._deprecations == []
    assert result._warnings == []

    result = validator.validate({'age_alias': 42})
    assert result.errors == []
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-11 00:54:53.110778
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str', 'required': False},
        'age': {
            'type': 'int',
            'default': 42,
            'aliases': ['old']
        },
        'height': {'type': 'int', 'required': True},
    }

    mutually_exclusive = [
        ['a', 'b'],
        ['x', 'y'],
    ]

    required_together = [
        ['abc', 'def'],
        ['ghi', 'jkl', 'mno']
    ]

    required_one_of = [
        ['abc', 'def'],
        ['ghi', 'jkl']
    ]


# Generated at 2022-06-11 00:55:01.185011
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # test with erroneous parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 2
    assert len(result.validated_parameters) == 0
    assert len(result._unsupported_parameters) == 0

    # test with valid parameters
    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:55:05.828905
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec, "argument_spec should be %s" % argument_spec



# Generated at 2022-06-11 00:55:11.222646
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({"a": {"type": "str", "aliases": ["b"]}})
    result = validator.validate({"a": "1", "b": "2"})

    assert len(result.error_messages) == 1
    assert result.error_messages[0] == 'Both option a and its alias b are set.'

# Generated at 2022-06-11 00:55:22.237261
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': '42'},
        'tags': {'type': 'list', 'default': ['tag1', 'tag2']},
        'properties': {'type': 'dict', 'default': {'size': 'large'}},
    }
    validator = ArgumentSpecValidator(argument_spec)

    # test valid
    parameters = {
        'name': 'bo',
        'age': '42',
        'tags': ['tag1', 'tag2', 'tag3'],
        'properties': {'size': 'large', 'weight': 'heavy'},
    }
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.valid

# Generated at 2022-06-11 00:55:30.492668
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for alias warnings.
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['requested_name']},
        'age': {'type': 'int'}}

    parameters = {'name': 'bo', 'requested_name': 'a', 'age': '42'}
    ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    # Test for alias deprecations.
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['requested_name']},
        'age': {'type': 'int'}}

    parameters = {'name': 'bo', 'requested_name': 'a', 'age': '42'}
    ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    # Test

# Generated at 2022-06-11 00:55:47.539761
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test case for the method validate of class ModuleArgumentSpecValidator"""
    result = ModuleArgumentSpecValidator.validate(self, parameters)

    for d in result._deprecations:
        test_data = [
            [d['name'], d['version'], d['date'], d['collection_name']]
            for test_data in [d['name'], d['version'], d['date'], d['collection_name']]
            if test_data is not None
        ]

# Generated at 2022-06-11 00:55:57.817379
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Define parameters to be validated
    parameters = {
        'name': 'Bob',
        'age': 42,
    }

    # Define argument spec. The contents of the spec are not meaningful here.
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nickname']},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert set(result.unsupported_parameters) == set()

    assert result.validated_parameters == parameters

    # Test alias handling
    parameters = {
        'nickname': 'Bob',
        'age': 42,
    }


# Generated at 2022-06-11 00:56:03.073393
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-11 00:56:10.956494
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
             "param1": {"type": "str"},
             "param2": {"type": "str"},
             "param3": {"type": "str"},
             "param4": {"type": "str"},
             "param5": {"type": "str"},
             "param6": {"type": "str"},
             "param7": {"type": "str"},
             "param8": {"type": "str"},
             "param9": {"type": "str"},
             "param10": {"type": "str"},
             "param11": {"type": "str"},
             "param12": {"type": "str"},
             "param13": {"type": "str"},
             "param14": {"type": "str"},
    }

# Generated at 2022-06-11 00:56:20.685629
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # argument_spec = {
    #     'name': {'type': 'str'},
    #     'age': {'type': 'int'}
    # }
    # parameters = {
    #     'name': 'bo',
    #     'age': '42'
    # }
    #
    # validator = ArgumentSpecValidator(argument_spec)
    # result = validator.validate(parameters)
    #
    # if result.error_messages:
    #     sys.exit("Validation failed: {0}".format(", ".join(result.error_messages))
    #
    # valid_params = result.validated_parameters

    assert True

# Generated at 2022-06-11 00:56:26.871802
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argspec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argspec)

    module_validator = ModuleArgumentSpecValidator(argspec)
    result = module_validator.validate(parameters)

    assert result == validator.validate(parameters)

# Generated at 2022-06-11 00:56:34.053163
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

# Generated at 2022-06-11 00:56:45.893814
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Validation test for method `ArgumentSpecValidator.validate()`"""

    class ValidationResultMock:
        def __init__(self):
            self.errors = AnsibleValidationErrorMultiple()
            self._validated_parameters = {}
            self._no_log_values = {}
            self._unsupported_parameters = []
            self._warnings = []
            self._deprecations = []

        @property
        def validated_parameters(self):
            """Validated and coerced parameters."""
            return self._validated_parameters

        @property
        def no_log_values(self):
            """
            Values marked as no_log. This is a temporary holding place for these
            values and may move in the future.
            """
            return self._no_log_values


# Generated at 2022-06-11 00:56:55.349332
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from io import StringIO

    # validate must be tested by setting module_compat_per_module.log_deprecations
    # and redirecting stderr to a StringIO
    from ansible.module_utils.common.module_compat_per_module import module_compat_per_module
    module_compat_per_module.log_deprecations = True
    old_stdout = sys.stderr
    sys.stderr = StringIO()

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-11 00:57:03.414432
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert result.errors.messages == list()
    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-11 00:57:17.479338
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec= {'a': {'type': 'str'}}
    mutually_exclusive= None
    required_together= None
    required_one_of= None
    required_if= None
    required_by= None
    validator=ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    parameters={'a':'test'}
    validator.validate(parameters)
    assert validator.validate(parameters)


# Generated at 2022-06-11 00:57:22.760450
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'},
                     'description': {'type': 'str', 'aliases': ['desc']}
                     }
    parameters = {'name': 'bo',
                  'age': '42',
                  'description': 'Foolish mortal'
                  }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.validated_parameters['description'] == 'Foolish mortal'


# Generated at 2022-06-11 00:57:33.833598
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    from ansible.module_utils.six import string_types

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'info': {'type': 'dict'},
        'info2': {'type': 'dict',
                  'aliases': ['aliased_info']},
        'info3': {'type': 'dict',
                  'aliases': ['aliased_info2'],
                  'deprecated': {'msg': 'deprecate message',
                                 'version': '2.11',
                                 'collection_name': 'foo.bar'}}
    }


# Generated at 2022-06-11 00:57:41.848118
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    import unittest

    class ArgumentSpecValidator_validate_TestCase(unittest.TestCase):
        """TestCase for validate of class ArgumentSpecValidator"""
        def test_none_argument_spec(self):
            """Test case for argument_spec is None"""
            argument_spec = None
            mutually_exclusive = None
            required_together = None
            required_one_of = None
            required_if = None
            required_by = None
            parameters = {}
            validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
            with self.assertRaises(AssertionError) as context:
                result = validator.validate(parameters)