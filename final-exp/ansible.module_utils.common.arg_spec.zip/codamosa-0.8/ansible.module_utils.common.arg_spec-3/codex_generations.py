

# Generated at 2022-06-11 00:47:51.278527
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    ##################################
    # Testing ArgumentSpecValidator validate function
    ##################################

    # Test for valid data
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42
    }

    # Test for multiple errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-11 00:47:58.398249
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    validator = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}},
                                      mutually_exclusive=None,
                                      required_together=None,
                                      required_one_of=None,
                                      required_if=None,
                                      required_by=None)

    parameters = {'name': 'bo', 'age': '42'}
    result = validator.validate(parameters)

    assert not result.errors

# Generated at 2022-06-11 00:48:10.278223
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3
    arg_spec = {'name': {'type': 'str', 'aliases': ['firstname']}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ModuleArgumentSpecValidator(argument_spec=arg_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    if PY3:
        assert result.validated_parameters['age'] == 42
    else:
        assert result.validated_parameters['age'] == u'42'

# Generated at 2022-06-11 00:48:19.082789
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import catch_deprecation_errors, catch_warnings
    from ansible.module_utils.parsing.convert_bool import boolean

    result = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'employed': {'aliases': ['permanent']}
    }).validate({
        'name': 'bo',
        'age': '42',
        'employed': 'true'
    })

    assert not result.error_messages, result.error_messages

# Generated at 2022-06-11 00:48:31.291970
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str', 'deprecated': [{'version': '2.12', 'date': '2022-12-31', 'collection_name': 'community.general'}]},
        'age': {'type': 'int', 'aliases': ['years']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-11 00:48:42.197634
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:48:52.012993
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:49:00.365529
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )
    validator = ArgumentSpecValidator(params)
    parameters = dict(
        name='bo',
        age='42',
    )

    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-11 00:49:12.420243
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'test': {'type': 'int'},
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'newkey': {'type': 'str'},
        'complex': {
            'type': 'dict',
            'options': {
                'key1': {'type': 'str'},
                'key2': {'type': 'int'},
            },
        },
    }

    mutually_exclusive = [['name', 'test']]
    required_together = [['name', 'test']]
    required_one_of = [('name', 'test')]

# Generated at 2022-06-11 00:49:20.929876
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = dict(
        argument_spec=dict(
            mutual_exclusive=True,
            required_together=True,
            required_one_of=True,
            required_if=True,
            required_by=True,
            ansible_module=True,
        ),
        mutually_exclusive=True,
        required_together=True,
        required_one_of=True,
        required_if=True,
        required_by=True,
        ansible_module=True,
    )

    print("*"*80)

    print("args=", args)

    ArgumentSpecValidator(*args)

# Generated at 2022-06-11 00:49:40.560334
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {'type': 'dict',
                    'options': {
                        'street': {'type': 'str'},
                        'city': {'type': 'str'},
                        'state': {'type': 'str'},
                        'zip': {'type': 'int'},
                        'country': {'type': 'str'}
                    }
                    }
    })

    # Simple tests test case

# Generated at 2022-06-11 00:49:51.794320
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def run_validate(validator, parameters, expected_result, expected_errors=None, expected_no_log_values=None):
        result = validator.validate(parameters)
        assert result.validated_parameters == expected_result
        no_log_values = result._no_log_values
        if expected_errors:
            assert result.error_messages == expected_errors
        else:
            assert result.error_messages == []
        if expected_no_log_values:
            assert no_log_values == expected_no_log_values
        else:
            assert no_log_values == set()

        return result


# Generated at 2022-06-11 00:49:59.745715
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = dict(name='bo', age='42')
    mutual_exclusive = [['name', 'age'], ['sex', 'age']]
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}, }
    validator = ModuleArgumentSpecValidator(argument_spec,mutually_exclusive=mutual_exclusive)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters
    assert result.errors == [MutuallyExclusiveError('parameters are mutually exclusive: name, age')]

# Generated at 2022-06-11 00:50:08.121196
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""
    age_spec = {
        'type': 'int',
        'required': True,
        'deprecated': {
            'msg': 'Deprecated in favor of something else',
            'version': '2.14',
        },
    }
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': age_spec,
        'employee': {
            'type': 'dict',
            'options': {
                'id': {'type': 'int', 'required': True},
                'name': {'type': 'str', 'required': True},
                'age': age_spec,
            }
        },
    }

    mutually_exclusive = [['name', 'age']]
    required_together

# Generated at 2022-06-11 00:50:14.865597
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = \
        {
            'name':
                {'type': 'str'},
            'age':
                {'type': 'int'},
        }

    parameters = \
        {
            'name': 'bo',
            'age': '42',
        }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert result.validated_parameters == parameters



# Generated at 2022-06-11 00:50:20.239696
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Define argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    # Define parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert(not result.error_messages)

# Generated at 2022-06-11 00:50:32.702583
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'local': {'type': 'str', 'aliases': ['local_deprecated']},
        'remote': {'type': 'str', 'aliases': ['remote_deprecated']},
        'local_deprecated': {'type': 'bool', 'deprecated': {'collection_name': 'community.general', 'version': '2.13', 'removed_in': '2.14', 'why': 'Use local instead', 'alternative': 'local'}},
        'remote_deprecated': {'type': 'bool', 'deprecated': {'collection_name': 'community.general', 'version': '2.13', 'removed_in': '2.14', 'why': 'Use remote instead', 'alternative': 'remote'}},
    }

    def _deprecate1():
        valid

# Generated at 2022-06-11 00:50:39.907280
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Create dummy argument spec
    argument_spec = {
        'test_param': {
            'type': 'str',
        },
    }

    # Create dummy mutually exclusive list
    mutually_exclusive = [['test_param', 'test_param2']]

    # Create dummy required together list
    required_together = [['test_param', 'test_param2']]

    # Create dummy required one of list
    required_one_of = [['test_param', 'test_param2']]

    # Create dummy required if list
    required_if = [['test_param', 'test_param2', 'test_param3']]

    # Create dummy required by dictionary
    required_by = {
        'test_param': ['test_param2'],
    }

    # Call constructor of class ArgumentSpecValidator
    validator

# Generated at 2022-06-11 00:50:46.987042
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['age'] == 42
    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-11 00:50:53.800209
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert len(result.errors) == 0
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-11 00:51:09.549471
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import ValidationError

    class MockValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            return None

    class MockResult(ValidationResult):
        def __init__(self, validated_parameters, deprecations=(), warnings=()):
            self._deprecations = deprecations
            self._warnings = warnings
            self._validated_parameters = validated_parameters
            self.errors = None
    pass_result = MockResult({'param1': 'value1'})

# Generated at 2022-06-11 00:51:21.395286
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'color': {'aliases': ['colour']},
        'skills': {
            'type': 'list',
            'elements': 'str',
            'arg_spec': {
                'skill': {
                    'type': 'str',
                    'aliases': ['skill_name', 'skill_label'],
                }
            }
        }
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-11 00:51:26.869206
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    result = ModuleArgumentSpecValidator({'name': {'type': 'str'},
                                            'age': {'type': 'int'}},
                                           ).validate({'name': 'bo',
                                                       'age': '42'})

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-11 00:51:38.770016
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    # name = bo
    # age = 42
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert not result._unsupported_parameters
    assert not result._deprecations
    assert not result._warnings

    # name = 42
    # age = bo
    parameters = {'name': 42, 'age': 'bo'}
    result = validator.validate(parameters)
    assert not result.error_messages


# Generated at 2022-06-11 00:51:48.627342
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    module_arguments = dict(
        name = dict(type='str'),
        age = dict(type='int'),
    )

    module_parameters = dict(
        name = 'bo',
        age = '42',
    )

    validator = ArgumentSpecValidator(module_arguments)
    result = validator.validate(module_parameters)

    assert len(result.error_messages) == 1
    assert result.error_messages[0].startswith('Unexpected type for parameter')

    module_parameters = dict(
        name = 'bo',
        age = 42,
    )

    result = validator.validate(module_parameters)

    assert len(result.error_messages) == 0

# Generated at 2022-06-11 00:52:00.012759
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'dob': {'type': 'str', 'required': True},
        }

    mutually_exclusive = [['name', 'age']]

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [['name', 'BO', ['age']]]

    required_by = {
        'name': ['age'],
        }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    # Validate simple spec with no errors

# Generated at 2022-06-11 00:52:11.205025
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class Deprecation:
        def __init__(self, name, version=None, date=None, collection_name=None):
            self.name = name
            self.version = version
            self.date = date
            self.collection_name = collection_name

    class Warning:
        def __init__(self, option, alias):
            self.option = option
            self.alias = alias

    class AnsibleModule:

        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None, required_one_of=None,
                     required_if=None, required_by=None):
            self.argument_spec = argument_spec
            self.deprecations = []
            self.warnings = []
            self.params = {}

# Generated at 2022-06-11 00:52:20.912958
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import copy
    import pytest

    # When all provided parameters are valid, the arguments are left untouched
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters

    # When one of the provided parameters is invalid, it is added to the error
    # messages of the ValidationResult
    invalid_parameters = copy.deepcopy(parameters)
    invalid_parameters['age'] = '42'

    result = validator.validate(invalid_parameters)

    assert result.validated

# Generated at 2022-06-11 00:52:32.478579
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {'name': {'type': 'str'}}
    parameters = {
        'name': 'bo',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    assert result.unsupported_parameters == set()

    argument_spec = {'name': {'type': 'str'}}
    parameters = {
        'name': 'bo',
        'test': ['foo', 'bar'],
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == ['Unsupported options: test']
    assert result.unsupported_

# Generated at 2022-06-11 00:52:41.031388
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # argument_spec = {
    #     'name': {'type': 'str'},
    #     'age': {'type': 'int'},
    # }

    # parameters = {
    #     'name': 'bo',
    #     'age': '42',
    # }

    # validator = ArgumentSpecValidator(argument_spec)
    # result = validator.validate(parameters)

    # assert len(result.error_messages) == 0

    # for v in result.validated_parameters:
    #     assert result.validated_parameters[v]['type'] == argument_spec[v]['type']

    return


# Generated at 2022-06-11 00:52:56.691815
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    no_log_values = [
        'password',
        'secret',
        'ssh_key_passphrase',
        'become_pass',
        'vault_password',
        'vault_password_file',
    ]


# Generated at 2022-06-11 00:52:59.442874
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for function that does not return any value
    validator = ModuleArgumentSpecValidator({})
    assert validator.validate({}) == None



# Generated at 2022-06-11 00:53:09.664860
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'dates': {'type': 'list', 'default': []},
    },
                                            mutually_exclusive=[['name', 'age']])

    with pytest.raises(MutuallyExclusiveError):
        validator.validate({'name': 'bob', 'age': 10})

    with pytest.raises(UnsupportedError):
        validator.validate({'name': 'bob', 'age': 10, 'foo': 'bar'})

    with pytest.raises(TypeError):
        validator.validate({'name': 'bob', 'age': '10'})


# Generated at 2022-06-11 00:53:18.844974
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    print("Parameter errors: {}".format(", ".join(result.error_messages)))
    print("Parameter values: {}".format(result.validated_parameters))

if __name__ == '__main__':
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-11 00:53:29.560568
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """The method validate of class ModuleArgumentSpecValidator has a bug
    when processing an argument spec with an 'aliases' key: it won't
    generate a warning and a deprecation even if both the option and its
    alias are set.
    This function tests the method by using the function warn and the
    function deprecate.
    """

    class TestWarnings:
        calls = []

        @classmethod
        def warn(cls, msg, *args, **kwargs):
            # Save the arguments of the call:
            cls.calls.append((msg, args, kwargs))

    class TestDeprecations:
        calls = []

        @classmethod
        def deprecate(cls, msg, *args, **kwargs):
            cls.calls.append((msg, args, kwargs))

# Generated at 2022-06-11 00:53:35.783564
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # SUT
    ASV = ArgumentSpecValidator({
        'my_arg': {'type': 'str', 'fallback': ('my_arg_fallback', 'my_arg_fallback_2')},
        'my_arg_fallback': {'type': 'str', 'fallback': ('my_arg_fallback_2',)},
        'my_arg_fallback_2': {'type': 'str'},
    })

    # Parameters
    parameters = {
        'my_arg': "I am my_arg",
        'my_arg_fallback': "I am my_arg_fallback",
        'my_arg_fallback_2': "I am my_arg_fallback_2",
    }

    # Expectation
    expected = ValidationResult(parameters)

    # Exercise and verify

# Generated at 2022-06-11 00:53:36.419619
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-11 00:53:47.056049
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ansibleModule = MockAnsibleModule()
    module_args = {'arg1': 'value1', 'arg2': 'value2'}

    arugmentSpec = {
        'arg1': {
            'type': 'str',
            'default': 'value1',
            'required': False,
            'version_added': None,
            'aliases': ['alias1']
        },
        'arg2': {
            'type': 'str',
            'default': 'value2',
            'version_added': None,
            'required': True
        }
    }

    # create our ModuleArgumentSpecValidator object
    validator = ModuleArgumentSpecValidator(arugmentSpec)
    # call validate
    validated_parameters = validator.validate(module_args)
    # Validated parameters should

# Generated at 2022-06-11 00:53:56.424908
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parameters)

    assert type(result.validated_parameters) is dict
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    assert result.unsupported_parameters == set()

    assert result.error_messages == []

    assert result._no_log_values == set()

# Generated at 2022-06-11 00:54:04.245533
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class AnsibleModule(object):
        @staticmethod
        def deprecate(msg, version=None, date=None, collection_name=None):
            pass
        @staticmethod
        def warn(msg):
            pass

    m_ansible_module = AnsibleModule()
    validator = ModuleArgumentSpecValidator({'a': {'required':True , 'type': 'bool'}}, None, None, None, None, None)
    result = validator.validate({'a': True})
    assert 'a' in result.validated_parameters

# Generated at 2022-06-11 00:54:38.039133
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''Test for method validate of class ArgumentSpecValidator.'''
    val = ArgumentSpecValidator({'hello': {'type': 'str'}}, required_one_of=[[['hello']]])
    result = val.validate({})
    assert result.errors.messages == ["The hello module requires one of the following: hello"]

    val = ArgumentSpecValidator({'hello': {'type': 'str'}}, required_one_of=[[['hello', 'world']]])
    result = val.validate({'world': 'world'})
    assert result.errors.messages == ["The hello module requires one of the following: hello"]


# Generated at 2022-06-11 00:54:49.633301
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import (
        ArgumentSpecValidator,
        ValidationResult,
    )
    schema = [
        {
          "name" : "option1",
          "type" : "str",
          "required" : True
        },
        {
          "name" : "option2",
          "type" : "str"
        },
        {
          "name" : "option3",
          "type" : "str"
        }
    ]
    argument_spec = dict()
    for field in schema:
        argument_spec[field['name']] = dict()
        argument_spec[field['name']]['type'] = field.get('type', 'str')
        argument_spec[field['name']]['required'] = field.get('required', False)


# Generated at 2022-06-11 00:54:57.103553
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42'
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    result_validated_parameters = result.validated_parameters
    assert result_validated_parameters['name'] == 'bo'
    assert result_validated_parameters['age'] == 42
    assert result.errors == []

# Generated at 2022-06-11 00:55:06.329004
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # When instance of ModuleArgumentSpecValidator is created
    validator = ModuleArgumentSpecValidator(
                    argument_spec={},
                    mutually_exclusive = None,
                    required_together = None,
                    required_one_of = None,
                    required_if = None,
                    required_by = None)

    # When method validate() is called
    result = validator.validate({})

    # Then validated_parameters attribute should be a dict
    assert isinstance(result.validated_parameters, dict)

    # And error_messages attribute should be a list
    assert isinstance(result.error_messages, list)

    # And no_log_values attribute should be a set
    assert isinstance(result.error_messages, list)

# Generated at 2022-06-11 00:55:17.556714
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    Test case to verify constructor of class ArgumentSpecValidator.
    '''
    assertArgumentSpecValidator = {'testParameter': {'required': True, 'type': 'int'}}
    assertMutuallyExclusive = [('testParameter', 'testParameter1'), ('testParameter2', 'testParameter3')]
    assertRequiredTogether = [['testParameter', 'testParameter1'], ['testParameter2', 'testParameter3']]
    assertRequiredOneOf = [['testParameter', 'testParameter1'], ['testParameter2', 'testParameter3']]
    assertRequiredIf = [['testParameter', 'testParameter1', ['testParameter2']]]
    assertRequiredBy = {'testParameter1': ['testParameter2']}


# Generated at 2022-06-11 00:55:24.592768
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class M(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(M, self).__init__(*args, **kwargs)

    v = M(dict({'a': {'type': 'dict', 'options': {'x': {'type': 'int'}}}}))
    ret = v.validate(dict({'a': {'x': 'y'}}))
    assert ret.error_messages[0] == 'a.x expects an integer value, received "y"'


# Generated at 2022-06-11 00:55:31.596989
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:55:41.920587
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup the test
    alias_warnings = []
    alias_deprecations = []
    argument_spec = {'name': {'type': 'str', 'required': True}, 'age': {'type': 'int'}, 'hobbies': {'type': list, 'default': []}, 'state': {'type': 'dict', 'default': {}}}
    parameters = {'name': 'bo', 'state': {}, 'hobbies': []}
    obj = ModuleArgumentSpecValidator(argument_spec)

    # Invoke validate which will invoke alias_warnings and alias_deprecations
    _handle_aliases(argument_spec, parameters, alias_warnings, alias_deprecations)

    # Ensure alias_deprecations is empty - no warnings to report
    assert not alias_deprecations

    # Ensure alias_warnings

# Generated at 2022-06-11 00:55:47.376993
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from .ansible_module import AnsibleModule
    from .common import AnsibleModuleTestCase2

    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )

    validator = ArgumentSpecValidator(argument_spec)

    parameters = dict(
        name='bo',
        age='42',
    )
    result = validator.validate(parameters)
    assert not result.error_messages

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    parameters = dict(
        name='bo',
        age='INVALID',
    )
    result = validator.validate(parameters)
    assert result.error_messages

# Generated at 2022-06-11 00:55:55.461112
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hair': {'type': 'str', 'aliases': ['colour']}
    }

    parameters = {
        'name': 'bo',
        'age': '42', 
        'colour': 'brown'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.errors.messages[0] == "Both option hair and its alias colour are set."
    assert result.validated_parameters['hair'] == 'brown'

# Generated at 2022-06-11 00:56:29.032791
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import DeprecationWarning
    from ansible.module_utils.six import PY3

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'collection': {
            'type': 'dict',
            'aliases': ['collect'],
            'elements': {'type': 'str'},
        },
    }
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            required_if=[('name', 'bo', ['age'])])

    parameters = {
        'name': 'bo',
        'age': '42',
        'collection': ['one', 'two', 'three'],
    }

    result = validator.validate(parameters)
   

# Generated at 2022-06-11 00:56:32.444597
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import pytest

    # Create a validator object
    validator = ArgumentSpecValidator({'foo': {'type': 'str'}})

    # Check that this object is a instance of our class
    assert (isinstance(validator, ArgumentSpecValidator))

    # Check that the ArgumentSpecValidator object has the right attributes
    assert (hasattr(validator, 'argument_spec'))

# Generated at 2022-06-11 00:56:42.849874
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class MockedValidationResult:
        def __init__(self):
            pass

    class MockedModuleArgumentSpecValidator(ArgumentSpecValidator):
        def __init__(self):
            pass

    class MockedArgSpecValidator:
        def validate(self, test_params):
            return MockedValidationResult()

    arg_spec_validator = MockedArgSpecValidator()
    validator = MockedModuleArgumentSpecValidator()
    validator.arg_spec_validator = arg_spec_validator
    validator.parameters = []
    validator.warnings = []
    validator.deprecations = []
    params = {
        'name': 'bo',
        'age': '42',
    }
    assert validator.validate(params) == MockedValidationResult()

# Generated at 2022-06-11 00:56:53.459615
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # setup
    mutually_exclusive = [
        ['a', 'b'],
    ]

    required_together = [
        ['c', 'd'],
    ]

    required_one_of = [
        ['e', 'f'],
    ]

    required_if = [
        ['g', 'h', ['i']],
    ]

    required_by = {
        'j': ['k'],
    }

    argument_spec = {
        'name': {'type': 'str'},
    }

    parameters = {
        'name': 'bo',
    }

    # test

# Generated at 2022-06-11 00:57:03.953979
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {'type': 'dict', 'options': {'street': {'type': 'str'}, 'city': {'type': 'str'}, 'state': {'type': 'str'}}},
        'names': {'type': 'list', 'elements': 'str'},
        'aliased': {'type': 'str', 'aliases': ['alias1', 'alias2']},
        'multiple_aliases': {'type': 'str', 'aliases': ['alias3', 'alias4']},
        'multiple_aliases_2': {'type': 'str', 'aliases': ['alias5', 'alias6']},
    }

# Generated at 2022-06-11 00:57:14.244069
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:57:23.258398
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create argument spec with one parameter, set to type dict.
    key_param_spec = {
        'type': 'dict',
        'elements': 'str',
        'required': True,
    }
    # Validate key_param is required and of type dict.
    key_param = 'key_param=thirty-three'
    key_param_validator = ArgumentSpecValidator(key_param_spec)
    key_param_validation_result = key_param_validator.validate({'key_param': key_param})
    assert key_param_validation_result.error_messages.__contains__("Invalid type for argument 'key_param'")

# Generated at 2022-06-11 00:57:34.344392
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''
    This function prints a message if the unit test(s) of the function(s)
    named in the import above fail.
    '''
    #####################
    module_name = 'ModuleArgumentSpecValidator.validate'
    #####################
    # Initialization before entering testing phase
    start_msg = "Initiating unit test(s) for AnsibleModule class"
    msg = '\n%s.%s on line: %s' % (cur_file_name, module_name, module_line_nbr)
    print('\n%s%s' % (start_msg, msg))
    print('-' * len(start_msg + msg))
    # Initialization
    start_time = datetime.datetime.now()
    #####################
    # Testing starts here