

# Generated at 2022-06-11 00:47:51.775547
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:48:03.504236
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestClass(object):
        pass

    t = TestClass()
    t.deprecate = None
    t.warn = None

    validator = ModuleArgumentSpecValidator({'w': {'aliases': ['x']}})
    validator.validate({'w': 1, 'x': 2})

    assert not t.deprecate
    assert t.warn

    validator = ModuleArgumentSpecValidator({'w': {'aliases': ['x'], 'deprecated': {'version': '1.0',
                                                                                     'collection_name': 'test_collection'}}})

    validator.validate({'w': 1, 'x': 2})

    assert t.deprecate

    t.deprecate = None

    validator.validate({'w': 1, 'x': 2})

# Generated at 2022-06-11 00:48:14.911800
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''
    Verify validate method of class ModuleArgumentSpecValidator
    '''
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import StringIO
    import json


# Generated at 2022-06-11 00:48:22.293224
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-11 00:48:34.596194
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_name = 'validators'

    # Create instance
    # module_args and check_invalid_arguments are not used and thus not given in __init__
    arg_spec_validator = ModuleArgumentSpecValidator({}, [], [], [], [], [])

    # Test case 1
    # No element in argument_spec
    parameters = {}
    result = {}

    result = arg_spec_validator.validate(parameters)

    assert result == {}, "parameters should be the same as result"

    # Test case 2
    # One element in argument_spec, the value is string
    parameters = {}
    parameters['name'] = 'TEST'
    result = {}


# Generated at 2022-06-11 00:48:38.871865
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    arsgument_spec = {'name': {'type': 'str'}}
    validator = ModuleArgumentSpecValidator(argument_spec=arsgument_spec)

    parameters = {'name': 'bo'}
    validator.validate(parameters)

# Generated at 2022-06-11 00:48:46.501992
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:48:53.798604
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters.get('name') == 'bo'
    assert result.validated_parameters.get('age') == 42
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-11 00:49:02.521231
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Load up validator
    argument_spec = {
        'name': {
            'type': 'str',
        },
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Validate an invalid parameter
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.error_messages[0] == "{0} (supported: {1})".format("age", "name")



# Generated at 2022-06-11 00:49:10.300050
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert '42' in result.validated_parameters['age']
    assert 'Validation failed: age must be an integer' in result.errors[0].message

# Generated at 2022-06-11 00:49:23.644853
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import types
    import unittest

    class TestArgumentSpecValidator_validate(unittest.TestCase):
        def test_type_validation(self):

            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
            parameters = {
                'name': 'bo',
                'age': '42',
            }

            validator = ArgumentSpecValidator(argument_spec)
            result = validator.validate(parameters)

            self.assertTrue(
                isinstance(result, types.ObjectType),
                "{this_type} is not of type {expected_type}".format(this_type=type(result), expected_type=types.ObjectType))


# Generated at 2022-06-11 00:49:34.239243
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:49:40.521008
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-11 00:49:51.806095
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Build a spec with a few parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    argument_spec = ModuleArgumentSpecValidator(argument_spec)

    # Verify simple success cases
    parameters = {
        'name': 'Alice',
        'age': 44,
    }
    result = argument_spec.validate(parameters)
    assert result._validated_parameters == {'name': 'Alice', 'age': 44}
    assert len(result.errors) == 0
    assert len(result._warnings) == 0
    assert len(result._deprecations) == 0

    # Verify simple failure case
    parameters = {
        'name': 'Bob',
        'age': 'forty-two',
    }

# Generated at 2022-06-11 00:50:02.355269
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    module_deprecation = dict()
    module_warnings = dict()
    class MockAnsibleModule(AnsibleModule):
        def deprecate(self, *args, **kwargs):
            module_deprecation['version'] = "version"
            module_deprecation['date'] = "date"
            module_deprecation['collection_name'] = "collection_name"
            module_deprecation['msg'] = "msg"

        def warn(self, msg):
            module_warnings['msg'] = msg



# Generated at 2022-06-11 00:50:09.798981
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def side_effect(*args, **kwargs):
        raise TypeError

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'things': {'type': 'list', 'elements': {'type': 'str'}},
        'nest': {'type': 'dict', 'elements': {'type': 'str'}},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'things': ['a'],
        'nest': {'thing': 'a'},
    }


    # expected_result = {
    #     'errors': dict(
    #         alias={'alias': 'a', 'option': 'thing'},
    #         mutually_exclusive={'parameters

# Generated at 2022-06-11 00:50:15.100883
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec = dict(
        test=dict(type='str'),
        test_deprecated=dict(type='str', aliases=['test_alias'], deprecated_aliases=['test_alias'], version='2.14')
    )
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

    validator = ModuleArgumentSpecValidator(module_argument_spec,
                                            mutually_exclusive,
                                            required_together,
                                            required_one_of,
                                            required_if,
                                            required_by)

    parameters = dict(test='test')
    result = validator.validate(parameters)
    assert not result.error_messages


# Generated at 2022-06-11 00:50:22.648706
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    mutually_exclusive = [['foo', 'bar']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'bar']]
    required_if = [['foo', 'bar', 'baz']]
    required_by = {'foo': ['bar', 'baz']}

    assert ArgumentSpecValidator(argument_spec,mutually_exclusive,required_together,required_one_of,required_if,required_by)

# Generated at 2022-06-11 00:50:30.571577
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str', 'aliases': ['firstname']}}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    param = {'name': 'john'}
    result = module_argument_spec_validator.validate(param)

# Generated at 2022-06-11 00:50:39.018647
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'image': {'type': 'str'},
        'force_delete': {'type': 'bool', 'default': False, 'aliases': ['force']},
        'volume': {'type': 'str', 'default': 'default-volume'},
        'ports': {'type': 'list', 'default': [80, 443]},
        'secrets': {
            'type': 'dict',
            'options': {
                'username': {'type': 'str'},
                'password': {'type': 'str', 'no_log': True},
            }
        }
    }


# Generated at 2022-06-11 00:50:50.149104
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'aliases': ['bar'], 'type': 'str'}
    }

    mutually_exclusive = [['a', 'b']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = {
        'a': 'a',
        'b': 'b',
        'bar': 'bar'
    }

    validator.validate(parameters)

# Generated at 2022-06-11 00:50:56.631585
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    )

    result = validator.validate({
        'name': 'bo',
        'age': '42',
    })

    assert len(result.errors) == 0
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.unsupported_parameters == set()

# Generated at 2022-06-11 00:51:05.139742
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}
    assert result.unsupported_parameters == set()


# Generated at 2022-06-11 00:51:16.593672
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate method of ArgumentSpecValidator class."""
    # Test validate method with sub spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {
            'type': 'dict',
            'options': {
                'street': {'type': 'str'},
                'city': {'type': 'str'},
                'zip': {'type': 'int'},
            }
        },
        'accounts': {
            'type': 'list',
            'options': {
                'name': {'type': 'str'},
                'amount': {'type': 'float'},
            }
        },
    }

# Generated at 2022-06-11 00:51:26.836918
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    msg_unsupported_deprecated_alias = 'The option "name" is deprecated and will be removed in a future release. ' \
                             'This parameter will be converted to an alias of "new_name" in the next major version.'
    msg_unsupported_deprecated_alias_2 = 'The option "name" is deprecated and will be removed in a future release. ' \
                             'This parameter will be converted to an alias of "new_name" in the next major version.'
    msg_unsupported_alias = 'The option "name" is not supported by the module. This parameter will be converted to an alias of "new_name" in the next major version.'
    msg_unsupported_alias_2 = 'The option "name" is not supported by the module. This parameter will be converted to an alias of "new_name" in the next major version.'
   

# Generated at 2022-06-11 00:51:38.719347
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test with non-module argument_spec
    # given
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'nested': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'nested': {
            'name': 'bo',
            'age': '42',
        }
    }

    # when
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # then

# Generated at 2022-06-11 00:51:49.193338
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    import os

    mp = 'ansible.module_utils.common.arg_spec'
    arg_spec = {
        'name': dict(type='str', required=True),
        'display_count': dict(type='int', aliases=['count']),
        'count': dict(type='int', aliases=['display_count'], default=2),
    }

    mutually_exclusive = [
        ['count', 'display_count'],
    ]

    parameters = {
        'name': 'joe',
        'count': '3',
        'display_count': '5'
    }

    validator = ArgumentSpecValidator(
        argument_spec=arg_spec,
        mutually_exclusive=mutually_exclusive,
    )

# Generated at 2022-06-11 00:51:54.276115
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'src': {'type': 'str', 'required': False},
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-11 00:52:02.172278
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-11 00:52:12.631467
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ArgumentSpecValidator.validate()"""

    # based on https://github.com/ansible/ansible-core/blob/devel/test/units/module_utils/common/arg_spec.py#L493
    #   and https://github.com/ansible/ansible-core/blob/devel/test/units/module_utils/common/arg_spec.py#L538


# Generated at 2022-06-11 00:52:27.828907
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
            'foo': {'type': 'str'},
            'bar': {'type': 'int'},
            'baz': {'type': 'dict'},
            'qux': {'type': 'list'},
            'bux': {'type': 'int', 'aliases': ['x', 'y']},
            'quux': {'type': 'bool', 'no_log': True},
            'corge': {'type': 'int', 'default': 42, 'no_log': True},
        }

    mutually_exclusive = [
        ['x', 'y'],
    ]


# Generated at 2022-06-11 00:52:38.933511
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:52:40.701590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import doctest
    test_result = doctest.testmod(sys.modules[__name__])
    if test_result.failed > 0:
        exit(1)

# Generated at 2022-06-11 00:52:48.316885
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert 'Validation failed: invalid type for required value' in result.error_messages


# Generated at 2022-06-11 00:52:59.243428
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils import basic
    import sys
    import pytest

    # data
    mutually_exclusive = ['test1', 'test2']
    required_together = [['test1', 'test2'], ['test3']]
    required_one_of = [['test1', 'test2'], ['test3']]
    required_if = [['test1', 't1', ['t2']]]
    required_by = {'test1': ['test2', 'test3'],
                   'test2': ['test1']}

# Generated at 2022-06-11 00:53:09.607764
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Function for testing of a method validate of a class ModuleArgumentSpecValidator.
    """
    an_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    a_parameters = {
        'name': 'bo',
        'age': '42',
    }
    a_validator = ModuleArgumentSpecValidator(
        an_argument_spec,
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None)
    result = a_validator.validate(a_parameters)
    assert result.error_messages == []

# Generated at 2022-06-11 00:53:16.532266
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'age': {'type': 'int', 'aliases': ['age_old'], 'deprecated': {'version': '2.14', 'msg': 'Age option is not used anymore'}}})

    result = validator.validate({'age': 42})
    assert result._deprecations == [{'date': None, 'version': '2.14', 'name': 'age', 'collection_name': None}]



# Generated at 2022-06-11 00:53:17.835032
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass



# Generated at 2022-06-11 00:53:26.614721
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == {'name': 'bo', 'age': 42}
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result._unsupported_parameters == set()

# Generated at 2022-06-11 00:53:28.624163
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO. Test any missing methods.
    assert ModuleArgumentSpecValidator.validate is ArgumentSpecValidator.validate



# Generated at 2022-06-11 00:53:40.613581
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.errors == [])

    parameter = result.validated_parameters
    assert(parameter == {'name': 'bo', 'age': 42})


# Generated at 2022-06-11 00:53:45.433406
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # argument_spec passed to ArgumentSpecValidator.__init__
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'}
    }

    # parameters passed to validate
    parameters = {
        'name': 'bo',
        'age': '42',
        'name_alias': 'bo',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # expected ValidationResult
    expected_result = ValidationResult(parameters)
    expected_result._validated_parameters = {
        'name': 'bo',
        'name_alias': 'bo',
        'age': 42,
    } 

    assert result._validated

# Generated at 2022-06-11 00:53:56.270827
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class ModuleArgumentSpecValidatorTest():
        def deprecate(self, msg, version=None, date=None, collection_name=None):
            return msg

        def warn(self, msg):
            return msg

    import sys
    import json
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.text.converters import to_bytes

    arg_spec = dict(
        foo=dict(type='int'),
        bar=dict(type='int', default=10),
        baz=dict(type='int', default=20, aliases=['quux'])
    )

    mutually_exclusive = [['foo', 'bar']]


# Generated at 2022-06-11 00:53:59.234487
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    x = ArgumentSpecValidator({})
    assert len(x.validate({}).errors) == 0
    b = x.validate({'a':'b'})
    assert len(b.errors) == 1


# Generated at 2022-06-11 00:54:10.229032
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg_spec = {
        'options': {
            'type': 'dict',
            'aliases': ['alt_option'],
            'options': {
                'name': {'type': 'str', 'aliases': ['alt_name']},
                'description': {'type': 'str'},
            }
        },
        'debug': {
            'type': 'bool',
            'default': False,
            'no_log': True,
            'aliases': ['debug_option'],
        },
    }

    parameter = {
        'options': {
            "name": "bo",
            "alt_name": "alt_name",
        },
        'debug': True,
        'debug_option': True,
    }

    validator = ModuleArgumentSpecValidator(arg_spec)
    result

# Generated at 2022-06-11 00:54:20.007333
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'greet': {'type': 'str', 'default': 'world'},
        'nested': {'type': 'dict',
                   'no_log': True,
                   'options': {
                       'name': {'type': 'str'},
                       'age': {'type': 'int'},
                   },
                   'required': True,
                  },
    }

    mutually_exclusive = [['age', 'nested.age']]

    parameters = {
        'name': 'bo',
        'age': '42',
        'nested': {
            'name': 'bo',
            'age': '42',
        },
    }


# Generated at 2022-06-11 00:54:21.884760
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # NOTE: the test of the function is to be done in the unit test of the class AnsibleModule

    pass


# Generated at 2022-06-11 00:54:32.630609
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings
    import pytest

    def test_val_method(parameters=None):
        argument_spec = {"_test1": {"type": "str", "aliases": ["test1"]},
                         "_test2": {"type": "str", "aliases": ["test2"]}}
        validator = ModuleArgumentSpecValidator(argument_spec)
        validator._deprecations = [{"name": "test1"}, {"name": "test2"}]
        validator._warnings = [{"option": "test1", "alias": "test2"}]
        result = validator.validate(parameters)

        return result
    # Testing for

# Generated at 2022-06-11 00:54:40.055220
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    init_mock = AnsibleModule(argument_spec=dict(x=dict(type='int')))
    mock_spec_validator = ModuleArgumentSpecValidator(argument_spec=dict(x=dict(type='str')))
    result = mock_spec_validator.validate(dict(x=42))
    assert isinstance(result.errors[0], AnsibleValidationErrorMultiple)
    assert isinstance(result.errors[0].errors[0], TypeError)
    assert "expected str, got int" in (str(result.errors[0].errors[0]))
    assert result.validated_parameters == {}


# Generated at 2022-06-11 00:54:46.603058
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    date = None
    validator = ModuleArgumentSpecValidator(argument_spec)

    with pytest.raises(AnsibleValidationErrorMultiple):
        result = validator.validate(parameters)

# Generated at 2022-06-11 00:55:07.817203
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate method of class ArgumentSpecValidator."""
    # Initialize class ArgumentSpecValidator with the appropriate
    # argument_spec, mutually_exclusive, required_together and required_if
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [["age", "name"]]
    required_together = [["age", "name"]]
    required_if = [["age", "hello", ["name"]]]
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_if=required_if)
    # Test case 1: Test validate with valid parameters.

# Generated at 2022-06-11 00:55:19.269012
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
    valid_params = result.validated_parameters

    assert valid_params['age'] == 42, 'Parameter age should be 42'

# Generated at 2022-06-11 00:55:21.410554
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({})
    result = validator.validate({})
    assert (not result.error_messages)

# Generated at 2022-06-11 00:55:28.442355
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str', 'default': 'bo'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    assert result.unsupported_parameters == set()

    assert result.error_messages == []

# Generated at 2022-06-11 00:55:39.156872
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning, AnsibleParserWarning

    argument_spec = {
        'name': {'type': 'str'},
        'hot': {'type': 'str', 'aliases': ['hot_dog']},
        'age': {'type': 'int'},
        'cool': {'required': True},
        'cool_new': {'deprecated': {'version': '2.5', 'removed_in': '3.0'}, 'type': 'int'},
        'connection': {'type': 'dict', 'default': {}, 'suboptions': {
            'foo': {'type': 'str'},
        }}
    }


# Generated at 2022-06-11 00:55:48.086971
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import Parameter, PARAM_TYPES
    from argparse import Namespace
    from ansible.module_utils.six import string_types

    # build an argument_spec of type dict
    argument_spec = {}
    for type in PARAM_TYPES:
        argument_spec[type] = {'type': type}

    mandatory_args = {}
    optional_args = {}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(mandatory_args)

    # check that the error messages of the result are of type list
    assert isinstance(result.error_messages, list)
    # check that the warnings of the result are of type dict
    assert isinstance(result._warnings, list)
    # check that the

# Generated at 2022-06-11 00:55:55.287388
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator(
        {'ansible_version_added': {'type': 'str'}},
        mutually_exclusive=[['a', 'b']]
    )
    validated_parameters = module_argument_spec_validator.validate({'a': 1})
    assert validated_parameters.validated_parameters == {'a': 1}
    assert validated_parameters.errors == []
    assert len(validated_parameters.error_messages) == 0



# Generated at 2022-06-11 00:56:05.558355
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create parameters to be validated using alias 'shell'
    parameters = {
        'name': 'bo',
        'age': '42',
        'shell': '/bin/bash',
    }

    # Create argument spec containing nested argument spec
    # 'shell' is an alias of 'executable'
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'executable': {'type': 'str'},
        'another_spec': {
            'type': 'dict',
            'shell': {'type': 'str'},
            'nested_spec': {
                'type': 'dict',
                'shell': {'type': 'str'},
            },
        },
    }

    # Instantiate the class ModuleArgumentSpecValidator


# Generated at 2022-06-11 00:56:12.398295
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-11 00:56:18.098087
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # pylint: disable=too-many-locals
    # pylint: disable=line-too-long
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import (
        to_native,
        to_text,
        to_bytes
    )

    # pylint: disable=redefined-builtin
    class AnsibleModule(object):
        """AnsibleModule test stub."""


# Generated at 2022-06-11 00:56:43.609491
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'food_preferences': {
            'type': 'list',
            'elements': 'dict',
            'options': {
                'name': {'type': 'str'},
                'ingredients': {'type': 'list'},
                'enabled': {'type': 'bool'},
            }
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'food_preferences': [
            {
                'name': 'yogurt',
                'ingredients': [],
                'enabled': 'yes',
            }
        ]
    }

    validator = ArgumentSpecValidator(argument_spec)
   

# Generated at 2022-06-11 00:56:49.971716
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleWarning
    from ansible.module_utils.six import PY2

    foo = {}
    bar = {}
    validator = ModuleArgumentSpecValidator({'foo': {'aliases': ['bar']}})
    assert validator.validate({'foo': foo, 'bar': bar}).validated_parameters['foo'] is foo

# Generated at 2022-06-11 00:56:55.489930
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-11 00:57:06.671213
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:57:15.253528
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    passed = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(passed)
    assert len(result.error_messages) == 0
    assert passed == result.validated_parameters

    failed = {
        'name': 'bo',
        'age': 'forty-two',
    }
    result = validator.validate(failed)
    assert len(result.error_messages) != 0

# Generated at 2022-06-11 00:57:23.997680
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    s = '''{
        "argument_spec": {
            "name": {
                "type": "str",
                "aliases": ["username"]
            }
        }
    }'''

    argument_spec = dict()
    argument_spec['name'] = dict()
    argument_spec['name']['type'] = "str"
    argument_spec['name']['aliases'] = ["username"]

    parameters = dict()
    parameters['name'] = "foo"

    validator = ModuleArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    # Check that the alias is correctly handle
    assert(result.validated_parameters['name'] == "foo")

# Generated at 2022-06-11 00:57:34.870705
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class ModuleArgumentSpecValidatorMock(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(ModuleArgumentSpecValidatorMock, self).__init__(*args, **kwargs)

        def deprecate(self, msg, version, date, collection_name=None):
            return msg

        def warn(self, msg):
            return msg

        def validate(self, parameters):
            return super(ModuleArgumentSpecValidatorMock, self).validate(parameters)

    argument_spec = {'test': {'type': 'str', 'aliases': ['test_alias']}}
    parameters = {'test': 'test', 'test_alias': 'test_alias'}

    validator = ModuleArgumentSpecValidatorMock(argument_spec)