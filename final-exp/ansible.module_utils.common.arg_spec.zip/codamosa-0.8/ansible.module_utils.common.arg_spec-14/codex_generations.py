

# Generated at 2022-06-11 00:47:50.529241
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'brand': {'type': 'str'}, 'brand2': {'type': 'str'}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator.argument_spec == argument_spec
    assert validator._valid_parameter_names == {'brand', 'brand2'}


# Generated at 2022-06-11 00:48:01.933501
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with alias_warnings from _handle_aliases
    argument_spec = {'name1': {'type': 'str'}, 'name2': {'type': 'str'}, 'name3': {'type': 'str'}, 'name4': {'type': 'str'}}
    alias_warnings = []
    parameters = {'name1': 'value1', 'name2': 'value2', 'name3': 'value3', 'name4': 'value4'}
    result = ModuleArgumentSpecValidator(argument_spec=argument_spec).validate(parameters=parameters)
    assert(isinstance(result, ValidationResult))
    assert(len(result._warnings) == 0)

# Generated at 2022-06-11 00:48:13.699065
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method ArgumentSpecValidator.validate()"""

    # Test mutual_exclusive and required_if
    argument_spec = {
        'name': {'type': 'str'},
        'state': {
            'type': 'str',
            'choices': ['present', 'absent'],
            'default': 'present'
        },
        'age': {'type': 'int'},
        'description': {'type': 'str'},
        'required_if_present': {'type': 'str'},
        'required_if_absent': {'type': 'str'},
        'required_in_both': {'type': 'str'},
        'mutual_exclusive': {'type': 'str'}
    }

    # Test mutually_exclusive

# Generated at 2022-06-11 00:48:24.926833
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # This class is defined in the method, so that it can use the
    # internal variables of the method.
    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec,
                     mutually_exclusive=None,
                     required_together=None,
                     required_one_of=None,
                     required_if=None,
                     required_by=None,
                     ):
            super(TestModuleArgumentSpecValidator, self).__init__(argument_spec,
                                                                  mutually_exclusive,
                                                                  required_together,
                                                                  required_one_of,
                                                                  required_if,
                                                                  required_by)


# Generated at 2022-06-11 00:48:37.209711
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Define test ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'is_child': {'type': 'bool'},
        'parent': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            },
        },
    }

    required_if = [
        ['is_child', True, ['parent']],
        ['is_child', False, ['age']],
    ]

    mutually_exclusive = [
        ['age', 'parent'],
    ]

    validator = ArgumentSpecValidator(argument_spec, required_if=required_if, mutually_exclusive=mutually_exclusive)



# Generated at 2022-06-11 00:48:40.480292
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"},
                     "age": {"type": "int"},
                     }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-11 00:48:46.949942
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Test the method validate of class ArgumentSpecValidator.
    """
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'str'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == '42'
    assert result.errors == []
    assert result.error_messages == []



# Generated at 2022-06-11 00:48:56.359884
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.module_utils.common.text.converters import to_bytes, to_text, to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import configparser

    argument_spec = {
        'name': dict(type='str'),
        'age': dict(type='int'),
    }
    mutually_exclusive = [['name', 'age']]
    required_one_of = [['name', 'age']]
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(
        argument_spec, mutually_exclusive=mutually_exclusive, required_one_of=required_one_of)

   

# Generated at 2022-06-11 00:49:06.907538
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # argument_spec = {
    #     'name': {'type': 'str'},
    #     'age': {'type': 'int'},
    # }
    #
    # parameters = {
    #     'name': 'bo',
    #     'age': '42',
    # }
    #
    # validator = ArgumentSpecValidator(argument_spec)
    # result = validator.validate(parameters)
    #
    # if result.error_messages:
    #     sys.exit("Validation failed: {0}".format(", ".join(result.error_messages))
    #
    # valid_params = result.validated_parameters

    pass

# Generated at 2022-06-11 00:49:18.544974
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Utility function for unit testing method validate of class ModuleArgumentSpecValidator
    """
    import sys
    import unittest

    class TestException(Exception):
        pass

    class TestModuleArgumentSpecValidator(unittest.TestCase):

        def setUp(self):
            self.name = 'TestModuleArgumentSpecValidator'
            self.argument_spec = {'valid_param': {'type': 'str'}, 'another_valid_param': {'type': 'int'}}
            self.parameters = {'valid_param': 'value'}
            self.mutually_exclusive = None
            self.required_together = None
            self.required_one_of = None
            self.required_if = None
            self.required_by = None

        def test_simple(self):
            validator

# Generated at 2022-06-11 00:49:33.201233
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    This function tests the ArgumentSpecValidator.validate method
    """
    argument_spec = {
        "name": {'type': 'str'},
        "age": {'type': 'int'},
    }
    parameters = {
        "name": "bo",
        "age": "42",
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result.error_messages, list)
    assert result.error_messages == []
    assert result.validated_parameters["name"] == "bo"
    assert result.validated_parameters["age"] == 42



# Generated at 2022-06-11 00:49:42.340242
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.testns.testcoll.plugins.module_utils.test_utils.compat_deepcopy import deepcopy
    from ansible_collections.testns.testcoll.plugins.module_utils.test_utils.compat_paramiko import Transport

    import os
    import sys

    # Create an instance of ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

# Generated at 2022-06-11 00:49:50.605946
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.deprecation import RemovedInAnsible27Warning
    import warnings

    warnings.filterwarnings('once', category=RemovedInAnsible27Warning)
    result = ModuleArgumentSpecValidator({"a": {"type": "str", "deprecated": [{"msg": "deprecated"}]}}, ).validate({"a": "a"})
    assert result.validated_parameters["a"] == "a"
    assert isinstance(result.errors[0], RemovedInAnsible27Warning)

# Generated at 2022-06-11 00:49:54.749814
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(arg_spec)
    assert validator.argument_spec == arg_spec


# Generated at 2022-06-11 00:49:58.841167
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)



# Generated at 2022-06-11 00:50:07.616532
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'bio': {'type': 'dict'},
        'bio.favourite_food': {'type': 'str'},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
        'bio': {'favourite_food': 'ice cream'},
        'not_a_parameter': 'hello',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-11 00:50:17.721702
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased_age': {'type': 'int', 'aliases': ['alias_age']},
        'birth': {'type': 'int', 'required': True},
        'aliased_birth': {'type': 'int', 'aliases': ['alias_birth'], 'version_added': '2.7'},
        'aliased_birth_with_deprecation': {'type': 'int', 'aliases': ['alias_birth_with_deprecation'], 'version_added': '2.7', 'version_removed': '3.0', 'collection_name': 'foo.bar'},
    }


# Generated at 2022-06-11 00:50:30.110940
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Only basic test: a few fields and types, plus a subspec.
    argument_spec = dict(
        test_param=dict(type="bool"),
        test_param_int=dict(type="int"),
        test_param_list=dict(type="list"),
        test_param_dict=dict(type="dict"),
        test_param_unknown=dict(type="unknown"),
        test_param_default=dict(type="str", default="default"),
        test_spec=dict(type="dict", elements="str", options=dict(
            test_param_sub=dict(type="str"),
            test_param_sub_list=dict(type="list"),
        )),
    )

# Generated at 2022-06-11 00:50:38.786752
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.text.converters import to_bytes
    class ASError(Exception):
        pass

    def test_check_required_arguments(parameters):
        if not parameters.get('name') or not parameters.get('age'):
            raise ASError("missing required arguments")

    def test_check_mutually_exclusive(parameters):
        if parameters.get('name') and parameters.get('number'):
            raise ASError("name and number are mutually exclusive")


# Generated at 2022-06-11 00:50:39.962266
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "Test not implemented"

# Generated at 2022-06-11 00:50:54.088448
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # parameter_spec is a nested dictionary that specifies the parameter name and its type.
    # Here the type of parameter is bool, the key name is valid_parameter_name.
    # The type of parameter bool has two options i.e., true and false
    parameter_spec = {
        'valid_parameter_name': {
            'type': 'bool',
        }
    }

    # Parameters is also a nested dictionary, where each key is parameters' name.
    # Here the key is 'valid_parameter_name', and its value is 'false'.
    # Note: the value must be of the same type as the value corresponding to 'type' in parameter_spec.
    # If the parameter is not specified in parameter_spec, ansible raises an error.
    parameters = {
        'valid_parameter_name': 'false'
    }

   

# Generated at 2022-06-11 00:50:59.997895
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator.validate(ModuleArgumentSpecValidator(),
                                                  parameters={'name': 'bo', 'age': '42'},
                                                  argument_spec={'name': {'type': 'str'},
                                                                 'age': {'type': 'int'}})

    assert result == ValidationResult({'name': 'bo', 'age': '42'})

# Generated at 2022-06-11 00:51:06.602575
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(argument_spec={'host': {'required': True, 'type': 'str'}})
    result = validator.validate({'host': '127.0.0.1'})

    assert result.validated_parameters == {'host': '127.0.0.1'}
    assert not result.errors
    assert not result._no_log_values
    assert not result._unsupported_parameters

# Generated at 2022-06-11 00:51:14.243322
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-11 00:51:22.162153
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-11 00:51:29.563772
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.six import StringIO
    import sys

    test_deprecation = False
    test_warnings = False
    test_module_parameters = {}

    def test_warn(msg, category=None, version='2.13', collection_name=None):
        global test_warnings
        test_warnings = True
        assert msg == "Both option module_utilities_test and its alias module_utilities_test_alias are set."

    def test_deprecate(msg, version=None, date=None, collection_name=None):
        global test_deprecation
        test_deprecation = True

# Generated at 2022-06-11 00:51:39.479832
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'one': {'type': 'str'}})
    assert validator.validate({'one': 'foo'}) is not None
    assert validator.validate({'one': 'foo'}).validated_parameters == {'one': 'foo'}
    assert validator.validate({'one': 'foo'}).unsupported_parameters == set()
    assert validator.validate({'one': 'foo'}).error_messages == []

    parameters = {'one': 'foo'}
    result = validator.validate(parameters)
    assert result.warnings == []
    assert result.deprecations == []

# Generated at 2022-06-11 00:51:49.686655
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'facts': {'type': 'dict'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'facts': {'name': 'moe', 'age': '42'}
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._validated_parameters['name'] == parameters['name']
    assert result._validated_parameters['age'] == parameters['age']
    assert result._validated_parameters['facts'] == parameters['facts']
    assert result._validated_parameters['facts']['name'] == parameters['facts']['name']

# Generated at 2022-06-11 00:52:01.438117
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.parameters import NON_NETWORK_PARAMETERS
    from ansible.module_utils.network.common.parameters import (
        NetworkConfig,
        NetworkConfigPolicy,
    )
    from ansible.module_utils.network.common.parameters import parameter_value_to_basic_type
    from ansible.module_utils.network.common.parameters import ENDPOINT_ARGUMENT_SPEC
    from ansible.module_utils.network.common.config import NETWORK_PROVIDERS_ARGS
    # need to send `parameters` along with argument_spec

# Generated at 2022-06-11 00:52:12.232859
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''
    unit test for method validate of class ArgumentSpecValidator
    '''
    validator = ArgumentSpecValidator({'parameter_1': {'type': 'dict', 'options': {'key_1': {'type': 'str'}}},
                                       'parameter_2': {'type': 'list', 'elements': 'dict', 'options': {'key_2': {'type': 'str'}}},
                                       'parameter_3': {'type': 'str'},
                                       'parameter_4': {'type': 'str'},
                                       'no_log': {'type': 'bool'}})


# Generated at 2022-06-11 00:52:28.399933
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test ModuleArgumentSpecValidator.validate
    """
    no_log_values = [
        'password',
        'secret',
        'private_key',
        'new_password',
        'access_token',
    ]


# Generated at 2022-06-11 00:52:39.319465
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.common.arg_spec

    # Test with parameters that should not raise errors
    spec = {'boolean_option': {'type': 'bool'}}
    parameters = {'boolean_option': 'true'}
    validator = ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert not result.error_messages

    # Test with parameters that should raise errors
    spec = {'boolean_option': {'type': 'bool'}}
    parameters = {'boolean_option': 'nonsense'}
    validator = ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator(spec)
    result

# Generated at 2022-06-11 00:52:50.360886
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    mutually_exclusive = [['value1', 'value2']]
    required_together = [['value1', 'value2']]
    required_one_of = [['value1', 'value2']]

# Generated at 2022-06-11 00:53:01.182574
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestException(Exception):
        pass

    # always used for recording deprecations
    def deprecate(msg, **kwargs):
        pass

    # always used for recording warnings
    def warn(msg):
        pass

    # always raise exceptions - can't get to actual methods with paramters
    def check_mutually_exclusive(terms, given_parameters):
        assert terms is not None
        assert given_parameters is not None
        raise TestException

    def check_required_arguments(arg_spec, given_parameters):
        assert arg_spec is not None
        assert given_parameters is not None

    class TestValidationResult:
        def __init__(self):
            self._deprecations = []
            self._warnings = []
            self.errors = AnsibleValidationErrorMultiple()


# Generated at 2022-06-11 00:53:09.453192
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'answer': {'type': 'bool', 'aliases': ['the_answer'], 'default': 42},
    }

    results = ModuleArgumentSpecValidator(argument_spec).validate({
        'name': 'bo',
        'age': '42',
        'answer': 42,
        'the_answer': False
    })

    assert results.validated_parameters['name'] == 'bo'
    assert results.validated_parameters['age'] == '42'
    assert results.validated_parameters['answer'] == False

# Generated at 2022-06-11 00:53:16.005334
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    # check that deprecation is warned with the right parameters
    v = ModuleArgumentSpecValidator({}, )
    p = {'name': 'some_name'}
    result = v.validate(p)
    # check that the deprecation is not added to the result
    assert(result._deprecations == [])
    # check that the  warning is added to the result
    assert(result._warnings == [])

# Generated at 2022-06-11 00:53:17.056963
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-11 00:53:28.285728
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age']
    ]

    required_by = {
        'name': ['age']
    }

    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive=mutually_exclusive,
                 required_together=required_together,
                 required_one_of=required_one_of,
                 required_if=required_if,
                 required_by=required_by,
                 )

# Generated at 2022-06-11 00:53:29.372101
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert 'ArgumentSpecValidator' == type(ArgumentSpecValidator()).__name__

# Generated at 2022-06-11 00:53:33.997686
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    raw_arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(raw_arg_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []



# Generated at 2022-06-11 00:53:37.586612
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():pass

# Generated at 2022-06-11 00:53:48.526864
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test method ArgumentSpecValidator.validate"""
    module = MockAnsibleModule()
    module.argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    module.argument_spec['sub_spec'] = module.argument_spec.copy()

    parameters = {
        'name': 'bo',
        'age': '42',
        'sub_spec': {
            'name': 'bo',
            'age': '42',
        },
    }

    validator = ArgumentSpecValidator(module.argument_spec,
                                      mutually_exclusive=(),
                                      required_together=(),
                                      required_one_of=(),
                                      required_if=(),
                                      required_by=())
    result = validator.valid

# Generated at 2022-06-11 00:53:58.151283
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'default': 42},
        'a_dict': {'type': 'dict', 'default': {}},
        'a_simple_list': {'type': 'list', 'default': ['a', 'b', 'c'], 'elements': 'str'},
        'a_simple_bool': {'type': 'bool'},
        'a_list_of_dicts': {'type': 'list', 'elements': 'dict'},
        'a_complex_list': {'type': 'list', 'elements': 'list'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['age', 'a_dict']]
   

# Generated at 2022-06-11 00:54:09.019691
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.parameters import sanitize_keys, sanitize_values
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.arg_spec import ValidationResult

    test_parameters = dict()
    test_argument_spec = dict()
    test_mutually_exclusive = None
    test_required_together = None

# Generated at 2022-06-11 00:54:16.691637
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create an ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    val = ModuleArgumentSpecValidator(argument_spec)

    # set parameters to be validated
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # validate the parameters
    result = val.validate(parameters)

    # tests
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:54:17.682280
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # TODO
    pass


# Generated at 2022-06-11 00:54:25.360688
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test_dummy_warning
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'int'},
        'c': {'type': 'float'},
        'd': {'type': 'bool'},
        'e': {},
    }

    parameters = {'a': '1',
                  'b': 'string',
                  'c': '3.0',
                  'd': '',
                  'e': '1'}

    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    assert 'a must be of type bool, but got string' in result.error_messages
    assert 'b must be of type int, but got string' in result.error_messages

# Generated at 2022-06-11 00:54:36.311937
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'likes': {'type': 'list', 'required': True},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'likes': ['food', 'travel', 'clowns', 42],
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert type(result.validated_parameters) is dict
    assert result.validated_parameters['name'] == 'bo'
    assert type(result.validated_parameters['name']) is str
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:54:42.349046
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "name": {"required": True},
        "age": {"type": "int", "default": 7},
    }

    module_args = {"name": "bo", "age": "42"}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(module_args)

    assert result.validated_parameters == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-11 00:54:53.537896
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator(argument_spec={'new_args': {'type': 'dict'}},
                                   mutually_exclusive=['new_arg'],
                                   required_together=['required_together', 'with_default'],
                                   required_one_of=[['one_of', 'one_of_second']],
                                   required_if=[['required_if', 'value', ['required_if', 'default_param']]],
                                   required_by=dict(required_by=['required_by_param'])
                                   ).validate(parameters={'new_args': {'key': 'value'}})

    # assert number of errors = 0 after validation
    assert len(result.errors) == 0


# Generated at 2022-06-11 00:55:10.067109
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    def test_failure(parameters, errors, deprecations=None, warnings=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None, required_if=None, required_by=None):
        # Make a copy to prevent side-effects
        parameters = deepcopy(parameters)
        arg_spec = {key: {'type': 'str', 'required': True} for key in parameters}

        validator = ModuleArgumentSpecValidator(arg_spec, mutually_exclusive=mutually_exclusive,
                                                required_together=required_together,
                                                required_one_of=required_one_of,
                                                required_if=required_if,
                                                required_by=required_by)
        result = validator.validate(parameters)
        assert result.errors

# Generated at 2022-06-11 00:55:21.365485
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MyModuleArgumentValidator(ModuleArgumentSpecValidator):
        # used to test _verbosity
        def __init__(self,*args, **kwargs):
            self._verbosity = kwargs.pop('verbosity')
            super(MyModuleArgumentValidator, self).__init__(*args, **kwargs)

    result = MyModuleArgumentValidator({'a':{}}, verbosity=1).validate({})
    assert not result._warnings, "Unexpected warnings: {0}".format(result._warnings)
    assert not result._deprecations, "Unexpected deprecations: {0}".format(result._deprecations)

# Generated at 2022-06-11 00:55:27.432767
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-11 00:55:32.681964
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    # Given
    spec = {
        'mandatory_parameter': {'type': 'str'},
    }

    valid_parameters = {'mandatory_parameter': 'value'}

    missing_parameters = {}

    invalid_parameters = {'mandatory_parameter': 42}

    validator = ModuleArgumentSpecValidator(spec)

    # When
    result1 = validator.validate(valid_parameters)
    result2 = validator.validate(missing_parameters)
    result3 = validator.validate(invalid_parameters)

    # Then
    assert result1.errors == []
    assert result2.errors != []
    assert result3.errors != []

# Generated at 2022-06-11 00:55:35.705472
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import _sanitize_version
    _sanitize_version()
    assert ModuleArgumentSpecValidator.validate.__doc__ is not None

# Generated at 2022-06-11 00:55:41.943887
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['my_name'],
        },
        'age': {
            'type': 'int',
            'aliases': ['my_age'],
        },
        'lang': {
            'type': 'str',
            'aliases': ['favorite_language'],
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'lang': 'python',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters
    assert result.error_messages == []



# Generated at 2022-06-11 00:55:50.073074
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common._collections_compat import Mapping
    val = {'collection_name': 'Test_collection_name', 'date': 'Test_date', 'version': 'Test_version'}
    warning = {'alias': 'alias_name', 'option': 'option_name'}
    val_result = {'name': 'Test_name'}
    expected_result_deprecate = [{'collection_name': 'Test_collection_name', 'date': 'Test_date', 'name': 'Test_name', 'version': 'Test_version'}]
    expected_result_warn = [{'alias': 'alias_name', 'option': 'option_name'}]
    expected_result_validated_params = {'name': 'Test_name'}
    validate_result = ModuleArgument

# Generated at 2022-06-11 00:55:50.958653
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})

# Generated at 2022-06-11 00:56:02.046034
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
        'other_thing': True
    }

    result = validator.validate(parameters)

    assert 'name' in result.validated_parameters
    assert result.validated_parameters['name'] == 'bo'

    assert 'age' in result.validated_parameters
    assert result.validated_parameters['age'] == 42

    assert len(result.error_messages) == 3

# Generated at 2022-06-11 00:56:10.317404
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    import traceback


# Generated at 2022-06-11 00:56:24.963219
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'count': {'type': 'int', 'default': 0},
        'count_list': {'type': 'list', 'default': []}
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
        'count': 'five',
        'count_list': 'five',
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive)

    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-11 00:56:33.668459
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-11 00:56:42.015257
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.unsupported_parameters == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-11 00:56:45.987232
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def test_function():
        pass
    m = ModuleArgumentSpecValidator(test_function.__annotations__)
    result = m.validate({'baz': 'bop'})
    assert not result.error_messages

# Generated at 2022-06-11 00:56:47.429384
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = super(ModuleArgumentSpecValidator, self).validate(parameters)

# Generated at 2022-06-11 00:56:56.295684
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate method of ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 1, 'require': True},
        'address': {'type': 'dict', 'require': True},
        'address.city': {'type': 'str'},
        'address.state': {'type': 'str'},
        'address.country': {'type': 'str'},
    }
    mutually_exclusive = [['country', 'state']]
    parameters = {
        'name': 'bo',
        'address': {
            'city': 'Beijing',
            'country': 'China'
        }
    }
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive)

# Generated at 2022-06-11 00:57:07.351301
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            pass

    # Mock ansible.module_utils.common.warnings.deprecate
    import unittest.mock as mock
    deprecate_mock = mock.Mock()
    warn_mock = mock.Mock()

# Generated at 2022-06-11 00:57:13.856417
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {}
    # kwargs are optional parameters which are mutually exclusive and required_if
    mutually_exclusive = [['value1', 'value2']]
    required_if = [['value3', 'value4', ['value5']]]
    myModuleArgumentSpecValidator = ModuleArgumentSpecValidator(argument_spec,
                                                                mutually_exclusive=mutually_exclusive,
                                                                required_if=required_if)



# Generated at 2022-06-11 00:57:22.632628
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  import sys
  import ansible_collections.ansible.community.plugins.module_utils.common.arg_spec as arg_spec
  import ansible_collections.ansible.community.plugins.module_utils.common.parameters as parameters
  import ansible_collections.ansible.community.plugins.module_utils.common.validation as validation

  # This method is really hard to unit test using mocks, since a large part of
  # the test code would have to be rewritten. So, instead, we use a real
  # argument spec, that has been tested and works in Ansible.

  # The argument spec we're going to use
  argument_spec = dict(name=dict(type='str'),
                       age=dict(type='int'),)

  # The parameters we're going to test

# Generated at 2022-06-11 00:57:33.665188
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Mutual exclusive validation
    argument_spec = {'names': {'type': 'list', 'required': True, 'elements': 'str'}}
    mutually_exclusive = ['names']
    parameters = {'names': ['test1', 'test2']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    assert not result.error_messages, result.error_messages

    mutually_exclusive = [['names'], ]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    assert not result.error_messages, result.error_messages

    mutually_exclusive = []