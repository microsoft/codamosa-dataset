

# Generated at 2022-06-16 22:17:29.397850
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:17:34.849859
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:17:46.499850
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Unit test for method validate of class ModuleArgumentSpecValidator
    """
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'str', 'aliases': ['alias']}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': 'alias'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'aliases'

    # Test for warnings

# Generated at 2022-06-16 22:17:58.514794
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with no deprecations or warnings
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test with deprecations and warnings
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias']},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:18:07.099620
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:14.464593
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-16 22:18:17.564058
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:18:25.780409
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['aliases_list']}
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['a', 'b', 'c'],
        'aliases_list': ['d', 'e', 'f']
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'aliases': ['a', 'b', 'c', 'd', 'e', 'f']}

# Generated at 2022-06-16 22:18:31.533730
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:39.418024
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import deprecate, warn

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:18:50.532298
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:18:57.789359
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:19:08.151104
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'name_alias'

    # Test for warning

# Generated at 2022-06-16 22:19:17.454756
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:19:24.296058
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    result = validator.validate({'name': 'bo'})
    assert result.validated_parameters == {'name': 'bo'}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-16 22:19:33.087513
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:19:38.535738
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:19:48.564600
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age'],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:20:01.220443
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple, RequiredError, UnsupportedError

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

   

# Generated at 2022-06-16 22:20:07.699120
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:20:22.784886
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-16 22:20:34.308291
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased': {'type': 'str', 'aliases': ['alias']},
        'deprecated': {'type': 'str', 'aliases': ['deprecated_alias'], 'deprecated': {'version': '2.9', 'collection_name': 'community.general'}},
    }


# Generated at 2022-06-16 22:20:42.312522
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'name_alias'

    # Test for warnings
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:20:54.344890
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings
    import pytest
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleModuleWarning
    from ansible.module_utils.common.warnings import AnsibleCollectionDeprecationWarning

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

   

# Generated at 2022-06-16 22:20:58.762605
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-16 22:21:10.500726
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:21:16.882439
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:21:20.940567
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:21:28.563199
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:21:36.055999
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:21:57.400074
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:22:04.336957
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:22:16.997909
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-16 22:22:27.846364
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'str', 'aliases': ['aliases_alias']},
        'deprecated_alias': {'type': 'str', 'aliases': ['deprecated_alias_alias'], 'deprecated': {'version': '2.9', 'collection_name': 'community.general'}},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': 'aliases_alias',
        'deprecated_alias': 'deprecated_alias_alias',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-16 22:22:36.389556
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:22:47.052931
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.parameters import _set_defaults
    from ansible.module_utils.common.errors import (
        AliasError,
        AnsibleValidationErrorMultiple,
        MutuallyExclusiveError,
        NoLogError,
        RequiredDefaultError,
        RequiredError,
        UnsupportedError,
    )

# Generated at 2022-06-16 22:22:52.301254
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:23:01.796759
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased_name': {'type': 'str', 'aliases': ['name']}
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'aliased_name': 'bo'
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'aliased_name'

    # Test for warnings

# Generated at 2022-06-16 22:23:10.429063
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []


# Generated at 2022-06-16 22:23:21.657680
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with no deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

    # Test with deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['old']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-16 22:23:36.734550
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:23:43.603460
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:23:56.161381
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test for warnings
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias']},
        'age': {'type': 'int'},
    }

# Generated at 2022-06-16 22:24:04.014559
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.error_messages


# Generated at 2022-06-16 22:24:10.205530
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:24:17.529573
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:24:28.433318
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['name']]
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-16 22:24:35.929756
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple, MutuallyExclusiveError, UnsupportedError

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-16 22:24:46.488963
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased_name': {'type': 'str', 'aliases': ['name']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliased_name': 'bo',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'aliased_name': 'bo'}
    assert result.unsupported_parameters == set()

    # Test for warnings

# Generated at 2022-06-16 22:24:54.641601
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-16 22:25:16.131390
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:25:27.271302
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleModuleWarning
    import warnings

    warnings.simplefilter('error', AnsibleDeprecationWarning)
    warnings.simplefilter('error', AnsibleModuleWarning)


# Generated at 2022-06-16 22:25:40.234643
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

    # Test for warning

# Generated at 2022-06-16 22:25:45.571049
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-16 22:25:58.484868
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn

    # Test if deprecate and warn are called
    def deprecate(msg, version=None, date=None, collection_name=None):
        assert msg == "Alias 'name' is deprecated. See the module docs for more information"
        assert version == '2.13'
        assert date == '2029-01-01'
        assert collection_name == 'community.general'

    def warn(msg):
        assert msg == "Both option name and its alias alias are set."

   

# Generated at 2022-06-16 22:26:09.270440
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['alias']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['alias1', 'alias2'],
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'aliases': ['alias1', 'alias2']}
    assert result.unsupported_parameters == set()

    # Test for warnings
    argument_

# Generated at 2022-06-16 22:26:16.829458
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-16 22:26:23.863044
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-16 22:26:34.367177
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with deprecations
    argument_spec = {'name': {'type': 'str', 'aliases': ['name_alias']}}
    parameters = {'name': 'bo', 'name_alias': 'bo'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo'}
    assert result.errors == []
    assert result.error_messages == []
    assert result._deprecations == [{'name': 'name_alias'}]
    assert result._warnings == []

    # Test with warnings
    argument_spec = {'name': {'type': 'str', 'aliases': ['name_alias']}}

# Generated at 2022-06-16 22:26:44.029930
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.six import string_types

    # Test for method validate of class ModuleArgumentSpecValidator
    #
    # This test is not meant to be run as part of the test suite.
    # It is meant to be run manually to ensure that the deprecation
    # and warning messages are printed correctly.
    #
    # To run this test, execute the following command:
    #
    # python -m ansible.module_utils.common.arg_spec test_ModuleArgumentSpecValidator_validate
    #
    # The expected output is:
    #
    # DEPRECATION WARNING: Alias 'name' is deprecated. See