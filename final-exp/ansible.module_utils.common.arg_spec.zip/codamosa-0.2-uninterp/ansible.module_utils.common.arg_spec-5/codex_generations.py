

# Generated at 2022-06-16 22:17:32.816973
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.error_messages

# Generated at 2022-06-16 22:17:45.353507
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'name_alias'

    # Test for warnings
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }

# Generated at 2022-06-16 22:17:52.381891
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:02.474803
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    import warnings
    import sys

    # Test for deprecation warning
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['aliases_list']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['a', 'b', 'c'],
        'aliases_list': ['d', 'e', 'f'],
    }



# Generated at 2022-06-16 22:18:10.749029
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:18:21.644925
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for mutually exclusive parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], MutuallyExclusiveError)

    # Test for required parameters
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int'},
    }
    validator = Argument

# Generated at 2022-06-16 22:18:32.235613
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-16 22:18:39.647873
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:46.934643
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:18:52.412803
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:19:07.772406
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleUndefinedVariable
    from ansible.module_utils.common.warnings import AnsibleUserWarning

    import warnings
    import pytest


# Generated at 2022-06-16 22:19:16.405297
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:19:22.453473
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for method validate of class ModuleArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:19:35.005940
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleModuleWarning

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['alias']},
        'deprecated': {'type': 'str', 'deprecated': {'version': '2.10', 'collection_name': 'test_collection'}},
        'warnings': {'type': 'str', 'aliases': ['alias_warnings']},
    }


# Generated at 2022-06-16 22:19:41.508074
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:19:52.133622
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age'],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:20:01.019760
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-16 22:20:09.496409
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import deprecate, warn
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result

# Generated at 2022-06-16 22:20:21.808466
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_str

# Generated at 2022-06-16 22:20:29.122817
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:20:49.042077
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name', 'age']],
    ]

    required_by = {
        'name': ['age'],
        'age': ['name'],
    }


# Generated at 2022-06-16 22:20:58.731924
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:21:10.500410
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)


# Generated at 2022-06-16 22:21:15.588056
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:21:22.773993
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.six import string_types

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance

# Generated at 2022-06-16 22:21:29.454736
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:21:41.241712
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nickname']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result._deprecations == [{'name': 'nickname'}]
    assert result._warnings == []

    # Test for warning

# Generated at 2022-06-16 22:21:48.667627
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:22:00.975007
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test for warnings
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['age_alias']},
    }


# Generated at 2022-06-16 22:22:08.743042
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple, MutuallyExclusiveError, RequiredError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:22:26.990977
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased_name': {'type': 'str', 'aliases': ['name']},
        'aliased_age': {'type': 'int', 'aliases': ['age']},
        'deprecated_name': {'type': 'str', 'aliases': ['name'], 'deprecated': {'version': '2.0', 'collection_name': 'test_collection'}},
        'deprecated_age': {'type': 'int', 'aliases': ['age'], 'deprecated': {'version': '2.0', 'collection_name': 'test_collection'}},
    }

# Generated at 2022-06-16 22:22:37.640685
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-16 22:22:44.938585
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:22:51.230824
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.error_messages

# Generated at 2022-06-16 22:22:58.950442
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['aliases_list']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['alias1', 'alias2'],
        'aliases_list': ['alias3', 'alias4'],
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result._deprecations) == 2
    assert result._deprecations[0]['name'] == 'aliases'

# Generated at 2022-06-16 22:23:11.280627
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:23:17.494612
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()


# Generated at 2022-06-16 22:23:27.892036
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:23:36.488746
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:23:46.201590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleParserWarning
    import warnings

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['alias']},
        'deprecated_aliases': {'type': 'list', 'aliases': ['deprecated_alias'], 'deprecated': {'version': '2.10', 'date': '2022-06-01', 'collection_name': 'community.general'}},
    }


# Generated at 2022-06-16 22:24:17.253423
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-16 22:24:28.173538
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for mutually exclusive parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.error_messages == ['parameters are mutually exclusive: [name, age]']

    # Test for required parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
    }

# Generated at 2022-06-16 22:24:33.614735
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:24:41.675520
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()


# Generated at 2022-06-16 22:24:47.190131
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for mutually exclusive parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'sex': {'type': 'str', 'choices': ['male', 'female']},
        'address': {'type': 'dict', 'options': {
            'street': {'type': 'str'},
            'city': {'type': 'str'},
            'state': {'type': 'str'},
            'zip': {'type': 'int'},
        }},
    }


# Generated at 2022-06-16 22:24:57.407572
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age'], 'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

    assert valid

# Generated at 2022-06-16 22:25:05.411129
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:25:18.147296
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert not result.unsupported_parameters

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:25:25.716570
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.error_messages

# Generated at 2022-06-16 22:25:39.215434
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecations
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []
    assert result._deprecations == [{'name': 'name_alias'}]
    assert result._warnings == []

    # Test for warnings
    argument

# Generated at 2022-06-16 22:26:15.109762
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test the method validate of class ModuleArgumentSpecValidator
    """
    # Test with no deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

    # Test with deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    valid

# Generated at 2022-06-16 22:26:24.422066
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:26:31.504084
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:26:37.660787
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:26:48.369222
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:26:53.890785
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-16 22:26:59.781825
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:27:05.115039
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-16 22:27:15.791856
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleUserWarning

    import warnings
