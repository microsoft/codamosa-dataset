

# Generated at 2022-06-16 22:17:33.335979
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test validate method of class ModuleArgumentSpecValidator
    """
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleCollectionDeprecationWarning
    import warnings


# Generated at 2022-06-16 22:17:42.814150
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:17:49.481494
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:18:00.470961
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['age']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:18:08.328281
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:16.473884
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:18:25.227821
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test the method validate of class ModuleArgumentSpecValidator."""
    # Test with no error
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test with error

# Generated at 2022-06-16 22:18:31.218787
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:36.333535
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:18:45.620723
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-16 22:19:00.801012
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:19:09.294272
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-arguments

    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn

# Generated at 2022-06-16 22:19:18.050859
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:19:27.897754
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:19:38.037346
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name', 'age']],
        ['name', 'age', ['name', 'age']],
    ]

    required_by = {
        'name': ['name', 'age'],
        'age': ['name', 'age'],
    }

    validator

# Generated at 2022-06-16 22:19:45.083528
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:19:57.280600
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['name', 'age'], 'age': ['name', 'age']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    assert validator._mutually_exclusive == [['name', 'age']]

# Generated at 2022-06-16 22:20:07.665787
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleCollectionDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleActionDeprecationWarning
    import warnings


# Generated at 2022-06-16 22:20:20.504401
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-16 22:20:32.464722
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.parameters import _set_defaults, _list_no_log_values, _handle_aliases, _get_legal_inputs, _get_unsupported_parameters, _validate_argument_types, _validate_argument_values, _validate_sub_spec

# Generated at 2022-06-16 22:20:46.200253
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.six import PY3

    # Test for deprecations

# Generated at 2022-06-16 22:20:57.177701
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['age']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:21:05.153929
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:21:12.189626
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:21:20.170479
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'str', 'aliases': ['alias']},
        'deprecated_aliases': {'type': 'str', 'aliases': ['deprecated_alias'], 'deprecated': {'version': '2.9', 'collection_name': 'community.general'}},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': 'alias',
        'deprecated_aliases': 'deprecated_alias',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-16 22:21:26.484074
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:21:33.815613
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:21:44.958077
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['name']]
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-16 22:21:52.724909
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:22:04.068124
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    import json

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._warnings == []


# Generated at 2022-06-16 22:22:18.408433
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []


# Generated at 2022-06-16 22:22:28.939712
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age'],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-16 22:22:40.716075
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.parameters import _set_defaults, _validate_argument_types, _validate_argument_values, _validate_sub_spec
    from ansible.module_utils.common.parameters import _list_no_log_values, _handle_aliases, _get_legal_inputs, _get_unsupported_parameters
    from ansible.module_utils.common.parameters import set_fallbacks

# Generated at 2022-06-16 22:22:50.558915
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-16 22:22:56.818936
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Unit test for method validate of class ModuleArgumentSpecValidator
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:23:00.711380
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:23:05.921886
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []

# Generated at 2022-06-16 22:23:16.095349
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleUndefinedVariable
    from ansible.module_utils.common.warnings import AnsibleUserWarning
    import warnings
    import pytest

    # Test for deprecation warning
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
   

# Generated at 2022-06-16 22:23:20.895796
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.error_messages) == 0

# Generated at 2022-06-16 22:23:27.250913
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-16 22:23:41.706082
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []

# Generated at 2022-06-16 22:23:46.988060
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:23:59.444435
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys
    import sys
    import json

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-16 22:24:09.279925
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case 1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test case 2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 'forty-two',
    }

    validator

# Generated at 2022-06-16 22:24:17.203377
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:24:28.132537
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with deprecations
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['aliases_list']},
        'aliases_dict': {'type': 'dict', 'aliases': ['aliases_dict_alias']},
        'aliases_dict_alias': {'type': 'dict', 'aliases': ['aliases_dict']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['a', 'b'],
        'aliases_dict': {'a': 'b'},
        'aliases_dict_alias': {'a': 'b'},
    }


# Generated at 2022-06-16 22:24:35.741700
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for deprecation warning
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': {'type': 'list', 'aliases': ['aliases_list']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['a', 'b'],
        'aliases_list': ['c', 'd'],
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'aliases': ['a', 'b', 'c', 'd']}

# Generated at 2022-06-16 22:24:42.892663
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:24:53.795841
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.parameters import _set_defaults
    from ansible.module_utils.common.errors import MutuallyExclusiveError, RequiredError, UnsupportedError
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.parameters import _validate_argument_types, _validate_argument_values
    from ansible.module_utils.common.parameters import _validate_

# Generated at 2022-06-16 22:25:05.749955
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['age']]
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-16 22:25:46.630138
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.warnings import deprecate, warn

    # Test with no errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters

# Generated at 2022-06-16 22:25:59.740286
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-16 22:26:07.515934
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:26:15.013698
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}},
                                            mutually_exclusive=None,
                                            required_together=None,
                                            required_one_of=None,
                                            required_if=None,
                                            required_by=None)
    parameters = {'name': 'bo', 'age': '42'}
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-16 22:26:24.326946
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:26:32.202114
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-16 22:26:40.721334
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for method validate(self, parameters)
    # of class ModuleArgumentSpecValidator
    #
    # This is not meant to be used outside of AnsibleModule. Use
    # ArgumentSpecValidator instead.

    # Setup test data
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-16 22:26:48.327386
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-16 22:26:55.036511
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-16 22:27:01.662196
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()