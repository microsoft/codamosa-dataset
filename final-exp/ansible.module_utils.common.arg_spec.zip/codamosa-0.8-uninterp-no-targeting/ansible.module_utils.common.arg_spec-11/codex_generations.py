

# Generated at 2022-06-20 15:33:42.691101
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-20 15:33:51.690483
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test argument spec validation
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # ModuleArgumentSpecValidator is a super-class of ArgumentSpecValidator,
    # any tests for ModuleArgumentSpecValidator should also be working for
    # ArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:33:57.943232
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:34:01.764316
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict()
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []


# Generated at 2022-06-20 15:34:11.472567
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_validator = ArgumentSpecValidator({"argument_spec": "validator"})
    assert argument_spec_validator.argument_spec == {"argument_spec": "validator"}
    assert argument_spec_validator._mutually_exclusive is None
    assert argument_spec_validator._required_together is None
    assert argument_spec_validator._required_one_of is None
    assert argument_spec_validator._required_if is None
    assert argument_spec_validator._required_by is None
    assert argument_spec_validator._valid_parameter_names == {"argument_spec"}

# Generated at 2022-06-20 15:34:22.916573
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test that both option and its alias are reported in warnings."""

    # The test case is to make sure that when an arg and alias are both present that we do
    # not raise a warning but put it into the deprecation list.

    mutually_exclusive = [('name', 'param')]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

    argument_spec = {
        'name': {'type': 'str'},
        'param': {'type': 'str', 'aliases': ['parameter']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'param': 'noo',
        'parameter': 'noo_too',
    }

    validator = ModuleArg

# Generated at 2022-06-20 15:34:34.168052
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator"""
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'int'},
    }

    mutually_exclusive = [['a', 'b']]

    required_together = [['a', 'b']]

    required_one_of = [['a', 'b']]

    required_if = [['a', 'b']]

    required_by = {'a': ['b']}

    result = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    # Check that the class variables are correctly set
    assert result._mutually_exclusive == mutually_exclusive
    assert result._required_together == required_together
    assert result._required_

# Generated at 2022-06-20 15:34:40.596273
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    parameters = {'name': 'bo', 'age': '42'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-20 15:34:43.401307
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator({'name': {'type': 'str', 'required': True}}),
                      ArgumentSpecValidator)


# Generated at 2022-06-20 15:34:54.009116
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator


# Generated at 2022-06-20 15:34:59.755855
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator('args') is not None
    assert ModuleArgumentSpecValidator('a','b','c') is not None

# Generated at 2022-06-20 15:35:11.502317
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [
        ['name', 'startswith', 'b', ['age']]
    ]
    required_by = {
        'name': ['age'],
        'age': ['name']
    }


# Generated at 2022-06-20 15:35:17.810462
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    test_spec = dict(
        a0=dict(type='str'),
        a1=dict(type='str'),
        a2=dict(type='str'),
        a3=dict(type='str'),
    )

    test_args = dict(a0='hello', a1='world')

    validator = ModuleArgumentSpecValidator(test_spec)

    result = validator.validate(test_args)

    assert len(result.errors) == 0

# Generated at 2022-06-20 15:35:29.964775
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class FakeArgs:
        def __init__(self, username=None, password=None, key_filename=None, port=22, host_key_checking=True):
            self.username = username
            self.password = password
            self.key_filename = key_filename
            self.port = port
            self.host_key_checking = host_key_checking

    class FakeModule:
        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json was called")


# Generated at 2022-06-20 15:35:35.968627
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    # Case1: Missing Required Arguments
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    error_messages = result.error_messages
    print(error_messages)

# Generated at 2022-06-20 15:35:46.728680
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys

    # check simple validation
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

    # check simple validation different order

# Generated at 2022-06-20 15:35:51.859067
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'param_1': 'value 1', 'param_2': 'value 2'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.error_messages == []


# Generated at 2022-06-20 15:35:57.035040
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    instance = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                                           mutually_exclusive=None,
                                           required_together=None,
                                           required_one_of=None,
                                           required_if=None,
                                           required_by=None,
                                           )
    assert isinstance(instance, ArgumentSpecValidator)

# Generated at 2022-06-20 15:36:05.948781
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = dict(
        name='test_name',
        port=80,
        age='test_age',
        location='test_location',
        user_name='test_user_name',
        passwd=None,
    )


# Generated at 2022-06-20 15:36:15.274887
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by=[]
      )
    assert(isinstance(m, ModuleArgumentSpecValidator))

    from io import StringIO
    import sys
    try:
        sys.stderr = StringIO()
        m.validate({"test": "value"})
        output = sys.stderr.getvalue().strip()
        assert("called with empty argument_spec") in output, "output is {}".format(output)
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-20 15:36:31.675941
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'},
                                             'age': {'type': 'int', 'default': 42},
                                             'alias': {'type': 'str', 'aliases': ['old_name']},
                                             'secret': {'type': 'str', 'no_log': True}
                                             },
                                            required_if=[['secret', 'password']],
                                            required_together=[[['name', 'alias']]],
                                            )

    parameters = {
        'name': 'bo',
        'age': '42',
        'alias': 'sbc',
    }

    result = validator.validate(parameters)

    assert result.validated_parameters == parameters

# Generated at 2022-06-20 15:36:41.325686
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    ''' unit test of class ArgumentSpecValidator '''

    # test arguments
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'sub': {'type': 'dict',
                'subspec': {
                    'subsuba': {'type': 'str'},
                    'subsubb': {'type': 'float'}}}}
    mutually_exclusive = [["subsuba","subsubb"]]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

    # Creating an ArgumentSpecValidator object
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    # testing that

# Generated at 2022-06-20 15:36:42.800162
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test
    ModuleArgumentSpecValidator(argument_spec={})



# Generated at 2022-06-20 15:36:43.361581
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:36:51.548571
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [["a", "b"]]
    required_together = [["c", "d"]]
    required_one_of = [["e", "f"]]
    required_if = [["g", "h", ["i", "j"]]]
    required_by = {'k': ['l', 'm']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                      required_together=required_together, required_one_of=required_one_of,
                                      required_if=required_if, required_by=required_by)
    assert type(validator) == ArgumentSpecValidator
    assert validator

# Generated at 2022-06-20 15:37:01.467382
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    assert issubclass(ArgumentSpecValidator, object)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages

    validator_with_spec = ArgumentSpecValidator(argument_spec,
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None)

    result_with_spec = validator.validate(parameters)

    assert result_with_spec.error_mess

# Generated at 2022-06-20 15:37:09.419359
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    module_utils/common/arg_spec.py uses the following imports.
    from __future__ import (absolute_import, division, print_function)
    Have to mock these imports for unit test of module_utils/common/arg_spec.py
    """
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    builtins.__dict__.update({"absolute_import": None, "division": None, "print_function": None})
    import ansible.module_utils.common.arg_spec


# Generated at 2022-06-20 15:37:10.295977
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:37:13.385053
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # We want to pass when we call the constructor
    ModuleArgumentSpecValidator(argument_spec={},
                                mutually_exclusive=[],
                                required_together=[],
                                required_one_of=[],
                                required_if=[],
                                required_by={})

# Generated at 2022-06-20 15:37:24.151805
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_cases = [
        {
            'given': {
                'parameters': {
                    'age': 42,
                    'name': 'Bob',
                    'gender': 'male'
                }
            },
            'expected': {
                'validated_parameters': {
                    'age': 42,
                    'name': 'Bob',
                    'gender': 'male'
                },
                'error_messages': [],
                'unsupported_parameters': set(),
                'no_log_values': set()
            }
        }
    ]

    for test_case in test_cases:
        given = test_case['given']
        expected = test_case['expected']
        result = ValidationResult(given['parameters'])
        assert result.validated_parameters == expected['validated_parameters']


# Generated at 2022-06-20 15:37:38.178643
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.urls import open_url

    my_open_url = open_url
    my_to_bytes = to_bytes
    my_result = {'stdout_lines': [b'hello world\n']}

    class MyBytesIO(BytesIO):
        def read(self, size):
            return my_result['stdout_lines']

    p = dict(
        url='http://www.ansible.com/',
        force=True,
        validate_certs=False,
        headers=dict(Accept='application/json'),
        url_username='admin',
        url_password='hunter2',
    )


# Generated at 2022-06-20 15:37:45.687614
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'password1': 'password'}
    argument_spec = {'password2': {'no_log': True, 'type': 'str', 'required': True}}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                            required_one_of, required_if, required_by)

    result = validator.validate(parameters)
    assert result.error_messages == ['missing required arguments: password2']

# Generated at 2022-06-20 15:37:55.330779
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [
        ['a', 'b'],
    ]

    required_together = [
        ['c', 'd']
    ]

    required_one_of = [
        ['e', 'f']
    ]

    required_if = [
        ['g', 'h', ['i']],
    ]

    required_by = {
        'j': ['k'],
    }


# Generated at 2022-06-20 15:38:03.253051
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ''' test_ModuleArgumentSpecValidator_validate
        This function performs unit test for method ModuleArgumentSpecValidator.validate
    '''
    test_result_success = True
    print("\n")
    print("print the test result of method ModuleArgumentSpecValidator.validate")

    print("test case 1: argument_spec contains normal case")
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.error_messages:
        test_result_success = False

# Generated at 2022-06-20 15:38:10.544266
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit test for constructor of class ModuleArgumentSpecValidator

    :return: Test result
    :rtype: tuple(bool, str)
    """
    argument_spec = {
        'name': {'type': 'str'},
        'needed': {'type': 'bool', 'default': True},
        'list': {'type': 'list', 'default': ['a', 'b'], 'elements': 'str'},
    }

    module_validator = ModuleArgumentSpecValidator(argument_spec, required_one_of=[['name', 'needed']])

    assert module_validator

    return True, "Constructor of ModuleArgumentSpecValidator() works as expected"



# Generated at 2022-06-20 15:38:21.245634
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Initialize ValidationResult class
    arg_result = ValidationResult({"foo":"bar"})

    # Check no_log_values property
    assert arg_result._no_log_values == set()
    # Check unsupported_parameters property
    assert arg_result._unsupported_parameters == set()
    # Check validated_parameters property
    assert arg_result._validated_parameters == {"foo": "bar"}
    # Check deprecations property
    assert arg_result._deprecations == []
    # Check warnings property
    assert arg_result._warnings == []
    # Check errors property
    assert isinstance(arg_result.errors, AnsibleValidationErrorMultiple)

    # Check no_log_values property getter
    assert arg_result.no_log_values == set()
    # Check unsupported_parameters property

# Generated at 2022-06-20 15:38:27.776379
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate({
        'name': 'bo',
        'age': '42',
    })

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-20 15:38:33.011990
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    param = {"test": "abc"}
    result = ValidationResult(param)
    assert result._validated_parameters == {"test": "abc"}
    assert result.errors.messages == []
    assert result.validated_parameters == {"test": "abc"}
    assert result.error_messages == []
    assert result._unsupported_parameters == set()
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()


# Generated at 2022-06-20 15:38:40.545655
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argumentspec = {
        "name": {
            "type": "str",
        },
        "age": {
            "type": "int",
        },
        "host": {
            "type": "str",
            "required": True,
            "default": "127.0.0.1"
        }
    }

    parameters = {
        "name": "bo",
        "age": "42",
    }

    validator = ArgumentSpecValidator(argumentspec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 4
    assert "parameter has no default value, so it is required" in result.error_messages
    assert "required field" in result.error_messages
    assert "parameter is unsupported" in result.error_messages


# Generated at 2022-06-20 15:38:45.306244
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:38:56.556535
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validation_result = ValidationResult(parameters={'param1': 'val1', 'param2': 'val2'})
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == {'param1': 'val1', 'param2': 'val2'}
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert isinstance(validation_result.errors, AnsibleValidationErrorMultiple)
    assert validation_result.validated_parameters == {'param1': 'val1', 'param2': 'val2'}

# Generated at 2022-06-20 15:39:04.508850
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Simple example of argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Create validator
    validator = ArgumentSpecValidator(argument_spec)

    # Test validation with correct parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test validation with incorrect parameters
    parameters = {
        'name': 'bo',
        'age': 'forty-two',
    }

    result = validator.validate(parameters)

    assert result.errors

# Generated at 2022-06-20 15:39:14.863761
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    # Create a dummy argument spec
    argument_spec = {
        "test_argument": {"type": "bool", "default": False, "aliases": ["test_alias"]},
    }

    # Create a dummy module
    am = AnsibleModule(argument_spec=argument_spec, add_file_common_args=False, no_log=["test_argument"])
    validator = ModuleArgumentSpecValidator(argument_spec, am._mutually_exclusive, am._required_together,
                                            am._required_one_of, am._required_if, am._required_by)

    # Validate an empty param

# Generated at 2022-06-20 15:39:20.618593
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-20 15:39:31.977450
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.six.moves import mock

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    with mock.patch('ansible.module_utils.common.arg_spec.warn') as warn:
        with mock.patch('ansible.module_utils.common.arg_spec.warnings') as warnings:
            warnings.catch_warnings.return_value = [('deprecation', '', '', '', '', '', '', '')]
            validator = ModuleArgumentSpecValidator(argument_spec)
            validator.validate(parameters)
            assert warn.call_count == 1

# Generated at 2022-06-20 15:39:40.047861
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec=arg_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert not result.error_messages

    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-20 15:39:48.858867
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import warnings
    import datetime

    def mock_deprecate(msg, date=None, version=None, collection_name=None):
        assert msg.startswith("Alias 'test_alias' is deprecated")
    def mock_warn(msg):
        expected_msg = "Both option option_name and its alias alias_name are set."
        assert msg == expected_msg


# Generated at 2022-06-20 15:39:52.882761
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_argument_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert isinstance(module_argument_spec_validator.validate({'name': 'bo'}), ValidationResult)

# Generated at 2022-06-20 15:39:56.476398
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    assert validator.argument_spec == argument_spec

# Generated at 2022-06-20 15:40:06.309430
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # To instanciate ModuleArgumentSpecValidator, it must be defined the set of arguments
    # that are mandatory in an argument spec: mutually_exclusive, required_together,
    # required_one_of, required_if and required_by
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None


# Generated at 2022-06-20 15:40:16.791529
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Function to test validate method of class ArgumentSpecValidator."""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == [], 'Validation should not have failed.'
    assert result.validated_parameters == {'name': 'bo', 'age': 42}, 'Expected validated parameters.'



# Generated at 2022-06-20 15:40:19.570764
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    v = ModuleArgumentSpecValidator(argument_spec={})
    assert v._valid_parameter_names == set()

# Unit tests for class ArgumentSpecValidator

# Generated at 2022-06-20 15:40:29.499857
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # Argument Values

# Generated at 2022-06-20 15:40:30.599411
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    x = ModuleArgumentSpecValidator(param=[])
    assert x is not None

# Generated at 2022-06-20 15:40:37.597241
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Test validate of class ArgumentSpecValidator """

    # Testing _no_log_values
    argument_spec = {
        'param1': {
            'type': 'str',
            'no_log': True,
        },
        'param2': {
            'type': 'str',
            'no_log': False,
        },
        'param3': {
            'type': 'str',
            'no_log': False,
        },
        'param4': {
            'type': 'str',
            'no_log': 'on_default',
        },
        'param5': {
            'type': 'str',
            'no_log': 'on_create',
        },
    }


# Generated at 2022-06-20 15:40:49.030553
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    argument_spec = {
    "name": {"type": "str",
             "required": True,
             "aliases": ["name1"]
             },
    "age": {"type": "int",
            "required": False,
            "default": 42,
            "aliases": ["age1"]
            },
    }

    mutually_exclusive = [['name', 'age']]

    parameters = {"name":"bo", "age":"abc"}
    validator = ArgumentSpecValidator(argument_spec=argument_spec,
                                      mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    print(result.error_messages)
    print(result.unsupported_parameters)

# Generated at 2022-06-20 15:40:56.337839
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import _collect_warnings
    from ansible.module_utils.common.warnings import _reset_warnings

    # Test if the method validate of class ModuleArgumentSpecValidator
    # verifies if the option and its alias are set.
    spec = {
        'option': {'type': 'str'},
        'alias': {'type': 'str', 'aliases': ['option']},
    }
    parameters = {'option': 'value', 'alias': 'value'}
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert len(result._warnings) == 1 # one warning is expected
    assert len(result._deprecations) == 0

    # Test if the method validate of class ModuleArgumentSpec

# Generated at 2022-06-20 15:41:02.266984
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [
        ['name', 'present', ['age']],
        ['age', 'present', ['name']],
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-20 15:41:12.485924
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    # ensure it's working
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    # ensure we do not get any deprecations
    assert result._deprecations == []

    # ensure we do not get any warnings
    assert result._warnings == []

    # ensure no errors were caught
    assert result.error_messages == []

    # ensure we did not overwrite parameters in the process
    assert parameters == {
        'name': 'bo',
        'age': '42',
    }

    # ensure we did not mutate

# Generated at 2022-06-20 15:41:15.556230
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-20 15:41:30.876455
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator({'foo': {'type': 'str'}})
    assert validator.argument_spec == {'foo': {'type': 'str'}}
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == {'foo'}


# Generated at 2022-06-20 15:41:42.497805
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [('a', 'b')]
    required_together = [('c', 'd')]
    required_one_of = [('e', 'f')]
    required_if = [['g', 'h', ['i', 'j']]]
    required_by = {'k': ['l', 'm']}
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}
    test_validator = ModuleArgumentSpecValidator(argument_spec,
                                                 mutually_exclusive,
                                                 required_together,
                                                 required_one_of,
                                                 required_if,
                                                 required_by)
    assert test_validator._mutually_exclusive == mutually_exclusive
    assert test_validator._required_together

# Generated at 2022-06-20 15:41:45.037361
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test for method validate of class ArgumentSpecValidator"""
    # No parameter

    # Return type: ValidationResult



# Generated at 2022-06-20 15:41:53.036546
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils._text import to_bytes
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters[b'name'] == to_bytes(u'bo')
    assert result.validated_parameters[b'age'] == 42

# Generated at 2022-06-20 15:42:00.173550
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-20 15:42:05.128154
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v_result = ValidationResult({})
    assert v_result._no_log_values == set()
    assert v_result._unsupported_parameters == set()
    assert v_result._validated_parameters == {}
    assert v_result._deprecations == []
    assert v_result._warnings == []
    assert v_result.errors.messages == []
    assert isinstance(v_result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-20 15:42:13.535175
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['left', 'right'],
    ]

    required_together = [
        ['left', 'right'],
    ]

    required_one_of = [
        ['left', 'right'],
    ]

    required_if = [
        ['left', 'right', ['up', 'down']],
    ]

    required_by = {
        'left': ['up', 'down'],
        'right': ['up', 'down'],
    }

    validator = ArgumentSpecValidator(
        argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)


# Generated at 2022-06-20 15:42:21.639391
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Create an instance of ArgumentSpecValidator
    validator = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator.argument_spec is {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    assert validator._valid_parameter_names == {'name', 'age'}
    assert validator._mutually_exclusive == []
    assert validator._required_together == []
    assert validator._required_one_of is None
    assert validator._required_

# Generated at 2022-06-20 15:42:30.814285
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    This test assert that parameters are validated and coerced to the correct type
    :return:
    """
    from ..common.arg_spec import ArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:42:36.656988
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:42:56.310702
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'firstarg': {'type': 'str'},
        'secondarg': {'type': 'str'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator.argument_spec == argument_spec
    assert validator._valid_parameter_names == {'firstarg', 'secondarg'}



# Generated at 2022-06-20 15:42:56.904489
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({})

# Generated at 2022-06-20 15:43:05.014747
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create an instance of ModuleArgumentSpecValidator class.
    mod_arg_spec_validator = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None,
    )

    # Call method validate of class ModuleArgumentSpecValidator.
    result = mod_arg_spec_validator.validate(parameters={})

    # Check that result is an instance of ValidationResult
    assert isinstance(result, ValidationResult), "Expected to get an instance of ValidationResult class"
    # Check that result is not None
    assert result is not None, "Expected to get an instance of ValidationResult class"

# Generated at 2022-06-20 15:43:09.915820
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(spec)
    assert isinstance(validator, ArgumentSpecValidator)
    assert validator.argument_spec == spec

# Generated at 2022-06-20 15:43:16.412548
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-20 15:43:21.185350
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-20 15:43:24.555856
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({'argument_spec': {}}), ModuleArgumentSpecValidator)
    # argument_spec is required 
    assert not isinstance(ModuleArgumentSpecValidator(), ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:43:27.864032
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Test ModuleArgumentSpecValidator has both the methods: __init__ and validate
    """
    assert hasattr(ModuleArgumentSpecValidator, '__init__')
    assert hasattr(ModuleArgumentSpecValidator, 'validate')

# Generated at 2022-06-20 15:43:34.928007
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    # Test case 1: test when argument_spec has aliases
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['my_name']},
        'age': {'type': 'int', 'aliases': ['my_age']},
        'country': {'type': 'str'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert sorted(validator._valid_parameter_names) == ['age (my_age)', 'country', 'name (my_name)']

    # Test case 2: test when argument_spec has no aliases
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'country': {'type': 'str'},
    }

    validator = Argument