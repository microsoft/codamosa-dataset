

# Generated at 2022-06-20 15:33:49.747600
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'one': 'two', 'three': 'four'}
    test = ValidationResult(parameters)
    assert isinstance(test.validated_parameters, dict)
    assert isinstance(test._no_log_values, set)
    assert isinstance(test._unsupported_parameters, set)
    assert isinstance(test.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:34:01.666783
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [['a', 'b'], ['c', 'd']]
    required_together = [['e', 'f'], ['g', 'h']]
    required_one_of = [['i', 'j']]
    required_if = [['i', 'k', ['l', 'm']]]
    required_by = {'n': ['o', 'p']}
    validator = ArgumentSpecValidator({}, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._required_if == required_if
    assert validator._required_by == required_by


# Generated at 2022-06-20 15:34:14.402070
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case #1
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

    mutually_exclusive = [["name", "age"]]

    parameters = {
        'name': 'bo',
        'age': '42',
        }

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert len(result.errors) == 1
    assert result.error_messages[0] == "age and name are mutually exclusive"

    # Test case #2
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

   

# Generated at 2022-06-20 15:34:15.405354
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validation_result = ValidationResult({'test': 'test'})
    assert isinstance(validation_result, ValidationResult)

# Generated at 2022-06-20 15:34:17.316396
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-20 15:34:26.330965
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils._text import to_text
    # Test cases for ArgumentSpecValidator.validate(self, parameters):

    # 1. tests for psudo-mucally_exclusive of 'yes' and 'no'
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'age': {
            'type': 'int',
            'required': True
        },
        'state': {
            'type': 'str',
            'required': True,
            'choices': ['present', 'absent', 'enabled', 'disabled']
        },
        'no_log': {
            'type': 'bool',
            'default': False
        }
    }

    # test case 1.1 parameters contains 'yes' and 'no' at the same

# Generated at 2022-06-20 15:34:35.033862
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'module_name': {'type': 'str', 'required': True},
                     'module_path': {'type': 'path', 'required': True}
                     }
    validator = ArgumentSpecValidator(argument_spec)

    parameters = {'module_name': 'ansible.module_utils.common.arg_spec',
                  'module_path': '/usr/local/lib/python2.7/dist-packages/ansible/module_utils/common/arg_spec.py'
                  }
    result = validator.validate(parameters)

    if result.errors:
        print(", ".join(result.errors))
    else:
        print(result.validated_parameters)

# Generated at 2022-06-20 15:34:47.671288
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes, to_text

    # To keep the test code shorter, we use a mock namedtuple for the ValidationResult class
    ValidationResult = namedtuple('ValidationResult', ['validated_parameters'])
    # To keep the test code shorter, we use a mock function for the deprecate method
    deprecate = lambda message, version=None, date=None, collection_name=None: None
    class Warn:
        def __init__(self):
            self.warnings = []
        def warn(self, message):
            self.warnings.append(message)
    warn = Warn()

    argument_spec = {'test': {'type': 'str'}}
    mutually_exclusive = None
    required_together = None
    required

# Generated at 2022-06-20 15:34:54.634957
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    sys.argv = []
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}},
                                            mutually_exclusive=[['name', 'age']])

    params = {'name': 'bo', 'age': '42'}
    result = validator.validate(params)

    messages = result.errors.messages
    valid_params = result.validated_parameters

    if messages:
        sys.exit("Validation failed: {0}".format(", ".join(messages)))

# Generated at 2022-06-20 15:35:06.963488
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'type': 'int'},
    }
    mutually_exclusive = [['foo', 'bar']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'bar']]
    required_if = [['foo', 'bar', ['foo', 'bar']]]
    required_by = {'foo': ['bar'], 'bar': ['foo']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    assert validator._mutually_exclusive == [['foo', 'bar']]
    assert validator._required_together == [['foo', 'bar']]
    assert validator

# Generated at 2022-06-20 15:35:22.090308
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    argument_spec = {'a_str': {'type': 'str', 'required': True},
                     'b_str': {'type': 'str', 'required': True},
                     'c_str': {'type': 'str', 'required': True},
                     'd_str': {'type': 'str', 'required': True}}
    mut_ex = [["a_str", "b_str"]]
    req_by = {"d_str": ["a_str", "b_str"], "c_str": ["a_str"]}
    req_if = [["a_str", "yes", ["c_str"]]]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mut_ex, required_by=req_by,
                                            required_if=req_if)

    # Test

# Generated at 2022-06-20 15:35:33.557419
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    arg_spec = {
        'my_arg': {'type': 'str'},
        'my_optional_arg': {'type': 'str', 'default': 'my_default'},
    }

    mutually_exclusive = [['my_arg', 'my_optional_arg']]

    validator = ModuleArgumentSpecValidator(arg_spec, mutually_exclusive=mutually_exclusive)

    # module parameter validation
    # require my_arg
    parameters = {'my_arg': 'foo'}
    result = validator.validate(parameters)
    assert result.validated_parameters['my_arg'] == 'foo'
    assert result.validated_parameters['my_optional_arg'] == 'my_default'

    # mutually exclusive error

# Generated at 2022-06-20 15:35:39.462052
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'a': {
            'type': 'str',
        },
        'b': {
            'type': 'int',
        },
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    assert validator is not None

# Generated at 2022-06-20 15:35:45.518515
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict({'name': 'bo', 'age': '42'})
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:35:56.130688
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Arrange
    class TestModule:
        def __init__(self, module_name):
            self._module_name = module_name

    module = TestModule("test_module")


# Generated at 2022-06-20 15:36:05.250176
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3

    # Not run the unit test for python version 2
    if not PY3:
        return

    from ansible.module_utils.common.parameters import ANSIBLE_METADATA
    from ansible.module_utils._text import to_text
    from ansible.module_utils.compat import ipaddress

    from ansible.module_utils.common.collections import ImmutableDict

    pip_info = ImmutableDict(
        dict(
            name='pip',
            version='22.0.0',
            status='stable',
            date='2022-05-31',
            collection_name='pip'
        )
    )

    # Mock _get_legal_inputs method
    original_get_legal_inputs = _get_legal

# Generated at 2022-06-20 15:36:10.932706
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({
        'name': 'Ansible',
        'age': 42,
    })
    assert result._no_log_values == set()
    assert result._validated_parameters == {
        'name': 'Ansible',
        'age': 42,
    }
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:36:14.405444
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(argument_spec={},
                                 mutually_exclusive=None,
                                 required_together=None,
                                 required_one_of=None,
                                 required_if=None,
                                 required_by=None)._mutually_exclusive == None

# Generated at 2022-06-20 15:36:16.941062
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator({'a': 1, 'b': 2})
    assert m is not None

# Generated at 2022-06-20 15:36:27.091971
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str'
        },
        'age': {
            'type': 'int'
        },
        'friend': {
            'type': 'dict',
            'spec': {
                'name': {
                    'type': 'str'
                }
            }
        }
    }

    mutually_exclusive = ['name', 'age']

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [['name', 'foo', ['age']]]

    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:36:37.298077
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors

    assert isinstance(result.validated_parameters['age'], int)



# Generated at 2022-06-20 15:36:45.274734
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    args = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    required_by = {
        'name': {'required_by': 'age'},
    }

    validator = ArgumentSpecValidator(args, required_by=required_by)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    errors = validator.validate(parameters)
    assert not errors.error_messages

# Generated at 2022-06-20 15:36:52.709909
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Test with valid arguments
    target = ModuleArgumentSpecValidator(
        argument_spec=dict(
            key1=dict(type="int"),
        ),
        mutually_exclusive=[["key1", "key2"]],
        required_together=[["key1", "key2"]],
        required_one_of=[["key1", "key2"]],
        required_if=[["key1", "value", ["key2", "key3"]]],
        required_by={'key1': ['key2']},
    )
    # Test with invalid mutually_exclusive arguments

# Generated at 2022-06-20 15:37:00.834133
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = {
        'name': 'bo',
        'age': '42'
    }
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['first_name']
        },
        'age': {
            'type': 'int'
        }
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(params)

    assert isinstance(result, ValidationResult)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:37:08.937087
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Constructor of class ModuleArgumentSpecValidator,
    with argument_spec as None and required_if,
    mutually_exclusive, required_together, required_one_of and required_by are not None.
    """
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # with argument_spec as None and required_if, mutually_exclusive, required_together,
    # required_one_of and required_by are not None
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    argument_spec = None
    # test constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:37:14.333624
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Testing for error message in the validation result (see Simple Example above)
    v = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}})
    assert v.validate(parameters={'name': 'bo', 'age': '42'}).error_messages == []
    assert v.validate(parameters={'name': 42, 'age': '42'}).error_messages == ['name (string) is required', 'Parameter (age) with value 42 is of type int(42) but we were unable to convert to int']
    assert v.validate(parameters={'age': '42'}).error_messages == ['name (string) is required']

# Generated at 2022-06-20 15:37:19.307161
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    obj = ModuleArgumentSpecValidator(dict(argument_spec=dict(foo=dict(type='str', aliases=['bar']),
                                                               baz=dict(type='str'))))
    res = obj.validate(parameters=dict(foo='foo_val', bar='bar_val', baz='baz_val'))
    assert isinstance(res, ValidationResult)
    assert res.errors == AnsibleValidationErrorMultiple()
    assert res.error_messages == list()
    assert res.validated_parameters == dict(foo='foo_val', baz='baz_val')
    assert res.unsupported_parameters == set()


# Generated at 2022-06-20 15:37:20.894547
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argspec = dict(
        param1=dict(type='str'),
    )

    validator = ModuleArgumentSpecValidator(argspec)
    assert validator is not None

# Generated at 2022-06-20 15:37:21.885546
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator(dict())

# Generated at 2022-06-20 15:37:23.452501
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.validate({})

# Generated at 2022-06-20 15:37:33.364082
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Check ValidationResult for sanity
    parameters = {'a': 'b', 'c': 'd'}
    result = ValidationResult(parameters)
    # Check if attributes are the same after the copy
    assert result.validated_parameters == parameters
    assert result._unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-20 15:37:40.000680
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common._collections_compat import Mapping

    validator = ModuleArgumentSpecValidator({'param1': {'type':'dict'}}, required_one_of=[['param1', 'param2'], ['param3', 'param4']])
    assert isinstance(validator.argument_spec, Mapping)

# Generated at 2022-06-20 15:37:48.373791
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test constructor for class ValidationResult"""
    parameters = {'a': 1, 'b': 2}
    validation_result = ValidationResult(parameters)

    assert validation_result._validated_parameters == parameters
    assert validation_result.validated_parameters == parameters
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.error_messages == AnsibleValidationErrorMultiple().messages
    assert validation_result.unsupported_parameters == set()
    assert validation_result._no_log_values == set()
    assert validation_result._deprecations == []
    assert validation_result._warnings == []


# Generated at 2022-06-20 15:37:49.268653
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:37:54.953203
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # no error
    ModuleArgumentSpecValidator(argument_spec={})

    # ValueError
    try:
        ModuleArgumentSpecValidator(argument_spec=['arg'])
    except ValueError:
        pass
    else:
        assert False

    # TypeError
    try:
        ModuleArgumentSpecValidator(argument_spec={123: None})
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-20 15:38:05.594206
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [['param1', 'param2'], ['param3', 'param4']]
    required_together = [['param1', 'param2'], ['param3', 'param4']]
    required_by = {'param1': ['param2', 'param3']}
    required_one_of = [['param2', 'param3'], ['param4', 'param5']]
    required_if = [
        ['param2', 'value2', ['param3', 'param4']],
        ['param3', 'value3', ['param4', 'param5']],
        ['param4', 'value4', ['param5', 'param6']],
    ]

# Generated at 2022-06-20 15:38:12.825845
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'ping': {'type': 'str'},
        'port': {'type': 'int'},
        'name': {'type': 'str', 'required': True},
        'use_ssl': {'type': 'bool', 'default': False},
        'trigger': {'type': 'dict', 'required': True},
    }
    mutually_exclusive = [['ping', 'port']]
    required_together = [('ping', 'port')]
    required_one_of = [('ping', 'port')]
    required_if = [('name', 'bo', ['port'])]
    required_by = {'trigger': ['name']}

# Generated at 2022-06-20 15:38:17.521196
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestAnsibleModule:
        pass

    m = TestAnsibleModule()
    m.argument_spec = {
        'foo': {'type': 'str'},
        }

    v = ModuleArgumentSpecValidator(m)
    ok = {'foo': 'bar'}
    not_ok = {'foo': 42}

    assert v.validate(ok).validated_parameters == ok
    with pytest.raises(AnsibleValidationErrorMultiple) as e:
        v.validate(not_ok)
    assert 'is of type <int> when we were expecting a <str>' in e.value.messages[0]

# Generated at 2022-06-20 15:38:19.764913
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    v = ModuleArgumentSpecValidator(argument_spec = {
        'test': {'type': 'str'}
    })
    assert v

# Generated at 2022-06-20 15:38:26.620554
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors.messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:38:38.962589
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import NO_LOG_PARAMETERS
    from ansible.module_utils.common.validation import check_required_if, check_required_by


# Generated at 2022-06-20 15:38:47.011689
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    check = {
        'argument_spec': {'test': {'type': 'str'}},
        'mutually_exclusive': None,
        'required_together': None,
        'required_one_of': None,
        'required_if': None,
        'required_by': None
    }
    m = ModuleArgumentSpecValidator(check['argument_spec'],
                                    mutually_exclusive=check['mutually_exclusive'],
                                    required_together=check['required_together'],
                                    required_one_of=check['required_one_of'],
                                    required_if=check['required_if'],
                                    required_by=check['required_by'])
    assert m.argument_spec == check['argument_spec']
    assert m._mutually_exclusive == check['mutually_exclusive']

# Generated at 2022-06-20 15:38:55.202746
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argspec = {
        'hello': {'type': 'int', 'aliases': ['hi']},
    }
    validator = ArgumentSpecValidator(argspec)
    parameters = {'hello': '42'}
    with pytest.raises(AnsibleValidationErrorMultiple):
        result = validator.validate(parameters)
    assert len(result.errors) == 2
    assert [isinstance(e, AliasError) for e in result.errors] == [True, True]
    assert all([hasattr(e, 'message') for e in result.errors])


# Generated at 2022-06-20 15:38:58.608431
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-20 15:39:06.002136
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._valid_parameter_names == {'age', 'name'}
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None

argument_spec = {
    'name': {'type': 'str'},
    'age': {'type': 'int'},
}


# Generated at 2022-06-20 15:39:12.020216
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validation_result = ValidationResult(parameters)
    assert 'no_log' not in validation_result.validated_parameters
    assert validation_result.validated_parameters == parameters
    assert validation_result.error_messages == []
    assert validation_result.unsupported_parameters == set()


# Generated at 2022-06-20 15:39:15.554025
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(parameters={})
    assert vr.errors == AnsibleValidationErrorMultiple()
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == {}


# Generated at 2022-06-20 15:39:17.222611
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({'name': 'bo', 'age': '42'})


# Generated at 2022-06-20 15:39:27.618142
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:39:28.414088
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass



# Generated at 2022-06-20 15:39:42.619737
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import sys

    argumentspec = {
        'name': {'required': True, 'type': 'str'},
        'age': {'required': False, 'type': 'int'},
        'sex': {
            'required': True,
            'type': 'str',
            'choices': ['male', 'female']
        }
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'sex']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['sex']]]

# Generated at 2022-06-20 15:39:45.515617
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Arrange
    # Act
    Result = ArgumentSpecValidator.validate(ArgumentSpecValidator, {'name': {'type': 'str'}}, {'name': 'John'})
    # Assert
    assert Result.validated_parameters['name'] == 'John'

# Generated at 2022-06-20 15:39:56.649480
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils import common as module_common
    from ansible.module_utils.common import REMOVED_ARGUMENTS
    from ansible.module_utils.common.arg_spec import DeprecationParser
    from ansible.module_utils.common.text.docutils import ArgumentSpec
    from ansible.module_utils.six import string_types

    # test the most basic constructor
    module_common.ModuleArgumentSpec = ModuleArgumentSpecValidator
    module = module_common.AnsibleModule(argument_spec=dict(), no_log=True)
    assert isinstance(module.argument_spec, ArgumentSpec)
    assert module.supports_check_mode is True

    # test a valid argument_spec
    module_common.ModuleArgumentSpec = ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:40:06.420610
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.module import WHOLE_FILE_ARGUMENT_SPEC
    from ansible.module_utils.common.module import WHOLE_FILE_ARGUMENT_SPEC_NO_TRANSFORM

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    class MockAnsibleModule:
        def __init__(self, argument_spec_mock, no_log_values_mock):
            self.argument_spec = argument_spec_mock
            self.no_log_values = no_log_values_mock


# Generated at 2022-06-20 15:40:09.076796
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = dict(a=dict(type='str'))
    validator = ModuleArgumentSpecValidator(spec)
    assert validator.argument_spec is spec


# Generated at 2022-06-20 15:40:16.357188
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils.common.arg_spec import ValidationResult
    from ansible.module_utils.common.parameters import sanitize_keys

    # Create a dummy ArgumentSpecValidator
    argument_spec = {'name': {'type': 'str', 'no_log': True},
                     'age': {'type': 'int', 'aliases': ['years']},
                     'mood': {'type': 'str', 'default': 'happy', 'choices': ['happy', 'sad']},
                     'fruits': {'type': 'list', 'elements': 'str', 'default': ['apple', 'pear']},
                     }

    mutually_exclusive = [('name', 'age')]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    # Test alias

# Generated at 2022-06-20 15:40:19.481241
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create object
    validator = ModuleArgumentSpecValidator({})
    parameters = {}
    result = validator.validate(parameters)

#############
# END CLASS #
#############

# Generated at 2022-06-20 15:40:28.142838
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={'one': 'two', 'foo': 'bar'})
    assert result
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'foo': 'bar', 'one': 'two'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []
    assert result.validated_parameters == {'foo': 'bar', 'one': 'two'}
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:40:37.665158
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'pets': {
            'type': 'dict',
            'options': {
                'dog': {'type': 'bool'},
                'cat': {'type': 'int'},
            }
        },
        'nested': {
            'type': 'list',
            'element': {
                'type': 'dict',
                'options': {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                }
            }
        }
    }


# Generated at 2022-06-20 15:40:49.110485
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Test creation of ArgumentSpecValidator objects
    """

    # Valid argument_spec format
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)

    # Invalid argument_spec format
    argument_spec = {
        'name': {'typee': 'str'},
        'age': {'type': 'int'},
    }
    try:
        ArgumentSpecValidator(argument_spec)
        # Should not get here
        assert 0
    except TypeError:
        pass

    # TODO: Test for valid mutually_exclusive, required_together, required_one_of, required_if, required_by

# Generated at 2022-06-20 15:40:58.432249
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:41:09.934612
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name']
    required_together = [['age']]
    required_one_of = [['name']]
    required_if = [['name', 'foo', ['age']]]
    required_by = {'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive=mutually_exclusive,
                 required_together=required_together,
                 required_one_of=required_one_of,
                 required_if=required_if,
                 required_by=required_by,
                 )
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together

# Generated at 2022-06-20 15:41:15.711190
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({
        "name": {"type": "str", "aliases": ["nodes"]},
        "age": {"type": "int"},
    }, mutually_exclusive=[["name", "age"]])
    result = validator.validate({
        "nodes": "bo",
        "age": "42",
    })
    assert result.errors.messages == [
        "name and age are mutually exclusive"
    ]
    assert result.validated_parameters == {
        "name": "bo",
        "age": "42",
    }

# Generated at 2022-06-20 15:41:18.971015
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_args = [dict(), None, None, None, None, None]
    result = ModuleArgumentSpecValidator(*test_args)
    assert isinstance(result, ModuleArgumentSpecValidator)


# Generated at 2022-06-20 15:41:20.497258
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    with pytest.raises(TypeError):
        ModuleArgumentSpecValidator()



# Generated at 2022-06-20 15:41:22.777589
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    assert ValidationResult(parameters).validated_parameters == parameters

# Generated at 2022-06-20 15:41:26.533892
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:41:33.306987
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = ({
        'name': 'bo',
        'age': 42,
    })
    result = ValidationResult(parameters)
    assert len(result._warnings) == 0
    assert len(result._deprecations) == 0
    assert len(result._no_log_values) == 0
    assert len(result._unsupported_parameters) == 0
    assert result._validated_parameters == parameters
    assert len(result.errors) == 0



# Generated at 2022-06-20 15:41:44.937707
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = dict(
        argument_spec = dict(
            name = dict(
                type = 'str',
            ),
            age = dict(
                type = 'int',
            ),
        ),
        mutually_exclusive = [],
        required_together = [],
        required_one_of = [],
        required_if = [],
        required_by = dict(),
    )
    validator = ArgumentSpecValidator(**spec)
    assert validator._mutually_exclusive == spec['mutually_exclusive']
    assert validator._required_together == spec['required_together']
    assert validator._required_one_of == spec['required_one_of']
    assert validator._required_if == spec['required_if']
    assert validator._required_by == spec['required_by']
    assert validator.argument

# Generated at 2022-06-20 15:41:52.979956
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'a': {'type': 'int'}, 'b': {'type': 'dict'}}
    spec_validator = ArgumentSpecValidator(spec, required_together=[[['a', 'b']]])
    assert spec_validator._valid_parameter_names == {'a', 'b'}
    assert spec_validator.argument_spec == spec
    assert spec_validator._mutually_exclusive is None
    assert spec_validator._required_if is None
    assert spec_validator._required_together == [[['a', 'b']]]
    assert spec_validator._required_one_of is None
    assert spec_validator._required_by is None


# Generated at 2022-06-20 15:42:20.251720
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Create a new instance of ValidationResult
    vr = ValidationResult({'name': 'bob'})
    # Make sure it has the correct attributes
    assert isinstance(vr._no_log_values, set)
    assert isinstance(vr._unsupported_parameters, set)
    assert isinstance(vr._validated_parameters, dict)
    assert isinstance(vr._deprecations, list)
    assert isinstance(vr._warnings, list)
    assert isinstance(vr.errors, AnsibleValidationErrorMultiple)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == {'name': 'bob'}
    assert vr._deprecations == []
    assert vr._warnings == []

# Generated at 2022-06-20 15:42:26.450710
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v_results = ValidationResult({})
    assert v_results
    assert v_results._no_log_values == set()
    assert v_results._unsupported_parameters == set()
    assert v_results._deprecations == []
    assert v_results._warnings == []
    assert v_results.errors.messages == []
    assert v_results.validated_parameters == {}



# Generated at 2022-06-20 15:42:35.576558
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.parameters import ModuleParameters

    parameter_dict = {}
    module_params = ModuleParameters(argument_spec={}, supports_check_mode=False)
    argument_spec = module_params.argument_spec
    validator = ModuleArgumentSpecValidator(argument_spec=argument_spec,
                                            mutually_exclusive=module_params.mutually_exclusive,
                                            required_together=module_params.required_together,
                                            required_one_of=module_params.required_one_of,
                                            required_if=module_params.required_if,
                                            required_by=module_params.required_by)
    validator.validate(parameter_dict)

# Generated at 2022-06-20 15:42:43.134259
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # By using the method ArgumentSpecValidator._set_defaults,
    # this method also implicitly tests the method.
    validator = ArgumentSpecValidator({
        'name': {
            'type': 'str',
            'default': 'bob'
        },
        'age': {
            'type': 'int',
            'default': 30
        },
        'weight': {
            'required': False,
            'type': 'int'
        }
    })

    # Test empty dict
    parameters = {}
    result = validator.validate(parameters)
    assert result._validated_parameters == {'name': 'bob', 'age': 30}
    assert len(result.errors) == 0
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0
   

# Generated at 2022-06-20 15:42:46.192469
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult({"aa": "bb"})
    assert vr.validated_parameters == {"aa": "bb"}
    assert vr.error_messages == []
    assert vr.errors == []

# Generated at 2022-06-20 15:42:52.762777
# Unit test for constructor of class ValidationResult

# Generated at 2022-06-20 15:43:02.896327
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    _validator = ArgumentSpecValidator
    mutually_exclusive = [["name", "age"], ["name", "sex"]]
    required_if = [["name", "bo", ["age"]]]


# Generated at 2022-06-20 15:43:07.193036
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters



# Generated at 2022-06-20 15:43:13.201504
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'required' in result.error_messages[0]

# Generated at 2022-06-20 15:43:19.109760
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockTemplate(object):
        def __init__(self, template):
            if template == 'alias_warnings':
                self._template = """\
Your usage has both option {option} and its alias {alias}. This is not a supported usage and will be removed in a future release.\
"""
            elif template == 'deprecations':
                self._template = """\
Alias '{name}' is deprecated. See the module docs for more information\
"""
            else:
                raise Exception("test_ModuleArgumentSpecValidator_validate() is hardcoded to support only 2 templates")

        def format(self, **kwargs):
            for key in kwargs:
                self._template = self._template.replace("{" + key + "}", kwargs[key])

            self._template = self._template.lstrip()
           