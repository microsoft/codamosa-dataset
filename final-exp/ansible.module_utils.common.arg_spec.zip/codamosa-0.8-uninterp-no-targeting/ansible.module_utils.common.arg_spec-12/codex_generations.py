

# Generated at 2022-06-20 15:33:52.647979
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_spec = dict(
        name=dict(required=True),
        age=dict(required=False, type='int'),
        gender=dict(type='str', choices=['Male', 'Female']),
        aliases=dict(aliases=['aliases2', 'aliases3'], type='list'),
        additional_params=dict(type='dict', required=True, default=dict()),
        is_active=dict(type='bool'),
    )

    parameters = dict(
        name='bo',
        age='42',
        gender='Male',
        aliases='["alias1", "alias2", "alias3"]',
        additional_params='{"name": "bo", "age": "42"}',
        is_active=True,
    )

    validator = ModuleArgumentSpecValidator(module_spec)
   

# Generated at 2022-06-20 15:33:56.434148
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {'name': 'bo'}
    result = ValidationResult(parameter)
    assert result._validated_parameters == parameter
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:33:56.961286
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    pass

# Generated at 2022-06-20 15:34:02.162773
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common.arg_spec import ValidationResult
    parameters = {'a': 1, 'b': 2}
    result = ValidationResult(parameters)
    assert result.error_messages == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters

# Generated at 2022-06-20 15:34:14.923835
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Functionality test
    validator = ModuleArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=['a', 'b'],
        required_together=[['a', 'b']],
        required_one_of=[['a', 'b']],
        required_if=[['a', 'b', 'c']],
        required_by={'a': ['b']},
    )

    # Validity test
    validator.validate(parameters)

    # TypeError test

# Generated at 2022-06-20 15:34:24.398968
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = dict(
        name=dict(type='str', aliases=['full_name'], required=True),
        age=dict(type='int'),
    )

    required_if = [
        ['state', 'present', ['full_name']],
        ['state', 'absent', ['name']],
    ]

    mutually_exclusive = [
        ['foo', 'bar'],
        ['bam', 'baz'],
    ]

    results = ModuleArgumentSpecValidator(
        argument_spec,
        required_if=required_if,
        mutually_exclusive=mutually_exclusive,
    )

    assert results._mutually_exclusive == mutually_exclusive
    assert results._required_if == required_if



# Generated at 2022-06-20 15:34:27.687517
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argspec = dict(param1 = dict(type = 'str'))
    m = ModuleArgumentSpecValidator(argspec)
    assert m.argument_spec == argspec

# Generated at 2022-06-20 15:34:36.210043
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator as uut

    specs = {
        'args': {
            'options': {
                'type': 'str',
                'default': 'world',
                'deprecated': {
                    'version': '2.12',
                    'removed_in': '4.0',
                    'collection_name': 'test',
                },
            },
            'file': {
                'type': 'path',
                'required': True,
            },
        },
    }
    parameters = {
        'file': 'bar',
        'args': 'hello',
    }
    alias_warnings = []
    alias_deprecations = []

# Generated at 2022-06-20 15:34:49.361158
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator."""
    # Using ArgumentSpecValidator
    arg_spec_validator = ArgumentSpecValidator({'name': {'type': 'str'}})
    parameters = {'name': 'bobby'}
    result = arg_spec_validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bobby'}

    # Using ModuleArgumentSpecValidator
    module_arg_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    parameters = {'name': 'bobby'}
    result = module_arg_spec_validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bobby'}

# Generated at 2022-06-20 15:34:56.729331
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import os
    import json

    path = os.path.join(os.path.dirname(__file__), 'fixtures', 'argument_spec', 'validate_tests.json')
    with open(path, 'r') as fixture:
        tests = json.load(fixture)

    # Skip these test cases because nested specs are not yet implemented
    skip = set([
        'init.2',
        'init.3',
        'init.4',
        'init.5',
    ])

    for test in tests:
        if test in skip:
            continue
        test_args = tests[test]
        name = test_args.pop('name')
        spec_validator = ArgumentSpecValidator(**test_args)
        result = spec_validator.validate(test_args.get('parameters', {}))

# Generated at 2022-06-20 15:35:04.791912
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    v1 = ArgumentSpecValidator(argument_spec)
    v2 = ModuleArgumentSpecValidator(argument_spec)

    assert (v1.__class__ == ArgumentSpecValidator)
    assert (v2.__class__ == ModuleArgumentSpecValidator)

# Unit test to make sure that the deprecation found in alias is reported

# Generated at 2022-06-20 15:35:08.998098
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Arrange
    argument_spec = {
        'a_string': {'type': 'str'},
        'an_integer': {'type': 'int'},
        'a_float': {'type': 'float'},
        'a_boolean': {'type': 'bool'},
        'a_list': {'type': 'list'},
        'a_dict': {'type': 'dict'},
    }

    parameters = {
        'a_string': 'testing',
        'an_integer': '42',
        'a_float': 42.0,
        'a_boolean': True,
        'a_list': [1, 2, 3],
        'a_dict': {'foo': 'bar'}
    }

    mutually_exclusive = []

    required_together = []

   

# Generated at 2022-06-20 15:35:19.766663
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_bytes
    import sys

    #
    # Test case 1:
    #   Test if deprecation warning is printed when any key in argument_spec
    #   contains aliases attribute.
    #   Expected Result: deprecation warning is printed.
    #
    argument_spec = {
        'name': {
            'aliases': ['firstname', 'fname'],
            'type': 'str'
        }
    }
    parameters = {
        'name': 'John',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

   

# Generated at 2022-06-20 15:35:26.219962
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}}, mutually_exclusive=[], required_together=[], required_one_of=[], required_if=[], required_by={})
    parameters = {'name': 'bo', 'age': '42'}
    assert validator.validate(parameters) == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-20 15:35:36.088366
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from collections import namedtuple
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning, AnsibleCollectionDeprecationWarning, AnsibleUserWarning

    # Mocking methods warn and deprecate
    def warn(warning_msg): pass
    def deprecate(deprecation_msg, version=None, date=None, collection_name=None): pass
    # Mocking class AnsibleUserWarning
    AnsibleUserWarning = namedtuple('AnsibleUserWarning', ['message', 'name'])

    # Test with deprecation warning
    module_argument_spec_validator_deprecation = ModuleArgumentSpecValidator(argument_spec={})

# Generated at 2022-06-20 15:35:46.825228
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['foo', 'bar'],
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['age']]
    ]

    required_by = {
        'name': ['age'],
        'age': ['name'],
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)

    assert validator._mutually

# Generated at 2022-06-20 15:35:51.908755
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': 42}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:35:54.464400
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(argument_spec={'test': {'type': 'str'}})

# Generated at 2022-06-20 15:36:03.665871
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    class my_class(object):
        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None):
            self.argument_spec = argument_spec
            self.mutually_exclusive = mutually_exclusive
            self.required_together = required_together

    my_object = my_class({'a': {'type': 'int'}, 'b': {'type': 'str'}}, ['a','b'], [['a','b']])
    result_object = ArgumentSpecValidator(my_object.argument_spec, mutually_exclusive = my_object.mutually_exclusive, required_together = my_object.required_together)

    assert my_object != result_object
    assert result_object.argument_spec == my_object.argument_spec
    assert result_object._mutually_exclusive == my

# Generated at 2022-06-20 15:36:08.912274
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    temp_result = ValidationResult({'age': '42'})
    assert temp_result.validated_parameters == {'age': '42'}
    assert temp_result.unsupported_parameters == set()
    assert temp_result.error_messages == []
    assert isinstance(temp_result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:36:23.508758
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:36:26.626428
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:36:36.439350
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)


# Generated at 2022-06-20 15:36:41.988051
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test for constructor
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int', 'required': False}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == {'name': {'type': 'str'}, 'age': {'type': 'int', 'required': False}}
    return validator


# Generated at 2022-06-20 15:36:50.489797
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'return': {'type': 'str', 'required': False},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'return']
    ]

    required_together = [
        ['name', 'return']
    ]

    required_one_of = [
        ['name', 'return']
    ]

    required_if = [
        ['name', 'bo', ['age']]
    ]

    required_by = {
        'name': ['age', 'return']
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)


# Generated at 2022-06-20 15:37:00.761288
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.parameters import to_native
    import sys

    if 'PyPy' in sys.version:
        # pylint: disable=undefined-variable
        from ansible.module_utils.six import string_types
    else:
        # pylint: disable=import-error
        from six import string_types

    assert isinstance(ValidationResult(parameters={'a': 'b'}), MutableMapping)
    assert isinstance(to_native(ValidationResult(parameters={'a': 'b'})), string_types)
    # Assert that we have the attributes we expect

# Generated at 2022-06-20 15:37:08.878572
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:37:14.030965
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == set(['age', 'name'])
    assert validator.argument_spec == {'age': {'type': 'int'}, 'name': {'type': 'str'}}


# Generated at 2022-06-20 15:37:15.391595
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = ArgumentSpecValidator({"test": {"type": "str"}})
    assert spec.argument_spec == {"test": {"type": "str"}}

# Generated at 2022-06-20 15:37:25.095983
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Test with no parameters to validate
    validator = ArgumentSpecValidator({})
    result = validator.validate({})
    assert result.error_messages == []

    # Test with parameter type that is not supported
    validator = ArgumentSpecValidator({
        'param_1': {'type': 'int'}
    })
    result = validator.validate({'param_1': 'string'})
    assert len(result.error_messages) == 1
    assert "param_1" in result.error_messages[0]

    # Test with nested parameters
    validator = ArgumentSpecValidator({
        'param_1': {'type': 'dict',
                    'nested_param': {'type': 'str'}},
    })

# Generated at 2022-06-20 15:37:38.358214
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Test class ArgumentSpecValidator
    """

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'bo', ['age']]]
    required_by = {'name': ['age'], 'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

# Generated at 2022-06-20 15:37:43.027599
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'host': {'type': 'str'}}

    # Test that the constructor was called.
    # This test should be replaced by a mocking library
    try:
        ModuleArgumentSpecValidator(argument_spec)
    except:
        assert False

# Generated at 2022-06-20 15:37:48.889580
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "test": {
            "type": "str",
            "choices": ["test1", "test2", "test3"],
            "default": "test1",
            "required": False,
            "aliases": ['test_one'],
        },
    }
    test_obj = ArgumentSpecValidator(argument_spec)
    assert isinstance(test_obj, ArgumentSpecValidator)

# Generated at 2022-06-20 15:37:50.071346
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult('parameters')

# Generated at 2022-06-20 15:37:59.005488
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate in class ModuleArgumentSpecValidator.

    Validate that the deprecations and warnings lists are populated."""

    a_spec = {
        'x': {'type': 'str', 'aliases': ['foo']},
        'y': {'type': 'str', 'aliases': ['bar']},
        'z': {'type': 'str', 'removed_in_version': '2.13'},
        'z1': {'type': 'str', 'removed_in_version': '2.14'},
        'z2': {'type': 'str', 'removed_in_version': '2.15'},
    }


# Generated at 2022-06-20 15:38:04.016978
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {'type': 'dict'},
    }

    spec_validator = ArgumentSpecValidator(spec)

    assert isinstance(spec_validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:38:11.940163
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # pylint: disable=too-many-locals,too-many-branches
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.arg_spec import ArgumentSpec, AnsibleFailJson, AnsibleExitJson, AnsibleModule
    from ansible.module_utils.common.collections import is_sequence, Mapping
    from ansible.module_utils.common.validation import _validate_boolean, _validate_type_spec, _validate_identifier, _validate_sub_spec, _validate_argument_types, _validate_argument_values, _validate_sub_spec, _validate_no_log_values, _validate_one_of
    from ansible.module_utils.common.warnings import _warn_if_deprecated

# Generated at 2022-06-20 15:38:22.007180
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    class TestCase(object):
        def __init__(self, name, argument_spec, parameters, expected_result):
            self.name = name
            self.argument_spec = argument_spec
            self.parameters = parameters
            self.expected_result = expected_result

    tests = []

    # test with simple spec
    argument_spec = {'name': {'type': 'str', 'required': True}, 'age': {'type': 'int', 'default': 42}}
    parameters = {'name': 'bo', 'age': '42'}
    expected_result = {'name': 'bo', 'age': 42}
    test = TestCase('simple spec', argument_spec, parameters, expected_result)
    tests.append(test)

    # test with base spec (no nested spec)

# Generated at 2022-06-20 15:38:31.762056
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys, sanitize_values


# Generated at 2022-06-20 15:38:40.861195
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Tests for the ModuleArgumentSpecValidator class"""
    # pylint: disable=R0904
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleFilterDeprecationWarning


# Generated at 2022-06-20 15:38:47.221598
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    test_instance = ModuleArgumentSpecValidator({})
    test_instance.validate({'name': 'bo', 'age': '42'})

# Generated at 2022-06-20 15:38:47.990256
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-20 15:38:56.907430
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = {}
    mutually_exclusive = [["host", "hosts"], ["host", "name"]]
    required_together = [["host", "name"]]
    required_one_of = [["host", "name"]]
    required_if = [["state", "present", ["name"]]]
    required_by = {"state": ["name"]}
    validator = ArgumentSpecValidator(result, mutually_exclusive=mutually_exclusive, required_together=required_together,
                                      required_one_of=required_one_of, required_if=required_if, required_by=required_by)
    validator.validate(result)



# Generated at 2022-06-20 15:38:57.755378
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:39:03.370594
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive,
                                            required_together,
                                            required_one_of,
                                            required_if,
                                            required_by,
                                            )
    assert argument_spec == validator.argument_spec

# Generated at 2022-06-20 15:39:08.842743
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ansible_module_args = {'a': 'b', 'c': 'd'}
    argument_spec = {'a': {'required': True, 'type': 'str'}, 'c': {'required': False, 'type': 'str'}}
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(ansible_module_args)

# Generated at 2022-06-20 15:39:18.529182
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test the construction of ArgumentSpecValidator"""
    spec = {"required": {"type": "str"}}
    mutually_exclusive = [["required", "absent"]]
    together = [["required", "absent"]]
    required_if = [("required", "somevalue", ['absent'])]
    required_by = {"required": ["absent"]}

    validator = ArgumentSpecValidator(spec, mutually_exclusive, together, required_if=required_if, required_by=required_by)
    assert validator.argument_spec == {"required": {"type": "str"}}
    assert validator._mutually_exclusive == [['required', 'absent']]
    assert validator._required_together == [['required', 'absent']]

# Generated at 2022-06-20 15:39:20.712334
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator()
    except BaseException:
        assert False, "test_ModuleArgumentSpecValidator()"


# Generated at 2022-06-20 15:39:24.227105
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = dict(type=dict(type='int'))
    validator = ModuleArgumentSpecValidator(spec)
    assert validator.__class__.__name__ == 'ModuleArgumentSpecValidator'
    assert validator.__class__.mro() == \
    (validator.__class__, ArgumentSpecValidator, object)


# Generated at 2022-06-20 15:39:30.683228
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def _validate_sub_spec(self, spec, parameters, errors, no_log_values, unsupported_parameters):
            return

    test_argspec = {'test_param': {'type': 'str'}}

    test_input = {'test_param': 'test_value'}

    validator = FakeValidator(argument_spec=test_argspec)
    result = validator.validate(test_input)

    assert(result._validated_parameters == test_input)
    assert(result._warnings == [])
    assert(result._deprecations == [])
    assert(result.errors.messages == [])

# Generated at 2022-06-20 15:39:40.179776
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'a': {'type': 'str'}}, None, None, None, None, None)
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:39:48.308541
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'foo': {'type': 'str'},
        'boo': {'type': 'int'},
    }
    result = ValidationResult(parameters)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'foo': {'type': 'str'}, 'boo': {'type': 'int'}}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-20 15:39:59.973965
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # argument_spec = {
    #     'name': {'type': 'str'},
    #     'age': {'type': 'int'},
    # }
    #
    # parameters = {
    #     'name': 'bo',
    #     'age': '42',
    # }
    #
    # validator = ArgumentSpecValidator(argument_spec)
    # result = validator.validate(parameters)
    # print("error_messages:", result.error_messages)
    # print("validated_parameters:", result.validated_parameters)
    # print("error:", result.error)
    # print("errors:", result.errors)
    vr = ValidationResult({'name': 'bo', 'age': '42'})

# Generated at 2022-06-20 15:40:02.530383
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Create the object
    validator = ModuleArgumentSpecValidator(dict())
    # TODO: Verify that the object has been correctly initialized
    assert True == True

# Generated at 2022-06-20 15:40:04.493261
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'Bo', 'age': 42})
    assert result._validated_parameters == {'name': 'Bo', 'age': 42}


# Generated at 2022-06-20 15:40:13.113576
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    testcases = [
        {'arg': {}, 'expected': {}},
        {'arg': {'option': 'value'}, 'expected': {'option': 'value'}},
        {'arg': {'option1': 'value1', 'option2': 'value2'}, 'expected': {'option1': 'value1', 'option2': 'value2'}},
    ]

    for testcase in testcases:
        result = ValidationResult(testcase['arg'])
        assert result._validated_parameters == testcase['expected']
        assert result._warnings == []
        assert result._deprecations == []
        assert result.errors == AnsibleValidationErrorMultiple()
        assert result.error_messages == []


# Generated at 2022-06-20 15:40:24.418454
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = ('foo', 'bar')
    kwargs = {'baz': 'qux'}
    class TestException(Exception):
        pass

    def mock_set_fallbacks(argument_spec, parameters):
        return {}

    def mock_handle_aliases(argument_spec, parameters, warnings, deprecations):
        return {}

    def mock_get_legal_inputs(argument_spec, parameters, aliases):
        return {}

    def mock_list_no_log_values(argument_spec, parameters):
        return {}

    def mock_get_unsupported_parameters(argument_spec, parameters, legal_inputs):
        return set()

    def mock_check_mutually_exclusive(*args, **kwargs):
        raise TestException


# Generated at 2022-06-20 15:40:33.052582
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']
    required_together = [('name', 'age')]
    required_one_of = [('name', 'age')]
    required_if = [('name', '=', 'age')]
    required_by = {'name': ['age'], 'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by,
                                      )

    assert argument_spec

# Generated at 2022-06-20 15:40:37.349225
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator.validate(parameters).errors

# Generated at 2022-06-20 15:40:46.537079
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'arg': {'type': 'str', 'required': True}})

    valid_params = {'arg': 'required'}
    result = validator.validate({'arg': 'required'})
    assert result.validated_parameters == valid_params, "Passing valid argument does not pass"

    with pytest.raises(AnsibleValidationErrorMultiple) as excinfo:
        validator.validate({})

    assert excinfo.value.errors[0].msg == u"Missing required arguments: ['arg']", "Failing case yields expected error message"



# Generated at 2022-06-20 15:40:57.024406
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {
        'verbose': {
            'type': 'bool',
            'default': False,
            'aliases': ['v']
        }
    }

    assert ArgumentSpecValidator(arg_spec).validated_parameters == {'verbose': False}


# Generated at 2022-06-20 15:41:06.433588
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    assert ValidationResult(ImmutableDict()).validated_parameters == ImmutableDict()
    assert ValidationResult(ImmutableDict()).error_messages == []
    assert ValidationResult(ImmutableDict()).unsupported_parameters == set()

    # Note that the to_text call is to replicate the usage of this method in the
    # actual error. The error itself contains a str, not a unicode object.
    assert ValidationResult(ImmutableDict()).errors == AnsibleValidationErrorMultiple(to_text(AnsibleValidationErrorMultiple()))


# Generated at 2022-06-20 15:41:15.674082
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_required_arguments
    import sys
    import re
    import pytest
    sys.path.append('../')
    from ansible_collections.ansible.netcommon.plugins.modules.opennms.nodes import Node

    argument_spec = Node.argument_spec
    mock_params = {
        'host': 'localhost',
        'port': 8080,
        'user': 'admin',
        'password': 'admin',
        'action': 'create',
        'name': 'test_node',
        'foreignSource': 'test_source',
        'foreignId': 'test_node_id',
        'asset_fields': {'city': 'test_city'}
    }

    validator = ArgumentSpecValidator(argument_spec)
   

# Generated at 2022-06-20 15:41:22.988362
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    s = {'a': {'type': 'str'},
         'b': {'type': 'str'}}
    m = {'a': 'a1', 'b': 'b1'}

    validator = ArgumentSpecValidator(s)
    result = validator.validate(m)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    result.validated_parameters['a']

# Generated at 2022-06-20 15:41:25.456584
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == []


# Generated at 2022-06-20 15:41:28.991392
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator({'test': {'type': 'str'}})
    assert result is not None

test_ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:41:40.433263
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Ensure constructor construction of ModuleArgumentSpecValidator.

    The constructor of class ModuleArgumentSpecValidator should be the same as
    class ArgumentSpecValidator and there is no argument that is specific to
    the ModuleArgumentSpecValidator.
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # call constructor of class ModuleArgumentSpecValidator with no extra arguments
    validator1 = ModuleArgumentSpecValidator(argument_spec)
    # call constructor of class ArgumentSpecValidator with no extra arguments
    validator2 = ArgumentSpecValidator(argument_spec)

    assert(validator1.argument_spec == validator2.argument_spec)

# Generated at 2022-06-20 15:41:47.118306
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
            'argument_1': {'type': 'str'},
            'argument_2': {'type': 'int'}
        })
    result = validator.validate({'argument_1': 'hello world'})
    assert result.validated_parameters == {'argument_1': 'hello world'}
    assert result.errors == []
    assert result.error_messages == []
    assert result.unsupported_parameters == []

# Generated at 2022-06-20 15:41:55.631149
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['age']]
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_by = {
        'name': 'age'
    }


# Generated at 2022-06-20 15:42:00.047578
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {'name': 'bo', 'age': 42}
    result = ValidationResult(p)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)


# Generated at 2022-06-20 15:42:14.995422
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator, ValidationResults
    from ansible.module_utils.common.text.converters import to_native

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResults) is True
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:42:18.526363
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    args = {
        'argument_spec': '',
        'mutually_exclusive': None,
        'required_together': None,
        'required_one_of': None,
        'required_if': None,
        'required_by': None,
    }
    validator = ModuleArgumentSpecValidator(**args)
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:42:20.500809
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({}), ArgumentSpecValidator)

# Generated at 2022-06-20 15:42:31.540382
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-20 15:42:36.179758
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator(
        argument_spec, **{
            "argument1": "value1",
            "argument2": "value2",
        })
    result = module_argument_spec_validator.validate()
    # Assert that method validate returns the correct value
    assert result is instance(result, AnsibleValidationErrorMultiple)

# Generated at 2022-06-20 15:42:40.791347
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    validation_result = ValidationResult(parameters)

    assert validation_result._no_log_values == set()
    assert validation_result._validated_parameters == {'name': 'bo', 'age': '42'}
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.unsupported_parameters == set()



# Generated at 2022-06-20 15:42:50.571007
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:42:59.862418
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)


# Generated at 2022-06-20 15:43:01.791144
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    def function_body():
        try:
            result = ValidationResult(parameters=None)
        except Exception as e:
            print(e)
            assert False
        assert True

    function_body()
    assert True


# Generated at 2022-06-20 15:43:07.738731
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Positive test case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    assert not result.error_messages

    # Negative test case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]


# Generated at 2022-06-20 15:43:31.800184
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test of method validate of class ArgumentSpecValidator """

    valid_parameters_dict = {'name': 'bo', 'age': 42}
    argument_spec_dict = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator_obj = ArgumentSpecValidator(argument_spec_dict)

    validation_result_obj = validator_obj.validate(valid_parameters_dict)
    assert len(validation_result_obj.error_messages) == 0
    assert validation_result_obj.validated_parameters == valid_parameters_dict
    assert len(validation_result_obj.errors) == 0
    assert len(validation_result_obj.unsupported_parameters) == 0
    assert len(validation_result_obj._deprecations)

# Generated at 2022-06-20 15:43:39.747581
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters