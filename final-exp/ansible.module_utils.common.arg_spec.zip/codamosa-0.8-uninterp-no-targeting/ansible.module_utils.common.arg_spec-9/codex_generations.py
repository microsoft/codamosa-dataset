

# Generated at 2022-06-20 15:33:51.866391
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)


# Generated at 2022-06-20 15:33:58.257480
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert type(result.errors) is AnsibleValidationErrorMultiple
    assert len(result.errors) == 0
    assert type(result.validated_parameters) is dict
    assert len(result.validated_parameters) == 2
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:34:00.487790
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({})
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:34:07.191992
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    result = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                   required_one_of, required_if, required_by)
    assert(isinstance(result, ArgumentSpecValidator))



# Generated at 2022-06-20 15:34:19.474054
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    class ValidationTestModule:
        def __init__(self, tmpdir):
            self.tempdir = tmpdir

        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs

        def exit_json(self, *args, **kwargs):
            self.exit_json_args = args
            self.exit_json_kwargs = kwargs

        def set_fact(self, *args, **kwargs):
            self.set_fact_args = args
            self.set_fact_kwargs = kwargs

    import os
    import tempfile
    import pytest

    tmpdir = tempfile.mkdtemp()
    module = ValidationTestModule(tmpdir)

# Generated at 2022-06-20 15:34:26.891587
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'food': {'type': 'list', 'elements': 'str'},
        'state': {'type': 'str', 'choices': ['present', 'absent']},
        'owner': {'type': 'str', 'default': 'root', 'no_log': True},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['food', 'owner'],
    ]

    required_together = [
        ['name', 'age'],
        ['food', 'owner'],
    ]

    required_one_of = [
        ['name', 'age'],
        ['food', 'owner'],
    ]


# Generated at 2022-06-20 15:34:36.007056
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Validate that ArgumentSpecValidator.validate returns the expected type and value."""

    from ansible.module_utils.network.fortios.fortios import FortiOSHandler

    def option_factory(name, required=False, default=None, choices=None, type=str, aliases=None):
        return dict(name=name, required=required, default=default, choices=choices, type=type, aliases=aliases)


# Generated at 2022-06-20 15:34:49.056685
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a mock class for the required objects
    class AnsibleValidationErrorMultiple(object):
        messages = []
        def append(self, parameter, type=None, check=None):
            self.messages.append({"parameter":parameter, "type":type, "check":check})

    # Create a mock class for the required objects
    class ValidationResult(object):
        def __init__(self, parameters):
            self._no_log_values = set()
            self._validated_parameters = deepcopy(parameters)
            self._deprecations = []
            self._warnings = []
            self.errors = AnsibleValidationErrorMultiple()

        @property
        def validated_parameters(self):
            return self._validated_parameters

    # Create a mock class for the required objects

# Generated at 2022-06-20 15:34:53.689001
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'arg1': 'val1', 'arg2': 'val2'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.error_messages == []



# Generated at 2022-06-20 15:35:04.264276
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


if __name__ == "__main__":
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-20 15:35:11.455030
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator()


# Generated at 2022-06-20 15:35:20.880842
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    # Test constructor with different options
    argument_spec_1 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    required_together_1 = {("name", "age")}
    required_one_of_1 = [("name", "age")]
    mutually_exclusive_1 = [("name", "age")]
    required_if_1 = [("name", "age", ("name", "age"))]
    required_by_1 = {("name"): ["age"]}

    argument_spec_2 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    required_together_2 = []
    required_one_of_2 = []
    mutually_exclusive_2

# Generated at 2022-06-20 15:35:24.158010
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator({'foo':{'type':'int'}}, mutually_exclusive=[['foo']], required_together=[['foo']])
    assert result is not None


# Generated at 2022-06-20 15:35:35.073266
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with no errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

    # Test with an error
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 'not an int',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.valid

# Generated at 2022-06-20 15:35:36.023178
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:35:40.853897
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import pytest
    argument_spec = {'name': {'type': 'str', 'aliases': ['definition']}}
    validator = ArgumentSpecValidator(argument_spec)
    assert sorted(list(validator._valid_parameter_names)) == sorted(["name (definition)"])



# Generated at 2022-06-20 15:35:41.911594
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({}), ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:35:52.659372
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.warnings import Deprecation
    from ansible.module_utils.common.text.utils import to_text
    from ansible.module_utils.common.text.formatters import wrap_text
    from ansible.module_utils.common.collections import is_string
    from ansible.module_utils.common.parameters import ArgumentError
    from ansible.module_utils.common.text.converters import to_native

    argument_spec = {'test': {'type': 'str', 'required': True}}
    mutually_exclusive = []
    required_together = []
    required_one_of = []


# Generated at 2022-06-20 15:36:00.890129
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # test with no_log=False
    assert ArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int', 'default': 42},
            'pet': {'type': 'dict', 'default': {'type': 'dog', 'name': 'Barkley'}},
            'fruit': {'type': 'list', 'default': ['apple', 'banana']},
        },
        mutually_exclusive=[['name', 'age']]
    ).validate({'name': 'bo'}).validated_parameters == {'name': 'bo', 'age': 42, 'pet': {'type': 'dog', 'name': 'Barkley'}, 'fruit': ['apple', 'banana']}
    # test with no_log=True
    assert ArgumentSpecValid

# Generated at 2022-06-20 15:36:03.831714
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    assert ArgumentSpecValidator(
        argument_spec=dict(),
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={},
    )

# Generated at 2022-06-20 15:36:10.357859
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    asv = ArgumentSpecValidator({})
    assert isinstance(asv, ArgumentSpecValidator)
    assert asv.argument_spec == {}


# Generated at 2022-06-20 15:36:12.700449
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator(
        {'parameter_name': {'type': 'str'}}
    ).validate({'parameter_name': 'parameter_value'})

# Generated at 2022-06-20 15:36:23.779231
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Check that the deprecation is called
    def deprecate(message, version=None, date=None, collection_name=None):
        assert message == "Alias 'foo' is deprecated. See the module docs for more information"
        assert version == '2.9'
        assert date == '2022-06-01'
        assert collection_name == 'community.network'

    # Check that the warn message is displayed
    def warn(message):
        assert message == "Both option foo and its alias bar are set."

    from ansible.module_utils import common
    common.deprecate = deprecate
    common.warn = warn


# Generated at 2022-06-20 15:36:28.499862
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {'a': 'foo', 'b': 'bar'}
    v = ValidationResult(p)
    assert v._no_log_values == set()
    assert v._unsupported_parameters == set()
    assert v._deprecations == []
    assert v._warnings == []
    assert v._validated_parameters == p
    assert v.errors.messages == []


# Generated at 2022-06-20 15:36:39.329585
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import warnings
    import collections

    validator = ModuleArgumentSpecValidator({'p1': {'type': 'int', 'aliases': ['p2']}},
        mutually_exclusive=[['p1', 'p2'], ['p2', 'p2']], required_together=[['p1', 'p2'], ['p1', 'p1'], ['p2', 'p2']],
        required_one_of=[['p1', 'p2'], ['p1', 'p1'], ['p2', 'p2']], required_if=[['p1', 'p2', ['p1']]])

    from ansible.utils.display import Display
    display = Display()

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')

        result = validator.valid

# Generated at 2022-06-20 15:36:48.122653
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = {
        'name': {'type': 'str'},
        #'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params == parameters

# Generated at 2022-06-20 15:36:48.857682
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:36:59.587492
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'interests'],
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    invalid_params = {
        'name': 'bo',
        'age': '42',
        'interests': ['hacking', 'flying'],
    }

    # should fail on mutually exclusive
    result = validator.validate(invalid_params)
    assert isinstance(result.errors, list)
    assert result.error_messages == [u'name and age are mutually exclusive']

# Generated at 2022-06-20 15:37:05.967083
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator.argument_spec == argument_spec
    assert validator._valid_parameter_names == {'age', 'name'}


# Generated at 2022-06-20 15:37:09.531849
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert(result.unsupported_parameters == set())
    assert(result.error_messages == [])


# Generated at 2022-06-20 15:37:21.069145
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    test_parameters = {'name': 'bo', 'age': '42'}
    test_validator = ModuleArgumentSpecValidator(argument_spec=test_argument_spec)
    test_result = test_validator.validate(parameters=test_parameters)
    assert test_result._validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:37:26.430126
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initialize test arguments
    args = {'argument_spec': {'server': {'type': 'str'}, 'port': {'type': 'int'}}}
    args['mutually_exclusive'] = None
    args['required_together'] = None
    args['required_one_of'] = None
    args['required_if'] = None
    args['required_by'] = None

    # Test arguments for class ModuleArgumentSpecValidator
    module_args = {
        'server': 'localhost',
        'port': 55,
        'state': 'present'
    }

    # Expected output

# Generated at 2022-06-20 15:37:34.647141
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import sys

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-20 15:37:40.795699
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    p = {}
    assert not ArgumentSpecValidator({
        'one': {'type': 'int'},
        'two': {'type': 'list'},
        'three': {'type': 'dict'},
        'four': {'type': 'bool'},
        'five': {'type': 'str'},
    }).validate(p).errors



# Generated at 2022-06-20 15:37:46.018985
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_bytes
    # :arg argument_spec: Specification of valid parameters and their type. May
    #     include nested argument specs.
    # :type argument_spec: dict[str, dict]
    #
    # :kwarg mutually_exclusive: List or list of lists of terms that should not
    #     be provided together.
    # :type mutually_exclusive: list[str] or list[list[str]]
    #
    # :kwarg required_together: List of lists of terms that are required together.
    # :type required_together: list[list[str]]
    #
    # :kwarg required_one_of: List of lists of terms, one of which in each list
    #     is required.
    # :type required_one_of: list[list[str]]
   

# Generated at 2022-06-20 15:37:55.660778
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )
    mutually_exclusive = [
        ["name", "age"],
    ]
    required_together = [
        ["name", "age"],
    ]
    required_one_of = [
        ["name", "age"],
    ]
    required_if = [
        ["name", "bo", ["age"]],
    ]
    required_by = dict(
        name=["age"],
        age=["name"],
    )

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of,
                                      required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together

# Generated at 2022-06-20 15:38:03.559448
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def check_error(result, class_, message_start):
        assert result.errors
        assert isinstance(result.errors[0], class_)
        assert str(result.errors[0]).startswith(message_start)

    def check(argument_spec, parameters, expected_parameters=None,
              expected_error_class=None, expected_error_message_start=None):
        validator = ArgumentSpecValidator(argument_spec)
        result = validator.validate(parameters)
        if expected_parameters:
            assert result.validated_parameters == expected_parameters
        elif expected_error_class:
            check_error(result, expected_error_class, expected_error_message_start)
        else:
            assert not result.errors


# Generated at 2022-06-20 15:38:10.799409
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hosts': {'type': 'list'},
        'no_log': {'type': 'bool', 'no_log': True},
    }
    spec_validator = ArgumentSpecValidator(argument_spec)
    assert spec_validator._mutually_exclusive is None
    assert spec_validator._required_if is None
    assert spec_validator._required_by is None
    assert spec_validator._required_one_of is None
    assert spec_validator._required_together is None
    assert spec_validator.argument_spec == argument_spec


# Generated at 2022-06-20 15:38:21.284664
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:38:28.561419
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors.messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:38:36.039304
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module = ModuleArgumentSpecValidator(argument_spec={'a': {'type': 'str'}},
                                         mutually_exclusive=[],
                                         required_together=[],
                                         required_one_of=[],
                                         required_if=[],
                                         required_by={})
    assert module


# Generated at 2022-06-20 15:38:37.845644
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}})
    assert result is not None


# Generated at 2022-06-20 15:38:45.035824
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'a': 1})
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.validated_parameters == {'a': 1}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:38:56.356642
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Method validate of class ArgumentSpecValidator"""
    # Test with parameters
    validator = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}},
                                      mutually_exclusive=[['name', 'age']],
                                      required_together=None,
                                      required_one_of=None,
                                      required_if=None,
                                      required_by=None)
    result = validator.validate({'name': 'bo', 'age': 42})
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

    # Test without parameters
    result = validator.validate({})
    assert result.validated_parameters == {}
    assert result.error_messages == []

   

# Generated at 2022-06-20 15:39:00.082418
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    param = {'a': 1, 'b': 2}
    test_result = ValidationResult(param)
    assert test_result._validated_parameters == param
    assert test_result._no_log_values == set()
    assert test_result.error_messages == []


# Generated at 2022-06-20 15:39:05.210838
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    import mock
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple

    parameters = {'name': 'bo', 'age': 42}
    vr = ValidationResult(parameters)
    assert vr.validated_parameters == parameters
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr.errors == AnsibleValidationErrorMultiple()
    assert vr._deprecations == []
    assert vr._warnings == []



# Generated at 2022-06-20 15:39:09.975473
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
        'people': {'type': 'list',
                   'elements': 'dict',
                   'options': {'age': {'type': 'int'},
                               'name': {'type': 'str'}}},
        'money': {'type': 'dict',
                  'options': {'age': {'type': 'int'},
                              'name': {'type': 'str'}}},
    }

    mutually_exclusive = [['name', 'no_name']]

    required_together = [['name', 'age']]

    required_one_of = [['name', 'no_name']]

    required_if = [['name', 'true', ['age']]]



# Generated at 2022-06-20 15:39:17.318086
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'some_default': {'type': 'int', 'default': 42},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'some_default': '123',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42
    assert valid_params['some_default'] == 123

# Generated at 2022-06-20 15:39:20.278884
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # test the constructor to make sure it takes the parent's one and that
    # calling it doesn't raise an exception
    ModuleArgumentSpecValidator({"name": {"type": "str"}})


# Generated at 2022-06-20 15:39:20.813512
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = Argumen

# Generated at 2022-06-20 15:39:37.651058
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_spec_dict = {
        "test_param_01": {"type": "str", "default": "default_value_01"},
        "test_param_02": {"type": "str", "default": "default_value_02"},
        "test_param_03": {"type": "str", "default": "default_value_03"}
    }

    test_argument_spec = {
        "argument_spec": test_spec_dict
    }

    test_result = ModuleArgumentSpecValidator(**test_argument_spec)

    assert test_result.argument_spec == test_spec_dict

# Generated at 2022-06-20 15:39:47.193945
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # name is required and should not be empty.
    argument_spec = {
        "name": {"required": True, "type": "str"},
        "age": {"type": "int"},
    }
    # case 1 - name is not provided.
    parameters1 = {
        "age": "42",
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters1)

    assert result.error_messages == ['The name parameter is required and should not be empty.']

    # case 2 - name is provided by using alias.
    parameters2 = {
        "sc": "bo",
    }


# Generated at 2022-06-20 15:39:58.606406
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    warn = []
    deprecate = []
    check_mutually_exclusive = []
    check_required_arguments = []
    _validate_argument_types = []
    check_required_if = []
    check_required_by = []

    ModuleArgumentSpecValidator(['options'],
                                mutually_exclusive = check_mutually_exclusive,
                                required_together = check_required_arguments,
                                required_if = check_required_if,
                                required_by = check_required_by,
                                )


# Generated at 2022-06-20 15:40:00.901077
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # TODO:
    #   * _ADDITIONAL_CHECKS
    #   * the rest
    pass

# Generated at 2022-06-20 15:40:05.740918
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({}, mutually_exclusive=None, required_together=None,
                                            required_one_of=None, required_if=None, required_by=None)
    params = {}
    result = validator.validate(params)
    assert result.validated_parameters == {}
    assert result.error_messages == []

    result = validator.validate(None)
    assert result.validated_parameters == {}
    assert result.error_messages == []

# Generated at 2022-06-20 15:40:07.501551
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(dict(foo='bar'))



# Generated at 2022-06-20 15:40:09.053878
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(argument_spec={})
    assert not result.argument_spec

# Generated at 2022-06-20 15:40:15.702321
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive=[[]]
    required_together=[[]]
    required_one_of=[[]]
    required_if=[[]]
    required_by=[[]]
    argument_spec=[[]]
    test_obj = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert test_obj._required_together == [[]]
    assert test_obj._required_one_of == [[]]
    assert test_obj._required_by == [[]]
    assert test_obj._valid_parameter_names == set()
    assert test_obj.argument_spec == [[]]

# unit test for validate method of class ArgumentSpecValidator

# Generated at 2022-06-20 15:40:26.394484
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # The following lines are used to test the constructor

    # empty argument spec
    argument_spec = {}
    # no mutual exclusive,
    # no required_together,
    # no required_one_of,
    # no required_if,
    # no required_by
    validator1 = ModuleArgumentSpecValidator(argument_spec)

    # argument_spec should not be empty
    try:
        validator2 = ModuleArgumentSpecValidator()
    except TypeError:
        pass
    else:
        raise AssertionError('validator2 was initialized successfully')

    # A test of example

# Generated at 2022-06-20 15:40:34.941663
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [ ['name', 'age'] ]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate({'name': 'fred', 'age': 42})
    assert result.error_messages == ['got unexpected extra keywords: name, age']

    v2 = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=[[['name', 'age']]])
    result = v2.validate({'name': 'fred', 'age': 42})
    assert result.error_messages == ['got unexpected extra keywords: name, age']

    # make sure that validate is able to run against the subclass

# Generated at 2022-06-20 15:40:48.247960
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'kashish',
    }
    result = ValidationResult(parameters)
    assert (result._validated_parameters == parameters)


# Generated at 2022-06-20 15:40:55.826964
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"},
                     "age": {"type": "int"}}

    mutually_exclusive = [["name", "age"], ["name", "age"]]
    required_together = [["name", "age"], ["name", "age"]]
    required_one_of = [["name", "age"], ["name", "age"]]
    required_if = [["name", "age", ["name", "age"]]]
    required_by = {"name": ["age"], "age": ["name"]}


# Generated at 2022-06-20 15:40:56.791402
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-20 15:41:02.537081
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit tests for method validate of class ArgumentSpecValidator"""

    import pytest
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.parameters import _list_no_log_values, _set_defaults

    # Test a good argument_spec and parameters
    good_spec = {"name": {"type": "str", "required": True}}
    good_params = {"name": "bo"}
    good_validator = ArgumentSpecValidator(good_spec)
    good_result = good_validator.validate(good_params)
    assert 'AnsibleValidationErrorMultiple' not in str(type(good_result.errors))
    assert good_params == good_result.validated_parameters


# Generated at 2022-06-20 15:41:07.388152
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    return ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:41:16.238987
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(
        argument_spec={
            "arg1": {
                "type": "str",
                "aliases": ["abc"],
            }
        },
        mutually_exclusive=[['arg1', 'abc']],
        required_together=[['arg1', 'abc']],
        required_one_of=[['arg1', 'abc']],
        required_if=[['arg1', 'present', 'abc']],
        required_by={
            "arg1": ["abc"]
        },
        )
    assert am.argument_spec == {'arg1': {'type': 'str', 'aliases': ['abc']}}
    assert am.mutually_exclusive == [['arg1', 'abc']]

# Generated at 2022-06-20 15:41:18.884154
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator(dict(), dict(), dict(), dict(), dict(), dict()), ModuleArgumentSpecValidator)


# Generated at 2022-06-20 15:41:20.593000
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:41:23.523017
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator(argument_spec={},
                                    mutually_exclusive=[],
                                    required_together=[],
                                    required_one_of=[],
                                    required_if=[],
                                    required_by={})
    except TypeError as te:
        assert False, te

    assert True


# Generated at 2022-06-20 15:41:32.807592
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'sex': {'type': 'str', 'required': False}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'sex': 1
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == ['sex=1 is an invalid value']

# Generated at 2022-06-20 15:41:55.279394
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # pylint: disable=unused-argument
    def check(n, kwargs):
        if kwargs['parameters'][n] == 'b':
            return False
        return True

# Generated at 2022-06-20 15:41:55.809034
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-20 15:42:05.260854
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # This test will fail when AnsibleModule.run_command is changed to not throw
    # DeprecationWarning
    from ansible.module_utils.basic import AnsibleModule
    # import warnings
    # warnings.filterwarnings('error')


# Generated at 2022-06-20 15:42:12.867160
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
        "bank_account": {"type": "int"},
        "deposit": {"type": "int"},
    }
    mutually_exclusive = [
        ["bank_account", "deposit"],
    ]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive = mutually_exclusive)
    parameters = {"name": "bo", "age": "42", "bank_account": "123123123", "deposit": "123123123"}
    result = validator.validate(parameters)
    assert result.errors[0].msg == "Parameters are mutually exclusive: deposit, bank_account"

# Generated at 2022-06-20 15:42:13.464834
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult()
    return True


# Generated at 2022-06-20 15:42:13.879949
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:42:16.440366
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'x': 1})
    assert ValidationResult({'x': 1, 'y': 2})
    assert ValidationResult({'x': 1, 'y': [2,3,4], 'z': 3})



# Generated at 2022-06-20 15:42:26.721150
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def test_func(self, parameters):
        pass

    options = {'required': True, 'aliases': ['state']}

    spec = {'test': options}

    validator = ModuleArgumentSpecValidator(spec)

    params = {'test': 'absent'}
    result = validator.validate(params)
    assert result.validated_parameters['test'] == 'absent'
    assert result.warnings == []
    assert result.deprecations == []

    params = {'test': 'absent', 'state': 'absent'}
    result = validator.validate(params)
    assert result.validated_parameters['test'] == 'absent'
    assert result.warnings == [{'option': 'test', 'alias': 'state'}]
    assert result.deprecations

# Generated at 2022-06-20 15:42:33.616502
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    results = ValidationResult({})
    assert type(results._no_log_values) == set
    assert results._unsupported_parameters == set()
    assert results._validated_parameters == {}
    assert type(results._deprecations) == list
    assert type(results._warnings) == list
    assert type(results.errors) == AnsibleValidationErrorMultiple
    assert results.validated_parameters == {}
    assert results.unsupported_parameters == set()
    assert results.error_messages == []



# Generated at 2022-06-20 15:42:36.371683
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict(a=1)
    v = ValidationResult(parameters)
    assert v.validated_parameters == parameters
    assert not v.error_messages


# Generated at 2022-06-20 15:43:27.237105
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo'}
    validation_result = ValidationResult(parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == {'name': 'bo'}
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:43:34.565244
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec={
        'foo': {'type': 'str', 'default': 'bar'},
        'bar': {'type': 'int', 'required': True},
        'baz': {'type': 'list', 'required': True},
        'qux': {'type': 'list'}
    }
    mutually_exclusive = [['foo', 'bar'], ['baz', 'qux']]
    required_together = [['foo', 'bar'], ['baz', 'qux']]
    required_one_of = [['foo'], ['bar']]
    required_if = [('foo', 'bar', ['baz', 'qux'])]
    required_by = {'baz': ['qux']}

# Generated at 2022-06-20 15:43:44.727025
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    def test_func():
        pass
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }

    deprecations = []
    warnings = []

    parameters = {
        'age': '11',
        'name': 'bo',
    }

    # this is the validation function being tested
    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    assert len(result.error_messages) == 0, "no errors expected"
    assert result.validated_parameters == {'age': 11, 'name': 'bo'}, "validated parameters are not equal"
