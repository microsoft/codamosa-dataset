

# Generated at 2022-06-20 15:33:53.229023
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(parameters={'a':1,'b':2}).validated_parameters == {'a':1,'b':2}


# Generated at 2022-06-20 15:33:58.225617
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test passing no_log and no_log_value aliases
    argument_spec = {
        'stuff': {'type': 'bool'},
        'state': {'type': 'str'},
        'msg': {'type': 'str', 'aliases': ['notify', 'notify_message', 'changed_when']},
        'no_log': {'type': 'bool'},
        'no_log_value': {'type': 'str', 'aliases': ['no_log_values']},
        'other': {'type': 'str', 'required': True},
    }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []


# Generated at 2022-06-20 15:34:01.131606
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({'argument_spec':'test','mutually_exclusive':'test','required_together':'test','required_one_of':'test','required_if':'test','required_by':'test'})

# Generated at 2022-06-20 15:34:13.786047
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:34:15.426684
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'hello': 'world', 'foo': 'bar'}
    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:34:25.287099
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.dict_transformations import recursive_diff
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.parameters import check_mutually_exclusive as cme
    import re


# Generated at 2022-06-20 15:34:27.110426
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Call function validate of class ModuleArgumentSpecValidator
    """
    pass

# Generated at 2022-06-20 15:34:34.423535
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = dict(
        name=dict(),
        state=dict(default='present', choices=['present', 'absent']),
    )
    validator = ArgumentSpecValidator(spec)
    assert validator.argument_spec == spec
    assert validator._valid_parameter_names == {'state', 'name'}
    assert validator._mutually_exclusive == None
    assert validator._required_if == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_by == None


# Generated at 2022-06-20 15:34:47.394112
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    Unit test for constructor of class ArgumentSpecValidator.
    '''

    argument_spec = {
        "name": {"type": "str", "required": True},
        "age": {"type": "int"},
        "gender": {"type": "str", "choices": ["male", "female"]},
        "hobby": {"type": "list"}
    }

    mutually_exclusive = [
        ["name", "age"],
        ["name", "gender"],
        ["age", "gender"]
    ]

    required_together = [["name", "age"], ["age", "gender"]]

    required_one_of = [["name", "age"], ["age", "gender"]]


# Generated at 2022-06-20 15:34:50.766794
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'a': {'default': 1}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-20 15:35:03.787296
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    params = {'name': 'John', 'age': 42}
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(params)
    assert result.validated_parameters == params
    assert validator.argument_spec == spec
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors
    assert not result._unsupported_parameters
    assert not result._no_log_values

# Generated at 2022-06-20 15:35:07.906310
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {
        'key': {
            'type': 'int',
            },
    }

    result = ValidationResult(parameter)

    assert result.validated_parameters == parameter
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-20 15:35:16.997949
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Setup
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'},
                     'aliases': {'type': 'str'}, 'aliases_for_parameters': {'type': 'str'}}
    params = {'name': 'bo', 'age': '42', 'aliases': 'woo', 'aliases_for_parameters': 'woo woo'}
    m_validator = ModuleArgumentSpecValidator(argument_spec)

    # Execute
    result = m_validator.validate(params)

    # Assert
    assert result is not None

# Generated at 2022-06-20 15:35:28.251459
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from unittest.mock import Mock
    from ansible.module_utils import basic

    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule

    mymodule = basic.AnsibleModule({'ANSIBLE_MODULE_ARGS': '{"arg1":"value1","arg2":"value2"}'})
    mymodule.check_mode = False

    # Define module argument specs
    argument_spec = {
        'arg1': {'type': 'str'},
        'arg2': {'type': 'str', 'default': 'default2'},
    }

    # Define mutually exclusive arguments.
    mutually_exclusive = [
        ['arg1', 'arg2'],
        ['arg3', 'arg4']
    ]



# Generated at 2022-06-20 15:35:30.215292
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Constructor of class ModuleArgumentSpecValidator
    ModuleArgumentSpecValidator(argument_spec={
        'name': {
            'type': 'str'
        }
    }, mutually_exclusive=[], required_together=[],
                            required_one_of=[],
                            required_if=[], required_by={})
    return

# Generated at 2022-06-20 15:35:38.987509
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    spec = ArgumentSpec()

    validator = ArgumentSpecValidator(spec.argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert result.validated_parameters == {}

    parameters = {
        'name': 'bo',
        'age': '42',
        'demo': {
            'default_value': 'Test',
            'aliases': [
                'demo_alias'
            ]
        }
    }

    result = validator.validate(parameters)


# Generated at 2022-06-20 15:35:46.282657
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec1 = {'key1': {'type': 'str'},
                      'key2': {'type': 'int'},
                      'key3': {'type': 'list', 'elements': 'str'},
                      'key4': {'type': 'dict',
                               'options': {'key1': {'type': 'str'},
                                           'key2': {'type': 'int'}}}}

    mutually_exclusive = [['key1', 'key2']]
    required_together = [['key1', 'key2']]
    required_one_of = [['key1', 'key2']]
    required_if = [('key1', 'value1', ['key4'])]
    required_by = {'key4': ['key1']}


# Generated at 2022-06-20 15:35:56.754828
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit tests for constructor of class ModuleArgumentSpecValidator.

    Examples:
        >>> import arg_spec
        >>>
        >>> argument_spec = {'foo': {'type': 'str'}, 'bar': {'type': 'int'}}
        >>> module_argument_spec_validator = arg_spec.ModuleArgumentSpecValidator(argument_spec)
        >>>
        >>> # noinspection PyTypeChecker
        >>> isinstance(module_argument_spec_validator, arg_spec.ArgumentSpecValidator)
        True
        >>>
        >>> isinstance(module_argument_spec_validator, arg_spec.ModuleArgumentSpecValidator)
        True
        >>>
        >>> set(argument_spec) == set(module_argument_spec_validator.argument_spec)
        True
    """
    pass




# Generated at 2022-06-20 15:36:05.744773
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Validates that of a deprecated alias is used, a deprecation warning is thrown
    """
    validator = ModuleArgumentSpecValidator(arg_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['age_in_years']},
        'places': {'type': 'list'},
        'arg_type': {'type': 'bool', 'default': False},
    }, mutually_exclusive=(('name', 'age'), ))

    parameters = {
        'name': 'John',
        'age': 42,
        'places': ['home', 'work'],
        'arg_type': True,
    }

    result = validator.validate(parameters)
    assert result.error_messages == []

# Generated at 2022-06-20 15:36:16.988815
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    required_if = [('test_bool_param', False, ['test_required_if_param'])]
    required_by = {'test_required_by_param': ['test_bool_param']}
    mutually_exclusive = [['test_mutex_param_1', 'test_mutex_param_2']]
    required_together = [['test_req_together_1', 'test_req_together_2']]
    required_one_of = [['test_req_one_of_1', 'test_req_one_of_2']]


# Generated at 2022-06-20 15:36:37.704374
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # mock up some values
    argument_spec = {
        "mutually_exclusive": [],
        "required_together": [],
        "required_one_of": [],
        "required_if": [],
        "required_by": [],
    }

    # create an instance
    validator = ModuleArgumentSpecValidator(argument_spec)

    # assert that the instance is of the right type
    assert type(validator) is ModuleArgumentSpecValidator


# Generated at 2022-06-20 15:36:40.577049
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert "ModuleArgumentSpecValidator" == ModuleArgumentSpecValidator.__name__
    assert "AnsibleModule" in ModuleArgumentSpecValidator.__doc__

# Generated at 2022-06-20 15:36:49.470279
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name']]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    parameters = {
        'name': 'bo',
    }
    validator = ArgumentSpecValidator(argument_spec,mutually_exclusive=mutually_exclusive,required_together=required_together,
                                      required_one_of=required_one_of,required_if=required_if,required_by=required_by)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.unsupported_parameters == []
    assert result.validated_

# Generated at 2022-06-20 15:36:51.260905
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """This is a test function for ModuleArgumentSpecValidator __init__"""
    assert ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:37:01.277817
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import validate_ip_address


# Generated at 2022-06-20 15:37:09.278211
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                    }
    mutually_exclusive = ['age']
    required_together = ['age']
    required_one_of = [('age', 'name')]
    required_if = ['age', 'name']
    required_by = {'age': ['name', 'last_name']}
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by)

# Generated at 2022-06-20 15:37:15.024829
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    #case 1: argument_spec contains no aliases.
    argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }

    module_arguments_spec = ModuleArgumentSpecValidator(argument_spec)
    assert module_arguments_spec.argument_spec == argument_spec
    assert module_arguments_spec._mutually_exclusive is None
    assert module_arguments_spec._required_together is None
    assert module_arguments_spec._required_one_of is None
    assert module_arguments_spec._required_if is None
    assert module_arguments_spec._required_by is None
    assert module_arguments_spec._valid_parameter_names == {'name', 'age'}

    #case 2: argument_spec contains aliases

# Generated at 2022-06-20 15:37:24.842986
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test constructor of class ArgumentSpecValidator"""
    # empty argument_spec
    argument_spec = {}
    # if mutually_exclusive is None
    mutually_exclusive = None
    # if required_together is None
    required_together = None
    # if required_one_of is None
    required_one_of = None
    # if required_if is None
    required_if = None
    # if required_by is None
    required_by = None
    # Call constructor
    try:
        validator = ArgumentSpecValidator(argument_spec,
                                          mutually_exclusive,
                                          required_together,
                                          required_one_of,
                                          required_if,
                                          required_by,
                                          )
    except ValueError:
        pass

    # non empty argument_spec
    argument

# Generated at 2022-06-20 15:37:32.028182
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'age': 42, 'name': 'bo'}
    assert result.error_messages == []

# Generated at 2022-06-20 15:37:43.929819
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:37:58.897116
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # Writing a unit test for the constructor
    def test_constructor(mock_arg_spec, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None):
        instance = ModuleArgumentSpecValidator(mock_arg_spec,mutually_exclusive,required_together,required_one_of,required_if,required_by)

        # checking if instance is created correctly
        assert instance._mutually_exclusive == mutually_exclusive
        assert instance._required_together == required_together
        assert instance._required_one_of == required_one_of
        assert instance._required_if == required_if
        assert instance._required_by == required_by
        assert instance.argument_spec == mock_arg_spec

# Generated at 2022-06-20 15:38:07.763735
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})
    assert ArgumentSpecValidator({}, mutually_exclusive=[])
    assert ArgumentSpecValidator({}, required_together=[])
    assert ArgumentSpecValidator({}, required_one_of=[])
    assert ArgumentSpecValidator({}, required_if=[])
    assert ArgumentSpecValidator({}, required_by={})
    assert ArgumentSpecValidator({'a': {'type': 'str'}}, mutually_exclusive=[])
    assert ArgumentSpecValidator({'a': {'type': 'str'}}, required_together=[])
    assert ArgumentSpecValidator({'a': {'type': 'str'}}, required_one_of=[])
    assert ArgumentSpecValidator({'a': {'type': 'str'}}, required_if=[])

# Generated at 2022-06-20 15:38:11.767149
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-20 15:38:21.901200
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}}, required_by={'name': []}, required_together=[])

    valid_parameters = {'name': 'bo'}
    validated_parameters = spec_validator.validate(valid_parameters)
    assert len(validated_parameters.error_messages) == 0
    validated_parameters = validated_parameters.validated_parameters
    assert validated_parameters['name'] == 'bo'

    invalid_parameters = {'name': 3}
    validated_parameters = spec_validator.validate(invalid_parameters)
    assert len(validated_parameters.error_messages) == 1

# Generated at 2022-06-20 15:38:31.654025
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:38:38.232624
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Create a result object with a set of parameters ready to be validated
    parameters = {
        'module_name': {
            'required': True,
            'type': 'str'
        },
    }

    result = ValidationResult(parameters)

    # Check if the attributes are empty as expected
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-20 15:38:42.577632
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({"name": {"default": "bo"}})
    # return an AnsibleValidationErrorMultiple() object.
    result = v.validate({})

    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-20 15:38:52.731149
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    my_argument_spec = {
        'foo': {'required': True, 'type': 'str'}
    }
    my_mutually_exclusive = [['foo']]
    my_required_together = [['foo']]
    my_required_one_of = [['foo']]
    my_required_if = [['foo', 'bar', ['baz']]]
    my_required_by = {'foo': ['baz']}

# Generated at 2022-06-20 15:39:02.366815
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'friend_ages': {'type': 'list', 'elements': 'int'}
    }

    group = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-20 15:39:10.220636
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult) is True
    assert result.error_messages == []



# Generated at 2022-06-20 15:39:24.623847
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Invalid parameters
    assert 'foo' in ValidationResult({'foo': 'bar'}).validated_parameters.keys()


# Generated at 2022-06-20 15:39:30.372493
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import pytest
    mav = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None,
                                      required_one_of=None, required_by=None, required_if=None)
    assert mav.argument_spec == {}


# Generated at 2022-06-20 15:39:37.586465
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.unsupported_parameters == set()

# Generated at 2022-06-20 15:39:38.235318
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-20 15:39:43.479670
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo'})

    assert isinstance(result, ValidationResult), "Expected ValidationResult, got {0}".format(type(result))
    assert result.validated_parameters == {'name': 'bo'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:39:47.848966
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert not ValidationResult(dict())._deprecations
    assert not ValidationResult(dict())._warnings
    assert not ValidationResult(dict())._unsupported_parameters
    assert not ValidationResult(dict())._validated_parameters
    assert not ValidationResult(dict())._no_log_values
    assert not ValidationResult(dict()).error_messages


# Generated at 2022-06-20 15:39:52.407527
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    val = ModuleArgumentSpecValidator(argument_spec={},
                                      mutually_exclusive={},
                                      required_together={},
                                      required_one_of={},
                                      required_if={},
                                      required_by={})

    assert isinstance(val, ModuleArgumentSpecValidator)


# Generated at 2022-06-20 15:39:58.024268
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'loves': {
            'type': 'list',
            'elements': 'str',
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    assert result.error_messages == []



# Generated at 2022-06-20 15:40:02.703008
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    PARAM_SPEC = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(PARAM_SPEC)

    assert validator.argument_spec == PARAM_SPEC

# Generated at 2022-06-20 15:40:08.235127
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        "name": "bo",
        "age": 42
    }

    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._warnings == []
    assert result._deprecations == []
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-20 15:40:27.978596
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:40:31.563770
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # tests for creation of ModuleArgumentSpecValidator instance
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:40:34.798970
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    module_validator = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    assert module_validator.argument_spec == argument_spec



# Generated at 2022-06-20 15:40:41.986078
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'age': '42'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == {'age': '42'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {'age': '42'}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:40:52.113974
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters_dic = {'a': 1, 'b': 'string'}
    result = ValidationResult(parameters_dic)
    assert result._no_log_values == set(), \
        "Expected empty set of no_log_values but found {}.".format(result._no_log_values)
    assert result._unsupported_parameters == set(), \
        "Expected empty set of unsupported_parameters but found {}.".format(result._unsupported_parameters)
    assert result._validated_parameters == parameters_dic, \
        "Expected parameters {expected} but found {found}.".format(expected=parameters_dic,
                                                                   found=result._validated_parameters)

# Generated at 2022-06-20 15:40:54.056525
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit test to construct an instance of class ModuleArgumentSpecValidator."""
    module_argument_spec = ModuleArgumentSpecValidator(argument_spec={})
    assert module_argument_spec



# Generated at 2022-06-20 15:40:56.250355
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Test constructor of class ModuleArgumentSpecValidator
    """
    arguments = dict()
    ModuleArgumentSpecValidator(arguments)

# Generated at 2022-06-20 15:41:02.198069
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test the constructor of the :class:`ModuleArgumentSpecValidator` class."""
    from ansible.module_utils.common.text.converters import to_text

    # Test simple argument spec with required parameter
    argument_spec = dict(
        parameter=dict(required=True)
    )

    validator = ModuleArgumentSpecValidator(argument_spec)

    # Test module input is validated and parameter is required
    parameters = dict()
    validated_params = validator.validate(parameters)
    assert validated_params.error_messages == [u"required field missing: ['parameter']"]

    # Test simple argument spec with no required parameters
    argument_spec = dict(
        parameter=dict(required=False)
    )

    validator = ModuleArgumentSpecValidator(argument_spec)

    # Test module

# Generated at 2022-06-20 15:41:09.186382
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    
    argument_spec = { 'b': {'type': 'bool', 'required': True}, 'a': {'type': 'int'}, 'c': {'type': 'list'} }
    parameters = { 'a': 1 }
    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)
    assert result.validated_parameters == parameters
    assert len(result.errors) == 1
    assert result.errors[0].message == "The required arguments ['b'] were not provided."

# Generated at 2022-06-20 15:41:12.486760
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'parameter1': 'value', 'parameter2': 'value2'}
    val = ValidationResult(parameters)
    assert val.validated_parameters == parameters
    assert val.unsupported_parameters == set()
    assert isinstance(val.errors, AnsibleValidationErrorMultiple)
    assert val.errors.messages == []
    assert val.error_messages == []

# Generated at 2022-06-20 15:41:47.908666
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age", ["name", "age"]]]
    required_by = {
        "name": ["age"],
        "age": ["age"],
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

# Generated at 2022-06-20 15:41:56.255260
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test simple dict
    expected = {'key': 'value'}
    result = ValidationResult(expected)
    assert result._validated_parameters == expected
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._warnings == []
    assert result._deprecations == []
    # test nested dict
    expected = {'key': {'key2': {'key3': 'value'}}}
    result = ValidationResult(expected)
    assert result._validated_parameters == expected
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._warnings == []
   

# Generated at 2022-06-20 15:41:57.176137
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:41:57.871906
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-20 15:42:01.042616
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator("argument_spec", "required_by", "required_if", "required_one_of", "required_together", "mutually_exclusive")
    # Expected no exception to be thrown.


# Generated at 2022-06-20 15:42:10.116770
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Function to unit test ArgumentSpecValidator"""
    argument_spec = {"a": {"type": "int", "required": True, "no_log": False},
                     "c": {"type": "bool", "no_log": True},
                     "b": {"type": "list", "elements": 'str', "required": True, "no_log": True},
                     "d": {"type": "dict", "required": True, "no_log": False},
                     "e": {"type": "dict", "required": True, "no_log": True},
                     "f": {"type": "int", "required": True, "no_log": False, "default": 10}}

    mutually_exclusive = [['a', 'b'], ['c', 'b'], ['d', 'e']]

# Generated at 2022-06-20 15:42:17.006765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name'], 'required': True},
        'age': {'type': 'int', 'aliases': ['age', 'years']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }


# Generated at 2022-06-20 15:42:22.116648
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'hello': 'world'})
    assert result
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'hello': 'world'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-20 15:42:31.544330
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliased': {'type': 'str', 'aliases': ['aliased2']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'aliased': '1',
        'aliased2': '2',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'age': 42, 'name': 'bo', 'aliased': '2'}

# Generated at 2022-06-20 15:42:33.093091
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(dict())
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:43:08.649602
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import logging
    logger = logging.getLogger()
    logger.disabled = True
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.parameters import DEFAULT_VALIDATION_TYPE
    module_args = dict(
        name=dict(required=True),
        debug=dict(type='bool', aliases=['output']),
        debug2=dict(type='bool', default=False),
        date=dict(type='datetime', default='2019-01-01'),
        debug3=dict(type='bool', no_log=True, default=False),
    )
    module = AnsibleModule(argument_spec=module_args, no_log=True)
    validator = ModuleArgumentSpecValidator(module_args)

# Generated at 2022-06-20 15:43:13.532154
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
            'default': 'default name'
        },
        'age': {
            'type': 'int',
            'default': 'default age'
        }
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate({})

# Generated at 2022-06-20 15:43:18.767359
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for proper exception handling
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True}}
    validator = ArgumentSpecValidator(argument_spec)
    p1 = {'name': 'bo', 'age': '42'}
    result = validator.validate(p1)
    assert result.errors, "Validation failure expected for type mismatch"
    p2 = {'name': 'bo', 'age': 42}
    result = validator.validate(p2)
    assert not result.errors, "Validation failure not expected"
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:43:25.955914
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['foobar']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'foobar': 'baz',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'age': 42, 'name': 'baz'}
    assert result.error_messages == []

# Generated at 2022-06-20 15:43:29.871594
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'a': 1}
    validation_result = ValidationResult(parameters)
    assert validation_result.validated_parameters == parameters
    assert validation_result.error_messages == []
    assert validation_result.unsupported_parameters == set()


# Generated at 2022-06-20 15:43:30.733295
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:43:40.781331
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''Unit test for the ArgumentSpecValidator() class.

    NOTE: This test cases are written for the static code analysis tool pylint.
    The code style should not be changed to something that does not match
    "PyLint >=2.0".
    '''

    # pylint: disable=unused-argument
    class ArgumentSpecValidatorTest(object):
        '''ArgumentSpecValidator tests class'''

        @staticmethod
        def test_init():
            '''ArgumentSpecValidator __init__ test case'''
            spec = dict()

            # Define abstract test cases