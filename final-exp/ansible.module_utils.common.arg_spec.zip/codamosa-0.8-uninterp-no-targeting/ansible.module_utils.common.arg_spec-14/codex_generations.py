

# Generated at 2022-06-20 15:33:54.439626
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    params = {'ip_address': '192.168.0.1'}
    expected_result = {'ip_address': '192.168.0.1'}
    specification = {'ip_address': {'type': 'str'}}

    validator = ArgumentSpecValidator(specification)
    result = validator.validate(params)

    assert result.validated_parameters == expected_result

# Generated at 2022-06-20 15:34:05.266460
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult({'name': 'ansible', 'loves': 'python'})
    assert isinstance(v, ValidationResult)
    assert isinstance(v.errors, AnsibleValidationErrorMultiple)
    assert not v.errors
    assert v._no_log_values == set()
    assert v._unsupported_parameters == set()
    assert v._validated_parameters == {'name': 'ansible', 'loves': 'python'}
    assert v._deprecations == []
    assert v._warnings == []

    assert v.validated_parameters == {'name': 'ansible', 'loves': 'python'}
    assert v.unsupported_parameters == set()
    assert v.error_messages == []


# Generated at 2022-06-20 15:34:10.505289
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'param_1': {'value': 1},
                  'param_2': {'value': 2},
                  }
    result = ValidationResult(parameters)

    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:34:22.987674
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # success
    asv = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })
    result = asv.validate({
        'name': 'bo',
        'age': '42'
    })
    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42
    }

    # success - with unsupported parameters
    asv = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

# Generated at 2022-06-20 15:34:34.218314
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_exclusive
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import sys

    # define spec and validate non aliased options

# Generated at 2022-06-20 15:34:40.597365
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'foo': {'type': 'str'}})
    validated = validator.validate({'foo': 'bar'})

    assert validated == {'foo': 'bar'}
    assert validated.error_messages == []
    assert validated.deprecations == []
    assert validated.warnings == []

# Generated at 2022-06-20 15:34:47.265076
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'num': {'type': 'int'},
        'dic': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'num': {'type': 'int'},
            },
            'allow_unknown': True,
        },
        'list': {
            'type': 'list',
            'elements': {
                'type': 'dict',
                'options': {
                    'name': {'type': 'str'},
                    'num': {'type': 'int'},
                },
                'allow_unknown': True,
            },
        },
    }


# Generated at 2022-06-20 15:34:51.274773
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)

    assert result._validated_parameters == parameters
    assert result.error_messages == []
    assert result.validated_parameters == parameters



# Generated at 2022-06-20 15:34:54.225988
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    instance = ValidationResult({})
    assert isinstance(instance, ValidationResult)
    assert instance.errors is not None
    assert instance._no_log_values is not None
    assert instance._unsupported_parameters is not None
    assert instance.validated_parameters is not None

# Generated at 2022-06-20 15:35:03.735454
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_ValidationResult_parameters = {
        'test': {
            'required': True,
            'type': 'list'
        }
    }
    my_ValidationResult = ValidationResult(test_ValidationResult_parameters)
    assert my_ValidationResult.validated_parameters == test_ValidationResult_parameters
    assert my_ValidationResult._validated_parameters == test_ValidationResult_parameters
    assert my_ValidationResult._unsupported_parameters == set()
    assert my_ValidationResult._no_log_values == set()


# Generated at 2022-06-20 15:35:15.823204
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    assert isinstance(ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by), ArgumentSpecValidator)


# Generated at 2022-06-20 15:35:24.719411
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    def test_1():
        return ArgumentSpecValidator(
            argument_spec={'test1': {'type': 'str'}},
            mutually_exclusive=[['test1', 'test2']],
            required_together=[['test1', 'test2']],
            required_one_of=[['test1', 'test2']],
            required_if=[['test1', 'test2', ['test3', 'test4']]],
            required_by={'test1': ['test2', 'test3']}
        )

    def test_2():
        return ArgumentSpecValidator(
            argument_spec={'test1': {'type': 'str'}}
        )

    tests = (
        (test_1,),
        (test_2,)
    )


# Generated at 2022-06-20 15:35:32.496628
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)



# Generated at 2022-06-20 15:35:35.571227
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'foo': {'type': 'str'}})
    parameters = {'foo': 'bar'}
    result = validator.validate(parameters)
    assert result.validated_parameters['foo'] == 'bar'

# Generated at 2022-06-20 15:35:41.580856
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"parameter": "value"}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert len(result._deprecations) == 0
    assert len(result._no_log_values) == 0
    assert len(result._unsupported_parameters) == 0
    assert len(result._warnings) == 0
    assert len(result.errors) == 0

# Generated at 2022-06-20 15:35:42.598734
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator is not None

# Generated at 2022-06-20 15:35:52.007305
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    1. Make sure that the super-class is called correctly
    """
    # Prepare test data
    argument_spec = {'test': {'type': 'str'}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    # Create the object and call the test method
    try:
        test = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    except AssertionError as e:
        assert False, "Instantiation of ModuleArgumentSpecValidator failed with message: %s" % e.args[0]

# Generated at 2022-06-20 15:36:01.803967
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import get_nested_spec
    parameter_spec = {
        'nested': get_nested_spec(),
    }

# Generated at 2022-06-20 15:36:03.374422
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(parameters= {'name' : 'bo', 'age': '42'} )

# Generated at 2022-06-20 15:36:09.910073
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"a": 7, "b": 3}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:36:24.836660
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:36:29.682348
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test ValidationResult class constructor
    """
    result1 = ValidationResult(dict(name='bo', age='42'))
    result2 = ValidationResult({'name': 'bo', 'age': '42'})
    expected_result = dict(name='bo', age='42')
    assert result1.validated_parameters == expected_result
    assert result2.validated_parameters == expected_result
    return


# Generated at 2022-06-20 15:36:37.542209
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator=ModuleArgumentSpecValidator({'option1': {'type': 'str'},
                            'option2': {'type': 'str'}},
                                   mutually_exclusive=[[['option1', 'option2']]],
                                   required_one_of=[['option1']],
                                   required_by={'option1': ['option2']})

    parameters = {'option1': 'hello',
                'option2': 'hi'}

    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-20 15:36:48.184572
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import make_default_argspec

    validator = ArgumentSpecValidator(make_default_argspec())

# Generated at 2022-06-20 15:36:58.038834
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    except ImportError as e:
        print(e)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    valid_params = result.validated_parameters

if __name__ == "__main__":
    # Unit test
    test_ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:37:02.469552
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}}
    parameters = {'name': 'bo'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters
    assert result.error_messages == []


# Generated at 2022-06-20 15:37:11.758635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    #validate method of ModuleArgumentSpecValidator, test
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    def mock_deprecated(msg, version=None, date=None, collection_name=None):
        pass
    def mock_warn(msg):
        pass
    def mock_warnings():
        pass
    def mock_to_native(value):
        return value
    def mock_AnsibleValidationErrorMultiple():
        return AnsibleValidationErrorMultiple()
    def mock_ArgumentSpecValidator_validate(self, options):
        return ValidationResult(options)
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    argument_spec_validator = ModuleArgumentSpecValid

# Generated at 2022-06-20 15:37:17.366469
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import get_validated_arguments

    def test_deprecations():
        fail_deprecations = []

        def check_deprecation(msg, *args, **kwargs):
            fail_deprecations.append(msg)

        # Fail if check_deprecation is called by check_valid_arguments_or_fail
        with mock.patch('ansible.module_utils.common.arg_spec.deprecate', check_deprecation):
            # Here we use ansible.module_utils.local_ansible_facts to get a spec that contains a deprecation
            spec = get_validated_arguments(local_ansible_facts.argument_spec, mock.MagicMock())

# Generated at 2022-06-20 15:37:23.325765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for method validate of class ModuleArgumentSpecValidator."""

    mutually_exclusive = [['aaa', 'bbb']]
    required_together = [('aaa', 'bbb')]
    required_one_of = [['aaa', 'bbb']]
    required_if = [['aaa', 'yes', ['bbb']]]
    required_by = {'aaa': ['bbb']}
    argument_spec = {
        'aaa': {'type': 'str', 'default': None},
        'bbb': {'type': 'str', 'default': None},
        'ccc': {'type': 'str', 'default': None, 'required': True}
    }


# Generated at 2022-06-20 15:37:34.889815
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockDeprecate(object):
        def __init__(self, obj):
            self.obj = obj

        def __call__(self, msg, version=None, date=None, collection_name=None):
            self.obj.deprecate_method_msg = msg

    class MockWarn(object):
        def __init__(self, obj):
            self.obj = obj

        def __call__(self, msg):
            self.obj.warn_method_msg = msg

    class TestClass(object):
        def __init__(self):
            self.deprecate_method_msg = None
            self.warn_method_msg = None


# Generated at 2022-06-20 15:37:45.130862
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not len(result.errors)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:37:54.869362
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 0
    assert result.validated_parameters.get('name') == 'bo'
    assert result.validated_parameters.get('age') == 42

    parameters = {
        'name': 'bo 1',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 0

# Generated at 2022-06-20 15:37:56.344865
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result._validated_parameters == {}



# Generated at 2022-06-20 15:38:06.456371
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['name']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-20 15:38:11.618847
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = { "name": {"type": "str"} }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate({"name": "bo"})

    assert result.validated_parameters == {"name": "bo"}
    assert result.errors == []
    assert result.warnings == []
    assert result.deprecations == []

# Generated at 2022-06-20 15:38:15.465061
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'zhaowei', 'age': 19})
    assert result._validated_parameters == {'name': 'zhaowei', 'age': 19}
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:38:19.476002
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    class_to_test = ModuleArgumentSpecValidator
    class_to_test({'name': {'type': 'str'}, 'age': {'type': 'int'}},
                  mutually_exclusive=[
                      ['name', 'age']
                  ])

# Generated at 2022-06-20 15:38:28.645265
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['nickname', 'alias']
        }
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator._valid_parameter_names == {'name (alias, nickname)'}

    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': {
                'alias': None,
                'nickname': None
            }
        }
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator._valid_parameter_names == {'name (alias, nickname)'}

# Generated at 2022-06-20 15:38:35.536580
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['age']
    requires_together = [['name', 'age']]
    requires_one_of = [['name', 'age']]
    requires_if = [['age', 1, ['name', 'age']]]
    requires_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive, required_together=requires_together,
                                      required_one_of=requires_one_of, required_if=requires_if, required_by=requires_by)
    assert validator.validate({'name': 'bo', 'age': '42'})
    assert validator.valid

# Generated at 2022-06-20 15:38:44.788245
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common.parameters import sanitize_keys
    parameters = {'param1': 'value1',
                  'param2': 'value2',
                  'no_log': {'param3': 'value3'},
                  'no_log_param4': True}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result

# Generated at 2022-06-20 15:39:02.941664
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec_validator = ArgumentSpecValidator({})
    assert argument_spec_validator._mutually_exclusive is None
    assert argument_spec_validator._required_together is None
    assert argument_spec_validator._required_one_of is None
    assert argument_spec_validator._required_if is None
    assert argument_spec_validator._required_by is None
    assert argument_spec_validator._valid_parameter_names == set()


# Generated at 2022-06-20 15:39:13.973016
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    :arg id: 1
    :type id: int
    :arg name: foo
    :type name: str
    """

    def _deprecate(msg, **kwargs):
        assert msg == "Alias 'name' is deprecated. See the module docs for more information"
        assert kwargs == {'version': '2.0', 'date': '2018-12-31', 'collection_name': 'test.collection'}

    def _warn(msg):
        assert msg == 'Both option name and its alias alias are set.'


# Generated at 2022-06-20 15:39:23.002646
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec, mutually_exclusive, required_together,
                     required_one_of, required_if, required_by):
            super(TestModuleArgumentSpecValidator, self).__init__(
                argument_spec, mutually_exclusive,
                required_together, required_one_of,
                required_if, required_by)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by

# Generated at 2022-06-20 15:39:31.634426
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = dict()

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    parameters = dict()

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                            required_together=required_together, required_one_of=required_one_of,
                                            required_if=required_if, required_by=required_by)

    validator.validate(parameters)

# Generated at 2022-06-20 15:39:42.241585
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'a': {'type': 'str', 'required': True},
                                       'b': {'type': 'int', 'required': True}})

    # Check that validation errors are collected and returned.
    result = validator.validate({})
    assert result.error_messages[0] == 'a is required'
    assert result.error_messages[1] == 'b is required'

    # Check that default values are set
    result = validator.validate({'a': '0'})
    assert result._validated_parameters['b'] == 0

    # Check that no_log values are set
    result = validator.validate({'a': '0', 'b': '0', 'password': 'secret'}, no_log_values=['password'])
    assert 'password'

# Generated at 2022-06-20 15:39:45.247281
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={'name': 'bo'})
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {'name': 'bo'}


# Generated at 2022-06-20 15:39:49.072236
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={"key1": "value1", "key2": "value2"})
    assert result._validated_parameters == {"key1": "value1", "key2": "value2"}


# Generated at 2022-06-20 15:39:58.666371
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={'a': 1, 'b': '2'})
    assert result._validated_parameters == {'a': 1, 'b': '2'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.validated_parameters == {'a': 1, 'b': '2'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-20 15:40:01.353219
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec = dict())
    parameters = dict()
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == dict()
    assert result.errors == []
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._unsupported_parameters == set()
    assert result._warnings == []

# Generated at 2022-06-20 15:40:07.693849
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    for method in ("warn", "deprecate"):
        setattr(ModuleArgumentSpecValidator, method, lambda *args, **kwargs: getattr(warn, method)(*args, **kwargs))
    attributes = {
        '_warnings': [{'option': 'name', 'alias': 'aliases'}],
        '_deprecations': [{'name': 'names',
                           'version': '2.0',
                           'date': 'today',
                           'collection_name': 'names'
                          }],
    }
    for attr, value in attributes.items():
        setattr(ModuleArgumentSpecValidator, attr, value)



# Generated at 2022-06-20 15:40:21.477375
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    validation_result = ValidationResult(parameters)
    assert (validation_result._validated_parameters == parameters)
    assert (validation_result._no_log_values == set())
    assert (validation_result._unsupported_parameters == set())
    assert (validation_result._deprecations == [])
    assert (validation_result._warnings == [])
    assert (validation_result.errors == AnsibleValidationErrorMultiple())
    assert (validation_result.validated_parameters == parameters)
    assert (validation_result.unsupported_parameters == set())
    assert (validation_result.error_messages == [])



# Generated at 2022-06-20 15:40:29.384227
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit tests for class ArgumentSpecValidator"""
    # Test instantiation of class ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    validator = ArgumentSpecValidator(argument_spec,
        mutually_exclusive=mutually_exclusive,
        required_if=[
            ['name', 'Jim', ['age']],
            ['name', 'John', ['age']],
        ],
        required_by={
            'name': ['age'],
        })

# Generated at 2022-06-20 15:40:36.756852
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.dict_transformations import recursive_diff
    validator = ArgumentSpecValidator({
        'a': {'type': 'str', 'required': True},
        'b': {'type': 'int', 'required': True},
        'c': {'type': 'str', 'required': True, 'default': 'test'},
        'o': {'type': 'list'},
        'z': {'type': 'str'},
        'w': {'type': 'dict'},
    })
    params = {
        'a': 'test',
        'b': '2',
        'z': 'test',
        'o': [1, 2],
        'w': {'a': 1, 'b': 2},
    }
    result = validator.validate(params)

# Generated at 2022-06-20 15:40:48.334623
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name1', 'name2'],
    ]
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    assert None == result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

# Generated at 2022-06-20 15:40:55.121374
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    constructor for class ArgumentSpecValidator
    """
    obj = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                                mutually_exclusive=None,
                                required_together=None,
                                required_one_of=None,
                                required_if=None,
                                required_by=None)
    assert obj._valid_parameter_names == set(['name'])
    assert obj._mutually_exclusive is None
    assert obj._required_together is None
    assert obj._required_one_of is None
    assert obj._required_if is None
    assert obj._required_by is None
    assert obj.argument_spec == {'name': {'type': 'str'}}

# Generated at 2022-06-20 15:41:01.482539
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_if = [['name', 'bo', ['age']]]
    required_by = {'name': ['age']}
    validator = ModuleArgumentSpecValidator(
        argument_spec=argument_spec,
        mutually_exclusive=mutually_exclusive,
        required_if=required_if,
        required_by=required_by,
    )

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}


# Generated at 2022-06-20 15:41:09.738168
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []

# Generated at 2022-06-20 15:41:17.562610
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # no_log: {'password': '7684'}
    parameters = {'password': '7684', 'username': 'root'}
    # mutually_exclusive: [{'group': ['host', 'hostname']}]
    mutually_exclusive = [{'group': ['host', 'hostname']}]
    # required_if: [{'host': 'localhost', 'group': ['foo']}, {'host': 'localhost', 'group': ['bar']}]
    required_if = [{'host': 'localhost', 'group': ['foo']}, {'host': 'localhost', 'group': ['bar']}]
    # required_one_of: [{'group': ['ansible_ssh_user', 'remote_user']}]

# Generated at 2022-06-20 15:41:27.176440
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-20 15:41:31.219298
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'test1': 'test1',
        'test2': 'test2',
    }
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-20 15:41:43.197794
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:41:51.837132
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'name': 'bo', 'age': 42}
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-20 15:41:55.365678
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator._mutually_exclusive == None
    assert validator._required_by == None
    assert validator._required_one_of == None
    assert validator._required_together == None
    assert validator._valid_parameter_names == {'age', 'name'}
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-20 15:41:57.820450
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    instance = ValidationResult({'parameters': 'value'})
    assert instance.validated_parameters == {'parameters': 'value'}

# Generated at 2022-06-20 15:42:05.091813
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    input_parameters = {
        'name': 'bo',
        'age': '42',
    }

    ret = ValidationResult(input_parameters)

    assert ret._no_log_values == set()
    assert ret._unsupported_parameters == set()
    assert ret._validated_parameters == input_parameters
    assert ret._deprecations == []
    assert ret._warnings == []
    assert ret.errors == AnsibleValidationErrorMultiple()
    assert ret.validated_parameters == input_parameters
    assert ret.unsupported_parameters == set()
    assert ret.error_messages == []

# Generated at 2022-06-20 15:42:08.300821
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'Mark'}
    vr = ValidationResult(parameters)
    assert vr._validated_parameters == parameters
    assert vr.validated_parameters == parameters


# Generated at 2022-06-20 15:42:12.795222
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age"]]
    required_by = {"name": ["age"]}
    ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:42:18.548809
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'str'},
                     'b': {'type': 'int'}}
    mutually_exclusive = [['a', 'b']]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)
    parameters = {'a': '42',
                  'b': 42}

    expected = {'a': '42',
                'b': 42}
    result = validator.validate(parameters)

    assert result.validated_parameters == expected

# Generated at 2022-06-20 15:42:29.930111
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    params = {'ANSIBLE_MODULE_ARGS': parameters}
    ansible_module = AnsibleModule(argument_spec=argument_spec)
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result.error_messages) == 0
    assert 'ansible_module' in result._validated_parameters

# Generated at 2022-06-20 15:42:39.435309
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    class TestClass1(object):
        def __init__(self):
            pass

    class TestClass2(object):
        def __init__(self):
            pass

    test1 = TestClass1()
    test2 = TestClass2()

    parameters = {'a': 'x', 'b': 1}
    validation_result = ValidationResult(parameters=parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == {'a': 'x', 'b': 1}
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result._deprecations == []
    assert validation_result._warnings == []

# Generated at 2022-06-20 15:42:47.337987
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:42:48.649891
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(argument_spec={})

# Generated at 2022-06-20 15:42:59.259505
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'deprecated_option': 'foo',
        'deprecated_option_for_new_option': 'foo',
        'new_option': 'foo',
        'required_option': 'foo'
    }

    result = ValidationResult(parameters)

    assert tuple(result.error_messages) == ()

    assert result.validated_parameters == {
        'deprecated_option': 'foo',
        'deprecated_option_for_new_option': 'foo',
        'new_option': 'foo',
        'required_option': 'foo'
    }

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-20 15:43:00.712484
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    modspec_validator = ModuleArgumentSpecValidator({})
    assert isinstance(modspec_validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:43:04.399184
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a mock class for ArgumentSpecValidator, so that validate method can be called for testing
    class ArgumentSpecValidator_Test:
        def validate(self):
            return True

    argument_spec_validator = ModuleArgumentSpecValidator(ArgumentSpecValidator_Test)
    result = argument_spec_validator.validate(['test'])

    assert result == True

# Generated at 2022-06-20 15:43:11.636263
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"arg1": "arg1"}
    result = ValidationResult(parameters)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result._no_log_values, set)

# Generated at 2022-06-20 15:43:14.573022
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:43:25.865707
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common._collections_compat import Mapping
    import sys

    # Don't use assertHandler since it's not available until Ansible 2.12

    class NullHandler:
        def emit(self, record):
            pass
    logger = NullHandler()
    logger.setLevel(logging.DEBUG)
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    logger.addHandler(console)
    logging.getLogger("deprecated").addHandler(logger)
    # Now we can import assertHandler
    from ansible.module_utils.common.arg_spec import assertHandler
    original_assertHandler = assertHandler



# Generated at 2022-06-20 15:43:34.505352
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # prepare arguments and expected results.
    parameters = {'name': 'bo', 'age': '42'}
    argument_spec = {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                   }
    expected = [{'error_message': "Error in converting name to type int: argument of type 'str' is not iterable",
                 'error_code': "AnsibleFailJson", 'failed_when_result': False}]

    # call to be tested.
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # check if result is the expected one.
    assert result.errors == expected
