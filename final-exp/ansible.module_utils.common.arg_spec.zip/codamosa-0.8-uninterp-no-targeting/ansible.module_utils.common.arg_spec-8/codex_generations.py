

# Generated at 2022-06-20 15:33:54.714321
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo', 'age': '42'})
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}


# Generated at 2022-06-20 15:34:00.397835
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []


# Generated at 2022-06-20 15:34:01.299100
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True == True

# Generated at 2022-06-20 15:34:11.722826
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    input_argument_spec = {}
    warnings = []
    deprecations = []
    args = {
        'argument_spec': input_argument_spec,
        'mutually_exclusive': None,
        'required_together': None,
        'required_one_of': None,
        'required_if': None,
        'required_by': None
    }

    with_params = {}
    validator = ModuleArgumentSpecValidator(**args)
    result = validator.validate(with_params)

    assert result.validated_parameters == with_params
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-20 15:34:23.122254
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    def test():
        """
        This function tests the constructor of the ValidationResult class
        """
        a1 = ValidationResult("foo")
        assert a1._validated_parameters == "foo"
        assert a1._no_log_values == set()
        assert a1._unsupported_parameters == set()
        assert a1._deprecations == []
        assert a1._warnings == []
        assert isinstance(a1.errors, AnsibleValidationErrorMultiple)

        a2 = ValidationResult("bar")
        assert a2._validated_parameters == "bar"
        assert a2._no_log_values == set()
        assert a2._unsupported_parameters == set()
        assert a2._deprecations == []
        assert a2._warnings == []

# Generated at 2022-06-20 15:34:34.280241
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'name': {
            'type': 'str',
            'required': True,
        },
        'age': {
            'type': 'int',
        },
    })

    result = validator.validate({'name': 'Bob'})
    assert result.validated_parameters == {'name': 'Bob'}

    result = validator.validate({'name': 'Bob', 'age': '42'})
    assert result.validated_parameters == {'name': 'Bob', 'age': 42}

    result = validator.validate({'age': '42'})
    assert result.error_messages == ['Missing required arguments: name']

    result = validator.validate({'name': 'Bob', 'age': ''})
    assert result.error_

# Generated at 2022-06-20 15:34:41.030947
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    # Should instantiate a ValidationResult from dict
    test_result = ValidationResult(parameters)
    assert test_result.validated_parameters == parameters
    assert test_result.error_messages == []
    assert test_result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:34:47.534048
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""
    parameters = {
        'name': 42,
    }
    argument_spec = {
        'name': {'type': 'str'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert 'invalid type' in result.error_messages



# Generated at 2022-06-20 15:34:55.959373
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        param1=dict(type='str'),
        param2=dict(type='int'),
        param3=dict(type='bool'),
    )

    mutually_exclusive = [
        ['param1', 'param2'],
        ['param1', 'param3'],
    ]

    required_together = [
        ['param1', 'param2'],
    ]

    required_one_of = [
        ['param1', 'param2'],
    ]

    required_if = [
        ['param1', 'param2', 'param3'],
    ]

    required_by = dict(
        param1=['param2']
    )


# Generated at 2022-06-20 15:34:56.391277
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-20 15:35:11.809252
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    d = dict()
    d['argument_spec'] = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    d['mutually_exclusive'] = None
    d['required_together'] = None
    d['required_one_of'] = None
    d['required_if'] = None
    d['required_by'] = None

    validator = ModuleArgumentSpecValidator(d['argument_spec'], d['mutually_exclusive'], d['required_together'], d['required_one_of'], d['required_if'], d['required_by'])

    #TODO
    #validator.validate({'name': 'bo', 'age': '42'})

# Generated at 2022-06-20 15:35:21.122860
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class Test:
        def test_basic(self):
            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }

            parameters = {
                'name': 'bo',
                'age': '42',
            }

            validator = ArgumentSpecValidator(argument_spec)
            result = validator.validate(parameters)

            assert not result.errors.messages
            assert result.validated_parameters == {
                'name': 'bo',
                'age': 42,
            }

        def test_validation_errors(self):
            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }


# Generated at 2022-06-20 15:35:24.760485
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator({"test": {"type": "str"}})
    assert type(m).__name__ == "ModuleArgumentSpecValidator"

# Generated at 2022-06-20 15:35:27.136551
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Allow args and kwargs to be passed through to constructor of ArgumentSpecValidator
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:35:36.632550
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    """
    :param type: Mock
    :param Mock: Mock
    :rtype: None
    """


# Generated at 2022-06-20 15:35:41.144863
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(argument_spec={}) is not None
    assert ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None) is not None


# Generated at 2022-06-20 15:35:51.367477
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        validator = ArgumentSpecValidator("Invalid argument spec")
    except TypeError as e:
        assert "Expected dict" in to_native(e)
    else:
        assert False

    try:
        validator = ArgumentSpecValidator(
            {
                'name': 'Invalid argument spec',
            })
    except TypeError as e:
        assert "Expected dict" in to_native(e)
    else:
        assert False

    try:
        validator = ArgumentSpecValidator(
            {
                'name': 'Invalid argument spec',
            },
            mutually_exclusive="Invalid mutually exclusive")
    except TypeError as e:
        assert "Requires a list" in to_native(e)
    else:
        assert False



# Generated at 2022-06-20 15:36:00.186720
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Setup
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age']]
    required_by = {'name' : ['age'] }

    # Exercise
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)

    # Verify
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together

# Generated at 2022-06-20 15:36:07.479187
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    import pytest
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive, check_required_arguments
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.common.text.converters import to_native

    # setup
    argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}

# Generated at 2022-06-20 15:36:09.280266
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = dict(foo=dict(type='str'))
    validator = ModuleArgumentSpecValidator(argument_spec=arg_spec)

    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:36:23.913945
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils import basic

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    # Test basic
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert len(result.errors.messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test multiple errors
    parameters = {
        'name': 1,
        'age': '42',
    }
    result = validator.validate(parameters)

    assert len(result.errors.messages) == 1
   

# Generated at 2022-06-20 15:36:24.880277
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:36:30.560496
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        "one": 1,
        "two": 2,
    }

    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []
    assert result.errors.orig_exc == ()
    assert result.errors.parent == None


# Generated at 2022-06-20 15:36:37.748212
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module = AnsibleModule(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    )
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module.validate(parameters)
    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42



# Generated at 2022-06-20 15:36:46.465298
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == {'name', 'age'}


# Generated at 2022-06-20 15:36:56.326966
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''validate'''
    # Test with no argument
    assert ModuleArgumentSpecValidator().validate({})

    # Test with argument
    assert ModuleArgumentSpecValidator({'arg1': {'type': 'bool', 'default': False}}).validate({'arg1': True})

    # Test with a required argument
    arg_spec = {
        'arg1': {'type': 'bool', 'default': False},
        'arg2': {'type': 'bool', 'required': True}
    }
    assert ModuleArgumentSpecValidator(arg_spec).validate({})

    # Test with a required argument
    assert ModuleArgumentSpecValidator(arg_spec).validate({'arg2': True})

# Generated at 2022-06-20 15:36:57.076297
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator()
    assert a


# Generated at 2022-06-20 15:37:01.278125
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)
    assert isinstance(validator._mutually_exclusive, type(None))
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-20 15:37:08.943049
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """ValidationResult class constructor"""

    # ValidationResult object will be constructed
    data = {}
    result = ValidationResult(data)

    # The parameters should match what was passed in
    assert result._validated_parameters is not data
    assert result._validated_parameters == data

    # The lists should be empty
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()

    # All of the parameters should be set
    assert result.validated_parameters is not None
    assert result.unsupported_parameters is not None
    assert result.error_messages is not None


# Generated at 2022-06-20 15:37:19.487612
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'str'}}
    mutually_exclusive = ['a', 'b']
    required_together = [('a', 'b')]
    required_one_of = [['a', 'b']]
    required_if = [('a', 'b', ['a'])]
    required_by = {'a': ['b']}
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    # Unit test for constructor of class ArgumentSpecValidator in module ansible.module_utils.common.arg_spec
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-20 15:37:31.214073
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'age', 'email'],
    ]

    arguments = ArgumentSpecValidator(argument_spec, mutually_exclusive)
    assert arguments.argument_spec == argument_spec
    assert arguments._mutually_exclusive == mutually_exclusive


# Generated at 2022-06-20 15:37:32.714375
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_spec_object = ModuleArgumentSpecValidator(argument_spec={})
    assert isinstance(module_spec_object, ArgumentSpecValidator)
    assert isinstance(module_spec_object, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:37:44.538678
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'param1': {'type': 'str'}, 'param2': {'type': 'int', 'required': True}, 'param3': {'type': 'int', 'default': 1}})

    parameters = {'param1': 'value1', 'param2': 2, 'param3': 3}
    result = validator.validate(parameters)
    assert result.validated_parameters == {'param1': 'value1', 'param2': 2, 'param3': 3}
    assert result.errors.messages == []

    parameters = {'param1': 'value1', 'param2': 'not_int', 'param3': 3}
    result = validator.validate(parameters)

# Generated at 2022-06-20 15:37:54.398749
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['name', 'age']}
    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive=mutually_exclusive,
                 required_together=required_together,
                 required_one_of=required_one_of,
                 required_if=required_if,
                 required_by=required_by,
                 )
    assert(validator)

# Generated at 2022-06-20 15:37:54.962556
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:38:00.638305
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'sport': {'type': 'str'},
        'favorite_python_version': {'type': 'str'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator



# Generated at 2022-06-20 15:38:09.905521
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_required_if
    from ansible.module_utils.common.validation import check_required_together

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'feed': {'type': 'list'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters


# Generated at 2022-06-20 15:38:12.090372
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:38:15.153489
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({})
    result = validator.validate({})

    assert len(result.validated_parameters) == 0
    assert len(result.error_messages) == 0

# Generated at 2022-06-20 15:38:24.055789
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    import sys
    import json

    from ansible.module_utils.common.validation import  ValidationResult
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple

    sys.stdout.write('\nParams: \n')

    params = {
        'name': 'bo',
        'age': 42,
    }

    json.dump(params, sys.stdout)

    sys.stdout.write('\nresult: \n')

    result = ValidationResult(params)
    if result.error_messages:
        sys.exit(to_native(result.errors))

    json.dump(result.validated_parameters, sys.stdout)


# Generated at 2022-06-20 15:38:34.957971
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test that invalid 'type' raises an error
    arg_spec = {
        'name': {'type': 5},
    }
    try:
        validator = ArgumentSpecValidator(arg_spec)
        validator.validate({'name': 'bo'})
        assert False
    except TypeError:
        pass
    except Exception as e:
        assert True
        # print('Unexpected Exception: {0}'.format(e))

    # Test that invalid 'type' raises a TypeError
    arg_spec = {
        'name': {'type': 'invalid'},
    }
    try:
        validator = ArgumentSpecValidator(arg_spec)
        validator.validate({'name': 'bo'})
        assert False
    except TypeError:
        pass

# Generated at 2022-06-20 15:38:37.297863
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={})
    parameters = {}
    assert validator.validate(parameters) == ValidationResult(parameters)

# Generated at 2022-06-20 15:38:46.150966
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Validate when there are no errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    # Validate parameters with no error
    parameters = {
        'name': 'John Doe',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.errors == []
    assert result.validated_parameters == parameters

    # Validate when an unsupported parameter is passed
    parameters = {'name': 'John Doe', 'age': 42, 'location': 'US'}
    result = validator.validate(parameters)
    assert result.unsupported_parameters == {'location'}
    assert result.validated_parameters

# Generated at 2022-06-20 15:38:56.907600
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}
    v = ArgumentSpecValidator(argument_spec)
    assert(v.argument_spec == argument_spec)
    assert(v._mutually_exclusive is None)
    assert(v._required_together is None)
    assert(v._required_one_of is None)
    assert(v._required_if is None)
    assert(v._required_by is None)

    v = ArgumentSpecValidator(argument_spec,
                              mutually_exclusive=['name'],
                              required_together=['name'],
                              required_one_of=['name'],
                              required_if={'name': {'value': 'value', 'others': ['name']}},
                              required_by={'name': ['name']})

# Generated at 2022-06-20 15:38:58.863986
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Arrange
    parameters={'name': 'bo', 'age': '42'}

    # Act
    result = ValidationResult(parameters)

    # Assert
    assert result.errors == []
    assert result.validated_parameters == parameters


# Generated at 2022-06-20 15:39:01.146722
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    result = validator.validate({})
    assert type(result) is ValidationResult

# Generated at 2022-06-20 15:39:08.841446
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    valid_params = result.validated_parameters
    # Assert the validated_parameters are valid
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-20 15:39:16.165177
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({})
    parameters = {'some_param': 'set', 'some_other_param': 'also set'}
    result = validator.validate(parameters)
    assert result.unsupported_parameters == {'some_param', 'some_other_param'}
    assert result.validated_parameters == {}
    assert result.errors[0].message == "some_other_param, some_param. Supported parameters include: ."
    assert result.error_messages[0] == "some_other_param, some_param. Supported parameters include: ."

# Generated at 2022-06-20 15:39:18.630476
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    args = {'p1': 'x', 'p2': 'y'}
    obj = ValidationResult(args)
    assert obj._validated_parameters == args
    assert obj.unsupported_parameters == set()
    assert obj.errors == AnsibleValidationErrorMultiple()
    assert obj.validated_parameters == args
    assert obj.error_messages == []


# Generated at 2022-06-20 15:39:20.063844
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator is not None


# Generated at 2022-06-20 15:39:26.870040
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'ansible'})
    err_msg = "ValidationResult object 'result' has no attribute 'foo'"
    assert not hasattr(result, 'foo'), err_msg


# Generated at 2022-06-20 15:39:37.177344
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test when validate method returns success
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test when validate method returns failure
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-20 15:39:42.608284
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common.validation import check_type_error, check_value_error, check_mutually_exclusive_error

    # Testing constructor of the error class
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = ValidationResult(parameters)
    name_error = check_type_error("argument 'name' is of type <class 'str'> when we were expecting <class 'int'>", "argument")
    age_error = check_value_error("argument 'age' is of type <class 'int'> and we were expecting an int in the range 0..100", "argument")

    # Testing mutation of ValidationResult object
    result.errors.extend([name_error, age_error])
    result._no_log_values.add('name')
    result._

# Generated at 2022-06-20 15:39:47.920400
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    parameters = {}
    result = ModuleArgumentSpecValidator({}).validate(parameters)
    assert result.error_messages == [
        u'parameter name: is required',
    ]
    assert result.validated_parameters == {}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()



# Generated at 2022-06-20 15:39:48.945525
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator({})

# Generated at 2022-06-20 15:39:51.620238
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert repr(ValidationResult({'x': 1})) == '<ValidationResult instances={x: 1}, no_log_values={}, unsupported_parameters={}, errors=[]>'

# Generated at 2022-06-20 15:40:01.847255
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    assert validator.validate(parameters)

# Generated at 2022-06-20 15:40:02.740261
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator is not None

# Generated at 2022-06-20 15:40:03.421615
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}) != None

# Generated at 2022-06-20 15:40:12.579322
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == set()

    argument_spec = {'name': {'type': 'str'}}
    mutually_exclusive = ['name']
    required_together = [['name']]
    required_one_of = [['name', 'age']]

# Generated at 2022-06-20 15:40:24.783237
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for method validate (line 33)
    result = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }).validate({
        'name': 'bo',
        'age': '42',
    })
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.error_messages == []
    assert result.unsupported_parameters == []
    assert result._no_log_values == []

# Generated at 2022-06-20 15:40:32.727324
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}, }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-20 15:40:38.847221
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:40:48.247136
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        "argument_spec": {
            "test": {
                "type": "bool",
            },
        },
    }

    result = ValidationResult(parameters)
    assert isinstance(result._validated_parameters, dict)
    assert not result._validated_parameters
    assert not result._no_log_values
    assert not result._unsupported_parameters
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors
    assert not result.validated_parameters
    assert not result.unsupported_parameters
    assert not result.error_messages


# Generated at 2022-06-20 15:40:55.556852
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method ArgumentSpecValidator.validate()"""

    # The values of the parameters to be tested
    params = {
        'name': 'bo',
        'age': '42',
        'private': 'True',
    }

    # The argument spec
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'private': {'type': 'bool', 'default': False},
    }

    # Initialize the validator and validate the parameters
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(params)

    # Assert if there is no error after validation
    assert(not result.error_messages)

    # Assert if the validated parameters are not equal to the parameters to be validated

# Generated at 2022-06-20 15:40:58.136751
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Test that ModuleArgumentSpecValidator can be initialized
    spec = {'a': {}}
    mav = ModuleArgumentSpecValidator(spec)
    assert mav is not None
    assert 1 == len(mav._valid_parameter_names)
    assert spec == mav.argument_spec


# Generated at 2022-06-20 15:41:09.284110
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    mutually_exclusive = [{"age": 42}]
    required_together = [{"age": 42}]
    required_one_of = [{"age": 42}]
    required_if = [{"age": 42}]
    required_by = [{"age": 42}]

    validator = ArgumentSpecValidator(argument_spec,
                                                 mutually_exclusive=mutually_exclusive,
                                                 required_together=required_together,
                                                 required_one_of=required_one_of,
                                                 required_if=required_if,
                                                 required_by=required_by)
    assert (validator._mutually_exclusive == mutually_exclusive)

# Generated at 2022-06-20 15:41:10.441389
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:41:15.352242
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': 42
    }

    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:41:20.251667
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({
        'test': {
            'type': 'str',
            'default': 'value',
        },
    })

    result = validator.validate(parameters={})
    valid_params = result.validated_parameters

    assert 'test' in valid_params
    assert valid_params['test'] == 'value'

# Generated at 2022-06-20 15:41:29.758134
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {}
    mav = ModuleArgumentSpecValidator(argument_spec)
    ansible_module = None

    list_no_log_values = []
    module_arg_spec = mav.validate(list_no_log_values)

# Generated at 2022-06-20 15:41:34.056282
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec



# Generated at 2022-06-20 15:41:45.654255
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert len(validator._valid_parameter_names) == 2
    assert "name" in validator._valid_parameter_names
    assert "age" in validator._valid_parameter_names

# Generated at 2022-06-20 15:41:53.560865
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'foo': {'type': 'str', 'aliases': ['bar']}}, required_if=[['bar', 'XXX', ['foo']]], mutually_exclusive=[['bar', 'foo']])
    parameters = {'foo': 'test', 'bar': 'test2'}
    result = validator.validate(parameters)
    assert 'Alias \'bar\' is deprecated. See the module docs for more information' in result.error_messages and 'Both option foo and its alias bar are set.' in result.error_messages and 'parameters bar and foo are mutually exclusive' in result.error_messages and 'foo or bar are required' in result.error_messages

# Generated at 2022-06-20 15:42:00.920861
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {'name': 'Ansible', 'age': 42}
    result = ValidationResult(p)
    assert result._validated_parameters == p
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors
    assert result.validated_parameters == p
    assert result.unsupported_parameters == set()
    assert not result.deprecations
    assert not result.warnings


# Generated at 2022-06-20 15:42:06.846048
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {
        'foo': {'type': 'str', 'required': True},
        'bar': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(arg_spec)
    assert validator.mutually_exclusive is None
    assert validator.required_together is None
    assert validator.required_one_of is None
    assert validator.required_if is None
    assert validator.required_by is None
    assert validator.argument_spec == arg_spec


# Generated at 2022-06-20 15:42:11.664607
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result is not None

# Generated at 2022-06-20 15:42:16.159310
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    t = ValidationResult(parameters)
    assert t.validated_parameters == parameters
    assert t._no_log_values == set()
    assert t._unsupported_parameters == set()
    assert t._validated_parameters == parameters
    assert t._deprecations == []
    assert t._warnings == []
    assert t.errors == AnsibleValidationErrorMultiple()
    assert t.error_messages == []


# Generated at 2022-06-20 15:42:22.633824
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    doc = '''Validate args for a file module'''
    mutually_exclusive = [('path', 'creates')]
    required_if = [('owner', 'directory', ['mode']), ('owner', 'file', ['mode'])]
    argument_spec = {
        'path': {'type': 'path', 'required': True},
        'owner': {'type': 'str'},
        'mode': {'type': 'str'}
    }
    ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, None, None, required_if, None)


# Generated at 2022-06-20 15:42:33.623464
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    for validator in [ArgumentSpecValidator]:
        with pytest.raises(TypeError):
            # missing required arguments
            validator()
        with pytest.raises(TypeError):
            # argument_spec only
            validator({"arg1": {"type": "str"}})
        with pytest.raises(TypeError):
            # invalid argument_spec
            assert validator(argument_spec="not a dict")
        with pytest.raises(TypeError):
            # mutually_exclusive only
            validator({"arg1": {"type": "str"}}, mutually_exclusive=["arg1"])

# Generated at 2022-06-20 15:43:00.802942
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common import AnsibleFailJsonException
    from ansible.module_utils.common.validation import MutuallyExclusiveError, RequiredError, UnsupportedError
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]

    required_if = [
        ['name', 'age'],
        ['name', 'age']
    ]

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_if=required_if)


# Generated at 2022-06-20 15:43:04.470847
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator({}).validate({'name': 'bo', 'age': '42'})
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.errors) == 0
    assert result.error_messages == []



# Generated at 2022-06-20 15:43:15.337419
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:43:21.693498
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Function test_ModuleArgumentSpecValidator_validate tests the method validate of class ModuleArgumentSpecValidator"""
    from ansible.module_utils.common.warnings import DEPRECATION_WARNINGS

    with DEPRECATION_WARNINGS:
        mg = ModuleArgumentSpecValidator({})
        mg.validate({})
    mg = ModuleArgumentSpecValidator({})
    mg.validate({})


# Generated at 2022-06-20 15:43:31.380649
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    import sys
    import types
    import random

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
    	sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters



    # Unit test for class ValidationResult
    class TestCase_ValidationResult(object):
        def test_error_message(self):
            assert isinstance(result.error_messages, list)


# Generated at 2022-06-20 15:43:41.246749
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Args and kwargs for ArgumentSpecValidator
    asv_args = dict(argument_spec=dict(), mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    asv_kwargs = {}
    # Args for ModuleArgumentSpecValidator
    masv_args = ()
    masv_kwargs = {}
    # Call ModuleArgumentSpecValidator with by calling the needed constructors or functions in order
    masv = ModuleArgumentSpecValidator(*masv_args, **masv_kwargs)
    asv = ArgumentSpecValidator(*asv_args, **asv_kwargs)
    masv.__init__(*masv_args, **masv_kwargs)