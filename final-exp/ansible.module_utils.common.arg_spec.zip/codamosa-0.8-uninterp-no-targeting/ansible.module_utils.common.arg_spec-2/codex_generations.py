

# Generated at 2022-06-20 15:33:50.610533
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"name": "bo", "age": 42}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:33:57.644240
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        "path": {"required": True, "type": "path", "version_added": "2.2"},
        "repo": {
            "required": True,
            "type": "str",
        },
        "state": {
            "default": "present",
            "type": "str",
            "choices": ["absent", "present"],
        },
    }
    mutually_exclusive = [["path", "repo"]]
    required_together = [["path", "repo"]]
    required_if = [["path", "present", ["repo"]]]
    required_one_of = [["path", "repo"]]
    required_by = {"repo": ["path"]}


# Generated at 2022-06-20 15:34:09.758127
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'list', 'default': 'bo'},
        'age': {'type': 'int', 'aliases': ['old']},
    }

    validator = ArgumentSpecValidator(spec)

    assert validator.argument_spec == spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == {'age (old)', 'name'}


# Generated at 2022-06-20 15:34:17.154238
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-20 15:34:26.218914
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test with no_log values
    argument_spec = {
        'name': {'type': 'str'},
        'no_log_value': {'type': 'str', 'no_log': True},
        'no_log_value_from_fallback': {'type': 'str', 'no_log': True},
    }

    parameters = {
        'name': 'bo',
        'no_log_value': 'hi',
        'no_log_value_from_fallback': 'hi2',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

    assert result._no_log_values == {'no_log_value', 'no_log_value_from_fallback'}



# Generated at 2022-06-20 15:34:33.410881
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Argument spec validation class used by :class:`AnsibleModule`.

    This is not meant to be used outside of :class:`AnsibleModule`. Use
    :class:`ArgumentSpecValidator` instead.
    """

    assertModuleArgumentSpecValidator = ModuleArgumentSpecValidator({'name': {'type': 'str'},
                                                                     'age': {'type': 'int'}
                                                                     })
    assert isinstance(assertModuleArgumentSpecValidator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:34:34.657374
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(None)
    assert validator

# Generated at 2022-06-20 15:34:47.543962
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test no errors with valid parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

    # Test KeyError for alias that does not exist

# Generated at 2022-06-20 15:34:56.631454
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings

    # no_log in argument spec.
    argument_spec = {
        'name': {'type': 'str', 'no_log': True},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    # no_log in arguments.

# Generated at 2022-06-20 15:35:08.078027
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [['a', 'b'], ['b', 'c'], ['d', 'e', 'f']]
    required_one_of = [['d', 'e', 'f'], ['g', 'h']]
    required_together = [
        ['d', 'e'],
        ['d', 'f'],
        ['e', 'f'],
    ]


# Generated at 2022-06-20 15:35:19.919853
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [['name', 'name2']]
    spec = {
            'name': {'type': 'str'},
            'name2': {'type': 'str'},
            'names': {
                'type': 'list',
                'element': {
                    'type': 'str'
                    }
                }
            }
    validator = ModuleArgumentSpecValidator(spec, mutually_exclusive)

    parameters = {'name': 'bo', 'name2': 'bo'}
    result = validator.validate(parameters)
    assert result.error_messages == ['name and name2 are mutually exclusive']

# Generated at 2022-06-20 15:35:31.572874
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'},
                     }
    mutually_exclusive = [['name', 'age'],
                          ['name', 'age'],
                          ]
    required_together = [['name', 'age'],
                         ['name', 'age'],
                         ]
    required_one_of = [['name', 'age'],
                       ['name', 'age'],
                       ]
    required_if = [['name', 'age', ['name', 'age']],
                   ['name', 'age', ['name', 'age']],
                   ]
    required_by = {'name': ['age', 'age'],
                   'age': ['name', 'name'],
                   }

# Generated at 2022-06-20 15:35:34.175743
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=[],
                                       required_together=[], required_one_of=[],
                                       required_if=[], required_by={})

# Generated at 2022-06-20 15:35:46.110733
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():  # pylint: disable=too-many-locals
    '''
    Test ModuleArgumentSpecValidator.validate()
    '''


# Generated at 2022-06-20 15:35:47.151891
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-20 15:35:56.424009
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validation_result = ValidationResult(parameters)
    assert validation_result
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == parameters
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.validated_parameters == parameters
    assert validation_result.unsupported_parameters == set()
    assert validation_result.error_messages == []


# Generated at 2022-06-20 15:36:02.403583
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'param1': 'one', 'param2': 'two'}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'param1': 'one', 'param2': 'two'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []

# Generated at 2022-06-20 15:36:06.383301
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Validate the `validate` method of class ModuleArgumentSpecValidator"""
    ModuleArgumentSpecValidator  # dummy access to the class definition
    assert isinstance(ModuleArgumentSpecValidator.validate(None, None), ValidationResult)



# Generated at 2022-06-20 15:36:08.291884
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator()
    assert a is not None

# Generated at 2022-06-20 15:36:12.260741
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Check if ValidationResult is constructed with a parameter as expected
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters


# Generated at 2022-06-20 15:36:26.755857
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

    validated_parameters = result.validated_parameters
    assert validated_parameters['name'] == 'bo'
    assert validated_parameters['age'] == 42

    parameters = {
        'name': 'bo',
    }
    result = validator.validate(parameters)
    assert 'age is required' in result.error_messages



# Generated at 2022-06-20 15:36:29.598545
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    "Initiate ValidationResult class to Validation_result"
    results = ValidationResult({'name': 'ansible', 'type': 'salt'})
    assert results is not None

# Generated at 2022-06-20 15:36:37.877524
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec={
            'foo': {'type': 'str'},
            'bar': {'type': 'list', 'aliases': ['baz']},
            'baz': {'type': 'list'},
        }
    )
    res = ValidationResult(m.params)
    assert res.validated_parameters == {'foo': None, 'bar': None, 'baz': None}
    assert res.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:36:48.391455
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:36:59.336695
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.parameters import sanitize_keys

    def test_get_mutually_exclusive():
        # check type
        assert isinstance(validator._mutually_exclusive, list)

        # check value
        assert 'a' in validator._mutually_exclusive
        assert 'b' in validator._mutually_exclusive
        assert len(validator._mutually_exclusive) == 2

    def test_get_required_together():
        # check type
        assert isinstance(validator._required_together, list)

        # check value
        assert validator._required_together == [['a', 'b']]

# Generated at 2022-06-20 15:37:01.492253
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # import the class and test
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    ModuleArgumentSpecValidator("Test")

# Generated at 2022-06-20 15:37:02.711434
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult({}), ValidationResult)


# Generated at 2022-06-20 15:37:11.836187
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    valid_parameter_names = set()
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by)

    assert isinstance(validator, ModuleArgumentSpecValidator)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert valid

# Generated at 2022-06-20 15:37:16.326217
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""
    vr = ValidationResult({"test": "funtest"})
    assert vr is not None


# Generated at 2022-06-20 15:37:19.114982
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    assert ValidationResult(parameters) is not None


# Generated at 2022-06-20 15:37:23.581384
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'test': 'data'})

# Generated at 2022-06-20 15:37:26.764923
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:37:32.079178
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    vr = ValidationResult({'name': 'bo'})
    assert vr.validated_parameters == {'name': 'bo'}
    assert vr.error_messages == []
    assert vr.unsupported_parameters == set()



# Generated at 2022-06-20 15:37:43.930049
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'arg1': {'type': 'str'}}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by)
    assert validator._mutually_exclusive == []
    assert validator._required_together == []
    assert validator._required_one_of == []
    assert validator._required_if == []
    assert validator._required_by == []
    assert validator

# Generated at 2022-06-20 15:37:47.636883
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Pass argument_spec with all values as None
    argument_spec = dict(
        name=dict(type=None),
        age=dict(type=None)
    )

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-20 15:37:48.889202
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "Need unit test for method validate of class ArgumentSpecValidator"

# Generated at 2022-06-20 15:37:54.910929
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'banana': 'hammock'})

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'banana': 'hammock'}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []

# Generated at 2022-06-20 15:38:02.896562
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:38:11.011842
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import pytest
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.errors import (
        AnsibleValidationErrorMultiple,
        AliasError,
        MutuallyExclusiveError,
        NoLogError,
        RequiredDefaultError,
        RequiredError,
        UnsupportedError,
    )
    from ansible.module_utils.common.arg_spec import (
        ValidationResult,
        ModuleArgumentSpecValidator
    )

    # test case 1
    # parameters = {}
    # 
    # validator = ModuleArgumentSpecValidator({})
    # result = validator.validate(parameters)
    # assert isinstance(result,

# Generated at 2022-06-20 15:38:21.397299
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator.
    """

# Generated at 2022-06-20 15:38:38.407314
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Check for failure of exception when mutually_exclusive is provided as None.
    with pytest.raises(TypeError) as excinfo:
        new_obj = ArgumentSpecValidator(argument_spec={},
                                        mutually_exclusive=None, required_together=None, required_one_of=None,
                                        required_if=None, required_by=None)
    assert "argument_spec should be of type <class 'dict'>" in str(excinfo.value)

    # Check for failure of exception when required_together is provided as None.
    with pytest.raises(TypeError) as excinfo:
        new_obj = ArgumentSpecValidator(argument_spec={},
                                        mutually_exclusive=None, required_together=None, required_one_of=None,
                                        required_if=None, required_by=None)


# Generated at 2022-06-20 15:38:44.751855
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult.__name__ == 'ValidationResult'
    assert ValidationResult.__doc__ is not None
    assert ValidationResult.__init__.__doc__ is not None
    param = {}
    result = ValidationResult(param)
    assert isinstance(result, ValidationResult)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._deprecations, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)



# Generated at 2022-06-20 15:38:54.687110
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = dict(
        name = dict(type = 'str'),
        age = dict(type = 'int'),
    )
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == dict(
        name = 'bo',
        age = 42,
    )
    assert not result._no_log_values
    assert not result._unsupported_parameters
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors

# Generated at 2022-06-20 15:38:57.065859
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    instance = ModuleArgumentSpecValidator(argument_spec={'ab': {'aliases': ['a']}}, mutually_exclusive=[],
                                           required_together=[], required_one_of=[], required_if={},
                                           required_by={})
    assert instance.argument_spec == {'ab': {'aliases': ['a']}}

# Generated at 2022-06-20 15:39:02.803095
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result.error_messages) == 0
    assert result.validated_parameters == parameters

# Generated at 2022-06-20 15:39:08.002698
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Tests that the constructor of the class ModuleArgumentSpecValidator
    does nothing more than calling the constructor of its parent class,
    i.e. the constructor of class ArgumentSpecValidator
    """
    arg_spec = {'arg': {'type': 'str'}}
    ModuleArgumentSpecValidator(arg_spec)

# Generated at 2022-06-20 15:39:18.046240
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class FakeArgumentSpecValidator:
        def __init__(self):
            self._error_messages = []
            self._warnings = []
            self._deprecations = []
            self._validated_parameters = {}
            self._unsupported_parameters = []
            self._no_log_values = []

        @property
        def error_messages(self):
            return self._error_messages

        @property
        def warnings(self):
            return self._warnings

        @property
        def deprecations(self):
            return self._deprecations

        @property
        def validated_parameters(self):
            return self._validated_parameters

        @property
        def unsupported_parameters(self):
            return self._unsupported_parameters


# Generated at 2022-06-20 15:39:25.432795
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''Unit test for constructor of class ArgumentSpecValidator'''

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age'],
        ['age', 'name']
    ]

    required_by = {
        'name': 'name',
        'age': 'age'
    }

    # Valid parameters

# Generated at 2022-06-20 15:39:27.525437
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.errors == []

# Generated at 2022-06-20 15:39:28.361609
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    pass

# Generated at 2022-06-20 15:39:49.247133
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
     # Arrange
     argument_spec = {
         'name': {'type': 'str', 'aliases': ['new']},
         'age': {'type': 'int'},
     }

     parameters = {
         'name': 'bo',
         'age': '42',
     }

     expected = {
         'name': 'bo',
         'age': 42,
     }

     # Act
     validator = ModuleArgumentSpecValidator(argument_spec)
     result = validator.validate(parameters)

     # Assert
     assert result.validated_parameters == expected

# Generated at 2022-06-20 15:39:54.615542
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:39:56.347659
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator({}).validate({})
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-20 15:40:06.217181
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case: Success
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages

    # Test case: Failure (age is not a integer)
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 'NaN',
    }
    validator = ArgumentSpecValidator(argument_spec)

# Generated at 2022-06-20 15:40:14.612840
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec = {
        'name1': {'type': 'str'},
        'name2': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name1', 'name2']
    ]

    required_together = [
        ['name1', 'name2'],
        ['name3', 'name4']
    ]

    required_one_of = [
        ['name1', 'name2'],
        ['name3', 'name4']
    ]

    required_if = [
        ['name1', 'A', ['name2']],
        ['name1', 'B', ['name3', 'name4', 'name5']]
    ]


# Generated at 2022-06-20 15:40:25.899639
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    test_module_args = {'name': 'test', 'age': 12, 'type': 'foo'}

    test_arg_spec = {
        'name': {'type': 'str', },
        'age': {'type': 'int', },
        'type': {'type': 'str', },
    }
    test_mutually_exclusive = []
    test_required_together = []
    test_required_one_of = []
    test_required_if = []
    test_required_by = []


# Generated at 2022-06-20 15:40:34.077055
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ValidationResult({})
    specs = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(specs)
    result = validator.validate({'name': 'bo', 'age': '42'})
    assert result.errors == [],\
        'Validation with missing parameters should not return errors'
    assert result.validated_parameters == {'name': 'bo', 'age': 42},\
        'Validation with missing parameters should return the correct parameters'
    result = validator.validate({'name': 'bo'})
    assert len(result.error_messages) == 1,\
        'Validation with missing parameters should return 1 error'

# Generated at 2022-06-20 15:40:38.965048
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    validation_result = ValidationResult(parameters)
    assert isinstance(validation_result, ValidationResult)
    assert validation_result.validated_parameters == parameters
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.error_messages == []


# Generated at 2022-06-20 15:40:49.997690
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'job': {
            'type': 'dict',
            'argument_spec': {
                'role': {'type': 'str'},
                'description': {'type': 'str'},
            },
        }
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'job': {
            'role': 'sheriff',
            'description': 22,
        }
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:40:50.790546
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})



# Generated at 2022-06-20 15:41:13.263012
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:41:14.603118
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_class = ModuleArgumentSpecValidator()
    assert test_class

# Generated at 2022-06-20 15:41:22.777780
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True},
    }

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'test',
        'age': 'test',
    }

    with pytest.raises(AnsibleModule.fail_json):
        validator.validate(parameters)

    parameters = {
        'name': 'test',
        'age': '10',
    }

    assert validator.validate(parameters).error_messages == []



# Generated at 2022-06-20 15:41:33.457327
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a mock AnsibleModule with the needed parameters for the validation
    class MockAnsibleModule():
        def __init__(self):
            self.params = {
                "name": "bo",
                "age": 42,
                "aliases": ["bobo", "bo"],
            }
            self.deprecations = []

        def warn(self, msg):
            self.deprecations.append(msg)

    mock_module = MockAnsibleModule()

    argument_spec = {
        "name": {
            "type": "str"
        },
        "age": {
            "type": "int",
            "aliases": ["height"],
        },
        "aliases": {
            "type": "list"
        }
    }


# Generated at 2022-06-20 15:41:45.136090
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({"spam": {}}).argument_spec == {"spam": {}}
    assert ArgumentSpecValidator({"spam": {}}, mutually_exclusive=[['spam1', 'spam2']])._mutually_exclusive == [['spam1', 'spam2']]
    assert ArgumentSpecValidator({"spam": {}}, required_together=[['spam1', 'spam2']])._required_together == [['spam1', 'spam2']]
    assert ArgumentSpecValidator({"spam": {}}, required_one_of=[['spam1', 'spam2']])._required_one_of == [['spam1', 'spam2']]

# Generated at 2022-06-20 15:41:54.050557
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    def do_test(legal):
        if legal:
            assert ArgumentSpecValidator(argument_spec)
        else:
            with pytest.raises(AnsibleValidationErrorMultiple) as e:
                ArgumentSpecValidator(argument_spec)
            assert e.value.messages == [
                "Mutually exclusive parameters: arg1, arg2",
            ]

    argument_spec = {
        "arg1": {"required": True, "type": "str", "mutually_exclusive": ["arg2"]},
        "arg2": {"required": True, "type": "str", "mutually_exclusive": ["arg1"]},
    }

    do_test(legal=False)

    argument_spec["arg2"]["mutually_exclusive"] = []
    do_test(legal=True)

    # This is not the

# Generated at 2022-06-20 15:42:01.123365
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # When:
    parameters = {"parameter1": "value1", "parameter2": "value2"}
    validation_result = ValidationResult(parameters)

    # Then:
    assert validation_result._validated_parameters == parameters
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:42:10.186948
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # 'simple' argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    # 'parameters' for this argument spec
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # create validator from argument spec
    validator = ModuleArgumentSpecValidator(argument_spec, required_if=[["age", "42", ["name"]]])
    # validate parameters
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:42:17.066020
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'host': {'type': 'str', 'default': 'localhost'},
        'port': {'type': 'int', 'default': 22},
        'name': {'type': 'str', 'aliases': ['full_name'], 'version_added': '1.1'},
        'passwd': {'type': 'str', 'no_log': True},
    }

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {'host': 'localhost', 'full_name': 'Lucy'}
    result = validator.validate(parameters)
    # print(result.errors.messages)
    assert result.errors.messages == []

# Generated at 2022-06-20 15:42:27.744892
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class fakeValidationResult:
        def __init__(self, _validated_parameters):
            self._validated_parameters = _validated_parameters

    class fakeValidator(ArgumentSpecValidator):
        def __init__(self, _mutually_exclusive):
            self._mutually_exclusive = _mutually_exclusive

    validator = fakeValidator(None)
    result = validator.validate({'a': 'aarg', 'b': 'barg'})

    assert isinstance(result, ValidationResult)
    assert isinstance(result.validated_parameters, dict)
    assert result.validated_parameters == {'a': 'aarg', 'b': 'barg'}

    result = validator.validate({'c': 'carg'})

# Generated at 2022-06-20 15:42:52.148870
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.parsing import from_json
    from ansible.module_utils.common.parameters import MODULE_ARGUMENT_SPEC
    import argparse
    import json

    parser = argparse.ArgumentParser()
    parser.add_argument('--json', type=json.loads)

    args = parser.parse_args()

    validator = ArgumentSpecValidator(MODULE_ARGUMENT_SPEC)
    params = validator.validate(from_json(args.json))

    print(json.dumps(params, indent=2))

# Generated at 2022-06-20 15:42:56.543738
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    expected = {'type': 'dict', 'options': {'name': {'required': False, 'type': 'str'}}, 'required': False}

    v = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert v.argument_spec == expected

# Generated at 2022-06-20 15:43:03.995750
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # test a source of info errors
    def _validate_argument_types_fake(argument_spec, parameters, errors=None):
        raise TypeError('wrong type')

    _ADDITIONAL_CHECKS[0]['func'] = _validate_argument_types_fake
    argument_spec = {'arg': {'type': 'list'}}
    parameters = {'arg': 'foo'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.error_messages

    del _ADDITIONAL_CHECKS[0]

# Generated at 2022-06-20 15:43:11.044745
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(
        {
            'name': {
                'type': 'str',
            },
        },
    )

    parameters = {
        'name': 'bo',
    }

    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert len(result.unsupported_parameters) == 0
    assert result.validated_parameters == parameters


# Generated at 2022-06-20 15:43:16.268885
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages is None
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:43:21.016121
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator()
    except TypeError:
        pass
    except Exception as exc:
        assert False, "raising {0} instead of TypeError".format(repr(exc))
    else:
        assert False, "not raising TypeError"

# Generated at 2022-06-20 15:43:21.907242
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(argument_spec={})

# Generated at 2022-06-20 15:43:31.517222
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    alias = {
        'option': 'test_option',
        'alias': 'test_alias',
    }
    deprecation = {
        'name': 'test_name',
        'version': '2.0',
        'date': '2020-01-01',
        'collection_name': 'test_col',
    }

    argument_spec = {}
    parameters = {}
    validator = ModuleArgumentSpecValidator(argument_spec, required_together=[])
    result = validator._validate(parameters)
    assert len(result._warnings) == 0
    assert len(result._deprecations) == 0

    parameters = {'test_option': 'foo'}
    validator = ModuleArgumentSpecValidator(argument_spec, required_together=[])