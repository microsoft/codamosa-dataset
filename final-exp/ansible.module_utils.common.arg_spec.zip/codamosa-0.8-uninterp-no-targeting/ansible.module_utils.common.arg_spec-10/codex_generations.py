

# Generated at 2022-06-20 15:33:52.491668
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-20 15:33:56.314486
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive


# Generated at 2022-06-20 15:34:08.273014
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    parameters = {
        'unknown_param': 'foo',
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert result.errors

# Generated at 2022-06-20 15:34:20.213328
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # sources of argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {
        'name': ['name', 'age'],
        'age': ['name', 'age']
    }

    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive,
        required_together,
        required_one_of,
        required_if,
        required_by
    )

    # source of parameters
    parameters

# Generated at 2022-06-20 15:34:29.218319
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.error_messages == []

# Generated at 2022-06-20 15:34:36.915689
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    if PY3:
        from ansible.module_utils._text import to_bytes as to_native
    else:
        from ansible.module_utils._text import to_text as to_native

    validator = ModuleArgumentSpecValidator({
        'a': {'type': 'str'},
        'b': {'type': 'str', 'aliases': ['c']},
    },
        mutually_exclusive=[
            ['a', 'b']
        ],
    )

    # test validation
    result = validator.validate(args={'a': 'foo', 'b': 'bar'})


# Generated at 2022-06-20 15:34:49.752834
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:34:54.940706
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({})
    alias_errors = []
    for params in [
        {'name': 'bo'},
        {'age': '42'},
    ]:
        result = validator.validate(params)
        if result.errors:
            alias_errors.append(result.errors)

    if alias_errors:
        print(', '.join(alias_errors))

if __name__ == '__main__':
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-20 15:35:02.870930
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = {
        'name': 'bo',
        'age': '42',
    }
    vr = ValidationResult(params)
    assert isinstance(vr, ValidationResult)
    assert isinstance(vr.errors, AnsibleValidationErrorMultiple)
    assert not vr.errors
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr.validated_parameters == params


# Generated at 2022-06-20 15:35:04.740594
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True, "ArgumentSpecValidator_validate method needs to be tested, please create a test for it"

# Generated at 2022-06-20 15:35:11.548716
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # This is the place for any tests for the constructor of ValidationResult
    assert True

# Generated at 2022-06-20 15:35:20.943257
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test ArgumentSpecValidator validation.

    Test the validation in AnsibleModule.validate.

    :returns: A dictionary containing the results of the unit test.  This will
        always be True as a failed test will raise an exception.
    :rtype: `dict`
    """

# Generated at 2022-06-20 15:35:21.501109
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:35:26.324074
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'a': 123})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []


# Generated at 2022-06-20 15:35:33.054467
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec=spec)
    result = validator.validate({'name': 'bo', 'age': '42'})

    assert not result.error_messages
    assert 'bo' == result._validated_parameters['name']
    assert 42 == result._validated_parameters['age']

# Generated at 2022-06-20 15:35:39.303820
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-20 15:35:44.942195
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Check constructor of ModuleArgumentSpecValidator and ArgumentSpecValidator
    # checks module_utils.common.arg_spec.ArgumentSpecValidator
    # pylint: disable=invalid-name
    v = ModuleArgumentSpecValidator({'a': {'type': 'int'}})
    assert isinstance(v, ArgumentSpecValidator)
    # pylint: enable=invalid-name

# Generated at 2022-06-20 15:35:55.593168
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    unit test for constructor of class ArgumentSpecValidator
    '''
    input_argument_spec = dict(
        param1=dict(type='str'),
        param2=dict(type='int', default=42)
    )
    mutually_exclusive = ['param1', 'param2']
    required_together = [['param1', 'param2']]
    required_one_of = [['param1', 'param2']]
    required_if = [['param1', 'param2']]
    required_by = {'param1': ['param2']}

    test_obj = ArgumentSpecValidator(
        input_argument_spec,
        mutually_exclusive,
        required_together,
        required_one_of,
        required_if,
        required_by,
    )

    assert test_obj._

# Generated at 2022-06-20 15:35:57.133323
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({})

    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:36:03.785790
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    validator = ArgumentSpecValidator({'key': {'type': 'str'}})
    result = validator.validate({'key': 'value'})
    assert result.validated_parameters == {'key': 'value'}
    assert result.errors.messages == []
    assert result.error_messages == []
    assert result.validated_parameters == {'key': 'value'}
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:36:18.796423
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # test multiple required_if parameters
    argument_spec = {"test": {"required_if": [("arg1", "val1", ['arg2', 'arg3'])]}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator._required_if == [("arg1", "val1", ['arg2', 'arg3'])]

    # test single required_if parameters
    argument_spec = {"test": {"required_if": ("arg1", "val1", ['arg2', 'arg3'])}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator._required_if == [("arg1", "val1", ['arg2', 'arg3'])]

    # test empty required_if parameters
    argument_spec = {"test": {"required_if": ()}}

# Generated at 2022-06-20 15:36:25.329033
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # This constructor should not fail.
    ModuleArgumentSpecValidator({'argument1': {'type': 'str'}},
                                mutually_exclusive=[['argument1', 'argument2']],
                                required_one_of=[['argument1']],
                                required_if=[['argument1', 'value1', ['argument2']]],
                                required_together=[['argument1', 'argument2', 'argument3']],
                                required_by={'argument1': ['argument2']})


# Generated at 2022-06-20 15:36:29.049106
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)



# Generated at 2022-06-20 15:36:34.577561
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    new_ModuleArgumentSpecValidator = ModuleArgumentSpecValidator(
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={},
        argument_spec={},
    )
    assert(new_ModuleArgumentSpecValidator is not None)

# Generated at 2022-06-20 15:36:45.533306
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {'name': {'type': 'str'}}
    argument_spec_validator = ArgumentSpecValidator(argument_spec=arg_spec)
    assert argument_spec_validator.argument_spec == arg_spec
    assert argument_spec_validator._mutually_exclusive is None
    assert argument_spec_validator._required_together is None
    assert argument_spec_validator._required_one_of is None
    assert argument_spec_validator._required_if is None
    assert argument_spec_validator._required_by is None
    assert argument_spec_validator._valid_parameter_names == {'name'}

    arg_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [['name', 'age']]

# Generated at 2022-06-20 15:36:51.345075
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {
            'type': 'int',
            'required': True,
            'default': 99,
        },
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    # {'name': 'Cartman', 'age': 'SIX!'}
    results = validator.validate({'name': 'Cartman', 'age': 'SIX!'})
    assert results.validated_parameters['name'] == 'Cartman'
    assert results.validated_parameters['age'] == 99
    assert results.errors
    assert isinstance(results.errors[0], MutuallyExclusiveError)

# Generated at 2022-06-20 15:36:52.341550
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:37:01.984307
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys # noqa F401

    class FakeResult:
        validated_parameters = {'name': 'bo', 'age': 42}
        _warnings = []
        _deprecations = []
        errors = []

    class FakeValidator:
        def __init__(self, *args, **kwargs):
            pass

        def validate(self, parameters):
            return FakeResult()

    original_args = sys.argv
    sys.argv = ['ansible-fake-script']
    import ansible.module_utils.common.arg_spec as arg_spec
    arg_spec._ArgumentSpecValidator = FakeValidator

    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # test call of method validate

# Generated at 2022-06-20 15:37:05.179912
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    v = ArgumentSpecValidator(argument_spec={'test_key': {'type': 'int', 'required': False}})
    result = v.validate({'test_key': '3'})
    assert result.validated_parameters['test_key'] == 3



# Generated at 2022-06-20 15:37:10.606684
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """ unit test for constructor of class ArgumentSpecValidator """
    import json

    test_validator = ArgumentSpecValidator({"name": {"type": "str"}})

    assert test_validator.argument_spec == {"name": {"type": "str"}}
    assert test_validator._valid_parameter_names == {"name"}

    assert json.loads(str(test_validator)) == {"argument_spec": {"name": {"type": "str"}}}

# Generated at 2022-06-20 15:37:21.340356
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == {'name', 'age'}

# Generated at 2022-06-20 15:37:25.502301
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.errors
    assert result.validated_parameters == parameters



# Generated at 2022-06-20 15:37:32.447078
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    for i in range(200):
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }

        parameters = {
            'name': 'bo',
            'age': '42',
        }

        validator = ArgumentSpecValidator(argument_spec)
        result = validator.validate(parameters)


# Generated at 2022-06-20 15:37:41.697461
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', 'height', 'weight']]
    required_by = {
        'name': ['age'],
        'age': ['name'],
    }


# Generated at 2022-06-20 15:37:44.795340
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Setup
    argument_spec = {}
    # Code to be tested
    validator = ModuleArgumentSpecValidator(argument_spec)
    # Assertions
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:37:54.535675
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Testing if function attribute checked required_one_of is called, when assigned in __init__
    class CheckRequiredOneOf():
        def __init__(self):
            self.call_count = 0

        def check(self, required_one_of, parameters):
            self.call_count = self.call_count + 1
    class CheckRequiredIf():
        def __init__(self):
            self.call_count = 0

        def check(self, required_if, parameters):
            self.call_count = self.call_count + 1

    # class CheckMutuallyExclusive and CheckRequiredArguments are not tested here, as they are
    # expected to be called using getattr of the base class

    argument_spec = {'param1': {'type': 'int'}}
    parameters = dict()
    validator = ArgumentSpecValid

# Generated at 2022-06-20 15:38:01.444501
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age':  {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    print(result.error_messages)

if __name__ == '__main__':
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-20 15:38:06.332826
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    class A:
        def __init__(self):
            self.argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        def validate(self, parameters):
            validator = ArgumentSpecValidator(self.argument_spec)
            result = validator.validate(parameters)
            return result

# Generated at 2022-06-20 15:38:14.931516
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    print("Testing ValidationResult class")
    result = ValidationResult({'myparam' : 'myvalue'})
    assert result._validated_parameters == {'myparam' : 'myvalue'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.validated_parameters == {'myparam' : 'myvalue'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:38:21.585108
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0

    valid_params = result.validated_parameters


# Generated at 2022-06-20 15:38:33.773071
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # pylint: disable=line-too-long
    """Test validate on a simple argument spec and a set of parameters.

    The parameters will be validated against the argument spec for type and value
    correctness.

    The parameter list should be a dictionary containing all the arguments
    expected by the module, including those related to the connection plugin
    (ansible_*), check mode (check_mode), and no log (no_log).

    Note that this is just for unit testing purposes and not meant to be used by
    modules directly.
    """

    # pylint: enable=line-too-long


# Generated at 2022-06-20 15:38:43.109077
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {'a': {'type': 'str'}, 'b': {'type': 'str'}}
    validate = ModuleArgumentSpecValidator(spec)

    # Normal test
    params = {'a': 'string_a', 'b': 'string_b'}
    result = validate.validate(params)

    assert result.validated_parameters['a'] == 'string_a'
    assert result.validated_parameters['b'] == 'string_b'

    # Test option and alias
    params = {'a': 'string_a', 'b': 'string_b', 'c': 'string_c'}
    result = validate.validate(params)

    assert result.validated_parameters['a'] == 'string_a'

# Generated at 2022-06-20 15:38:53.517973
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    adict = {"vol_id": {"type": "str"},
             "user": {"type": "str", "aliases": ["user_name"]},
             "password": {"type": "str", "no_log": True},
             }


# Generated at 2022-06-20 15:38:54.642570
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: Implement this test
    pass

# Generated at 2022-06-20 15:38:57.595261
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    f = ModuleArgumentSpecValidator({})
    r = f.validate({'test': 'Failed'})
    assert r.validated_parameters == {'test': 'Failed'}

# Generated at 2022-06-20 15:39:02.326376
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    with pytest.raises(AnsibleModuleTestWarning) as excinfo:
        validator = ModuleArgumentSpecValidator({'name': {'aliases': ['name1']}}, {'name1': 'name'})
        result = validator.validate({'name': 'test', 'name1': 'test1'})

    assert 'Both option name and its alias name1 are set.' in str(excinfo.value)

# Generated at 2022-06-20 15:39:13.625952
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    class MockResult():
        def __init__(self, errors):
            self.errors = errors
    # Test alias
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'bruce': True
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

    result = MockResult([AliasError("'bruce' is not a valid parameter for this module")])
    assert validator.validate(parameters) == result

    result = MockResult([])
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    assert validator.validate(parameters) == result



# Generated at 2022-06-20 15:39:16.928203
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'foo':'bar'}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters['foo'] == 'bar'


# Generated at 2022-06-20 15:39:17.943005
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-20 15:39:25.348761
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive_list = ['name', 'age']
    required_together_list = [['name', 'age']]
    required_one_of_list = [['name', 'age']]
    required_if_list = [['name', 'foo', ['age']]]
    required_by_dict = {'name': ['age']}

    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'},
                     }
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive_list, required_together=required_together_list, required_one_of=required_one_of_list, required_if=required_if_list, required_by=required_by_dict)

# Generated at 2022-06-20 15:39:42.325501
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:39:44.987825
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={})
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:39:55.820724
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Unit test function for class ArgumentSpecValidator
    """
    argument_spec = {
        'src': {'type': 'path'},
        'dest': {'type': 'path'},
        'recursive': {'type': 'bool', 'default': True},
        'owners': {'type': 'bool'},
        'content': {'type': 'bool'},
        'mode': {'type': 'bool'},
        'group': {'type': 'bool'},
        'others': {'type': 'bool'},
        'checksum': {'type': 'bool'},
    }

    validator = ArgumentSpecValidator(argument_spec)

# Generated at 2022-06-20 15:40:05.916923
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator({'foo': {'type': 'str'}}), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'foo': {'type': 'str'}}, mutually_exclusive=['foo']), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'foo': {'type': 'str'}}, required_together=['foo']), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'foo': {'type': 'str'}}, required_one_of=['foo']), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'foo': {'type': 'str'}}, required_if=['foo']), ArgumentSpecValidator)

# Generated at 2022-06-20 15:40:10.302191
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', },
        'age': {'type': 'int'},
        'state': {
            'type': 'str',
            'default': 'present',
            'choices': ['present', 'absent', 'enabled', 'disabled'],
        },
    }
    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'state': 'present'}
    assert result.error_messages == []


# Generated at 2022-06-20 15:40:17.002701
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import _validate_argument_types
    from ansible.module_utils.common.arg_spec import _validate_argument_values
    from ansible.module_utils.common.arg_spec import check_required_arguments
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.arg_spec import _handle_aliases
    from ansible.module_utils.common.arg_spec import _set_defaults
    from ansible.module_utils.common.arg_spec import _list_no_log_values
    from ansible.module_utils.common.arg_spec import _validate_sub_spec
    from ansible.module_utils.common.arg_spec import _get_unsupported_

# Generated at 2022-06-20 15:40:27.566799
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    class TestClass(object):
        pass

    test_class = TestClass()

    # Parameters: dict[str, dict]

    # Return type: ValidationResult

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    test_class.argument_spec = argument_spec
    test_class.mutually_exclusive = mutually_exclusive
    test_class.required_together = required_together
    test_class.required_one_of = required_one_of

# Generated at 2022-06-20 15:40:30.273722
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'a': '1', 'b': 2}
    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:40:32.874745
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"FORCED": "bo", "OTHER": "42"}
    result = ValidationResult(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == parameters

# Generated at 2022-06-20 15:40:33.658720
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult



# Generated at 2022-06-20 15:40:53.208482
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # unit test for method `ArgumentSpecValidator.validate`
    # in success case it returns validated parameters
    # in error case it returns errors
    class ArgumentSpecValidatorStub(ArgumentSpecValidator):
        def __init__(self, result):
            self.result = result

        def validate(self, parameters):
            return self.result

    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidatorStub(parameters)
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters

# Generated at 2022-06-20 15:40:57.783139
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == {'age': 42, 'name': 'bo'}
    assert not result.errors

# Generated at 2022-06-20 15:41:09.013396
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    for args in [[],
                 [{}],
                 [{}, [], [], []],
                 [{}, [], [], [], []]]:
        try:
            ArgumentSpecValidator(*args)
            raise AssertionError('ArgumentSpecValidator() did not raise exception when passed {}'.format(args))
        except TypeError:
            pass


# Generated at 2022-06-20 15:41:13.823174
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'bar': {'type': 'str'}, 'foo': {'type': 'list'}}
    parameters = {'bar': 'hello', 'foo': []}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.warnings == []
    assert result.validated_parameters == parameters
    assert result.error_messages == []

# Generated at 2022-06-20 15:41:16.082824
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator({})
    assert isinstance(result, ModuleArgumentSpecValidator)
    assert isinstance(result, ArgumentSpecValidator)


# Generated at 2022-06-20 15:41:25.390427
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test constructor of class ModuleArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)
    result = validator.validate(parameters)

# Generated at 2022-06-20 15:41:32.018201
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    module = AnsibleModule(argument_spec=argument_spec)
    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert not result.errors

# Generated at 2022-06-20 15:41:38.260925
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:41:49.220044
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'mass': {'type': 'int'},
        'height': {'type': 'int'},
    }

    mutually_exclusive = [['mass', 'height']]
    required_together = [['mass', 'height']]
    required_one_of = [['mass', 'height']]
    required_if = [['mass', 3, ['height']]]
    required_by = {'mass': ['height']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of,
                                      required_if, required_by)

    assert validator._mutually_exclusive == [['mass', 'height']]
    assert validator._required_together == [['mass', 'height']]

# Generated at 2022-06-20 15:41:54.345834
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutual_exclude = [["my_param", "my_param2"]]
    argument_spec = {
        "my_param": {"type": "str"},
        "my_param2": {"type": "str"},
    }
    validator = ModuleArgumentSpecValidator(
        argument_spec=argument_spec,
        mutually_exclusive=mutual_exclude,
    )
    assert validator
    assert validator._mutually_exclusive == mutual_exclude

# Generated at 2022-06-20 15:42:27.024703
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'Joe', 'age': '42'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result.errors == AnsibleValidationErrorMultiple()
    assert not result._unsupported_parameters


# Generated at 2022-06-20 15:42:36.808897
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-20 15:42:43.981150
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    from ansible.module_utils.six import iteritems

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {
            'type': 'dict',
            'options': {
                'city': {'type': 'str'},
                'street': {'type': 'str'},
                'numbers': {
                    'type': 'list',
                    'elements': 'int'
                }
            }
        }
    }

# Generated at 2022-06-20 15:42:53.609846
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:42:59.819770
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    param = ''
    arg_spec = 'x'
    mut_excl = 'y'
    req_together = 'z'

    result = ModuleArgumentSpecValidator(param, arg_spec, mut_excl, req_together)
    assert result._mutually_exclusive == 'y'
    assert result._required_together == 'z'
    assert result.argument_spec == 'x'

# Generated at 2022-06-20 15:43:04.957620
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [["name", "age"]]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == parameters

# Generated at 2022-06-20 15:43:15.194490
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    _validate_argument_types.counter = 0

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    parameters = {
        'name': 'bo',
        'age': 42,
        }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

    # return_validated_parameters
    assert result.validated_parameters == parameters

    # return_unsupported_parameters
    assert result.unsupported_parameters == set()

    # check _validate_argument_types
    assert _validate_argument_types.counter == 2

# Generated at 2022-06-20 15:43:26.045001
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""
    argspec_validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42, 'required': True},
        'no_log': {'type': 'bool', 'default': False, 'no_log': True},
    })
    validated_parameters = argspec_validator.validate({
        'name': 'Fred',
        'age': '42',
    })

    assert len(validated_parameters.errors.messages) == 0
    assert validated_parameters.validated_parameters['name'] == 'Fred'
    assert validated_parameters.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:43:29.244362
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'ansible_test': 'test'}
    result = ValidationResult(parameters)
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {'ansible_test': 'test'}

# Generated at 2022-06-20 15:43:35.360218
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hosts': {'type': 'list'}
    }

    parameters1 = {'name': 'bo', 'age': '42', 'hosts': ['test-a', 'test-b']}
    parameters2 = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result1 = validator.validate(parameters1)
    assert result1.validated_parameters == parameters1
    assert result1.unsupported_parameters == set()
    assert result1.error_messages == []
    assert result1.validated_parameters['name'] == 'bo'
    assert result1.validated_parameters