

# Generated at 2022-06-20 15:33:58.949318
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters = {"param_1" : "one"})
    assert result._validated_parameters["param_1"] == 'one'


# Generated at 2022-06-20 15:34:01.630634
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    instance = ModuleArgumentSpecValidator(argument_spec={})
    assert isinstance(instance, ModuleArgumentSpecValidator)
    assert isinstance(instance, ArgumentSpecValidator)


# Generated at 2022-06-20 15:34:13.101371
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Set up the object.
    argspec = {'key1': {'required': True, 'type': 'str'}}
    validator = ModuleArgumentSpecValidator(argspec)

    # Test the object
    assert validator.argument_spec == argspec
    assert validator._unsupported_parameters == set()
    assert validator._required_by == None
    assert validator._required_if == None
    assert validator._mutually_exclusive == None
    assert validator._required_one_of == None
    assert validator._required_together == None
    assert len(validator._validated_parameters) == 0

# Unit tests for class ModuleArgumentSpecValidator.validate

# Generated at 2022-06-20 15:34:17.456181
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert set(result.validated_parameters) == set(parameters)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:34:26.407776
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # case that the parameter contain one of the argument
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_native
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    # case that the parameter contain both of the argument
    assert type(result) == ValidationResult
    assert (result.validated_parameters) == {'name': 'bo', 'age': 42}

    # case that the parameter contain both of the argument

# Generated at 2022-06-20 15:34:32.200413
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0

# Generated at 2022-06-20 15:34:35.514033
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    v = ModuleArgumentSpecValidator({'a': {'type': 'str'}})
    assert v.argument_spec == {'a': {'type': 'str'}}

# Generated at 2022-06-20 15:34:48.374726
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # unit tests don't have warnings module
    if False:
        import warnings

    argument_spec = {
        'name': {'type': 'str', 'aliases': ['full name']},
        'age': {'type': 'int'},
        'deprecated_alias': {'type': 'str',
                             'deprecated': {'collection_name': 'my_collection',
                                            'removed_in': '5.5',
                                            'why': 'to make a test',
                                            'alternative': 'new_alias'}},
    }

    parameters = {
        'name': 'bo',
        'full name': 'yes',
        'age': '42',
        'deprecated_alias': 'deprecated',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-20 15:34:56.328574
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    aspec = {'age': {'required':True, 'type':'int'}, 'name': {'required': True, 'type':'str'}}
    mutually_exclusive = [['a', 'b'], ['c', 'd']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['age', 10, ['name']]]
    required_by = {'name':['age']}
    validator = ArgumentSpecValidator(aspec, mutually_exclusive=mutually_exclusive, required_together=required_together,
                                      required_one_of=required_one_of, required_if=required_if, required_by=required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator

# Generated at 2022-06-20 15:35:04.315198
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=[])
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()

# Generated at 2022-06-20 15:35:13.766573
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'term':{'type':'str'}})
    res = validator.validate({'term':'value'})
    assert res.validated_parameters['term'] == 'value'

# Generated at 2022-06-20 15:35:22.221546
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible_collections.nordstrom.cloud_foundry.tests.unit.module_utils.common.arg_spec import ArgumentSpecValidator as testmodule

    """Ensure ArgumentSpecValidator.validate return correct results"""

    def check_result(result, expected_validated_parameters, expected_error_messages):
        assert(result.validated_parameters == expected_validated_parameters)
        assert(result.error_messages == expected_error_messages)

    simple_arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    simple_parameters = {
        'name': 'bo',
        'age': '42',
    }

    simple_validator = testmodule(simple_arg_spec)
   

# Generated at 2022-06-20 15:35:33.681626
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    import sys

    # Example for simple module
    # -------------------------

    argument_spec_1 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters_1 = {
        'name': 'bo',
        'age': '42',
    }

    validator_1 = ArgumentSpecValidator(argument_spec_1)
    result_1 = validator_1.validate(parameters_1)

    if result_1.error_messages:
        sys.exit("Validation failed: {0}".format(result_1.error_messages))

    valid_params_1 = result_1.validated_

# Generated at 2022-06-20 15:35:41.734595
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.error_messages == [])


# Generated at 2022-06-20 15:35:44.744939
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult(parameters='example')
    assert isinstance(v._validated_parameters, dict)
    assert v._validated_parameters == 'example'


# Generated at 2022-06-20 15:35:47.486507
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    val = ArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    )
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    val.validate(parameters)

# Generated at 2022-06-20 15:35:52.946950
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'hello': 'world'}
    assert parameters == ValidationResult(parameters)._validated_parameters
    assert set() == ValidationResult(parameters)._no_log_values
    assert set() == ValidationResult(parameters)._unsupported_parameters
    assert AnsibleValidationErrorMultiple() == ValidationResult(parameters).errors


# Generated at 2022-06-20 15:36:01.035545
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'colors': {'type': 'list', 'elements': 'str', 'default': []},
    }
    mutually_exclusive = [
        ['a', 'b'],
        ['c', 'd', 'e'],
    ]
    required_together = [
        ['a', 'b'],
        ['c', 'd', 'e'],
    ]
    required_one_of = [
        ['a', 'b'],
        ['c', 'd', 'e'],
    ]
    required_if = [
        ['a', 42, ['b']],
        ['c', 'd', ['e']],
    ]

# Generated at 2022-06-20 15:36:07.903230
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', None, ['age']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)

    result = validator.validate({'name': 'bo', 'age': 42})


# Generated at 2022-06-20 15:36:14.222196
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'foo': 'bar'}

    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == list()
    assert result._warnings == list()
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors._errors == []



# Generated at 2022-06-20 15:36:23.204884
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {'name': 'bo', 'age': '42'}
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameter)

    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:36:26.024331
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}})
    assert validator.validate({'name': 'foo'}).validated_parameters == {'name': 'foo'}

# Generated at 2022-06-20 15:36:28.197793
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator.validate(parameters)
    assert result is None
    return result

# Generated at 2022-06-20 15:36:29.327216
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'foo': 'bar'})

# Generated at 2022-06-20 15:36:39.914468
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initialize validator
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
        required_one_of, required_if, required_by)

    # Initialize parameters
    parameters = {'name': 'bo', 'age': '42'}

    # call method
    result = validator.validate(parameters)

    # check that no errors were encountered
    assert not result.errors

    # check that output was correct

# Generated at 2022-06-20 15:36:47.622708
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class AnsibleModule"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name']]]
    required_by = {'name': ['age']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:36:54.356709
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name']

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-20 15:37:00.844275
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str', 'default': 'bo'},
        'age': {'type': 'int', 'default': 42, 'required': True},
    }

    parameters = {
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-20 15:37:04.007903
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)

    assert result._validated_parameters == {
        'name': 'bo',
        'age': '42'
        }



# Generated at 2022-06-20 15:37:11.950719
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Initialize the ValidationResult class
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)
    # Check the types of the attributes
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    return True



# Generated at 2022-06-20 15:37:19.568824
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Sanity Checks
    with pytest.raises(Exception):
        ModuleArgumentSpecValidator('hello')
    result = ModuleArgumentSpecValidator(argument_spec={})

    # Functionality
    assert isinstance(result.validate({}), ValidationResult)



# Generated at 2022-06-20 15:37:25.238027
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test for method validate of class ArgumentSpecValidator. """

    # Validate nested argument spec
    argument_spec = {
        'test': {'type': 'dict', 'options':
            {'name': {'type': 'str'},
            'age': {'type': 'int'},
            'list': {'type': 'list', 'options': {'type': 'str'}},
            }
        }
    }

    # Valid parameters
    parameters = {
        'test': {
            'name': 'bo',
            'age': 42,
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages, "validate() failed: {0}".format(result.error_messages)

# Generated at 2022-06-20 15:37:28.856121
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    test = ArgumentSpecValidator(argument_spec)


# Generated at 2022-06-20 15:37:30.369285
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:37:38.754356
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.connection import Connection

    argument_spec = {'firstarg': {'type': 'str', 'default': 'hello'},
                     'secondarg': {'type': 'list'},
                     'thirdarg': {'type': 'dict', 'default': {'hello': 'world'}},
                     'fourtharg': {'type': 'int'},
                     'fiftharg': {'type': 'bool'},
                     'sixtharg': {'type': 'list', 'elements': 'int'},
                     'seventharg': {'type': 'dict', 'options': {'a': {'type': 'int'}}}}

    module = Connection(argument_spec=argument_spec)
    result = module._argument_spec_validator.valid

# Generated at 2022-06-20 15:37:51.291328
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:37:58.667831
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_data = {
        'validation_result_1': {
            'name': 'Jim',
            'age': 42
        }
    }
    validation_result = ValidationResult(test_data)

    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == test_data
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-20 15:38:05.552920
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    test_case = [
        {},
        {'name': 'bo', 'age': '42'}
    ]
    validator = ModuleArgumentSpecValidator(spec)
    for param in test_case:
        result = validator.validate(param)

    assert result.error_messages == []

# Generated at 2022-06-20 15:38:12.800939
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:38:22.574058
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator"""

# Generated at 2022-06-20 15:38:34.854546
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age']}

    spec_validator = ArgumentSpecValidator(argument_spec,
                                           mutually_exclusive=mutually_exclusive,
                                           required_together=required_together,
                                           required_one_of=required_one_of,
                                           required_if=required_if,
                                           required_by=required_by,)

    assert spec

# Generated at 2022-06-20 15:38:36.892330
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    parser = ModuleArgumentSpecValidator({"sample": {'type': 'str'}})
    assert(isinstance(parser, ArgumentSpecValidator))

# Generated at 2022-06-20 15:38:45.767811
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test method ``validate`` of class ``ModuleArgumentSpecValidator``

    Check :class:`~ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator` to get more details.

    :return: None
    """

    # simple test for alias
    spec = {
        "FOO": {"type": "str",
                "aliases": ["foo"]},
        "BAR": {"type": "str"}
    }
    params = {"FOO": "oops"}

    validator = ModuleArgumentSpecValidator(spec)
    validated = validator.validate(params)
    assert len(validated.errors) == 0
    assert validated.validated_parameters == {'foo': 'oops'}
    assert validated.unsupported_parameters == set()


# Generated at 2022-06-20 15:38:49.390110
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator

# Generated at 2022-06-20 15:38:54.069360
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    param = {'version': 'fake_version', 'collection_name': 'fake_collection', 'name': 'fake_name', 'date': 'fake_date'}
    result = validator.validate({})
    for d in result._deprecations:
        assert d == param

# Generated at 2022-06-20 15:38:56.118377
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})

# Generated at 2022-06-20 15:39:04.416926
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator({'name': {}, 'age': {}}), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'name': {}, 'age': {}}, mutually_exclusive=[[1, 2]]), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'name': {}, 'age': {}}, required_together=[[1, 2]]), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'name': {}, 'age': {}}, required_one_of=[[1, 2]]), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator({'name': {}, 'age': {}}, required_if=[[1, 2, [3, 4]]]), ArgumentSpecValidator)

# Generated at 2022-06-20 15:39:05.947553
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({'name': {'type': 'str'}})

# Generated at 2022-06-20 15:39:11.978749
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.basic import ModuleDeprecationWarning
    with warn(catch_warnings=True) as w:
        validator = ModuleArgumentSpecValidator(
            {
                'name': {'type': 'str', 'aliases': ['name_0']},
            },
            mutually_exclusive=[[['name', 'name_0']]],
        )

        assert Validat

# Generated at 2022-06-20 15:39:20.856265
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.deprecation import deprecation_message
    from ansible.module_utils.common.warnings import WarningMessage
    import ansible.module_utils.common.validation
    ansible.module_utils.common.validation.check_mutually_exclusive = lambda *args: None
    ansible.module_utils.common.validation.check_required_arguments = lambda *args: None

    DEPRECATED_ALIAS = {
        'name': 'age',
        'version': 'v2.10',
        'date': '2032-11-03',
        'collection_name': 'collection'
    }


# Generated at 2022-06-20 15:39:26.473119
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    assert isinstance(ModuleArgumentSpecValidator({}), ArgumentSpecValidator)

# Generated at 2022-06-20 15:39:33.066690
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Create a ArgumentSpecValidator
    module_argument_spec_validator = ModuleArgumentSpecValidator({})
    assert isinstance(module_argument_spec_validator, ArgumentSpecValidator)

    # Create a ModuleArgumentSpecValidator
    module_argument_spec_validator = ModuleArgumentSpecValidator({})
    assert isinstance(module_argument_spec_validator, ModuleArgumentSpecValidator)



# Generated at 2022-06-20 15:39:42.663590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test validation with both option and a corresponding alias are set
    spec = {
        'name': dict(type='str', aliases=['fullname']),
        'age': dict(type='int')
    }

    kwargs = dict(
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None
    )

    parameters = {
        'name': 'Bob',
        'fullname': 'Bob'
    }

    results = ModuleArgumentSpecValidator(spec, **kwargs).validate(parameters)

    assert 'Both option name and its alias fullname are set.' in results.warnings


# Generated at 2022-06-20 15:39:53.197872
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # The argument_spec is the example provided in the docstring of ArgumentSpecValidator.validate.
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by,
                                      )

    # Parameters to validate against the argument spec
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # result should be a ValidationResult instance containing validated parameters

# Generated at 2022-06-20 15:39:59.295826
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'subspec': {
            'type': 'dict',
            'subspec': {
                'attr1': {'type': 'str'},
                'attr2': {'type': 'str'},
            },
        },
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'subspec': {
            'attr1': 1,
            'attr2': 2,
        }
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-20 15:40:05.917942
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert (ValidationResult({"name": "bo"}).validated_parameters == {"name": "bo"})
    assert (ValidationResult({"name": "bo"})._no_log_values == set())
    assert (ValidationResult({"name": "bo"})._unsupported_parameters == set())
    assert (ValidationResult({"name": "bo"})._deprecations == [])
    assert (ValidationResult({"name": "bo"})._warnings == [])
    assert (ValidationResult({"name": "bo"}).errors == AnsibleValidationErrorMultiple())


# Generated at 2022-06-20 15:40:14.518522
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""

    # Create an instance of ArgumentSpecValidator class
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'age': {'type': 'int', 'required': True},
        'address': {'type': 'str', 'required': True},
        'email': {'type': 'str', 'required': True}
    }

    mutually_exclusive = [['name', 'age']]

    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive)

    # Validate arguments by passing argument spec, mutually exclusive parameters
    # and actual parameters

    # When all required parameters are passed,
    # validation should succeed and should not
    # raise any exceptions

    # Parameters as list
    parameters

# Generated at 2022-06-20 15:40:21.209495
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}).validated_parameters == {}
    assert ValidationResult({}).errors.messages == []
    assert ValidationResult({}).unsupported_parameters == set()
    assert ValidationResult({})._no_log_values == set()
    assert ValidationResult({'test_key': 'test_value'}).validated_parameters == {'test_key': 'test_value'}



# Generated at 2022-06-20 15:40:30.599746
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class ArgumentSpecValidatorTest:
        def test(self, argument_spec, parameters):
            validator = ArgumentSpecValidator(argument_spec,
                mutually_exclusive=[['name', 'age']],
                required_together=[['name', 'age']])
            result = validator.validate(parameters)
            return (result.error_messages, result.validated_parameters)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    expected = ([], {'age': 42, 'name': 'bo'})
    result = ArgumentSpecValidatorTest().test(argument_spec,parameters)
    assert result == expected



# Generated at 2022-06-20 15:40:34.382017
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert result._unsupported_parameters == set()
    assert result._no_log_values == set()
    assert not result.errors


# Generated at 2022-06-20 15:40:39.111455
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    val = ModuleArgumentSpecValidator(None)
    assert val is not None

# Generated at 2022-06-20 15:40:41.592513
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test constructor of class ArgumentSpecValidator."""
    validator = ArgumentSpecValidator({})
    assert validator is not None

# Generated at 2022-06-20 15:40:51.795366
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str', 'default': 'bo'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_if = [
        ['name', 'bo', ['age']],
    ]
    required_by = {
        'name': ['age'],
    }

# Generated at 2022-06-20 15:40:56.663884
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(
                                argument_spec={"name": {'type': 'str'},
                                               "age": {'type': 'int'},
                                               },
                                mutually_exclusive=["name"],
                                required_together=["age"],
                                required_one_of=[["age"]],
                                required_if=[["age", 42, ["name"]]],
                                required_by={"name": ["age"]},
                                )

# Generated at 2022-06-20 15:41:00.571435
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    data = [
        [
            {'type': 'dict', 'options': {'host': {'required': True, 'type': 'str'}, 'username': {'required': True, 'type': 'str'}, 'password': {'required': True, 'type': 'str'}}},
            {},
            True,
        ],
    ]

    for spec, params, expected_result in data:
        validator = ArgumentSpecValidator(spec)
        result, = validator.validate(params)
        assert expected_result == result

# Generated at 2022-06-20 15:41:11.098015
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Prepare test parameters
    this = {
        "argument_spec": {
            "src": {"type": "path"},
            "dest": {"type": "path"}
        }
    }

    # First test: no warnings and no deprecations
    parameters = {}
    result = ModuleArgumentSpecValidator(**this).validate(parameters)
    assert not result._warnings
    assert not result._deprecations
    assert not result.errors

    # Second test: no warnings
    deprecations = [
        {"name": 'd1', "version": '1.0', "date": 'now', "collection_name": 'ansible.builtin'}
    ]
    this['argument_spec']['dest']['aliases'] = deprecations
    parameters = {"dest": "test"}
    result = ModuleArg

# Generated at 2022-06-20 15:41:19.008819
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a dummy function to mock the reference to __init__
    def func():
        super(ModuleArgumentSpecValidator, self).__init__()

    # Create a class with a mocked method __init__
    class ModuleArgumentSpecValidatorMock(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            func()

    # Moke the __init__ method
    ModuleArgumentSpecValidator._Function__init__ = func

    # Create the object
    args = ['arg1']
    kwargs = {'kwarg1': 'val1'}

    obj = ModuleArgumentSpecValidatorMock(*args, **kwargs)

    # Verify the object returns the expected response

# Generated at 2022-06-20 15:41:23.174225
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'a': {'value': 1}, 'b': {'value': 2}, 'c': {'value': 3}}
    validation_result = ValidationResult(parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == parameters
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == []


# Generated at 2022-06-20 15:41:28.548178
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
        'deprecated_alias': {'type': 'str', 'aliases': ['d']},
        'warn_alias': {'type': 'str', 'aliases': ['w']},
        'sub_arg': {
            'type': 'dict',
            'suboptions': {
                'sub_name': {'type': 'str'}
            }
        }
    }

    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []


# Generated at 2022-06-20 15:41:37.533112
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}, }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set(['age', 'name'])


# Generated at 2022-06-20 15:41:47.384188
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {
        'name': 'Bo Jackson',
        'age': 43,
        'nickname': None,
    }

    result = ValidationResult(parameter)
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameter
    assert result.error_messages == []
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-20 15:41:53.829127
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:42:03.710937
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_native
    class MockModule(object):
        def __init__(self):
            self.argument_spec = {'dst': {'type': 'path'}}
            self.params = {'dst': 'a-/path'}
            self.no_log_values = set()
            self.deprecations = []
            self.warnings = []
            self.fail_json_in_clean = False
            self.fail_json_in_clean_called = False

        def fail_json(self, msg, **kwargs):
            self.fail_json_in_clean_called = True

    class MockValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(MockValidator, self).__

# Generated at 2022-06-20 15:42:08.394682
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator.

    Input: A dict of parameters used in AnsibleModule and a deprecation
    Output: A ValidationResult object it will contain warnings if the key and alias are set together
    """
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    deprecation = {"name": "name"}
    parameters = {"name": "bo", "age": "42"}
    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)
    # Case1: the alias is not set
    assert result.warnings == []

    # Case2: the key and alias are set, expect a warning
    parameters["name"] = "bo1"

# Generated at 2022-06-20 15:42:11.530067
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"test"}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:42:14.627659
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {"test": "testing"}
    argument_spec = {"test": {"type" : "str"}}
    expected_result = {"test": "testing"}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == expected_result

# Generated at 2022-06-20 15:42:15.811331
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # This is just a placeholder for now.
    assert True

# Generated at 2022-06-20 15:42:25.090433
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(dict())
    assert isinstance(validator, ArgumentSpecValidator)
    assert validator.argument_spec == dict()
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_by == None
    assert validator._required_if == None
    assert validator._valid_parameter_names == set()

    mutually_exclusive = [['a']]
    required_together = [['a']]
    required_one_of = [['a']]
    required_if = [['a']]
    required_by = {'a': ['b'], 'b': ['a']}


# Generated at 2022-06-20 15:42:30.999219
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = {'name': 'Fred'}
    result = ValidationResult(params)
    assert result._validated_parameters == params
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:42:32.961506
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': 10}
    result = ValidationResult(parameters)
    assert parameters == result.validated_parameters

# Generated at 2022-06-20 15:42:47.985327
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for ArgumentSpecValidator.validate"""

    def create_validation_result(validated_parameters=None, error_messages=None):
        """Create a ValidationResult.

        :type validated_parameters: dict[str, dict]
        :type error_messages: list[str]
        """
        result = ValidationResult({})
        result._validated_parameters = validated_parameters or {}
        result.errors.messages = error_messages or []
        return result


# Generated at 2022-06-20 15:42:52.149438
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    assert validator



# Generated at 2022-06-20 15:43:02.423009
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test method validate of class ModuleArgumentSpecValidator
    """
    argument_spec = {'param1': {'type': 'str'},
                     'nested': {
                         'type': 'dict',
                         'options': {
                             'nested_param': {'type': 'str'},
                         },
                     },
                     'array': {'type': 'list'},
                     'nested_array': {'type': 'list',
                                      'elements': 'dict',
                                      'options': {
                                          'nested_param': {'type': 'str'}
                                      }
                                      }
                     }

# Generated at 2022-06-20 15:43:11.636790
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.unsupported_parameters == set()
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:43:17.431679
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # mock parameters
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # mock validator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    # check validation
    error_messages = []
    validation_result = validator.validate(parameters)
    if validation_result.error_messages:
        error_messages = validation_result.error_messages

    assert not error_messages

# Generated at 2022-06-20 15:43:21.650446
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""
    vresult = ValidationResult(dict())
    assert vresult._validated_parameters is not None
    assert vresult.errors is not None
    assert vresult._deprecations is not None
    assert vresult._warnings is not None

# Generated at 2022-06-20 15:43:23.661618
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        asv = ArgumentSpecValidator()
    except (TypeError, NameError):
        pass

# Generated at 2022-06-20 15:43:26.256376
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_parameters = {"a": "b"}
    assert ValidationResult(test_parameters).validated_parameters["a"] == "b"



# Generated at 2022-06-20 15:43:33.551673
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name']

    required_together = [['name', 'age']]

    required_one_of = [['name', 'age']]

    required_if = [['name', 'age', ['age']]]

    required_by = {'name': ['name']}

    ArgumentSpecValidator(argument_spec,
                          mutually_exclusive=mutually_exclusive,
                          required_together=required_together,
                          required_one_of=required_one_of,
                          required_if=required_if,
                          required_by=required_by)