

# Generated at 2022-06-20 15:33:50.021352
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    class arspecA:
        name = "name"
        type = "str"

    class arspecB:
        name = "age"
        type = "int"

    class arspecC:
        name = "gender"
        type = "str"

    class arspecD:
        name = "location"
        type = "str"

    class arspecE:
        name = "score"
        type = "int"

    class arspecF:
        name = "grade"
        type = "str"

    class arspecG:
        name = "height"
        type = "float"

    class arspecH:
        name = "weight"
        type = "float"


# Generated at 2022-06-20 15:33:55.209001
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)

    def validate(parameters):
        return validator.validate(parameters)

    # validate int
    assert ({'a': 1}, None, None, None) == (validate({'a': 1}).validated_parameters, validate({'a': 1}).errors, validate({'a': 1}).error_messages, validate({'a': 1}).unsupported_parameters)
    # validate str
    print (validate({'a': '1'}).validated_parameters)
    print (validate({'a': '1'}).errors)
    print (validate({'a': '1'}).error_messages)

# Generated at 2022-06-20 15:34:06.267410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "name": {
            "type": "str",
            "aliases": ["full_name", "alias_name"],
            "required": True,
        },
        "age": {
            "type": "int",
            "required": True,
        },
    }

    result = ModuleArgumentSpecValidator(argument_spec).validate({"name": "Steve", "age": 70})
    assert "full_name" not in result.validated_parameters

    result = ModuleArgumentSpecValidator(argument_spec).validate({"full_name": "Steve", "age": 70})
    assert "name" not in result.validated_parameters

    result = ModuleArgumentSpecValidator(argument_spec).validate({"full_name": "Steve", "age": "70"})


# Generated at 2022-06-20 15:34:11.480615
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors

    assert len(result.error_messages) == 1
    assert len(result.unsupported_parameters) == 0

    assert result.error_messages == ['Age must be an integer.']
    assert result.validated_parameters == {'age': '42', 'name': 'bo'}



# Generated at 2022-06-20 15:34:22.959063
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    import unittest
    from ansible.module_utils.common.arg_spec import ValidationResult
    from ansible.module_utils.common.text.converters import to_text

    class TestArgSpecValidator(unittest.TestCase):
        """Unit test for ValidationResult class"""

        def setUp(self):
            self.parameters = {'name': 'bo'}

        def tearDown(self):
            pass

        def test_init(self):
            result = ValidationResult(self.parameters)

            self.assertEqual(result._validated_parameters, self.parameters)
            self.assertEqual(result._no_log_values, set())
            self.assertEqual(result._unsupported_parameters, set())

# Generated at 2022-06-20 15:34:34.218393
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six


# Generated at 2022-06-20 15:34:42.787846
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"name": "ansible", "age": 10, "state": "present"}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:34:54.473114
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    result = []

    class TestArgumentSpecValidator(ArgumentSpecValidator):

        def __init__(self, argument_spec, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None):
            super(TestArgumentSpecValidator, self).__init__(
                argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by
            )

        def validate(self, parameters, *args, **kwargs):
            result.append(self.argument_spec)
            return super(TestArgumentSpecValidator, self).validate(parameters, *args, **kwargs)

    # test init
    argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_

# Generated at 2022-06-20 15:35:06.691388
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'age': {
            'type': 'int',
            'default': 42
        },
        'ice_cream_flavor': {
            'type': 'str',
            'choices': ['chocolate', 'vanilla', 'strawberry']
        }
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'chocolate', ['ice_cream_flavor']]
    ]

    required_by = {
        'age': ['name']
    }



# Generated at 2022-06-20 15:35:15.372378
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 0
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert len(result.errors) == 0
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-20 15:35:26.373540
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test with empty argument spec
    result = ValidationResult({})
    # Test with non-empty argument spec
    result = ValidationResult({'age': '42'})


# Generated at 2022-06-20 15:35:36.173634
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test the ModuleArgumentSpecValidator class"""
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Make a temporary directory for this test
    if PY3:
        module_utils_dir = shutil.TemporaryDirectory()
    else:
        module_utils_dir = shutil.mkdtemp()

    # Generate a module to test

# Generated at 2022-06-20 15:35:46.922438
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test for empty deprecations
    argument_spec = {'name': {'type': 'str'}, 'value': {'type': 'int'}}
    mutually_exclusive = None
    required_together = None
    required_if = None
    required_one_of = None
    required_by = None
    parameters = {'name': 'bo', 'value': '42'}
    validator = ModuleArgumentSpecValidator(
        argument_spec,
        mutually_exclusive,
        required_together,
        required_if,
        required_one_of,
        required_by,
    )
    result = validator.validate(parameters)
    assert result.error_messages == []

    # Test for valid deprecations

# Generated at 2022-06-20 15:35:48.344682
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:35:58.004509
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    from ansible.module_utils.common.warnings import AnsibleCollectionWarning
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import warnings


# Generated at 2022-06-20 15:35:59.764814
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # def __init__(self, parameters):

    result = ValidationResult({'name':'testValidationResult'})

# Generated at 2022-06-20 15:36:04.682911
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-20 15:36:09.548816
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {
        'name': {'required': True, 'type': 'str'},
        'age': {'required': False, 'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec=spec)
    assert validator.argument_spec == spec

# Generated at 2022-06-20 15:36:17.714339
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str', 'aliases': ['nickname']}
    }

    parameters = {
        'name': 'bo',
        'nickname': 'john',
        'age': '42'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert ['Error while validating parameter "age": expected an int value but received a string',
            "Both option name and its alias nickname are set."] == result.error_messages

# Generated at 2022-06-20 15:36:24.261090
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    # parameter _deprecations, _warnings is only used in ModuleArgumentSpecValidator
    # so don't test here
    assert result.errors.messages == []


# Generated at 2022-06-20 15:36:43.087207
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    doc = {}
    mutually_exclusive = [['b', 'c']]
    required_together = [['a', 'b']]
    required_one_of = [['a', 'b']]
    required_if = [['a', 'b', 'c']]
    required_by = {'a': ['b']}
    ret = ArgumentSpecValidator(doc, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert ret.argument_spec is doc
    assert ret._mutually_exclusive is mutually_exclusive
    assert ret._required_together is required_together
    assert ret._required_one_of is required_one_of
    assert ret._required_if is required_if
    assert ret._required_by is required_by

# Generated at 2022-06-20 15:36:51.430136
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeAnsibleModule:
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False):
            self.argument_spec = argument_spec
            self.check_mode = False
            self.params = None
            self.supports_check_mode = supports_check_mode
            self.bypass_checks = bypass_checks
            self.no_log_values = set()

        def fail_json_tersely(self, msg, **kwargs):
            raise AnsibleValidationErrorMultiple([msg])

    argument_spec = {
        'name': {'type': 'str', 'no_log': True},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '0',
    }

# Generated at 2022-06-20 15:36:55.898920
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'a': 1, 'b': 2}
    vr = ValidationResult(parameters)
    assert vr._validated_parameters == parameters
    assert vr._unsupported_parameters == set()
    assert vr.errors == []


# Generated at 2022-06-20 15:37:03.547984
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def is_warn_called():
        warn_called = False

        if len(warn.call_args_list) > 0:
            if len(warn.call_args_list[0]) > 0:
                if 'Both option option and its alias alias are set.' in str(warn.call_args_list[0][0][0]):
                    warn_called = True
        return warn_called

    def is_deprecate_called():
        deprecate_called = False


# Generated at 2022-06-20 15:37:12.643855
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'a': {'type': 'int'},
        'b': {'type': 'str'}
    })

    result = validator.validate({
        'a': '1',
        'b': 'foo'
    })
    assert result._deprecations == []
    assert result._warnings == []
    assert result.validated_parameters == {
        'a': 1,
        'b': 'foo'
    }
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

    result = validator.validate({
        'a': 'a',
        'b': 'foo'
    })
    assert result._deprecations == []
    assert result._warnings == []
    assert result.validated_param

# Generated at 2022-06-20 15:37:24.339901
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class Test:
        def __init__(self):
            self.warnings = []
            self.deprecations = []

        def warn(self, msg):
            self.warnings.append(msg)

        def deprecate(self, msg, version=None, date=None, collection_name=None):
            self.deprecations.append(msg)

    #when alias is deprecated
    test = Test()
    argument_spec = dict(
        good={'type': 'str'},
        bad={'type': 'str', 'aliases': ['old']},
        both={'type': 'str', 'aliases': ['old']},
    )
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

# Generated at 2022-06-20 15:37:35.269389
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    #Write your unit test here
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'height': {'type': 'float'},
        'list': {'type': 'list'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'height'],
        ['age', 'height'],
        ['list', 'height'],
        ['list', 'name'],
        ['list', 'age'],
    ]

    required_together = [
        ['name', 'age'],
        ['name', 'height'],
        ['age', 'height'],
        ['list', 'height'],
        ['list', 'name'],
        ['list', 'age'],
    ]

   

# Generated at 2022-06-20 15:37:42.208172
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test the constructor of ValidationResult"""
    result = ValidationResult({'name': 'bo'})

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'name': 'bo'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:37:53.085310
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'host': {'default': 'localhost', 'type': 'str'},
                     'password': {'default': 'secret', 'type': 'str'},
                     'username': {'default': 'user', 'type': 'str'},
                     'vault_password': {'default': 'secret', 'type': 'str', 'no_log': True},
                     'new_password': {'default': 'secret', 'type': 'str', 'aliases': ['new_pass']}
                     }

    parameters = {'host': 'localhost'}
    mutually_exclusive = [['username', 'vault_password']]
    required_together = [['username', 'password']]
    required_one_of = [['username', 'vault_password']]

# Generated at 2022-06-20 15:38:01.677448
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    kwargs = {
        'argument_spec': {
            'name': {'type': 'str'},
            'age': {'type': 'int'}
        }
    }
    validator = ModuleArgumentSpecValidator(**kwargs)
    assert isinstance(validator, ModuleArgumentSpecValidator)
    assert validator.argument_spec == kwargs['argument_spec']
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None

# Generated at 2022-06-20 15:38:47.743418
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    val_result = ValidationResult({})
    assert val_result.validated_parameters is not None
    assert val_result.errors is not None
    assert val_result.error_messages is not None
    assert val_result.unsupported_parameters is not None


# Generated at 2022-06-20 15:38:55.333258
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
                      "name": {"type": "str"},
                      "age": {"type": "int"}
                    }
    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", 42, ["age"]]]
    required_by = {"name": ["age"]}
    ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:38:56.616162
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'test': True})._validated_parameters['test'] == True


# Generated at 2022-06-20 15:39:04.791728
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive_list = ['vm_id', 'vm_uuid']
    required_together_list = [['vm_uuid', 'vm_name']]
    required_one_of_list = [['vm_uuid', 'vm_name']]
    required_if_list = [['vm_uuid', 'present', ['vm_name']]]
    required_by_dict = {'vm_uuid': ['vm_name']}


# Generated at 2022-06-20 15:39:12.720430
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    # Constructing the validation result class testing the result of
    # parameters after the constructor
    test_validation_result = ValidationResult('test_parameter')

    # Asserting the resultant parameters after the constructor
    assert test_validation_result.validated_parameters == 'test_parameter'
    assert test_validation_result.unsupported_parameters == set()
    assert test_validation_result.errors == AnsibleValidationErrorMultiple()
    assert test_validation_result.error_messages == []
    assert test_validation_result.unsupported_parameters == set()

# Generated at 2022-06-20 15:39:18.225442
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """This function is to test constructor of class ArgumentSpecValidator"""
    assert ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}}, mutually_exclusive=['test'], required_together=['test'],
                                 required_one_of=['test'], required_if=['test'], required_by=['test'])



# Generated at 2022-06-20 15:39:24.613972
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test for passing mutually_exclusive as list of lists
    mutually_exclusive = [["no_one", "no_two"], ["no_three"]]
    instance_1 = ArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=mutually_exclusive
    )
    assert instance_1._mutually_exclusive == mutually_exclusive

    # Test for passing mutually_exclusive as list of strings
    mutually_exclusive = ["no_one", "no_two"]
    instance_2 = ArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=mutually_exclusive
    )
    assert instance_2._mutually_exclusive == [mutually_exclusive]

# Generated at 2022-06-20 15:39:26.735467
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(parameters = {'a':1})


# Generated at 2022-06-20 15:39:37.177757
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # ensure that deprecate() and warn() are called once
    # when the corresponding options are present

    # mock the deprecate and warn functions
    import collections
    import mock

    deprecate_mock = mock.MagicMock(side_effect=lambda *args, **kwargs: deprecate(*args, **kwargs))
    warn_mock = mock.MagicMock(side_effect=lambda *args, **kwargs: warn(*args, **kwargs))

    # decorate deprecate and warn functions
    def _deprecate(*args, **kwargs):
        deprecate_mock(*args, **kwargs)

    def _warn(*args, **kwargs):
        warn_mock(*args, **kwargs)

    # make deprecate and warn functions visible to parameters.py module

# Generated at 2022-06-20 15:39:41.940176
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test a simple case: pass a valid spec and check that
    # argument_spec is set correctly
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hobbies': {'type': 'list', 'elements': 'str'}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-20 15:40:21.221552
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    expected_parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(expected_parameters)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == expected_parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == expected_parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:40:25.433784
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}})
    assert validator.argument_spec == {'name': {'type': 'str'}, 'age': {'type': 'int'}}

# Generated at 2022-06-20 15:40:28.060474
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'parameter_a': "a",
        'parameter_b': "b"
    }
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters

# Generated at 2022-06-20 15:40:34.267721
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""

    parameters = {'example': 'parameters'}
    validation = ValidationResult(parameters)

    assert hasattr(validation, '_no_log_values')
    assert hasattr(validation, '_unsupported_parameters')
    assert hasattr(validation, '_validated_parameters')
    assert hasattr(validation, '_deprecations')
    assert hasattr(validation, '_warnings')
    assert hasattr(validation, 'errors')

# Generated at 2022-06-20 15:40:36.931347
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Constructor of ArgumentSpecValidator should return an object
    """
    try:
        validator = ArgumentSpecValidator({})
        assert isinstance(validator, ArgumentSpecValidator)
    except:
        assert 0, "Constructor of ArgumentSpecValidator failed."


# Generated at 2022-06-20 15:40:48.496545
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from unittest import TestCase

    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.text.converters import to_text

    from ansible.module_utils._text import to_native
    import ansible.module_utils.common.arg_spec

    class TestModuleArgumentSpecValidator(TestCase):

        def setUp(self):
            self.argument_spec = {
                'name': {'type': 'dict', 'required': True},
                'age': {'type': 'list'},
                'sex': {'type': 'str'},
            }

            self.mutually_exclusive = [
                ['name', 'age'],
            ]

            self._module = ansible.module_utils.common.arg_spec.Module

# Generated at 2022-06-20 15:40:49.038738
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-20 15:40:49.616430
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(dict())


# Generated at 2022-06-20 15:40:51.405431
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    m = ModuleArgumentSpecValidator()
    assert m

# Generated at 2022-06-20 15:40:58.649001
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator."""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name'],
        ['age'],
    ]

    required_if = [
        ['name', 'x', ['age']],
        ['name', 'y', ['age']],
    ]

    required_by = {
        'name': ['age']
    }

    # Test without all optional parameters
    validator = ArgumentSpecValidator(argument_spec)

    assert validator._mutually_exclusive is None
    assert validator._required_together

# Generated at 2022-06-20 15:42:06.953926
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''
    test_ModuleArgumentSpecValidator_validate:
        Test validate method of class ModuleArgumentSpecValidator
    '''
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'dob': {
            'type': 'dict',
            'options': {
                'date': {'type': 'str'},
                'month': {'type': 'str'},
                'year': {'type': 'str'},
            },
            'aliases': ['birth_date'],
        },
        'gender': {'type': 'str', 'choices': ['male', 'female', 'others'], 'default': 'male'},
    }

    mutually_exclusive = [['dob', 'birth_date']]

# Generated at 2022-06-20 15:42:14.175502
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validator = ArgumentSpecValidator({'param1': {'type': 'str'}})
    result = validator.validate({'param1': 'value1'})
    assert result._validated_parameters == {'param1': 'value1'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []
    assert result.validated_parameters == {'param1': 'value1'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:42:19.914244
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # First test that the normal ArgumentSpecValidator class works. This will assure that
    # the same validation functionality is present.
    arg_spec = {
        'foo': {'type': 'int', 'required': True},
        'bar': {'type': 'bool', 'default': True},
        'baz': {'type': 'list', 'default': 'something that is not a list'},
        'bat': {'type': 'list', 'required': True, 'aliases': ['bzz']},
        'nested': {'type': 'dict', 'options': {'level2': {'type': 'int', 'default': 'not a int'}}}
    }

    parameters = {'foo': '10', 'bzz': None}

    validator = ArgumentSpecValidator(arg_spec)
    result = validator.valid

# Generated at 2022-06-20 15:42:25.811366
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:42:29.629264
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        # equal
        validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'},})
    except Exception as e:
        print ("Error in test_ModuleArgumentSpecValidator: " + str(e))
        assert False

# Generated at 2022-06-20 15:42:39.190481
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age']]
    required_by = {'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    result = validator.validate({'name': 'bo', 'age': '42'})

    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-20 15:42:40.777686
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-20 15:42:50.531736
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [['A', 'B'], ['C'], ['D']]
    required_together = [['E', 'F']]
    required_one_of = [['G', 'H']]
    required_if = [['I', 'J', ['K']], ['M', 'N', ['O']]]
    required_by = {'L': ['P']}


# Generated at 2022-06-20 15:42:58.570561
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    object_for_validation = {"key1": "value1", "key2": "value2"}
    result = ValidationResult(object_for_validation)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {"key1": "value1", "key2": "value2"}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:43:05.999574
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    dict_spec = dict(
        type=dict(type='dict',
              options=dict(
                  name=dict(required=True),
                  age=dict(type='int'),
                  password=dict(type='str', no_log=True),
                  state=dict(type='str', default='present', choices=['present', 'absent']),
                  description=dict(type='str'),
                  # The following is an example of a nested spec
                  children=dict(type='dict',
                                options=dict(
                                    name=dict(type='str'),
                                    age=dict(type='int'),
                                )
                               ),
              )
             )
    )

    parameters = dict(name="bo", password="test", state="present")

    validator = ArgumentSpecValidator(dict_spec)
    result = validator