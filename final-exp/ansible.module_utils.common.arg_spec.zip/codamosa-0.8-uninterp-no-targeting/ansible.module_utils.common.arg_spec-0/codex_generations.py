

# Generated at 2022-06-20 15:33:51.932650
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({})

# Generated at 2022-06-20 15:34:01.666987
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import sys
    import json

    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # Read the data from the file
    json_file = sys.argv[1]
    with open(json_file, "r") as f:
        data = json.load(f)

    # Instantiate the ArgumentSpecValidator() class
    validator = ArgumentSpecValidator(argument_spec=data['argument_spec'],
                                      mutually_exclusive=data['mutually_exclusive'],
                                      required_together=data['required_together'],
                                      required_one_of=data['required_one_of'],
                                      required_if=data['required_if'],
                                      required_by=data['required_by'])

    # Perform the validation

# Generated at 2022-06-20 15:34:14.393943
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import json

    def test(parameters, expected_results):
        validator = ModuleArgumentSpecValidator({
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        })

        result = validator.validate(parameters)

        assert result.validated_parameters == expected_results['validated_parameters']
        errors = [json.loads(error) for error in result.error_messages]
        assert errors == expected_results['errors']

    # Test parameters (dict): Validate
    # Test expected_results (dict): Validate
    test({'name': 'bo', 'age': '42'}, {
        'validated_parameters': {'name': 'bo', 'age': 42},
        'errors': [],
    })

    # Test parameters (

# Generated at 2022-06-20 15:34:24.389209
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    spec = dict(
        option1=dict(type='str'),
        option2=dict(type='str')
    )

    parameters_1 = dict(
        option1='test'
    )

    parameters_2 = dict(
        option1=1,
        option2='test'
    )

    validator = ArgumentSpecValidator(spec)

    # Test for simple example
    result = validator.validate(parameters_2)
    assert result.validated_parameters == parameters_2
    assert not result.error_messages

    # Test for error
    result = validator.validate(parameters_1)
    assert result.error_messages
    assert result.error_messages[0] == "option2 is required"


# Generated at 2022-06-20 15:34:33.797880
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_parameters = {
        "test1" : "known",
        "test2" : "unknown",
        "test3" : "unknown"
    }

    result = ValidationResult(test_parameters)

    assert result._validated_parameters == test_parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == test_parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-20 15:34:46.823951
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test to test constructor of module 'ansible.module_utils.common.arg_spec._ValidationResult' using pytest fixture."""
    parameters = {
    }
    result = ValidationResult(parameters)
    assert result._validated_parameters == {
        '_ansible_parse_cache': {
            'ansible_default_filter_name': 'json_query'
        }
    }
    assert len(result.errors) == 0
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0
    assert len(result._no_log_values) == 0
    assert len(result._unsupported_parameters) == 0

# Generated at 2022-06-20 15:34:54.572937
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = dict(param1=dict(type=str), param2=dict(type=str))
    mutually_exclusive = [["param1", "param2"]]
    required_together = [["param1", "param2"]]
    required_one_of = [["param1", "param2"]]
    required_if = [["param1", "param2"]]
    required_by = {"param1": ["param2"]}

    # Add asserts to test the constructor of class ModuleArgumentSpecValidator
    assert ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-20 15:34:58.384775
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Passed
    validator = ModuleArgumentSpecValidator({})
    # class constructor can be called by passing no arguments
    validator = ModuleArgumentSpecValidator()


# Generated at 2022-06-20 15:35:09.214781
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """
    Unit test for constructor of class ValidationResult
    """

    # Create a ValidationResult
    parameters = dict(test_dict_param=dict(test_dict_param_key='test_dict_param_value'))
    result = ValidationResult(parameters)

    # Check if the validated parameters is set correctly
    assert result._validated_parameters == dict(test_dict_param=dict(test_dict_param_key='test_dict_param_value'))

    # Check if the no_log_values returned is empty
    assert result._no_log_values == set()

    # Check if the unsupported_parameters returned is empty
    assert result._unsupported_parameters == set()

    # Check if the deprecations returned is empty
    assert result._deprecations == []

    # Check if the warnings returned is

# Generated at 2022-06-20 15:35:19.957582
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Unit test for method validate
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'required': True},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.error_messages == []
    assert isinstance(result.validated_parameters, dict)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test with missing required argument
    parameters = {'name': 'bo'}
    result = validator.validate(parameters)



# Generated at 2022-06-20 15:35:27.780843
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(argument_spec=dict(), mutually_exclusive=list(),
                                         required_together=list(), required_one_of=list(),
                                         required_if=list(), required_by=dict())
    assert result is not None

# Generated at 2022-06-20 15:35:31.113995
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = {}
    x = ModuleArgumentSpecValidator(arg_spec)
    assert x.__class__.__name__ == "ModuleArgumentSpecValidator"

# Generated at 2022-06-20 15:35:38.488527
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # successful validation
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

    # validation failure
    parameters = {
        'name': 'bo',
        'age': 'foo',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-20 15:35:39.908880
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator('test')
    assert result is not None

# Generated at 2022-06-20 15:35:46.295192
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})

    assert isinstance(result, ValidationResult)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-20 15:35:49.382066
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator('argument_spec', 'mutually_exclusive', 'required_one_of', 'required_together', 'required_if', 'required_by')

# Generated at 2022-06-20 15:35:54.142065
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # test default parameters
    ModuleArgumentSpecValidator(argument_spec={})

    # test filled parameters
    ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None
    )

# Generated at 2022-06-20 15:36:03.334544
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:36:08.910978
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test that validate emits a deprecate warning
    validator = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    result = validator.validate({})
    deprecations = result._deprecations
    assert deprecations == []


# Generated at 2022-06-20 15:36:11.728675
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(parameters={'key1': 'value1'}).validated_parameters == {'key1': 'value1'}


# Generated at 2022-06-20 15:36:24.502514
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(dict(), mutually_exclusive=[], required_together=[], required_one_of=[], required_if=[], required_by={})
    assert validator.argument_spec == {}
    assert validator._valid_parameter_names == set()
    assert validator._mutually_exclusive == []
    assert validator._required_together == []
    assert validator._required_one_of == []
    assert validator._required_if == []
    assert validator._required_by == {}


# Generated at 2022-06-20 15:36:37.207239
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "required1": {"type": "str", "required": True},
        "required2": {"type": "bool", "required": True},
        "required3": {"type": "list", "required": True},
        "required4": {"type": "dict", "required": True},
        "aliases": {"type": "list", "aliases": ["other_name"]},
    }
    mutually_exclusive = [['required1', 'required2', 'required3', 'required4']]
    required_together = [['required1', 'required2'], ['required1', 'required3'], ['required2', 'required4']]
    required_one_of = [['required1', 'required2'], ['required1', 'required3'], ['required2', 'required4']]

# Generated at 2022-06-20 15:36:48.146444
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    os_spec = {
        "name": {"type": "str"}
    }

    argument_spec = {
        "auth": {"type": "dict",
                 "options": {"username": {"type": "str"},
                             "password": {"type": "str", "no_log": True}},
                 "required": False},
        "os": {"type": "dict",
               "options": os_spec},
        "required_for_other_os": {"type": "str", "required_if": ["os", {"RedHat": ["other_os"]}]}
    }
    mutually_exclusive = [["auth", "required_for_other_os"]]
    required_one_of = [["auth", "required_for_other_os"]]


# Generated at 2022-06-20 15:36:56.590832
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    err_msg = ModuleArgumentSpecValidator(argument_spec).validate(parameters)
    assert err_msg == 'The field age has an invalid value, which appears to include a variable that is undefined. The error was: \'int\' object is not iterable'


# Generated at 2022-06-20 15:37:04.978082
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert(getattr(ValidationResult, '_validated_parameters') == None)
    assert(getattr(ValidationResult, '_no_log_values') == None)
    assert(getattr(ValidationResult, '_unsupported_parameters') == None)
    assert(getattr(ValidationResult, 'errors') == None)
    assert(getattr(ValidationResult, '_deprecations') == None)
    assert(getattr(ValidationResult, '_warnings') == None)
    test = ValidationResult({})
    assert(test._validated_parameters == {})
    assert(test._no_log_values == set())
    assert(test._unsupported_parameters == set())


# Generated at 2022-06-20 15:37:10.360243
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    '''
    ValidationResult class
    '''
    vr = ValidationResult({"Name":"abc"})

    assert vr._validated_parameters == {"Name":"abc"}
    assert vr.validated_parameters == {"Name":"abc"}
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._deprecations == []
    assert vr._warnings == []
    assert isinstance(vr.errors, AnsibleValidationErrorMultiple)
    assert vr.error_messages == []


# Generated at 2022-06-20 15:37:13.699472
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result._no_log_values == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:37:24.216974
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "foo": {"type": "str", "required": True},
        "bar": {'type': 'str', 'required': False},
        "baz": {'type': 'str', 'default': 'qux'},
    }

    mutually_exclusive = [['foo', 'bar']]
    required_together = [["foo", "bar"]]
    required_one_of = [["foo", "bar"]]
    required_if = [["foo", "bar", "baz"]]
    required_by = {"foo": ["bar", "baz"]}


# Generated at 2022-06-20 15:37:35.157435
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:37:45.879073
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit tests for method validate of class ArgumentSpecValidator"""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'job': {'type': 'dict', 'options': {'title': {'type': 'str'}}},
    }

    required_together = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec, required_together=required_together)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Failing parameters

# Generated at 2022-06-20 15:37:57.006216
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    if not isinstance(ArgumentSpecValidator, type):
        raise Exception("ArgumentSpecValidator is not implemented as a class")
    if not isinstance(ModuleArgumentSpecValidator, type):
        raise Exception("ModuleArgumentSpecValidator is not implemented as a class")

# Generated at 2022-06-20 15:38:07.214283
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'examples': {'type': 'list', 'elements': 'str'},
        'description': {'type': 'str', 'no_log': True},
        'nested': {'type': 'dict',
                   'default': {'nested': {'depth': 42}},
                   'options': {
                       'nested': {
                           'type': 'dict',
                           'options': {
                               'depth': {'type': 'int'},
                               'name': {'type': 'str'},
                           },
                       },
                   },
                   },
    }


# Generated at 2022-06-20 15:38:18.364847
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common import AnsibleModule
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import builtins


# Generated at 2022-06-20 15:38:29.146791
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # test with an empty argument_spec
    argument_spec = {}
    validator = ModuleArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ModuleArgumentSpecValidator)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == set()

    # test with an non-empty argument_spec
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

    assert isinstance

# Generated at 2022-06-20 15:38:38.305103
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # The following test is for the validation of a valid spec

    argument_spec = dict(username=dict(type='str', aliases=['user']),
                         password=dict(type='str', no_log=True))
    parameters = dict(username='user', password='password')
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result._no_log_values) == 1
    assert result._no_log_values == set([('password', 'password')])
    assert len(result._unsupported_parameters) == 0
    assert len(result._validated_parameters) == 2
    assert result._validated_parameters['username'] == 'user'
    assert result._validated_parameters['password'] == 'password'

# Generated at 2022-06-20 15:38:46.849490
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    valid_parameters = {
        'foo': 'bar',
        'bar': 42,
    }
    result = validator.validate(valid_parameters)
    assert result.validated_parameters == {
        'foo': 'bar',
        'bar': 42,
    }

    invalid_parameters = {
        'foo': 'bar',
        'bar': '42',
    }
    result = validator.validate(invalid_parameters)
    assert result.error_messages == ['bar must be an integer', 'bar (b) must be an integer']



# Generated at 2022-06-20 15:38:49.890581
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test to verify module importing in the class ModuleArgumentSpecValidator"""

    msv = ModuleArgumentSpecValidator()
    assert type(msv) == ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:38:58.150516
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.validated_parameters, dict)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:39:01.761863
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = {'distro': 'centos7'}
    result = ValidationResult(params)
    assert result._validated_parameters == params
    assert result._deprecations == []
    assert result._warnings == []
    assert result._valid_parameter_names == []
    assert result.errors == None

# Generated at 2022-06-20 15:39:10.033385
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:39:25.732003
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult.__init__.__doc__
    r = ValidationResult({})
    assert isinstance(r._no_log_values, set)
    assert isinstance(r._unsupported_parameters, set)
    assert isinstance(r._validated_parameters, dict)
    assert isinstance(r._deprecations, list)
    assert isinstance(r._warnings, list)
    assert isinstance(r.errors, AnsibleValidationErrorMultiple)
    assert r.validated_parameters
    assert r.unsupported_parameters
    assert r.error_messages



# Generated at 2022-06-20 15:39:36.654971
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    )
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.unsupported_parameters == set()
    assert result._validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result._no_log_values == set()
    assert result._deprecations == []
    assert result._warn

# Generated at 2022-06-20 15:39:46.434992
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [["a", "b"]]
    required_together = [["a", "b"]]
    required_one_of = [["a", "b"]]
    required_if = [["a", "b", ["c"]]]
    required_by = {"name": ["age"]}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator.argument_spec == argument_spec, "argument_spec property is not set"
    assert validator._mutually_exclusive == mutually_exclusive, "mutually_exclusive property is not set"
    assert validator._required_together == required_together

# Generated at 2022-06-20 15:39:54.704030
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-20 15:40:05.058356
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator(): # pylint: disable=too-many-locals
    # pylint: disable=protected-access
    class WarningsAndErrors:
        def __init__(self):
            self.warnings = []
            self.errors = []
        def append(self, value):
            self.warnings.append(value)

    class Deprecations:
        def __init__(self):
            self.deprecations = []
        def append(self, value):
            self.deprecations.append(value)

    class AnsibleModule:
        def __init__(self, spec, **kwargs):
            self.argument_spec = spec
            self.params = {}
            self.deprecations = Deprecations()
            self.warnings = WarningsAndErrors()


# Generated at 2022-06-20 15:40:13.883541
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test for method validate of class ArgumentSpecValidator """
    # TODO: also test argument_spec with nested argument_spec
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.arg_spec import ArgumentSpec
    import os
    import sys
    import inspect

    if 'ANSIBLE_TEST_DATA_ROOT' not in os.environ:
        # todo: make this work under both testinfra and pytest-ansible
        print('ANSIBLE_TEST_DATA_ROOT not available, skipping test')
        return

    # ArgumentSpecValidator_validate uses ArgumentSpec
    # and as ArgumentSpecValidator_validate is recursive,
    # we must declare ArgumentSpecValidator_validate before ArgumentSpec

# Generated at 2022-06-20 15:40:25.561099
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argspec = {
        'param_1': {'type': 'str'},
        'param_2': {'type': 'bool'},
        'param_3': {'type': 'str'}
    }

    mutually_exclusive = [['param_1', 'param_3']]
    required_together = [['param_1', 'param_2']]
    required_one_of = [['param_1', 'param_2']]
    required_if = [['param_1', 42, ['param_3']]]
    required_by = {'param_2': ['param_1']}


# Generated at 2022-06-20 15:40:32.390126
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == deepcopy(parameters)
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == deepcopy(parameters)
    assert result.error_messages == []
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:40:35.081616
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        "name": "bo",
        "age": 42,
    }

    result = ValidationResult(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()

# Generated at 2022-06-20 15:40:43.004560
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    assert validator is not None
    assert validator.mutually_exclusive == mutually_exclusive
    assert validator._valid_parameter_names == {'age', 'name'}
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-20 15:40:59.637228
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(dict())

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == dict()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Unit tests for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:41:06.988861
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'A required parameter "name" was not provided.' == result.error_messages[0]
    #print(result.validated_parameters)


# Generated at 2022-06-20 15:41:15.380188
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Check that ModuleArgumentSpecValidator is a subclass of ArgumentSpecValidator
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

    # Check that validator works
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-20 15:41:19.929148
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_arg_spec = {
        'required_multiselect_option': {
            'type': 'list',
            'default': [],
            'elements': 'str',
            'options': [
                'foo',
                'bar',
                'baz'
            ],
            'required': True
        }
    }
    module_arg_spec_validator = ModuleArgumentSpecValidator(module_arg_spec)
    assert module_arg_spec_validator

# Generated at 2022-06-20 15:41:22.988688
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    try:
        validator = ArgumentSpecValidator(argument_spec)
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-20 15:41:27.823957
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def _check(result):
        assert isinstance(result, ValidationResult)
        assert isinstance(result.errors, AnsibleValidationErrorMultiple)
        assert not result.error_messages
        assert result.validated_parameters == {'name': 'foo', 'age': 42}
        assert not result.unsupported_parameters

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'foo',
        'age': 42,
    }

    validator = ArgumentSpecValidator(argument_spec)
    _check(validator.validate(parameters))

    results = validator.validate(parameters)
    _check(results)
    assert not results._no_log_values


# Generated at 2022-06-20 15:41:39.006349
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test _no_log_values
    # pylint: disable=unused-argument
    no_log_values = set()
    no_log_values.add('NOLOGVAL')
    argument_spec_no_log_values = {
        'arg_1': {
            'type': 'str',
            'required': True,
            'no_log': 'yes'
        }
    }
    parameters_no_log_values = {
        'arg_1': 'NOLOGVAL',
        'arg_2': 'value2'
    }
    validator_no_log_values = ArgumentSpecValidator(argument_spec_no_log_values)
    result_no_log_values = validator_no_log_values.validate(parameters_no_log_values)

# Generated at 2022-06-20 15:41:46.140350
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def check_result(result, no_log_values, errors, validated_parameters):
        # Check items in no_log_values set
        assert all(item in result._no_log_values for item in no_log_values)
        # Check items in errors list
        assert all(item in result.errors for item in errors)
        # Check items in validated_parameters dict
        for key, value in validated_parameters.items():
            assert key in result._validated_parameters
            assert value == result._validated_parameters[key]


# Generated at 2022-06-20 15:41:54.860664
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test for method validate of class ArgumentSpecValidator."""

    # Unit test 1. Invalid spec type (check type)
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 1
    assert result.error_messages[0] == 'The following arguments are not expected: age'

    # Unit test 2. Valid spec type (check no_log)

# Generated at 2022-06-20 15:41:59.832451
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""
    params = {'name': 'Ansible', 'password': 'secret'}
    with pytest.raises(Exception) as excinfo:
        ValidationResult(params)
    assert '__init__() takes 1 positional argument but 2 were given' in excinfo.exconly()


# Generated at 2022-06-20 15:42:16.737355
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ''' Unit test for constructor of class ValidationResult '''
    parameters = {'a' : 10, 'b' : 20}
    result = ValidationResult(parameters)
    assert (result._validated_parameters == parameters)
    assert (result.errors == [])


# Generated at 2022-06-20 15:42:27.255068
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class module:
        def exit_json(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def _load_params(self):
            return {'one': 'one', 'two': 'two'}

    my_module = module()
    my_module.argument_spec = {
        'one': {'type': 'str'},
        'two': {
            'type': 'dict',
            'options': {
                'three': {'type': 'str'},
                'four': {'type': 'str'}
            }
        }
    }
    validator = ArgumentSpecValidator(my_module.argument_spec)
    result = validator.validate(my_module._load_params())
    assert result.validated

# Generated at 2022-06-20 15:42:31.820910
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'test1': 'test'}
    result = ValidationResult(parameters)
    assert result._validated_parameters
    assert result.errors 
    assert result.error_messages()
    assert result._no_log_values
    assert result._unsupported_parameters
    assert result._deprecations
    assert result._warnings

# Generated at 2022-06-20 15:42:34.308576
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    obj = ValidationResult(parameters={"Foo": "Bar"})
    assert obj != None

# Unit Test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-20 15:42:40.514873
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    x = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive, required_together=required_together)
    assert x._mutually_exclusive == mutually_exclusive
    assert x._required_together == required_together
    assert not x._required_one_of
    assert not x._required_if
    assert not x._required_by
    assert x._valid_parameter_names == {'name', 'age'}
    assert x.argument_spec == argument_spec

# Generated at 2022-06-20 15:42:44.563192
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }).validate({
        'name': 'bo',
        'age': '42',
    })

    assert not result.errors

# Generated at 2022-06-20 15:42:54.709593
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [
        ["passwd", "encrypted_passwd"],
        ["passwd", "unencrypted_passwd"],
    ]
    required_together = [
        ["passwd", "encrypted_passwd"],
        ["passwd", "unencrypted_passwd"],
    ]
    required_one_of = [
        ["passwd", "encrypted_passwd"],
        ["passwd", "unencrypted_passwd"],
    ]
    required_if = [
        ["passwd", "encrypted_passwd"],
        ["passwd", "unencrypted_passwd"],
    ]
    required_by = [
        ["passwd", "encrypted_passwd"],
        ["passwd", "unencrypted_passwd"],
    ]

# Generated at 2022-06-20 15:42:56.156800
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    a = ArgumentSpecValidator()
    assert a

# Generated at 2022-06-20 15:43:04.533212
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator.argument_spec == {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    assert validator._valid_parameter_names == {'name', 'age'}


# Generated at 2022-06-20 15:43:13.575810
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """
    Case 1: Normal test
    """
    parameters = {
        '_parameter_a': 'value_a',
        '_parameter_b': 'value_b',
        '_parameter_c': 'value_c',
    }
    result = ValidationResult(parameters)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()