

# Generated at 2022-06-20 15:34:01.631486
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    #check alias deprecation
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nickname']},
    }
    parameters = {
        'name': 'test'
    }
    validator = ModuleArgumentSpecValidator(argument_spec, None, None, None, None, None)
    result = validator.validate(parameters)
    assert result.errors == []
    assert result.warnings == []

    # check alias
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['old']},
    }
    parameters = {
        'name': 'test',
        'age': '42',
    }

# Generated at 2022-06-20 15:34:03.365080
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator


# Generated at 2022-06-20 15:34:15.388622
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
        },
        'age': {
            'type': 'int'
        },
        'interests': {
            'type': 'list'
        }
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'interests']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age'],
        ['name', 'interests']
    ]

    required_if = [
        ['name', 'playboy', ['age']],
    ]

    required_by = {
        'age': ['name'],
        'interests': ['name']
    }


# Generated at 2022-06-20 15:34:25.256495
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import ansible.module_utils.common.arg_spec as arg_spec
    print(isinstance(arg_spec.ArgumentSpecValidator(argument_spec=None), arg_spec.ArgumentSpecValidator))
    print(isinstance(arg_spec.ArgumentSpecValidator(argument_spec=None, mutually_exclusive=None), arg_spec.ArgumentSpecValidator))
    print(isinstance(arg_spec.ArgumentSpecValidator(argument_spec=None, mutually_exclusive=None,
                                                    required_together=None), arg_spec.ArgumentSpecValidator))
    print(isinstance(arg_spec.ArgumentSpecValidator(argument_spec=None, mutually_exclusive=None,
                                                    required_together=None, required_one_of=None), arg_spec.ArgumentSpecValidator))
    print

# Generated at 2022-06-20 15:34:35.333392
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys

    def test_func(parameters):
        argument_spec = {
            'path': {'type': 'path', 'aliases': ['d']},
            'src': {'type': 'path', 'aliases': ['source']},
            'dest': {'type': 'path', 'aliases': ['dst']},
            'age': {'type': 'int'}
        }

        mutually_exclusive = [
            ['path', 'src'],
            ['path', 'dest'],
            ['src', 'dest']
        ]

        validator = ModuleArgumentSpecValidator(argument_spec=argument_spec,
                                                mutually_exclusive=mutually_exclusive)

        result = validator.validate(parameters)


# Generated at 2022-06-20 15:34:38.704325
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    s = 'content'
    assert ValidationResult(s).validated_parameters == 'content'


if __name__ == '__main__':
    test_ValidationResult()

# Generated at 2022-06-20 15:34:50.888939
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import _handle_fallbacks
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.validation import check_required_if
    assert_regex = lambda x, y, z: True if x == y else False

    # test default ansible module argument_spec

# Generated at 2022-06-20 15:34:56.524689
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    result = validator.validate({
        'name': 'bo',
        'age': '42',
    })

    assert result._deprecations == []
    assert result._warnings == []
    assert result._validated_parameters == {}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors.messages == []

# Generated at 2022-06-20 15:35:07.949743
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.text.converters import to_text

    # Check if the class is declared.
    assert hasattr(ModuleArgumentSpecValidator, '__init__')

    # Check if the constructor exists, and it is callable.
    assert callable(ModuleArgumentSpecValidator.__init__)

    # Check that the class can be instantiated.
    ModuleArgumentSpecValidator(argument_spec={'arg1': {'type': 'str'}})

    # Check the constructor parameters.

# Generated at 2022-06-20 15:35:13.498850
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    obj = ModuleArgumentSpecValidator()
    assert obj.argument_spec == {}
    assert obj._mutually_exclusive == None
    assert obj._required_together == None
    assert obj._required_one_of == None
    assert obj._required_if == None
    assert obj._required_by == None
    assert obj._valid_parameter_names == {}


# Generated at 2022-06-20 15:35:20.282633
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator({'foo': {'type': 'int'}}, 'MUTUALLY_EXCLUSIVE', ['REQUIRED_TOGETHER'], ['REQUIRED_ONE_OF'], ['REQUIRED_IF'], ['REQUIRED_BY'])
    assert result

# Generated at 2022-06-20 15:35:23.331514
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-20 15:35:27.932806
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-20 15:35:31.255259
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})

    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:35:38.566064
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.validation import check_requirements

    def test_function(module):
        check_requirements([[]])

    module = AnsibleModule(
        argument_spec={'name': {'type': 'str'},
                       'age': {'type': 'int'}},
        supports_check_mode=True
    )
    validator = ModuleArgumentSpecValidator(module.argument_spec, module._mutually_exclusive, module._required_together,
                                            module._required_one_of, module._required_if, module._required_by)
    assert isinstance(validator, ModuleArgumentSpecValidator)
    assert isinstance(validator.argument_spec, dict)

# Generated at 2022-06-20 15:35:49.434254
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common._collections_compat import Mapping
    import inspect

    ASV_attrs = inspect.getargspec(ArgumentSpecValidator)
    assert len(ASV_attrs.args) == 7
    assert ASV_attrs.args[0] == 'self'
    assert ASV_attrs.args[1] == 'argument_spec'
    assert ASV_attrs.args[2] == 'mutually_exclusive'
    assert ASV_attrs.args[3] == 'required_together'
    assert ASV_attrs.args[4] == 'required_one_of'
    assert ASV_attrs.args[5] == 'required_if'
    assert ASV_attrs.args[6] == 'required_by'
    assert ASV_att

# Generated at 2022-06-20 15:35:59.129073
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.dict_transformations import recursive_diff

# Generated at 2022-06-20 15:36:05.086311
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {
        'name': 'bo',
        'age': '42'
    }
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias_name']},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)

    result = validator.validate(parameter)
    assert len(result.errors) == 0
    assert len(result.validated_parameters) == 2



# Generated at 2022-06-20 15:36:11.990028
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': dict(type='str'),
        'age': dict(type='int'),
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:36:19.375850
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.validated_parameters == {}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()


# Generated at 2022-06-20 15:36:32.070451
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
        ['age', 'name'],
        ['age', 'age']
    ]
    required_together = [
        ['name', 'age'],
        ['age', 'name'],
        ['age', 'age']
    ]
    required_one_of = [
        ['name', 'age'],
        ['age', 'name'],
        ['age', 'age']
    ]
    required_if = [
        [],
        ['name', 'age'],
        ['age', 'name'],
        ['age', 'age']
    ]

# Generated at 2022-06-20 15:36:38.174769
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    class FakeArgs:
        pass

    args = FakeArgs()
    args.params = {}
    args.mutually_exclusive = []
    args.required_together = []
    args.required_one_of = []
    args.required_if = []
    args.required_by = {}

    validator = ModuleArgumentSpecValidator(args)

    assert validator.validate(args.params) is not None

# Generated at 2022-06-20 15:36:48.580933
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit testing for ModuleArgumentSpecValidator class constructor."""

    import copy

    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'},
                     }


    SPEC_REQUIRED_KEYS = (
        'name',
        'required',
        'type',
    )

# Generated at 2022-06-20 15:36:59.505969
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():  # pylint: disable=missing-function-docstring
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [
        ['name', 'bo', ['age']],
        ['name', 'bo', ['age', 'baz']],
    ]
    required_by = {'age': ['name']}


# Generated at 2022-06-20 15:37:05.332143
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test the validate method of ArgumentSpecValidator.
    """
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes


# Generated at 2022-06-20 15:37:06.656816
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'a': 1})
    assert result


# Generated at 2022-06-20 15:37:08.781327
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)
    assert ModuleArgumentSpecValidator == ArgumentSpecValidator

# Generated at 2022-06-20 15:37:11.648549
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import mock

    with mock.patch('ansible.module_utils.common.arg_spec.ArgumentSpecValidator.validate') as validate:
        result = ModuleArgumentSpecValidator(argument_spec={}).validate({'foo': 'bar'})
        validate.assert_called_once_with({'foo': 'bar'})

        assert result == validate.return_value

# Generated at 2022-06-20 15:37:17.754410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    # This unit test is for method validate of class ModuleArgumentSpecValidator
    # The test data is from real usage example, with replacement of module name,
    # argument spec, and parameters
    """
    module_name = 'test_module_name'
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None


# Generated at 2022-06-20 15:37:26.020312
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test the method validate of class ArgumentSpecValidator.

    """
    # Test Parameters
    parameters = {"name": "bo", "age": "42"}
    parameters_clone = deepcopy(parameters)
    # Test ArgumentSpecValidator()
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None


# Generated at 2022-06-20 15:37:35.201164
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert(type(ModuleArgumentSpecValidator({"argument_spec": dict()})) is ModuleArgumentSpecValidator)


# Generated at 2022-06-20 15:37:45.955591
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    _validator = ArgumentSpecValidator({'a': {'required': True, 'type': 'int'}, 'b': {'required': False, 'type': 'int'}})

    # scenario 2
    result = _validator.validate({'a': 1, 'b': 2})
    assert 'a' in result.validated_parameters
    assert 'b' in result.validated_parameters
    assert result.validated_parameters['a'] == 1
    assert result.validated_parameters['b'] == 2

    # scenario 3
    result = _validator.validate({'a': 1})
    assert 'a' in result.validated_parameters
    assert 'b' not in result.validated_parameters

# Generated at 2022-06-20 15:37:51.089010
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-20 15:37:52.016778
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert 1 == 1

# Generated at 2022-06-20 15:38:03.163487
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    ''' Test the __init__ method of the ArgumentSpecValidator class'''
    valid_spec = dict(
        name = dict(required=True, type='str', aliases=['name']),
        age = dict(required=False, type='int', aliases=['age']),
    )

    invalid_spec = dict(
        name = dict(required=True, type='str'),
        age = dict(required=False, type='int', aliases=['age']),
    )

    mutually_exclusive = dict(
        mutually_exclusive=[['name1', 'name2', 'name3'], ['name4', 'name5']]
    )

    required_together = dict(
        required_together=[['name1', 'name2'], ['name3', 'name4',  'name5']]
    )

    required_one_

# Generated at 2022-06-20 15:38:05.213379
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    asv = ModuleArgumentSpecValidator({})
    assert isinstance(asv, ArgumentSpecValidator)


# Generated at 2022-06-20 15:38:09.234350
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    myValidationResult = ValidationResult({'key':'value'})
    assert myValidationResult.validated_parameters == {'key': 'value'}
    assert myValidationResult._no_log_values  == set()
    assert myValidationResult._unsupported_parameters == set()
    assert myValidationResult.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-20 15:38:11.158476
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult({}), ValidationResult)


# Generated at 2022-06-20 15:38:21.545526
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common.parameters import truncate_message
    import sys
    import json

    if PY2:
        from ansible.module_utils.common.text.converters import to_text
    else:
        to_text = None

    valid_parameter_types = (
        [str, type(None)],
        [str],
        [str, float],
        [str, float, int],
        [str, float, int, type(None)],
    )


# Generated at 2022-06-20 15:38:31.508632
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # argument_spec as defined in AnsibleModule
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # mutually_exclusive as defined in AnsibleModule
    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'foo'],
        ['name', 'bar'],
        ['age', 'foo'],
        ['age', 'bar'],
    ]

    # required_together as defined in AnsibleModule
    required_together = [
        ['name', 'age']
    ]

    # required_one_of as defined in AnsibleModule
    required_one_of = [
        ['name', 'age']
    ]

    # required_if as defined in AnsibleModule

# Generated at 2022-06-20 15:38:41.666039
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(None).argument_spec is None
    assert ArgumentSpecValidator(42).argument_spec == 42
    assert ArgumentSpecValidator("str").argument_spec == "str"
    assert ArgumentSpecValidator({}).argument_spec == {}



# Generated at 2022-06-20 15:38:43.908476
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    obj = ModuleArgumentSpecValidator(argument_spec={})
    assert obj is not None

if __name__ == '__main__':
    test_ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:38:49.433597
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import os
    import json
    # Load the main module directory
    module_path = os.path.join(os.path.dirname(__file__), '..', '..')
    # Load the file containing the example argument spec
    with open(os.path.join(module_path, 'doc', 'examples', 'example_argument_spec.json')) as f:
        # Since dump() writes the spec from a different format, only the first
        # item will be used for testing
        example_spec = json.load(f)[0]
    # Instantiate the class with the example spec
    validator = ModuleArgumentSpecValidator(example_spec)
    # Verify that the returned validator is of the correct type
    assert isinstance(validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:38:50.481740
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator()

# Generated at 2022-06-20 15:38:53.486517
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # pylint: disable=unused-variable
    errors = AnsibleValidationErrorMultiple()
    result = ValidationResult({})

# Generated at 2022-06-20 15:38:57.124044
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""

    result = ValidationResult({'name': 'bo', 'age': '42'})
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate({'name': 'bo', 'age': '42'})

    assert not result.error_messages
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:39:05.183909
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockAnsibleModule:
        def __init__(self):
            self.deprecations = []
            self.warnings = []

        def deprecate(self, msg, **kwargs):
            self.deprecations.append({'msg': msg, 'kwargs': kwargs})

        def warn(self, msg):
            self.warnings.append(msg)

    mod = MockAnsibleModule()
    MockAnsibleModule.deprecate = mod.deprecate
    MockAnsibleModule.warn = mod.warn

    spec = dict(
        name=dict(required=True, type='str'),
        age=dict(required=True, type='int'),
        force=dict(default='no', type='bool'),
    )

    validator = ModuleArgumentSpecValidator(spec)
   

# Generated at 2022-06-20 15:39:08.842820
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator is not None


# Generated at 2022-06-20 15:39:18.604232
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = dict(
        name = dict(type='str', required=True),
        age = dict(type='int'),
        gender = dict(type='str', default='male'),
        married = dict(type='bool', default='yes'),
        children = dict(type='list'),
        pets = dict(type='list')
    )

    validator = ArgumentSpecValidator(spec)

    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set(['age', 'children', 'gender', 'married', 'name', 'pets'])
    assert validator.argument_spec is spec

# Generated at 2022-06-20 15:39:20.318516
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'name': 'bo'}).validated_parameters == {'name': 'bo'}

# Generated at 2022-06-20 15:39:35.058556
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult(parameters={'a': 'b'}), ValidationResult)

# Generated at 2022-06-20 15:39:45.165926
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # init ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    # parameters input is empty
    parameters = {}
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters
    assert result.error_messages == []

    # parameters input is None
    parameters = None
    result = validator.validate(parameters)
    assert result.validated_parameters == {}
    assert result.error_messages == []

    # parameters input is invalid type
    parameters = []
    result = validator.validate(parameters)
    assert result.validated_parameters == {}
    assert result.error_mess

# Generated at 2022-06-20 15:39:51.741883
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    # Example for testing:
    #     argument_spec = {
    #         'name': {'type': 'str'},
    #         'age': {'type': 'int'},
    #     }
    #
    #     parameters = {
    #         'name': 'bo',
    #         'age': '42',
    #     }
    #
    #     validator = ArgumentSpecValidator(argument_spec)
    #     result = validator.validate(parameters)
    #
    #     if result.error_messages:
    #         sys.exit("Validation failed: {0}".format(", ".join(result.error_messages))
    #
    #     valid_params = result.validated_parameters



# Generated at 2022-06-20 15:40:00.982218
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = dict(
        a1=dict(type='str'),
        b1=dict(type='int'),
    )

    mutually_exclusive = [
        ['a1', 'b1']
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = dict(
        a1='Hello',
        b1=42,
    )

    result = validator.validate(parameters)
    if result.errors:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))


# Generated at 2022-06-20 15:40:08.300596
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'version': {'type': 'float'},
        'bool': {'type': 'bool'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['bool', 'age'],
    ]

    inputs = (
        {'name': 'bo', 'age': '42'},
        {'bool': False, 'age': 25},
        {'bool': True, 'age': 25},
        {'age': 35},
        {'bool': False},
    )

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                     )


# Generated at 2022-06-20 15:40:15.138118
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters



# Generated at 2022-06-20 15:40:26.157099
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_bytes

    argument_spec = dict(
        a=dict(type='str'),
        b=dict(type='str'),
        c=dict(type='str'),
        d=dict(type='str'),
    )

    mutually_exclusive = [['a', 'b'], ['b', 'c']]
    required_together = [['a', 'c'], ['b', 'd']]
    required_one_of = [['a', 'b']]
    required_if = [['a', 'b', ['c', 'd']]]
    required_by = dict(
        a=['c'],
        b=['d']
    )


# Generated at 2022-06-20 15:40:29.053814
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-20 15:40:36.485469
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''Unit test for ArgumentSpecValidator class'''

    # pylint: disable=too-few-public-methods
    class Obj(object):
        """Object class for testing."""

    obj = Obj()
    obj.foo = "foo"

    argument_spec = {
        'foo': {'type': 'int'},
        'bar': {'type': 'dict'},
    }

    expected = set([('foo', 'bar')])
    mutually_exclusive = [
        ['foo', 'bar'],
    ]

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      )

    result = validator.validate(obj.__dict__)


# Generated at 2022-06-20 15:40:48.204387
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # unit test for method validate of class ArgumentSpecValidator
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # type args
    argument_spec = {'test': {'type': 'str'}}

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {'test': 'some text'}
    result = validator.validate(parameters)
    assert parameters == result.validated_parameters

    parameters = {'test': 12345}
    result = validator.validate(parameters)
    assert result.error_messages == ["The 'test' parameter value is invalid type (<class 'int'>, must be of <class 'str'>)"]

    # required
    argument_spec = {'test': {'type': 'str', 'required': True}}


# Generated at 2022-06-20 15:41:05.590353
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_spec = {'name': {'type': 'str'}}
    assert isinstance(ModuleArgumentSpecValidator(test_spec), ArgumentSpecValidator)


# Generated at 2022-06-20 15:41:13.949675
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator(argument_spec={})
    assert m.argument_spec == {}
    assert m._mutually_exclusive is None
    assert m._required_together is None
    assert m._required_one_of is None
    assert m._required_if is None
    assert m._required_by is None
    assert m._valid_parameter_names == set()

    m = ModuleArgumentSpecValidator({'a': {}}, a=1, b=2)
    assert m.argument_spec == {'a': {}}
    assert m._mutually_exclusive == 1
    assert m._required_together == 2
    assert m._valid_parameter_names == set(['a'])



# Generated at 2022-06-20 15:41:23.067076
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    params = {'name' : None, 'path': '/tmp'}
    mue = None
    argument_spec = {'name': {'type': 'str', 'choices': ['foo', 'bar']},
                     'path': {'type': 'path'},
                     'recurse': {'type': 'bool', 'default': False},
                     'state': {'default': 'present', 'choices': ['absent', 'present']},
                     'type': {'default': 'file', 'choices': ['file', 'directory']},
                     'group': {'type': 'str'},
                     'owner': {'type': 'str'},
                     'mode': {'type': 'str', 'default': '0755'}}

# Generated at 2022-06-20 15:41:25.366987
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo', 'age': '42'})
    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert result.unsupported_parameters == set()



# Generated at 2022-06-20 15:41:36.862882
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # test argument_spec
    args = dict()
    args['host'] = dict()
    args['host']['default'] = 'localhost'
    args['host']['type'] = 'str'

    args['port'] = dict()
    args['port']['default'] = 22
    args['port']['type'] = 'int'
    args['port']['choices'] = [22, 80]

    args['aliases'] = dict()
    args['aliases']['aliases'] = ['aliases_name']

    args['aliases_with_default'] = dict()
    args['aliases_with_default']['aliases'] = ['aliases_with_default_name']
    args['aliases_with_default']['default'] = 'default'

    args['aliased_choice']

# Generated at 2022-06-20 15:41:47.821786
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=None,
                                            required_together=None, required_one_of=None,
                                            required_if=None, required_by=None
                                            )
    result = validator.validate(parameters)
    assert result._unsupported_parameters == set()
    assert result.errors == []
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-20 15:41:56.191423
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutually_exclusive = [
        ['one', 'two']
    ]
    required_together = [
        ['one', 'two']
    ]
    required_one_of = [
        ['one', 'two']
    ]
    required_if = [
        ['one', 'two', 'three']
    ]
    required_by = {
        'one': 'two'
    }


# Generated at 2022-06-20 15:42:00.004209
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'debug': {'aliases': ['blah']}}
    result = ModuleArgumentSpecValidator(argument_spec=argument_spec).validate({'debug': True, 'blah': False})
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-20 15:42:09.369729
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test method validate of class ArgumentSpecValidator"""

    # Validation with different types of argument spec
    # alias and type
    validator_alias_type = ArgumentSpecValidator({"name": {"type": "str", "aliases": ["user"]},
                                                  "age": {"type": "int"},
                                                  "hobbies": {"type": "list", "elements": "str"},
                                                  "job": {"type": "dict", "options": {"company": {"type": "str"}}},
                                                  })
    parameters_alias_type = {"name": "bo", "age": "42", "hobbies": "books", "job": {"company": "ansible"}}
    result_alias_type = validator_alias_type.validate(parameters_alias_type)

# Generated at 2022-06-20 15:42:10.216014
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult(parameters={'user': 'root'})

# Generated at 2022-06-20 15:42:35.614882
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.error_messages == []


# Generated at 2022-06-20 15:42:41.928526
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    ''' test ArgumentSpecValidator constructor '''
    arg_spec = {
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'path': {'type': 'str'},
    }

    mutually_exclusive = [['state', 'foo'], ['path', 'bar']]
    required_together = [['state', 'path']]
    required_one_of = [['state', 'path']]
    required_if = [{'state': 'present', 'required': ['path']}]
    required_by = {'required_by': ['state']}


# Generated at 2022-06-20 15:42:45.566690
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator(argument_spec={'param': {'type': 'str'}})
    except TypeError:
        pytest.fail('Could not initialize ModuleArgumentSpecValidator()')

# Generated at 2022-06-20 15:42:48.377029
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-20 15:42:51.894871
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec



# Generated at 2022-06-20 15:43:01.682303
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters = {'name': 'bo',
                                            'age': '42',
                                            'num_stars': 'one'})

    assert result._validated_parameters == {'name': 'bo', 'age': '42', 'num_stars': 'one'}

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'name': 'bo',
                                            'age': '42',
                                            'num_stars': 'one'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []



# Generated at 2022-06-20 15:43:13.075420
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Only exception cases should be tested.
    # 1. deprecation and warning are added
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alternate_name']},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    parameters = {
        'name': 'bo',
        'alternate_name': 'john',
    }
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo'}
    assert len(result._deprecations)

# Generated at 2022-06-20 15:43:19.881011
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))


# Generated at 2022-06-20 15:43:30.062690
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    Unit test for ArgumentSpecValidator class
    :return: None
    '''
    argument_spec = {
        'name': {'required': True, 'type': 'str'},
        'pwd': {'required': True, 'type': 'str', 'no_log': True},
    }

    mutually_exclusive = [['name', 'dummy1'], ['pwd', 'dummy2']]

    required_together = [['name', 'pwd']]

    required_one_of = [
        ['dummy1', 'dummy2'],
        ['dummy3', 'dummy4'],
        ['dummy5']
    ]


# Generated at 2022-06-20 15:43:34.956187
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'aliases': [],
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages