

# Generated at 2022-06-20 15:33:58.259990
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    "Unit test for constructor of class ArgumentSpecValidator"
    args = [
        {'age': {'type': 'int'}},
        {'mutually_exclusive': None},
        {'required_together': None},
        {'required_one_of': None},
        {'required_if': None},
        {'required_by': None}
    ]

    assert ArgumentSpecValidator(*args) is not None


# Generated at 2022-06-20 15:34:05.471569
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = {
        'name': 'ansible',
        'age': 42,
        'state': 'present',
        'data': {
            'tmp': {
                'foo': 'bar',
                'baz': 42,
            },
        },
    }

# Generated at 2022-06-20 15:34:11.923539
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }).validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-20 15:34:23.278212
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    class TestClass:
        def __init__(self, *args):
            assert len(args) == 5
            assert isinstance(args[0], dict)
            assert args[1] == ['a', 'b']
            assert args[2] == [['c', 'd']]
            assert args[3] == ['e', 'f']
            assert args[4] == {'g': ['h', 'i'], 'l': ['j', 'k']}

    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'str'}}
    mutually_exclusive = [['a', 'b'], ['c', 'd']]
    required_together = [['e', 'f']]

# Generated at 2022-06-20 15:34:34.281789
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Empty argument_spec
    arg_spec = dict()
    validator = ArgumentSpecValidator(arg_spec)
    assert validator.argument_spec == arg_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set()
    assert repr(validator) == "<ArgumentSpecValidator validator=<ArgumentSpecValidator argument_spec=<NoArgumentSpecValidator argument_spec={}>>"

    # Test with argument_spec
    arg_spec = {
        'name': dict(type=str),
        'age': dict(type=int),
    }
    valid

# Generated at 2022-06-20 15:34:47.345427
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    def _check_validate_result(validator, parameters, expected_result):
        result = validator.validate(parameters)

        for check in expected_result['checks']:
            for attr, value in check.items():
                assert getattr(result, attr) == value

        assert result.error_messages == expected_result['errors']

    # Only used for testing, not classes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.parameters import sanitize_keys


# Generated at 2022-06-20 15:34:55.852637
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    required_together = [
        ['name', 'age']
    ]

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'fred', ['age']]
    ]

    required_by = {
        'name': ['age']
    }

    required_one_of = [
        ['name', 'age']
    ]


# Generated at 2022-06-20 15:34:56.680529
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    assert validator.validate({})

# Generated at 2022-06-20 15:34:58.483512
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'param1': 1,
        'param2': 2,
        'param3': 3,
    }

    result = ValidationResult(parameters)
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-20 15:35:09.299338
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age', ['age']],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-20 15:35:18.541749
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    param = {"a": 1}
    v = ValidationResult(param)
    assert v._validated_parameters == param

# Generated at 2022-06-20 15:35:23.739388
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == []


# Generated at 2022-06-20 15:35:26.276123
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo'}
    assert ValidationResult(parameters)


# Generated at 2022-06-20 15:35:36.111257
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'param1': {'type': 'str'},
            'param2': {'type': 'str', 'aliases': ['param2a', 'param2b']},
            'param3': {'type': 'str', 'aliases': ['param3a', 'param3b']},
            'param4': {'type': 'str', 'required': True},
        },
    )

    # Test handling of : option
    parameters = {
        'param1': 'value1'
    }

    result = validator.validate(parameters)
    assert not result.error_messages

    # Test handling of : option

# Generated at 2022-06-20 15:35:40.953205
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import json
    result = ModuleArgumentSpecValidator({})
    # validate is not implemented in the base class
    try:
        result.validate({})
    except NotImplementedError:
        pass
    else:
        raise Exception('result.validate() was not supposed to be implemented in the base class')

# Generated at 2022-06-20 15:35:45.306612
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    module_arg_spec={'name':{'required': True, 'type': 'str'}, 'age':{'required': True, 'type': 'int'}}
    parameters={'name': 'Matt', 'age': '20'}

    validator=ModuleArgumentSpecValidator(module_arg_spec)
    result=validator.validate(parameters)

    assert result.error_messages == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-20 15:35:50.362386
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator(argument_spec=None,
                               mutually_exclusive=None,
                               required_together=None,
                               required_one_of=None,
                               required_if=None,
                               required_by=None,
    )
    assert isinstance(m, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:36:00.158257
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    def my_arg_spec():
        return {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            'foo': {'type': 'str'},
            'bar': {'type': 'str'},
            'baz': {'type': 'str'},
            'qux': {'type': 'str'},
        }

    def my_main():
        module = AnsibleModule(argument_spec=my_arg_spec())

        module.deprecate('foo', version='1.0', date='2017-01-01', collection_name='my.collection')
        module.warn('foo', 'bar')

        module.exit_json(**module.params)


# Generated at 2022-06-20 15:36:05.542649
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    arg_spec_validator = ArgumentSpecValidator({})
    parameters = {'name': 'ansible', 'age': 42}
    result = arg_spec_validator.validate(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-20 15:36:16.532697
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    This is a test method to test the class ArgumentSpecValidator.validate()
    """
    def unit_test_ArgumentSpecValidator_validate():
        """
        This is the test function to test the class ArgumentSpecValidator.validate()
        """
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            'last_name': {'type': 'str'},
            'location': {'type': 'str'},
        }
        parameters = {
            'name': 'bo',
            'age': '42',
            'last_name': 'foo',
            'location': 'bar',
        }
        mutually_exclusive = [['name', 'last_name']]

# Generated at 2022-06-20 15:36:29.161799
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive = [
                     ['name', 'age']
                 ],
                 required_together = [
                     ['name', 'age']
                 ],
                 required_one_of = [
                     ['name', 'age']
                 ],
                 required_if = [
                     ['name', 'age']
                 ],
                 required_by = {
                     'age': 'name'
                 })

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    expected_output = {
        'name': 'bo',
        'age': 42,
    }

    result = validator.validate

# Generated at 2022-06-20 15:36:37.541744
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert isinstance(result, ValidationResult)
    assert result.errors is not None
    assert result._validated_parameters
    assert result.validated_parameters
    assert result._unsupported_parameters
    assert result.unsupported_parameters
    assert result._no_log_values
    assert result.error_messages


# Generated at 2022-06-20 15:36:39.329596
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}) == {}, "ValidationResult(None) returns None"

# Generated at 2022-06-20 15:36:49.068008
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:36:55.048574
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    :description: Test constructor of class ArgumentSpecValidator
    :steps:
        1. Instantiate ArgumentSpecValidator with mutually_exclusive, required_together, required_one_of, required_if, required_by
    :expected results:
        1. Check all the parameters are set correctly
    """

    mutually_exclusive = [['a', 'b'], ['a', 'c']]
    required_together = [['a', 'b'], ['b', 'c']]
    required_one_of = [['a', 'b'], ['b', 'c']]
    required_if = [['a', 'b', ['b', 'c']], ['b', 'c', ['c', 'd']]]
    required_by = {'a': ['b'], 'b': ['c']}


# Generated at 2022-06-20 15:37:03.110713
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator()
    assert hasattr(validator, 'argument_spec')
    assert validator.argument_spec is None
    assert hasattr(validator, '_mutually_exclusive')
    assert validator._mutually_exclusive is None
    assert hasattr(validator, '_required_together')
    assert validator._required_together is None
    assert hasattr(validator, '_required_one_of')
    assert validator._required_one_of is None
    assert hasattr(validator, '_required_if')
    assert validator._required_if is None
    assert hasattr(validator, '_required_by')
    assert validator._required_by is None
    assert hasattr(validator, '_valid_parameter_names')
    assert validator._valid_param

# Generated at 2022-06-20 15:37:12.217313
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Example of spec that contains deprecation of alias "foo"
    spec = {
        'foo': {
            'type': 'str',
            'aliases': ['bar'],
            'deprecated': {
                'msg': 'Aliases are deprecated',
                'collection_name': 'ansible.builtin',
                'version': '2.11'
            }
        }
    }
    # Example of parameters that match the spec
    parameters = {
        'foo': 'option foo set',
        'bar': 'option bar set'
    }

    # Class for testing
    class MockAnsibleModule:
        def __init__(spec, parameters):
            self.params = parameters

    mock_module = MockAnsibleModule(spec, parameters)
    # Prepare the validator
    validator = ModuleArgumentSpecValid

# Generated at 2022-06-20 15:37:23.324627
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeValidationResult:
        def __init__(self, result):
            self.result = result
        def __iter__(self):
            return iter(self.result)

    class FakeAnsibleModule:
        def __init__(self, result):
            self._result = FakeValidationResult(result)

    validator = ModuleArgumentSpecValidator({})
    validator._deprecations = [{'name': 'test deprecation'}]
    validator._warnings = [{'option': 'name', 'alias': 'alias'}]

    with FakeAnsibleModule({}) as module_result:
        validator.validate({})

# Generated at 2022-06-20 15:37:32.492156
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    instance_1 = ModuleArgumentSpecValidator(
                argument_spec={
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                },
                required_one_of=[[], ], 
                required_by=dict(), 
                required_if=[], 
                required_together=[[], ], 
                mutually_exclusive=[[]], 
            )
    parameters_1 = dict()
    result_1 = instance_1.validate(parameters_1)
    assert result_1 is not None



# Generated at 2022-06-20 15:37:44.324282
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    res = {'warnings': [], 'deprecations': []}
    result = ModuleArgumentSpecValidator(argument_spec={
        'meta1': {'type': 'dict'},
        'meta2': {'type': 'dict'},
        'meta3': {'type': 'dict'}
    }, mutually_exclusive=[], required_together=[], required_one_of=[], required_if=[], required_by={}).validate(
        parameters={'meta1': {'meta1_1': 'val1'}, 'meta2': {'meta2_1': 'val2'}, 'meta3': {'meta3_1': 'val3'}})


# Generated at 2022-06-20 15:37:51.511371
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:38:02.769636
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'friends': {
            'type': 'list',
            'elements': 'str'
        }
    }

    mutually_exclusive = [
        ["name", "age"],
        ["name", "friends"],
        ["age", "friends"]
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
        'friends': 'bob',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:38:04.231700
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={})
    assert result._no_log_values == set()

# Generated at 2022-06-20 15:38:04.974989
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:38:09.874903
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({})
    assert validator.argument_spec == {}
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set()


# Unit tests for the method ModuleArgumentSpecValidator.validate

# Generated at 2022-06-20 15:38:21.086485
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True,
            'version_added': '2.8',
        },
        'age': {
            'type': 'int',
            'default': 42,
        },
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', '==', 'age'],
    ]

    required_by = {
        'name': ['age'],
        'age': ['name'],
    }


# Generated at 2022-06-20 15:38:27.297984
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test ModuleArgumentSpecValidator constructor."""
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ModuleArgumentSpecValidator(
        argument_spec, mutually_exclusive=['name', 'age'],
        required_together=['name', 'age'], required_one_of=['name', 'age'],
        required_if=['name', 'age'], required_by=['name', 'age'])
    assert validator._mutually_exclusive == ['name', 'age']
    assert validator._required_together == [['name', 'age']]
    assert validator._required_one_of == [['name', 'age']]
    assert validator._required_if == [['name', 'age', None]]
    assert validator

# Generated at 2022-06-20 15:38:36.750310
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common._text.compat import ensure_text
    # construct argument_spec

# Generated at 2022-06-20 15:38:45.676706
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'}
    }

    mutually_exclusive = ['name']
    required_together = [['name']]
    required_one_of = [['name']]
    required_if = [['name', 'hello', ['age']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

    assert set(validator.argument_spec) == {'name'}
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._

# Generated at 2022-06-20 15:38:54.465900
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = { 'name': 'bo', 'age': '42' }
    validation_result = ValidationResult(parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == parameters
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.validated_parameters == parameters
    assert validation_result.unsupported_parameters == set()
    assert validation_result.error_messages == []

# Generated at 2022-06-20 15:39:16.927793
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult(parameters={})
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == {}
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors.messages == []

# Generated at 2022-06-20 15:39:21.423405
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Prepare for the test
    import textwrap
    from collections import namedtuple
    from ansible.module_utils.common.parameters import _VALID_ARGUMENT_SPEC
    from ansible.module_utils.common.warnings import reset_deprecations

    Fake_AnsibleModule = namedtuple('Fake_AnsibleModule', ['argument_spec', '_aliases', '_no_log_values', 'fail_json'])

# Generated at 2022-06-20 15:39:22.198856
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    pass


# Generated at 2022-06-20 15:39:28.090019
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}

    parameters = {'name': 'bo',
                  'age': '42'}
    # Create an instance of ArgumentSpecValidator
    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    # Check if result type is ValidationResult
    assert type(result) == ValidationResult

    # Check if error_messages is empty
    if result.error_messages:
        assert len(result.error_messages) == 0
    else:
        assert False

    assert 'name' in result.validated_parameters
    assert result.validated_parameters['name'] == 'bo'
    assert 'age' in result.validated_parameters


# Generated at 2022-06-20 15:39:36.501859
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == []

# Generated at 2022-06-20 15:39:39.154109
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)
    assert issubclass(ModuleArgumentSpecValidator, object)



# Generated at 2022-06-20 15:39:48.255372
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    def test_init_ValidationResult(parameters):
        result = ValidationResult(parameters)
        assert isinstance(result, ValidationResult)
        assert result._no_log_values is not None
        assert result._unsupported_parameters is not None
        assert isinstance(result._validated_parameters, dict)
        assert len(result._validated_parameters) == 0
        assert result._deprecations is not None
        assert result._warnings is not None
        assert result.errors is not None
        assert isinstance(result.errors, list)
        assert len(result.errors) == 0

    parameters = {}
    test_init_ValidationResult(parameters)
    parameters = {'name' : 'tommy'}
    test_init_ValidationResult(parameters)


# Generated at 2022-06-20 15:39:59.932232
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str', 'required': True}, 'age': {'type': 'int'}, 'sex': {'type': 'str', 'required': True, 'choices': ['Male', 'Female']}}
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'sex']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'bob', ['age']]]

    try:
        argument_spec_validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                                        required_one_of, required_if)
    except Exception as e:
        assert False, "Unable to create ArgumentSpecValidator object: %s" % to_native(e)


# Generated at 2022-06-20 15:40:07.626271
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    a = {'name': {'type': 'str', 'required': False, 'no_log': False},
         'age': {'type': 'int', 'required': True, 'no_log': False},
         'pets': {'type': 'list', 'required': False, 'no_log': False, 'default': [],
                  'elements': 'dict',
                  'options': {'name': {'type': 'str', 'required': True},
                              'age': {'type': 'int', 'required': True},
                              'species': {'type': 'str', 'required': False, 'default': 'dog'}
                              }
                  },
         }
    p = {'name': 'bo', 'age': 42}
    m = ModuleArgumentSpecValidator(a)
    r = m.valid

# Generated at 2022-06-20 15:40:11.210291
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test__init__
    parameters = {'username': 'david', 'password': 'mysecret'}
    vr = ValidationResult(parameters)
    assert vr._validated_parameters == parameters
    assert vr.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-20 15:40:32.438246
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_data = {'a': 1, 'b': 2}
    result = ValidationResult(test_data)
    assert result._validated_parameters == test_data, "validated_parameters should equal test_data"
    assert result._no_log_values == set(), "no_log_values should be empty"
    assert result._unsupported_parameters == set(), "unsupported_parameters should be empty"
    assert result._deprecations == [], "deprecations should be empty"
    assert result._warnings == [], "warnings should be empty"
    assert result.errors == AnsibleValidationErrorMultiple(), "errors should be empty"

# Unit tests for constructor of class ArgumentSpecValidator

# Generated at 2022-06-20 15:40:38.665423
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:40:49.772851
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    mutually_exclusive = ['a']
    required_together = ['b']
    required_one_of = ['c']
    required_if = ['d']
    required_by = ['e']
    argument_spec = {
        'required_argument': {'type': 'str', 'required': True},
        'optional_argument': {'type': 'str', 'required': False},
        'sub_spec': {
            'sub_required_argument': {'type': 'str', 'required': True},
        },
    }


# Generated at 2022-06-20 15:40:57.063004
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = list()
    class A:
        def deprecate(*args):
            result.extend(args)
    class B:
        def warn(*args):
            result.extend(args)
    import sys
    class C:
        def exit(*args):
            raise TypeError(args)

    sys.modules['ansible.module_utils.basic'] = A()
    sys.modules['ansible.module_utils.common.warnings'] = B()
    sys.modules['ansible.module_utils.six'] = C()

# Generated at 2022-06-20 15:41:00.313912
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {'list_key': ['value1', 'value2'], 'dict_key': {'dict_key1': {'value1': 'value1', 'value2': 'value2'}}}
    vr = ValidationResult(parameter)
    assert vr.validated_parameters == parameter
    assert vr._no_log_values == set()
    assert vr.errors.messages == list()


# Generated at 2022-06-20 15:41:10.854852
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # TODO: Refactor this to use pytest fixtures with pytest.param, as well as using
    # the validation result object in the test rather than checking for exceptions.
    # That would allow for better tests and better error reporting.

    # The 'name' parameter is required
    argument_spec = {'name': {'type': 'str'}}

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {}
    result = validator.validate(parameters)
    assert result.error_messages == ['The required arguments were not provided.']

    parameters['name'] = 'bo'
    result = validator.validate(parameters)
    assert result.error_messages == []

    # 'name' and 'age' can not both be provided

# Generated at 2022-06-20 15:41:18.791907
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ..module_utils.common.arg_spec import ArgumentSpecValidator
    from ..module_utils.common.parameters import sanitize_keys
    import random
    import string


# Generated at 2022-06-20 15:41:21.326329
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-20 15:41:31.466143
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import json

    argument_spec = {"name": {'type': 'str'}, "age": {'type': 'int'}}
    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age", ["age", "name"]]]
    required_by = {"name": ["age"]}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if,required_by)

    assert json.dumps(validator.argument_spec) == json.dumps(argument_spec)
    assert json.dumps(validator._mutually_exclusive) == json.dumps(mutually_exclusive)

# Generated at 2022-06-20 15:41:43.045640
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:42:11.398212
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)



# Generated at 2022-06-20 15:42:16.412387
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict(a=1)
    vr = ValidationResult(parameters)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == dict(a=1)
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors == {}
    assert vr.validated_parameters == dict(a=1)
    assert vr.unsupported_parameters == set()
    assert vr.error_messages == []


# Generated at 2022-06-20 15:42:17.577105
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator,ArgumentSpecValidator)


# Generated at 2022-06-20 15:42:21.637422
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator('argument_spec', mutually_exclusive=['a','b','c'], required_together=['a','b','c'], required_one_of=['a','b','c'], required_if=['a','b','c'], required_by=['a','b','c'])

# Generated at 2022-06-20 15:42:28.704370
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(not result.error_messages)
    assert(result.validated_parameters['age'] == 42)

# Generated at 2022-06-20 15:42:38.482904
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['a', 'b'],
        ['c', 'd'],
    ]
    required_together = [
        ['a', 'b']
    ]
    required_one_of = [
        ['a', 'b']
    ]
    required_if = [
        ['a', 'b', ['c', 'd']]
    ]
    required_by = {
        'a': 'b'
    }
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive

# Generated at 2022-06-20 15:42:45.012268
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test constructor of class ArgumentSpecValidator."""

    # Test for all non-recursive use
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['a', 'b'], ['c', 'd']]
    required_together = [['a', 'b'], ['c', 'd']]
    required_one_of = [['a', 'b'], ['c', 'd']]
    required_if = ['a', 'b', ['c', 'd']]
    required_by = {
        'a': ['b', 'c'],
        'b': ['c', 'd'],
    }


# Generated at 2022-06-20 15:42:48.213131
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    expected_argument_spec = {'arg': {}}

    validator = ArgumentSpecValidator(expected_argument_spec)
    assert validator.argument_spec == expected_argument_spec



# Generated at 2022-06-20 15:42:58.786496
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.parameters import (sanitize_keys,
                                                        sanitize_values,
                                                        Extractions)
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 15:43:02.132687
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    v = ModuleArgumentSpecValidator(argument_spec=dict(), mutually_exclusive=None,
                                    required_together=None, required_one_of=None,
                                    required_if=None, required_by=None, )
    assert isinstance(v, ModuleArgumentSpecValidator)

# Generated at 2022-06-20 15:43:39.746602
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert result.error_messages == []
    assert {'name': 'bo', 'age': 42} == result.validated_parameters