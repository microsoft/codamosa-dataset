

# Generated at 2022-06-20 15:33:51.225744
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert type(ArgumentSpecValidator({})) == ArgumentSpecValidator

# Generated at 2022-06-20 15:34:01.676354
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    # class Mapping
    import sys
    import sys
    import sys
    import sys
    import sys
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    # class Sequence
    import sys

# Generated at 2022-06-20 15:34:04.277464
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({"name": "test", "age": "1"})


# Generated at 2022-06-20 15:34:16.294978
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(argument_spec={})
    assert validator.argument_spec == {}

    validator = ArgumentSpecValidator(argument_spec={}, mutually_exclusive=[])
    assert validator.argument_spec == {}

    validator = ArgumentSpecValidator(argument_spec={}, mutually_exclusive=[[]])
    assert validator.argument_spec == {}

    validator = ArgumentSpecValidator(argument_spec={},
                                      mutually_exclusive=[],
                                      required_together=[],
                                      required_one_of=[],
                                      required_if=[])
    assert validator.argument_spec == {}


# Generated at 2022-06-20 15:34:25.728669
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [['loop', 'count']]
    required_together = [['loop_args', 'loop_args_file']]
    required_one_of = [['src', 'url']]
    required_if = [['src', 'file', ['path']]]
    required_by = {'path': ['src', 'dest', 'state', 'force']}

# Generated at 2022-06-20 15:34:35.534546
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': dict(type='str'),
        'age': dict(type='int'),
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['name2']]
    ]

    required_by = {
        'name': ['name2'],
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert argument_spec == validator.argument_spec
    assert mutually_exclusive == validator._mutually_exclusive
    assert required_together

# Generated at 2022-06-20 15:34:48.420102
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Basic
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result._unsupported_parameters == set()
    assert not result._warnings
    assert not result._deprecations
    assert not result.errors

    # Error
    result = validator.validate({'name': 'bo', 'age': 'foo'})

# Generated at 2022-06-20 15:34:53.073619
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult([1, 2, 3])
    assert len(result.errors) is 0
    assert result.error_messages == []
    assert result.validated_parameters == [1, 2, 3]
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-20 15:35:04.692594
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # If there is a key in the parameters that is not in the argument_spec, then there is an error - unsupported parameter
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'gender': 'male'
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert "Unsupported parameters for" in result.error_messages
    assert "gender" in result.error_messages

    # If there is a key in the parameters that is not in the argument_spec, but that key is in the ArgumentSpecValidator's
    # list of valid parameter names, then it is handled by a sub_

# Generated at 2022-06-20 15:35:05.541746
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-20 15:35:20.315813
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {})

    with pytest.raises(TypeError):
        ArgumentSpecValidator("abc")

    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {"str": 1})

    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {"str": [1]})

    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {"str": {1: 2}})

    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {"str": ""})

    with pytest.raises(TypeError):
        ArgumentSpecValidator(argument_spec = {"str": 0})


# Generated at 2022-06-20 15:35:32.019307
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    def create_spec(specs):
        return ArgumentSpecValidator(argument_spec=specs,
                                     mutually_exclusive=[["name", "age"]],
                                     required_together=[["name", "age"]],
                                     required_one_of=[]).argument_spec

    # If test fails, the ArgumentSpecValidator constructor is not behaving as expected
    assert create_spec({ "name": { "type": "str" } }) == { "name": { "type": "str" } }
    assert create_spec({ "name": { "type": "str" }, "age": { "type": "int" } }) == { "name": { "type": "str" }, "age": { "type": "int" } }

# Generated at 2022-06-20 15:35:36.780749
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Parameters to validate against the argument spec
    parameters = {
        'name': 'test'
    }

    # Create a validator based on the argument_spec
    argument_spec = {
        'name': {
            'type': 'str',
            'default':'repo-test'
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

# Generated at 2022-06-20 15:35:47.873341
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Tests for ArgumentSpecValidator.validate

    Test to make sure that the proper errors and type conversions are
    implemented for the ArgumentSpecValidator's validate method.
    """

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'is_human': {'type': 'bool'},
        'birthday': {'type': 'datetime'},
        'favorite_colors': {'type': 'list'},
        'favorite_foods': {'type': 'dict'},
        'favorite_fruits': {'type': 'set'},
    }

   

# Generated at 2022-06-20 15:35:56.509497
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Create an object by constructor of class ArgumentSpecValidator
    arg_spec_validator = ArgumentSpecValidator({})

    # Check all attributes of this object are not equal to None
    assert arg_spec_validator != None
    assert arg_spec_validator._mutually_exclusive != None
    assert arg_spec_validator._required_together != None
    assert arg_spec_validator._required_one_of != None
    assert arg_spec_validator._required_if != None
    assert arg_spec_validator._required_by != None
    assert arg_spec_validator._valid_parameter_names != None
    assert arg_spec_validator.argument_spec != None

# Generated at 2022-06-20 15:36:05.562152
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:36:16.533962
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Unit test ansible.module_utils.common.arg_spec.ArgumentSpecValidator.validate()
    """

    argument_spec_1 = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }
    arguments_1 = {
        'age': '42',
        'name': 'bo',
    }
    validator_1 = ArgumentSpecValidator(argument_spec_1)
    result_1 = validator_1.validate(arguments_1)
    assert result_1.validated_parameters == {
        'age': 42,
        'name': 'bo',
    }
    assert result_1.error_messages == []


# Generated at 2022-06-20 15:36:24.000520
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class Args:
        name = 'george'
        age = '42'

    args = Args()
    params = vars(args)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(params)

    assert result.errors == []
    assert result._validated_parameters == {'name': 'george', 'age': 42}

# Generated at 2022-06-20 15:36:31.968123
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

    mutually_exclusive = [
        ['name', 'age']
    ]
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Unit test for mutually exclusive
    result = validator.validate(parameters)
    print(result.errors)
    assert result.errors
    try:
        assert result.errors[0] is not None
    except IndexError:
        assert result.error_messages[0] is not None
    else:
        assert result.error_messages[0] == result.errors[0].message

# Generated at 2022-06-20 15:36:37.392194
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argumentSpecValidator = ArgumentSpecValidator({"argument_spec":
                                                  {"arg1": {"required": True},
                                                   "arg2": {"required": True}},
                                                  "mutually_exclusive": [["arg1", "arg2"]],
                                                  "required_if": [["arg1"]]})
    assert argumentSpecValidator


# Generated at 2022-06-20 15:36:55.394397
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    _a = ModuleArgumentSpecValidator
    # Check static properties
    assert _a.__module__ == ModuleArgumentSpecValidator.__module__
    assert _a.__annotations__ == {}
    assert _a.__doc__ == ModuleArgumentSpecValidator.__doc__

    # Check parent references properly
    assert hasattr(_a.__bases__[0], '__name__') == True

    # check static methods
    assert _a.__new__.__func__ == ModuleArgumentSpecValidator.__new__.__func__
    assert _a.__init__.__func__ == ModuleArgumentSpecValidator.__init__.__func__
    assert _a.validate == ModuleArgumentSpecValidator.validate

    return

# Generated at 2022-06-20 15:37:03.055572
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert validator.__class__ == ModuleArgumentSpecValidator


# Generated at 2022-06-20 15:37:12.105386
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'a': {'type': 'dict'}, 'b': {'type': 'int'}}
    mutually_exclusive = [['a', 'b'], [['a'], 'b']]
    required_together = [['a', 'b'], [['a'], 'b']]
    required_one_of = [[[1, 2], ['a']], 'b']
    required_if = [[[1, 2], 'a', 'b'], [[1, 2], ['a'], 'b']]
    required_by = {'a': ['b']}

# Generated at 2022-06-20 15:37:18.216004
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    a = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}})
    result = a.validate({'name': 'bo'})
    assert len(result.errors) == 0
    assert result.validated_parameters == {'name': 'bo'}

# Generated at 2022-06-20 15:37:25.097366
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-20 15:37:35.988968
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_arg_spec = {
        "selected": {
            "default": None,
            "type": "bool",
        },
        "force": {
            "required": False,
            "type": "bool",
            "aliases": ["ignore_lock_status"],
            "deprecated": {
                "msg": "The 'force' option is deprecated ",
                "version": "2.11",
                "collection_name": "community.general",
                "date": "2020-11-10",
            },
        }
    }

    mutex_arg_spec = [["selected", "force"]]
    required_arg_spec = [["selected", "force"]]


# Generated at 2022-06-20 15:37:46.594914
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # test case 1: no mutually_exclusive, required_together, required_one_of, required_if, required_by
    argument_spec = dict(age=dict(type='int', default=25, required=True), name=dict(type='str', required=True))
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None

    # test case 2: all mutually_exclusive, required_together, required_one_of, required_if, required_by

# Generated at 2022-06-20 15:37:54.487488
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    test_arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    validator = ArgumentSpecValidator(test_arg_spec)
    assert validator.argument_spec == test_arg_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == {'age', 'name'}



# Generated at 2022-06-20 15:37:57.203452
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    x = ModuleArgumentSpecValidator("argument")

    assert isinstance(x, ModuleArgumentSpecValidator)
    assert x.argument_spec == "argument"


# Generated at 2022-06-20 15:38:07.237978
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age'], ['name', 'age']]
    required_together = [['name', 'age'], ['name', 'age']]
    required_one_of = [['name', 'age'], ['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']], ['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age'], 'age': ['name']}


# Generated at 2022-06-20 15:38:26.899898
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(name, age):
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }

        module = AnsibleModule(argument_spec=argument_spec,
            mutually_exclusive=[['name', 'age']],
            required_one_of=[['name', 'age']],
            )
        module.params['name'] = name
        module.params['age'] = age

        result = module.validate_parameters()

        assert result["name"] == age
        assert result["age"] == age

    # Argument 'name' is required if argument 'age' is not provided
    test_module(None, None)

    # Argument 'name' is not required if argument 'age

# Generated at 2022-06-20 15:38:33.414628
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''
    unit test for method validate of class ArgumentSpecValidator
    '''
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-20 15:38:40.818041
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ArgumentSpecValidator.validate() unit test."""
    import os
    import sys


# Generated at 2022-06-20 15:38:47.923468
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # create a mock argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # create a validator with the mock argument spec and no other arguments
    validator = ModuleArgumentSpecValidator(argument_spec)

    # create a valid parameter dictionary
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # call validate
    result = validator.validate(parameters)

    # check for no errors
    assert not result.error_messages, "Argument spec validator should not have errors"

    # extract the parameters from the result
    valid_params = result.validated_parameters

    # Check the validated parameters

# Generated at 2022-06-20 15:38:58.312449
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'test': {'type': 'path'}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive,
                                            required_together,
                                            required_one_of,
                                            required_if,
                                            required_by)
    # Test with valid parameters
    parameters = {'test': '/tmp/not_existing_file'}
    result = validator.validate(parameters)
    assert result.validated_parameters['test'] == '/tmp/not_existing_file'
    assert result._deprecations == []
    assert result._warnings == []
    assert result.error_

# Generated at 2022-06-20 15:39:05.847940
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-20 15:39:08.454156
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
    }

    parameters = {
        'name': 'bo',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'


# Generated at 2022-06-20 15:39:15.515175
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-20 15:39:24.624614
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'max_length': {'type': 'int'},
        'list_of_str': {'type': 'list', 'elements': 'str'},
        'list_of_dict': {'type': 'list', 'elements': 'dict'},
        'nested': {'type': 'dict',
                   'arg_spec': {'nested_length': {'type': 'int'}},
                   'spec': {'nested_length': {'type': 'int'}}}
    }
    validator = ArgumentSpecValidator(argument_spec)

# Generated at 2022-06-20 15:39:36.316527
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test for all option arguments

    argument_spec = {
        'src': {'type': 'str', 'help': 'The source file'},
        'dest': {'type': 'str', 'help': 'The file to copy the src file to'}
    }

    mutually_exclusive = [
        ['src', 'dest'],
        ['dest', 'src']
    ]

    required_together = [
        ['src', 'dest']
    ]

    required_one_of = [
        ['src', 'dest']
    ]

    required_if = [
        ['src', 'dest']
    ]

    required_by = {
        'src': ['src', 'dest'],
        'dest': ['src', 'dest']
    }


# Generated at 2022-06-20 15:40:13.744201
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    This test method tests the ModuleArgumentSpecValidator.validate method
    """

    # Case 1:
    # test that all warnings and deprecations are printed as expected
    parameters = dict(
        name='bo',
        age='42',
        no_log=True,
        password='secret',
    )

# Generated at 2022-06-20 15:40:25.392572
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    m = ModuleArgumentSpecValidator({'a':{'type': 'str', 'version_added': '2.9'}},
                                    mutually_exclusive=[['a', 'b']],
                                    required_together=[['a', 'b']],
                                    required_one_of=[['a', 'b']],
                                    required_if=[['a', '2.9', ['c']]],
                                    required_by={'a': ['c']})
    assert m.argument_spec == {'a': {'type': 'str', 'version_added': '2.9'}}
    assert m._mutually_exclusive == [['a', 'b']]
    assert m._required_together == [['a', 'b']]
    assert m._required_one_of == [['a', 'b']]
    assert m

# Generated at 2022-06-20 15:40:33.726589
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [['vesion', 'ver']]
    required_one_of = [['vesion', 'ver']]
    required_together = [['vesion', 'ver']]
    required_if = [['vesion', 'ver']]
    required_by = {'vesion': 'ver'}
    argument_spec = {
        'version': {'type': 'int', 'required': True},
        'ver': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by)

   

# Generated at 2022-06-20 15:40:39.910366
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    ####################################################
    ## Simple Example
    ####################################################

    # ArgumentSpecValidator.validate() takes two arguments.
    # First argument is a dictionary of arguments.
    # Second argument is a list of arguments to ignore.
    #
    # self.argument_spec is a dictionary of arguments which contain a
    # list of key/values. Keys are the names of the arguments, and
    # values are within another dictionary, which include
    # - 'default'
    # - 'type'
    # - 'required'
    # - etc
    #
    ###

    # Play with ArgumentSpecValidator.validate()
    import sys
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_native


# Generated at 2022-06-20 15:40:50.755082
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator"""
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', 'name']]
    required_by = {'name': 'age'}

    validator = ArgumentSpecValidator(
        argument_spec, mutually_exclusive, required_together,
        required_one_of, required_if, required_by)

    # check the attributes were set
    assert validator._mutually_exclusive == [['name', 'age']]

# Generated at 2022-06-20 15:40:57.805527
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # test without params
    validator = ArgumentSpecValidator(argument_spec)
    assert validator  # should not raise exception

    # test required params
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=[[1, 2]],
                                      required_together=[[1, 2]],
                                      required_one_of=[[1, 2]],
                                      required_if=[1, 2, [3, 4]],
                                      required_by={1: 2}
                                      )
    assert validator  # should not raise exception

    # test unknown params

# Generated at 2022-06-20 15:41:06.303711
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict()
    argument_validator_object = ArgumentSpecValidator(argument_spec)

    assert argument_validator_object._mutually_exclusive is None
    assert argument_validator_object._required_together is None
    assert argument_validator_object._required_one_of is None
    assert argument_validator_object._required_if is None
    assert argument_validator_object._required_by is None
    assert argument_validator_object._valid_parameter_names == set()
    assert argument_validator_object.argument_spec == argument_spec



# Generated at 2022-06-20 15:41:08.332046
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}}, mutually_exclusive={'name'})

# Generated at 2022-06-20 15:41:10.974378
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # ensure that the __init__ method for the class does not throw an exception
    module = ModuleArgumentSpecValidator(argument_spec={})

# Generated at 2022-06-20 15:41:18.899757
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive_test = [['a', 'b']]
    required_together_test = [['c', 'd']]
    required_one_of_test = [['e', 'f']]
    required_if_test = [['g', 'h', ['i', 'j']]]
    required_by_test = {'k': ['l']}

# Generated at 2022-06-20 15:42:26.184199
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ArgumentSpecValidator(spec)
    assert validator.argument_spec == spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None

    spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

# Generated at 2022-06-20 15:42:29.793062
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    assert isinstance(validator, ArgumentSpecValidator) == True


# Generated at 2022-06-20 15:42:31.778040
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult({"test": {}}), ValidationResult)


# Generated at 2022-06-20 15:42:37.138224
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})
    assert ArgumentSpecValidator({}, required_one_of=[[]])
    assert ArgumentSpecValidator({}, required_together=[[]])
    assert ArgumentSpecValidator({}, mutually_exclusive=[[]])
    assert ArgumentSpecValidator({}, required_if=[])
    assert ArgumentSpecValidator({}, required_by={"a": []})

# Unit tests for validate of class ArgumentSpecValidator

# Generated at 2022-06-20 15:42:40.488132
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator({"age": {"type": "int"}}).validate(parameters={"age": "42"})

    assert isinstance(result, ValidationResult)
    assert not result.error_messages
    assert result.validated_parameters == {"age": 42}

# Generated at 2022-06-20 15:42:46.506420
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Unit test for method validate of class ArgumentSpecValidator for case 1
    # test to validate parameter with valid input and "required" validation
    argument_spec = {
        'brand': {'required': True,
                  'type': 'str'},
        'model_num': {'required': True,
                      'type': 'str'},
        'year': {'required': True,
                 'type': 'int',
                 'aliases': ['release_year']}
    }
    parameters = {
        'brand': 'honda',
        'model_num': 'accord',
    }
    mutually_exclusive = [['brand', 'model_num']]
    required_together = [['brand', 'model_num']]
    required_one_of = []
    required_if = []
    required_by = []
   

# Generated at 2022-06-20 15:42:52.762427
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    result = ModuleArgumentSpecValidator(argument_spec)
    assert isinstance(result, ModuleArgumentSpecValidator)
    assert result.argument_spec == argument_spec
    assert result._valid_parameter_names == set()


# unit test for call of method ModuleArgumentSpecValidator.validate

# Generated at 2022-06-20 15:42:54.439445
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Ensure initialization works and that no defaults are set
    assert ArgumentSpecValidator(None)

# Generated at 2022-06-20 15:43:01.602317
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # mock parameters
    parameters = {
        'name': 'bo'}
    # mock argument_spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    # get the validator object
    validator = ModuleArgumentSpecValidator(argument_spec)
    # validate parameters
    result = validator.validate(parameters)

    # assert error messages
    assert result.error_messages == ['The option `age` is required']

# Generated at 2022-06-20 15:43:11.505738
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # result.errors is not empty
    assert result.error_messages
    assert result.errors is not None

    # result.validated_parameters is not empty
    assert result.validated_parameters is not None

    # result.validated_parameters and parameters are different
    assert result.validated_parameters != parameters