

# Generated at 2022-06-24 20:15:04.031190
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arguments = [
        {"name": "alpha", "type": "bool"},
        {"name": "beta"},
        {"name": "gamma"},
    ]
    parameters = {
        "alpha": True,
        "beta": 2.5,
        "gamma": [],
    }
    validator = ArgumentSpecValidator(argument_spec=arguments)
    result = validator.validate(parameters=parameters)
    assert not result.errors
    assert "alpha" in result.validated_parameters
    assert "beta" in result.validated_parameters
    assert "gamma" in result.validated_parameters


# Generated at 2022-06-24 20:15:06.976036
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters_0 = dict()
    argument_spec_validator_0 = ModuleArgumentSpecValidator(parameters_0)
    argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:15:14.147071
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()

# Generated at 2022-06-24 20:15:21.135194
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # AssertionError raised by validate
    # assert argument_spec_validator_1.validate() == ValidationResult(validated_parameters=None, errors=None, warnings=None)
    pass


# Unit tests for class ValidationResult

# Generated at 2022-06-24 20:15:22.790462
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)


test_ArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:15:27.254685
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    str_0 = 'd'
    bytes_0 = b'm'
    argument_spec_validator_0 = ModuleArgumentSpecValidator(str_0)
    argument_spec_validator_0_validate_0 = argument_spec_validator_0.validate(bytes_0)


# Generated at 2022-06-24 20:15:29.405967
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)


# Generated at 2022-06-24 20:15:37.488374
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    argument_spec_validator_1 = ArgumentSpecValidator(float_0)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator(float_0)
    module_argument_spec_validator_2 = ModuleArgumentSpecValidator(float_0)
    validation_result_0 = argument_spec_validator_0.validate(argument_spec_validator_1)
    validation_result_1 = module_argument_spec_validator_0.validate(module_argument_spec_validator_1)
    validation_result_2 = module_argument_spec_validator_

# Generated at 2022-06-24 20:15:38.467547
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True == False


# Generated at 2022-06-24 20:15:43.171412
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_0 = {
        'age': '42',
        'name': 'bo',
    }
    validation_result_0 = argument_spec_validator_0.validate(parameters_0)

# Test for __init__ of class ValidationResult

# Generated at 2022-06-24 20:15:55.949015
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 1
    argument_spec_0 = {int_0: {'aliases': ['int_0']}}
    parameters_0 = {int_0: {'int_0': 'unit_test'}}
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0)
    result_0 = argument_spec_validator_0.validate(parameters_0)

if __name__ == "__main__":
    test_case_0()
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:16:05.366180
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    case_0_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    case_0_parameters = {
        'name': 'bo',
        'age': '42',
    }
    case_0_expected = ValidationResult(case_0_parameters)
    case_0_expected._error_messages = ["invalid value for age, must be of int type"]
    case_0_expected._validated_parameters = {
        'name': 'bo',
        'age': 42,
    }
    argument_spec_validator_0 = ArgumentSpecValidator(case_0_spec)
    result_0 = argument_spec_validator_0.validate(case_0_parameters)
    assert result_0._valid

# Generated at 2022-06-24 20:16:06.930820
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:16:09.094358
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_validator = ModuleArgumentSpecValidator(None)
    parameters = {}
    assert argument_spec_validator.validate(parameters) is None

# Generated at 2022-06-24 20:16:10.885685
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)


# Generated at 2022-06-24 20:16:18.265025
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator({})
    argument_spec_validator_0.validate({})
    argument_spec_validator_1 = ArgumentSpecValidator({'a': {'type': 'dict', 'aliases': ['b']}, 'c': {'type': 'bool'}})
    argument_spec_validator_1.validate({'a': {'d': {'e': {'f': 'g'}}}, 'c': True})
    argument_spec_validator_2 = ArgumentSpecValidator({'a': {'type': 'dict', 'aliases': ['b']}, 'c': {'type': 'bool'}})

# Generated at 2022-06-24 20:16:21.376768
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_0 = {}
    # Validate arguments using assertions methods
    result_0 = argument_spec_validator_0.validate(parameters_0)
    # Validate return type of method validate
    assert isinstance(result_0, ValidationResult)


# Generated at 2022-06-24 20:16:28.160087
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_1 = {'foo': 'bar'}
    result_validate = argument_spec_validator_0.validate(parameters_1)

    assert result_validate.validated_parameters == {}
    assert result_validate.error_messages == ["Invalid argument_spec: 1.5"]



# Generated at 2022-06-24 20:16:30.219405
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    assert(isinstance(argument_spec_validator_0, ArgumentSpecValidator))



# Generated at 2022-06-24 20:16:40.366066
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    str_1 = 'bad'
    float_1 = 42.0
    bool_0 = bool
    float_0 = float
    str_0 = str
    argument_spec_validator_1 = ArgumentSpecValidator(float_0)

# Generated at 2022-06-24 20:16:55.444508
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case 0: Simple validation of parameters
    # Expected results
    #   - all parameters validated and coerced to expected types
    #   - no errors, warnings or deprecations
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_0 = 1.5

    result_0 = argument_spec_validator_0.validate(parameters_0)

    assert isinstance(result_0.validated_parameters, float)
    assert result_0.validated_parameters == 1.5
    assert isinstance(result_0.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result_0.error_messages, list)
    assert len(result_0.error_messages) == 0
    assert result_0.unsupported_

# Generated at 2022-06-24 20:17:01.928282
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters_0 = {'a': 'b'} # {'a': 'b'}
    argument_spec_validator_0 = ArgumentSpecValidator(parameters_0)
    result_0 = argument_spec_validator_0.validate({})
    assert result_0 == {}


# Generated at 2022-06-24 20:17:13.587867
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Init
    str_0 = "t!b"
    int_0 = 4
    dict_0 = dict()
    dict_0["dict_0"] = dict_0
    dict_1 = dict()
    dict_1["dict_1"] = dict_1
    dict_2 = dict()
    dict_2["dict_2"] = dict_2
    dict_3 = dict()
    dict_3["dict_1"] = dict_1
    dict_3["dict_2"] = dict_2
    dict_4 = dict()
    dict_4["dict_1"] = dict_3
    dict_4["dict_2"] = dict_2
    argument_spec_validator_0 = ArgumentSpecValidator(dict_4)
    parameters_0 = dict()
    parameters_0["dict_0"] = dict

# Generated at 2022-06-24 20:17:20.530584
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    string_0 = 'z'
    int_0 = 0xAB
    it = iter([string_0, int_0])
    argument_spec_validator_0 = ModuleArgumentSpecValidator(it)
    value_0 = next(it)
    value_1 = next(it)
    value_0 = argument_spec_validator_0.validate(value_1)
    value_0 = next(it)
    value_1 = next(it)
    value_0 = argument_spec_validator_0.validate(value_1)


# Generated at 2022-06-24 20:17:24.670726
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    validate_0 = [['name', 'age', None, None, None], [None, None, ['name', 'age', None], None, None], [None, None, ['name', 'age', None], None, None]]
    result = argument_spec_validator_0.validate(validate_0)
    assert result == validate_0
    

# Generated at 2022-06-24 20:17:28.910763
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    boolean_0 = False
    boolean_1 = True
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    argument_spec_validator_0.validate(boolean_0)

# Generated at 2022-06-24 20:17:33.394026
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters_0 = False
    ModuleArgumentSpecValidator_0 = ModuleArgumentSpecValidator()
    output_0 = ModuleArgumentSpecValidator_0.validate(parameters_0)
    assert output_0 == ValidationResult(parameters_0)


# Generated at 2022-06-24 20:17:44.361084
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = {"ALIASES": ["ONE"], "BOOL": True, "B": True, "C": False, "D": True, "E": False, "F": False, "INT": 42, "INT_LIST": [42, 42], "INT_ALIASES": [42], "INT_ALIASES_LIST": [42], "STR": "ansible", "STR_LIST": ["ansible", "is"], "STR2": "ansible", "STR2_LIST": ["ansible", "is"], "FLOAT": 1.5, "FLOAT_LIST": [1.5, 1.5]}

# Generated at 2022-06-24 20:17:48.612345
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    dict_0 = {}
    validation_result_0 = argument_spec_validator_0.validate(dict_0)
    validation_result_0.validated_parameters
    validation_result_0.unsupported_parameters
    validation_result_0.error_messages


# Generated at 2022-06-24 20:17:59.526583
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    complex_0 = complex()
    list_0 = [complex_0, complex_0, complex_0, complex_0]
    dict_0 = dict()
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0['options'] = list_0
    dict_0

# Generated at 2022-06-24 20:18:19.058365
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # 0:
    int_0 = 2
    argument_spec_validator_0 = ModuleArgumentSpecValidator(int_0)

    string_0 = "a string that is not very fun"
    result_ValidationResult_0 = argument_spec_validator_0.validate(string_0)



# Generated at 2022-06-24 20:18:25.249736
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {
        'query_params': {'type': 'dict'},
    }
    argument_spec_validator_0 = ArgumentSpecValidator(parameters)
    parameters = {
        'query_params': [
            'a',
            'b',
        ],
    }
    result = argument_spec_validator_0.validate(parameters)



# Generated at 2022-06-24 20:18:29.397335
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    string_0 = "U5*6m-]"
    ModuleArgumentSpecValidator(string_0)


# Generated at 2022-06-24 20:18:36.349778
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)

    assert_exception_type = None
    assert_exception_message = None
    try:
        argument_spec_validator_0.validate(None)
    except Exception as exception:
        assert_exception_type = type(exception)
        assert_exception_message = exception.args[0]

    assert isinstance(assert_exception_type, TypeError)
    assert assert_exception_message == "validate() missing 1 required positional argument: 'parameters'"

# Generated at 2022-06-24 20:18:44.659834
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({
        'expires': {'type': 'int'},
        'extra': {'type': 'str'},
        'extra_keywords': {
            'type': 'dict',
            'options': {
                'python': {'type': 'str'},
                'features': {'type': 'list'},
            }
        },
    }, required_if=[
        ['expires', True, ['extra']]
    ], aliases={'python': 'extra_keywords.python'})

    result = validator.validate({
        'expires': 1,
        'extra_keywords': {
            'python': 'python2',
            'features': ['one', 'two'],
        },
    })


# Generated at 2022-06-24 20:18:57.003289
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec_validator = ArgumentSpecValidator({'type': 'dict', 'default': {}, 'options': {'test': {'type': 'str', 'default': 'test', 'aliases': ['test_alias']}}}, [], [['test', 'test_alias']], [['test'], ['test_alias']])
    result = argument_spec_validator.validate({'test': 'test_value'})
    assert isinstance(result, ValidationResult)
    assert result._no_log_values == set(['test_value'])
    assert result.errors == []
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'test': 'test_value'}
    assert result

# Generated at 2022-06-24 20:19:00.291565
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_validator_0 = ModuleArgumentSpecValidator(int_0, )
    str_0 = 'foobar'
    float_0 = 1.5
    # xfail: module validation requires AnsibleModule
    # result = argument_spec_validator_0.validate(str_0, float_0)



# Generated at 2022-06-24 20:19:06.883988
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    my_arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    try:
        my_params = {
            'name': 'bo',
            'age': '42',
        }
        validator = ModuleArgumentSpecValidator(my_arg_spec)
        result = validator.validate(my_params)
        assert (True)
    except SystemExit as e:
        assert (False)
        assert (e)


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:19:16.756867
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Import necessary modules and functions
    from ansible.module_utils.common import AnsibleModule

    # Create an AnsibleModule object
    module = AnsibleModule({'k1': 1, 'k2': 2, 'k3': 3})

    # Create a nested dict
    dict_0 = {}
    dict_0.update({'k1': 1})
    dict_0.update({'k2': 2})
    dict_0.update({'k3': 3})

    # Create an ArgumentSpecValidator object
    argument_spec_validator_0 = ModuleArgumentSpecValidator({'a': {'type': 'int'}, 'b': {'type': 'int', 'aliases': ['c']}})

    # Try to validate the given arguments
    argument_spec_validator_0.validate(dict_0)



# Generated at 2022-06-24 20:19:26.561712
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_args = dict(
        argument_spec=dict(
            name=dict(type='str'),
            age=dict(type='int')
        ),
        mutually_exclusive=[
            ['name', 'age']
        ]
    )

    parameters = dict(
        name='bo',
        age=42,
    )

    validator = ModuleArgumentSpecValidator(**module_args)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit('Validation failed: {0}'.format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42



# Generated at 2022-06-24 20:19:37.911430
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)

    parameters = {}
    validation_result_0 = argument_spec_validator_0.validate(parameters)
    assert validation_result_0.validated_parameters == {}


# Generated at 2022-06-24 20:19:42.844509
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator(int_0)
    result_0 = argument_spec_validator_0.validate(str_0)
    assert result_0 == None


# Generated at 2022-06-24 20:19:48.321877
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test arguments
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)

    parameters = 1.5

    # Test without optional args
    result = argument_spec_validator_0.validate(parameters)

    # Test with all optional args
    result = argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:19:50.097956
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    parameters = {}
    result_0 = argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:19:51.675770
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)

# Generated at 2022-06-24 20:19:54.324866
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)


# Generated at 2022-06-24 20:19:59.069327
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Check that validate method of ArgumentSpecValidator can be called
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    try:
        argument_spec_validator_0.validate()
    except TypeError:
        pass


# Generated at 2022-06-24 20:20:01.631441
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    test_case_0()

# Generated at 2022-06-24 20:20:05.059019
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_validator_0 = ModuleArgumentSpecValidator()
    arguments_0 = {}
    print(argument_spec_validator_0.validate(arguments_0))


# Generated at 2022-06-24 20:20:13.511920
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import copy

# Generated at 2022-06-24 20:20:36.999494
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    str_0 = '0'
    str_1 = '8'
    int_0 = 0
    int_1 = 2
    list_0 = []
    dict_0 = {}
    list_1 = []
    dict_1 = {}
    argument_spec_validator_0 = ModuleArgumentSpecValidator(dict_1)
    result = argument_spec_validator_0.validate(dict_0)
    assert not result
    assert result.error_messages
    assert result.validated_parameters
    assert result.unsupported_parameters
    assert not result.no_log_values
    assert not result.warnings
    assert not result.deprecations



# Generated at 2022-06-24 20:20:42.694225
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    dict_0 = {
        'anchor': 'apple',
        'apple': 'anchor',
        'anchor2': 'anchor',
    }
    validation_result_0 = module_argument_spec_validator_0.validate(dict_0)
    expected_0 = False
    assert validation_result_0.errors == expected_0

# Generated at 2022-06-24 20:20:48.616831
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_0 = {}
    result = argument_spec_validator_0.validate(parameters_0)
    assert result.validated_parameters == {}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._validated_parameters == {}


# Generated at 2022-06-24 20:20:55.763147
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    moduleargumentspecvalidator_0 = ModuleArgumentSpecValidator(float_0)
    dict_0 = {
        'validated_parameters': {},
        'validation_errors': {}}
    dict_1 = {
        'validated_parameters': {},
        'validation_errors': {}}
    dict_2 = {
        'validated_parameters': {},
        'validation_errors': {}}
    dict_3 = {
        'validated_parameters': {},
        'validation_errors': {}}
    dict_4 = {
        'validated_parameters': {},
        'validation_errors': {}}
    dict_5 = {
        'validated_parameters': {},
        'validation_errors': {}}
   

# Generated at 2022-06-24 20:21:00.365221
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    results_0 = argument_spec_validator_0.validate(float_0)
    assert results_0._validated_parameters == 1.5
    assert results_0._unsupported_parameters == set()
    assert results_0._no_log_values == set()
    assert results_0._deprecations == []
    assert results_0._warnings == []
    assert results_0.errors.messages == []
    assert results_0.error_messages == []

if __name__ == "__main__":
    try:
        test_ArgumentSpecValidator_validate()
    except Exception as e:
        print(to_native(e))
        raise

# Generated at 2022-06-24 20:21:03.107022
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class_0 = ModuleArgumentSpecValidator
    ModuleArgumentSpecValidator_validate_0 = class_0(ModuleArgumentSpecValidator)
    ModuleArgumentSpecValidator_validate_1 = class_0(dict)
    ModuleArgumentSpecValidator_validate_2 = class_0(list)



# Generated at 2022-06-24 20:21:08.642927
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_validator_0 = ModuleArgumentSpecValidator(1.5)
    str_0 = "1.5"
    assert argument_spec_validator_0.validate(str_0) == '1.5', "assert failed"


# Generated at 2022-06-24 20:21:11.532378
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    parameters_0 = "Bx"

    assert argument_spec_validator_0.validate(parameters_0) == ValidationResult(parameters_0)


# Generated at 2022-06-24 20:21:14.457608
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    result = argument_spec_validator_0.validate(parameters_0, )
    assert(result.errors.messages == [])


# Generated at 2022-06-24 20:21:20.805114
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    str_0 = 'foobar'
    validation_result_0 = argument_spec_validator_0.validate(str_0)


# Generated at 2022-06-24 20:21:56.369079
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 2.0
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)


# Generated at 2022-06-24 20:22:01.319236
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)

    parameters = {'key': 'value'}
    result = argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

    parameters = {}
    result = argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-24 20:22:04.992455
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)
    result = None
    # Test
    result = argument_spec_validator_0.validate(result)
    # Verify
    assert result is not None


# Generated at 2022-06-24 20:22:09.617293
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator(None)
    parameters_0 = {}
    result_0 = argument_spec_validator_0.validate(parameters_0)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-24 20:22:18.369332
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    argument_spec_validator_1 = ModuleArgumentSpecValidator(float_0)
    argument_spec_validator_2 = ModuleArgumentSpecValidator(float_0)
    argument_spec_validator_3 = ModuleArgumentSpecValidator(float_0)
    argument_spec_validator_4 = ModuleArgumentSpecValidator(float_0)
    argument_spec_validator_5 = ModuleArgumentSpecValidator(float_0)
    str_0 = "jWdu"
    str_1 = "3BjC"
    str_2 = "T%^j"
    str_3 = "jWdu"
    str_4 = "3BjC"


# Generated at 2022-06-24 20:22:25.273257
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)

    # Unit test for validate()
    parameters = {'name': 'bo', 'age': '42'}
    result = argument_spec_validator_0.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}

# Generated at 2022-06-24 20:22:32.171229
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    parameters = None
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    try:
        # Testing for exception
        argument_spec_validator_0.validate(parameters)
        assert False
    except TypeError as e:
        assert "unorderable types: float() > dict()" in str(e)

    parameters = {float_0: str(float_0), float_0: None}
    try:
        # Testing for exception
        result = argument_spec_validator_0.validate(parameters)
        assert False
    except TypeError as e:
        assert "unorderable types: float() > dict()" in str(e)



# Generated at 2022-06-24 20:22:38.132878
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test nested argument spec validation
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'nested': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'nested': {
            'name': 'bo',
            'age': '42',
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []

# Generated at 2022-06-24 20:22:41.908364
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_1 = 1.5
    moduleargument_spec_validator_0 = ModuleArgumentSpecValidator(float_1)
    assert isinstance(moduleargument_spec_validator_0.validate(1.5), ValidationResult)


# Generated at 2022-06-24 20:22:51.522472
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:23:55.573094
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator(float)
    parameters_0 = {'parameters': [1.5]}
    _dict_0 = argument_spec_validator_0.validate(parameters_0)
    _str_0 = _dict_0.to_json()
    _str_1 = _dict_0.to_json()



# Generated at 2022-06-24 20:24:00.425361
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)


# Generated at 2022-06-24 20:24:09.817399
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {'required': True}
    argument_spec_validator_0 = ArgumentSpecValidator({})
    str_0 = 'any_value'
    int_0 = 3
    dict_0 = {str_0: int_0}
    ValidationResult_0 = argument_spec_validator_0.validate(dict_0)
    assert isinstance(ValidationResult_0, ValidationResult) is True
    ValidationResult_0 = argument_spec_validator_0.validate({str_0: int_0})
    assert isinstance(ValidationResult_0, ValidationResult) is True
    ValidationResult_0 = argument_spec_validator_0.validate(dict_0)
    assert isinstance(ValidationResult_0, ValidationResult) is True
    ValidationResult_

# Generated at 2022-06-24 20:24:12.042155
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_validator_0 = ModuleArgumentSpecValidator(1.5)
    with pytest.raises(TypeError, match=r'.*parameters.*'):
        argument_spec_validator_0.validate(parameters='parameters', )


# Generated at 2022-06-24 20:24:20.692770
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_1 = 1.5
    argument_spec_validator_3 = ArgumentSpecValidator(float_1)
    dict_1 = dict()
    dict_1["foo"] = dict()
    dict_1["foo"]["type"] = "bool"
    dict_1["foo"]["default"] = False
    dict_1["bar"] = dict()
    dict_1["bar"]["type"] = "int"
    dict_2 = dict()
    dict_2["foo"] = dict()
    dict_2["bar"] = dict()
    dict_2["bar"]["type"] = "str"
    dict_2["bar"]["default"] = "3"
    argument_spec_validator_4 = ArgumentSpecValidator(dict_1)
    result_3 = argument_spec_validator_

# Generated at 2022-06-24 20:24:22.637920
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)

# Generated at 2022-06-24 20:24:32.224751
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters_0 = dict()
    parameters_0['name'] = 'bo'
    parameters_0['age'] = '42'
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0)
    result = argument_spec_validator_0.validate(parameters_0)
    result_item = {}
    result_item['validated_parameters'] = dict()
    result_item['validated_parameters']['name'] = 'bo'
    result_item['validated_parameters']['age'] = '42'
    result_item['unsupported_parameters'] = set()
    result_item['deprecations'] = []
    result_item['warnings'] = []
    result_item['errors'] = []
    assert result == result_item
    parameters_1 = dict

# Generated at 2022-06-24 20:24:33.848638
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ArgumentSpecValidator(float_0)



# Generated at 2022-06-24 20:24:40.032923
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    str_0 = 'q=gE'
    str_1 = 'TQE'
    str_2 = 'a@%'
    str_3 = '<p>'
    str_4 = 'QGh'
    str_5 = '`'
    str_6 = '|0@'
    str_7 = 'L-t'
    str_8 = '>'
    str_9 = 'iP'
    argument_spec_validator_0.validate(str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9)


# Generated at 2022-06-24 20:24:46.124271
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    float_0 = 1.5
    argument_spec_validator_0 = ModuleArgumentSpecValidator(float_0)
    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }
    bool_0 = parameter_0 != None
    if bool_0:
        parameter_1 = argument_spec_validator_0.validate(parameter_0)
    else:
        parameter_1 = None
    bool_1 = parameter_1 != None
    if bool_1:
        message_0 = parameter_1.error_messages
    else:
        message_0 = None
    return message_0