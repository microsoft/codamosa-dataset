

# Generated at 2022-06-24 20:15:03.936535
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    result = module_argument_spec_validator_0.validate(parameters=None)

# Generated at 2022-06-24 20:15:07.377830
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    try:
        test_case_0()
    except Exception as e:
        print('Error in test_case_0: {0}'.format(e))



# Generated at 2022-06-24 20:15:10.550495
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = dict(a=1, b=2)

    result = module_argument_spec_validator.validate(parameters)
    assert result.validated_parameters == dict(a=1, b=2)



# Generated at 2022-06-24 20:15:15.435314
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = module_argument_spec_validator_0.validate(parameters)
    assert 'AnsibleValidationErrorMultiple' in repr(result)
    assert 'ValidationResult' in repr(result)


# Generated at 2022-06-24 20:15:21.571804
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_validate = ModuleArgumentSpecValidator()

    # Initializing parameters:
    parameters = {}

    # Invoking validate method
    result = module_argument_spec_validator_validate.validate(parameters)



# Generated at 2022-06-24 20:15:23.007916
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:15:24.372890
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator.validate()


# Generated at 2022-06-24 20:15:26.828094
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Ensure that validate() throws an exception when called with
    #   wrong argument types
    # The following call should throw a TypeError
    with pytest.raises(TypeError):
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
        test_parameters = {}
        test_result = module_argument_spec_validator_0.validate(test_parameters)

# Generated at 2022-06-24 20:15:35.677260
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import (
        assert_argument_spec_type,
        assert_required_together,
        assert_required_one_of,
        assert_required_if,
        assert_required_by,
        assert_mutually_exclusive,
    )

    # Create argument_spec

# Generated at 2022-06-24 20:15:42.887909
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {'name': 'John Doe', 'age': '42'}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0.validated_parameters == {'name': 'John Doe', 'age': 42}
    assert result_0.error_messages == []

# unit tests end here
if __name__ == '__main__':
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:15:53.519216
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict(bucket='the_bucket_name_string', name='the_object_name_string')
    result = module_argument_spec_validator_0.validate(parameters)

    assert result.validated_parameters['bucket'] == 'the_bucket_name_string'
    assert result.validated_parameters['name'] == 'the_object_name_string'
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-24 20:15:57.658055
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}

    ValidationResult = module_argument_spec_validator.validate(parameters)


# Generated at 2022-06-24 20:16:00.502392
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = dict()

    # Validate the parameters
    module_argument_spec_validator_1.validate(parameters_1)

# Generated at 2022-06-24 20:16:03.805327
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {
        "1": {
            "2": {
                "3": 4
            },
            "5": 6
        },
        "7": 8
    }
    result = module_argument_spec_validator.validate(parameters)

# Generated at 2022-06-24 20:16:15.191407
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.error_messages, list)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert len(result.error_messages) == 0
    assert len(result.errors) == 0

# Generated at 2022-06-24 20:16:16.694419
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:16:17.814360
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:16:20.321825
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(argument_spec={"a": {"type": "str", "required": True}})
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-24 20:16:22.878133
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    result_0 = module_argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:16:31.611097
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'state': 'absent'}
    argument_spec = {
        'state': {
            'type': 'str',
            'required': True,
            'choices': ['absent', 'present']
        },
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    validate = result.validated_parameters
    assert validate == {'state': 'absent'}

# Generated at 2022-06-24 20:16:42.892842
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    try:
        import ansible.module_utils.common.arg_spec.ArgumentSpecValidator as ArgumentSpecValidator
        assert isinstance(ArgumentSpecValidator, object)
    except ImportError as e:
        assert False, "Could not import class 'ArgumentSpecValidator' from module 'ansible.module_utils.common.arg_spec.ArgumentSpecValidator'"

# Generated at 2022-06-24 20:16:43.487872
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:16:49.108230
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0

    with pytest.raises(TypeError):
        module_argument_spec_validator_0.validate()



# Generated at 2022-06-24 20:16:54.569697
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)  # TODO: fix this test case


# Generated at 2022-06-24 20:17:00.275847
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = {'number': 'number', 'number1': 'number1'}

    result = module_argument_spec_validator_0.validate(parameters)
    assert result.validated_parameters == {'number': 'number', 'number1': 'number1'}
    assert result.error_messages == [
        'The following parameter is unsupported: number1. Supported parameters include: number.']
    assert result.unsupported_parameters == set(['number1'])
    assert result.no_log_values == set()



# Generated at 2022-06-24 20:17:01.039960
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:17:06.134280
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    file_argument_spec = {
        'state': {
            'required': True,
            'choices': ['present', 'absent'],
            'type': 'str'
        },
        'path': {
            'required': True,
            'type': 'str'
        },
        'content': {
            'default': None,
            'type': 'str'
        },
        'force': {
            'default': False,
            'type': 'bool'
        }
    }

    # Valid case
    module_argument_spec_validator_0 = ArgumentSpecValidator(file_argument_spec)
    parameters = {
        'path': '/path/to/file',
        'content': 'some content',
        'state': 'present'
    }
    result = module_argument_spec_validator

# Generated at 2022-06-24 20:17:11.416414
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {'name': 'bo', 'age': '42'}
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result._validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:17:17.771148
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator = ModuleArgumentSpecValidator()

    parameters = {
        "parameters": {
            "aliases": [
                "aliases"
            ]
        }
    }
    result = module_argument_spec_validator.validate(parameters)
    assert result.errors[0].args[0] == "Aliases may not contain duplicates. The following duplicate aliased parameters have been found: aliases"


# Generated at 2022-06-24 20:17:20.858152
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test_args = ['']
    # Failure test for method validate
    with raises(TypeError):
        module_argument_spec_validator_0.validate(test_args)


# Generated at 2022-06-24 20:17:38.587410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters_1 = {}
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

    parameters_2 = {}
    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()

    parameters_3 = {}
    module_argument_spec_validator_3 = ModuleArgumentSpecValidator()

    parameters_4 = {}
    module_argument_spec_validator_4 = ModuleArgumentSpecValidator()

    parameters_5 = {}
    module_argument_spec_validator_5 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:17:39.978934
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert callable(ModuleArgumentSpecValidator.validate)



# Generated at 2022-06-24 20:17:47.828226
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
  parameters = dict()
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult
  assert type(module_argument_spec_validator_0.validate(parameters)) is ValidationResult

# Generated at 2022-06-24 20:17:55.493635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        "url": "https://example.org/api/v1",
        "headers": {"Authorization": "Bearer $TOKEN"}
    }
    module_argument_spec_validator_0.validate(parameters)
    # In this example we use the value $TOKEN as the Authorization header for an API call and we want
    # that value to be sanitized from the error message. The sanitize_keys function can be used to do
    # that.
    # Error messages in the ValidationResult may contain no_log values and should be
    # sanitized with sanitize_keys before logging or displaying.

    from ansible.module_utils.common.parameters import sanitize_keys
    sanitized_errors = sanitize

# Generated at 2022-06-24 20:17:56.697269
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:18:01.050075
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate() of ModuleArgumentSpecValidator"""
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    actual_result = module_argument_spec_validator.validate(parameters)
    expected_result = None
    assert isinstance(actual_result, type(expected_result))

# Generated at 2022-06-24 20:18:10.913321
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Successfully validated parameters
    parameters_0 = {
        'state': 'present',
        'name': 'bo',
        'age': 35
    }

    result_0 = module_argument_spec_validator_0.validate(parameters_0)

    # The validated parameters should be the parameters used as input.
    assert result_0.validated_parameters == parameters_0
    # The warnings should be empty.
    assert not result_0.warnings
    # The deprecations should be empty.
    assert not result_0.deprecations
    # The error messages should be empty.
    assert not result_0.error_messages

    # Unsupported parameter

# Generated at 2022-06-24 20:18:12.560077
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator()
    assert result.validate == ArgumentSpecValidator.validate

# Generated at 2022-06-24 20:18:17.165406
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO
    # Loading the class
    module_argument_spec_validator_instance = ModuleArgumentSpecValidator()
    # TODO
    # Calling the method
    # function_to_test(module_argument_spec_validator_instance, parameters)
    pass

# Generated at 2022-06-24 20:18:22.258017
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec)
    result_0 = argument_spec_validator_0.validate(parameters)
    assert result_0 is not None

# Generated at 2022-06-24 20:18:43.492056
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    arguments_1 = {'parameters': {'command': 'uptime'}}
    arguments_2 = {'parameters': {'command': 'uptime'}}
    arguments_3 = {'parameters': {'command': 'uptime'}}

# Generated at 2022-06-24 20:18:44.789832
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert module_argument_spec_validator_0.validate == ArgumentSpecValidator.validate

# Generated at 2022-06-24 20:18:52.403174
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    asv = ArgumentSpecValidator({'name': {'type': 'str'}})
    assert asv._mutually_exclusive is None
    assert asv._required_together is None
    assert asv._required_one_of is None
    assert asv._required_if is None
    assert asv._required_by is None
    assert asv._valid_parameter_names == set(['name'])
    assert asv.argument_spec == {'name': {'type': 'str'}}


# Generated at 2022-06-24 20:18:57.658635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    with pytest.raises(TypeError):
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
        parameters = {
            'gen_month': '20',
            'gen_year': '20',
        }
        module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:19:06.068873
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator(argument_spec={}), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None), ArgumentSpecValidator)

# Generated at 2022-06-24 20:19:10.461764
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {'name': 'bo', 'age': '42', 'job': 'chef'}
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'job': 'chef'}
    assert result.error_messages == []


# Generated at 2022-06-24 20:19:19.500200
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Define arguments and argument spec for the following test
    parameters = {'name': 'bo', 'age': '42', 'password': 'secret', 'port': '25', 'enabled': True, 'ip': '192.168.1.1', 'updated': False}
    argument_spec = {'name': {"required": True, "type": "str"}, 'age': {"required": True, "type": "int"}, 'password': {"required": True, "type": "str", "no_log": True}, 'port': {"required": True, "type": "int"}, 'enabled': {"required": True, "type": "bool"}, 'ip': {"required": True, "type": "str"}, 'updated': {"required": True, "type": "bool"}}


# Generated at 2022-06-24 20:19:20.954283
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:19:21.996663
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:19:25.580058
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_validate_0 = ModuleArgumentSpecValidator()

    argument_spec_validator_validate_0.validate(
        {
            'state': 'absent',
            'content': 'yum -y install telnet'
        }
    )


# Generated at 2022-06-24 20:19:49.443138
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameter_spec_0 = dict()  # type: dict

    result_0 = ArgumenSpecValidator.validate(parameter_spec_0)

    assert isinstance(result_0, ValidationResult)

if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-24 20:19:49.972314
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True == True

# Generated at 2022-06-24 20:20:00.932420
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator({'params': {'type': 'str'}}, required_by={'state': ['name', 'host']}, mutually_exclusive={'name': ['speed']}, required_together={'name': ['host'], 'pass': ['speed']}, required_if={'state': 'present', 'name': 'wide open', 'host': 'localhost'}, required_one_of=[['name', 'pass']], mutually_exclusive_set=None, required_one_of_set=None, required_together_set=None)
    module_argument_spec_validator_0.validate({'params': 'string'})
    module_argument_spec_validator_0.validate({'params': 'string', 'name': 'wide open', 'host': 'localhost'})
    module

# Generated at 2022-06-24 20:20:05.834961
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = None
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result.error_messages == []


# Generated at 2022-06-24 20:20:10.507081
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for class ModuleArgumentSpecValidator.validate"""

    # Case 0:
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:20:16.447294
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    test_case_1_validated_parameters = {'param1': 'value1', 'param2': 'value2'}
    test_case_1_validation_result = module_argument_spec_validator_1.validate(test_case_1_validated_parameters)
    assert test_case_1_validation_result == {'param1': 'value1', 'param2': 'value2'}

    module_argument_spec_validator_2 = ModuleArgumentSpecValidator(required_if=['param1', 'value1', ['param2']])
    test_case_2_validated_parameters = {'param1': 'value1', 'param2': 'value2'}
    test_case_2

# Generated at 2022-06-24 20:20:21.545949
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = []
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result._validated_parameters == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == []
    assert result._warnings == []



# Generated at 2022-06-24 20:20:22.788823
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert module_argument_spec_validator_0

# Generated at 2022-06-24 20:20:23.300931
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-24 20:20:26.650844
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = "endpoint, user_password, client_id, client_secret, client_timeout, state, api_timeout"
    module_argument_spec_validator_validate = ModuleArgumentSpecValidator(parameters)

    assert module_argument_spec_validator_validate.validate(parameters) is not None



# Generated at 2022-06-24 20:20:59.269185
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create a new instance of ArgumentSpecValidator with valid arguments
    module_argument_spec_validator_0 = ArgumentSpecValidator()

    # Invoke method validate to test
    # TODO
    # assert()

# Generated at 2022-06-24 20:21:01.821860
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    try:
        result = ModuleArgumentSpecValidator.validate(module_argument_spec_validator_0, parameters)
    except Exception as e:
        raise Exception("Exception raised when calling method 'validate' of class 'ModuleArgumentSpecValidator': {message}".format(message=str(e)))


# Generated at 2022-06-24 20:21:05.544236
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    try:
        result = module_argument_spec_validator_0.validate({
            'parameters': {
                'type': 'dict'
            }
        })
        assert result == {
            'parameters': {
                'type': 'dict'
            }
        }

        # Result contains the validated parameters
        assert result['parameters'] == {'type': 'dict'}
    except Exception as e:
        # Verify that an exception was thrown
        assert False



# Generated at 2022-06-24 20:21:07.536318
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Check that constructor works without passing parameters
    val = ArgumentSpecValidator()


# Generated at 2022-06-24 20:21:13.978231
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    _validator = ModuleArgumentSpecValidator()
    with pytest.raises(RuntimeError) as error:
        _validator.validate()
    assert "validate() missing 1 required positional argument: 'parameters'" == str(error)



# Generated at 2022-06-24 20:21:15.462126
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:21:21.571151
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters=parameters_0)


# Generated at 2022-06-24 20:21:26.893713
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters={})
    assert result is not None
    assert isinstance(result, ValidationResult)
    assert result.errors.messages == []
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._unsupported_parameters == set()
    assert result.validated_parameters == {}
# TESTING END



# Generated at 2022-06-24 20:21:28.550332
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={})
    parameters_0 = {}

    module_argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:21:31.766957
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # No test cases defined
    pass

# Generated at 2022-06-24 20:23:42.468543
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:23:50.988936
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    parameters['name'] = 'bo'
    parameters['age'] = '42'
    argument_spec = dict()
    argument_spec['age'] = dict()
    argument_spec['age']['type'] = 'int'
    argument_spec['name'] = dict()
    argument_spec['name']['type'] = 'str'
    module_argument_spec_validator_0.argument_spec = argument_spec
    module_argument_spec_validator_0._valid_parameter_names = set()

# Generated at 2022-06-24 20:23:52.430053
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:23:53.561877
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  validator = ArgumentSpecValidator()
  validator.validate()

# Generated at 2022-06-24 20:23:58.805704
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Constructor test-cases.
    """
    argument_spec = to_native({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    parameters = to_native({
        'name': 'bo',
        'age': '42',
    })

    # Validate parameters against the argument_spec

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()


# Generated at 2022-06-24 20:24:02.838565
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ValidationResult(parameters={'name': 'bo'})
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters={'name': 'bo'})


# Generated at 2022-06-24 20:24:05.045331
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result_0 = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:24:07.484413
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec_validator = ArgumentSpecValidator()

    params = {'name': 'bo', 'age': '42'}
    # Execute test
    result = argument_spec_validator.validate(params)

    # Check result
    assert result == None


# Generated at 2022-06-24 20:24:13.998098
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-24 20:24:20.085124
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create an object
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Assert type of argument
    assert isinstance(module_argument_spec_validator_0, ModuleArgumentSpecValidator)

    # Call method
    result_0 = module_argument_spec_validator_0.validate()

    # Assert type of return value
    assert isinstance(result_0, ValidationResult)
