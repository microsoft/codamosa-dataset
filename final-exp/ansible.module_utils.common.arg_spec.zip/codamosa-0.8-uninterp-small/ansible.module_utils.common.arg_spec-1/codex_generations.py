

# Generated at 2022-06-24 20:14:56.952676
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    module_argument_spec_validator_0.validate()

# Generated at 2022-06-24 20:15:03.945931
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    parameters_0 = {}
    result = module_argument_spec_validator_0.validate(**parameters_0)
    assert isinstance(result, ValidationResult)
    assert result.errors.messages == []
    assert result.error_messages == []
    assert result.unsupported_parameters == []
    assert result.validated_parameters == {}



# Generated at 2022-06-24 20:15:05.936195
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-24 20:15:13.357431
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  test_params = {
    'str_param': {'date': '3.2.2021', 'name': 'elmer fudd', 'type': 'str'},
    'int_param': {'default': 0, 'type': 'int'},
  }

  validator = ArgumentSpecValidator({
    'str_param': {'type': 'str', 'required': True},
    'int_param': {'type': 'int', 'default': 0},
  })

  result = validator.validate({
    'str_param': 'bob',
    'int_param': 12,
  })

  assert result.validated_parameters == {'str_param': 'bob', 'int_param': 12}


# Generated at 2022-06-24 20:15:18.715613
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_0 = {}
    dict_1 = {}
    argument_spec_validator_0 = ArgumentSpecValidator(**dict_0)
    validationResult_0 = argument_spec_validator_0.validate(**dict_1)
    pass


# Generated at 2022-06-24 20:15:30.484808
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)

    parameters = {
        'remote_url': 'ssh://user@host.com',
        'remote_user': 'root',
        'option': 'value'
    }

    result = module_argument_spec_validator_0.validate(**parameters)

    # Test result
    assert isinstance(result, ValidationResult)
    assert isinstance(result.error_messages, list)
    assert result.error_messages == []
    assert isinstance(result._no_log_values, set)
    assert result._no_log_values == set()
    assert isinstance(result._unsupported_parameters, set)
    assert result._unsupported_parameters == {'option'}

# Generated at 2022-06-24 20:15:38.292795
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    try:
        result_0 = ModuleArgumentSpecValidator(**dict_0).validate(**dict_1)
    except Exception as exc_0:
        result_0 = exc_0
    try:
        result_1 = ModuleArgumentSpecValidator(**dict_2).validate(**dict_3)
    except Exception as exc_1:
        result_1 = exc_1
    try:
        result_2 = ModuleArgumentSpecValidator(**dict_4).validate(**dict_5)
    except Exception as exc_2:
        result_2 = exc_2
    try:
        result_3 = ModuleArgumentSpecValidator(**dict_6).validate(**dict_7)
    except Exception as exc_3:
        result_3 = exc_3

# Generated at 2022-06-24 20:15:42.308142
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create value for argument named 'parameters'
    parameters_0 = {}
    # Call validate(parameters)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:15:44.985778
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_0 = {}
    argument_spec_validator_0 = ArgumentSpecValidator(**dict_0)
    dict_1 = {}
    parameters_0 = {}
    assert argument_spec_validator_0.validate == result_0

# Generated at 2022-06-24 20:15:50.094283
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {
        'name': {
            'type': 'str'
        },
        'age': {
            'type': 'int'
        },
    }

    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }

    validator_0 = ArgumentSpecValidator(argument_spec_0)
    result_val_0 = validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:15:57.766965
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    instance_0 = ModuleArgumentSpecValidator(int_0)

    validation_result_0 = instance_0.validate(int_0)


# Generated at 2022-06-24 20:16:06.098949
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:16:07.765496
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: add other tests
    test_case_0()



# Generated at 2022-06-24 20:16:12.691144
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    ModuleArgumentSpecValidator_instance_0 = ModuleArgumentSpecValidator()
    validation_result_0 = ModuleArgumentSpecValidator_instance_0.validate(int_0)

# Generated at 2022-06-24 20:16:15.501914
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_1 = 23
    module_argument_spec_validator_obj_1 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_obj_1.validate(int_1)


# Generated at 2022-06-24 20:16:19.504765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    warnings_0 = []
    deprecations_0 = []
    validation_result_0 = module_argument_spec_validator_0.validate(int_0, deprecations_0, warnings_0)


# Generated at 2022-06-24 20:16:27.312805
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    ModuleArgumentSpecValidator_instance = ModuleArgumentSpecValidator(int_0)
    validation_result_0 = ModuleArgumentSpecValidator_instance.validate(int_0)
    assert validation_result_0.validated_parameters == int_0
    assert validation_result_0.unsupported_parameters == set((23,))
    assert validation_result_0.error_messages == [u'23']



# Generated at 2022-06-24 20:16:36.749847
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Imports
    from ansible.module_utils.common.arg_spec import ValidationResult
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # Setup

# Generated at 2022-06-24 20:16:46.273294
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {'options': {'type': 'list'}}

    mutually_exclusive_1 = ['name', 'state']

    required_together_0 = [('name', 'state')]

    required_one_of_0 = [['name', 'state']]

    required_if_0 = [['name', 'present', ['required_option']]]

    required_by_0 = {'required_option': 'name'}


# Generated at 2022-06-24 20:16:52.938658
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'type': {'type': 'str'}, 'default': {'type': 'str'}}
    mutually_exclusive_0 = []
    required_together_0 = []
    required_one_of_0 = []
    required_if_0 = []
    required_by_0 = []
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec)
    test_case_0()
    parameters_0 = {'type': 'str'}
    validation_result_0 = argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:17:17.683634
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:17:19.242788
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)


# Generated at 2022-06-24 20:17:28.379971
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)

    assert validation_result_0.validated_parameters == 23

    assert validation_result_0.unsupported_parameters == set()
    assert validation_result_0.error_messages == []

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    assert result.unsupported_parameters == set()
    assert result

# Generated at 2022-06-24 20:17:29.023198
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert true

# Generated at 2022-06-24 20:17:32.786623
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    validation_result_object_0 = ModuleArgumentSpecValidator.validate(validation_result_0)


# Generated at 2022-06-24 20:17:37.033664
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Mock argument and call the method
    mock_self = ["ModuleArgumentSpecValidator", "validate"]

    # Call method
    # assert "validate" == "validate"


# Generated at 2022-06-24 20:17:38.063006
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator.validate()



# Generated at 2022-06-24 20:17:43.699603
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Instantiating class ModuleArgumentSpecValidator with mock object parameters
    mock_parameters = None
    # Instantiating class ModuleArgumentSpecValidator with the help of __init__ method
    mock_instance = ModuleArgumentSpecValidator(mock_parameters)
    # Calling the method validate in class ModuleArgumentSpecValidator
    validation_result_1 = mock_instance.validate(parameters = None)
    assert validation_result_1 is None


# Generated at 2022-06-24 20:17:45.503412
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)


# Generated at 2022-06-24 20:17:46.729543
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # TODO: Update test case to be more flexible and work with Python 3.
    pass

test_case_0()

# Generated at 2022-06-24 20:18:03.886173
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    result = ModuleArgumentSpecValidator(validation_result_0).validate(validation_result_0)
    assert result is not None


# Generated at 2022-06-24 20:18:13.676173
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    int_0 = 23
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_0 = {'type': 'int'}
    validation_result_0 = ValidationResult(int_0)
    obj = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    result = obj.validate(int_0)
    assert result == validation_result_0
    assert result is not None


# Generated at 2022-06-24 20:18:16.203371
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)


# Generated at 2022-06-24 20:18:25.015599
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = []
    required_together_0 = []
    required_one_of_0 = []
    required_if_0 = []
    required_by_0 = dict()
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = dict()
    validation_result = module_argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:18:26.548743
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    int_0 = 23
    ArgumentSpecValidator_1 = ArgumentSpecValidator(int_0)


# Generated at 2022-06-24 20:18:33.607001
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg0 = {}
    arg1 = None
    arg2 = []
    arg3 = {}
    arg4 = {}
    arg5 = []
    arg6 = []
    arg7 = []
    arg8 = {}
    t0 = ModuleArgumentSpecValidator(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
    t1 = ValidationResult(arg0)
    t2 = t0.validate(arg0)
    assert t2 == t1

# Generated at 2022-06-24 20:18:44.997775
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule

    int_0 = 23
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['type'] = 'str'
    dict_1['name'] = dict_2
    dict_2 = dict()
    dict_2['type'] = 'int'
    dict_1['age'] = dict_2
    dict_0['argument_spec'] = dict_1
    argument_spec_0 = dict_0
    set_0 = set()

    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0)

    validation_result_0 = argument_spec_validator_0.validate(set_0)


# Generated at 2022-06-24 20:18:52.349921
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = {}
    spec = {
        'aliases': {'type': 'list', 'default': []},
        'autorefresh': {'type': 'bool', 'default': False},
        'command': {'type': 'str', 'required': True},
        'confirm': {'type': 'bool', 'default': False},
        'command_timeout': {'type': 'int', 'default': 10},
        'creates': {'type': 'str'},
        'executable': {'type': 'str'},
        'removes': {'type': 'str'},
        'stdin': {'type': 'str'},
        'warn': {'type': 'bool', 'default': True}
    }
    validation_result = ArgumentSpecValidator(spec).validate(params)


# Generated at 2022-06-24 20:18:57.269894
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg_spec = {'choices': ['a', 'b', 'c'], 'type': 'str', 'required': True}
    result = ModuleArgumentSpecValidator(arg_spec)({'foo': 'val'})
    assert 'foo' in result.error_messages[0]

# Generated at 2022-06-24 20:19:05.713473
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = {}
    validation_result_0 = ValidationResult(int_0)

    # Test validation errors

# Generated at 2022-06-24 20:19:26.131623
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 23
    validation_result = ValidationResult(int_0)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    validation_result = validator.validate(parameters)
    if validation_result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(validation_result.error_messages)))

    valid_params = validation_result.validated_parameters


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:19:33.592147
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:19:41.720032
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Testing case 1
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    validation_result_0.error_messages
    validation_result_0.validated_parameters
    validation_result_0.unsupported_parameters
    # Testing case 2
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    validation_result_0.error_messages
    validation_result_0.validated_parameters
    validation_result_0.unsupported_parameters
    # Testing case 3
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    validation_result_0.error_messages
    validation_result_0.validated_parameters
    validation_result_0.unsupported_param

# Generated at 2022-06-24 20:19:49.135914
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    with pytest.raises(TypeError):
        str_0 = 'This is a str'
        str_1 = 'This is also a str'
        validation_result_0 = ValidationResult(str_0)
        try:
            raise TypeError(str_1)
        except TypeError:
            pass
        else:
            raise AssertionError("Expected type error, got {0}".format(validation_result_0.validated_parameters))


# Generated at 2022-06-24 20:19:59.920178
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_validator_0 = ArgumentSpecValidator(
        argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = {}
    result = argument_spec_validator_0.validate(parameters_0)

    assert isinstance(result, ValidationResult)
    assert len(result.error_messages) == 0
    assert len(result.unsupported_parameters) == 0
    assert result.validated_parameters == {}

# Generated at 2022-06-24 20:20:03.263482
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Testing with parameters: parameters
    # int_0 = 23
    # validation_result_0 = ValidationResult(int_0)
    validation_result_0 = ValidationResult(23)


# Generated at 2022-06-24 20:20:12.563407
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {"default": "default", "type": "str", "spec": {"description": "description", "options": ["options"], "required": [{"description": "description", "type": "int", "spec": {"description": "description", "options": ["options"], "required": [{"description": "description", "type": "int", "spec": {"description": "description", "options": ["options"], "required": [{"description": "description", "type": "int", "spec": {"description": "description", "options": ["options"], "required": [{"description": "description", "type": "int"}]}}], "additionalProperties": False}}], "additionalProperties": False}}], "additionalProperties": False}}
    mutually_exclusive_0 = []
    required_together_0 = []
    required_one_of_0

# Generated at 2022-06-24 20:20:15.603576
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(int_0)
    validation_result_1 = module_argument_spec_validator_0.validate(int_0)
    validation_result_1 = ModuleArgumentSpecValidator.validate(module_argument_spec_validator_0, int_0)


# Generated at 2022-06-24 20:20:20.692541
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    m_0 = ModuleArgumentSpecValidator()
    p_0 = { }
    r_0 = m_0.validate(p_0)
    # Check that r_0 is equal to expected value(s)
    assert isinstance(r_0, ValidationResult)
    assert ravel(r_0) == ravel(ValidationResult({}))


# Generated at 2022-06-24 20:20:23.062215
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 23
    result_0 = ArgumentSpecValidator(argument_spec=int_0).validate(parameters=int_0)


# Generated at 2022-06-24 20:20:38.904920
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_0 = {"type": "str",}
    result_0 = ArgumentSpecValidator(argument_spec_0)


# Generated at 2022-06-24 20:20:42.505921
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    Test method validate() of class ModuleArgumentSpecValidator
    """
    instance0 = ModuleArgumentSpecValidator()
    str_0 = ""
    validation_result_0 = instance0.validate(str_0)
    return



# Generated at 2022-06-24 20:20:45.994784
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)

    # Skip test for unsupported argument
    # validation_result_2 = ModuleArgumentSpecValidator.validate(int_0)



# Generated at 2022-06-24 20:20:46.533678
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-24 20:20:56.198813
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_1 = 1
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    argument_spec_validator_0 = ArgumentSpecValidator(dict_2, dict_3, dict_4, dict_5, dict_6)
    validation_result_1 = argument_spec_validator_0.validate(int_1)
    assert type(validation_result_1) is ValidationResult


# Generated at 2022-06-24 20:21:05.944623
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    check_mutually_exclusive = (lambda self, mutually_exclusive, parameters: None)
    check_required_arguments = (lambda self, argument_spec, parameters: None)
    _set_defaults = (lambda self, argument_spec, parameters, include_defaults: None)
    _validate_argument_types = (lambda self, argument_spec, parameters, errors: None)
    _validate_argument_values = (lambda self, argument_spec, parameters, errors: None)

    parameters = {}
    argument_spec_validator = ModuleArgumentSpecValidator(None, None, None)
    # int is not a dict, therefore raises a ValueError
    result = argument_spec_validator.validate(parameters)
    assert result.errors[0] == RequiredError("parameters must be a dict")

# Generated at 2022-06-24 20:21:07.798052
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Assert argument type
    args = {}
    # Assert return type
    val = None
    assert isinstance(val, (AnsibleValidationErrorMultiple), msg="Return type should be {}".format(AnsibleValidationErrorMultiple))

# Generated at 2022-06-24 20:21:11.090947
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)
    moduleargumentspecvalidator_0 = ModuleArgumentSpecValidator(int_0)
    validation_result_1 = moduleargumentspecvalidator_0.validate(int_0)

    assert validation_result_1 is validation_result_0

# Generated at 2022-06-24 20:21:13.195427
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = {'name': {'required': True, 'type': 'str'}}
    modarg = ModuleArgumentSpecValidator(spec)
    params = {'name': 'hello world'}
    modarg.validate(params)

# Generated at 2022-06-24 20:21:16.629122
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    int_1 = 23
    validation_result_0 = ValidationResult(int_0)
    argument_spec_dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_dict_0)
    validation_result_1 = module_argument_spec_validator_0.validate(int_1)
    assert validation_result_1 is not None



# Generated at 2022-06-24 20:22:05.323931
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)

    validation_result_0 = ValidationResult(int_0)

# Generated at 2022-06-24 20:22:15.364192
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    sample_spec = {'param1': {'type': 'bool', 'choices': [True, False]}}
    sample_legal_inputs = {'param1': [True, False]}
    sample_parameters = {'param1': False}
    sample_result = ValidationResult(sample_parameters)
    sample_result._validated_parameters = {'param1': True}
    sample_expected_result = {'param1': True}
    # Set up mock
    with patch.object(ArgumentSpecValidator, 'validate', return_value=sample_result):
        spec_validator = ModuleArgumentSpecValidator(sample_spec, None, None, None, None, None)
        result = spec_validator.validate(sample_parameters)
        assert result['param1'] == sample_expected_result

# Generated at 2022-06-24 20:22:23.274543
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Testing when argument is None
    try:
        assert utils.ModuleArgumentSpecValidator.validate(None) == None
    except AssertionError as e:
        utils.tutschkopf().fail(e)

    # Testing when argument is an integer
    try:
        assert utils.ModuleArgumentSpecValidator.validate(23) == 23
    except AssertionError as e:
        utils.tutschkopf().fail(e)

    # Testing when argument is a string
    try:
        assert utils.ModuleArgumentSpecValidator.validate("fish") == "fish"
    except AssertionError as e:
        utils.tutschkopf().fail(e)

    # Testing when argument is a list

# Generated at 2022-06-24 20:22:27.435272
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    dict_0 = {'age': '42', 'name': 'bo'}
    argument_spec_validator_0 = ArgumentSpecValidator(dict_0)
    validation_result_0 = argument_spec_validator_0.validate(int_0)
    assert (validation_result_0 != None)


# Generated at 2022-06-24 20:22:29.118727
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)

    assert False, "WIP"



# Generated at 2022-06-24 20:22:35.964416
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 23
    validation_result_0 = ValidationResult(int_0)

    argument_spec_0 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }
    result_0 = ArgumentSpecValidator(argument_spec_0).validate(parameters_0)
    assert result_0.validated_parameters == {'name': 'bo', 'age': '42'}


    argument_spec_0 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-24 20:22:40.402594
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {}
    parameters = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    ansible_validator = ArgumentSpecValidator(arg_spec = arg_spec, mutually_exclusive = mutually_exclusive, required_together = required_together, required_one_of = required_one_of, required_if = required_if, required_by = required_by)
    ansible_validation_result = ansible_validator.validate(parameters = parameters)
    assert ansible_validation_result


# Generated at 2022-06-24 20:22:42.337933
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:22:43.636258
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert isinstance(ModuleArgumentSpecValidator.validate(ArgumentSpecValidator, int), ValidationResult)


# Generated at 2022-06-24 20:22:50.582106
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_10 = 23
    validation_result_10 = ValidationResult(int_10)

    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parameters)

    assert result.errors.messages == []
    assert result.validated_parameters == {"name": "bo", "age": 42}

# Generated at 2022-06-24 20:23:53.791994
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 23
    ModuleArgumentSpecValidator_instance = ModuleArgumentSpecValidator()
    result = ModuleArgumentSpecValidator_instance.validate(int_0)
    assert result

# Generated at 2022-06-24 20:23:54.578741
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-24 20:24:06.106740
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.network import register_platform_parameter
    register_platform_parameter('iosxr', 'netconf_transport', 'ssh')

# Generated at 2022-06-24 20:24:14.866821
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Verify that the ArgumentSpecValidator.validate method doesn't raise exceptions
    #   when called with valid types
    argument_spec_0 = {"type": "str"}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    str_0 = "A string."
    validation_result_0 = argument_spec_validator_0.validate(str_0)


# Generated at 2022-06-24 20:24:21.137607
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    # Check that the expected exit status is returned when the 'parameters' argument is not provided
    # and that the expected Exception is raised.
    result = ModuleArgumentSpecValidator().validate()
    assert result == TypeError()



# Generated at 2022-06-24 20:24:29.187310
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'str'}}
    mutually_exclusive = [["a", "b"]]
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    mav = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    # No assertions yet
    mav.validate({})
    mav.validate({'a': 'string'})
    mav.validate({'a': 'string', 'b': 'string'})
    mav.validate({'c': 'string'})


# Generated at 2022-06-24 20:24:31.877828
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Input parameters and expected return value test cases
    params = dict()
    expected = None

    # Perform the test
    instance = ArgumentSpecValidator(params)
    result = instance.validate(params)
    assert isinstance(result, ValidationResult) == expected

# Generated at 2022-06-24 20:24:39.621830
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = {
        'b_or_d': {
            'default': 'blue',
            'type': 'str',
            'choices': ['blue', 'red', 'yellow']
        },
        'c': {
            'type': 'str',
            'required': True,
            'choices': ['blue', 'red', 'yellow']
        },
        'a': {
            'default': 'blue',
            'type': 'str',
            'choices': ['blue', 'red', 'yellow']
        }
    }

    mutually_exclusive_0 = [
        ['a', 'b_or_d']
    ]

    parameters_0 = {
        'a': 'blue',
        'b_or_d': 'blue',
        'c': 'blue'
    }

    #

# Generated at 2022-06-24 20:24:44.633542
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    int_0 = 23

    validation_result_0 = ValidationResult(int_0)
    assert validation_result_0.validated_parameters == int_0
    assert validation_result_0.unsupported_parameters == set()
    assert validation_result_0.error_messages == []


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgumentSpecValidator_validate()