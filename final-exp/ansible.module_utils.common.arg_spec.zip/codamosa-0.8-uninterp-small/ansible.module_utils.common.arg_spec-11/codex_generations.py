

# Generated at 2022-06-24 20:15:01.290340
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
            'name': 'John',
            'age': '42',
        }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'age': 42, 'name': 'John'}


# Generated at 2022-06-24 20:15:06.363557
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {"key_0" : dict(), "key_1" : dict(), "key_2" : dict()}
    result = module_argument_spec_validator_0.validate(parameters)
    assert not result.errors, result.errors


# Generated at 2022-06-24 20:15:10.026367
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Check for KeyError
    parameters = {}
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_1.validate(parameters)
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-24 20:15:16.057471
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-24 20:15:17.972342
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # First use try/except like tests in other files
    try:
        module_argument_spec_validator_0 = ArgumentSpecValidator()
    except:
        pass
    # Then assert for failure
    assert(True)


# Generated at 2022-06-24 20:15:21.764616
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator"""
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:15:27.824936
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    arg_spec_1 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters_1 = {
        'name': 'bo',
        'age': '42',
    }
    assert module_argument_spec_validator_0.validate(parameters_1)

# Generated at 2022-06-24 20:15:30.716048
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Place holder for test case data
    parameters_0 = {}
    # Place holder for return data
    _set_defaults_0 = None
    # Call the method
    try:
        _set_defaults_0 = module_argument_spec_validator_0.validate(parameters_0)
    except Exception as e:
        pass


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-24 20:15:35.493077
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator(argument_spec=dict(), mutually_exclusive=list(),
                                                                   required_together=list(), required_one_of=list(),
                                                                   required_if=list(), required_by=dict())
    parameters_1 = dict()
    result_1 = module_argument_spec_validator_1.validate(parameters_1)
    assert result_1

# Generated at 2022-06-24 20:15:44.845971
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Check error message for "required_if" argument check
    """
    argument_spec = {
        "required_if_0": {"required": False, "type": "str"},
        "required_if_1": {"required": False, "type": "str"},
        "required_if_2": {"required": False, "type": "str"},
        "required_if_3": {"required": False, "type": "str"},
        "required_if_4": {"required": False, "type": "str"},
    }


# Generated at 2022-06-24 20:15:54.938258
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    MODULES_VALIDATE_PARAMETERS = {
        'parameter': 'value',
    }

    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_1.validate(MODULES_VALIDATE_PARAMETERS)

    assert result is not None


# Generated at 2022-06-24 20:15:55.777079
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:16:02.639293
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {}
    error = None
    result = None
    try:
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
        result = module_argument_spec_validator_0.validate(parameters)
    except Exception as e:
        error = e
    assert error is not None
    assert result is None


if __name__ == "__main__":
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:16:08.955973
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  try:
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    params = dict()
    # Test the return type is ValidationResult
    assert isinstance(module_argument_spec_validator_1.validate(params), ValidationResult)

  except Exception as e:
    print('Caught exception: ' + str(e))
    raise


# Generated at 2022-06-24 20:16:10.085346
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert isinstance(ModuleArgumentSpecValidator.validate, object)


# Generated at 2022-06-24 20:16:17.601723
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'is_active': {'type': 'bool'},
        'enum_field': {'type': 'str', 'choices': ['a', 'b', 'c']}
        }

    parameters = {
        'name': 'bo',
        'age': '42',
        'is_active': 'True',
        'enum_field': 'b',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-24 20:16:19.096400
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {}
    assert ArgumentSpecValidator.validate(parameters)


# Generated at 2022-06-24 20:16:24.458090
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    loader = importlib.machinery.SourceFileLoader('', './test/unit/test_ModuleArgumentSpecValidator.py')
    spec = importlib.util.spec_from_loader(loader.name, loader)
    test_mod = importlib.util.module_from_spec(spec)
    loader.exec_module(test_mod)

    # Initialize test_ModuleArgumentSpecValidator_validate
    test_parameters = dict()
    # Test ModuleArgumentSpecValidator.validate method
    test_mod.test_case_0()


# Generated at 2022-06-24 20:16:26.707768
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {"invalid_param": "value"}
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_1.validate(parameters)
    assert len(result)==1


# Generated at 2022-06-24 20:16:28.609627
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    # Make sure validate does not return None
    result = module_argument_spec_validator.validate({"name": "bo", "age": "42"})


# Generated at 2022-06-24 20:16:37.765993
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}

    ##
    # If a parameter is passed by name, it must show up in the argument spec and
    # that parameter cannot be marked as required.
    ##
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        # This parameter is not required
        'name': {'type': 'str'},
        # This parameter is required
        'age': {'type': 'int', 'required': True},
    }
    result = ArgumentSpecValidator(argument_spec).validate(parameters)
    assert len(result.error_messages) == 0


# Generated at 2022-06-24 20:16:42.119962
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0.validate({
        '0': '0',
        '1': '1',
    }), ValidationResult)


# Generated at 2022-06-24 20:16:47.925230
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:16:50.793460
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = dict(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}})
    args['parameters'] = {'name': 'bo', 'age': '42'}

    result = ArgumentSpecValidator(**args)

    assert result is not None

# Generated at 2022-06-24 20:16:53.981177
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Test case 0
    # ArgumentSpecValidator
    module_argument_spec_validator_0 = ArgumentSpecValidator()

    # dict[str, dict]
    parameters_0 = {}

    # ValidationResult
    validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)



# Generated at 2022-06-24 20:16:56.948980
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    assert isinstance(module_argument_spec_validator_0.validate(parameters_0), ValidationResult)


# Generated at 2022-06-24 20:17:02.068224
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # test ModuleArgumentSpecValidator.validate()
    module_argument_spec_validator_0.validate({})
    module_argument_spec_validator_0.validate({})


# Generated at 2022-06-24 20:17:13.740504
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)

    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    result_1 = module_argument_spec_validator_1.validate(parameters_1)

    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()
    parameters_2 = {}
    result_2 = module_argument_spec_validator_2.validate(parameters_2)

    module_argument_spec_validator_3 = ModuleArgumentSpecValidator()
    parameters_3 = {}

# Generated at 2022-06-24 20:17:22.659702
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Test input which does not match argument spec
    parameters_0 = {'name': 'bo', 'age': 42}
    # Test input which does match argument spec
    parameters_1 = {'name': 'bo', 'age': '42'}
    # Test input which does not match argument spec
    parameters_2 = {'name': ['bo', 'bob'], 'age': 42}
    # Test input which does match argument spec
    parameters_3 = {'name': ['bo', 'bob'], 'age': '42'}

    # Testing input argument: parameters_0
    validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert validation_result_0.errors == []

# Generated at 2022-06-24 20:17:27.548282
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    res = ArgumentSpecValidator()
    assert res is not None, "Failed to create an instance of class ArgumentSpecValidator"

# Generated at 2022-06-24 20:17:35.024864
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    test_arg_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'str'},
        'c': {'type': 'str'},
    }

    test_inputs = {
        'a': 'one',
        'b': 'two',
        'c': 'three'
    }

    test_expected_arg_spec = {
        'a': 'one',
        'b': 'two',
        'c': 'three'
    }

    test_instance = ArgumentSpecValidator(test_arg_spec)

    # Exercise
    test_result = test_instance.validate(test_inputs)

    test_result_validated_params = test_result.validated_parameters

    # Verify

# Generated at 2022-06-24 20:17:36.164204
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False


# Generated at 2022-06-24 20:17:38.834812
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Test if method validate throws an exception when argument parameters is not of valid type
    with pytest.raises(AttributeError) as excinfo:
        module_argument_spec_validator_0.validate("None")
    # Test without argument parameters
    module_argument_spec_validator_0.validate()

# Generated at 2022-06-24 20:17:46.000189
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    argument_spec_0 = {}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    params_0 = {}
    validator_0 = ArgumentSpecValidator()

    # Testing
    test_case_result_0 = validator_0.validate(params_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)

    # Unit test assertion
    assert test_case_result_0 is not None



# Generated at 2022-06-24 20:17:49.429247
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec=dict())
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    print(result._deprecations)



# Generated at 2022-06-24 20:17:54.425528
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:17:59.450069
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert (hasattr(module_argument_spec_validator_0.validate, '__call__')
            ), "Class ModuleArgumentSpecValidator has no 'validate' method"
    assert (hasattr(module_argument_spec_validator_0, '_valid_parameter_names')
            ), "Class ModuleArgumentSpecValidator has no '_valid_parameter_names' attribute"


# Generated at 2022-06-24 20:18:06.887032
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []


# Generated at 2022-06-24 20:18:09.162087
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Test when positional args length is 0
    assert len(module_argument_spec_validator_0.validate('parameters_0').error_messages) == 0

# Generated at 2022-06-24 20:18:17.212887
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    root_dir = 'tests/data/ansible_collections/ansible/python/plugins/modules/ansible_test/tests/'
    test_dir = 'tests/unit/module_utils/common/arg_spec/'
    test_file = 'validate_ansible_test_result.txt'
    test_file_path = root_dir + test_dir + test_file
    f = open(test_file_path, 'r')
    result_dict = {}
    key_value_list = []
    for i, line in enumerate(f):
        if i > 1:
            key_value_list.append(line.split(',', 1))
        elif i == 1:
            key_value_list.append(line.split(',', 1))

# Generated at 2022-06-24 20:18:22.070097
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:18:25.541729
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {"foo": "bar"}
    result = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:18:29.185440
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:18:36.181028
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Raises TypeError if parameters is not a dict.
    with pytest.raises(TypeError):
        module_argument_spec_validator_validate_0 = ModuleArgumentSpecValidator()
        result = module_argument_spec_validator_validate_0.validate("parameters")
        assert result == None

    # Successful validation should contain no errors.
    module_argument_spec_validator_validate_1 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_validate_1.validate("parameters")
    assert len(result.errors) == 0

# Generated at 2022-06-24 20:18:44.073543
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()

    # Test using a dict as parameters
    assert module_argument_spec_validator_0.validate({})[0] == "this test needs some parameters"
    # Test using a string as parameters
    try:
        module_argument_spec_validator_0.validate("Some parameters")
    except SystemExit:
        pass
    else:
        raise AssertionError("Argument should be a dict")
    # Test using a list as parameters
    try:
        module_argument_spec_validator_0.validate(["Some parameters"])
    except SystemExit:
        pass
    else:
        raise AssertionError("Argument should be a dict")

# Generated at 2022-06-24 20:18:49.057998
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Testing the following exception:
    # ansible.module_utils.common.validation.ValidationError: a is required

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = dict()

    try:
        module_argument_spec_validator_0.validate(parameters)
    except Exception as e:
        assert(e.args[0] == 'a is required')



# Generated at 2022-06-24 20:18:52.585047
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    with pytest.raises(NotImplementedError):
        module_argument_spec_validator_0.validate()

# Generated at 2022-06-24 20:19:02.606834
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }
    validator_0 = ArgumentSpecValidator(argument_spec_0)
    result_0 = validator_0.validate(parameters_0)
    assert not result_0.errors
    assert result_0.validated_parameters == {'name': 'bo', 'age': 42}
    assert result_0._validated_parameters == {'name': 'bo', 'age': '42'}
    assert result_0.error_messages == []



# Generated at 2022-06-24 20:19:09.974270
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # verify successful validation with string
    argument_spec_validator_0 = ArgumentSpecValidator({'name': {'type': 'str'}})
    result_0 = argument_spec_validator_0.validate({'name': 'bo'})
    assert(result_0.validated_parameters == {'name': 'bo'})

    # verify successful validation with int
    argument_spec_validator_1 = ArgumentSpecValidator({'name': {'type': 'str'}})
    result_1 = argument_spec_validator_1.validate({'name': 'bo'})
    assert(result_1.validated_parameters == {'name': 'bo'})

    # verify successful validation with dict

# Generated at 2022-06-24 20:19:12.998944
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0.validate(parameters=''), ValidationResult)


# Generated at 2022-06-24 20:19:25.111296
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Validate to make sure no exception is thrown
    if True:
        parameters = {
            'name': 'bo',
            'age': '42',
        }

        legal_inputs = {
            'name': 'bo',
            'age': 42,
        }

        result = module_argument_spec_validator_0.validate(parameters)

        assert result


# Generated at 2022-06-24 20:19:29.187796
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:19:33.222366
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_0 = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0)
    assert argument_spec_validator_0.argument_spec == argument_spec_0
    # per merge/poc decorator is removed
    # assert argument_spec_validator_0.failsafe_only == False


# Generated at 2022-06-24 20:19:41.510869
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # TEST-FIXTURE-BEGIN
    # TESTING-FIXTURE-SETUP-BEGIN
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # TESTING-FIXTURE-SETUP-END ...

    # TEST-FIXTURE-END ...

    def test_case_0():
        # TESTING-ALTERNATIVE-BEGIN
        # TESTING-ALTERNATIVE-SETUP-BEGIN
        # TESTING-ALTERNATIVE-SETUP-END ...

        result = module_argument_spec_validator_0.validate(parameters={
            "first_item": "pizza",
            "second_item": "sandwiches",
        })

        # TESTING-ALTERNATIVE-END ...



# Generated at 2022-06-24 20:19:45.290689
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.error_messages == ["'name' is mutually exclusive with 'age'"]


# Generated at 2022-06-24 20:19:47.688461
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters_0 = {}
    test_case_0 = ModuleArgumentSpecValidator().validate(parameters_0)
    assert test_case_0.unsupported_parameters == set()



# Generated at 2022-06-24 20:19:48.205821
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  assert True

# Generated at 2022-06-24 20:19:55.817838
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameter_0 = {'type': 'dict', 'types': ['int', 'str'], 'subspec': {'subsubspec': {'subsubsubspec': {'type': 'bool'}}}}
    parameter_1 = {'type': 'dict', 'subspec': {'subsubspec': {'subsubsubspec': {'type': 'bool'}}}, 'types': ['int', 'str']}
    parameter_2 = {}
    parameter_3 = {'type': 'dict', 'subspec': {'subsubspec': {'subsubsubspec': {'type': 'bool'}}}, 'types': ['int', 'str'], 'version_added': '1.0'}
    result_0 = module_argument_spec_validator_

# Generated at 2022-06-24 20:19:58.715100
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # test default behavior
    module_argument_spec_validator_0.validate()

# Generated at 2022-06-24 20:20:04.399183
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-24 20:20:22.757887
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json
    import argparse
    parser = argparse.ArgumentParser(description='Test Class ArgumentSpecValidator')
    parser.add_argument('input', type=str, help='input data file')
    args = parser.parse_args()

    with open(args.input) as f:
        in_data = json.loads(f.read())

    obj_0 = ArgumentSpecValidator(in_data[0], in_data[1], in_data[2], in_data[3], in_data[4], in_data[5])
    output_0 = obj_0.validate(in_data[6])

    with open('/tmp/test/test_ArgumentSpecValidator_validate.json', 'w') as f:
        f.write(json.dumps(output_0))

# Unit test

# Generated at 2022-06-24 20:20:23.239947
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:20:25.120976
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:20:29.313102
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert result.unsupported_parameters == set()
    assert result.error_messages == []
    assert result.validated_parameters == {}


# Generated at 2022-06-24 20:20:33.316414
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {
    }
    result_0 = module_argument_spec_validator_0.validate(parameters_0)

    assert result_0


# Generated at 2022-06-24 20:20:39.789787
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator(
        {'string': {'type': 'str'}},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={}
    )
    result = module_argument_spec_validator.validate(
       {'string': 'text'}
    )
    assert result._validated_parameters == {'string': 'text'}


# Generated at 2022-06-24 20:20:41.644621
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator()
    parameters_0 = {}
    argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:20:47.642348
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-24 20:20:50.625783
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {"parameters": "npm_format", "help": "parameters"}
    assert isinstance(module_argument_spec_validator_0.validate(parameters), ValidationResult)


# Generated at 2022-06-24 20:20:59.248632
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validation_result_0 = ValidationResult({})
    assert isinstance(validation_result_0, ValidationResult) == True
    validation_result_0_keys = set(dir(validation_result_0))
    validation_result_0_keys_expected = {'error_messages', 'errors', 'validated_parameters', '_deprecations', '_no_log_values', '_unsupported_parameters', '_validated_parameters', '_warnings'}

    assert validation_result_0_keys_expected.issubset(validation_result_0_keys) == True
    validation_result_0_errors = validation_result_0.errors
    assert isinstance(validation_result_0_errors, list) == True

    argument_spec_validator_0 = ArgumentSpecValidator({})


# Generated at 2022-06-24 20:21:21.989859
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert len(result_0.errors) == 0


# Generated at 2022-06-24 20:21:24.501795
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    with pytest.raises(TypeError):
        module_argument_spec_validator_0.validate()

# Generated at 2022-06-24 20:21:31.271807
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Test validate() method of class ArgumentSpecValidator
    Parameters:
        - None
    Raises:
        - None
    """
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters, "Validated parameters is {0}".format(result.validated_parameters)

    return None


# Generated at 2022-06-24 20:21:41.311879
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Unit test for ArgumentSpecValidator.validate
    """

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator({
        'type': {'required': True, 'choices': ['str', 'list', 'dict']},
        'name': {'type': 'str', 'required': True},
        'value': {'type': 'str', 'required': True}
    },)
    parameters = {
        'type': 'str',
        'name': 'bo',
        'value': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters)

    assert result.validated_parameters == {'type': 'str', 'name': 'bo', 'value': '42'}
    assert result.unsupported_parameters == set()
   

# Generated at 2022-06-24 20:21:49.030897
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate()"""
    print("\n\n===Running test_ArgumentSpecValidator_validate for AnsibleModule===")

    # Test case 1
    # Test case for None argument_spec
    print("***Test case 1***")
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {'ansible_version': {'full': '2.10.8', 'api': (2, 11)}}
    module_argument_spec_validator_1.validate(parameters_1)

    # Test case 2
    # Test case for empty argument_spec
    print("***Test case 2***")
    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:21:55.576100
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_validate_0 = ModuleArgumentSpecValidator(argument_spec={"properties": {"mother": {"type": "str"}, "father": {"type": "str"}}}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    parameters_0 = {}
    parameters_1 = {"mother": "Marie Curie", "father": "James Watt"}
    parameters_2 = {"father": "James Watt"}
    parameters_3 = {"mother": "Marie Curie"}
    parameters_4 = {"mother": "Marie Curie", "father": "James Watt", "mother": "René Descartes", "father": "Gottfried Leibniz"}

# Generated at 2022-06-24 20:21:59.342121
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate({})
    assert result.errors == []
    assert result.validated_parameters == {}



# Generated at 2022-06-24 20:22:06.706408
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == [], "Parameter 'error_messages' is empty."
    assert result.validated_parameters == {'age': 42, 'name': 'bo'}, "Parameter 'validated_parameters' equals {'age': 42, 'name': 'bo'}."


# Generated at 2022-06-24 20:22:09.615782
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate()



# Generated at 2022-06-24 20:22:11.206876
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator()
    parameters = dict()
    validator.validate(parameters)

# Generated at 2022-06-24 20:22:43.392446
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert False


# Generated at 2022-06-24 20:22:46.373733
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    assert module_argument_spec_validator_0.validate(parameters_0) == ValidationResult(parameters_0)

# Generated at 2022-06-24 20:22:50.771620
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    result_1 = module_argument_spec_validator_0.validate(parameters_0)
    # Print the result of the test
    print(result_0)
    print(result_1)
    assert True

test_case_0()

# Generated at 2022-06-24 20:22:51.407679
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-24 20:22:57.725330
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec=spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-24 20:23:08.171576
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  argument_spec = {
    'playbook': {
      'required': False, 
      'version_added': None, 
      'type': 'str', 
      'default': None, 
      'description': 'Path to playbook', 
      'value': 'test value', 
      'no_log': None, 
      'aliases': ['pb']
    },
    'inventory': {
      'required': False, 
      'version_added': None, 
      'type': 'str', 
      'default': None, 
      'description': 'Path to inventory', 
      'value': 'test value', 
      'no_log': None, 
      'aliases': ['inv']
    }
  }

# Generated at 2022-06-24 20:23:16.857377
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'path': 'C:\\Windows\\Temp', 
        'loglevel': 'debug', 
        'fetch_timeout': 0, 
        'archive': '{{installer_path}}', 
        'dest': 'C:\\Windows\\Temp\\ansible_installer.exe'
    }
    result = module_argument_spec_validator_0.validate(parameters)
    assert(result.validated_parameters['fetch_timeout'] == 0)
    assert(result.validated_parameters['path'] == 'C:\\Windows\\Temp')
    assert(result.validated_parameters['dest'] == 'C:\\Windows\\Temp\\ansible_installer.exe')

# Generated at 2022-06-24 20:23:22.291194
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        "name": 42,
        "age": 'bo',
    }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate(parameters)
    # If assertion fails, verify you are populating the errors
    assert len(module_argument_spec_validator_0.errors) == 0



# Generated at 2022-06-24 20:23:24.810508
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True


# Generated at 2022-06-24 20:23:29.796943
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    v0 = module_argument_spec_validator_0.validate(parameters_0)
    assert isinstance(v0, ValidationResult)
    assert v0.validated_parameters == dict()
    assert v0.unsupported_parameters == set()
    assert v0.errors.messages == []
    assert v0.error_messages == []
    assert v0._no_log_values == set()
    assert v0._validated_parameters == dict()

# Generated at 2022-06-24 20:24:37.855020
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}, "validated parameters is not as expected"

# Generated at 2022-06-24 20:24:40.708748
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    a = ModuleArgumentSpecValidator()
    return a.validate()

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 20:24:44.338688
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()
    parameters_2 = {}
    expected_2 = None
    actual_2 = module_argument_spec_validator_2.validate(parameters_2)
    assert actual_2 == expected_2


# Generated at 2022-06-24 20:24:46.104410
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()