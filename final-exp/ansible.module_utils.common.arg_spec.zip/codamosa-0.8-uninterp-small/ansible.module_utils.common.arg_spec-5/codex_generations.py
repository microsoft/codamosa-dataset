

# Generated at 2022-06-24 20:14:59.609704
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Jason
    # test where both returns are the same (if statement)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    var_0 = module_argument_spec_validator_0.validate(module_argument_spec_validator_0)
    # if var_0 == None:
    #    pass
    # else:
    #    raise Exception("Code ubsanitizer error: {function_name} is not being tested properly".format(function_name = "test_ModuleArgumentSpecValidator_validate"))

    var_0 = module_argument_spec_validator_0.validate(module_argument_spec_validator_0)
    # if var_0 == None:
    #    pass
    # else:
    #    raise Exception("Code ubsanitizer error:

# Generated at 2022-06-24 20:15:01.511885
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO Add unit test
    raise NotImplementedError()

# Generated at 2022-06-24 20:15:03.390587
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False


# Generated at 2022-06-24 20:15:09.250644
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    var = {'name': 'bo', 'age': '42'}
    argument_spec_validator_0 = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})
    actual_returned_value = argument_spec_validator_0.validate(var)
    assert type(actual_returned_value) is ValidationResult


# Generated at 2022-06-24 20:15:11.417136
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case with valid input
    argument_spec_validator_2 = ArgumentSpecValidator()
    var_2 = argument_spec_validator_2.validate(argument_spec_validator_2)



# Generated at 2022-06-24 20:15:13.723956
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test Case 1
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    var_0 = module_argument_spec_validator_1.validate(module_argument_spec_validator_1)


# Generated at 2022-06-24 20:15:21.813659
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Assert
    #
    #   var_0  =  ModuleArgumentSpecValidator()
    #   var_0 . validate( var_0 )
    #

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    var_0 = module_argument_spec_validator_0.validate(module_argument_spec_validator_0)


# Generated at 2022-06-24 20:15:23.356565
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    var_0 = module_argument_spec_validator_0.validate()
    return var_0

# Generated at 2022-06-24 20:15:26.495989
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    var_0 = module_argument_spec_validator_0.validate(module_argument_spec_validator_0)

# Generated at 2022-06-24 20:15:29.922408
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_4 = ModuleArgumentSpecValidator()
    var_4 = module_argument_spec_validator_4.validate(module_argument_spec_validator_4)


# Generated at 2022-06-24 20:15:46.307012
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(
        argument_spec_0,
        mutually_exclusive_0,
        required_together_0,
        required_one_of_0,
        required_if_0,
        required_by_0,
    )

    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert isinstance(result_0, ValidationResult)



# Generated at 2022-06-24 20:15:50.641719
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg1 = [['one', 'two', ['three', 'four']]]
    arg2 = {'type': 'str'}
    arg3 = [['one', 'two']]
    arg4 = {'required_if': arg1, 'aliases': ['one', 'two']}
    arg5 = {'one': arg4}
    arg6 = {'type': 'list', 'elements': 'str', 'required_together': arg3, 'aliases': ['foo', 'bar', 'foobar']}
    arg7 = {'required_if': arg1, 'aliases': ['one', 'two'], 'type': 'bool'}
    arg8 = {'required_by': arg5, 'type': 'str'}

# Generated at 2022-06-24 20:15:57.408425
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arg = object()
    arg_0 = {'version': arg, 'type': str, 'required': True}
    arg_1 = {'version': arg, 'type': str}
    arg_2 = {'version': arg, 'type': dict, 'required': True}
    arg_3 = {'version': arg, 'type': dict}
    arg_4 = {'version': arg, 'type': list, 'required': True}
    arg_5 = {'version': arg, 'type': list}
    arg_6 = {'version': arg, 'type': dict}
    arg_7 = {'version': arg, 'type': bool}
    arg_8 = {'version': arg, 'type': dict}
    arg_9 = {'version': arg, 'type': dict}

# Generated at 2022-06-24 20:16:02.536330
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_validate = 589
    validation_result = ValidationResult(int_validate)
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator.validate(validation_result)


# Generated at 2022-06-24 20:16:03.242375
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-24 20:16:11.788934
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)

    int_1 = 5453
    validation_result_1 = ValidationResult(int_1)

    # AssertionError: <ansible.module_utils.common.arg_spec.ValidationResult object at 0x7fa3b36cee80> not equals <ansible.module_utils.common.arg_spec.ValidationResult object at 0x7fa3b36cee10>
    assert validation_result_0 == validation_result_1


# Generated at 2022-06-24 20:16:13.978580
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 9650
    result = ModuleArgumentSpecValidator.validate(int_0)


# Generated at 2022-06-24 20:16:22.373864
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validation_result = ValidationResult(None)

    # test_case_0
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    assert validation_result_0.error_messages is not None
    assert validation_result_0.unsupported_parameters is not None
    assert validation_result_0.validated_parameters is not None
    assert validation_result_0.validated_parameters is not None

    # test_case_1
    str_0 = "abc"
    validation_result_1 = ValidationResult(str_0)
    assert validation_result_1.error_messages is not None
    assert validation_result_1.unsupported_parameters is not None
    assert validation_result_1.validated_parameters is not None
    assert validation_result

# Generated at 2022-06-24 20:16:24.160525
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result_0 = validation_result_0

    assert result_0.error_messages == []
    assert result_0.validated_parameters == int_0

# Generated at 2022-06-24 20:16:26.909141
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argumentspec = {}
    parameters = 30
    instance = ModuleArgumentSpecValidator(argumentspec)
    result = instance.validate(parameters)
    assert result is not None


# Generated at 2022-06-24 20:16:50.527238
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    name_0 = 'test_ModuleArgumentSpecValidator_validate_0'
    argument_spec_0 = {
        'type': 'dict',
        'options': {
            'name': {
                'type': 'str',
            },
        },
    }
    parameters_0 = {
        'name': 'string',
    }
    test_ModuleArgumentSpecValidator = ModuleArgumentSpecValidator(argument_spec_0)
    validation_result_0 = test_ModuleArgumentSpecValidator.validate(parameters_0)


# Generated at 2022-06-24 20:16:54.250934
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    # Test that a TypeError is raised if the first argument is not of type 'dict'
    try:
        ArgumentSpecValidator.validate(ArgumentSpecValidator, validation_result_0)
    except TypeError:
        pass
    else:
        assert False, 'ExpectedTypeError not found'



# Generated at 2022-06-24 20:17:00.999687
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
            'foo': {'type':'int'},
            'bar': {'type':'str', 'aliases':['bar1']}
    }

    mutually_exclusive = [['foo', 'bar']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'bar']]
    required_if = [['foo', '1', ['bar']]]
    required_by = {'bar': ['foo']}

    validation_result = ArgumentSpecValidator(argument_spec)

    validation_result_1 = validation_result.validate(argument_spec)

    validation_result_2 = validation_result.validate(argument_spec, mutually_exclusive=mutually_exclusive)


# Generated at 2022-06-24 20:17:03.031493
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    validation_result_0 = module_argument_spec_validator.validate(int_0)


# Generated at 2022-06-24 20:17:11.505264
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_argspec_accepter_0 = {
        'type': 'int',
        'default': 6,
        'required': True,
        'no_log': False
    }
    str_argspec_accepter_0 = {
        'choices': ['present', 'absent'],
        'type': 'str',
        'default': 'present',
        'required': True,
        'no_log': False
    }
    bool_argspec_accepter_0 = {
        'type': 'bool',
        'default': False,
        'required': False,
        'no_log': False
    }

# Generated at 2022-06-24 20:17:16.321200
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(int_0)
    assert module_argument_spec_validator_0.validate(int_0) is validation_result_0


# Generated at 2022-06-24 20:17:20.306784
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # ArgumentSpecValidator(self: ArgumentSpecValidator, argument_spec: dict[str, dict], mutually_exclusive: list[list[str]], required_together: list[list[str]], required_one_of: list[list[str]], required_if: list, required_by: dict[str, list[str]])
    pass

# Generated at 2022-06-24 20:17:28.781107
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    argument_spec_0 = {'name': {'type': 'dict'}}
    mutually_exclusive_0 = [
        [
            'dict_0',
            'dict_1'
        ]
    ]
    required_together_0 = [
        [
            'hello',
            'hello'
        ]
    ]
    required_one_of_0 = [
        [
            'name_0',
            'name_1'
        ]
    ]

# Generated at 2022-06-24 20:17:36.154827
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(validation_result_0)
    int_1 = int_0
    validation_result_1 = module_argument_spec_validator_0.validate(int_1)
    return validation_result_1


# Generated at 2022-06-24 20:17:45.228538
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)

    # test case 1
    validation_result_1 = ModuleArgumentSpecValidator(argument_spec={'value_spec': {'key_spec': {'type': 'int'}}}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None).validate(int_0)
    assert not (validation_result_1 == validation_result_0)

    # test case 2

# Generated at 2022-06-24 20:17:59.040374
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = dict()
    validation_result_0 = argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:18:03.350784
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    instance = None
    parameters = dict()

    try:
        ModuleArgumentSpecValidator.validate(instance, parameters)
    except SystemExit as exception:
        assert exception.args[0] == 1
    except Exception as exception:
        raise AssertionError("unexpected exception raised: " + str(type(exception)))


if __name__ == '__main__':
    test_case_0()
    print("Unit tests for ModuleArgumentSpecValidator complete.")

# Generated at 2022-06-24 20:18:09.922978
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    validation_result_0.validated_parameters = int_0
    bool_0 = False
    validation_result_0.errors = AnsibleValidationErrorMultiple(bool_0, bool_0)
    bool_1 = True
    validation_result_0.error_messages = []
    argument_spec_validator_0 = ArgumentSpecValidator(validation_result_0)
    str_0 = 'validated_parameters'
    str_1 = 'errors'
    str_2 = 'error_messages'

# Generated at 2022-06-24 20:18:16.594509
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = {}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = {}
    validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:18:24.505930
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arguments_spec = {"state": {"required": True, "type": "str", "choices": ["present", "absent"], "default": "present"}}

    # Test with valid parameters
    parameters = {"state": "present"}
    validator = ArgumentSpecValidator(arguments_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert not result.error_messages
    assert result.validated_parameters == parameters


# Generated at 2022-06-24 20:18:32.131818
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:18:45.149183
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args_0 = {}

# Generated at 2022-06-24 20:18:52.419480
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:18:53.290304
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True



# Generated at 2022-06-24 20:19:01.613809
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = {
        'name': 'test',
        'age': 'test',
    }
    args = [
        'name',
        'age',
    ]
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(spec)
    result = validator.validate(params, args[0], args[1])

    if 'age' not in result.validated_parameters:
        assert 'age' in result.error_messages

# Generated at 2022-06-24 20:19:16.130233
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # ensures that validate method of ModuleArgumentSpecValidator class can be called
    # ensures that validate method of ArgumentSpecValidator class can be called
    options = [
        (['arg_spec', 'params'], {'testcase': 'test case 0'}),
    ]
    for opts in options:
        validate_params = {
            'arg_spec': {},
            'params': {},
        }
        for i, k in enumerate(opts[0]):
            validate_params[k] = opts[1][i]
        obj = ModuleArgumentSpecValidator(**validate_params['arg_spec'])
        result = obj.validate(validate_params['params'])
        assert result is not None


# Generated at 2022-06-24 20:19:26.070260
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    a_0 = {'_options': {'no_log': False}}
    mutually_exclusive_0 = None
    a_1 = 'set_environment'
    required_if_0 = None
    mutually_exclusive_1 = None
    a_2 = 'engine'
    a_3 = {'_options': {'no_log': False}}
    mutually_exclusive_2 = None
    a_4 = {'_options': {'no_log': False}}
    mutually_exclusive_3 = None
    a_5 = 'set_environment'
    mutually_exclusive_4 = ['set_fact', 'set_stats', 'set_stats_complex', 'set_environment', 'delete_lines_before', 'delete_lines_after', 'delete_lines_before_match', 'delete_lines_after_match']
    a_6

# Generated at 2022-06-24 20:19:32.007085
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # No test case
    # test_case_0 is skipped
    # test_case_1 is skipped
    # test_case_2 is skipped
    # test_case_3 is skipped
    # test_case_4 is skipped
    # test_case_5 is skipped
    # test_case_6 is skipped
    # test_case_7 is skipped
    # test_case_8 is skipped
    # test_case_9 is skipped
    # test_case_10 is skipped
    # test_case_11 is skipped
    # test_case_12 is skipped
    # test_case_13 is skipped
    # test_case_14 is skipped
    # test_case_15 is skipped
    pass


# Generated at 2022-06-24 20:19:34.450336
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Variables
    int_0 = 490
    validation_result_0 = ValidationResult(int_0)

    # SETUP
    subject = ModuleArgumentSpecValidator()

    # TEST
    assert subject.validate(int_0, validation_result_0) == validation_result_0


# Generated at 2022-06-24 20:19:37.666520
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    int_0 = 3150
    validation_result_0 = module_argument_spec_validator_0.validate(int_0)


# Generated at 2022-06-24 20:19:40.706225
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Assert of equals (false is not true)
    assert False == ModuleArgumentSpecValidator.validate('')

# Generated at 2022-06-24 20:19:44.939611
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:19:50.918475
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    assert validation_result_0.validated_parameters == 3150

# Generated at 2022-06-24 20:20:01.854294
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_3 = {
    'type': 'str',
    'required': True,
    'fallback': (str, ['name']),
    'aliases': ['cmd'],
    }
    int_4 = {
    'type': 'str',
    'required': True,
    'fallback': (str, ['cmd']),
    'aliases': ['name'],
    }
    int_0 = {
    'name': int_3,
    'cmd': int_4,
    }
    int_5 = {
    'cmd': 'cat ~/.ssh/id_rsa.pub',
    'name': 'cat',
    }
    int_6 = {
    'cmd': 'cat ~/.ssh/id_rsa.pub',
    'name': 'cat',
    }

# Generated at 2022-06-24 20:20:04.753976
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    test_instance_0 = ArgumentSpecValidator(int_0)
    test_instance_0.validate(int_0)


# Generated at 2022-06-24 20:20:27.075763
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    param_0 = {
        'awesome': set(),
        'legal_inputs': {
            'age': {
                'default': 42,
                'type': int,
                'aliases': ['years_old'],
                'required': True,
                'choices': [12, 17, 18, 21, 42],
            },
            'name': {
                'default': 'bob',
                'required': True,
                'no_log': False,
                'choices': ['bob', 'alice'],
                'type': 'str',
            }
        },
        'errors': AnsibleValidationErrorMultiple(),
        'validated_parameters': {
            'age': 42,
            'name': 'bob',
        },
    }

    int_0 = 3150
    ModuleArgument

# Generated at 2022-06-24 20:20:37.349163
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 7195
    bool_0 = True
    bool_1 = True
    int_1 = -15271
    list_0 = []
    list_1 = []
    list_2 = []
    bool_2 = False
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    list_7 = []
    list_8 = []
    list_9 = []
    list_10 = []
    list_11 = []
    list_12 = []
    list_13 = []
    list_14 = []
    list_15 = []
    list_16 = []
    list_17 = []
    list_18 = []
    list_19 = []
    list_20 = []
    list_21 = []
    list_22 = []


# Generated at 2022-06-24 20:20:46.681812
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    """Unit test for method validate of class ModuleArgumentSpecValidator."""

    # Explicitly name p0.p1 and p0.p2 as mutually exclusive even though this is
    # technically implied by the mutually exclusive list. This is to make sure
    # the explicit check does not cause any problems.

# Generated at 2022-06-24 20:20:53.625054
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    type_0 = type(None)
    int_0 = 3150
    str_0 = str()
    int_1 = 3150
    argument_spec_validator_0 = ArgumentSpecValidator(int_0, int_1)
    int_2 = 3150
    validation_result_0 = argument_spec_validator_0.validate(int_2)
    assert not hasattr(validation_result_0.errors, "message")
    assert (validation_result_0.validated_parameters, 3150)
    assert validation_result_0.error_messages == []
    assert validation_result_0._no_log_values == set()
    assert validation_result_0._unsupported_parameters == set()



# Generated at 2022-06-24 20:20:55.672668
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    result = ArgumentSpecValidator.validate(validation_result_0)


# Generated at 2022-06-24 20:20:57.228885
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    testing = False
    if testing:
        int_0 = 3150
        validation_result_0 = ValidationResult(int_0)

        assert 0 == 0



# Generated at 2022-06-24 20:21:07.252718
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec_0 = dict(
        lookup_plugin=dict(
            default=None,
            required=None,
            type='str'
        )
    )

    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_0,
        mutually_exclusive=mutually_exclusive_0,
        required_together=required_together_0,
        required_one_of=required_one_of_0,
        required_if=required_if_0,
        required_by=required_by_0
        )

    parameters_0 = dict(
        lookup_plugin=None
    )

# Generated at 2022-06-24 20:21:12.089270
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validation_result_0 = test_case_0()
    assert validation_result_0.validated_parameters == 3150
    assert validation_result_0._unsupported_parameters == set()
    assert validation_result_0._validated_parameters == 3150
    assert validation_result_0._deprecations == []
    assert validation_result_0._warnings == []
    assert validation_result_0.errors == AnsibleValidationErrorMultiple()
    assert validation_result_0.error_messages == []


# Generated at 2022-06-24 20:21:16.867428
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    args = [
        {'arg': 'name', 'type': 'str'},
        {'arg': 'age', 'type': 'int'},
    ]
    params = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(args)
    result = validator.validate(params)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}, 'Received invalid result'
    assert not result.warnings, 'Received unexpected warnings'
    assert not result.deprecations, 'Received unexpected deprecations'
    assert not result.errors, 'Received unexpected errors'

# Generated at 2022-06-24 20:21:21.105176
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Trac 2 -
    print("test_ModuleArgumentSpecValidator_validate")
    validation_result_0 = ValidationResult(int())


# Generated at 2022-06-24 20:21:54.394086
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    supported_check_mode = True
    include_diff = False
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    mutually_exclusive_groups = []
    required_if_extra_condition = None
    argument_spec = {}

    argument_spec_validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None, )
    int_0 = 3150
    validation_result_0 = argument_spec_validator.validate(int_0)

# Generated at 2022-06-24 20:22:02.600049
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        'username': {'type': 'str'},
        'password': {'type': 'str', 'no_log': True},
        'verify': {'type': 'bool'},
        'force': {'type': 'bool', 'default': False},
    }

    parameters = {
        'username': 'Zaphod Beeblebrox',
        'password': '42',
        'verify': 'true',
        'force': 'false',
    }

    validator = ArgumentSpecValidator(spec)

    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'username': 'Zaphod Beeblebrox', 'password': '42', 'verify': True, 'force': False}


# Unit test

# Generated at 2022-06-24 20:22:12.730675
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    bool_0 = bool()
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_0 = bool(int_0)
    bool_1 = bool()
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)
    bool_1 = bool(int_0)

# Generated at 2022-06-24 20:22:14.297947
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)


# Generated at 2022-06-24 20:22:22.138447
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    validation_result_0 = ValidationResult(int_0)
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec=validation_result_0)
    str_0 = "X@e"
    validation_result_1 = ValidationResult(str_0)
    validation_result_2 = argument_spec_validator_0.validate(parameters=validation_result_1, *[validation_result_0], **{"validation": validation_result_0})
    assert (validation_result_2.validated_parameters == validation_result_1.validated_parameters)
    assert (validation_result_2.unsupported_parameters == validation_result_1.unsupported_parameters)

# Generated at 2022-06-24 20:22:30.157975
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(
        argument_spec=argument_spec_0,
        mutually_exclusive=mutually_exclusive_0,
        required_together=required_together_0,
        required_one_of=required_one_of_0,
        required_if=required_if_0,
        required_by=required_by_0
    )

    # Setup fixture
    parameters_0 = 3150

    # Call method to test

# Generated at 2022-06-24 20:22:38.463833
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    dict_0 = {}
    dict_1 = {}
    dict_1['source'] = dict_0
    dict_1['dest'] = dict_0
    dict_1['name'] = dict_0
    dict_1['state'] = dict_0
    dict_1['force'] = dict_0
    dict_1['follow'] = dict_0
    dict_1['get_checksum'] = dict_0
    dict_1['other_checksum'] = dict_0
    dict_1['checksum'] = dict_0
    dict_1['copy'] = dict_0
    dict_1['backup'] = dict_0
    dict_1['content'] = dict_0
    dict_1['regexp'] = dict_0
    dict_1['delimiter'] = dict

# Generated at 2022-06-24 20:22:47.167311
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 3150
    argument_spec_dict_0 = {'z': {'type': 'int'}, 'm': {'type': 'int'}, 'f': {'type': 'int', 'aliases': ['o', 'g']}, 'j': {'type': 'int', 'aliases': ['y', 'i', 'q']}, 'a': {'type': 'int', 'aliases': ['n', 's', 'h']}, 'v': {'type': 'int', 'aliases': ['p']}, 'k': {'type': 'int', 'aliases': ['t', 'l', 'e']}, 'u': {'type': 'int', 'aliases': ['x', 'w', 'b']}}
    mutually_exclusive_list1_0 = []
    required_together_list1_0 = []

# Generated at 2022-06-24 20:22:48.876376
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    int_1 = 3150
    validation_result_1 = ValidationResult(int_1)
    assert isinstance(validation_result_1, ValidationResult)


# Generated at 2022-06-24 20:22:54.713030
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # This call form is only valid for module_utils
    # Validate the parameters
    parameters = {
        'string_0': 'string_1',
        'list_0': ['list_item_0', 'list_item_1']
    }
    argument_spec = {
        'string_0': {'type': 'str'},
        'list_0': {'type': 'list'},
        'dict_0': {'type': 'dict', 'required': True}
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None