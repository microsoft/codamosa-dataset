

# Generated at 2022-06-24 20:15:04.812181
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = dict()
    required_together_0 = dict()
    required_one_of_0 = dict()
    required_if_0 = dict()
    required_by_0 = dict()
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = dict()
    result = argument_spec_validator_0.validate(parameters_0)
    assert result.error_messages == []


# Generated at 2022-06-24 20:15:08.181735
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # test_case_0
    result_0 = module_argument_spec_validator_0.validate({})

    assert result_0.validated_parameters == {}


# Generated at 2022-06-24 20:15:14.733641
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {
        'argument_spec': {
            'argument': {
                'type': 'str'
            },
            'required': 'boolean'
        },
        'mutually_exclusive': 'mutually_exclusive',
        'required_if': 'required_if',
        'required_one_of': 'required_one_of',
        'required_together': 'required_together',
        'required_by': 'required_by'
    }
    parameters_0 = {
        'argument': 'str'
    }
    assert ArgumentSpecValidator.validate(argument_spec_0, parameters_0)



# Generated at 2022-06-24 20:15:17.170243
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}

    result = module_argument_spec_validator_0.validate(parameters_0)
    print(result.validated_parameters)
    print(result.error_messages)


# Generated at 2022-06-24 20:15:18.272754
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:15:23.851470
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:15:33.582908
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Call the method validate with mandatory parameters
    result = module_argument_spec_validator_0.validate("")
    # Validate the function result
    assert validate_function_result(result) == Passed

    # Call the method validate with mandatory parameters
    result = module_argument_spec_validator_0.validate("")
    # Validate the function result
    assert validate_function_result(result) == Passed

    # Call the method validate with mandatory parameters
    result = module_argument_spec_validator_0.validate("")
    # Validate the function result
    assert validate_function_result(result) == Passed

    # Call the method validate with mandatory parameters
    result = module_argument_spec_validator_0.validate("")


# Generated at 2022-06-24 20:15:44.055013
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Test with a valid argument spec and parameters
    argument_spec_0 = {
        'a': {'type':'str'},
        'b': {'type':'int'},
        'c': {'type':'list', 'elements':'str', 'required':True},
        'd': {'type':'dict', 'options':{'d_key_0':{'type':'str'}, 'd_key_1':{'type':'str'}}, 'required':True},
        'e': {'type':'bool', 'default':True},
        'f': {'type':'bool', 'default':False}
    }

# Generated at 2022-06-24 20:15:49.662222
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    module_argument_spec_validator_0.validate(parameters_0)
    parameters_1 = dict()
    module_argument_spec_validator_0.validate(parameters_1)


# Generated at 2022-06-24 20:15:51.296272
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Constructor for class ArgumentSpecValidator
    argument_spec_validator_0 = ArgumentSpecValidator()


# Generated at 2022-06-24 20:16:08.849615
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    validated_parameters_0 = {
    }
    result_0 = module_argument_spec_validator_0.validate(validated_parameters_0)

# Generated at 2022-06-24 20:16:12.854831
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test = {}
    parameters = test
    result = module_argument_spec_validator_0.validate(parameters)
    assert (result.error_messages == []) and (result.validated_parameters == {}) and (result.unsupported_parameters == set())

# Generated at 2022-06-24 20:16:16.747994
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate("key1", "key2")
    # Test
    try:
        assert "key1" == result
    except AssertionError as e:
        print("Test fail, an error occurred: " + str(e))

test_case_0()

# Generated at 2022-06-24 20:16:20.167606
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult), "Function returned unexpected type. Found: " + str(type(result))


# Generated at 2022-06-24 20:16:26.788362
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'dest': {'type': 'path'},
        'src': {'type': 'path'},
        'symlink': {'type': 'bool', 'default': True},
    }
    mutually_exclusive = [
        ['dest', 'src'],
    ]
    required_together = [
        ['dest', 'symlink'],
    ]
    required_one_of = [
        ['dest', 'src'],
    ]
    required_if = [
        ['dest', 'foo', ['symlink']],
    ]
    required_by = {
        'dest': ['symlink'],
    }


# Generated at 2022-06-24 20:16:30.705119
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate()


# Generated at 2022-06-24 20:16:38.151765
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {'a': {'type': 'str'}, 'b': {'type': 'int'}}
    mutually_exclusive_0 = []
    required_together_0 = []
    required_one_of_0 = []
    required_if_0 = []
    required_by_0 = {}

    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)
    parameters_0 = {'a': 'A', 'b': 42}
    ret_val_0 = argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:16:46.408041
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'type': {'arg': {'subarg': {'subsubarg': {}}, 'subarg2': {}}, 'arg2': {'subarg': {}}, 'arg3': {}, 'arg4': {'subarg': {}}}}
    mutually_exclusive = ['arg', 'arg2']
    required_together = ['arg', 'arg2']
    required_one_of = ['arg', 'arg2']
    required_if = ['arg2', 'arg2', 'arg', 'arg2', 'subsubarg']
    required_by = {'arg4': ['subarg']}

    parameters = {'type': {'arg': {'subarg': {'subsubarg': 'arg4'}, 'subarg4': {'subsubarg': 'arg4'}}}}
    validator = ArgumentSpecValidator

# Generated at 2022-06-24 20:16:51.252635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    input_mock = mock.Mock()
    output_mock = mock.Mock()
    instance = ModuleArgumentSpecValidator()
    output_mock.validate.return_value = output_mock
    output_mock.validate = input_mock

    returned = instance.validate(input_mock)

    returned == output_mock.validate
    output_mock.validate.assert_called_once_with(input_mock)

# Generated at 2022-06-24 20:16:58.478644
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test with argument type is invalid
    with pytest.raises(TypeError) as excinfo:
        ModuleArgumentSpecValidator()
    assert 'argument_spec is not a dict' in str(excinfo.value)

    # Test with parameters type is invalid
    with pytest.raises(TypeError) as excinfo:
        ModuleArgumentSpecValidator({'test': {'type': 'str'}})
    assert 'parameters must be a dict' in str(excinfo.value)

    # Test with parameters type is valid
    with pytest.raises(TypeError) as excinfo:
        ModuleArgumentSpecValidator({'test': {'type': 'str'}})
    assert 'parameters must be a dict' in str(excinfo.value)

# Generated at 2022-06-24 20:17:06.526183
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate({'name': 'bo'})
    assert (result.validated_parameters == {'name': 'bo'})


# Generated at 2022-06-24 20:17:09.986513
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = module_argument_spec_validator_0.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-24 20:17:20.384624
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    param_0 = dict()
    param_0['name'] = 'bo'
    param_0['age'] = '42'
    param_0['legal_inputs'] = set()
    param_0['supports_check_mode'] = False
    param_0['argument_spec'] = dict()
    param_0['argument_spec']['name'] = dict()
    param_0['argument_spec']['name']['type'] = 'str'
    param_0['argument_spec']['age'] = dict()
    param_0['argument_spec']['age']['type'] = 'int'
    param_0['argument_spec']['validated_parameters'] = dict()

# Generated at 2022-06-24 20:17:22.095772
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # First build the validator
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:27.003323
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate(parameters)


test_case_0()

# Generated at 2022-06-24 20:17:29.997008
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test without arguments
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    try:
        module_argument_spec_validator_0.validate(None)
    except Exception as e:
        assert False, "unexpected exception {0}".format(to_native(e))


# Generated at 2022-06-24 20:17:33.941645
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator().validate(None)
    validate_type_0 = result.validated_parameters
    assert isinstance(validate_type_0, dict)


# Generated at 2022-06-24 20:17:42.178497
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters=None)
    assert(result is not None)
    assert not result.errors
    assert not result.error_messages
    assert not result._deprecations
    assert not result._no_log_values
    assert not result._unsupported_parameters
    assert not result._validated_parameters
    assert not result._warnings
    assert set(result.validated_parameters) == set()


# Generated at 2022-06-24 20:17:49.428458
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert not result_0.errors
    assert not result_0._deprecations
    assert not result_0._warnings
    assert not result_0._no_log_values
    assert not result_0._unsupported_parameters
    assert result_0._validated_parameters == parameters_0

# Generated at 2022-06-24 20:17:51.700184
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)


# Generated at 2022-06-24 20:18:05.565834
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # calling validate method with positional arguments
    result = ModuleArgumentSpecValidator.validate(module_argument_spec_validator_0, parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:18:07.099638
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
# end of test_ArgumentSpecValidator_validate


# Generated at 2022-06-24 20:18:09.321463
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()

    module_argument_spec_validator_0.validate(dict_1)

    module_argument_spec_validator_0.validate(dict_2)

    module_argument_spec_validator_0.validate(dict_3)



# Generated at 2022-06-24 20:18:11.903574
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Prepare input arguments
    parameters = {}

    # Run method
    result = ArgumentSpecValidator.validate(parameters)

    # Check for positive result
    assert (result)


# Generated at 2022-06-24 20:18:18.546616
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Code that exercises validate to ensure that it is working properly.
    """
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Testing with a valid value for the required named parameter parameters.

# Generated at 2022-06-24 20:18:24.001283
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    actual_result = module_argument_spec_validator.validate(parameters)
    expected_result = {}
    assert actual_result == expected_result


# Generated at 2022-06-24 20:18:33.341735
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # The argument spec and parameters to validate
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Create a validator using the arguments spec
    validator = ArgumentSpecValidator(argument_spec)

    # Validate the parameters
    result = validator.validate(parameters)

    # Make sure there were no errors
    assert not result.error_messages, "Validation failed: {0}".format(", ".join(result.error_messages))

    # Check the validated parameters

# Generated at 2022-06-24 20:18:37.242729
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert_variable_types(module_argument_spec_validator_0, [
        ('_mutually_exclusive', str),
        ('_required_together', str),
        ('_required_one_of', str),
        ('_required_if', str),
        ('_required_by', str),
        ('_valid_parameter_names', str),
        ('argument_spec', dict)
    ])


# Generated at 2022-06-24 20:18:40.308644
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = { }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result == None

# Generated at 2022-06-24 20:18:42.492105
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    assert False is False


# Generated at 2022-06-24 20:18:55.086635
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    assert True == module_argument_spec_validator_0.validate(parameters).errors.success


# Generated at 2022-06-24 20:18:59.617866
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Case 1 - parameters is not a dict
    # It will throw an exception for the Method validation.
    try:
        parameters = ModuleArgumentSpecValidator.validate(0)
    except Exception:
        parameters = None
        assert parameters is None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:19:03.491920
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Unit test for method validate of class ModuleArgumentSpecValidator """

    # Constructor test
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Call method validate of class ModuleArgumentSpecValidator with argument(s)
    result = module_argument_spec_validator_0.validate(parameters)
    assert result is None



# Generated at 2022-06-24 20:19:08.264868
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result_1 = module_argument_spec_validator_1.validate(parameters)


# Generated at 2022-06-24 20:19:11.091028
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create an instance of ArgumentSpecValidator
    instance = ArgumentSpecValidator()
    # Create a dictionary of arguments to pass to the method validate
    parameters = {}
    instance.validate(parameters)



# Generated at 2022-06-24 20:19:15.915522
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = module_argument_spec_validator_0.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-24 20:19:22.425826
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'},
                                                                                   'age': {'type': 'int'}},
                                                                   mutually_exclusive=None,
                                                                   required_together=None,
                                                                   required_one_of=None,
                                                                   required_if=None,
                                                                   required_by=None)
    # TODO: import test data in test case

    parameters = {'age': 42,
                  'name': 'bo'}
    module_argument_spec_validator_1.validate(parameters)

# Generated at 2022-06-24 20:19:24.988216
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    
    # Test with empty argument spec
    assert module_argument_spec_validator_0.validate({})


# Generated at 2022-06-24 20:19:31.328801
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json
    import ansible.module_utils.common.arg_spec

    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Test with valid parameters
    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ansible.module_utils.common.arg_spec.ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})

    result = validator.validate(parameters)

    # Verify that there are no validation errors
    assert result.error_messages == []
    # Verify that validated parameters are as expected
    assert result.validated_parameters == parameters
    # Verify that there are no unsupported parameters
    assert result

# Generated at 2022-06-24 20:19:37.499276
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    try:
        parameters = [{}]
        
        module_argument_spec_validator_1.validate(parameters)
        assert True
    except Exception as e:
        assert False
    return True

# Generated at 2022-06-24 20:20:03.414898
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters={})
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert isinstance(result.error_messages, list)


# Generated at 2022-06-24 20:20:04.797288
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:20:10.402821
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Declare the parameters and results of the testcase
    validator = None
    parameters = None
    expected_result = None
    expected_result_errors = None
    expected_result_unsupported_parameters = None
    expected_result_deprecations = None
    expected_result_warnings = None
    expected_result_error_messages = None

    result = None


# Generated at 2022-06-24 20:20:16.363926
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ValidationResult

    # Case 0: a legal parameter should be validated successfully
    module_argument_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    result = module_argument_spec_validator.validate({'name': 'value'})
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {'name': 'value'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()

    # Case 1: an illegal parameter should be validated unsuccessfully
    result = module_argument_spec_validator.validate({'unknown': 'value'})
    assert result.validated_

# Generated at 2022-06-24 20:20:24.040417
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = None
    assert argument_spec is None
    mutually_exclusive = None
    assert mutually_exclusive is None
    required_together = None
    assert required_together is None
    required_one_of = None
    assert required_one_of is None
    required_if = None
    assert required_if is None
    required_by = None
    assert required_by is None
    test_instance = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert test_instance._mutually_exclusive is None
    assert test_instance._required_together is None
    assert test_instance._required_one_of is None
    assert test_instance._required_if is None
    assert test_instance._required_by is None
    assert test_instance

# Generated at 2022-06-24 20:20:26.289737
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator = ModuleArgumentSpecValidator()
    module_argument_spec_validator.validate()

# Generated at 2022-06-24 20:20:32.442499
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    assert module_argument_spec_validator_0.validate(parameters_0).validated_parameters == {}
    assert module_argument_spec_validator_0.validate(parameters_0).unsupported_parameters == set()
    assert module_argument_spec_validator_0.validate(parameters_0).error_messages == []


# Generated at 2022-06-24 20:20:33.980708
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    expected = ValidationResult({})
    actual = module_argument_spec_validator_0.validate({})
    assert actual == expected


# Generated at 2022-06-24 20:20:42.705231
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    modules_args_spec = {
        'ansible_host': {'type': 'str', 'aliases': ['ansible_host']},
        'host_name': {'type': 'str', 'choices': [
            'host_name_a', 'host_name_b', 'host_name_c']},
        'host_port': {'type': 'int'},
        'host_state': {'type': 'str', 'choices': [
            'present', 'absent']},
        'users': {'type': 'list', 'elements': 'dict', 'options': {
            'name': {'type': 'str'},
            'state': {'type': 'str', 'choices': ['present', 'absent']},
            'uid': {'type': 'int'}}}}


# Generated at 2022-06-24 20:20:45.838122
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate("name") == "name"

# Generated at 2022-06-24 20:21:04.313191
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate(parameters=dict())


# Generated at 2022-06-24 20:21:08.442404
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit tests for method validate of class ModuleArgumentSpecValidator"""
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert not module_argument_spec_validator_0.validate({})


# Generated at 2022-06-24 20:21:11.644678
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:21:15.853650
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {"parameters": {"name": "bo", "age": 42}}
    expected = {"validated_parameters": {"name": "bo", "age": 42}, "error_messages": []}

    # Exercise
    result = module_argument_spec_validator.validate(parameters)

    # Verify
    assert result.validated_parameters == expected["validated_parameters"]
    assert result.error_messages == expected["error_messages"]



# Generated at 2022-06-24 20:21:21.319670
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {"type": "dict"}
    result = module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:21:26.212242
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    sut = ArgumentSpecValidator()
    arguments = {'one': {'required': True}}

    # Run test
    # Test exception case
    try:
        sut.validate(arguments)
        raise Exception("Excpected error was not raised")
    except RequiredError as e:
        assert(e.to_native() == "Missing required arguments: 'one'")
    except Exception as e:
        raise Exception("Unexpected exception raised:", e)



# Generated at 2022-06-24 20:21:27.593864
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    # x = ArgumentSpecValidator().validate()
    pass


# Generated at 2022-06-24 20:21:31.396643
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: Test case description
    module_argument_spec_validator_0_params = {}
    module_argument_spec_validator_0_expected_result = ""
    module_argument_spec_validator_0_result = module_argument_spec_validator_0.validate(module_argument_spec_validator_0_params)
    assert module_argument_spec_validator_0_result == module_argument_spec_validator_0_expected_result

# Generated at 2022-06-24 20:21:41.386734
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [["name", "age"]]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec)

    argument_spec_validator_1 = ArgumentSpecValidator(argument_spec, mutually_exclusive)

    argument_spec_validator_2 = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together)

    argument_spec_validator_3 = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of)


# Generated at 2022-06-24 20:21:47.283932
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Validate a dict against the argument_spec spec.
    
    
    
    
    Returns:
        A ValidationResult containing the validated parameters.
    """
    
    results = dict()
    
    name_result = dict()
    name_result['name'] = dict()
    name_result['name']['type'] = 'str'
    results['name'] = name_result
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return results


# Generated at 2022-06-24 20:22:20.093874
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate(parameters={})
    assert(result_0 is None)



# Generated at 2022-06-24 20:22:20.508284
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:22:24.031330
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate with faked resources."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if not result.errors:
        valid_params = result.validated_parameters


# Generated at 2022-06-24 20:22:26.610581
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_validate = ModuleArgumentSpecValidator()

    with pytest.raises(AttributeError):
        module_argument_spec_validator_validate.validate()


# Generated at 2022-06-24 20:22:31.417018
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_0 = dict(
        age=dict(type='int', required=True),
        name=dict(type='str'),
        sex=dict(type='str', required=True),
    )

    arguments_0 = dict(
        age=42,
        sex='male',
    )

    validator = ArgumentSpecValidator(argument_spec_0)
    validator.validate(arguments_0)

    assert validator.validated_parameters == arguments_0


# Generated at 2022-06-24 20:22:34.779063
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    try:
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    except TypeError:
        ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:22:45.760026
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Function for testing validate of class ArgumentSpecValidator
    """
    check_required_arguments_0 = check_required_arguments
    check_mutually_exclusive_0 = check_mutually_exclusive
    _validate_sub_spec_0 = _validate_sub_spec
    _list_no_log_values_0 = _list_no_log_values
    _set_defaults_0 = _set_defaults
    _handle_aliases_0 = _handle_aliases
    _get_legal_inputs_0 = _get_legal_inputs
    _validate_argument_types_0 = _validate_argument_types
    _validate_argument_values_0 = _validate_argument_values
    argument_spec_0 = ArgumentSpecValidator()

# Generated at 2022-06-24 20:22:47.131314
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:22:57.962462
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.parameters import sanitize_keys

    argument_spec_validator_0 = ArgumentSpecValidator(dict())
    result_0 = argument_spec_validator_0.validate(dict())
    assert result_0.validated_parameters == dict()
    assert result_0.error_messages == []

    argument_spec_validator_1 = ArgumentSpecValidator(dict(type='str'))
    result_1 = argument_spec_validator_1.validate(dict())
    assert result_1.validated_parameters == dict()
    assert result_1.error_messages == []

    argument_spec_validator_2 = ArgumentSpecValidator(dict(type='str'))

# Generated at 2022-06-24 20:23:05.097751
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator, ModuleArgumentSpecValidator)

    error_msg = 'Expected "args" to be an instance of ArgumentSpecValidator'
    with pytest.raises(TypeError, match=error_msg):
        module_argument_spec_validator.validate('args')


# Generated at 2022-06-24 20:23:28.460922
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True == True

# Generated at 2022-06-24 20:23:39.871132
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = dict()
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = (list(),)
    required_if_0 = (list(),)
    required_by_0 = None
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_0,
                                                                   mutually_exclusive_0,
                                                                   required_together_0,
                                                                   required_one_of_0,
                                                                   required_if_0,
                                                                   required_by_0,
                                                                   )

    parameters_0 = dict()
    args_0 = dict()
    kwargs_0 = dict()


# Generated at 2022-06-24 20:23:49.968652
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Default values for arguments, if any
    # Argument 1: argument_spec
    argument_spec_0 = {}

    # Argument 2: mutually_exclusive
    mutually_exclusive_0 = None

    # Argument 3: required_together
    required_together_0 = None

    # Argument 4: required_one_of
    required_one_of_0 = None

    # Argument 5: required_if
    required_if_0 = None

    # Argument 6: required_by
    required_by_0 = None

    # Instance of class ArgumentSpecValidator initialized using the default constructor (no arguments)
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0,
                                                      required_one_of_0, required_if_0, required_by_0)

# Generated at 2022-06-24 20:23:51.246166
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:23:55.488497
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    mock_result = ArgumentSpecValidator(argument_spec).validate(parameters)
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec)
    result = module_argument_spec_validator_0.validate(parameters)
    assert result == mock_result

# Generated at 2022-06-24 20:23:58.647068
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:24:03.958160
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    # Validate the parameters
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    # validate return type
    assert isinstance(result_0, ValidationResult)


test_case_0()

# Generated at 2022-06-24 20:24:05.011017
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:24:14.307509
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters={'a': {'type': 'str', 'required': True}, 'b': {'type': 'str', 'required': True}}

    # Should raise AnsibleValidationError:
    try:
        module_argument_spec_validator_1.validate({'a': {'type': 'str', 'required': True}})
    except Exception as e:
        print(e)

    # Should raise NoLogError:
    try:
        module_argument_spec_validator_1.validate({'a': 'b', 'b': {'no_log': True}})
    except Exception as e:
        print(e)

    # Should raise AliasError:

# Generated at 2022-06-24 20:24:22.327017
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Tests :meth:`ArgumentSpecValidator.validate()`
    """
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters_0 = {'age': '42', 'name': 'bo'}
    argument_spec_0 = {'age': {'type': 'int'}, 'name': {'type': 'str'}}

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec_0)

    validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)

    assert validation_result_0.validated_parameters == {'name': 'bo', 'age': 42}
    assert validation_result_0.unsupported_parameters == set()
    assert validation_result_0