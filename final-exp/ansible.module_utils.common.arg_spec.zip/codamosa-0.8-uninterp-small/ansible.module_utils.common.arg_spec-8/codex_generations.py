

# Generated at 2022-06-24 20:14:59.105732
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    int_0 = 196
    str_0 = 'l("XOc%.scP'
    validation_result_0 = ValidationResult(str_0)
    parameters = validation_result_0.validated_parameters
    int_1 = 196
    assert isinstance(validation_result_0, ValidationResult)
    assert isinstance(parameters, dict)


# Generated at 2022-06-24 20:15:09.377298
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    str_0 = 'Y"~I\x0b$ n.\x05\n'
    validation_result_0 = ValidationResult(str_0)
    validation_result_1 = ValidationResult(validation_result_0)
    validation_result_2 = ValidationResult(validation_result_1)
    validation_result_i = validation_result_2
    validation_result_3 = ValidationResult(validation_result_i)
    validation_result_4 = ValidationResult(validation_result_3)
    validation_result_5 = ValidationResult(validation_result_4)
    validation_result_6 = ValidationResult(validation_result_5)
    validation_result_7 = ValidationResult(validation_result_6)

# Generated at 2022-06-24 20:15:16.984606
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:15:25.073254
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:15:30.320618
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # input parameters
    parameters_0 = 'K("6TqTzZ1'
    parameters_1 = 'l("XOc%.scP'
    # object instance created for testing
    obj = ModuleArgumentSpecValidator(parameters_0, parameters_1)
    # test passed
    assert validator.validate(parameters_0, parameters_1) == True


# Generated at 2022-06-24 20:15:34.509069
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = ["Uc%QW6mhM)YmXn`"  ]
    with pytest.raises(AnsibleValidationErrorMultiple) as excinfo:
        ArgumentSpecValidator.validate(*args)
    assert '`[`}5`y-JtS>FbAb' in str(excinfo.value)


# Generated at 2022-06-24 20:15:44.278999
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert callable(ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(dict(a=dict(type='str'))), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(dict(a=dict(type='str')),
                                            mutually_exclusive=[]), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(dict(a=dict(type='str')),
                                            mutually_exclusive=[]), ArgumentSpecValidator)
    assert isinstance(ArgumentSpecValidator(dict(a=dict(type='str')),
                                            mutually_exclusive=[]), ArgumentSpecValidator)

# Generated at 2022-06-24 20:15:46.260812
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Call function to test
    try:
        test_case_0()
    # Correct TypeError raised, function returns None
    except TypeError as te:
        return None
    # Incorrect TypeError raised, test case fails
    except Exception:
        raise AssertionError('Incorrect Exception raised: {}'.format(te))


# Generated at 2022-06-24 20:15:53.126090
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    str_0 = str()
    str_1 = str('iwsP)%}viQ.CmyebF-LhD_?zT=)y~,>F"N(gN-kXOc%.scP')
    str_2 = str('y~,>F"N(gN-kXOc%.scPiwsP)%}viQ.CmyebF-LhD_?zT=)')

    try:
        ArgumentSpecValidator.validate(str_0, str_1, str_2)
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 20:16:03.024465
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arr = []
    arr.append('')
    argument_spec = {
        'arg_name': {'type': 'str'},
        'arg2_name': {'type': 'str'},
        'arg3_name': {'type': 'str'},
    }

    parameters = {
        'arg_name': arr[0],
        'arg2_name': arr[1],
        'arg3_name': arr[2],
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'arg_name': '', 'arg2_name': '', 'arg3_name': ''}

# Generated at 2022-06-24 20:16:12.288429
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # First, create an instance of a class;
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Now use the instance object in the test...

    try:
        module_argument_spec_validator_0.validate(parameters=({
          "key_1" : "value_1",
          "key_2" : "value_2",
          "key_3" : "value_3",
        }))
    except TypeError:
        pass


# Generated at 2022-06-24 20:16:15.497971
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    result_1 = module_argument_spec_validator_1.validate(parameters_1)


# Generated at 2022-06-24 20:16:23.338097
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    val = ArgumentSpecValidator()
    argumentspec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
    ]
    required_together = [
    ]
    required_one_of = [
    ]
    required_if = [
    ]
    required_by = {
    }
    val.__init__(argumentspec, mutually_exclusive=mutually_exclusive, required_together=required_together, required_one_of=required_one_of, required_if=required_if, required_by=required_by)

    result = val.validate({
        'name': 'bo',
        'age': 42,
    })

# Generated at 2022-06-24 20:16:26.548876
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    module_argument_spec_validator_0.validate(parameters)
    pass

# Generated at 2022-06-24 20:16:33.443634
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"test": "test_data"}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec,
                                    mutually_exclusive,
                                    required_together,
                                    required_one_of,
                                    required_if,
                                    required_by)


# Generated at 2022-06-24 20:16:40.987765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_validate_0 = ModuleArgumentSpecValidator()
    validated_parameters = {}
    result = module_argument_spec_validator_validate_0.validate(validated_parameters)
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-24 20:16:48.101817
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ test_ArgumentSpecValidator_validate
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-24 20:16:54.013387
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create an instance of ValidationResult
    validation_result_instance = ValidationResult()
    # Create an instance of ArgumentSpecValidator
    module_argument_spec_validator_1 = ArgumentSpecValidator()
    # Call method validate of ArgumentSpecValidator instance
    module_argument_spec_validator_1.validate(validation_result_instance)

if __name__ == '__main__':
    test_case_0()
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:16:58.660114
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    # Constructor for class ArgumentSpecValidator
    """
    argumentSpecValidator = ArgumentSpecValidator(argument_spec={'type': 'str'}, mutually_exclusive=['wtf'], required_together=['a', 'b', 'c'], required_one_of=['d', 'e', 'f'], required_if={'g': 'h', 'i': 'j'}, required_by={'k': 'l'})



# Generated at 2022-06-24 20:17:00.584083
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_validate_0 = ArgumentSpecValidator()


# Generated at 2022-06-24 20:17:12.739134
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert '_mutually_exclusive' in dir(ArgumentSpecValidator)
    assert '_required_together' in dir(ArgumentSpecValidator)
    assert '_required_one_of' in dir(ArgumentSpecValidator)
    assert '_required_if' in dir(ArgumentSpecValidator)
    assert '_required_by' in dir(ArgumentSpecValidator)
    assert '_valid_parameter_names' in dir(ArgumentSpecValidator)
    assert 'argument_spec' in dir(ArgumentSpecValidator)


# Generated at 2022-06-24 20:17:14.786630
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:23.181632
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {}
    result = validator.validate(parameters)

    assert result.errors
    assert result.validated_parameters == parameters

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == parameters

    parameters = {
        'name': 'bo',
        'age': '42',
        'unsupported': '42',
    }
    result = validator.validate(parameters)
    assert result.error_mess

# Generated at 2022-06-24 20:17:29.493268
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Verify error message if validation fails
    # Test case 0
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result.error_messages[0].startswith("found type <type 'str'> where an int is required")


# Test cases for validate method

# Generated at 2022-06-24 20:17:41.493761
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0, ModuleArgumentSpecValidator)

    # Test the upperbound of the argument spec
    params = {'path': '/root/my_file', 'state': 'file', 'mode': '777'}
    result = module_argument_spec_validator_0.validate(params)

    assert not result.error_messages

    assert result.validated_parameters['path'] == '/root/my_file'
    assert result.validated_parameters['state'] == 'file'
    assert result.validated_parameters['mode'] == '777'

if __name__ == '__main__':
    # Test for ModuleArgumentSpecValidator.validate()
    test_Module

# Generated at 2022-06-24 20:17:45.857304
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    module_argument_spec_validator = ArgumentSpecValidator()


# Generated at 2022-06-24 20:17:53.525095
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'data': {'type': 'dict'}, 'msg': {'type': 'str'}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    parameters = {'data': {'one': 1, 'two': 2, 'three': 3}, 'msg': 'foo'}
    argument_spec_validator = ArgumentSpecValidator(argument_spec=argument_spec,
                                                    mutually_exclusive=mutually_exclusive,
                                                    required_together=required_together,
                                                    required_one_of=required_one_of,
                                                    required_if=required_if,
                                                    required_by=required_by)

# Generated at 2022-06-24 20:18:04.054148
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Not a valid case, missing positional parameters
    try:
        result = ArgumentSpecValidator.validate()
    except Exception as e:
        if str(e) != "validate() missing 1 required positional argument: 'parameters'":
            raise AssertionError("incorrect error: " + str(e))
    else:
        raise AssertionError("validate() missing 1 required positional argument: 'parameters'")
    # Not a valid case, too many positional parameters
    try:
        result = ArgumentSpecValidator.validate(1, 2)
    except Exception as e:
        if str(e) != "validate() takes 1 positional argument but 2 were given":
            raise AssertionError("incorrect error: " + str(e))

# Generated at 2022-06-24 20:18:07.728371
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
# Call method validate of class ModuleArgumentSpecValidator
    test_ModuleArgumentSpecValidator_validate_0 = module_argument_spec_validator_0.validate(parameters={})
    assert test_ModuleArgumentSpecValidator_validate_0 == None



# Generated at 2022-06-24 20:18:08.379897
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    raise NotImplementedError()

# Generated at 2022-06-24 20:18:13.637169
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:18:21.542574
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_0 = {'param_1': {'type': 'str'}, 'param_2': {'type': 'str'}}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)


# Generated at 2022-06-24 20:18:26.743923
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert result.errors



# Generated at 2022-06-24 20:18:35.371878
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # AnsibleModule arguments:
    # argument_spec
    argument_spec = {
        "age": {"type": "int"},
        "name": {"type": "str"},
    }

    # mutually_exclusive
    mutually_exclusive = None

    # required_together
    required_together = None

    # required_one_of
    required_one_of = None

    # required_if
    required_if = None

    # required_by
    required_by = None

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec,
                                                                   mutually_exclusive,
                                                                   required_together,
                                                                   required_one_of,
                                                                   required_if,
                                                                   required_by)

    # Validate a parameters data structure against the argument_spec

# Generated at 2022-06-24 20:18:40.957779
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Dummy arguments to pass type checking
    arg0 = {}
    arg1 = 'string'
    arg2 = [1, 2, 3, 4]
    arg3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    arg4 = [1, 2, 3, 4, 5, 6]
    arg5 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
    # Make actual call to function (remove this line when done testing)
    try:
        retval = ModuleArgumentSpecValidator.validate(arg0, arg1, arg2, arg3, arg4, arg5)
    except (TypeError, ValueError) as e:
        retval = str(e)
    return retval




# Generated at 2022-06-24 20:18:42.163068
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_1.validate(parameters)

# Generated at 2022-06-24 20:18:48.769478
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    try:
        module_argument_spec_validator_0 = ArgumentSpecValidator()
        parameters_0 = dict()
        module_argument_spec_validator_0.validate(parameters_0)
    except TypeError as exc:
        assert 'module' in str(exc)
    except AssertionError as exc:
        assert 'module' in str(exc)
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    parameters_0 = dict()
    module_argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:18:52.309692
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    module_argument_spec_validator_1.validate(parameters_1)


# Generated at 2022-06-24 20:19:01.011445
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    ValidationResult_0 = module_argument_spec_validator_0.validate(parameters=parameters)
    ValidationResult_0.validated_parameters
    ValidationResult_0.unsupported_parameters
    ValidationResult_0._no_log_values
    ValidationResult_0._deprecations
    ValidationResult_0._warnings
    ValidationResult_0.errors.messages

# Generated at 2022-06-24 20:19:03.206223
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:19:14.714017
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Values to pass to function
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = None

    # Invoke method
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.error_messages, list)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result.unsupported_parameters, set)


# Generated at 2022-06-24 20:19:20.937906
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameter1 = dict()
    test_0 = ArgumentSpecValidator(parameter1)
    parameter1 = dict()
    test_1 = ArgumentSpecValidator(parameter1)
    try:
        test_0.validate(parameter1)
    except:
        assert_true(False)
    try:
        test_1.validate(parameter1)
    except:
        assert_true(False)
    test_2 = ArgumentSpecValidator(parameter1)
    try:
        test_2.validate(parameter1)
    except:
        assert_true(False)


# Generated at 2022-06-24 20:19:29.970421
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create an instance of ArgumentSpecValidator
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0, ArgumentSpecValidator)

    # Create a new validator
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator({'type': 'str', 'required': False}, mutually_exclusive=[['type', 'required']])

    valid_parameters = {
        'type': 'str',
    }

    # Validate valid parameters
    result = module_argument_spec_validator_1.validate(valid_parameters)
    assert result.validated_parameters == valid_parameters

    # Test argument_spec with required=False and no value passed
    # See https://github.com/ansible/ansible/issues

# Generated at 2022-06-24 20:19:37.763505
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test for valid number of arguments
    argument_spec_validator = ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}})
    # Test for invalid number of arguments
    try:
        argument_spec_validator = ArgumentSpecValidator()
    except TypeError:
        pass

# Unit Test for validate

# Generated at 2022-06-24 20:19:39.421640
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:19:42.943930
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate()


# Generated at 2022-06-24 20:19:46.456509
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    parameters = {}
    assert module_argument_spec_validator_0.validate(parameters) != None


# Generated at 2022-06-24 20:19:47.301954
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator = ModuleArgumentSpecValidator({})



# Generated at 2022-06-24 20:19:50.221216
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:20:01.185206
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:20:06.747306
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert callable(ArgumentSpecValidator.validate)



# Generated at 2022-06-24 20:20:12.513033
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    module_argument_spec_validator_0.validate(parameters)



# Generated at 2022-06-24 20:20:14.728509
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''Tests validate of class ArgumentSpecValidator'''

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {'parameters': {}}
    module_argument_spec_validator_0.validate(parameters)
    assert True

# Generated at 2022-06-24 20:20:18.041237
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {}

    parameters_0 = {}

    validation_result_0 = ArgumentSpecValidator(argument_spec_0).validate(parameters_0)

    assert validation_result_0.errors == []



# Generated at 2022-06-24 20:20:20.405484
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    module_argument_spec_validator.validate({})

# Generated at 2022-06-24 20:20:25.719631
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec_0 = dict(argument_spec=dict(),
                  mutually_exclusive=None,
                  required_together=None,
                  required_one_of=None,
                  required_if=None,
                  required_by=None,
                  )
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**spec_0)


# Generated at 2022-06-24 20:20:29.309778
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    param_0 = {'param_0': 'param_0'}
    result_0 = module_argument_spec_validator_0.validate(param_0)

# Test case 2

# Generated at 2022-06-24 20:20:31.551459
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(argument_spec={})
    validator.validate(parameters={})
    return True

# Generated at 2022-06-24 20:20:33.814012
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_validator_0 = ArgumentSpecValidator()
    assert isinstance(argument_spec_validator_0, ArgumentSpecValidator)


# Generated at 2022-06-24 20:20:42.336833
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec0 = {
        'name': {
            'aliases': [
                'item'
            ],
            'type': 'str',
            'required': True
        },
        'age': {
            'aliases': [
                'value'
            ],
            'type': 'int',
            'required': True
        }
    }

    parameters0 = {
        'name': 'bo',
        'age': 42,
        'extra_param': 'value'
    }

    validator0 = ArgumentSpecValidator(arg_spec0)
    result0 = validator0.validate(parameters0)

    assert not result0.errors
    assert result0.validated_parameters == {'age': 42, 'name': 'bo'}

# Generated at 2022-06-24 20:20:48.767678
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert not isinstance(ModuleArgumentSpecValidator().validate({"name": "bo"}), ValidationResult)

# Generated at 2022-06-24 20:20:50.234492
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False, "TODO: Write unit tests for ModuleArgumentSpecValidator.validate()"

# Generated at 2022-06-24 20:20:56.965544
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_0 = {}
    mutually_exclusive_0 = None
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0,
                                                      mutually_exclusive=mutually_exclusive_0,
                                                      required_together=required_together_0,
                                                      required_one_of=required_one_of_0,
                                                      required_if=required_if_0,
                                                      required_by=required_by_0)
    parameters_0 = {}
    args_0 = ()
    kwargs_0 = {}
    # The ArgumentSpecValidator class contains a number of private members
    # which are not accessible, and

# Generated at 2022-06-24 20:20:57.850016
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator()


# Generated at 2022-06-24 20:21:06.623511
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={
        'argument_spec': {'type': 'dict'},
        'mutually_exclusive': {'type': 'list'},
        'required_together': {'type': 'list'},
        'required_one_of': {'type': 'list'},
        'required_if': {'type': 'list'},
        'required_by': {'type': 'dict'}
    })
    parameters = {}
    assert(module_argument_spec_validator_0.validate(parameters) == None)


# Generated at 2022-06-24 20:21:11.537795
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })
    result = validator.validate(parameters)


# Generated at 2022-06-24 20:21:16.315564
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate of ModuleArgumentSpecValidator"""

    # Setup test case
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters_0 = {}
    expect_0 = ValidationResult(parameters_0)

    # Execute
    actual_0 = module_argument_spec_validator_0.validate(parameters_0)

    # Verify
    assert(expect_0.validated_parameters == actual_0.validated_parameters)
    assert(expect_0.no_log_values == actual_0.no_log_values)
    assert(expect_0.unsupported_parameters == actual_0.unsupported_parameters)
    assert(expect_0.error_messages == actual_0.error_messages)


# Generated at 2022-06-24 20:21:24.998908
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initializing Mock object
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters_0 = {"name" : "bo", "age": "42"}
    # Calling Method Under Test
    result = module_argument_spec_validator.validate(parameters_0)
    assert result.validated_parameters == {"name" : "bo", "age": 42}
    # Calling Method Under Test
    result = module_argument_spec_validator.validate(parameters_0)
    assert result.error_messages == []


# Generated at 2022-06-24 20:21:32.406917
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from random import randint
    # Unit tests, with various different parameters and return values

# Generated at 2022-06-24 20:21:43.724275
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters_0_0 = {'item_0': {'item_0': 'value_0', 'item_1': 'value_1'}, 'item_1': {'item_0': 'value_2', 'item_1': 'value_3'}, 'item_2': 'value_4'}
    module_argument_spec_validator_0._mutually_exclusive = [('item_0', 'item_1'), ('item_1', 'item_2')]
    module_argument_spec_validator_0._required_by = {'item_1': ['item_0']}
    module_argument_spec_validator_0._required_if = [['item_1', 'value_1', ['item_2']]]
   

# Generated at 2022-06-24 20:21:53.363145
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = "Invalid example"
    assert module_argument_spec_validator_0.validate(parameters) is None


# Generated at 2022-06-24 20:22:02.329753
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    argument_spec_0 = {
        'age': {
            'default': 42,
            'type': 'int'
        },
        'name': {
            'default': 'bo',
            'type': 'str'
        }
    }
    parameters_0 = {
        'name': [
            'bo'
        ],
        'age': [
            42
        ]
    }
    result = module_argument_spec_validator_0.validate(argument_spec_0, parameters_0)
    print(result)

if __name__ == "__main__":
    test_case_0()
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:22:12.233662
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    not_set = "<not set>"

    validator = ArgumentSpecValidator({})
    result = validator.validate({})

    assert result.error_messages == []
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()

    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'height': {'type': 'float'},
        'awesome': {'type': 'bool'},
        'registered': {'type': 'bool'},
    })

# Generated at 2022-06-24 20:22:17.308362
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = dict(
        argument_spec=dict(
            name=dict(
                required=True,
                type='str')
        ),
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None)
    obj = ArgumentSpecValidator(**args)
    obj.validate(parameters=dict(name='bo'))

# Generated at 2022-06-24 20:22:23.057482
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {'name': 'bo', 'age': '42'}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0._no_log_values == set()
    assert result_0._unsupported_parameters == set()
    assert result_0._validated_parameters == {'name': 'bo', 'age': '42'}
    assert result_0.errors == [
        AliasError('Could not match supplied parameter age with supported parameters')
    ]
    assert result_0.error_messages == ['Could not match supplied parameter age with supported parameters']

# Generated at 2022-06-24 20:22:24.227346
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:22:26.448988
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

test_case_0()
test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:22:33.963951
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = dict(
            state=dict(type='str',
                       required=True),
            name=dict(type='str',
                      required=True),
            key=dict(type='str',
                     aliases=['account_key']),
            secret=dict(type='str',
                        aliases=['account_secret']),
            size=dict(type='int',
                      choices=[3, 6, 9],
                      default=3),
            created=dict(type='str',
                         default=str(datetime.now())),
            )
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(dict(state='present', name='foo', key='bar', secret='baz'))

# Generated at 2022-06-24 20:22:43.044899
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    with pytest.raises(TypeError):
        module_argument_spec_validator_1.validate(parameters=parameters_1)

    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()
    parameters_2 = {'a': 'a'}
    result_2 = module_argument_spec_validator_2.validate(parameters=parameters_2)
    assert result_2.validated_parameters == {'a': 'a'}



# Generated at 2022-06-24 20:22:47.130390
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    data = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator({"name": {"type": "str"}, "age": {"type": "int"}})
    result = validator.validate(data)
    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:23:10.107552
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator, \
        ModuleArgumentSpecValidator

    args_0 = {'required': True, 'type': 'str', 'aliases': ['a']}
    result_0 = ArgumentSpecValidator.validate(self=args_0)
    assert result_0 == True

    args_0 = {'required': True, 'type': 'str', 'aliases': ['a']}
    result_0 = ModuleArgumentSpecValidator.validate(self=args_0)
    assert result_0 == True

# Unit tests for function _handle_aliases

# Generated at 2022-06-24 20:23:12.525668
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    assert module_argument_spec_validator_0.validate(parameters_1) is None


# Generated at 2022-06-24 20:23:21.959431
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    # input parameters
    parameters = {
        'comment:string': '',
        'dest:string': '',
        'force:boolean': '',
        'follow:boolean': '',
        'remote_src:boolean': '',
        'src:string': '',
        'src_type:string': '',
        'unsafe_writes:boolean': '',
    }

# Generated at 2022-06-24 20:23:29.206383
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    class validation_result:
        validated_parameters = 'dict'
        error_messages = 'list'

    validation_result_0 = validation_result()
    assert isinstance(validation_result_0, validation_result)

    parameters_0 = 'dict'

    validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert isinstance(validation_result_0, validation_result)
    assert validation_result_0.validated_parameters == 'dict'
    assert validation_result_0.error_messages == 'list'

# Generated at 2022-06-24 20:23:40.684530
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = {}
    result_1 = module_argument_spec_validator_1.validate(parameters_1)

    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()
    parameters_2 = {}
    result_2 = module_argument_spec_validator_2.validate(parameters_2)

    module_argument_spec_validator_3 = ModuleArgumentSpecValidator()
    parameters_3 = {}
    result_3 = module_argument_spec_validator_3.validate(parameters_3)

    module_argument_spec_validator_4 = ModuleArgumentSpecValidator()
    parameters_4 = {}

# Generated at 2022-06-24 20:23:43.846535
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    error_msg = [
        'Error Message',
        'Failed to import object from the following zipfile'
    ]

    validate_result_0 = {}

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    module_argument_spec_validator_0.validate(validate_result_0)

# Generated at 2022-06-24 20:23:49.284380
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # This test scenario is used to test the case when the following are passed
    # as parameters to validate
    # - argument_spec = {}
    # - parameters = {}

    # test_ArgumentSpecValidator_validate_0
    argument_spec_0 = {}
    parameters_0 = {}
    validator = ArgumentSpecValidator(argument_spec_0)
    result = validator.validate(parameters_0)
    assert isinstance(result, ValidationResult) is True


# Generated at 2022-06-24 20:23:51.150880
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # unit test for calling validate on ModuleArgumentSpecValidator
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:23:53.583235
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    ansible_module_0 = AnsibleModule()
    result = module_argument_spec_validator_0.validate(ansible_module_0)
    assert result == ""


# Generated at 2022-06-24 20:24:05.012537
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    class TestClass:

        def set_module_kwargs_defaults(self, **kwargs):
            return kwargs

        def default_module_options(self):
            return {}

    class ModuleDeprecationWarning(Warning):
        pass

    class AnsibleModule(TestClass):

        def __init__(self, argument_spec, no_log=False, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None, **kwargs):
            self._mutually_exclusive = mutually_exclusive
            self._required_together = required_together
            self._required_one_of = required_one_of
            self._required_if = required_if
            self._

# Generated at 2022-06-24 20:24:41.798329
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    # Nothing to test.
    pass
