

# Generated at 2022-06-24 20:15:01.975768
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_val = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    )

    result = validator.validate(module_val)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-24 20:15:09.438165
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert isinstance(argument_spec_validator_0, ArgumentSpecValidator)


# Generated at 2022-06-24 20:15:14.795184
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_0 = {'x': 'y'}
    argument_spec_validator_0 = ArgumentSpecValidator(**dict_0)
    dict_1 = {'a': 'b'}
    validation_result_0 = argument_spec_validator_0.validate(**dict_1)
    assert validation_result_0.validated_parameters == {'a': 'b'}
    assert validation_result_0.error_messages == []


# Generated at 2022-06-24 20:15:24.560724
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    dict_0 = {
        'argument_spec': {
            'age': {
                'default': 42,
                'type': 'int',
            },
            'name': {
                'type': 'str',
            },
        },
    }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)

    dict_1 = {
        'age': '42',
        'name': 'bo',
    }
    validation_result_0 = module_argument_spec_validator_0.validate(dict_1)
    assert validation_result_0.validated_parameters == {
        'age': 42,
        'name': 'bo',
    }


# Generated at 2022-06-24 20:15:28.381149
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    dict_1 = {}
    module_argument_spec_validator_0.validate(dict_1)

# Generated at 2022-06-24 20:15:30.052312
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    args = {"argument_spec": {} }
    instance = ArgumentSpecValidator(**args)


# Generated at 2022-06-24 20:15:33.946235
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    dict_1 = {}
    validation_result_0 = module_argument_spec_validator_0.validate(**dict_1)
    assert validation_result_0 is not None


# Generated at 2022-06-24 20:15:40.721412
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Init
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    parameters_0 = {}

    # Test
    val = module_argument_spec_validator_0.validate(**parameters_0)
    assert val is not None, "Expected valid response"

    # Init
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)
    parameters_0 = {}

    # Test
    val = module_argument_spec_validator_0.validate(**parameters_0)
    assert val is not None, "Expected valid response"

    # Init
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:15:42.717469
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_0 = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**dict_0)

# Generated at 2022-06-24 20:15:54.064311
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    dict_0 = {'aliases': None, 'default': None, 'required': False, 'type': 'bool'}
    dict_1 = {'type': 'dict'}
    dict_2 = {'type': 'dict'}
    dict_3 = dict()
    dict_4 = {'type': 'dict'}
    dict_5 = {'type': 'dict'}
    dict_6 = {'aliases': None, 'default': None, 'required': False, 'type': 'bool'}
    dict_7 = {'aliases': None, 'default': None, 'required': False, 'type': 'dict'}
    dict_8 = {'aliases': None, 'default': None, 'required': False, 'type': 'dict'}

# Generated at 2022-06-24 20:16:14.633950
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    asv = ModuleArgumentSpecValidator()
    params = {'greeting': 'Hello',
              'name': 'John',
              'incorrect_type': True}
    result = asv.validate(params)
    assert result.errors[0].message == "The boolean parameter 'incorrect_type' expects either 'true' or 'false'"
    assert result.validated_parameters['greeting'] == 'Hello'
    assert result.validated_parameters['name'] == 'John'
    assert 'incorrect_type' not in result.validated_parameters
    assert result.error_messages[0] == "The boolean parameter 'incorrect_type' expects either 'true' or 'false'"


# Generated at 2022-06-24 20:16:16.650736
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:16:23.792042
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case for when: no_log=False and path=[] and required=False
    from ansible.module_utils.basic import AnsibleModule
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator({"name": {"type": "str"}})
    module = AnsibleModule(argument_spec={"name": {"type": "str"}}, supports_check_mode=False)
    # Test code starts here
    result_0 = module_argument_spec_validator_0.validate({'name': 'bo'})
    assert result_0.validated_parameters == {'name': 'bo'}
    assert result_0.errors == []
    assert result_0.error_messages == []


# Generated at 2022-06-24 20:16:29.466380
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_1.validate() == None
    assert module_argument_spec_validator_1.validate() == None


# Generated at 2022-06-24 20:16:32.802659
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(False)
    assert validator.argument_spec == {}

    validator = ArgumentSpecValidator(
        {
            'arg': {'type': 'str'}
        }
    )
    assert validator.argument_spec == {
        'arg': {'type': 'str'}
    }


# Generated at 2022-06-24 20:16:35.357465
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Set up test fixture
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = {}

    # Invoke method
    result = module_argument_spec_validator_1.validate(parameters)

    # Check the results
    pass

# Generated at 2022-06-24 20:16:44.616112
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.errors:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters


# Generated at 2022-06-24 20:16:45.982055
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:16:50.305751
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'demo',
        'description': 'description',
    }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result
    assert result.error_messages == []


# Generated at 2022-06-24 20:17:00.662548
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test case #0
    try:
        result = module_argument_spec_validator_0.validate('parameters_0')
        assert result.validated_parameters == 'parameters_0'
        assert result.unsupported_parameters == set()
        assert result.error_messages == []
    except Exception as err:  # noqa
        print(err)

    # Test case #1
    try:
        result = module_argument_spec_validator_0.validate('parameters_1')
        assert result.validated_parameters == 'parameters_1'
        assert result.unsupported_parameters == set()
        assert result.error_messages == []
    except Exception as err:  # noqa
        print(err)

    # Test case #2

# Generated at 2022-06-24 20:17:07.329350
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:09.997376
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec_validator = ArgumentSpecValidator({'name': {'type': 'str'}})
    assert arg_spec_validator is not None


# Generated at 2022-06-24 20:17:14.688954
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Arrange
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Act
    result = module_argument_spec_validator_0.validate(parameters=False)

    # Assert
    assert result == False


# Generated at 2022-06-24 20:17:22.184012
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # initialize
    params = {}
    args = ()
    kwargs = {'mutually_exclusive': [], 'required_together': [], 'required_if': [], 'required_by': []}
    argspec_validator_0 = ArgumentSpecValidator(params, *args, **kwargs)

    # assert
    assert argspec_validator_0.validate(params) is not None



# Generated at 2022-06-24 20:17:22.908450
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False, 'Test not implemented.'


# Generated at 2022-06-24 20:17:27.663595
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Verify that the method of the module_argument_spec_validator_0 object does not raise any exceptions
    assert module_argument_spec_validator_0.validate({}) is not None


# Generated at 2022-06-24 20:17:39.694425
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    module_argument_spec = {'argument_spec': {'name': {'type': 'str'}, 'age': {'type': 'int'}}, 'mutually_exclusive': [['name', 'age']], 'required_together': [['name', 'age']], 'required_one_of': [['name', 'age']], 'required_if': [{'parameter': 'name', 'value': 'bo', 'parameters': ['age']}], 'required_by': {'name': ['age'], 'age': ['name']}}
    parameters = {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:17:46.886835
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    validator = ArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        required_if=[["name", "test", ["age"]]],
        mutually_exclusive=[["name", "age"]],
        required_one_of=[["name", "age"]],
    )

    # Test a valid parameters, should just return as is.
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters

    assert len(result.error_messages) == 0



# Generated at 2022-06-24 20:17:49.285686
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator = ArgumentSpecValidator()
    assert type(module_argument_spec_validator.validate("parameters")) == ValidationResult

# Generated at 2022-06-24 20:17:59.935957
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(parameters)

# Generated at 2022-06-24 20:18:10.512201
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert ArgumentSpecValidator.validate(
                argument_spec=dict(
                    termType='str',
                    term='str',
                    genbank='str',
                    timeout='int'
                ),
                mutually_exclusive=['term', 'genbank'],
                parameters=dict(
                    termType='gene',
                    term='SOD1',
                    genbank='NM_000454.3',
                    timeout=30
                )
    )

# Generated at 2022-06-24 20:18:17.816332
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'required_parameter': {'type': 'str', 'required': True},
        'optional_parameter': {'type': 'str', 'required': False},
    }

    parameters = {'required_parameter': 'value'}

    validator = ArgumentSpecValidator(spec)
    assert validator._valid_parameter_names == {'required_parameter', 'optional_parameter'}
    assert validator._validated_parameters == parameters
    assert validator._required_by is None
    assert validator._required_if is None
    assert validator._required_one_of is None
    assert validator._required_together is None
    assert validator._mutually_exclusive is None
    assert validator.argument_spec == spec



# Generated at 2022-06-24 20:18:21.929623
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:18:25.044048
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = {}
    module_argument_spec_validator_validate = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_validate.validate(params)


# Generated at 2022-06-24 20:18:30.333584
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test_params = {"age": "42",
                   "name": "bo"}

    result = module_argument_spec_validator_0.validate(test_params)

    assert result.validated_parameters == test_params, 'validated_parameters'
    assert result.unsupported_parameters == set(), 'unsupported_parameters'
    assert result.error_messages == [], 'error_messages'

# Generated at 2022-06-24 20:18:36.997787
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec={'state': {'type': 'str', 'choices': ['present', 'absent'], 'required': True}, 'name': {'type': 'str', 'required': True}, 'url': {'type': 'str', 'required': True}, 'aliases': {'type': 'list', 'default': []}}, mutually_exclusive=[['url', 'host'], 'password'], required_together=[['url', 'host']], required_one_of=[], required_if=[], required_by=[])
    parameters = module_argument_spec_validator.validate(parameters={})


# Generated at 2022-06-24 20:18:38.973530
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    print(test_case_0)

# Generated at 2022-06-24 20:18:41.661505
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Check default constructors
    test_case_0()

if __name__ == '__main__':
    test_ArgumentSpecValidator()

# Generated at 2022-06-24 20:18:43.641776
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    try:
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

        module_argument_spec_validator_0.validate()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 20:18:51.185769
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    try:
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    except Exception as e:
        msg = "Failed to create instance of class ModuleArgumentSpecValidator"
        raise Exception(msg)
    else:
        print("Created instance of class ModuleArgumentSpecValidator")

    argument_spec_0 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }
    result_0 = module_argument_spec_validator_0.validate(argument_spec_0, parameters_0)
    print(result_0)


# Generated at 2022-06-24 20:19:08.917664
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })
    assert ArgumentSpecValidator({
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    })
    assert ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }, [])
    assert ArgumentSpecValidator({
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }, [])
    assert ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }, [])

# Generated at 2022-06-24 20:19:15.209476
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator()

    # Test with valid input
    parameters = {'name': 'foo'}
    argument_spec = {'name': {'type': 'str'}}
    validator.argument_spec = argument_spec
    result = validator.validate(parameters)

    assert hasattr(result, 'unsupported_parameters')
    assert hasattr(result, 'validated_parameters')
    assert hasattr(result, 'error_messages')



# Generated at 2022-06-24 20:19:19.419017
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Test with positional arguments
    try:
        module_argument_spec_validator_0.validate()
    except TypeError as e:
        assert "argument 'parameters' (pos 1): " in str(e)


# Generated at 2022-06-24 20:19:25.689420
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import pytest
    from . import mock_ansible_module
    from ansible.module_utils.common.arg_spec import ValidationResult

    # Arrange
    mock_module = mock_ansible_module()
    mock_module._ansible_no_log = False
    mock_ansible_module_get_ansible_version = mock_module.get_ansible_version
    mock_ansible_module_get_ansible_version.return_value = '2.10.2'
    mock_module.get_ansible_version = mock_ansible_module_get_ansible_version
    mock_validation_result_0 = mock_ansible_module_validation_result_new()
    mock_validation_result_0.error_messages = ['error_messages']
    mock_validation_

# Generated at 2022-06-24 20:19:32.359074
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-24 20:19:36.525788
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = dict()
    actual_result = module_argument_spec_validator_1.validate(parameters)

# Generated at 2022-06-24 20:19:40.330636
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0, ModuleArgumentSpecValidator)
    parameters_0 = {"parameter_0": "value_0"}
    print("unit test for ModuleArgumentSpecValidator method validate")
    assert isinstance(module_argument_spec_validator_0.validate(parameters_0), ValidationResult)
    print("unit test successfull")

test_ModuleArgumentSpecValidator_validate()



# Generated at 2022-06-24 20:19:44.821886
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)


# Generated at 2022-06-24 20:19:50.918629
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate(parameters=[]) != 0

# Generated at 2022-06-24 20:19:59.221667
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"a": {"type": "bool"}}
    mutually_exclusive = ["a", "b"]
    required_together = [['a', 'b']]
    required_one_of = [['a', 'b']]
    required_if = [['a', 'b', ['c']]]
    required_by = {'a': ['b']}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)



# Generated at 2022-06-24 20:20:15.427256
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator_0 = ArgumentSpecValidator()


# Generated at 2022-06-24 20:20:22.862611
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator(None,
                                 mutually_exclusive='mutually_exclusive',
                                 required_together='required_together',
                                 required_one_of='required_one_of',
                                 required_if='required_if',
                                 required_by='required_by',
                                 )
    try:
        ArgumentSpecValidator(None,
                              mutually_exclusive='mutually_exclusive',
                              required_together='required_together',
                              required_one_of='required_one_of',
                              required_if='required_if',
                              required_by='required_by',
                              )
    except TypeError:
        pytest.fail("Initialization of ArgumentSpecValidator object failed.")

# Generated at 2022-06-24 20:20:26.334008
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Given arguments
    # When parameters values are None
    parameters = None
    # Then validate should raise ValueError
    with pytest.raises(ValueError):
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
        module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:20:30.812774
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters = {'a': "42", 'b': "42"})
    assert result.validated_parameters == {'a': "42", 'b': "42"}


# Generated at 2022-06-24 20:20:32.410422
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_1.validate(parameters=None)
    assert result is not None


# Generated at 2022-06-24 20:20:40.730770
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    parameters_0 = dict()
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0 is not None
    assert result_0._deprecations == []
    assert set(result_0._no_log_values) == set()
    assert result_0._unsupported_parameters == set()
    assert result_0._validated_parameters == dict()
    assert result_0.errors == AnsibleValidationErrorMultiple()
    assert result_0.error_messages == []
    assert result_0.validated_parameters == dict()


# Generated at 2022-06-24 20:20:44.257423
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    expected = {'arg_spec': {"name": {"type": "str"}, "age": {"type": "int"}}, 'parameters': {'name': 'bo', 'age': '42'}}
    actual = module_argument_spec_validator_0.validate(expected.get('parameters'))
    assert actual == expected

# Generated at 2022-06-24 20:20:52.229878
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {'state': 'present', 'ip': '192.168.1.1', 'vlan': '5', 'interface': 'eth0'}
    mutually_exclusive = [['ip', 'interface']]
    required_one_of = [['ip', 'interface']]
    required_together = [['ip', 'interface']]
    argument_spec = {
        'ip': {'type': 'str'},
        'vlan': {'type': 'int'},
        'interface': {'type': 'str'},
        'state': {'type': 'str'}
    }
    argument_spec_validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, None, None)
    result = argument_spec_validator.validate(parameters)




# Generated at 2022-06-24 20:21:02.548677
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {'parameter_0': {'type': 'str'},
                'parameter_1': {'type': 'int'},
                'parameter_2': {'type': 'list'},
                'parameter_3': {'type': 'dict'},
                'parameter_4': {'type': 'bool'},
                'parameter_5': {'type': 'path'},
                'parameter_6': {'type': 'raw'},
                }


# Generated at 2022-06-24 20:21:10.611248
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validation_result_0 = module_argument_spec_validator_0.validate(parameters)
    if validation_result_0.error_messages:
        sys.exit("Validation failed: {}".format(", ".join(validation_result_0.error_messages)))
    valid_params = validation_result_0.validated_parameters

# Generated at 2022-06-24 20:22:13.185714
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception
    ArgumentSpecValidator.validate(ArgumentSpecValidator, {})
    # Must not raise an exception

# Generated at 2022-06-24 20:22:21.360864
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    test = ArgumentSpecValidator(argument_spec={'param1':{'type':'int'}, 'param2':{'type':'str'}}, mutually_exclusive=['param1','param2'], required_together=[['param1','param2']], required_one_of=['param1'], required_if={'param1':'value'}, required_by='param1')
    assert test._mutually_exclusive == ['param1','param2']
    assert test._required_together == [['param1','param2']]
    assert test._required_one_of == ['param1']
    assert test._required_if == {'param1':'value'}
    assert test._required_by == 'param1'
    assert test._valid_parameter_names == set(["param1", "param2"])

# Generated at 2022-06-24 20:22:29.449918
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:22:34.972311
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    # No error should be raised because the parameters are all valid
    try:
        result_0 = module_argument_spec_validator_0.validate(parameters_0)
        assert True
    except:
        assert False
    # No error should be raised because the parameters are all valid
    try:
        result_1 = module_argument_spec_validator_0.validate(parameters_0)
        assert True
    except:
        assert False
    

# Generated at 2022-06-24 20:22:40.755699
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:22:45.889286
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'foo': 'bar'}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters)



# Generated at 2022-06-24 20:22:52.372525
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:22:57.456139
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = dict()
    parameters = module_argument_spec_validator_0.validate(parameters)

    assert parameters == None



if __name__ == "__main__":
    test_case_0()
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:23:01.139318
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate()


# Generated at 2022-06-24 20:23:05.959231
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    parameter_result = module_argument_spec_validator_0.validate(parameters)

    assert len(parameter_result.errors) == 0
    assert parameter_result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:24:13.668925
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec_validator = ArgumentSpecValidator(argument_spec)
    result = argument_spec_validator.validate(parameters)

    if result.errors:
        sys.exit("Validation failed: {0}".format(", ".join(result.errors)))

    valid_params = result.validated_parameters


# Generated at 2022-06-24 20:24:18.390749
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate('test_value_1')
    assert result == 'test_value_1'
# End of test case for method validate of class ModuleArgumentSpecValidator


# Generated at 2022-06-24 20:24:21.179199
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    assert module_argument_spec_validator_0.validate("parameters") == ""


# Generated at 2022-06-24 20:24:23.917170
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate({'param': {'type': 'str'}})
    assert result_0.error_messages == [] and result_0.validated_parameters == {'param': {'type': 'str'}}

# Generated at 2022-06-24 20:24:26.568739
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:24:31.217182
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = {}
    # error = None
    # try:
    #     result = module_argument_spec_validator_1.validate(parameters)
    # except Exception as err:
    #     error = err
    # assert result is None
    # assert error is None


# Generated at 2022-06-24 20:24:31.664008
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:24:39.600708
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Pass
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={'type': 'dict'})

    # Pass
    ArgumentSpecValidator(argument_spec={'type': 'dict'})

    # Pass
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={'type': 'dict'}, mutually_exclusive=[['type']])

    # Pass
    ArgumentSpecValidator(argument_spec={'type': 'dict'}, mutually_exclusive=[['type']])

    # Pass
    ArgumentSpecValidator(argument_spec={'type': {'type': 'dict'}}, mutually_exclusive=[['type']])

    # Pass

# Generated at 2022-06-24 20:24:40.288359
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:24:43.198971
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate()
    module_argument_spec_validator_0.validate()

