

# Generated at 2022-06-24 20:14:56.977332
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:15:03.645752
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {}
    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec)

    parameters = {}
    result = module_argument_spec_validator.validate(parameters)
    assert isinstance(result, ValidationResult) and \
        result.validated_parameters == parameters and \
        result.unsupported_parameters == set() and \
        result.errors.messages == list()

# Generated at 2022-06-24 20:15:12.556852
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case to assert bool type
    # inputs:
    #       - self: argument_spec = {'examplebool': {'type': 'bool', 'required': True, 'default': False}},
    #               parameters = {'examplebool': 'true'}

    argument_spec = {'examplebool': {'type': 'bool', 'required': True, 'default': False}}
    parameters = {'examplebool': 'true'}
    validator = ArgumentSpecValidator(argument_spec=argument_spec)
    result = validator.validate(parameters=parameters)
    assert result.validated_parameters['examplebool'] == True
    assert result.error_messages == []

    # Test case to assert default value
    # input:
    #       - self: argument_spec = {'examplestr': {'

# Generated at 2022-06-24 20:15:14.978983
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {

    }
    # Exercise

    # Verify
    assert module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:15:16.839902
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # Setup

    # Exercise
    result = ModuleArgumentSpecValidator.validate()

    # Verify
    assert result == None


# Generated at 2022-06-24 20:15:18.101397
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test_case_0()

test_case_0()

# Generated at 2022-06-24 20:15:27.673302
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.validation import check_mutually_exclusive
    # Testing method validate of class ModuleArgumentSpecValidator with arguments [{'type': 'str'}, {'type': 'int'}]
    x = ModuleArgumentSpecValidator()
    y = x.validate({'type': 'str'}, {'type': 'int'})
    # assert type(y) == type(x), f"{type(y)} == {type(x)}"


# Generated at 2022-06-24 20:15:31.168403
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate of class ArgumentSpecValidator"""
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result = module_argument_spec_validator_0.validate(parameters_0)
    assert result is None

# Generated at 2022-06-24 20:15:32.385936
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:15:35.783692
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Validate with no parameters
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test_case_0()


if __name__ == '__main__':

    # test_case_0()

    test_ArgumentSpecValidator_validate()

    pass

# Generated at 2022-06-24 20:15:43.711514
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_of_method = module_argument_spec_validator_0.validate(parameters_0)
    assert result_of_method



# Generated at 2022-06-24 20:15:46.794044
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_case_0()

# Generated at 2022-06-24 20:15:54.808588
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test_ModuleArgumentSpecValidator_validate()

    # Test ModuleArgumentSpecValidator.validate() with no argument spec
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate({})
    assert not result_0.validated_parameters
    assert not result_0.error_messages
    assert not result_0.deprecations
    assert not result_0.warnings
    assert not result_0.unsupported_parameters

    # Test ModuleArgumentSpecValidator.validate() with a single argument spec
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}})
    result_1 = module_argument_spec_

# Generated at 2022-06-24 20:16:01.105530
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import AnsibleModule
    module_argument_spec_validator_validate_0 = ModuleArgumentSpecValidator()
    parameters_validate_0 = {u'name': u'bo'}
    validation_result_validate_0 = module_argument_spec_validator_validate_0.validate(parameters_validate_0)


# Generated at 2022-06-24 20:16:02.165428
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:16:09.776192
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Create an instance of ArgumentSpecValidator
    invalid_argument_spec_1 = {'host': {'required': True}}
    invalid_argument_spec_2 = {'host': {'required': False}}
    invalid_argument_spec_3 = {'host': {'type': 'str'}}
    invalid_argument_spec_4 = {'host': {'type': 'bool'}}
    invalid_argument_spec_5 = {'host': {'type': 'list', 'elements': 'str'}}
    invalid_argument_spec_6 = {'host': {'type': 'dict'}}
    invalid_argument_spec_7 = {'host': {'type': 'dict', 'options': 'str'}}

# Generated at 2022-06-24 20:16:13.210482
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate({"a": "str", "b": "str", "c": "str"})
    assert result_0.validated_parameters == {}

# Generated at 2022-06-24 20:16:15.522891
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result is None

# Generated at 2022-06-24 20:16:26.839810
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'valid_params': {
            'one': 'foo'
        }
    }
    argument_spec = {
        'valid_params': dict(
            one=dict(type='str'),
            two=dict(type='str')
        ),
        'invalid_params': dict(
            one=dict(type='str'),
            two=dict(type='str')
        ),
    }
    mutually_exclusive = [
        ['valid_params', 'invalid_params'],
    ]
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec=argument_spec, mutually_exclusive=mutually_exclusive)
    validate_result = module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:16:30.337579
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    arguments_spec_0 = {'type': 'str', 'default': 'test'}
    parameters_0 = {}
    test = module_argument_spec_validator_0.validate(parameters_0, arguments_spec_0)

    if test.validated_parameters['default'] == 'test':

        return True


# Generated at 2022-06-24 20:16:40.603636
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Remove this line if you can successfully run the test case.
    assert False, "Test case will not be run."


# Generated at 2022-06-24 20:16:44.644893
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = dict()
    with pytest.raises(TypeError) as err:
        module_argument_spec_validator_0.validate(parameters)


if __name__ == '__main__':
    test_case_0()
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:16:48.984283
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {"name": "bo", "age": "42"}

# Generated at 2022-06-24 20:16:49.487659
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert 0


# Generated at 2022-06-24 20:16:49.969560
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-24 20:16:51.025635
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_case_0()

# Generated at 2022-06-24 20:16:56.709806
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters_0 = {
        'required_one_of': [[
            'name',
            'uuid',
        ]],
    }

    kwargs_0 = {
        'mutually_exclusive': [
            [
                'name',
                'uuid',
            ],
        ],
        'required_together': [[
            'name',
            'uuid',
        ]],
    }

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator('argument_spec', **kwargs_0)


# Generated at 2022-06-24 20:17:02.435716
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # test case
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    result_1 = module_argument_spec_validator_0.validate(parameters_0)

# Generated at 2022-06-24 20:17:04.655550
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:17:07.937287
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result = module_argument_spec_validator_0.validate(parameters_0)



# Generated at 2022-06-24 20:17:16.714323
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = dict()
    result = module_argument_spec_validator_1.validate(parameters)

# Generated at 2022-06-24 20:17:23.853068
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Setup
    argument_spec_0 = {}

    mutually_exclusive_0 = None

    required_together_0 = None

    required_one_of_0 = None

    required_if_0 = None

    required_by_0 = None

    parameters_0 = {}

    # Invocation
    try:
        ArgumentSpecValidator(argument_spec_0, mutually_exclusive=mutually_exclusive_0, required_together=required_together_0, required_one_of=required_one_of_0, required_if=required_if_0, required_by=required_by_0)
    except:
        raise AssertionError()

try:
    test_case_0()
except AssertionError as e:
    print (e)

# Generated at 2022-06-24 20:17:24.753833
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    asv = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:27.300874
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(arg1)
    module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:17:39.423421
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result, ValidationResult)

    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
   

# Generated at 2022-06-24 20:17:42.883614
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = dict()
    result = module_argument_spec_validator_0.validate(params)
    assert result.validated_parameters == dict()
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-24 20:17:45.191777
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0, ModuleArgumentSpecValidator)


# Generated at 2022-06-24 20:17:48.982458
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    result_0 = module_argument_spec_validator_0.validate({'parameters': {}})
    assert result_0._validated_parameters == {}, "Result of method ArgumentSpecValidator.validate is incorrect."



# Generated at 2022-06-24 20:17:51.978682
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator = ModuleArgumentSpecValidator()
    expected = ('validate', )
    actual = module_argument_spec_validator._validate_parameter_names
    assert expected == actual, "ModuleArgumentSpecValidator().validate.parameter_names was {actual}, should have been {expected}".format(actual=actual, expected=expected)


# Generated at 2022-06-24 20:17:55.410687
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    param = dict()
    module_argument_spec_validator_0.validate(param)

if __name__ == '__main__':
    exit(main())

# Generated at 2022-06-24 20:18:10.659090
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(hasattr(result, 'error_messages'))
    assert('Must be of type int' in result.error_messages)



# Generated at 2022-06-24 20:18:11.863800
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate({})

# Generated at 2022-06-24 20:18:15.316815
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters =  {
                     "register": "1"
                   }
    result = module_argument_spec_validator_0.validate(parameters)
    assert result._validated_parameters["register"] == parameters["register"]


# Generated at 2022-06-24 20:18:25.413779
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_001 = ModuleArgumentSpecValidator(
        {
            "name": {
                "type": "str",
                "required": True
            }
        },
    )
    result = module_argument_spec_validator_001.validate({
        "name": "test"
    })
    assert result.validated_parameters == {
        "name": "test"
    }
    assert result.errors.messages == []

    module_argument_spec_validator_002 = ModuleArgumentSpecValidator(
        {
            "name": {
                "type": "str",
                "required": True
            }
        },
    )
    result = module_argument_spec_validator_002.validate({})

# Generated at 2022-06-24 20:18:35.303347
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    test_argspec_dict_0 = {}
    test_argspec_dict_1 = {}
    test_argspec_dict_1['aliases'] = ['test_aliases']
    test_argspec_dict_1['required'] = True
    test_argspec_dict_1['type'] = 'str'
    test_argspec_dict_0['test_key_0'] = test_argspec_dict_1

    parameters_0 = {}
    parameters_0['test_key_0'] = 'test_value_0'
    parameters_0['test_key_1'] = 'test_value_1'
    parameters_0['test_key_2'] = 'test_value_2'

# Generated at 2022-06-24 20:18:46.209029
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create a ArgSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    # Test whether validator works as expected
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    expected_result = ValidationResult(parameters)
    expected_result.errors = AnsibleValidationErrorMultiple()
    expected_result.errors.append("age ({0}) is invalid, expected int, got str.".format("42"))
    expected_result._validated_parameters = {
        'age': 42,
        'name': 'bo',
    }

    assert result._validated

# Generated at 2022-06-24 20:18:50.244894
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create test object
    argument_spec_validator_1 = ArgumentSpecValidator(None, None, None, None, None, None)
    # Call method validate
    assert argument_spec_validator_1.validate(None, None) is not None

# Generated at 2022-06-24 20:18:52.265883
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # FIXME: Add tests for path to validate method once it is moved to a proper module

    assert True

# Generated at 2022-06-24 20:19:02.946500
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert to_native(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None).validate(parameters={})) == to_native(ValidationResult({}))
    assert to_native(ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None).validate(parameters={"name": "bo", "age": 42})) == to_native(ValidationResult({"name": "bo", "age": 42}))

# Generated at 2022-06-24 20:19:07.185473
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters_0 = dict()
    result_0 = ValidationResult(parameters_0)

    test_ArgumentSpecValidator = ArgumentSpecValidator(
    )

    result_0 = test_ArgumentSpecValidator.validate(parameters_0)

    assert result_0 is not None
    assert len(result_0.error_messages) == 0
    assert len(result_0.validated_parameters) == 0


# Generated at 2022-06-24 20:19:22.792216
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    ret_obj = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:19:25.589885
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
# -------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-24 20:19:31.250545
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test the case where parameters is None
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = None
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0 is not None


# Generated at 2022-06-24 20:19:39.344073
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
        )
    parameters = dict(
        name='bo',
        age='42',
        )

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == dict(name='bo', age=42)



# Generated at 2022-06-24 20:19:44.695351
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters={})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-24 20:19:51.512998
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {"a": {"type": "str"}, "b": {"type": "int"}, "c": {"type": "bool"}, "d": {"type": "dict"}}
    # Create ArgumentSpecValidator instance
    argument_spec_validator = ArgumentSpecValidator(argument_spec)
    parameters = {"a": "mystring", "b": 9}
    result = argument_spec_validator.validate(parameters)
    assert result.errors == []
    assert result.validated_parameters ==  {"a": "mystring", "b": 9}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-24 20:19:55.992311
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert isinstance(result_0, ValidationResult)


# Generated at 2022-06-24 20:20:05.317427
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Assert that the exception is thrown for a None argument_spec parameter
    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec=None) # TODO: The function should be updated to also accept dict[str, dict] instead of only dict
    with pytest.raises(AnsibleValidationErrorMultiple):
        module_argument_spec_validator.validate(parameters={})
    # assert module_argument_spec_validator.validate(parameters={}) is None
#
# def test_ModuleArgumentSpecValidator_validate_exception_message(self):
#     module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec=None)
#     with pytest.raises(AnsibleValidationErrorMultiple) as exc_info:
#         module_argument_spec

# Generated at 2022-06-24 20:20:10.341578
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Setup
    parameters = dict()

    # Test
    try:
        result = module_argument_spec_validator_0.validate(parameters)
    except Exception as ex:
        assert False, "unexpected exception: {0}".format(ex)

    # Teardown
    teardown()



# Generated at 2022-06-24 20:20:17.561995
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    Unit test for constructor of class ArgumentSpecValidator
    '''
    TEST_DATA = {
                    'argument_spec': {
                        'name': {'type': 'str'},
                        'age': {'type': 'int'},
                    },
                    'mutually_exclusive': [
                        ['name', 'age']
                    ],
                    'required_together': [
                        ['name', 'age']
                    ],
                    'required_one_of': [
                        ['name', 'age']
                    ],
                    'required_if': [
                        ['name', 'bo', ['age']]
                    ],
                    'required_by': {
                        'age': ['name']
                    }
                }

    argument_spec_validator_instance = ArgumentSpecValidator(**TEST_DATA)

    assert argument_spec_validator

# Generated at 2022-06-24 20:20:48.351259
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})
    parameters_0 = {'name': 'bo', 'age': '42'}
    result_0 = argument_spec_validator_0.validate(parameters_0)
    expected_0 = {'name': 'bo', 'age': 42}
    assert result_0['validated_parameters'] == expected_0
    assert not result_0['errors']


# Generated at 2022-06-24 20:20:50.417536
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    assert isinstance(ValidationResult, type(module_argument_spec_validator_1))


# Generated at 2022-06-24 20:20:52.877938
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:20:56.816251
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()

    parameters = {'a': 1, 'b': 2}
    result = module_argument_spec_validator.validate(parameters)

    assert isinstance(result, ValidationResult)


# Generated at 2022-06-24 20:20:58.822361
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  module_argument_spec_validator_case_0 = ModuleArgumentSpecValidator()
  result = module_argument_spec_validator_case_0.validate(None)
  assert(result)

# Generated at 2022-06-24 20:21:04.871595
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initialize the object
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    print("\n#### Test 1: No type, no default, no value")
    # Test case : no type, no default, no value
    parameter_0 = {'name': {}}
    try:
        result = module_argument_spec_validator_0.validate(parameter_0)
        assert False
    except TypeError:
        assert True

    print("\n#### Test 2: No type, no default, with value")
    # Test case : no type, no default, with value
    parameter_0 = {'name': {'value': 'test'}}

# Generated at 2022-06-24 20:21:08.234684
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parms = {"name":"name"}
    assert module_argument_spec_validator_0.validate(parms)


# Generated at 2022-06-24 20:21:14.736443
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # This should fix linters, it shouldn't be required normally
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # This should fix linters, it shouldn't be required normally
    result_validate = module_argument_spec_validator_0.validate()
    assert result_validate.__class__.__name__ == 'ValidationResult'

# Generated at 2022-06-24 20:21:18.965737
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:21:27.277911
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initialization
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Testing on provided sample

    # Testing on sample provided by Ansible

# Generated at 2022-06-24 20:22:27.172553
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {"foo": "bar"}
    module_argument_spec_validator_0_0 = ModuleArgumentSpecValidator()
    validation_result_0_0 = module_argument_spec_validator_0_0.validate(parameters)
    assert validation_result_0_0.validated_parameters == {"foo": "bar"}

# Generated at 2022-06-24 20:22:29.410210
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec1 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}}

    asv = ArgumentSpecValidator(argument_spec1)


# Generated at 2022-06-24 20:22:30.727426
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:22:31.190649
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True == True

# Generated at 2022-06-24 20:22:34.119729
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate({"age":42,"name":'bo'}) == None

test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-24 20:22:38.124908
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator.validate(parameters)
    assert result == True

# Tests for ArgumentSpecValidator


# Generated at 2022-06-24 20:22:46.913375
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate method of class ArgumentSpecValidator."""
    # Test cases for validate method of class ArgumentSpecValidator
    # Test case 0
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    # validation_result_0 = module_argument_spec_validator_0.validate(parameters_0)
    # assert validation_result_0.unsupported_parameters == set()
    # assert validation_result_0.validated_parameters == {}
    # assert validation_result_0.errors == AnsibleValidationErrorMultiple()
    # assert validation_result_0.error_messages == []
    # assert validation_result_0._no_log_values == set()
    # assert validation_result_0._deprecations == []
    # assert validation_result_

# Generated at 2022-06-24 20:22:50.551935
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator() != None


# Generated at 2022-06-24 20:22:58.239496
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0.validated_parameters == {}
    assert result_0.error_messages == []
    assert result_0._no_log_values == set()
    assert result_0._validated_parameters == {}
    assert result_0._unsupported_parameters == set()
    assert result_0._deprecations == []
    assert result_0._warnings == []

# Generated at 2022-06-24 20:22:59.407165
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
