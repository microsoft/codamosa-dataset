

# Generated at 2022-06-24 20:14:55.816529
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-24 20:15:06.290666
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Simple Example test
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    # Simple Example test
    test_0_argumentspec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )
    test_0_parameters = dict(
        name='bo',
        age='42',
    )
    test_0_result = module_argument_spec_validator_0.validate(test_0_parameters)
    test_0_validated_parameters = test_0_result.validated_parameters
    test_0_error_messages = test_0_result.error_messages
    test_0_no_log_values = test_0_result.no_log_values
    test_0_unsupported_parameters

# Generated at 2022-06-24 20:15:07.825671
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert ModuleArgumentSpecValidator.validate() == NotImplementedError


# Generated at 2022-06-24 20:15:14.087107
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    ansible_module_0 = AnsibleModule(argument_spec=dict(
        required=dict(type='raw')))
    parameters = dict()
    try:
        with pytest.raises(AnsibleValidationErrorMultiple) as excinfo:
            module_argument_spec_validator_0.validate(parameters=parameters)
    except Exception:
        pytest.fail("Unexpected exception raised: %s" % excinfo)
    else:
        expected_has_msg = re.compile(
            r'required\">.*?is required').search
        assert excinfo.match(expected_has_msg)

# Generated at 2022-06-24 20:15:17.035693
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'name': {'type': 'str', 'required': True}, 'age': {'type': 'int', 'required': True}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(parameters)

    if result.errors:
        print("Validation failed: {0}".format(", ".join(result.error_messages)))

# Generated at 2022-06-24 20:15:18.601924
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:15:21.252333
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-24 20:15:22.665308
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:15:32.508827
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"a": 1, "b": 2, "c": 3}
    mutually_exclusive = [["a", "b"], ["a", "c"]]
    required_together = [["b", "c"]]
    required_one_of = [["a", "b"], ["a", "c"]]
    required_if = [["a", "b"], ["a", "c"]]
    required_by = {"a": ["b", "c"]}
    argumentSpecValidator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-24 20:15:39.312633
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Arrange
    argument_spec_0 = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters_0 = {
        'name': 'bo',
        'age': '42',
    }

    # Act
    validator_validate_0 = ArgumentSpecValidator(argument_spec_0)
    result_0 = validator_validate_0.validate(parameters_0)

    # Assert
    assert isinstance(result_0, ValidationResult), "result is not a ValidationResult"

    assert result_0.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-24 20:15:48.984215
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    ValidationResult_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert ValidationResult_0.errors == []


# Generated at 2022-06-24 20:15:52.414137
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0.validate({}), ValidationResult)
    assert isinstance(module_argument_spec_validator_0.validate({'a': 'b'}), ValidationResult)

# Generated at 2022-06-24 20:16:03.528193
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case with a list of mutually_exclusive
    mutually_exclusive = ['name', 'alias']
    required_together = [('param_1', 'param_2')]
    required_one_of = [['param_1', 'param_2']]
    required_if = [['param_1', 'param_1_value', ['param_3', 'param_4']]]
    required_by = {'param_1': ['param_3', 'param_4']}

    argument_spec_0 = {'param_1':{'type':'str'}, 'param_2':{'type':'str'}, 'param_3':{'type':'str'}, 'param_4':{'type':'str'}}

# Generated at 2022-06-24 20:16:12.724221
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate()"""

    from ansible.module_utils.basic import AnsibleModule

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hobbies': {'type': 'list', 'elements': 'str'},
        'spouse': {'type': 'dict', 'options': {
            'name': {'type': 'str'},
            'age': {'type': 'int'}
        }},
        'dob': {'type': 'datetime'}
    }

    import dateutil.parser

    module = AnsibleModule(argument_spec=argument_spec)


# Generated at 2022-06-24 20:16:16.809546
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Case 0
    module_argument_spec_validator_case_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_case_0.validate({})
    assert result.validated_parameters == {}
    assert result.error_messages == []
    assert result.unsupported_parameters == []


# Generated at 2022-06-24 20:16:23.924871
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_values = [
        {
            'argument_spec': {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
        }
    ]

    for test_value in test_values:
        argument_spec_validator_0 = ArgumentSpecValidator(**test_value['argument_spec'])
        parameters_0 = {
            'name': 'bo',
            'age': '42',
        }
        try:
            result_0 = argument_spec_validator_0.validate(parameters_0)
        except Exception as e:
            print(e)
            assert False

        assert result_0.error_messages is None


# Generated at 2022-06-24 20:16:32.023987
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
    }
    argument_spec = {
        'name': {'type': 'str'},
    }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec)
    result = module_argument_spec_validator_0.validate(parameters)
    assert result.validated_parameters == {
        'name': 'bo',
    }, result.validated_parameters



# Generated at 2022-06-24 20:16:36.603807
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {'provider': {'auth_pass': 'pass', 'auth_user': 'user'}, 'name': 'test', 'groups': 'test'}
    result = module_argument_spec_validator_0.validate(parameters)
    (valid_params, result) = result
    assert isinstance(valid_params, dict)
    assert isinstance(result, AnsibleValidationErrorMultiple)
    assert result.messages == []

# Generated at 2022-06-24 20:16:42.396918
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    parameters_0 = {}
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert result_0 is not None
    assert result_0._deprecations == []
    assert result_0._no_log_values == set()
    assert result_0._unsupported_parameters == set()
    assert result_0._validated_parameters == {}
    assert result_0._warnings == []
    assert result_0.errors.messages == []
    assert result_0.errors.exceptions == []
    assert result_0.validated

# Generated at 2022-06-24 20:16:44.766192
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert callable(ArgumentSpecValidator.validate)



# Generated at 2022-06-24 20:17:00.892520
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_2 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_3 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_4 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_5 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_6 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_7 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_8 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:04.094173
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # load_fixture() sets up the test conditions
    load_fixture('ArgumentSpecValidator_validate')
    argument_spec = dict()
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec)
    parameters = dict()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result.validated_parameters == dict()
    assert result.warnings == []
    assert result.errors == []

# Generated at 2022-06-24 20:17:08.170769
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # FIXME: See discussion in https://github.com/ansible/ansible/pull/62426#issuecomment-566822180
    # See also https://github.com/ansible/ansible/pull/64153
    assert False, "not implemented"

# Generated at 2022-06-24 20:17:19.006089
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-24 20:17:22.238773
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    try:
        parameters = module_argument_spec_validator.validate(parameters)
    except Exception as e:
        raise Exception('Unit test to validate validate function of class ModuleArgumentSpecValidator')


# Generated at 2022-06-24 20:17:32.115047
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            },
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None,
        )
    result = module_argument_spec_validator_0.validate(
        parameters={
            'name': 'bo',
            'age': '42',
            },
        )
    assert isinstance(result, ValidationResult)
    assert not result.error_messages
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-24 20:17:37.826883
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator_0 = ArgumentSpecValidator()
    parameters_0 = {}
    result = argument_spec_validator_0.validate(parameters_0)
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {}
    assert result.error_messages == []

# Generated at 2022-06-24 20:17:42.238748
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {'path': "/etc/ansible/ansible.cfg"}
    result = module_argument_spec_validator_0.validate(parameters_0)

    assert result.validated_parameters == parameters_0

# Generated at 2022-06-24 20:17:46.266087
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec={})
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    assert result

# Generated at 2022-06-24 20:17:48.193124
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate of class ModuleArgumentSpecValidator"""
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:18:07.099941
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator is not None


# Generated at 2022-06-24 20:18:08.922970
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    module_argument_spec_validator.validate(parameters)


# Generated at 2022-06-24 20:18:10.133857
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: Implement test cases
    # test_case_0()
    pass

# Generated at 2022-06-24 20:18:14.719868
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = {}
    response_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert response_0.validated_parameters == {}
    assert response_0.unsupported_parameters == {}
    assert response_0.error_messages == []

# Generated at 2022-06-24 20:18:20.605368
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result.error_messages == ['success'], "Expected ['success'], but got " + str(result.error_messages)
    assert result.validated_parameters == dict(), "Expected dict(), but got " + str(result.validated_parameters)


# Generated at 2022-06-24 20:18:27.270420
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator.validate(parameters)
    assert result.validated_parameters == parameters
    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()
    assert result._deprecations == []


# Generated at 2022-06-24 20:18:34.009521
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert not result.error_messages
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result.unsupported_parameters == set()


# Generated at 2022-06-24 20:18:45.427303
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validated_parameters_0_0 = {"name": "bo", "age": 42,}
    argument_spec_0_0 = {"name": {"type": "str",}, "age": {"type": "int",},}
    _mutually_exclusive_0_0 = []
    _required_together_0_0 = []
    _required_one_of_0_0 = []
    _required_if_0_0 = []
    _required_by_0_0 = {}
    argument_spec_validator_0_0 = ArgumentSpecValidator(argument_spec_0_0, _mutually_exclusive_0_0, _required_together_0_0, _required_one_of_0_0, _required_if_0_0, _required_by_0_0, )

# Generated at 2022-06-24 20:18:49.048616
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_0 = module_argument_spec_validator_0.validate(parameter)

# Generated at 2022-06-24 20:19:00.652826
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters_1 = dict()

    # Test #1 - no params, no spec
    # Run test with no spec, no params
    # expect: exception raised, invalid function call
    # cleanup: none required
    with pytest.raises(TypeError) as e_1:
        result_1 = module_argument_spec_validator_1.validate(parameters_1)

    # Validate exception message
    assert str(e_1.value) == "validate() missing 1 required positional argument: 'parameters'"

    # Test #2 - no params, spec present
    # Run test with spec, no params
    # expect: exception raised, invalid function call
    # cleanup: none required
    module_argument_spec_validator_2 = ModuleArgument

# Generated at 2022-06-24 20:19:26.527699
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {'foo': 'bar'}
    # Call method validate of class ModuleArgumentSpecValidator and return result
    result = ModuleArgumentSpecValidator.validate(parameter)
    assert result == "actual result"


# Generated at 2022-06-24 20:19:31.978008
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters=[{'key': 'value'}])

    assert hasattr(result, 'errors')
    assert hasattr(result, 'validated_parameters')
    assert hasattr(result, 'unsupported_parameters')

    validated_parameters = result.validated_parameters

    assert validated_parameters is not None
    assert validated_parameters.get('key') == 'value'

# Generated at 2022-06-24 20:19:34.094831
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    arguments_0 = {}
    # validate() returns a ValidationResult object
    validation_result_0 = module_argument_spec_validator_0.validate(arguments_0)


# Generated at 2022-06-24 20:19:36.606098
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate() == false


# Generated at 2022-06-24 20:19:46.406003
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = dict()
    ModuleArgumentSpecValidator_validate_result_0 = module_argument_spec_validator_0.validate(parameters)
    assert ModuleArgumentSpecValidator_validate_result_0.validated_parameters == dict()
    assert ModuleArgumentSpecValidator_validate_result_0.error_messages == []
    assert ModuleArgumentSpecValidator_validate_result_0.unsupported_parameters == set()

# Generated at 2022-06-24 20:19:48.767061
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:19:52.035141
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str'}
    })

    parameters = {
        'name': 'bo'
    }

    result = module_argument_spec_validator.validate(parameters)

    assert result.error_messages == []
    assert result.unsupported_parameters == set()
    assert result.validated_parameters == {'name': 'bo'}



# Generated at 2022-06-24 20:19:53.749200
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:20:00.621696
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    _mutually_exclusive=None
    _required_together=None
    _required_one_of=None
    _required_if=None
    _required_by=None
    argument_spec = {}
    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec,_mutually_exclusive,_required_together,_required_one_of,_required_if,_required_by)
    assert module_argument_spec_validator != None


# Generated at 2022-06-24 20:20:09.052575
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    It should return a new instance of ValidationResult.
    """
    spec = {'option': {'required': True}}

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(spec)
    assert isinstance(module_argument_spec_validator_0, ModuleArgumentSpecValidator)

    result = module_argument_spec_validator_0.validate({'option': 'value'})

    assert isinstance(result, ValidationResult)

    assert result.validated_parameters == {'option': 'value'}



# Generated at 2022-06-24 20:21:06.717755
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = { "key0": {"type": "str"} }
    result = ArgumentSpecValidator(argument_spec=argument_spec).validate({"key0": "value0"})

    print("First check:")
    print("Validating the key0")
    assert result.validated_parameters == {"key0": "value0"}, "The first assert failed!"
    print("Successful!")

    print("Second check:")
    print("Validating the key1")
    try:
      ArgumentSpecValidator(argument_spec=argument_spec).validate({"key1": "value1"})
      assert 0
    except AnsibleValidationErrorMultiple as e:
      print("The 'key1' is not a valid key")
      assert 1
    print("Successful!")


# Generated at 2022-06-24 20:21:12.325726
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

    argument_spec_1 = {"interpreter_python": {"required": True, "type": "str"}}
    parameters_1 = {"interpreter_python": "ansible.module_utils.basic.AnsibleModule"}
    result_1 = module_argument_spec_validator_1.validate(parameters_1)
    # Since we currently dont do anything with the result other than pass it to
    # the module, all we care about is that it doesn't cause an exception.
    # This test could be easily extended to verify the content.
    assert True

# Generated at 2022-06-24 20:21:13.100579
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert 1 == 1, "Failed testing of validate for class ModuleArgumentSpecValidator"

# Generated at 2022-06-24 20:21:15.405181
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = dict()
    test_0 = module_argument_spec_validator_0.validate(parameters_0)
    assert test_0.validated_parameters == dict()
    assert not test_0.errors



# Generated at 2022-06-24 20:21:16.453894
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:21:21.423395
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args_0 = {'type': 'str'}
    args_1 = {'type': 'str'}
    args_2 = None
    args_3 = {'type': 'int'}
    args_4 = None
    args_5 = None
    args_6 = {'type': 'int'}
    args_7 = {'type': 'list', 'elements': 'str'}
    args_8 = None
    args_9 = None
    args_10 = {'type': 'list', 'elements': 'int'}
    args_11 = {'type': 'dict', 'options': {'first_name': args_0, 'last_name': args_1, 'age': args_3, 'birthdate': args_6}}

# Generated at 2022-06-24 20:21:27.037725
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator_0, ArgumentSpecValidator)
    if hasattr(Test_ArgumentSpecValidator, "assert_raises"):
        with Test_ArgumentSpecValidator.assert_raises(TypeError):
            result = module_argument_spec_validator_0.validate()
    else:
        with pytest.raises(TypeError):
            result = module_argument_spec_validator_0.validate()



# Generated at 2022-06-24 20:21:29.184969
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


if __name__ == "__main__":
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-24 20:21:41.022577
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters_0 = {'ip': '1.2.3.4'}
    mutually_exclusive_0 = [['ip', 'hostname']]
    required_together_0 = None
    required_one_of_0 = None
    required_if_0 = None
    required_by_0 = None
    argument_spec_0 = {'hostname': {'type': 'str'}, 'ip': {'type': 'str'}, 'password': {'type': 'str', 'no_log': True}}
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec_0, mutually_exclusive_0, required_together_0, required_one_of_0, required_if_0, required_by_0)

# Generated at 2022-06-24 20:21:49.189262
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Arrange
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)

    # Act
    result = validator.validate(parameters)

    # Assert
    assert result.error_messages == []
    assert result.validated_parameters["age"] == 42


# Generated at 2022-06-24 20:23:42.574012
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate(parameters="null") is None


# Generated at 2022-06-24 20:23:44.560745
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:23:47.956307
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = { 'ansible_user': 'str ', }
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters)
    assert result == parameters


# Generated at 2022-06-24 20:23:51.308646
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameter_0 = {}
    exception_0 = None
    try:
        module_argument_spec_validator_0.validate(parameter_0)
    except Exception as exception_0:
        pass
    return exception_0


# Generated at 2022-06-24 20:23:57.300734
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = deepcopy(VALID_ARGUMENT_SPEC)
    params.update({'name': 'bo', 'age': '42'})
    asv = ArgumentSpecValidator(VALID_ARGUMENT_SPEC)
    res = asv.validate(params)
    assert len(res.errors) == 0, "errors: %s" % res.errors
    assert res.validated_parameters['age'] == 42, "validated parameters: %s" % res.validated_parameters
    assert res.validated_parameters['name'] == 'bo', "validated parameters: %s" % res.validated_parameters

    params = deepcopy(VALID_ARGUMENT_SPEC)
    asv = ArgumentSpecValidator(VALID_ARGUMENT_SPEC)
    res = asv.valid

# Generated at 2022-06-24 20:24:07.430412
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    passed = True

    dict_1 = dict()
    dict_1['fqdn'] = dict()
    dict_1['fqdn']['default'] = 'foo'
    dict_1['fqdn']['type'] = 'str'
    dict_1['usage'] = dict()
    dict_1['usage']['choices'] = ['foo', 'bar']
    dict_1['usage']['type'] = 'str'
    try:
        module_argument_spec_validator_0.validate(dict_1)
        passed = True
    except Exception as e:
        passed = False

    assert passed

    dict_1['usage'] = dict()

# Generated at 2022-06-24 20:24:08.359824
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:24:13.936372
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Note that it's up to the caller to make sure the result is sanitized first
    parameters = dict()
    assert isinstance(module_argument_spec_validator_0.validate(parameters), ValidationResult)


# Generated at 2022-06-24 20:24:17.617216
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec=dict())
    assert module_argument_spec_validator is not None


# Generated at 2022-06-24 20:24:20.367235
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate()

test_case_0()