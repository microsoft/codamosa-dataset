

# Generated at 2022-06-24 20:15:05.555710
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    args = dict()
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(**args)

    parameters = dict()
    result_0 = module_argument_spec_validator_0.validate(**parameters)
    assert result_0 == result_0


# Generated at 2022-06-24 20:15:10.965340
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Case 0
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    argument_spec_1 = {'argument_spec_1': dict(type='str')}
    parameters_1 = {'argument_spec_1': 'str'}
    result_0 = module_argument_spec_validator_0.validate(parameters_1)
    assert 'errors' in result_0
    assert isinstance(result_0.errors, list)
    assert len(result_0.errors) == 0


# Generated at 2022-06-24 20:15:15.314289
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Test using temporary file as input
    parameters = {}
    return_value = module_argument_spec_validator_0.validate(parameters)
    assert return_value is not None
    assert return_value._validated_parameters is not None


# Generated at 2022-06-24 20:15:18.422768
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:15:24.649948
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        module_argument_spec_validator_1 = ArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None, required_by=None)
    except:
        print("Failed to create object of class ArgumentSpecValidator")
        raise


# Generated at 2022-06-24 20:15:30.619198
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    # Assigning some values to parameters for tetsing
    parameters_1 = {
        'name': 'bo',
        'age': '42',
    }
    # Invoking the validate method using the above defined arguments
    # Expected Result:
    # Results in validation error
    module_argument_spec_validator_1.validate(parameters_1)

# Generated at 2022-06-24 20:15:37.070589
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # _valid_parameter_names = set()
    # argument_spec = {}
    # mutually_exclusive = None
    # required_together = None
    # required_one_of = None
    # required_if = None
    # required_by = None

    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    argument_spec = {}
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)


# Generated at 2022-06-24 20:15:48.092205
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Testing with invalid input
    # 1. argument_spec is None
    with pytest.raises(AnsibleValidationErrorMultiple) as excinfo:
        module_argument_spec_validator_1 = ArgumentSpecValidator(argument_spec=None)
    assert excinfo.match("Missing required 'argument_spec'")

    # 2. argument_spec is not a dict
    with pytest.raises(AnsibleValidationErrorMultiple) as excinfo:
        module_argument_spec_validator_2 = ArgumentSpecValidator(argument_spec=['name', 'Type', 'str', 'Name of the job.'])
    assert excinfo.match("Missing required 'argument_spec'")

    # Testing with different combinations of argument_spec
    # 1. argument_spec with single core param

# Generated at 2022-06-24 20:15:54.389032
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Initialize parameters
    parameters = {}

    # Call method
    try:
        ModuleArgumentSpecValidator().validate(parameters)
    except Exception as e:
        err = str(e)

    # Check results
    assert err == "An argument spec is required to use the validator."


# Generated at 2022-06-24 20:16:00.643164
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_validation_result_0 = ValidationResult({})
    argument_spec_validator_validate_0 = ArgumentSpecValidator()
    argument_spec_validator_validate_0.validate(module_validation_result_0)


if __name__ == "__main__":
    try:
        import ansible_module_utils.common.arg_spec.test
        ansible_module_utils.common.arg_spec.test.test_main()
    except ImportError:
        pass

# Generated at 2022-06-24 20:16:10.320547
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    _validator = ArgumentSpecValidator({'name': {'type': 'str'}}, None, None, None, None, None)
    assert _validator.validate({'name': 'bo'}).validated_parameters == {'name': 'bo'}



# Generated at 2022-06-24 20:16:13.768079
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Declare argument_spec
    argument_spec = {}
    # create instance of ArgumentSpecValidator
    argument_spec_validator_0 = ArgumentSpecValidator(argument_spec)

    parameters = {}
    # call validate
    argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:16:20.418974
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()

    # Test default value for parameter parameters of method validate
    # of class ModuleArgumentSpecValidator
    # Error: Missing argument 'parameters'
    # module_argument_spec_validator.validate()
    # Test with a valid value for parameter parameters of method validate
    # of class ModuleArgumentSpecValidator
    parameters = {
        'x': 1,
        'y': 2
    }
    module_argument_spec_validator.validate(parameters)
    # Test with a valid value for parameter parameters of method validate
    # of class ModuleArgumentSpecValidator
    parameters = {
        "name": "Bob",
        "age": 42,
        "charlie": "hurray"
    }

# Generated at 2022-06-24 20:16:26.804471
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters)
    assert(result.error_messages == [])


# Generated at 2022-06-24 20:16:28.994432
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = {"name": "Hans"}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(params)
    assert result.errors == []

# Generated at 2022-06-24 20:16:33.726421
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        module_argument_spec_validator_0 = ModuleArgumentSpecValidator({'required': True}, required_together=[['foo', 'bar'], ['foo', 'baz'], ['bar', 'baz']], required_one_of=[['foo', 'bar']], required_if=[['foo', 'bar', 'bar', 'foo']])
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:16:42.080799
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    exception = TypeError()
    try:
        module_argument_spec_validator_0.validate(parameters)
    except TypeError as exception_1:
        exception = exception_1
    except TypeError:
        exception_1 = TypeError()
        if (exception_1 != exception):
            raise AssertionError(exception_1)


# Generated at 2022-06-24 20:16:51.749947
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result_validate_0 = module_argument_spec_validator_0.validate()
    assert result_validate_0 is not None
    assert result_validate_0._unsupported_parameters is not None
    assert isinstance(result_validate_0._unsupported_parameters, set)
    assert result_validate_0.errors is not None
    assert isinstance(result_validate_0.errors, AnsibleValidationErrorMultiple)
    assert result_validate_0.validated_parameters is not None
    assert isinstance(result_validate_0.validated_parameters, dict)


# Generated at 2022-06-24 20:16:57.537079
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-24 20:16:58.862713
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator


# Generated at 2022-06-24 20:17:18.076979
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    argument_spec_validator_0 = ArgumentSpecValidator()

    result = argument_spec_validator_0.validate({})
    assert result.error_messages == []
    assert result.validated_parameters == {}

    result = argument_spec_validator_0.validate(dict(name='bo', age='42'))
    assert result.error_messages == []
    assert result.validated_parameters == dict(name='bo', age=42)

    # sub spec
    result = argument_spec_validator_0.validate(dict(name='bo', age='42', sub=dict(a=1, b='2')))
    assert result.error_messages == []
    assert result.validated_parameters

# Generated at 2022-06-24 20:17:18.964422
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    test_case_0()

# Generated at 2022-06-24 20:17:19.493481
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
   pass

# Generated at 2022-06-24 20:17:26.117475
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['foo', 'bar'],
        ['baz', 'quux'],
    ]
    required_together = [
        ['foo', 'bar'],
        ['baz', 'quux'],
    ]
    required_one_of = [
        ['foo', 'bar'],
        ['baz', 'quux'],
    ]
    required_if = [
        ['foo', 'bar', ['baz', 'quux']],
        ['baz', 'quux', ['foo', 'bar']],
    ]

# Generated at 2022-06-24 20:17:28.439046
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:17:30.329095
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters_0 = dict()

# Generated at 2022-06-24 20:17:40.406613
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Given
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    parameters = {
        'param_2': 3,
        'param_1': '1',
        'param_0': '0',
    }

    # When
    result = module_argument_spec_validator_0.validate(parameters)

    # Then
    assert result._validated_parameters == {
        'param_2': 3,
        'param_1': '1',
        'param_0': '0',
    }


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:17:41.708667
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()

# Generated at 2022-06-24 20:17:48.966182
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test validate of class ArgumentSpecValidator"""
    validator = ArgumentSpecValidator(argument_spec={},
                                      mutually_exclusive=[],
                                      required_together=[],
                                      required_one_of=[],
                                      required_if=[],
                                      required_by=[])
    result = validator.validate({})
    assert isinstance(validator, ArgumentSpecValidator)
    assert isinstance(result, ValidationResult)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.validated_parameters == {}
    assert result.error_messages == []
    assert result.unsupported_parameters == set

# Generated at 2022-06-24 20:17:51.605087
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate("parameters")
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-24 20:18:03.398946
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {'name': 'bo', 'age': '42'}
    result = module_argument_spec_validator_0.validate(parameters)
    result_sanitized = sanitize_keys(result._validated_parameters, result._no_log_values)
    assert result_sanitized == {'name': 'bo', 'age': 42}

# Generated at 2022-06-24 20:18:08.439150
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Arrange
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # Act
    module_argument_spec_validator_0.validate(parameters)
    # Assert

# Generated at 2022-06-24 20:18:16.772716
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-24 20:18:27.634258
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    parameters = {}

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    # Testing exception raise while validating due to error in super class
    # Create object of ModuleArgumentSpecValidator and assign params to it
    # Call method validate of class ModuleArgumentSpecValidator with args
    # Assertion: check that error is not generated
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = None
    required_together = None


# Generated at 2022-06-24 20:18:32.562899
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  argument_spec = {
      'name': {'type': 'str'},
      'age': {'type': 'int'},
  }

  parameters = {
      'name': 'bo',
      'age': '42',
  }

  validator = ArgumentSpecValidator(argument_spec)
  result = validator.validate(parameters)


# Generated at 2022-06-24 20:18:37.698544
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = None
    result = module_argument_spec_validator.validate(parameters)

### END OF TESTS

# Generated at 2022-06-24 20:18:41.376502
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-24 20:18:43.849459
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {}
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []


# Generated at 2022-06-24 20:18:46.340239
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # xfail
    """
    unit test for validate of class ModuleArgumentSpecValidator
    """
    # TODO: Unit test this method


# Generated at 2022-06-24 20:18:58.248074
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-24 20:19:16.357514
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator(None, None, None, None, None, None)
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)
    result.error_messages


# Generated at 2022-06-24 20:19:17.527925
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec_validator_0 = ArgumentSpecValidator()


# Generated at 2022-06-24 20:19:27.337756
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    parameters_0 = dict()
    parameters_0['parameters'] = dict()
    parameters_0['parameters']['name'] = dict()
    parameters_0['parameters']['name']['type'] = 'str'
    parameters_0['parameters']['age'] = dict()
    parameters_0['parameters']['age']['type'] = 'int'
    parameters_0['parameters'] = dict()
    parameters_0['parameters']['name'] = 'bo'
    parameters_0['parameters']['age'] = '42'
    assert type(module_argument_spec_validator_0.validate(parameters_0['parameters'])) is ValidationResult

# Generated at 2022-06-24 20:19:34.295075
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters_0 = [
        'test0'
    ]
    parameters_1 = {
        'test1': 0
    }
    parameters_2 = [
        'test2',
        'test3',
        'test4'
    ]
    result_0 = module_argument_spec_validator_0.validate(parameters_0)
    result_1 = module_argument_spec_validator_0.validate(parameters_1)
    result_2 = module_argument_spec_validator_0.validate(parameters_2)
    # The assertEqual() method is used to compare two values.
    assertEqual(result_0, result_1)
    assertEqual(result_2, parameters_2)

# Generated at 2022-06-24 20:19:38.239924
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()

    parameters = {"CONFLICT_PREFIX": "fails the _check_conflicts test", "name": "test", "age": "test"}
    assert module_argument_spec_validator_0.validate(parameters)

# Generated at 2022-06-24 20:19:42.516688
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert not module_argument_spec_validator_0.validate('parameters')


# Generated at 2022-06-24 20:19:50.181150
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    global result_ArgumentSpecValidator_validate
    result_ArgumentSpecValidator_validate = 0
    for test_case in test_cases_ArgumentSpecValidator_validate:
        validation_result = test_case_0()
        print(validation_result)
        if str(validation_result) == str(test_case['result']):
            result_ArgumentSpecValidator_validate += 1

print("Result of testing method validate of class ArgumentSpecValidator is: " + str(result_ArgumentSpecValidator_validate) + "/" + str(len(test_cases_ArgumentSpecValidator_validate)))

# Generated at 2022-06-24 20:20:01.150211
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = dict(
        name=dict(type='str', aliases=['full_name']),
        age=dict(type='int', aliases=['years']),
    )
    merged_params = dict(
        name='joe',
        age='10',
    )
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(merged_params)

    assert result.validated_parameters == {'name': 'joe', 'age': 10}
    assert len(result.errors) == 1, "Wrong error count"
    assert isinstance(result.errors[0], UnsupportedError), "Wrong error type"
    assert len(result.error_messages) == 1, "Wrong error message count"

# Generated at 2022-06-24 20:20:03.820016
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0


# Generated at 2022-06-24 20:20:08.727903
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-24 20:20:44.249531
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO:
    # argument_spec = {'aliases': {'type': 'list', 'aliases': ['commands']}, 'type': 'list', 'elements': 'str'}
    # mutually_exclusive = None
    # required_together = None
    # required_one_of = None
    # required_if = None
    # required_by = None
    assert False


# Generated at 2022-06-24 20:20:49.804969
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test using a mock object
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.parameters import sanitize_keys
    # Test arg spec

# Generated at 2022-06-24 20:20:52.088807
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    try:
        module_argument_spec_validator_0.validate()
    except TypeError:
        pass

# Generated at 2022-06-24 20:20:54.965881
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    test_case_0()


# Generated at 2022-06-24 20:21:02.475434
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    # Initializing validator with a new argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    module_argument_spec_validator_0.argument_spec = argument_spec
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_0.validate(parameters)
    assert result.validated_parameters is not None



# Generated at 2022-06-24 20:21:06.334056
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    specs = dict(
        argument_spec = dict(
            type='str',
            aliases=['test_alias1', 'test_alias2']
        )
    )
    parms = dict(
        argument_spec = 1
    )
    validator = ArgumentSpecValidator(specs)
    validation_result = validator.validate(parms)
    assert len(validation_result.errors) == 1 and isinstance(validation_result.errors[0], AliasError)


# Generated at 2022-06-24 20:21:07.623494
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:21:13.495085
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # For test case number 0
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert module_argument_spec_validator_0.validate(None) == None


# Generated at 2022-06-24 20:21:15.426751
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_t = ModuleArgumentSpecValidator()
    parameters = {}
    ans = module_argument_spec_validator_t.validate(parameters)
    assert ans is not None


# Generated at 2022-06-24 20:21:19.679981
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()


# Generated at 2022-06-24 20:21:48.937135
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    assert isinstance(module_argument_spec_validator, ModuleArgumentSpecValidator)

    try:
        assert module_argument_spec_validator is not None
    except AssertionError as e:
        raise AssertionError(str(e))
    else:
        assert True


# Generated at 2022-06-24 20:21:54.849137
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arguments = {"Age": {"required": False, "type": "int"}, "Name": {"required": True, "type": "str"}}

    # testcode begin
    spec_validator = ModuleArgumentSpecValidator(
        {"Age": {"required": False, "type": "int"}, "Name": {"required": True, "type": "str"}}
    )
    parameters = {"Age": "42", "Name": "Albert"}
    result = spec_validator.validate(parameters)
    # testcode end

    assert result.error_messages == []
    assert result.validated_parameters == {"Age": 42, "Name": "Albert"}
    assert result.unsupported_parameters == set()


# Generated at 2022-06-24 20:21:59.305637
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Prepare mock args
    parameters = ['hello']

    # Run method
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate(parameters=parameters)
    assert result == None



# Generated at 2022-06-24 20:22:02.119471
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate({})
    assert result.validated_parameters == {}
    assert result.error_messages == []


# Generated at 2022-06-24 20:22:04.914459
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    assert (isinstance(module_argument_spec_validator_0.validate(), ValidationResult))



# Generated at 2022-06-24 20:22:06.845309
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()



# Generated at 2022-06-24 20:22:07.446543
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-24 20:22:08.195772
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True


# Generated at 2022-06-24 20:22:15.246231
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_object = ModuleArgumentSpecValidator({'test_dict': {'type': 'dict'}})
    parameters = {'test_dict': 'value'}
    
    #call the method 
    result = module_argument_spec_validator_object.validate(parameters)
    assert(len(result.errors)==1)
    assert(result.errors[0].message == "argument 'test_dict' is of type <class 'str'> and we were unable to convert to <class 'dict'>. Error was: not convertible to a dictionary.")


# Generated at 2022-06-24 20:22:18.217804
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # TODO: Add additional tests
    assert test_case_0()

# Generated at 2022-06-24 20:23:21.574275
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator.validate(parameters)


# Generated at 2022-06-24 20:23:25.192506
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    # We do not have a good way to unit test this method.

# Generated at 2022-06-24 20:23:26.888585
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    result = module_argument_spec_validator_0.validate({})

# Generated at 2022-06-24 20:23:29.224694
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ArgumentSpecValidator()
    assert (isinstance(module_argument_spec_validator_0.validate({}), ValidationResult))



# Generated at 2022-06-24 20:23:31.953832
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    module_argument_spec_validator_0.validate()


# Generated at 2022-06-24 20:23:41.991461
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameters = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    argument_spec = {'type': 'int', 'required': True}

    argument_spec_validator = ArgumentSpecValidator(argument_spec,
                                                    mutually_exclusive,
                                                    required_together,
                                                    required_one_of,
                                                    required_if,
                                                    required_by)
    result = argument_spec_validator.validate(parameters)
    assert result.errors - result.errors._we_raised == {RequiredError('Missing required argument: type')}
    assert result.validated_parameters == {}


# Generated at 2022-06-24 20:23:47.163695
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_1 = ModuleArgumentSpecValidator()
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = module_argument_spec_validator_1.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-24 20:23:52.604302
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec_0 = {
        'password': {
            'required': False,
            'type': 'str',
            'no_log': False
        },
        'name': {
            'required': True,
            'type': 'str',
            'no_log': False
        }
    }

    parameters_0 = {
        'password': 'password',
        'name': 'name'
    }

    parameter_validator_0 = ModuleArgumentSpecValidator(argument_spec_0)
    parameter_validator_0.validate(parameters=parameters_0)

# Generated at 2022-06-24 20:23:54.911487
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()
    parameters = {}
    result = module_argument_spec_validator_0.validate(parameters)


# Generated at 2022-06-24 20:23:56.224838
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator_0 = ModuleArgumentSpecValidator()