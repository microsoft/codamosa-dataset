

# Generated at 2022-06-22 21:19:58.894136
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:20:00.914880
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(None)

# Generated at 2022-06-22 21:20:04.722173
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(argument_spec={'foo': {'type': 'int'}})
    assert result.argument_spec == {'foo': {'type': 'int'}}

# Generated at 2022-06-22 21:20:15.258327
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert_equals(type(result), ValidationResult)
    assert_equals(result.error_messages, [])
    assert_equals(result.validated_parameters, {'name': 'bo', 'age': 42})
    assert_equals(result.unsupported_parameters, set())
    assert_equals(result._no_log_values, set())
    assert_equals(result.errors, AnsibleValidationErrorMultiple())



# Generated at 2022-06-22 21:20:21.697312
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    # Test Init with parameters
    parameters = {'test': 'parameters'}
    vr = ValidationResult(parameters)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == parameters
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors == AnsibleValidationErrorMultiple()


# Unit Test for attributes of class ValidationResult

# Generated at 2022-06-22 21:20:23.594815
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod_arg_v = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert mod_arg_v is not None

# Generated at 2022-06-22 21:20:24.911381
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator('mod_arg')

# Generated at 2022-06-22 21:20:35.373051
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    input_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    input_mutually_exclusive = None
    input_required_together = None
    input_required_one_of = None
    input_required_if = None
    input_required_by = None

    validator = ArgumentSpecValidator(input_argument_spec, input_mutually_exclusive, input_required_together,
                                      input_required_one_of, input_required_if, input_required_by)
    assert validator.argument_spec == input_argument_spec
    assert validator._mutually_exclusive == input_mutually_exclusive
    assert validator._required_together == input_required_together
    assert validator._required_one_of == input_required

# Generated at 2022-06-22 21:20:46.084341
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Test for module_utils/common/arg_spec.py:ModuleArgumentSpecValidator
    """

    from ansible.module_utils.common.removed import removed_module

# Generated at 2022-06-22 21:20:49.690710
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'first_name': 'Jan', 'last_name': 'De Vos'}
    validation_result = ValidationResult(parameters)
    assert validation_result.validated_parameters == parameters

# Generated at 2022-06-22 21:20:52.569629
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'ansible_user': {'type': 'str'}})
    assert validator


# Generated at 2022-06-22 21:21:04.116121
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    def test_func(name, expected_errors, mutually_exclusive=None,
                  required_together=None, required_one_of=None, required_if=None,
                  argument_spec=None, expected_validated_params=None, parameters=None):
        # pylint: disable=too-many-statements,too-many-locals,too-many-branches,too-many-arguments
        validator = ArgumentSpecValidator(argument_spec, mutually_exclusive,
                                          required_together, required_one_of,
                                          required_if)
        result = validator.validate(parameters)
        if expected_validated_params is None:
            expected_validated_params = parameters

        assert result.error_messages == expected_errors
        assert result.validated_parameters == expected_valid

# Generated at 2022-06-22 21:21:12.151345
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'nested': {'type': 'dict', 'options': {'nested_name': {'type': 'str'}}},
        'list_nested': {'type': 'list', 'elements': {'type': 'dict',
                                                     'options': {'list_nested_name': {'type': 'str'}}}}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'nested': {'nested_name': 'foo'},
        'list_nested': [{'list_nested_name': 'bar'}]
    }

    validator = ArgumentSpecValidator(argument_spec)
    result

# Generated at 2022-06-22 21:21:23.643925
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == [], 'error_messages is not empty!'
    assert result.validated_parameters['name'] == 'bo', 'validated_parameters[\'name\'] is not \'bo\'!'
    assert result.validated_parameters['age'] == 42, 'validated_parameters[\'age\'] is not 42!'
    assert result.unsupported_parameters == set(), 'unsupported_parameters is not empty!'

# Generated at 2022-06-22 21:21:32.944297
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert_spec_equal(
        validator=ArgumentSpecValidator(dict(
            name=dict(type='str'),
            age=dict(type='int'),
        )),

        parameters=dict(
            name='bo',
            age=42,
        ),

        validated=dict(
            name='bo',
            age=42,
        ),

        messages=[],
    )

    assert_spec_equal(
        validator=ArgumentSpecValidator(dict(
            name=dict(type='str'),
            age=dict(type='int'),
        )),

        parameters=dict(
            name='bo',
            age='42',
        ),

        validated=dict(
            name='bo',
            age=42,
        ),

        messages=[],
    )


# Generated at 2022-06-22 21:21:35.449688
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({'foo': {'type': 'bool'}}) is not None


# Generated at 2022-06-22 21:21:42.387513
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=[['test']])
    result = validator.validate(parameters)
    assert result.validated_parameters['age'] == 42
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-22 21:21:53.929985
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [["name", "age"]]
    required_if = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_by = {"name": ["age"], "age": ["name"]}

    assert ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                 required_together=required_together,
                                 required_if=required_if,
                                 required_one_of=required_one_of,
                                 required_by=required_by) is not None



# Generated at 2022-06-22 21:22:05.960164
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    args = {'arg1': {'type': 'int', 'required': True, 'fallback': (0, '0', 'zero'), 'default': 0},
            'arg2': {'type': 'list', 'default': ['list argument']},
            'arg3': {'type': 'str', 'required': True},
            'arg4': {'type': 'str', 'default': 'hello', 'aliases': ['arg5']}}
    mutually_exclusive = [['arg1', 'arg3']]
    required_together = [('arg1', 'arg3')]
    required_one_of = [('arg1',)]
    required_if = (('arg1', 2, ['arg4']), ('arg2', 'list argument', ['arg3']))

# Generated at 2022-06-22 21:22:16.859948
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = {
        'name': {
            'type': 'str',
            'aliases': ['ansible_name']
        },
        'age': {
            'type': 'int',
            'required': True
        },
        'school': {
            'type': 'str',
            'default': 'MUST',
            'required': True
        },
        'city': {
            'type': 'dict',
            'required': True
        }
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'ansible_name': 'bo2',
        'school': '',
        'city': {
            'name': 'Seoul',
            'population': 10.5
        }
    }

    validator = ModuleArgumentSpecValidator(spec)
   

# Generated at 2022-06-22 21:22:28.004570
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    def verify_default_argument_function(function, parameter_name, error_type):
        try:
            function(None)
        except error_type as e:
            assert parameter_name in str(e)

    # Test that None values do not get passed into the constructor.
    validator = ModuleArgumentSpecValidator({})
    for attr in ['UNSUPPORTED_ARGUMENTS', 'mutually_exclusive', 'required_one_of', 'required_together', 'required_if', 'required_by']:
        verify_default_argument_function(getattr(validator, attr), attr, AttributeError)

    # Test that the UNSUPPORTED_ARGUMENTS attribute is set to the empty list.
    assert validator.UNSUPPORTED_ARGUMENTS == []

# Generated at 2022-06-22 21:22:33.089808
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({
        'name': 'bo',
        'age': '42',
    })
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters ==  {'name': 'bo', 'age': '42'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-22 21:22:43.902917
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Test 1: argument_spec and mutually_exclusive arguments
    try:
        ModuleArgumentSpecValidator({'test': {'type': 'str'}}, mutually_exclusive=['test'])
    except AttributeError:
        pass
    else:
        raise AssertionError('Failed: argument_spec and mutually_exclusive arguments')

    # Test 2: argument_spec, mutually_exclusive and required_together arguments
    try:
        ModuleArgumentSpecValidator({'test': {'type': 'str'}},
                                    mutually_exclusive=['test'], required_together=['test'])
    except AttributeError:
        pass
    else:
        raise AssertionError('Failed: argument_spec, mutually_exclusive and required_together arguments')

    # Test 3: argument_spec, mutually_exclusive and required_one_of

# Generated at 2022-06-22 21:22:49.919836
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters['age'] == 42
    assert len(result._no_log_values) == 0
    assert not result._unsupported_parameters

# Generated at 2022-06-22 21:22:58.910130
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ansible_fqcn = "ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator"
    assert ansible_fqcn == "ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator", "ansible_fqcn is a string"
    moduledoc = ansible_fqcn.rsplit('.', 1)[-1]
    module = globals().get(moduledoc)
    assert module, '<ansible.module_utils.common.arg_spec.ModuleArgumentSpecValidator> module not found'
    arg_spec = module.__init__.__dict__['__annotations__']

# Generated at 2022-06-22 21:23:11.068226
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:23:15.683285
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils import basic

    basic.AnsibleModule(argument_spec={'foo': {'type': 'bool', 'default': False, 'required': False}})
    assert True

# Generated at 2022-06-22 21:23:18.348654
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    parameters = {
                    'name': 'bo',
                    'age': '42',
                  }

    res = ValidationResult(parameters)

    valid_parameters = res.validated_parameters
    assert valid_parameters == parameters


# Generated at 2022-06-22 21:23:19.146180
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "not implemented"

# Generated at 2022-06-22 21:23:21.293345
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert type(validator) == ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:23:30.432829
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({}) is not None
    assert ArgumentSpecValidator({}, mutually_exclusive=['test']) is not None
    assert ArgumentSpecValidator({}, required_together=[['test']]) is not None
    assert ArgumentSpecValidator({}, required_one_of=[['test']]) is not None
    assert ArgumentSpecValidator({}, required_if=[['test', 'test', ['test']]]) is not None
    assert ArgumentSpecValidator({}, required_by={'test': ['test']}) is not None


# Generated at 2022-06-22 21:23:34.239061
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    parameters = dict(
        name=dict(type='str'),
        age=dict(type='int')
    )

    result = ValidationResult(parameters)

    assert result.validated_parameters == parameters



# Generated at 2022-06-22 21:23:40.257332
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo'}
    result = ValidationResult(parameters)

    assert result.validated_parameters == {}
    assert result.errors == []
    assert result.error_messages == []
    assert result._no_log_values == []
    assert result._unsupported_parameters == []


# Generated at 2022-06-22 21:23:44.154460
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str'
        },
        'age': {
            'type': 'int'
        }
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None


# Generated at 2022-06-22 21:23:54.519903
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set

    # Test to make sure the Validation Result class has the expected attributes
    val_res = ValidationResult({
        'name': 'John Smith',
        'age': 42
    })

    assert is_set(val_res._no_log_values)
    assert val_res._no_log_values == set()
    assert is_set(val_res._unsupported_parameters)
    assert val_res._unsupported_parameters == set()
    assert val_res._validated_parameters == {
        'name': 'John Smith',
        'age': 42
    }
    assert is_sequence(val_res.errors)
    assert val_res.errors == []

# Generated at 2022-06-22 21:23:55.677509
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({}) is not None

# Generated at 2022-06-22 21:24:04.243843
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    para = {'name':'test','age':24}
    validationResult = ValidationResult(para)
    assert validationResult._validated_parameters == para
    assert validationResult.error_messages == []
    assert validationResult._deprecations == []
    assert validationResult._warnings == []
    assert validationResult.errors == []
    assert validationResult._no_log_values == set()
    assert validationResult._unsupported_parameters == set()


# Generated at 2022-06-22 21:24:14.373169
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'info': {'type': 'dict',
                 'options': {'name': {'type': 'str'},
                             'age': {'type': 'int'}}},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'info': {'name': 'bo',
                 'age': '42',
                 'extra': 'no_extra'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters

# Generated at 2022-06-22 21:24:17.148987
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validation = ValidationResult(parameters)
    assert validation._validated_parameters == parameters

# Generated at 2022-06-22 21:24:25.484148
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:24:31.131672
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    class FakeModule:
        def __init__(self):
            self.argument_spec = {
                "key1": {
                    "type": "str",
                    "removed_in_version": "10.0.0",
                },
                "key2": {
                    "type": "int"
                },
                "key3": {
                    "type": "str",
                    "aliases": ["key4"],
                },
            }

    m = FakeModule()
    validator = ModuleArgumentSpecValidator(m.argument_spec)
    assert validator
    result = validator.validate({})
    assert result



# Generated at 2022-06-22 21:24:38.994572
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    validator = ArgumentSpecValidator(
        {
            "name": {"type": "str", "default": "bo"},
            "age": {"type": "int"},
        },
        required_if=[["name", "bo", ["age"]]]
    )

    result = validator.validate({"name": "bo"})
    assert result.errors
    assert len(result.errors) == 1
    assert "required when name is bo" in result.errors[0].msg

    result = validator.validate({"name": "bo", "age": "42"})
    assert result.errors
    assert len(result.errors) == 1
    assert "expected one of" in result.errors[0].msg

    result = validator.validate({"name": "bo", "age": 42})
    assert not result.errors



# Generated at 2022-06-22 21:24:51.500614
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.validation import check_required_together, check_required_one_of, check_required_if, check_required_by

    mutually_exclusive = [['a', 'b']]
    required_together = [['b', 'c']]
    required_one_of = [['c', 'd']]
    required_if = ['e', 'f', 'g']
    required_by = {'g': ['h']}

    argument_spec = {}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by,
                                      )

   

# Generated at 2022-06-22 21:24:59.767664
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameter_spec = {
        'name': 'bo',
        'age': '42',
    }

    v = ArgumentSpecValidator(argument_spec)
    result = v.validate(parameter_spec)

    valid_params = result.validated_parameters
    assert valid_params['name'] == parameter_spec['name']
    assert valid_params['age'] == parameter_spec['age']

# Generated at 2022-06-22 21:25:00.628230
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    o = ValidationResult({}) # No error is expected

# Generated at 2022-06-22 21:25:10.023339
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import unittest
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.params import ModuleValidationException

    np = False
    try:
        from numpy import ndarray
        np = True
    except ImportError:
        np = False

    class FakeModule:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def fail_json(self, **kwargs):
            raise ModuleValidationException(**kwargs)

        def exit_json(self, **kwargs):
            raise NotImplementedError

        def fail_on_missing_params(self, *args):
            return False


# Generated at 2022-06-22 21:25:19.318384
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = dict(
        filter=dict(
            aliases=['pattern']
        )
    )
    mutually_exclusive = [['pattern', 'filter']]
    parameters = dict(
        pattern='*.txt'
    )

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.error_messages == []

    deprecation_lines = result._deprecations[0]['msg'].split("\n")
    assert deprecation_lines[0] == "Alias 'pattern' is deprecated."
    # Add the following to the existing testcase when the deprecation becomes warning
    # assert deprecation_lines[-1] == "Deprecation warnings can be disabled by setting"
    # assert deprec

# Generated at 2022-06-22 21:25:26.650531
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    result = ValidationResult(parameters)

    assert result._no_log_values == set()
    assert result._validated_parameters == {
        'name': 'bo',
        'age': '42'
    }
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:25:38.986447
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    def test_instance(obj):
        # Function to test if an object is an instance of a class
        if isinstance(obj, ModuleArgumentSpecValidator):
            return True
        return False

    # Testing if return value of validate method is an instance of ModuleArgumentSpecValidator
    # Test file tmp_h__mznMQ_test_mate_valid.py
    argument_spec = {'a': {'type': 'str', 'default': 'a_default'}}
    parameters = {'a': 'a_value'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert test_instance(result)

    # Testing if required error is raised by validate method
    # Test file tmp_h__mznMQ_test_mate_valid.py
    argument

# Generated at 2022-06-22 21:25:46.265819
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    print(result)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}





# Generated at 2022-06-22 21:25:55.012106
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-22 21:25:59.362826
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)

    if result == None:
        raise AssertionError('result is None')

    if result._validated_parameters != parameters:
        raise AssertionError('parameters does not match: ' + str(result._validated_parameters))

# Generated at 2022-06-22 21:26:03.581414
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit test for constructor of class ModuleArgumentSpecValidator"""
    assert not hasattr(ModuleArgumentSpecValidator, 'validate')
    assert hasattr(ModuleArgumentSpecValidator, '_validate')
    assert hasattr(ModuleArgumentSpecValidator, '__init__')

# Generated at 2022-06-22 21:26:15.743904
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import sys

    from ansible.module_utils.common.parameters import sanitize_keys

    # this module is used to test our argument validation, so we disable its own argument checks
    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs['argument_spec'] = dict()
            super(TestModule, self).__init__(*args, **kwargs)


# Generated at 2022-06-22 21:26:23.652635
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # noinspection PyUnusedLocal
    def dummy_method(a):
        return

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'str'},
        'into': {'type': 'str'},
        'not_required': {'type': 'str', 'required': False},
        'other': {'type': 'str'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'into': 'house'
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == parameters



# Generated at 2022-06-22 21:26:28.252154
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test the ValidationResult class with a simple case."""
    result = ValidationResult({})
    assert not result.errors
    assert not result.unsupported_parameters
    assert not result.error_messages



# Generated at 2022-06-22 21:26:36.705091
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

    argument_spec = {'a': {'type': 'int'}}

    # if the argument_spec is not of type dict, it should raise an exception
    with basic.AnsibleModule(argument_spec=argument_spec) as am:
        try:
            ModuleArgumentSpecValidator([])
        except TypeError:
            pass

        # if the argument_spec is of type dict, it should be accepted
        ModuleArgumentSpecValidator({})
        # if the argument_spec is of type ImmutableDict, it should be accepted
        ModuleArgumentSpecValidator(ImmutableDict())

        # empty argument_spec is invalid

# Generated at 2022-06-22 21:26:39.638817
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(spec)
    assert validator.argument_spec == spec

# Generated at 2022-06-22 21:26:46.767164
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    param_name = "name"
    param_value = "value"
    param = {param_name: param_value}
    param_type = "str"
    param_spec = {param_name: {'type': param_type}}

    validator = ArgumentSpecValidator(param_spec)
    assert validator.argument_spec == param_spec
    result = validator.validate(param)
    assert result.validated_parameters == {param_name: param_value}

# Generated at 2022-06-22 21:26:50.182813
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator is not None

    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:26:54.692965
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test the constructor of class ModuleArgumentSpecValidator."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set(['age', 'name'])


# Generated at 2022-06-22 21:27:02.540770
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec=arg_spec)
    result = validator.validate(parameters=parameters)

    assert isinstance(result._validated_parameters['age'], int)

    validator = ModuleArgumentSpecValidator(argument_spec=arg_spec)
    result = validator.validate(parameters=parameters)
    assert isinstance(result._validated_parameters['age'], int)



# Generated at 2022-06-22 21:27:13.983711
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Given a argument_spec without default values,
    # and a parameteres that contains a legal and a illegal parameter that should raise errors
    argument_spec = {
        'name': {
            'type': 'str',
        },
        'age': {
            'type': 'int',
        },
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # When a argument_spec validator is created and validate is called
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Then the illegal parameter should raise an error
    assert result.error_messages == ["Parameter age is of type '<class 'str'>' when it should be of type '<class 'int'>'."]
    assert result._validated_param

# Generated at 2022-06-22 21:27:21.507034
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test default init
    validator = ArgumentSpecValidator(dict())
    assert validator is not None

    # Test complete init
    validator = ArgumentSpecValidator(dict(), ['a', 'b'], [['a', 'b'], ['c', 'd']], [['a', 'b'], ['c', 'd']], [["a", "b", ["a"]]], {"a": ["c", "b"]})
    assert validator is not None



# Generated at 2022-06-22 21:27:31.290158
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # constructor should not raise an error
    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    assert vars(validator) == {
        '_mutually_exclusive': None,
        '_required_together': None,
        '_required_one_of': None,
        '_required_if': None,
        '_required_by': None,
        '_valid_parameter_names': {'age', 'name'},
        'argument_spec': {'age': {'type': 'int'}, 'name': {'type': 'str'}}
    }

# Generated at 2022-06-22 21:27:40.635892
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3, text_type
    # Convert text_type to string in Python 2
    if not PY3:
        to_native = lambda x: to_text(x, encoding='utf-8')
    else:
        to_native = to_text
    mutually_exclusive = [['a', 'b'], ['b', 'c']]
    required_together = [['a', 'b'], ['b', 'c']]
    required_one_of = [['a', 'b'], ['b', 'c']]
    required_if = ['a', 'b', ['c', 'd']]

# Generated at 2022-06-22 21:27:42.353257
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:27:54.353509
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    """
    Unit test for method validate of class ArgumentSpecValidator
    """

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'hobbies': {'type': 'list', 'elements': 'str'}
    }
    parameters = {
        "name": "bo",
        "age": "42",
        "hobbies": ["walking", "jogging"]
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'hobbies': ['walking', 'jogging']}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:28:02.358446
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from unittest import mock
    w1 = mock.Mock()
    w2 = mock.Mock()
    d1 = mock.Mock()
    d2 = mock.Mock()
    v1 = [w1, w2]
    v2 = [d1, d2]
    class T:
        def __init__(self):
            pass
        def validate(self, parameters):
            return v1, v2
    mock_argument_spec_validator = T()
    test_obj = ModuleArgumentSpecValidator()
    test_obj.__dict__['_ModuleArgumentSpecValidator__real_validator'] = mock_argument_spec_validator
    r = test_obj.validate('parameters')
    assert r == (v1, v2)

# Generated at 2022-06-22 21:28:08.580190
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    argument_spec_validator = ArgumentSpecValidator(
        argument_spec,
    )
    assert not argument_spec_validator is None
    assert not argument_spec_validator.argument_spec is None

# Generated at 2022-06-22 21:28:14.699542
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    import pytest
    validator = ArgumentSpecValidator({
        'argument': {
            'type': 'str'
        }
    })

    with pytest.raises(TypeError):
        validator.validate()

    validator.validate(parameters={'argument': 'foo'})



# Generated at 2022-06-22 21:28:22.567909
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    data = {'name': 'Bob', 'age': '42', 'location': 'Chicago'}
    vr = ValidationResult(data)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == data
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors is not None
    assert isinstance(vr.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-22 21:28:26.663217
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_argument_spec = {'name': {'type': 'str'}, 'color': {'type': 'str', 'default': 'blue', 'aliases': ['colour']}, 'age': {'type': 'int'}}
    mav = ModuleArgumentSpecValidator(module_argument_spec)
    assert mav.argument_spec == module_argument_spec


# Generated at 2022-06-22 21:28:34.637728
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}

    result = ValidationResult(parameters)

    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []



# Generated at 2022-06-22 21:28:43.013755
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str', 'required': True},
                     'age': {'type': 'int', 'required': True}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert not result.errors



# Generated at 2022-06-22 21:28:48.837139
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    spec = {
        'type': 'dict'
    }
    parameters = {}

    validator = ArgumentSpecValidator(spec, mutually_exclusive=[], required_together=[], required_one_of=[], required_if=[], required_by={})

    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)

# Generated at 2022-06-22 21:28:55.544352
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = dict(
        name=dict(type="str"),
        age=dict(type="int")
    )

    parameters = dict(
        name="bo",
        age="42"
    )

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == dict(
        name="bo",
        age=42
    )

# Generated at 2022-06-22 21:29:01.858092
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:29:11.667051
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import pytest
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    tmp_parameters = {
        'name': 'bo',
        'age': '42',
    }
    tmp_no_log_values = set()
    tmp_unsupported_parameters = set()
    tmp_deprecations = []
    tmp_warnings = []
    tmp_errors = AnsibleValidationErrorMultiple()
    result = ValidationResult(parameters)
    result._validated_parameters = tmp_parameters
    result._no_log_values = tmp_no_log_values
    result._unsupported_parameters = tmp_unsupported_parameters
    result._deprecations = tmp_deprecations
    result._warnings = tmp_warnings
    result.errors = tmp

# Generated at 2022-06-22 21:29:18.362986
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    spec = {
        'arg1': {'type': 'str', 'required': False},
        'arg2': {'type': 'str', 'required': False},
    }
    parameters = {
        'arg1': 'val1',
        'arg2': 'val2',
    }
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters

# Generated at 2022-06-22 21:29:26.149725
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'John', 'last_name':'Wick'}

    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:29:37.598411
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['foo', 'bar']]]
    required_by = {'name': ['age', 'foo']}

    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive=mutually_exclusive,
                 required_together=required_together,
                 required_one_of=required_one_of,
                 required_if=required_if,
                 required_by=required_by)

    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:29:40.122517
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator()
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 21:29:51.675361
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    
    # Create a validator
    argument_spec = {'parameter1': {'type': 'str'}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec,mutually_exclusive,required_together,required_one_of,required_if,required_by)

    # valid parameter
    parameters = {'parameter1': 'value1'}
    result = validator.validate(parameters)
    assert not result.errors
    assert result.validated_parameters['parameter1'] == 'value1'

    # invalid parameter
    parameters = {'parameter1': 1}
    result = validator.validate(parameters)

# Generated at 2022-06-22 21:29:58.189677
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult({})
    assert vr.validated_parameters == {}
    assert vr.unsupported_parameters == set()
    assert vr.error_messages == []
    assert vr.errors.messages == []
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == {}
    assert vr._deprecations == []
    assert vr._warnings == []


# Generated at 2022-06-22 21:30:06.288925
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    validation_result = ValidationResult(parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._validated_parameters == parameters
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.validated_parameters == parameters
    assert validation_result.unsupported_parameters == set()
    assert validation_result.error_messages == []