

# Generated at 2022-06-22 21:20:07.429680
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test 1:
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}, 'id': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42', 'id': '123456789'}
    validator = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'id': 123456789}
    assert result.unsupported_parameters == set()

    # Test 2:

# Generated at 2022-06-22 21:20:18.904188
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test with a parameter set
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    result = ValidationResult({
        'name': 'bo',
        'age': '42',
    })

    validator = ArgumentSpecValidator(argument_spec)
    validated_result = validator.validate({
        'name': 'bo',
        'age': '42',
    })
    assert validated_result == result

    # Test with a parameter set and a list of mutually exclusive parameters
    argument_spec = {
        'names': {'type': 'list'},
        'age': {'type': 'int'},
    }


# Generated at 2022-06-22 21:20:19.479749
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:20:24.514944
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    valid_params = result.validated_parameters

    assert result.errors == []
    assert valid_params == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:20:31.430743
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test example
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-22 21:20:39.981923
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'update_cache': {'type': 'bool', 'default': False},
        'state': {'type': 'str', 'default': 'latest', 'choices': ['latest', 'absent', 'present', 'noop']},
        'age': {'type': 'int'},
        'with_content': {'type': 'dict', 'required': False},
    }

    mutually_exclusive = [['update_cache', 'state']]

    parameters = {
        'name': 'bo',
        'age': '42',
        'with_content': {'path': 'test'},
        'update_cache': True,
        'state': 'noop',
        'test': 'test',
    }

    # create an object of class

# Generated at 2022-06-22 21:20:46.710068
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:20:58.822702
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_if = [
        ['name', 'age'],
    ]
    required_by = {
        'name': ['age'],
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }


# Generated at 2022-06-22 21:21:07.539915
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Set up
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Run
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # Assert Result
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-22 21:21:10.484910
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-22 21:21:13.822398
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert a.argument_spec == {'name': {'type': 'str'}}

# Generated at 2022-06-22 21:21:16.262708
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    instance = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=None, required_together=None, required_one_of=None, required_if=None,
                                           required_by=None)
    assert isinstance(instance, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:21:28.482811
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import pytest

    # test for input_parameters being empty
    argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}
    parameters = {}
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by,
                                      )

    try:
        result = validator.validate(parameters)
    except SystemExit as e:
        pytest.fail('test_ArgumentSpecValidator_validate failed with SystemExit being raised')


# Generated at 2022-06-22 21:21:29.613624
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator([], [], [], [], [])

# Generated at 2022-06-22 21:21:34.470527
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['years']},
    }

    parameters = {
        'name': 'bo',
        'years': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.unsupported_parameters == set()
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:21:44.210159
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "name": {
            "type": "str",
        },
        "aliases": {
            "type": "list",
            "aliases": ["alt_names"],
            "elements": "dict",
            "options": {
                "name": {"type": "str"},
                "age": {"type": "int"},
            },
        }
    }

    parameters = {
        "name": "bob",
        "alt_names": [
            {"name": "bob", "age": 42},
            {"name": "robert", "age": 40}
        ],
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []


# Generated at 2022-06-22 21:21:56.022261
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:22:06.077085
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator."""

    # ArgumentSpecValidator with mutually_exclusive
    mutually_exclusive = [
        ['a', 'b'],
    ]
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'str'},
    }
    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive,
    )
    assert validator._mutually_exclusive == mutually_exclusive

    # ArgumentSpecValidator with required_together
    required_together = [
        ['a', 'b'],
    ]
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'str'},
    }
    validator = ArgumentSpecValidator

# Generated at 2022-06-22 21:22:13.621404
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutex = [['foo'], ['bar'], ['baz'], ['qux', 'quux']]
    req_together = [['foo', 'bar'], ['baz', 'qux']]
    req_one_of = [['foo', 'bar']]
    req_if = [['foo', 'bar', 'baz']]
    req_by = {'baz': ['foo', 'bar']}
    arg_spec = {'foo': {'type': 'str'},
                'bar': {'type': 'str'},
                'baz': {'type': 'str'},
                'qux': {'type': 'str'},
                'quux': {'type': 'str'}}


# Generated at 2022-06-22 21:22:22.880557
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create spec
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Create parameters to validate
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # Create ArgumentSpecValidator and run validation
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parameters)

    # Check validation result
    assert len(result.error_messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:22:29.388541
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(result.validated_parameters == {'name': 'bo', 'age': 42})

# Generated at 2022-06-22 21:22:40.665660
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod_arg_spec_validator = ModuleArgumentSpecValidator({'foo': {'required': False}}, [], [], [], [], {})
    assert mod_arg_spec_validator.argument_spec == {'foo': {'required': False}}
    assert mod_arg_spec_validator._mutually_exclusive is None
    assert mod_arg_spec_validator._required_together is None
    assert mod_arg_spec_validator._required_one_of is None
    assert mod_arg_spec_validator._required_if is None
    assert mod_arg_spec_validator._required_by is None
    #assert mod_arg_spec_validator._valid_parameter_names is None


# Generated at 2022-06-22 21:22:46.492022
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Setup
    parameters = {
        'arg1': 'value1',
        'arg2': 'value2',
    }
    m = ModuleArgumentSpecValidator()

    # Test
    result = m.validate(parameters)

    # Verify
    assert result.unsupported_parameters == set([('arg1',), ('arg2',)])
    assert result.error_messages == [
        "arg1: unsupported parameter",
        "arg2: unsupported parameter"
    ]

# Generated at 2022-06-22 21:22:49.186344
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod_arg_spec_validator = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}})
    assert isinstance(mod_arg_spec_validator, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:22:54.894108
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result1 = ValidationResult({'my_name': 'Mohamed'})
    assert result1 is not None
    assert result1.error_messages == []
    assert result1.validated_parameters == {'my_name': 'Mohamed'}
# end of test_ValidationResult

if __name__ == '__main__':
    test_ValidationResult()

# Generated at 2022-06-22 21:23:06.427808
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {'a': {'type': 'str'}, 'b': {'type': 'str', 'aliases': ['c']}, 'ab': {'aliases': ['ba']}}
    parameters = {'a': 'a', 'b': 'b', 'ab': 'ab'}
    expected = {'a': 'a', 'b': 'b', 'ab': 'ab'}
    asv = ArgumentSpecValidator(spec)
    result = asv.validate(parameters)
    assert result._validated_parameters == expected

    spec = {'a': {'type': 'str'}, 'b': {'type': 'str', 'aliases': ['c']}, 'ab': {'aliases': ['ba']},
            'cd': {'aliases': ['cd', 'dc']}}

# Generated at 2022-06-22 21:23:16.583522
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import iteritems

# Generated at 2022-06-22 21:23:28.273243
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    spec = dict(
        param1=dict(type='str'),
        param2=dict(type='dict'),
        param3=dict(type='dict', elements='str'),
    )

    # Testing AliasError
    # First must fail, because there is two different "parameters" for param1 and param1-alias
    parameters = dict(
        param1='value',
        param1_alias='value2',
        param2=dict(
            field1='value1',
            field2='value2',
        ),
    )
    validator = ArgumentSpecValidator(spec)
    result = validator.validate(parameters)
    assert result.errors
    assert len(result.errors) == 1
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-22 21:23:32.369097
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict()
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == dict()
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []
    assert result.validated_parameters == dict()
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:23:37.249891
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_arg_spec = {"name": {"type": "str", "required": True}}
    parameters = {"name": "bo"}
    validator = ModuleArgumentSpecValidator(module_arg_spec)
    result = validator.validate(parameters)
    assert result.errors.messages == []
    assert result.validated_parameters == parameters

# Generated at 2022-06-22 21:23:40.483285
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': 42}
    result = ValidationResult(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.errors.messages == []


# Generated at 2022-06-22 21:23:45.307345
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ValidationResult({})
    class ModuleArgumentSpecValidator_mock:
        def __init__(self, *args, **kwargs):
            pass
        def validate(self, *args, **kwargs):
            return result

    params = {}
    validator = ModuleArgumentSpecValidator_mock()
    assert ModuleArgumentSpecValidator(validator).validate(params) == result

# Generated at 2022-06-22 21:23:46.224280
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert False, "Test not implemented"

# Generated at 2022-06-22 21:23:56.811330
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        {
            "name": {
                "required": True,
                "type": "str"
            },
            "nested": {
                "required": True,
                "type": "dict",
                "options": {
                    "name": {
                        "required": True,
                        "type": "str"
                    }
                }
            }
        }
    )
    result = validator.validate({"name": "bo", "nested": {"name": "bo"}})
    assert result.validated_parameters == {"name": "bo", "nested": {"name": "bo"}}
    assert len(result.errors) == 0
    assert len(result.error_messages) == 0


# Generated at 2022-06-22 21:24:04.347977
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"name":"Ansible", "age":42}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters
    assert validation_result.errors == []
    assert validation_result.validated_parameters == parameters
    assert validation_result.unsupported_parameters == []
    assert validation_result.error_messages == []

# Generated at 2022-06-22 21:24:06.351783
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    with pytest.raises(TypeError):
        result = ValidationResult()


# Generated at 2022-06-22 21:24:17.693202
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    print("Validated: {0}".format(to_text(result.validated_parameters)))

# Generated at 2022-06-22 21:24:28.182251
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test empty args, kwargs
    m = ModuleArgumentSpecValidator({'a': {'type': 'int', 'required': True}, 'b': {'type': 'float', 'required': True}})
    assert m.validate({'a': 1, 'b': 2.1}) is not None

    # Test optional args, kwargs
    m = ModuleArgumentSpecValidator({'a': {'type': 'int', 'required': True}},
                                    mutual_exclusive=[['a', 'b']],
                                    required_together=[[1, 2]],
                                    required_one_of=[[1, 2]],
                                    required_if=[['c', 'd', ['a']]],
                                    required_by={'a': ['b']})

# Generated at 2022-06-22 21:24:40.529741
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Create an alias and conflicting name
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['name_alias']},
        'name_alias': {'type': 'str'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'name_alias': 'bo',
    }
    result = validator.validate(parameters)

    # Check that deprecations and warnings have been created
    assert len(result._deprecations) == 1
    assert result._deprecations[0]['name'] == 'name_alias'
    assert len(result._warnings) == 1
    assert result._warnings[0]['option'] == 'name'

# Generated at 2022-06-22 21:24:41.100755
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:24:48.106296
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeModule:
        def __init__(self):
            pass
        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)
    fake_module = FakeModule()
    module_arg_spec_validator = ModuleArgumentSpecValidator({})
    module_arg_spec_validator.validate({"name": "bo", "age": "42"}, {"type": "str"})

# Generated at 2022-06-22 21:25:00.189079
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'job': {'type': 'str', 'default': 'worker'}
    }
    required_one_of = [
        ['name', 'age'],
        ['age', 'job']
    ]
    mutually_exclusive = [
        ['age', 'job']
    ]
    required_together = [
        ['name', 'age'],
        ['age', 'job']
    ]
    required_if = [
        ['name', 'job', ['age']]
    ]


# Generated at 2022-06-22 21:25:04.885224
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-22 21:25:15.061747
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'Ansible',
        'age': 34,
    }

    vr = ValidationResult(parameters)

    assert hasattr(vr, "_no_log_values")
    assert hasattr(vr, "validated_parameters")
    assert hasattr(vr, "errors")
    assert hasattr(vr, "_unsupported_parameters")
    assert hasattr(vr, "_deprecations")

    assert isinstance(vr._no_log_values, set)
    assert vr._no_log_values == set()
    assert vr.validated_parameters == parameters
    assert vr.errors == AnsibleValidationErrorMultiple()
    assert isinstance(vr._unsupported_parameters, set)
    assert vr._unsupported_parameters == set()

# Generated at 2022-06-22 21:25:26.087164
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils.common.parameters import HASH_DUNDERS
    from ansible.module_utils.common.text.converters import to_text

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['years']},
    }

    # Missing a required argument
    parameters = {'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], RequiredError)
    assert result.error_messages == [result.errors[0].message]
    assert result.unsupported_parameters == set()
    assert result.validated_parameters

# Generated at 2022-06-22 21:25:35.331848
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test method validate of class ArgumentSpecValidator."""

    test_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    test_parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(test_argument_spec)
    result = validator.validate(test_parameters)

    assert result._validated_parameters["name"] == "bo"
    assert result._validated_parameters["age"] == 42

# Generated at 2022-06-22 21:25:40.232700
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert isinstance(result, ValidationResult)
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == []


# Generated at 2022-06-22 21:25:52.516206
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # pylint: disable=unused-argument,unused-variable
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import open_url

    argument_spec = {
        'name': {'type': 'str'},
    }
    mutually_exclusive = [
        ['host', 'connection'],
        ['name', 'ip'],
    ]
    required_one_of = [
        ['host', 'connection'],
    ]
    required_together = [
        ['name', 'ip'],
    ]
    required

# Generated at 2022-06-22 21:25:56.051215
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:26:03.587276
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # module.params = {'age': '42', 'name': 'bo'}
    real_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    result = validate(real_argument_spec, {'name': 'bo', 'age': '42'})

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []



# Generated at 2022-06-22 21:26:15.283077
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def test_warn():
        test_warn.called += 1

    test_warn.called = 0
    # Set up the class to test
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    # Set up warn method
    import __builtin__
    backup_warn = __builtin__.warn
    __builtin__.warn = test_warn
    # Execute the test
    result = validator.validate(parameters)
    # Remove warn method and replace backup
    del __builtin__.warn
    __builtin__.warn = backup_warn
   

# Generated at 2022-06-22 21:26:16.263075
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    ArgumentSpecValidator.validate()

# Generated at 2022-06-22 21:26:21.760757
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo'})
    assert result._validated_parameters == {'name': 'bo'}
    assert result.error_messages == []
    assert result.errors == []

# Generated at 2022-06-22 21:26:29.609727
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec,
    mutually_exclusive, required_together, required_one_of, required_if, required_by)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)


# Generated at 2022-06-22 21:26:40.719070
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Test ModuleArgumentSpecValidator constructor
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['a', 'b'], ['b', 'c']]

    required_together = [['a', 'b'], ['b', 'c']]

    required_one_of = [['a', 'b'], ['b', 'c']]

    required_if = [['a', 'b'], ['b', 'c']]

    required_by = {'a': ['b', 'c'], 'b': ['a', 'c']}


# Generated at 2022-06-22 21:26:46.326826
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(argument_spec={'test': {}}, mutually_exclusive=['test1', 'test2'],
                                            required_together=['test3', 'test4'], required_one_of=['test5', 'test6'],
                                            required_if='test1 and test2', required_by='test3')
    assert validator
    assert hasattr(validator, 'validate')

# Generated at 2022-06-22 21:26:53.410729
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator.validate(self, parameters)
    assert result._no_log_values.update(set_fallbacks(self.argument_spec, result._validated_parameters))
    assert result._no_log_values.update(_list_no_log_values(self.argument_spec, result._validated_parameters))
    assert result._unsupported_parameters.update(_get_unsupported_parameters(self.argument_spec, result._validated_parameters, legal_inputs))
    assert result._no_log_values.update(_set_defaults(self.argument_spec, result._validated_parameters, False))
    assert result._no_log_values.update(_set_defaults(self.argument_spec, result._validated_parameters))


# Generated at 2022-06-22 21:27:03.017406
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator(argument_spec={
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }, mutually_exclusive=['name', 'age'],
        required_together=['name', 'age'],
        required_one_of=['name', 'age'],
        required_if=[['name', 'age', ['name']]],
        required_by={'name': ['name']},
    )
    assert validator.argument_spec == {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    assert validator._mutually_exclusive == ['name', 'age']
    assert validator._required_together == ['name', 'age']

# Generated at 2022-06-22 21:27:14.966187
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockResult:
        def __init__(self, validated_parameters, warnings, deprecations, errors):
            self._validated_parameters = validated_parameters
            self._warnings = warnings
            self._deprecations = deprecations
            self.errors = errors
    # testing with warnings
    warnings = [{'option': 'name', 'alias': 'first_name'}]
    deprecations = [{'name': 'first_name', 'version': '2.10', 'date': None, 'collection_name': None}]
    errors = []
    result = MockResult({'name': 'bo', 'age': '42'}, warnings, deprecations, errors)

# Generated at 2022-06-22 21:27:19.487966
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import inspect
    assert '__init__' in dir(ModuleArgumentSpecValidator)
    assert len(inspect.getfullargspec(ModuleArgumentSpecValidator.__init__).args) == 7

# Generated at 2022-06-22 21:27:27.001116
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {'foo': {'type': 'str'}, 'bar': {'type': 'dict'}}
    _valid_parameter_names = [u'foo']

    parameters = dict(foo='bar')

    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parameters)

    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []



# Generated at 2022-06-22 21:27:36.408724
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {
        'name': 'bo',
        'age': '42',
    }
    assert result._deprecations == []
    assert result._warnings == []
    assert type(result.errors).__name__ == 'AnsibleValidationErrorMultiple'
    assert result.errors.messages == []
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:27:46.471798
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
    }
    # run the test.
    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=None,
                                            required_together=None,
                                            required_one_of=None,
                                            required_if=None,
                                            required_by=None,
                                            )
    assert validator.validate(parameters) == None
# end of test_ModuleArgumentSpecValidator_validate

# Generated at 2022-06-22 21:27:52.734298
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    arg_spec_validator = {
        "name": {"required": True, "type": "str"},
        "age": {"required": True, "type": "int"}
    }
    valid_parameters = {
        "name": "Ansible",
        "age": 10
    }
    validation_result = ValidationResult(valid_parameters)
    assert validation_result._validated_parameters == valid_parameters


# Generated at 2022-06-22 21:27:57.640322
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'a': {}, 'b': {'c': {}}}
    result = ValidationResult(parameters)
    assert result._validated_parameters == {}
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == []



# Generated at 2022-06-22 21:28:01.652973
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validationresult = ValidationResult({'foo': {'bar': 1}})
    assert validationresult.validated_parameters == {'foo': {'bar': 1}}
    assert validationresult.error_messages == []
    assert validationresult._deprecations == []
    assert validationresult._warnings == []
    assert validationresult._unsupported_parameters == set()


# Generated at 2022-06-22 21:28:11.257957
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule(argument_spec=dict(name=dict(type='str'), age=dict()), mutually_exclusive=["name", "age"])
    validator = ModuleArgumentSpecValidator(ansible_module.argument_spec,
                                                                 ansible_module._mutually_exclusive)
    result = validator.validate(dict(name="foo", age=20))
    assert len(result.error_messages) == 1
    assert "name, age are mutually exclusive" in result.error_messages[0]

# Generated at 2022-06-22 21:28:19.869592
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'a': {'type': 'str', 'aliases': ['aaa']}}
    validator = ArgumentSpecValidator(spec)
    assert validator.__dict__ == {'_mutually_exclusive': None,
                                  '_required_by': None,
                                  '_required_if': None,
                                  '_required_one_of': None,
                                  '_required_together': None,
                                  '_valid_parameter_names': set(['a (aaa)']),
                                  'argument_spec': {'a': {'type': 'str', 'aliases': ['aaa']}}}

# Generated at 2022-06-22 21:28:27.175382
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    required_if = [('users','present','groups','present')]
    argument_spec = {
        'users': {'type': 'str', 'required': True},
        'groups': {'type': 'str'},
    }
    mutually_exclusive = [['users', 'groups']]
    m = ModuleArgumentSpecValidator(argument_spec,
                                    mutually_exclusive=mutually_exclusive,
                                    required_if = required_if)
    assert m._mutually_exclusive == [['users', 'groups']]
    assert m._required_if == required_if

# Generated at 2022-06-22 21:28:31.116320
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult({"1":"23"})
    assert vr.validated_parameters == {"1":"23"}
    assert vr.unsupported_parameters == set()
    assert vr.error_messages == []


# Generated at 2022-06-22 21:28:32.639782
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    r = ValidationResult({'name': 'bo'})
    assert isinstance(r, ValidationResult)


# Generated at 2022-06-22 21:28:39.282854
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {'name': 'bo', 'age': '42'}

    result = validator.validate(parameters)

    assert result.error_messages == []

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:28:45.918934
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str'
        },
        'age': {
            'type': 'int'
        }
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)
    assert validator.argument_spec == argument_spec

# # Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:28:47.262734
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert(ArgumentSpecValidator)


# Generated at 2022-06-22 21:28:49.976540
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Test that it fails if the wrong arguments are passed in
    assert ValueError(ModuleArgumentSpecValidator("test"))



# Generated at 2022-06-22 21:28:54.801847
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == set(['age', 'name'])

# Generated at 2022-06-22 21:28:58.115852
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"test_string": "me is string", "test_int": 12}
    valid_result = ValidationResult(parameters)



# Generated at 2022-06-22 21:29:01.706240
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}
    result = ModuleArgumentSpecValidator(argument_spec)
    assert isinstance(result, ModuleArgumentSpecValidator)


# Generated at 2022-06-22 21:29:11.560711
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    import sys
    import os

    arg1 = {
        'type': 'str',
        'required': 'True',
        'aliases': ['argument1'],
        'default': 'Terraform'
    }
    arg2 = {'type': 'int'}
    arg3 = {'type': 'bool'}

    argument_spec = {
        'name': arg1,
        'age': arg2,
        'enabled': arg3,
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'enabled': 'True',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:29:21.744394
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    assert len(result._no_log_values) == 0
    assert result._unsupported_parameters == set()
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0
    assert len(result.errors) == 0


# Generated at 2022-06-22 21:29:34.237197
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                                         mutually_exclusive=None,
                                         required_together=None,
                                         required_one_of=None,
                                         required_if=None,
                                         required_by=None,
                                         )
    assert isinstance(result, ModuleArgumentSpecValidator)
    assert result.argument_spec == {'name': {'type': 'str'}}
    assert result._mutually_exclusive is None
    assert result._required_together is None
    assert result._required_one_of is None
    assert result._required_if is None
    assert result._required_by is None
    assert result._valid_parameter_names == {'name'}


# Generated at 2022-06-22 21:29:35.140532
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:29:47.344122
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ArgumentSpecValidator(argument_spec).validate(parameters)

    if len(result.error_messages) > 0:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params

# Generated at 2022-06-22 21:29:57.293082
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
    }

    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age"]]
    required_by = {"name": ["age"]}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by,
                                      )

    assert validator.argument_spec == argument_spec
    assert validator._