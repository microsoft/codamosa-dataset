

# Generated at 2022-06-22 21:20:07.428546
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # First, test arguments aliases
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'color': {'type': 'str', 'aliases': ['colour']}
    }
    # Should be ignored, first option is used
    parameters = {
        'name': 'freddy',
        'age': 12,
        'colour': 'blue',
        'color': 'black'
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._validated_parameters == {'name': 'freddy', 'age': 12, 'color': 'blue'}
    # Deprecation
    assert len(result._deprecations) == 1
    assert result._dep

# Generated at 2022-06-22 21:20:15.708472
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        "age": {"type": "int", "default": 41},
        "name": {"type": "str"},
        "details": {"type": "dict", "options": {
            "nickname": {"type": "str"},
            "siblings": {"type": "list", "options": {
                "type": "str",
                "aliases": ["sibs"]
            }}
        }}
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [
        ['name', 'bo', ['details']]
    ]
    required_by = {
        'details': ['name']
    }


# Generated at 2022-06-22 21:20:22.549126
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        'name': {'required': True, 'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }

    parameters = {
        'name': 'bo',
        'age': '43',
    }

    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 43}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:20:26.916856
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'no_log': True, '_ansible_verbosity': 4}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.error_messages == []

# Generated at 2022-06-22 21:20:37.183574
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_if = [
        ['name', '<', ['age']]
    ]
    required_by = {
        'name': ['age']
    }

    argument_spec_validator = ArgumentSpecValidator(argument_spec,
                                                    mutually_exclusive,
                                                    required_together,
                                                    required_one_of,
                                                    required_if,
                                                    required_by)
    assert argument_spec_valid

# Generated at 2022-06-22 21:20:47.429075
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameter = {
        'name': 'bo',
        'age': '42',
        'lastname': 'hysterical',
        'sex': 'male',
        'sex2': 'male2',
    }

    # populate test case with args

# Generated at 2022-06-22 21:20:57.404919
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)

    assert result.validated_parameters['age'] == 42
    assert result.validated_parameters['name'] == 'bo'

    assert 'age' not in result.unsupported_parameters
    assert 'name' not in result.unsupported_parameters



# Generated at 2022-06-22 21:20:58.485542
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert hasattr(ModuleArgumentSpecValidator, "validate")

# Generated at 2022-06-22 21:21:04.116709
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test the instantiation of a ValidationResult with the following predefined parameters
    vr = ValidationResult(
        {
            'name': 'bo',
            'age': '42',
        }
    )
    assert vr._validated_parameters == {
            'name': 'bo',
            'age': '42',
        }


# Generated at 2022-06-22 21:21:09.768216
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={'host': 'localhost', 'port': 22})
    assert result.validated_parameters == {'host': 'localhost', 'port': 22}
    assert not result._no_log_values
    assert not result._unsupported_parameters
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors



# Generated at 2022-06-22 21:21:20.460471
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}

    vr = ValidationResult(parameters)
    assert(isinstance(vr.errors, AnsibleValidationErrorMultiple))
    assert(vr.error_messages == [])
    assert(vr.unsupported_parameters == set())
    assert(isinstance(vr.validated_parameters, dict))
    assert(set(vr.validated_parameters.keys()) == set(parameters.keys()))
    assert(set(vr.validated_parameters.values()) == set(parameters.values()))

    vr.errors.append(ValueError("An error"))
    assert(vr.error_messages == ["An error"])


# Generated at 2022-06-22 21:21:30.790570
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'user': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
            },
        },
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'user': {'name': None},
        'unexpected': 'value',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors
    assert "unexpected" in result.error_messages[0]
    assert "user.name" in result.error_messages[1]
    assert "age" in result.error_messages

# Generated at 2022-06-22 21:21:38.464494
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # create a new instance of class ModuleArgumentSpecValidator
    arg_spec_validator = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=[], required_together=[],
                                                     required_if=[], required_by={}, required_one_of=[])

    # assert that our newly created object is an instance of class ModuleArgumentSpecValidator
    assert isinstance(arg_spec_validator, ModuleArgumentSpecValidator), "arg_spec_validator is not an instance of class ModuleArgumentSpecValidator"

# Generated at 2022-06-22 21:21:45.827001
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert 'name' in result.validated_parameters
    assert not result._unsupported_parameters

# Generated at 2022-06-22 21:21:51.725932
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Ensure ModuleArgumentSpecValidator is well constructed"""

    # argument_spec
    argument_spec = {
        'name': {},
    }
    # mutually_exclusive
    mutually_exclusive = [
        ['name'],
    ]
    # required_together
    required_together = [
        ['name'],
    ]
    # required_one_of
    required_one_of = [
        ['name'],
    ]
    # required_if
    required_if = [
        ['name', 'a', ['name']]
    ]
    # required_by
    required_by = {
        'name': ['name'],
    }

    # check attributes of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:21:59.530839
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    sorted_valid_parameter_names = sorted(['help', 'name', 'age'])
    spec = {
        'help': {},
        'name': {'default': 'bo', 'aliases': ['person']},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(spec)
    assert sorted(validator._valid_parameter_names) == sorted_valid_parameter_names
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None

# Generated at 2022-06-22 21:22:08.501479
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def fun():
        pass
    
    params = {
        'new_name': 'foo',
        'password': 'bar',
        'host': 'all',
        'vars': {
            'a': 42,
            'b': 'str'
        },
        'port': 11,
        'login_user': 'login_user',
        'connect_timeout': 60,
        'char_enc': 'ascii',
        'provider': None,
        'login_password': 'login_password',
    }


# Generated at 2022-06-22 21:22:18.302641
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic


# Generated at 2022-06-22 21:22:20.354600
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict()
    ValidationResult(parameters)


# Generated at 2022-06-22 21:22:24.080622
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"name": "Bob"}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []
    assert result._unsupported_parameters == set()

# Generated at 2022-06-22 21:22:30.007757
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    args = {'data': {'key': {'data1': 'value1'}}}
    expected = deepcopy(args)
    result = ValidationResult(args)
    assert result._validated_parameters == expected
    assert result.errors == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []

# Unit tests for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:22:36.635227
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_arguments = {'name': 'ccc', 'age': '32'}

    vr = ValidationResult(test_arguments)
    assert vr.errors == AnsibleValidationErrorMultiple()
    assert vr._validated_parameters == test_arguments
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()


# Generated at 2022-06-22 21:22:40.578865
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Unit test for method validate of class ModuleArgumentSpecValidator """

    parameters = {'key': 'value'}
    result = ModuleArgumentSpecValidator.validate(parameters)
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-22 21:22:49.487042
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import string_types

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult), "result should be instance of ValidationResult"

    assert isinstance(result.validated_parameters, dict)

# Generated at 2022-06-22 21:22:58.804780
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'age'],
    ]

    required_if = [
        ['name', 'age']
    ]

    required_by = {
        'name': ['age'],
        'age': ['name'],
    }


# Generated at 2022-06-22 21:23:01.498534
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator()
        raise AssertionError('Unexpected instantiation of ModuleArgumentSpecValidator')
    except TypeError:
        pass


# Generated at 2022-06-22 21:23:02.078522
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    pass


# Generated at 2022-06-22 21:23:07.156277
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # test normal execution
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive,
        required_together,
        required_one_of,
        required_if,
        required_by,
    )

# Generated at 2022-06-22 21:23:16.998257
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.common.test_utils import AnsibleExitJson
    from ansible.module_utils.common.test_utils import AnsibleFailJson
    from ansible.module_utils.common.test_utils import AnsibleModule
    from ansible.module_utils.common.test_utils import set_module_args

    import json

    argument_spec = {
        'name': {'type': 'str'},
        'state': {'type': 'str', 'default': 'present', 'choices': ['present', 'absent']},
        'age': {'type': 'int', 'default': 10}
    }


# Generated at 2022-06-22 21:23:27.246768
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.arg_spec import ArgumentSpec
    arg_spec = ArgumentSpec()
    argument_spec = arg_spec.argument_spec
    mutually_exclusive = arg_spec.mutually_exclusive
    required_together = arg_spec.required_together
    required_one_of = arg_spec.required_one_of
    required_if = arg_spec.required_if
    required_by = arg_spec.required_by
    asv = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                required_one_of, required_if, required_by)


# Generated at 2022-06-22 21:23:36.246301
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['nickname']},
        'age': {'type': 'int'},
        'hobby': {'type': 'dict', 'options': {
            'name': {'type': 'str', 'default': 'tennis'},
            'hours': {'type': 'int', 'default': 4},
        }},
    }

    mutually_exclusive = [['name', 'age']]

    required_together = [['name', 'age'], ['name', 'hobby']]

    required_one_of = [['name', 'age'], ['name', 'hobby']]

    required_by = {'name': ['hobby'], 'age': ['hobby']}


# Generated at 2022-06-22 21:23:42.062950
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.testns.testcoll.plugins.module_utils.argument_spec.example_spec import argument_spec

    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {'name': 'fred', 'age': 10}
    results = validator.validate(parameters)
    assert len(results.errors) == 0



# Generated at 2022-06-22 21:23:50.071127
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    input_arg = dict()
    input_arg['name'] = 'test_module'
    input_arg['path'] = 'test_path'
    input_arg['aliases'] = 'test_alias'
    input_arg['version_added'] = 'test_version'
    variables = dict()
    variables['name'] = 'test_module'
    variables['path'] = 'test_path'
    variables['aliases'] = 'test_alias'
    variables['version_added'] = 'test_version'

    # ValidationResult
    #####################
    # _no_log_values:
    #   set()
    # _unsupported_parameters:
    #   set()
    # _validate_parameters:
    #   {'name': 'test_module', 'path': 'test_path',
   

# Generated at 2022-06-22 21:23:51.279499
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-22 21:23:56.005029
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test specifying an invalid parameter
    try:
        result = ValidationResult(parameters='blah')
        assert False
    except TypeError:
        assert True

    # Test passing in an empty dict
    assert ValidationResult(parameters={}).validated_parameters == {}


# Generated at 2022-06-22 21:23:58.376922
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    test_spec = {
        'argument1': {'type': 'str'},
        'argument2': {'type': 'str'},
        }
    validator = ArgumentSpecValidator(test_spec)

# Generated at 2022-06-22 21:24:00.654804
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        ArgumentSpecValidator(None)
    except TypeError as e:
        assert str(e) == 'argument_spec cannot be a NoneType'

# Generated at 2022-06-22 21:24:12.203176
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}, }
    parameters = {'name': 'bo',
                  'age': '42', }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert (result.error_messages == [])
    assert (result.validated_parameters == {'name': 'bo', 'age': 42})
    assert (result.unsupported_parameters == set())

    parameters = {'name': 'bo',
                  'age': '42',
                  'height': '185'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-22 21:24:19.673859
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v_result = ValidationResult({})
    assert v_result._no_log_values == set()
    assert v_result._unsupported_parameters == set()
    assert v_result._validated_parameters == {}
    assert v_result._deprecations == []
    assert v_result._warnings == []
    assert v_result.errors == AnsibleValidationErrorMultiple()
    assert v_result.error_messages == []
    assert v_result.validated_parameters == {}
    assert v_result.unsupported_parameters == set()

# Generated at 2022-06-22 21:24:27.618891
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Test validate method of class ArgumentSpecValidator with valid input specification,
    # mutually_exclusive, required_together, required_one_of, required_if and required_by
    # and valid parameters
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int', default=30)
    )

    parameters = dict(
        name='bo',
        age=40
    )

    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []


# Generated at 2022-06-22 21:24:40.078153
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text

    # Test case when no alias nor deprecation was found
    argument_spec = {'name': {'type':'str', 'aliases':[]}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    parameters = {'name': 'bo'}

    # Test when no errors and no deprecations
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo'}

# Generated at 2022-06-22 21:24:52.469712
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Unit tests to check the constructor of class ArgumentSpecValidator
    """

    # Test case 1: Valid input arguments
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['ali1', 'ali2']},
        'age': {'type': 'int'}
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [('age', 'name')]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['new_age']]]
    required_by = {'age': ['name']}

# Generated at 2022-06-22 21:24:56.384932
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    result = validator.validate({'name': 'ansible'})
    assert result.error_messages == []


# Generated at 2022-06-22 21:25:05.577418
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test the ArgumentSpecValidator class constructor."""
    test_spec = dict(
        age=dict(type='int'),
        name=dict(type='str'),
    )
    test_mutually_exclusive = [
        ['age', 'name'],
        ['age', 'name'],
        ['age', 'name'],
    ]
    test_required_together = [
        ['age', 'name'],
        ['age', 'name'],
        ['age', 'name'],
    ]
    test_required_one_of = [
        ['age', 'name'],
        ['age', 'name'],
        ['age', 'name'],
    ]

# Generated at 2022-06-22 21:25:07.895032
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({'n': {'type': 'str'}}), ArgumentSpecValidator)


# Generated at 2022-06-22 21:25:15.104879
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    )

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-22 21:25:20.513736
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit test for constructor"""
    # Load ArgumentSpecValidator
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # Instantiate ModuleArgumentSpecValidator
    try:
        ModuleArgumentSpecValidator(dict())
        msg = None
    except:
        msg = "Failed to instantiate ModuleArgumentSpecValidator"

    assert msg == None, 'ModuleArgumentSpecValidator constructor failed'



# Generated at 2022-06-22 21:25:33.090853
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # in the future, this should be in a "fixture"

# Generated at 2022-06-22 21:25:34.373840
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert type(ArgumentSpecValidator)

# Generated at 2022-06-22 21:25:46.169008
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn
    import sys
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = []

    #  Testing ModuleArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
   

# Generated at 2022-06-22 21:25:48.659328
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator({}), ArgumentSpecValidator)


# Generated at 2022-06-22 21:25:52.422387
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'valid': {'type': 'bool'}}

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert type(validator) == ModuleArgumentSpecValidator




# Generated at 2022-06-22 21:25:56.646407
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    # Create an instance of argument spec class
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)

    print('Test completed successfully.')



# Generated at 2022-06-22 21:26:08.762848
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [
        ['a', 'b'],
        ['c', 'd']
    ]
    required_together = [
        ['a', 'b'],
        ['c', 'd']
    ]
    required_one_of = [
        ['a', 'b'],
        ['c', 'd']
    ]
    required_if = [
        ['a', 'b', ['c', 'd']]
    ]
    required_by = {
        'a': ['b'],
        'c': ['d']
    }

# Generated at 2022-06-22 21:26:19.282718
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [["name", "age"]]

    required_together = [["name", "age"]]

    required_one_of = [["name", "age"]]

    required_if = [
        ["age", 42, "name"],
    ]

    required_by = {
        "42": ["name"],
    }


# Generated at 2022-06-22 21:26:23.124261
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    # Create parameters from dictionary and pass that
    # dictionary to ValidationResult as parameters
    parameters = {
    "test_param_1": "parameter_value_1",
    "test_param_2": "parameter_value_2",
    }

    result = ValidationResult(parameters)

    assert result.validated_parameters == parameters

    assert result.error_messages == []


# Generated at 2022-06-22 21:26:33.102464
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test with empyt argument_spec
    s = {'argument_spec':{}}
    v = ArgumentSpecValidator(s['argument_spec'])
    assert v.argument_spec == {}, 'Invalid argument_spec'

    # Test with non-empty argument_spec
    s = {'argument_spec':{'name':{'type':'string'},
                        'name2':{'type':'string'},
                        'name3':{'type':'string'}}}
    v = ArgumentSpecValidator(s['argument_spec'])
    assert v.argument_spec == s['argument_spec'], 'Invalid argument_spec'


# Generated at 2022-06-22 21:26:39.158988
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'Doe', 'age': 42}
    v = ValidationResult(parameters)
    assert v._no_log_values == set()
    assert v._unsupported_parameters == set()
    assert v._validated_parameters == {'name': 'Doe', 'age': 42}
    assert v._deprecations == []
    assert v._warnings == []
    assert v.error_messages == []


# Generated at 2022-06-22 21:26:49.256672
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(
        argument_spec={'name': {'type': 'str'}},
        mutually_exclusive=[["a", "b"]],
        required_together=[["a", "b"]],
        required_one_of=[["a", "b"]],
        required_if=[["a", "b", ["c"]]],
        required_by={"a": ["b", "c"]}
    )
    parameters = {'name': 'bo', 'age': '42'}
    validated_parameters = validator.validate(parameters)['validated_parameters']

    # The test below is comparing a dict and a dictproxy, so we need to convert dictproxy to a dict
    dict_validated_parameters = dict(validated_parameters)
    assert dict_validated_param

# Generated at 2022-06-22 21:26:53.890869
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict()
    instance = ArgumentSpecValidator(argument_spec)
    assert isinstance(instance, ArgumentSpecValidator)


# Generated at 2022-06-22 21:27:03.264879
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str


# Generated at 2022-06-22 21:27:10.401958
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Unit test for method validate of class ModuleArgumentSpecValidator """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-22 21:27:22.953963
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        foo=dict(
            required=True,
            type='str'
        ),
        bar=dict(
            type='int'
        )
    )
    mutually_exclusive = [['foo', 'bar']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'bar']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of)

    parameters = dict(
        foo='foo',
        bar='bar'
    )

    result = validator.validate(parameters)
    # Note: The following test is dependent on the result of the test. Assuming the inputs are correct, validate()
    # will not return any errors. It is not very good test practice but this is how we are

# Generated at 2022-06-22 21:27:33.541242
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:27:42.935357
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    def _get_warnings():
        return Module._get_warnings(lambda: warn('boo'))

    argument_spec = {"name": {"type": "str", "aliases": ["display_name"]},
                     "age": {"type": "int", "required": True}}
    parameters = {"name": "bo", "age": "42"}

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result._deprecations == [{'name': 'display_name', 'version': None, 'date': None, 'collection_name': None}]
    assert result._warnings == [{'option': 'name', 'alias': 'display_name'}]

# Generated at 2022-06-22 21:27:49.926060
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'state': 'present', 'name': 'foo'}
    validation_result = ValidationResult(parameters)
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result._validated_parameters == {'state': 'present', 'name': 'foo'}


# Generated at 2022-06-22 21:28:00.172736
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import reset_warnings_filters

    # Reset the warnings filters so that it doesn't block the warn below
    reset_warnings_filters()

    validator = ModuleArgumentSpecValidator({'x': {'type': 'str', 'aliases': ['y']}, 'z': {'type': 'str'}}, required_by={'x': ['z']})
    result = validator.validate({'x': 'a', 'y': 'b'})
    assert result.validated_parameters['z'] == 'a'
    assert result.validated_parameters['x'] == 'a'
    assert len(result._warnings) == 1

# Generated at 2022-06-22 21:28:13.210685
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)

    assert validator._mutually_exclusive == mutually_exclusive

# Generated at 2022-06-22 21:28:22.662442
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    my_params = {"hostname":"192.168.0.1"}
    my_validation_result = ValidationResult(my_params)
    assert my_validation_result._unsupported_parameters == set()
    assert my_validation_result._validated_parameters == my_params
    assert my_validation_result._deprecations == []
    assert my_validation_result._warnings == []
    assert my_validation_result.error_messages == []
    assert my_validation_result.validated_parameters == my_params
    assert my_validation_result.unsupported_parameters == set()
    assert my_validation_result.error_messages == []



# Generated at 2022-06-22 21:28:32.666997
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # ArgumentSpecValidator.validate() returns a ValidationResult object.
    # The validated parameters are in the attribute ValidationResult.validated_parameters
    # The errors are in ValidationResult.error_messages

    argument_spec = dict(
        testparam1=dict(required=False, type='str'),
        testparam2=dict(required=False, type='str'),
        testparam3=dict(required=False, type='str'),
        testparam4=dict(required=False, type='str'),
        testparam5=dict(required=False, type='str'),
    )

    mutually_exclusive = [
        ['testparam1', 'testparam2'],
        ['testparam3', 'testparam4', 'testparam5'],
    ]


# Generated at 2022-06-22 21:28:40.643611
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={},
    )

    # Expect:
    assert isinstance(result, ModuleArgumentSpecValidator)
    assert result._mutually_exclusive == []
    assert result._required_together == []
    assert result._required_one_of == []
    assert result._required_if == []
    assert result._required_by == {}
    assert result._valid_parameter_names == set()
    assert result.argument_spec == {}


# Generated at 2022-06-22 21:28:53.116433
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # Test for mutually_exclusive option: Test for mutually_exclusive option:
    # Test for mutually_exclusive option: Test for mutually_exclusive option:
    argument_spec = {
        'mutually_exclusive': {
            'type': 'str',
            'required': False
        }
    }

    mutually_exclusive = [
        'ansible_connection', ['ansible_ssh_priv_key_file', 'ansible_ssh_user']
    ]
    validator = ModuleArgumentSpecValidator(argument_spec=argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate({'mutually_exclusive': 'localhost'})

    assert len(result.errors) == 0
    assert result.error_messages == []


# Generated at 2022-06-22 21:28:59.740194
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:29:10.498649
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test the constructor of class ArgumentSpecValidator."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age'], 'age': ['name']}

# Generated at 2022-06-22 21:29:20.136851
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Unit test for constructor.

    Function to test the constructor of class ModuleArgumentSpecValidator.
    """
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [('name', 'fred', ['age'])]
    required_by = {'age': ['name']}
    ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)


# Generated at 2022-06-22 21:29:24.074485
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-22 21:29:35.674395
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
        'flag': True
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'deprecated': {'version': 2.9, 'removed_in': '3.0'}},
        'flag': {'type': 'bool'},
        'weight': {'type': 'int', 'default': 42, 'required': True},
    }

    mutually_exclusive = [
        ['weight', 'age']
    ]

    validator = ModuleArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive,
    )
    validated_parameters = validator.validate(parameters)

    assert 'name' in validated_

# Generated at 2022-06-22 21:29:47.930431
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {
            'type': 'str',
            'type_check': int,
        },
        'phone_number': {
            'type': 'int',
            'aliases': ['phone_no'],
        },
    }

    parameters = {}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == AnsibleValidationErrorMultiple()

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_param

# Generated at 2022-06-22 21:29:53.488634
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    class TestClass(ModuleArgumentSpecValidator):
        def __init__(self):
            super(TestClass, self).__init__(mutually_exclusive=['key_mutually_exc', 'key_mutually_exc2'])

        def validate(self, parameters):
            pass

    test_instance = TestClass()
    assert test_instance._mutually_exclusive == ['key_mutually_exc', 'key_mutually_exc2']

# Generated at 2022-06-22 21:30:04.323204
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes

    argument_spec = {
        'arg1': {
            'type': 'str',
            'alias': 'old_arg1'
        }
    }

    parameters = {
        'arg1': to_bytes('value1'),
        'old_arg1': to_bytes('value2'),
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['arg1'] == 'value1'
    assert result.error_messages == [
        'Both option arg1 and its alias old_arg1 are set.',
    ]

   