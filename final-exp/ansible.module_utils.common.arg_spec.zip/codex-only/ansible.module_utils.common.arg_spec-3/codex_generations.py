

# Generated at 2022-06-22 21:20:01.177004
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    vresult = ValidationResult(parameters)
    assert vresult.validated_parameters == parameters
    assert vresult.errors == []
    assert vresult.error_messages == []


# Generated at 2022-06-22 21:20:06.818207
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    with pytest.raises(TypeError):
        ArgumentSpecValidator()
    with pytest.raises(TypeError):
        ArgumentSpecValidator(None)
    spec = dict(parameter=dict(required=True, type='str'))
    assert ArgumentSpecValidator(spec)
    assert ArgumentSpecValidator(spec, required_if=['a', 'b'])


# Generated at 2022-06-22 21:20:15.214503
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    _parameters = {"test_parameter": {"required": True, 'type': 'str'}}
    _argument_spec = {"test_parameter": {"required": True, 'type': 'str'}}

    mav = ModuleArgumentSpecValidator(_argument_spec)
    result = mav.validate(_parameters)
    assert len(result.errors) == 1 and isinstance(result.errors[0], RequiredError)

    _parameters = {"test_parameter": "string"}
    result = mav.validate(_parameters)
    assert len(result.errors) == 0

# Generated at 2022-06-22 21:20:25.612344
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    '''
     Test to validate a parameter dictionary against the argument spec.
    '''
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int')
    )
    mutually_exclusive = list()
    required_together = list()
    required_one_of = list()
    required_if = list()
    required_by = dict()
    parameters = dict(
        name='bo',
        age='42'
    )

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == dict(
        name='bo',
        age=42
    )

# Generated at 2022-06-22 21:20:30.454418
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = {'name': 'bo', 'age': 28}
    result = ValidationResult(params)
    assert result._no_log_values == set()
    assert result.validated_parameters == params
    assert result._warnings == list()
    assert result._deprecations == list()
    assert result.errors.messages == list()


# Generated at 2022-06-22 21:20:41.710057
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'str'},
        'c': {'type': 'str'},
        'd': {'type': 'str'},
        'e': {'type': 'str'},
    }

    mutually_exclusive = [['a', 'b'], ['c', 'd']]
    required_together = [['a', 'b'], ['c', 'd'], ['e', 'a']]
    required_one_of = [['a', 'b'], ['c', 'd'], ['e', 'a']]
    required_if = [{'param': 'a', 'value': 'b', 'required_param': ['c', 'd', 'e']}]

# Generated at 2022-06-22 21:20:49.953029
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'needs': {
            'type': 'dict',
            'options': {
                'food': {'type': 'str',},
                'water': {'type': 'bool',},
            },
        },
        'home': {
            'type': 'list',
            'elements': 'dict',
            'options': {
                'address': {'type': 'str'},
                'city': {'type': 'str'},
                'state': {'type': 'str'},
            },
        },
    }
    mutually_exclusive = [['food', 'water'], ['address', 'city']]

# Generated at 2022-06-22 21:21:02.054444
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'foo': {
            'type': 'dict',
            'options': {
                'bar': {'type': 'str'},
                'baz': {'type': 'int'},
            }
        },
    }

    test_params = {
        'name': 'bo',
        'age': '42',
        'foo': {
            'bar': '1',
            'baz': '2',
        },
    }

    errors = AnsibleValidationErrorMultiple()
    _validate_sub_spec(arg_spec, test_params, errors)
    # Errors should be empty
    assert len(errors) == 0

    arg_spec['age']['type']

# Generated at 2022-06-22 21:21:10.800984
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys, traceback

    module_name = 'test_module'
    # Results of the test
    class SimpleResult:
        def __init__(self, result):
            self.result = result
        def to_dict(self):
            return self.result

    # Mock parameters that can be passed by the user
    class Params:
        def __init__(self, name=None, age=None, boolean=None):
            self.name = name
            self.age = age
            self.boolean = boolean

    # Mock the module class
    class AnsibleModuleMock:
        def __init__(self, *args, **kwargs):
            pass

        @staticmethod
        def fail_json(msg):
            sys.exit("{0}: {1}".format(module_name, msg))


# Generated at 2022-06-22 21:21:22.086738
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age", ["name", "age"]]]
    required_by = {'name': ["age"], 'age': ["name"]}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)
    assert (validator.argument_spec == argument_spec)
    assert (validator._mutually_exclusive == mutually_exclusive)
    assert (validator._required_together == required_together)
   

# Generated at 2022-06-22 21:21:31.970289
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test with no argument_spec and no parameters
    argument_spec = {}
    parameters = {}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.errors.messages == list()
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()

    # Test with no argument_spec and no parameters
    argument_spec = {}
    parameters = {'name': 'bo'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.errors.messages == ['Unexpected parameter "name"']
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set(['name'])

    # Test with argument_

# Generated at 2022-06-22 21:21:32.857911
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  pass

# Generated at 2022-06-22 21:21:42.128770
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'height': {'type': 'str'},
        'weight': {'type': 'str'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'height': 'short',
        'weight': 'light',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.errors:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))


# Generated at 2022-06-22 21:21:49.066085
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {'type': 'str', 'required': True},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert validator



# Generated at 2022-06-22 21:21:58.840698
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case where there are no errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    # Test case where there is one error
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-22 21:22:05.290023
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._valid_parameter_names == {'name', 'age'}


# Generated at 2022-06-22 21:22:07.561722
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({})



# Generated at 2022-06-22 21:22:16.353130
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # set up validation result
    parameters = {'name': 'bo'}
    validation_result = ValidationResult(parameters)

    # check if _no_log_values is set
    assert(not validation_result._no_log_values)

    # check if _validated_parameters is set
    assert(validation_result._validated_parameters == parameters)

    # check if _deprecations is set
    assert(not validation_result._deprecations)

    # check if _warnings is set
    assert(not validation_result._warnings)

    # check if errors is set
    assert(validation_result.errors)


# Generated at 2022-06-22 21:22:22.382689
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo', 'age': '42'})
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert result.unsupported_parameters == set()


# Generated at 2022-06-22 21:22:23.172817
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert ModuleArgumentSpecValidator()

# Generated at 2022-06-22 21:22:32.088636
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    v = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    p = {'name': 'bob'}
    r = v.validate(p)
    assert r.validated_parameters == p
    assert r.error_messages == []

    v = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    p = {'name': 42}
    r = v.validate(p)
    assert r.validated_parameters == {}
    assert r.error_messages == ['name (42) is not of type str']

    p = {'name': 'bob'}
    r = v.validate(p)
    assert r.validated_parameters == p
    assert r.error_messages == []


# Generated at 2022-06-22 21:22:40.968982
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = { 'name': 'bo', 'age': '42' }
    result = ValidationResult(parameters)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []

    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:22:45.752484
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    _ModuleArgumentSpecValidator = ModuleArgumentSpecValidator({'name': {'type': 'str'}},
                                                               mutually_exclusive=[['name']])
    assert _ModuleArgumentSpecValidator.validate({'name': 'bo'}).error_messages == [
        'the following arguments are mutually exclusive: name']



# Generated at 2022-06-22 21:22:52.700249
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    parameter = {
        'name': 'bo',
        'age': '42',
        'qqq': '444',
        'bbb': '555'
    }
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'bbb': {'type': 'str'},
        'ccc': {'type': 'str'}
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameter)

    assert result.error_messages == [
        'Unsupported parameters for (ansible.module_utils.basic.AnsibleModule) module: qqq Supported parameters include: age, bbb, ccc, name'
    ]

# Generated at 2022-06-22 21:23:02.850638
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-22 21:23:05.823416
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test that ArgumentSpecValidator creates an instance"""
    validator = ArgumentSpecValidator({'option_a': {'type': 'int'}, 'option_b': {'type': 'int'}})
    assert validator is not None
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:23:16.298212
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ''' Test ModuleArgumentSpecValidator constructor to verify correct use of super() '''
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = ['name']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'Bob', ['age']]]
    required_by = {'name': ['age']}

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_

# Generated at 2022-06-22 21:23:23.741135
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec={'age': {'type': 'int', 'default': 0, 'aliases': ['age_alias']},
                   'name': {'type': 'str'},
                   'gender': {'type': 'bool', 'default': False},
                   'single': {'type': 'bool', 'default': True},
                   'objects': {'type': 'dict'},
                   'subspec': {'address': {'type': 'dict'}},
                   }
    mutually_exclusive=['age', 'name']
    required_if=[['name', 'female', ['age']]]
    required_one_of=[['name', 'age']]
    required_together=[['name', 'age']]

# Generated at 2022-06-22 21:23:28.954488
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    #assert ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}}, mutually_exclusive=['name'], required_together=['name'], required_one_of=['name'], required_if='name', required_by='name')
    print('test_ArgumentSpecValidator is passed.')


# Generated at 2022-06-22 21:23:36.661402
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    a = {"git_diff_strategy": {'type': 'str',
                               'choices': ['noprefix', 'no_prefix', 'minimal', 'patience', 'histogram', 'myers'],
                               'default': 'patience'},
         "git_diff_options": {'type': 'list', 'default': ['--stat'], 'elements': 'str'},
         "git_diff_ignore_submodules": {'type': 'str', 'choices': ['none', 'untracked', 'dirty', 'all'],
                                        'default': 'all'}}

    ArgumentSpecValidator(a)



# Generated at 2022-06-22 21:23:46.606513
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'repo': {'type': 'str'},
        'project': {'type': 'str'},
        'branch': {'type': 'str'},
        'output_directory': {'type': 'str'},
        'command': {'type': 'str'},
        'keep_repo': {'type': 'bool', 'default': True},
        'force_clone': {'type': 'bool', 'default': False},
        'plugin_dir': {'type': 'str', 'default': 'playbooks/plugins'},
        'state': {'type': 'str', 'default': 'present', 'choices': ['present', 'absent']},
        'comment': {'type': 'str', 'default': ''},
    }


# Generated at 2022-06-22 21:23:48.473874
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name":{"type":"str"}}
    assert ArgumentSpecValidator(argument_spec) is not None

# Generated at 2022-06-22 21:23:56.973473
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Testing validate method of ArgumentSpecValidator
    # data to create an ArgumentSpecValidator instance
    params = {
        "option1": "value1",
        "option2": "value2"
    }
    # data to create an ArgumentSpecValidator instance
    argument_spec = {
        "option1": {"type": "str", "required": True},
        "option2": {"type": "str"}
    }

    v = ArgumentSpecValidator(argument_spec)
    # data to validate an ArgumentSpecValidator
    result = v.validate(params)

    assert result.validated_parameters == params



# Generated at 2022-06-22 21:23:58.430146
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({})

# Generated at 2022-06-22 21:24:09.730692
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class TestModule(object):
        def __init__(self, result):
            self.result = result

        def deprecate(self, message, version, date, collection_name):
            d = {'name': message}
            if version:
                d['version'] = version
            if date:
                d['date'] = date
            if collection_name:
                d['collection_name'] = collection_name
            self.result['deprecations'].append(d)

        def warn(self, message):
            self.result['warnings'].append(message)


# Generated at 2022-06-22 21:24:11.484056
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Instantiate ModuleArgumentSpecValidator object. Since no special attribute is required, there is no need to pass in
    # any special argument to the constructor.
    test_object = ModuleArgumentSpecValidator()
    assert isinstance(test_object, ModuleArgumentSpecValidator) == True



# Generated at 2022-06-22 21:24:18.075859
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec_validator_test = ModuleArgumentSpecValidator({'test_key':{'type': 'str', 'aliases':['test_key_alias']}})
    assert arg_spec_validator_test
    assert 'test_key' in arg_spec_validator_test._valid_parameter_names
    assert 'test_key (test_key_alias)' in arg_spec_validator_test._valid_parameter_names



# Generated at 2022-06-22 21:24:23.170479
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    v = ModuleArgumentSpecValidator({
        'name': {'type': 'str', 'required': True, 'no_log': True},
        'age': {'type': 'int', 'default': 42},
    })
    assert isinstance(v, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:24:28.362595
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

    validator = ArgumentSpecValidator(argument_spec)

    # pylint: disable=protected-access
    assert len(validator._valid_parameter_names) == 2
    assert 'name' in validator._valid_parameter_names
    assert 'age' in validator._valid_parameter_names
    # pylint: enable=protected-access

# Generated at 2022-06-22 21:24:35.362882
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)

    assert not result._no_log_values
    assert not result._unsupported_parameters
    assert not result._validated_parameters
    assert not result._deprecations
    assert not result._warnings
    assert not result.errors



# Generated at 2022-06-22 21:24:42.872587
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str'},
        'param3': {'type': 'list'},
        'param4': {'type': 'str'},
        'param5': {'type': 'str'},
        'param6': {'type': 'str'},
    }
    mutually_exclusive = [['param1', 'param2'], ['param3', 'param4']]
    required_together = [['param1', 'param2'], ['param2', 'param3']]
    required_one_of = [['param5', 'param6']]
    required_if = [['param5', 'test', ['param1']]]
    required_by = {'param6': ['param5']}

   

# Generated at 2022-06-22 21:24:45.582521
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Validate the constructor of class ModuleArgumentSpecValidator"""
    assert (ModuleArgumentSpecValidator is not None)

# Generated at 2022-06-22 21:24:49.545181
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [['one', 'two'], ['three', 'four']]
    required_together = [['one', 'two'], ['three', 'four']]
    required_one_of = [['one', 'two']]
    required_if = [['one', 'is_one', ['two']]]
    required_by = {'one': ['two']}

    argument_spec = {
        'one': {'type': 'str'},
        'two': {'type': 'str'},
        'three': {'type': 'str'},
        'four': {'type': 'str'}
    }

# Generated at 2022-06-22 21:25:01.064024
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test exception: alias is not string or list
    argument_spec = {
        'name': {'type': 'str', 'aliases': 0},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 1
    assert result.error_messages[0] == "The alias must be a string or a list."
    # Test exception: required_if list is not a list
    argument_spec = {
        'name': {'type': 'str', 'aliases': 0},
        'age': {'type': 'int'},
    }
    parameters

# Generated at 2022-06-22 21:25:10.939095
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {'type': 'str', 'aliases': ['status']},
        'user': {
            'type': 'dict',
            'options': {'name': {'type': 'str'},
                        'password': {'type': 'str',
                                     'no_log': True},
                        'group': {'type': 'list', 'elements': 'str'}},
        },
    }

    mutually_exclusive = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:25:20.021460
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def deprecate_mock(msg, version, date, collection_name):
        assert msg == "Alias 'option' is deprecated. See the module docs for more information"
        assert version == "9.9.9"
        assert date == "2099-01-01"
        assert collection_name == "test_module"

    def warn_mock(msg):
        assert msg == "Both option option and its alias alias are set."


# Generated at 2022-06-22 21:25:32.580997
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    _validator = ModuleArgumentSpecValidator({}, {}, {}, {}, {})
    class _FakeValidationResult:
        def __init__(self):
            self.errors = {}
            self.validated_parameters = {}
            self.no_log_values = []
            self._deprecations = []
            self._warnings = []

    result = _FakeValidationResult()
    result.errors = {"error": True}
    result._deprecations = ["foo"]
    result._warnings = ["bar"]

    class _FakeModule:
        def __init__(self):
            self.fail_json = lambda: None

    import sys
    orig_stdout = sys.stdout
    sys.stdout = ""

# Generated at 2022-06-22 21:25:44.300471
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:25:45.732082
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'parameters': {}})
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-22 21:25:48.548774
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:25:53.933148
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult('parameters')

    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == 'parameters'
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-22 21:26:01.918574
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_args = {'test_name': {'type': 'str'}, 'test_age': {'type': 'int'}}
    test_param = {'test_name': 'test_name', 'test_age': '20'}
    test_validator = ArgumentSpecValidator(test_args)
    test_result = test_validator.validate(test_param)
    assert test_result.validated_parameters['test_name'] == 'test_name'
    assert test_result.validated_parameters['test_age'] == 20

# Generated at 2022-06-22 21:26:14.098215
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['age','name']
    required_together = [['age','name']]
    required_one_of = [['age','name']]
    required_if = [['age', '^42$', ['name']]]
    required_by = {'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of

# Generated at 2022-06-22 21:26:19.182820
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    parameters = {
        'name': 'bo',
        'age': 10
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    # validator.validate method will do validation,
    # deprecation and warning will be done in this method
    assert len(result._deprecations) == 0
    assert len(result._warnings) == 0

    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 10
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:26:28.709702
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'location': {'type': 'str'},
        'gender': {'type': 'str'},
        'year': {'type': 'int'},
        'test': {'type': 'str',
                 'default': 'test_default'}
    }

    parameters = {
        'name': 'bo_answer',
        'age': '42',
        'location': 'SF',
        'gender': 'male',
        'year': 2020,
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:26:40.214473
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    class test_ValidationResult:
        def __init__(self):
            self._no_log_values = set()
            self._unsupported_parameters = set()
            self._validated_parameters = {}
            self._deprecations = []
            self._warnings = []
            self.errors = AnsibleValidationErrorMultiple()

        def validate(self, parameters):
            self._no_log_values.update({'test'})
            self._unsupported_parameters.update({'test'})
            self._validated_parameters = parameters
            self._deprecations.append({'name': 'name'})
            self._warnings.append({'option': 'option', 'alias': 'alias'})
            return self

        @property
        def validated_parameters(self):
            return self._validated_

# Generated at 2022-06-22 21:26:45.010319
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-22 21:26:48.619958
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    args = {'argument_spec': {'age': {'type': 'int'}, 'name': {'type': 'str'}}, 'required_by': {'state': ['save']}}
    assert isinstance(ModuleArgumentSpecValidator(args['argument_spec'], **args), ArgumentSpecValidator)

# Generated at 2022-06-22 21:26:56.604679
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['name', 'age']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'test', ['age']]]
    required_by = {'name': ['age']}

    # call the ArgumentSpecValidator constructor
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by
                                      )

    parameters

# Generated at 2022-06-22 21:27:04.913066
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a instance of ArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        mutually_exclusive=[['name', 'age']],
        required_together=[['name', 'age']]
    )

    result = validator.validate({
        'name': 'bo',
        'age': '42',
    })

    # The validation result must be an instance of ValidationResult
    assert isinstance(result, ValidationResult)

    # Expect the _validated_parameters is an instance of dict
    assert isinstance(result._validated_parameters, dict)
    assert result._validated_parameters == {'name': 'bo', 'age': 42}

    #

# Generated at 2022-06-22 21:27:06.968052
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test case tests the correct functionality of the constructor of class ArgumentSpecValidator"""

    assert ArgumentSpecValidator != None

# Generated at 2022-06-22 21:27:10.727421
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = dict(
        name = dict(type='str'),
        age = dict(type='int')
    )
    validator = ModuleArgumentSpecValidator(spec)
    assert validator.argument_spec == spec


# Generated at 2022-06-22 21:27:23.161174
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'one': {'type': 'int', 'default': 1},
        'two': {'type': 'int', 'default': 2, 'deprecated': {'version': '2.10',
                                                            'removed_in': '3.0',
                                                            'why': 'It\'s best to avoid this option'}},
        'three': {'type': 'int', 'default': 3, 'removed': {'version': '2.11',
                                                          'why': 'This option was never meant to be here'}},
        'four': {'type': 'int', 'default': 4, 'collection_name': 'test_collection'},
    }

# Generated at 2022-06-22 21:27:31.337120
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutex = [
                ['a', 'b']
            ]
    required = [
                ['c', 'd']
            ]
    required_oneof = [
                ['e', 'f']
            ]
    required_if = [
                ['g', 1, ['h', 'i']]
            ]
    required_by = {
        'j': ['k', 'l']
    }

# Generated at 2022-06-22 21:27:36.511952
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:27:45.678105
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    params = {
        'name': 'bo',
    }

    argument_spec = {
        'name': {'type': 'str'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(params)

    params = {
        'name': 'bo',
        'type': 'user',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'type': {'type': 'str'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(params)
    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:27:46.764882
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult('test')


# Generated at 2022-06-22 21:27:49.519354
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(argument_spec={'foo': dict(type='string')})
    assert validator.argument_spec['foo']['type'] == 'string'

# Generated at 2022-06-22 21:27:58.570231
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method ModuleArgumentSpecValidator.validate"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '3',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 3}
    assert result.error_messages == []


if __name__ == '__main__':
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-22 21:28:08.116922
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = {"name": "bo", "age": "42"}
    arg_spec = {
                    "name": {'type': 'str'},
                    'age':  {'type': 'int'},
                }
    argument_spec_validator = ArgumentSpecValidator(arg_spec)

    result = argument_spec_validator.validate(params)
    assert result.validated_parameters == {"age": 42, "name": "bo"}
    assert result.error_messages == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:28:17.413632
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-22 21:28:25.648361
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
        ['name', 'sex'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'sex'],
    ]

    required_if = [
        ['name', 'age'],
    ]

    required_by = {
        'name': ['age'],
    }


# Generated at 2022-06-22 21:28:36.804412
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    spec = {
        'name': dict(type='str', aliases=['name2']),
        'age': dict(type='int'),
    }

    x = ArgumentSpecValidator(spec)
    y = x.validate(dict(name='bo', age='42'))

    assert y.validated_parameters == dict(name='bo', age=42)
    assert y.error_messages == []
    assert y.unsupported_parameters == []

    y = x.validate(dict(name='bo', age=42))
    assert y.validated_parameters == dict(name='bo', age=42)
    assert y.error_messages == []
    assert y.unsupported_parameters == []


# Generated at 2022-06-22 21:28:45.429131
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name']]
    required_if = [['name', 'age', ['name', 'age']]]

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together

# Generated at 2022-06-22 21:28:56.333756
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit test for method validate of class ModuleArgumentSpecValidator"""

    # set up test
    from ansible import constants
    from ansible.plugins.loader import module_loader
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.module_utils.connection import Connection

    class ModuleDeprecate:
        """Class for Module Deprecation"""

        def __init__(self):
            self._deprecations = []

        def deprecate(self, *args, **kwargs):
            self._deprecations.append({'args': args, 'kwargs': kwargs})

        @property
        def deprecations(self):
            return self._deprecations

    class ModuleWarn:
        """Class for Module Warnings"""

       

# Generated at 2022-06-22 21:28:59.231541
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # This test is for the side effects during module instantiation, so the return value is not used.
    ModuleArgumentSpecValidator({})

# Generated at 2022-06-22 21:29:09.544830
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Test the validate method of class ArgumentSpecValidator
    """
    # Setup
    argument_spec = {
        'name': {},
        'age': {},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = None
    required_one_of = None
    required_if = None

    parameters = {
        'name': 'bo',
        'age': '42',
        'sex': 'male',
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    # Execute
    result = validator.validate(parameters)

    # Validate
    assert len(result.errors) == 0


# Generated at 2022-06-22 21:29:16.459850
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Build the argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Create a validator
    validator = ArgumentSpecValidator(argument_spec)

    # Assert that the validator can return an empty result
    assert isinstance(validator.validate({}), ValidationResult)



# Generated at 2022-06-22 21:29:25.302931
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test init
    assert ArgumentSpecValidator({'key': {'type': 'str'}}) is not None
    assert ArgumentSpecValidator({'key': {'type': 'str'}}) is not None

    # Test init with additional arguments
    assert ArgumentSpecValidator({'key': {'type': 'str'}},
                                 mutually_exclusive=[['key']],
                                 required_together=[['key']],
                                 required_if=[['key', 'true', ['key']]],
                                 required_one_of=[['key']],
                                 required_by={'key': ['key']}) is not None

# Generated at 2022-06-22 21:29:36.770434
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import mock
    # If this test fails to import mock for some reason, then it will not be listed as a test.
    # Since unittest.TestCase creates a new instance of the test class for each test,
    # it is OK if the class has an instance attribute __dict__.  It is not OK if there is a
    # class attribute __dict__.

# Generated at 2022-06-22 21:29:43.608792
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # These tests are not exhaustive but simply show that the code runs
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.parameters import ModuleParameters
    validator = ModuleArgumentSpecValidator({'count': {'type': 'int'}})
    result = validator.validate({'count': 1})
    assert isinstance(result, ModuleParameters)

# Generated at 2022-06-22 21:29:54.843145
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import PY3
    import sys

    params = {
        'age': '42',
        'name': 'bo'
    }

    spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str'},
    }

    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(params)

    assert "int" not in result._validated_parameters['age'].__class__.__name__
    assert PY3 or "long" not in result._validated_parameters['age'].__class__.__name__
    assert result._validated_parameters['age'] == 42

    assert result._validated_parameters['name'] == 'bo'
    assert "str" not in result

# Generated at 2022-06-22 21:29:56.422831
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator({"argument_spec": {}})


# Generated at 2022-06-22 21:30:06.362027
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test for method validate of class ArgumentSpecValidator"""

    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}

    parameters = {'name': 'bo',
                  'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        print("Validation failed: {}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42


