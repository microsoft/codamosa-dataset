

# Generated at 2022-06-22 21:20:02.008292
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert(isinstance(validator, ModuleArgumentSpecValidator))

# Generated at 2022-06-22 21:20:05.936938
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    m = ModuleArgumentSpecValidator(argument_spec)
    assert m is not None


# Generated at 2022-06-22 21:20:16.501102
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Create a validator and validate parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {
            'type': 'int',
            'default': 42
        },
        'child': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'}
            }
        }
    }

# Generated at 2022-06-22 21:20:27.529689
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import ArgumentSpec
    spec = {
        "name": {"required": True, "type": "str"},
        "size": {"required": True, "type": "int"},
        "state": {"default": "present", "choices": ["present", "absent"], "type": "str"}
    }
    spec = ArgumentSpec.from_dict(spec)
    spec_validator = ArgumentSpecValidator(spec.argument_spec)
    # Test for required parameters
    result = spec_validator.validate({})
    assert result.error_messages == ['required field is missing: name', 'required field is missing: size']
    # Test for invalid parameters

# Generated at 2022-06-22 21:20:29.515116
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'key1': 'value1'}
    _result = ValidationResult(parameters)
    assert _result is not None


# Generated at 2022-06-22 21:20:37.235127
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert(isinstance(result.validated_parameters, dict))
    assert(result.validated_parameters['name'] == 'bo')
    assert(result.validated_parameters['age'] == 42)

# Generated at 2022-06-22 21:20:41.812482
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
    }
    parameters = {
        'name': 'bo',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0

# Generated at 2022-06-22 21:20:44.739199
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert not result.errors

# Generated at 2022-06-22 21:20:54.229435
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ''' Validate the constructor of class ValidationResult'''
    assert 'validated_parameters' not in vars(ValidationResult({}))
    assert '_no_log_values' not in vars(ValidationResult({}))
    assert '_unsupported_parameters' not in vars(ValidationResult({}))
    assert '_deprecations' not in vars(ValidationResult({}))
    assert '_warnings' not in vars(ValidationResult({}))
    assert 'errors' not in vars(ValidationResult({}))



# Generated at 2022-06-22 21:20:58.876079
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert set(result._validated_parameters) == set()
    assert set(result._no_log_values) == set()
    assert set(result._unsupported_parameters) == set()
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:21:04.475025
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    try:
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }

        validator = ArgumentSpecValidator(argument_spec)

    except (TypeError, ValueError) as e:
        raise AssertionError("test failed: ArgumentSpecValidator constructor failed") from e



# Generated at 2022-06-22 21:21:06.119969
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult(parameters={'test1': 'test2'}), ValidationResult)

# Generated at 2022-06-22 21:21:13.236281
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Test the ModuleArgumentSpecValidator.validate() method """

    # A deprecation message should be printed out when an alias is deprecated
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias_name']},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
        'collection': 'ansible_collections.ansible.community.plugins'
    }
    # Execute the validate method
    result = validator.validate(parameters)

    # There should be no error message
    assert result.error_messages == []

    # A deprecation message should be printed out for 'alias_name'

# Generated at 2022-06-22 21:21:18.532712
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert hasattr(ModuleArgumentSpecValidator, '__init__')
    assert hasattr(ModuleArgumentSpecValidator, 'validate')

# Unit test to check if method validate and validate_argument_types call the respective methods
from ansible.module_utils.common.validation import check_required_arguments
from ansible.module_utils.common.validation import check_mutually_exclusive
from ansible.module_utils.common.validation import _validate_argument_types
import pytest
from unittest.mock import patch


# Generated at 2022-06-22 21:21:27.122149
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict(a=[12, 3, 45, 6],
                      b=['hello', 'world'],
                      c=['h5n1', 'h3n2'])
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == list()
    assert result._warnings == list()
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:21:34.702230
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import iteritems


# Generated at 2022-06-22 21:21:46.577677
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Test for the constructor of class ArgumentSpecValidator"""
    import pytest

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=['c', 'd'],
                                      required_together=[[['p', 'q'], ['r', 's']]],
                                      required_one_of=[[['p', 'q'], ['r', 's']]],
                                      required_if=[['a', 'b', ['c', 'd']]],
                                      required_by={'name': ['age']}
                                      )

    assert validator._mutually_exclusive == ['c', 'd']

# Generated at 2022-06-22 21:21:54.179173
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec =  {
        'name': {
            'type': 'str',
            'required': True,
            'aliases': ['user']
        },
        'age': {
            'type': 'int',
            'required': True,
        },
        'age_optional': {
            'type': 'int',
            'required': False,
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator

# Generated at 2022-06-22 21:21:58.749895
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {"name": dict(type="str")}
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:22:00.945601
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    with pytest.raises(TypeError):
        ModuleArgumentSpecValidator()


# Generated at 2022-06-22 21:22:09.187514
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.validation import check_required_arguments

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert is_iterable(result.error_messages)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.validated_parameters, dict)
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:22:18.691115
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    class ValidationResultTest(ValidationResult):
        _no_log_values = set()
        _unsupported_parameters = set()
        _validated_parameters = dict()
        _deprecations = list()
        _warnings = list()
        errors = AnsibleValidationErrorMultiple()

        def __init__(self, parameters):
            super(ValidationResultTest, self).__init__(parameters)

    result = ValidationResultTest({})
    assert result._no_log_values is not None
    assert len(result._no_log_values) == 0
    assert result._unsupported_parameters is not None
    assert len(result._unsupported_parameters) == 0
    assert result._validated_parameters is not None
    assert len(result._validated_parameters) == 0
    assert result

# Generated at 2022-06-22 21:22:22.517744
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Validate that the expected exception is thrown when a missing argument spec is passed.
    """

    try:
        ArgumentSpecValidator(None)
    except Exception as err:
        assert isinstance(err, ValueError)



# Generated at 2022-06-22 21:22:23.462898
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator is not None

# Generated at 2022-06-22 21:22:24.046773
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-22 21:22:33.185205
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Test alias deprecation warning
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['myname']},
    }
    parameters = {
        'name': 'bo',
        'myname': 'kim',
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ModuleArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:22:37.568014
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.arg_spec import ArgumentSpecValidator
    moduleargumentvalidator = ModuleArgumentSpecValidator()
    assert isinstance(moduleargumentvalidator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:22:47.288115
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    dict_type = dict(type='dict')
    path_type = dict(type='path')
    type_error = {'error': 'This is a type error'}
    value_error = {'error': 'This is a value error'}
    required_error = {'error': 'This is a required error'}
    mutually_exclusive_error = {'error': 'This is a mutually exclusive error'}
    required_together_error = {'error': 'This is a required together error'}
    required_one_of_error = {'error': 'This is a required one of error'}
    required_if_error = {'error': 'This is a required if error'}
    required_by_error = {'error': 'This is a required by error'}

# Generated at 2022-06-22 21:22:55.395126
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    MODULE_ARGUMENT_SPEC = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(MODULE_ARGUMENT_SPEC)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0, "Should not have any errors"

# Generated at 2022-06-22 21:22:57.421815
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator(), ArgumentSpecValidator)

# Generated at 2022-06-22 21:23:09.203304
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [('name', 'age', ['age'])]
    required_by = {'name': ['age'], 'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert isinstance

# Generated at 2022-06-22 21:23:12.639012
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # should pass
    ModuleArgumentSpecValidator({"name": {"type": "str", "default": "bo", "aliases": ["foo"]},
                                 "age": {"type": "int", "default": 42}})


# Generated at 2022-06-22 21:23:22.594999
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['name', 'age']
    required_together = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_if = [
        ['name', 'age']
    ]
    required_by = {
        'name': 'age'
    }
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                      required_together=required_together, required_one_of=required_one_of,
                                      required_if=required_if, required_by=required_by)


# Generated at 2022-06-22 21:23:28.495609
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argumentspec = {
        'aliases': {'type': 'list'},
        'alias_warnings': {'type': 'list'},
    }
    parameters = {
        'aliases': ['first', 'second'] ,
        'alias_warnings': ['name'],
    }
    validator = ArgumentSpecValidator(argumentspec)
    result = validator.validate(parameters)

    assert result.validated_parameters['aliases'] == ['first', 'second']

# Generated at 2022-06-22 21:23:35.509747
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    print(valid_params['age'])

# Generated at 2022-06-22 21:23:41.336708
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    params = {'one': 'value', 'two': 'value', 'three': 'value'}
    argspec = {'one': {'type': 'str'},
               'two': {'type': 'str'},
               'three': {'type': 'str'}}
    with ModuleArgumentSpecValidator(argspec) as validator:
        validator.validate(params)

# Generated at 2022-06-22 21:23:49.699765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''Test class ModuleArgumentSpecValidator, method validate for the following scenarios:
        - No Parameters given
        - One valid parameter given
        - One invalid parameter given
        - One deprecation given
        - One alias warning set given
        - One required parameter given
    '''

    from ansible.module_utils.common.parameters import sanitize_keys
    import sys

    asv = ModuleArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            'birth': {'type': 'str'},
        },
        mutually_exclusive=(('name', 'age'),),
        required_together=(('name', 'birth'),)
    )

    #case 1: No Parameters given
    result = asv.validate({})

# Generated at 2022-06-22 21:23:56.094486
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'ignore': 'here'}
    validateResult = ValidationResult(parameters)
    assert validateResult._validated_parameters == parameters
    assert validateResult._no_log_values == set()
    assert validateResult._unsupported_parameters == set()
    assert validateResult._deprecations == []
    assert validateResult._warnings == []
    assert validateResult.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-22 21:24:06.301674
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'new_param': {'type': 'str', 'aliases': ['old_param']},
    }

    parameters = {
        'new_param': 'foo',
        'old_param': 'bar',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'new_param': 'foo'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-22 21:24:17.595872
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
        'sex': {'type': 'str', 'choices': ['male', 'female']},
    }

    validator = ArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
        'sex': 'male',
    }

    result = validator.validate(parameters)
    assert len(result.error_messages) == 0
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.validated_parameters['sex'] == 'male'


# Generated at 2022-06-22 21:24:28.131588
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [('name', 'age'),]
    required_together = [('name', 'age'),]
    required_one_of = [('name', 'age'),]
    required_if = [('name', 'age', ['name']),]
    required_by = {'name': ['age'],}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                      required_together=required_together, required_one_of=required_one_of,
                                      required_if=required_if, required_by=required_by)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_

# Generated at 2022-06-22 21:24:29.736972
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({}, None, None, None, None, None)

# Generated at 2022-06-22 21:24:39.980219
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ase = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(ase)

    result = validator.validate(parameters)

    assert not result.errors
    assert not result.error_messages
    assert result.unsupported_parameters == set()

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-22 21:24:48.456364
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages
    valid_params = result.validated_parameters

    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

# Generated at 2022-06-22 21:25:00.472950
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ansible_module = dict()
    ansible_module['argument_spec'] = dict()
    ansible_module['argument_spec']['ansible_module'] = dict()
    ansible_module['argument_spec']['ansible_module']['type'] = 'dict'

    ansible_module['argument_spec']['warnings'] = dict()
    ansible_module['argument_spec']['warnings']['type'] = 'list'

    ansible_module['argument_spec']['deprecations'] = dict()
    ansible_module['argument_spec']['deprecations']['type'] = 'list'

    ansible_module['validator'] = ModuleArgumentSpecValidator(ansible_module['argument_spec'])

    parameters = dict()

# Generated at 2022-06-22 21:25:06.408016
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'},
                     }

    parameters = {'name': 'bo', 'age': '42', }

    validator = ModuleArgumentSpecValidator(argument_spec,
                                  mutually_exclusive=None,
                                  required_together=None,
                                  required_one_of=None,
                                  required_if=None,
                                  required_by=None,
                                  )

    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)

# Generated at 2022-06-22 21:25:16.407357
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import iteritems

    import ansible.module_utils.ansible_module_common as a_m_c

    def _deprecate(msg, version='', date='', collection_name=''):
        raise AssertionError(msg)

    def _warn(msg):
        raise AssertionError(msg)

    # The test will fail if message is incorrect.
    a_m_c.deprecate = _deprecate
    a_m_c.warn = _warn

    # Testing data
    # Key is the filename of the testdata, value is a list of values
    #   - the first value is a dict containing the validated parameter
    #   - the second one is a dict containing deprecations
    #   - the third one is a dict containing warnings
    #   - the fourth one

# Generated at 2022-06-22 21:25:28.304825
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "name": {"type": "str", "required": True},
        "authorized": {"type": "bool", "default": False},
        "groups": {"type": "list", "default": [], "elements": "str"},
        "dictionary": {"type": "dict"},
    }
    mutually_exclusive = [
        ["name", "authorized"],
        ["name", "groups"],
        ["name", "dictionary"],
    ]
    required_together = [
        ["name", "authorized", "groups"],
    ]
    required_one_of = [
        ["name", "authorized"],
    ]
    required_if = [
        ["name", "authorized", "groups"],
    ]

# Generated at 2022-06-22 21:25:39.628249
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    class Test_ArgumentSpecValidator(ArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(Test_ArgumentSpecValidator, self).__init__(*args, **kwargs)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = Test_ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert False == result.errors
    assert 'bo' == result.validated_parameters['name']
    assert 42 == result.validated_parameters['age']

# Generated at 2022-06-22 21:25:44.062826
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    results = {'name': 'bo', 'age': 42}
    assert ValidationResult(results).validated_parameters == results
    assert ValidationResult(results).error_messages == []
    assert ValidationResult(results).unsupported_parameters == set()



# Generated at 2022-06-22 21:25:52.216822
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""
    parameters = {'joe':42, 'wally':0} 
    validationresult = ValidationResult(parameters)
    assert isinstance(validationresult, ValidationResult)
    assert validationresult.validated_parameters == {'joe':42, 'wally':0}
    assert validationresult._no_log_values == set()
    assert validationresult._unsupported_parameters == set()
    assert validationresult.error_messages == []



# Generated at 2022-06-22 21:25:58.159510
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # arrange
    obj = ModuleArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    )

    # act
    result = obj.validate(
        {
            'name': 'bo',
            'age': '42',
        }
    )

    # assert
    assert [
        'age: 42 is not of type int',
    ] == result.error_messages

# Generated at 2022-06-22 21:25:59.168883
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator(), ArgumentSpecValidator)



# Generated at 2022-06-22 21:26:05.124634
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:26:17.091875
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Deprecation
    validator = ModuleArgumentSpecValidator(argument_spec=dict(deprecated_parameter=dict(aliases=['deprecated_alias'], type='str')))
    result = validator.validate(parameters=dict(deprecated_parameter='value'))

    assert len(result._deprecations) == 1
    assert result._deprecations[0] == {'name': 'deprecated_alias', 'version': None, 'date': None, 'collection_name': None}

    # Both the option and alias are set
    validator = ModuleArgumentSpecValidator(argument_spec=dict(normal_parameter=dict(aliases=['normal_alias'], type='str')))

# Generated at 2022-06-22 21:26:28.065727
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    
    import arg_spec as arg_spec
    
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    parameters = {
        'name': 'bo',
        'age': '42',
        }

    validator = arg_spec.ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert type(result) is arg_spec.ValidationResult

    assert result.validated_parameters['age'] == 42
    assert type(result.validated_parameters['age']) == int

    assert type(result.validated_parameters['name']) == str
    assert result.validated_parameters['name'] == 'bo'


# Generated at 2022-06-22 21:26:34.668364
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for constructor of class ValidationResult"""
    # 1. Arrange
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    # 2. Act
    result = ValidationResult(parameters)
    # 3. Assert
    assert result is not None


# Generated at 2022-06-22 21:26:46.112178
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    Test the method ArgumentSpecValidator.validate
    """
    parameter = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                      required_one_of, required_if, required_by)
    result = validator.validate(parameter)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result.unsupported_parameters, set)
    assert isinstance(result.error_messages, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-22 21:26:46.903917
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True

# Generated at 2022-06-22 21:26:55.566557
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.six import string_types

    mutually_exclusive = [['name', 'age'], ['state']]
    required_together = [['name', 'age'], ['state']]
    required_one_of = [['name'], ['age']]
    required_if = [{'state': 'present', 'name': ['required']}, {'state': 'absent', 'age': ['required']}]
    required_by = {'name': ['state'], 'age': ['state']}

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'state': {'type': 'str', 'default': 'present'}
    }


# Generated at 2022-06-22 21:27:04.343339
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn

    original_check_mutually_exclusive = check_mutually_exclusive
    original_deprecate = deprecate
    original_warn = warn

    def mock_check_mutually_exclusive(mutually_exclusive, parameters):
        return original_check_mutually_exclusive(mutually_exclusive, parameters)

    def mock_deprecate(deprecation_msg, version, collection_name=None, date=None):
        return original_deprecate(deprecation_msg, version, collection_name=collection_name, date=date)

    def mock_warn(warning_msg):
        return original_warn(warning_msg)


# Generated at 2022-06-22 21:27:15.933223
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'id': {'type': 'str', 'required': True},
        'age': {'type': 'str'},
    }
    mutually_exclusive = [['id', 'age'], ['id', 'slow']]
    required_together = [['id', 'age']]
    required_one_of = [['id', 'age']]
    required_if = [{'id': 'age', 'required': ['id']}]
    required_by = {'age': ['id']}


# Generated at 2022-06-22 21:27:22.881723
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo'})
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'name': 'bo'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:27:33.496064
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import validate_boolean
    from ansible.module_utils.common.validation import validate_integer
    from ansible.module_utils.common.validation import validate_list
    from ansible.module_utils.common.validation import validate_string


# Generated at 2022-06-22 21:27:38.710026
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = [['a', 'b'], ['c']]
    required_together = [['a', 'b'], ['c']]
    required_one_of = [['a', 'b'], ['c']]
    required_if = [['a', 1, ['b', 'c']]]
    required_by = {'d': ['e']}
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'str'}, 'c': {'type': 'str'}}

# Generated at 2022-06-22 21:27:41.644396
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Test __init__ function of class ModuleArgumentSpecValidator"""
    v = ModuleArgumentSpecValidator({}, None, None, None, None, None)
    assert v is not None

# Generated at 2022-06-22 21:27:53.902881
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test case 1: Normal case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

    # Test case 2: multiple error messages
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }


# Generated at 2022-06-22 21:27:56.862372
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(argument_spec={})
    assert isinstance(validator, ModuleArgumentSpecValidator)
# End unit test for constructor of class ModuleArgumentSpecValidator



# Generated at 2022-06-22 21:28:03.896570
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['mutex1', 'mutex2'],
        ['mutex3', 'mutex4'],
    ]

    required_together = [
        ['req1', 'req2'],
        ['req3', 'req4'],
    ]

    required_one_of = [
        ['req1', 'req2'],
        ['req3', 'req4'],
    ]

    required_if = [
        ['req1', 'val1', ['req2', 'req3']],
        ['req4', 'val4', ['req5', 'req6']]
    ]


# Generated at 2022-06-22 21:28:10.822891
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result._no_log_values == set()
    assert result._validated_parameters == {}
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:28:22.730764
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # the following is a class level compare
    def assert_same_spec(spec_one, spec_two):
        same = True

        same = same and (sorted(spec_one.keys()) == sorted(spec_two.keys()))
        for k in spec_one.keys():
            if same:
                for subk in sorted(spec_one[k].keys()):
                    if spec_one[k][subk] != spec_two[k][subk]:
                        print(spec_one[k][subk])
                        print(spec_two[k][subk])
                        print("%s[%s][%s]" % (k, subk, spec_one[k][subk]))
                        same = False
                        break
            else:
                break

        if same:
            print("same")

# Generated at 2022-06-22 21:28:24.067380
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({}), ArgumentSpecValidator)



# Generated at 2022-06-22 21:28:35.727230
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'comments': {'type': 'list'},
        'details': {'type': 'dict'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'comments': 'These are my comments',
        'details': {},
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'age' in result.validated_parameters
    assert result.validated_parameters['age'] == 42
    assert 'comments' in result.validated_parameters
    assert result.validated_parameters['comments'] == ['These are my comments']



# Generated at 2022-06-22 21:28:44.777761
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'rr': {'type': 'str', 'default': '', 'aliases': ['req_r']},
        'address': {'type': 'str', 'aliases': ['country']}
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'req_r': 'default',
        'country': 'usa'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42, 'address': 'usa', 'rr': ''}


# Generated at 2022-06-22 21:28:54.177857
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    x = {}
    for i in range(1, 7):
        x['v' + str(i)] = i
    mutually_exclusive = [['v1', 'v2'], ['v3', 'v4'], ['v5', 'v6']]
    required_one_of = [['v1', 'v2']]
    required_together = [['v1', 'v2']]
    params = {}
    validator = ModuleArgumentSpecValidator(x, mutually_exclusive, required_together, required_one_of)
    result = validator.validate(params)
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:29:06.149136
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    check_names = ['check_required_arguments', 'check_mutually_exclusive', 'check_required_one_of',
                   'check_required_together', 'check_required_if', 'check_required_by']
    result = ModuleArgumentSpecValidator({}, check_mutually_exclusive=True, check_required_one_of=True,
                                         check_required_together=True, check_required_if=True,
                                         check_required_by=True)
    assert result.validate({'x': {}, 'y': {}, 'z': {}}).errors == []

# Generated at 2022-06-22 21:29:11.901805
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'hostname': '127.0.0.1',
        'port': 80,
        'username': 'admin',
        'password': 'password123',
        'validate_certs': False
    }
    result = ValidationResult(parameters)
    assert result


# Generated at 2022-06-22 21:29:15.278381
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    v = ValidationResult(parameters)


# Generated at 2022-06-22 21:29:23.614695
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import get_validator
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    module = AnsibleModule({}, '', True)

    validator = get_validator(argument_spec, module)
    result = validator.validate(parameters)

    assert not result.error_messages
    assert not result._deprecations
    assert not result._warnings

# Generated at 2022-06-22 21:29:24.496019
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-22 21:29:32.644365
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    class MyArgumentSpecValidator(ArgumentSpecValidator):
        def __init__(self, argument_spec):
            super(MyArgumentSpecValidator, self).__init__(argument_spec)

    # test_constructor_with_simple_argument_spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = MyArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:29:43.979287
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Basic unit tests of class ArgumentSpecValidator.
    """

    mutually_exclusive = [["mutex1", "mutex2"]]
    required_together = [["required1", "required2"]]
    required_one_of = [["required3", "required4"]]
    required_if = [["required5", "required6"]]
    required_by = {"required7" : ["required8"]}
    argument_spec = { "fixed" : { "type" : "str", "default" : "fixed value" } }


# Generated at 2022-06-22 21:29:51.975744
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            }
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
            'name': 'bo',
            'age': '42',
            }
    result = validator.validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42, }
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-22 21:30:03.833528
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.six.moves import redirect_stdout

    argument_spec = {'name': {'type': 'str'},
                     'size': {'type': 'int'},
                     'extra1': {'type': 'str'},
                     'extra2': {'type': 'str'},
                     'extra3': {'type': 'str'},
                     }

    mutually_exclusive = [['extra1', 'extra2']]
    required_together = [['extra2', 'extra3']]
    required_if = [['extra1', 'present', ['extra2', 'extra3']]]
    required_by = {'extra2': ['extra1', 'extra3'],
                   'extra3': ['extra1', 'extra2']}
    required_