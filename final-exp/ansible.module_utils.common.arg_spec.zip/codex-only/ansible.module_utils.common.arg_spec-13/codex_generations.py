

# Generated at 2022-06-22 21:20:06.410759
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Prepare for validation
    argument_spec = {'arg': {'type': 'str', 'required': True}}
    keywords = {'argument_spec': argument_spec}
    module_args = {'arg': 'test'}
    validator = ModuleArgumentSpecValidator(**keywords)
    result = validator.validate(module_args)

    # Test result
    assert result.validated_parameters == {'arg': 'test'}
    assert not result.errors

# Generated at 2022-06-22 21:20:15.171696
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    print(valid_params)

# Generated at 2022-06-22 21:20:19.396233
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator

# Generated at 2022-06-22 21:20:20.464722
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult([]), ValidationResult)



# Generated at 2022-06-22 21:20:21.006759
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:20:27.785543
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    params = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(params)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))
    valid_params = result.validated_parameters

# Generated at 2022-06-22 21:20:38.195737
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.community.general.tests.unit.compat import mock, unittest
    from ansible.module_utils.common import AnsibleModule
    import ansible.module_utils.common.arg_spec as arg_spec
    import ansible.module_utils.common.validation as validation

    from packets.models_v1 import *
    from packets.models_v2 import *
    from packets.mapping import *
    from packets.operations import *
    from packets.exceptions import *

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)


# Generated at 2022-06-22 21:20:45.012787
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:20:57.254669
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['age', 'name']]
    required_together = [['age', 'name']]
    required_one_of = [['age', 'name']]
    required_if = [['age', 'name']]

    validator = ArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive,
        required_together=required_together,
        required_one_of=required_one_of,
        required_if=required_if)

    result = validator.validate({'age': 42})

    assert len(result.errors) == 1
    assert isinstance(result.errors[0], RequiredError)
    assert str

# Generated at 2022-06-22 21:21:02.668245
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"name": "bo", "age": "42"}
    validation_result = ValidationResult(parameters)

    assert isinstance(validation_result._validated_parameters, dict) 
    assert validation_result._validated_parameters == parameters
    assert isinstance(validation_result.errors, AnsibleValidationErrorMultiple)

# Generated at 2022-06-22 21:21:04.281386
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:21:10.128658
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Test that constructor properly assigns and sets up all instance variables
    test_input = {'name': 'bo'}
    result = ValidationResult(test_input)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == test_input
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Unit tests for class ValidationResult

# Generated at 2022-06-22 21:21:16.438366
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {"a":"a","b":"b"}
    result = ValidationResult(parameter)

    assert result._validated_parameters == parameter
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:21:28.585482
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    '''
    Lets create an object for ValidationResult and validate it for correctness
    '''
    parameters = {'bo': 'Klint', 'age': '42'}
    vr_obj = ValidationResult(parameters)
    assert isinstance(vr_obj.errors, object)
    assert isinstance(vr_obj._validated_parameters, dict)
    # we should see a copy of the input parameter dict we passed to the class
    assert vr_obj._validated_parameters == parameters
    # we expect the validated parameters to be a copy
    assert vr_obj._validated_parameters != parameters
    assert isinstance(vr_obj._unsupported_parameters, set)
    assert isinstance(vr_obj._deprecations, list)
    assert isinstance(vr_obj._warnings, list)
   

# Generated at 2022-06-22 21:21:30.009633
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    data = {'terms': {'first':'1', 'second':'two'}}
    result = ValidationResult(data)
    assert result.validated_parameters['terms']['first'] == '1'


# Generated at 2022-06-22 21:21:36.268376
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'metadata': {
            'type': 'dict',
            'options': {
                'url': {'type': 'str'},
                'index': {'type': 'int'},
            }
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate({'name': 'bo', 'age': '42', 'metadata': {'url': 'https://example.com', 'index': '10'}}, check_sub_spec=True)

    assert len(result.error_messages) == 0
    assert len(result.warnings) == 0
    assert len(result.deprecations) == 0
    assert result.validated

# Generated at 2022-06-22 21:21:47.354127
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """The following tests the class ModuleArgumentSpecValidator
        (see ansible.module_utils.common.arg_spec.py)
    """
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator

    # test alias_error
    result = ModuleArgumentSpecValidator(
        {'option': {'required': True}, 'other': {'required': True, 'aliases': ['alias']}}
    ).validate({'alias': 'test'})
    assert result.errors[0].__class__.__name__ == "AliasError"
    assert result.error_messages[0] == 'An alias was provided, but the option was already set.'
    assert 'alias' not in result.validated_parameters

    # test mutually_exclusive_error

# Generated at 2022-06-22 21:21:53.930494
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []

# Generated at 2022-06-22 21:22:02.204297
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Method validate of class ModuleArgumentSpecValidator returns a result object when called with correct parameters"""
    parameters = {'option_one': 'test_value_one'}
    validator = ModuleArgumentSpecValidator({'option_one': {'type': 'str'}}, required_one_of=[['option_one', 'option_two']])
    result = validator.validate(parameters)
    assert result


# Generated at 2022-06-22 21:22:03.485693
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert isinstance(ArgumentSpecValidator({}), ArgumentSpecValidator)

# Generated at 2022-06-22 21:22:08.113389
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # Create a ModuleArgumentSpecValidator object to test the __init__ method
    test_masv = ModuleArgumentSpecValidator({})

    assert isinstance(test_masv, ArgumentSpecValidator)

# Generated at 2022-06-22 21:22:16.818493
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.error_messages, list)
    assert isinstance(result.validated_parameters, dict)

# Generated at 2022-06-22 21:22:25.838617
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'needs_deprecate': {'type': 'str', 'aliases': ['deprecated'], 'deprecated': {
            'version': '2.13',
            'removed_at_date': '2022-12-31',
            'collection_name': 'community.general'
        }},
        'needs_warning': {'type': 'str', 'aliases': ['warning_me']}
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'deprecated': 'I will be deprecated'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)



# Generated at 2022-06-22 21:22:36.413663
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.path import unfrackpath

    # Create argument spec
    argument_spec = AnsibleModule.argument_spec

    # Remove REMOVED parameters
    with open(unfrackpath("../../lib/ansible/constants.py"), "r") as f:
        argument_spec = dict(x for x in argument_spec.items() if '_REMOVED_' not in f.read())

    # Coerce to YAML
    validator = ArgumentSpecValidator(argument_spec)
    print(validator)
    print(validator.argument_spec)

# Generated at 2022-06-22 21:22:38.760893
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}})
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:22:45.182814
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {'name': 'bo', 'age': '42'}
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo', 'The expected result is not returning'
    assert result.validated_parameters['age'] == 42, 'The expected result is not returning'

# Generated at 2022-06-22 21:22:49.213184
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {'test': {'type': 'str'}}
    mod_arg_spec = {'test': {'type': 'str', 'deprecated': [{'name': 'test', 'version': '2.2'}]}}
    assert ArgumentSpecValidator(arg_spec)
    assert ModuleArgumentSpecValidator(mod_arg_spec)

# Generated at 2022-06-22 21:22:50.520960
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(None)
    assert validator.validate(None) == None

# Generated at 2022-06-22 21:22:57.839292
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult({})
    assert isinstance(vr._no_log_values, set)
    assert isinstance(vr._unsupported_parameters, set)
    assert isinstance(vr._validated_parameters, dict)
    assert isinstance(vr._deprecations, list)
    assert isinstance(vr._warnings, list)
    assert isinstance(vr.errors, AnsibleValidationErrorMultiple)
    assert isinstance(vr.validated_parameters, dict)
    assert isinstance(vr.unsupported_parameters, set)
    assert isinstance(vr.error_messages, list)

# Generated at 2022-06-22 21:23:09.678552
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Tests the method  validate of ModuleArgumentSpecValidator."""

    # Test1
    # Testing with unsupported_parameters
    parameter = {"param1": "value1"}
    argument_spec = {"param2": {"required": True}}
    v = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    result = v.validate(parameter)
    assert len(result._unsupported_parameters) == 1


    # Test2
    # Testing with deprecations
    parameter = {"param1": "value1"}

# Generated at 2022-06-22 21:23:18.348387
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = ['a', 'b', ['b', 'c']]
    required_together = [['a', 'b'], ['c']]
    required_one_of = [['a', 'b']]
    required_if = [['a', '1', ['b']]]
    required_by = {'a': ['b']}
    argument_spec = {
        'a': {'type': 'str'},
        'b': {'type': 'str'},
        'c': {'type': 'str'},
    }

# Generated at 2022-06-22 21:23:19.146101
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator(dict())

# Generated at 2022-06-22 21:23:22.252314
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = {'foo': {'type': 'bool'}, 'bar': {'type': 'int', 'aliases': ['baz']}}
    validator = ModuleArgumentSpecValidator(arg_spec)

# Generated at 2022-06-22 21:23:23.463260
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult


# Generated at 2022-06-22 21:23:26.527609
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'foo'}
    vr = ValidationResult(parameters)
    assert vr._validated_parameters == parameters
    assert vr.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:23:29.176483
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42'
    }
    result = ValidationResult(parameters)

    assert result is not None
    assert result.error_messages is None



# Generated at 2022-06-22 21:23:35.389271
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    x = ArgumentSpecValidator(argument_spec={'name':{'type':'str'}, 'age': {'type': 'int'}},
                              mutually_exclusive=[['name', 'age']],
                              required_together=[['name', 'age']],
                              required_one_of=[['name', 'age']],
                              required_if=[['name', 'age', ['age']]],
                              required_by={'name': ['age']})

# Generated at 2022-06-22 21:23:42.440405
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'foo': 'bar'})
    assert result.validated_parameters == {'foo': 'bar'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'foo': 'bar'}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:23:50.253952
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_arg_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}})
    assert module_arg_spec_validator.argument_spec == {'name': {'type': 'str'}}
    assert module_arg_spec_validator._mutually_exclusive == None
    assert module_arg_spec_validator._required_together == None
    assert module_arg_spec_validator._required_one_of == None
    assert module_arg_spec_validator._required_if == None
    assert module_arg_spec_validator._required_by == None
    assert module_arg_spec_validator._valid_parameter_names == ['name']

# Generated at 2022-06-22 21:23:59.675359
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    def assert_same_validator(module, argument_spec):
        spec = ArgumentSpecValidator(argument_spec)

        v = ArgumentSpecValidator(argument_spec)
        assert v == spec

        v = ArgumentSpecValidator(argument_spec,
                                  mutually_exclusive=module.mutually_exclusive,
                                  required_if=module.required_if,
                                  required_one_of=module.required_one_of,
                                  required_together=module.required_together,
                                  required_by=module.required_by)
        assert v == spec

        # New validator with additional checks.
        v = ArgumentSpecValidator(argument_spec, additional_checks=["new"])
        assert v != spec

        # New validator with different required_by.

# Generated at 2022-06-22 21:24:11.539714
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    try:
        validator = ArgumentSpecValidator(argument_spec='an invalid argument spec')
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError when trying to construct ArgumentSpecValidator with an invalid argument_spec")
    try:
        validator = ArgumentSpecValidator(argument_spec=argument_spec, unsupported_parameters='an unsupported_parameters')
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError when trying to construct ArgumentSpecValidator with an unsupported_parameters")

# Generated at 2022-06-22 21:24:16.530544
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {}, 'age': {'type': 'int'}})
    result = validator.validate({'name': 'bo', 'age': '42'})

    assert result.errors == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-22 21:24:28.076996
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_native

    class FakeModule(AnsibleModule):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     mutually_exclusive=None, required_together=None,
                     required_one_of=None, required_if=None, required_by=None,
                     supports_check_mode=False, required_if_one_of=None):
            argument_spec = ArgumentSpec().argument_spec

# Generated at 2022-06-22 21:24:40.444141
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int'},
        'name': {'type': 'str', 'no_log': True},
    }

    mutually_exclusive = [['age', 'name']]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)

    validated_parameters = result.validated_parameters

    answer = {
        'name': 'bo',
        'age': 42,
    }

    assert(validated_parameters == answer)

    assert(len(result.error_messages) == 3)


# Generated at 2022-06-22 21:24:44.599911
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    dict_name = {"name": "john"}
    result = ValidationResult(dict_name)
    assert result._validated_parameters == dict_name
    assert result.errors == AnsibleValidationErrorMultiple()
    

# Generated at 2022-06-22 21:24:57.582638
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    arg_list = {
        'driver': {'type': 'str'},
        'password': {'type': 'str', 'no_log': True},
    }
    mutually_exclusive = [
        ['driver', 'password']
    ]
    kwargs = {
        'required_one_of': [
            ['driver', 'password']
        ],
    }
    validator = ArgumentSpecValidator(argument_spec=arg_list, mutually_exclusive=mutually_exclusive, **kwargs)
    parameters = {
        'password': 'abc'
    }

    result = validator.validate(parameters)

    assert not result.errors
    assert not result.error_messages
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result._no_

# Generated at 2022-06-22 21:25:05.990765
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Fail: the arguments list is specified in the wrong format; a list is expected
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {
        'name': 'Joe',
        'age': '42',
    }
    mutually_exclusive = ['name', 'age']
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)

    result = validator.validate(parameters)
    assert len(result.error_messages) == 1
    assert isinstance(result.errors[0], MutuallyExclusiveError)


    # Fail: required parameters are missing

# Generated at 2022-06-22 21:25:11.781970
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    valid_params = result.validated_parameters


# Generated at 2022-06-22 21:25:17.355672
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42


# Generated at 2022-06-22 21:25:29.419180
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.parameters import (
        sanitize_keys,
        sanitize as _sanitize
    )
    from ansible.module_utils.common.warnings import (
        deprecate as _deprecate,
        warn as _warn
    )


# Generated at 2022-06-22 21:25:33.773442
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
      'name': {'type': 'str'},
      'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:25:35.581949
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator(("a", "b", "c"))



# Generated at 2022-06-22 21:25:47.368720
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def _test(parameters, expected_result, errors=None, return_deprecations=None, return_warnings=None):
        if errors is None:
            errors = []
        if return_deprecations is None:
            return_deprecations = []
        if return_warnings is None:
            return_warnings = []
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
        class A:
            def __init__(self, errors, return_deprecations, return_warnings):
                self.errors = errors
                self.return_deprecations = return_deprecations
                self.return_warnings = return_warnings

# Generated at 2022-06-22 21:25:58.343790
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit tests for constructor of class ArgumentSpecValidator"""

# Generated at 2022-06-22 21:26:05.122376
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {'param_1': 'value_1'}

    result = ValidationResult(parameter)

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'param_1': 'value_1'}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-22 21:26:06.988222
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module = ArgumentSpecValidator()
    assert module


# Generated at 2022-06-22 21:26:08.861646
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator({}) is not None


# Generated at 2022-06-22 21:26:12.299633
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({'option': {'aliases': ['alias']}})
    assert isinstance(validator, ModuleArgumentSpecValidator)
    assert isinstance(validator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:26:17.863129
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert(validator is not None)

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=[['name', 'age']])
    assert(validator is not None)

# Generated at 2022-06-22 21:26:22.000778
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        name=dict(type='str')
    )

    validator = ArgumentSpecValidator(argument_spec, None, None, None, None)

# Generated at 2022-06-22 21:26:27.217278
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict()
    argument_spec['name'] = {'type': 'str'}
    argument_spec['age'] = {'type': 'int'}

    parameters = dict()
    parameters['name'] = 'bo'
    parameters['age'] = '42'

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:26:36.113574
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_parameters = {
        'name': 'bo',
        'age': 42,
    }

    test_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(test_spec)
    result = validator.validate(test_parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

# Generated at 2022-06-22 21:26:42.756862
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        ArgumentSpecValidator(argument_spec=None)
    except TypeError as e:
        assert "'NoneType' object is not iterable" == to_native(e)
    try:
        ArgumentSpecValidator(argument_spec='argument_spec')
    except TypeError as e:
        assert "'str' object is not iterable" == to_native(e)
    try:
        ArgumentSpecValidator(argument_spec=[1, 2, 3])
    except TypeError as e:
        assert "'int' object is not subscriptable" == to_native(e)

# Generated at 2022-06-22 21:26:50.146897
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    try:
        assert result.validated_parameters == {'name': 'bo', 'age': 42}
    except AssertionError as e:
        raise AssertionError(
            "The result of 'validate' method of class ArgumentSpecValidator is not as expected")

# Generated at 2022-06-22 21:26:57.204382
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Initialization of ``ArgumentSpecValidator``.

    :returns: ``True``
    :rtype: bool
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)
    assert validator.argument_spec == argument_spec
    assert validator._valid_parameter_names == {'name', 'age'}
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None

    return True



# Generated at 2022-06-22 21:27:05.234259
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result_set_fallbacks = dict(
        mixins=dict(
            mymixin=dict(
                name='mymixin',
                mixin_var='mixin_var_value',
                mixin_var_dict=dict(a='a'),
            ),
            mydict=dict(
                name='mydict',
            ),
            mylist=dict(
                name='mylist',
            ),
            with_default=dict(
                name='with_default',
                max_devices=1,
            ),
        ),
    )


# Generated at 2022-06-22 21:27:12.769684
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod_args = {'name': {'required': True, 'type': 'str'},
                'age': {'type': 'int'},
                }

    validator = ArgumentSpecValidator(mod_args)

    parameters = {'name': 'mary',
                  'age': '37',
                  }

    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'mary'
    assert result.validated_parameters['age'] == 37
    assert sorted(result.error_messages) == []

# Generated at 2022-06-22 21:27:24.316958
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """
    Test case for constructor of class ModuleArgumentSpecValidator
    """
    arg_spec = {
        'test': {'type': 'str'},
        'anothertest': {'type': 'str'},
        'subtest': {
            'suboption': {'type': 'str'},
        },
    }

    mutually_exclusive = [['test', 'anothertest']]
    required_together = [['test', 'anothertest']]
    required_one_of = [['test', 'anothertest']]
    required_if = [['test', 'anothertest', ['subtest']]]
    required_by = {'subtest': ['test', 'anothertest']}


# Generated at 2022-06-22 21:27:26.679483
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    val = ModuleArgumentSpecValidator({
        "test_1": {"type": "str"},
    })
    assert val.validate({})

# Generated at 2022-06-22 21:27:36.444381
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'name': 'bo', 'age': '42'})._validated_parameters == {'name': 'bo', 'age': '42'}
    assert ValidationResult({'name': 'bo', 'age': '42'}).errors == []
    assert ValidationResult({'name': 'bo', 'age': '42'}).error_messages == []
    assert ValidationResult({'name': 'bo', 'age': '42'}).validated_parameters == {'name': 'bo', 'age': '42'}
    assert ValidationResult({'name': 'bo', 'age': '42'})._no_log_values == set()
    assert ValidationResult({'name': 'bo', 'age': '42'})._unsupported_parameters == set()
    assert ValidationResult

# Generated at 2022-06-22 21:27:41.310896
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({})
    result = validator.validate({})
    assert result.validated_parameters == {}
    assert result.errors == AnsibleValidationErrorMultiple()

# Generated at 2022-06-22 21:27:44.580851
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator({"test": {"choices": [1, 2, 3]}})
    assert isinstance(a, ArgumentSpecValidator)

# Generated at 2022-06-22 21:27:47.655066
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(dict())
    result = validator.validate(dict())
    assert isinstance(result, ValidationResult)

# Generated at 2022-06-22 21:27:58.437121
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    """Test the constructor of class ArgumentSpecValidator.

    The purpose of the test is making sure the argument spec will be validated against
    the types of argument spec, mutually_exclusive and required_together.

    :return: True or False
    :rtype: bool
    """

    validator_1 = ArgumentSpecValidator('test_spec')
    validator_2 = ArgumentSpecValidator(argument_spec='test_spec')
    validator_3 = ArgumentSpecValidator({'test_spec': {'type': 'str', 'required': False, 'default': 'abc'}})

# Generated at 2022-06-22 21:28:02.371697
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=None,
                                required_together=None, required_one_of=None,
                                required_if=None, required_by=None)

# Generated at 2022-06-22 21:28:08.624198
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict()
    tmp = ValidationResult(parameters)
    assert isinstance(tmp._validated_parameters, dict)
    assert isinstance(tmp._no_log_values, set)
    assert isinstance(tmp._unsupported_parameters, set)
    assert isinstance(tmp.errors, AnsibleValidationErrorMultiple)



# Generated at 2022-06-22 21:28:11.300416
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ValidationResult(parameters)
    assert validator is not None

# Generated at 2022-06-22 21:28:23.165274
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}, 'state': {'type': 'str', 'default': 'present', 'choices': ['present', 'absent']}, 'dummy': {'type': 'bool', 'no_log': True}}

    mutually_exclusive = [['name', 'test']]
    required_together = [['name', 'state']]
    required_one_of = [['name', 'test']]
    required_if = [{'state': 'present', 'ref': ['name', 'test']}]
    required_by = {'state': ['name', 'test']}

    parameters = {'name': 'bo', 'state': 'absent'}


# Generated at 2022-06-22 21:28:35.602056
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            'height': {'type': 'float'},
            'status': {'type': 'bool'},
            'friends': {'type': 'list'},
            'description': {'type': 'dict', 'metadata': {'description': 'a dict object'}},
            'abstract': {'type': 'obj'}
        }
    )

# Generated at 2022-06-22 21:28:39.872836
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator



# Generated at 2022-06-22 21:28:44.734013
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec



# Generated at 2022-06-22 21:28:55.950561
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'valid_param5': {'type': 'str'},
    }

    mutually_exclusive = [
        ['valid_param1', 'valid_param2']
    ]

    required_together = [
        ['valid_param1', 'valid_param2'],
        ['valid_param3', 'valid_param4']
    ]

    required_one_of = [
        ['valid_param1', 'valid_param2', 'valid_param3'],
        ['valid_param1', 'valid_param2', 'valid_param4']
    ]


# Generated at 2022-06-22 21:29:07.837452
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:29:20.559946
# Unit test for constructor of class ValidationResult

# Generated at 2022-06-22 21:29:24.629647
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-22 21:29:25.260701
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:29:36.743088
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}})

    # Test alias errors
    assert 'name (alias)' in str(validator.validate({'name (alias)': 'hello'}).errors[0])
    assert 'name (alias)' in str(validator.validate({'name (alias)': 'hello', 'name': 'hello'}).errors[0])
    assert 'name (aliases)' in str(validator.validate({'name (aliases)': 'hello', 'name': 'hello'}).errors[0])
    assert 'name (aliases)' in str(validator.validate({'name (aliases)': 'hello', 'name': 'hello', 'name (alias)': 'hello'}).errors[0])

    # Test NoLogError errors

# Generated at 2022-06-22 21:29:40.827267
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:29:48.579521
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': 42}
    result = ValidationResult(parameters)
    assert isinstance(result._validated_parameters, dict)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []


# Generated at 2022-06-22 21:29:50.647988
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    validation_result = ValidationResult(parameters)
    assert isinstance(validation_result, ValidationResult)

# Generated at 2022-06-22 21:29:58.281956
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test simple case, only success case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

    module_argument_spec_validator = ModuleArgumentSpecValidator(argument_spec)
    result = module_argument_spec_validator.validate(parameters)
    assert result.error_messages == []

# Generated at 2022-06-22 21:30:02.199018
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo'})
    assert result.errors == []
    assert result._validated_parameters == {'name': 'bo'}
    assert result.validated_parameters == {'name': 'bo'}
