

# Generated at 2022-06-22 21:20:07.428127
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'phones': {
            'type': 'list',
            'elements': 'dict',
            'options': {
                'type': {'choices': ['mobile', 'home'], 'type': 'str'},
                'number': {'type': 'str'},
            },
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'phones': [
            {'type': 'mobile', 'number': '+86-1234-5678'},
            {'type': 'hone', 'number': '+86-8765-4321'},
        ],
    }


# Generated at 2022-06-22 21:20:12.667508
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'age': {'type': 'int'}
    }
    parameters = {}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []
    assert result.validated_parameters == {}

# Generated at 2022-06-22 21:20:23.449435
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:20:33.795223
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'debug': {'type': 'bool'},
        'nicknames': {'type': 'list', 'elements': 'str'},
        'address': {'type': 'dict',
                    'options': {
                        'city': {'type': 'str'},
                    }
        }
    }
    mutually_exclusive = [['name', 'age']]
    required_if = [['name', 'bob', ['address']]]
    required_by = dict(name=['address'], age=['address'])


# Generated at 2022-06-22 21:20:41.090487
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Unit tests for method `validate` of class `ModuleArgumentSpecValidator`"""
    # Test with parameters that contain deprecations
    argument_spec = {'a': {'type': 'str', 'aliases': ['alias']}}
    parameters = {'a': 'a'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._deprecations == [{'name': 'alias'}]

    # Test with parameters that contain warnings
    argument_spec = {'a': {'type': 'str', 'aliases': ['alias']}}
    parameters = {'a': 'a', 'alias': 'b'}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:20:49.608160
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Test valid input
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int", "required": True}
    }

    parameters = {
        "name": "Bob",
        "age": 42
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    # Test result
    assert not result.error_messages
    assert result.errors == []
    assert result.validated_parameters == parameters

    # Test failures
    # Missing required arg
    result = validator.validate({})
    assert len(result.errors) == 1
    assert result.error_messages == ["The following arguments are required: age"]
    assert result.errors[0].parameter == "age"

    # Name is an

# Generated at 2022-06-22 21:20:51.213468
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert issubclass(ValidationResult, object)


# Generated at 2022-06-22 21:21:03.191290
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        "state": {"default": "present", "type": "str"},
        "name": {"required": True, "type": "str"},
        "address": {"type": "str"},
    }

    mutually_exclusive = [["name", "address"]]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive)

    expected_arg_spec = {
        "state": {"default": "present", "type": "str"},
        "name": {"required": True, "type": "str"},
        "address": {"type": "str"}
    }

    expected_valid_parameter_names = set(["address", "name", "state"])
    argument_spec_validated = validator.argument_spec
    assert argument_spec_validated == expected_arg_spec
    assert validator

# Generated at 2022-06-22 21:21:11.430217
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.common.text.converters import to_native
    import json

    argument_spec = {'param1': {'type': 'str'}}
    mutually_exclusive = [["param1", "param2"]]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    module_args = {'param1': 'value1', 'param2': 'value2'}
    result = validator.validate(module_args)

    assert len(result.errors) == 1

    fake_module = basic.AnsibleModule(argument_spec=argument_spec, mutually_exclusive=mutually_exclusive)
    fake_module.params = module_

# Generated at 2022-06-22 21:21:19.848838
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str', 'default': 'bo'}}
    validator = ArgumentSpecValidator(
        argument_spec,
        required_if=dict(state=('present', 'absent'))
    )
    assert validator is not None
    assert validator._mutually_exclusive == None
    assert validator._required_together == None
    assert validator._required_if == dict(state=('present', 'absent'))
    assert validator._required_by == None


# Generated at 2022-06-22 21:21:31.689039
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive = 'mutually_exclusive'
    required_together = 'required_together'
    required_one_of = 'required_one_of'
    required_if = 'required_if'
    required_by = 'required_by'

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._required_if == required_if
    assert validator._required_by == required

# Generated at 2022-06-22 21:21:37.652456
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert len(result.errors) == 0

# Generated at 2022-06-22 21:21:40.506645
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result is not None
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-22 21:21:52.166462
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    '''
    The class ArgumentSpecValidator implements __init__, __eq__ and
    validate methods for validation of the spec. Let us test that it works
    as expected.
    '''

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [('name', 'age')]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {'name': ['age']}


# Generated at 2022-06-22 21:22:00.779498
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Declare instances of classes
    class ArgumentSpecValidator(ArgumentSpecValidator):
        pass

    class JSONArgumentError(AnsibleValidationErrorMultiple):
        pass

    # Create an instance of the class
    argument_spec_validator = ArgumentSpecValidator()

    # Create mock attributes
    argument_spec_validator._alias_warnings = [('option', 'alias')]
    argument_spec_validator._alias_deprecations = [{'name': 'deprecation_name'}]
    argument_spec_validator._argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    argument_spec_validator._mutually_exclusive = [('one', 'two')]

    # Set up the mock input parameters and expected results.

# Generated at 2022-06-22 21:22:03.942745
# Unit test for constructor of class ValidationResult
def test_ValidationResult():

    p = {'parameter_1':'one', 'parameter_2':'two'}
    result = ValidationResult(p)
    assert result._validated_parameters == p
    assert result.errors.messages == []


# Generated at 2022-06-22 21:22:06.695845
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult({}), ValidationResult)


# Generated at 2022-06-22 21:22:15.348390
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """This unit test is checking that when the 'warnings' option is set in the argument
    spec, a warning is generated when the alias is used as well as the option.
    """

    argument_spec = {
        'name': {'type': 'str', 'aliases': ['alias']},
    }

    parameters = {
        'name': 'bo',
        'alias': 'joe',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert "Both option name and its alias alias are set." in result.error_messages



# Generated at 2022-06-22 21:22:20.542110
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """test_ModuleArgumentSpecValidator"""

    validator = ModuleArgumentSpecValidator({'test':{'required':True, 'type':'str'}})
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:22:28.441234
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict(
        param1="param1",
        param2=2,
        param3=dict(
            nested_param1="nested_param1",
            nested_param2=3
        )
    )
    result = ValidationResult(parameters)
    assert result.validated_parameters == parameters
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)

# Generated at 2022-06-22 21:22:37.816705
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    # Create argument spec dict
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Create a module argument spec validator
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Validate given parameters against argument spec
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    # Test if validation fails
    try:
        assert result.error_messages
    except:
        # Output the error, if any
        print(result.error_messages)
        raise AssertionError

    # Print the validated parameters
    print(result.validated_parameters)

# Generated at 2022-06-22 21:22:47.135111
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Required parameters not provided
    argument_spec = ArgumentSpecValidator({'a': {'required': True, 'type': 'dict'}})
    expected = AnsibleValidationErrorMultiple()
    expected.append(RequiredError('a is required'))
    assert argument_spec.validate({}).errors == expected

    # Nested required parameters not provided
    argument_spec = ArgumentSpecValidator({'a': {'type': 'dict', 'required': True, 'options': {'c': {'required': True, 'type': 'int'}}}})
    expected = AnsibleValidationErrorMultiple()
    expected.append(RequiredError('a is required'))
    expected.append(RequiredError('c is required'))
    assert argument_spec.validate({}).errors == expected

    # Nested optional parameters not provided
    argument_spec

# Generated at 2022-06-22 21:22:57.903894
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Check for deprecations and warnings returned in ValidationResult object
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'color': {'type': 'str', 'aliases': ['colour']},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'color': 'blue',
        'colour': 'black',
        'unk1': 'unk',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert result._deprecations == [{'name': 'colour', 'version': None, 'date': None, 'collection_name': None}]

# Generated at 2022-06-22 21:23:02.571207
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    try:
        ModuleArgumentSpecValidator(None)
        raise AssertionError('ModuleArgumentSpecValidator should not accept None')
    except TypeError:
        pass
    try:
        ModuleArgumentSpecValidator({'arg': {}})
    except:
        raise AssertionError('ModuleArgumentSpecValidator did not accept {}')

# Generated at 2022-06-22 21:23:09.619677
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    from ansible.module_utils import basic
    import types

    v = ModuleArgumentSpecValidator({'name': {'type': 'str'}}, required_one_of=[[['name']]])
    assert isinstance(v, (types.InstanceType, types.TypeType))
    assert v.argument_spec == {'name': {'type': 'str'}}
    assert v._required_one_of == [[['name']]]
    assert v._valid_parameter_names == set(['name'])

    with basic._ANSIBLE_ARGS.update(no_log=['password']):
        v = ModuleArgumentSpecValidator({'name': {'type': 'str', 'no_log': True}}, required_one_of=[[['name']]])

# Generated at 2022-06-22 21:23:16.340146
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
      "param_name": "param_value"
    }
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()


# Generated at 2022-06-22 21:23:17.800385
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator



# Generated at 2022-06-22 21:23:21.826926
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = {
        'nested_arg': {
            'arg1': {'type': 'str'},
            'arg2': {'type': 'str'}
        }
    }
    validator = ModuleArgumentSpecValidator(arg_spec)
    valid_params = validator._valid_parameter_names
    assert valid_params == {'nested_arg'}

# Generated at 2022-06-22 21:23:30.948062
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)

    if result is not None:
        if result._no_log_values == set():
            print('No log values is not None')
        if result._unsupported_parameters == set():
            print('unsupported parameters is not None')
        if result._validated_parameters == parameters:
            print('validated parameter is not None')
        if result._deprecations == []:
            print('deprecations is not None')
        if result._warnings == []:
            print('warnings is not None')
        if result.errors is None:
            print('errors is not None')
        if result.validated_parameters == parameters:
            print('validated parameters is not None')

# Generated at 2022-06-22 21:23:39.901021
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test for constructor of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age'], ['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['name', 'age']]]
    required_by = {
        'name': ['name', 'age'],
    }

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)

# Generated at 2022-06-22 21:23:48.857895
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    validator = ArgumentSpecValidator(argument_spec)
    validator.validate({'name': 'bo', 'age': '42'})
    validator.validate({'age': '42'})
    validator.validate({'name': 'bo', 'age': 42})
    validator.validate({'name': 'bo'})

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=[['name', 'age']])

# Generated at 2022-06-22 21:23:52.412002
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {}
    result = validator.validate(parameters)
    assert result.error_messages == []



# Generated at 2022-06-22 21:24:00.529702
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Create a ValidationResult instance
    vr = ValidationResult({'a':1})

    # Create a ModuleArgumentSpecValidator instance
    mav = ModuleArgumentSpecValidator({'a': {'type': 'str'}, 'b': {'type': 'str', 'aliases': ['c']}})

    # Test argument errors
    assert mav.validate({'b': 1}).error_messages == [u'b (c) is of type <int> but we were expecting a <str>']
    assert mav.validate({'a': '1', 'b': 1}).error_messages == [u'b (c) is of type <int> but we were expecting a <str>']


# Testing the validate method of class ArgumentSpecValidator
# testing if the alias is correctly handled.

# Generated at 2022-06-22 21:24:12.109883
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeModule:
        def __init__(self):
            self.params = dict()
            self.deprecations = []
            self.warnings = []
            self.fail_json = dict()

        def exit_json(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            self.fail_json['msg'] = args[0]

    fake_module = FakeModule()

    argument_spec = {'name': {'type': 'str'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ModuleArgumentSpecValidator(argument_spec)

    validator.validate(parameters)
    assert fake_module.params == {'name': 'bo'}
    assert fake_module.warnings == []


# Generated at 2022-06-22 21:24:18.634210
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters
    assert validation_result._no_log_values == set()
    assert validation_result._unsupported_parameters == set()
    assert validation_result._deprecations == []
    assert validation_result._warnings == []
    assert validation_result.error_messages == []


# Generated at 2022-06-22 21:24:27.239437
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
        )

    parameters = dict(
        name='bo',
        age=42,
        )

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert result.unsupported_parameters == set()
    assert result.errors.messages == []
    assert result.error_messages == []

# Generated at 2022-06-22 21:24:39.517128
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Legacy module with no aliases in argument_spec
    argument_spec = {'name': {'type': 'str'}}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    parameters = {'name': 'bo'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters

    # Module with parameters and aliases in argument_spec
    argument_spec = {'name': {'type': 'str', 'aliases': ['name1']}}

    parameters = {'name1': 'bo'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result

# Generated at 2022-06-22 21:24:47.699731
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult('somedict')
    assert 'somedict' == result._validated_parameters
    assert 'somedict' != result.validated_parameters
    assert 'set' == type(result._no_log_values).__name__
    assert 'set' == type(result._unsupported_parameters).__name__
    assert 'AnsibleValidationErrorMultiple' == type(result.errors).__name__
    assert 'list' == type(result.error_messages).__name__

# Generated at 2022-06-22 21:24:50.054542
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    f = ModuleArgumentSpecValidator(argument_spec={'a': {'type': 'str'}})
    assert f

# Generated at 2022-06-22 21:24:52.127754
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module = ModuleArgumentSpecValidator(argument_spec=None)
    assert isinstance(module, ArgumentSpecValidator)

# Generated at 2022-06-22 21:25:02.883296
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec_validator = ArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
    )

    # Test failing validation with no_log value.
    params = {'name': 'bo', 'no_log': True}
    validation_result = argument_spec_validator.validate(params)
    assert set(validation_result.error_messages) == set(
        [u"Unexpected parameter in arguments: no_log"])
    assert validation_result.validated_parameters == params
    assert len(validation_result.errors) == 1
    assert validation_result.errors[0].name == u'no_log'

# Generated at 2022-06-22 21:25:12.122983
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:25:18.266078
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_parameters = {"a": "b"}
    test_validation_result = ValidationResult(test_parameters)
    assert test_validation_result.errors == AnsibleValidationErrorMultiple()
    assert test_validation_result.validated_parameters == {"a": "b"}
    assert test_validation_result.unsupported_parameters == set()
    assert test_validation_result._no_log_values == set()
    assert test_validation_result.error_messages == list()

# Generated at 2022-06-22 21:25:27.803985
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json

    valid_parameters = {
        "bypass_proxy": {
            "required": False,
            "type": "bool"
        },
        "system_id": {
            "required": True,
            "type": "str"
        },
        "id": {
            "required": False,
            "type": "bool"
        }
    }

    json_str = json.dumps(valid_parameters)
    valid_parameters = json.loads(json_str)

    validator = ArgumentSpecValidator(valid_parameters)

# Generated at 2022-06-22 21:25:39.531610
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text

    class FakeModuleArgs(object):
        def __init__(self):
            # explicitly set to empty dict since None will be treated as a default value
            self.params = {}
    fake_module_args = FakeModuleArgs()
    fake_module_args.params = {u'warn': u'foo', u'warn_bytes': u'bar'}

# Generated at 2022-06-22 21:25:51.873183
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    from ansible.module_utils.common.validation import (TestClassModuleValidator as TestClassOneModuleValidator,
                                                        TestClassSecondModuleValidator as TestClassTwoModuleValidator)

    TestClassOneModuleValidator.module = TestClassTwoModuleValidator.module = TestClassThreeModuleValidator.module = TestClassFourModuleValidator.module = TestClassFiveModuleValidator.module = TestClassSixModuleValidator.module = None
    TestClassOneModuleValidator.argument_spec = {'name':{'type':'str'},'value':{'type':'str'}}
    TestClassTwoModuleValidator.argument_spec = {'name':{'type':'str'},'value':{'type':'str','default':'bo'}}

# Generated at 2022-06-22 21:26:00.657619
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test valid parameter, no warnings, no errors
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': 42,
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result._warnings == []
    assert result._deprecations == []
    assert result._unsupported_parameters == set()

    # Test missing required parameter, error should be raised
    parameters = {
        'age': 42,
    }

    validator = ArgumentSpecValidator

# Generated at 2022-06-22 21:26:03.928719
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    params = {'state': {'type': 'str', 'choices': ['present', 'absent']}}
    m = ModuleArgumentSpecValidator(params)
    assert m.argument_spec == params

# Generated at 2022-06-22 21:26:11.989551
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters={'name':'name', 'age':'age'}
    validationResult=ValidationResult(parameters)
    assert validationResult._no_log_values == set()
    assert validationResult._unsupported_parameters == set()
    assert validationResult._validated_parameters == {'name':'name', 'age':'age'}
    assert validationResult._deprecations == []
    assert validationResult._warnings == []
    assert validationResult.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:26:19.175590
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        """`name`""": {
            """`type`""": """`str`""",
        },
        """`age`""": {
            """`type`""": """`int`""",
        },
    }

    parameters = {
        """`name`""": """`bo`""",
        """`age`""": """`42`""",
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages



# Generated at 2022-06-22 21:26:25.882825
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_parameters = {'name': 'bo', 'age': '42'}
    test_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    spec_validator = ArgumentSpecValidator(argument_spec=test_spec)
    result = spec_validator.validate(parameters=test_parameters)
    assert not result.errors.messages



# Generated at 2022-06-22 21:26:26.517872
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:26:28.253350
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "TODO: Write unit tests for ArgumentSpecValidator.validate()."

# Generated at 2022-06-22 21:26:39.913809
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """Unit test function to test constructor of class ArgumentSpecValidator"""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['name']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'Yes', ['name', 'age']]]
    required_by = {'name': ['name', 'age']}

# Generated at 2022-06-22 21:26:50.110154
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common._text.converters import to_unicode
    from ansible.module_utils.common.arg_spec import ArgumentSpec, AnsibleModule, AnsibleModuleError
    import json
    import pytest

    groups = [
        'no_log',
        'required',
        'required_if',
        'required_one_of',
        'required_together',
        'mutually_exclusive'
    ]


# Generated at 2022-06-22 21:26:51.858582
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:27:02.241281
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def fake_deprecate(*args, **kwargs):
        return
    def fake_warn(*args, **kwargs):
        return

    from ansible.module_utils.common.warnings import deprecate, warn
    deprecate_original = deprecate
    warn_original = warn

# Generated at 2022-06-22 21:27:04.556296
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    doc = AnsibleModule.__doc__
    assert "_AnsibleModule._init" in doc

# Generated at 2022-06-22 21:27:16.176737
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    """Tests the constructor of class ModuleArgumentSpecValidator"""

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        [
            'name',
            'age'
        ]
    ]

    required_together = [
        [
            'name',
            'age'
        ]
    ]

    required_if = [
        [
            'name',
            '!=',
            'bo'
        ]
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-22 21:27:28.438212
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:27:37.551503
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Argument_spec is required when create an instance of class ModuleArgumentSpecValidator
    import pytest
    from ansible.module_utils.common.warnings import DeprecatedAliasWarning
    from ansible.module_utils.six import PY2
    import warnings
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    with pytest.raises(TypeError):
        ModuleArgumentSpecValidator()
    with warnings.catch_warnings(record=True) as w:
        if PY2:
            warnings.simplefilter('always')
        validator = ModuleArgumentSpecValidator(argument_spec, deprecations={'name': {'version': 2.9,
                                                                                        'collection_name': 'collection'}})

# Generated at 2022-06-22 21:27:42.587682
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arg_spec = {'required_arg': {'type': 'str', 'required': True}}
    validator = ModuleArgumentSpecValidator(argument_spec=arg_spec)

    result = validator.validate({})
    assert isinstance(result.errors[0], RequiredError)

# Generated at 2022-06-22 21:27:49.979173
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test_argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    test_argument_parameters = {
        'name': 'bo',
        'age': '42'
    }
    test_module_argument_spec_validator = ModuleArgumentSpecValidator(test_argument_spec)
    test_module_argument_spec_validator.validate(test_argument_parameters)

# Generated at 2022-06-22 21:28:00.217028
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Case1
    moduleArgumentSpecValidator = ModuleArgumentSpecValidator({'name': {'type': 'str'}}, required_by=[{'name': ['ip']}])
    parameters = {'ip': '192.168.0.1'}
    actual = moduleArgumentSpecValidator.validate(parameters)
    assert not actual.errors

    # Case2
    moduleArgumentSpecValidator = ModuleArgumentSpecValidator({'name': {'type': 'str'}}, required_one_of=[['ip', 'name']])
    parameters = {'ip': '192.168.0.1'}
    actual = moduleArgumentSpecValidator.validate(parameters)
    assert not actual.errors

    # Case3

# Generated at 2022-06-22 21:28:13.210515
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    args = [argument_spec, ]
    kwargs = {'mutually_exclusive': [['name', 'age'], ['name', 'book']],
              'required_together': [['name', 'age'], ['name', 'book']],
              'required_one_of': [['name', 'age', 'book'], ['name', 'age', 'book']],
              'required_if': [['name', 'age', 'book']],
              'required_by': {'name': ['age', 'book']}
              }
    validator = ArgumentSpecValidator(*args, **kwargs)
    assert validator
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-22 21:28:23.558516
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    required_if = [
        ['name', 'Bob', ['age', 20]]
    ]

    validator = ArgumentSpecValidator(argument_spec, required_if=required_if)

    parameters = {
        'age': 42
    }

    result = validator.validate(parameters)

    assert not result.error_messages
    assert result.validated_parameters == {'age': 42}

    parameters = {
        'age': 'fail'
    }

    result = validator.validate(parameters)


# Generated at 2022-06-22 21:28:35.644343
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    try:
        test = ArgumentSpecValidator({'name':{'type':'str','required':False}})
        assert True
    except Exception as e:
        assert False, e
    try:
        test = ArgumentSpecValidator({'name':{'type':'str','required':False}},mutually_exclusive=['name'],required_together=[[]])
        assert True
    except Exception as e:
        assert False, e
    try:
        test = ArgumentSpecValidator({'name':{'type':'str','required':False}},mutually_exclusive=['name'],required_together=[[]]
                                     ,required_one_of=['name'])
        assert True
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 21:28:38.723562
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    try:
        parameters = {
            'name': 'bo',
            'age': '42',
        }
        #Test the object creation
        result = ValidationResult(parameters)
    except TypeError as e:
        #Tests that it makes the object
        assert False

# Generated at 2022-06-22 21:28:43.163433
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(
        argument_spec={
            'test_param': {
                'type': 'int',
                'default': 42,
                'required': True,
                'aliases': ['test_alias'],
            },
        },
    )

# Generated at 2022-06-22 21:28:54.705947
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # Create new ValidationResult
    result = ValidationResult({})
    # Unset all the variables for the ValidationResult
    result._no_log_values = None
    result._unsupported_parameters = None
    result._validated_parameters = None
    result._deprecations = None
    result._warnings = None
    result.errors = None
    # Validate that all the variables of ValidationResult are set
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-22 21:29:07.018589
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator.

    :return: boolean, True if the test passed
    :rtype: bool
    """

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    params = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(params)

    assert type(result) == ValidationResult

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-22 21:29:13.259992
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    test = """
        argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
            'state': {'type': 'bool', 'default': True},
            'size': {'type': 'int', 'default': 1024},
            'info': {'type': 'dict'},
            'people': {'type': 'list'},
        }

        parameters = {
            'name': 'bo',
            'age': '42',
            'state': 'True',
        }
    """
    result = ModuleArgumentSpecValidator(test)
    print(result)

# Generated at 2022-06-22 21:29:25.494621
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    args = [
        'mutually_exclusive',
        'required_together',
        'required_one_of',
        'required_if',
        'required_by',
    ]
    arg_spec = {
        'param1': {'required': True, 'type': 'int'},
        'param2': {'type': 'dict', 'options': {'opt1': {'required': True, 'type': 'list'}}},
    }

    # test all args are optional
    validator = ArgumentSpecValidator(arg_spec)
    result = validator.validate({'param1': 1})

    for arg in args:
        assert getattr(validator, '_{0}'.format(arg)) is None
    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:29:30.271704
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'john', 'age': 30}
    result = ValidationResult(parameters)
    assert isinstance(result, ValidationResult)
    assert result._validated_parameters == parameters
    assert not result.error_messages


# Generated at 2022-06-22 21:29:35.326743
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    original = {'a': {'type': 'str', 'aliases': ['b']}, 'c': {'type': 'bool'}}

    validator = ArgumentSpecValidator(original)
    param = {'a': 'hello'}
    result = validator.validate(param)
    assert result.validated_parameters['a'] == 'hello'

# Generated at 2022-06-22 21:29:36.312530
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({})


# Generated at 2022-06-22 21:29:43.516101
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-22 21:29:52.261107
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    dict1 = dict()
    dict1['name'] = 'sahil'
    dict1['age'] = 10
    result = ValidationResult(dict1)
    assert result._validated_parameters == dict1
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.error_messages == []
    assert result.validated_parameters == dict1
    assert result._deprecations == []
    assert result._warnings == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()


# unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:30:03.833770
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {
            'type': 'str',
            'no_log': False,
            'required': True,
            'default': 'alice',
            'aliases': ['first_name'],
            'aliases_only_one_of': [],
            'collection': [],
        },
        'age': {
            'type': 'int',
            'no_log': False,
            'required': True,
            'default': 21,
            'aliases': ['current_age'],
            'aliases_only_one_of': [],
            'collection': [],
        },
    }
