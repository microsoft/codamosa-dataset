

# Generated at 2022-06-22 21:20:07.462355
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    args = ['test_argument_spec',
            'test_mutually_exclusive',
            'test_required_together',
            'test_required_one_of',
            'test_required_if',
            'test_required_by']

    kwargs = {'mutually_exclusive': 'test_mutually_exclusive',
              'required_together': 'test_required_together',
              'required_one_of': 'test_required_one_of',
              'required_if': 'test_required_if',
              'required_by': 'test_required_by'}

    test_validator = ModuleArgumentSpecValidator(*args, **kwargs)
    assert test_validator._mutually_exclusive == 'test_mutually_exclusive'

# Generated at 2022-06-22 21:20:08.402330
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'a':1, 'b':2})

# Generated at 2022-06-22 21:20:20.473086
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.parameters import sanitize_keys
    import json

    # Unit test for argument_spec example in ArgumentSpecValidator.validate()
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'tags': {'type': 'list'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'tags': ['dev', 'ops'],
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:20:28.185684
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = { 'name': {'type': 'str', 'default': 'bo'}, 'age': {'type': 'int'}, 'hobbies': {'type': 'list', 'default': ['fishing']}}
    mutually_exclusive = [['age', 'hobbies'], 'hobbies']
    required_together = [['age', 'hobbies'], 'name']
    required_one_of = [['age', 'hobbies'], 'hobbies']
    required_if = [['age', 12, ['hobbies']], ['name', 'bo', ['hobbies']]]
    required_by = {'age': ['hobbies'], 'name': ['hobbies']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-22 21:20:38.289566
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_dict = {
        "name": "bo",
        "age": "42",
        "extra": "test",
        "dict": {
            "name": "test"
        },
        "list": [
            {
                "name": {
                    "nested": "test"
                }
            },
            {
                "name": {
                    "nested": 42
                }
            },
            "test"
        ],
        "no_log": "NOLOG",
        "port": 111222,
        "invalid_type": "test",
        "invalid_list": [42],
    }


# Generated at 2022-06-22 21:20:48.146519
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    This unit test is used to validate the constructor of class ArgumentSpecValidator
    """
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutual_exclusive = [['name', 'age']]
    required_together = [['age', 'name']]
    required_one_of = [['age', 'name']]
    required_if = [['age', 'name', 'career']]
    required_by = {'name': 'age', }


# Generated at 2022-06-22 21:20:56.257734
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test if class ValidationResult is instantiated"""
    arguments = {
        'a': {'required': True},
        'b': {'type': 'dict'},
    }

    result = ValidationResult(arguments)
    assert result._validated_parameters == arguments
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []


# Generated at 2022-06-22 21:20:57.800767
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """
    This is a unit test for constructor of class ValidationResult
    """
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)

    assert result is not None

# Generated at 2022-06-22 21:21:03.703463
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {}
    vr = ValidationResult(p)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == {}
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors == []
    assert vr.validated_parameters == {}
    assert vr.unsupported_parameters == set()
    assert vr.error_messages == []


# Generated at 2022-06-22 21:21:11.014850
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Create a dummy argument spec
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Create the validator and validate the parameters
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    # Make sure validation didn't fail
    assert not result.error_messages

    # Make sure the parameters were converted to the correct type
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42



# Generated at 2022-06-22 21:21:22.275382
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    def func_ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=None,
                 required_together=None, required_one_of=None, required_if=None,
                 required_by=None):
        return ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                           required_one_of, required_if, required_by)
    # Function calls
    argument_spec = {}
    ModuleArgumentSpecValidator(argument_spec)

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together,
                                           required_one_of, required_if, required_by)

    mutually_exclusive = []

# Generated at 2022-06-22 21:21:32.106353
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    # Testing that I can set ModuleArgumentSpecValidator's attributes
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None
    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    # Testing that I can get ModuleArgumentSpecValidator's attributes
    validator.argument_spec
    validator._mutually_exclusive
    validator._required_together
    validator._required_one_of
    validator._required_if
    validator._required_by
    validator._valid

# Generated at 2022-06-22 21:21:42.604855
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'string': {"type": "str"},
        'list': {"type": "list"},
        'dict': {"type": "dict"},
        'aliased': {'type': 'str', 'aliases': ['alias']}
    }
    mutually_exclusive = [
        ['a', 'b'],
        ['c', 'd', 'e']
    ]
    required_together = [
        ['f', 'g'],
        ['c', 'd']
    ]
    required_one_of = [
        ['f', 'g'],
        ['c', 'd']
    ]
    required_if = [
        ['c', 'd', ['f', 'g']]
    ]
    required_by = {
        'b': ['a']
    }
    validator = ArgumentSpec

# Generated at 2022-06-22 21:21:54.567293
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    asv = ArgumentSpecValidator(dict(a=dict(type='str'),
                                     b=dict(type='bool', required=True),
                                     ))
    assert asv.validate(dict(a='foo'))
    assert len(asv.validate(dict(a='foo')).errors) == 0
    assert len(asv.validate(dict(a='foo'))
                   .validated_parameters) == 1
    assert asv.validate(dict(a='foo'))

# Generated at 2022-06-22 21:22:01.962357
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Test 'validate' method of class ModuleArgumentSpecValidator """

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

    parameters = {
        'name': 'bo',
        'age': 'not_an_int',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:22:02.927029
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "Test not implemented"

# Generated at 2022-06-22 21:22:09.824818
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }

    validator = ArgumentSpecValidator(spec)

    assert repr(validator) == (
        "<ArgumentSpecValidator alias_warnings=[], argument_spec={'age': {'type': 'int'}, 'name': {'type': 'str'}}>")



# Generated at 2022-06-22 21:22:16.221698
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result._warnings
    assert not result._deprecations
    assert not result.errors

# Generated at 2022-06-22 21:22:28.184848
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'port': {"type": "str"},
        'state': {"type": "str", "choices": ["absent", "present"], "default": "present"},
        'optional_with_default': {"type": "str", "default": "hello"},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'port': '443',
        'state': 'present',
        'optional_with_default': 'world',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.error_messages

# Generated at 2022-06-22 21:22:33.344621
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """argument_spec should be a dict."""
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int', 'aliases': ['age']}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-22 21:22:41.392052
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """ValidationResult constructor test"""
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)
    assert result._validated_parameters == {
        'name': 'bo',
        'age': '42',
    }
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._deprecations == []
    assert result._warnings == []

# Generated at 2022-06-22 21:22:46.452302
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters


# Generated at 2022-06-22 21:22:52.123591
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Unit test for method validate of class ArgumentSpecValidator

    This test is to test the method validate of class ArgumentSpecValidator.
    """

    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:22:57.672081
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    def dummy_validator_validate(self, parameters):
        return parameters

    # This is not a good practice, but for the unit test, we don't want to check
    # the behavior of super class.
    ModuleArgumentSpecValidator.validate = dummy_validator_validate

    validator = ModuleArgumentSpecValidator({}, {})

    assert validator.validate({}) == {}

    # recover dummy_validator_validate
    ModuleArgumentSpecValidator.validate = ArgumentSpecValidator.validate

# Generated at 2022-06-22 21:23:00.230638
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator({}), ArgumentSpecValidator), "Should be a ModuleArgumentSpecValidator instance."

# Generated at 2022-06-22 21:23:02.616698
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    class ArgSpec(ArgumentSpecValidator):
        pass

    class ModuleArgSpec(ModuleArgumentSpecValidator):
        pass

    assert issubclass(ModuleArgSpec, ArgSpec)

# Generated at 2022-06-22 21:23:06.331179
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    #Test function for method validate of class ModuleArgumentSpecValidator
    module_arg_spec_validator = ModuleArgumentSpecValidator(argument_spec={'name':{'type':'str'}, 'age': {'type': 'int'}})
    parameters = {'name': 'bo', 'age': '42'}
    assert module_arg_spec_validator.validate(parameters) is not None

# Generated at 2022-06-22 21:23:16.502591
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    arg_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
        # "state": {"type": "str", "choices": ["present", "absent"]},
        "address": {
            "type": "dict",
            "options": {
                "city": {"type": "str"},
                "street": {"type": "str"},
                "house": {"type": "int", "aliases": ["home"]},
            },
        },
    }
    parameters = {
        "name": "bo",
        "age": "42",
        "state": "present",
        "address": {
            "home": "1",
            "street": "Main Street",
            "city": "Anytown",
        }
    }

# Generated at 2022-06-22 21:23:23.830506
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'the_name': dict(type='str', required=True),
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    parameters = {'the_name': 'bo'}
    result = validator.validate(parameters)

    assert result.errors, 'Expected errors but got none'
    assert not result.error_messages, 'Expected no error messages but got some'
    assert not result.validated_parameters, 'Expected no validated parameters but got some'

    parameters = {'the_name': 'bo'}
    result = validator.validate(parameters)

    assert result.errors, 'Expected errors but got none'
    assert not result.error_messages, 'Expected no error messages but got some'
    assert not result.validated_

# Generated at 2022-06-22 21:23:29.030449
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = {'parameter_a': 'value'}
    result = ValidationResult(parameters=params)
    assert result.validated_parameters == params
    assert result.unsupported_parameters == set()
    assert result.error_messages == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []


# Generated at 2022-06-22 21:23:37.972879
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']
    required_together = [['name', 'age']]
    required_one_of = [['name'], ['age']]
    required_if = [['name', 'age', ['name']]]
    required_by = {'age': ['name']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by)
    assert validator._mutually_exclusive == mutually_exclusive


# Generated at 2022-06-22 21:23:47.773830
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Tests for mutually_exclusive
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)


# Generated at 2022-06-22 21:23:53.664770
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    instance = ArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=None,
        required_together=None,
        required_one_of=None,
        required_if=None,
        required_by=None,
    )
    parameters = {
        "foo": "bar",
    }

    result = instance.validate(parameters)

    assert result is not None

# Generated at 2022-06-22 21:23:54.703280
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    assert ArgumentSpecValidator is not None

# Generated at 2022-06-22 21:24:07.334272
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    def test_attr_deprecations(attr_value):
        if attr_value:
            for d in attr_value:
                deprecations.append(d)

    class TestArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, argument_spec,
                     mutually_exclusive=None,
                     required_together=None,
                     required_one_of=None,
                     ):

            super(TestArgumentSpecValidator, self).__init__(argument_spec,
                                                            mutually_exclusive=mutually_exclusive,
                                                            required_together=required_together,
                                                            required_one_of=required_one_of)

    parameter_set = {
        "option": "value",
        "alias": "value"
    }


# Generated at 2022-06-22 21:24:18.759159
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # The ModuleArgumentSpecValidator_validate method is an internal method of class ModuleArgumentSpecValidator
    # and it is not meant to be used outside of AnsibleModule.
    # The purpose of this unit test is to be able to validate the arguments without creating an instance of AnsibleModule.
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        result.errors.raise_error()

    valid_params = result.validated_parameters

# Generated at 2022-06-22 21:24:20.215239
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """testing ValidationResult class"""
    assert ValidationResult(parameters={'param1': 'val'})

# Generated at 2022-06-22 21:24:28.729143
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'address': {'type': 'dict',
                    'options': {
                        'street': {'type': 'str'},
                        'city': {'type': 'str'},
                        'state': {'type': 'str'},
                        'zip': {'type': 'int'}
                    }
                    },
        'phone': {'type': 'list',
                  'options': {
                      'home': {'type': 'str'},
                      'work': {'type': 'str'}
                  }
                  }
    }

    mutually_exclusive = [["name", "age"]]
    required_together = [['name', 'age']]

# Generated at 2022-06-22 21:24:30.265655
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    with pytest.raises(TypeError):
        ModuleArgumentSpecValidator()

# Generated at 2022-06-22 21:24:42.102163
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    v_result = ValidationResult(parameters)

    assert v_result._no_log_values == set()
    assert v_result._unsupported_parameters == set()
    assert v_result._validated_parameters == parameters
    assert v_result._deprecations == []
    assert v_result._warnings == []
    assert isinstance(v_result.errors, AnsibleValidationErrorMultiple)
    assert v_result.errors == AnsibleValidationErrorMultiple()

    assert v_result.validated_parameters == parameters
    assert v_result.unsupported_parameters == set()
    assert v_result.error_messages == []



# Generated at 2022-06-22 21:24:45.574991
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result_parameters = {'key1': ['value1']}
    result = ValidationResult(result_parameters)
    assert isinstance(result, ValidationResult)


# Generated at 2022-06-22 21:24:46.862133
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({})


# Generated at 2022-06-22 21:24:53.960917
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {'option': 'value', 'alias': 'value'}
    argument_spec = {'option': {'type': 'str', 'aliases': ['alias']}}
    m = ModuleArgumentSpecValidator(argument_spec)
    result = m.validate(parameters)
    assert result._warnings[0]['alias'] == 'alias'
    assert result._warnings[0]['option'] == 'option'

# Generated at 2022-06-22 21:25:03.920787
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # test required_one_of
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    required_one_of = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec, required_one_of=required_one_of)

    parameters = {
        'age': 42
    }

    result = validator.validate(parameters)
    assert not result.error_messages
    assert result.validated_parameters == parameters

    parameters = {}
    result = validator.validate(parameters)
    assert result.error_messages

    parameters = {
        'name': 'Eric',
        'age': 42
    }

    result = validator.validate(parameters)
   

# Generated at 2022-06-22 21:25:14.056703
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['name', 'age']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]

    required_if = [['name', 'bo', ['age']]]

    required_by = {
        'name': ['age']
    }

    # Test for constructor
    validator_instance = ModuleArgumentSpecValidator(
        argument_spec,
        mutually_exclusive=mutually_exclusive,
        required_together=required_together,
        required_one_of=required_one_of,
        required_if=required_if,
        required_by=required_by,
    )

   

# Generated at 2022-06-22 21:25:18.841588
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    return (result)

# Generated at 2022-06-22 21:25:31.654906
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'str'}}

    # Test the case when the deprecations is not empty
    parameters = {'a': 'a1', 'b': 'b1'}
    validator_deprecations = ModuleArgumentSpecValidator(argument_spec)
    result = validator_deprecations.validate(parameters)
    assert result._validated_parameters['a'] == 'a1'
    assert result._validated_parameters['b'] == 'b1'
    assert len(result._deprecations) == 0

    # Test the case when the warnings is not empty
    parameters = {'a': 'a1', 'b': 'b1'}
    validator_warnings = ModuleArgumentSpecValidator(argument_spec)

# Generated at 2022-06-22 21:25:38.938991
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        a=dict(type='bool'),
        b=dict(aliases=['ba']),
        c=dict(aliases=['cb', 'cc']),
        d=dict(aliases=['dd', 'de'])
    )
    validator = ArgumentSpecValidator(argument_spec)
    assert {'a', 'b (ba)', 'c (cb, cc)', 'd (dd, de)'} == validator._valid_parameter_names

# Generated at 2022-06-22 21:25:43.765960
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Unit test for the constructor of class ValidationResult"""
    parameters = {}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)

# Unit tests for property no_log_values of class ValidationResult

# Generated at 2022-06-22 21:25:54.288648
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ Test the method validate of class ModuleArgumentSpecValidator """
    import sys

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

if __name__ == '__main__':
    test_ModuleArgumentSpecValidator_validate()

# Generated at 2022-06-22 21:26:06.121721
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import CheckParameter
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.warnings import deprecate, warn

    arg_spec = dict(
        arg1=dict(type='str', aliases=['other']),
        arg2=dict(type='str', required=True),
        arg3=dict(type='list', elements='str'),
        arg4=dict(type='str', default='None'),
    )

    mutually_exclusive = [
        ['arg1', 'arg2']
    ]


# Generated at 2022-06-22 21:26:17.547695
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {'param_a': {'type': 'str', 'default': 'foo', 'aliases': ['a']}, 'param_b': {'type': 'int', 'default': 25}}
    mutually_exclusive = [['param_a', 'param_b']]
    required_together = [['param_a', 'param_b']]
    required_one_of = [['param_a', 'param_b']]
    required_by = {'param_b': ['param_a']}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_by=required_by)
    result = validator.validate({})
   

# Generated at 2022-06-22 21:26:26.137373
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:26:27.638799
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator(None)

# Generated at 2022-06-22 21:26:39.469392
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ('age', 'name')
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    assert result.unsupported_parameters == set()

    assert len(result.error_messages) == 1

    error_message = "age and name are mutually exclusive"
    assert error_message in result.error_messages

# Generated at 2022-06-22 21:26:49.764654
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    mutually_exclusive = [["name", "age"]]
    required_together = [["name", "age"]]
    required_one_of = [["name", "age"]]
    required_if = [["name", "age"]]
    required_by = {"name": "age", "age": "name"}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive,
                                        required_together, required_one_of, required_if, required_by)

    # validate init parameters
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._

# Generated at 2022-06-22 21:27:00.384334
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Test the existing expected constructor
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    ModuleArgumentSpecValidator(argument_spec={'a': {'type': 'str'}}, required_if=None, required_one_of=None, required_together=None, mutually_exclusive=None, required_by=None)
    # Test with extra parameters in the constructor
    ModuleArgumentSpecValidator(argument_spec={'a': {'type': 'str'}}, required_if=None, required_one_of=None, required_together=None, mutually_exclusive=None, required_by=None, extra_parameter=None, dummy=None)

# Generated at 2022-06-22 21:27:12.633433
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    test_object = ArgumentSpecValidator(argument_spec={'test_key': {'type': 'str'}},
                                        mutually_exclusive=['test_key'],
                                        required_together=['test_key'],
                                        required_one_of=['test_key'],
                                        required_if='test_key',
                                        required_by='test_key'
                                        )

    result = test_object.validate(parameters={'test_key': 'test'})
    assert result.error_messages == []



# Generated at 2022-06-22 21:27:15.981915
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test = {'name': 'bo', 'age': '42'}
    result = ValidationResult(test)
    assert result.validated_parameters == test


# Generated at 2022-06-22 21:27:28.437987
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils import module_base

    argument_spec = dict(
        test=dict(type="str",
                  required=False,
                  aliases=['test_alias']),
    )
    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(dict(test="test value", test_alias="alias value"))
    module = module_base.AnsibleModule(argument_spec, {}, "testing")
    module.warn = mock.Mock()
    module.deprecate = mock.Mock()

    validator.validate(dict(test="test value"))
    module.warn.assert_not_called()
    module.deprecate.assert_not_called()

    validator.validate(dict(test="test value", test_alias="alias value"))
    module

# Generated at 2022-06-22 21:27:37.552172
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test case 1: no argument_spec
    try:
        ArgumentSpecValidator()
        assert 0, 'ArgumentSpecValidator failed to catch exception'
    except TypeError:
        pass

    # Test case 2: None argument_spec
    try:
        ArgumentSpecValidator(argument_spec=None)
        assert 0, 'ArgumentSpecValidator failed to catch exception'
    except TypeError:
        pass

    # Test case 3: Test argument_spec with no key
    try:
        ArgumentSpecValidator(argument_spec={})
        assert 0, 'ArgumentSpecValidator failed to catch exception'
    except TypeError:
        pass

    # Test case 4: Test argument_spec with empty key

# Generated at 2022-06-22 21:27:40.215585
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)


# Generated at 2022-06-22 21:27:52.174147
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils import basic
    from ansible.module_utils.common.arg_spec import validate_argument_spec

    argspec = {
        'parameter1': {'required': False, 'type': 'str'},
    }
    mutually_exclusive = [
        ['parameter1', 'parameter2'],
    ]
    required_together = [
        ['parameter1', 'parameter2'],
    ]
    required_one_of = [
        ['parameter1', 'parameter2'],
    ]
    required_if = [
        ['parameter1', 'parameter1_value', 'parameter1_required'],
    ]
    required_by = dict(
        parameter2=['parameter1'],
        parameter1_required=['parameter1'],
    )



# Generated at 2022-06-22 21:28:01.623834
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.data_loader import load_from_file

    import os
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.basic import AnsibleModule

    fixtures_path = os.path.join(os.path.dirname(__file__), 'unit/arg_spec/fixtures')
    validator = ArgumentSpecValidator(load_from_file(os.path.join(fixtures_path, 'validator.json')))

    def assert_result(result):
        assert result._no_log_values == {'use_method': '_secret', 'pw': '_secret'}
        assert result.errors == AnsibleValidationErrorMultiple()
        assert result.error_messages == []
        assert result.validated_param

# Generated at 2022-06-22 21:28:13.594443
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_if = [
        ['name', 'foo', ['age']]
    ]
    required_by = {
        'name': ['age']
    }
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by,
                                      )
    return validator

# Generated at 2022-06-22 21:28:24.709980
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result.error_messages

    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)
    assert not result.error_messages

    parameters = {
        'name': 'bo',
        'age': 'bob',
    }
    result = validator.validate(parameters)
    assert result.error_messages

# Generated at 2022-06-22 21:28:28.511052
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({'name': {'type': 'str'}})

    assert validator.validate({'name': 'foo'}).validated_parameters == {'name': 'foo'}

# Generated at 2022-06-22 21:28:33.269753
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """ Unit test for ValidationResult class. """
    parameters = {"test_key": "test_value"}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters
    assert validation_result.error_messages == []
    assert validation_result.validated_parameters == parameters



# Generated at 2022-06-22 21:28:35.858670
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({}, required_by={'test_arg': []})
    assert validator._required_by == {'test_arg': []}

# Generated at 2022-06-22 21:28:48.294769
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    import sys
    import __main__
    # Import from a file in a directory that has the same name as one of our
    # standard library modules.
    sys.path.append('./ansible/module_utils/ansible_collections')
    COLLECTION_PATH = __main__.COLLECTION_PATH
    sys.path.append(COLLECTION_PATH)
    from ansible_collections.shell.sys.plugins.module_utils.sys_vendor_utils import sys_vendor_util

    output_dir = './ansible/module_utils/ansible_collections/shell/sys/plugins/module_utils/output'
    output_file = 'sys_vendor_util.output'
    output_path = output_dir + '/' + output_file

# Generated at 2022-06-22 21:28:53.269008
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {'a': 'b'}
    r = ValidationResult(p)
    assert r._validated_parameters == p
    assert r.errors == AnsibleValidationErrorMultiple()
    assert r._no_log_values == set()
    assert r._unsupported_parameters == set()


# Generated at 2022-06-22 21:28:59.134590
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'age': {
            'type': 'int',
        },
        'sex': {
            'type': 'str',
            'default': 'male',
        },
        'employed': {
            'type': 'bool',
            'default': False,
        }
    }

    parameters = {
        'name': 'bo',
        'age': 42,
        'sex': 'male',
        'employed': False
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert not result.errors
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()


# Generated at 2022-06-22 21:29:04.506333
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)

# Unit tests for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:29:09.671907
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ArgumentSpecValidator(
        {'parameter': {'required': True, 'type': 'str'}}, # argument_spec
        mutually_exclusive=[['parameter']],
    ).validate({'parameter': ''})
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], RequiredDefaultError)


# Generated at 2022-06-22 21:29:11.901531
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validation_result = ValidationResult({})
    assert isinstance(validation_result, ValidationResult)


# Generated at 2022-06-22 21:29:24.076046
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'email': {'type': 'str', 'required': True},
        'object': {'type': 'dict', 'options': {
                'id': {'type': 'str', 'required': True},
                'value': {'type': 'float', 'required': True},
            }
        }
    }
    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [["name", "value", ["object"]], ["age", "value", ["object"]]]
    required_by = {"object": ["name", "age"]}

    validator

# Generated at 2022-06-22 21:29:26.053105
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'parameters':'dummy parameters'})
    assert result._validated_parameters == {'parameters':'dummy parameters'}
    assert result.errors == None

# Generated at 2022-06-22 21:29:37.510779
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 21:29:48.332677
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_variable = {'a': 1, 'b': 2, 'c': {'d': 4}}

    result = ValidationResult(test_variable)
    assert isinstance(result, ValidationResult)
    assert result._validated_parameters == test_variable
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {'a': 1, 'b': 2, 'c': {'d': 4}}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:29:51.975893
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:29:59.951541
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'foo': 42, 'bar': 'baz'}
    vr = ValidationResult(parameters)
    assert vr._no_log_values == set()
    assert vr._unsupported_parameters == set()
    assert vr._validated_parameters == parameters
    assert vr._deprecations == []
    assert vr._warnings == []
    assert vr.errors == AnsibleValidationErrorMultiple()
