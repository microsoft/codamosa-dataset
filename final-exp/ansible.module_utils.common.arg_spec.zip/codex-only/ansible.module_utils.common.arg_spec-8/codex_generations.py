

# Generated at 2022-06-22 21:20:08.288326
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:20:10.570239
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    try:
        ValidationResult()
    except TypeError:
        print("test_ValidationResult passed")


# Generated at 2022-06-22 21:20:21.557059
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    '''
    Test ModuleArgumentSpecValidator constructor
    '''
    #test with optional parameters

# Generated at 2022-06-22 21:20:28.167731
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.parameters import DEFAULT_ATTRIBUTE_WARNINGS

    a = ImmutableDict({'type': 'str'})
    argument_spec = {'name': a}

    m = ModuleArgumentSpecValidator(argument_spec=argument_spec,
                                    mutually_exclusive=None,
                                    required_together=None,
                                    required_one_of=None,
                                    required_if=None,
                                    required_by=None)
    assert m.argument_spec == argument_spec

# Generated at 2022-06-22 21:20:38.687399
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    base_spec = dict(
        mutually_exclusive=[['required_if_1', 'required_if_2'], ['required_if_3', 'required_if_4']],
        required_one_of=[['required_if_1', 'required_if_2']],
        required_together=['required_if_1', 'required_if_2'],
        required_one_of=[['required_if_3', 'required_if_4']],
        required_together=['required_if_3', 'required_if_4']
    )
    asv = ArgumentSpecValidator(argument_spec=dict(), **base_spec)
    assert asv._mutually_exclusive == [['required_if_1', 'required_if_2'], ['required_if_3', 'required_if_4']]

# Generated at 2022-06-22 21:20:45.057844
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ Unit test for method validate of class ArgumentSpecValidator """

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []

# Generated at 2022-06-22 21:20:46.361909
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    pass


# Generated at 2022-06-22 21:20:58.541193
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """ unit test for ArgumentSpecValidator.validate """
    from ansible.module_utils.common.arg_spec import (
        ArgumentSpec,
        ArgumentSpecs,
    )

    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.basic import AnsibleModule

    # Test case 1: arguments given

# Generated at 2022-06-22 21:21:08.841138
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    mutually_exclusive_list = [['name', 'age', 'gender']]
    required_if_list = [['name', 'gender']]
    required_by_dict = {'gender': ['age']}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive_list,
                                      required_if=required_if_list,
                                      required_by=required_by_dict)
    assert isinstance(validator._mutually_exclusive, list)
    assert isinstance(validator._required_if, list)
    assert isinstance(validator._required_by, dict)

# Generated at 2022-06-22 21:21:20.911913
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # empty argument spec
    validator = ModuleArgumentSpecValidator({})
    assert len(validator.argument_spec) == 0
    assert validator._valid_parameter_names == set()
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None

    # non-empty argument spec
    validator = ModuleArgumentSpecValidator({'param1': {'type': 'str'}})
    assert len(validator.argument_spec) == 1
    assert validator._valid_parameter_names == set(["param1"])
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert valid

# Generated at 2022-06-22 21:21:29.043503
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "option1": {
            "type": "str",
            "default": "hello"
        },
        "option2": {
            "type": "str",
            "default": "world",
            "aliases": ['defaultoption']
        }
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({'option2': 'world'})
    assert result.validated_parameters == {'option1': 'hello', 'option2': 'world'}
    assert result.error_messages == []
    assert not result.errors

# Generated at 2022-06-22 21:21:30.955049
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult(parameters={'key1': 'value1'}).validated_parameters == {'key1': 'value1'}

# Generated at 2022-06-22 21:21:36.695546
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """ Unit test for the constructor of class ArgumentSpecValidator """

    argument_spec = dict()
    mutually_exclusive = [["a", "b"]]
    required_together = [["c", "d"]]
    required_one_of = [["a", "b", "c"]]
    required_if = [["a", "b", ["a", "b", "c"]]]
    required_by = dict()

    validator = ArgumentSpecValidator(argument_spec,
                 mutually_exclusive,
                 required_together,
                 required_one_of,
                 required_if,
                 required_by)

    assert argument_spec == validator.argument_spec
    assert mutually_exclusive == validator._mutually_exclusive
    assert required_together == validator._required_together
    assert required_one_of == validator._required

# Generated at 2022-06-22 21:21:42.809996
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    arg_spec = {
        'required': {'type': 'str'},
        'optional': {'type': 'str', 'default': 'foo'},
        'required_with_default': {'type': 'str', 'required': False, 'default': 'bar'},
    }

    arg_spec_validator = ArgumentSpecValidator(arg_spec)
    assert isinstance(arg_spec_validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:21:54.808641
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    def call_validate(self, parameters):
        try:
            return super().validate(parameters)
        except Exception as e:
            return e

    validated_parameters = {}
    parameters = {}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = None
    required_together = None
    required_if = None
    required_one_of = None
    required_by = None
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_if, required_one_of, required_by)


# Generated at 2022-06-22 21:22:00.596677
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}}, None, None, None, None, None)
    result = validator.validate({'name': 'bo', 'age': '42'})
    assert not result.error_messages

# Generated at 2022-06-22 21:22:05.420197
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name']
    ]
    required_if = [
        ['name', 'age']
    ]
    required_by = {
        'name': ['age'],
    }
    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by,)
    assert validator

# Generated at 2022-06-22 21:22:06.970335
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:22:17.330152
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(
        argument_spec={
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        mutually_exclusive=[
            ['name', 'age'],
        ],
        required_together=[
            ['name', 'age'],
        ],
        required_one_of=[
            ['name', 'age'],
        ],
        required_if=[
            ['name', '3', ['age']],
        ],
        required_by=[
            ['name', ['age']],
        ],
    )
    parameters = {}
    result = validator.validate(parameters)
    assert result.errors
    assert 'name is required' in result.errors.messages
    assert 'age is required' in result.errors.messages



# Generated at 2022-06-22 21:22:28.620188
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_arguments = [
        "action",
        "name",
        "free_form"
    ]
    argument_spec = {
        "action": {
            "type": "str",
            "required": True,
            "choices": ["create", "list", "read", "update", "delete"]
        },
        "name": {
            "type": "str",
            "required": True
        }
    }

    mutually_exclusive = [
        [
            "action",
            "free_form"
        ]
    ]
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)

    parameters1 = {
        "action": "create",
        "name": "bo"
    }

    result1 = validator.validate(parameters1)

# Generated at 2022-06-22 21:22:32.387635
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    validator = ArgumentSpecValidator(argument_spec)

    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:22:42.340908
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Define a default instance
    validator = ModuleArgumentSpecValidator(argument_spec)

    # Validate parameters against argument_spec
    result = validator.validate(parameters)

    # Expected result of the validation
    expected_result = {'name': u'bo', 'age': 42}

    assert result.validated_parameters == expected_result
    assert not result.error_messages
    assert not result._deprecations
    assert not result._warnings

# Generated at 2022-06-22 21:22:52.767965
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"},
                     "age": {"type": "int"}}
    mutually_exclusive = ["name", "age"]
    required_together = [["name"], ["age"]]
    required_one_of = [["name"], ["age"]]
    required_if = [["name", "age", ["name", "age"]]]
    required_by = {"name": ["name", "age"], "age": ["name", "age"]}

    argument_spec_validator = ArgumentSpecValidator(
        argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    assert argument_spec_validator.argument_spec == argument_spec
    assert argument_spec_validator._mutually_exclusive == mutually_exclusive
    assert argument_spec_validator

# Generated at 2022-06-22 21:22:56.343770
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={"a": 1, "b": 2})
    assert result.validated_parameters == {"a": 1, "b": 2}


# Generated at 2022-06-22 21:23:07.801461
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test for missing parameters
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {'name': 'bo'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == ['age is required']
    # Test for invalid parameter type
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'}
    }
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

# Generated at 2022-06-22 21:23:17.216767
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = ['name', 'age']
    required_together = [('name', 'age')]
    required_one_of = [['name'], ['age']]
    required_if = [('name', 'Guido')]
    required_by = {'name': 'age'}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_

# Generated at 2022-06-22 21:23:19.818648
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={})

    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}



# Generated at 2022-06-22 21:23:31.528386
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Deprecation warnings expected to be printed from this test
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six import assertRegex
    deprecation_output = StringIO()
    import sys
    sys.stderr = deprecation_output

    # Setup argument spec and parameters

# Generated at 2022-06-22 21:23:34.921185
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)



# Generated at 2022-06-22 21:23:42.484650
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    result = ValidationResult({'name': 'bo', 'age': '42'})
    validator = ArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}},
                                      mutually_exclusive=None, required_together=None, required_one_of=None,
                                      required_if=None, required_by=None)
    assert validator.validate({'name': 'bo', 'age': '42'}).error_messages == []

# Generated at 2022-06-22 21:23:48.828702
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    module_argument_spec_validator = ModuleArgumentSpecValidator({'name': {'type': 'str'}, 'age': {'type': 'int'}})
    parameters = {'name': 'bo', 'age': '42'}
    result = module_argument_spec_validator.validate(parameters)
    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result._validated_parameters == {'name': 'bo', 'age': '42'}



# Generated at 2022-06-22 21:23:58.698517
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # ModuleArgumentSpecValidator.validate() returns ValidationResult
    validator = ModuleArgumentSpecValidator({'test': {'type': 'str'}}, None, [], [], [])
    result = validator.validate({'test': 'abc'})
    assert(isinstance(result, ValidationResult))
    assert(result.validated_parameters['test'] == 'abc')

    # ModuleArgumentSpecValidator.validate() returns ValidationResult with deprecations
    validator = ModuleArgumentSpecValidator({'test': {'type': 'str', 'aliases': ['deprecated']}}, None, [], [], [])
    result = validator.validate({'deprecated': 'abc'})
    assert(isinstance(result, ValidationResult))

# Generated at 2022-06-22 21:24:02.137995
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert deepcopy({"parameters": {"demo": "demo"}}) == ValidationResult({"parameters": {"demo": "demo"}}).validated_parameters


# Generated at 2022-06-22 21:24:13.789464
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={
        'name': {'type': 'str', 'aliases': ['my_name']},
        'age': {'type': 'int', 'aliases': ['my_age']},
    })

    parameters = {
        'name': 'bo', 'age': '42',
        'my_name': 'not_bo', 'my_age': '43'
    }

    result = validator.validate(parameters)

    assert(result.error_messages == ['Both option name and its alias my_name are set.',
                                     'Both option age and its alias my_age are set.'])

# Generated at 2022-06-22 21:24:21.612610
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_arg_validator = ModuleArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })
    assert len(module_arg_validator.argument_spec) == 2
    assert module_arg_validator._mutually_exclusive == None
    assert module_arg_validator._required_together == None
    assert module_arg_validator._required_one_of == None
    assert module_arg_validator._required_if == None
    assert module_arg_validator._required_by == None
    assert len(module_arg_validator._valid_parameter_names) == 2

# Generated at 2022-06-22 21:24:22.319607
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:24:28.397781
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'param1': {'required': True, 'type': 'str'},
        'param2': {'required': True, 'type': 'str'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec=argument_spec)
    parameters = {
        'param1': 'value1',
        'param2': 'value2',
    }

    result = validator.validate(parameters)


# Generated at 2022-06-22 21:24:36.223486
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = ValidationResult(parameters)
    assert result.error_messages == []
    assert result.errors == []
    assert result.validated_parameters == {'name':'bo','age':'42'}
    assert result.unsupported_parameters == set()
    assert result._no_log_values == set()

# Generated at 2022-06-22 21:24:39.229134
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'nested': {'child': 'childvalue'}})
    assert result._validated_parameters['nested']['child'] == 'childvalue'


# Generated at 2022-06-22 21:24:46.810931
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    args = {
        'argument_spec': {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        },
        'mutually_exclusive': [
            ['name', 'age'],
        ],
    }

    validator = ArgumentSpecValidator(**args)

    assert validator.argument_spec == args['argument_spec']
    assert validator._mutually_exclusive == args['mutually_exclusive']

# Generated at 2022-06-22 21:24:50.600489
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    ModuleArgumentSpecValidator(dict([('argument_spec', dict([('name', dict([('type', 'str')]))]))])).validate(dict([('name', 'bo')]))

# Generated at 2022-06-22 21:24:54.609996
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'ANSIBLE'})
    assert result._validated_parameters == {'name': 'ANSIBLE'}
    assert result.validated_parameters == {'name': 'ANSIBLE'}



# Generated at 2022-06-22 21:25:01.105561
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class FakeValidation:
        def __init__(self,_):
            pass
        def validate(self, parameters):
            return parameters

    # Test that ModuleArgumentSpecValidator extends ArgumentSpecValidator with super method
    validator = ModuleArgumentSpecValidator({'e': {'type':'str', 'default': 'value1'}})
    assert validator.validate({'e': 'value2'}) == {'e': 'value2'}

# Generated at 2022-06-22 21:25:02.101109
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}) != None

# Generated at 2022-06-22 21:25:10.939674
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # test an usual case
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:25:20.801979
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible_collections.ansible.netcommon.plugins.module_utils.arg_spec import ModuleArgumentSpecValidator
    from ansible_collections.ansible.netcommon.plugins.module_utils.arg_spec import set_fallbacks

    argument_spec = {
        'foo': {
            'type': 'str',
            'aliases': ['baz']
        }
    }
    parameters = {
        'foo': 'qux',
        'baz': 'qux'
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.warnings == [{'alias': 'baz', 'option': 'foo'}]

# Generated at 2022-06-22 21:25:22.379498
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    assert False, "TODO: Implement"

# Generated at 2022-06-22 21:25:26.136728
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    data = {
        "a": "b",
        "c": "d"
    }

    result = ValidationResult(data)
    assert result.validated_parameters["a"] == "b"

# Generated at 2022-06-22 21:25:38.448273
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Module tests for ArgumentSpecValidator.validate()"""

    # Test that casting is done
    assert ArgumentSpecValidator({'a': {'type': int}}).validate({'a': '12'}).validated_parameters == {'a': 12}

    # Test that validated_parameters is a copy of the parameters
    assert id(ArgumentSpecValidator({'a': {'type': int}}).validate({'a': '12'}).validated_parameters) != id({'a': 12})  # noqa: E999

    # Test that casting is done recursively

# Generated at 2022-06-22 21:25:50.758891
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # Assert that UserWarning is raised for parameter conflict
    parameters = {
        'path': {'type': 'str', 'required': False, 'aliases': ['src']},
        'src': {'type': 'str', 'required': False, 'aliases': ['path']}
    }
    validator = ModuleArgumentSpecValidator(parameters)
    result = validator.validate(parameters)
    assert len(result.error_messages) == 0, "Expected no validation errors."
    assert len(result._warnings) == 1
    assert result._warnings[0]['alias'] == 'src'
    assert result._warnings[0]['option'] == 'path'

    # Assert that DeprecationWarning is raised for deprecation

# Generated at 2022-06-22 21:25:54.547501
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {"name": {"type": "list", "elements": "str"}, "age": {"type": "int"}}
    validator = ModuleArgumentSpecValidator(spec)
    validator.validate({"name": "zookeeper", "age": 1})

# Generated at 2022-06-22 21:26:06.442267
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = ['name',['age', 'name']]
    required_together = ['name',['age', 'name']]
    required_one_of = ['name',['age', 'name']]

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:26:13.300166
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    spec = {'param': {'type': 'str'}}
    validator = ArgumentSpecValidator(spec)
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == {'param'}

# Generated at 2022-06-22 21:26:21.793498
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    # Confirm the deprecation and warning messages are output
    # when the aliasing logic is used by AnsibleModule.
    # This encourages the module developer to update the
    # module for removal of the deprecated alias logic.

    fake_module = object()
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'alias': {'type': 'str', 'aliases': ['alias_one']},
        'alias_two': {'type': 'str', 'aliases': ['alias_three']},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
        'alias': 'alias_value',
        'alias_two': 'alias_two_value',
    }
    validator = ModuleArgumentSpecValid

# Generated at 2022-06-22 21:26:33.244781
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age']
    ]

    required_together = [
        ['name', 'age']
    ]

    required_one_of = [
        ['name', 'age']
    ]

    required_if = [
        ['name', 'age', ['name']]
    ]

    required_by = {
        'name': ['age']
    }


# Generated at 2022-06-22 21:26:42.757746
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # This test is for the method validate of class ArgumentSpecValidator
    # The method validate has the following signature:
    # validate(self, parameters)
    # We will use stubs for the parameter self and parameters
    # The stubs for self and parameters are defined below:
    from ansible.module_utils.compat import collections_abc

    class StubArgumentSpecValidator(object):
        def __init__(self):
            self.mutually_exclusive = None

        def get_mutually_exclusive(self):
            return self.mutually_exclusive

    class StubParameters(object):
        def __init__(self):
            self.validated_parameters = dict()

    stub_self = StubArgumentSpecValidator()
    stub_parameters = StubParameters()

    # Now we instantiate the class ArgumentSpecValidator
    argument

# Generated at 2022-06-22 21:26:48.301994
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameter = {
        "name": "Bob",
        "age": 30
    }
    result = ValidationResult(parameter)
    assert hasattr(result, "_no_log_values")
    assert hasattr(result, "_unsupported_parameters")
    assert hasattr(result, "_validated_parameters")
    assert hasattr(result, "_deprecations")
    assert hasattr(result, "_warnings")
    assert hasattr(result, "errors")


# Generated at 2022-06-22 21:26:54.495315
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['full_name']
        },
        'age': {'type': 'int'}
    }

    # no parameter provided
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({})

# Generated at 2022-06-22 21:27:03.648215
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    valid_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    # Test code
    validator = ModuleArgumentSpecValidator(valid_spec)

    # No_log_values
    valid_params = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(valid_params)
    assert len(result.no_log_values) == 0

    valid_params2 = {
        'name': 'bo',
        'age': '42',
        'vault_password': 'asdf'
    }

# Generated at 2022-06-22 21:27:05.524332
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert isinstance(ValidationResult({}), ValidationResult)


# Generated at 2022-06-22 21:27:17.257268
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:27:19.411615
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert hasattr(ModuleArgumentSpecValidator, "validate")


# Generated at 2022-06-22 21:27:31.081503
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # nb: test_mutually_exclusive_list
    mutually_exclusive_list = [['a', 'b']]
    # nb: test_mutually_exclusive_nested_lists
    mutually_exclusive_nested_lists = [['a', 'b'], ['c', 'd']]
    # nb: test_required_together_list
    required_together_list = [['a', 'b']]
    # nb: test_required_one_of_list
    required_one_of_list = [['a', 'b'], ['c', 'd']]
    # nb: test_required_if_list
    required_if_list = [['a', 'b', ['c']]]
    # nb: test_required_by_key_val

# Generated at 2022-06-22 21:27:40.442040
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings
    import pytest
    import json

    warnings.simplefilter("error")

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'user': {'type': 'str', 'required': True},
    }

    parameters = {
        'user': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)


# Generated at 2022-06-22 21:27:46.356537
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    input_parameters = { 'name': 'test_name' }
    vr = ValidationResult(input_parameters)
    assert vr.validated_parameters == { 'name': 'test_name' }
    assert vr.unsupported_parameters == set()
    assert vr.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:27:55.496044
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    spec = {'name': {'required': True, 'type': 'str'}, 'favorite_color': {'required': True, 'type': 'str'}}
    params = {'name': 'Dave', 'favorite_color': 'blue'}
    result = ValidationResult(parameters=params)
    assert result._validated_parameters == {}
    assert result.error_messages == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors.messages == []



# Generated at 2022-06-22 21:27:59.009392
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator(
        {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
    ).validate({
        'name': 'bo',
        'age': '42',
    })

    assert result.error_messages == []



# Generated at 2022-06-22 21:28:05.273434
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import json
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.validation import check_type_bool, check_type_dict, check_type_int, check_type_list
    from ansible.module_utils.common.validation import check_type_none, check_type_str
    from ansible.module_utils._text import to_text
    from io import StringIO

    def check_type_dict_of_str(param, name):
        check_type_dict(param, name, types=str)


# Generated at 2022-06-22 21:28:15.111592
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str', 'aliases': ['myname']},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert set(validator.argument_spec.keys()) == set(['name', 'age'])
    assert set(validator._valid_parameter_names) == set(['name (myname)', 'age'])
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None


# Generated at 2022-06-22 21:28:25.998990
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = dict(
        var1=dict(required=True, type='str'),
        var2=dict(required=True, type='int', aliases=['var2alias']),
        var3=dict(required=True, type='list'),
    )

    mutually_exclusive = [
        ['var3', 'var4'],
        ['var1', 'var2'],
    ]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(dict(
        var1='good',
        var2=42,
        var2alias='bad',
        var3='bad',
        var4=42,
    ))

    result.errors[0].__class__.__name__ == 'MutuallyExclusiveError'
    result.errors

# Generated at 2022-06-22 21:28:34.774032
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult(parameters={'param': {'age': '42'}})
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'param': {'age': '42'}}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []
    assert result.validated_parameters == {'param': {'age': '42'}}


# Unit tests for func _get_legal_inputs

# Generated at 2022-06-22 21:28:47.213590
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    def function(): pass

    mod_validator = ModuleArgumentSpecValidator({'foo': {'type': 'int'}}, required_by={"foo": ["bar"]}, required_one_of=[["foo"]])
    assert mod_validator._mutually_exclusive is None
    assert mod_validator._required_together is None
    assert mod_validator._required_one_of == [["foo"]]
    assert mod_validator._required_if is None
    assert mod_validator._required_by == {"foo": ["bar"]}
    assert mod_validator.argument_spec == {'foo': {'type': 'int'}}

    mod_validator = ModuleArgumentSpecValidator({'foo': {'type': 'int'}}, required_one_of=["foo"])
    assert mod_validator._mut

# Generated at 2022-06-22 21:28:57.033649
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.validated_parameters) == 2
    assert len(result.error_messages) == 0
    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-22 21:28:59.056351
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    x = ValidationResult(parameters={'a': 'b'})
    assert x


# Generated at 2022-06-22 21:29:10.040269
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters_spec = dict(
        name=dict(type='str'),
        age=dict(type='int'),
    )
    parameters = dict(
        name='bo',
        age='42',
    )
    validator = ArgumentSpecValidator(parameters_spec)
    result = validator.validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.validated_parameters == parameters
    assert result

# Generated at 2022-06-22 21:29:20.474269
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    '''Unit test for method ModuleArgumentSpecValidator.validate'''
    import sys
    sys.path.insert(0, '..')
    from ansible.module_utils.six.moves import builtins
    builtins.__ansible_module__ = 'ansible.module_utils.common.arg_spec'

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:29:30.217979
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    params = {
        'test_param1': 'test_value1',
        'test_param2': 'test_value2',
    }
    args = {
        'test_param1': {
            'type': 'str',
            'required': True,
        },
        'test_param2': {
            'type': 'str',
            'required': False,
        },
    }

    validator = ArgumentSpecValidator(args)
    result = validator.validate(params)

    assert result.validated_parameters == params
    assert result.errors == []

# Generated at 2022-06-22 21:29:36.041140
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    alias_warnings = ['b', 'd']
    alias_deprecations = ['a']
    validator = ModuleArgumentSpecValidator({}, alias_warnings=alias_warnings,alias_deprecations=alias_deprecations)
    result = validator.validate({})
    assert result._warnings == alias_warnings
    assert result._deprecations == alias_deprecations

# Generated at 2022-06-22 21:29:48.335297
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Mock values
    aliases = {'name': 'name'}
    arguments = {'Name': 'Bo', 'Age': 42}
    args = [arguments]
    kwargs = {}
    extracted_values = {}
    sec_args = [arguments]
    sec_kwargs = {}
    sec_extracted_values = {}

    # Mock classes
    class ValidationResultMock:
        _no_log_values = {}
        _unsupported_parameters = {}
        _validated_parameters = arguments
        _deprecations = []
        _warnings = []
        errors = []

        def __init__(self, parameters):
            pass

        @property
        def validated_parameters(self):
            return self._validated_parameters


# Generated at 2022-06-22 21:29:56.226467
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import iteritems, string_types

    # Setup test data

# Generated at 2022-06-22 21:30:05.567009
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {}
    parameters = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ModuleArgumentSpecValidator(argument_spec,
                                 mutually_exclusive,
                                 required_together,
                                 required_one_of,
                                 required_if,
                                 required_by)
 
    # validate() method should be inherited from super class
    assert hasattr(validator, 'validate')

    # constructor of super class should be called
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert valid