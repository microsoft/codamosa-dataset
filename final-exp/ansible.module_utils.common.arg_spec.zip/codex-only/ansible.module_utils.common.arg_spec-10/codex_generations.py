

# Generated at 2022-06-22 21:19:58.785277
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert len(result.errors) == 0
    assert result.validated_parameters == {}



# Generated at 2022-06-22 21:20:00.069343
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    assert isinstance(ModuleArgumentSpecValidator(), ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:20:10.611592
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning

    class TestModuleArgumentSpecValidator(ModuleArgumentSpecValidator):
        def __init__(self, *args, **kwargs):
            super(TestModuleArgumentSpecValidator, self).__init__(*args, **kwargs)

    class TestParameters:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class TestMutuallyExclusive:
        def description(self):
            return "exclusivity test"

        def __call__(self, parameters):
            return False

    def test_deprecation(record):
        return record.msg.startswith("Alias 'age' is deprecated") and type(record.message) == Ans

# Generated at 2022-06-22 21:20:15.069080
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {"name": {"type": "str"}, "age": {"type": "int"}}
    validator = ModuleArgumentSpecValidator(argument_spec)

    parameters = {"name": "bo", "age": "42"}
    validator.validate(parameters)

# Generated at 2022-06-22 21:20:24.514571
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    import unittest
    import unittest.mock
    
    class TestArgumentSpecValidator(unittest.TestCase):
        def test_one_error(self):
            argument_spec = {
                'name': {'type': 'str'},
                'age': {'type': 'int'},
            }
            parameters = {
                'name': 'bo',
                'age': '42',
            }
            validator = ArgumentSpecValidator(argument_spec)
            result = validator.validate(parameters)

            self.assertEqual(result.validated_parameters, {"name": "bo", "age": 42})
            self.assertEqual(result.errors, [])
            self.assertEqual(result.unsupported_parameters, set())


# Generated at 2022-06-22 21:20:27.063029
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vresult = ValidationResult(dict(name='tom', age=20))
    assert vresult.validated_parameters == {'name': 'tom', 'age': 20}



# Generated at 2022-06-22 21:20:37.393093
# Unit test for constructor of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:20:47.567561
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = dict(
        foo=dict(type='str'),
        bar=dict(type='int', aliases=['baz']),
    )
    mutually_exclusive = [['foo', 'bar'], ['baz', 'nonexistant']]
    required_together = [['bar', 'foo']]
    required_one_of = [['bar', 'foo', 'nonexistant']]
    required_if = [
        ['foo', 'bar', ['bar', 'baz']],
        ['foo', 'baz', ['bar', 'baz']],
    ]
    required_by = {'foo': ['bar', 'baz']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

# Generated at 2022-06-22 21:20:56.257747
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:21:02.462816
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of,
                                      required_if, required_by)
    assert isinstance(validator, ArgumentSpecValidator)



# Generated at 2022-06-22 21:21:09.092631
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == parameters
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)


# Generated at 2022-06-22 21:21:21.047735
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
        "siblings": {"type": "list"},
        "address": {
            "type": "dict",
            "options": {
                "street": {"type": "str", "required": True},
                "apt": {"type": "int"},
            },
        },
    }

    parameters = {
        "name": "bo",
        "age": "42",
        "siblings": ["mo", "zo", "jo"],
        "address": {
            "street": "123 St",
            "apt": "1",
        },
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_param

# Generated at 2022-06-22 21:21:31.156621
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # pylint: disable=unused-variable
    @classmethod
    def warning(cls, message):
        cls._warnings.append(message)

    @classmethod
    def deprecate(cls, message, version=None, collection_name=None, date=None, removed=False):
        cls._deprecations.append((message, version, collection_name, date, removed))

    # pylint: disable=too-few-public-methods
    class MockModule:
        argument_spec = {'test_arg': {'type': 'str'}}
        _warnings = []
        _deprecations = []
        warning = warning
        deprecate = deprecate

    mock_module = MockModule()

    validator = ModuleArgumentSpecValidator(mock_module.argument_spec)

# Generated at 2022-06-22 21:21:40.914848
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'married': {'type': 'bool', 'default': False},
        'city': {'type': 'str', 'default': 'Delhi'},
        'state': {'type': 'str', 'default': 'Delhi'},
    }

    mutually_exclusive = [
        ['age', 'married'],
        ['state', 'city'],
    ]

    required_together = [
        ['name', 'age'],
    ]

    required_one_of = [
        ['name', 'married', 'city', 'state'],
    ]

    required_if = [
        ['state', 'Delhi', ['age']],
    ]


# Generated at 2022-06-22 21:21:45.813771
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'param_1': 'param 1', 'param_2': 'param 2'}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == parameters
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:21:57.001903
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # type: () -> values
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}

    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors == []

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

    parameters = {'name': 'bo', 'age': 'not-an-int'}
    result = validator.validate(parameters)
    assert result.errors != []
    assert result

# Generated at 2022-06-22 21:22:03.374117
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator(
        argument_spec={},
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        required_if=[],
        required_by={}
    )

    assert validator
    assert validator.argument_spec == {}
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator._valid_parameter_names == set()


# Generated at 2022-06-22 21:22:15.398901
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import ParameterError

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'dict': {
            'type': 'dict',
            'options': {
                'name': {'type': 'str'},
                'age': {'type': 'int'}
            }
        }
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'dict': {
            'name': 'bo',
            'age': '42',
        }
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'name' in result.validated_parameters
    assert result

# Generated at 2022-06-22 21:22:24.821643
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    # Case 1
    # Test validate for simple example
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-22 21:22:27.428994
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    assert ValidationResult(parameters)


# Generated at 2022-06-22 21:22:28.937998
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert hasattr(ArgumentSpecValidator, 'validate')
    assert callable(ArgumentSpecValidator.validate)

# Generated at 2022-06-22 21:22:41.391705
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    # Test with no args

    arg_spec = {}

    validator = ArgumentSpecValidator(argument_spec=arg_spec)
    assert validator.argument_spec == arg_spec

    # Test with multiple args

    # mutually_exclusive
    mutually_exclusive = [
        ["a", "b"],
        ["c", "d"],
    ]

    # required_together
    required_together = [
        ["e", "f"],
        ["g", "h"],
    ]

    # required_one_of
    required_one_of = [
        ["i", "j"],
        ["k", "l"],
    ]

    # required_if
    required_if = [
        ["m", True, ["n"]],
        ["n", False, ["m"]]
    ]

    # required_by
    required_

# Generated at 2022-06-22 21:22:50.134246
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:22:59.009097
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age'],
    ]
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_if = [
        ['name', 'age'],
    ]
    required_by = {
        'name': 'age',
    }

    validator = ArgumentSpecValidator(argument_spec)

    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator

# Generated at 2022-06-22 21:23:05.181287
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    # parameter type is list
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['aliases_age']},
        'aliases_age': {},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    parameters_copy = parameters.copy()
    try:
        result = ModuleArgumentSpecValidator(argument_spec).validate(parameters_copy)
        assert result.errors.messages == []
        assert parameters_copy == parameters
    except Exception as e:
        print(e)
        assert False

    # parameter type is str

# Generated at 2022-06-22 21:23:09.157845
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    a = ValidationResult({'name': 'joe'})
    assert a._validated_parameters == {'name': 'joe'}



# Generated at 2022-06-22 21:23:20.560979
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Test for ArgumentSpecValidator.validate"""
    # Test happy path
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.errors.to_native():
        assert False, "Validation failed: {0}".format(", ".join(result.errors.messages))
    valid_params = result.validated_parameters
    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42

    # Test argument spec with nested spec

# Generated at 2022-06-22 21:23:23.855518
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    result = ModuleArgumentSpecValidator(None)
    assert isinstance(result, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:23:32.725913
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert 'name' in result.validated_parameters
    assert 'age' in result.validated_parameters
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result.error_messages) == 0

# Generated at 2022-06-22 21:23:34.037093
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert isinstance(ModuleArgumentSpecValidator(None), ArgumentSpecValidator)


# Generated at 2022-06-22 21:23:36.843502
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result._validated_parameters == {}


# Generated at 2022-06-22 21:23:44.028149
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockResult:
        def __init__(self):
            self.warnings = []
            self.deprecations = []

    mock_result = MockResult()
    a = ModuleArgumentSpecValidator([], deprecations=[{'name': 'test'}], warnings=[{'option': 'test', 'alias': 'test2'}])
    a.validate({})
    assert len(mock_result.deprecations) == 1
    assert len(mock_result.warnings) == 1

# Generated at 2022-06-22 21:23:45.440337
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = ModuleArgumentSpecValidator(argument_spec=dict())
    assert a.argument_spec == {}

# Generated at 2022-06-22 21:23:56.053650
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    
    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }

    parameters = {
        'name': 'bo',
        'age': 'foo',
    }
    result = validator.validate(parameters)
    assert result.validated_parameters == {
        'name': 'bo',
        'age': None,
    }
   

# Generated at 2022-06-22 21:24:08.755026
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    import json
    import tempfile

    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes

    #
    # Handle mutually exclusive argument
    #

    # Create validator
    argument_spec = {"optionA": {"type": "str", "mutually_exclusive": [["optionB"]]}}
    validator = ArgumentSpecValidator(argument_spec)

    # Test mutually exclusive arguments
    parameters = {"optionA": "testA", "optionB": "testB"}
    result = validator.validate(parameters)
    assert len(result.error_messages) == 1
    assert "either optionB or optionA" in result.error_messages[0]

    #
    # Handle required_together argument
   

# Generated at 2022-06-22 21:24:17.055081
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {"param1": "foo", "param2": "bar"}
    validation_result = ValidationResult(parameters)
    assert validation_result.validated_parameters == parameters
    assert validation_result.unsupported_parameters == set()
    assert len(validation_result.error_messages) == 0

    # Add an error to the result
    validation_result.errors.append(AliasError("Something is wrong with aliases"))
    assert len(validation_result.error_messages) == 1
    assert "Something is wrong with aliases" in validation_result.error_messages



# Generated at 2022-06-22 21:24:18.759233
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:24:27.367194
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.errors) == 0
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42
    assert len(result._no_log_values) == 0

# Generated at 2022-06-22 21:24:34.443791
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.error_messages == []

# Generated at 2022-06-22 21:24:39.516439
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        "name": {"type": "str"},
        "age": {"type": "int"},
    }

    assert ArgumentSpecValidator(argument_spec).validate({'name': 'bo', 'age': '42'}).validated_parameters == {'name': u'bo', 'age': 42}

# Generated at 2022-06-22 21:24:49.185724
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    print("In test_ArgumentSpecValidator_validate")

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = [['name', 'age']]

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive)
    result = validator.validate(parameters)
    print(result.errors)
    print(result.validated_parameters)

# Generated at 2022-06-22 21:25:00.842720
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_if = [
        ['name', 'age']
    ]
    required_by = {
        'name': ['age']
    }

    result = ArgumentSpecValidator(argument_spec,
                                   mutually_exclusive,
                                   required_together,
                                   required_one_of,
                                   required_if,
                                   required_by)

    assert sorted(result._valid_parameter_names) == ["age", "name"]


# Generated at 2022-06-22 21:25:01.696146
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:25:13.632509
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:25:21.291163
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    def get_spec():
        spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }
        return spec

    def get_parameters():
        parameters = {
            'name': 'bo',
            'age': '42',
        }
        return parameters

    validator = ArgumentSpecValidator(get_spec())
    result = validator.validate(get_parameters())

    assert len(result.error_messages) == 0
    assert result.validated_parameters == get_parameters()

# Generated at 2022-06-22 21:25:33.819519
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    :return: None
    """
    argument_spec = {
        "path": {
            "type": "str",
            "required": True,
            "aliases": ["destination", "dest"],
        },
        "src": {
            "type": "path",
            "required": True,
        },
        "state": {
            "type": "str",
            "default": "link",
            "aliases": ["ensure"],
            "choices": ['absent', 'link', 'hard', 'symlink'],
        },
        "force": {
            "type": "bool",
            "default": False,
        },
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-22 21:25:45.729167
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
    }
    mutually_exclusive = None
    required_together = [['name','age']]
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator.validate({'name': 'bo'}).error_messages[0] == "The required arguments ['age'] were not provided."
    assert validator.validate({'age': '42'}).error_messages[0] == "The required arguments ['name'] were not provided."

# Test to ensure the validation of mutually_exclusive option

# Generated at 2022-06-22 21:25:57.214015
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.validation import check_nested_required_arguments
    from ansible.module_utils.common.parameters import check_required_arguments_one_of, check_required_arguments_together
    from ansible.module_utils.common.warnings import deprecate, warn

    def check_required_arguments(spec, parameters):
        return check_nested_required_arguments(spec, parameters, errors=None)

    def check_required_arguments_one_of(one_ofs, parameters):
        return check_required_arguments_one_of(one_ofs, parameters, errors=None)

# Generated at 2022-06-22 21:25:58.134206
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass

# Generated at 2022-06-22 21:26:01.918461
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Test constructor of class ValidationResult"""
    parameters = {'name': 'bo', 'age': '42'}
    validation_result = ValidationResult(parameters)
    assert validation_result._validated_parameters == parameters

# Generated at 2022-06-22 21:26:11.055203
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == {'age': 42, 'name': 'bo'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-22 21:26:16.478398
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {}
    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()



# Generated at 2022-06-22 21:26:25.584479
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive=mutually_exclusive,
                                      required_together=required_together,
                                      required_one_of=required_one_of,
                                      required_if=required_if,
                                      required_by=required_by,
                                      )

    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:26:29.399843
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        "name": "Azure",
    }
    validation_result = ValidationResult(parameters)
    assert validation_result.validated_parameters['name'] == 'Azure'
    assert validation_result.error_messages == []


# Generated at 2022-06-22 21:26:40.677604
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    import ansible.module_utils.common.arg_spec as arg_spec_test_module
    import ansible.module_utils.common.json_sanitize as json_sanitize_test_module
    import ansible.module_utils.common.warnings as warnings_test_module
    import ansible.module_utils.common.validation as validation_test_module

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.warnings import DeprecationWarning
    from ansible.module_utils.six import PY3

    final_warnings = []
    final_deprecations = []
    final_error_messages = []

    if PY3:
        import io
        sys.stdout = io.StringIO()
       

# Generated at 2022-06-22 21:26:50.147328
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Test _list_no_log_values()
    argument_spec = {
        'name': {'type': 'str', 'no_log': True},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'foo',
        'age': 42,
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._no_log_values == set(['foo'])
    assert result.validated_parameters == parameters
    assert result.error_messages == []

    parameters = {
        'name': 'foo',
        'age': '42',
    }
    result = validator.validate(parameters)
    assert result._no_log_values == set(['foo'])


# Generated at 2022-06-22 21:27:00.470389
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import ansible.module_utils.common.arg_spec
    from unittest.mock import patch

    with patch.object(ansible.module_utils.common.arg_spec.ArgumentSpecValidator, '_warn') as mock_warn:
        ansible.module_utils.common.arg_spec.ArgumentSpecValidator(
            {'arg1': {'type': 'str', 'aliases': ['arg1_alias']}}).validate({'arg1': 'value1', 'arg1_alias': 'alias-value'})
        mock_warn.assert_called_once_with('Both option arg1 and its alias arg1_alias are set.')

# Generated at 2022-06-22 21:27:04.472306
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mv = ModuleArgumentSpecValidator()
    assert isinstance(mv, ModuleArgumentSpecValidator)
    assert isinstance(mv, ArgumentSpecValidator)


# Generated at 2022-06-22 21:27:13.893033
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

    assert valid_params['name'] == 'bo'
    assert valid_params['age'] == 42



# Generated at 2022-06-22 21:27:15.933056
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}) is not None


# Generated at 2022-06-22 21:27:26.771208
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    VALID_ARGUMENT_SPEC = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    # valid_parameter_names = [ 'age', 'name' ]
    validator = ArgumentSpecValidator(argument_spec=VALID_ARGUMENT_SPEC)
    assert validator._mutually_exclusive is None
    assert validator._required_together is None
    assert validator._required_one_of is None
    assert validator._required_if is None
    assert validator._required_by is None
    assert validator.argument_spec == VALID_ARGUMENT_SPEC


# Generated at 2022-06-22 21:27:36.526882
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """
    This method tests the validate method of class ArgumentSpecValidator.
    The method has been broken down into various unit tests.
    """
    # no_log_values in argument_spec and validated_parameters
    argument_spec = {
        'name': {'type': 'str', 'no_log': 'true'},
        'age': {'type': 'int', 'no_log': 'true'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result._no_log_values == set()

    # multiple mutually exclusive errors

# Generated at 2022-06-22 21:27:42.484683
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'arg1': {'type': 'bool'},
        'arg2': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec


# Generated at 2022-06-22 21:27:48.121076
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {"name": {"type": "str"}}
    parameters = {"name": "static test"}
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert result.validated_parameters == parameters
    assert result.errors == []
    assert result.error_messages == []

# Generated at 2022-06-22 21:27:48.890281
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:27:59.367906
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    validator = ModuleArgumentSpecValidator(argument_spec={'param1': {}})
    parameters = {'param1': 'value'}
    result = validator.validate(parameters)
    assert result.validated_parameters == {'param1': 'value'}

    parameters = {'param1': 'value', 'param2': 'value'}
    result = validator.validate(parameters)
    assert 'Unsupported parameters' in result.error_messages[0]
    assert 'param1' in result.validated_parameters
    assert 'param2' not in result.validated_parameters

    parameters = {'param1': 0}
    result = validator.validate(parameters)
    assert 'param1' in result.validated_parameters
    assert result.validated_parameters

# Generated at 2022-06-22 21:28:07.364151
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '43',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator is not None 


# Generated at 2022-06-22 21:28:16.277883
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod = ModuleArgumentSpecValidator(argument_spec={'a':{}, 'b':{}},
                                      mutually_exclusive=['a', 'b'],
                                      required_together=[['a', 'b']])

    assert mod._mutually_exclusive == ['a', 'b']
    assert mod._required_together == [['a', 'b']]
    assert mod._valid_parameter_names == {'a', 'b'}

# Generated at 2022-06-22 21:28:20.331523
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    '''
    Returns true if ValidationResult successfully created,
    else false
    '''
    # Python 3: avoid test failures when running with python -bb
    try:
        assert ValidationResult({})
        return True
    except:
        return False


# Generated at 2022-06-22 21:28:21.204769
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass


# Generated at 2022-06-22 21:28:25.378802
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    assert isinstance(validator, ArgumentSpecValidator)

# Unit tests for validate method of class ArgumentSpecValidator

# Generated at 2022-06-22 21:28:27.966673
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validation_result = ValidationResult(dict())
    assert not validation_result.error_messages
    assert not validation_result.unsupported_parameters

# Generated at 2022-06-22 21:28:39.133802
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(
        argument_spec=argument_spec,
        mutually_exclusive=[
            ['name', 'age']
        ],
        required_together=[
            ['name', 'age']
        ],
        required_one_of=[
            ['name', 'age']
        ],
        required_if=[
            ['name', 'age']
        ],
        required_by=[
            {'name': 'age'},
            {'age': 'name'},
        ],
    )
    assert type(validator) == ArgumentSpecValidator
    assert validator.argument_spec == argument_spec

# Generated at 2022-06-22 21:28:40.576286
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'name': 'bo'})


# Generated at 2022-06-22 21:28:49.931318
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters

# Generated at 2022-06-22 21:28:55.480995
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockArgumentSpecValidator:
        def validate(self, parameters):
            return 'arguments'

    with patch.object(
        ModuleArgumentSpecValidator, '__bases__', (MockArgumentSpecValidator,)
    ):
        validator = ModuleArgumentSpecValidator()

        assert validator.validate('parameters') == 'arguments'

# Generated at 2022-06-22 21:29:03.360246
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator({
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    })

    parameters = {
        'name': 'bo',
        'age': 42,
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == parameters
    assert result.errors == []
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()

# Generated at 2022-06-22 21:29:05.281422
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:29:13.521305
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = ['name', 'age']
    required_together = [['age', 'name']]
    required_one_of = [['name']]
    required_if = [['age', 42, ['name']]]
    required_by = {'name': ['age']}

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive,
                                      required_together=required_together, required_one_of=required_one_of,
                                      required_if=required_if, required_by=required_by)
    assert validator
    assert validator.argument_spec is argument_spec

# Generated at 2022-06-22 21:29:18.272689
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator is not None, "validator is null"

# Generated at 2022-06-22 21:29:30.545081
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import pytest
    from ansible.module_utils._text import to_text
    validator = ModuleArgumentSpecValidator({'a': {'type': 'str'}})
    assert validator._valid_parameter_names == set(['a'])

    class DoNothing:
        def __init__(self):
            self._deprecations = []
            self._warnings = []
        @staticmethod
        def append(w):
            pass

    with pytest.raises(TypeError):
        validator.validate({'a': 'foo', 'b': 'bar'}, deprecations=DoNothing(), warnings=DoNothing())

    assert validator.validate({'a': 'foo', 'b': 'bar'}).error_messages == ["unsupported parameters: ('b',)"]
    assert validator.valid

# Generated at 2022-06-22 21:29:41.820676
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    class MockParameters:
        def __init__(self, parameters):
            self.parameters = parameters

    class MockErrors:
        def __init__(self):
            self.error_msgs = []

        def append(self, msg):
            self.error_msgs.append(msg)

    class MockAnsibleModuleValidator:
        def __init__(self):
            pass

        def validate(self, parameters):
            return MockParameters(parameters)

    def mock_warn(msg, *args, **kwargs):
        print("MockWarning: {0}".format(msg))
        print("Optional Args: {0}".format(args))
        print("Optional Kwargs: {0}".format(kwargs))

    def mock_deprecate(msg, *args, **kwargs):
        print

# Generated at 2022-06-22 21:29:53.139008
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils._text import to_native
    argument_spec = {
            'foo': dict(type='str'),
            'bar': dict(type='str')
    }
    mutually_exclusive = [['foo', 'bar']]
    required_together = [['foo', 'bar']]
    required_one_of = [['foo', 'bar']]

    check_mutually_exclusive_mock = Mock()
    check_required_arguments_mock = Mock()
    result_mock = Mock()
    v = ModuleArgumentSpecValidator(
            argument_spec,
            mutually_exclusive,
            required_together,
            required_one_of
    )


# Generated at 2022-06-22 21:30:04.289239
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    mutually_exclusive = [
        ['name', 'age']
    ]
    required_together = [
        ['name', 'age']
    ]
    required_one_of = [
        ['name', 'age']
    ]
    required_if = [
        ['name', 'age']
    ]
    required_by = {
        'name': ['age'],
    }