

# Generated at 2022-06-22 21:20:08.265265
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Given
    args = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'item': {'type': 'dict',
                 'options': {
                   'shape': {'type': 'str'},
                   'color': {'type': 'str'},
                 }
        }
    }
    validator = ArgumentSpecValidator(args)

    # When
    valid_parameters = {
        'name': 'bo',
        'age': 42,
        'item': {
            'shape': 'square',
            'color': 'blue',
        },
    }

# Generated at 2022-06-22 21:20:10.570540
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator({
        'test': {
            'type': 'str',
            'default': 'default'
        }
    })

# Generated at 2022-06-22 21:20:21.595855
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    required_together = [['a', 'b']]
    mutually_exclusive = [['c', 'd']]
    argument_spec = {'a': {'type': 'str'},
                     'b': {'type': 'str'},
                     'c': {'type': 'str'},
                     'd': {'type': 'str'},
                     'e': {'type': 'str'},
                     'f': {'type': 'str'},
                     'g': {'type': 'str'},
                     }
    parameters = {'a': 'a',
                  'b': 'b',
                  'c': 'c',
                  'd': 'd',
                  'e': 'e',
                  'f': 'f',
                  'g': 'g',
                  }

    validator = ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:20:29.230724
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # assert_raises_regex is a Python 3.2+ function only
    try:
        # Python 3+
        from unittest.mock import patch
        from unittest import mock
        from unittest.mock import MagicMock
        my_mock = MagicMock()
        with patch.dict('sys.modules', unittest=my_mock):
            from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
            from unittest.mock import Mock
            my_mock.mock_module = Mock()
            from ansible.module_utils.parsing.convert_bool import boolean
            from ansible.module_utils.basic import AnsibleModule, env_fallback
    except ImportError:
        # Python 2
        from mock import patch
        from mock import mock

# Generated at 2022-06-22 21:20:34.460791
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'bo', 'age': '42'})

    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert result.error_messages == []
    assert result.errors == []
    assert result.unsupported_parameters == set()

# Generated at 2022-06-22 21:20:45.407750
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mutually_exclusive = [["a", "b"]]
    required_together = [["a", "b"]]
    required_one_of = [["a", "b", "c"]]
    required_if = [["a", "b", ["c", "d"]]]
    required_by = {"a": ["b", "c"], "b": ["d", "e"]}

    argument_spec = {
        "a": {"type": "str"},
        "b": {"type": "str"},
        "c": {"type": "str"},
        "d": {"type": "str"},
        "e": {"type": "str"}
    }


# Generated at 2022-06-22 21:20:47.626003
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    new_obj = ModuleArgumentSpecValidator()
    assert isinstance(new_obj, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:20:54.083366
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.error_messages == []


# Generated at 2022-06-22 21:21:05.222424
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # legally parameter name can be '0', but that's not supported by AnsibleModule
    # or other code so we will not investigate this case
    assert ArgumentSpecValidator({'arg': {'type': 'str'}}).validate({'arg': 0}).error_messages == [
        'The \"arg\" argument (which starts with a number) requires a string value, got 0']
    assert ArgumentSpecValidator({'arg': {'type': 'int'}}).validate({'arg': '0'}).error_messages == [
        'The \"arg\" argument requires a value of type int, got 0']
    assert ArgumentSpecValidator({'arg': {'type': 'bool'}}).validate({'arg': 0}).error_messages == [
        'The \"arg\" argument requires a value of type bool, got 0']


# Generated at 2022-06-22 21:21:14.385187
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import pytest
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning, AnsibleWarning

    argument_spec = {
        'name': {'type': 'str', 'aliases': ['foo']},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)
    assert not result.errors
    assert len(result._deprecations) == 1
    assert any(d['name'] == 'foo' for d in result._deprecations)
    assert len(result._warnings) == 1
    assert result._warnings[0] == {'option': 'name', 'alias': 'foo'}

# Generated at 2022-06-22 21:21:25.942352
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    kwargs = {
        'argument_spec': {
            'one': {'type': 'int', 'aliases': ['alias_one']},
            'two': {'type': 'int', 'aliases': ['alias_two']},
            'three': {'type': 'int'},
            'four': {'type': 'str'}
        },
        'mutually_exclusive': [['one', 'two'], ['three', 'four']],
        'required_if': [['one', 42, ['three', 'four']]],
        'required_by': {'four': ['one', 'three']},
        'required_together': [['one', 'two']],
        'required_one_of': [['one', 'two']]
    }

# Generated at 2022-06-22 21:21:34.050078
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """ check that correct number of deprecations and warnings are issued"""
    import subprocess
    import os
    from tempfile import TemporaryDirectory

    from ansible.module_utils._text import to_bytes

    here = os.path.abspath(os.path.dirname(__file__))
    with TemporaryDirectory() as test_dir:
        with open(os.path.join(here, 'fixtures', 'module_spec_validator_test.py'), 'rb') as f:
            test_file = os.path.join(test_dir, 'module_spec_validator_test.py')
            with open(test_file, 'wb') as f2:
                f2.write(f.read())

# Generated at 2022-06-22 21:21:43.307434
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
  validator = ModuleArgumentSpecValidator(argument_spec=dict({
    "parameters": {
      "type": "dict",
      "aliases": ['parms'],
      "default": {},
      "options": {
        "name": {"required": True, "type": "str"},
        "age": {"required": False, "type": "int", "default": 100}
      }
    }
  }))

  parameters = {'parameters': {'name': 'bo', 'age': 42}}

  result = validator.validate(parameters=parameters)

  assert result.validated_parameters == {'parameters': {'name': 'bo', 'age': 42}}

  parameters = {'parms': {'name': 'bo', 'age': 42}}


# Generated at 2022-06-22 21:21:55.274133
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    import sys
    #
    # Test for  validating arguments with different types.
    #
    _ = sys.argv

    _ = {
        'type': 'int'
    }
    _ = {
        'type': 'dict'
    }
    _ = {
        'type': 'list'
    }
    _ = {
        'type': 'str'
    }

    _ = {
        'date': 'date'
    }
    _ = {
        'datetime': 'datetime'
    }
    _ = {
        'bool': 'bool'
    }
    _ = {
        'float': 'float'
    }

    _ = {
        'default': 'default'
    }

    _ = {
        'required': 'required'
    }

# Generated at 2022-06-22 21:22:06.005454
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    from ansible.module_utils.common.collections import Mapping

    # case when no constructor argument is passed
    validobj = ArgumentSpecValidator(None)
    # check if legal_inputs is created correctly
    assert isinstance(validobj.legal_inputs, Mapping)
    assert len(validobj.legal_inputs) == 0

    # case when no argument_spec is passed
    validobj = ArgumentSpecValidator(None)
    # check if legal_inputs is created correctly
    assert isinstance(validobj.legal_inputs, Mapping)
    assert len(validobj.legal_inputs) == 0

    # case when argument_spec has values

# Generated at 2022-06-22 21:22:13.342783
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:22:22.784185
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'name': 'bo', 'age': '42'}
    result = ValidationResult(parameters)

    assert isinstance(result, ValidationResult)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result.validated_parameters, dict)
    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 0
    assert isinstance(result.unsupported_parameters, set)



# Generated at 2022-06-22 21:22:30.112338
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['old'], 'fallback': (1,)},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'old': '43',
        'other': 'something',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:22:40.399154
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    import sys
    class Testclass:
        def __init__(self):
            self._validated_parameters = {}
            self._no_log_values =None
            self._unsupported_parameters = None
            self.argument_spec = {}
    test = Testclass()
    test.argument_spec = {'name': {'type': 'str'}}
    parameters = {'name': 'Bo'}
    test.validate = ArgumentSpecValidator.validate(test, parameters)
    if test.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(test.error_messages)))
    valid_params = test.validated_parameters


# Generated at 2022-06-22 21:22:47.818688
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    argument_spec = {
        'name': {'type': 'str', 'required': True, 'fallback': (str,)},
        'age': {'type': 'int', 'required': False, 'fallback': (int,)},
    }

    result = ModuleArgumentSpecValidator(argument_spec).validate(parameters)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}


# Generated at 2022-06-22 21:22:56.241873
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert len(result.error_messages) == 0
    assert result.validated_parameters['name'] == 'bo'
    assert result.validated_parameters['age'] == 42

# Generated at 2022-06-22 21:23:07.611758
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    """
    Validate the behaviour of the constructor for ArgumentSpecValidator
    """
    argument_spec_a = {'a': {'type': 'str'}, 'b': {'type': 'str'}, 'c': {'type': 'str'}}
    validator = ArgumentSpecValidator(argument_spec_a,
                             mutually_exclusive=[],
                             required_together=[],
                             required_one_of=[],
                             required_if=[],
                             required_by=[]
                             )
    assert(validator.argument_spec == {'a': {'type': 'str'}, 'b': {'type': 'str'}, 'c': {'type': 'str'}})
    assert(validator._valid_parameter_names == {'a', 'b', 'c'})

# Generated at 2022-06-22 21:23:18.757317
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec= {
        "src": {
            "required": True,
            "type": "str"
        },
        "dest": {
            "required": False,
            "default": "",
            "type": "str"
        }
    }

    mutually_exclusive = None
    required_together = None
    required_one_of = None
    required_if = None
    required_by = None

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)

    parameters = {"src": "/path/to/src/file"}

    result = validator.validate(parameters)

    assert result._valid_parameter_names == {"src", "dest"}

# Generated at 2022-06-22 21:23:28.229293
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    args = [{'name': {'type': 'str'}},
            [],
            None,
            None,
            None,
            None]
    c = ArgumentSpecValidator(*args)
    assert c.argument_spec == args[0]
    assert c._mutually_exclusive == args[1]
    assert c._required_together == args[2]
    assert c._required_one_of == args[3]
    assert c._required_if == args[4]
    assert c._required_by == args[5]

# Generated at 2022-06-22 21:23:33.396413
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.text.converters import to_text

    def _basic_arg_spec():
        return {
            'name': {'type': 'str'},
            'age': {'type': 'int'},
        }

    def _basic_parameters():
        return {
            'name': 'bo',
            'age': '42',
        }

    validator = ArgumentSpecValidator(_basic_arg_spec(), required_one_of=[[['name', 'age']]])
    result = validator.validate(_basic_parameters())
    assert len(result.validated_parameters) == 2, "Validation failed: {0}".format(", ".join(result.error_messages))
    assert len(result.error_messages) == 0

    validator = Argument

# Generated at 2022-06-22 21:23:33.996754
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ValidationResult({})

# Generated at 2022-06-22 21:23:41.400741
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import serialize_no_log_values
    import json

# Generated at 2022-06-22 21:23:49.299889
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    for test_argument_spec in [
        None,
        {},
        {'test_arg': {}},
    ]:
        result = ValidationResult(test_argument_spec)
        assert result._validated_parameters == test_argument_spec
        assert result._deprecations == []
        assert result._warnings == []
        assert result.errors == AnsibleValidationErrorMultiple()
        assert result.errors.messages == []
        assert result._no_log_values == set()
        assert result._unsupported_parameters == set()
        assert hasattr(result, "validated_parameters")
        assert hasattr(result, "error_messages")

# Unit tests of constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:23:51.234099
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    result = ModuleArgumentSpecValidator.validate([])
    assert result is None


# Generated at 2022-06-22 21:23:53.190211
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate method of class ArgumentSpecValidator"""
    pass

# Generated at 2022-06-22 21:24:00.096773
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import os
    import sys
    import __main__ as main

    if 'TEST_MODULE_ARG_SPEC_VALIDATOR' in os.environ:
        module_args = sys.argv[1:]
        result = {}
        result['invocation'] = dict(module_args=module_args)
        result['ansible_facts'] = dict(module_args=module_args)
        result['warnings'] = []
        result['changed'] = False
        result['deprecations'] = []
        result['_ansible_version'] = 0
        sys.stdout.write(json.dumps(result))
        sys.exit(0)

# Generated at 2022-06-22 21:24:11.821437
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_required_if, check_required_by
    from ansible.module_utils.common.parameters import _validate_argument_values

    check_if = {'func': check_required_if, 'attr': '_required_if', 'err': RequiredError}
    _ADDITIONAL_CHECKS.append(check_if)

    check_by = {'func': check_required_by, 'attr': '_required_by', 'err': RequiredError}
    _ADDITIONAL_CHECKS.append(check_by)

    res = {'name': 'test', 'age': 'test'}

# Generated at 2022-06-22 21:24:21.501148
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import string_types

    class FakeResult:
        def __init__(self, errors=[], warnings=[]):
            self.errors = errors
            self.warnings = warnings

    class FakeValidator:
        def __init__(self, previous_result):
            self.previous_result = previous_result

        def validate(self, parameters):
            return self.previous_result

    # Test 1: no errors and no warnings
    previous_result = FakeResult()
    validator = ModuleArgumentSpecValidator()
    # pylint: disable=protected-access
    result = validator._validate(parameters={}, previous_result=previous_result)
    assert result.errors == []
    assert result.warnings == []
    assert isinstance(result, ValidationResult)

   

# Generated at 2022-06-22 21:24:26.769094
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    arr = [1,2,2,3]
    param_spec = {'arr': {'type':'list', 'elements': 'int'}}
    validator = ModuleArgumentSpecValidator(param_spec, required_one_of=[['arr']])
    parameters = {'arr': arr}
    result = validator.validate(parameters)
    assert result.validated_parameters.get('arr') == arr

# Generated at 2022-06-22 21:24:33.867561
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str', 'aliases': ['foo']},
    }
    v = ModuleArgumentSpecValidator(spec)

    assert v._valid_parameter_names == {"param1", "param2 (foo)"}
    assert v.argument_spec == spec

# Generated at 2022-06-22 21:24:45.576145
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
   with pytest.raises(TypeError):
        ArgumentSpecValidator()

   with pytest.raises(TypeError):
       ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}},
                           mutually_exclusive=['name', 'age'])

   with pytest.raises(TypeError):
      ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}, 'age': {'type': 'int'}},
                           mutually_exclusive=[[['name', 'age']]])


# Generated at 2022-06-22 21:24:58.480340
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:25:03.534926
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    test_dict = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    result = ValidationResult(test_dict)

    assert result._no_log_values == set()
    assert result._validated_parameters == test_dict
    assert result._warnings == []
    assert result._deprecations == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:25:10.300245
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    ''' Test our ValidationResult constructor '''
    parameters = { 'one': '1', 'two': 2, 'three': '3' }
    r = ValidationResult(parameters)
    assert r._no_log_values == set()
    assert r._unsupported_parameters == set()
    assert r._validated_parameters == parameters
    assert r._deprecations == []
    assert r._warnings == []
    assert r.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:25:17.078186
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec, mutual_exclusive, required_together, required_one_of, required_if, required_by = \
        {"argument_spec": {}, "mutually_exclusive": None, "required_together": None, "required_one_of": None, "required_if": None, "required_by": None}
    result = ModuleArgumentSpecValidator(argument_spec, mutual_exclusive, required_together, required_one_of, required_if, required_by)
    assert result

# Generated at 2022-06-22 21:25:18.235814
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({}) is not None


# Generated at 2022-06-22 21:25:25.087930
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # Test with all constructor kwargs
    # This tests the constructor and ensures there are no exceptions
    arg_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }
    mutually_exclusive = ['name', 'age']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age', ['age']]]
    required_by = {'age': ['age']}

# Generated at 2022-06-22 21:25:29.242319
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
  argument_spec = {
      'name': {'type': 'str'},
      'age': {'type': 'int'},
  }
  parameters = {
      'name': 'bo',
      'age': '42',
  }

  validator = ArgumentSpecValidator(argument_spec)
  result = validator.validate(parameters)

  assert result.validated_parameters == {
      'name': 'bo',
      'age': 42,
  }


# Generated at 2022-06-22 21:25:32.863352
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    instance = ArgumentSpecValidator(argument_spec)
    assert isinstance(instance, ArgumentSpecValidator)

# Generated at 2022-06-22 21:25:38.836654
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys

    def assert_error_type(errors, error_type):
        found_errors = []
        for error in errors:
            if isinstance(error, error_type):
                found_errors.append(error)
        assert len(found_errors) == 1, "Did not find exactly one error of type {} in errors: {}".format(error_type, errors)
        return found_errors[0]


# Generated at 2022-06-22 21:25:51.152885
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Arrange
    test_cases = []

    # Mutually exclusive sets of arguments
    test_cases.append({
        'argument_spec': dict(
            required_one_of=[['required_one_of_0', 'required_one_of_1']],
            required_together=[['required_together_0', 'required_together_1']]
        ),
        'parameters': dict(
            required_one_of_0=True,
            required_one_of_1=False,
            required_together_0=True,
            required_together_1=False,
        ),
        'expected_error_messages': [],
    })

    # Mutually exclusive sets of arguments - both required_one_of arguments provided

# Generated at 2022-06-22 21:26:00.228376
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.warnings import deprecate, warn

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    mutually_exclusive = [['name', 'age']]

    alias_warnings = []
    alias_deprecations = []

    result = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive)
    result.validate(parameters)

    check_mutually_exclusive.assert_called_once_with(mutually_exclusive, parameters)


# Generated at 2022-06-22 21:26:12.235607
# Unit test for method validate of class ArgumentSpecValidator

# Generated at 2022-06-22 21:26:17.177728
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    validator.validate(parameters)

# Generated at 2022-06-22 21:26:28.065750
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:26:39.913715
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'num_list': {'type': 'list', 'elements': 'int'},
        }
    mutually_exclusive = [['name', 'age']]
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert (validator._mutually_exclusive == ['name', 'age'])
    assert (validator._required_together == [])
    assert (validator._required_one_of == [])
    assert (validator._required_if == [])
   

# Generated at 2022-06-22 21:26:43.706991
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    assert ArgumentSpecValidator(argument_spec)

# Generated at 2022-06-22 21:26:46.114443
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    vr = ValidationResult("parameters")
    assert vr.validated_parameters == "parameters"
    assert vr.error_messages == []



# Generated at 2022-06-22 21:26:55.146366
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
    unit test for validate method of class ModuleArgumentSpecValidator
    """
    class ArgumentSpecValidatorMock:
        """
        Mock class for ArgumentSpecValidator class
        """

        def __init__(self, *args, **kwargs):
            self._mutually_exclusive = None
            self._required_together = None
            self._required_one_of = None
            self._required_if = None
            self._required_by = None
            self._valid_parameter_names = set()
            self.argument_spec = None

        def validate(self, parameters):
            """
            Mock function for validate method of class ArgumentSpecValidator
            """
            class ValidationResultMock:
                """
                Mock class for ValidationResult class
                """
                def __init__(self, parameters):
                    self._

# Generated at 2022-06-22 21:27:02.011386
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    #setup
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}
    validator = ArgumentSpecValidator(argument_spec)

    #execute
    result = validator.validate(parameters)

    #assert
    assert isinstance(result, ValidationResult)
    assert isinstance(result.error_messages, list)
    assert len(result.error_messages) == 0



# Generated at 2022-06-22 21:27:13.354156
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [['name', 'age']]
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age']]
    required_by = {'name': ['age']}

    assert isinstance(ArgumentSpecValidator(argument_spec,
                                            mutually_exclusive=mutually_exclusive,
                                            required_together=required_together,
                                            required_one_of=required_one_of,
                                            required_if=required_if,
                                            required_by=required_by),
                      ArgumentSpecValidator)


# Unit

# Generated at 2022-06-22 21:27:16.349614
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """
    :return: instance of class ValidationResult
    """
    v_instance = ValidationResult("parameter_test")
    return v_instance

# Generated at 2022-06-22 21:27:26.588574
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert result.validated_parameters
    assert not result.error_messages

    assert result.validated_parameters['age'] == 42
    assert result.validated_parameters['name'] == 'bo'


# Generated at 2022-06-22 21:27:36.373835
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    import sys

    content = StringIO()
    sys.stdout = content

    # Deprecate a normal parameter alias
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['user-name', 'user_name'],
        }
    }
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = []

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive,
                                            required_together, required_one_of,
                                            required_if, required_by)


# Generated at 2022-06-22 21:27:42.328431
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {'name': {'type': 'str'}}
    validator = ArgumentSpecValidator(argument_spec)
    parameters = {'name': 'bo'}
    result = validator.validate(parameters)
    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-22 21:27:50.901319
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    # Arrange
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    # Act
    result = validator.validate(parameters)

    # Assert
    assert len(result.error_messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:28:00.903385
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'arg1': {
            'aliases': ['arg1_alias', 'arg1_alias1'],
            'type': 'str',
            'required': True,
            'no_log': False,
            'deprecated': {'version': '1.0', 'collection_name': 'a'}}
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({'arg1_alias': 'test',
                                 'arg1_alias1': 'test1'})

    assert result.error_messages == []
    assert result.validated_parameters['arg1'] == 'test'
    assert result.validated_parameters['arg1_alias'] == 'test'

# Generated at 2022-06-22 21:28:10.457764
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)


# Generated at 2022-06-22 21:28:22.444601
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {}
    mutually_exclusive = []
    required_together = []
    required_one_of = []
    required_if = []
    required_by = {}
    kwargs = {
        'mutually_exclusive': mutually_exclusive,
        'required_together': required_together,
        'required_one_of': required_one_of,
        'required_if': required_if,
        'required_by': required_by,
    }
    validator = ModuleArgumentSpecValidator(argument_spec, **kwargs)
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_together == required_together
    assert validator._required_one_of == required_one_of
    assert validator._required_if

# Generated at 2022-06-22 21:28:32.556904
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """
        ValidationResult.validated_parameters and ValidationResult.error_messages should be checked
        for correct values.
    """
    argument_spec = {
        'name': {'type': 'str', 'default': 'bo'},
        'age': {'type': 'int'},
        'employed': {'type': 'bool', 'default': False}
    }
    # Test ValidationResult.error_messages
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({})
    assert result.error_messages == ["Required parameter missing: age"]

    result = validator.validate({'age': '42'})
    assert result.error_messages == []
    assert result.validated_parameters['name'] == 'bo'

# Generated at 2022-06-22 21:28:34.499959
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {}

    validator = ArgumentSpecValidator(argument_spec)
    assert validator


# Generated at 2022-06-22 21:28:46.912129
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """Check that ValidationResult has the expected attributes"""
    parameters = {}
    result = ValidationResult(parameters)
    assert hasattr(result, '_no_log_values'), '_no_log_values'
    assert hasattr(result, '_unsupported_parameters'), '_unsupported_parameters'
    assert hasattr(result, '_validated_parameters'), '_validated_parameters'
    assert hasattr(result, 'errors'), 'errors'
    assert hasattr(result, 'validated_parameters'), 'validated_parameters'
    assert hasattr(result, 'unsupported_parameters'), 'unsupported_parameters'
    assert hasattr(result, 'error_messages'), 'error_messages'
    assert result._unsupported_parameters == set()
    assert result._no_log

# Generated at 2022-06-22 21:28:56.715776
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert set(validator._valid_parameter_names) == set(['name', 'age'])

    validator = ModuleArgumentSpecValidator(argument_spec, required_if=[('name', 'foo', ['state'])])
    assert validator.argument_spec == argument_spec
    assert validator._required_if == [('name', 'foo', ['state'])]
    assert set(validator._valid_parameter_names) == set(['name', 'age'])



# Generated at 2022-06-22 21:29:04.846466
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = None
    required_one_of = None
    required_together = None
    required_if = None
    required_by = None

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive, required_one_of, required_together, required_if, required_by)

    assert validator._mutually_exclusive == mutually_exclusive
    assert validator._required_one_of == required_one_of
    assert validator._required_together == required_together
    assert validator._required_if == required_if
    assert validator._required_by == required_by

# Generated at 2022-06-22 21:29:11.937189
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
     argument_spec = {
                    'name': {'type': 'str'},
                    'age': {'type': 'int'},
                }

     parameters = {
                    'name': 'bo',
                    'age': '42',
                }

     validator = ArgumentSpecValidator(argument_spec)
     result = validator.validate(parameters)

     assert result.error_messages == [], 'Valid parameters, should not have any errors'
     assert result.validated_parameters == {'name': 'bo', 'age': 42}, 'Validated parameters should be the same'



# Generated at 2022-06-22 21:29:21.745061
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    """Validate a simplified argument spec and parameters."""
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

    valid_params = result.validated_parameters
    print(valid_params)


if __name__ == '__main__':
    test_ArgumentSpecValidator_validate()

# Generated at 2022-06-22 21:29:32.738617
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import sys
    # Test validate of class ModuleArgumentSpecValidator
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }
    # Test ModuleArgumentSpecValidator.validate
    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    if result.error_messages:
        sys.exit("Validation failed: {0}".format(", ".join(result.error_messages)))

# Generated at 2022-06-22 21:29:40.929215
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    p = {'a': 1, 'b': 2}
    r = ValidationResult(p)
    assert len(r.errors) == 0
    assert r._no_log_values == set()
    assert r._unsupported_parameters == set()
    assert r._validated_parameters == p
    assert r._deprecations == []
    assert r._warnings == []
    assert r.validated_parameters == p
    assert r.unsupported_parameters == set()
    assert len(r.error_messages) == 0


# Generated at 2022-06-22 21:29:45.702038
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }
    validator = ModuleArgumentSpecValidator(argument_spec)
    assert validator.argument_spec is argument_spec

# Generated at 2022-06-22 21:29:47.147986
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult is not None

# Generated at 2022-06-22 21:29:54.199339
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {
        'name': 'bo',
        'age': 42,
    }


# Generated at 2022-06-22 21:29:59.522189
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    module_validator = ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive=[],
                                           required_together=[],
                                           required_one_of=[],
                                           required_if=[],
                                           required_by={})
    assert isinstance(module_validator, ModuleArgumentSpecValidator)