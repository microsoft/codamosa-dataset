

# Generated at 2022-06-22 21:20:07.428489
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # check the constructor of class ModuleArgumentSpecValidator
    validator = ModuleArgumentSpecValidator(
        argument_spec={'name': {'type': 'str'}},
        mutually_exclusive=[['a']],
        required_together=[['b']],
        required_one_of=[['c']],
        required_if=[['d']],
        required_by=[['e']])

    # check object creation
    assert validator._mutually_exclusive == [['a']]
    assert validator._required_together == [['b']]
    assert validator._required_one_of == [['c']]
    assert validator._required_if == [['d']]
    assert validator._required_by == {'e': []}
    assert validator._valid_parameter_names == {'name'}

# Generated at 2022-06-22 21:20:15.172666
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    params = dict(a=1, b=2, c=3)
    check_obj = ValidationResult(params)
    assert check_obj.validated_parameters == params
    assert isinstance(check_obj._no_log_values, set)
    assert isinstance(check_obj._unsupported_parameters, set)
    assert isinstance(check_obj._validated_parameters, dict)
    assert isinstance(check_obj.errors, AnsibleValidationErrorMultiple)
    assert check_obj.error_messages == []

# Generated at 2022-06-22 21:20:25.929727
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from unittest.mock import Mock

    spec = {
        "param1": {"required": True, "type": "str"},
        "param2": {"required": True, "type": "int"},
        "param3": {"required": False, "type": "str"},
        "param4": {"required": True, "type": "bool"},
    }

    validator = ArgumentSpecValidator(spec)
    module = Mock(params=Mock(return_value={"param1": "foo", "param2": 2, "param3": "bar", "param4": True}))

    result = validator.validate(module)
    assert result.validated_parameters == {'param1': 'foo', 'param2': 2, 'param3': 'bar', 'param4': True}

# Generated at 2022-06-22 21:20:36.489361
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type':'str'},
        'age': {'type':'int'},
    }
    mutually_exclusive = ['name', 'age']
    required_together = [
        ['name', 'age'],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_if = [
        ['name', 'age', ['age']],
    ]
    required_by = {
        'name': 'age',
    }
    validator = ArgumentSpecValidator(argument_spec,mutually_exclusive,
                                      required_together, required_one_of,
                                      required_if, required_by)
    assert argument_spec == validator.argument_spec
    assert mutually_exclusive == validator._mutually_exclusive
   

# Generated at 2022-06-22 21:20:43.755520
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    validator = ModuleArgumentSpecValidator({}, required_together=[[]])
    assert validator.argument_spec == {}
    assert validator._mutually_exclusive == None
    assert validator._required_together == [[]]
    assert validator._required_one_of == None
    assert validator._required_if == None
    assert validator._required_by == None
    assert validator._valid_parameter_names == set()


# test functions of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:20:45.587748
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass  # Nothing to test as of now

# Generated at 2022-06-22 21:20:49.638856
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    y = {'Name': 'ankita', 'age': '27'}
    a = ValidationResult(y)
    assert a._validated_parameters == {'Name': 'ankita', 'age': '27'}



# Generated at 2022-06-22 21:21:01.660795
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    """
    :return: True
    :rtype: bool
    """
    # Sample argument_spec - to be used by multiple modules
    argument_spec = {
        "foo": { "type": "str", "required": True },
        "bar": { "type": "str", "required": True },
        "bam": { "type": "str", "default": "bam_value" },
        "boo": { "type": "int", "default": 42 },
        "abc": { "type": "int" },
        "xyz": { "type": "list", "default": [ "bam", "baz" ] },
    }


# Generated at 2022-06-22 21:21:08.774698
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []

# Generated at 2022-06-22 21:21:17.482283
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    assert ValidationResult({'test': 'value'})


if __name__ == '__main__':
    argument_spec = {'name': {'type': 'str'}, 'age': {'type': 'int'}}
    parameters = {'name': 'bo', 'age': '42'}

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert isinstance(result, ValidationResult)
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:21:20.710400
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {'name': {'type': 'str'},
                     'age': {'type': 'int'}}
    validator = ArgumentSpecValidator(argument_spec)
    assert validator is not None

# Generated at 2022-06-22 21:21:30.955289
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    m = ModuleArgumentSpecValidator(
        argument_spec = {
            'name': {
                'type': 'str',
                'aliases': ['alias1'],
            },
            'age': {
                'type': 'str',
                'aliases': ['alias2'],
            },
        },
    )

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = m.validate(parameters)

    assert result.validated_parameters == {
        'name': 'bo',
        'age': '42',
    }

    assert result.error_messages == []
    assert result.unsupported_parameters == set()


# Generated at 2022-06-22 21:21:40.375479
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():

    spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'int'}
    }

    validator = ArgumentSpecValidator(spec)
    result = validator.validate(dict(param1='valid', param2='value'))

    assert len(result.error_messages) == 1

    spec = {
        'param1': {'type': 'str', 'aliases': ['param1_alias']},
        'param2': {'type': 'int'}
    }

    validator = ArgumentSpecValidator(spec)
    result = validator.validate(dict(param1='valid', param1_alias='valid', param2='value'))
    assert len(result.error_messages) == 2

# Generated at 2022-06-22 21:21:41.902906
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:21:42.805607
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert False, "TODO"

# Generated at 2022-06-22 21:21:54.808260
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # check parameters is copied
    parameters = {'a': 1}
    result = ValidationResult(parameters)

    parameters['a'] = 'test'
    assert result.validated_parameters['a'] == 1

    # check attributes are initialized to empty set and empty list
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []

    # check _no_log_values gets updated
    result._no_log_values.update((1, 2))
    assert result._no_log_values == set((1, 2))

    # check validated_parameters gets updated
    result._validated

# Generated at 2022-06-22 21:21:58.852006
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    validate_arguments = {}
    validate_arguments = ValidationResult(validate_arguments)
    assert validate_arguments._no_log_values == set()
    assert validate_arguments._unsupported_parameters == set()
    assert validate_arguments._validated_parameters == {}
    assert validate_arguments._deprecations == []
    assert validate_arguments._warnings == []
    assert validate_arguments.errors == AnsibleValidationErrorMultiple()
    assert validate_arguments.validated_parameters == {}
    assert validate_arguments.unsupported_parameters == set()
    assert validate_arguments.error_messages == []


# Generated at 2022-06-22 21:21:59.764734
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result is not None


# Generated at 2022-06-22 21:22:02.721020
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    mod_arg_spec_val = ModuleArgumentSpecValidator.__new__(ModuleArgumentSpecValidator)
    del mod_arg_spec_val



# Generated at 2022-06-22 21:22:10.207671
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    # argument_spec is of the form:
    #   <parameter_name>: {'default': <default value>, 'type': <type>, 'required': <True or False>}
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42},
    }
    validator = ArgumentSpecValidator(argument_spec)
    assert(validator._mutually_exclusive == None)
    assert(validator._required_together == None)
    assert(validator._required_one_of == None)
    assert(validator._required_if == None)
    assert(validator._required_by == None)
    assert(validator._valid_parameter_names == set(['age', 'name']))

# Generated at 2022-06-22 21:22:17.211110
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ArgumentSpecValidator(argument_spec)

    result = validator.validate(parameters)

    assert len(result.error_messages) == 0
    assert result.validated_parameters == {'name': 'bo', 'age': 42}



# Generated at 2022-06-22 21:22:27.484721
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = dict(
        param1 = dict(type = 'str'),
        param2 = dict(type = 'str')
    )

    result = ValidationResult(parameters)
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == dict(
        param1 = dict(type = 'str'),
        param2 = dict(type = 'str')
    )
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == dict(
        param1 = dict(type = 'str'),
        param2 = dict(type = 'str')
    )
    assert result.unsupported_parameters == set()
    assert result

# Generated at 2022-06-22 21:22:33.593387
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)
    assert not result._deprecations
    assert not result._warnings
    assert not result.error_messages

    # test deprecation warning
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'aliases': ['age_1', 'age_2']},
    }


# Generated at 2022-06-22 21:22:40.493210
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    v = ValidationResult({})
    assert v._no_log_values == set()
    assert v._unsupported_parameters == set()
    assert v._validated_parameters == {}
    assert v._deprecations == []
    assert v._warnings == []
    assert v.errors == AnsibleValidationErrorMultiple()
    assert v.validated_parameters == {}
    assert v.unsupported_parameters == set()
    assert v.error_messages == []

# Generated at 2022-06-22 21:22:49.783808
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    mutex = ['a', 'b', 'c']
    required_together = [['a', 'b', 'c']]
    required_one_of = [['a', 'b', 'c']]
    required_if = [['a', 'b', 'c']]
    required_by = {'a': ['b', 'c'], 'b': ['a'], 'c': ['a']}

    argument_spec = {
        'a': {'type': 'int'},
        'b': {'type': 'int'},
        'c': {'type': 'int'},
        'd': {'type': 'int'},
    }

    parameters = {
        'a': '1',
        'b': '2',
        'c': '3',
        'd': '4',
    }

# Generated at 2022-06-22 21:22:58.910667
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    import warnings
    warnings.filterwarnings('error', category=DeprecationWarning)
    from ansible.module_utils._text import to_native


# Generated at 2022-06-22 21:23:03.377139
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'name': {
            'type': 'str',
            'aliases': ['fake_name'],
            'default': 'lala',
        }
    }
    mutually_exclusive = [
        ['name', 'fake_name']
    ]

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    parameters = {
        'name': 'lala',
    }

    validator.validate(parameters)

    parameters = {
        'fake_name': 'lala',
    }

    validator.validate(parameters)

# Generated at 2022-06-22 21:23:10.531508
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from collections import deque
    # set up data
    args = deque()
    args.append((
        {'name': {'type': 'str', 'required': True},
         'age': {'type': 'int', 'required': True, 'default': 42}},
        None,
        None,
        None,
        None,
        {'name': 'bo', 'age': '42'}))
    args.append((
        {'name': {'type': 'str', 'required': True},
         'age': {'type': 'int', 'required': True, 'default': 42}},
        None,
        None,
        None,
        None,
        {'name': 'bo'}))
    args.append

# Generated at 2022-06-22 21:23:12.375672
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)


# Generated at 2022-06-22 21:23:17.664103
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # testing type of ModuleArgumentSpecValidator
    assert isinstance(ModuleArgumentSpecValidator, type)

    # testing type of ModuleArgumentSpecValidator()
    assert isinstance(ModuleArgumentSpecValidator(), ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:23:24.145136
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import to_native
    from ansible import module_utils
    from ansible.errors import AnsibleError
    module_utils.basic.ANSIBLE_METADATA = {}

    class TestModule(object):
        def __init__(self, parameter_s, argument_spec):
            self.argument_spec = argument_spec
            self.params = parameter_s

        def fail_json(self, *args, **kwargs):
            raise AnsibleError(kwargs["msg"])

        def warn(self, *args, **kwargs):
            print(to_native(kwargs["msg"]))


# Generated at 2022-06-22 21:23:29.604378
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'name': 'foo'})
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {'name': 'foo'}
    assert result.errors == AnsibleValidationErrorMultiple()
    assert result.validated_parameters == {'name': 'foo'}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:23:38.428348
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [
        ['name', 'age'],
    ]

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters['age'] == 42

    parameters['age'] = '42.5'

    validator = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive)
    result = validator.validate(parameters)

    assert result.error_

# Generated at 2022-06-22 21:23:42.252341
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'arg1': 1, 'arg2': 1}
    v = ValidationResult(parameters)
    assert v.validated_parameters == parameters
    assert v.error_messages == []
    assert v.unsupported_parameters == set()

# Generated at 2022-06-22 21:23:43.554950
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    check = lambda: ModuleArgumentSpecValidator({})
    assert check()

# Generated at 2022-06-22 21:23:49.401562
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    assert validator.argument_spec == argument_spec
    assert validator._required_together is None
    assert validator._required_if is None
    assert validator._required_one_of is None
    assert validator._required_by is None
    assert validator._mutually_exclusive is None



# Generated at 2022-06-22 21:23:59.091339
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        }

    mutually_exclusive = ['name', 'age']
    required_together = [['name', 'age']]
    required_one_of = [['name', 'age']]
    required_if = [['name', 'age']]
    required_by = {'name': 'age'}

    validator = ArgumentSpecValidator(argument_spec,
                                      mutually_exclusive,
                                      required_together,
                                      required_one_of,
                                      required_if,
                                      required_by)

    ## Test that arguments in constructor are saved in the class
    assert validator._mutually_exclusive == ['name', 'age']

# Generated at 2022-06-22 21:24:06.040311
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test validate method of class ModuleArgumentSpecValidator"""
    test_result = ValidationResult({})
    test_result.validated_parameters = {
        'name': 'bo',
        'age': '42',
        'aliases': ['bob'],
        'mutex': ['a', 'b'],
        'collection_name': 'test_collection'
    }

    test_result._deprecations = [
        {
            'name': 'bob',
            'version': '2.8',
            'date': '2021-08-01',
            'collection_name': 'test_collection'
        }
    ]

    test_result._warnings = [
        {
            'option': 'name',
            'alias': 'bob'
        }
    ]


# Generated at 2022-06-22 21:24:06.470192
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    pass

# Generated at 2022-06-22 21:24:17.897001
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'child': {
            'child_name': {'type': 'str'},
            'child_age': {'type': 'int'},
        },
    }

    parameters = {
        'name': 'bo',
        'age': '42',
        'child': {
            'child_name': 'bo'
        }
    }

    validator = ArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.errors == []


# Generated at 2022-06-22 21:24:24.597652
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    validator = ArgumentSpecValidator(argument_spec={"test":{"type":"str"}})
    result = validator.validate({'test': 'test'})

    assert "test", "test" in result.validated_parameters
    assert result.errors == []
    assert result.error_messages == []
    assert result.unsupported_parameters == []
    assert result._no_log_values == []

# Generated at 2022-06-22 21:24:29.046899
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    ASV = ArgumentSpecValidator
    a = ASV({'a': {'type': 'str'}}, [])
    assert a.argument_spec == {'a': {'type': 'str'}}
    assert a._mutually_exclusive == []

    b = ASV({'b': {'type': 'str'}}, [['a', 'b']])
    assert b._mutually_exclusive == [['a', 'b']]


# Generated at 2022-06-22 21:24:36.739689
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert result.validated_parameters == {}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._validated_parameters == {}
    assert result._deprecations == []
    assert result._warnings == []
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.error_messages == []


# Generated at 2022-06-22 21:24:45.092312
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    from ansible.module_utils.common.arg_spec import ModuleArgumentSpecValidator
    import pdb

    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'default': 42, 'required': True},
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate({'name': 'bo'})

    assert len(result.errors) == 1
    assert isinstance(result.errors[0], NoLogError)

    pdb.set_trace()

# Generated at 2022-06-22 21:24:57.961839
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    arguments = {
        'url': {'type': 'str'},
        'force': {'type': 'bool', 'default': False},
        'register': {'type': 'bool', 'default': False},
        'client_cert': {'type': 'str', 'default': '/etc/ssl/certs/client.pem'},
        'client_key': {'type': 'str', 'default': '/etc/ssl/private/client.key'},
    }

    validator = ModuleArgumentSpecValidator(arguments)

    result = validator.validate({
        'foo': 'bar',
        'client_cert': '/etc/ssl/certs/client.pem',
        'client_key': '/etc/ssl/private/client.key',
    })


# Generated at 2022-06-22 21:25:02.956517
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {'param1':1, 'param2': 2}
    result = ValidationResult(parameters)
    assert result._validated_parameters == parameters
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:25:08.652878
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    exp_validated_parameters = {
        'validated_parameters': {
            'name': {'type': 'str'}
        },
        'validated_keys': ['name'],
        'validated_value': {'type': 'str'}
    }

    result = ValidationResult(exp_validated_parameters)

    assert result._validated_parameters == exp_validated_parameters


# Generated at 2022-06-22 21:25:15.806604
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    a = {'argument_spec':{'a':{'type':'str'},'b':{'type':'str'}}}
    b = {'argument_spec':{'a':{'type':'str'},'b':{'type':'str'}}}
    c = {'argument_spec':{'a':{'type':'str'},'b':{'type':'str'}}}
    d = {'argument_spec':{'a':{'type':'str'},'b':{'type':'str'}},
            }

# Generated at 2022-06-22 21:25:16.704944
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:25:28.653895
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    mutually_exclusive = [('first', 'second'), ('third', 'fourth')]
    required_together = [('first', 'second')]
    required_one_of = [('first', 'second')]
    required_if = [('first', 'second', ['third'])]
    required_by = {'first': ['second']}
    validator = ArgumentSpecValidator(argument_spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert validator._valid_parameter_names == {'age', 'name'}
    assert validator.argument_spec == argument_spec
    assert validator._mutually_exclusive == mutually

# Generated at 2022-06-22 21:25:36.522814
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    parameters = {
        'name': 'bo',
        'age': '42',
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    result = validator.validate(parameters)

    assert result.error_messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': 42}

# Generated at 2022-06-22 21:25:48.138186
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'sex': {'type': 'str', 'default': 'Male'},
    }
    mutually_exclusive = [
        ['name', 'age'],
    ]
    required_together = [
        ['name', 'age'],
        ['name', 'sex'],
    ]
    required_one_of = [
        ['name', 'age'],
    ]
    required_if = [
        ['name', 'World', ['age']],
    ]
    required_by = {
        'name': ['age', 'sex'],
        'age': ['name'],
    }


# Generated at 2022-06-22 21:25:56.727473
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {'valid_keys': {'type': 'list', 'no_log': True}}
    mutually_exclusive = [['a', 'b']]
    required_together = [['b', 'c']]
    required_one_of = [('b', 'c')]
    required_if = [['a', 'b', 'c']]
    required_by = {'a': 'b'}

    mv = ModuleArgumentSpecValidator(spec, mutually_exclusive, required_together, required_one_of, required_if, required_by)
    assert isinstance(mv, ModuleArgumentSpecValidator)

# Generated at 2022-06-22 21:26:08.815616
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    with pytest.raises(TypeError) as e:
        ArgumentSpecValidator()
    assert str(e.value) == '__init__() missing 1 required positional argument: \'argument_spec\''
    with pytest.raises(TypeError) as e:
        ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                              mutually_exclusive='bo')
    assert str(e.value) == "'mutually_exclusive' is an invalid keyword argument for this function"
    with pytest.raises(TypeError) as e:
        ArgumentSpecValidator(argument_spec={'name': {'type': 'str'}},
                              required_together='bo')
    assert str(e.value) == "'required_together' is an invalid keyword argument for this function"

# Generated at 2022-06-22 21:26:19.317760
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    invalid_spec = [
        # bad type
        ([], {}),
        # bad key type
        (["hello"], {}),
        # bad spec type
        ({42: "hi"}, {}),
        # bad spec value type
        ({"hello": 42}, {}),
        # bad spec value value
        ({"hello": {"bad_key": "hi"}}, {}),
        # type not in valid types
        ({"hello": {"type": "bogus"}}, {}),
        # type not in valid types list
        ({"hello": {"type": ["bogus"]}}, {}),
    ]

    for arg_spec, mutually_exclusive in invalid_spec:
        try:
            ArgumentSpecValidator(arg_spec, mutually_exclusive)
            assert False, "Shouldn't get here."
        except TypeError:
            pass


# Generated at 2022-06-22 21:26:21.780759
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'param': {
            'type': 'str',
            'default': 'foo'
        }
    }

    validator = ModuleArgumentSpecValidator(argument_spec)
    assert isinstance(validator, ArgumentSpecValidator)

# Generated at 2022-06-22 21:26:27.535057
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    assert issubclass(ModuleArgumentSpecValidator, ArgumentSpecValidator)
    module_argument_spec_validator = ModuleArgumentSpecValidator({}, [], [], [], [], {})
    assert isinstance(module_argument_spec_validator, ModuleArgumentSpecValidator)



# Generated at 2022-06-22 21:26:39.342199
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    unittest.main()

if __name__ == '__main__':
    import unittest

    class TestModuleArgumentSpecValidator(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_test_ModuleArgumentSpecValidator_validate(self):
            self.assertEqual(test_ModuleArgumentSpecValidator_validate(), None)

    def test_method_validate_of_class_ModuleArgumentSpecValidator(self):
        test_method_validate_of_class_ModuleArgumentSpecValidator_instance = TestModuleArgumentSpecValidator()
        test_method_validate_of_class_ModuleArgumentSpecValidator_instance.setUp()
        test_method_validate_of_class_ModuleArg

# Generated at 2022-06-22 21:26:45.324199
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ma = ModuleArgumentSpecValidator(argument_spec={'whitelist': {'type': 'list', 'default': [], 'elements': 'str'},
                                                   'blacklist': {'type': 'list', 'default': [], 'elements': 'str'}})
    assert ma.validate(parameters={'whitelist': []}) == ma.validate(parameters={'blacklist': []})

# Generated at 2022-06-22 21:26:50.385152
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({'a': 42, 'b': 'bo'})
    assert result._validated_parameters == {'a': 42, 'b': 'bo'}
    assert result._no_log_values == set()
    assert result._unsupported_parameters == set()
    assert result._deprecations == []
    assert result._warnings == []
    assert result.errors == AnsibleValidationErrorMultiple()


# Generated at 2022-06-22 21:26:59.799569
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    """ Unit test for constructor of class ValidationResult.
    """
    validation_result = ValidationResult({'test': 'value'})
    assert validation_result._no_log_values == set()
    assert validation_result._validated_parameters == {'test': 'value'}
    assert validation_result._deprecations == []
    assert validation_result.errors == AnsibleValidationErrorMultiple()
    assert validation_result.error_messages == []
    assert validation_result.unsupported_parameters == set()
    assert validation_result.validated_parameters == {'test': 'value'}


# Generated at 2022-06-22 21:27:12.189697
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from textwrap import dedent
    case1_spec = {'param1': {'choices': ['red', 'green', 'blue']}}

    case1_parameters = {'param1': 'red'}
    case2_parameters = {'param1': 'green'}
    case3_parameters = {'param1': 'purple'}

    validator = ArgumentSpecValidator(case1_spec)
    result = validator.validate(case1_parameters)

    assert result.error_messages == []

    result = validator.validate(case2_parameters)
    assert result.error_messages == []

    result = validator.validate(case3_parameters)
    assert 'param1 is purple' in result.error_messages


# Generated at 2022-06-22 21:27:15.169553
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    ModuleArgumentSpecValidator('dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy')

# Generated at 2022-06-22 21:27:21.594283
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    specification = {'foo': {'type': 'str'}, 'bar': {'type': 'str'}}
    d = {'foo': 'test'}
    v = ModuleArgumentSpecValidator(specification, required_by={'bar': ['foo']})
    v.validate(d)
    assert d == {'foo': 'test'}

# Generated at 2022-06-22 21:27:31.926312
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    spec = {'name': {
                'aliases': ['first'],
                'deprecated': {
                    'version': '2.9',
                    'collection_name': 'community.general',
                    'removed_in': '4.0',
                    'why': 'y',
                    'alternative': 'z'
                }
            },
            'age': {
                'aliases': ['years'],
                'type': 'int',
            },
        }

    parameters = {'name': 'Ansible', 'age': '100'}

    validator = ModuleArgumentSpecValidator(spec)
    result = validator.validate(parameters)

    assert not result.errors

# Generated at 2022-06-22 21:27:41.358100
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    parameters = {
        'name': 'bo',
        'age': '42',
    }

    result = ValidationResult(parameters)

    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert result._validated_parameters == {'name': 'bo', 'age': '42'}
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert result.errors.messages == []
    assert result.validated_parameters == {'name': 'bo', 'age': '42'}
    assert not result.unsupported_parameters
    assert result.error_messages == []


# Generated at 2022-06-22 21:27:47.987621
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    # Note: This test is not a proper unit test with asserts, but if in the
    # future someone breaks the constructor of ModuleArgumentSpecValidator,
    # this test will also break.
    for i in range(100):
        ModuleArgumentSpecValidator(argument_spec={}, mutually_exclusive={}, required_together={},
                                    required_one_of={}, required_if={}, required_by={})

# Generated at 2022-06-22 21:27:49.126567
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    assert True


# Generated at 2022-06-22 21:27:58.766033
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    
    # Arrange
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import BytesIO

    stdin = BytesIO(to_text("{\"_ansible_verbosity\": 0, \"_ansible_syslog_facility\": \"LOG_USER\"}"))

    # Act
    test_result = ModuleArgumentSpecValidator._validate(stdin, "{}")

    # Assert
    assert test_result.errors == []
    assert len(test_result._validated_parameters) == 2
    assert test_result._validated_parameters["_ansible_verbosity"] == 0
    assert test_result._validated_parameters["_ansible_syslog_facility"] == "LOG_USER"

# Generated at 2022-06-22 21:27:59.443896
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    pass


# Generated at 2022-06-22 21:28:12.431365
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():

    mutually_exclusive = [['a', 'b'], ['a', 'c']]
    argument_spec = {
        'a': {'type': 'str', 'aliases': ['a1']},
        'b': {'type': 'str', 'aliases': ['b1']},
        'c': {'type': 'str', 'aliases': ['c1']},
    }

    parameters = {'a': 'a', 'b': 'b'}
    result = ModuleArgumentSpecValidator(argument_spec, mutually_exclusive=mutually_exclusive).validate(parameters)
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert len(result.errors) == 1
    assert isinstance(result.errors[0], MutuallyExclusiveError)

# Generated at 2022-06-22 21:28:24.067964
# Unit test for constructor of class ArgumentSpecValidator
def test_ArgumentSpecValidator():
    argument_spec = {
        'test': {
            'type': 'str',
        },
    }

    validator = ArgumentSpecValidator(argument_spec)

    # Validate test string
    assert validator.validate({'test': 'a'}).validated_parameters == {'test': 'a'}

    assert validator.validate({'test': 'a'}).errors == []

    # Test string validation that fails
    result = validator.validate({'test': 'a'})
    result.errors.append(Exception('Exception'))

    assert result.errors[0].message == 'Exception'

    # Missing parameter
    assert validator.validate({}).error_messages == ['The following required arguments are missing: test']

    # Mutually exclusive parameters

# Generated at 2022-06-22 21:28:26.531486
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Tests method validate of class ModuleArgumentSpecValidator"""
    pass

# Generated at 2022-06-22 21:28:30.409273
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    # test no param
    result = ValidationResult({})
    assert result.validated_parameters == {}
    assert result.unsupported_parameters == set()
    assert result.error_messages == []


# Generated at 2022-06-22 21:28:41.907739
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    module_argument_spec = dict(
        command=dict(type='str', no_log=False),
        args=dict(type='dict'),
        check=dict(type='bool', default=False)
    )
    parameters = dict(arg1=dict(command='ls'), arg2=dict(args=dict(cwd='pwd')))
    mutually_exclusive = [['arg1', 'arg2'], ['arg2', 'arg3']]
    required_together = [['arg1', 'arg2', 'arg3'], ['arg4', 'arg5']]
    required_if = [
        ['arg1', 'y', ['arg3', 'arg4']],
        ['arg2', 'x', ['arg5']]
    ]

# Generated at 2022-06-22 21:28:54.521602
# Unit test for method validate of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator_validate():
    """Test for method validate of class ModuleArgumentSpecValidator."""
    # Case 1
    validator = ModuleArgumentSpecValidator({'param1': {'type': 'int'}})
    params = {'param1': 1}
    result = validator.validate(params)
    expected = ValidationResult(parameters=params)
    assert result.validated_parameters == expected.validated_parameters
    assert result.errors == expected.errors
    assert result.error_messages == expected.error_messages
    assert result.unsupported_parameters == expected.unsupported_parameters

    # Case 2
    validator = ModuleArgumentSpecValidator({'param1': {'type': 'int'}})
    params = {'param1': 'a'}
    result = validator.validate(params)

# Generated at 2022-06-22 21:28:59.081864
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    import pytest
    validator = ModuleArgumentSpecValidator({}, [], [], [], [], {})
    assert isinstance(validator, ModuleArgumentSpecValidator)


# unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:29:10.079905
# Unit test for method validate of class ModuleArgumentSpecValidator

# Generated at 2022-06-22 21:29:20.853528
# Unit test for constructor of class ArgumentSpecValidator

# Generated at 2022-06-22 21:29:33.614144
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    from ansible.module_utils.common.parameters import sanitize_keys
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.parameters import add_fallback_to_argument_spec

    argument_spec = dict(
        bool_val=dict(type='bool', default=True, no_log=True),
        int_val=dict(type='int'),
        list_val=dict(type='list'),
        num_val=dict(type='num'),
        str_val=dict(type='str', required=True),
        dict_val=dict(type='dict', required=True),
    )
    add_fallback_to_argument_spec(argument_spec, fallback=(dict(), ['str_val', 'dict_val']))


# Generated at 2022-06-22 21:29:40.689065
# Unit test for constructor of class ValidationResult
def test_ValidationResult():
    result = ValidationResult({})
    assert isinstance(result, ValidationResult)
    assert isinstance(result.errors, AnsibleValidationErrorMultiple)
    assert isinstance(result._no_log_values, set)
    assert isinstance(result._unsupported_parameters, set)
    assert isinstance(result._validated_parameters, dict)
    assert isinstance(result._deprecations, list)
    assert isinstance(result._warnings, list)



# Generated at 2022-06-22 21:29:48.827282
# Unit test for method validate of class ArgumentSpecValidator
def test_ArgumentSpecValidator_validate():
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
    }

    validator = ArgumentSpecValidator(argument_spec)
    parameters = {
        'name': 'bo',
        'age': '42',
    }
    result = validator.validate(parameters)

    assert result.validated_parameters == {'name': 'bo', 'age': 42}
    assert result.error_messages == []

# Generated at 2022-06-22 21:29:58.281650
# Unit test for constructor of class ModuleArgumentSpecValidator
def test_ModuleArgumentSpecValidator():
    argument_spec = {
        'verbose': {'type': 'bool'},
        'msg': {'type': 'str'},
        'msg_debug': {'type': 'str', 'default': 'debug'},
    }
    mutually_exclusive = [
        ['verbose', 'msg_debug'],
        ['msg', 'msg_debug']
    ]
    required_one_of = [
        ['verbose', 'msg', 'msg_debug'],
    ]
    required_together = [
        ['msg', 'msg_debug'],
    ]
    required_if = [
        ['verbose', 'yes', ['msg', 'msg_debug']],
    ]
    required_by = {
        'msg': ['verbose'],
    }
