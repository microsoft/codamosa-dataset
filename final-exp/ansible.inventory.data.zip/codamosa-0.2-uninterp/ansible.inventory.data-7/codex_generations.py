

# Generated at 2022-06-16 21:33:13.215739
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:33:26.405060
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')
    inventory.add_child('group3', 'host3')

# Generated at 2022-06-16 21:33:35.406927
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    assert 'test_host' in inventory_data.hosts
    assert 'test_group' in inventory_data.groups
    assert 'test_host' in inventory_data.groups['test_group'].hosts
    inventory_data.remove_host(inventory_data.hosts['test_host'])
    assert 'test_host' not in inventory_data.hosts
    assert 'test_group' in inventory_data.groups
    assert 'test_host' not in inventory_data.groups['test_group'].hosts

# Generated at 2022-06-16 21:33:42.202102
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:33:50.350927
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'localhost')
    inventory.add_child('group1', '127.0.0.1')
    inventory.add_child('group2', '127.0.0.2')
    assert len(inventory.hosts) == 3
    assert len(inventory.groups) == 3
    assert len(inventory.groups['group1'].hosts) == 2
    assert len(inventory.groups['group2'].hosts) == 1
    inventory.remove_host(inventory.hosts['localhost'])

# Generated at 2022-06-16 21:34:01.525443
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    assert inv.hosts['localhost'].vars == {}
    assert inv.hosts['localhost'].groups == [inv.groups['all'], inv.groups['ungrouped']]

    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22

    inv.add_host('localhost', port=2222)
    assert inv.hosts['localhost'].port == 2222

    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None

    inv.add_host('localhost', port='')

# Generated at 2022-06-16 21:34:10.369783
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.groups['group1'].get_groups() == [inventory.groups['group2']]
    assert inventory.groups['group2'].get_hosts() == []
    assert inventory.groups['group2'].get_groups() == []

# Generated at 2022-06-16 21:34:18.367978
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert len(inventory.groups['group1'].get_hosts()) == 2
    inventory.remove_host(inventory.hosts['host1'])
    assert len(inventory.groups['group1'].get_hosts()) == 1

# Generated at 2022-06-16 21:34:31.292437
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'localhost')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')

    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1']]

# Generated at 2022-06-16 21:34:36.770214
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.reconcile_inventory()
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory_data.hosts['test_host'].get_groups()[0].name == 'test_group'

# Generated at 2022-06-16 21:34:46.806074
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:34:57.599442
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    """
    Test method reconcile_inventory of class InventoryData
    """
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.reconcile_inventory()

    assert inventory.groups['group1'].name == 'group1'
    assert inventory.groups['group2'].name == 'group2'
    assert inventory.hosts['host1'].name == 'host1'
    assert inventory.hosts['host2'].name == 'host2'
    assert inventory.groups

# Generated at 2022-06-16 21:35:10.547123
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:15.320914
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups
    assert 'test_group' in inventory_data.groups['all'].child_groups
    assert 'test_group' in inventory_data.groups['ungrouped'].child_groups


# Generated at 2022-06-16 21:35:22.879759
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group1', 'host3')
    inventory.add_child('group1', 'host4')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_group('group2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')

# Generated at 2022-06-16 21:35:26.396021
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert 'localhost' in inventory.hosts
    assert 'all' in inventory.groups
    assert 'ungrouped' in inventory.groups
    assert 'localhost' in inventory.groups['all'].get_hosts()
    assert 'localhost' in inventory.groups['ungrouped'].get_hosts()
    assert 'all' in inventory.hosts['localhost'].get_groups()
    assert 'ungrouped' in inventory.hosts['localhost'].get_groups()


# Generated at 2022-06-16 21:35:35.300144
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory_data.hosts['test_host'].get_groups()[0].name == 'test_group'


# Generated at 2022-06-16 21:35:45.757886
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:58.122273
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:04.929533
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Create an InventoryData object
    inventory_data = InventoryData()

    # Add a group to inventory
    group_name = 'test_group'
    inventory_data.add_group(group_name)

    # Add a host to inventory
    host_name = 'test_host'
    inventory_data.add_host(host_name)

    # Add a child to group
    inventory_data.add_child(group_name, host_name)

    # Reconcile inventory
    inventory_data.reconcile_inventory()

    # Check if the group is in inventory
    assert group_name in inventory_data.groups

    # Check if the host is in inventory
    assert host_name in inventory_data.hosts

    # Check if the host is in the group

# Generated at 2022-06-16 21:36:22.418876
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:36:29.598127
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]

# Generated at 2022-06-16 21:36:34.689557
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:45.536883
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group')
    inventory.add_host('test_host3', 'test_group')
    inventory.add_host('test_host4', 'test_group')
    inventory.add_host('test_host5', 'test_group')
    inventory.add_host('test_host6', 'test_group')
    inventory.add_host('test_host7', 'test_group')
    inventory.add_host('test_host8', 'test_group')
    inventory.add_host('test_host9', 'test_group')
    inventory.add_host('test_host10', 'test_group')
   

# Generated at 2022-06-16 21:36:56.414811
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:00.102240
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert inventory.hosts['test_host_2'].port == 22


# Generated at 2022-06-16 21:37:11.682483
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_child('all', 'group1')
    inventory.add_child('all', 'group2')
    inventory.add_child('all', 'group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')

# Generated at 2022-06-16 21:37:24.793139
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:34.412026
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:37:40.201021
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:37:57.139144
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:38:07.442285
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:38:11.293224
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test')
    assert 'test' in inventory_data.groups


# Generated at 2022-06-16 21:38:16.286407
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)

# Generated at 2022-06-16 21:38:21.582744
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_host' not in inventory.groups['test_group'].hosts


# Generated at 2022-06-16 21:38:33.389726
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    assert inventory_data.get_host('localhost') is None
    assert inventory_data.get_host('127.0.0.1') is None
    assert inventory_data.get_host('127.0.0.2') is None
    assert inventory_data.get_host('127.0.0.3') is None
    assert inventory_data.get_host('127.0.0.4') is None
    assert inventory_data.get_host('127.0.0.5') is None
    assert inventory_data.get_host('127.0.0.6') is None
    assert inventory_data.get_host('127.0.0.7') is None
    assert inventory_data.get_host('127.0.0.8') is None
    assert inventory_data.get

# Generated at 2022-06-16 21:38:42.148761
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('otherhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.add_child('group1', 'otherhost')

    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert len(inventory.hosts) == 2

    inventory.remove_host(inventory.hosts['localhost'])

    assert len(inventory.groups['group1'].get_hosts()) == 1
    assert len(inventory.hosts) == 1

# Generated at 2022-06-16 21:38:48.603434
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    assert inv.hosts['localhost'].vars == {}
    assert inv.hosts['localhost'].groups == []
    assert inv.hosts['localhost'].implicit is False
    assert inv.hosts['localhost'].address == '127.0.0.1'
    assert inv.hosts['localhost'].get_groups() == [inv.groups['all'], inv.groups['ungrouped']]
    assert inv.groups['all'].get_hosts() == [inv.hosts['localhost']]
    assert inv.groups['ungrouped'].get_hosts() == [inv.hosts['localhost']]
   

# Generated at 2022-06-16 21:39:00.742109
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:39:11.913598
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:39:24.825926
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:39:35.173252
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]

# Generated at 2022-06-16 21:39:38.823371
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:39:42.095969
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert inventory_data.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:39:53.859104
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:40:07.327373
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inv = InventoryData()
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_group('group3')
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_host('host3')
    inv.add_host('host4')
    inv.add_host('host5')
    inv.add_host('host6')
    inv.add_host('host7')
    inv.add_host('host8')
    inv.add_host('host9')
    inv.add_host('host10')
    inv.add_child('group1', 'host1')
    inv.add_child('group1', 'host2')
    inv.add_child('group1', 'host3')
    inv.add

# Generated at 2022-06-16 21:40:10.771353
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:40:23.176442
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:40:26.291520
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:40:38.291688
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.hosts.get('host1') is None
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host2']]

# Generated at 2022-06-16 21:40:53.339542
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:41:01.451292
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.hosts['test_host'].get_groups()[0].name == 'test_group'
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:41:06.797521
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:41:15.304935
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1", "group1")
    inventory.add_host("host2", "group1")
    inventory.add_host("host3", "group2")
    inventory.add_host("host4", "group2")
    inventory.add_host("host5", "group3")
    inventory.add_host("host6", "group3")
    inventory.add_host("host7", "group4")
    inventory.add_host("host8", "group4")
    inventory.add_host("host9", "group5")
    inventory.add_host("host10", "group5")
    inventory.add_host("host11", "group6")
    inventory.add_host("host12", "group6")

# Generated at 2022-06-16 21:41:23.069473
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:41:30.275362
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11', 'group1')
    inventory.add_

# Generated at 2022-06-16 21:41:41.477141
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("host1", "group1")
    inventory.add_host("host2", "group1")
    inventory.add_host("host3", "group2")
    inventory.add_host("host4", "group2")
    inventory.add_host("host5", "group3")
    inventory.add_host("host6", "group3")
    inventory.add_host("host7", "group4")
    inventory.add_host("host8", "group4")
    inventory.add_host("host9", "group5")
    inventory.add_host("host10", "group5")
    inventory.add_host("host11", "group6")
    inventory.add_host("host12", "group6")

# Generated at 2022-06-16 21:41:49.807290
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()

    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')

    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')

    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group1', 'host3')
    inventory.add_child('group1', 'host4')
    inventory.add_child('group1', 'host5')


# Generated at 2022-06-16 21:42:00.356766
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')

# Generated at 2022-06-16 21:42:13.031853
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_host("host4")
    inventory.add_host("host5")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_group("group3")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host3")
    inventory.add_child("group2", "host4")
    inventory.add_child("group3", "host5")
    inventory.add_child("group3", "group1")
    inventory.add_child("group3", "group2")

# Generated at 2022-06-16 21:42:38.166571
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)


# Generated at 2022-06-16 21:42:40.913186
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert inventory_data.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:42:49.968139
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:42:59.567562
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory