

# Generated at 2022-06-16 21:33:25.511536
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]

# Generated at 2022-06-16 21:33:35.377609
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_group('group2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_group('group3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')
    inventory.add_group('group4')
    inventory.add_child('group4', 'host1')

# Generated at 2022-06-16 21:33:47.035144
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('localhost', 'group3')
    inventory.add_host('localhost', 'group4')
    inventory.add_host('localhost', 'group5')
    inventory.add_host('localhost', 'group6')
    inventory.add_host('localhost', 'group7')
    inventory.add_host('localhost', 'group8')
    inventory.add_host('localhost', 'group9')
    inventory.add_host('localhost', 'group10')
    inventory.add_host('localhost', 'group11')
    inventory.add_host('localhost', 'group12')
    inventory.add_host('localhost', 'group13')


# Generated at 2022-06-16 21:33:58.718601
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')

    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]

# Generated at 2022-06-16 21:34:05.692672
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.hosts['host1'] is None
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host2']]

# Generated at 2022-06-16 21:34:10.676890
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22


# Generated at 2022-06-16 21:34:24.149872
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host("localhost")
    assert inv.hosts["localhost"].name == "localhost"
    assert inv.hosts["localhost"].vars == {}
    assert inv.hosts["localhost"].groups == []
    assert inv.hosts["localhost"].port is None
    assert inv.hosts["localhost"].implicit is False
    assert inv.hosts["localhost"].address == "127.0.0.1"
    assert inv.hosts["localhost"].variables == {}
    assert inv.hosts["localhost"].has_key("inventory_file")
    assert inv.hosts["localhost"].has_key("inventory_dir")
    assert inv.hosts["localhost"].has_key("ansible_python_interpreter")

# Generated at 2022-06-16 21:34:28.999829
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.remove_host(inventory.get_host("host2"))
    assert inventory.get_host("host2") is None
    assert inventory.groups["group1"].get_hosts() == [inventory.get_host("host1")]

# Generated at 2022-06-16 21:34:37.532605
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'test_group')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['test_group'].get_hosts()[0].port is None
    assert inventory.groups['test_group'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['test_group'].get_hosts()[0].port is None
    assert inventory.groups['test_group'].get_hosts()[0].name == 'localhost'

# Generated at 2022-06-16 21:34:47.877668
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].hosts
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].hosts

# Generated at 2022-06-16 21:35:00.681444
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Test case 1:
    # Test case for the following scenario:
    # 1. Create a new InventoryData object.
    # 2. Add a new group to the inventory.
    # 3. Add a new host to the inventory.
    # 4. Add the host to the group.
    # 5. Call the reconcile_inventory method.
    # 6. Verify that the group is added to the host.
    inventory_data = InventoryData()
    group_name = "test_group"
    host_name = "test_host"
    inventory_data.add_group(group_name)
    inventory_data.add_host(host_name)
    inventory_data.add_child(group_name, host_name)
    inventory_data.reconcile_inventory()
    assert inventory_data.hosts[host_name].get_

# Generated at 2022-06-16 21:35:03.776877
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert "test_group" in inventory.groups


# Generated at 2022-06-16 21:35:15.644604
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:35:23.081665
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert 'test_host' in inventory_data.hosts
    assert 'test_host' in inventory_data.groups['all'].get_hosts()
    assert 'test_host' in inventory_data.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory_data.get_groups_dict()['all']
    assert 'test_host' in inventory_data.get_groups_dict()['ungrouped']
    assert inventory_data.get_host('test_host') == inventory_data.hosts['test_host']
    assert inventory_data.get_host('test_host') == inventory_data.localhost

# Generated at 2022-06-16 21:35:35.489856
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group1')

# Generated at 2022-06-16 21:35:46.663147
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    assert inventory_data.get_host('localhost') is None
    assert inventory_data.get_host('127.0.0.1') is None
    assert inventory_data.get_host('127.0.0.2') is None
    assert inventory_data.get_host('127.0.0.3') is None

    inventory_data.add_host('127.0.0.1')
    assert inventory_data.get_host('localhost') is None
    assert inventory_data.get_host('127.0.0.1') is not None
    assert inventory_data.get_host('127.0.0.2') is None
    assert inventory_data.get_host('127.0.0.3') is None


# Generated at 2022-06-16 21:35:58.967450
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].get_groups() == []
    assert inventory.hosts['localhost'].get_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars() == {}
    assert inventory.hosts['localhost'].get_group_variables() == {}
    assert inventory.hosts['localhost'].get_variables() == {}
   

# Generated at 2022-06-16 21:36:05.520310
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:17.737131
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:21.935709
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv_data = InventoryData()
    inv_data.add_group("test_group")
    assert inv_data.groups["test_group"].name == "test_group"


# Generated at 2022-06-16 21:36:27.839628
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group_name = 'test_group'
    inventory.add_group(group_name)
    assert group_name in inventory.groups


# Generated at 2022-06-16 21:36:40.808129
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group3', 'host3')
    inventory_data.reconcile_inventory()

# Generated at 2022-06-16 21:36:50.152568
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.remove_host(inventory_data.hosts['host2'])
    assert 'host2' not in inventory_data.hosts
    assert 'host2' not in inventory_data.groups['group1'].hosts


# Generated at 2022-06-16 21:36:58.207206
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].hosts
    assert 'host2' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:37:04.152603
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.remove_host(inventory_data.hosts['host2'])
    assert 'host2' not in inventory_data.groups['group1'].get_hosts()

# Generated at 2022-06-16 21:37:11.723766
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.reconcile_inventory()
    assert inventory_data.groups['test_group'].get_hosts() == [inventory_data.hosts['test_host']]
    assert inventory_data.hosts['test_host'].get_groups() == [inventory_data.groups['test_group']]


# Generated at 2022-06-16 21:37:16.209649
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'test_group'
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:37:27.718389
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    inventory.add_host('localhost', 'all', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port == 22

# Generated at 2022-06-16 21:37:33.450060
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    assert 'group1' in inventory.groups
    assert len(inventory.groups) == 3
    assert len(inventory.hosts) == 0
    assert len(inventory.processed_sources) == 0
    assert inventory.current_source is None
    assert inventory.localhost is None
    assert len(inventory._groups_dict_cache) == 0


# Generated at 2022-06-16 21:37:45.827140
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory.add_host('localhost', 'test_group')
    inventory

# Generated at 2022-06-16 21:37:59.716532
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Create inventory data object
    inventory_data = InventoryData()

    # Create groups
    group_all = Group('all')
    group_ungrouped = Group('ungrouped')
    group_test = Group('test')

    # Create hosts
    host_localhost = Host('localhost')
    host_localhost.address = '127.0.0.1'
    host_localhost.implicit = True
    host_localhost.set_variable('ansible_python_interpreter', '/usr/bin/python')
    host_localhost.set_variable('ansible_connection', 'local')
    host_test = Host('test')

    # Add groups to inventory data
    inventory_data.groups['all'] = group_all
    inventory_data.groups['ungrouped'] = group_ungrouped

# Generated at 2022-06-16 21:38:10.039031
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2'], inventory.groups['all']]
    assert inventory

# Generated at 2022-06-16 21:38:21.104129
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('all')
    inventory_data.add_group('ungrouped')
    inventory_data.add_host('localhost', 'all')
    inventory_data.add_host('localhost', 'ungrouped')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')
    inventory_data.add_host('localhost', 'test')

# Generated at 2022-06-16 21:38:33.163832
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars['inventory_file'] == None
    assert inventory.hosts['localhost'].vars['inventory_dir'] == None
    inventory.current_source = 'test_source'
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].vars['inventory_file'] == 'test_source'
    assert inventory.hosts['localhost'].vars['inventory_dir'] == basedir('test_source')
    inventory.add_host('localhost', 'test_group')
    assert inventory.groups['test_group'].hosts['localhost'].name == 'localhost'

# Generated at 2022-06-16 21:38:43.978165
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['ungrouped']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['group1'], inventory.groups['ungrouped']]

# Generated at 2022-06-16 21:38:55.731122
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('test')
    inventory.add_host('localhost')
    inventory.add_host('testhost')
    inventory.add_child('test', 'testhost')
    inventory.add_child('all', 'test')
    inventory.add_child('all', 'testhost')
    inventory.add_child('all', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['testhost'].get_groups() == [inventory.groups['test'], inventory.groups['all']]
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all']]

# Generated at 2022-06-16 21:38:57.084286
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:39:06.986362
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group3')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group4')
    inventory.add_host('host10', 'group4')
    inventory.add_host('host11', 'group5')
    inventory.add_host('host12', 'group5')

# Generated at 2022-06-16 21:39:17.613731
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].hosts
    assert 'host2' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:39:26.577282
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.remove_host(inventory.hosts["host2"])
    assert inventory.hosts.get("host2") is None
    assert inventory.groups["group1"].get_hosts() == [inventory.hosts["host1"]]

# Generated at 2022-06-16 21:39:38.872993
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    assert inventory.groups['group1'].name == 'group1'
    inventory.add_group('group2')
    assert inventory.groups['group2'].name == 'group2'
    assert inventory.groups['group1'].name == 'group1'


# Generated at 2022-06-16 21:39:47.938521
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group3')
    inventory.add_host('host4', 'group4')
    inventory.add_host('host5', 'group5')
    inventory.add_host('host6', 'group6')
    inventory.add_host('host7', 'group7')
    inventory.add_host('host8', 'group8')
    inventory.add_host('host9', 'group9')
    inventory.add_host('host10', 'group10')
    inventory.add_host('host11', 'group11')
    inventory.add_host('host12', 'group12')

# Generated at 2022-06-16 21:39:54.496466
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups
    assert inventory.groups['test'].name == 'test'
    assert inventory.groups['test'].depth == 1
    assert inventory.groups['test'].parent is None
    assert inventory.groups['test'].children == []
    assert inventory.groups['test'].hosts == []
    assert inventory.groups['test'].vars == {}


# Generated at 2022-06-16 21:40:08.160540
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'all')


# Generated at 2022-06-16 21:40:20.138061
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:40:29.557048
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost')
    inventory.add_host('otherhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('otherhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('otherhost', 'ungrouped')
    inventory.add_child('all', 'ungrouped')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]

# Generated at 2022-06-16 21:40:31.809549
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups
    assert 'test' in inventory.get_groups_dict()
    assert len(inventory.get_groups_dict()['test']) == 0


# Generated at 2022-06-16 21:40:44.083433
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].get_groups() == []
    assert inventory.hosts['localhost'].get_vars() == {}
    assert inventory.hosts['localhost'].get_variables() == {}
    assert inventory.hosts['localhost'].get_group_vars() == {}
    assert inventory.hosts['localhost'].get_group_variables() == {}
    assert inventory.hosts['localhost'].get_host_vars() == {}

# Generated at 2022-06-16 21:40:53.006949
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].groups[0].name == 'all'
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].get_groups()[0].name == 'all'
    assert inventory.hosts['localhost'].get_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars(['all']) == {}
    assert inventory.hosts['localhost'].get_group_vars(['all'], True) == {}
    assert inventory

# Generated at 2022-06-16 21:40:54.665350
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert inventory.groups['test']


# Generated at 2022-06-16 21:41:02.102884
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert inventory.groups["test_group"].name == "test_group"


# Generated at 2022-06-16 21:41:12.475393
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host1")
    inventory_data.add_host("test_host2")
    inventory_data.add_host("test_host3")
    inventory_data.add_host("test_host4")
    inventory_data.add_host("test_host5")
    inventory_data.add_host("test_host6")
    inventory_data.add_host("test_host7")
    inventory_data.add_host("test_host8")
    inventory_data.add_host("test_host9")
    inventory_data.add_host("test_host10")
    inventory_data.add_host("test_host11")
    inventory_data.add_host("test_host12")

# Generated at 2022-06-16 21:41:16.841888
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups
    assert 'test' in inventory._groups_dict_cache
    assert inventory._groups_dict_cache['test'] == []


# Generated at 2022-06-16 21:41:25.441515
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    assert inventory_data.add_group('test_group') == 'test_group'
    assert inventory_data.add_group('test_group') == 'test_group'
    assert inventory_data.add_group('test_group2') == 'test_group2'
    assert inventory_data.add_group('') == ''
    assert inventory_data.add_group(None) == None
    assert inventory_data.add_group(False) == False
    assert inventory_data.add_group(True) == True
    assert inventory_data.add_group(0) == 0
    assert inventory_data.add_group(1) == 1
    assert inventory_data.add_group(1.0) == 1.0
    assert inventory_data.add_group(['test_group'])

# Generated at 2022-06-16 21:41:32.751313
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]
    assert inventory.groups['group2'].get_hosts() == [inventory.hosts['host2']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_host

# Generated at 2022-06-16 21:41:43.246321
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]

# Generated at 2022-06-16 21:41:45.262757
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:41:52.222850
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:42:01.845283
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:42:05.118989
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:42:17.002581
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:42:20.752698
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:42:29.458887
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host2', port=22)
    assert inventory.hosts['test_host2'].name == 'test_host2'
    assert inventory.hosts['test_host2'].port == 22
    assert inventory.hosts['test_host2'].vars == {}
    inventory.add_host('test_host3', port=22)
    assert inventory.hosts['test_host3'].name == 'test_host3'
    assert inventory.hosts['test_host3'].port == 22
    assert inventory.hosts['test_host3'].v

# Generated at 2022-06-16 21:42:40.752307
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]

    inventory = InventoryData()
    inventory

# Generated at 2022-06-16 21:42:52.021718
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]

# Generated at 2022-06-16 21:42:54.472891
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups
