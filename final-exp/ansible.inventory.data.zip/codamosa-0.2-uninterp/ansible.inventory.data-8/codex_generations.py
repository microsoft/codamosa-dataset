

# Generated at 2022-06-16 21:33:23.583140
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host

# Generated at 2022-06-16 21:33:30.209171
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:33:37.941855
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group3')
    inventory.add_host('host4', 'group4')
    inventory.add_host('host5', 'group5')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'group3')

# Generated at 2022-06-16 21:33:48.206066
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.remove_host(inventory_data.hosts['host1'])
    assert inventory_data.hosts['host1'] is None
    assert inventory_data.hosts['host2'] is not None

# Generated at 2022-06-16 21:33:56.899500
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:34:07.488376
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert inventory.get_host('test_host').get_groups()[0].name == 'test_group'
    assert inventory.get_host('test_host').get_groups()[1].name == 'all'
    assert inventory.get_host('test_host').get_groups()[2].name == 'ungrouped'
    assert inventory.get_host('test_host').get_groups()[3].name == 'test_host'
    assert inventory.get_host('test_host').get_groups()[4].name == 'localhost'

# Generated at 2022-06-16 21:34:15.327123
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.0.5")
    inventory.add_host("127.0.0.6")
    inventory.add_host("127.0.0.7")
    inventory.add_host("127.0.0.8")
    inventory.add_host("127.0.0.9")
    inventory.add_host("127.0.0.10")
    inventory.add_host("127.0.0.11")
    inventory.add_host

# Generated at 2022-06-16 21:34:29.466353
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['all'], inventory.groups['group1']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['group2']]
    assert inventory

# Generated at 2022-06-16 21:34:37.743869
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]

# Generated at 2022-06-16 21:34:44.943981
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host1'], inventory_data.hosts['host2']]
    inventory_data.remove_host(inventory_data.hosts['host1'])
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host2']]

# Generated at 2022-06-16 21:35:00.705525
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:13.572342
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    assert inventory.get_host("test_host") is not None
    assert inventory.get_host("test_host").name == "test_host"
    assert inventory.get_host("test_host").address == "test_host"
    assert inventory.get_host("test_host").port is None
    assert inventory.get_host("test_host").vars == {}
    assert inventory.get_host("test_host").groups == []
    assert inventory.get_host("test_host").implicit is False
    assert inventory.get_host("test_host").has_children() is False
    assert inventory.get_host("test_host").has_parents() is False
    assert inventory.get_host("test_host").get_children() == []
   

# Generated at 2022-06-16 21:35:25.893306
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].hosts
    assert 'host2' not in inventory.groups['group2'].hosts


# Generated at 2022-06-16 21:35:37.692963
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:35:49.050509
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].name == 'all'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].get_groups()[0].name == 'all'
    assert inventory.hosts['localhost'].get_groups()[0].name == 'all'
    assert inventory.hosts['localhost'].get_groups()[0].get_hosts()[0].name == 'localhost'
    assert inventory.hosts['localhost'].get_groups()[0].get_hosts()[0].get_groups()[0].name == 'all'
    assert inventory

# Generated at 2022-06-16 21:35:58.968101
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('localhost')
    assert inventory.get_host('127.0.0.2') == inventory.get_host('127.0.0.2')


# Generated at 2022-06-16 21:36:08.641298
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('localhost')


# Generated at 2022-06-16 21:36:21.488642
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:24.357113
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group_name = 'test_group'
    inventory.add_group(group_name)
    assert group_name in inventory.groups


# Generated at 2022-06-16 21:36:37.759936
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.3')
    assert inventory.get_host('127.0.0.3') is None
    assert inventory.get_host('127.0.0.1').name == '127.0.0.1'

# Generated at 2022-06-16 21:36:44.664620
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'


# Generated at 2022-06-16 21:36:53.013508
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')

# Generated at 2022-06-16 21:37:05.099024
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:37:14.323167
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.reconcile_

# Generated at 2022-06-16 21:37:26.727637
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group2', 'host1')
    inventory_data.add_child('group2', 'host2')
    assert len(inventory_data.groups['group1'].get_hosts()) == 1
    assert len(inventory_data.groups['group2'].get_hosts()) == 2
    inventory_data.remove_host(inventory_data.hosts['host1'])
    assert len(inventory_data.groups['group1'].get_hosts()) == 0


# Generated at 2022-06-16 21:37:35.954945
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts
    assert 'host2' in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:37:49.483593
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    group1 = Group('group1')
    group2 = Group('group2')
    inventory.hosts['host1'] = host1
    inventory.hosts['host2'] = host2
    inventory.groups['group1'] = group1
    inventory.groups['group2'] = group2
    group1.add_host(host1)
    group2.add_host(host2)
    inventory.remove_host(host1)
    assert host1.name not in inventory.hosts
    assert host1 not in group1.get_hosts()
    assert host2.name in inventory.hosts
    assert host2 in group2.get_hosts()
    assert group1.name in inventory.groups

# Generated at 2022-06-16 21:37:58.858869
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['group2']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['group2'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    inventory.add_host('localhost', 'group1')

# Generated at 2022-06-16 21:38:04.628730
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:38:17.413930
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('all')
    inventory.add_group('test')
    inventory.add_child('all', 'test')
    inventory.add_child('test', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['test']]
    assert inventory.groups['test'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['test']]
    assert inventory.groups['test'].get_children() == []
    assert inventory.groups

# Generated at 2022-06-16 21:38:26.407375
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'test_group'
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:38:35.223724
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')

# Generated at 2022-06-16 21:38:44.802655
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:38:48.574566
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    inventory_data.add_host('test_host', 'test_group')
    inventory_data.reconcile_inventory()
    assert 'test_group' in inventory_data.groups
    assert 'test_host' in inventory_data.hosts
    assert 'test_group' in inventory_data.get_groups_dict()
    assert 'test_host' in inventory_data.get_groups_dict()['test_group']

# Generated at 2022-06-16 21:39:00.695170
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:39:11.820109
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:39:21.686696
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['ungrouped']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['group1'], inventory.groups['ungrouped']]

# Generated at 2022-06-16 21:39:29.180145
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_children() == [inventory.groups['test_group']]
    assert inventory.groups

# Generated at 2022-06-16 21:39:37.243359
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:39:46.396955
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost', 'group1')
    inventory_data.add_host('localhost', 'group2')
    inventory_data.add_host('localhost', 'group3')
    inventory_data.add_host('localhost', 'group4')
    inventory_data.add_host('localhost', 'group5')
    inventory_data.add_host('localhost', 'group6')
    inventory_data.add_host('localhost', 'group7')
    inventory_data.add_host('localhost', 'group8')
    inventory_data.add_host('localhost', 'group9')
    inventory_data.add_host('localhost', 'group10')
    inventory_data.add_host('localhost', 'group11')
    inventory

# Generated at 2022-06-16 21:39:53.724321
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    assert inventory_data.hosts["test_host"].name == "test_host"


# Generated at 2022-06-16 21:40:00.571243
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'
    assert inventory.hosts['test_host'].get_groups()[1].name == 'all'
    assert inventory.hosts['test_host'].get_groups()[2].name == 'ungrouped'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'
    assert inventory

# Generated at 2022-06-16 21:40:10.252336
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('all')
    inventory_data.add_group('ungrouped')
    inventory_data.add_group('test_group')
    inventory_data.add_host('test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.add_child('test_group', 'test_host')
    inventory_

# Generated at 2022-06-16 21:40:22.587537
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:40:35.888994
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group2')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')

# Generated at 2022-06-16 21:40:48.325559
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group1')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].name == 'group1'
    assert inventory.groups['group2'].name == 'group2'
    assert inventory.hosts['host1'].name == 'host1'
    assert inventory.hosts['host2'].name == 'host2'

# Generated at 2022-06-16 21:41:00.389814
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')

# Generated at 2022-06-16 21:41:11.016390
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')


# Generated at 2022-06-16 21:41:22.787102
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:41:31.396996
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:41:44.334223
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test')
    assert inv.hosts['test'].name == 'test'
    assert inv.hosts['test'].port is None
    inv.add_host('test2', port=1234)
    assert inv.hosts['test2'].port == 1234


# Generated at 2022-06-16 21:41:51.706839
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group3', 'host5')

# Generated at 2022-06-16 21:42:01.505728
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')

# Generated at 2022-06-16 21:42:13.674335
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_group('group6')
    inventory.add_group('group7')
    inventory.add_group('group8')
    inventory.add_group('group9')
    inventory.add_group('group10')
    inventory.add_group('group11')
    inventory.add_group('group12')
    inventory.add_group('group13')
    inventory.add_group('group14')
    inventory.add_group('group15')
    inventory.add_group('group16')
    inventory.add_group('group17')
    inventory.add_

# Generated at 2022-06-16 21:42:24.976502
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.get_host('host1').get_groups() == [inventory.groups['all'], inventory.groups['group1']]

# Generated at 2022-06-16 21:42:38.217289
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].variables == {}
    assert inventory.hosts['localhost'].has_variable('inventory_file')
    assert inventory.hosts['localhost'].has_variable('inventory_dir')
    assert inventory.hosts['localhost'].get_variable('inventory_file') is None
    assert inventory.hosts['localhost'].get_variable('inventory_dir') is None

# Generated at 2022-06-16 21:42:45.984537
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'all' in inventory.hosts['test_host'].get_groups()
    assert 'ungrouped' in inventory.hosts['test_host'].get_groups()
    inventory.add_host('test_host2', 'test_group')
    assert 'test_host2' in inventory.hosts
    assert 'test_host2' in inventory.groups['test_group'].get_hosts()
    assert 'test_group' in inventory.hosts['test_host2'].get_groups()

# Generated at 2022-06-16 21:42:56.614860
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group3')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group4')
    inventory.add_host('host10', 'group4')
    inventory.add_host('host11', 'group4')
    inventory.add_host('host12', 'group5')
    inventory.add_host('host13', 'group5')
   