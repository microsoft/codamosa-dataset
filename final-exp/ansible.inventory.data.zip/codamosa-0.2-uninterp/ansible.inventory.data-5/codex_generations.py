

# Generated at 2022-06-16 21:33:27.327282
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'
    assert inventory.hosts['test_host'].get_groups()[0].name == inventory.groups['test_group'].name
    assert inventory.hosts['test_host'].get_groups()[0] == inventory.groups['test_group']


# Generated at 2022-06-16 21:33:36.426225
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:33:47.477451
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_host("host4")
    inventory.add_host("host5")
    inventory.add_host("host6")
    inventory.add_host("host7")
    inventory.add_host("host8")
    inventory.add_host("host9")
    inventory.add_host("host10")
    inventory.add_host("host11")
    inventory.add_host("host12")
    inventory.add_host("host13")
    inventory.add_host("host14")
    inventory.add_host("host15")
    inventory.add_host("host16")
    inventory.add_host("host17")
    inventory.add_

# Generated at 2022-06-16 21:33:58.758271
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('otherhost')
    inventory.add_group('testgroup')
    inventory.add_child('testgroup', 'localhost')
    inventory.add_child('testgroup', 'otherhost')

    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['testgroup']]
    assert inventory.hosts['otherhost'].get_groups() == [inventory.groups['all'], inventory.groups['testgroup']]
    assert inventory.groups['testgroup'].get_hosts() == [inventory.hosts['localhost'], inventory.hosts['otherhost']]

    inventory.remove_host(inventory.hosts['localhost'])

    assert inventory.hosts['otherhost'].get_groups()

# Generated at 2022-06-16 21:34:07.313371
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.hosts['test_host'].port is None
    inventory_data.add_host('test_host', port=1234)
    assert inventory_data.hosts['test_host'].port == 1234
    inventory_data.add_host('test_host', port=4321)
    assert inventory_data.hosts['test_host'].port == 4321
    inventory_data.add_host('test_host', port=None)
    assert inventory_data.hosts['test_host'].port is None


# Generated at 2022-06-16 21:34:15.172829
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('test_group')
    inventory.add_host('test_host')
    inventory.add_host('test_host2')
    inventory.add_child('test_group', 'test_host')
    inventory.add_child('test_group', 'test_host2')
    inventory.add_child('all', 'test_group')
    inventory.add_child('all', 'test_host')
    inventory.add_child('all', 'test_host2')
    inventory.add_child('ungrouped', 'test_host')
    inventory.add_child('ungrouped', 'test_host2')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:34:29.303762
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_group('group4')
    inventory_data.add_group('group5')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group1', 'host3')

# Generated at 2022-06-16 21:34:37.442993
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert inventory.hosts['host2'] not in inventory.groups['group1'].get_hosts()
    assert inventory.hosts['host2'] not in inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:34:50.280773
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    inv.add_host('localhost', port=2222)
    assert inv.hosts['localhost'].port == 2222
    inv.add_host('localhost', port=2222)
    assert inv.hosts['localhost'].port == 2222
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None

# Generated at 2022-06-16 21:34:56.756657
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    inventory.remove_host(inventory.hosts['test_host'])
    assert len(inventory.groups['test_group'].get_hosts()) == 0

# Generated at 2022-06-16 21:35:15.051034
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')

    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert len(inventory.groups['group2'].get_hosts()) == 2

    inventory.remove_host(inventory.hosts['host2'])

    assert len(inventory.groups['group1'].get_hosts()) == 1


# Generated at 2022-06-16 21:35:21.764574
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.2') == inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.3') == None


# Generated at 2022-06-16 21:35:27.115014
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:35:38.572874
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:35:50.204384
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.0.5")
    inventory.add_host("127.0.0.6")
    inventory.add_host("127.0.0.7")
    inventory.add_host("127.0.0.8")
    inventory.add_host("127.0.0.9")
    inventory.add_host("127.0.0.10")
    inventory.add_host("127.0.0.11")
    inventory.add_host

# Generated at 2022-06-16 21:35:52.668081
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test")
    assert inventory.groups["test"].name == "test"


# Generated at 2022-06-16 21:36:00.213606
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_child('group1', 'host1')
    inv.add_child('group2', 'host2')
    inv.add_child('group2', 'host1')
    assert inv.hosts['host1'].get_groups() == [inv.groups['group1'], inv.groups['group2']]
    assert inv.groups['group1'].get_hosts() == [inv.hosts['host1']]
    assert inv.groups['group2'].get_hosts() == [inv.hosts['host2'], inv.hosts['host1']]
    inv.remove_host

# Generated at 2022-06-16 21:36:14.019661
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv_data = InventoryData()
    inv_data.add_host('host1')
    inv_data.add_host('host2')
    inv_data.add_host('host3')
    inv_data.add_group('group1')
    inv_data.add_group('group2')
    inv_data.add_child('group1', 'host1')
    inv_data.add_child('group1', 'host2')
    inv_data.add_child('group2', 'host2')
    inv_data.add_child('group2', 'host3')
    inv_data.remove_host(inv_data.get_host('host2'))
    assert inv_data.groups['group1'].get_hosts() == [inv_data.get_host('host1')]
    assert inv

# Generated at 2022-06-16 21:36:25.419843
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:38.606584
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:53.412893
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].implicit is False

    inventory.add_host('test_host_2', port=22)
    assert 'test_host_2' in inventory.hosts
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22
    assert inventory.hosts

# Generated at 2022-06-16 21:36:57.448297
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    # Create an InventoryData object
    inventory_data = InventoryData()

    # Create a host object
    host = Host('localhost')

    # Add the host object to the inventory_data object
    inventory_data.hosts['localhost'] = host

    # Test if the host object is returned
    assert inventory_data.get_host('localhost') == host


# Generated at 2022-06-16 21:37:00.185563
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group("test_group")
    assert "test_group" in inventory_data.groups


# Generated at 2022-06-16 21:37:11.681905
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:37:24.797495
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:35.480794
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    assert inventory.hosts["localhost"].name == "localhost"
    assert inventory.hosts["localhost"].port is None
    assert inventory.hosts["localhost"].vars == {}
    assert inventory.hosts["localhost"].groups == []
    assert inventory.hosts["localhost"].implicit is False
    assert inventory.hosts["localhost"].address is None
    assert inventory.hosts["localhost"].host_vars_from_top_file == {}
    assert inventory.hosts["localhost"].host_vars_from_group_vars == {}
    assert inventory.hosts["localhost"].host_vars_from_inventory == {}
    assert inventory.hosts["localhost"].host_vars_from_fact_cache == {}
    assert inventory

# Generated at 2022-06-16 21:37:40.972202
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:50.228699
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22


# Generated at 2022-06-16 21:37:59.280275
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')

# Generated at 2022-06-16 21:38:02.757537
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert inventory.groups["test_group"].name == "test_group"
    assert inventory.groups["test_group"].depth == 0


# Generated at 2022-06-16 21:38:18.684579
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:38:31.153235
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:38:42.098458
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.reconcile_inventory()
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host1'], inventory_data.hosts['host2']]
    assert inventory_data.groups['group2'].get_hosts() == [inventory_data.hosts['host2']]
   

# Generated at 2022-06-16 21:38:48.581504
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'group1')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]

# Generated at 2022-06-16 21:38:59.049822
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']]
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.groups['test_group'].get_hosts() == []

# Generated at 2022-06-16 21:39:01.630831
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:39:09.354152
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    assert inventory.hosts["host1"].get_groups() == [inventory.groups["all"], inventory.groups["group1"]]
    assert inventory.hosts["host2"].get_groups() == [inventory.groups["all"], inventory.groups["group1"], inventory.groups["group2"]]
    assert inventory.hosts

# Generated at 2022-06-16 21:39:14.914851
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit == False
    assert inventory.hosts['localhost'].address == None
    assert inventory.hosts['localhost'].port == None
    assert inventory.hosts['localhost'].get_groups() == []
    assert inventory.hosts['localhost'].get_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars_for_host() == {}
    assert inventory.hosts['localhost'].get_group_v

# Generated at 2022-06-16 21:39:20.480941
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.hosts['test_host'] in inventory_data.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:39:28.473915
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    assert inv.hosts['localhost'].name == 'localhost'
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    assert inv.hosts['localhost'].name == 'localhost'
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None
    assert inv.hosts['localhost'].name == 'localhost'
    inv.add_host('localhost', port=None)
    assert inv.hosts

# Generated at 2022-06-16 21:39:38.264431
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert inventory.groups["test_group"].name == "test_group"


# Generated at 2022-06-16 21:39:49.757498
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("host1")
    inventory_data.add_host("host2")
    inventory_data.add_host("host3")
    inventory_data.add_group("group1")
    inventory_data.add_group("group2")
    inventory_data.add_group("group3")
    inventory_data.add_child("group1", "host1")
    inventory_data.add_child("group1", "host2")
    inventory_data.add_child("group2", "host2")
    inventory_data.add_child("group2", "host3")
    inventory_data.add_child("group3", "host3")
    inventory_data.add_child("group3", "host1")
    inventory_data.reconcile_

# Generated at 2022-06-16 21:39:58.790149
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:40:04.236660
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert inventory.groups['test_group'] is not None
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:40:11.559888
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=22)

# Generated at 2022-06-16 21:40:23.780440
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'group1')
    inventory.add_child('group3', 'group2')
    inventory.reconc

# Generated at 2022-06-16 21:40:36.217361
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group2')
    inventory_data.add_host('host3', 'group3')
    inventory_data.add_child('group1', 'group2')
    inventory_data.add_child('group2', 'group3')
    inventory_data.reconcile_inventory()
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host1']]

# Generated at 2022-06-16 21:40:42.897909
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host')
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.hosts['test_host'].port is None
    inv.add_host('test_host2', port=22)
    assert inv.hosts['test_host2'].port == 22


# Generated at 2022-06-16 21:40:52.462958
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['test_group'].get_ancestors() == [inventory.groups['all']]
    assert inventory.groups['test_group'].get_children() == []
    assert inventory.groups['all'].get_children() == [inventory.groups['test_group']]

# Generated at 2022-06-16 21:41:03.555451
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group2')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')

# Generated at 2022-06-16 21:41:17.789485
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host_1')
    inventory.add_host('test_host_2')
    inventory.add_group('test_group_1')
    inventory.add_group('test_group_2')
    inventory.add_child('test_group_1', 'test_host_1')
    inventory.add_child('test_group_2', 'test_host_2')
    inventory.reconcile_inventory()
    assert inventory.groups['test_group_1'].get_hosts() == [inventory.hosts['test_host_1']]
    assert inventory.groups['test_group_2'].get_hosts() == [inventory.hosts['test_host_2']]

# Generated at 2022-06-16 21:41:26.638625
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()

    # add a group
    inventory.add_group('group1')
    assert 'group1' in inventory.groups

    # add a host
    inventory.add_host('host1')
    assert 'host1' in inventory.hosts

    # add a child
    inventory.add_child('group1', 'host1')
    assert 'host1' in inventory.groups['group1'].get_hosts()

    # remove a group
    inventory.remove_group('group1')
    assert 'group1' not in inventory.groups

    # remove a host
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts

    # add a group
    inventory.add_group('group1')
    assert 'group1' in inventory.groups



# Generated at 2022-06-16 21:41:32.418737
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].port is None


# Generated at 2022-06-16 21:41:40.430880
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert 'test_host_2' in inventory.hosts
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22


# Generated at 2022-06-16 21:41:43.515239
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'test_group'
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:41:50.749358
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups
    assert 'test_group' in inventory_data.groups['all'].child_groups
    assert 'test_group' in inventory_data.groups['ungrouped'].child_groups
    assert 'test_group' in inventory_data.get_groups_dict()


# Generated at 2022-06-16 21:41:53.825931
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:42:02.907691
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group3', 'host5')

# Generated at 2022-06-16 21:42:14.760860
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:42:16.026353
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test")
    assert inventory.groups["test"].name == "test"


# Generated at 2022-06-16 21:42:34.414307
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host')
    assert 'test_host' in inv.hosts
    assert 'test_host' in inv.groups['all'].get_hosts()
    assert 'test_host' in inv.groups['ungrouped'].get_hosts()
    assert 'test_host' in inv.get_groups_dict()['all']
    assert 'test_host' in inv.get_groups_dict()['ungrouped']
    inv.add_host('test_host2', 'test_group')
    assert 'test_host2' in inv.hosts
    assert 'test_host2' in inv.groups['all'].get_hosts()
    assert 'test_host2' in inv.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:42:37.286325
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:42:40.832200
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups
    assert 'test' in inventory.get_groups_dict()
    assert 'test' in inventory.groups['all'].get_hosts()


# Generated at 2022-06-16 21:42:45.893761
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host("test_host", "test_group")
    assert inventory.hosts["test_host"].name == "test_host"
    assert inventory.groups["test_group"].name == "test_group"
    assert inventory.hosts["test_host"] in inventory.groups["test_group"].get_hosts()


# Generated at 2022-06-16 21:42:50.914719
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', group='all')
    assert 'localhost' in inventory.hosts
    assert 'all' in inventory.groups
    assert 'localhost' in inventory.groups['all'].hosts
    assert 'all' in inventory.hosts['localhost'].groups


# Generated at 2022-06-16 21:43:00.383296
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory