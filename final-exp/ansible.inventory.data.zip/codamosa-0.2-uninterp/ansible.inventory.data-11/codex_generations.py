

# Generated at 2022-06-16 21:33:32.487939
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:33:44.685425
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')

    assert len(inventory.hosts) == 3
    assert len(inventory.groups) == 3
    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert len(inventory.groups['group2'].get_hosts()) == 2


# Generated at 2022-06-16 21:33:57.323114
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.0.5")
    inventory.add_host("127.0.0.6")
    inventory.add_host("127.0.0.7")
    inventory.add_host("127.0.0.8")
    inventory.add_host("127.0.0.9")
    inventory.add_host("127.0.0.10")
    inventory.add_host("127.0.0.11")
    inventory.add_host

# Generated at 2022-06-16 21:34:07.854305
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_host('host3')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_child('group1', 'host1')
    inv.add_child('group1', 'host2')
    inv.add_child('group2', 'host2')
    inv.add_child('group2', 'host3')

    assert inv.hosts['host1'].get_groups() == [inv.groups['group1'], inv.groups['all']]
    assert inv.hosts['host2'].get_groups() == [inv.groups['group1'], inv.groups['group2'], inv.groups['all']]
    assert inv

# Generated at 2022-06-16 21:34:18.750275
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].hosts
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].hosts

# Generated at 2022-06-16 21:34:30.049920
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:34:35.749834
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert inventory.hosts["test_host"] in inventory.groups["test_group"].get_hosts()
    inventory.remove_host(inventory.hosts["test_host"])
    assert inventory.hosts["test_host"] not in inventory.groups["test_group"].get_hosts()

# Generated at 2022-06-16 21:34:43.016979
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')


# Generated at 2022-06-16 21:34:46.929700
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts

# Generated at 2022-06-16 21:34:54.998004
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():

    inventory = InventoryData()

    # Create a group
    group = inventory.add_group('group')

    # Create a host
    host = inventory.add_host('host')

    # Add the host to the group
    inventory.add_child(group, host)

    # Remove the host from the inventory
    inventory.remove_host(host)

    # Check that the host is not in the inventory
    assert host not in inventory.hosts

    # Check that the host is not in the group
    assert host not in inventory.groups[group].get_hosts()

# Generated at 2022-06-16 21:35:13.322782
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:35:21.616128
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert 'localhost' in inventory.hosts
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:35:34.325961
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group3')
    inventory_data.add_host('host5', 'group3')
    inventory_data.add_host('host6', 'group4')
    inventory_data.add_host('host7', 'group4')
    inventory_data.add_host('host8', 'group4')
    inventory_data.add_host('host9', 'group5')
    inventory_data.add_host('host10', 'group5')
    inventory_data.add_host('host11', 'group5')
    inventory_

# Generated at 2022-06-16 21:35:44.721334
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    inventory.add_host('localhost', 'all', 22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port == 22


# Generated at 2022-06-16 21:35:51.872506
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:01.630588
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:36:15.025280
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:36:26.310369
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:36:39.395045
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'group3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]


# Generated at 2022-06-16 21:36:49.529044
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host

# Generated at 2022-06-16 21:36:58.626480
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:37:10.644615
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:37:12.586645
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert "test_group" in inventory.groups


# Generated at 2022-06-16 21:37:26.094238
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('all', 'host1')
    inventory.add_child('all', 'host2')
    inventory.add_child('all', 'host3')
    inventory.add_child('ungrouped', 'host1')
    inventory.add_child('ungrouped', 'host2')
    inventory.add_child('ungrouped', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['all'].get_hosts() == inventory.groups['ungrouped'].get_hosts()

# Generated at 2022-06-16 21:37:35.663369
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:48.918869
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('localhost').name == 'localhost'
    assert inventory.get_host('127.0.0.1').name == 'localhost'
    assert inventory.get_host('127.0.0.1').address == '127.0.0.1'
    assert inventory.get_host('127.0.0.1').implicit == True
    assert inventory.get_host('127.0.0.1').vars['ansible_python_interpreter'] == sys.executable

# Generated at 2022-06-16 21:37:58.684972
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")

    assert inventory.get_host("localhost") == inventory.get_host("127.0.0.1")
    assert inventory.get_host("127.0.0.2") != inventory.get_host("127.0.0.1")
    assert inventory.get_host("127.0.0.3") != inventory.get_host("127.0.0.1")

# Generated at 2022-06-16 21:38:02.617991
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.get_host('localhost') == inventory.hosts['localhost']
    assert inventory.get_host('127.0.0.1') == inventory.hosts['localhost']
    assert inventory.get_host('::1') == inventory.hosts['localhost']
    assert inventory.get_host('::1') == inventory.hosts['localhost']
    assert inventory.get_host('example.com') == None


# Generated at 2022-06-16 21:38:09.308708
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert len(inventory.hosts) == 3
    assert len(inventory.groups) == 3
    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert len(inventory.groups['group2'].get_hosts()) == 2

# Generated at 2022-06-16 21:38:19.988920
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 2222

# Generated at 2022-06-16 21:38:35.189923
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    assert inventory.hosts["test_host"].name == "test_host"
    assert inventory.hosts["test_host"].port is None
    inventory.add_host("test_host_2", port=22)
    assert inventory.hosts["test_host_2"].name == "test_host_2"
    assert inventory.hosts["test_host_2"].port == 22


# Generated at 2022-06-16 21:38:37.712595
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:38:46.224554
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host1')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1']]

# Generated at 2022-06-16 21:38:48.496468
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test')
    assert 'test' in inventory_data.groups


# Generated at 2022-06-16 21:39:00.652622
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]
    assert inventory.groups['group2'].get_host

# Generated at 2022-06-16 21:39:08.911965
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_child('group1', 'host1')
    inv.add_child('group2', 'host2')
    inv.remove_host(inv.hosts['host1'])
    assert inv.hosts['host1'] not in inv.groups['group1'].get_hosts()
    assert inv.hosts['host1'] not in inv.groups['group2'].get_hosts()
    assert inv.hosts['host2'] in inv.groups['group1'].get_hosts()
    assert inv.hosts['host2'] in inv.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:39:12.189081
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = "test_group"
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:39:14.909455
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert "test_group" in inventory.groups


# Generated at 2022-06-16 21:39:24.464795
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host1")
    inventory.add_child("group2", "host3")
    inventory.remove_host(inventory.hosts["host1"])
    assert "host1" not in inventory.hosts
    assert "host1" not in inventory.groups["group1"].hosts
    assert "host1" not in inventory.groups["group2"].hosts

# Generated at 2022-06-16 21:39:34.658852
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].hosts
    assert 'host2' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:39:45.163693
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups
    assert inventory.groups['test'].name == 'test'


# Generated at 2022-06-16 21:39:51.433836
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    inventory_data.add_group("test_group")
    inventory_data.add_child("test_group", "test_host")
    assert len(inventory_data.hosts) == 1
    assert len(inventory_data.groups) == 2
    assert len(inventory_data.groups["test_group"].get_hosts()) == 1
    inventory_data.remove_host(inventory_data.hosts["test_host"])
    assert len(inventory_data.hosts) == 0
    assert len(inventory_data.groups) == 2
    assert len(inventory_data.groups["test_group"].get_hosts()) == 0

# Generated at 2022-06-16 21:39:59.515601
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group2')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group3')
    inventory.add_host('host8', 'group3')
    inventory.add_host('host9', 'group4')
    inventory.add_host('host10', 'group4')
    inventory.add_host('host11', 'group4')
    inventory.add_host('host12', 'group4')

# Generated at 2022-06-16 21:40:09.837352
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:40:22.144364
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host1')

# Generated at 2022-06-16 21:40:30.282326
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group3')
    inventory.add_host('host4', 'group1')
    inventory.add_host('host5', 'group2')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group3')
    inventory.add_host('host10', 'group1')

# Generated at 2022-06-16 21:40:32.798993
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:40:45.247074
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('localhost', 'group3')
    inventory.add_host('localhost', 'group3')
    inventory.add_host('localhost', 'group4')
    inventory.add_host('localhost', 'group4')
    inventory.add_host('localhost', 'group5')
    inventory.add_host('localhost', 'group5')
    inventory.add_host('localhost', 'group6')
    inventory.add_host('localhost', 'group6')
    inventory.add

# Generated at 2022-06-16 21:40:53.590689
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:41:04.811268
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory

# Generated at 2022-06-16 21:41:22.373534
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:41:24.086682
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:41:32.036694
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host

# Generated at 2022-06-16 21:41:40.037666
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.groups['test_group'].get_hosts() == []
    assert inventory.hosts == {}

# Generated at 2022-06-16 21:41:45.305356
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host')
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.hosts['test_host'].port is None
    inv.add_host('test_host_with_port', port=22)
    assert inv.hosts['test_host_with_port'].port == 22


# Generated at 2022-06-16 21:41:52.248724
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory.add_host("localhost")
    inventory

# Generated at 2022-06-16 21:42:00.726535
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']]
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.groups['test_group'].get_hosts() == []

# Generated at 2022-06-16 21:42:13.354915
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]

# Generated at 2022-06-16 21:42:24.674404
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2'], inventory.groups['all']]
    assert inventory

# Generated at 2022-06-16 21:42:38.066421
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')


# Generated at 2022-06-16 21:42:54.966425
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].get_hosts()