

# Generated at 2022-06-16 21:33:30.264323
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:33:42.959618
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.groups['group1'].get_children_groups() == [inventory.groups['group2']]
    assert inventory.groups['group2'].get_hosts() == []
    assert inventory.groups['group2'].get_children_groups() == []
    assert inventory

# Generated at 2022-06-16 21:33:50.752967
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:33:53.577300
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:34:04.800565
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars['inventory_file'] is None
    assert inventory.hosts['localhost'].vars['inventory_dir'] is None
    assert inventory.hosts['localhost'].vars['ansible_python_interpreter'] == '/usr/bin/python'
    assert inventory.hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inventory.hosts['localhost'].vars['ansible_host'] == '127.0.0.1'
    assert inventory.hosts['localhost'].vars['ansible_port'] is None
    assert inventory.hosts['localhost'].vars['ansible_user'] is None
   

# Generated at 2022-06-16 21:34:13.372588
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('host1', 'group1')
    inv.add_host('host2', 'group1')
    inv.add_host('host3', 'group2')
    inv.add_host('host4', 'group2')
    inv.add_host('host5', 'group3')
    inv.add_host('host6', 'group3')
    inv.add_host('host7', 'group4')
    inv.add_host('host8', 'group4')
    inv.add_host('host9', 'group5')
    inv.add_host('host10', 'group5')
    inv.add_host('host11', 'group6')
    inv.add_host('host12', 'group6')

# Generated at 2022-06-16 21:34:19.019025
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'group1')
    inventory.add_child('group3', 'group2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:34:26.014404
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:34:29.851523
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].hosts
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].hosts

# Generated at 2022-06-16 21:34:33.262864
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    assert 'group1' in inventory.groups
    assert 'group1' in inventory.get_groups_dict()
    assert inventory.get_groups_dict()['group1'] == []


# Generated at 2022-06-16 21:34:43.204015
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('localhost') == inventory.localhost


# Generated at 2022-06-16 21:34:56.023815
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert 'test_host_2' in inventory.hosts
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22
    inventory.add_host('test_host_3', group='test_group')
    assert 'test_host_3' in inventory.hosts

# Generated at 2022-06-16 21:35:08.964029
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.hosts['test_host'].vars == {}
    assert inventory_data.hosts['test_host'].groups == []
    assert inventory_data.hosts['test_host'].port is None
    assert inventory_data.hosts['test_host'].implicit is False
    assert inventory_data.hosts['test_host'].address is None
    assert inventory_data.hosts['test_host'].host_vars_from_top_file == {}
    assert inventory_data.hosts['test_host'].host_vars_from_group_vars == {}
    assert inventory_data.host

# Generated at 2022-06-16 21:35:18.895006
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:26.798114
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'] is not None
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].implicit is False


# Generated at 2022-06-16 21:35:38.340261
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:35:48.772219
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:35:59.836689
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:36:13.677225
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inv_data = InventoryData()
    inv_data.add_host('127.0.0.1')
    inv_data.add_host('localhost')
    inv_data.add_host('127.0.0.2')
    inv_data.add_host('127.0.0.3')
    inv_data.add_host('127.0.0.4')
    inv_data.add_host('127.0.0.5')
    inv_data.add_host('127.0.0.6')
    inv_data.add_host('127.0.0.7')
    inv_data.add_host('127.0.0.8')
    inv_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:36:19.732112
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:36:38.467677
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].get_hosts()
    assert 'host2' not in inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:36:48.829654
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_child('group1', 'host1')
    inv.add_child('group2', 'host2')
    inv.add_child('group1', 'group2')
    inv.remove_host(inv.hosts['host1'])
    assert inv.hosts['host1'] not in inv.groups['group1'].get_hosts()
    assert inv.hosts['host1'] not in inv.groups['group2'].get_hosts()
    assert inv.hosts['host1'] not in inv.groups['all'].get_hosts()

# Generated at 2022-06-16 21:36:57.690788
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['test_group'].get_ancestors() == [inventory.groups['all']]
    assert inventory.groups['all'].get_ancest

# Generated at 2022-06-16 21:37:01.170807
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('testhost')
    inventory.add_group('testgroup')
    inventory.add_child('testgroup', 'testhost')
    inventory.reconcile_inventory()
    assert inventory.groups['testgroup'].get_hosts() == [inventory.hosts['testhost']]
    assert inventory.hosts['testhost'].get_groups() == [inventory.groups['testgroup']]


# Generated at 2022-06-16 21:37:12.306592
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:37:25.730084
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_group('group6')
    inventory.add_group('group7')
    inventory.add_group('group8')
    inventory.add_

# Generated at 2022-06-16 21:37:35.554897
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:37:40.993595
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:37:54.511769
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group3')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group4')
    inventory.add_host('host10', 'group4')
    inventory.add_host('host11', 'group4')
    inventory.add_host('host12', 'group5')

# Generated at 2022-06-16 21:38:05.878471
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['ungrouped']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['group1'], inventory.groups['ungrouped']]

# Generated at 2022-06-16 21:38:22.070039
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert len(inventory.hosts) == 1
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert len(inventory.groups['all'].get_hosts()) == 1
    assert len(inventory.groups['ungrouped'].get_hosts()) == 1
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.hosts['test_host'].vars == {}

# Generated at 2022-06-16 21:38:31.327446
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22


# Generated at 2022-06-16 21:38:39.262256
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:38:47.182673
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group2')
    inventory_data.add_host('host5', 'group3')
    inventory_data.add_host('host6', 'group3')
    inventory_data.add_host('host7', 'group3')
    inventory_data.add_host('host8', 'group4')
    inventory_data.add_host('host9', 'group4')
    inventory_data.add_host('host10', 'group4')
    inventory_data.add_host('host11', 'group4')
    inventory_

# Generated at 2022-06-16 21:38:59.183826
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group3')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group4')
    inventory.add_host('host10', 'group4')
    inventory.add_host('host11', 'group4')
    inventory.add_host('host12', 'group5')

# Generated at 2022-06-16 21:39:08.236860
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    assert inventory.groups['all'].get_hosts()[0].address == '127.0.0.1'
    assert inventory.groups['all'].get_hosts()[0].vars['ansible_python_interpreter'] == sys.executable
    assert inventory.groups['all'].get_hosts()[0].vars['ansible_connection'] == 'local'

# Generated at 2022-06-16 21:39:13.333410
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:39:22.865229
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_host("host4")
    inventory.add_host("host5")
    inventory.add_host("host6")
    inventory.add_host("host7")
    inventory.add_host("host8")
    inventory.add_host("host9")
    inventory.add_host("host10")
    inventory.add_host("host11")
    inventory.add_host("host12")
    inventory.add_host("host13")
    inventory.add_host("host14")
    inventory.add_host("host15")
    inventory.add_host("host16")
    inventory.add_host("host17")
    inventory.add_

# Generated at 2022-06-16 21:39:34.114102
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:39:44.838075
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'all' in inventory.hosts['test_host'].get_groups()
    assert 'ungrouped' in inventory.hosts['test_host'].get_groups()
    assert len(inventory.hosts['test_host'].get_groups()) == 2
    assert len(inventory.groups['all'].get_hosts()) == 1
    assert len(inventory.groups['ungrouped'].get_hosts()) == 1
    assert len(inventory.groups['all'].get_children()) == 1


# Generated at 2022-06-16 21:39:59.156247
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:40:03.269569
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:40:11.009497
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group1')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group1')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group1')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group1')
    inventory.add_host('host11', 'group1')
    inventory.add_host('host12', 'group1')
   

# Generated at 2022-06-16 21:40:15.714013
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:40:23.797833
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    group1 = Group('group1')
    group2 = Group('group2')
    inventory.hosts = {'host1': host1, 'host2': host2}
    inventory.groups = {'group1': group1, 'group2': group2}
    group1.add_host(host1)
    group1.add_host(host2)
    group2.add_host(host1)
    group2.add_host(host2)
    inventory.remove_host(host1)
    assert host1.name not in inventory.hosts
    assert host1.name not in group1.get_hosts()
    assert host1.name not in group2.get_hosts()
    assert host

# Generated at 2022-06-16 21:40:32.258915
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    inventory.reconcile_inventory()
    assert inventory.groups["test_group"].get_hosts()[0].name == "test_host"
    assert inventory.hosts["test_host"].get_groups()[0].name == "test_group"

# Generated at 2022-06-16 21:40:39.204591
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'


# Generated at 2022-06-16 21:40:50.749332
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11', 'group1')
    inventory.add_host('host12', 'group2')

# Generated at 2022-06-16 21:41:02.526370
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group3', 'host3')
    inventory_data.add_child('group1', 'group2')
    inventory_data.add_child('group2', 'group3')
    inventory_data.add_child('group3', 'group1')

# Generated at 2022-06-16 21:41:12.736093
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_host("host4")
    inventory.add_host("host5")
    inventory.add_host("host6")
    inventory.add_host("host7")
    inventory.add_host("host8")
    inventory.add_host("host9")
    inventory.add_host("host10")
    inventory.add_host("host11")
    inventory.add_host("host12")
    inventory.add_host("host13")
    inventory.add_host("host14")
    inventory.add_host("host15")
    inventory.add_host("host16")
    inventory.add_host("host17")
    inventory.add_

# Generated at 2022-06-16 21:41:29.481361
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group2'], inventory.groups['all']]

# Generated at 2022-06-16 21:41:40.480030
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')
    assert inventory_data.hosts['host1'].name == 'host1'
    assert inventory_data.groups['group1'].name == 'group1'
    assert inventory_data.hosts['host1'] in inventory_data.groups['group1'].get_hosts()
    assert inventory_data.groups['group1'] in inventory_data.hosts['host1'].get_groups()
    assert inventory_data.hosts['host1'].get_variable('inventory_file') is None
    assert inventory_data.hosts['host1'].get_variable('inventory_dir') is None
    inventory_data.current_source = 'test_source'

# Generated at 2022-06-16 21:41:43.558945
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group = inventory_data.add_group('test_group')
    assert group == 'test_group'
    assert group in inventory_data.groups


# Generated at 2022-06-16 21:41:55.186021
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:42:03.673397
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_group("group3")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.add_child("group3", "host1")
    inventory.add_child("group3", "host3")
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:42:07.314792
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group = 'test_group'
    inventory_data.add_group(group)
    assert group in inventory_data.groups


# Generated at 2022-06-16 21:42:19.196702
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:42:28.472910
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group')
    inventory.add_host('test_host3', 'test_group')
    inventory.add_host('test_host4', 'test_group')
    inventory.add_host('test_host5', 'test_group')
    inventory.add_host('test_host6', 'test_group')
    inventory.add_host('test_host7', 'test_group')
    inventory.add_host('test_host8', 'test_group')
    inventory.add_host('test_host9', 'test_group')
    inventory.add_host('test_host10', 'test_group')
   

# Generated at 2022-06-16 21:42:40.022341
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host']
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host2', port=22)
    assert inventory.hosts['test_host2'].port == 22
    assert inventory.hosts['test_host2'].name == 'test_host2'
    assert inventory.hosts['test_host2']
    assert inventory.hosts['test_host2'].name == 'test_host2'
    assert inventory.hosts['test_host2'].port == 22
    assert inventory.hosts['test_host2'].vars == {}
    assert inventory.hosts

# Generated at 2022-06-16 21:42:51.931910
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]