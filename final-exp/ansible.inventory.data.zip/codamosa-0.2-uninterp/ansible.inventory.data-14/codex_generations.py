

# Generated at 2022-06-16 21:33:14.252590
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test_group")
    assert "test_group" in inventory.groups


# Generated at 2022-06-16 21:33:22.266808
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    inventory_data.add_group("test_group")
    inventory_data.add_child("test_group", "test_host")
    inventory_data.reconcile_inventory()
    assert inventory_data.get_host("test_host").get_groups() == [inventory_data.groups["all"], inventory_data.groups["test_group"]]

# Generated at 2022-06-16 21:33:32.846101
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    assert 'test_host' in inventory_data.hosts
    assert 'test_group' in inventory_data.groups
    assert 'test_host' in inventory_data.groups['test_group'].hosts
    inventory_data.remove_host(inventory_data.hosts['test_host'])
    assert 'test_host' not in inventory_data.hosts
    assert 'test_group' in inventory_data.groups
    assert 'test_host' not in inventory_data.groups['test_group'].hosts

# Generated at 2022-06-16 21:33:43.071239
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].hosts
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].hosts

# Generated at 2022-06-16 21:33:50.803603
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.get_host('localhost').get_groups() == [inventory.groups['all'], inventory.groups['group1']]
    assert inventory.groups['group1'].get_hosts() == [inventory.get_host('localhost')]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_hosts() == [inventory.get_host('localhost')]
    assert inventory.groups['all'].get_children() == [inventory.groups['group1']]
    assert inventory.groups['group1'].get_children() == []
   

# Generated at 2022-06-16 21:34:02.001633
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].implicit is False
    assert inventory.hosts['test_host'].address is None
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.hosts['test_host'].get_variables() == {}
    assert inventory.hosts['test_host'].get_vars() == {}
    assert inventory.hosts['test_host'].get_group_vars()

# Generated at 2022-06-16 21:34:10.687292
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:34:17.291067
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].get_hosts()
    assert 'host2' not in inventory.groups['group2'].get_hosts()

# Unit

# Generated at 2022-06-16 21:34:28.465622
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:34:37.295711
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].get_hosts()
    assert 'host1' not in inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:34:58.454732
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].get_hosts()
    assert 'host1' not in inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:35:11.563093
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.add_child('group3', 'host3')

# Generated at 2022-06-16 21:35:22.788446
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')
    inventory_data.hosts['host1'] = host1
    inventory_data.hosts['host2'] = host2
    inventory_data.hosts['host3'] = host3
    inventory_data.groups['group1'] = group1
    inventory_data.groups['group2'] = group2
    inventory_data.groups['group3'] = group3
    group1.add_host(host1)
    group1.add_host(host2)
    group2.add_host(host2)
    group2.add_host

# Generated at 2022-06-16 21:35:24.328999
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:35:36.552780
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    inv.add_host('localhost', 'group1')
    inv.add_host('localhost', 'group2')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group4')
    inv.add_host('localhost', 'group5')
    inv.add_host('localhost', 'group6')
    inv.add_host('localhost', 'group7')
    inv.add_host('localhost', 'group8')
    inv.add_host('localhost', 'group9')
    inv.add_host('localhost', 'group10')
    inv.add_host('localhost', 'group11')
    inv.add_host('localhost', 'group12')
    inv.add_host('localhost', 'group13')


# Generated at 2022-06-16 21:35:47.432167
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].implicit is False
    assert inventory.hosts['test_host'].address is None
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.hosts['test_host'].get_vars() == {}

    inventory.add_host('test_host2', 'test_group')
    assert inventory.hosts['test_host2'].name == 'test_host2'

# Generated at 2022-06-16 21:35:59.432030
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:36:13.170912
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=22222)
    assert inventory.hosts['localhost'].port == 22222
    inventory.add_host('localhost', port=222222)
    assert inventory.hosts['localhost'].port == 222222
    inventory.add_host('localhost', port=2222222)
    assert inventory.hosts['localhost'].port == 2222222
   

# Generated at 2022-06-16 21:36:24.731489
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')

    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.hosts['host1'] not in inventory.groups['group1'].get_hosts()

# Generated at 2022-06-16 21:36:38.043309
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert len(inventory.hosts) == 3
    assert len(inventory.groups) == 3
    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert len(inventory.groups['group2'].get_hosts()) == 2

# Generated at 2022-06-16 21:36:53.042642
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address == '127.0.0.1'
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]
   

# Generated at 2022-06-16 21:36:59.690085
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    assert inventory.groups['test_group'] in inventory.hosts['test_host'].get_groups()

# Generated at 2022-06-16 21:37:11.372480
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    inventory.add_host('localhost', 'all', 22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port == 22
    inventory.add_host('localhost', 'all', 22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts

# Generated at 2022-06-16 21:37:20.349509
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host2', port=22)
    assert inventory.hosts['test_host2'].name == 'test_host2'
    assert inventory.hosts['test_host2'].port == 22


# Generated at 2022-06-16 21:37:31.311614
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=23)
    assert inventory_data.hosts['localhost'].port == 23
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=23)


# Generated at 2022-06-16 21:37:43.745776
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:37:56.267134
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2'], inventory.hosts['host3']]

# Generated at 2022-06-16 21:38:06.857296
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address == '127.0.0.1'
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.hosts['localhost'].get_vars() == inventory.groups['all'].get_vars()

# Generated at 2022-06-16 21:38:19.648119
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory

# Generated at 2022-06-16 21:38:26.138954
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'test')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == None
    assert inventory.groups['test'].name == 'test'
    assert inventory.groups['test'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['test'].get_hosts()[0].port == None
    inventory.add_host('localhost', 'test', 22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    assert inventory.groups['test'].name == 'test'
    assert inventory.groups['test'].get_hosts()[0].name == 'localhost'

# Generated at 2022-06-16 21:38:33.084444
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert inventory_data.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:38:43.938722
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:38:55.731137
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:38:59.850937
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_group('group6')
    inventory.add_group('group7')
    inventory.add_group('group8')
    inventory.add_group('group9')
    inventory.add_group('group10')
    inventory.add_group('group11')
    inventory.add_group('group12')
    inventory.add_group('group13')
    inventory.add_group('group14')
    inventory.add_group('group15')
    inventory.add_

# Generated at 2022-06-16 21:39:09.872629
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group')
    inventory.add_host('test_host3')
    inventory.reconcile_inventory()
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host'], inventory.hosts['test_host2']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['test_host3']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['test_host'], inventory.hosts['test_host2'], inventory.hosts['test_host3']]

# Generated at 2022-06-16 21:39:19.040493
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert 'test_host' in inventory.get_groups_dict()['all']

# Generated at 2022-06-16 21:39:22.142024
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'


# Generated at 2022-06-16 21:39:29.386027
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:39:37.335934
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()

    # Test 1:
    # Add a group and a host to the inventory
    # The group and the host should be added to the inventory
    inventory_data.add_group('test_group')
    inventory_data.add_host('test_host', 'test_group')

    assert 'test_group' in inventory_data.groups
    assert 'test_host' in inventory_data.hosts

    # Test 2:
    # Add a group and a host to the inventory
    # The group should be added to the inventory
    # The host should not be added to the inventory
    inventory_data.add_group('test_group')
    inventory_data.add_host('test_host', 'test_group')

    assert 'test_group' in inventory_data.groups

# Generated at 2022-06-16 21:39:49.621230
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:39:54.984546
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:40:08.307713
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars['inventory_file'] == None
    assert inventory.hosts['localhost'].vars['inventory_dir'] == None
    assert inventory.hosts['localhost'].vars['ansible_python_interpreter'] == '/usr/bin/python'
    assert inventory.hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inventory.hosts['localhost'].port == None
    assert inventory.hosts['localhost'].implicit == True
    assert inventory.hosts['localhost'].address == '127.0.0.1'

# Generated at 2022-06-16 21:40:20.189291
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert 'test_host' in inventory_data.hosts
    assert 'test_host' in inventory_data.groups['all'].get_hosts()
    assert 'test_host' in inventory_data.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory_data.get_groups_dict()['all']
    assert 'test_host' in inventory_data.get_groups_dict()['ungrouped']

    inventory_data.add_host('test_host2', 'test_group')
    assert 'test_host2' in inventory_data.hosts
    assert 'test_host2' in inventory_data.groups['all'].get_hosts()

# Generated at 2022-06-16 21:40:29.595460
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars['inventory_file'] == None
    assert inventory.hosts['localhost'].vars['inventory_dir'] == None
    inventory.current_source = 'test_file'
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars['inventory_file'] == 'test_file'
    assert inventory.hosts['localhost'].vars['inventory_dir'] == basedir('test_file')
    inventory.add_host('localhost', group='test_group')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.host

# Generated at 2022-06-16 21:40:36.126628
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.reconcile_inventory()
    assert inventory

# Generated at 2022-06-16 21:40:48.548190
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:40:52.091565
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:41:03.105652
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('localhost', 'group3')
    inventory.add_host('localhost', 'group4')
    inventory.add_host('localhost', 'group5')
    inventory.add_host('localhost', 'group6')
    inventory.add_host('localhost', 'group7')
    inventory.add_host('localhost', 'group8')
    inventory.add_host('localhost', 'group9')
    inventory.add_host('localhost', 'group10')
    inventory.add_host('localhost', 'group11')
    inventory.add_host('localhost', 'group12')
    inventory.add_host('localhost', 'group13')


# Generated at 2022-06-16 21:41:13.206001
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    inventory_data.add_group("test_group")
    inventory_data.add_child("test_group", "test_host")
    inventory_data.reconcile_inventory()
    assert inventory_data.groups["all"].get_hosts() == [inventory_data.hosts["test_host"]]
    assert inventory_data.groups["ungrouped"].get_hosts() == []
    assert inventory_data.groups["test_group"].get_hosts() == [inventory_data.hosts["test_host"]]
    assert inventory_data.hosts["test_host"].get_groups() == [inventory_data.groups["all"], inventory_data.groups["test_group"]]

# Generated at 2022-06-16 21:41:23.368966
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    assert inventory.groups['all'].get_hosts()[0].vars == {}
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_children() == ['ungrouped']
    assert inventory.groups['all'].get_vars() == {}
    assert inventory.groups['ungrouped'].get

# Generated at 2022-06-16 21:41:38.186246
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2'], inventory.hosts['host3']]

# Generated at 2022-06-16 21:41:47.702105
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].implicit is False
    assert inventory.hosts['test_host'].address is None
    assert inventory.hosts['test_host'].variables == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.hosts['test_host'].get_vars() == {}
    assert inventory.hosts

# Generated at 2022-06-16 21:41:51.778990
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    inv.add_group("test_group")
    assert "test_group" in inv.groups


# Generated at 2022-06-16 21:42:01.540404
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.add_child('group3', 'host3')
    inventory_data.reconcile_

# Generated at 2022-06-16 21:42:05.651622
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert inventory_data.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:42:16.476598
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11', 'group1')
    inventory.add_

# Generated at 2022-06-16 21:42:27.473113
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert inventory.hosts['test_host_2'].port == 22
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_3', group='test_group')
    assert inventory.hosts['test_host_3'].name == 'test_host_3'

# Generated at 2022-06-16 21:42:39.327766
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_

# Generated at 2022-06-16 21:42:50.478835
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:43:00.038401
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}