

# Generated at 2022-06-16 21:33:23.534440
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:33:34.273898
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')
    inventory.add_host('host11', 'group6')
    inventory.add_host('host12', 'group6')

# Generated at 2022-06-16 21:33:46.326582
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_group("group1")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.remove_host(inventory.hosts["host1"])
    assert inventory.groups["group1"].get_hosts() == [inventory.hosts["host2"]]
    assert inventory.hosts["host1"] not in inventory.groups["group1"].get_hosts()
    assert inventory.hosts["host2"] in inventory.groups["group1"].get_hosts()
    assert inventory.hosts["host1"] not in inventory.hosts
    assert inventory.hosts["host2"] in inventory.hosts



# Generated at 2022-06-16 21:33:58.411775
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.groups['group1'].get_children_groups() == [inventory.groups['group2']]
    assert inventory.groups['group2'].get_hosts() == []
    assert inventory.groups['group2'].get_children_groups() == []
    assert inventory

# Generated at 2022-06-16 21:34:08.202627
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.remove_host(inventory.hosts["host2"])
    assert inventory.hosts["host2"] is None
    assert "host2" not in inventory.groups["group1"].hosts
    assert "host2" not in inventory.groups["group2"].hosts

# Generated at 2022-06-16 21:34:15.819127
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=23)
    assert inventory.hosts['localhost'].port == 23
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:34:29.760942
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert(inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']])
    assert(inventory.groups['group1'].get_groups() == [inventory.groups['group2']])
    assert(inventory.groups['group2'].get_hosts() == [])
    assert(inventory.groups['group2'].get_groups() == [])

# Generated at 2022-06-16 21:34:37.924186
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.remove_host(inventory_data.hosts['host1'])
    assert 'host1' not in inventory_data.hosts
    assert 'host1' not in inventory_data.groups['group1'].hosts
    assert 'host1' not in inventory_data.groups

# Generated at 2022-06-16 21:34:47.760590
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts

# Generated at 2022-06-16 21:34:54.380276
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.reconcile_inventory()
    assert inventory_data.hosts['test_host'].get_groups() == [inventory_data.groups['all'], inventory_data.groups['test_group']]

# Generated at 2022-06-16 21:35:06.271762
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:35:09.959034
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group = 'test_group'
    inventory_data.add_group(group)
    assert group in inventory_data.groups


# Generated at 2022-06-16 21:35:12.294652
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups


# Generated at 2022-06-16 21:35:21.085207
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host("host1")
    inventory_data.add_host("host2")
    inventory_data.add_host("host3")
    inventory_data.add_group("group1")
    inventory_data.add_group("group2")
    inventory_data.add_child("group1", "host1")
    inventory_data.add_child("group1", "host2")
    inventory_data.add_child("group2", "host2")
    inventory_data.add_child("group2", "host3")

    assert len(inventory_data.hosts) == 3
    assert len(inventory_data.groups) == 2
    assert len(inventory_data.groups["group1"].hosts) == 2

# Generated at 2022-06-16 21:35:24.827066
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'test_group'
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:35:36.902662
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1']]
    inventory.remove_host(inventory.hosts['host1'])

# Generated at 2022-06-16 21:35:48.686787
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host1'], inventory_data.hosts['host2']]
    assert inventory_data.hosts['host1'].get_groups() == [inventory_data.groups['group1']]
    assert inventory_data.hosts['host2'].get_groups() == [inventory_data.groups['group1']]

# Generated at 2022-06-16 21:35:59.835436
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:13.678218
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]

# Generated at 2022-06-16 21:36:25.159636
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:36.125888
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host', 'test_group')
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.groups['test_group'].name == 'test_group'
    assert inv.hosts['test_host'] in inv.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:36:39.658713
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    assert inventory_data.add_group("test_group") == "test_group"
    assert inventory_data.add_group("test_group") == "test_group"


# Generated at 2022-06-16 21:36:49.759366
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:36:58.175178
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    inv.add_host('localhost', 'group1')
    inv.add_host('localhost', 'group2')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group4')
    inv.add_host('localhost', 'group5')
    inv.add_host('localhost', 'group6')
    inv.add_host('localhost', 'group7')
    inv.add_host('localhost', 'group8')
    inv.add_host('localhost', 'group9')
    inv.add_host('localhost', 'group10')
    inv.add_host('localhost', 'group11')
    inv.add_host('localhost', 'group12')
    inv.add_host('localhost', 'group13')


# Generated at 2022-06-16 21:37:10.215720
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:14.604345
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.hosts['test_host'] in inventory_data.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:37:26.812011
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'group1')
    inventory.add_child('group3', 'group2')

    # remove host1


# Generated at 2022-06-16 21:37:37.940683
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('localhost', 'group1')
    inventory.add_host('localhost', 'group2')
    inventory.add_host('localhost', 'group3')
    inventory.add_host('localhost', 'group4')
    inventory.add_host('localhost', 'group5')
    inventory.add_host('localhost', 'group6')
    inventory.add_host('localhost', 'group7')
    inventory.add_host('localhost', 'group8')
    inventory.add_host('localhost', 'group9')
    inventory.add_host

# Generated at 2022-06-16 21:37:51.481014
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:59.986323
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:38:16.880637
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.add_child('group3', 'host3')

# Generated at 2022-06-16 21:38:24.591291
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:38:30.955143
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:38:32.874206
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:38:43.742119
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')


# Generated at 2022-06-16 21:38:47.817810
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    host = inventory.get_host('localhost')
    assert host.name == 'localhost'
    assert host.address == '127.0.0.1'
    assert host.implicit
    assert host.vars['ansible_python_interpreter'] == sys.executable
    assert host.vars['ansible_connection'] == 'local'
    assert host.vars['inventory_file'] is None
    assert host.vars['inventory_dir'] is None


# Generated at 2022-06-16 21:38:59.804679
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group1', 'group2')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['group2'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group2'], inventory.groups['all']]
    assert inventory.groups['group1'].get_hosts

# Generated at 2022-06-16 21:39:04.156683
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    assert inventory.get_host("test_host") == inventory.hosts["test_host"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host2"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host3"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host4"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host5"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host6"]
    assert inventory.get_host("test_host") != inventory.hosts["test_host7"]

# Generated at 2022-06-16 21:39:17.221964
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:39:25.656779
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    # Test case 1: hostname is in hosts dict
    inventory = InventoryData()
    inventory.hosts = {'host1': 'host1'}
    assert inventory.get_host('host1') == 'host1'

    # Test case 2: hostname is not in hosts dict, but in C.LOCALHOST
    inventory = InventoryData()
    inventory.hosts = {}
    inventory._create_implicit_localhost = lambda x: 'localhost'
    assert inventory.get_host('localhost') == 'localhost'

    # Test case 3: hostname is not in hosts dict, and not in C.LOCALHOST
    inventory = InventoryData()
    inventory.hosts = {}
    assert inventory.get_host('host1') is None


# Generated at 2022-06-16 21:39:30.809976
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert inventory.groups['test']


# Generated at 2022-06-16 21:39:43.710465
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host1')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1']]

# Generated at 2022-06-16 21:39:54.869841
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    assert len(inventory.groups['group1'].get_hosts()) == 1
    assert len(inventory.groups['group2'].get_hosts()) == 2
    inventory.remove_host(inventory.hosts['host1'])
    assert len(inventory.groups['group1'].get_hosts()) == 0
    assert len(inventory.groups['group2'].get_hosts()) == 1

# Generated at 2022-06-16 21:40:08.307197
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:40:16.166938
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:40:26.801849
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    # Test add a group
    inventory_data.add_group('group1')
    assert inventory_data.groups['group1'].name == 'group1'
    # Test add a group which already exists
    inventory_data.add_group('group1')
    assert inventory_data.groups['group1'].name == 'group1'
    # Test add a group with invalid name
    try:
        inventory_data.add_group(None)
    except AnsibleError as e:
        assert 'Invalid empty/false group name provided' in str(e)
    try:
        inventory_data.add_group(1)
    except AnsibleError as e:
        assert 'Invalid group name supplied' in str(e)


# Generated at 2022-06-16 21:40:33.305550
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:40:45.896049
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('test_group')
    inventory.add_host('test_host')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert(inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['test_group']])
    assert(inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']])
    assert(inventory.groups['ungrouped'].get_hosts() == [])
    assert(inventory.groups['all'].get_hosts() == [inventory.hosts['test_host']])


# Generated at 2022-06-16 21:40:53.876461
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_host('host3')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_child('group1', 'host1')
    inv.add_child('group1', 'host2')
    inv.add_child('group2', 'host2')
    inv.add_child('group2', 'host3')
    assert inv.hosts['host1'].get_groups() == [inv.groups['all'], inv.groups['group1']]
    assert inv.hosts['host2'].get_groups() == [inv.groups['all'], inv.groups['group1'], inv.groups['group2']]
    assert inv

# Generated at 2022-06-16 21:40:59.981876
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Create inventory data
    inventory = InventoryData()
    # Create groups
    group_all = Group('all')
    group_all.vars = {'group_all_var': 'group_all_value'}
    group_ungrouped = Group('ungrouped')
    group_ungrouped.vars = {'group_ungrouped_var': 'group_ungrouped_value'}
    group_group1 = Group('group1')
    group_group1.vars = {'group_group1_var': 'group_group1_value'}
    group_group2 = Group('group2')
    group_group2.vars = {'group_group2_var': 'group_group2_value'}
    group_group3 = Group('group3')

# Generated at 2022-06-16 21:41:15.255067
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # Create inventory data object
    inventory_data = InventoryData()

    # Create groups
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')
    group4 = Group('group4')

    # Add groups to inventory data
    inventory_data.groups['group1'] = group1
    inventory_data.groups['group2'] = group2
    inventory_data.groups['group3'] = group3
    inventory_data.groups['group4'] = group4

    # Create hosts
    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')
    host4 = Host('host4')
    host5 = Host('host5')

    # Add hosts to inventory data
    inventory_data.hosts['host1']

# Generated at 2022-06-16 21:41:17.515659
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert inventory.groups['test'].name == 'test'


# Generated at 2022-06-16 21:41:25.853562
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'group1')
    inventory.reconcile_inventory()
    assert inventory.get_host('localhost') is not None
    assert inventory.get_host('host1') is not None
    assert inventory.get_host('host2') is not None
    assert inventory.get_host('group1') is None
    assert inventory.get_host('group2') is None

# Generated at 2022-06-16 21:41:36.629828
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None

    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts

# Generated at 2022-06-16 21:41:46.583804
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group2')
    inventory.add_group('test_group3')
    inventory.add_child('test_group3', 'test_host')
    inventory.add_child('test_group3', 'test_host2')
    inventory.add_child('test_group3', 'test_host3')
    inventory.add_child('test_group3', 'test_host4')
    inventory.add_child('test_group3', 'test_host5')
    inventory.add_child('test_group3', 'test_host6')
    inventory.add_child('test_group3', 'test_host7')

# Generated at 2022-06-16 21:41:52.965718
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group1')
    inventory.add_host('host7', 'group2')
    inventory.add_host('host8', 'group3')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11', 'group3')
    inventory.add_host('host12', 'group1')

# Generated at 2022-06-16 21:42:02.502931
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=23)
    assert inventory.hosts['localhost'].port == 23
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:42:14.398857
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    assert inventory.hosts["localhost"] is not None
    assert inventory.hosts["localhost"].name == "localhost"
    assert inventory.hosts["localhost"].vars == {}
    assert inventory.hosts["localhost"].groups == []
    assert inventory.hosts["localhost"].port is None
    assert inventory.hosts["localhost"].implicit is False
    assert inventory.hosts["localhost"].address == "127.0.0.1"
    assert inventory.hosts["localhost"].get_groups() == [inventory.groups["all"], inventory.groups["ungrouped"]]
    assert inventory.groups["all"].get_hosts() == [inventory.hosts["localhost"]]
    assert inventory.groups["ungrouped"].get_hosts()

# Generated at 2022-06-16 21:42:25.650633
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory.add_host('localhost', 'test')
    inventory

# Generated at 2022-06-16 21:42:38.403714
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    """
    Test add_host method of class InventoryData
    """
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['all'].get_hosts()[0].name == 'test_host'
    assert inventory_data.groups['ungrouped'].get_hosts()[0].name == 'test_host'
    inventory_data.add_host('test_host2', 'test_group')
    assert inventory_data.hosts['test_host2'].name == 'test_host2'
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host2'
    assert inventory_data.groups