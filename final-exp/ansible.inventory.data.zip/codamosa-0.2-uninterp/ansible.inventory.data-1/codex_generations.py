

# Generated at 2022-06-16 21:33:16.413189
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group2')
    inventory_data.add_host('host3', 'group1')
    inventory_data.add_host('host4', 'group2')
    inventory_data.add_host('host5', 'group1')
    inventory_data.add_host('host6', 'group2')
    inventory_data.add_host('host7', 'group1')
    inventory_data.add_host('host8', 'group2')
    inventory_data.add_host('host9', 'group1')

# Generated at 2022-06-16 21:33:19.388163
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:33:31.788038
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'group3')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2'], inventory.hosts['host3']]

# Generated at 2022-06-16 21:33:44.331309
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group1', 'group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group1', 'host3')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2'], inventory.hosts['host3']]

# Generated at 2022-06-16 21:33:57.277905
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2')
    inv.add_host('host3')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_group('group3')
    inv.add_child('group1', 'host1')
    inv.add_child('group2', 'host2')
    inv.add_child('group3', 'host3')
    inv.add_child('group1', 'group2')
    inv.add_child('group2', 'group3')
    inv.remove_host(inv.hosts['host1'])
    assert inv.hosts.keys() == ['host2', 'host3']
    assert inv.groups['group1'].get_hosts()

# Generated at 2022-06-16 21:34:07.815339
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_child('group1', 'group2')

    # remove group1
    inventory.remove_group('group1')
    assert 'group1' not in inventory.groups
    assert 'group2' in inventory.groups
    assert 'host1' not in inventory.hosts
    assert 'host2' not in inventory.hosts
    assert 'host3' in inventory.hosts
    assert 'host4' in inventory.hosts

# Generated at 2022-06-16 21:34:14.279187
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:34:20.292335
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert 'test_host' in inventory_data.hosts
    assert 'test_group' in inventory_data.groups
    assert 'test_host' in inventory_data.groups['test_group'].get_hosts()


# Generated at 2022-06-16 21:34:31.951531
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    assert inventory.add_child('group1', 'group2') == True
    assert inventory.add_child('group1', 'host1') == True
    assert inventory.add_child('group1', 'host2') == True
    assert inventory.add_child('group1', 'host3') == False
    assert inventory.add_child('group1', 'group3') == False
    assert inventory.add_child('group3', 'host1') == False
    assert inventory.add_child('group3', 'group1') == False

# Generated at 2022-06-16 21:34:36.735879
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:34:57.889432
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:35:10.547387
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].hosts
    assert 'host2' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:35:15.713373
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:35:27.381387
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:38.763312
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') == inventory.get_host('127.0.0.2')
    assert inventory.get_host('127.0.0.2') == inventory.get_host('127.0.0.3')

# Generated at 2022-06-16 21:35:49.085650
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:59.635930
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('localhost')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('127.0.0.3')
    assert inventory.get_host('127.0.0.3') is None


# Generated at 2022-06-16 21:36:06.813597
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:36:19.617412
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:24.686476
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host2', port=22)
    assert inventory.hosts['test_host2'].port == 22


# Generated at 2022-06-16 21:36:42.139121
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    host = inventory.get_host('127.0.0.1')
    assert host.name == '127.0.0.1'
    assert host.address == '127.0.0.1'
    assert host.implicit == True
    assert host.get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert host.get_vars() == {'ansible_python_interpreter': '/usr/bin/python', 'ansible_connection': 'local'}
    assert inventory.hosts['127.0.0.1'] == host
    assert inventory.localhost == host
    assert inventory.groups['all'].get_hosts() == [host]
    assert inventory.groups['ungrouped'].get_hosts() == [host]
   

# Generated at 2022-06-16 21:36:51.381479
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].address == '127.0.0.1'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.hosts['localhost'].implicit is True
    assert inventory.hosts['localhost'].has_vars() is False
    assert inventory.hosts['localhost'].has_vars_files() is False
    assert inventory.hosts['localhost'].has_vars_plugins() is False
    assert inventory.hosts['localhost'].has_

# Generated at 2022-06-16 21:36:59.228600
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('::1')
    inventory_data.add_host('127.0.0.2')

    assert inventory_data.get_host('localhost') == inventory_data.hosts['localhost']
    assert inventory_data.get_host('127.0.0.1') == inventory_data.hosts['127.0.0.1']
    assert inventory_data.get_host('::1') == inventory_data.hosts['::1']
    assert inventory_data.get_host('127.0.0.2') == inventory_data.hosts['127.0.0.2']

# Generated at 2022-06-16 21:37:10.954817
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:37:23.872727
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:37:34.505209
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:37:47.028112
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.reconcile_inventory()
    assert inventory.get_host('test_host').get_groups()[0].name == 'test_group'
    assert inventory.get_host('test_host').get_groups()[1].name == 'all'
    assert inventory.get_host('test_host').get_groups()[2].name == 'ungrouped'
    assert inventory.get_host('test_host').get_groups()[3].name == 'test_group'
    assert inventory.get_host('test_host').get_groups()[4].name == 'all'

# Generated at 2022-06-16 21:37:58.187712
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_group("group3")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.add_child("group3", "host1")
    inventory.add_child("group3", "host3")
    inventory.remove_host(inventory.hosts["host2"])

# Generated at 2022-06-16 21:38:07.472422
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.reconcile_

# Generated at 2022-06-16 21:38:20.035032
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].address == '127.0.0.1'
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == [inventory.groups['all']]
    assert inventory.hosts['localhost'].implicit is True
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all']]
    assert inventory.hosts['localhost'].get_vars() == {}
    assert inventory.hosts['localhost'].get_group_vars() == inventory.groups['all'].get_vars()
    assert inventory

# Generated at 2022-06-16 21:38:34.169007
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1", "group1")
    inventory.add_host("host2", "group1")
    inventory.add_host("host3", "group2")
    inventory.add_host("host4", "group2")
    inventory.add_host("host5", "group3")
    inventory.add_host("host6", "group3")
    inventory.add_host("host7", "group4")
    inventory.add_host("host8", "group4")
    inventory.add_host("host9", "group5")
    inventory.add_host("host10", "group5")
    inventory.add_host("host11", "group6")
    inventory.add_host("host12", "group6")

# Generated at 2022-06-16 21:38:37.022181
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test")
    assert inventory.groups["test"].name == "test"


# Generated at 2022-06-16 21:38:41.919024
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:38:46.733379
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert inventory.hosts["test_host"] in inventory.groups["test_group"].get_hosts()
    inventory.remove_host(inventory.hosts["test_host"])
    assert inventory.hosts["test_host"] not in inventory.groups["test_group"].get_hosts()

# Generated at 2022-06-16 21:38:48.989327
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    inv.add_group('test')
    assert 'test' in inv.groups


# Generated at 2022-06-16 21:39:00.394334
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host2']]
    assert inventory.hosts['host1'] not in inventory.groups['group1'].get_hosts()

# Generated at 2022-06-16 21:39:05.885595
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host2', port=22)
    assert inventory.hosts['test_host2'].name == 'test_host2'
    assert inventory.hosts['test_host2'].port == 22

# Generated at 2022-06-16 21:39:17.646735
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2', 'group1')
    inv.add_host('host3', 'group1')
    inv.add_host('host4', 'group2')
    inv.add_host('host5', 'group2')
    inv.add_host('host6', 'group3')
    inv.add_host('host7', 'group3')
    inv.add_host('host8', 'group3')
    inv.add_host('host9', 'group4')
    inv.add_host('host10', 'group4')
    inv.add_host('host11', 'group4')
    inv.add_host('host12', 'group4')
    inv.add_host('host13', 'group5')
   

# Generated at 2022-06-16 21:39:26.613473
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3', 'group1')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group1')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group1')

# Generated at 2022-06-16 21:39:35.986459
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('all')
    inventory.add_group('test')
    inventory.add_child('test', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['test']]
    assert inventory.groups['test'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['test']]
    assert inventory.groups['test'].get_children() == []

# Generated at 2022-06-16 21:39:48.066702
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:39:50.333148
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert inventory.groups['test_group']


# Generated at 2022-06-16 21:39:59.154810
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:40:05.431403
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("localhost2")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "localhost")
    inventory.add_child("group2", "localhost2")
    assert "localhost" in inventory.hosts
    assert "localhost2" in inventory.hosts
    assert "group1" in inventory.groups
    assert "group2" in inventory.groups
    assert "localhost" in inventory.groups["group1"].hosts
    assert "localhost2" in inventory.groups["group2"].hosts
    inventory.remove_host(inventory.hosts["localhost"])
    assert "localhost" not in inventory.hosts
    assert "localhost2" in inventory.hosts


# Generated at 2022-06-16 21:40:10.134021
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_host('localhost', 'all')
    inventory.add_host('localhost', 'ungrouped')
    inventory.reconcile_inventory()
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []

# Generated at 2022-06-16 21:40:22.488179
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:40:35.888861
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].vars == {}
    assert inv.hosts['localhost'].groups == []
    assert inv.hosts['localhost'].implicit == False
    assert inv.hosts['localhost'].address == None
    assert inv.hosts['localhost'].port == None
    assert inv.hosts['localhost'].get_groups() == []

    inv.add_host('localhost', 'group1')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].vars == {}
    assert inv.hosts['localhost'].groups == []
    assert inv.hosts['localhost'].implicit == False
    assert inv

# Generated at 2022-06-16 21:40:44.653663
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('all')
    inventory.add_group('test')
    inventory.add_child('test', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['test']]
    assert inventory.groups['test'].get_hosts() == [inventory.hosts['localhost']]


# Generated at 2022-06-16 21:40:53.281543
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['all'].get_children() == [inventory.groups['ungrouped']]
    assert inventory.groups['ungrouped'].get_children

# Generated at 2022-06-16 21:40:55.336346
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group = 'test_group'
    inventory.add_group(group)
    assert group in inventory.groups


# Generated at 2022-06-16 21:41:04.396730
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:41:14.118360
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")
    inventory.add_host("localhost", "test")


# Generated at 2022-06-16 21:41:23.800016
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.remove_host(inventory_data.hosts['host1'])
    assert 'host1' not in inventory_data.hosts
    assert 'host1' not in inventory_data.groups['group1'].hosts
    assert 'host1' not in inventory_data.groups

# Generated at 2022-06-16 21:41:30.937780
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inv_data = InventoryData()
    inv_data.add_host('test_host')
    inv_data.add_group('test_group')
    inv_data.add_child('test_group', 'test_host')
    inv_data.reconcile_inventory()
    assert inv_data.groups['all'].get_hosts() == inv_data.hosts.values()
    assert inv_data.groups['all'].get_hosts() == inv_data.groups['test_group'].get_hosts()
    assert inv_data.hosts['test_host'].get_groups() == inv_data.groups.values()


# Generated at 2022-06-16 21:41:41.958178
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:41:53.644012
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=23)
    assert inventory.hosts['localhost'].port == 23
    assert inventory.hosts['localhost'].name == 'localhost'
    inventory.add_host('localhost', port=None)
    assert inventory.hosts

# Generated at 2022-06-16 21:42:02.785881
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False
    assert inventory.hosts['localhost'].address is None
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]

# Generated at 2022-06-16 21:42:12.797501
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    inventory_data.add_group("test_group")
    inventory_data.add_child("test_group", "test_host")
    assert(inventory_data.hosts["test_host"].get_groups()[0].name == "test_group")
    inventory_data.remove_host(inventory_data.hosts["test_host"])
    assert(inventory_data.hosts["test_host"] == None)
    assert(inventory_data.groups["test_group"].get_hosts() == [])


# Generated at 2022-06-16 21:42:24.111935
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')

    inventory.reconcile_inventory()


# Generated at 2022-06-16 21:42:37.914040
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=22222)
    assert inventory.hosts['localhost'].port == 22222
    inventory.add_host('localhost', port=222222)
    assert inventory.hosts['localhost'].port == 222222
    inventory.add_host('localhost', port=2222222)
    assert inventory.hosts['localhost'].port == 2222222
   

# Generated at 2022-06-16 21:42:50.128648
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'test_group'
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:42:59.753637
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]