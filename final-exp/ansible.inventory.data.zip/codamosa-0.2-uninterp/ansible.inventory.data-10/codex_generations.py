

# Generated at 2022-06-16 21:33:18.421508
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    assert inventory.groups['test_group'] in inventory.hosts['test_host'].get_groups()


# Generated at 2022-06-16 21:33:30.949155
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    host_name = 'test_host'
    host_name_implicit = 'test_host_implicit'
    host_name_not_exist = 'test_host_not_exist'
    host_name_not_exist_implicit = 'test_host_not_exist_implicit'
    group_name = 'test_group'

    # Test case 1: host_name is not in self.hosts
    #              host_name is in C.LOCALHOST
    #              self.localhost is None
    #              expected: host_name is added to self.hosts
    #                        host_name is set to self.localhost
    #                        return host_name
    inventory_data.hosts = {}
    inventory_data.localhost = None

# Generated at 2022-06-16 21:33:38.325987
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')

    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.hosts['host1'].name not in inventory.groups['group1'].hosts
    assert inventory.hosts['host2'].name in inventory.groups['group1'].hosts
    assert inventory.hosts

# Generated at 2022-06-16 21:33:48.427489
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host')
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.hosts['test_host'].groups == [inv.groups['all'], inv.groups['ungrouped']]
    assert inv.groups['all'].hosts == [inv.hosts['test_host']]
    assert inv.groups['ungrouped'].hosts == [inv.hosts['test_host']]
    assert inv.groups['all'].children == [inv.groups['ungrouped']]
    assert inv.groups['ungrouped'].parents == [inv.groups['all']]
    assert inv.groups['all'].parents == []
    assert inv.groups['ungrouped'].children == []

    inv.add_host

# Generated at 2022-06-16 21:33:54.794442
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    inventory.remove_host(inventory.hosts['test_host'])
    assert len(inventory.groups['test_group'].get_hosts()) == 0

# Generated at 2022-06-16 21:33:59.731890
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:34:09.339971
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group2')
    inventory_data.add_host('host5', 'group2')
    inventory_data.add_host('host6', 'group3')
    inventory_data.add_host('host7', 'group3')
    inventory_data.add_host('host8', 'group3')
    inventory_data.add_host('host9', 'group3')
    inventory_data.add_host('host10', 'group3')
    inventory_data.add_host('host11', 'group4')
    inventory_

# Generated at 2022-06-16 21:34:22.299150
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("localhost.localdomain")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.1.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.1.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.1.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.1.4")

    assert inventory.get_host("localhost") is not None
    assert inventory.get_host("localhost.localdomain") is not None
    assert inventory.get_

# Generated at 2022-06-16 21:34:32.158498
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    assert len(inventory.groups['group1'].get_hosts()) == 2
    inventory.remove_host(inventory.hosts['host1'])
    assert len(inventory.groups['group1'].get_hosts()) == 1
    assert inventory.groups['group1'].get_hosts()[0].name == 'host2'

# Generated at 2022-06-16 21:34:39.224303
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv_data = InventoryData()
    inv_data.add_host('test_host')
    assert inv_data.hosts['test_host'].name == 'test_host'
    assert inv_data.hosts['test_host'].port is None
    inv_data.add_host('test_host', port=22)
    assert inv_data.hosts['test_host'].port == 22
    inv_data.add_host('test_host', port=22)
    assert inv_data.hosts['test_host'].port == 22
    inv_data.add_host('test_host', port=23)
    assert inv_data.hosts['test_host'].port == 23
    inv_data.add_host('test_host', port=None)

# Generated at 2022-06-16 21:34:47.380326
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group = 'test_group'
    inventory.add_group(group)
    assert group in inventory.groups


# Generated at 2022-06-16 21:34:58.034708
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert 'test_host' in inventory.get_groups_dict()['all']

# Generated at 2022-06-16 21:35:11.129730
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:20.366261
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')

    assert(len(inventory.hosts) == 3)
    assert(len(inventory.groups) == 3)
    assert(len(inventory.groups['group1'].get_hosts()) == 2)
    assert(len(inventory.groups['group2'].get_hosts()) == 2)

    inventory.remove_host

# Generated at 2022-06-16 21:35:33.811172
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'localhost')
    inventory_data.add_child('group2', 'localhost')
    inventory_data.reconcile_inventory()
    assert inventory_data.hosts['localhost'].get_groups() == [inventory_data.groups['all'], inventory_data.groups['group1'], inventory_data.groups['group2']]
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['localhost']]
    assert inventory_data.groups['group2'].get_hosts() == [inventory_data.hosts['localhost']]

# Generated at 2022-06-16 21:35:44.611284
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost', 'all')
    inventory_data.add_host('127.0.0.1', 'all')
    inventory_data.add_host('127.0.0.2', 'all')
    inventory_data.add_host('127.0.0.3', 'all')
    inventory_data.add_host('127.0.0.4', 'all')
    inventory_data.add_host('127.0.0.5', 'all')
    inventory_data.add_host('127.0.0.6', 'all')
    inventory_data.add_host('127.0.0.7', 'all')
    inventory_data.add_host('127.0.0.8', 'all')
    inventory_data.add_

# Generated at 2022-06-16 21:35:56.909039
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Test case 1: add host to group
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_host('host1', 'group1')
    assert inventory.hosts['host1'].name == 'host1'
    assert inventory.hosts['host1'].get_groups()[0].name == 'group1'
    assert inventory.groups['group1'].get_hosts()[0].name == 'host1'

    # Test case 2: add host to group which doesn't exist
    inventory = InventoryData()
    try:
        inventory.add_host('host1', 'group1')
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError not raised'

    # Test case 3: add host to group which is not a string

# Generated at 2022-06-16 21:36:04.219326
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:36:16.450427
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2'], inventory.groups['all']]
    assert inventory

# Generated at 2022-06-16 21:36:27.061333
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:42.292539
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('localhost')
    assert inventory.get_host('127.0.0.2') == inventory.hosts['127.0.0.2']
    assert inventory.get_host('127.0.0.2') != inventory.hosts['127.0.0.1']

# Generated at 2022-06-16 21:36:51.506901
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:36:59.567536
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:37:05.153008
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    assert inventory_data.groups['group1'].name == 'group1'
    assert inventory_data.groups['group2'].name == 'group2'


# Generated at 2022-06-16 21:37:14.352053
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:37:26.727632
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('testhost1')
    inventory.add_host('testhost2')
    inventory.add_host('testhost3')
    inventory.add_host('testhost4')
    inventory.add_host('testhost5')
    inventory.add_host('testhost6')
    inventory.add_host('testhost7')
    inventory.add_host('testhost8')
    inventory.add_host('testhost9')
    inventory.add_host('testhost10')
    inventory.add_host('testhost11')
    inventory.add_host('testhost12')
    inventory.add_host('testhost13')
    inventory.add_host('testhost14')
    inventory.add_host('testhost15')
    inventory.add_host('testhost16')


# Generated at 2022-06-16 21:37:35.990055
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    host_name = 'localhost'
    host = inventory_data.get_host(host_name)
    assert host.name == host_name
    assert host.address == "127.0.0.1"
    assert host.implicit == True
    assert host.vars['ansible_python_interpreter'] == sys.executable
    assert host.vars['ansible_connection'] == 'local'
    assert host.vars['inventory_file'] == None
    assert host.vars['inventory_dir'] == None

    host_name = '127.0.0.1'
    host = inventory_data.get_host(host_name)
    assert host.name == host_name
    assert host.address == "127.0.0.1"
    assert host.implicit

# Generated at 2022-06-16 21:37:49.483199
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    inv.add_group('group1')
    assert inv.groups['group1'].name == 'group1'
    assert inv.groups['group1'].depth == 0
    assert inv.groups['group1'].parent is None
    assert inv.groups['group1'].child_groups == []
    assert inv.groups['group1'].child_hosts == []
    assert inv.groups['group1'].vars == {}
    assert inv.groups['group1'].get_hosts() == []
    assert inv.groups['group1'].get_variables() == {}
    assert inv.groups['group1'].get_hosts() == []
    assert inv.groups['group1'].get_vars() == {}
    assert inv.groups['group1'].get_children() == []

# Generated at 2022-06-16 21:37:58.829165
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:38:07.530837
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group3')
    inventory.add_host('host6', 'group3')
    inventory.add_host('host7', 'group4')
    inventory.add_host('host8', 'group4')
    inventory.add_host('host9', 'group5')
    inventory.add_host('host10', 'group5')

    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')

# Generated at 2022-06-16 21:38:15.602363
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("test_host")
    inventory.add_group("test_group")
    inventory.add_child("test_group", "test_host")
    assert "test_host" in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" in inventory.groups["test_group"].hosts
    inventory.remove_host(inventory.hosts["test_host"])
    assert "test_host" not in inventory.hosts
    assert "test_group" in inventory.groups
    assert "test_host" not in inventory.groups["test_group"].hosts

# Generated at 2022-06-16 21:38:23.923632
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert 'localhost' in inventory_data.hosts
    assert 'localhost' in inventory_data.groups['all'].get_hosts()
    assert 'localhost' in inventory_data.groups['ungrouped'].get_hosts()
    assert 'localhost' in inventory_data.groups['all'].get_hosts()
    assert 'localhost' in inventory_data.groups['ungrouped'].get_hosts()
    assert inventory_data.hosts['localhost'].get_groups() == [inventory_data.groups['all'], inventory_data.groups['ungrouped']]
    assert inventory_data.groups['all'].get_hosts() == [inventory_data.hosts['localhost']]

# Generated at 2022-06-16 21:38:27.031176
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:38:28.664437
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    inv.add_group('test_group')
    assert 'test_group' in inv.groups
    assert inv.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:38:39.173051
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('host1')
    inv.add_host('host2', 'group1')
    inv.add_host('host3', 'group1')
    inv.add_host('host4', 'group2')
    inv.add_host('host5', 'group2')
    inv.add_host('host6', 'group2')
    inv.add_host('host7', 'group3')
    inv.add_host('host8', 'group3')
    inv.add_host('host9', 'group3')
    inv.add_host('host10', 'group3')
    inv.add_host('host11', 'group4')
    inv.add_host('host12', 'group4')
    inv.add_host('host13', 'group4')
   

# Generated at 2022-06-16 21:38:47.130560
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    assert 'test_host' in inventory_data.hosts
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.hosts['test_host'].port is None
    assert inventory_data.hosts['test_host'].vars == {}
    assert inventory_data.hosts['test_host'].groups == []
    assert inventory_data.hosts['test_host'].implicit is False

    inventory_data.add_host('test_host2', port=22)
    assert 'test_host2' in inventory_data.hosts
    assert inventory_data.hosts['test_host2'].name == 'test_host2'

# Generated at 2022-06-16 21:38:59.139850
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:39:08.135019
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_host('host2')
    inventory.add_group('group2')
    inventory.add_child('group2', 'host2')
    inventory.add_host('host3')
    inventory.add_group('group3')
    inventory.add_child('group3', 'host3')
    inventory.add_host('host4')
    inventory.add_group('group4')
    inventory.add_child('group4', 'host4')
    inventory.add_host('host5')
    inventory.add_group('group5')
    inventory.add_child('group5', 'host5')

# Generated at 2022-06-16 21:39:11.773708
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group("test_group")
    assert inventory_data.groups["test_group"].name == "test_group"


# Generated at 2022-06-16 21:39:14.870214
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv_data = InventoryData()
    inv_data.add_group('test_group')
    assert 'test_group' in inv_data.groups


# Generated at 2022-06-16 21:39:23.866596
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'


# Generated at 2022-06-16 21:39:34.766561
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_group('group1')
    inventory_data.add_child('group1', 'localhost')
    inventory_data.reconcile_inventory()
    assert inventory_data.get_host('localhost').get_groups() == [inventory_data.groups['all'], inventory_data.groups['group1']]
    assert inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['localhost']]
    assert inventory_data.groups['ungrouped'].get_hosts() == []
    assert inventory_data.groups['all'].get_hosts() == [inventory_data.hosts['localhost']]

# Generated at 2022-06-16 21:39:43.849836
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].hosts
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' not in inventory.groups['test_group'].hosts

# Generated at 2022-06-16 21:39:47.442620
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:39:57.436881
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:40:09.206798
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1", "group1")
    inventory.add_host("host2", "group1")
    inventory.add_host("host3", "group2")
    inventory.add_host("host4", "group2")
    inventory.add_host("host5", "group3")
    inventory.add_host("host6", "group3")
    inventory.add_host("host7", "group4")
    inventory.add_host("host8", "group4")
    inventory.add_host("host9", "group5")
    inventory.add_host("host10", "group5")
    inventory.add_host("host11", "group6")
    inventory.add_host("host12", "group6")

# Generated at 2022-06-16 21:40:14.479086
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:40:24.271512
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port is None
    inventory.add_host('localhost', 'all', 22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory.groups['all'].get_hosts()[0].port == 22

# Generated at 2022-06-16 21:40:36.665950
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host')
    inventory_data.add_group('test_group')
    inventory_data.add_child('test_group', 'test_host')
    inventory_data.reconcile_inventory()
    assert inventory_data.get_host('test_host').get_groups() == [inventory_data.groups['all'], inventory_data.groups['test_group']]
    assert inventory_data.groups['test_group'].get_hosts() == [inventory_data.hosts['test_host']]
    assert inventory_data.groups['all'].get_hosts() == [inventory_data.hosts['test_host']]
    assert inventory_data.groups['ungrouped'].get_hosts() == []

# Generated at 2022-06-16 21:40:39.656640
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:40:53.851060
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:41:05.059002
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_host('host7')
    inventory_data.add_host('host8')
    inventory_data.add_host('host9')
    inventory_data.add_host('host10')
    inventory_data.add_host('host11')
    inventory_data.add_host('host12')
    inventory_data.add_host('host13')
    inventory_data.add_host('host14')
    inventory_data.add_host

# Generated at 2022-06-16 21:41:14.601922
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:41:22.874922
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:41:30.076330
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Create a new InventoryData object
    inv = InventoryData()

    # Create a new group
    group = Group('test_group')

    # Add the group to the inventory
    inv.groups['test_group'] = group

    # Create a new host
    host = Host('test_host')

    # Add the host to the inventory
    inv.hosts['test_host'] = host

    # Add the host to the group
    group.add_host(host)

    # Call the reconcile_inventory method
    inv.reconcile_inventory()

    # Check that the group is in the inventory
    assert 'test_group' in inv.groups

    # Check that the host is in the inventory
    assert 'test_host' in inv.hosts

    # Check that the host is in the group
    assert host in group.get_host

# Generated at 2022-06-16 21:41:41.284087
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    inventory.reconcile_inventory()
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['test_host']]
    assert inventory.groups['all'].get_children() == [inventory.groups['test_group']]
    assert inventory.groups['test_group'].get_children() == []

# Generated at 2022-06-16 21:41:49.680807
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:41:55.361852
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')

# Generated at 2022-06-16 21:42:03.774058
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    host3 = Host('host3')
    group1 = Group('group1')
    group2 = Group('group2')
    group3 = Group('group3')
    inventory.hosts = {'host1': host1, 'host2': host2, 'host3': host3}
    inventory.groups = {'group1': group1, 'group2': group2, 'group3': group3}
    group1.add_host(host1)
    group1.add_host(host2)
    group2.add_host(host2)
    group2.add_host(host3)
    group3.add_host(host1)
    group3.add_host(host2)
    group3

# Generated at 2022-06-16 21:42:15.463733
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:42:30.406863
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    host = inventory.add_host('localhost')
    assert host == 'localhost'
    assert 'localhost' in inventory.hosts
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit is False

    host = inventory.add_host('localhost', port=22)
    assert host == 'localhost'
    assert 'localhost' in inventory.hosts
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    assert inventory.hosts['localhost'].vars == {}

# Generated at 2022-06-16 21:42:41.397191
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group')
    inventory.add_host('test_host3', 'test_group')
    inventory.add_host('test_host4', 'test_group')
    inventory.add_host('test_host5', 'test_group')
    inventory.add_host('test_host6', 'test_group')
    inventory.add_host('test_host7', 'test_group')
    inventory.add_host('test_host8', 'test_group')
    inventory.add_host('test_host9', 'test_group')
    inventory.add_host('test_host10', 'test_group')
   

# Generated at 2022-06-16 21:42:47.962749
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:42:57.860857
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    assert inventory.hosts['test_host'].vars == {}
    assert inventory.hosts['test_host'].groups == []
    assert inventory.hosts['test_host'].implicit is False
    assert inventory.hosts['test_host'].address is None
    assert inventory.hosts['test_host'].get_groups() == []
    assert inventory.hosts['test_host'].get_vars() == {}
    assert inventory.hosts['test_host'].get_group_vars() == {}