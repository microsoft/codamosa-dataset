

# Generated at 2022-06-16 21:33:27.326094
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5', 'group2')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7', 'group2')
    inventory.add_host('host8', 'group2')
    inventory.add_host('host9', 'group2')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11', 'group2')
    inventory.add_

# Generated at 2022-06-16 21:33:34.015170
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:33:46.085552
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host3', 'group2')
    inventory.add_host('host4', 'group2')
    inventory.add_host('host5')
    inventory.remove_group('group1')
    assert 'group1' not in inventory.groups
    assert 'host1' not in inventory.hosts
    assert 'host2' not in inventory.hosts
    assert 'host3' in inventory.hosts
    assert 'host4' in inventory.hosts
    assert 'host5' in inventory.hosts
    assert 'group2' in inventory.groups

# Generated at 2022-06-16 21:33:58.421294
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    group1 = Group('group1')
    group2 = Group('group2')
    inventory.hosts['host1'] = host1
    inventory.hosts['host2'] = host2
    inventory.groups['group1'] = group1
    inventory.groups['group2'] = group2
    group1.add_host(host1)
    group1.add_host(host2)
    group2.add_host(host1)
    group2.add_host(host2)
    inventory.remove_host(host1)
    assert host1.name not in inventory.hosts
    assert host1 not in group1.get_hosts()
    assert host1 not in group2.get_hosts()


# Generated at 2022-06-16 21:34:06.894832
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.groups['group1'].get_hosts()
    assert 'host1' not in inventory.hosts
    assert 'host2' in inventory.groups['group1'].get_hosts()
    assert 'host2' in inventory.hosts

# Generated at 2022-06-16 21:34:14.886106
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group2', 'host2')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['group2']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group2']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]

# Generated at 2022-06-16 21:34:28.925519
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'localhost')
    inventory.remove_host(inventory.hosts['host2'])
    assert 'host2' not in inventory.hosts
    assert 'host2' not in inventory.groups['group1'].get_hosts()
   

# Generated at 2022-06-16 21:34:34.847536
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:34:40.613353
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'group1')
    inventory.add_child('group3', 'group2')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]
    assert inventory.groups['group2'].get_host

# Generated at 2022-06-16 21:34:53.425560
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]
    assert inventory.groups['group2'].get_hosts() == [inventory.hosts['host2'], inventory.hosts['host3']]
    inventory.remove_

# Generated at 2022-06-16 21:35:13.155939
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:35:21.522904
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('test_host')
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.hosts['test_host'].port is None
    inv.add_host('test_host2', port=22)
    assert inv.hosts['test_host2'].port == 22
    assert inv.hosts['test_host2'].name == 'test_host2'
    inv.add_host('test_host3', port=22)
    assert inv.hosts['test_host3'].port == 22
    assert inv.hosts['test_host3'].name == 'test_host3'
    inv.add_host('test_host3', port=22)

# Generated at 2022-06-16 21:35:34.224690
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:35:44.931793
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host('127.0.0.12')


# Generated at 2022-06-16 21:35:57.301582
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:36:09.413215
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:36:17.319515
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    host = inventory.get_host('localhost')
    assert host.name == 'localhost'
    assert host.address == '127.0.0.1'
    assert host.implicit == True
    assert host.vars['ansible_python_interpreter'] == sys.executable
    assert host.vars['ansible_connection'] == 'local'
    assert host.vars['inventory_file'] == None
    assert host.vars['inventory_dir'] == None


# Generated at 2022-06-16 21:36:27.444020
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_host('test_host2')
    inventory.add_host('test_host3')
    inventory.add_host('test_host4')
    inventory.add_host('test_host5')
    inventory.add_host('test_host6')
    inventory.add_host('test_host7')
    inventory.add_host('test_host8')
    inventory.add_host('test_host9')
    inventory.add_host('test_host10')
    inventory.add_host('test_host11')
    inventory.add_host('test_host12')
    inventory.add_host('test_host13')
    inventory.add_host('test_host14')

# Generated at 2022-06-16 21:36:40.359454
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('127.0.0.3')
    assert inventory.get_host('127.0.0.2') != inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.3') != inventory.get_host('127.0.0.1')

# Generated at 2022-06-16 21:36:50.334752
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.reconcile_inventory()
    assert inventory.get_host('host1').get_groups() == [inventory.groups['all'], inventory.groups['group1']]
    assert inventory.get_host('host2').get_groups() == [inventory.groups['all'], inventory.groups['group1']]


# Generated at 2022-06-16 21:37:02.333541
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("test")
    assert inventory.groups["test"].name == "test"


# Generated at 2022-06-16 21:37:12.785209
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:37:26.189774
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')

# Generated at 2022-06-16 21:37:35.723522
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('test_group')
    inventory.add_host('test_host', 'test_group')
    inventory.add_host('test_host2', 'test_group')
    inventory.add_host('test_host3', 'test_group')
    inventory.add_host('test_host4', 'test_group')
    inventory.add_host('test_host5', 'test_group')
    inventory.add_host('test_host6', 'test_group')
    inventory.add_host('test_host7', 'test_group')
    inventory.add_host('test_host8', 'test_group')
    inventory.add_host('test_host9', 'test_group')
    inventory.add_host('test_host10', 'test_group')
   

# Generated at 2022-06-16 21:37:48.972228
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:37:58.714122
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert 'test_host' in inventory.get_host('test_host').get_groups()
    assert 'test_host' in inventory.get_host('test_host').get_groups()
    assert 'test_host' in inventory.get_host('test_host').get_groups()
    assert 'test_host' in inventory.get_

# Generated at 2022-06-16 21:38:04.515282
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:38:17.310835
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('testhost')
    assert 'testhost' in inv.hosts
    assert inv.hosts['testhost'].name == 'testhost'
    assert inv.hosts['testhost'].port is None
    assert inv.hosts['testhost'].vars == {}
    assert inv.hosts['testhost'].groups == []

    inv.add_host('testhost2', port=22)
    assert 'testhost2' in inv.hosts
    assert inv.hosts['testhost2'].name == 'testhost2'
    assert inv.hosts['testhost2'].port == 22
    assert inv.hosts['testhost2'].vars == {}
    assert inv.hosts['testhost2'].groups == []


# Generated at 2022-06-16 21:38:20.190508
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = "test_group"
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups


# Generated at 2022-06-16 21:38:26.451518
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv_data = InventoryData()
    inv_data.add_host('localhost')
    inv_data.add_host('localhost', 'group1')
    inv_data.add_host('localhost', 'group2')
    inv_data.add_host('localhost', 'group3')
    inv_data.add_host('localhost', 'group4')
    inv_data.add_host('localhost', 'group5')
    inv_data.add_host('localhost', 'group6')
    inv_data.add_host('localhost', 'group7')
    inv_data.add_host('localhost', 'group8')
    inv_data.add_host('localhost', 'group9')
    inv_data.add_host('localhost', 'group10')
    inv_data.add_host('localhost', 'group11')
    inv

# Generated at 2022-06-16 21:38:44.635771
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=2222)
    assert inventory_data.hosts['localhost'].port == 2222
    inventory_data.add_host('localhost', port=None)
    assert inventory_data.hosts['localhost'].port is None

# Generated at 2022-06-16 21:38:56.647752
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_group('group1')
    inventory_data.add_child('group1', 'localhost')
    inventory_data.reconcile_inventory()
    assert inventory_data.groups['group1'].get_hosts()[0].name == 'localhost'
    assert inventory_data.groups['all'].get_hosts()[0].name == 'localhost'
    assert inventory_data.groups['ungrouped'].get_hosts()[0].name == 'localhost'
    assert inventory_data.hosts['localhost'].get_groups()[0].name == 'group1'
    assert inventory_data.hosts['localhost'].get_groups()[1].name == 'all'
    assert inventory_data.host

# Generated at 2022-06-16 21:39:06.794995
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=None)
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port='22')
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port='22')


# Generated at 2022-06-16 21:39:17.788836
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert 'test_host' in inventory.groups['all'].get_hosts()
    assert 'test_host' in inventory.groups['ungrouped'].get_hosts()
    assert 'test_host' in inventory.get_groups_dict()['all']
    assert 'test_host' in inventory.get_groups_dict()['ungrouped']
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.hosts['test_host'].get_vars() == {}
    assert inventory.hosts

# Generated at 2022-06-16 21:39:24.903030
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.hosts['test_host'].port is None
    inventory.add_host('test_host_2', port=22)
    assert 'test_host_2' in inventory.hosts
    assert inventory.hosts['test_host_2'].name == 'test_host_2'
    assert inventory.hosts['test_host_2'].port == 22


# Generated at 2022-06-16 21:39:35.238027
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'group1')
    inventory.add_child('group3', 'group2')
    inventory.reconc

# Generated at 2022-06-16 21:39:42.654606
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert 'test_host' in inventory.hosts
    assert 'test_group' in inventory.groups
    assert 'test_host' in inventory.groups['test_group'].get_hosts()
    assert 'test_group' in inventory.hosts['test_host'].get_groups()
    assert 'test_group' in inventory.hosts['test_host'].get_groups()

# Generated at 2022-06-16 21:39:49.230778
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host', 'test_group')
    assert inventory_data.hosts['test_host'].name == 'test_host'
    assert inventory_data.groups['test_group'].name == 'test_group'
    assert inventory_data.groups['test_group'].get_hosts()[0].name == 'test_host'


# Generated at 2022-06-16 21:39:58.452037
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost', 'all')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.groups['all'].get_hosts()[0].name == 'localhost'
    assert inv.groups['all'].get_children_groups() == []
    assert inv.groups['all'].get_hosts()[0].get_groups()[0].name == 'all'
    assert inv.groups['all'].get_hosts()[0].get_groups()[0].get_hosts()[0].name == 'localhost'
    assert inv.groups['all'].get_hosts()[0].get_groups()[0].get_hosts()[0].get_groups()[0].name == 'all'

# Generated at 2022-06-16 21:40:09.560305
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == []
    assert inventory.hosts['localhost'].implicit == False
    assert inventory.hosts['localhost'].address == None
    assert inventory.hosts['localhost'].port == None
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == [inventory.hosts['localhost']]

# Generated at 2022-06-16 21:40:33.969825
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5', 'group1')
    inventory.add_host('host6', 'group2')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9', 'group1')
    inventory.add_host('host10', 'group2')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13', 'group1')

# Generated at 2022-06-16 21:40:46.544344
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost', 'all')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].vars == {}
    assert inventory.hosts['localhost'].groups == [inventory.groups['all']]
    assert inventory.groups['all'].hosts == [inventory.hosts['localhost']]
    assert inventory.groups['all'].children == []
    assert inventory.groups['all'].vars == {}
    assert inventory.groups['all'].parents == []
    assert inventory.groups['all'].name == 'all'
    assert inventory.groups['all'].depth == 0
    assert inventory.groups['all'].implicit == False

# Generated at 2022-06-16 21:40:58.939459
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.reconcile_inventory()

# Generated at 2022-06-16 21:41:09.858768
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:41:17.754642
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost')

# Generated at 2022-06-16 21:41:26.022047
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('group1')
    inventory.add_child('group1', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.hosts['localhost'].get_groups() == [inventory.groups['all'], inventory.groups['group1'], inventory.groups['ungrouped']]
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['ungrouped'].get_hosts() == []
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['localhost']]
    assert inventory.groups['all'].get_children() == [inventory.groups['group1'], inventory.groups['ungrouped']]

# Generated at 2022-06-16 21:41:32.879099
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('all')
    inventory_data.add_group('ungrouped')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group2')
    inventory_data.add_host('host3', 'group3')
    inventory_data.add_host('host4', 'group1')
    inventory_data.add_host('host5', 'group2')
    inventory_data.add_host('host6', 'group3')
    inventory_data.add_host('host7', 'group1')
    inventory_data.add

# Generated at 2022-06-16 21:41:39.624006
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('test_host', 'test_group')
    assert inventory.hosts['test_host'].name == 'test_host'
    assert inventory.groups['test_group'].name == 'test_group'
    assert inventory.groups['test_group'].get_hosts()[0].name == 'test_host'
    assert inventory.hosts['test_host'].get_groups()[0].name == 'test_group'


# Generated at 2022-06-16 21:41:48.673106
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['all'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2'], inventory.hosts['host3']]

# Generated at 2022-06-16 21:41:54.597669
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    assert inventory.hosts['host1'].name == 'host1'
    assert inventory.groups['group1'].name == 'group1'
    assert inventory.hosts['host1'] in inventory.groups['group1'].get_hosts()


# Generated at 2022-06-16 21:42:23.406117
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1'], inventory.hosts['host2']]

# Generated at 2022-06-16 21:42:30.567882
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups
    assert 'test_group' in inventory.groups['all'].child_groups
    assert 'test_group' in inventory.groups['ungrouped'].child_groups


# Generated at 2022-06-16 21:42:34.122139
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group("test_group")
    assert inventory_data.groups["test_group"].name == "test_group"


# Generated at 2022-06-16 21:42:43.750962
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=22)
    assert inventory_data.hosts['localhost'].port == 22
    inventory_data.add_host('localhost', port=None)
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=None)
    assert inventory_data.hosts['localhost'].port is None
    inventory_data.add_host('localhost', port=22)


# Generated at 2022-06-16 21:42:46.555819
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group_name = "test_group"
    inventory.add_group(group_name)
    assert group_name in inventory.groups


# Generated at 2022-06-16 21:42:57.003823
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_group('group5')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group1', 'host3')
    inventory.add_child('group2', 'host4')
    inventory.add_child('group2', 'host5')