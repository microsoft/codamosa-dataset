

# Generated at 2022-06-16 21:33:23.808881
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].address == '127.0.0.1'
    assert inventory.hosts['localhost'].port is None
    assert inventory.hosts['localhost'].implicit is True
    assert inventory.hosts['localhost'].vars['ansible_python_interpreter'] == sys.executable
    assert inventory.hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inventory.hosts['localhost'].vars['inventory_file'] is None
    assert inventory.hosts['localhost'].vars['inventory_dir'] is None

# Generated at 2022-06-16 21:33:34.428555
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group2", "host2")
    inventory.add_child("group1", "group2")

    assert inventory.hosts["host1"].name == "host1"
    assert inventory.hosts["host2"].name == "host2"
    assert inventory.groups["group1"].name == "group1"
    assert inventory.groups["group2"].name == "group2"
    assert inventory.groups["group1"].get_hosts()[0].name == "host1"

# Generated at 2022-06-16 21:33:46.443151
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_group("group1")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.remove_host(inventory.hosts["host1"])
    assert "host1" not in inventory.hosts
    assert "host1" not in inventory.groups["group1"].hosts
    assert "host1" not in inventory.groups["group1"].children
    assert "host1" not in inventory.groups["ungrouped"].hosts
    assert "host1" not in inventory.groups["ungrouped"].children
    assert "host1" not in inventory.groups["all"].hosts

# Generated at 2022-06-16 21:33:58.465054
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.add_child('group1', 'group2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'group2' not in inventory.groups['group1'].child_groups


# Generated at 2022-06-16 21:34:07.474079
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_host("host3")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_group("group3")
    inventory.add_child("group1", "host1")
    inventory.add_child("group1", "host2")
    inventory.add_child("group2", "host2")
    inventory.add_child("group2", "host3")
    inventory.add_child("group3", "host1")
    inventory.add_child("group3", "host3")
    inventory.remove_host(inventory.hosts["host2"])
    assert inventory.hosts["host2"] is None

# Generated at 2022-06-16 21:34:13.732496
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts
    assert 'host2' in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:34:18.396524
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts
    assert 'host2' in inventory.groups['group2'].hosts

# Generated at 2022-06-16 21:34:23.237735
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:34:28.013126
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host3')
    assert inventory.hosts['host1'].get_groups() == [inventory.groups['group1'], inventory.groups['all']]
    assert inventory.hosts['host2'].get_groups() == [inventory.groups['group1'], inventory.groups['group2'], inventory.groups['all']]
    assert inventory

# Generated at 2022-06-16 21:34:37.025995
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:34:47.010742
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port='22')
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:34:57.745659
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:35:10.760670
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group3', 'host1')
    inventory.add_child('group3', 'group1')
    inventory.add_child('group3', 'group2')
    inventory.add_child('group1', 'group2')

# Generated at 2022-06-16 21:35:20.069209
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host("test_host")
    assert inv.hosts["test_host"].name == "test_host"
    assert inv.hosts["test_host"].port is None
    assert inv.hosts["test_host"].vars == {}
    assert inv.hosts["test_host"].groups == []
    assert inv.hosts["test_host"].implicit is False
    assert inv.hosts["test_host"].address is None
    assert inv.hosts["test_host"].get_groups() == []
    assert inv.hosts["test_host"].get_vars() == {}
    assert inv.hosts["test_host"].get_group_vars() == {}
    assert inv.hosts["test_host"].get_group_vari

# Generated at 2022-06-16 21:35:33.485902
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inv_data = InventoryData()
    inv_data.add_host('localhost')
    inv_data.add_host('127.0.0.1')
    inv_data.add_host('127.0.0.2')
    inv_data.add_host('127.0.0.3')
    inv_data.add_host('127.0.0.4')
    inv_data.add_host('127.0.0.5')
    inv_data.add_host('127.0.0.6')
    inv_data.add_host('127.0.0.7')
    inv_data.add_host('127.0.0.8')
    inv_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:35:44.376906
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group3', 'host3')
    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    inventory.reconcile_inventory()
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host1']]
    assert inventory.groups['group2'].get_host

# Generated at 2022-06-16 21:35:56.675187
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:36:04.109023
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert inventory_data.hosts['localhost'].name == 'localhost'
    assert inventory_data.hosts['localhost'].address == '127.0.0.1'
    assert inventory_data.hosts['localhost'].implicit == True
    assert inventory_data.hosts['localhost'].vars['ansible_python_interpreter'] == sys.executable
    assert inventory_data.hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inventory_data.hosts['localhost'].vars['inventory_file'] == None
    assert inventory_data.hosts['localhost'].vars['inventory_dir'] == None

# Generated at 2022-06-16 21:36:16.337004
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    assert inventory.add_group('test') == 'test'
    assert inventory.add_group('test') == 'test'
    assert inventory.add_group('test2') == 'test2'
    assert inventory.add_group('test3') == 'test3'
    assert inventory.add_group('test4') == 'test4'
    assert inventory.add_group('test5') == 'test5'
    assert inventory.add_group('test6') == 'test6'
    assert inventory.add_group('test7') == 'test7'
    assert inventory.add_group('test8') == 'test8'
    assert inventory.add_group('test9') == 'test9'
    assert inventory.add_group('test10') == 'test10'

# Generated at 2022-06-16 21:36:24.112628
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert inventory.hosts['host1'] is None
    assert inventory.groups['group1'].get_hosts() == [inventory.hosts['host2']]

# Generated at 2022-06-16 21:36:38.093544
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')

    assert inventory.get_host('localhost') == inventory.get_host('127.0.0.1')
    assert inventory.get_host('127.0.0.1') != inventory.get_host('127.0.0.2')


# Generated at 2022-06-16 21:36:48.509406
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')
    inventory.add_host('127.0.0.1', 'test')

# Generated at 2022-06-16 21:36:57.658097
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('127.0.0.2')
    inventory_data.add_host('127.0.0.3')
    inventory_data.add_host('127.0.0.4')
    inventory_data.add_host('127.0.0.5')
    inventory_data.add_host('127.0.0.6')
    inventory_data.add_host('127.0.0.7')
    inventory_data.add_host('127.0.0.8')
    inventory_data.add_host('127.0.0.9')

# Generated at 2022-06-16 21:37:09.655520
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_group('group3')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group2', 'host3')
    inventory_data.add_child('group3', 'host3')
    inventory_data.add_child('group3', 'host1')
    inventory_data.reconcile_

# Generated at 2022-06-16 21:37:17.126461
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.0.5")
    inventory.add_host("127.0.0.6")
    inventory.add_host("127.0.0.7")
    inventory.add_host("127.0.0.8")
    inventory.add_host("127.0.0.9")
    inventory.add_host("127.0.0.10")
    inventory.add_host("127.0.0.11")
    inventory.add_host

# Generated at 2022-06-16 21:37:26.809988
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host("host1")
    inventory.add_host("host2")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_child("group1", "host1")
    inventory.add_child("group2", "host2")
    inventory.remove_host(inventory.hosts["host1"])
    assert "host1" not in inventory.hosts
    assert "host1" not in inventory.groups["group1"].hosts
    assert "host2" in inventory.hosts
    assert "host2" in inventory.groups["group2"].hosts


# Generated at 2022-06-16 21:37:37.941158
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:37:51.427884
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None

# Generated at 2022-06-16 21:37:59.958545
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts
    assert 'host2' in inventory.groups['group2'].hosts
    inventory

# Generated at 2022-06-16 21:38:05.390546
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory.add_host('localhost')
    inventory

# Generated at 2022-06-16 21:38:19.607143
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group2', 'host2')
    inventory.add_child('group2', 'host1')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].get_hosts()
    assert 'host1' not in inventory.groups['group2'].get_hosts()

# Generated at 2022-06-16 21:38:25.204959
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:38:34.507001
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:38:37.021943
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test')
    assert 'test' in inventory.groups


# Generated at 2022-06-16 21:38:39.677649
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups


# Generated at 2022-06-16 21:38:47.414451
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:38:55.098273
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:39:05.845667
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:39:11.811261
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host("localhost")
    inventory.add_host("127.0.0.1")
    inventory.add_host("127.0.0.2")
    inventory.add_host("127.0.0.3")
    inventory.add_host("127.0.0.4")
    inventory.add_host("127.0.0.5")
    inventory.add_host("127.0.0.6")
    inventory.add_host("127.0.0.7")
    inventory.add_host("127.0.0.8")
    inventory.add_host("127.0.0.9")
    inventory.add_host("127.0.0.10")
    inventory.add_host("127.0.0.11")
    inventory.add_host

# Generated at 2022-06-16 21:39:21.686491
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:39:31.827068
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group('test_group')
    assert inventory.groups['test_group'].name == 'test_group'


# Generated at 2022-06-16 21:39:41.266236
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    host = inventory_data.get_host('localhost')
    assert host.name == 'localhost'
    assert host.address == '127.0.0.1'
    assert host.implicit == True
    assert host.vars['ansible_python_interpreter'] == sys.executable
    assert host.vars['ansible_connection'] == 'local'
    assert host.vars['inventory_file'] == None
    assert host.vars['inventory_dir'] == None


# Generated at 2022-06-16 21:39:49.339351
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.get_host('test_host') in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.get_host('test_host'))
    assert inventory.get_host('test_host') not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:39:58.543106
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('all')
    inventory.add_group('ungrouped')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_child('all', 'group1')
    inventory.add_child('all', 'group2')
    inventory.add_child('all', 'group3')
    inventory.add_child('all', 'group4')
    inventory.add

# Generated at 2022-06-16 21:40:09.592770
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host1', group='group1')
    inventory.add_host('host2', group='group1')
    inventory.add_host('host3', group='group2')
    inventory.add_host('host4', group='group2')
    inventory.add_host('host5', group='group3')
    inventory.add_host('host6', group='group3')
    inventory.add_host('host7', group='group3')
    inventory.add_host('host8', group='group4')
    inventory.add_host('host9', group='group4')
    inventory.add_host('host10', group='group4')
    inventory.add_host('host11', group='group4')
    inventory.add_host('host12', group='group5')


# Generated at 2022-06-16 21:40:21.721494
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:40:30.138688
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:40:42.014908
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    host = inventory.get_host('127.0.0.1')
    assert host.name == '127.0.0.1'
    assert host.address == '127.0.0.1'
    assert host.implicit == True
    assert host.vars['ansible_python_interpreter'] == sys.executable
    assert host.vars['ansible_connection'] == 'local'
    assert inventory.localhost == host
    assert inventory.get_host('127.0.0.1') == host
    assert inventory.get_host('127.0.0.1') == inventory.localhost
    assert inventory.get_host('127.0.0.1') == inventory.get_host('127.0.0.1')

# Generated at 2022-06-16 21:40:52.021882
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:41:03.061505
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_host('127.0.0.1')
    inventory.add_host('127.0.0.2')
    inventory.add_host('127.0.0.3')
    inventory.add_host('127.0.0.4')
    inventory.add_host('127.0.0.5')
    inventory.add_host('127.0.0.6')
    inventory.add_host('127.0.0.7')
    inventory.add_host('127.0.0.8')
    inventory.add_host('127.0.0.9')
    inventory.add_host('127.0.0.10')
    inventory.add_host('127.0.0.11')
    inventory.add_host

# Generated at 2022-06-16 21:41:13.849631
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # Create inventory data object
    inventory_data = InventoryData()

    # Create a host object
    host = Host('test_host')

    # Add host to inventory data
    inventory_data.add_host(host.name)

    # Remove host from inventory data
    inventory_data.remove_host(host)

    # Check if host is removed from inventory data
    assert host.name not in inventory_data.hosts

# Generated at 2022-06-16 21:41:20.664735
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert(inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts())
    inventory.remove_host(inventory.hosts['test_host'])
    assert(inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts())

# Generated at 2022-06-16 21:41:29.958647
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    inv.add_host('localhost')
    inv.add_host('localhost', 'group1')
    inv.add_host('localhost', 'group1')
    inv.add_host('localhost', 'group2')
    inv.add_host('localhost', 'group2')
    inv.add_host('localhost', 'group2')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group3')
    inv.add_host('localhost', 'group4')
    inv.add_host('localhost', 'group4')
    inv.add_host('localhost', 'group4')
    inv.add

# Generated at 2022-06-16 21:41:41.178153
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')

# Generated at 2022-06-16 21:41:49.613959
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].vars['inventory_file'] == None
    assert inv.hosts['localhost'].vars['inventory_dir'] == None
    assert inv.hosts['localhost'].vars['ansible_python_interpreter'] == '/usr/bin/python'
    assert inv.hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inv.hosts['localhost'].vars['ansible_ssh_host'] == '127.0.0.1'
    assert inv.hosts['localhost'].vars['ansible_ssh_port'] == 22

# Generated at 2022-06-16 21:42:00.314747
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('localhost')
    assert inv.hosts['localhost'].name == 'localhost'
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port=22)
    assert inv.hosts['localhost'].port == 22
    inv.add_host('localhost', port=2222)
    assert inv.hosts['localhost'].port == 2222
    inv.add_host('localhost', port=None)
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port='')
    assert inv.hosts['localhost'].port is None
    inv.add_host('localhost', port='22')
    assert inv.hosts['localhost'].port == 22

# Generated at 2022-06-16 21:42:08.804324
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('test_host')
    inventory.add_group('test_group')
    inventory.add_child('test_group', 'test_host')
    assert inventory.hosts['test_host'] in inventory.groups['test_group'].get_hosts()
    inventory.remove_host(inventory.hosts['test_host'])
    assert inventory.hosts['test_host'] not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:42:20.402628
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_host('host3')
    inventory.add_host('host4')
    inventory.add_host('host5')
    inventory.add_host('host6')
    inventory.add_host('host7')
    inventory.add_host('host8')
    inventory.add_host('host9')
    inventory.add_host('host10')
    inventory.add_host('host11')
    inventory.add_host('host12')
    inventory.add_host('host13')
    inventory.add_host('host14')
    inventory.add_host('host15')
    inventory.add_host('host16')
    inventory.add_host('host17')
    inventory.add_

# Generated at 2022-06-16 21:42:29.273585
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    inventory.add_host('host1')
    inventory.add_host('host2')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1', 'host1')
    inventory.add_child('group1', 'host2')
    inventory.add_child('group2', 'host2')
    inventory.remove_host(inventory.hosts['host1'])
    assert 'host1' not in inventory.hosts
    assert 'host1' not in inventory.groups['group1'].hosts
    assert 'host1' not in inventory.groups['group2'].hosts
    assert 'host2' in inventory.hosts
    assert 'host2' in inventory.groups['group1'].hosts

# Generated at 2022-06-16 21:42:34.339434
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()

    # add a host
    inventory.add_host('test_host')
    assert 'test_host' in inventory.hosts

    # add a group
    inventory.add_group('test_group')
    assert 'test_group' in inventory.groups

    # add host to group
    inventory.add_child('test_group', 'test_host')
    assert 'test_host' in inventory.groups['test_group'].get_hosts()

    # remove host
    inventory.remove_host(inventory.hosts['test_host'])
    assert 'test_host' not in inventory.hosts
    assert 'test_host' not in inventory.groups['test_group'].get_hosts()

# Generated at 2022-06-16 21:42:52.111808
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert inventory.hosts['localhost'].name == 'localhost'
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port=2222)
    assert inventory.hosts['localhost'].port == 2222
    inventory.add_host('localhost', port=None)
    assert inventory.hosts['localhost'].port is None
    inventory.add_host('localhost', port=22)
    assert inventory.hosts['localhost'].port == 22
    inventory.add_host('localhost', port='')
    assert inventory.hosts['localhost'].port is None