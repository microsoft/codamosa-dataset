

# Generated at 2022-06-10 23:56:51.311884
# Unit test for method remove_host of class InventoryData

# Generated at 2022-06-10 23:57:05.257253
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    group1 = inventory.add_group('mysql')
    group2 = inventory.add_group('mongo')
    host1 = inventory.add_host('server1')
    host2 = inventory.add_host('server2')
    host3 = inventory.add_host('server3')
    host4 = inventory.add_host('server4')
    inventory.add_child(group1, host1)
    inventory.add_child(group1, host2)
    inventory.add_child(group1, host3)
    inventory.add_child(group2, host2)
    inventory.add_child(group2, host3)
    inventory.add_child(group2, host4)
    inventory.remove_host(host2)


# Generated at 2022-06-10 23:57:14.887087
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    inv.add_host('host_name')
    assert(len(inv.hosts) == 1)
    assert(len(inv.groups) == 2)
    assert('host_name' in inv.hosts)
    assert('all' in inv.groups)
    assert('ungrouped' in inv.groups)
    assert(inv.groups['ungrouped'].get_hosts()[0].name == 'host_name')

    host = inv.hosts['host_name']
    inv.remove_host(host)
    assert(len(inv.hosts) == 0)
    assert(len(inv.groups) == 2)
    assert('host_name' not in inv.hosts)
    assert('all' in inv.groups)

# Generated at 2022-06-10 23:57:26.520212
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data_object = InventoryData()
    group_1 = 'group1'
    group_2 = 'group2'
    host_1 = 'host1'
    group_1_add_child_group_2_result = inventory_data_object.add_child(group_1, group_2)
    assert(group_1_add_child_group_2_result == False)
    host_1_add_child_group_2_result = inventory_data_object.add_child(host_1, group_2)
    assert(host_1_add_child_group_2_result == False)
    host_1_add_child_host1_result = inventory_data_object.add_child(host_1, host_1)

# Generated at 2022-06-10 23:57:35.466033
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    '''Tests for inventory add_child method
    '''
    i = InventoryData()
    i.add_host('testhost')
    i.add_group('supergroup')
    i.add_child('supergroup', 'testhost')
    if 'testhost' not in i.groups['supergroup'].get_hosts():
        raise Exception(
            'Supergroup not added to testhost')
    i.add_group('supergroup1')
    i.add_group('supergroup2')
    i.add_child('supergroup1', 'supergroup2')
    if 'supergroup2' not in i.groups['supergroup1'].get_hosts():
        raise Exception(
            'Supergroup2 not added to supergroup1')

# Generated at 2022-06-10 23:57:45.281625
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')

    assert len(inventory_data.hosts) == 1
    assert inventory_data.hosts['host1'].name == 'host1'
    assert len(inventory_data.groups) == 3
    assert inventory_data.groups['group1'].name == 'group1'
    assert len(inventory_data.groups['group1'].get_hosts()) == 1
    assert len(inventory_data.groups['all'].get_hosts()) == 1
    assert len(inventory_data.groups['ungrouped'].get_hosts()) == 0


# Generated at 2022-06-10 23:57:52.635272
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Prepare
    inventory = InventoryData()
    hostname = '192.168.1.1'
    groupname = 'group'

    # Act
    inventory.add_host(hostname, groupname)

    # Assert
    assert hostname in inventory.hosts
    assert groupname in inventory.groups
    assert groupname in inventory.hosts[hostname].get_groups()
    assert hostname in inventory.groups[groupname].get_hosts()


# Generated at 2022-06-10 23:58:03.412857
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # First initialize and populate the InventoryData class
    inv = InventoryData()
    inv.add_group('g1')
    inv.add_group('g2')
    inv.add_host('h1')
    inv.add_host('h2')
    inv.add_child('g1', 'h1')
    inv.add_child('g2', 'h2')
    inv.reconcile_inventory()
    assert inv.groups['g1'].get_hosts()[0].name == 'h1'
    assert inv.groups['g2'].get_hosts()[0].name == 'h2'
    assert inv.groups['ungrouped'].get_hosts()[0].name == 'h1'
    assert inv.groups['ungrouped'].get_hosts()[1].name

# Generated at 2022-06-10 23:58:08.896792
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():

    i = InventoryData()
    i.add_host("1.1.1.1")
    assert i.get_host("1.1.1.1") is i.hosts["1.1.1.1"]
    assert i.get_host("localhost") is i.localhost
    assert i.get_host("127.0.0.1") is i.localhost
    assert i.get_host("nohost") is None

# Generated at 2022-06-10 23:58:23.354146
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    c = InventoryData()
    c.add_group('group1')
    c.add_host('host1')
    c.add_host('host2')
    c.add_host('host3')
    c.add_host('host4')
    c.add_host('host5')
    c.add_host('host6')
    c.add_child('group1', 'host1')
    c.add_child('group1', 'host2')
    c.add_child('group1', 'host3')
    c.add_child('group1', 'host4')
    c.add_child('group1', 'host5')
    c.add_child('group1', 'host6')
    c.remove_host(c.get_host('host1'))

# Generated at 2022-06-10 23:58:36.030039
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    inventory_manager = InventoryManager(InventoryData(), PlayContext())
    test_InventoryData_add_host_helper(inventory_manager, "test_inventory_data")
    test_InventoryData_add_host_helper(inventory_manager, "test_inventory_data2")
    test_InventoryData_add_host_helper(inventory_manager, "test_inventory_data3")
    test_InventoryData_add_host_helper(inventory_manager, "test_inventory_data4")


# Generated at 2022-06-10 23:58:44.559525
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()

    inventory.add_group("test-group")
    group = inventory.groups["test-group"]
    # Create 2 hosts
    inventory.add_host("host1")
    inventory.add_host("host2")
    host1 = inventory.hosts["host1"]
    host2 = inventory.hosts["host2"]

    # Add hosts to the group
    group.add_host(host1)
    group.add_host(host2)

    # Let's check if the hosts are added to the group
    assert len(group.hosts) == 2

    # Remove the first host from the inventory
    inventory.remove_host(host1)

    # Let's check if the group is updated as well
    assert len(group.hosts) == 1

# Generated at 2022-06-10 23:58:45.159674
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    return None

# Generated at 2022-06-10 23:58:57.455061
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # set up the test
    id = InventoryData()

    # test 1:
    test1_host = Host('test1_host')
    id.hosts['test1_host'] = test1_host
    test1_host.groups.add(id.groups['all'])
    id.groups['all'].hosts.add(test1_host)
    test1_host.groups.add(id.groups['ungrouped'])
    id.groups['ungrouped'].hosts.add(test1_host)
    id.reconcile_inventory()
    # verify that host test1_host is still in group 'all' and 'ungrouped'
    assert('all' in test1_host.groups_names)
    assert('ungrouped' in test1_host.groups_names)

# Generated at 2022-06-10 23:59:09.432094
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    Inventory = InventoryData()

    # test remove host
    Inventory.add_host("test_host", None, None)
    Inventory.add_host("test_host2", None, None)
    Inventory.remove_host(Inventory.hosts["test_host"])
    assert("test_host" not in Inventory.hosts)

    # test remove host with groups
    Inventory.add_host("test_host_group", None, None)
    Inventory.add_group("test_group")
    Inventory.add_child("test_group", "test_host_group")
    Inventory.remove_host(Inventory.hosts["test_host_group"])
    assert("test_host_group" not in Inventory.hosts)


# Generated at 2022-06-10 23:59:21.254786
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    i = InventoryData()

    # testing new host with group param
    hostname = "test_host1"
    group_name = "test_group1"
    port = 22
    i.add_host(hostname, group=group_name, port=port)
    assert hostname in i.hosts
    host_obj = i.hosts.get(hostname, None)
    assert host_obj.name == hostname
    assert host_obj.port == port
    assert group_name in i.groups
    group_obj = i.groups.get(group_name, None)
    assert group_name in group_obj.child_groups
    assert host_name in group_obj.hosts
    assert group_obj.hosts == host_obj

    # testing new host without group param

# Generated at 2022-06-10 23:59:33.649787
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # create a host
    myhost_data = {'variable_manager': {'_fact_cache': {}},
                   'errors': [],
                   'name': 'foo',
                   'vars': {}}
    myhost = Host(**myhost_data)

    # create an group
    mygroup_data = {'variable_manager': {},
                    'name': 'mygroup',
                    'hosts': {}}
    mygroup = Group(**mygroup_data)

    # create an inventory
    inventory = InventoryData()

    # add myhost to inventory
    inventory.hosts[myhost.name] = myhost
    # add mygroup to inventory
    inventory.groups[mygroup.name] = mygroup

    # call reconcile_inventory method
    inventory.reconcile_inventory()

    # test if mygroup is

# Generated at 2022-06-10 23:59:35.667837
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('localhost')
    assert 'localhost' in inventory.hosts

# Generated at 2022-06-10 23:59:47.370404
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryData()
    host = Host('localhost', port=None)

    group1 = 'group1'
    group2 = 'group2'
    inventory.add_group(group1)
    inventory.add_group(group2)

    inventory.add_host(host.name, group=group1)
    inventory.add_host(host.name, group=group2)

    # Should have host in both groups
    assert host in inventory.groups[group1].get_hosts()
    assert host in inventory.groups[group2].get_hosts()

    # Should have a host in both groups
    assert host in inventory.groups[group1].get_hosts()

# Generated at 2022-06-11 00:00:00.112623
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    from ansible.inventory.vars_plugins.group_vars import group_vars_playbook
    from ansible.inventory.vars_plugins.host_vars import host_vars_playbook

    test_hosts = ['host1.example.com', 'host2.example.com']
    test_groups = ['group1', 'group2']

    inv = InventoryData(host_list=test_hosts, group_list=test_groups)

    for host in test_hosts:
        inv.set_variable(host, 'test_var', 'test_var_value')
    for group in test_groups:
        inv.set_variable(group, 'test_var', 'test_var_value')

    group_vars_playbook.push_host(inv)

# Generated at 2022-06-11 00:00:20.114219
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()

    # Case 1: Assert that the host is added to the inventory
    assert inventory.add_host(host="test_host_1") == "test_host_1"

    # Case 2: Assert that the host is added to the inventory
    assert inventory.add_host(host="test_host_2", group="test_group_1") == "test_host_2"

    # Case 3: Assert that the host is added to the inventory
    assert inventory.add_host(host="test_host_3", group="test_group_1", port=22) == "test_host_3"

    # Case 4: Assert that the host is added to the inventory

# Generated at 2022-06-11 00:00:27.049204
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Create InventoryData object
    o = InventoryData()

    # Add a host 'host1.example.com' to inventory
    o.add_host('host1.example.com')

    # Check if the host 'host1.example.com' exists in the inventory
    assert 'host1.example.com' in o.hosts.keys()


# Generated at 2022-06-11 00:00:37.929060
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # create groups
    g1 = Group('G1')
    g2 = Group('G2')
    g3 = Group('G3')
    g4 = Group('G4')

    # create hosts
    h1 = Host('H1')
    h2 = Host('H2')
    h3 = Host('H3')
    h4 = Host('H4')

    # create inventory data
    inv_data = InventoryData()
    inv_data.groups = {'G1': g1, 'G2': g2, 'G3': g3, 'G4': g4}
    inv_data.hosts = {'H1': h1, 'H2': h2, 'H3': h3, 'H4': h4}

    # test adding a host to the following groups
    inv_data.add_host

# Generated at 2022-06-11 00:00:40.760909
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    groupname = 'testgroup1'
    inventory.add_group(groupname)
    group = inventory.groups.get(groupname)
    assert group
    assert group.name==groupname


# Generated at 2022-06-11 00:00:53.698694
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole

    # Create a playbook to test the behavior of add_host
    play = Play()
    play.hosts = "test_inventory_host"
    play.name = "test_inventory_host"
    play.tasks = [Task()]
    play.tasks[0].action = "test_inventory_test"
    play.tasks[0].args = {}
    play.tasks[0].delegate_to = None
    play.tasks[0].name = "test_inventory_test"

    blocks = [Block()]
    blocks[0].block = play

# Generated at 2022-06-11 00:01:05.107199
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    data = InventoryData()
    data.add_host('host1')
    assert data.hosts['host1']
    assert data.groups['all'].get_hosts() == data.hosts.values()
    assert data.groups['ungrouped'].get_hosts() == [data.hosts['host1']]
    data.add_host('host2', 'group1')
    assert data.groups['group1'].get_hosts() == [data.hosts['host2']]
    assert data.groups['ungrouped'].get_hosts() == [data.hosts['host1']]


# Generated at 2022-06-11 00:01:14.743610
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('host1', 'group1')
    inventory.add_host('host2', 'group1')
    inventory.add_host('host1', 'group2')
    inventory.add_host('host2', 'group2')
    inventory.add_host('host1', 'group3')
    inventory.add_host('host2', 'group3')
    inventory.add_host('host1', 'group4')
    inventory.add_host('host2', 'group4')
    inventory.add_host('host1', 'group5')
    inventory.add_host('host2', 'group5')
    inventory.add_child('group2', 'group1')
    inventory.add_child('group3', 'group1')

# Generated at 2022-06-11 00:01:19.637898
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    p = InventoryData()

    p.add_host('test1')
    p.add_host('test2')
    p.add_host('test3')

    assert len(p.hosts) == 3

    assert p.hosts['test1'].name == 'test1'
    assert p.hosts['test2'].name == 'test2'
    assert p.hosts['test3'].name == 'test3'


# Generated at 2022-06-11 00:01:32.404626
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('foo.example.com')
    inventory_data.add_host('foo.example.com', 'group1')
    inventory_data.add_host('bar.example.com', 'group2')
    assert 'foo.example.com' in inventory_data.hosts.keys()
    assert 'bar.example.com' in inventory_data.hosts.keys()
    assert 'group1' in inventory_data.hosts['foo.example.com'].get_groups()
    assert 'group2' in inventory_data.hosts['bar.example.com'].get_groups()
    assert 'group1' in inventory_data.groups.keys()



# Generated at 2022-06-11 00:01:38.693522
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group_name = 'test group'

    inventory.add_group(group_name)

    assert group_name in inventory.groups, 'Should add {group_name} to groups'.format(group_name=group_name)
    assert inventory.groups[group_name].name == group_name, \
        'Saved group name should be the same as the one supplied'

# Generated at 2022-06-11 00:01:54.852108
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("hostname")
    inventory.add_group("group1")
    inventory.add_group("group2")
    inventory.add_group("group3")
    inventory.add_child("group1", "group2")
    inventory.add_child("group2", "group3")
    inventory.add_child("group3", "hostname")
    inventory.reconcile_inventory()
    assert "group2" in inventory.groups["group1"].get_groups()
    assert inventory.groups["group1"].name in inventory.hosts["hostname"].groups
    assert inventory.hosts["hostname"].vars["inventory_dir"] == "."
    assert inventory.hosts["hostname"].vars["inventory_file"] == None

# Generated at 2022-06-11 00:02:04.899988
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()

    # Checking that adding a host with no port specified gives the default port (22)
    inventory.add_host('test')
    assert inventory.get_host('test').port == 22, "Wrong port for 'test'"

    # Checking that adding a host with a custom port gives the port specified
    inventory.add_host('test2', port=3022)
    assert inventory.get_host('test2').port == 3022, "Wrong port for 'test2'"

    # Checking that adding a host with a port identical to the default port (22) ignores the port specified
    inventory.add_host('test3', port=22)
    assert inventory.get_host('test3').port == 22, "Wrong port for 'test3'"


# Generated at 2022-06-11 00:02:14.497951
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('all')
    inventory_data.add_group('ungrouped')
    inventory_data.add_group('foo')
    inventory_data.add_group('bar')
    inventory_data.add_host('localhost', 'all')
    inventory_data.add_host('localhost', 'ungrouped')
    inventory_data.add_host('localhost', 'foo')
    inventory_data.add_host('localhost', 'bar')
    inventory_data.add_host('localhost', 'fake')
    inventory_data.hosts['localhost'].add_group(None)

    inventory_data.reconcile_inventory()

    # ensure no duplicate localhost
    assert inventory_data.localhost is inventory_data.hosts['localhost']

    # ensure localhost is

# Generated at 2022-06-11 00:02:23.009406
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('foo.example.com', 'srv', 666)
    assert inventory_data.get_host('foo.example.com').name == 'foo.example.com'
    assert inventory_data.get_host('foo.example.com').port == 666
    assert inventory_data.add_host('foo.example.com', 'srv') == 'foo.example.com'
    assert inventory_data.add_host('foo.example.com') == 'foo.example.com'
    assert inventory_data.get_host('foo.example.com').port == 666
    assert inventory_data.get_host('foo.example.com').name == 'foo.example.com'
    assert 'foo.example.com' in inventory_data.hosts

# Generated at 2022-06-11 00:02:35.372867
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_obj = InventoryData()
    # Add group group_1 to inventory
    inventory_obj.add_group('group_1')
    inventory_obj.add_host('host_1', 'group_1')
    inventory_obj.add_host('host_2', 'group_1')
    inventory_obj.reconcile_inventory()
    assert len(inventory_obj.hosts)==2 and len(inventory_obj.groups)==3
    # Test if we get the right error message when an invalid group name is supplied to add_group
    try:
        inventory_obj.add_group(['group_test'])
        assert False
    except AnsibleError as e:
        assert e.message.find('Invalid group')>-1 and e.message.find('string but got')>-1
    # Test if we get

# Generated at 2022-06-11 00:02:44.222412
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    i = InventoryData()
    i.add_host('foo')
    i.add_host('bar', 'baz')
    i.add_host('qux', 'baz')
    i.add_group('baz')
    i.add_child('baz', 'qux')
    # we need to call reconcile_inventory to set the group parents
    i.reconcile_inventory()
    assert len(i.groups) == 2
    assert len(i.groups['baz'].get_hosts()) == 2
    assert len(i.groups['ungrouped'].get_hosts()) == 1
    assert len(i.hosts) == 3
    assert i.hosts['foo'] == Host('foo')


# Generated at 2022-06-11 00:02:51.437729
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    group_name = 'groupName'
    host_name = 'hostName'
    inventory.add_host(host_name, group_name)
    assert inventory.hosts[host_name].name == host_name
    assert inventory.hosts[host_name].get_groups()[0].name == group_name
    assert inventory.groups[group_name].get_hosts()[0].name == host_name

# Generated at 2022-06-11 00:02:56.300370
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host(host = 'localhost', group = 'test_group')
    assert 'test_group' in inventory_data.groups
    assert 'localhost' in inventory_data.hosts

    # Add an implicit localhost
    inventory_data.add_host(host = '127.0.0.1', group = 'test_group')
    assert 'test_group' in inventory_data.groups
    assert inventory_data.hosts['localhost'] == inventory_data.hosts['127.0.0.1']

    # Attempt to add a non-string host name
    try:
        inventory_data.add_host(host = 1, group = 'test_group')
        assert False, 'Should not make it here'
    except AnsibleError as e:
        pass

#

# Generated at 2022-06-11 00:03:03.670336
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    display.verbosity = 3
    idt = InventoryData()
    idt.add_group('lmn')
    idt.add_host('alpha','lmn')
    idt.reconcile_inventory()
    assert ('alpha' in idt.hosts)
    assert ('lmn' in idt.groups)
    assert ('alpha' in [h.name for h in idt.get_group('lmn').get_hosts()])

# Generated at 2022-06-11 00:03:06.916416
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    assert inventory_data.add_group('test') == 'test'
    assert inventory_data.add_group('test') == 'test'
    assert len(inventory_data.groups) == 3

# Generated at 2022-06-11 00:03:18.827142
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1', 'group1')
    assert(inventory_data.hosts['host1'].name == 'host1')
    assert(inventory_data.hosts['host1'].port is None)
    assert(inventory_data.hosts['host1'].vars == {})
    assert(inventory_data.hosts['host1'].get_groups() == [inventory_data.groups['all'], inventory_data.groups['group1']])
    assert(inventory_data.groups['group1'].get_hosts() == [inventory_data.hosts['host1']])
    assert(inventory_data.current_source is None)
    assert(inventory_data.processed_sources == [])

# Generated at 2022-06-11 00:03:29.926784
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    invdata = InventoryData()
    invdata.add_host('a')
    invdata.add_host('b')
    invdata.add_host('c')
    invdata.add_group('foo')
    invdata.add_child('foo', 'a')
    invdata.add_child('foo', 'b')
    invdata.add_child('foo', 'c')
    assert invdata.reconcile_inventory()
    assert isinstance(invdata.groups['all'], Group) and invdata.groups['all'].name == 'all'
    assert isinstance(invdata.groups['foo'], Group) and invdata.groups['foo'].name == 'foo'

# Generated at 2022-06-11 00:03:37.373434
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv_data = InventoryData()
    inv_data.add_host("host1", "group1")
    inv_data.add_host("host2", "group2")

    assert "group1" in inv_data.groups
    assert "group2" in inv_data.groups

    group = inv_data.groups["group1"]
    assert "host1" in group.hosts
    assert "host2" not in group.hosts

    group = inv_data.groups["group2"]
    assert "host1" not in group.hosts
    assert "host2" in group.hosts


# Generated at 2022-06-11 00:03:40.685687
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = 'abc'
    inventory_data.add_group(group_name)
    assert(group_name in inventory_data.groups)


# Generated at 2022-06-11 00:03:52.369335
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()

    host = inventory.add_host(host='hostname', group='groupname')
    # Test return value
    assert host == 'hostname'

    # Test additions
    assert host in inventory.hosts
    assert host in inventory.groups['groupname'].hosts

    # Addition of a host that already exists in inventory should not be possible
    host = inventory.add_host(host='hostname', group='groupname')
    # Test return value
    assert host == 'hostname'

    # Test additions
    assert host in inventory.hosts
    assert host in inventory.groups['groupname'].hosts

    # Test additions
    assert len(inventory.hosts) == 1
    assert len(inventory.groups['groupname'].hosts) == 1


# Generated at 2022-06-11 00:04:01.106558
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host("test-host-1")
    assert (inventory.get_host("test-host-1") is not None)
    assert (inventory.get_host("test-host-1").get_groups() == [])

    inventory.add_group("test-group")
    inventory.add_group("test-group-2")
    assert (inventory.groups["test-group"].hosts == [])
    assert (inventory.groups["test-group-2"].hosts == [])

    inventory.add_child("test-group", "test-host-2")
    assert (inventory.groups["test-group"].hosts == [inventory.get_host("test-host-2")])

# Generated at 2022-06-11 00:04:03.988284
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    data = InventoryData()
    data.add_host('1.1.1.1')
    assert data.hosts['1.1.1.1']

# Generated at 2022-06-11 00:04:04.811664
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    pass

# Generated at 2022-06-11 00:04:16.235076
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('group_1')
    inventory_data.add_group('group_2')

    inventory_data.add_host('host_1')
    inventory_data.add_host('host_2')
    inventory_data.add_host('host_3')

    inventory_data.add_child('group_1', 'host_1')
    inventory_data.add_child('group_1', 'host_2')
    inventory_data.add_child('group_2', 'host_2')
    inventory_data.add_child('group_2', 'host_3')

    inventory_data.reconcile_inventory()

    assert 'all' in inventory_data.groups.keys()
    assert 'group_1' in inventory_data.groups.keys()

# Generated at 2022-06-11 00:04:22.532064
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # setup
    groups_filename = 'test/test_data/inventory/test_groups'
    hosts_filename = 'test/test_data/inventory/test_hosts'
    hostvars_filename = 'test/test_data/inventory/test_hostvars'
    groupvars_filename = 'test/test_data/inventory/test_groupvars'

    # create inventory
    inventory = InventoryData()
    # populate with sample data
    inventory.read_inventory(groups_filename, hosts_filename, hostvars_filename, groupvars_filename)
    # add host to group
    inventory.add_host('host1', 'group1')

    # run test code
    inventory.reconcile_inventory()

    # check all and ungrouped, as well as group1 and group2 exist
    assert 'all'

# Generated at 2022-06-11 00:04:36.304352
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # Init
    i = InventoryData()
    group = 'group'
    group1 = 'group1'
    group2 = 'group2'
    group3 = 'group3'
    host = 'host'
    host1 = 'host1'
    host2 = 'host2'
    host3 = 'host3'

    # Create groups
    i.add_group(group)
    i.add_group(group1)
    i.add_group(group2)
    i.add_group(group3)

    # Create hosts
    i.add_host(host)
    i.add_host(host1)
    i.add_host(host2)
    i.add_host(host3)

    # group1 -> group
    # group2 -> group1
    # group3 -> group
    i

# Generated at 2022-06-11 00:04:41.156517
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost')
    assert len(inventory_data.hosts) == 1
    assert 'localhost' in inventory_data.hosts
    assert inventory_data.hosts['localhost'].name == 'localhost'

# Generated at 2022-06-11 00:04:48.707355
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    t_inv = InventoryData()
    # add group
    group1 = t_inv.add_group("group1")
    group2 = t_inv.add_group("group2")
    group3 = t_inv.add_group("group3")
    group4 = t_inv.add_group("group4")
    # add host
    host1 = t_inv.add_host("host1", group=group1)
    host2 = t_inv.add_host("host2", group=group2)
    host3 = t_inv.add_host("host3", group=group3)
    host4 = t_inv.add_host("host4", group=group4)
    host5 = t_inv.add_host("host5", group=group4)
    host6 = t_inv.add_host

# Generated at 2022-06-11 00:05:01.445538
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    inv_data = InventoryData()
    host = "myhost"
    group = "mygroup"
    inv_data.add_host(host, group)
    hosts = inv_data.get_host(host)
    groups = inv_data.groups

    assert hosts.name == host
    assert group in [group.name for group in hosts.groups]
    assert host in groups[group].get_hosts()

    host = "localhost"
    group = "localhost"
    inv_data.add_host(host, group)
    hosts = inv_data.get_host(host)
    groups = inv_data.groups

    assert hosts.name == host
    assert group in [group.name for group in hosts.groups]
    assert host in groups[group].get_hosts()


# Generated at 2022-06-11 00:05:03.350611
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    inventory.add_group("group_01")
    assert "group_01" in inventory.groups
    assert isinstance(inventory.groups["group_01"], Group)


# Generated at 2022-06-11 00:05:16.265630
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    idata = InventoryData()
    idata.add_host('testhost')
    idata.add_group('testgroup')
    idata.add_child('testgroup', 'testhost')
    idata.set_variable('testhost', 'testvar', 'testvalue')
    idata.set_variable('testgroup', 'testvar', 'testvalue')

    # Not in testhost and not in testgroup
    assert idata.get_host('testhost').get_variables().get('inventory_file') is None
    assert idata.get_host('testhost').get_variables().get('inventory_dir') is None
    assert idata.get_host('testhost').get_variables().get('testvar') is None

# Generated at 2022-06-11 00:05:20.802458
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    invdata = InventoryData()
    invdata.add_group('test_group')  # Add a test_group, before test

    assert isinstance(invdata.add_group('test_group'), string_types)
    assert len(invdata.groups) == 2

    invdata.add_group('group2')
    assert len(invdata.groups) == 3



# Generated at 2022-06-11 00:05:31.839885
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()
    inventory.add_host('host-1')
    host1_host_object = inventory.hosts.get('host-1')
    assert(host1_host_object.name == 'host-1' and not host1_host_object.port)
    inventory.add_host('host-2', 'group-1')
    host2_host_object = inventory.hosts.get('host-2')
    assert(host2_host_object.name == 'host-2' and not host2_host_object.port and host2_host_object.get_groups()[0].name == 'group-1')
    inventory.add_host('host-3', 'group-2', 123)
    host3_host_object = inventory.hosts.get('host-3')

# Generated at 2022-06-11 00:05:40.007066
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    '''
    basic tests to ensure we can add and retrieve hosts in inventory
    '''

    inventory_string = u"""
[webservers]
foo ansible_port=2222
localhost ansible_port=2223

[db]
bar
localhost ansible_port=2224

[mygroup:children]
webservers
db
"""

    inventory = InventoryData()
    import io
    inventory.parse_inventory(host_list=io.StringIO(inventory_string))

    inventory.reconcile_inventory()
    assert len(inventory.hosts) == 2
    assert 'foo' in inventory.hosts
    assert 'bar' in inventory.hosts
    assert inventory.groups['db'].hosts['bar'] == inventory.hosts['bar']

# Generated at 2022-06-11 00:05:49.646646
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    data = InventoryData()

    test_group = Group('testgroup')
    data.groups['testgroup'] = test_group

    test_host = Host('testhost')
    data.hosts['testhost'] = test_host
    test_host.groups.append(data.groups['all'])

    data.add_child('all', 'testgroup')

    data.add_child('testgroup', 'testhost')

    test_host = Host('testhost2')
    data.hosts['testhost2'] = test_host
    test_host.groups.append(data.groups['all'])

    data.add_child('all', 'testgroup2')
    test_host.add_group(data.groups['testgroup2'])

    data.reconcile_inventory()


# Generated at 2022-06-11 00:06:02.392191
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    idata = InventoryData()
    idata.add_host(host='test', group='testgroup')
    assert 'all' in idata.hosts['test'].groups
    assert 'ungrouped' in idata.hosts['test'].groups
    assert 'testgroup' in idata.hosts['test'].groups


# Generated at 2022-06-11 00:06:11.714723
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    """
    This test checks if the method add_group() from class InventoryData
    works as expected.
    """
    # Create new empty InventoryData object and test if initial 'all' and
    # 'ungrouped' groups are created if no argument is given
    inventory = InventoryData()
    assert 'all' in inventory.groups.keys()
    assert 'ungrouped' in inventory.groups.keys()

    # Create new InventoryData object and initialize with a fake group
    # inventory
    inventory = InventoryData()
    fake_group = {'foo': {'hosts': [], 'vars': {}, 'children': []}}
    inventory.groups = fake_group
    inventory.add_group('bar')

    # Test if check if add_groups() adds a desired group to InventoryData
    # object
    assert 'bar' in inventory.groups

# Generated at 2022-06-11 00:06:18.911854
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    ''' test of InventoryData.reconcile_inventory method '''

    # prepare inventory
    inv = InventoryData()
    inv.add_host('testhost')
    inv.add_host('testhost2')
    inv.add_host('testhost3')
    inv.add_host('testhost4')
    inv.add_host('testhost5')
    inv.add_host('testhost6')

    # test of inventory rules
    inv.add_group('testgroup')
    inv.add_child('testgroup','testhost')
    inv.add_child('testgroup','testhost2')
    inv.add_child('testgroup','testhost3')
    inv.add_child('testgroup','testhost4')
    inv.add_child('testgroup','testhost5')
    inv.add_child

# Generated at 2022-06-11 00:06:25.279393
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inv_hosts = {'hostA': 'host_objA', 'hostB': 'host_objB'}
    inv_groups = {'groupA': 'group_objA', 'groupB': 'group_objB'}
    inv_data = InventoryData()
    inv_data.hosts = inv_hosts
    inv_data.groups = inv_groups
    inv_data.reconcile_inventory()
    assert inv_data.hosts == inv_hosts
    assert inv_data.groups == inv_groups


# Generated at 2022-06-11 00:06:28.666130
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    i = InventoryData()
    i.add_host('localhost', port=23)
    h = Host('localhost')
    h.port = 23
    assert i.get_host('localhost') == h, 'add_host() method doesn\'t add host'