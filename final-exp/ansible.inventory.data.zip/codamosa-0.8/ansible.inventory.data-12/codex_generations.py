

# Generated at 2022-06-10 23:57:03.235095
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    '''
    unit test for InventoryData.remove_host
    '''

    inventory_data = InventoryData()

    host_x = Host("host_x")
    inventory_data.hosts["host_x"] = host_x
    host_y = Host("host_y")
    inventory_data.hosts["host_y"] = host_y
    host_z = Host("host_z")
    inventory_data.hosts["host_z"] = host_z

    group_a = Group("group_a")
    group_a.add_host(host_x)
    group_a.add_host(host_y)
    group_a.add_host(host_z)
    inventory_data.groups["group_a"] = group_a

    group_b = Group("group_b")
    group

# Generated at 2022-06-10 23:57:12.815067
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    test_inventory =  InventoryData()

    test_inventory.add_group('group_a')
    test_inventory.add_group('group_b')
    test_inventory.add_group('group_c')
    test_inventory.add_group('group_d')

    test_inventory.add_host('host_a', 'group_a')
    test_inventory.add_host('host_b', 'group_b')
    test_inventory.add_host('host_c', 'group_c')
    test_inventory.add_host('host_d', 'group_d')

    test_inventory.add_child('group_a', 'host_b')
    test_inventory.add_child('group_b', 'host_c')
    test_inventory.add_child('group_c', 'host_d')


# Generated at 2022-06-10 23:57:23.266739
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('grp1')
    inventory.add_group('grp2')
    inventory.add_child('grp1', 'grp2')
    inventory.add_child('grp2', 'localhost')
    inventory.reconcile_inventory()
    assert inventory.get_host('localhost').get_groups() == [inventory.groups['all'], inventory.groups['grp1'], inventory.groups['grp2']]

    inventory = InventoryData()
    inventory.add_host('localhost')
    inventory.add_group('grp1')
    inventory.add_child('grp1', 'localhost')
    inventory.add_group('grp2')
    inventory.add_child('grp2', 'localhost')
    inventory

# Generated at 2022-06-10 23:57:30.680886
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    data = InventoryData()
    data.add_host("test1", "group1")
    data.add_host("test2", "group2")
    data.add_host("test3")

    assert "test1" in data.hosts
    data.remove_host(data.hosts["test1"])
    assert "test1" not in data.hosts

    assert "test3" in data.hosts
    data.remove_host(data.hosts["test3"])
    assert "test3" not in data.hosts

# Generated at 2022-06-10 23:57:43.311850
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    in_data = InventoryData()
    in_data.current_source = 'dummy_file'
    in_data.processed_sources = []

    in_data.add_host('localhost', 'all')
    host_localhost = in_data.get_host('localhost')
    assert host_localhost is not None, "Test get_host in class InventoryData failed, host localhost not found"
    assert host_localhost.name == 'localhost', "Test get_host in class InventoryData failed, host localhost found not with name localhost"
    assert host_localhost.address == '127.0.0.1', "Test get_host in class InventoryData failed, host localhost found with wrong address"

    host_none = in_data.get_host('none')

# Generated at 2022-06-10 23:57:54.705143
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # prepare data:
    inventory_data = InventoryData()
    host_1 = Host('host_1')
    host_2 = Host('host_2')
    host_3 = Host('host_3')
    group_1 = Group('group_1')
    group_2 = Group('group_2')
    inventory_data.groups['group_1'] = group_1
    inventory_data.groups['group_2'] = group_2
    inventory_data.hosts['host_1'] = host_1
    inventory_data.hosts['host_2'] = host_2
    inventory_data.hosts['host_3'] = host_3

    # test function
    inventory_data.remove_host(host_1)

    # check for group_1
    assert len(group_1.hosts) == 0


# Generated at 2022-06-10 23:58:03.506325
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    invdata = InventoryData()
    invdata.add_group('group1')
    invdata.add_host('host1', 'group1')
    invdata.add_host('host2', 'group1')
    invdata.add_host('host3', 'group1')
    invdata.add_host('host4', 'group1')
    invdata.reconcile_inventory()
    assert invdata.hosts['host1'].get_groups() == [invdata.groups['ungrouped'],
                                                   invdata.groups['all'],
                                                   invdata.groups['group1']]

# Generated at 2022-06-10 23:58:09.784793
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    # Implicit localhost not exist
    inv_data = InventoryData()
    assert(inv_data.get_host("localhost") is None)

    # Implicit localhost exist
    inv_data.add_host("localhost", None)
    assert(inv_data.get_host("127.0.0.1") is not None)
    assert(inv_data.get_host("localhost") is not None)

    # Normal host
    inv_data.add_host("test-host", None)
    assert(inv_data.get_host("test-host") is not None)
    assert(inv_data.get_host("test-host1") is None)

    # Warning & Create implicit localhost
    # TODO: Display.show_warnings is not able to mock
    # inv_data.add_host("localhost", None

# Generated at 2022-06-10 23:58:17.995624
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inv = InventoryData()
    host = Host('test')
    group = Group('test')
    group.add_host(host)
    inv.add_group(group)
    assert group.get_hosts() == [host]
    assert host.get_groups() == [group]
    inv.remove_host(host)
    assert group.get_hosts() == []
    assert host.get_groups() == []


# Generated at 2022-06-10 23:58:23.429145
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    test_inventory_data = {}
    test_inventory_data[inventory_data.add_host("test_host")] = {"inventory_file": None, "inventory_dir": None}

    assert test_inventory_data == inventory_data.hosts

# Generated at 2022-06-10 23:58:39.667923
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():

    inv = InventoryData()

    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    inv.add_group('g1')
    inv.add_child('g1', 'h1')
    inv.add_child('g1', 'h2')
    inv.add_child('g1', 'h3')

    inv.remove_host(h2)

    assert('h2' not in inv.hosts)
    assert('h2' not in inv.groups['g1'].hosts)



# Generated at 2022-06-10 23:58:50.770575
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    import os
    import tempfile
    import shutil
    import sys

    # test with a dynamically created temporary inventory file
    # and a temporary directory to store the inventory_dir
    # this temporary inventory file should be deleted automatically
    # when the test is over
    # the temporary directory and content should be deleted automatically
    # when the test is over

    tmp_dir_fd, inventory_dir = tempfile.mkdtemp()


# Generated at 2022-06-10 23:58:59.275567
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    g = Group('all')
    g_all = g
    g = Group('g1')
    g1 = g
    g = Group('g2')
    g2 = g
    g = InventoryData()
    g.add_group('all')
    g.add_group('g1')
    g.add_group('g2')

    g.add_child('all', 'g1')
    g.add_child('all', 'g2')
    h1 = Host('h1')
    g.add_host(h1)
    g.add_child('g1', 'h1')

    g.remove_host(h1)
    assert g_all.hosts == set()
    assert g1.hosts == set()
    assert g2.hosts == set()

# Generated at 2022-06-10 23:59:10.355873
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()

    group_name = "test group"
    group = Group(group_name)
    inventory_data.groups[group_name] = group

    host_name = "test host"
    host = Host(host_name)
    inventory_data.hosts[host_name] = host
    inventory_data.add_child(group_name, host_name)

    assert group.get_hosts() == [host]

    inventory_data.remove_host(host)

    assert host.name not in inventory_data.hosts
    assert host.name not in inventory_data.groups[group_name].get_hosts()
    assert host.name not in inventory_data.groups[group_name].get_children()
    assert host.name not in inventory_data.groups[group_name].get

# Generated at 2022-06-10 23:59:22.419156
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory = InventoryData()
    host = Host('host1')
    inventory.hosts = {'host1': host}
    inventory.groups = {'all': Group('all'), 'group1': Group('group1')}
    inventory.groups['all'].hosts = [host]
    inventory.groups['all'].child_groups = [inventory.groups['group1']]
    inventory.groups['group1'].hosts = [host]
    inventory.groups['group1'].parent_groups = [inventory.groups['all']]
    host.groups = [inventory.groups['all'], inventory.groups['group1']]

    inventory.reconcile_inventory()
    assert(inventory.groups['all'].parent_groups == [])

# Generated at 2022-06-10 23:59:28.138815
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    test_inventory = InventoryData()
    test_group = test_inventory.add_group('test_group')

    assert test_group == 'test_group'
    assert 'test_group' in test_inventory.groups
    assert test_inventory.add_group('test_group') == 'test_group'



# Generated at 2022-06-10 23:59:34.321811
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test = InventoryData()
    test.add_host("localhost")
    test.add_host("localhost", port=1234)
    test.add_host("host1")
    test.add_host("host2")
    test.add_host("host3")
    test.add_host("host4")
    test.add_host("host5")
    assert test.get_host("localhost") is test.get_host("localhost")
    assert test.get_host("localhost").port == 22
    assert test.get_host("localhost").address == test.get_host("localhost").name == "localhost"
    assert test.get_host("localhost").port == 22
    assert test.get_host("localhost").port != test.get_host("localhost", 1234).port

# Generated at 2022-06-10 23:59:41.963557
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    groups = inv.groups

    assert groups == {'all': Group('all'), 'ungrouped': Group('ungrouped')}

    assert inv.add_group('group_foo') == 'group_foo'

    assert len(groups) == 3
    assert groups['group_foo'].name == 'group_foo'

    assert inv.add_group('group_foo') == 'group_foo'
    assert len(groups) == 3
    assert groups['group_foo'].name == 'group_foo'



# Generated at 2022-06-10 23:59:48.754640
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_obj = InventoryData()
    new_group = inventory_data_obj.add_group('test-group')
    new_host = inventory_data_obj.add_host('test-host', new_group)

    inventory_data_obj.remove_host(new_host)
    assert 'test-host' not in inventory_data_obj.hosts.keys()
    assert 'test-group' not in inventory_data_obj.groups.keys()



# Generated at 2022-06-11 00:00:01.016111
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory = InventoryData()
    host = Host('host0', port=0)

    inventory.hosts[host.name] = host
    inventory.groups['group0'] = Group('group0')
    inventory.groups['group1'] = Group('group1')

    inventory.groups['group0'].add_host(host)
    inventory.groups['group1'].add_host(host)
    assert len(inventory.groups) == 2
    assert len(inventory.hosts) == 1
    assert list(inventory.groups.keys()) == ['group0', 'group1']
    assert set(inventory.groups['group0'].get_hosts()) == {host}
    assert set(inventory.groups['group1'].get_hosts()) == {host}

    inventory.remove_host(host)

# Generated at 2022-06-11 00:00:10.268678
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv_data = InventoryData()
    inv_data.add_host('test_host', 'test_group')
    assert inv_data.groups['test_group'].get_hosts()[0].name == 'test_host'

# Generated at 2022-06-11 00:00:21.541348
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import vars_loader
    from ansible.plugins import vars_plugins

    # Init
    inventory = InventoryData()
    play_context = PlayContext()
    play_context.inventory = inventory
    inventory.set_variable('all', 'foo', 'bar')
    vars_loader.add_directory(play_context, 'test/unit/vars_plugins/')
    vars_plugins.run_vars_plugins(play_context, 'all', 'foobar')

    # Expected groups
    expected_groups = [
        'all',
        'foobar',
        'foobars',
        'group_vars',
        'host_vars',
        'ungrouped',
	]

    # Check

# Generated at 2022-06-11 00:00:29.705349
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventoryData = InventoryData()
    assert isinstance(inventoryData, object)

    try:
        inventoryData.add_group(None)
        assert False
    except Exception:
        assert True

    assert inventoryData.add_group("group0") == "group0"
    assert isinstance(inventoryData.groups["group0"], Group)

    assert inventoryData.add_group("group0") == "group0"
    assert isinstance(inventoryData.groups["group0"], Group)


# Generated at 2022-06-11 00:00:38.358362
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # Setup
    data = InventoryData()
    data.add_host('localhost')
    data.add_host('host1')
    data.add_host('host2')

    data.add_group('group1')
    data.add_group('group2')

    # Test 1
    # Reconcile without any child
    data.reconcile_inventory()
    assert(sorted(data.get_groups_dict().keys()) == sorted(['group1', 'group2', 'all', 'ungrouped']))

    # Add child
    data.add_child('group1', 'host1')
    data.add_child('group2', 'host2')
    data.reconcile_inventory()

# Generated at 2022-06-11 00:00:44.542128
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    inventory_data = InventoryData()
    test_host = "test_host"
    test_group = "test_group"

    inventory_data.add_host(test_host)
    assert test_host in inventory_data.hosts
    assert test_group not in inventory_data.groups
    assert test_host not in inventory_data.groups['all']
    assert test_host not in inventory_data.groups['ungrouped']

    inventory_data.add_host(test_host, test_group)
    assert test_group in inventory_data.groups
    assert test_group in inventory_data.groups['all']
    assert test_host in inventory_data.groups[test_group]
    assert test_host in inventory_data.groups['all']
    assert test_host not in inventory_data.groups['ungrouped']

# Generated at 2022-06-11 00:00:53.545898
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    iv = InventoryData()
    iv.add_host('host1')
    iv.add_host('host2', group='group1')
    iv.add_host('host3', group='group1')
    iv.reconcile_inventory()
    assert 'group1' in iv._groups_dict_cache
    assert 'all' in iv._groups_dict_cache

    iv2 = InventoryData()
    iv2.add_host('host1', group='group1')
    iv2.add_host('host2', group='group2')
    iv2.add_group('group1')
    iv2.reconcile_inventory()
    assert 'all' in iv2.groups['group1'].child_groups
    assert 'group1' in iv2.groups['group1'].child_groups


# Unit test

# Generated at 2022-06-11 00:01:07.520222
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Arrange
    inventory = InventoryData()
    inventory.add_host("host")
    inventory.add_host("host2")
    inventory.add_host("host3")

    inventory.add_group("group")
    inventory.add_group("group2")
    inventory.add_group("group3")

    inventory.add_child("group", "host2")
    inventory.add_child("group", "host3")

    inventory.add_child("group2", "host")

    # Act
    inventory.reconcile_inventory(True)

    # Assert
    assert inventory.groups["all"]._children == ["group", "group2", "group3", "ungrouped"],\
        "Unexpected group membership 'all'."

# Generated at 2022-06-11 00:01:14.277099
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.current_source = 'test_source'
    inventory_data.add_host('test_host1')
    assert(inventory_data.hosts['test_host1'].name == 'test_host1')
    assert(inventory_data.hosts['test_host1'].vars == {'inventory_file': inventory_data.current_source, 'inventory_dir': basedir(inventory_data.current_source)})


# Generated at 2022-06-11 00:01:26.065529
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    invd = InventoryData()
    invd.hosts = {
        'host1': Host('host1', port=1234),
        'host2': Host('host2', port=5678),
    }
    invd.hosts['host1'].add_group('group1')
    invd.hosts['host2'].add_group('group2')
    invd.groups = {
        'group1': Group('group1'),
        'group2': Group('group2'),
    }
    invd.groups['group1'].add_host(invd.hosts['host1'])
    invd.groups['group2'].add_host(invd.hosts['host2'])

    invd.reconcile_inventory()

# Generated at 2022-06-11 00:01:37.536437
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    #Creating new InventoryData object
    inventory_data = InventoryData()

    #Testing with group name which does not already exist in the inventory
    group_name = 'Apples'
    #Calling add_group method of InventoryData class
    inventory_data.add_group(group_name)
    #Checking if the group indeed is created
    assert inventory_data.groups['Apples'] != None

    #Testing with group name which already exists in the inventory
    group_name = 'Apples'
    #Calling add_group method of InventoryData class
    inventory_data.add_group(group_name)
    #Checking if the group is still Apples
    assert inventory_data.groups['Apples'] != None

# Generated at 2022-06-11 00:01:52.224462
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    """
    Add host test
    """

    display.verbosity = 4
    inv = InventoryData()
    inv.add_host('test_host', 'group1')

    assert list(inv.get_groups_dict().keys()) == ['all', 'group1', 'ungrouped']
    assert 'test_host' in inv.get_groups_dict()['group1']
    assert inv.hosts['test_host'].name == 'test_host'
    assert inv.hosts['test_host'].get_groups()[0].name == 'group1'
    assert inv.hosts['test_host'].get_groups()[1].name == 'all'

# Generated at 2022-06-11 00:01:58.791218
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    test_inventory = InventoryData()
    assert isinstance(test_inventory, InventoryData)
    group = test_inventory.add_group('testgroup1')
    assert isinstance(group, string_types)
    assert group == 'testgroup1'
    groupNames = test_inventory.groups.keys()
    assert isinstance(groupNames, list)
    assert 'testgroup1' in groupNames
    assert len(groupNames) == 3



# Generated at 2022-06-11 00:02:05.880228
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    idata = InventoryData()
    idata.add_group("groupA")
    idata.add_group("groupB")
    idata.add_host("hostA", "groupA")
    idata.reconcile_inventory()
    assert idata.groups["groupA"].get_hosts() == [idata.hosts["hostA"]]
    assert idata.groups["groupA"].get_vars() is None


# Generated at 2022-06-11 00:02:15.230192
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    display = Display()
    inventory_data = InventoryData()
    group_names = ['all', 'ungrouped']
    host_names = ['127.0.0.1']
    host_names.extend(C.LOCALHOST)
    inventory_data.add_host('127.0.0.1', 'all')
    for host in host_names:
        inventory_data.add_host(host, 'ungrouped')
    inventory_data.reconcile_inventory()
    assert inventory_data.get_host('127.0.0.1').name == '127.0.0.1'
    assert inventory_data.get_host('127.0.0.1').address == '127.0.0.1'
    assert inventory_data.get_host('127.0.0.1').v

# Generated at 2022-06-11 00:02:26.622664
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    filename = 'test_InventoryData.py'
    display.verbosity = 3
    # Checking that groups and hosts in inventory clear after first use if they not present in inventory
    inventory = InventoryData()
    fake_group = Group('fake_group')
    fake_host = Host('fake_host')
    inventory.groups['fake_group'] = fake_group
    inventory.hosts['fake_host'] = fake_host
    assert 'fake_group' in inventory.groups and 'fake_host' in inventory.hosts
    inventory.reconcile_inventory()
    assert 'fake_group' not in inventory.groups and 'fake_host' not in inventory.hosts

    # Checking that group and host do not leave in inventory if they not in inventory sources
    host1 = 'host1'
    host2 = 'host2'
    host

# Generated at 2022-06-11 00:02:38.533097
# Unit test for method reconcile_inventory of class InventoryData

# Generated at 2022-06-11 00:02:44.784635
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    '''check implicit localhost creation, ungrouped'''
    idata = InventoryData()
    idata.add_host('foo')
    idata.reconcile_inventory()
    assert idata.get_host('127.0.0.1') == idata.get_host('localhost')
    assert idata.get_host('foo').get_groups() == [idata.groups['all'], idata.groups['ungrouped']]


# Generated at 2022-06-11 00:02:56.819131
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Arrange
    inventory_data = InventoryData()
    inventory_data.current_source = 'test_inventory_file'
    hostname = 'test_host'

    # Act
    result = inventory_data.add_host(hostname)

    # Assert
    assert result == hostname
    assert hostname in inventory_data.hosts
    assert 'inventory_file' in inventory_data.hosts[hostname].vars
    assert 'inventory_dir' in inventory_data.hosts[hostname].vars
    assert inventory_data.hosts[hostname].vars['inventory_file'] == 'test_inventory_file'
    assert inventory_data.hosts[hostname].vars['inventory_dir'] == basedir('test_inventory_file')

# Generated at 2022-06-11 00:03:03.372330
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    inv.add_host('h1', 'g1')
    assert inv.hosts['h1'].groups == ['all', 'g1']
    assert inv.groups['g1'].hosts == [inv.hosts['h1']]
    assert inv.groups['all'].hosts == [inv.hosts['h1']]

# Generated at 2022-06-11 00:03:07.656056
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    idata = InventoryData()
    idata.add_group("foo")
    assert len(idata.groups) == 1
    idata.add_group("bar")
    assert len(idata.groups) == 2
    assert 'foo' in idata.groups
    assert 'bar' in idata.groups


# Generated at 2022-06-11 00:03:18.164287
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test_inventory = InventoryData()
    test_host = test_inventory.add_host("test_host")

    assert test_host == 'test_host'

    assert test_host in test_inventory.hosts



# Generated at 2022-06-11 00:03:20.117991
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    assert len(inventory_data.add_group('')) == 0



# Generated at 2022-06-11 00:03:22.819107
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    g = InventoryData()
    g.add_group("test1")
    g.add_group("test2")
    print(g.groups)


# Generated at 2022-06-11 00:03:33.203827
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    inventoryData = InventoryData()
    inventoryData.add_host('localhost')
    inventoryData.add_host('one')
    inventoryData.add_host('two')
    inventoryData.add_host('three')
    inventoryData.add_host('four')
    inventoryData.add_host('host1')
    inventoryData.add_host('host2')
    inventoryData.add_host('host3')
    inventoryData.add_host('host4')

    inventoryData.add_group('group1')
    inventoryData.add_group('group2')
    inventoryData.add_group('group3')
    inventoryData.add_group('group4')
    inventoryData.add_group('group5')
    inventoryData.add_group('group6')
    inventoryData.add_group('group7')


# Generated at 2022-06-11 00:03:44.335115
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    data = InventoryData()

    # Add group 'group1', 'group2'
    data.add_group('group1')
    data.add_group('group2')

    # Add host 'host1', 'host2'
    data.add_host('host1', 'group1')
    data.add_host('host2', 'group2')

    # Assertion for groups before run reconcile_inventory
    assert len(data.groups) == 3
    assert 'group1' in data.groups
    assert 'group2' in data.groups
    assert 'all' in data.groups
    assert 'group1' in data.add_group('group1').get_ancestors()
    assert 'all' in data.add_group('group1').get_ancestors()

# Generated at 2022-06-11 00:03:56.171424
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    display.verbosity = 3

    g = Group('group')
    g.vars = {'groupprop': 'true'}
    group_name = 'mygroup'
    group_name_variant = 'mygroupvar'
    h = Host('host')
    h.vars = {'hostprop': 'true'}
    host_name = 'myhost'
    host_name_variant = 'myhostvar'

    my = InventoryData()

    # 1.) add a new group, with a new host
    my.add_group(group_name_variant)
    my.add_host(host_name_variant, group_name_variant)

    # 2.) add implicit localhost, add it to a new group
    my.add_host('localhost')

# Generated at 2022-06-11 00:04:09.226157
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    data = InventoryData()
    data.add_host('hostname')
    assert 'hostname' in data.hosts
    assert len(data.hosts) == 1
    h = data.hosts['hostname']
    assert h.port is None
    assert len(h.get_groups()) == 2
    assert data.groups["all"] in h.get_groups()
    assert data.groups["ungrouped"] in h.get_groups()

    data = InventoryData()
    data.add_host('hostname', port=2)
    assert 'hostname' in data.hosts
    assert len(data.hosts) == 1
    h = data.hosts['hostname']
    assert h.port == 2
    assert len(h.get_groups()) == 2

# Generated at 2022-06-11 00:04:17.680083
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inv_data = InventoryData()

    host_name = 'test_host'
    group_name = 'test_group'

    inv_data.add_group(group_name)
    inv_data.add_host(host_name, group_name)

    # Expecting that host is in group
    assert inv_data.hosts[host_name] in inv_data.groups[group_name].get_hosts()

    inv_data.reconcile_inventory()

    # Expecting that group is not in 'ungrouped' group
    assert group_name not in inv_data.groups['ungrouped'].get_groups()

    # Expecting that host is in group
    assert inv_data.hosts[host_name] in inv_data.groups[group_name].get_hosts()

# Generated at 2022-06-11 00:04:22.132536
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    hostname = '192.168.1.1'
    port = 22
    inventory_data.add_host(hostname, 'all', port)

    assert inventory_data.get_host(hostname).port == port

# Generated at 2022-06-11 00:04:25.863853
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    id = InventoryData()
    assert(id.add_group("group1") == "group1")

    id.add_group("group2")
    assert("group2" in id.groups)

    assert("group3" in id.groups)
    assert("group3" in id.get_groups_dict())


# Generated at 2022-06-11 00:04:45.148221
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv = InventoryData()
    # Test successfull host creation without group assignment
    host1 = 'host1'
    inv.add_host(host1)
    assert inv.hosts[host1].name == 'host1'
    assert not inv.hosts[host1].get_groups()
    # Test successfull host creation with group assignment
    host2 = 'host2'
    group1 = 'group1'
    inv.add_group(group1)
    inv.add_host(host2, group1)
    assert inv.hosts[host2].get_groups() == [inv.groups[group1]]
    # Test exception on group name not found
    host3 = 'host3'
    try:
        inv.add_host(host3, 'group2')
    except AnsibleError:
        pass
    #

# Generated at 2022-06-11 00:04:57.015125
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory = InventoryData()

    # add_host() calls add_group()
    inventory.add_host('localhost')

    inventory.add_group('ungrouped-2')

    # add_child() calls add_group()
    inventory.add_child('ungrouped-2', 'localhost')

    # add_child() calls add_group()
    inventory.add_child('all', 'ungrouped-2')

    assert(inventory.groups.get('all').get_hosts() == inventory.groups.get('ungrouped-2').get_hosts())
    assert(inventory.groups.get('all').get_vars())
    assert(inventory.groups.get('ungrouped-2').get_vars())

    # reconcile_inventory() will remove the unnecessary child from 'all'
    inventory.reconcile_inventory

# Generated at 2022-06-11 00:05:00.926151
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    dut = InventoryData()
    dut.reconcile_inventory()
    assert dut.hosts == {}
    assert dut.groups['all'].hosts == {}
    assert dut.groups['ungrouped'].hosts == {}


# Generated at 2022-06-11 00:05:03.596927
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inv = InventoryData()
    inv.add_host("localhost")
    inv.add_host("testhost")
    assert inv.reconcile_inventory() is None
    assert inv.get_host("localhost") is not None
    assert inv.get_host("testhost") is not None



# Generated at 2022-06-11 00:05:16.454533
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    result = True

    inventoryData = InventoryData()
    inventoryData.add_group("group1")
    inventoryData.add_group("group2")
    inventoryData.add_group("group3")
    inventoryData.add_host("host1", "group1")
    inventoryData.add_host("host2", "group1")
    inventoryData.add_host("host3", "group2")
    inventoryData.add_host("host4", "group2")
    inventoryData.add_host("host5")
    inventoryData.reconcile_inventory()
    group_uncoupled = inventoryData.add_group("group4")
    inventoryData.add_child(group_uncoupled, "host2")
    # Should not be added because host2 is already in group1

# Generated at 2022-06-11 00:05:24.941370
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    # Test for False group name
    try:
        inventory.add_group(False)
    except AnsibleError as e:
        assert e.message == "Invalid group name supplied, expected a string but got <type 'bool'> for False"
    # Test for empty group name
    try:
        inventory.add_group("")
    except AnsibleError as e:
        assert e.message == "Invalid empty/false group name provided: "
    # Test for group that already exists
    group_name = "group"
    inventory.add_group(group_name)
    assert inventory.add_group(group_name) == group_name

if __name__ == '__main__':
    test_InventoryData_add_group()

# Generated at 2022-06-11 00:05:33.835034
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    test_inventory_data = InventoryData()

    # Add Hosts
    test_inventory_data.add_host('host1')
    test_inventory_data.add_host('host2')

    # Add Groups
    test_inventory_data.add_group('group1')
    test_inventory_data.add_group('group2')

    # Add groups as children of host1
    test_inventory_data.add_child('group1', 'host1')
    test_inventory_data.add_child('group2', 'host1')

    test_inventory_data.reconcile_inventory()

    return test_inventory_data

if __name__ == "__main__":
    test_InventoryData_reconcile_inventory()

# Generated at 2022-06-11 00:05:38.904593
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    ansible_inventory_data = InventoryData()

    result = ansible_inventory_data.groups

    assert (result == {})

    ansible_inventory_data.add_group('test')
    result2 = ansible_inventory_data.groups

    assert (result2 == {'test': 'test'})


# Generated at 2022-06-11 00:05:43.565134
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    group_name = "test_group"

    assert group_name not in inv.groups
    inv.add_group(group_name)
    assert group_name in inv.groups

    # TODO add test for invalid group name (i.e. not a string)


# Generated at 2022-06-11 00:05:47.028143
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group = inventory.add_group('my_group')
    assert group is not None
    assert group in inventory.groups

    group = inventory.add_group('my_group')
    assert group is not None
    assert group in inventory.groups



# Generated at 2022-06-11 00:06:04.639565
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    groups_saved = inventory_data.groups
    display_saved = display.display
    try:
        display.display = False
        inventory_data.add_group("test_group")
        assert(groups_saved != inventory_data.groups)
        assert(groups_saved.__len__() == inventory_data.groups.__len__() - 1)
        assert("test_group" in inventory_data.groups)
        groups_saved = inventory_data.groups
        inventory_data.add_group("test_group")
        assert(groups_saved == inventory_data.groups)
        assert(groups_saved.__len__() == inventory_data.groups.__len__())
    finally:
        display.display = display_saved


# Generated at 2022-06-11 00:06:13.628059
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    groups = {
        'test_group_1': Group('test_group_1'),
        'test_group_2': Group('test_group_2'),
        'all': Group('all'),
        'ungrouped': Group('ungrouped')
    }

    groups['all'].add_child_group(groups['test_group_1'])
    groups['all'].add_child_group(groups['test_group_2'])

    hosts = {
        'test_host_1': Host('test_host_1'),
        'test_host_2': Host('test_host_2'),
        'test_host_3': Host('test_host_3'),
        'test_host_4': Host('test_host_4'),
    }


# Generated at 2022-06-11 00:06:17.961504
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    id = InventoryData()
    id.add_group('testgroup1')
    assert('testgroup1' in id.groups)
#test_InventoryData_add_group()


# Generated at 2022-06-11 00:06:27.523821
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    parser = InventoryManager(loader=DataLoader(), sources='tests/inventory/reconcile_inventory/')
    inv_data = parser.inventory.get_inventory_data()
    inv_data.reconcile_inventory()
    # check group
    assert inv_data.groups['all'] == inv_data.groups['all_group']
    assert inv_data.groups['group1'] == inv_data.groups['group1_group']
    assert inv_data.groups['group2'] == inv_data.groups['group2_group']
    # check parents
    assert inv_data.groups['all_group'].get_parents() == ['all']


# Generated at 2022-06-11 00:06:36.434957
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory = InventoryData()

    # Rules to test
    # - Hosts needs to be unique
    # - Hosts needs to be in ungrouped if not grouped
    # - All groups needs to inherit from all
    # - All groups needs to be unique

    # Setup groups and subgroups
    groups = ['all', 'group1', 'group2', 'group1_1', 'group1_2', 'group2_1']
    all_group = inventory.groups['all']
    for group in groups:
        inventory.add_group(group)
    inventory.add_child('all', 'group1')
    inventory.add_child('all', 'group2')
    inventory.add_child('group1', 'group1_1')
    inventory.add_child('group1', 'group1_2')