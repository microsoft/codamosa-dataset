

# Generated at 2022-06-22 20:35:56.439160
# Unit test for constructor of class InventoryData
def test_InventoryData():
    """
    Validate that InventoryData class is working properly.
    """
    data = InventoryData()
    assert 'all' in data.groups and 'ungrouped' in data.groups
    assert len(data.groups) == 2
    assert len(data.hosts) == 0
    assert data.localhost is None
    assert data.current_source is None

if __name__ == '__main__':
    test_InventoryData()

# Generated at 2022-06-22 20:35:58.975323
# Unit test for constructor of class InventoryData
def test_InventoryData():
    """
    Unit test for constructor of class InventoryData
    """
    inventory_data = InventoryData()
    assert 'all' in inventory_data.groups
    assert 'ungrouped' in inventory_data.groups

# Generated at 2022-06-22 20:36:10.738213
# Unit test for method serialize of class InventoryData
def test_InventoryData_serialize():
    inventory_data = InventoryData()
    group_all = Group('all')
    group_all.add_host(Host('localhost'))
    inventory_data.groups['all'] = group_all
    inventory_data.hosts['localhost'] = group_all.get_hosts()[0]
    inventory_data.localhost = group_all.get_hosts()[0]
    inventory_data.current_source = '1'
    inventory_data.processed_sources = ['1']
    serialize_data = inventory_data.serialize()
    assert serialize_data['groups'] == inventory_data.groups
    assert serialize_data['hosts'] == inventory_data.hosts
    assert serialize_data['local'] == inventory_data.localhost
    assert serialize_data['source'] == inventory_data.current

# Generated at 2022-06-22 20:36:22.552117
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    i = InventoryData()

    h1 = Host('h1')
    h2 = Host('h2')
    h3 = Host('h3')
    h4 = Host('h4')

    i.hosts['h1'] = h1
    i.hosts['h2'] = h2
    i.hosts['h3'] = h3
    i.hosts['h4'] = h4

    g1 = Group('g1')
    g2 = Group('g2')
    g3 = Group('g3')
    g4 = Group('g4')

    i.groups['g1'] = g1
    i.groups['g2'] = g2
    i.groups['g3'] = g3
    i

# Generated at 2022-06-22 20:36:25.716938
# Unit test for constructor of class InventoryData
def test_InventoryData():
    inv = InventoryData()
    assert inv

    groups_map = {'ungrouped': [], 'all': ['ungrouped']}
    hosts_map = {}
    assert inv.hosts == hosts_map
    assert inv.groups == groups_map


# Generated at 2022-06-22 20:36:34.356633
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():
    """ Unit test for method deserialize of class InventoryData
    """
    inv_data = InventoryData()
    inv_data.deserialize({u'groups': {}, u'hosts': {}, u'local': None, u'processed_sources': [], u'source': None})
    assert inv_data.groups == {}
    assert inv_data.hosts == {}
    assert inv_data.localhost is None
    assert inv_data.current_source is None
    assert inv_data.processed_sources == []

# Generated at 2022-06-22 20:36:47.314405
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():
  data = dict(
        hosts = dict(
            host1 = dict(
                address = '1.1.1.1',
                port = 22,
                )
            ),
        groups = dict(
            group1 = dict(
                hosts = ['host1',],
                vars = dict(
                    groupvar1 = 'groupvar1value'
                    )
                ),
            group2 = dict(
                hosts = ['host1',]
                )
            ),
        source = 'test_source',
        processed_sources = ['test_processed_source',],
        local = dict(
            address = '1.1.1.1',
            port = 22,
            )
        )

  inventoryData = InventoryData()
  inventoryData.deserialize(data)

  # Test that the host was deserialized correctly

# Generated at 2022-06-22 20:36:54.357268
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():

    idata = InventoryData()
    idata.add_host('foo')
    assert idata.get_host('foo') == idata.hosts['foo']
    assert idata.get_host('foo') != idata.hosts['bar']
    idata.add_host('127.0.0.1')
    assert '127.0.0.1' in idata.hosts
    assert idata.hosts['127.0.0.1'].name == '127.0.0.1'

# Generated at 2022-06-22 20:36:59.386963
# Unit test for constructor of class InventoryData
def test_InventoryData():
    i = InventoryData()
    assert i.groups == {'all': {}, 'ungrouped': {}}
    assert i.current_source == None
    assert i.processed_sources == []
    assert i.localhost == None
    assert i.hosts == {}
    assert i._groups_dict_cache == {}


# Generated at 2022-06-22 20:37:03.880341
# Unit test for method serialize of class InventoryData
def test_InventoryData_serialize():
    inventoryData = InventoryData()
    inventoryData.hosts = {'127.0.0.1': Host('127.0.0.1'), '127.0.0.2': Host('127.0.0.2')}
    inventoryData.groups = {'group1': Group('group1'), 'group2': Group('group2')}
    inventoryData.localhost = Host('127.0.0.1')
    inventoryData.current_source = 'source'
    inventoryData.processed_sources = ['processed_source1', 'processed_source2']

# Generated at 2022-06-22 20:37:15.267089
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('test_host_name', 'test_group_name')
    inventory_data.add_host('test_host_name2', 'test_group_name')
    inventory_data.add_group('test_group_name2')
    inventory_data.add_child('test_group_name2', 'test_host_name2')
    inventory_data.remove_host('test_host_name')
    assert inventory_data.hosts == {'test_host_name2': Host('test_host_name2')}

# Generated at 2022-06-22 20:37:22.594605
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory = InventoryData()
    group_1 = 'group 1'
    group_2 = 'group 2'

    # no group should be added
    display.verbosity = 1
    assert inventory.add_group(None) == None

    # one group should be added
    display.verbosity = 1
    assert inventory.add_group(group_1) == group_1

    # yet another group should be added
    display.verbosity = 1
    assert inventory.add_group(group_2) == group_2

    # first group should not be added
    display.verbosity = 1
    assert inventory.add_group(group_1) == group_1
    

# Generated at 2022-06-22 20:37:33.853868
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    idv = InventoryData()

    # set 3 hosts
    idv.add_host('host1')
    idv.add_host('host2')
    idv.add_host('host3')

    # set 4 groups
    idv.add_group('group1')
    idv.add_group('group2')
    idv.add_group('group3')
    idv.add_group('group4')

    # add host to group
    idv.add_child('group1', 'host1')
    idv.add_child('group1', 'host2')
    idv.add_child('group2', 'host3')
    idv.add_child('group3', 'host1')
    idv.add_child('group4', 'host2')

# Generated at 2022-06-22 20:37:37.702132
# Unit test for constructor of class InventoryData
def test_InventoryData():
    inventory_data = InventoryData()

    for group in ('all', 'ungrouped'):
        assert group in inventory_data.get_groups_dict()

# Generated at 2022-06-22 20:37:47.011474
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    invdata = InventoryData()
    invdata.add_group("foo")
    invdata.add_group("bar")
    invdata.add_host("localhost", "foo")
    assert "foo" in invdata.groups
    assert "localhost" in invdata.hosts
    assert invdata.get_host("localhost").get_groups()[0].name == "foo"
    invdata.remove_group("foo")
    assert "foo" not in invdata.groups
    assert "localhost" in invdata.hosts
    assert len(invdata.get_host("localhost").get_groups()) == 0

# Generated at 2022-06-22 20:37:52.358331
# Unit test for method get_groups_dict of class InventoryData

# Generated at 2022-06-22 20:38:04.642717
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():

    inventory = InventoryData()

# Generated at 2022-06-22 20:38:11.118619
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    x = InventoryData()
    assert x.get_host('localhost') is None
    assert x.get_host('127.0.0.1') is None

    localhost = x.add_host('127.0.0.1')
    assert x.localhost
    assert x.get_host('localhost') is not None
    assert x.get_host('127.0.0.1') is not None
    assert x.get_host('127.0.0.1') == x.localhost
    assert x.get_host('127.0.0.1') == localhost

# Generated at 2022-06-22 20:38:14.322102
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    data_in_tests = InventoryData()
    data_in_tests.add_group('toto')

    assert 'toto' in data_in_tests.groups



# Generated at 2022-06-22 20:38:23.564653
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    # Create an object of class InventoryData.
    x = InventoryData()
    
    # Create two hosts and add them to the inventory x.
    h1 = Host("h1")
    x.add_host(h1.name, port=h1.port)
    h2 = Host("h2")
    x.add_host(h2.name, port=h2.port)

    # Create two groups and add them to the inventory x.
    g1 = Group("g1")
    x.add_group(g1.name)
    g2 = Group("g2")
    x.add_group(g2.name)

    # Verify that the group g1 has no hosts in it.
    assert(len(g1.get_hosts()) == 0)

    # Add the host h1 to the group g1.

# Generated at 2022-06-22 20:38:33.173152
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    # test setup
    inventory = InventoryData()
    inventory.add_group('groupA')
    inventory.add_group('groupB')
    inventory.add_host('hostA', 'groupA')
    inventory.add_host('hostB', 'groupB')
    inventory.add_host('hostC')
    # test
    groups_dict = inventory.get_groups_dict()
    # assert
    assert groups_dict == {'groupA': ['hostA'], 'groupB': ['hostB'], 'all': ['hostA', 'hostB', 'hostC'], 'ungrouped': ['hostC']}

# Generated at 2022-06-22 20:38:34.238601
# Unit test for constructor of class InventoryData
def test_InventoryData():
    inv_data = InventoryData()
    assert (isinstance(inv_data, InventoryData))

# Generated at 2022-06-22 20:38:39.605459
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    inventory = InventoryData()
    inventory.add_group('groupA')
    inventory.add_group('groupB')
    inventory.add_host('hostA', group='groupA')
    inventory.add_host('hostB', group='groupA')
    inventory.add_host('hostC', group='groupB')

    expected_dict = dict(
        groupA = ['hostA', 'hostB'],
        groupB = ['hostC']
    )
    assert expected_dict == inventory.get_groups_dict()

# Generated at 2022-06-22 20:38:40.122024
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    pass

# Generated at 2022-06-22 20:38:50.254350
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    inventory = InventoryData()
    groupA = inventory.add_group('groupA')
    groupB = inventory.add_group('groupB')
    groupC = inventory.add_group('groupC')

    host0 = inventory.add_host('host0')
    host1 = inventory.add_host('host1')
    host2 = inventory.add_host('host2')
    host3 = inventory.add_host('host3')

    inventory.add_child('groupA', 'host0')
    inventory.add_child('groupA', 'host1')
    inventory.add_child('groupA', 'host2')

    inventory.add_child('groupB', 'host0')
    inventory.add_child('groupB', 'host1')
    inventory.add_child('groupB', 'host3')

    inventory.add

# Generated at 2022-06-22 20:38:55.989115
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    """
    Tests the get_groups_dict method
    """
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host

    test_host = Host('test_host', port=1234)
    test_host2 = Host('test_host2', port=1234)
    test_host.set_variable('foo', 'bar')

    test_group = Group('test_group')
    test_group2 = Group('test_group2')

    test_group2.add_host(test_host)
    test_group2.add_host(test_host2)

    test_inventory = Inventory()
    test_inventory.add_group(test_group)
    test_inventory.add_group(test_group2)
    test_inventory.add_host(test_host)
    test_inventory

# Generated at 2022-06-22 20:39:08.417709
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    inventory = InventoryData()
    inventory.add_host("test01","group1")
    inventory.add_host("test02","group1")
    inventory.add_host("test03")
    inventory.add_host("test04","group2")
    inventory.add_host("test05","group2")
    inventory.add_host("test06","group3")

    expected = {'all': ['test01', 'test02', 'test03', 'test04', 'test05', 'test06'], 'group1': ['test01', 'test02'], 'group2': ['test04', 'test05'], 'group3': ['test06'], 'ungrouped': ['test03']}
    assert(inventory.get_groups_dict() == expected)


# Generated at 2022-06-22 20:39:11.909472
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    inv = InventoryData()
    inv.add_group('test_group')
    assert type(inv.groups['test_group']) == Group


# Generated at 2022-06-22 20:39:22.732288
# Unit test for method deserialize of class InventoryData

# Generated at 2022-06-22 20:39:35.283625
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory = InventoryData()

    # add_host method should accept hostname and group
    inventory.add_host('192.168.1.1', 'testgroup')
    inventory.add_host('192.168.1.2', 'testgroup2')
    inventory.add_host('192.168.1.3')

    # add_host should return hostname that was passed
    assert inventory.add_host('192.168.1.3') == '192.168.1.3'

    inventory.add_child('testgroup', '192.168.1.4')

    # add_host should give error if group is not present
    try:
        inventory.add_host('192.168.1.5', 'a_group_that_is_not_present')
    except AnsibleError:
        pass

    # add_host

# Generated at 2022-06-22 20:39:47.940292
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # Create a InventoryData object
    i = InventoryData()

    # Create implicit localhost
    i._create_implicit_localhost('127.0.0.1')

    # Add a host to inventory
    i.add_host('127.0.0.1')

    # Reconcile inventory
    i.reconcile_inventory()

    # Test if group 'all' contains host '127.0.0.1'
    assert('all' in i.hosts['127.0.0.1'].group_names)

    # Test if group 'all' contains group 'ungrouped'
    assert('ungrouped' in i.groups['all'].child_groups)

    # Test if group 'ungrouped' contains host '127.0.0.1'

# Generated at 2022-06-22 20:39:58.466667
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    from copy import deepcopy

    from ansible.module_utils.six import binary_type, text_type

    inv_data = InventoryData()

    group_names = ['all', 'ungrouped', 'foo', 'bar', 'baz', 'boo', 'bax', 'baw', 'baz:baz', 'baz:boo', 'baz:baw', 'baz:boo:baz']
    host_names = ['localhost', '127.0.0.1', 'foo', 'bar', 'baz', 'boo', 'bax', 'baw', 'foo:foo', 'foo:bar', 'foo:baz', 'foo:boo']
    for group_name in group_names:
        inv_data.add_group(group_name)

# Generated at 2022-06-22 20:40:08.813021
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    '''
    test_InventoryData_get_groups_dict: test function InventoryData.get_groups_dict
    '''

    # Create 3 groups: groupA, groupB, groupC
    # groupA has 1 host: hostA
    # groupB has 1 host: hostB
    # groupC has 2 hosts: hostA, hostB

    # Initialize inventory data
    idata = InventoryData()
    idata.add_group('groupA')
    idata.add_group('groupB')
    idata.add_group('groupC')
    idata.add_host('hostA')
    idata.add_host('hostB')
    idata.add_child('groupA', 'hostA')
    idata.add_child('groupB', 'hostB')

# Generated at 2022-06-22 20:40:17.524638
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # test inventory data
    # group_vars/all
    group_vars_all = dict(
        var1="group_vars_all_var1_value",
        var2="group_vars_all_var2_value"
    )
    # host_vars/testserver1
    host_vars_testserver1 = dict(
        var1="host_vars_testserver1_var1_value",
        var2="host_vars_testserver1_var2_value"
    )
    # host_vars/testserver2
    host_vars_testserver2 = dict(
        var1="host_vars_testserver2_var1_value",
        var2="host_vars_testserver2_var2_value"
    )
    # host_vars

# Generated at 2022-06-22 20:40:21.218525
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group("test")
    inventory.add_host("127.0.0.1", port=22)
    inventory.add_child("test", "127.0.0.1")
    inventory.reconcile_inventory()

# Generated at 2022-06-22 20:40:28.330074
# Unit test for method set_variable of class InventoryData
def test_InventoryData_set_variable():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    g = Group('group1')
    g1 = Group('group2')
    h = Host('host1')
    data = InventoryData()
    data.groups = {'group1': g, 'group2': g1}
    data.hosts = {'host1': h}
    data.set_variable('group1', 'foo', 'bar')
    data.set_variable('group2', 'foo', 'bar')
    data.set_variable('host1', 'foo', 'bar')
    assert g.get_vars()['foo'] == 'bar'
    assert g1.get_vars()['foo'] == 'bar'
    assert h.get_vars()['foo'] == 'bar'


# Generated at 2022-06-22 20:40:38.854254
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['add_child_test_inventory.ini'])
    inv_data = inv_manager.get_inventory_data()

    groups = inv_data.groups

    print("\nTesting add_child")

    group_1 = groups.get('group_1', None)
    group_2 = groups.get('group_2', None)
    group_3 = groups.get('group_3', None)
    group_4 = groups.get('group_4', None)

# Generated at 2022-06-22 20:40:48.284560
# Unit test for method serialize of class InventoryData
def test_InventoryData_serialize():
    data = InventoryData()
    data.add_group('testgroup')
    data.add_host('testhost', 'testgroup')
    data.localhost = 'testhost'

    data.current_source = '/test/path'
    data.processed_sources = ['/test/path']
    serialized = data.serialize()
    assert serialized['groups']['testgroup'] == {'hosts': ['testhost'], 'children': [], 'vars': {}}
    assert serialized['hosts']['testhost'] == {'vars': {'inventory_file': '/test/path', 'inventory_dir': '/test'},
                                               'group_names': ['all', 'testgroup', 'ungrouped']}
    assert serialized['local'] == 'testhost'
    assert serialized['source']

# Generated at 2022-06-22 20:40:52.440602
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()

    host_test = Host('test')
    host_test.vars = dict()

    inventory.add_host(host_test)

    assert(host_test in inventory.groups['all'])
    assert(host_test in inventory.groups['ungrouped'])

    inventory.add_group('test_group')
    test_group = inventory.groups['test_group']
    inventory.add_child('test_group', 'test')

    assert(host_test in test_group)

    inventory.remove_group('test_group')

    assert(host_test not in test_group)

# Generated at 2022-06-22 20:41:02.945530
# Unit test for constructor of class InventoryData
def test_InventoryData():
    d = InventoryData()
    d.add_host('host1')
    d.add_group('group1')
    assert d.get_host('host1')  is not None
    assert d.groups['group1']  is not None
    assert d.hosts['host1']  is not None
    assert d.groups['all']  is not None
    assert d.groups['ungrouped']  is not None
    assert d.add_child('all', 'group1') is True
    assert d.add_child('group1', 'host1') is True
    assert d.add_child('all', 'group1') is False
    assert d.add_child('group1', 'host1') is False

# Generated at 2022-06-22 20:41:08.769953
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():
    inventory = InventoryData()
    data = inventory.serialize()
    inventory.deserialize(data)
    assert inventory.hosts == {}
    assert inventory.groups == {}
    assert inventory.localhost is None
    assert inventory.processed_sources == []

# Generated at 2022-06-22 20:41:09.881234
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # TODO
    pass

# Generated at 2022-06-22 20:41:21.244734
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_group('group3')
    inventory.add_group('group4')

    inventory.add_child('group1', 'group2')
    inventory.add_child('group2', 'group3')
    inventory.add_child('group1', 'group4')
    assert inventory.groups['group1'].get_children() == ['group2', 'group4']
    assert inventory.groups['group2'].get_children() == ['group3']

    inventory.remove_group('group3')
    assert inventory.groups['group1'].get_children() == ['group2', 'group4']

    inventory.remove_group('group1')
    assert 'group4' not in inventory.groups

# Generated at 2022-06-22 20:41:33.634629
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    # hostname is in inventory and is in C.LOCALHOST
    localhost = InventoryData()
    localhost.hosts = {'localhost': 'host object'}
    assert localhost.get_host('localhost') == 'host object'
    # hostname is in inventory and is not in C.LOCALHOST
    localhost = InventoryData()
    localhost.hosts = {'wrong.hostname': 'host object'}
    assert localhost.get_host('wrong.hostname') == 'host object'
    # hostname is not in inventory and is in C.LOCALHOST, localhost is not in inventory and is not set
    localhost = InventoryData()
    localhost.hosts = {}
    localhost._create_implicit_localhost = MagicMock(return_value='implicit localhost')
    assert local

# Generated at 2022-06-22 20:41:43.996054
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():

    import types
    import shutil
    import tempfile
    import re

    from ansible.parsing.utils.jsonify import json_dict_unicode_to_bytes

    from ansible_collections.ansible.builtin.plugins.inventory.base import BaseInventoryPlugin
    from ansible_collections.ansible.builtin.plugins.inventory.host_list import HostList

    # Serialization of the inventory data

# Generated at 2022-06-22 20:41:55.433808
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    # testing basic group inheritance and group-host relationships
    inv = InventoryData()
    inv.add_group('all')
    inv.add_group('printer')
    inv.add_host('workhorse1', port=2222)
    inv.add_child('printer', 'workhorse1')
    inv.add_child('all', 'printer')
    inv.reconcile_inventory()

    assert inv.get_groups_dict() == {'all': ['printer'], 'printer': ['workhorse1']}
    assert inv.get_host('workhorse1').get_groups() == [inv.get_group('all'), inv.get_group('printer')]
    assert inv.get_group('all').get_children_groups() == [inv.get_group('printer')]

# Generated at 2022-06-22 20:42:02.725870
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.inventory.host import Host

    ##########################################################################
    ##  Fake classes for unittest
    #########################################################################
    class AnsibleBaseFakeInventoryManager(InventoryManager):
        def __init__(self, loader, sources=C.DEFAULT_HOST_LIST):
            self._loader = loader
            self.sources = sources
            self.parse_sources(self.sources)


    class AnsibleFakeInventoryManager(AnsibleBaseFakeInventoryManager):
        def parse_sources(self, sources):
            self

# Generated at 2022-06-22 20:42:15.200990
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():
    display.verbosity = 3

    inv_data = InventoryData()
    inv_data.deserialize({'groups': {'foo': {'name': 'foo', 'vars': {'bar': 'baz1'}, 'children': ['bar'], 'hosts': ['foo']}},
                          'hosts': {'foo': {'name': 'foo', 'groups': ['foo', 'all', 'ungrouped'], 'vars': {'bar': 'baz2'}}},
                          'local': False})

    # test number of groups
    assert(len(inv_data.groups) == 1)

    # test number of hosts
    assert(len(inv_data.hosts) == 1)

    # test host 'foo'
    assert(inv_data.hosts['foo'].name == 'foo')



# Generated at 2022-06-22 20:42:25.064332
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory = InventoryData()
    # Test with a real hostname
    # Should return the host
    host = inventory.get_host('localhost')
    assert host.name == 'localhost'

    # Test with a hostname leading to implicit localhost
    # Should return the implicit localhost
    host = inventory.get_host('127.0.0.1')
    assert host.name == '127.0.0.1'
    assert host.address == '127.0.0.1'
    assert host.implicit == True

    # Test with unknown host
    # Should return None
    host = inventory.get_host('unknown')
    assert host == None

test_InventoryData_get_host()

# Generated at 2022-06-22 20:42:35.003415
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():

    i = InventoryData()

    # Create some host and group objects, add them to inventory
    h1 = Host("h1")
    h2 = Host("h2")
    h3 = Host("h3")
    g1 = Group("g1")
    g1.add_host(h1)
    g1.add_host(h2)
    g2 = Group("g2")
    g2.add_host(h1)
    g2.add_child_group(g1)

    i.groups.update({'g1': g1, 'g2': g2})
    i.hosts.update({'h1': h1, 'h2': h2, 'h3': h3})

    # Remove one of the groups
    i.remove_group('g2')

    # Check that the group was

# Generated at 2022-06-22 20:42:44.769766
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory = InventoryData()
    inventory.add_host('test1')
    inventory.add_host('test2')
    inventory.add_host('test3')
    inventory.add_host('test4')
    inventory.add_host('test5')
    inventory.add_host('test6')
    inventory.add_host('test7')

    inventory.add_group('group1')
    inventory.add_child('group1', 'test1')
    inventory.add_child('group1', 'test2')

    inventory.add_group('group2')
    inventory.add_child('group2', 'test3')
    inventory.add_child('group2', 'test4')

    inventory.add_group('group3')
    inventory.add_child('group3', 'test5')

# Generated at 2022-06-22 20:42:52.561011
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_group("all")
    inventory.add_host("hostA", "all")
    inventory.add_host("hostB", "all")
    inventory.add_host("hostC")

    inventory.reconcile_inventory()

    assert "all" in inventory.groups
    assert "all" in inventory.groups["all"].child_groups_names
    assert "ungrouped" in inventory.groups["all"].child_groups_names

    assert "ungrouped" in inventory.groups
    assert "hostC" in inventory.groups["ungrouped"].host_names

# Generated at 2022-06-22 20:43:01.412032
# Unit test for method deserialize of class InventoryData
def test_InventoryData_deserialize():
    # Check with correct data
    inventory = InventoryData()
    data = {
        'hosts': {
            'host1': {
                'hostname': 'host1'
            }
        },
        'groups': {
            'group1': {
                'name': 'group1'
            },
            'group2': {
                'name': 'group2'
            }
        },
        'local': 'host1',
        'source': 'host1',
        'processed_sources': ['host1']
    }
    inventory.deserialize(data)
    assert inventory.hosts == {'host1': {'hostname': 'host1'}}
    assert inventory.groups == {'group1': {'name': 'group1'}, 'group2': {'name': 'group2'}}

# Generated at 2022-06-22 20:43:09.430970
# Unit test for method serialize of class InventoryData
def test_InventoryData_serialize():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    display = Display()

    loader = DataLoader()
    manager = InventoryManager(loader, sources=['/tmp/hosts.example'])

    print("\n\n\n=====\nInventory Data\n=====\n")

    inv_data = manager.get_inventory_from_sources().get_inventory_data()
    data = inv_data.serialize()

    print(data)
    return data


# Generated at 2022-06-22 20:43:13.876405
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inv = InventoryData()
    inv.add_group("group")
    assert "group" in inv.groups
    inv.add_group("group1")
    assert "group1" in inv.groups

test_InventoryData_add_group()

# Generated at 2022-06-22 20:43:22.864954
# Unit test for method set_variable of class InventoryData
def test_InventoryData_set_variable():
    inv_data = InventoryData()
    inv_data.groups = {
        'host': ['host1'],
    }
    inv_data.hosts = {
        'host1': 'host1',
        'host2': 'host2',
    }
    inv_data.set_variable('host', 'test', 'test')
    # set a group
    assert inv_data.groups['host']['vars']['test'] == 'test'
    # set a host
    assert inv_data.hosts['host2']['vars']['test'] == 'test'

# Generated at 2022-06-22 20:43:33.070387
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    # Create test inventory data object
    inventory_data = InventoryData()

    # Add two groups to the inventory_data.groups
    group1 = Group("TestGroup1")
    group2 = Group("TestGroup2")
    group3 = Group("TestGroup3")

    inventory_data.groups[group1.name] = group1
    inventory_data.groups[group2.name] = group2
    inventory_data.groups[group3.name] = group3

    # Add two hosts to the inventory_data.hosts
    host1 = Host("Host1")
    host2 = Host("Host2")
    host3 = Host("Host3")

    inventory_data.hosts[host1.name] = host1
    inventory_data.hosts[host2.name] = host2

# Generated at 2022-06-22 20:43:42.308798
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():

    # create inventory_data object
    inventory_data = InventoryData()

    # group with 1 host
    group = Group('test_group')
    host = Host('test_host')
    host.vars = {'var1': 'value1'}
    group.add_host(host)
    inventory_data.groups[group.name] = group

    # Test remove_host method
    inventory_data.remove_host(host)

    # Verify host is not in inventory_data.
    assert host.name not in inventory_data.hosts
    # Verify host not in group.
    assert host.name not in group.get_hosts()

# Generated at 2022-06-22 20:43:51.418582
# Unit test for method set_variable of class InventoryData
def test_InventoryData_set_variable():
    display = Display()

    test = InventoryData()

    # test1: Set a value to a nonexistent host.
    varname = 'test_var'
    value = 'test_value'
    test.set_variable('test_host', varname, value)
    assert test.hosts['test_host'].vars[varname] == value, 'FAILED: test.hosts["test_host"].vars["test_var"] != "test_value"'
    display.debug('PASSED: Set a value to a nonexistent host.')

    # test2: Set a value to a nonexistent group.
    test.set_variable('test_group', varname, value)

# Generated at 2022-06-22 20:44:00.676761
# Unit test for method set_variable of class InventoryData
def test_InventoryData_set_variable():

    inventory = InventoryData()

    disp = Display()
    disp.verbosity = 4

    # checking variable set for host
    inventory.add_host("test_host")
    inventory.set_variable("test_host", "test_variable", "test_value")
    assert inventory.get_host("test_host").get_vars()["test_variable"] == "test_value"

    # checking variable set for group
    inventory.add_group("test_group")
    inventory.set_variable("test_group", "test_variable", "test_value")
    assert inventory.groups["test_group"].get_vars()["test_variable"] == "test_value"

    # checking for invalid host/group

# Generated at 2022-06-22 20:44:05.538589
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    inv = InventoryData()
    inv.add_host('foo', 'foogroup')
    inv.add_host('bar', 'bargroup')
    inv.add_child('foogroup', 'bargroup')

    assert(inv.get_groups_dict() ==
           {'all': ['foo', 'bar'],
            'ungrouped': ['foo', 'bar'],
            'foogroup': ['foo', 'bar'],
            'bargroup': ['bar']
           })

if __name__ == "__main__":
    test_InventoryData_get_groups_dict()

# Generated at 2022-06-22 20:44:18.425845
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    '''
    Test case to verify that get_groups_dict() function is working as expected
    '''
    inventory = InventoryData()
    inventory.add_host('testhost1', 'group1')
    inventory.add_host('testhost2', 'group1')
    inventory.add_host('testhost3', 'group2')
    inventory.add_host('testhost4', 'group2')
    inventory.add_host('testhost5', 'group3')
    inventory.add_host('testhost6', 'group4')
    inventory.add_host('testhost7', 'group5')
    inventory.add_host('testhost8', 'group5')


# Generated at 2022-06-22 20:44:23.050033
# Unit test for method serialize of class InventoryData
def test_InventoryData_serialize():
    inv_data = InventoryData()
    data = inv_data.serialize()
    assert(len(data) == 6)
    assert('groups' in data)
    assert('hosts' in data)
    assert('local' in data)
    assert('source' in data)
    assert('processed_sources' in data)

# Generated at 2022-06-22 20:44:29.223592
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inv1 = inventory.add_host('host1', group='group1')
    group1 = inventory.add_group('group1')
    group2 = inventory.add_group('group2')
    inventory.add_child('group2','group1')
    inventory.reconcile_inventory()
    assert inv1.get_groups() == [inventory.groups['all'], inventory.groups['ungrouped']]
    assert inventory.get_hosts('group2') == [inventory.hosts['host1']]
    assert inventory.get_hosts('ungrouped') == []

# Generated at 2022-06-22 20:44:37.997933
# Unit test for constructor of class InventoryData
def test_InventoryData():

    i = InventoryData()

    assert(i.groups == {})
    assert(i.hosts == {})
    assert(i._groups_dict_cache == {})

    assert(i.current_source is None)
    assert(i.processed_sources == [])

    assert('all' in i.groups)
    assert('all' in i.groups['all'].children)
    assert('ungrouped' in i.groups['all'].children)
    assert('all' in i.groups['ungrouped'].parents)

# Generated at 2022-06-22 20:44:47.795061
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    """
    Test for method reconcile_inventory of class InventoryData which test with
    following conditions:
    1) Host in all and ungrouped
    2) Host in all, ungrouped and other groups too
    3) Host in both groups and hosts
    """
    inventory_instance = InventoryData()
    inventory_instance.add_group("all")
    inventory_instance.add_group("ungrouped")
    inventory_instance.add_host("localhost")
    inventory_instance.add_child("all", "localhost")
    inventory_instance.add_child("ungrouped", "localhost")
    # Case 1 : Host in all and ungrouped
    inventory_instance.reconcile_inventory()
    assert "localhost" in inventory_instance.hosts
    assert "localhost" in inventory_instance.hosts.get("localhost").get_

# Generated at 2022-06-22 20:44:56.386315
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory_data = InventoryData()
    inventory_data.add_group('web')
    inventory_data.add_host('192.168.1.1', 'web')
    inventory_data.add_host('192.168.1.2', 'web')
    inventory_data.add_host('192.168.1.3', 'web')
    inventory_data.add_host('192.168.1.4', 'web')
    inventory_data.remove_group('web')
    assert inventory_data.groups == {'all': Group('all'), 'ungrouped': Group('ungrouped')}

# Generated at 2022-06-22 20:45:06.118286
# Unit test for constructor of class InventoryData
def test_InventoryData():

    inventory = InventoryData()

    assert(inventory.groups["all"].name == "all")
    assert(inventory.groups["all"].vars == {})
    assert(inventory.groups["all"].children == [inventory.groups["ungrouped"]])
    assert(inventory.groups["all"].parents == [])

    assert(inventory.groups["ungrouped"].name == "ungrouped")
    assert(inventory.groups["ungrouped"].vars == {})
    assert(inventory.groups["ungrouped"].children == [])
    assert(inventory.groups["ungrouped"].parents == [inventory.groups["all"]])

# Generated at 2022-06-22 20:45:16.799534
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    data = InventoryData()
    data.add_host('dummy', 'dummy_group')

    assert data.groups['dummy_group'].has_host('dummy')
    assert len(data.groups['dummy_group'].get_hosts()) == 1

    dummy_host = data.get_host('dummy')
    data.remove_host(dummy_host)
    assert not data.groups['dummy_group'].has_host('dummy')
    assert len(data.groups['dummy_group'].get_hosts()) == 0
    assert not data.hosts.get('dummy')

# Generated at 2022-06-22 20:45:22.343617
# Unit test for method get_groups_dict of class InventoryData
def test_InventoryData_get_groups_dict():
    """
    We merge a 'magic' var 'groups' with group name keys and hostname list values into every host variable set. Cache for speed.
    """
    groupsdict_cache={}
    groupsdict_cache['group_name']=['host_name']
    InventoryData().get_groups_dict() == groupsdict_cache



# Generated at 2022-06-22 20:45:30.889689
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    host1 = Host("node1")
    host2 = Host("node2")
    host3 = Host("node3")
    g1 = Group("g1")
    g2 = Group("g2")
    g3 = Group("g3")

    i = InventoryData()
    i.groups[g1.name] = g1
    i.groups[g2.name] = g2
    i.groups[g3.name] = g3
    i.hosts[host1.name] = host1
    i.hosts[host2.name] = host2
    i.hosts[host3.name] = host3

    # Test add_child function
    i.add_child(g1.name, host1.name)

# Generated at 2022-06-22 20:45:42.556997
# Unit test for method deserialize of class InventoryData

# Generated at 2022-06-22 20:45:47.205332
# Unit test for method set_variable of class InventoryData
def test_InventoryData_set_variable():

    # initialize inventory object
    inventory_data = InventoryData()

    inventory_data.set_variable("localhost", "testvar1", "testval1")

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 20:45:55.745905
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    hosts = [u'c64-a', u'c64-b', u'c64-c', u'c64-d', u'c64-e']
    hosts.sort()
    groups = [u'database', u'webservers', u'workstations']
    groups.sort()
    variables = dict(
        a_variable='success',
        other_variable=dict(
            a_nested_variable='success',
            another_nested_variable='success'
        )
    )

    # create the inventory and feed it with hosts, groups and variables
    loader = DataLoader()
