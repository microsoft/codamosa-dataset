

# Generated at 2022-06-24 19:28:33.811815
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    group_1 = inventory_data_1.add_group('group_1')
    group_2 = inventory_data_1.add_group('group_2')
    group_3 = inventory_data_1.add_group('group_3')
    group_4 = inventory_data_1.add_group('group_4')
    group_5 = inventory_data_1.add_group('group_5')
    group_6 = inventory_data_1.add_group('group_6')
    group_7 = inventory_data_1.add_group('group_7')
    group_8 = inventory_data_1.add_group('group_8')
    group_9 = inventory_data_1.add_group('group_9')
    group_10 = inventory_data

# Generated at 2022-06-24 19:28:36.657447
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("test_host_0", "test_group_0")


# Generated at 2022-06-24 19:28:44.073157
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()

    # Assign value to variable host
    host = "ansible.com"

    # Use method remove_host of inventory_data_0
    result = inventory_data_0.remove_host(host)
    display.debug("HERE")
    display.debug("HERE: %s" % result)


# Generated at 2022-06-24 19:28:46.373194
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    host = inventory_data_0.add_host("A")

    inventory_data_0.remove_host(host)


# Generated at 2022-06-24 19:28:57.039846
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()

    inventory_data_1.add_host("b")
    inventory_data_1.add_host("c")
    inventory_data_1.add_host("a")
    inventory_data_1.add_group("a")
    inventory_data_1.add_group("b")
    inventory_data_1.add_group("c")
    inventory_data_1.add_child("c", "c")
    inventory_data_1.add_child("c", "b")
    inventory_data_1.add_child("b", "b")
    inventory_data_1.add_child("b", "a")
    inventory_data_1.add_child("a", "a")
    inventory_data_1.add_child("a", "c")

    inventory

# Generated at 2022-06-24 19:29:05.626309
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()

    # set inventory source
    inventory_data_0.current_source = 'test_case_0'
    # add group 'test_group_0'
    test_group_0 = inventory_data_0.add_group('test_group_0')

    # add host 'test_host_0'
    test_host_0 = inventory_data_0.add_host('test_host_0', test_group_0)

    # add child 'test_host_0' to group 'test_group_0'
    inventory_data_0.add_child('test_group_0', 'test_host_0')

    # remove host 'test_host_0'
    inventory_data_0.remove_host(test_host_0)


# Generated at 2022-06-24 19:29:15.434271
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data = InventoryData()
    print('Test for method add_child of class InventoryData started...')

    print('Add a group to group all')
    group_name = 'ansible'
    inventory_data.add_group(group_name)
    is_add = inventory_data.add_child('all', group_name)
    if is_add:
        print("Group %s was added to group all" % group_name)
    else:
        print("Group %s wasn't added to group all" % group_name)

    print('Try to add an unknown group to group all')
    group_name = 'hansible'
    is_add = inventory_data.add_child('all', group_name)
    if is_add:
        print("Group %s was added to group all" % group_name)


# Generated at 2022-06-24 19:29:17.878731
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host("localhost")
    inventory_data_0.remove_host("localhost")

# Generated at 2022-06-24 19:29:23.488616
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('test')
    inventory_data_1.add_host('host1','test')
    assert inventory_data_1.get_host('host1').get_groups()[0].name == 'test'
    return inventory_data_1



# Generated at 2022-06-24 19:29:29.143561
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    test_inv_data = InventoryData()
    test_inv_data.add_host('test-host1')
    test_inv_data.add_host('test-host2')
    test_inv_data.add_host('test-host3')
    test_inv_data.add_group('test-group1')
    test_inv_data.add_group('test-group2')
    test_inv_data.add_group('test-group3')
    test_inv_data.add_child('test-group1', 'test-group2')
    test_inv_data.add_child('test-group2', 'test-group3')
    test_inv_data.add_child('test-group3', 'test-host1')

# Generated at 2022-06-24 19:29:43.650279
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    host_name = 'localhost'
    group_name = 'group1'
    inventory_data_0.add_host(hostname=host_name, group=group_name)
    assert inventory_data_0.get_host('localhost')


# Generated at 2022-06-24 19:29:49.282701
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_obj = InventoryData()
    new_host = Host("test_host")
    new_group = Group("test_group")
    inventory_data_obj.hosts["test_host"] = new_host
    inventory_data_obj.groups["test_group"] = new_group
    new_group.add_host(new_host)
    inventory_data_obj.remove_host(new_host)
    assert not new_host in new_group.get_hosts()



# Generated at 2022-06-24 19:29:56.523944
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():

    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('host_1')
    inventory_data_1.add_host('host_2')
    inventory_data_1.add_host('host_3')

    assert inventory_data_1.get_host('host_1').name == 'host_1'
    assert inventory_data_1.get_host('host_2').name == 'host_2'
    assert inventory_data_1.get_host('host_3').name == 'host_3'



# Generated at 2022-06-24 19:30:00.851875
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()

    host_name = "test"
    host = Host(host_name)
    inventory_data.hosts[host_name] = host

    assert inventory_data.get_host("test") is host


# Generated at 2022-06-24 19:30:10.319883
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # Create test objects
    inventory = InventoryData()
    Host.check_name_validity = lambda self: True

    # Create a simple inventory with one group and one host
    group_name = "testgroup"
    host_name = "testhost"
    inventory.add_group(group_name)
    inventory.add_host(host_name, group_name)

    # Remove the host from the inventory
    host = inventory.get_host(host_name)
    inventory.remove_host(host)

    # Check that the host was removed from the group
    group = inventory.get_group(group_name)
    assert group.get_hosts(all=True) == []
    assert group.get_hosts() == []
    assert group.get_hosts(ignore_limits=True) == []
    assert group.get

# Generated at 2022-06-24 19:30:15.910236
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()

    inventory_data_1.add_host("host_1", "group_1")
    inventory_data_1.add_host("host_2", "group_1")

    inventory_data_1.remove_host(inventory_data_1.hosts["host_1"])

    # Expecting "host_1" not to be found in inventory
    if inventory_data_1.hosts.get("host_1", "Error") != "Error":
        print("Failed test_InventoryData_remove_host: Test 1")
        return False

    # Expecting "host_2" to be found in inventory

# Generated at 2022-06-24 19:30:21.539361
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    assert inventory_data.hosts is not None and len(inventory_data.hosts) == 2
    inventory_data.remove_host(Host('host1'))
    assert inventory_data.hosts is not None and len(inventory_data.hosts) == 1
    assert inventory_data.hosts.get('host1') == None
    assert inventory_data.hosts.get('host2') != None

# Generated at 2022-06-24 19:30:26.311251
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group1')
    inventory_data.add_host('host3', 'group1')
    inventory_data.add_host('host4', 'group1')
    inventory_data.remove_host(inventory_data.hosts['host1'])


# Generated at 2022-06-24 19:30:29.420207
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    host_name = "localhost"
    inventory_data.get_host(host_name)


# Generated at 2022-06-24 19:30:32.165384
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory(
        )

# Generated at 2022-06-24 19:30:48.491624
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    group_add = inventory_data.add_group
    group_add('test_group1')
    group_add('test_group2')
    host_add = inventory_data.add_host


    host_add('test_host1', 'test_group1')
    host_add('test_host2', 'test_group2')
    host_add('test_host3', 'test_group3')

    # call reconcile_inventory() function
    inventory_data.reconcile_inventory()

    # localhost should be created with implicit=True
    assert inventory_data.localhost.implicit == True, 'localhost should be created as Implicit'

    # test_group3 should not be added to groups

# Generated at 2022-06-24 19:30:57.998486
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data_1 = InventoryData()

    inventory_data_1.add_host("192.168.1.10")
    inventory_data_1.add_host("192.168.1.11")
    inventory_data_1.add_host("192.168.1.12")

    inventory_data_1.add_group("node1")
    inventory_data_1.add_group("node2")
    inventory_data_1.add_group("node3")

    inventory_data_1.add_child("node1", "192.168.1.10")
    inventory_data_1.add_child("node2", "192.168.1.11")
    inventory_data_1.add_child("node3", "192.168.1.12")

    inventory_data_1.reconcile

# Generated at 2022-06-24 19:31:04.311001
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    host_name = 'cancelled'
    try:
        inventory_data_0.add_host(host_name=host_name)
    except AnsibleError as err:
        assert host_name in err.message
    else:
        raise Exception("Expected AnsibleError to be thrown")


# Generated at 2022-06-24 19:31:11.021752
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    try:
        inventory_data_1 = InventoryData()
        inventory_data_1.add_group('filter_plugins')
        inventory_data_1.add_group('connection_plugins')
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-24 19:31:15.567977
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    i = InventoryData()
    i.add_host("host01", "group01")
    i.add_group("group01")
    i.add_child("group01", "host01")
    assert "host01" in i.groups["group01"].hosts
    assert "group01" in i.hosts["host01"].groups


# Generated at 2022-06-24 19:31:25.507767
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    '''
    1. Test with hosts & groups
    2. Test with no hosts & groups
    3. Test with hosts & no groups
    4. Test with groups & no hosts
    '''
    # Test case 1
    inventory_data_1 = InventoryData()
    host1 = Host('host1')
    host2 = Host('host2')
    group1 = Group('group1')
    group2 = Group('group2')
    inventory_data_1.hosts = {'host1' : host1, 'host2' : host2}
    inventory_data_1.groups = {'group1' : group1, 'group2' : group2}
    inventory_data_1.reconcile_inventory()

    # Test case 2
    inventory_data_2 = InventoryData()
    inventory_data_2.re

# Generated at 2022-06-24 19:31:30.120675
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    Host_0 = Host("Hello")
    inventory_data_0.add_host(Host_0.name)
    inventory_data_0.reconcile_inventory()



# Generated at 2022-06-24 19:31:36.897661
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    # Tests for the case when group is not there already
    inventory_data_0 = InventoryData()
    group_0 = "group_0"
    InventoryData.add_group(inventory_data_0, group_0)

# Generated at 2022-06-24 19:31:45.211086
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('all')
    inventory_data_1.add_group('webserver')
    inventory_data_1.add_group('dbserver')
    inventory_data_1.add_host('localhost')
    inventory_data_1.add_host('172.16.0.1')
    inventory_data_1.add_host('172.16.0.2')
    inventory_data_1.add_host('172.16.0.3')
    inventory_data_1.add_child('webserver','172.16.0.1')
    inventory_data_1.add_child('webserver','172.16.0.2')

# Generated at 2022-06-24 19:31:57.759661
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    display.debug("Testing add_host method")
    host_names = ['host1', 'host2', 'host3']
    groups_names = ['group1', 'group2']
    host1_port = 22
    host2_port = 13
    host3_port = 13
    assert inventory_data.add_host(host_names[0], group = groups_names[0], port = host1_port) == host_names[0]
    assert inventory_data.add_host(host_names[1], group = groups_names[0]) == host_names[1]
    assert inventory_data.add_host(host_names[2], group = groups_names[1], port = host3_port) == host_names[2]
    assert 'host1' in inventory_data.host

# Generated at 2022-06-24 19:32:03.656133
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    assert True


# Generated at 2022-06-24 19:32:07.674393
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.set_variable('localhost', 'a', 'b')
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.hosts['localhost'].vars['a'] == 'b'


# Generated at 2022-06-24 19:32:11.271623
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    group = 'group'
    inventory_data_0.add_group(group)
    assert group in inventory_data_0.groups


# Generated at 2022-06-24 19:32:12.200511
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    test_case_0()

# Generated at 2022-06-24 19:32:22.700652
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()

    #case 1: testing ungrouped hosts
    test_host_0 = Host("test_host_0")
    test_host_1 = Host("test_host_1")
    test_host_2 = Host("test_host_2")
    test_host_3 = Host("test_host_3")

    inventory_data_1.hosts = {
        "test_host_0": test_host_0,
        "test_host_1": test_host_1,
        "test_host_2": test_host_2,
        "test_host_3": test_host_3
    }


# Generated at 2022-06-24 19:32:27.387923
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    # Test fail, check:
    # instrumented __init__ method to not set ungrouped hosts
    # No hosts exist
    inventory_data_0.reconcile_inventory()  # should raise AnsibleError


# Generated at 2022-06-24 19:32:37.197617
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()

    inventory_data_1.add_group('test_group_1')
    inventory_data_1.add_group('test_group_2')
    inventory_data_1.add_group('test_group_3')
    inventory_data_1.add_host('test_host_1')
    inventory_data_1.add_host('test_host_2')
    inventory_data_1.add_host('test_host_3')
    inventory_data_1.add_child('test_group_1', 'test_host_1')
    inventory_data_1.add_child('test_group_2', 'test_host_2')
    inventory_data_1.add_child('test_group_3', 'test_host_3')
    inventory_data_

# Generated at 2022-06-24 19:32:45.312573
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    display.display('test_InventoryData_reconcile_inventory() started')

    inventory_data_0 = InventoryData()
    inventory_data_0.current_source = 'inventory.file'
    inventory_data_0.processed_sources = []

    inventory_data_0._groups_dict_cache = {}

    group_0 = Group('all')
    group_0.vars = {}

    group_1 = Group('ungrouped')
    group_1.vars = {}

    inventory_data_0.groups['all'] = group_0
    inventory_data_0.groups['ungrouped'] = group_1

    host_0 = Host('localhost')
    host_0.name = 'localhost'
    host_0.address = '127.0.0.1'
    host_0.impl

# Generated at 2022-06-24 19:32:51.962751
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("memsql")

    host_data_0 = inventory_data_1.get_host("memsqldb1")
    assert(host_data_0 == None)
    assert(host_data_0 == None)

    host_data_1 = inventory_data_1.get_host("memsqldb1")
    assert(host_data_1 == None)
    assert(host_data_1 == None)

    inventory_data_1.reconcile_inventory()


# Generated at 2022-06-24 19:32:56.114930
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    test_group_name = "test_group_1"
    inventory_data_1.add_group(test_group_name)
    assert test_group_name in inventory_data_1.groups
    test_group_name = "test_group_2"
    inventory_data_1.add_group(test_group_name)
    assert test_group_name in inventory_data_1.groups


# Generated at 2022-06-24 19:33:05.132162
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:33:08.881371
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    inv_data_1 = inventory_data_1.add_group('hrs')
    assert inv_data_1 == 'hrs'


# Generated at 2022-06-24 19:33:14.156872
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    test_group_3 = 'all'
    test_group_5 = 'all'
    test_group_6 = 'ungrouped'
    inventory_data_1.add_group(test_group_3)
    inventory_data_1.add_group(test_group_5)
    inventory_data_1.add_group(test_group_6)


# Generated at 2022-06-24 19:33:17.848351
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()

    inventory_data_0.reconcile_inventory()

test_InventoryData_reconcile_inventory()

# Generated at 2022-06-24 19:33:22.808601
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_reconcile_inventory_0 = InventoryData()
    inventory_data_reconcile_inventory_0.current_source = 'test_dummy_data_0'
    inventory_data_reconcile_inventory_0.processed_sources = [ 'test_dummy_data_1', 'test_dummy_data_2' ]
    inventory_data_reconcile_inventory_0.reconcile_inventory()
    assert inventory_data_reconcile_inventory_0.current_source == 'test_dummy_data_0'
    assert inventory_data_reconcile_inventory_0.processed_sources == [ 'test_dummy_data_1', 'test_dummy_data_2' ]


# Generated at 2022-06-24 19:33:27.783673
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()

    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:33:29.155015
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0= InventoryData()
    inventory_data_0.add_group('test1')
    assert inventory_data_0.groups['test1'] == 'test1'


# Generated at 2022-06-24 19:33:39.839866
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Test add_host with group not in inventory
    inventory_data_1 = InventoryData()
    group = "group_1"
    group_2 = "group_2"
    host_name = "host_name_1"
    host_name_1 = "host_name_2"
    host_name_2 = "host_name_3"
    port = 2222
    host_name_invalid = None
    port_invalid = None

    try:
        result_1 = inventory_data_1.add_host(host_name, group)
    except AnsibleError:
        result_1 = None

    assert result_1 == None, "Invalid test - should raise exception"
    
    # Test add_host with port not in inventory

# Generated at 2022-06-24 19:33:46.817548
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    # case 0: add group to a blank inventory
    test_case_0()

    # case 1: add group to an inventory that contains group already
    test_case_0()
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("all")
    inventory_data_1.add_group("hosts")

    # case 2: add group to an inventory that contains host already
    test_case_0()
    inventory_data_2 = InventoryData()
    inventory_data_2.add_host("all", "hosts")
    inventory_data_2.add_host("hosts")

    # case 3: add group to an inventory that contains both group and host
    test_case_0()
    inventory_data_3 = InventoryData()
    inventory_data_3.add_host("all")

# Generated at 2022-06-24 19:33:53.608109
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data_1 = InventoryData()
    #
    # Add host and group to inventory
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_group("group1")
    #
    # Reconcile inventory
    inventory_data_1.reconcile_inventory()
    #
    # Add host and group to inventory
    inventory_data_1.add_group("group2")
    inventory_data_1.add_child("group2", "group1")
    inventory_data_1.add_child("group2", "host1")
    #
    # Reconcile inventory
    inventory_data_1.reconcile_inventory()

    assert inventory_data_1.get_host("host1") is not None

# Generated at 2022-06-24 19:34:02.362919
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    group = 'group'
    inventory_data_0.add_group(group)
    return True


# Generated at 2022-06-24 19:34:05.892697
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Create InventoryData object
    inventory_data_1 = InventoryData()
    # Try to add a host that doesn't exist in the inventory
    if inventory_data_1.add_host("test_host", group="test_group") == "test_host":
        print ("PASS")
    else:
        print ("FAIL")


# Generated at 2022-06-24 19:34:16.584106
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    print("--- test_InventoryData_reconcile_inventory")
    inventory_data_reconcile = InventoryData()
    group_name_1 = "group1"
    group_name_2 = "group2"
    group_name_1_child = "group1child"
    group_name_2_child = "group2child"
    host_1 = "10.0.0.1"
    host_2 = "10.0.0.2"
    inventory_data_reconcile.add_group(group_name_1)
    inventory_data_reconcile.add_group(group_name_1_child)
    inventory_data_reconcile.add_group(group_name_2)
    inventory_data_reconcile.add_host(host_1)

# Generated at 2022-06-24 19:34:22.215556
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    # Success case
    inventory_data_1.add_host(host='host_0', group='group_0')
    inventory_data_1.add_host(host='host_1', group='group_1')
    inventory_data_1.add_host(host='host_2')
    inventory_data_1.reconcile_inventory()



# Generated at 2022-06-24 19:34:26.224915
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = "new_group"
    inventory_data.add_group(group_name)
    assert group_name in inventory_data.groups
    del inventory_data.groups[group_name]


# Generated at 2022-06-24 19:34:31.149034
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('group_1')
    inventory_data_1.add_host('host_1','group_1')
    inventory_data_1.add_child('group_1','host_2')
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.hosts['host_1'].get_groups().pop().name == 'all'
    assert inventory_data_1.hosts['host_2'].get_groups().pop().name == 'all'

# Generated at 2022-06-24 19:34:41.526262
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    print("***Unit Test: InventoryData.add_group()")
    idata = InventoryData()

    print("Test1:")
    print("***** Empty group *****")
    try:
        idata.add_group('')
    except AnsibleError as e:
        print(e)
        print("Checking passed\n")
    else:
        print("Checking failed\n")

    print("Test2:")
    print("***** Existing group *****")
    idata.groups['all'] = Group('all')
    idata.add_group('all')
    print("Checking passed\n")

    print("Test3:")
    print("***** Add group to inventory *****")
    name = idata.add_group('ungrouped')

# Generated at 2022-06-24 19:34:46.638587
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Create an instance of InventoryData,
    inventory_data_0 = InventoryData()
    # Invoke method add_host of class InventoryData on instance inventory_data_0 with the following parameters,
    inventory_data_0.add_host(host='test_host_0', port='test_port_0', group='test_group_0')


# Generated at 2022-06-24 19:34:49.430753
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group("group_0")
    assert inventory_data_0.groups["group_0"].name == "group_0"

# Generated at 2022-06-24 19:34:58.948125
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # GIVEN
    inventory_data_1 = InventoryData()
    host = "Host1"
    group = "Group1"
    port = "Port1"
    
    # WHEN
    inventory_data_1.add_host(host, group, port)
    
    # THEN
    assert inventory_data_1.hosts[host].name == host
    assert inventory_data_1.hosts[host].port == port
    assert len(inventory_data_1.groups) == 3
    assert inventory_data_1.groups[group].name == group
    assert len(inventory_data_1.groups[group].hosts) == 1
    assert inventory_data_1.groups[group].hosts[0].name == host
    

# Generated at 2022-06-24 19:35:15.804000
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    test_group_name = 'test_group'
    test_group = inventory_data.add_group(test_group_name)
    assert test_group_name == test_group


# Generated at 2022-06-24 19:35:19.428212
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    print("Testing reconcile_inventory(self) of class InventoryData:")
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:35:29.153913
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    inventory_data = InventoryData()

    inventory_data.add_host('testaddhost')
    inventory_data.add_host('testaddhost2', 'testaddhostgroup')
    inventory_data.add_host('testaddhost3', 'testaddhostgroup')

    assert len(inventory_data.hosts) == 3
    assert len(inventory_data.groups) == 3
    assert len(inventory_data.groups['testaddhostgroup'].get_hosts()) == 2
    assert len(inventory_data.groups['testaddhostgroup'].get_groups()) == 1
    assert len(inventory_data.groups['all'].get_hosts()) == 3
    assert len(inventory_data.groups['all'].get_groups()) == 3


# Generated at 2022-06-24 19:35:35.985825
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group_1")
    inventory_data_1.add_host("host_1")
    assert "host_1" == inventory_data_1.hosts["host_1"].name
    assert "host_1" == inventory_data_1.groups["group_1"].hosts["host_1"].name


# Generated at 2022-06-24 19:35:37.730436
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    if inventory_data_1.add_host("localhost"):
        print("Host localhost added")
    else:
        print("Host localhost not added")


# Generated at 2022-06-24 19:35:46.798525
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group('group')
    inventory_data.add_host('localhost')
    inventory_data.add_host('localhost', 'group')
    inventory_data.reconcile_inventory()
    got_output = inventory_data.groups
    expected_output = {'group': Group(name='group'), 'all': Group(name='all'), 'ungrouped': Group(name='ungrouped')}
    assert got_output == expected_output

# Generated at 2022-06-24 19:35:53.814842
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory = InventoryData()
    inventory.add_host('127.0.0.1', 'all')
    inventory.add_group('group1')
    inventory.add_group('group2')
    inventory.add_child('group1','group2')
    inventory.add_child('group2','127.0.0.1')
    inventory.reconcile_inventory()
    assert len(inventory.groups['group1'].get_hosts()) == 1
    assert len(inventory.groups['group2'].get_hosts()) == 1
    assert len(inventory.groups['ungrouped'].get_hosts()) == 0
    assert len(inventory.groups['all'].get_hosts()) == 1
    assert len(inventory.groups['all'].get_children()) == 2

# Generated at 2022-06-24 19:35:56.017274
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:36:06.097195
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('jerry')
    inventory_data_1.add_host('localhost', 'jerry')
    inventory_data_1.add_host('tom', 'jerry')
    inventory_data_1.reconcile_inventory()
    #   host 'localhost' should have 2 groups: all and jerry
    h_localhost_groups = inventory_data_1.hosts['localhost'].get_groups()
    assert len(h_localhost_groups) == 2
    assert h_localhost_groups[0].name == 'all' or h_localhost_groups[1].name == 'all'
    assert h_localhost_groups[0].name == 'jerry' or h_localhost_groups[1].name == 'jerry'
    #   group 'all

# Generated at 2022-06-24 19:36:10.223809
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host('sometest_host')


# Generated at 2022-06-24 19:36:32.579137
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    host_0 = 'test_host'
    group_0 = 'test_group'
    port_0 = 22
    result = inventory_data_0.add_host(host_0, group_0, port_0)
    assert result == host_0


# Generated at 2022-06-24 19:36:43.635934
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test_host = "TEST_HOST"
    test_host_2 = "TEST_HOST_2"
    test_group = "TEST_GROUP"
    test_group_2 = "TEST_GROUP_2"

    inventory = InventoryData()
    host_object = inventory.get_host(test_host)
    assert host_object is None

    inventory.add_host(test_host, group=test_group)
    host_object = inventory.get_host(test_host)
    assert host_object is not None

    groups = host_object.get_groups()
    assert len(groups) == 2
    assert groups[0].name == "all"
    assert groups[1].name == test_group

    group_object = inventory.add_group(test_group_2)
    assert group_

# Generated at 2022-06-24 19:36:48.813966
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.hosts = {
        'host1': 'host1',
        'host2': 'host2',
        'host3': 'host3'
    }
    inventory_data.groups = {
        'group1': 'group1',
        'group2': 'group2'
    }
    inventory_data.processed_sources = [1, 2, 3]
    inventory_data.current_source = 'source'
    inventory_data.reconcile_inventory()
    print ("Expected result: {'group2': 'group2', 'group1': 'group1', 'all': 'all'}")
    print ("Actual result: {0}".format(inventory_data.groups))


# Generated at 2022-06-24 19:36:50.456243
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()

    group = "group"
    group_1 = inventory_data_0.add_group(group)


# Generated at 2022-06-24 19:36:56.078397
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group_1")
    inventory_data_1.add_group("group_2")
    inventory_data_1.add_group("group_3")
    inventory_data_1.add_group("group_4")

    inventory_data_1.add_child("group_1","group_2")
    inventory_data_1.add_child("group_1","group_3")
    inventory_data_1.add_child("group_3","group_4")

    inventory_data_1.add_host("host_1")
    inventory_data_1.add_host("host_2")
    inventory_data_1.add_host("host_3")
    inventory_data_1.add_host("host_4")



# Generated at 2022-06-24 19:36:58.575166
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    ''' test for method InventoryData.reconcile_inventory '''
    inventory_data_0 = InventoryData()

    # test below should pass without any exceptions
    inventory_data_0.reconcile_inventory()
    
    return


# Generated at 2022-06-24 19:37:04.973116
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test_inventory_data = InventoryData()
    test_inventory_data.add_group('test_group')
    test_inventory_data.add_host('test_host', group='test_group')
    assert test_inventory_data.groups['test_group'].hosts['test_host']


# Generated at 2022-06-24 19:37:07.622489
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    test_cases = ['test_case_0']
    for test_case in test_cases:
        name = test_case
        globals()[name]()

# Generated at 2022-06-24 19:37:10.256087
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group(None)



# Generated at 2022-06-24 19:37:19.068688
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group2', 'host1')
    inventory_data.add_child('group2', 'host2')
    inventory_data.add_child('group1', 'group2')
    inventory_data.reconcile_inventory()
    hosts = inventory_data.hosts
    assert len(hosts) == 2
    assert sorted(hosts) == sorted(['host1', 'host2'])
    groups = inventory_data.groups
    assert len(groups) == 3

# Generated at 2022-06-24 19:37:58.883387
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    test_host = inventory_data.add_host("test_host", "test_group")
    assert test_host == "test_host"
    test_host_dup = inventory_data.add_host("test_host", "test_group")
    assert test_host_dup == "test_host"
