

# Generated at 2022-06-24 19:28:25.207247
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    import copy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Inventory Data Dump
    display.debug("Testing reconcile_inventory() method of class InventoryData")
    display.debug("----------------------------------------------------------------------------------------")
    display.debug("Test Case 1: Expected behavior")
    display.debug("----------------------------------------------------------------------------------------")
    inventory_data_0 = InventoryData()
    inventory_data_0.hosts = copy.deepcopy(dict({"host-1": Host("host-1")}))
    inventory_data_0.hosts["host-1"].address = "127.0.0.1"
    inventory_data_0.hosts["host-1"].port = 22
    inventory_data_0.hosts["host-1"].implicit

# Generated at 2022-06-24 19:28:26.665473
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.get_groups_dict()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:28:33.220518
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("host-1", "group-1")
    inventory_data_1.add_host("host-2", "group-2")
    inventory_data_1.add_host("host-1", "group-2")
    var_1 = inventory_data_1.get_host("host-1")
    var_2 = [g.name for g in var_1.get_groups()]
    assert var_2 == ['group-1', 'group-2']


# Generated at 2022-06-24 19:28:45.853293
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():

    print("test_InventoryData_remove_host")

    my_inventory_data = InventoryData()
    n_hosts_before = len(my_inventory_data.hosts)
    my_inventory_data.add_host("local_host")
    my_inventory_data.add_host("local_host2")
    my_inventory_data.add_host("local_host3")
    n_hosts_after_add = len(my_inventory_data.hosts)

    # Check if the number of hosts is increased by one
    assert n_hosts_after_add == n_hosts_before + 3

    # Remove host
    my_inventory_data.remove_host(my_inventory_data.hosts["local_host"])

# Generated at 2022-06-24 19:28:51.518484
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    host_0 = 'localhost'
    group_0 = 'all'
    port_0 = 22
    inventory_data_0 = InventoryData()
    host_1 = inventory_data_0.add_host(host_0, group_0, port_0)
    assert host_0 == host_1


# Generated at 2022-06-24 19:28:55.638201
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    host_0 = Host('localhost')
    inventory_data_0.remove_host(host_0)
    assert inventory_data_0.groups.get('all').get_hosts() == []


# Generated at 2022-06-24 19:29:02.454284
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    g_name_0 = 'all'
    inventory_data.add_group(g_name_0) #Invoke method
    g_name_1 = 'un'
    inventory_data.add_group(g_name_1) #Invoke method
    inventory_data.add_group(g_name_1) #Invoke method
    var_0 = inventory_data.groups
    var_1 = inventory_data.get_groups_dict()


# Generated at 2022-06-24 19:29:09.101303
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data = InventoryData()

    # Test case 0:
    # Test of the function with one child element and one group
    # add_child should add the child to the list of children of the group
    # add_child should return True
    test_0_group = 'TestGroup0'
    test_0_child = 'TestChild0'
    inventory_data.add_group(test_0_group)
    inventory_data.add_host(test_0_child)
    assert inventory_data.add_child(test_0_group, test_0_child) == True
    assert inventory_data.groups[test_0_group].get_hosts() == [inventory_data.hosts[test_0_child]]
    assert inventory_data.groups[test_0_group].get_children_groups() == []

   

# Generated at 2022-06-24 19:29:17.023145
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data_1 = InventoryData()
    inventory_data_2 = InventoryData()
    inventory_data_3 = InventoryData()
    inventory_data_4 = InventoryData()
    inventory_data_5 = InventoryData()
    inventory_data_6 = InventoryData()
    inventory_data_7 = InventoryData()
    inventory_data_8 = InventoryData()
    inventory_data_9 = InventoryData()
    inventory_data_10 = InventoryData()
    inventory_data_11 = InventoryData()
    inventory_data_12 = InventoryData()
    inventory_data_13 = InventoryData()
    inventory_data_14 = InventoryData()
    inventory_data_15 = InventoryData()
    inventory_data_16 = InventoryData()

# Generated at 2022-06-24 19:29:28.132805
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Test add_child
    inventory_data_1 = InventoryData()
    inventory_data_1.reconcile_inventory()
    inventory_data_2 = InventoryData()
    inventory_data_2.add_group('a1')
    inventory_data_2.add_group('a2')
    inventory_data_2.add_group('a3')
    inventory_data_2.add_child('a2', 'a1')
    inventory_data_2.add_child('a1', 'a3')
    inventory_data_2.reconcile_inventory()
    inventory_data_2.get_host('a2')
    inventory_data_2.get_host('a1')
    inventory_data_2.get_host('a3')

# Generated at 2022-06-24 19:29:41.746540
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data = InventoryData()

    inventory_data.add_host('host_0', group='group_0')
    inventory_data.set_variable('host_0', 'var_0', 'val_0')

    inventory_data.add_host('host_1', group='group_1')
    inventory_data.set_variable('host_1', 'var_0', 'val_0')

    inventory_data.add_group('group_0')
    inventory_data.set_variable('group_0', 'g_var_0', 'val_0')
    inventory_data.add_child('group_0', 'group_1')

    inventory_data.reconcile_inventory()

    assert inventory_data.groups['all'].get_ancestors() == []

# Generated at 2022-06-24 19:29:42.896067
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    InventoryData.add_host(InventoryData(), "hostname", "group")

# Generated at 2022-06-24 19:29:44.359812
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host("Some Host")

# Generated at 2022-06-24 19:29:51.354233
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    inventory_data.add_host('localhost', 'group1')
    assert inventory_data.get_host('localhost') is not None
    assert inventory_data.get_host('127.0.0.1') is not None
    assert inventory_data.get_host('127.0.0.2') is None
    assert inventory_data.get_host('127.0.0.2') is not None

# This is a test case from the legacy inventory script.

# Generated at 2022-06-24 19:29:54.369956
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    ''' Test that invalid conflicts are detected in reconcile_inventory '''
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host('test_host_0')
    inventory_data_0.add_group('test_host_0')
    with pytest.raises(AnsibleError):
        inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:30:06.130682
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    assert (inventory_data_0.add_group('all') == 'all')
    assert (inventory_data_0.add_group('all') == 'all')
    assert (inventory_data_0.add_group('ungrouped') == 'ungrouped')
    assert (inventory_data_0.add_group('ungrouped') == 'ungrouped')
    assert (inventory_data_0.add_group('My Group') == 'My Group')
    assert (inventory_data_0.add_group('My Group') == 'My Group')
    assert (inventory_data_0.add_group('1234') == '1234')
    assert (inventory_data_0.add_group('1234') == '1234')

# Generated at 2022-06-24 19:30:15.189475
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():

    inventory_data_a = InventoryData()
    inventory_data_a.add_host("localhost")
    inventory_data_a.add_host("127.0.0.1")
    assert inventory_data_a.get_host("localhost") == inventory_data_a.get_host("127.0.0.1")
    assert inventory_data_a.get_host("localhost") is not None

    inventory_data_b = InventoryData()
    inventory_data_b.add_host("testhost")
    assert inventory_data_b.get_host("testhost") is not None


# Generated at 2022-06-24 19:30:18.985944
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_add_group = InventoryData()
    group_name = 'test_group'
    group = inventory_data_add_group.add_group(group_name)
    if group:
        assert group == 'test_group'
        assert(group in inventory_data_add_group.groups)
    else:
        assert False


# Generated at 2022-06-24 19:30:25.699957
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data_1 = InventoryData()

    # Set up InventoryData object to test
    inventory_data_1.add_host('127.0.0.1', 'group1')
    inventory_data_1.add_host('google.com', 'www')
    inventory_data_1.add_host('yahoo.com', 'www')
    inventory_data_1.add_host('facebook.com', 'www')
    inventory_data_1.add_host('twitter.com', 'www')
    inventory_data_1.add_host('github.com', 'www')

    for i in range(0, 5):
        inventory_data_1.add_host('127.0.0.1')

    # Test #1
    assert inventory_data_1.get_host('127.0.0.1') == inventory

# Generated at 2022-06-24 19:30:28.635973
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group_1")
    assert inventory_data_1.groups.get("group_1") is not None
    assert len(inventory_data_1.groups) is 1


# Generated at 2022-06-24 19:30:37.686375
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data_0 = InventoryData()
    inventory_data.reconcile_inventory()
    display.display(inventory_data)
    display.display(inventory_data_0)


# Generated at 2022-06-24 19:30:45.810364
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_group("group1")
    inventory_data.add_group("group2")
    inventory_data.add_host("host1", "group1")
    inventory_data.add_host("host2", "group1")
    inventory_data.add_host("host3")
    inventory_data.reconcile_inventory()
    assert inventory_data.get_host("host3").get_groups() == [inventory_data.groups["all"]]
    assert len(inventory_data.groups["ungrouped"].get_hosts()) == 1
    assert inventory_data.groups["ungrouped"].get_hosts()[0].name == "host3"

if __name__ == '__main__':
    test_InventoryData_reconcile_

# Generated at 2022-06-24 19:30:54.594016
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    '''
    This method tests if the reconcile_inventory method will call groups 'remove' function.
    '''
    inventory_data = InventoryData()
    inventory_data.add_group('parent')
    inventory_data.add_host('host')
    inventory_data.add_child('parent', 'host')
    host = inventory_data.get_host('host')
    host.set_variable('group_names', 'parent')
    inventory_data.reconcile_inventory()
    assert len(inventory_data.groups) == 3
    assert len(inventory_data.hosts) == 1
    assert len(inventory_data.get_host('host').get_groups('parent')) == 1
    assert len(inventory_data.get_host('host').get_groups('all')) == 1

# Generated at 2022-06-24 19:30:57.377475
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    """
    Test case for method reconcile_inventory of class InventoryData
    """
    inventory_data_0 = InventoryData()
    assert inventory_data_0.reconcile_inventory() is None



# Generated at 2022-06-24 19:31:08.349859
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()

    for group in ('all','ungrouped','test','test_all','test_ungrouped','test_group','test2','test2_group','test2_group2','test2_group2_ungrouped'):
        inventory_data.add_group(group)
    for host in ('host1','host2','host3','host4','host5','host6','host_no_group','host_all'):
        inventory_data.add_host(host,group=None)

# Generated at 2022-06-24 19:31:17.926171
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data_1 = InventoryData()

    inventory_data_1.add_group('test_group_1')
    inventory_data_1.add_group('test_group_2')
    inventory_data_1.add_group('test_group_3')
    inventory_data_1.add_group('test_group_4')
    inventory_data_1.add_group('test_group_5')
    inventory_data_1.add_host('test_host_1', group = 'test_group_1')
    inventory_data_1.add_host('test_host_2', group = 'test_group_2')
    inventory_data_1.add_host('test_host_3', group = 'test_group_3')

# Generated at 2022-06-24 19:31:20.534427
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.current_source = 'c/source'
    inventory_data_0.reconcile_inventory()



# Generated at 2022-06-24 19:31:29.006408
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    print('Test start test_InventoryData_reconcile_inventory')

    inventory_data = InventoryData()

    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group2')
    inventory_data.add_host('host3', 'group2')
    inventory_data.add_host('host4', 'group3')
    inventory_data.add_host('host5', 'group4')

    inventory_data.add_group('group5')
    inventory_data.add_group('group6')

    inventory_data.add_child('group5', 'group6')

    inventory_data.reconcile_inventory()

    for (name, group) in iteritems(inventory_data.groups):
        hosts = group.get_hosts()
       

# Generated at 2022-06-24 19:31:33.028641
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('hostname')
    inventory_data_1.add_group('group_name')
    inventory_data_1.add_child('group_name', 'hostname')
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.get_host('hostname').name == 'hostname'

# Generated at 2022-06-24 19:31:44.230563
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    inventory_data.add_group("TestGroup1")
    inventory_data.add_group("TestGroup2")
    inventory_data.add_group("TestGroup3")
    assert inventory_data.groups.has_key("TestGroup1"), "InventoryData.groups hasn't key 'TestGroup1'"
    assert inventory_data.groups.has_key("TestGroup2"), "InventoryData.groups hasn't key 'TestGroup2'"
    assert inventory_data.groups.has_key("TestGroup3"), "InventoryData.groups hasn't key 'TestGroup3'"

    inventory_data.add_host("host1", "TestGroup1")
    inventory_data.add_host("host2", "TestGroup2")
    inventory_data.add_host("host3", "TestGroup1")
   

# Generated at 2022-06-24 19:31:50.002008
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group-1")



# Generated at 2022-06-24 19:31:59.889229
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    group_name = 'testgroup'
    inventory_data_1.add_group(group_name)
    assert group_name in inventory_data_1.groups
    assert 'all' in inventory_data_1.groups
    assert 'ungrouped' in inventory_data_1.groups
    assert 'all' in inventory_data_1.groups[group_name].get_ancestors()
    assert group_name in inventory_data_1.get_groups_dict()
    assert group_name in inventory_data_1.groups['all'].get_hosts()


# Generated at 2022-06-24 19:32:10.554503
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    my_inventory_data = InventoryData()
    my_inventory_data.add_host('host1')
    my_inventory_data.add_host('host2')
    my_inventory_data.add_group('group1')
    my_inventory_data.add_group('group2')

    assert my_inventory_data.add_child('group1', 'group2')
    # verify group2 is now a child of group1
    assert my_inventory_data.groups['group1'].child_groups == ['group2']

    assert my_inventory_data.add_child('group2', 'host1')
    # verify host1 is now a child of group2
    assert my_inventory_data.groups['group2'].hosts == ['host1']


# Generated at 2022-06-24 19:32:13.250206
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    def test_reconcile_inventory_0():
        inventory_data_0 = InventoryData()

    test_reconcile_inventory_0()


# Generated at 2022-06-24 19:32:17.261518
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    # create instance of class InventoryData
    inventory_data = InventoryData()
    # create a group with valid name
    inventory_data.add_group("valid_group")

    # assert that the group "valid_group" is in inventory
    assert "valid_group" in inventory_data.groups


# Generated at 2022-06-24 19:32:26.020344
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    test_group = "test_group"
    test_host1 = "test_host1"
    test_host2 = "test_host2"

    inventory_data_1.add_group(test_group)
    inventory_data_1.add_host(test_host1, test_group)
    inventory_data_1.add_host(test_host2, test_group)
    inventory_data_1.reconcile_inventory()

    # result of method reconcile_inventory on class InventoryData
    result = inventory_data_1.get_host(test_host1).get_groups()

    expected_result = [inventory_data_1.groups['all'],
            inventory_data_1.groups['test_group']]

    assert result == expected_result




# Generated at 2022-06-24 19:32:36.500365
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inv_data = InventoryData()
    inv_data.add_host("test1", "test")  # Test for new host in a new group
    inv_data.add_host("test2", "test")  # Test for new host in existing group
    inv_data.add_host("test3", "non_exist")  # Test for new host in a non-existing group
    assert(inv_data.get_host("test1").get_groups()[0].name == "test")
    assert(inv_data.get_host("test2").get_groups()[0].name == "test")
    assert(inv_data.get_host("test1").get_groups()[0].has_host("test1"))

# Generated at 2022-06-24 19:32:44.856769
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group1")
    inventory_data_1.add_group("group2")
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_host("host2", "group2")
    inventory_data_1.add_host("host3", "group2")
    inventory_data_1.add_host("host4", "group2")
    inventory_data_1.add_host("host5", "group2")
    result_1 = inventory_data_1.add_child("group3", "host1")
    assert result_1 == True
    result_2 = inventory_data_1.add_child("group3", "host2")
    assert result_2 == True
   

# Generated at 2022-06-24 19:32:50.919343
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data = InventoryData()
    inventory_data.add_group("group0")
    inventory_data.add_host("host1", "group0")
    assert inventory_data.add_child("group0", "host1") == True
    assert inventory_data.add_child("group0", "group0") == False
    assert inventory_data.add_child("group0", "host2") == False


# Generated at 2022-06-24 19:32:57.961558
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():

    inventory_data_mock = InventoryData()
    inventory_data_mock.add_host('ubuntu-1')
    inventory_data_mock.add_host('ubuntu-2')
    inventory_data_mock.add_host('ubuntu-3')

    assert len(inventory_data_mock.hosts) == 3
    assert list(inventory_data_mock.hosts.keys()) == ['ubuntu-1', 'ubuntu-2', 'ubuntu-3']
    assert inventory_data_mock.hosts['ubuntu-1'].name == 'ubuntu-1'
    assert inventory_data_mock.hosts['ubuntu-2'].name == 'ubuntu-2'
    assert inventory_data_mock.hosts['ubuntu-3'].name == 'ubuntu-3'


# Generated at 2022-06-24 19:33:13.316249
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.current_source = 'tests/unit/data/inventory_data/vars_plugins_1'
    inventory_data_1.processed_sources = [ 'tests/unit/data/inventory_data/vars_plugins_1' ]
    host1 = Host('localhost')
    host1.set_variable('ansible_python_interpreter', '/usr/bin/python2.7')
    host1.set_variable('ansible_connection', 'local')
    host1.implicit = True
    inventory_data_1.hosts['localhost'] = host1
    group1 = Group('all')
    group1.source = 'tests/unit/data/inventory_data/vars_plugins_1'

# Generated at 2022-06-24 19:33:26.415434
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()

    # Always create the 'all' and 'ungrouped' groups.
    inventory_data_0.add_group("all")
    inventory_data_0.add_group("ungrouped")

    # Add to the dict hosts a Host instance named WEB01
    inventory_data_0.add_host("WEB01")

    # Add to the dict hosts a Host instance named DB01
    inventory_data_0.add_host("DB01")

    # Add to the dict hosts a Host instance named WEB02
    inventory_data_0.add_host("WEB02")

    # Add to the dict hosts a Host instance named DB02
    inventory_data_0.add_host("DB02")

    # Add to the dict groups a Group instance named WEB

# Generated at 2022-06-24 19:33:36.128063
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
        print("[+] Testing add_host() of InventoryData class.")

        inventory_data_00 = InventoryData()
        assert len(inventory_data_00.hosts.keys()) == 0

        inventory_data_00.add_host('host1')
        assert len(inventory_data_00.hosts.keys()) == 1
        assert inventory_data_00.hosts.get('host1').name == 'host1'

        inventory_data_00.add_host('host2')
        assert len(inventory_data_00.hosts.keys()) == 2
        assert inventory_data_00.hosts.get('host2').name == 'host2'



# Generated at 2022-06-24 19:33:45.378776
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    if len(inventory_data_0.groups) == 0:
        assert False, "Expected True, but returned False"

    if len(inventory_data_0.hosts) == 0:
        assert False, "Expected True, but returned False"

    if inventory_data_0.localhost is not None:
        assert False, "Expected True, but returned False"

    if inventory_data_0.current_source is not None:
        assert False, "Expected True, but returned False"

    if inventory_data_0.processed_sources is not None:
        assert False, "Expected True, but returned False"

    if inventory_data_0._groups_dict_cache is not None:
        assert False, "Expected True, but returned False"

    return inventory_data

# Generated at 2022-06-24 19:33:47.378493
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test_case_0()
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group('test_group')
    inventory_data_0.add_host('test_host', 'test_group')

# Generated at 2022-06-24 19:33:56.266534
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()

    inventory_data_1.add_host("tomcat", "app_server")
    inventory_data_1.add_host("java", "app_server")
    inventory_data_1.add_host("web", "app_server")
    inventory_data_1.add_host("db", "database_server")
    inventory_data_1.add_host("storage", "storage_server")
    inventory_data_1.add_host("data", "storage_server")


# Generated at 2022-06-24 19:34:04.014852
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    # Create a host object for testing
    inventory_data_0.add_host("test_host_0", "test_group_0")
    inventory_data_0.add_host("test_host_1", "test_group_0")
    inventory_data_0.add_host("test_host_2", "test_group_1")
    # Create a group object for testing
    inventory_data_0.add_group("test_group_0")
    # Create a group object for testing
    inventory_data_0.add_group("test_group_1")
    # Set the default localhost object
    inventory_data_0.localhost = inventory_data_0.hosts["test_host_0"]

# Generated at 2022-06-24 19:34:09.518208
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host("ansible-test")
    assert inventory_data_0.hosts == {"ansible-test": "ansible-test"}
    assert inventory_data_0.groups["all"].hosts == [inventory_data_0.hosts["ansible-test"]]


# Generated at 2022-06-24 19:34:14.436609
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()

    # add localhost to inventory
    inventory_data.add_host('127.0.0.1')

    # add test_group to inventory
    inventory_data.add_group('test_group')

    # add test_host to test_group
    inventory_data.add_host('test_host', group='test_group')

    # add test_host to ungrouped
    inventory_data.add_host('test_host', group='ungrouped')

    inventory_data.reconcile_inventory()

    # verify test_host is present in the inventory
    assert inventory_data.get_host('test_host') is not None
    assert inventory_data.get_host('test_host') == inventory_data.hosts['test_host']

    # verify test_host belongs to test

# Generated at 2022-06-24 19:34:20.154355
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    group_name = 'test_group_name'
    group_name_from_add_group = inventory_data_1.add_group(group_name)
    assert type(group_name_from_add_group) == str
    assert group_name == group_name_from_add_group
    assert group_name_from_add_group in inventory_data_1.groups


# Generated at 2022-06-24 19:34:31.209715
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    group_0 = 'all'
    host_0 = 'host_0'
    inventory_data_0.add_host(host_0, group_0)

    inventory_data_1 = InventoryData()
    group_1 = 'group_1'
    host_1 = 'host_1'
    inventory_data_1.add_host(host_1, group_1)

    inventory_data_2 = InventoryData()
    group_2 = ''
    host_2 = 'localhost'
    inventory_data_2.add_host(host_2, group_2)


# Generated at 2022-06-24 19:34:40.072653
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    host = 'test_host'
    group = 'test_group'
    inventory_data_0.add_host(host)
    inventory_data_0.add_group(group)
    inventory_data_0.add_child(group, host)
    inventory_data_0.reconcile_inventory()
    inventory_data_0.remove_group(group)
    inventory_data_0.remove_host(inventory_data_0.hosts[host])
    expected = False
    actual = group in inventory_data_0.groups
    assert expected == actual
    actual = host in inventory_data_0.hosts
    assert expected == actual


# Generated at 2022-06-24 19:34:44.747371
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()

    inventory_data_0.add_host('host2')
    inventory_data_0.add_host('host2')
    assert inventory_data_0.hosts == {'host2': Host('host2')}


# Generated at 2022-06-24 19:34:48.101038
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    test_group = "test_group"
    inventory_data_0.add_group(test_group)

    assert test_group in inventory_data_0.groups


# Generated at 2022-06-24 19:34:50.512450
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()

# Generated at 2022-06-24 19:34:56.426160
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    command = "add_group('group-0', 'group-1')"
    inventory_data_0 = InventoryData()
    actual = inventory_data_0.add_group('group-0', 'group-1')
    expected = 'group-1'
    assert actual == expected, "actual = %s; expected = %s; command = %s" % (actual, expected, command)


# Generated at 2022-06-24 19:34:58.189943
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    assert inventory_data_1.reconcile_inventory() is None



# Generated at 2022-06-24 19:35:05.216530
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group('foo')
    inventory_data_0.add_group('bar')
    inventory_data_0.add_host('gaz')
    inventory_data_0.add_child('foo', 'gaz')
    inventory_data_0.add_child('bar', 'foo')
    inventory_data_0.add_child('bar', 'gaz')
    inventory_data_0.reconcile_inventory()
    print('Manual')
    print(inventory_data_0.groups['foo'].get_vars())
    print('auto')
    print(inventory_data_0.groups['bar'].get_vars())

# Generated at 2022-06-24 19:35:14.423110
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Define first group
    group_name_1 = "group1"
    # Define first host
    host_name_1 = "host1"
    # Create an instance of InventoryData
    inventory_data_1 = InventoryData()
    # Add the first group
    inventory_data_1.add_group(group_name_1)
    # Add the first host to the first group
    inventory_data_1.add_host(host_name_1, group_name_1)
    # Check host count in group1
    assert len(inventory_data_1.groups[group_name_1].get_hosts()) > 0
    # Check whether host1 exists in group1
    assert host_name_1 in inventory_data_1.groups[group_name_1].get_hosts()

# Generated at 2022-06-24 19:35:20.106415
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host('localhost')
    inventory_data_0.add_group('group1')
    inventory_data_0.add_group('group2')
    inventory_data_0.add_child('group1', 'localhost')
    inventory_data_0.add_child('group2', 'localhost')
    inventory_data_0.reconcile_inventory()

    # assert correct method calls
    assert len(inventory_data_0.hosts) == 1
    assert len(inventory_data_0.groups) == 3
    assert inventory_data_0.hosts['localhost'].name == 'localhost'
    assert inventory_data_0.groups['group1'].name == 'group1'

# Generated at 2022-06-24 19:35:38.589361
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    # test case 0
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group("test_group_1")
    if not inventory_data_0.groups:
        raise AssertionError("Key groups not found in inventory_data")
    # test case 1
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("test_group_0")
    if not inventory_data_1.groups:
        raise AssertionError("Key groups not found in inventory_data")
    # test case 2
    inventory_data_2 = InventoryData()
    inventory_data_2.add_group("test_group_2")
    if not inventory_data_2.groups:
        raise AssertionError("Key groups not found in inventory_data")
    # test case 3
   

# Generated at 2022-06-24 19:35:46.428659
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("127.0.0.1", None, 22)
    if inventory_data_1.hosts['127.0.0.1'].address != "127.0.0.1" and inventory_data_1.hosts['127.0.0.1'].port != 22:
        return -1
    else:
        return 0


# Generated at 2022-06-24 19:35:49.342569
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    global inventory_data_0
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:35:56.052212
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('host1')
    inventory_data_1.add_host('host2')

    assert inventory_data_1.hosts['host1']
    assert inventory_data_1.hosts['host2']
    assert len(inventory_data_1.hosts) == 2


# Generated at 2022-06-24 19:36:01.774443
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    i = InventoryData()
    i.add_host(host='test1', group='alice')
    i.add_child(group='bob', child='test2')
    i.add_host(host='test3')
    i.reconcile_inventory()
    assert 'test1' in i.groups['alice'].get_hosts()
    assert 'test2' in i.groups['bob'].get_hosts()
    assert 'test3' in i.groups['ungrouped'].get_hosts()

# Generated at 2022-06-24 19:36:14.123601
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group("foobar")
    inventory_data_0.add_host("localhost")
    inventory_data_0.add_host("foobar", "foobar")
    inventory_data_0.add_host("barfoo", "foobar")
    inventory_data_0.add_host("zoo", "ungrouped")
    inventory_data_0.reconcile_inventory()
    assert inventory_data_0.groups['foobar'].name == "foobar"
    assert inventory_data_0.hosts['localhost'].name == "localhost"
    assert inventory_data_0.hosts['foobar'].name == "foobar"
    assert inventory_data_0.hosts['barfoo'].name == "barfoo"
   

# Generated at 2022-06-24 19:36:20.205158
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host("test1", "test_group")
    assert inventory_data.hosts["test1"] is not None
    assert inventory_data.hosts["test1"].get_groups()["test_group"] is not None

# Generated at 2022-06-24 19:36:22.761475
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("test-host", "test-group")


# Generated at 2022-06-24 19:36:27.537281
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host('localhost')
    inventory_data_0.reconcile_inventory()
    #assert len(inventory_data_0.groups ) != 0
    #assert len(inventory_data_0.hosts ) != 0
    #assert inventory_data_0.localhost != None


# Generated at 2022-06-24 19:36:32.749425
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()

    # Test add_host()
    inventory_data.add_host("host_1")
    assert isinstance(inventory_data.hosts["host_1"], Host)

    # Test add_host() with existing host
    inventory_data.add_host("host_1")
    assert inventory_data.hosts["host_1"] != None


# Generated at 2022-06-24 19:36:47.856358
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.current_source = '<string>'

    # test 1 basic test
    inventory_data_1 = InventoryData()
    inventory_data_1.current_source = '<string>'
    inventory_data_1.add_host('localhost')
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.hosts.get('localhost') is not None
    assert inventory_data_1.groups.get('all') is not None
    assert inventory_data_1.groups.get('all').get_hosts() is not None
    assert len(inventory_data_1.groups.get('all').get_hosts()) == 1
    assert inventory_data_1.groups.get('all').get_hosts()[0].name

# Generated at 2022-06-24 19:36:56.944540
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("host1")
    if "host1" not in inventory_data_1.hosts:
        raise SystemExit("test_InventoryData_add_host test 1 failed")
    hostobj1 = inventory_data_1.get_host("host1")
    if hostobj1.name != "host1":
        raise SystemExit("test_InventoryData_add_host test 2 failed")
    inventory_data_1.add_host("host2")
    if "host2" not in inventory_data_1.hosts:
        raise SystemExit("test_InventoryData_add_host test 3 failed")
    hostobj2 = inventory_data_1.get_host("host2")

# Generated at 2022-06-24 19:37:03.264774
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data_1 = InventoryData()
    inventory_data_1.reconcile_inventory()

    group_names = inventory_data_1.get_groups_dict().keys()
    assert 'all' in group_names
    assert 'ungrouped' in group_names

    assert inventory_data_1.localhost.name in C.LOCALHOST

# Generated at 2022-06-24 19:37:13.598494
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    test_group = "test_group"
    test_host = "test_host"
    test_port = 42
    inventory_data_1.add_group(test_group)
    inventory_data_1.add_host(test_host, test_group, test_port)
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.groups.has_key(test_group)
    assert inventory_data_1.hosts.has_key(test_host)
    assert inventory_data_1.groups[test_group].has_host(inventory_data_1.hosts[test_host])
    assert inventory_data_1.hosts[test_host].get_groups()[0].name == test_group # host has group set


# Generated at 2022-06-24 19:37:20.366740
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    # Test case 1
    inventory_data_1 = InventoryData()
    host_1 = 'new_host_1'
    port_1 = 2222
    inventory_data_1.add_host(host_1, port=port_1)
    res_host = inventory_data_1.hosts.get(host_1)
    assert res_host.port == port_1
    # Test case 2
    inventory_data_2 = InventoryData()
    host_2 = 'new_host_2'
    group_2 = 'test_group'
    inventory_data_2.add_host(host_2, group=group_2)
    res_host_2 = inventory_data_2.hosts.get(host_2)

# Generated at 2022-06-24 19:37:25.168739
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("webservers")
    inventory_data_1.add_group("dbservers")
    inventory_data_1.add_group("test")
    assert len(inventory_data_1.groups.keys()) == 5


# Generated at 2022-06-24 19:37:34.160233
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    '''
    Demonstrates usage of method reconcile_inventory of class InventoryData
    '''
    # host_var and group_var host entries
    inventory_data_1 = InventoryData()
    inventory_data_1.set_variable('host1', 'group_var', 'group_var_val')
    inventory_data_1.set_variable('host1', 'host_var', 'host_var_val')
    inventory_data_1.set_variable('host2', 'group_var', 'group_var_val')
    inventory_data_1.set_variable('host2', 'host_var', 'host_var_val')
    inventory_data_1.set_variable('group1', 'group_var', 'group_var_val')

# Generated at 2022-06-24 19:37:40.590921
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.hosts = {}
    inventory_data_1.hosts['host1'] = Host('host1')
    inventory_data_1.hosts['host2'] = Host('host2')
    inventory_data_1.hosts['host3'] = Host('host3')
    inventory_data_1.hosts['host4'] = Host('host4')
    inventory_data_1.hosts['host5'] = Host('host5')

    inventory_data_2 = InventoryData()
    inventory_data_2.groups = {}
    inventory_data_2.groups['group1'] = Group('group1')
    inventory_data_2.groups['group2'] = Group('group2')

# Generated at 2022-06-24 19:37:43.835011
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    assert inventory_data.groups['all'] == inventory_data.add_group('all')
    assert inventory_data.groups['all'] == inventory_data.groups['all']


# Generated at 2022-06-24 19:37:52.690507
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    # Case 1
    host_name = "ansible_test_host"
    group = "ansible_test_group"
    inventory_data_1.add_group(group)
    inventory_data_1.add_host(host_name, group)
    # print inventory_data_1.groups
    # print inventory_data_1.hosts
    # print inventory_data_1.current_source
    assert host_name in inventory_data_1.hosts
    assert group in inventory_data_1.groups
    assert host_name in inventory_data_1.groups[group].hosts
    # Case 2
    host_name = "ansible_test_host_2"
    group = "ansible_test_group_2"
    inventory_data_1.add

# Generated at 2022-06-24 19:38:02.309609
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('localhost')
    assert inventory_data_1.get_host('localhost') is not None
#    assert inventory_data_1.get_host('localhost').name == 'localhost'
