

# Generated at 2022-06-24 19:28:27.706695
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data_1 = InventoryData()
    group = "group1"
    child = "child1"
    inventory_data_1.add_group(group)
    inventory_data_1.add_group(child)
    added = inventory_data_1.add_child(group, child)
    assert added == True



# Generated at 2022-06-24 19:28:30.086994
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    host_name = "unset"
    inventory_data_0.remove_host(host_name)


# Generated at 2022-06-24 19:28:33.621169
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    group = None
    port = None
    host = "alpha"
    inventory_data_0.add_host(host, group, port)
    assert inventory_data_0.hosts.keys() == ['alpha']
    assert list(inventory_data_0.hosts['alpha'].groups) == ['all', 'ungrouped']
    assert inventory_data_0.groups['all'].get_hosts()[0].name == 'alpha'

# Generated at 2022-06-24 19:28:46.215072
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data_test_case_0 = InventoryData()
    inventory_data_test_case_0.localhost = Host("localhost")
    inventory_data_test_case_0.localhost.address = "127.0.0.1"
    inventory_data_test_case_0.localhost.implicit = True
    inventory_data_test_case_0.localhost.set_variable("ansible_python_interpreter", "/usr/bin/python")
    inventory_data_test_case_0.localhost.set_variable("ansible_connection", "local")
    inventory_data_test_case_0.hosts["localhost"] = inventory_data_test_case_0.localhost
    inventory_data_test_case_0.groups["all"] = Group("all")

# Generated at 2022-06-24 19:28:49.587250
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data_0 = InventoryData()

    hostname = 'test_host'
    result = inventory_data_0.get_host(hostname)

    assert result == None


# Generated at 2022-06-24 19:29:00.496465
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    test_group_name = 'test_group'
    inventory_data_1.add_group(test_group_name)
    assert(len(inventory_data_1.groups) == 3)
    assert(len(inventory_data_1.hosts) == 0)
    assert(test_group_name in inventory_data_1.groups)
    assert(test_group_name in inventory_data_1.groups['all'].child_groups.keys())
    inventory_data_1.reconcile_inventory()
    assert(len(inventory_data_1.groups) == 3)
    assert(len(inventory_data_1.hosts) == 0)
    assert(test_group_name in inventory_data_1.groups)

# Generated at 2022-06-24 19:29:03.190079
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    test_host = Host('test_host')
    inventory_data_0.hosts['test_host'] = test_host
    inventory_data_0.groups['all'] = Group('all')
    inventory_data_0.groups['all'].add_host(test_host)
    inventory_data_0.remove_host(test_host)


# Generated at 2022-06-24 19:29:07.085294
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    
    host1 = inventory_data.add_host('host1', group='group1')
    group = inventory_data.add_group('group1')
    assert host1 == 'host1'
    assert group == 'group1'
    assert inventory_data.groups[group].get_hosts()[0].name == 'host1'


# Generated at 2022-06-24 19:29:12.199933
# Unit test for method remove_group of class InventoryData
def test_InventoryData_remove_group():
    inventory_data = InventoryData()
    inventory_data.add_group('test_group')
    assert 'test_group' in inventory_data.groups
    inventory_data.remove_group('test_group')
    assert 'test_group' not in inventory_data.groups



# Generated at 2022-06-24 19:29:17.291716
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_1 = InventoryData()
    group_1_name = 'group_1'
    group_1 = Group(group_1_name)
    assert group_1_name not in inventory_data_1.groups
    inventory_data_1.add_group(group_1_name)
    assert group_1_name in inventory_data_1.groups


# Generated at 2022-06-24 19:29:36.849192
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host(u'localhost')
    get_host = inventory_data_0.get_host(u'localhost')
    assert get_host.name == u'localhost'


# Generated at 2022-06-24 19:29:44.187449
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # Initialization
    inventory_data = InventoryData()
    group1_name = "unit test group1"
    group2_name = "unit test group2"
    inventory_data.add_group(group1_name)
    inventory_data.add_group(group2_name)
    inventory_data.add_host("unit test host1", group1_name)
    inventory_data.add_host("unit test host2", group1_name)
    inventory_data.add_host("unit test host3", group2_name)
    inventory_data.add_host("unit test host4", group2_name)
    host1_name = "unit test host1"
    host2_name = "unit test host2"
    host3_name = "unit test host3"

# Generated at 2022-06-24 19:29:50.512180
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():

    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('group1')
    host1 = inventory_data_1.add_host('host1')
    host2 = inventory_data_1.add_host('host2')
    inventory_data_1.add_child('group1', 'host1')
    inventory_data_1.remove_host('host1')
    assert 'host1' not in inventory_data_1.hosts
    assert 'host1' not in inventory_data_1.groups['group1'].hosts
    assert inventory_data_1.hosts['host2'] == host2


# Generated at 2022-06-24 19:29:53.197364
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('ubuntu')
    assert inventory_data_1.hosts['ubuntu'].name == 'ubuntu'


# Generated at 2022-06-24 19:30:04.762385
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_host("host2", "group1")
    inventory_data_1.add_group("group2")
    inventory_data_1.add_child("group2", "group1")
    inventory_data_1.remove_group("group2")
    inventory_data_1.reconcile_inventory()
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_host("host1", "group1")
    inventory_data_1.add_host("host2", "group1")
    inventory_data_1.add_group

# Generated at 2022-06-24 19:30:07.658516
# Unit test for method add_child of class InventoryData
def test_InventoryData_add_child():
    inventory_data_1 = InventoryData()
    group = inventory_data_1.add_group('webservers')
    inventory_data_1.add_child(group, 'app1')


# Generated at 2022-06-24 19:30:11.153483
# Unit test for method get_host of class InventoryData
def test_InventoryData_get_host():
    inventory_data = InventoryData()
    assert inventory_data.get_host("localhost") is None


# Generated at 2022-06-24 19:30:23.126708
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('group_1')
    inventory_data_1.add_group('group_2')
    inventory_data_1.add_host('host_1', 'group_1')
    inventory_data_1.add_host('host_2', 'group_2')
    inventory_data_1.reconcile_inventory()
    assert inventory_data_1.get_host('host_1').vars == {'groups': {'group_1': ['host_1'], 'group_2': ['host_2'], 'all': ['host_1', 'host_2']}}

# Generated at 2022-06-24 19:30:28.202751
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0._groups_dict_cache = {'all': ['127.0.0.1'], 'ungrouped': ['127.0.0.1']}
    inventory_data_0.current_source = 'test/inventory'
    inventory_data_0.processed_sources = ['test/inventory']
    inventory_data_0.hosts = {'127.0.0.1': Host('127.0.0.1'),
                              '127.0.0.2': Host('127.0.0.2')}

# Generated at 2022-06-24 19:30:40.209245
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()

    inventory_data.add_group('group0')
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')

    inventory_data.add_host('host0', 'group0')
    inventory_data.add_host('host1', 'group1')
    inventory_data.add_host('host2', 'group2')
    inventory_data.add_host('host3', None)

    print(inventory_data.hosts)
    print(inventory_data.groups)
    print(inventory_data.get_groups_dict())

if __name__ == '__main__':
    test_case_0()
    test_InventoryData_add_host()


# Generated at 2022-06-24 19:30:52.019912
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    test_host = Host('test_host')

    inventory_data_0.add_group('test_group')
    inventory_data_0.add_child('test_group', 'test_host')

    inventory_data_0.remove_host(test_host)

    assert 'test_host' not in inventory_data_0.hosts
    assert 'test_host' not in inventory_data_0.groups['test_group'].hosts


# Generated at 2022-06-24 19:30:53.024253
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    assert(False)



# Generated at 2022-06-24 19:31:01.503497
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host(hostname="127.0.0.1", group=None, port=None)
    if set(inventory_data_1.hosts) != set(["127.0.0.1"]):
        raise Exception("Wrong hosts")
    inventory_data_1.add_host(hostname="localhost", group=None, port=None)
    if set(inventory_data_1.hosts) != set(["127.0.0.1", "localhost"]):
        raise Exception("Wrong hosts")


# Generated at 2022-06-24 19:31:05.878816
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_host("test_host")
    assert("test_host" in inventory_data.hosts)
    inventory_data.remove_host("test_host")
    assert("test_host" not in inventory_data.hosts)


# Generated at 2022-06-24 19:31:11.070380
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data=InventoryData()
    inventory_data.hosts['host1']='host1'
    inventory_data.hosts['host2']='host2'
    inventory_data.hosts['host3']='host3'
    inventory_data.hosts['host4']='host4'

    inventory_data.groups['group1']='group1'
    inventory_data.groups['group2']='group2'
    inventory_data.groups['group3']='group3'
    inventory_data.groups['group4']='group4'

    '''Host and group relationship'''
    inventory_data.groups['group1'].add_host(inventory_data.hosts['host1'])
    inventory_data.groups['group1'].add_host(inventory_data.hosts['host2'])

   

# Generated at 2022-06-24 19:31:12.819748
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData ()
    inventory_data_0.reconcile_inventory ()


# Generated at 2022-06-24 19:31:22.884591
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    test_InventoryData_add_host_0()
    test_InventoryData_add_host_1()
    test_InventoryData_add_host_2()
    test_InventoryData_add_host_3()
    test_InventoryData_add_host_4()
    test_InventoryData_add_host_5()
    test_InventoryData_add_host_6()
    test_InventoryData_add_host_7()
    test_InventoryData_add_host_8()
    test_InventoryData_add_host_9()
    test_InventoryData_add_host_10()

# Unit test no. 0

# Generated at 2022-06-24 19:31:27.383906
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    
    inventory_data_0 = InventoryData()
    group = 'group'
    # Case 0
    result = inventory_data_0.add_group(group)
    # Verification
    assert (result == group)
    assert (inventory_data_0.groups['group'] == Group("group"))
    assert (inventory_data_0.groups['group'].name == "group")


# Generated at 2022-06-24 19:31:34.679674
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('test_group')
    inventory_data_1.add_host('test_host', group='test_group')
    print('\nThe hosts are:', inventory_data_1.hosts.keys())
    print('\nThe hosts mapped to their groups are: ')
    for host in inventory_data_1.hosts.keys():
        print('Host %s, group %s' % (host, inventory_data_1.hosts[host].groups))

# Unit test to check if method add_host of class InventoryData raises an error
# when an invalid ip address is specified for the host

# Generated at 2022-06-24 19:31:38.070951
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    test_host = Host("test_host")
    inventory_data.remove_host(test_host)

# Generated at 2022-06-24 19:31:44.585324
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    group = 'group1'
    host = 'host1'
    port = '22' 
    host_name = inventory_data_1.add_host(host, group, port)
    assert host == host_name


# Generated at 2022-06-24 19:31:56.890043
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    # test case 1
    # add group:all
    inventory_data_1 = InventoryData()
    group = 'all'
    inventory_data_1.add_group(group)

# Generated at 2022-06-24 19:32:03.423467
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    inventory_data_0 = InventoryData()
    if not inventory_data_0.groups:
        inventory_data_0.add_group('my_group')
        #print inventory_data_0.groups
        i_keys = inventory_data_0.groups.keys()
        if ('my_group') in i_keys:
            print('Test case test_InventoryData_add_group PASS')
        else:
            print('Test case test_InventoryData_add_group FAIL')


# Generated at 2022-06-24 19:32:06.483441
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    inventory_data = InventoryData()

    group_name = "foobar"
    inventory_data.add_group(group_name)

    assert group_name in inventory_data.groups


# Generated at 2022-06-24 19:32:07.057974
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    assert 0

# Generated at 2022-06-24 19:32:08.574525
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data=InventoryData()
    assert isinstance(inventory_data, InventoryData)

# Generated at 2022-06-24 19:32:11.849091
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    # case 1
    inventory_data.reconcile_inventory()
    

# Generated at 2022-06-24 19:32:17.172268
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.remove_host(Host("test"))
    assert inventory_data_0.hosts.__len__() == 0
    assert inventory_data_0.groups['all'].get_hosts().__len__() == 0
    assert inventory_data_0.groups['ungrouped'].get_hosts().__len__() == 0



# Generated at 2022-06-24 19:32:26.020444
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    """
    Unit test for method remove_host of class InventoryData
    """
    print("\nInventoryData.remove_host()")

    test_host = Host('dummy_host_name')
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group('dummy_group_name1')
    inventory_data_1.add_group('dummy_group_name2')

    inventory_data_1.add_host(test_host.name)
    inventory_data_1.set_variable('dummy_host_name', 'discovered_interpreter_python', "Test value")
    inventory_data_1.add_child('dummy_group_name1', test_host.name)

# Generated at 2022-06-24 19:32:30.594637
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    """
    Make sure we can succesfully remove a host, along with its corresponding data
    """
    inventory_data = InventoryData()
    test_hostname = 'test_host'
    test_port = 8080
    test_groupname = 'test_group'
    test_varname = 'test_variable'
    test_value = 'test_value'
    h = Host(test_hostname, test_port)
    g = Group(test_groupname)
    inventory_data.hosts[test_hostname] = h
    inventory_data.groups[test_groupname] = g
    inventory_data.set_variable(test_hostname, test_varname, test_value)

    assert(test_hostname in inventory_data.hosts)

# Generated at 2022-06-24 19:32:44.482767
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.get_host("localhost")
    inventory_data_1.get_host("other")
    inventory_data_1.add_group("all")
    inventory_data_1.add_group("group")
    inventory_data_1.get_host("localhost").add_group("group")
    inventory_data_1.get_host("localhost").add_group("all")
    inventory_data_1.get_host("localhost").add_group("other")
    inventory_data_1.get_host("other").add_group("group")
    inventory_data_1.get_host("other").add_group("all")
    inventory_data_1.get_host("other").add_group("other")

# Generated at 2022-06-24 19:32:48.381915
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    try:
        inventory_data_0.reconcile_inventory()
    except Exception as e:
        assert False, "Failed to reconcile inventory"


# Generated at 2022-06-24 19:32:54.137888
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.processed_sources = None
    inventory_data_1.processed_sources = None
    inventory_data_1.processed_sources.append("TEST_CASE_INVENTORY_FILE_1")
    inventory_data_1.add_host("TEST_CASE_HOSTNAME_1", "TEST_CASE_GROUP_1", 22)
    assert(True)
    return




# Generated at 2022-06-24 19:32:55.912904
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group('test')


# Generated at 2022-06-24 19:33:06.420936
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    i1 = inventory_data_1.add_host("apac-test-01", "test_group1")
    i1 = inventory_data_1.add_host("apac-test-01", "test_group2")
    i1 = inventory_data_1.add_host("apac-test-01", "test_group3")
    inventory_data_1.remove_host(i1)
    if i1.get_groups():
        raise AnsibleError("not able to remove host from group")
    else:
        print("test_InventoryData_remove_host: test passed")


# Generated at 2022-06-24 19:33:08.947754
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_group("group1")
    inventory_data_1.add_group("group2")
    inventory_data_1.add_host("Host1","group1")
    inventory_data_1.add_host("Host2","group2")
    result = inventory_data_1.reconcile_inventory()
    assert result == None


# Generated at 2022-06-24 19:33:10.893769
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_0 = InventoryData()
    try:
        inventory_data_0.remove_host(host='host')
    except AnsibleError as e:
        assert('Could not identify group or host named host' in str(e))
    else:
        raise Exception('AnsibleError was not raised')

# Generated at 2022-06-24 19:33:16.038957
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    """
    test for host add
    """
    inventory_data = InventoryData()
    inventory_data.add_host("machine1")
    inventory_data.add_host("machine2")
    inventory_data.add_host("machine3")
    assert inventory_data.hosts.keys() == ["machine1", "machine2", "machine3"]



# Generated at 2022-06-24 19:33:27.723304
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.add_group('group1')
    inventory_data.add_group('group2')
    inventory_data.add_host('host1')
    inventory_data.add_host('host2')
    inventory_data.add_host('host3')
    inventory_data.add_host('host4')
    inventory_data.add_host('host5')
    inventory_data.add_host('host6')
    inventory_data.add_child('group1', 'host1')
    inventory_data.add_child('group1', 'host2')
    inventory_data.add_child('group1', 'host3')
    inventory_data.add_child('group2', 'host4')
    inventory_data.add_child('group2', 'host5')
   

# Generated at 2022-06-24 19:33:29.234439
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    test_inventory_data = InventoryData()
    host = Host("myhost")
    test_inventory_data.add_host(host.name,"mygroup")
    test_inventory_data.remove_host(host)


# Generated at 2022-06-24 19:33:44.912000
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("localhost")
    inventory_data_1.add_host("web2.example.com")
    inventory_data_1.add_host("web3.example.com")
    inventory_data_1.add_host("web4.example.com")
    inventory_data_1.add_host("web5.example.com")
    inventory_data_1.add_host("web6.example.com")
    inventory_data_1.add_group("webserver")
    inventory_data_1.add_group("databases")
    inventory_data_1.add_child("webserver", "web2.example.com")
    inventory_data_1.add_child("webserver", "web3.example.com")


# Generated at 2022-06-24 19:33:54.463617
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("alpha", "test")
    inventory_data_1.add_host("beta", "test")
    inventory_data_1.add_host("gamma", "test")
    inventory_data_1.remove_host("gamma")

    host_names = [hostname for hostname in inventory_data_1.hosts]
    assert host_names == ["alpha", "beta"], "host: %s" % host_names

    groups_names = [hostname for hostname in inventory_data_1.groups]
    assert groups_names == ["all", "test", "ungrouped"], "groups: %s" % groups_names


# Generated at 2022-06-24 19:34:00.237332
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_2 = InventoryData()
    inventory_data_2.add_host("alpha", "None")
    inventory_data_2.remove_host(inventory_data_2.hosts["alpha"])
    assert "alpha" not in inventory_data_2.hosts

# Generated at 2022-06-24 19:34:02.772081
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data = InventoryData()
    group_name = "test"

    inventory_data.add_group(group_name)

    assert group_name in inventory_data.groups.keys()


# Generated at 2022-06-24 19:34:09.383131
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    """
    This test case tests the reconcile_inventory method of the InventoryData class
    """
    # Initializing the inventory data
    inventory_data = InventoryData()
    # Adding new groups 'all', 'testGroup' and 'ungrouped'
    inventory_data.add_group('all')
    inventory_data.add_group('testGroup')
    inventory_data.add_group('ungrouped')
    # Adding a new host 'testHost'
    inventory_data.add_host('testHost')
    # Setting the current source
    inventory_data.current_source = '/etc/ansible/hosts'
    # Running the reconcile_inventory method
    inventory_data.reconcile_inventory()
    # Testing the reconcile_inventory method
    assert len(inventory_data.processed_sources) == 0
    

#

# Generated at 2022-06-24 19:34:14.952085
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    test_inventory_data = InventoryData()

    assert test_inventory_data.add_group("group1") == "group1"
    assert test_inventory_data.add_group("group2") == "group2"

    # test for adding a None group
    try:
        test_inventory_data.add_group(None)
    except Exception as e:
        assert type(e) == AnsibleError
        assert str(e) == "Invalid group name supplied, expected a string but got <class 'NoneType'> for None"


# Generated at 2022-06-24 19:34:16.667828
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:34:18.496773
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    inventory_data.remove_host('test')


# Generated at 2022-06-24 19:34:28.588705
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_1 = InventoryData()
    inventory_data_0.add_host('test_host_0')
    inventory_data_0.add_group('test_group_0')
    inventory_data_0.add_child('test_group_0','test_host_0')
    print(inventory_data_0.hosts['test_host_0'].get_groups())
    print(inventory_data_0.groups['test_group_0'].get_hosts())
    print(inventory_data_0.groups['test_group_0'].get_children())
    print(inventory_data_0.hosts['test_host_0'].get_ancestors())



# Generated at 2022-06-24 19:34:33.630929
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    i = InventoryData()
    h = Host('test')
    i.add_host(h)
    i.remove_host(h)
    assert h.name not in i.hosts
    assert h not in i.groups['all'].get_hosts()

# Generated at 2022-06-24 19:34:45.035690
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    # Test args for remove_host
    test_host = Host('abc')

    # Execute the function under test
    InventoryData().remove_host(test_host)


# Generated at 2022-06-24 19:34:47.572081
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.load_inventory()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:34:51.743691
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    group = "Test_Group"
    host = "Test_Host"
    inventory_data.add_host(host,group)
    inventory_data.remove_host(host)

    assert(host not in inventory_data.hosts.keys())
    assert(host not in inventory_data.groups[group].hosts)


# Generated at 2022-06-24 19:34:55.760773
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    print('#### Test: add_host')
    test_host = 'host'
    test_group = 'group'
    assert inventory_data_1.add_host( test_host, test_group ) == test_host

# Generated at 2022-06-24 19:35:04.198892
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    # Create temporary objects from InventoryData class
    inventory_data_1 = InventoryData()
    inventory_data_2 = InventoryData()

    # Create group and host objects
    group_1 = Group('all')
    group_1.name = 'all'
    group_2 = Group('hostname')
    group_2.name = 'hostname'
    host_1 = Host('test')
    host_1.name = 'test'

    # Add groups and hosts to inventory data
    inventory_data_1.groups['all'] = group_1
    inventory_data_1.groups['hostname'] = group_2
    inventory_data_1.hosts['test'] = host_1
    inventory_data_2.groups['all'] = group_1
    inventory_data_2.groups['hostname'] = group_2
   

# Generated at 2022-06-24 19:35:08.934613
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    display.debug('Test: InventoryData - remove_host...')
    inventory_data_3 = InventoryData()
    inventory_data_3.add_host('test_host')
    inventory_data_3.remove_host(inventory_data_3.hosts['test_host'])
    assert inventory_data_3.hosts.get('test_host') is None


# Generated at 2022-06-24 19:35:14.345765
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()

    host_name = "host"
    inventory_data.add_host(host_name)
    assert(host_name in inventory_data.hosts)
    inventory_data.remove_host(inventory_data.hosts[host_name])
    assert(host_name not in inventory_data.hosts)


if __name__ == "__main__":
    #test_case_0()
    test_InventoryData_remove_host()

# Generated at 2022-06-24 19:35:16.122742
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.remove_host('test_host')


# Generated at 2022-06-24 19:35:19.768528
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    host = "localhost"
    group = "all"
    port = 22
    inventory_data.add_host(host, group, port)


# Generated at 2022-06-24 19:35:23.546133
# Unit test for method remove_host of class InventoryData
def test_InventoryData_remove_host():
    inventory_data = InventoryData()
    host = Host('test')
    inventory_data.hosts['test'] = host
    inventory_data.remove_host(host)
    assert host.name not in inventory_data.hosts


# Generated at 2022-06-24 19:35:35.790429
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    print("  Testing InventoryData.add_host()")
    inventory_data_1.add_host("127.0.0.1")
    assert inventory_data_1.get_host("127.0.0.1") != None, "add_host doesn't work"
    print("    add_host test sucessfully")
    print("    Passed")
    print()


# Generated at 2022-06-24 19:35:37.784428
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("localhost")
    inventory_data.add_host("localhost", "group1")
    inventory_data.reconcile_inventory()
    print("Test case passed")



# Generated at 2022-06-24 19:35:48.597455
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host('127.0.0.1')
    inventory_data.add_host('192.168.56.101', port='22')
    inventory_data.add_host('192.168.56.102', group='all')
    inventory_data.add_host('192.168.56.103', group='all', port='22')
    inventory_data.add_group('newgroup')
    inventory_data.add_host('192.168.56.104', group='newgroup')

    # Testing localhost implicitly created
    local_host = inventory_data.get_host('127.0.0.1')
    assert local_host.implicit == True # implicit flag is set
    assert local_host.name == '127.0.0.1' # name is

# Generated at 2022-06-24 19:35:50.361240
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_2 = InventoryData()
    inventory_data_2.add_group('Windows')
    inventory_data_2.add_group('Linux')
    assert(len(inventory_data_2.groups) == 4)



# Generated at 2022-06-24 19:35:58.587557
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
     inventory_data = InventoryData()
     inventory_data.add_host('localhost')
     assert(inventory_data.hosts.has_key('localhost'))
     assert(inventory_data.groups['all'].get_hosts()[0].name == 'localhost')
     assert(inventory_data.groups['all'].has_host('localhost'))
     assert(inventory_data.groups['ungrouped'].get_hosts()[0].name == 'localhost')
     assert(inventory_data.groups['ungrouped'].has_host('localhost'))
     assert(inventory_data.hosts['localhost'].get_groups()[0].name == 'all')
     assert(inventory_data.hosts['localhost'].get_groups()[1].name == 'ungrouped')


# Generated at 2022-06-24 19:36:01.936061
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host("test")


# Generated at 2022-06-24 19:36:06.395211
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():

    inventory_data_0 = InventoryData()
    print("test_InventoryData_add_group")

    # Check if add_group() doesn't raise any exceptions:
    try:
        inventory_data_0.add_group("X")
    except Exception:
        print("Exception detected, expected no exception")
        assert False

    # Nothing to check, no return value.


# Generated at 2022-06-24 19:36:13.749994
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_0 = InventoryData()
    group_0 = 'test_var'
    host_0 = 'test_var'
    port_0 = True
    inventory_data_0.add_host(host_0, group_0, port_0)
    assert inventory_data_0 is not None


# Generated at 2022-06-24 19:36:25.732503
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host("127.0.0.1", "all")
    inventory_data_1.add_host("127.0.0.1", "all")
    inventory_data_1.add_host("127.0.0.1", "all")
    
    assert inventory_data_1.hosts["127.0.0.1"].name == "127.0.0.1"
    assert len(inventory_data_1.hosts) == 1
    assert len(inventory_data_1.groups["all"].get_hosts()) == 1
    assert inventory_data_1.groups["all"].get_hosts()[0].name == "127.0.0.1"
    

# Generated at 2022-06-24 19:36:31.382794
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_host('host1')
    inventory_data_0.add_host('host2')
    answer0 = inventory_data_0.reconcile_inventory()
    assert answer0 == None


# Generated at 2022-06-24 19:36:43.215432
# Unit test for method add_group of class InventoryData
def test_InventoryData_add_group():
    inventory_data_0 = InventoryData()
    inventory_data_0.add_group('all')
    inventory_data_0.add_group('ungrouped')

# Generated at 2022-06-24 19:36:47.785970
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()
    inventory_data.add_host("hostname")
    inventory_data.add_host("hostname", "groupname")
    inventory_data.add_host("hostname", "groupname", "port")
    assert(inventory_data.hosts['hostname'].name == 'hostname')
    assert(inventory_data.hosts['hostname'].port == 'port')


# Generated at 2022-06-24 19:36:50.515617
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    result = inventory_data.reconcile_inventory()
    assert result is None


# Generated at 2022-06-24 19:37:00.242155
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inv_data = InventoryData()
    inv_data.add_host('foo')
    inv_data.add_host('bar')
    inv_data.add_host('baz')
    inv_data.add_host('baz')

# Generated at 2022-06-24 19:37:04.139377
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_0 = InventoryData()
    inventory_data_0.reconcile_inventory()


# Generated at 2022-06-24 19:37:14.123772
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():

    inventory_data = InventoryData()

    # created group 'all'
    assert inventory_data.groups is not None
    assert len(inventory_data.groups) == 2
    assert 'all' in inventory_data.groups
    assert 'ungrouped' in inventory_data.groups

    # added child 'ungrouped' to 'all'
    assert inventory_data.groups['all'].name is not None
    assert len(inventory_data.groups['all'].get_hosts()) == 0
    assert inventory_data.groups['all'].name == 'all'
    assert len(inventory_data.groups['all'].get_children()) == 1

    inventory_data.add_group('group1')
    inventory_data.add_group('group2')

    group1 = inventory_data.groups['group1']

# Generated at 2022-06-24 19:37:18.102618
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host('host1')


# Generated at 2022-06-24 19:37:28.220055
# Unit test for method add_host of class InventoryData
def test_InventoryData_add_host():
    inventory_data = InventoryData()

    group1 = "test_group"
    group2 = "test_group2"
    host1 = "test_host"
    host2 = "test_host2"

    inventory_data.add_group(group1)
    inventory_data.add_group(group2)
    inventory_data.add_host(host1, group1)
    inventory_data.add_host(host2, group2)

    print("Testing add_host()")
    assert inventory_data.groups[group1].get_hosts()[0].name == "test_host"
    assert inventory_data.groups[group1].get_hosts()[0].implicit is False
    assert inventory_data.groups[group1].get_hosts()[0].vars == {}
    assert inventory_data

# Generated at 2022-06-24 19:37:36.309145
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data_1 = InventoryData()
    inventory_data_1.add_host(host="jerry", group="admins")
    inventory_data_1.add_host(host="joe", group="admins")
    inventory_data_1.add_host(host="larry", group="developers")
    inventory_data_1.add_host(host="curly", group="developers")
    inventory_data_1.reconcile_inventory()
    print("InventoryData.groups['admins'].get_hosts(): ", inventory_data_1.groups['admins'].get_hosts())
    print("InventoryData.groups['developers'].get_hosts(): ", inventory_data_1.groups['developers'].get_hosts())

# Generated at 2022-06-24 19:37:40.346160
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    test_inventory = InventoryData()
    assert test_inventory.reconcile_inventory() == True



# Generated at 2022-06-24 19:38:03.127597
# Unit test for method reconcile_inventory of class InventoryData
def test_InventoryData_reconcile_inventory():
    inventory_data = InventoryData()
    inventory_data.add_host("localhost")
    inventory_data.add_host("localhost2")
    inventory_data.add_host("host1")
    inventory_data.add_host("host2")
    inventory_data.add_host("host3")
    inventory_data.add_group("group1")
    inventory_data.add_group("group2")
    inventory_data.add_group("group3")
    inventory_data.add_group("group4")
    inventory_data.add_group("group5")
    inventory_data.add_child("group1", "group2")
    inventory_data.add_child("group5", "group1")
    inventory_data.add_child("group1", "localhost")