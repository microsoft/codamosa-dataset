

# Generated at 2022-06-25 17:31:46.428160
# Unit test for function find_paths
def test_find_paths():
    # Setup initial values to be assigned to the variables
    # pypi.python.org/pypi/pathlib
    pattern_0 = module_0.PosixPath(
        "/home/test_user/tmp/*"
    )
    # Setup and call the tested function
    # The actual test is in the next function so this can support iterators
    pattern_1 = pattern_0
    find_paths_gen = find_paths(pattern_1)
    # Check if the result expected
    # pypi.python.org/pypi/pathlib
    assert isinstance(find_paths_gen, module_0.Generator)
    assert callable(find_paths_gen.__next__)


# Generated at 2022-06-25 17:31:49.509089
# Unit test for function chmod
def test_chmod():
    path_0 = Path()
    chmod(path_0)

import os as module_0


# Generated at 2022-06-25 17:31:58.981119
# Unit test for function chown
def test_chown():
    # Test paths that exist
    path_0 = Path(__file__)
    if (exists_as(path_0) == "dir"):
        pass
    elif (exists_as(path_0) == "file"):
        pass
    path_0 = Path()
    if (exists_as(path_0) == "dir"):
        pass
    elif (exists_as(path_0) == "file"):
        pass
    # Test paths that do not exist
    path_0 = Path('/dev/null')
    if (exists_as(path_0) == "dir"):
        pass
    elif (exists_as(path_0) == "file"):
        pass
    path_0 = Path('foo/bar/baz')

# Generated at 2022-06-25 17:32:01.769262
# Unit test for function find_paths
def test_find_paths():
    pattern_0 = module_0.PathLike()
    generator_0 = find_paths(pattern_0)
    assert type(generator_0) is GeneratorType



# Generated at 2022-06-25 17:32:03.058345
# Unit test for function find_paths
def test_find_paths():
    path_like_0 = module_0.PathLike()
    generator_0 = find_paths(path_like_0)


# Generated at 2022-06-25 17:32:04.080207
# Unit test for function exists_as
def test_exists_as():
    x_0 = module_0.PathLike()
    y_0 = exists_as(x_0)


# Generated at 2022-06-25 17:32:15.564171
# Unit test for function chown
def test_chown():
    path_0 = normalize_path(path_0)
    if isinstance(user, str) and user == '-1':
        uid = -1
    else:
        uid = get_os_user(user).pw_uid

    if isinstance(user, str) and group == '-1':
        gid = -1
    else:
        gid = get_os_group(group).gr_gid


# Generated at 2022-06-25 17:32:19.546234
# Unit test for function chown
def test_chown():
    path_like_0 = module_0.PathLike()
    str_0 = None
    str_1 = None
    boolean_0 = None
    function_return_value_1 = chown(path_like_0, str_0, str_1, boolean_0)


# Generated at 2022-06-25 17:32:32.281805
# Unit test for function get_os_group

# Generated at 2022-06-25 17:32:33.251102
# Unit test for function exists_as
def test_exists_as():
    test_case_0()



# Generated at 2022-06-25 17:32:54.320348
# Unit test for function exists_as
def test_exists_as():
    print()
    print('exists_as()')
    str_0 = '/home/test_user'
    str_1 = 'tmp/*'
    str_2 = '/home/test_user/tmp'
    str_3 = '~/tmp/*'

    print(exists_as(Path(str_0)))
    print(exists_as(Path(str_1)))
    print(exists_as(Path(str_2)))
    print(exists_as(Path(str_3)))
    print(exists_as(Path(str_0)))
    print(exists_as(Path(str_1)))
    print(exists_as(Path(str_2)))
    print(exists_as(Path(str_3)))

# Generated at 2022-06-25 17:32:57.530649
# Unit test for function chmod
def test_chmod():
    # Module variables
    global str_0
    str_0 = '/home/test_user/tmp/*'

    # Function call
    chmod(str_0)



# Generated at 2022-06-25 17:33:04.982433
# Unit test for function chmod
def test_chmod():
    test_case_1_mock_chmod_chmod = mock.MagicMock(return_value=None)
    @mock.patch('flutils.pathutils.chmod.chmod', new=test_case_1_mock_chmod_chmod)
    def test_case_1():
        str_0 = '/home/test_user/tmp/*'
    str_0 = test_case_1()
    test_case_1_mock_chmod_chmod.assert_called_with(str_0, mode_dir=0o700, mode_file=0o600)
    return True


# Generated at 2022-06-25 17:33:11.878789
# Unit test for function path_absent
def test_path_absent():
    path_test_0 = '/home/test_user/tmp/test_path'
    path_test_1 = '/home/test_user/tmp/test_path/test_path_one'
    path_test_2 = '/home/test_user/tmp/test_path/test_path_two'
    path_test_3 = '/home/test_user/tmp/test_path/test_path_three'
    path_test_4 = '/home/test_user/tmp/test_path/test_path_one/test_path_one_four'
    path_test_5 = '/home/test_user/tmp/test_path/test_path_one/test_path_one_five'

# Generated at 2022-06-25 17:33:23.566980
# Unit test for function path_absent
def test_path_absent():
    print('Testing function path_absent')

    # Create the test directory
    p = Path('~/tmp/test_path')
    path_absent(p)
    p.mkdir(0o700)

    # Create the test file
    p = Path('~/tmp/test_dir/test_file')
    path_absent(p)
    p.touch()

    # Create the test symbolic link
    p = Path('~/tmp/test_dir/test_symlink')
    path_absent(p)
    p.symlink_to('/home/test_user/tmp/test_dir/test_file')

    # Create the test directory and remove it in a single step
    p = Path('~/tmp/test_dir')
    p.mkdir(0o700)
    path_abs

# Generated at 2022-06-25 17:33:24.417134
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-25 17:33:31.814044
# Unit test for function chown
def test_chown():
    str_0 = '**'
    str_1 = '/home/test_user/tmp/*'
    str_2 = '/home/test_user/tmp/file'

    # Test case 0
    str_3 = '-1'
    str_4 = '/home/test_user/tmp/*'
    chown(str_4, user = str_3, include_parent = True)

    # Test case 1
    str_3 = '/home/test_user/tmp/chown'
    str_4 = '/home/test_user/tmp/*'
    chown(str_4, user = str_3, group = str_3, include_parent = True)

    # Test case 2
    chown(str_1)

    # Test case 3
    chown(str_1, user = str_1)

   

# Generated at 2022-06-25 17:33:34.325521
# Unit test for function directory_present
def test_directory_present():
    str_0 = '/home/test_user/tmp/*'
    str_1 = '/home/test_user/tmp/'
    Path_2 = directory_present(str_0)
    assert str(Path_2) == str_1

# Generated at 2022-06-25 17:33:36.781036
# Unit test for function chmod
def test_chmod():
    path = '/home/test_user/tmp/*'
    mode_file = None
    mode_dir = None
    include_parent = False
    chmod(path, mode_file, mode_dir, include_parent)


# Generated at 2022-06-25 17:33:41.762346
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [Path('~/tmp/file_one'), Path('~/tmp/dir_one')]
    assert list(find_paths('~/tmp/happy_*')) == [Path('~/tmp/happy_panda')]

# Generated at 2022-06-25 17:33:54.464446
# Unit test for function chmod
def test_chmod():
    '''
    UNIT TESTS FOR FUNCTION chmod

    '''
    import shutil
    import stat
    import tempfile
    import unittest

    from flutils.commonutils import (
        pushd,
    )
    from flutils.pathutils import (
        chmod,
    )

    def perm_to_int(perm_str: str) -> int:
        '''
        Converts a permission string to an integer

        '''
        perm_int = 0
        for ch in perm_str:
            perm_int *= 8

# Generated at 2022-06-25 17:33:57.936710
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    path = Path(tempfile.gettempdir()) / 'test_path'
    path.mkdir(mode=0o700)
    path_absent(path)
    assert path.exists() is False

if __name__ == '__main__':
    # Test path_absent
    #test_case_0()
    test_path_absent()

# Generated at 2022-06-25 17:34:07.981819
# Unit test for function chmod

# Generated at 2022-06-25 17:34:18.674128
# Unit test for function exists_as
def test_exists_as():
    # Test case 0:
    # Test empty string return value when path does not exist.
    assert exists_as('~/does NOT exist/') == ''

    # Test case 1:
    # Test 'file' return value when path exists and is a file.
    assert exists_as('~/.gitignore_global') == 'file'

    # Test case 2:
    # Test 'char device' return value when path exists and is a char device.
    assert exists_as('/dev/null') == 'char device'

    # Test case 3:
    # Test 'block device' return value when path exists and is a block device.
    assert exists_as('/dev/sda') == 'block device'

    # Test case 4:
    # Test 'FIFO' return value when path exists and is a FIFO.
    assert exists_as

# Generated at 2022-06-25 17:34:22.733487
# Unit test for function chown
def test_chown():
    test_path = r'E:\\tmp\\flutils.test_chown'
    chown(test_path)
    os.chmod(test_path, 0o660)



# Generated at 2022-06-25 17:34:25.620962
# Unit test for function path_absent
def test_path_absent():
    p = cast(str, normalize_path('~/tmp/test_file').as_posix())
    with open(p, 'w') as fp:
        fp.write('foo')
    assert os.path.exists(p) is True
    path_absent('~/tmp/test_file')
    assert os.path.exists(p) is False



# Generated at 2022-06-25 17:34:34.740814
# Unit test for function exists_as
def test_exists_as():
    path_set = {
        'directory': '/Users/len/tmp',
        'file': '/Users/len/tmp/.bash_history',
        'block device': '/dev/disk1',
        'char device': '/dev/console',
        'FIFO': '/tmp/shm/2b4d4d8b-c3a6-4a57-9011-8e056b9821e5',
        'socket': '/var/run/ssh-YiRKkfRk0C/agent.1234',
        'broken link': '/Users/len/tmp/not-a-real-path',
        'unknown': '/Users/len/tmp/not-a-real-file',
        'empty': ''
    }


# Generated at 2022-06-25 17:34:45.664770
# Unit test for function chown

# Generated at 2022-06-25 17:34:58.241188
# Unit test for function path_absent
def test_path_absent():
    """
    Function: path_absent

    Ensure the given ``path`` does **NOT** exist.

    If the given ``path`` does exist, it will be deleted.

    If the given ``path`` is a directory, this function will
    recursively delete all of the directory's contents.

    :rtype: :obj:`None`
    """

    # Test Case 0
    # Create a temporary directory and create subdirectories and files
    # within that directory that will be deleted by the
    # path_absent function.
    with tempfile.TemporaryDirectory() as tmp_dir:
        test_path = os.path.join(tmp_dir, 'test_path')
        # Create a directory to be deleted
        os.mkdir(test_path)
        # Create a file to be deleted

# Generated at 2022-06-25 17:35:07.694321
# Unit test for function exists_as
def test_exists_as():
    # Bad file path
    assert exists_as('/this/file/does/not/exist') == ''

    # File
    assert exists_as('/etc/hosts') == 'file'

    # Block device
    assert exists_as('/dev/sda') == 'block device'

    # Directory
    assert exists_as('/etc') == 'directory'

    # Character device
    assert exists_as('/dev/pts/0') == 'char device'

    # FIFO
    assert exists_as('/dev/stdin') == 'FIFO'

    # Socket
    assert exists_as('/tmp/ssh-XXXXXXXXXX/agent.32765') == 'socket'



# Generated at 2022-06-25 17:35:30.110721
# Unit test for function exists_as
def test_exists_as():
    # Test case 1
    #
    # Test case 1, path type = str
    expected_result_1 = 'directory'
    actual_result_1 = exists_as('/usr/bin')
    assert actual_result_1 == expected_result_1,\
        f'\n{inspect.currentframe().f_code.co_name}\n'\
        f'TEST CASE 1\n'\
        f'Inputs: /usr/bin (str)\n'\
        f'Expected result = {expected_result_1}\n'\
        f'Actual result = {actual_result_1}\n'

    # Test case 2
    #
    # Test case 2, path type = PosixPath
    expected_result_2 = 'directory'

# Generated at 2022-06-25 17:35:32.399514
# Unit test for function get_os_user
def test_get_os_user():
    s_test_get_os_user = str(test_case_0)
    s_test_get_os_user_results = re.findall(r'\(pw_name=\'(.*?)\', pw_passwd', s_test_get_os_user)
    assert s_test_get_os_user_results[0] == getpass.getuser()


# Generated at 2022-06-25 17:35:39.871446
# Unit test for function path_absent
def test_path_absent():
    import shutil
    tmp = os.path.join(tempfile.gettempdir(), 'flutils_test_data')
    path = os.path.join(tmp, 'tmp', 'path_absent')
    path_absent(path)
    tmp_files = os.listdir(tmp)
    assert 'tmp' not in tmp_files
    directory = os.path.join(tmp, 'directory')
    os.makedirs(directory)
    path_absent(directory)
    tmp_files = os.listdir(tmp)
    assert 'directory' not in tmp_files



# Generated at 2022-06-25 17:35:51.209242
# Unit test for function exists_as
def test_exists_as():
    import os.path
    import unittest

    class TestExists_As(unittest.TestCase):
        def setUp(self):
            ''' Sets up the test case for function exists_as.'''
            self.path1 = os.path.curdir
            self.path2 = os.path.join(os.path.curdir, 'makefile')
            self.path3 = os.path.join(os.path.curdir, 'fakefile')
            self.path4 = os.path.join(os.path.curdir, 'fakefile1')

        def test_exists_as1(self):
            ''' Tests for the return of a directory.'''
            self.assertEqual(exists_as(self.path1), 'directory')


# Generated at 2022-06-25 17:35:54.279122
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    dir_path = directory_present('~/tmp/test_path')
    print("dir_path = {0}".format(dir_path))


# Generated at 2022-06-25 17:36:05.189385
# Unit test for function exists_as
def test_exists_as():

    # Create a path to a sample file
    path_file = Path("/Users/len/tmp/exists_as_sample_file")

    # Create a path to a sample directory
    path_dir = Path("/Users/len/tmp/exists_as_sample_dir")

    # Remove the test file and directory if it exists
    try:
        Path(path_file).unlink()
    except Exception:
        pass

    try:
        Path(path_dir).rmdir()
    except Exception:
        pass

    # If the file or dir does not exist, returns ''
    assert exists_as(path_file) == ''
    assert exists_as(path_dir) == ''

    # Create the test file and directory
    assert Path(path_file).mkdir(parents=True) == None

# Generated at 2022-06-25 17:36:13.276893
# Unit test for function get_os_user
def test_get_os_user():
    _user_list = [
        'root',
        'nobody'
    ]
    struct_passwd_0 = get_os_user()
    struct_passwd_1 = get_os_user('root')
    struct_passwd_2 = get_os_user('nobody')
    struct_passwd_3 = get_os_user('-1')
    struct_passwd_4 = get_os_user(0)
    struct_passwd_5 = get_os_user(65534)

# Generated at 2022-06-25 17:36:15.789780
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-25 17:36:25.857793
# Unit test for function chown
def test_chown():
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = os.path.join(tmpdirname, 'tmpdir')
        tmpfile = os.path.join(tmpdir, 'tmpfile')
        os.mkdir(tmpdir)
        with open(tmpfile, 'w'):
            pass

        orig_user = get_os_user().pw_uid
        orig_group = get_os_group().gr_gid
        chown(tmpfile)

        new_user = get_os_user().pw_uid
        new_group = get_os_group().gr_gid
        assert orig_user == new_user and orig_group == new_group


# Generated at 2022-06-25 17:36:29.798593
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.touch()

    assert exists_as(path) == 'file'

    path.unlink()



# Generated at 2022-06-25 17:37:15.512232
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    test_path = Path('~/tmp/flutils_test_absent')

    if test_path.is_dir():
        path_absent(test_path)

    # Ensures the test path is gone.
    if test_path.is_dir():
        raise AssertionError('Test path is still present.')

    test_path.mkdir(mode=0o755)

    if test_path.is_dir() is False:
        raise AssertionError('Test path was not properly created.')

    test_file1 = test_path.joinpath('test_file1')
    test_file2 = test_path.joinpath('test_file2')
    test_path.joinpath('test_file3').mkdir(mode=0o755)

   

# Generated at 2022-06-25 17:37:17.192615
# Unit test for function path_absent
def test_path_absent():
    path = 'pathutils_test_dir'
    path_absent(path)


# Generated at 2022-06-25 17:37:27.452815
# Unit test for function chown
def test_chown():

    # path is not a directory
    with temporary_directory() as tmpdir:
        path = Path(tmpdir) / 'temp.flutils.test.txt'
        path.touch()
        chown(path, user='nobody')
        assert get_os_user(path.stat().st_uid).pw_name == 'nobody'

    chown(path, user='-1')
    assert get_os_user(path.stat().st_uid).pw_name == getpass.getuser()

    # path exists but is a directory
    with temporary_directory() as tmpdir:
        path = Path(tmpdir) / 'temp.flutils.test.dir'
        path.mkdir(parents=True)
        assert path.is_dir()

        chown(path, 'nobody')
        assert get_os

# Generated at 2022-06-25 17:37:37.016138
# Unit test for function chown
def test_chown():
    path = '~/tmp'
    path = normalize_path(path)
    if '*' in path.as_posix():
        for sub_path in Path().glob(path.as_posix()):
            if sub_path.is_dir() or sub_path.is_file():
                print(sub_path)
            #os.chown(sub_path.as_posix(), uid, gid)
    else:
        print(path)
        #os.chown(path.as_posix(), uid, gid)
    #assert _normalize_path('~/tmp') == '/home/foo/tmp'



# Generated at 2022-06-25 17:37:41.990668
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()

    assert struct_passwd_0.pw_name == 'test_user'
    assert struct_passwd_0.pw_gecos == 'Test User'
    assert struct_passwd_0.pw_uid == 1000
    assert struct_passwd_0.pw_gid == 2000
    assert struct_passwd_0.pw_dir == '/home/test_user'
    assert struct_passwd_0.pw_shell == '/usr/local/bin/bash'

    struct_passwd_1 = get_os_user('test_user')
    assert struct_passwd_1 == struct_passwd_0

    struct_passwd_2 = get_os_user(1000)
    assert struct_passwd_2 == struct_passwd

# Generated at 2022-06-25 17:37:49.657741
# Unit test for function directory_present
def test_directory_present():
    # Test case 0
    path = '~/tmp/flutils.tests.osutils'
    expected_passwd = struct_passwd_0
    out_path = directory_present(path, user=expected_passwd.pw_name)
    path_info = os.stat(path, follow_symlinks=False)
    assert out_path == path
    assert path_info.st_uid == expected_passwd.pw_uid
    assert path_info.st_gid ==  expected_passwd.pw_gid
    assert path_info.st_mode == 493


# Generated at 2022-06-25 17:38:02.050700
# Unit test for function chmod
def test_chmod():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    path_to_create_0 = Path('/tmp/flutils.tests.osutils.chmod.dir')
    path_to_create_1 = Path('/tmp/flutils.tests.osutils.chmod.dir1')

    path_to_create_0.mkdir(mode=0o700, parents=True, exist_ok=True)
    path_to_create_1.mkdir(mode=0o700, parents=True, exist_ok=True)

    path_to_create_0.joinpath('tmp_file').write_text('test')


# Generated at 2022-06-25 17:38:03.719132
# Unit test for function chown
def test_chown():

    chown_ret = chown('docs/../docs/README.rst')



# Generated at 2022-06-25 17:38:09.659303
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/var') == 'directory'
    assert exists_as('/correct') == ''
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/urandom') == 'block device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/log') == 'socket'



# Generated at 2022-06-25 17:38:15.630069
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    mydir = TemporaryDirectory()
    path = normalize_path(mydir.name + '/test')
    try:
        directory_present(path)
        assert path.exists() is True
        assert path.is_dir() is True
        assert path.stat().st_mode & 0o700
    finally:
        rmtree(mydir.name)


# Generated at 2022-06-25 17:38:38.086881
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o600, mode_dir=0o700)
    test_passwd = get_os_user()
    test_group = get_os_group()


# Generated at 2022-06-25 17:38:44.930509
# Unit test for function chown
def test_chown():
    chown_path = normalize_path('~/.bashrc')
    chown_path_before = get_os_user(chown_path.owner()).pw_name
    chown(chown_path, 'root', 'root')
    chown_path_after = get_os_user(chown_path.owner()).pw_name
    assert chown_path_before != chown_path_after
    chown(chown_path, chown_path_before, chown_path_before)
    assert chown_path.owner() == chown_path_before


# Generated at 2022-06-25 17:38:50.381145
# Unit test for function chmod
def test_chmod():
    test_path = '~/tmp/flutils.tests.osutils.txt'
    test_path = normalize_path(test_path)
    if test_path.exists():
        test_path.unlink()
    chmod(test_path, 0o660)
    if test_path.exists():
        assert True


# Generated at 2022-06-25 17:38:55.272499
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    # Get the the test user's home directory.
    test_user_home: Path = normalize_path('~')

    # Create a directory test_dir and add a file to test_dir.
    test_dir = os.path.join(test_user_home, 'tmp', 'test_dir')
    os.makedirs(test_dir, mode=0o755, exist_ok=True)
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'wt') as f:
        f.write('Test contents')

    # Create a symbolic link to test_dir.
    test_link = os.path.join(test_user_home, 'tmp', 'test_link')
    os.symlink

# Generated at 2022-06-25 17:39:05.230085
# Unit test for function chown
def test_chown():
    # Test with non existing path
    path = '~/tmp/flutils.tests.osutils.not.existent'
    chown(path, user='admin', group='adm', include_parent=True)
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()
    path = normalize_path(path)
    stat = os.stat(path.as_posix())
    assert stat.st_uid == struct_passwd_0.pw_uid
    assert stat.st_gid == struct_group_0.gr_gid
    assert path.parent.stat().st_uid == struct_passwd_0.pw_uid
    assert path.parent.stat().st_gid == struct_group_0.gr_gid

    # Test with non

# Generated at 2022-06-25 17:39:13.935847
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    file_path = os.path.join(tmpdir, "Test")
    with open(file_path, "w") as f:
        print("Test", file=f)
    dir_path = os.path.join(tmpdir, "Test2")
    try:
        os.mkdir(dir_path)
    except OSError:
        pass
    path_absent(tmpdir)
    assert not os.path.exists(tmpdir)

# Generated at 2022-06-25 17:39:25.998483
# Unit test for function chmod
def test_chmod():
    from testfixtures import LogCapture
    from flutils.pathutils import chmod

    logcapture = LogCapture()

    # Test case 0
    chmod_path = '/tmp/flutils.pathutils.chmod.txt'
    open(chmod_path, 'w').close()
    chmod(chmod_path, mode_file=0o640)
    assert os.stat(chmod_path).st_mode & 0o777 == 0o640

    # Test case 1
    chmod('/tmp/**', mode_dir=0o771)
    # TODO: Implement Path().glob().

    # Test case 2
    chmod_path = '/tmp/flutils.pathutils.chmod.dir'
    os.mkdir(chmod_path)

# Generated at 2022-06-25 17:39:34.264985
# Unit test for function chmod
def test_chmod():
    from pathlib import Path
    from shutil import rmtree
    path = Path('.').resolve()
    root = path / 'tmp' / 'flutils.tests.osutils.txt'
    root.parent.mkdir(exist_ok=True, parents=True)
    root.write_text('test')


# Generated at 2022-06-25 17:39:38.548774
# Unit test for function exists_as
def test_exists_as():
    # Test for directory's.
    with TemporaryDirectory() as tmp_path:
        current_path = Path(tmp_path)
        assert exists_as(current_path) == 'directory'
        assert exists_as(current_path.as_posix()) == 'directory'
        assert exists_as(current_path.as_bytes()) == 'directory'

        # A directory can also be a file
        current_path = Path(tmp_path, 'foo')
        assert exists_as(current_path) == 'directory'
        assert exists_as(current_path.as_posix()) == 'directory'
        assert exists_as(current_path.as_bytes()) == 'directory'

    # Test for files.
    with TemporaryDirectory() as tmp_path:
        current_path = Path(tmp_path, 'foo')

# Generated at 2022-06-25 17:39:49.842703
# Unit test for function chown
def test_chown():
    class pwd0(pwd.struct_passwd):
        pw_name = 'systemd-coredump'
        pw_gecos = 'systemd coredump user'
        pw_dir = '/'
        pw_shell = '/sbin/nologin'
        pw_uid = 999
        pw_gid = 999

    def patched_getpwnam(username):
        if username == 'systemd-coredump':
            return pwd0
        else:
            raise KeyError

    patcher = mock.patch('pwd.getpwnam', patched_getpwnam)
    patched_getpwnam = patcher.start()
    addCleanup(patcher.stop)


# Generated at 2022-06-25 17:40:10.061933
# Unit test for function chmod
def test_chmod():
    print ('Testing chmod')
    print ('\tTesting chmod_0')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')
    print ('\tTest Passed')


# Generated at 2022-06-25 17:40:20.174197
# Unit test for function exists_as
def test_exists_as():
    """
    Test cases for the pathutils.exists_as function.
    """
    # Test case for a directory
    assert exists_as('~/tmp') == 'directory'
    # Test case for a regular file
    assert exists_as('~/tmp/flutils.tests.py') == 'file'
    # Test case for called with a None type
    assert exists_as(None) == ''
    # Test case for a glob pattern
    assert exists_as('~/tmp/*') == ''
    # Test case for a broken link
    assert exists_as('~/tmp/flutils.tests.pyz') == ''
    # Test case for a created path that doesn't exist
    assert exists_as('~/tmp/flutils.tests.pyy') == ''


# Generated at 2022-06-25 17:40:24.297260
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.pathutils.txt', user='foo', group='bar')
    chown('/tmp/flutils.tests.pathutils.txt', user='foo')
    chown('/tmp/flutils.tests.pathutils.txt', group='bar')


# Generated at 2022-06-25 17:40:36.516771
# Unit test for function chmod
def test_chmod():
    test_path = os.path.normpath('~/tmp/flutils.tests.pathutils.txt')
    test_path = normalize_path(test_path)

    if test_path.exists():
        test_path.unlink()

    test_path.touch()
    chmod(test_path, 0o660)
    assert os.path.exists(test_path) is True
    assert os.path.isfile(test_path) is True
    assert oct(os.stat(test_path).st_mode & 0o777) == '0o660'
    test_path.unlink()

    test_path.touch()
    chmod(test_path, 0o660, include_parent=True)
    assert os.path.exists(test_path) is True

# Generated at 2022-06-25 17:40:48.778402
# Unit test for function chown
def test_chown():
    test_path_list = []
    test_path_list.append("test/test_pathutils/test_chown")
    test_path_list.append("test/test_pathutils/test_chown/*")
    test_path_list.append("test/test_pathutils/test_chown/test_pathutils")
    test_path_list.append("test/test_pathutils/test_chown/test_chown.txt")
    test_path_list.append("test/test_pathutils/test_chown/test_chown_0.txt")
    test_path_list.append("test/test_pathutils/test_chown/test_chown_1.txt")

# Generated at 2022-06-25 17:40:54.549337
# Unit test for function chmod
def test_chmod():
    path = normalize_path('/tmp/flutils.tests/osutils/test.txt')
    create_path(path)
    chmod(path, 0o660)
    mode = os.stat(path.as_posix(), follow_symlinks=False).st_mode
    result = stat.S_IMODE(mode)
    assert result == 0o660
    cleanup_path(path)


# Generated at 2022-06-25 17:41:04.679598
# Unit test for function path_absent
def test_path_absent():
    # Test Case 0
    path = Path('/tmp/pathutils_test_path')
    path.mkdir()
    path_absent(path)
    assert not path.exists()
    # Test Case 1
    path = Path('/tmp/pathutils_test_path1')
    path.mkdir()
    path_absent(path.as_posix())
    assert not path.exists()
    # Test Case 2
    path = Path('/tmp/pathutils_test_path2')
    path.mkdir()
    path_absent(path.as_posix().encode('utf-8'))
    assert not path.exists()


# Generated at 2022-06-25 17:41:06.509895
# Unit test for function chmod
def test_chmod():
    # TODO: Do the test
    pass


# Generated at 2022-06-25 17:41:15.470690
# Unit test for function chmod
def test_chmod():
    file_path_0 = 'test_chmod.txt'
    file_path_1 = 'test_chmod_1.txt'
    dir_path_0 = 'test_chmod_dir'

    # Create file, file_path_0
    with open(file_path_0, 'w') as file_0:
        pass

    # Create file, file_path_1
    with open(file_path_1, 'w') as file_1:
        pass

    # Create directory, dir_path_0
    os.mkdir(dir_path_0)

    # Apply mode 0o660 to file, file_path_0
    chmod(file_path_0, 0o660)