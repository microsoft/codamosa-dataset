

# Generated at 2022-06-25 17:31:56.803435
# Unit test for function find_paths
def test_find_paths():
    files_0 = ['~/tmp/flutils.tests.osutils.txt']
    files_1 = ['~/tmp/file_one', '~/tmp/file_two', '~/tmp/file_three']
    files_2 = ['~/tmp/file_two', '~/tmp/file_three', '~/tmp/file_four']
    files_3 = ['~/tmp/flutils.tests.osutils.txt', '~/tmp/file_*']
    files_4 = ['~/tmp/file_one', '~/tmp/file_two', '~/tmp/file_three', '~/tmp/file_four']

    for path in find_paths(files_0[0]):
        print(path)


# Generated at 2022-06-25 17:32:06.437869
# Unit test for function chown
def test_chown():
    try:
        uid_prev = os.stat('chown.txt').st_uid
        gid_prev = os.stat('chown.txt').st_gid
    except:
        raise

    struct_passwd_tests = get_os_user()
    struct_group_tests = get_os_group()

    try:
        chown('chown.txt', 'tests')
        assert os.stat('chown.txt').st_uid == struct_passwd_tests.pw_uid
        assert os.stat('chown.txt').st_gid == struct_group_tests.gr_gid
    except:
        raise

    try:
        os.chown('chown.txt', uid_prev, gid_prev)
    except:
        raise


# Generated at 2022-06-25 17:32:19.177447
# Unit test for function chmod
def test_chmod():
    t_path = None
    if sys.platform == 'linux':
        t_path = os.path.join('~', 'tmp', 'flutils.tests.osutils.txt')
    elif sys.platform == 'darwin':
        t_path = os.path.join('~', 'tmp', 'flutils.tests.osutils.txt')
    else:
        print("Unsupported platform")

    # Test case where the path is a file
    chmod(t_path, 0o660)

    # Test case where the path is a directory
    chmod(os.path.join('~', 'tmp'), 0o755)

    # Test case where the path is glob pattern
    chmod(os.path.join('~', 'tmp', '*'), mode_file=0o444, mode_dir=0o770)



# Generated at 2022-06-25 17:32:27.778648
# Unit test for function chmod
def test_chmod():
    struct_passwd_0 = get_os_user()
    print("Running test_case_0...")
    print("Creating file to chmod")
    path = normalize_path("~/tmp/test_file_0.txt")
    path.write_text('test')
    print("Running test chmod(0o600)")
    chmod(path, 0o600)
    print("Running test chmod(0o600, include_parent=True)")
    chmod(path, 0o600, include_parent=True)
    print("Running test chmod(0o600, include_parent=True)")
    chmod(path, 0o600)
    print("Running test chmod(0o700)")
    chmod(path, 0o700)

# Generated at 2022-06-25 17:32:35.028726
# Unit test for function exists_as
def test_exists_as():
    """Test for function ``exists_as``."""
    # Test for a path that does not exist
    assert exists_as('/home/foo/does/not/exist') == ''

    # Test for a directory
    assert exists_as('/home') == 'directory'

    # Test for a file
    assert exists_as('/etc/hosts') == 'file'

    # Test for a block device
    if sys.platform in ['linux', 'linux2']:
        assert exists_as('/dev/sr0') == 'block device'

    # Test for a character device
    if sys.platform in ['linux', 'linux2']:
        assert exists_as('/dev/null') == 'char device'

    # Test for a FIFO
    if sys.platform in ['linux', 'linux2']:
        assert exists_

# Generated at 2022-06-25 17:32:43.453845
# Unit test for function exists_as
def test_exists_as():
    import os
    import tempfile
    my_temp_dir = tempfile.mkdtemp()
    my_temp_file = os.path.join(my_temp_dir, os.path.basename('foo'))
    open(my_temp_file,'w').close()
    try:
        assert(exists_as(my_temp_dir) == 'directory')
        assert(exists_as(my_temp_file) == 'file')
    finally:
        os.remove(my_temp_file)
        os.removedirs(my_temp_dir)


# Generated at 2022-06-25 17:32:48.855226
# Unit test for function find_paths
def test_find_paths():
    '''
       Unit test for function find_paths
    '''
    path = '/tmp/'
    p = Path(path)
    #print(p.absolute().as_posix())
    #print(p.anchor)
    #print(p.as_posix())
    pattern = '/tmp/dir_one/*'
    list_path = list(find_paths(pattern))
    print(list_path)
    for path in list_path:
        print(path.as_posix())


# Generated at 2022-06-25 17:33:02.088938
# Unit test for function directory_present
def test_directory_present():
    # Test case 0
    struct_passwd_0 = get_os_user()
    path_0 = Path(struct_passwd_0.pw_dir) / 'tmp' / 'test_directory_present'
    directory_present(path_0,
            mode=0o700,
            user='-1',
            group='-1'
        )
    path_0.chmod(0o700)
    path_0.chown(struct_passwd_0.pw_uid, struct_passwd_0.pw_gid)
    assert path_0.exists() == True
    assert struct_passwd_0.pw_uid == path_0.stat().st_uid
    assert struct_passwd_0.pw_gid == path_0.stat().st_gid

# Generated at 2022-06-25 17:33:04.415687
# Unit test for function path_absent
def test_path_absent():
    path_absent("~/tmp")

# Run tests
if __name__ == '__main__':
    test_case_0()
    test_path_absent()

# Generated at 2022-06-25 17:33:07.734598
# Unit test for function path_absent
def test_path_absent():
    test_path = Path('~/tmp/bar')
    if test_path.exists():
        test_path.unlink()
    path_absent(test_path)
    assert test_path.exists() == False
    path_absent(test_path)


# Generated at 2022-06-25 17:33:19.414139
# Unit test for function exists_as
def test_exists_as():
    print(exists_as('/'))
    print(exists_as('/tmp/test.txt'))
    print(exists_as('../pathutils.py'))
    print(exists_as('pathutils.py'))

if __name__ == '__main__':
    test_case_0()
    test_exists_as()

# Generated at 2022-06-25 17:33:29.826117
# Unit test for function chown
def test_chown():
    testdir = 'testdir'
    home = str(Path.home())
    testdir_path = Path(home + '/' + testdir)
    testdir_path.mkdir()
    #os.chdir(testdir)

    def check_file_owner_group(file = 'test.txt',
                               user = getpass.getuser(),
                               group = 'users'):

        st = os.stat(file)
        uid = st.st_uid
        i_user = pwd.getpwuid(uid).pw_name
        gid = st.st_gid
        i_group = grp.getgrgid(gid).gr_name
        assert i_user == user and i_group == group


# Generated at 2022-06-25 17:33:37.504402
# Unit test for function directory_present
def test_directory_present():
    struct_group_0 = get_os_group()
    struct_passwd_0 = get_os_user()
    directory_present('/Users/len/tmp/test_path')
    directory_present('/Users/len/tmp/test_dir_1')
    directory_present('/Users/len/tmp/test_dir_1/test_dir_2')
    directory_present('/Users/len/tmp/test_dir_1/test_dir_2/test_dir_3')
    directory_present('/Users/len/tmp/test_dir_1/test_dir_2/test_dir_3/test_dir_4')
    chown('/Users/len/tmp/test_dir_1/*', user='len', group=struct_group_0.gr_name)

# Generated at 2022-06-25 17:33:47.729805
# Unit test for function chmod
def test_chmod():
    def test_case_0_sub(sub_path):
        sub_path.chmod(0o644)

    chmod('a.py', 0o644)
    chmod('b.py', 0o644)
    chmod('c.py', 0o644)
    chmod('subdir/subsubdir/subsubsubdir/*', 0o644)
    chmod('subdir/subsubdir/*', 0o644)
    chmod('subdir/subsubdir/*', 0o644)
    chmod('subdir/*', 0o644)
    chmod('subdir/*', 0o644)

    Path('subdir/subsubdir').glob('subsubsubdir/*')
    list(Path('subdir/subsubdir').glob('subsubsubdir/*'))

# Generated at 2022-06-25 17:33:53.670348
# Unit test for function chmod
def test_chmod():
    path = normalize_path('./test/test_file_0.txt')
    if path.exists() is True:
        print ("File exists")
        chmod(path, None, None)
    else:
        print ("File does not exist")
    path.stat()
    print (path.stat())
  

# Generated at 2022-06-25 17:34:04.198190
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/var') == 'directory'
    assert exists_as('/var/www') == 'directory'
    assert exists_as('/var/www/html') == 'directory'
    assert exists_as('/var/www/html/') == 'directory'
    assert exists_as('/var/www/html/index.html') == 'file'
    assert exists_as('/var/www/doesnotexist') == ''
    assert exists_as('/usr/bin/python3') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/loop7') == 'block device'
    assert exists

# Generated at 2022-06-25 17:34:11.165442
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwnam(getpass.getuser())
    assert get_os_user(1001) == pwd.getpwuid(1001)
    assert get_os_user('foo') == pwd.getpwnam('foo')
    with pytest.raises(OSError):
        get_os_user(10001)
    with pytest.raises(OSError):
        get_os_user('unittest_username')


# Generated at 2022-06-25 17:34:13.293561
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    chmod(path, 0o660)
    assert os.stat(path).st_mode == 33188


# Generated at 2022-06-25 17:34:21.473689
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()

    current_user = (getpass.getuser(), struct_passwd_0.pw_uid)
    current_group = (grp.getgrgid(struct_passwd_0.pw_gid).gr_name, struct_passwd_0.pw_gid)

    chown('/tmp/test/chown.txt', current_user[0], current_group[0])

    stat_result = os.stat('/tmp/test/chown.txt')
    if stat_result.st_uid != current_user[1]:
        raise OSError('UserID is not correct')
    if stat_result.st_gid != current_group[1]:
        raise OSE

# Generated at 2022-06-25 17:34:28.991460
# Unit test for function chmod
def test_chmod():
    path = "./flutils.tests.pathutils.txt"
    chmod(path, 0o700)
    norm_path = normalize_path(path)
    assert(norm_path.exists() is True)
    assert(norm_path.is_file() is True)
    assert(norm_path.is_dir() is False)
    assert(norm_path.is_symlink() is False)
    assert(norm_path.is_socket() is False)



# Generated at 2022-06-25 17:34:41.445857
# Unit test for function directory_present
def test_directory_present():
    # Unit test to create new dir
    directory_present('/home/datadrive/test0/temp')

    # Unit test to update already created dir
    directory_present('/home/datadrive/test0/temp')

    # Unit test to create new dir without owner/group/mode
    directory_present('/home/datadrive/test0/temp1')

    # Unit test to update already created dir without owner/group/mode
    directory_present('/home/datadrive/test0/temp1')

    # Unit test to create new dir with owner/group/mode
    directory_present('/home/datadrive/test0/temp2', mode=0o755, user='root', group='root')

    # Unit test to update already created dir with owner/group/mode

# Generated at 2022-06-25 17:34:55.054568
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function: exists_as.

    Returns:
        :obj:`tuple` of :obj:`bool`: The first boolean value indicates
        whether the first test function succeeded. The second boolean value
        indicates whether the second test function succeeded.

    """

# Generated at 2022-06-25 17:35:01.630281
# Unit test for function directory_present
def test_directory_present():
    test_dir = '/Users/len/tmp'
    test_path = directory_present(test_dir)
    assert test_path.as_posix() == test_dir
    assert test_path.exists() == True
    assert test_path.is_dir() == True



# Generated at 2022-06-25 17:35:09.947929
# Unit test for function chmod
def test_chmod():
    # chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o644)
    path = Path.home() / 'tmp' / 'flutils.tests.osutils.txt'
    path.touch()
    chmod(path, mode_file=0o644)
    assert path.stat().st_mode & 0o777 == 0o644
    path.chmod(0o755)


# Generated at 2022-06-25 17:35:14.579841
# Unit test for function path_absent
def test_path_absent():
    # create the path and make sure it exists
    the_path = Path(os.getcwd(), 'tmp', 'test')
    the_path.mkdir(parents=True, exist_ok=True)
    assert exists_as(the_path) == 'directory'
    # delete the path and make sure it doesn't exist
    path_absent(the_path)
    assert exists_as(the_path) == ''


# Generated at 2022-06-25 17:35:18.171121
# Unit test for function chown
def test_chown():
    # assert chown(path, user=None, group=None, include_parent=False):
    # assert 
    print("OK")


# Generated at 2022-06-25 17:35:21.844589
# Unit test for function directory_present
def test_directory_present():
    path = directory_present("/Users/len/Desktop/tmp/test_path")
    assert path == Path("/Users/len/Desktop/tmp/test_path")

test_directory_present()



# Generated at 2022-06-25 17:35:25.518804
# Unit test for function chmod
def test_chmod():
    path = '/home/leon/tmp'
    mode_file = 0o777
    mode_dir = 0o434
    include_parent = True
    chmod(path, mode_file, mode_dir, include_parent)
    
    


# Generated at 2022-06-25 17:35:28.388917
# Unit test for function chmod
def test_chmod():
    chmod(
        "~/tmp/flutils.tests.osutils.txt", 
        0o660
    )

# Generated at 2022-06-25 17:35:29.974533
# Unit test for function chmod
def test_chmod():
    assert_passes(test_case_0)


# Generated at 2022-06-25 17:35:49.129166
# Unit test for function chmod
def test_chmod():
    # Test case 0
    #
    # Test that the function chmod can be invoked and does not raise an
    # exception.
    try:
        test_case_0()
    except Exception as e:
        print('Error: ', e)
    else:
        print('Success!')

    # Test case 1
    #
    # Test that the function chmod can be invoked with no passed arguments and
    # does not raise an exception.
    try:
        chmod()
    except Exception as e:
        print('Error: ', e)
    else:
        print('Success!')

    # Test case 2
    #
    # Test that the function chmod raises an exception when passed an invalid
    # mode.

# Generated at 2022-06-25 17:35:53.219721
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    tmpdir = tempfile.gettempdir()
    path = pathlib.Path(tmpdir).joinpath('testdt')
    directory_present(path)
    assert path.exists()
    assert path.is_dir()


# Generated at 2022-06-25 17:36:04.316300
# Unit test for function get_os_user
def test_get_os_user():
    # Create a dict of arguments for get_os_user
    arguments = {}
    # get the return value of get_os_user
    ret_get_os_user = get_os_user(**arguments)
    # assert that our return type is a 'pwd.struct_passwd'
    assert(isinstance(ret_get_os_user, pwd.struct_passwd))
    # assert that our return type is a 'pwd.struct_passwd'
    assert(isinstance(ret_get_os_user, pwd.struct_passwd))
    # assert that our return type is not a different type
    assert(not isinstance(ret_get_os_user, pwd.struct_group))
    # assert that our return type is not a different type

# Generated at 2022-06-25 17:36:10.261415
# Unit test for function directory_present
def test_directory_present():
    # Test string
    assert str(directory_present("~/tmp/test_path3")) == "/Users/len/tmp/test_path"

    # Test None
    assert str(directory_present("~/tmp/test_path", None, None)) == "/Users/len/tmp/test_path"


# Generated at 2022-06-25 17:36:18.593057
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path_absent'
    dir_path = '~/tmp/test_path_absent/dir'
    file_path = '~/tmp/test_path_absent/dir/file'
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(dir_path)
    with open(file_path, 'w'):
        pass
    path_absent(path)
    assert os.path.exists(path) == False


# Generated at 2022-06-25 17:36:21.529486
# Unit test for function chmod
def test_chmod():
    chmod('C:\\Users\\david\\flutils\\flutils\\pathutils.py', mode_file=0o755)


# Generated at 2022-06-25 17:36:26.244891
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    if path.exists():
        print('osutils.py: path exists')
    else:
        print('osutils.py: path does not exist')
    chown(path)
    print(get_os_user().pw_uid)



# Generated at 2022-06-25 17:36:29.842293
# Unit test for function path_absent
def test_path_absent():
    path = '/opt/tmp/user_is_not_root'
    path_absent(path)
    assert os.path.exists(path) is False


# Generated at 2022-06-25 17:36:40.326631
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc/passwd') == 'file'
    # assert exists_as(':memory:') == 'database'
    assert exists_as('/Users') == 'directory'
    assert exists_as('/Users/zach') == 'directory'
    assert exists_as('/Users/zach/tmp') == 'directory'
    assert exists_as('/Users/zach/tmp/dir_present_foo') == ''
    assert exists_as('/Users/zach/tmp/dir_present_foo/') == ''
    assert exists_as('/Users/zach/tmp/dir_present_foo/bar') == ''
    assert exists_as('/Users/zach/tmp/dir_present_foo/bar/') == ''

# Generated at 2022-06-25 17:36:42.301100
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.pathutils.txt', 0o660)


# Generated at 2022-06-25 17:36:59.995087
# Unit test for function chmod
def test_chmod():
    # Test case 0
    # Test that chmod sets the right permissions for a file
    os.makedirs('/tmp/test_chmod_dir', mode=0o755)
    Path('/tmp/test_chmod_dir/test_chmod_file').touch()
    chmod('/tmp/test_chmod_dir/test_chmod_file', mode_file=0o660)
    assert oct(os.stat('/tmp/test_chmod_dir/test_chmod_file').st_mode & 0o777) == oct(0o660)
    os.remove('/tmp/test_chmod_dir/test_chmod_file')
    os.removedirs('/tmp/test_chmod_dir')

    # Test case 1
    # Test that chmod sets the right permissions for a directory


# Generated at 2022-06-25 17:37:07.700531
# Unit test for function chmod
def test_chmod():
    # Expected result from get_os_user call
    struct_passwd_0 = get_os_user()
    passwd_0 = struct_passwd_0.pw_name
    
    # Passing in the current user in get_os_user
    struct_passwd_1 = get_os_user(passwd_0)
    passwd_1 = struct_passwd_1.pw_name
    assert passwd_0 == passwd_1, "Function 'get_os_user' not working properly"


# Unittest fuction for get_os_group

# Generated at 2022-06-25 17:37:17.500448
# Unit test for function chown
def test_chown():

    # The current working directory should change from /tmp/
    # to /tmp/foo/ once the call to path.chown is made.
    path = Path.cwd()
    if path.as_posix() == '/tmp':
        path.chmod(0o700)
        chown(str(path), user='nobody', group='nogroup')
    else:
        path = Path('/tmp/foo')
        path.mkdir(parents=True, exist_ok=True)
        path.chmod(0o700)
        chown(str(path), user='nobody', group='nogroup')
        path.chmod(0o700)
        chown(str(path), user='nobody', group='nogroup')


# Generated at 2022-06-25 17:37:25.416929
# Unit test for function path_absent
def test_path_absent():

    # Create the path to test
    test_path = os.path.join(tempfile.gettempdir(), 'test_path')

    # Remove the path if it exists
    path_absent(test_path)

    # Create the path
    os.mkdir(test_path)

    # Assert that the path exists
    assert os.path.exists(test_path)

    # Call the function
    path_absent(test_path)

    # Assert that the path no longer exists
    assert os.path.exists(test_path) is False


# Generated at 2022-06-25 17:37:33.952097
# Unit test for function chmod
def test_chmod():

    # Setup
    path = Path('./tmp/flutils.tests.utils.txt')
    path.write_text('')

    # chmod: single file, change both modes
    chmod(path, 0o644, 0o755)
    assert path.stat().st_mode == 33188

    # chmod: single file, change only file mode
    path.write_text('')
    chmod(path, 0o644)
    assert path.stat().st_mode == 33188

    # chmod: single file, change only dir mode
    path.write_text('')
    chmod(path, mode_dir=0o755)
    assert path.stat().st_mode == 33188

    # chmod: single file, change none
    path.write_text('')
    chmod(path)


# Generated at 2022-06-25 17:37:43.416297
# Unit test for function chown
def test_chown():
    path = "testpath"
    user = "user"
    group = "group"
    if os.path.exists(path):
        os.rmdir(path)
    os.mkdir(path)
    chown(path,user,group)
    uid = get_os_user(user).pw_uid
    gid = get_os_group(group).gr_gid
    file_stat_info = os.stat(path)
    if file_stat_info.st_uid == uid and file_stat_info.st_gid == gid:
        status = True
    else:
        status = False
    # os.rmdir(path)
    return status


# Generated at 2022-06-25 17:37:52.859414
# Unit test for function exists_as
def test_exists_as():
    with tempfile.TemporaryDirectory() as tmpdir:
        filename = os.path.join(tmpdir, 'file.txt')
        touch(filename)
        assert exists_as(filename) == 'file'
        assert exists_as(os.path.join(tmpdir, 'noexistentfile')) == ''
        assert exists_as(tmpdir) == 'directory'
        assert exists_as(os.path.join(tmpdir, 'missingdir')) == ''
        assert exists_as('/dev/null') == 'char device'
        assert exists_as('/dev/zero') == 'char device'
        assert exists_as(os.path.join(tmpdir, 'missingchardev')) == ''
        assert exists_as('/dev/tty') == 'char device'
        assert exists_as('/dev/tty0')

# Generated at 2022-06-25 17:37:54.594407
# Unit test for function chmod
def test_chmod():
    chmod('~/.bashrc', 0o644)


# Generated at 2022-06-25 17:38:01.435700
# Unit test for function chown
def test_chown():
    _user = getpass.getuser()
    _group = grp.getgrgid(os.getgid())[0]

    # Change ownership of a file...
    path = '.fltest-chown'
    try:
        with open(path, 'w'):
            pass

        chown(path, user=_user, group=_group)

        assert os.stat(path).st_uid == os.getuid()
        assert os.stat(path).st_gid == os.getgid()

    finally:
        os.unlink(path)

    # Change ownership of a directory...
    path = '.fltest-chown'

# Generated at 2022-06-25 17:38:07.890767
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    # Create test files
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-25 17:38:27.975779
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as for paths that exist as a file
    """
    test_path = "/tmp/test_file.txt"
    test_data = "This is a test\n"
    with open(test_path, "w") as test_file:
        test_file.write(test_data)
    assert exists_as(test_path) == "file"
    assert exists_as("/tmp/test_file") == ""
    os.unlink(test_path)
    assert exists_as(test_path) == ""


# Generated at 2022-06-25 17:38:29.632811
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests.osutils.txt'
    chown(path)


# Generated at 2022-06-25 17:38:31.958216
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/**', mode_dir=0o777)
    chmod('~/tmp/flutils.tests.osutils.txt', 0o666)


# Generated at 2022-06-25 17:38:43.455044
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    parent = path.parent
    if not parent.exists():
        parent.mkdir()
    if not path.exists():
        Path('~/tmp/flutils.tests.osutils.txt').touch()
    parent_stat = Path('~/tmp/').stat()
    file_stat = Path('~/tmp/flutils.tests.osutils.txt').stat()
    chown('~/tmp/flutils.tests.osutils.txt')
    assert get_os_user(parent_stat.st_uid).pw_name == 'mark'
    assert get_os_user(file_stat.st_uid).pw_name == 'mark'

# Generated at 2022-06-25 17:38:48.858503
# Unit test for function chown
def test_chown():
    import getpass
    from pathlib import Path

    username = getpass.getuser()
    file_path = Path('/tmp/chown.test.txt')
    file_path.write_text('This is a test')
    chown(file_path, '-1', '-1')
    struct_passwd_0 = get_os_user()



# Generated at 2022-06-25 17:38:58.146404
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import normalize_path

    test_root_dir = normalize_path('./tests/tmp')
    test_file = test_root_dir + '/test_file_chmod'
    test_file_sym = test_root_dir + '/test_file_chmod_sym'
    test_sub_dir = test_root_dir + '/test_sub_dir_chmod'
    test_sub_dir_sym = test_root_dir + '/test_sub_dir_chmod_sym'

    # We don't need to cleanup this file
    test_dummy_file = normalize_path('./tests/tmp/test_file_chmod_dummy')


# Generated at 2022-06-25 17:39:00.839297
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/Users/len/tmp') == 'directory'

    # Does not exist
    assert exists_as('./does_not_exist') == ''


# Generated at 2022-06-25 17:39:04.565294
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-25 17:39:10.971712
# Unit test for function chown
def test_chown():
    #chown('~/foo/flutils.tests.osutils.txt', group='-1')
    chown('~/foo/flutils.tests.osutils.txt', group='root')
    chown('~/foo/flutils.tests.osutils.txt', group='users')
    chown('~/foo/flutils.tests.osutils.txt', group='wheel')



# Generated at 2022-06-25 17:39:15.659830
# Unit test for function chmod
def test_chmod():
    print("TESTING CHMOD")
    # Test Function 0
    print("TEST FUNCTION 0")
    chmod(path=".", mode_dir=0o755)
    print("no error")
    print("\n")
    # Test Function 1
    # Test Function 2
    # Test Function 3
    # Test Function 4


# Generated at 2022-06-25 17:39:30.049929
# Unit test for function path_absent
def test_path_absent():
    import tempfile

    path = Path(tempfile.mkdtemp())
    assert path.exists() == True
    path_absent(path)
    assert path.exists() == False

    path = Path(tempfile.mkdtemp())
    assert path.exists() == True
    subdir = path / 'subdir'
    create_dir(subdir)
    assert subdir.exists() == True
    path_absent(path)
    assert path.exists() == False



# Generated at 2022-06-25 17:39:34.685455
# Unit test for function chmod
def test_chmod():
    mode = os.stat(os.environ.get('HOME'), follow_symlinks=True).st_mode
    if mode & 0o777 != 0o770:
        chmod(os.environ.get('HOME'), mode_dir=0o770)
        assert os.stat(os.environ.get('HOME')).st_mode & 0o777 == 0o770
        chmod(os.environ.get('HOME'), mode_dir=0o700)


# Generated at 2022-06-25 17:39:38.508774
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o644)
    assert Path('~/tmp/flutils.tests.osutils.txt').stat().st_mode == 0o100644


# Generated at 2022-06-25 17:39:49.795271
# Unit test for function chmod
def test_chmod():
    os.mkdir('~/tmp/flutils.tests/osutils')
    open('~/tmp/flutils.tests/osutils/txt', 'w').close()
    def test_0():

        chmod('~/tmp/flutils.tests/osutils/*', 0o640)
        # assert struct_passwd_1.pw_uid == struct_passwd_0.pw_uid
        # assert struct_passwd_1.pw_gid == struct_passwd_0.pw_gid
    test_0()

    os.chdir('~/tmp/flutils.tests/osutils')
    def test_1():
        chmod('~/tmp/flutils.tests/osutils/*', 0o441)
        # assert struct_passwd_1.pw_uid == struct_pass

# Generated at 2022-06-25 17:39:54.653324
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    assert chmod('~/tmp/*')


# Generated at 2022-06-25 17:39:59.387364
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/tmp/') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as(Path('/tmp/flutils_test_dir')) == 'directory'
    assert exists_as(Path('/tmp/flutils_test_dir_symlink')) == ''


# Generated at 2022-06-25 17:40:04.113415
# Unit test for function chown
def test_chown():
    os.chdir(os.environ['HOME'])
    path = '~/tmp/test_file.txt'
    user = '-1'
    group = '-1'
    include_parent = False
    #chown(path, user, group, include_parent)
    assert (os.path.isfile(path) == True)


# Generated at 2022-06-25 17:40:10.128643
# Unit test for function exists_as
def test_exists_as():
    res = exists_as('/etc/')
    print(res)
    res = exists_as('/etc/hosts')
    print(res)
    #res = exists_as('/no_such_dir/')
    #print(res)




# Generated at 2022-06-25 17:40:20.516427
# Unit test for function directory_present
def test_directory_present():
    # Set of test cases to test function directory_present
    # os.environ['HOME'] = '/home/'
    test_case_0()
    path = Path('/tmp/flutils.tests.pathutils.directory_present.txt')
    parent = path.parent
    child = path
    while child.as_posix() != parent.as_posix():
        print(child.as_posix())
        child = parent
        parent = parent.parent
    print('path: %r' % path.as_posix())
    # path = normalize_path('/tmp/flutils.tests.pathutils.directory_present.txt')
    # print('path: %r' % path.as_posix())
    # test_case_0(path)
    # directory_present(path)
    # path = Path

# Generated at 2022-06-25 17:40:25.907895
# Unit test for function chmod
def test_chmod():
    # Create a temporary file in a temporary directory.
    with tempfile.TemporaryDirectory() as tmp:
        # Create a temporary file to perform
        # the chmod on.
        path = os.path.join(tmp, 'test-tmp.txt')

        # Create a temporary file.
        with open(path, 'w') as f:
            f.write('Hello World')

        # Set the permissions to 777.
        chmod(path, 0o777)

        # Get the stat information.
        s = os.stat(path)

        # Check that the mode is 777.
        assert stat.S_IMODE(s.st_mode) == 0o777



# Generated at 2022-06-25 17:40:33.846269
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()
    struct_passwd_1 = get_os_user(1500)
    struct_passwd_2 = get_os_user('root')
    pass


# Generated at 2022-06-25 17:40:40.066609
# Unit test for function chown
def test_chown():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_filepath = os.path.join(temp_dir, 'test.txt')
    with open(temp_filepath, 'w'):
        os.utime(temp_filepath, None)

    chown(temp_filepath, user='-1')
    chown(temp_filepath, group='-1')


# Generated at 2022-06-25 17:40:49.831533
# Unit test for function chmod
def test_chmod():
    from pwd import getpwnam
    from subprocess import run, PIPE, STDOUT
    from tempfile import TemporaryDirectory, NamedTemporaryFile

    uid = os.getuid()
    gid = os.getgid()
    with TemporaryDirectory() as td:
        td_abspath = normalize_path(td)
        f = NamedTemporaryFile(mode='w+b', dir=td, prefix='', suffix='.py')
        print(f.read())
        print(f.write(b'foo\n'))
        print(f.read())
        f.close()
        f_abspath = normalize_path(f.name)
        chown(f_abspath, uid, gid)
        chmod(f_abspath, 0o600)

# Generated at 2022-06-25 17:40:55.221952
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()

    struct_passwd_1 = get_os_user(getpass.getuser())
    struct_group_1 = get_os_group(grp.getgrgid(os.getgid()))

    struct_passwd_2 = get_os_user(int(struct_passwd_0.pw_uid+1))
    struct_group_2 = get_os_group(int(struct_group_0.gr_gid+1))

    # test_case0: chown_test_case_0
    os.chown(__file__, struct_passwd_0.pw_uid, struct_group_0.gr_gid)

# Generated at 2022-06-25 17:41:00.420117
# Unit test for function chown
def test_chown():
    path = normalize_path('.')
    uid = get_os_user('root').pw_uid
    gid = get_os_group('root').gr_gid
    os.chown(path.as_posix(), uid, gid)
    # Need to check the result of chown


# Generated at 2022-06-25 17:41:02.909492
# Unit test for function chown
def test_chown():
    assert chown('/home/ubuntu/git/flutils/flutils/pathutils.py') == None


# Generated at 2022-06-25 17:41:10.899632
# Unit test for function path_absent
def test_path_absent():
    """Unit test for path_absent"""
    import time

    # Clean up.
    path_absent('/tmp/test_path_absent')

    # Create the test directory.
    path = normalize_path('/tmp/test_path_absent')
    path_present(path)

    # Create a test file.
    path = path.joinpath('file')
    with path.open('w', encoding='utf-8') as fh:
        fh.write('Hello')

    # Create a symlink.
    path2 = path.parent
    path2 = path2.joinpath('file_symlink')
    path2.symlink_to(path)

    # Recursively remove everything.
    path_absent('/tmp/test_path_absent')
