

# Generated at 2022-06-25 17:31:46.759756
# Unit test for function path_absent
def test_path_absent():
    # Test path_absent
    
    # Create testing directory
    os.makedirs("/tmp/test_path_absent")
    
    # Create test file
    F = open("/tmp/test_path_absent/test_file", "w+")
    F.write("foo")
    F.close()
    
    # Create test file symbolic link
    os.symlink("/tmp/test_path_absent/test_file", "/tmp/test_path_absent/test_file_symlink")
    
    # Create test directory symbolic link
    os.symlink("/tmp/test_path_absent", "/tmp/test_path_absent_symlink")
    
    # Test deleting entire directory
    path_absent("/tmp/test_path_absent")
   

# Generated at 2022-06-25 17:31:57.465516
# Unit test for function exists_as
def test_exists_as():
    # Exists as a directory
    path = Path('~/flutils.tests.unit.pathutils/1')
    directory_present(path)
    result = exists_as(path)
    assert result == 'directory'

    # Exists as a regular file
    path = Path('~/flutils.tests.unit.pathutils/2')
    file_present(path)
    result = exists_as(path)
    assert result == 'file'

    # Exists as a block device
    path = Path('~/flutils.tests.unit.pathutils/3')
    with pytest.raises(EnvironmentError) as excinfo:
        block_device_present(path)
    assert excinfo.type == NotImplementedError

    # Exists as a char device

# Generated at 2022-06-25 17:32:06.701039
# Unit test for function exists_as
def test_exists_as():
    path1 = Path('/Users/len/tmp/test_file.txt')
    path2 = Path('/Users/len/tmp/test_dir')
    path3 = Path('/Users/len/tmp/test_nonexistant')

    assert exists_as(path1) == 'file'
    assert exists_as(path2) == 'directory'
    assert exists_as(path3) == ''

    path4 = Path('/tmp/test_file.txt')
    path5 = Path('/tmp/test_dir')
    path6 = Path('/tmp/test_nonexistant')

    assert exists_as(path4) == 'file'
    assert exists_as(path5) == 'directory'
    assert exists_as(path6) == ''


# Generated at 2022-06-25 17:32:17.981100
# Unit test for function chown
def test_chown():
    """Tests for chown"""
    def test_chown_0():
        path = normalize_path('~/tmp/flutils.tests.osutils.txt')
        user = '-1'
        group = '-1'
        include_parent = False
        chown(path=path,user=user,group=group,include_parent=include_parent)

    def test_chown_1():
        path = normalize_path('~/tmp/flutils.tests.osutils.txt')
        user = None
        group = None
        include_parent = True
        chown(path=path,user=user,group=group,include_parent=include_parent)


# Generated at 2022-06-25 17:32:26.938860
# Unit test for function find_paths
def test_find_paths():
    pattern_0 = Path('/Users/len/.gitconfig')
    pattern_1 = Path('/Users/len/Downloads/test_repo/README.md')
    pattern_2 = Path('/Users/len/Downloads/test_repo/**')
    pattern_3 = Path('/Users/len/Downloads/test_repo/')
    pattern_4 = Path('/Users/len/Downloads/test_repo/*')
    pattern_5 = Path('/Users/len/Downloads/test_repo/flutils_test.txt')
    pattern_6 = Path('/Users/len/Downloads/test_repo/NOTFOUND.md')


# Generated at 2022-06-25 17:32:31.415254
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    # supports a glob pattern
    chown('~/tmp/**')
    # to change ownership of all the directory's immediate contents
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-25 17:32:41.350829
# Unit test for function chown
def test_chown():
    os.environ['FLUTILS_TEST_PATH'] = os.path.abspath('./test_data/chown')
    os.environ['FLUTILS_TEST_PATH_1'] = os.path.abspath('./test_data/chown/f1.txt')
    os.environ['FLUTILS_TEST_PATH_2'] = os.path.abspath('./test_data/chown/f2.txt')
    os.environ['FLUTILS_TEST_USER'] = 'nobody'
    os.environ['FLUTILS_TEST_GROUP'] = 'nogroup'

# Generated at 2022-06-25 17:32:44.908138
# Unit test for function chmod
def test_chmod():
    """Test function chmod
    """
    run_test = False
    if run_test:
        from flutils.pathutils import chmod
        chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-25 17:32:52.849529
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import pytest
    from pathlib import Path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import normalize_path

    # Create a directory
    tmp_dir = Path(tempfile.gettempdir())
    test_path = tmp_dir / 'test_path'
    test_path.mkdir()

    # Test directory is created
    assert path_exists(test_path)

    # Delete directory
    path_absent(test_path)

    # Test directory doesn't exist
    assert path_exists(test_path) == False

    # Create a directory
    test_path.mkdir()

    # Put a file in the directory
    test_file = test_path / 'test_file'
    test

# Generated at 2022-06-25 17:32:58.826167
# Unit test for function chmod
def test_chmod():
    filepath = '/tmp/test.txt'
    from pathlib import Path
    p = Path(filepath)
    open(filepath, 'a').close()
    if p.exists():
        chmod(filepath, mode_file=0o644)
        os.remove(filepath)
    else:
        raise FileNotFoundError('%s not created' % (filepath))
   

# Generated at 2022-06-25 17:33:26.035051
# Unit test for function get_os_user
def test_get_os_user():

    current_user = get_os_user()
    assert current_user.pw_name == getpass.getuser()

    user_foo = get_os_user('foo')
    assert user_foo.pw_name == 'foo'

    struct_passwd_foo = get_os_user(1001)
    assert struct_passwd_foo.pw_name == 'foo'

    try:
        get_os_user('name_does_not_exist')
        assert False
    except:
        assert True

    try:
        get_os_user(12345454545)
        assert False
    except:
        assert True


# Generated at 2022-06-25 17:33:32.060545
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/test_dir')
    path.mkdir(parents=True, exist_ok=True)
    path = normalize_path(path)

    # Test for present file
    path = Path('/tmp/test_file')
    path.touch()
    path = normalize_path(path)
    path_absent(path)
    path_exists_as = exists_as(path)
    assert (path_exists_as == '')

    # Test for present directory
    path = Path('/tmp/test_dir')
    path.mkdir(parents=True, exist_ok=True)
    path = normalize_path(path)
    path_absent(path)
    path_exists_as = exists_as(path)
    assert (path_exists_as == '')

# Generated at 2022-06-25 17:33:38.834491
# Unit test for function path_absent
def test_path_absent():
    """
    Test function path_absent.
    """
    # Test 1 - create path and make sure it exists
    # Test 1.1 - setup, create path
    pass
    # Test 1.2 - assert path exists
    pass
    # Test 2 - call path_absent with create path
    # Test 2.1 - assert path no longer exists
    pass

    # Test 3 - create directory and make sure it exists
    # Test 3.1 - setup, create directory
    pass
    # Test 3.2 - assert directory exists
    pass
    # Test 4 - call path_absent with create directory
    # Test 4.1 - assert directory no longer exists
    pass



# Generated at 2022-06-25 17:33:48.691094
# Unit test for function exists_as
def test_exists_as():
    # Test that the ~/tmp directory exists as a directory.
    path = Path('~/tmp')
    assert exists_as(path) == 'directory'
    # Test that I don't have a "~/tmpf" directory or file.
    path = Path('~/tmpf')
    assert exists_as(path) == ''
    # Test that I don't have a "~/tmpf" directory or file.
    path = Path('~/tmpf/bar')
    assert exists_as(path) == ''
    # Test the ~/tmpf directory will be created as a directory.
    path = Path('~/tmpf')
    path = directory_present(path)
    # Test that the ~/tmpf directory exists as a directory.
    path = Path('~/tmpf')
    assert exists_as(path) == 'directory'


# Generated at 2022-06-25 17:33:56.409091
# Unit test for function chmod
def test_chmod():
    path = Path('test_file.out')
    with path.open('w') as fh:
        fh.write('test file')

    chmod(path, 0o666, include_parent=True)
    assert path.exists() is True
    assert path.stat().st_mode == 33188
    assert path.parent.stat().st_mode == 16877

    # Cleanup
    path.unlink()



# Generated at 2022-06-25 17:34:06.633111
# Unit test for function chown
def test_chown():
    os.makedirs('/tmp/flutils_test/one/two')
    os.makedirs('/tmp/flutils_test/three/four')
    os.makedirs('/tmp/flutils_test/three/five')
    os.makedirs('/tmp/flutils_test/three/five/six')
    with open('/tmp/flutils_test/pathutils.txt', 'w') as fobj:
        fobj.write('testing')

    chown('/tmp/flutils_test/*', 'nobody', 'nogroup', include_parent=True)
    chown('/tmp/flutils_test/*/*', 'nobody', 'nogroup', include_parent=True)

# Generated at 2022-06-25 17:34:12.795072
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    import flutils.pathutils as pathutils

    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, 'testfile')
        pathutils.chown(test_file)
        assert pathutils.exists_as(test_file, 'file')


# Generated at 2022-06-25 17:34:15.464008
# Unit test for function find_paths
def test_find_paths():
    test_glob = '*/**'
    assert list(find_paths(test_glob)) is not None, "Find Paths did not find any paths."


# Generated at 2022-06-25 17:34:22.191381
# Unit test for function chmod
def test_chmod():
    # Get the path of the file to chmod
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    # Create the file
    path.touch()
    # Check that the file has been created
    assert path.exists() == True
    # Chmod the file
    chmod(path, 0o660)
    # Check that the file has been chmodded
    assert path.permission() == 0o660


# Generated at 2022-06-25 17:34:33.047105
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    from pathlib import Path
    from flutils.pathutils import chmod

    t_dir = Path(tempfile.mkdtemp())
    f_path = t_dir / 'foo.txt'
    d_path = t_dir / 'foo'

    try:
        f_path.touch()
        d_path.mkdir()

        chmod(f_path, 0o600)
        assert f_path.stat().st_mode & 0o777 == 0o600, 'Failed chmod.'
        chmod(d_path, 0o700)
        assert d_path.stat().st_mode & 0o777 == 0o700, 'Failed chmod.'
    finally:
        shutil.rmtree(t_dir)


# Generated at 2022-06-25 17:34:43.446252
# Unit test for function find_paths
def test_find_paths():
    expected = [
        '~/tmp/file_one',
        '~/tmp/dir_one',
    ]

    result = list(find_paths('~/tmp/*'))
    result = [item.as_posix() for item in result]
    assert result == expected

# Generated at 2022-06-25 17:34:47.142431
# Unit test for function exists_as
def test_exists_as():
    _ = directory_present('tests/test_pathutils/tmp')
    assert exists_as('tests/test_pathutils/tmp') == 'directory'



# Generated at 2022-06-25 17:34:48.083542
# Unit test for function chown
def test_chown():
    assert test_case_0() == None


# Generated at 2022-06-25 17:34:50.117139
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~')
    assert 'directory' == exists_as(path)



# Generated at 2022-06-25 17:34:58.717325
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('flutils/__init__.py')) == 'file'
    assert exists_as(Path('/usr/lib')) == 'directory'
    assert exists_as(Path('/home/len/tmp/lib_test_dir')) == ''


if __name__ == '__main__':

    # Unit test for function directory_present
    test_case_0()
    directory_present(Path('/home/len/tmp/lib_test_dir'))
    test_exists_as()

    print('All Tests Passed!')

# Generated at 2022-06-25 17:35:01.297730
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') == None


# Generated at 2022-06-25 17:35:10.180680
# Unit test for function chown
def test_chown():
    import flutils
    this_func_name = sys._getframe().f_code.co_name
    # Create a temporary directory
    tmpd = flutils.pathutils.mkdtemp(prefix=f'{this_func_name}-')
    # Cleanup the temporary directory
    tmpd.cleanup()
    # Make a temporary directory again
    tmpd = flutils.pathutils.mkdtemp(prefix=f'{this_func_name}-')



# Generated at 2022-06-25 17:35:13.882079
# Unit test for function chmod
def test_chmod():
    path = Path("/tmp/flutils.tests.pathutils.test_chmod")
    chmod(path, 0o777)
    print("File/Directory at {} should have mode 0o777".format(path.as_posix()))
    assert path.stat().st_mode & 0o777 == 0o777


# Generated at 2022-06-25 17:35:26.316653
# Unit test for function path_absent
def test_path_absent():

    # Test creating a directory if it doesn't exist.
    create_dir('~/tmp/test_case_d_0/foo')

    # Test recursively removing a directory
    path_absent('~/tmp/test_case_d_0')
    assert os.path.exists('~/tmp/test_case_d_0') is False

    # Test removing a file, symlink or a non existing path.
    create_path('~/tmp/test_case_0_a.txt')
    create_symlink('~/tmp/test_case_0_b.txt', '~/tmp/test_case_0_a.txt')
    path_absent('~/tmp/test_case_0_a.txt')

# Generated at 2022-06-25 17:35:37.636941
# Unit test for function directory_present
def test_directory_present():
    from pathlib import os
    from tempfile import mkdtemp
    from shutil import rmtree
    # case 0:
    # Create a directory that does not exist.
    # chown and chmod will default to the getpwuid of the user running
    # the test.
    temp_dir = mkdtemp(prefix='flutils.pathutils_')
    print('Test Case 0:')
    test_dir = directory_present(temp_dir)
    if test_dir.exists():
        print('Test Case 0: Success')
        print(temp_dir)
    else:
        print('Test Case 0: Failed')
    # case 1:
    # Create a directory that exists
    # chown and chmod will default to the getpwuid of the user running
    # the test.

# Generated at 2022-06-25 17:35:44.475844
# Unit test for function directory_present
def test_directory_present():
    print(test_case_0())

test_directory_present()





# Generated at 2022-06-25 17:35:47.753047
# Unit test for function chown
def test_chown():
    path = "foo"
    user = "bar"
    group = "baz"
    include_parent = True
    chown(path, user, group, include_parent)


# Generated at 2022-06-25 17:35:55.469857
# Unit test for function exists_as
def test_exists_as():
    # Path does not exist
    assert(exists_as('~/tmp/does/not/exist') == '')

    # Directory exists
    directory_present('~/tmp/exists_as_test')
    assert(exists_as('~/tmp/exists_as_test') == 'directory')

    # File exists
    file_present('~/tmp/exists_as_test/file.txt')
    assert(exists_as('~/tmp/exists_as_test/file.txt') == 'file')


# Generated at 2022-06-25 17:36:05.443671
# Unit test for function chown
def test_chown():
    try:
        os.makedirs("t2")
    except FileExistsError:
        pass
    f = open("t2/t2.txt", 'w')
    f.close()
    test_case_1(getpass.getuser(), grp.getgrgid(pwd.getpwnam(getpass.getuser()).pw_gid).gr_name)
    test_case_2(getpass.getuser(), grp.getgrgid(pwd.getpwnam(getpass.getuser()).pw_gid).gr_name)
    test_case_3(getpass.getuser(), grp.getgrgid(pwd.getpwnam(getpass.getuser()).pw_gid).gr_name)

# Generated at 2022-06-25 17:36:16.957385
# Unit test for function chown
def test_chown():
    # Tests on POSIX OS
    if (sys.platform == 'linux') or (sys.platform == 'darwin'):

        # Tests file
        path = Path('/tmp')
        _ = Path(path / 'flutils.tests.osutils.txt')
        if not (path / 'flutils.tests.osutils.txt').is_file():
            (path / 'flutils.tests.osutils.txt').touch()
        chown('flutils.tests.osutils.txt', user='root', group='root')
        st = os.stat(path / 'flutils.tests.osutils.txt')
        assert st.st_uid == 0
        assert st.st_gid == 0
        (path / 'flutils.tests.osutils.txt').unlink()

# Generated at 2022-06-25 17:36:28.676643
# Unit test for function chmod
def test_chmod():
    import tempfile
    import os

    print('chmod: begin')

    dirpath = tempfile.mkdtemp()

    path = os.path.join(dirpath, 'test')
    mode = 0o660


# Generated at 2022-06-25 17:36:31.344711
# Unit test for function directory_present
def test_directory_present():
    test_dir = directory_present("test", mode=0o755, user="testuser")
    # Find children
    # Find parents
    assert(True)


# Generated at 2022-06-25 17:36:37.873209
# Unit test for function exists_as
def test_exists_as():
    path = Path('pathutils.py')
    assert exists_as(path) == 'file'

    path = Path('/dev/urandom')
    assert exists_as(path) == 'file'

    path = '/dev/urandom'
    assert exists_as(path) == 'file'



# Generated at 2022-06-25 17:36:45.034897
# Unit test for function directory_present
def test_directory_present():
    import os
    from pathlib import Path
    from flutils.pathutils import directory_present

    def _call(path):
        return directory_present(path)

    assert _call('~/this/is/a/test/path') == Path('~/this/is/a/test/path').expanduser()
    assert _call('~/this/is/a/test/path') == Path('/home/kalt/this/is/a/test/path').expanduser()

    assert _call('/tmp/this/is/a/test/path') == Path('/tmp/this/is/a/test/path')

    try:
        _call('/this/is/a/test/path')
    except ValueError:
        pass
    else:
        os.sys.exit(-1)


# Generated at 2022-06-25 17:36:57.340248
# Unit test for function chmod
def test_chmod():
    """
    Test for function chmod
    """
    _modprobe_prefix = '/tmp/flutils.tests.pathutils'

    # Test case where the path does not exist
    Path(_modprobe_prefix + '.0').unlink(missing_ok=True)
    chmod(_modprobe_prefix + '.0')
    assert not os.path.exists(_modprobe_prefix + '.0')

    # Test case where the path is a file
    Path(_modprobe_prefix + '.1').write_text('hi')
    chmod(_modprobe_prefix + '.1')
    prev_mode = os.stat(_modprobe_prefix + '.1').st_mode & 0o777
    assert prev_mode == 0o600

    # Test case where the path is a directory

# Generated at 2022-06-25 17:37:04.945815
# Unit test for function chmod
def test_chmod():
    path = normalize_path('./test_tmp')
    chmod(path)
    os.chmod(path, 0o770)


# Generated at 2022-06-25 17:37:16.115129
# Unit test for function directory_present

# Generated at 2022-06-25 17:37:26.056427
# Unit test for function path_absent
def test_path_absent():
    dir_name = 'test_dir'
    file_name = 'test_file'
    os.mkdir(dir_name)
    open(file_name, 'w').close()
    assert os.path.exists(dir_name)
    assert os.path.exists(file_name)
    path_absent(dir_name)
    path_absent(file_name)
    assert not os.path.exists(dir_name)
    assert not os.path.exists(file_name)
    os.rmdir(dir_name)
    open(file_name, 'w').close()
    assert os.path.exists(file_name)
    path_absent(file_name)
    assert not os.path.exists(file_name)

# Generated at 2022-06-25 17:37:29.505885
# Unit test for function exists_as
def test_exists_as():

    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/test.txt') == 'file'
    assert exists_as('~/tmp/test.notfound') == ''
    assert exists_as('~/tmp/test.notfound') != 'file'


# Generated at 2022-06-25 17:37:37.878806
# Unit test for function path_absent
def test_path_absent():
    path = os.path.join(os.getcwd(), test_dir_name)
    test_path = os.path.join(path, 'foo')
    create_directory(test_path)
    test_file = os.path.join(path, 'bar.txt')
    with open(test_file, 'w') as f:
        f.write('This is a test')
    path_absent(path)
    assert not os.path.exists(path)


# Generated at 2022-06-25 17:37:48.205483
# Unit test for function chmod
def test_chmod():
    test_path_0 = normalize_path('~')
    test_path_1 = normalize_path('~/tmp')
    test_path_2 = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path_3 = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path_4 = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path_5 = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path_6 = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path_7 = normalize_path('~/tmp/flutils.tests.osutils.txt')

# Generated at 2022-06-25 17:37:55.564216
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/testdir')
    path_exists_as = exists_as(path)
    assert path_exists_as == '', 'This test requires /tmp/testdir to not exist'

    path = path_exists_as
    os.makedirs(path.as_posix(), exist_ok=True)
    path_absent(path.as_posix())
    assert not os.path.exists(path), 'Deletion failed'
    assert not os.path.exists(path), 'Expected /tmp/testdir to not exist after deletion.'

    path = Path('/tmp/testfile')
    path_exists_as = exists_as(path)
    assert path_exists_as == '', 'This test requires /tmp/testfile to not exist'

    path = path

# Generated at 2022-06-25 17:37:59.817741
# Unit test for function chown
def test_chown():
    try:
        chown('/home/sadmin/dir1/dir2/dir3/file1.txt',user='sadmin',group='sadmin')
    except Exception as e:
        assert 0, "Test chown failed"


# Generated at 2022-06-25 17:38:01.201076
# Unit test for function path_absent
def test_path_absent():
    assert path_absent('C:\\Users\\test\\test_dir') == None

# Generated at 2022-06-25 17:38:03.581679
# Unit test for function chmod
def test_chmod():
    try:
        chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 17:38:10.012945
# Unit test for function directory_present
def test_directory_present():
    directory_present('/Users/len/tmp/flutils')


# Generated at 2022-06-25 17:38:18.494600
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__ + 'foo') == ''
    assert exists_as(__name__) == ''
    assert exists_as(__name__ + '.foo') == ''
    assert exists_as(__package__) == 'directory'
    assert exists_as(__package__ + '.foo') == ''
    # assert exists_as(__path__) == 'directory'
    assert exists_as('') == ''
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__ + '/foo') == ''


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:38:28.813479
# Unit test for function path_absent
def test_path_absent():
    import sys
    import os
    import argparse
    import tempfile
    import shutil
    import stat

    def cli_parser() -> argparse.Namespace:
        parser = argparse.ArgumentParser('path_absent')
        parser.add_argument(
            '-p', '--path',
            help='A path to use for testing path_absent',
            type=str,
            default=None)
        parser.add_argument(
            '-t', '--test',
            help='A unit test number to run',
            type=int,
            default=0)
        return parser.parse_args()

    parser = cli_parser()
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

# Generated at 2022-06-25 17:38:40.679194
# Unit test for function chmod
def test_chmod():
    from .osutils import set_os_user
    set_os_user('root', 'root')
    import tempfile
    tmpdir = Path(tempfile.gettempdir())
    print(tmpdir)
    tmpdir_subdir = tmpdir / 'subdir'
    tmpdir_subdir.mkdir()
    tmppath = tmpdir / 'subdir' / 'tmppath'
    tmppath.touch()
    print(tmpdir.stat().st_mode)
    print(tmpdir_subdir.stat().st_mode)
    print(tmppath.stat().st_mode)
    chmod(tmppath, 0o660, 0o770, True)
    print(tmpdir.stat().st_mode)
    print(tmpdir_subdir.stat().st_mode)
    print

# Generated at 2022-06-25 17:38:47.598180
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    # Test that a non existent path returns False
    test_path = '/tmp/this_directory_does_not_exist'
    rv = False
    assert not os.path.exists(test_path)
    path_absent(test_path)
    assert not os.path.exists(test_path)
    test_path = '/tmp/this_directory_does_not_exist/subdir'
    path_absent(test_path)
    assert not os.path.exists(test_path)
    assert rv is False

    # Test with a non directory path
    test_path = '/tmp/test_file'
    with open(test_path, 'w') as f:
        f.write('')


# Generated at 2022-06-25 17:38:50.233076
# Unit test for function exists_as
def test_exists_as():
    """Test ``exists_as``."""
    exists_as('../README.rst')
    exists_as('~/tmp/flutils.tests.osutils.txt')
    exists_as('~/tmp/flutils.tests.osutils.dummy')
    exists_as('/dev/null')


# Generated at 2022-06-25 17:38:58.935360
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import (
        is_dir_writable,
        is_file_writable,
        is_user_member_of_group,
        )
    from flutils.tests.helpers import get_or_create_temp_dir
    import os
    import pwd
    import shutil
    import stat
    import sys

    def get_stat_mode(path: str) -> int:
        return os.stat(path, follow_symlinks=False).st_mode

    # Create /tmp/flutils.tests.osutils.chmod

# Generated at 2022-06-25 17:39:11.135551
# Unit test for function path_absent
def test_path_absent():
    test_user = getpass.getuser()
    test_dir_name = 'absent_test'
    test_file_name = 'absent_test_file'
    test_dir = Path('~').expanduser() / test_user / test_dir_name
    test_file = test_dir / test_file_name

    def _path_absent_test_case_0():
        file_path = Path('~').expanduser() / test_file_name
        path_absent(file_path)
        assert file_path.exists() == False

    def _path_absent_test_case_1():
        path_absent(test_file)
        assert test_file.exists() == False


# Generated at 2022-06-25 17:39:13.997180
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()
    assert struct_passwd_0.pw_name == 'len'


# Generated at 2022-06-25 17:39:19.104412
# Unit test for function chown
def test_chown():
    user_0 = getpass.getuser()
    group_0 = grp.getgrgid(os.getgid()).gr_name
    chown('~/tmp/flutils.tests.osutils.txt', user_0, group_0)



# Generated at 2022-06-25 17:39:33.164279
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        tmpfile_path = tmpdir_path / "flutils.tests.osutils.txt"
        tmpdir_path.chmod(0o700)
        tmpfile_path.chmod(0o600)
        tmpfile_path.touch()

        chmod(tmpdir_path, mode_dir=0o440, include_parent=False)
        tmpdir_path.chmod(0o440)
        assert 0o440 == tmpdir_path.stat().st_mode & 0o777

        chmod(tmpdir_path, mode_dir=0o440, include_parent=True)
        tmpdir_path.chmod(0o440)
        assert 0o440 == tmpdir_path.stat().st_mode

# Generated at 2022-06-25 17:39:41.444019
# Unit test for function chmod
def test_chmod():
    # This function will change the mode of a path.  If the given path
    # does NOT exist, nothing will be done.

    # This function will **NOT** change the mode of:

    #  - symlinks (symlink targets that are files or directories will be
    #    changed)
    #  - sockets
    #  - fifo
    #  - block devices
    #  - char devices

    # path: The path of the file or directory to have it's mode changed.
    pass



# Generated at 2022-06-25 17:39:44.776429
# Unit test for function chown
def test_chown():
    """Unit test for function chown
    """
    import flutils.pathutils as pt
    import templates.pathutils_tests as pt_tests

    pt_tests.test_chown(pt.chown)



# Generated at 2022-06-25 17:39:50.539779
# Unit test for function chown
def test_chown():
    struct_group_0 = get_os_group(grp.getgrgid(os.getgid()).gr_name)
    struct_passwd_0 = get_os_user()
    chown(
        '~/tmp/flutils.tests.osutils.txt',
        struct_passwd_0.pw_name,
        struct_group_0.gr_name,
    )


# Generated at 2022-06-25 17:39:59.822147
# Unit test for function exists_as
def test_exists_as():
    # is_dir()
    assert exists_as(Path(__file__).parent) == 'directory'

    # is_file()
    assert exists_as(Path(__file__)) == 'file'

    # is_block_device()
    assert exists_as(Path('/dev/urandom')) == 'block device'

    # is_char_device()
    assert exists_as(Path('/dev/null')) == 'char device'

    # is_fifo()
    if (exists_as(Path('/dev/fd')) == 'directory'):
        assert exists_as(Path('/dev/fd/0')) == 'FIFO'

    # is_socket()

# Generated at 2022-06-25 17:40:03.504036
# Unit test for function chmod
def test_chmod():
    try:
        chmod('h1.py', 0o755)
        assert True
    except AssertionError as e:
        print(e)
        return False
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-25 17:40:16.695449
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    fake_path = '/tmp/fake_path'
    fake_path_1 = '/tmp/fake_path_1'

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir.joinpath('test_file.txt')
        tmpfile.write_text(dedent('''
            This is a test file that is used
            in unit tests.
        '''))

        # ----------------------------------------------------
        # Skip this exception.
        try:
            chmod(fake_path)
            assert False, 'Failed to raise exception.'
        except FileNotFoundError:
            pass

        # ----------------------------------------------------
        # This should fail because the content of tmpfile
        # matches that of

# Generated at 2022-06-25 17:40:24.310925
# Unit test for function chmod
def test_chmod():
    # change the mode of a file to 0o660
    mode_file = 0o664
    file_to_change = Path('./TestFile.txt')
    chmod(file_to_change, mode_file=mode_file)
    assert file_to_change.stat().st_mode & 0o777 == mode_file
    # change the mode of a directory to 0o770
    mode_dir = 0o770
    dir_to_change = Path('./TestDir')
    chmod(dir_to_change, mode_dir=mode_dir)
    assert dir_to_change.stat().st_mode & 0o777 == mode_dir
    # check for a failure in case the supplied file is not present
    no_file = Path('NotPresentFile.txt')

# Generated at 2022-06-25 17:40:27.665774
# Unit test for function directory_present
def test_directory_present():
    # directory_present('~/tmp/test_path')
    test_path = directory_present('~/tmp/test_path')
    assert test_path == '/Users/len/tmp/test_path'


# Generated at 2022-06-25 17:40:39.905105
# Unit test for function directory_present
def test_directory_present():
    directory_present(
        path='~/test1',
        mode=0o700,
        user=getpass.getuser(),
        group=get_os_group().gr_name
    )
    directory_present(
        path='~/test1/test2',
        mode=0o700,
        user=getpass.getuser(),
        group=get_os_group().gr_name
    )
    directory_present(
        path='~/test1/test2/test3',
        mode=0o700,
        user=getpass.getuser(),
        group=get_os_group().gr_name
    )
    # Testing for redundant call.

# Generated at 2022-06-25 17:40:49.955923
# Unit test for function exists_as
def test_exists_as():
    assert(exists_as('/etc/') == 'directory')
    assert(exists_as('/etc/passwd') == 'file')

# Unit tests for function normalize_path()

# Generated at 2022-06-25 17:40:55.965651
# Unit test for function chmod
def test_chmod():
    # First, make sure the test directory is present
    directory_present('~/tmp/flutils-tests')
    # Create a test file
    Path('~/tmp/flutils-tests/chmod.txt').touch()
    chmod('~/tmp/flutils-tests/chmod.txt', 0o666)
    assert Path('~/tmp/flutils-tests/chmod.txt').stat().st_mode & 0o777 == 0o666


# Generated at 2022-06-25 17:40:57.158247
# Unit test for function chmod
def test_chmod():
    test_case_0()
    if 1:
        pass



# Generated at 2022-06-25 17:40:58.120170
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd = get_os_user()


# Generated at 2022-06-25 17:41:10.826151
# Unit test for function chmod
def test_chmod():
    """Test for chmod()
    """

    # Find out who the current user is since these tests require
    # the that user to have the ability to chown files.
    m_os_user = get_os_user()
    if m_os_user.get('name') != 'root':
        m_uid = m_os_user.get('uid')
        m_gid = m_os_user.get('gid')
    else:
        m_uid = getpass.getuser()
        m_gid = grp.getgrnam(m_uid).gr_gid
    m_os_group = get_os_group(gid=m_gid)

    # Find base dir
    m_s_base = os.environ.get('TEST_BASE_DIR', '/tmp')
    #