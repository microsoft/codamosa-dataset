

# Generated at 2022-06-25 17:31:44.349916
# Unit test for function chown
def test_chown():
    home = Path.home()
    user = getpass.getuser()
    group = get_os_group().gr_gid
    print(home)
    print(user)
    print(group)
    path = normalize_path('/home/jim/git/x_data/test.txt')
    user = get_os_user().pw_uid
    group = get_os_group().gr_gid
    print(user)
    print(group)
    print(path.name)
    print(path)
    print(path.stat().st_uid)
    print(path.stat().st_gid)
    chown(path, user, group)
    print(path.stat().st_uid)
    print(path.stat().st_gid)
    print("Done")



# Generated at 2022-06-25 17:31:55.926082
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp')
    struct_stat = os.stat(path.as_posix())
    if struct_stat.st_uid != 1000:
        raise ValueError('This unit test needs to be run as a regular user.')
    if struct_stat.st_gid != 1000:
        raise ValueError('This unit test needs to be run as a regular user.')
    if struct_stat.st_mode != 0o40700:
        raise ValueError('The mode of ~/tmp after being created should be 2705 but was %o.' % struct_stat.st_mode)

exists_as_str_0 = exists_as('/Users/len/tmp/flutils/tests/osutils.txt')


# Generated at 2022-06-25 17:31:57.483271
# Unit test for function chmod
def test_chmod():
    # Function is called with a single string parameter
    chmod('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:32:03.400218
# Unit test for function find_paths
def test_find_paths():
    from flutils.testutils import TestCase
    class Test_find_paths(TestCase):
        def test_case_0(self):
            values = tuple(
                path.as_posix()
                for path in find_paths('~/tmp/*')
            )
            self.assertEqual(values, ('/tmp/file_one', '/tmp/dir_one'))

    Test_find_paths().run(verbose=True)

# Generated at 2022-06-25 17:32:10.480588
# Unit test for function chown
def test_chown():
    if sys.platform == "linux":
        mode_file = 0o600
        mode_dir = 0o700
        file_path = "tmp/new_file.txt"
        dir_path = "tmp/new_dir"


# Generated at 2022-06-25 17:32:21.853528
# Unit test for function find_paths
def test_find_paths():
    
    def test_case_0():
        # find_paths('~/tmp/flutils.tests.osutils.txt')
        assert '~/tmp/flutils.tests.osutils.txt' in find_paths('~/tmp/flutils.tests.osutils.txt')
    
    def test_case_1():
        # The can't find the specific path we are looking for
        assert '~/tmp/flutils.tests.osutils.txt' not in find_paths('~/tmp/flutils.tests.osutils1.txt')

    def test_case_2():
        # The can't find the specific path we are looking for
        assert '~/tmp/flutils.tests.osutils.txt' not in find_paths('~/tmp/flutils.tests.osutils.txt1')


# Generated at 2022-06-25 17:32:23.444686
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.path.expanduser("~")) == 'directory'

# Generated at 2022-06-25 17:32:25.856880
# Unit test for function find_paths
def test_find_paths():
    files_dir = find_paths('~/tmp/*')
    assert isinstance(files_dir, Generator)
    assert all(isinstance(x, Path) for x in files_dir)


# Generated at 2022-06-25 17:32:26.937226
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(test_dir) == 'directory'



# Generated at 2022-06-25 17:32:31.436165
# Unit test for function directory_present
def test_directory_present():

    def test_case_0():
        """

            Parameters:
                path
            Expected Results:
                dir_path
        """

        dir_path = directory_present('/tmp/test')

        assert dir_path.as_posix() == '/tmp/test'

    def test_case_1():
        """

            Parameters:
                path, mode, user, group
            Expected Results:
                dir_path
        """

        dir_path = directory_present('~/tmp/test', 0o660, 'foo', 'bar')
        assert dir_path


# Generated at 2022-06-25 17:32:43.707527
# Unit test for function chown
def test_chown():
    chown('text.txt')


# Generated at 2022-06-25 17:32:47.466124
# Unit test for function directory_present
def test_directory_present():
    p = directory_present('/tmp/test_directory')
    assert p.as_posix() == '/tmp/test_directory'
    p = directory_present('/tmp/test_directory2', mode=0o777)
    assert p.as_posix() == '/tmp/test_directory2'





# Generated at 2022-06-25 17:32:52.904494
# Unit test for function directory_present
def test_directory_present():
    # Test case 1:
    directory_present('~/tmp/test_path')
    # Test case 2:
    directory_present('~/tmp/test_path', group='bar')


# Generated at 2022-06-25 17:32:58.525850
# Unit test for function exists_as
def test_exists_as():
    import pytest

    with pytest.raises(TypeError):
        exists_as(None)
    with pytest.raises(ValueError):
        exists_as('')
    with pytest.raises(FileNotFoundError):
        exists_as('/a/path/that/doesnt/exist')
    assert exists_as('/') == 'directory'


# Generated at 2022-06-25 17:33:00.077162
# Unit test for function chown
def test_chown():
    path = '/tmp/flutils.tests.osutils.txt'
    chown(path)


# Generated at 2022-06-25 17:33:07.353140
# Unit test for function exists_as
def test_exists_as():
    directory_file_map = {
        'testpath/dir/dir2': 'dir',
        'testpath/dir/dir2/dir3': 'dir',
        'testpath/dir/dir2/file1': 'file',
        'testpath/dir/file2': 'file',
        'testpath/dir/file3': 'file',
        'testpath/dir3': 'dir',
        'testpath/file1': 'file',
        'testpath/file2': 'file',
        'testpath/file3': 'file',
        'testpath/socket1': 'socket',
        'testpath/socket2': 'socket',
        'testpath/socket3': 'socket',
    }
    # Create test directory structure

# Generated at 2022-06-25 17:33:16.030557
# Unit test for function directory_present
def test_directory_present():
    from pathlib import WindowsPath, PosixPath
    import sys
    import os
    import platform
    isWindows = platform.system() == 'Windows'
    if isWindows:
        path = 'C:\\tmp\helloThere'
        directory_present(path)
        assert os.path.isdir(path)
        os.rmdir(path)
        assert os.path.isdir(path) is False
    else:
        path = '/tmp/helloThere'
        directory_present(path)
        assert os.path.isdir(path)
        os.rmdir(path)
        assert os.path.isdir(path) is False



# Generated at 2022-06-25 17:33:19.740097
# Unit test for function chown
def test_chown():
    try:
        path = '~/tmp/flutils.tests.osutils.txt'
        os.system('touch ' + path)
        chown(path)
        assert(True)
    except:
        print('test_chown failed')
        assert(False)
    finally:
        os.system('rm -f ' + path)


# Generated at 2022-06-25 17:33:28.823585
# Unit test for function chown
def test_chown():
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'flutils.test.test_case_0'
        path.touch()
        assert path.exists() is True
        uid = os.getuid()
        gid = os.getgid()
        user = getpass.getuser()
        group = grp.getgrgid(gid).gr_name
        path_user = pwd.getpwuid(path.stat().st_uid).pw_name
        path_group = grp.getgrgid(path.stat().st_gid).gr_name
        assert path_user == user
        assert path_group == group
        # Test to chown a file
        chown(path)
        assert path.stat().st_uid == uid

# Generated at 2022-06-25 17:33:30.398451
# Unit test for function directory_present
def test_directory_present():
    directory_present('/home/keshavsetty/Desktop/flutils/flutils/tests/flutils/tests/test_pathutils')


# Generated at 2022-06-25 17:33:48.070389
# Unit test for function path_absent
def test_path_absent():
    # Test to make sure this does not blow up.
    path_absent('/tmp/this/path/does/not/exist')

    # Test to make sure this does not blow up.
    path_absent('/tmp/')

    # Test to make sure this does not blow up.
    path_absent('.')

    # Test to make sure this does not blow up.
    path_absent('~/tmp')

    # Test to make sure this does not blow up.
    path_absent('~/tmp/')

    # Test to make sure this does not blow up.
    path_absent('/tmp/this/path/does/not/exist/tmp.txt')

    # Test to make sure this does not blow up.
    path_absent('/tmp/tmp.txt')

    # Test to make sure this

# Generated at 2022-06-25 17:33:50.711814
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        with open(tmp_dir / 'file_one', 'w') as f:
            f.write('\n')
        (tmp_dir / 'dir_one').mkdir()

        res = list(find_paths(tmp_dir))
        assert res == [tmp_dir / 'file_one', tmp_dir / 'dir_one']



# Generated at 2022-06-25 17:34:02.588769
# Unit test for function find_paths
def test_find_paths():
    # Create a list of relative path objects
    find_paths_my_list = [
        Path('.'),
        Path('./file_one'),
        Path('./file_two'),
        Path('./dir_one'),
        Path('./dir_one/file_three')
        ]
    # Create a list of absolute path objects
    find_paths_my_absolute_list = []
    # Convert the relative paths to absolute paths
    for i in find_paths_my_list:
        find_paths_my_absolute_list.append(i.absolute())

    # Run find_paths on the absolute paths and
    # convert the results to a list
    find_paths_list = list(find_paths('./'))

    # Check that the number of elements in each list is the same


# Generated at 2022-06-25 17:34:04.091494
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/file_0', 644)



# Generated at 2022-06-25 17:34:12.815615
# Unit test for function directory_present
def test_directory_present():
    # Test 1
    # Test with absolute path
    path_1 = '/Users/len/tmp'
    directory_present(path_1)

    # Test 2
    # Test with relative path
    path_2 = '../..'
    directory_present(path_2)

    # Test 3
    # Test with path containing Unicode characters
    path_3 = '/Users/len/tmp/test_path'
    directory_present(path_3)
    #result_3 = directory_present(path_3)
    #assert result_3 == '/Users/len/tmp/test_path', 'Test directory_present, absolute path with Unicode characters'

    # Test 4
    # Test with existing path as a file
    path_4 = '/Users/len/tmp/test.txt'
    #directory_present(path_4)

# Generated at 2022-06-25 17:34:21.182590
# Unit test for function chmod
def test_chmod():
    __fname__ = sys._getframe().f_code.co_name
    curr_path = os.path.abspath(os.path.dirname(__file__))
    tmp_path = os.path.join(curr_path, "tmp")
    try:
        os.mkdir(tmp_path)
    except OSError:
        pass
    fname = os.path.join(tmp_path, __fname__ + ".txt")

# Generated at 2022-06-25 17:34:32.311528
# Unit test for function find_paths
def test_find_paths():

    case_passed = False
    # Create a test directory and files to find.

# Generated at 2022-06-25 17:34:40.710841
# Unit test for function chmod
def test_chmod():
    path_0 = Path('./tmp')
    mode_file_0 = 0o660
    mode_dir_0 = 0o770
    mode_dir_1 = 0o600
    test_chmod_0 = chmod(path_0, mode_file_0, mode_dir_0)
    assert test_chmod_0 == None
    try:
        chmod(path_0, 0o600, mode_dir_1)
    except PermissionError:
        pass


# Generated at 2022-06-25 17:34:55.055383
# Unit test for function find_paths
def test_find_paths():
    # First, create a file and a directory that have the same
    # base name.
    def create_test_paths():
        file_path = Path(tempfile.mktemp(suffix='.test', prefix='test_')).resolve()
        dir_path = Path(tempfile.mktemp('.test', 'test_')).resolve()
        print('file_path: ', file_path.as_posix())
        print('dir_path: ', dir_path.as_posix())
        return file_path, dir_path

    file_path, dir_path = create_test_paths()

    # Create the file.
    with open(file_path.as_posix(), 'w') as _file:
        _file.write('This is a simple test.')

    # Create the directory.
    dir

# Generated at 2022-06-25 17:35:02.246111
# Unit test for function chmod
def test_chmod():
    with open('flutils.tests.osutils.txt', 'w') as file_object:
        file_object.write('Hello world')

    chmod('flutils.tests.osutils.txt', 0o660)
    assert os.stat('flutils.tests.osutils.txt').st_mode & 0o777 == 0o660



# Generated at 2022-06-25 17:35:10.259403
# Unit test for function directory_present
def test_directory_present():
    dir_path = directory_present('~/tmp/test_dir_present')
    assert dir_path == PosixPath('/Users/len/tmp/test_dir_present')


# Generated at 2022-06-25 17:35:16.776202
# Unit test for function chown
def test_chown():
    """Test chown()."""
    path = '~flutils/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    group = get_os_group()
    user = get_os_user()
    chown(path, '', group.gr_name)
    pw = pwd.getpwuid(os.stat(path.as_posix()).st_uid)
    assert pw.pw_name == user.pw_name
    grp = grp.getgrgid(os.stat(path.as_posix()).st_gid)
    assert grp.gr_name == group.gr_name



# Generated at 2022-06-25 17:35:28.796397
# Unit test for function chmod
def test_chmod():

    mode_dir = 0o700
    mode_file = 0o600
    path = '~/tmp/flutils.tests.pathutils.txt'
    chmod(path, mode_file=mode_file, mode_dir=mode_dir, include_parent=False)
    path = normalize_path(path)
    #assert path.exists() is False
    assert path.stat().st_mode == mode_file
    assert path.parent.stat().st_mode != mode_dir
    chmod(path, include_parent=True)
    assert path.parent.stat().st_mode == mode_dir

    # Test if a directory is made with mode_file
    # But it should be mode_dir
    # FIXME: This test is not working

# Generated at 2022-06-25 17:35:31.092722
# Unit test for function exists_as
def test_exists_as():
    exists_as_path = Path('/etc/group')
    assert exists_as(exists_as_path) == 'file'


# Generated at 2022-06-25 17:35:33.756844
# Unit test for function chown
def test_chown():
    chown('./test.txt', 'bob', 'bobsgroup')
    assert get_os_group().gr_gid == 1000


# Generated at 2022-06-25 17:35:35.275762
# Unit test for function path_absent
def test_path_absent():
    path_absent('~/tmp/test_path')

# EOF

# Generated at 2022-06-25 17:35:36.450635
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-25 17:35:39.467289
# Unit test for function chown
def test_chown():
    # Assert that chown does not raise an exception when called multiple
    # times w/ the same arguments.
    for i in range(4):
        chown('~/flutils_test_chown.txt', '-1', '-1')



# Generated at 2022-06-25 17:35:40.457879
# Unit test for function get_os_group
def test_get_os_group():
    print('test_get_os_group:')
    # test_case_0
    test_case_0()


# Generated at 2022-06-25 17:35:43.933089
# Unit test for function chmod
def test_chmod():
    chmod(
        './test_chmod.txt',
        mode_file=0o600,
        mode_dir=0o700,
        include_parent=False,
    )


# Generated at 2022-06-25 17:35:51.199114
# Unit test for function get_os_group
def test_get_os_group():
    struct_group_0 = get_os_group()
    assert isinstance(struct_group_0, grp.struct_group)
    assert struct_group_0.gr_name == 'foo'
    assert struct_group_0.gr_gid == 2000
    struct_group_1 = get_os_group('bar')
    assert isinstance(struct_group_1, grp.struct_group)
    assert struct_group_1.gr_name == 'bar'
    assert struct_group_1.gr_gid == 2001



# Generated at 2022-06-25 17:36:02.367441
# Unit test for function chmod
def test_chmod():
    import argparse
    import sys

    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('mode_file', type=int, nargs='?', default=0o660)
    parser.add_argument('mode_dir', type=int, nargs='?', default=0o770)
    parser.add_argument('include_parent', type=bool, nargs='?', default=False)
    parser.add_argument('path', type=str, nargs=1)
    args = parser.parse_args()

    # print(args)

    chmod(
        path = args.path[0],
        mode_file = args.mode_file,
        mode_dir = args.mode_dir,
        include_parent = args.include_parent,
    )


# Generated at 2022-06-25 17:36:14.783748
# Unit test for function chown
def test_chown():

    try:
        # Normal
        chown('flutils.tests.osutils.txt', include_parent=True)
    except Exception as err:
        # Cause an error
        raise type(err)(
            f'Failed to test \"chown\" '
            f'with normal arguments. Error: {err!r}'
        ) from None

    try:
        # Cause an error
        chown(chown)
    except TypeError as err:
        # Check we got the error we expect
        assert str(err) == '\"path\" must be a string or bytes'
    else:
        raise AssertionError(
            'Failed to cause a type error.'
        )


# Generated at 2022-06-25 17:36:18.881148
# Unit test for function find_paths
def test_find_paths():
    """Test case for :func:`~flutils.pathutils.find_paths`."""
    # Test Path.as_posix() = '/home/test_user/tmp/dir_one'
    # Test Path.as_posix() = '~/tmp/dir_one'
    # Test Path.as_posix() = 'file_one', 'dir_one'
    # Test Path.as_posix() = 'file_one'
    # Test Path.as_posix() = 'file_one.txt'
    # Test Path.as_posix() = '~/tmp/*'
    # Test Path.as_posix() = '~/tmp/file_one'
    # Test Path.as_posix() = '~/tmp/file_one.txt'
    # Test Path.as_posix

# Generated at 2022-06-25 17:36:26.549503
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/') == 'directory'
    assert exists_as('/etc/some_file') == 'file'
    assert exists_as('/some_file') == ''
    assert exists_as('/dev/zero') == 'character device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'

# Generated at 2022-06-25 17:36:38.566043
# Unit test for function chown
def test_chown():
    from pathlib import Path
    import tempfile
    temp_dir = Path(tempfile.mkdtemp())

    try:
        test_path = temp_dir / 'test_file.txt'
        test_path.touch()

        test_path.chmod(0o777)
        test_path.chown()

        assert test_path.stat().st_mode == 0o100777
        assert test_path.stat().st_uid == getpass.getpwuid(os.getuid())[2]
        assert test_path.stat().st_gid == grp.getgrgid(os.getuid())[2]

    finally:
        # Cleanup the fake dir
        if temp_dir.exists():
            os.chmod(temp_dir.as_posix(), 0o777)
            temp_

# Generated at 2022-06-25 17:36:51.779907
# Unit test for function directory_present
def test_directory_present():
    # Unit test for directory_present
    import os
    import pathlib
    from flutils.pathutils import mkdirs
    from flutils.pathutils import path_exists

    # Create a temp directory for the test
    var = mkdirs('/tmp/flutils.pathutils.tests/')

    # Run the test on a path that does NOT exist
    # All the defaults used
    test_path = directory_present('/tmp/flutils.pathutils.tests/foo/bar')
    # Convert the path to a string
    test_path = str(test_path)

    # Check if path exists
    assert test_path == '/tmp/flutils.pathutils.tests/foo/bar'
    assert path_exists(test_path) is True

    # Clean up

# Generated at 2022-06-25 17:36:58.979829
# Unit test for function chown
def test_chown():
    # Test 1:
    # def chown(
    #         path: _PATH,
    #         user: Optional[str] = None,
    #         group: Optional[str] = None,
    #         include_parent: bool = False
    # ) -> None:
    path = ''
    user = ''
    group = ''
    include_parent = False
    chown(
        path,
        user,
        group,
        include_parent
    )



# Generated at 2022-06-25 17:37:06.010829
# Unit test for function directory_present
def test_directory_present():
    test_path = Path().cwd()/'tmp'
    assert directory_present(test_path) == test_path
    assert directory_present(test_path) == directory_present(str(test_path))
    assert directory_present(str(test_path)) == directory_present(bytes(test_path))
    test_file = test_path/'test_file.txt'
    test_file.touch()
    struct_group_0 = get_os_group()
    struct_group_1 = grp.getgrnam(struct_group_0.gr_name)
    struct_user_0 = get_os_user()
    struct_user_1 = pwd.getpwnam(struct_user_0.pw_name)
    directory_present(test_path,mode=0o755)

# Generated at 2022-06-25 17:37:16.568452
# Unit test for function path_absent
def test_path_absent():
    path_absent('./tmp')
    path_absent('./tmp_0/')
    path_absent('./tmp_0/tmp_1')
    path_absent('./tmp_0/tmp_1/')
    path_absent('./tmp_0/tmp_1/tmp_2')
    path_absent('./tmp_0/tmp_1/tmp_2/')
    path_absent('./tmp_0/tmp_1/tmp_2/tmp_3')
    path_absent('./tmp_0/tmp_1/tmp_2/tmp_3/')
    path_absent('./tmp_0/tmp_1/tmp_2/tmp_3/tmp_4')



# Generated at 2022-06-25 17:37:27.981401
# Unit test for function chmod
def test_chmod():
    for i in range(10):
        try:
            chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
        except FileNotFoundError:
            pass
        except NotADirectoryError:
            pass
        except OSError:
            pass
    chmod('/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('/tmp/*')
    chmod('/root/**', mode_file=0o644, mode_dir=0o770)
    chmod('/root/*')


# Generated at 2022-06-25 17:37:32.066905
# Unit test for function get_os_group
def test_get_os_group():
    struct_group_0 = get_os_group()
    struct_group_1 = get_os_group(name=None)
    struct_group_2 = get_os_group(name=struct_group_0.gr_gid)
    struct_group_3 = get_os_group(name=struct_group_0.gr_name)
    assert struct_group_0 == struct_group_1
    assert struct_group_0 == struct_group_2
    assert struct_group_0 == struct_group_3
    assert struct_group_1 == struct_group_2
    assert struct_group_1 == struct_group_3
    assert struct_group_2 == struct_group_3

# Generated at 2022-06-25 17:37:33.180275
# Unit test for function directory_present
def test_directory_present():
    pass


# Generated at 2022-06-25 17:37:38.366000
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir(parents=True, mode=0o700)
        tmp_path_0 = tmp_dir / 'test_0'
        tmp_path_0.touch()
        path_absent(tmp_path_0)
        assert exists_as(tmp_path_0) == ''
        tmp_path_0 = tmp_dir / 'test_0'
        tmp_path_0.mkdir()
        path_absent(tmp_path_0)
        assert exists_as(tmp_path_0) == ''
        tmp_path_0 = tmp_dir / 'test_0'
        tmp_path_1 = tmp_dir / 'test_0' / 'test_1'
        tmp

# Generated at 2022-06-25 17:37:38.967623
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-25 17:37:40.711506
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one')]

# Generated at 2022-06-25 17:37:44.244126
# Unit test for function exists_as
def test_exists_as():
    path = Path.home()

    assert exists_as(path) == 'directory'
    assert exists_as(path / 'foobar') == ''
    assert exists_as(Path(__file__)) == 'file'


# Generated at 2022-06-25 17:37:49.223895
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    
    # Path().glob() returns an iterator that will
    # raise NotImplementedError if there
    # are no results from the glob pattern.
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)


# Generated at 2022-06-25 17:37:50.264874
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-25 17:37:56.502294
# Unit test for function chmod
def test_chmod():
    struct_group = get_os_group()
    print(type(struct_group))
    print('struct_group =', struct_group)
    print('struct_group[\'group_passwd\'] =', struct_group['group_passwd'])
    print('struct_group[\'group_passwd\'] =', struct_group['group_passwd'].decode())
    print('struct_group[\'group_id\'] =', struct_group['group_id'])
    print('struct_group[\'group_name\'] =', struct_group['group_name'])
    print('struct_group[\'group_name\'] =', struct_group['group_name'].decode())
    print('type(struct_group[\'group_members\']) =', type(struct_group['group_members']))


# Generated at 2022-06-25 17:38:09.296382
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = pwd.getpwnam(user).pw_gid
    chown('/tmp', user, group)
    pass


# Generated at 2022-06-25 17:38:18.787367
# Unit test for function chmod
def test_chmod():
    '''
    The function chmod should change permissions of files.
    '''
    import shutil
    import os
    import errno
    import time
    import stat

    fname_0 = 'test_chmod_0.txt'
    fname_1 = 'test_chmod_1.txt'
    fname_2 = 'test_chmod_2.txt'
    fname_3 = 'test_chmod_3.txt'
    fname_4 = 'test_chmod_4.txt'
    fname_5 = 'test_chmod_5.txt'
    fname_6 = 'test_chmod_6.txt'
    fname_7 = 'test_chmod_7.txt'
    fname_8 = 'test_chmod_8.txt'
    fname_

# Generated at 2022-06-25 17:38:20.959261
# Unit test for function directory_present
def test_directory_present():
    directory_present('/var/lib/docker')


# Generated at 2022-06-25 17:38:29.569959
# Unit test for function chmod
def test_chmod():
    # Test that chmod works with a normal path
    print('Test 1/6 - Testing chmod with normal path')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660, True)
    # Test that chmod works with a glob pattern
    print('Test 2/6 - Testing chmod with glob pattern')
    chmod('~/tmp/**', 0o660, 0o770, True)
    chmod('~/tmp/**', 0o660, 0o770, True)
    # Test that chmod works for the immediate children of a directory
    print('Test 3/6 - Testing chmod for the immediate contents of the directory')
    chmod('~/tmp/*')
    # Test that chmod works for a path that doesn't exist

# Generated at 2022-06-25 17:38:40.946343
# Unit test for function chmod
def test_chmod():
    test_dir = '~/tmp/flutils.tests.osutils'
    test_dir = normalize_path(test_dir)
    mode_file = 0o660
    mode_dir = 0o770
    chmod(test_dir, mode_file, mode_dir)
    path = test_dir.joinpath('test_file.txt')
    path.touch()
    chmod(path, mode_file=0o600)
    assert path.stat().st_mode & 0o777 == 0o660
    chmod(test_dir, mode_dir=0o700)
    assert test_dir.stat().st_mode & 0o777 == 0o770
    chmod(path, mode_dir=0o700)
    assert path.stat().st_mode & 0o777 == 0o660



# Generated at 2022-06-25 17:38:52.500367
# Unit test for function chown
def test_chown():
    import unittest
    import tempfile
    class TestCase_0(unittest.TestCase):
        def test_0(self):
            struct_group_0 = get_os_group()
            struct_passwd_0 = get_os_user()
            path_0 = Path(tempfile.mkdtemp(dir='/tmp'))
            path_0.mkdir()
            chown(path_0,
                  user=struct_passwd_0.pw_name,
                  group=struct_group_0.gr_name,
                  include_parent=False)
            chown(path_0,
                  user=struct_passwd_0.pw_name,
                  group=struct_group_0.gr_name,
                  include_parent=True)
            path_0.rmdir()
           

# Generated at 2022-06-25 17:38:53.479827
# Unit test for function chmod
def test_chmod():
    test_case_0()


# Generated at 2022-06-25 17:39:01.270927
# Unit test for function chmod
def test_chmod():
    # Test normal operation
    # Test normal operation
    # Test normal operation
    # Test normal operation

    # Test normal operation
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    # Test normal operation
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    # Test normal operation
    chmod('~/tmp/*')

    # Test normal operation
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Test normal operation
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # Test normal operation
    chmod('~/tmp/*')

    # Test normal operation

# Generated at 2022-06-25 17:39:13.661227
# Unit test for function chown
def test_chown():
    import flutils.pathutils as pathutils

    # Create a temporary directory
    path = pathutils.directory_present('~/tmp/flutils.tests.osutils',
                                       mode_dir=0o700)
    user_1 = getpass.getuser()
    group_1 = getpass.getuser()

    # Create sample file
    path_1 = Path(path).joinpath('flutils.tests.osutils.txt')
    path_1.touch(mode=0o600)

    # Create sample directory
    path_2 = Path(path).joinpath('flutils.tests.osutils.d')
    path_2.mkdir(mode=0o700)

    # Create sample empty file

# Generated at 2022-06-25 17:39:19.799590
# Unit test for function chown
def test_chown():
    # Test function determines pathlib.Path.exists
    # first, then returns if false
    # Thus we check return values against expected
    # return values
    # We'll start with a dummy file
    path = Path('dummy')
    with path.open('w') as f:
        f.write('sample dummy file,' +
                ' to be used for testing chown')

    # os.chown can be used for testing because
    # it modifies the file's group ownership
    # by default it is the user's group
    # So we need the user's group for comparison
    pwd_0 = pwd.getpwuid(os.getuid())
    group_name_0 = pwd_0.pw_name # expected group
    group_0 = grp.getgrnam(group_name_0)
    dummy_

# Generated at 2022-06-25 17:39:29.209021
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o660
    chmod(path, mode_file)


# Generated at 2022-06-25 17:39:30.078192
# Unit test for function chmod
def test_chmod():
    assert(1 == 1)


# Generated at 2022-06-25 17:39:31.771594
# Unit test for function chown
def test_chown():
    path = './a/chown/path.txt'
    chown(path, 'root', 'root')
    pass


# Generated at 2022-06-25 17:39:36.380182
# Unit test for function chown
def test_chown():
    chown('/tmp/file', 'root', 'root')
    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name
    chown('/tmp/file', user, group)
    chown('/tmp/file', '-1', '-1')



# Generated at 2022-06-25 17:39:48.234011
# Unit test for function directory_present
def test_directory_present():
    # Test data in case 0
    path_0 = Path('/tmp/flutils.pathutils.test_directory_present.0')
    mode_0 = 0o755
    user_0 = 'tmpuser'
    group_0 = 'tmpgroup'
    try:
        os.chmod(path_0, mode_0)
    except:
        pass
    try:
        os.chown(path_0, get_pwnam(user_0).pw_uid, get_grnam(group_0).gr_gid)
    except:
        pass
    try:
        os.mkdir(path_0)
    except:
        pass
    # Call function
    path = directory_present(path_0, mode=mode_0, user=user_0, group=group_0)
    # Check

# Generated at 2022-06-25 17:39:53.742061
# Unit test for function chmod
def test_chmod():
    path_0 = './tools/tmp/flutils.tests.osutils.txt'
    path_1 = './tools/tmp/**'
    path_2 = './tools/tmp/*'
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')


# Generated at 2022-06-25 17:40:01.870985
# Unit test for function directory_present
def test_directory_present():
    # Test normalize_path path is a string with a glob pattern
    path = directory_present('/tmp/test_directory_present.***')
    assert path.as_posix() == '/tmp/test_directory_present.__'
    assert path.is_dir() is True
    path = directory_present('/tmp/test_directory_present.__')
    assert path.as_posix() == '/tmp/test_directory_present.__'
    assert path.is_dir() is True
    path = directory_present('/tmp/test_directory_present.__', user='-1')
    assert path.as_posix() == '/tmp/test_directory_present.__'
    assert path.is_dir() is True

# Generated at 2022-06-25 17:40:15.176586
# Unit test for function directory_present
def test_directory_present():
    # Case 0: Test default values of arguments
    case_0 = directory_present('~/tmp/test_path')
    assert 'PosixPath' in str(type(case_0))
    assert case_0.parent == '/Users/len/tmp'
    assert case_0.name == 'test_path'

    # Case 1: Test absolute path provided with '~'
    case_1 = directory_present('~/test_path')
    assert 'PosixPath' in str(type(case_1))
    assert case_1.parent == '/Users/len'
    assert case_1.name == 'test_path'

    # Case 2: Test absolute path provided without '~'
    case_2 = directory_present('/Users/len/test_path')

# Generated at 2022-06-25 17:40:23.250998
# Unit test for function path_absent
def test_path_absent():
    # Setup
    temp_dir = os.path.join(os.path.dirname(__file__), 'temp')
    if not os.path.isdir(temp_dir):
        os.mkdir(temp_dir)
    nested_dir = os.path.join(temp_dir, 'nested-test-directory')
    if not os.path.isdir(nested_dir):
        os.mkdir(nested_dir)
    nested_file = os.path.join(temp_dir, 'nested-test-file')
    if not os.path.isfile(nested_file):
        with open(nested_file, 'w'):
            pass
    # Test
    path_absent(temp_dir)
    path_absent(nested_file)

# Generated at 2022-06-25 17:40:25.182633
# Unit test for function chown
def test_chown():
    chown('/tmp/foo', '0', '-1')
    assert chown('/tmp/foo') is None



# Generated at 2022-06-25 17:40:34.765887
# Unit test for function chmod
def test_chmod():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 17:40:43.267814
# Unit test for function chmod
def test_chmod():
    # Prepare test data
    path = os.path.join(os.path.expanduser('~'), 'tmp', 'flutils.tests.osutils.txt')
    mode_file = 0o660
    mode_dir = 0o700
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as fh:
        fh.write('Test data')

    # Execute test
    chmod(path, mode_file=mode_file)
    assert os.stat(path).st_mode == mode_file
    # Cleanup
    os.remove(path)
    os.removedirs(os.path.dirname(path))



# Generated at 2022-06-25 17:40:55.754314
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil

    td = Path(tempfile.mkdtemp())
    tm = Path(tempfile.mkdtemp())

    d0 = Path(td, 'd0')
    d0.mkdir()
    f0 = Path(d0, 'f0')
    f0.touch()

    d1 = Path(d0, 'd1')
    d1.mkdir()
    f1 = Path(d1, 'f1')
    f1.touch()

    d2 = Path(d1, 'd2')
    d2.mkdir()
    f2 = Path(d2, 'f2')
    f2.touch()

    d3 = Path(d1, 'd3')
    d3.mkdir()

# Generated at 2022-06-25 17:41:00.254641
# Unit test for function chmod
def test_chmod():
    test_dir = Path(__file__).parent / 'tmp'
    test_dir.mkdir(parents=True, exist_ok=True)

    test_case_0()
    # chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-25 17:41:07.187281
# Unit test for function chown
def test_chown():
    for path in ['~/tmp/flutils.tests.osutils.txt', '~/tmp/**']:
        for user in [None, '-1', 'foo']:
            for group in [None, '-1', 'bar']:
                for include_parent in [True, False]:
                    chown(path, user=user, group=group,
                          include_parent=include_parent)


# Generated at 2022-06-25 17:41:08.659479
# Unit test for function get_os_user
def test_get_os_user():
    uid = getpass.getuser()
    current_user = get_os_user()
    assert current_user.pw_name == uid


# Generated at 2022-06-25 17:41:16.840879
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from .. import _POSIX_TEST_PATHS, _WIN_TEST_PATHS
    import os

    paths = []
    paths.extend(_POSIX_TEST_PATHS)
    paths.extend(_WIN_TEST_PATHS)

    for path in paths:
        path = os.path.expanduser(path)

        if os.path.isdir(path):
            assert exists_as(path) == 'directory'
        elif os.path.isfile(path):
            assert exists_as(path) == 'file'
        elif os.path.islink(path) is True:
            assert exists_as(path) in ['directory', 'file']
        else:
            assert exists_as(path) == ''


