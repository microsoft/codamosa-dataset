

# Generated at 2022-06-25 17:31:44.008504
# Unit test for function find_paths
def test_find_paths():
    import os
    import tempfile

    test_directory = Path(tempfile.mkdtemp())
    test_file = Path(tempfile.NamedTemporaryFile(dir=test_directory).name)

    assert len(list(find_paths(test_directory.as_posix()))) == 1
    assert len(list(find_paths(test_file.as_posix()))) == 1

    assert len(list(find_paths(test_directory.as_posix() + '/*'))) == 1
    assert len(list(find_paths(test_directory.as_posix() + '/**'))) == 1
    assert len(list(find_paths(test_directory.as_posix() + '/**/*'))) == 1

    os.remove(test_file.as_posix())
    os

# Generated at 2022-06-25 17:31:50.260930
# Unit test for function directory_present
def test_directory_present():
    struct_passwd_0 = get_os_user()
    struct_passwd_0_name = struct_passwd_0.pw_name
    struct_group_0 = get_os_group()
    struct_group_0_name = struct_group_0.gr_name
    dir_0_path = 'var/test_dir'
    dir_0_path = directory_present(dir_0_path, user=struct_passwd_0_name, group=struct_group_0_name)
    if (dir_0_path.as_posix() != '/var/test_dir'):
        print('Failed test_case_1')
        sys.exit(1)
    dir_1_path = 'var/test_dir/test_dir'

# Generated at 2022-06-25 17:31:53.010719
# Unit test for function chown
def test_chown():
    path = 'tmp'
    user = '-1'
    group = '-1'
    chown(path, user, group)

    assert 'struct_group_0' in globals()



# Generated at 2022-06-25 17:31:58.714597
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'tmp'
    if not path.exists():
        path.mkdir()
    path = path / 'flutils.tests.pathutils.txt'
    if not path.exists():
        path.touch()
    path.chmod(0o600)
    chown(path, 'nobody')
    assert path.stat().st_uid == pwd.getpwnam('nobody').pw_uid


# Generated at 2022-06-25 17:32:02.381093
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/Users/len/tmp/flutils.tests.osutils.txt'),
        Path('/Users/len/tmp/test_path')
    ]


# Generated at 2022-06-25 17:32:03.678127
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:32:05.716167
# Unit test for function exists_as
def test_exists_as():
    # Path does not exist.
    result = exists_as('/tmp/foo/bar')
    assert result == ''

    # Path exists as a directory.
    result = exists_as('/tmp')
    assert result == 'directory'

    # Path exists as a file.
    result = exists_as('/etc/hosts')
    assert result == 'file'


# Generated at 2022-06-25 17:32:11.649832
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    open(tempfile.mkstemp(prefix='flutils.tests.pathutils.chmod.tmp.0.')[1], 'a').close()
    try:
        chmod(tempfile.mkstemp(prefix='flutils.tests.pathutils.chmod.tmp.1.')[1], mode_dir=0o770, mode_file=0o660)
        chmod(tempfile.mkstemp(prefix='flutils.tests.pathutils.chmod.tmp.2.')[1], mode_dir=0o770, mode_file=0o660, include_parent=True)
    finally:
        [os.remove(tmp) for tmp in Path('/tmp').glob('flutils.tests.pathutils.chmod.tmp.*')]


# Generated at 2022-06-25 17:32:15.460344
# Unit test for function find_paths
def test_find_paths():
    assert get_os_group() != None
    assert get_os_user() != None


if __name__ == '__main__':
    test_case_0()
    test_find_paths()

# Generated at 2022-06-25 17:32:25.237688
# Unit test for function find_paths
def test_find_paths():
    import os
    import pathlib
    import tempfile
    import unittest

    class Test_find_paths(unittest.TestCase):

        def test_find_paths(self):
            with tempfile.TemporaryDirectory() as tmpdirname:
                base_path = pathlib.Path(tmpdirname)

                dir_one = base_path.joinpath('dir_one')
                dir_one.mkdir()

                file_one = dir_one.joinpath('file_one')
                file_one.touch()

                file_two = dir_one.joinpath('file_two')
                file_two.touch()

                file_three = base_path.joinpath('file_three')
                file_three.touch()

                file_four = base_path.joinpath('file_four')
                file

# Generated at 2022-06-25 17:32:47.634317
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    path = './tmp/path_absent_test_path'
    path = normalize_path(path)
    path_absent(path)
    assert not path.exists()
    path.mkdir(parents=True)
    assert path.exists()
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-25 17:32:56.769620
# Unit test for function path_absent
def test_path_absent():
    test_path = os.path.expanduser(os.path.join('~', 'tmp', 'test_path'))
    if os.path.exists(test_path):
        path_absent(test_path)
    os.mkdir(test_path)
    assert os.path.exists(test_path) == True
    path_absent(test_path)
    assert os.path.exists(test_path) == False


# Generated at 2022-06-25 17:33:06.950098
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()
    passwd_name_0 = struct_passwd_0.pw_name
    group_name_0 = struct_group_0.gr_name
    passwd_uid_0 = struct_passwd_0.pw_uid
    group_gid_0 = struct_group_0.gr_gid


    path_str_0 = os.path.expanduser('~/tmp/flutils.tests.osutils.txt')
    path_0 = PosixPath(path_str_0)

    directory_0 = path_0.parent
    if not directory_0.exists():
        directory_present(directory_0)


# Generated at 2022-06-25 17:33:16.892130
# Unit test for function chown
def test_chown():
    from subprocess import Popen, PIPE
    user = 'test_user'
    group = 'test_group'
    if user in [x.pw_name for x in pwd.getpwall()]:
        p = Popen(['userdel', user], stdout=PIPE, stderr=PIPE)
        p.communicate()
        p.wait()
    if group in [x.gr_name for x in grp.getgrall()]:
        p = Popen(['groupdel', group], stdout=PIPE, stderr=PIPE)
        p.communicate()
        p.wait()
    p = Popen(['groupadd', group], stdout=PIPE, stderr=PIPE)
    p.communicate()
    p.wait()
   

# Generated at 2022-06-25 17:33:22.023565
# Unit test for function chown
def test_chown():
    path = "~/tmp/flutils.tests.osutils.txt"
    chown(path)
    stat_info = os.stat(os.path.expanduser(path))
    user = getpass.getuser()
    group = getpass.getuser()
    assert stat_info.st_uid == get_os_user(user).pw_uid


# Generated at 2022-06-25 17:33:25.117820
# Unit test for function path_absent
def test_path_absent():
    test_path = Path('/tmp/tmp_test_path')
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    path_absent(test_path)
    assert exists_as(test_path) == ''


# Generated at 2022-06-25 17:33:27.159006
# Unit test for function exists_as
def test_exists_as():
    exists_as_path = exists_as("/Users/len/tmp/flutils.tests.osutils.txt")
    assert exists_as_path == 'file'


# Generated at 2022-06-25 17:33:32.158130
# Unit test for function path_absent
def test_path_absent():
    # Create temp dir
    test_dir = '/tmp/test_flutils'
    path_present(test_dir, mode_dir=0o700)
    # Create temp file
    test_file = '/tmp/test_flutils/test_file'
    path_present(test_file, mode_file=0o600)
    # Make sure path is there
    assert os.path.exists(test_dir)
    assert os.path.exists(test_file)
    # Test function
    path_absent(test_dir)
    # Make sure path is removed
    assert os.path.exists(test_dir) == False


# Generated at 2022-06-25 17:33:36.170096
# Unit test for function path_absent
def test_path_absent():
    x = 'filename'
    y = 'dirname'
    z = 'othername'
    os.makedirs(z)
    pathlib.Path(x).touch()
    path_absent(x)
    assert os.path.isfile(x) == False
    os.makedirs(y)
    path_absent(y)
    assert os.path.isdir(y) == False
    os.rmdir(z)


# Generated at 2022-06-25 17:33:45.431136
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as"""

    # Initialize
    try:
        # Setup
        path = Path('/tmp/__flutils.tests.pathutils.exists_as__')
        if path.is_dir():
            rmtree(path)
        if path.is_file():
            path.unlink()

        # Test exists_as() against an empty path
        assert exists_as(path) == ''

        # Test exists_as() against an existing path
        path.mkdir()
        assert exists_as(path) == 'directory'

        # Teardown
        path.rmdir()

    finally:
        pass



# Generated at 2022-06-25 17:34:08.081852
# Unit test for function chmod
def test_chmod():
    with pytest.raises(OSError) as err:
        chmod('/root/tmp/flutils.tests.osutils.txt')
    assert 'Permission denied' in err.value.strerror

    # test with a path that is a directory
    os.mkdir('/tmp/flutils.tests.osutils.dir')
    os.chmod('/tmp/flutils.tests.osutils.dir', 0o000)

    chmod('/tmp/flutils.tests.osutils.dir', mode_dir=0o755)
    assert os.stat('/tmp/flutils.tests.osutils.dir').st_mode == 0o40755

    # test with paht that is a file
    with open('/tmp/flutils.tests.osutils.txt', 'w') as fh:
        f

# Generated at 2022-06-25 17:34:10.704725
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('~/tmp/test_path') == '/Users/len/tmp/test_path'


# Generated at 2022-06-25 17:34:12.915168
# Unit test for function path_absent
def test_path_absent():
    d = Path(cwd) / Path('tmp')
    mkdir_p(d)
    f = d / Path('test_path')
    f.touch()
    path_absent(f)


# Generated at 2022-06-25 17:34:20.564606
# Unit test for function chown
def test_chown():
    import os
    from flutils.pathutils import chown
    from flutils.tests.pathutils import test_data

    if 'win32' == sys.platform:
        return

    chown(test_data.dir_flutils_tests.as_posix(), user=test_data.user_nobody)

    try:
        os.chdir(test_data.dir_flutils_tests.as_posix())
        os.getcwd()
    except PermissionError:
        pass
    else:
        assert False, 'Directory must NOT be writable by "nobody".'

    chown(test_data.dir_flutils_tests.as_posix(), user=getpass.getuser())



# Generated at 2022-06-25 17:34:22.335459
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

    # Test "include_parent"
    pass


# Generated at 2022-06-25 17:34:30.712257
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests.osutils.txt'
    user = 'foo'
    group = 'bar'
    chown(path, user, group, include_parent=True)
    infos = os.stat(path)
    assert infos.st_uid == 1000 and infos.st_gid == 1000
    chown(path, '-1','-1', include_parent=False)
    infos = os.stat(path)
    assert infos.st_uid == 0 and infos.st_gid == 0


# Generated at 2022-06-25 17:34:32.355391
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path = normalize_path(path)
    path.mkdir(parents=True)
    path_absent(path)
    assert not path.exists()


# Generated at 2022-06-25 17:34:38.456930
# Unit test for function chown
def test_chown():
    chown(path=Path('/tmp/flutils.tests.pathutils.txt1'),
          user='flutils',
          group='flutils')
    assert  os.stat('/tmp/flutils.tests.pathutils.txt1').st_gid == get_os_group(group='flutils').gr_gid


# Generated at 2022-06-25 17:34:50.117474
# Unit test for function chmod
def test_chmod():
    # Test with pathlib.Path
    test_path = Path('/tmp/flutils.tests.osutils.txt')
    test_path.touch()
    chmod(test_path, 0o660)
    assert test_path.stat().st_mode & 0o777 == 0o660
    test_path.unlink()

    # Test with str
    test_path = '/tmp/flutils.tests.osutils.txt'
    Path(test_path).touch()
    chmod(test_path, 0o660)
    assert os.stat(test_path).st_mode & 0o777 == 0o660
    os.unlink(test_path)

    # Test with bytes
    test_path = b'/tmp/flutils.tests.osutils.txt'
    Path(test_path).touch()
    ch

# Generated at 2022-06-25 17:34:51.436329
# Unit test for function path_absent
def test_path_absent():
    path = Path.home() / 'tmp' / 'test_dir'
    path.mkdir()
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-25 17:35:10.447815
# Unit test for function path_absent
def test_path_absent():
    """Unit test for flutils.pathutils.path_absent."""
    path_absent('/tmp/test_absent_1')
    path_absent('/tmp/test_absent_2')
    path_absent('/tmp/test_absent_3')
    path_absent('/tmp/test_absent_4')


# Generated at 2022-06-25 17:35:13.883882
# Unit test for function directory_present
def test_directory_present():
    hw = get_os_user(os.environ['USER'])
    directory_present(
        path = './test_directory_present_0',
        mode = 0o755,
        user = hw.pw_name,
        group = hw.pw_name
    )


# Generated at 2022-06-25 17:35:25.096977
# Unit test for function chmod
def test_chmod():
    if not os.getuid() == 0:
        sys.stderr.write('SKIP: test_chmod: must be root\n')
        return
    os.rmdir('/root/tmp')
    os.mkdir('/root/tmp')
    os.mkdir('/root/tmp/subdir')
    os.chmod('/root/tmp', 0o700)
    os.chmod('/root/tmp/subdir', 0o700)
    chmod('/root/tmp/*', 0o600, 0o600, include_parent=True)
    os.remove('/root/tmp/subdir')
    os.rmdir('/root/tmp')


# Generated at 2022-06-25 17:35:29.743425
# Unit test for function exists_as
def test_exists_as():
    """Test `flutils.pathutils.exists_as` function.
    """

    path = Path('~/tmp').expanduser()
    exists_as = exists_as(path)
    assert(exists_as == 'directory')



# Generated at 2022-06-25 17:35:33.663001
# Unit test for function chown
def test_chown():
    struct_group_0 = get_os_group()
    struct_passwd_0 = get_os_user()
    path_0 = './flutils_test.txt'
    chown(path_0, user='-1', group='-1')



# Generated at 2022-06-25 17:35:41.766982
# Unit test for function chown
def test_chown():
    from . import osutils
    from pathlib import Path
    
    filePath = Path(osutils.tmp_path('myfile.txt'))
    dirPath = Path(osutils.tmp_path('mydir'))
    dirPath.mkdir()
    
    def setToDan(path):
        chown(path, 'dan')
        
    user = get_os_user()
    group = get_os_group()
    
    # Test that chowning a file or directory with user and group
    # sets it to those values.
    setToDan(filePath)
    setToDan(dirPath)
    assert os.stat(filePath.as_posix()).st_uid == osutils.my_uid
    assert os.stat(dirPath.as_posix()).st_uid == osutils.my

# Generated at 2022-06-25 17:35:50.661997
# Unit test for function chown
def test_chown():
    os.environ['TMP'] = '/tmp'
    path = normalize_path('$TMP/flutils.tests.fileutils.txt')
    with open(path.as_posix(), 'r') as file_obj:
        mode = stat.filemode(os.fstat(file_obj.fileno()).st_mode)
        assert mode == '-rw-r--r--'
        chown(path.as_posix(), user='foo')
        mode = stat.filemode(os.fstat(file_obj.fileno()).st_mode)
        assert mode == '-rw-r--r--'


# Generated at 2022-06-25 17:36:01.790092
# Unit test for function chown
def test_chown():
    """Test chown."""
    import os
    import shutil

    # Create a temp dir.
    tmpdir = Path('/tmp/tmpdir')
    tmpdir.mkdir(mode=0o700, parents=True, exist_ok=True)

    # Create a subdir in the temp dir.
    subdir = Path('/tmp/tmpdir/subdir')
    subdir.mkdir(mode=0o700, parents=True, exist_ok=True)

    # Touch a file in the subdir.
    file0 = Path('/tmp/tmpdir/subdir/file0')
    assert file0.exists() is False
    file0.touch()
    assert file0.exists() is True

    # Change ownership and group of the subdir.

# Generated at 2022-06-25 17:36:14.742756
# Unit test for function chown
def test_chown():
    import os
    from flutils.pathutils import chown, normalize_path, path_absent

    # Make sure the path does not exist.
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path_absent(path)

    # Create a file so we can chown it later.
    with path.open('wt', encoding='latin_1') as f:
        f.write('foo')

    # "Don't touch" using '-1'
    chown(path, user='-1', group='-1')
    assert os.stat(path).st_uid == os.getuid()
    assert os.stat(path).st_gid == os.getgid()

    # "Don't touch" using 0

# Generated at 2022-06-25 17:36:19.713322
# Unit test for function chown
def test_chown():
    path = 'flutils.tests.pathutils.txt'
    user = 'jdunck'
    group = 'jdunck'
    include_parent = True
    chown(path, user, group, include_parent)


# Generated at 2022-06-25 17:36:41.268734
# Unit test for function chown
def test_chown():
    path = './tmp/foo'
    normalize_path(path)
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    chown(path, user, group)
    normalize_path(path)
    uid = getpwnam(user).pw_uid
    gid = getgrnam(group).gr_gid
    os_stat = os.stat('/home/barry/flutils/flutils/tests/tmp/foo')
    assert uid == os_stat.st_uid
    assert gid == os_stat.st_gid


# Generated at 2022-06-25 17:36:47.421643
# Unit test for function directory_present
def test_directory_present():
    directory_present(
        '~/tmp/flutils/directory_present/case_0',
        mode=0o700,
        user=getpass.getuser(),
        group=get_os_group().gr_name,
    )
    assert os.path.exists('~/tmp/flutils/directory_present/case_0') is True


# Generated at 2022-06-25 17:36:49.489628
# Unit test for function exists_as
def test_exists_as():
    # Test for existing directory
    result = exists_as("/")
    assert result == 'directory'



# Generated at 2022-06-25 17:37:00.236855
# Unit test for function chmod
def test_chmod():

    def _check_mode(
            path: _PATH,
            mode: int
    ) -> None:
        """
        Checks if the given ``path``'s mode matches the given ``mode``.

        Args:
            path (:obj:`str` or :obj:`Path <pathlib.Path>`):
                The path of the file or directory to check it's mode.
            mode (:obj:`int`): The mode to check for.
        """

        path = normalize_path(path)

        assert path.stat().st_mode & 0o777 == mode


# Generated at 2022-06-25 17:37:09.485655
# Unit test for function chmod
def test_chmod():
    struct_group_0 = get_os_group()
    path = normalize_path('./flutils_test.txt')
    chmod(path, 0o660)
    if path.exists() is True:
        if path.is_dir():
            path.chmod(0o660)
        elif path.is_file():
            path.chmod(0o660)
    print("File: flutils_test.txt has mode", oct(path.stat().st_mode & 0o777))
    #assert(path.stat().st_mode & 0o777 == 0o660)
    path.unlink()
# end unit test



# Generated at 2022-06-25 17:37:10.798984
# Unit test for function directory_present
def test_directory_present():
    directory_present('/home/foo/tmp/test_path')


# Generated at 2022-06-25 17:37:21.440758
# Unit test for function path_absent
def test_path_absent():
    def setup_function(function):
        path_present('/tmp/pathutils')
        path_present('/tmp/pathutils/test_dir')
        path_present('/tmp/pathutils/test_dir/test_path')
        path_present('/tmp/pathutils/test_dir/test_file')

    def teardown_function(function):
        path_absent('/tmp')

    def test_remove_directory():
        path_absent('/tmp/pathutils/test_dir')
        assert os.path.exists(
            '/tmp/pathutils/test_dir'
        ) is False

    def test_remove_file():
        path_absent('/tmp/pathutils/test_dir/test_file')

# Generated at 2022-06-25 17:37:22.798725
# Unit test for function exists_as
def test_exists_as():
    """Test exists_as()"""
    test_exists_as_0()



# Generated at 2022-06-25 17:37:26.410457
# Unit test for function path_absent
def test_path_absent():
    path = "/home/test/test_path_absent/path_absent"
    os.makedirs(path)
    path_absent(path)
    assert os.path.exists(path) == False
    print("path_absent() test passed")


# Generated at 2022-06-25 17:37:28.584337
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'
    path = path.parent
    assert exists_as(path) == 'directory'



# Generated at 2022-06-25 17:37:49.570999
# Unit test for function chmod
def test_chmod():
    if os.name == 'posix':
        path_0 = '/tmp/flutils.tests.osutils.txt'
        path_1 = '/tmp/flutils.tests.osutils.txt.1'
        path_2 = '/tmp/flutils.tests.osutils.txt.2'
        path_3 = '/tmp/flutils.tests.osutils.txt.1.2'
        path_4 = '/tmp/flutils.tests.osutils.txt.1.2.3'
        path_5 = '/tmp/flutils.tests.osutils.txt.1.2.3.4'
        path_6 = '/tmp/flutils.tests.osutils.txt.1.2.3.4.5'

# Generated at 2022-06-25 17:37:50.555689
# Unit test for function path_absent
def test_path_absent():
    path_absent('~/tmp_path')
    

# Generated at 2022-06-25 17:37:53.901681
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    

# Generated at 2022-06-25 17:38:00.875596
# Unit test for function exists_as
def test_exists_as():
    # Test Path does NOT exist
    assert(exists_as('/this/path/does/not/exist') == '')
    assert(exists_as('/Users/len/tmp/test_directory') == 'directory')
    assert(exists_as('/Users/len/tmp/test_file') == 'file')
    assert(exists_as('/Users/len/tmp/test_fifo') == 'FIFO')



# Generated at 2022-06-25 17:38:03.334615
# Unit test for function exists_as
def test_exists_as():
    dir_path = Path('tests/osutils/')
    file_path = dir_path / 'file_exists_as_file.txt'
    assert exists_as(dir_path) == 'directory'
    assert exists_as(file_path) == 'file'

test_exists_as()

# Generated at 2022-06-25 17:38:10.628503
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()
    print("\nstruct_passwd_0:")
    struct_passwd_0_dict = struct_passwd_0._asdict()
    for key, value in struct_passwd_0_dict.items():
        print("\t{0}: {1}".format(key, value))
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-25 17:38:19.598327
# Unit test for function chown
def test_chown():
    from pathlib import PosixPath
    from tempfile import TemporaryDirectory
    # Create struct_group name `testgrp`
    testgrp = 'testgrp'
    assert get_os_group(testgrp) is None
    run('groupadd -r testgrp')
    struct_group = get_os_group(testgrp)
    assert struct_group is not None
    assert struct_group.gr_gid == 5000

    # Create struct_passwd name `testusr`
    testusr = 'testusr'
    assert get_os_user(testusr) is None
    run('useradd -r -g testgrp testusr')
    struct_passwd = get_os_user(testusr)
    assert struct_passwd is not None

    # Create a temporary directory

# Generated at 2022-06-25 17:38:23.865150
# Unit test for function chmod
def test_chmod():
    # If a directory is specified, the chmod should appropriately set the
    # file mode of the directory.
    path = Path("/tmp")
    mode_dir = 0o777
    mode_file = 0o666
    chmod(path, mode_file, mode_dir)
    if not path.is_dir():
        raise IOError("Failure to make directory")
    mode = path.stat().st_mode
    if not mode == mode_dir:
        raise IOError("Failure to set directory mode")

    # If a file is specified, the chmod should appropriately set the file
    # mode of the file.
    path = Path("/tmp/flutils.test.chmod")
    path.touch()
    chmod(path, mode_file, mode_dir)

# Generated at 2022-06-25 17:38:30.462762
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)

    with open('/tmp/flutils.tests.osutils.txt', 'w+') as f:
        f.write('test_chmod')

    chmod('/tmp/**', mode_file=0o644, mode_dir=0o770)

    chmod('/tmp/*')



# Generated at 2022-06-25 17:38:41.992011
# Unit test for function chown
def test_chown():
    if sys.platform.startswith('linux'):
        struct_group_0 = 0
        struct_group_1 = os.getgid()

        struct_user_0 = os.getuid()
        struct_user_1 = os.getuid()
    else:
        struct_group_0 = grp.getgrgid(0).gr_gid
        struct_group_1 = grp.getgrgid(os.getgid()).gr_gid

        struct_user_0 = pwd.getpwuid(os.getuid()).pw_uid
        struct_user_1 = pwd.getpwuid(os.getuid()).pw_uid


# Generated at 2022-06-25 17:39:14.711302
# Unit test for function path_absent
def test_path_absent():
    '''Test the path_absent function.'''

    path_0 = '~/tmp/foo'
    path_1 = '~/tmp/foo/bar'
    path_2 = '~/tmp/foo/bar/baz'
    path_3 = '~/tmp/foo/bar/baz/boo'
    path_4 = '~/tmp/foo/bar/baz/boo/far'
    path_5 = '~/tmp/foo/bar/baz/boo/far/bar'

    path_0 = normalize_path(path_0)
    path_1 = normalize_path(path_1)
    path_2 = normalize_path(path_2)
    path_3 = normalize_path(path_3)

# Generated at 2022-06-25 17:39:18.900898
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    # Set the
    # Create a temporary directory
    # Delete the temporary directory
    # None
    return


# Generated at 2022-06-25 17:39:20.256309
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc/passwd') == 'file'


# Generated at 2022-06-25 17:39:30.448454
# Unit test for function path_absent
def test_path_absent():
    # Test for directories
    dtmp = '/tmp/test_path_absent'
    if os.path.exists(dtmp):
        shutil.rmtree(dtmp)
    os.makedirs(dtmp)
    assert os.path.exists(dtmp)
    path_absent(dtmp)
    assert os.path.exists(dtmp) is False

    # Test for files
    ftmp = dtmp + '/test_path_absent.txt'
    with open(ftmp, mode='w') as f:
        f.write('test_path_absent')
    assert os.path.exists(ftmp)
    path_absent(ftmp)
    assert os.path.exists(ftmp) is False

    # Test for sym links

# Generated at 2022-06-25 17:39:31.280958
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'


# Generated at 2022-06-25 17:39:38.508682
# Unit test for function chown
def test_chown():
    from unittest.mock import patch
    from unittest.mock import Mock
    import os
    import pwd
    import grp
    with patch.object(os, 'chown') as mock_chown:
        test_path = '~/tmp/flutils.pathutils.tests.txt'
        chown(test_path)
        mock_chown.assert_called_once_with(
            str(normalize_path(test_path)),
            -1,
            -1
        )



# Generated at 2022-06-25 17:39:49.851638
# Unit test for function path_absent
def test_path_absent():
    # First create a test directory
    path = Path('~/tmp/test_path').expanduser().absolute()
    if not isinstance(path, str):
        path = path.as_posix()
    path = cast(str, path)
    if os.path.exists(path) is False:
        os.makedirs(path)

    # Then ensure the directory was created.
    if os.path.isdir(path) is False:
        raise OSError(
            'Bug in the unit test.  Unable to create the directory: %r'
            % path
        )

    # Clean up the test directory
    path_absent(path)

    # Then ensure the directory was removed.

# Generated at 2022-06-25 17:39:58.944371
# Unit test for function chown
def test_chown():
    sub_path = "./tmp/flutils.tests.osutils.txt"
    mode_current = stat.S_IMODE(os.lstat(sub_path).st_mode)
    mode_modify = mode_current | stat.S_IRGRP | stat.S_IWGRP | stat.S_IXGRP
    if mode_current == mode_modify:
        # chmod() did not work, skip this test
        pass
    else:
        chmod(sub_path, mode_file=mode_modify)
        mode_after = stat.S_IMODE(os.lstat(sub_path).st_mode)
        #chown(sub_path, user="user", group="group")
        assert mode_after == mode_modify



# Generated at 2022-06-25 17:40:01.486067
# Unit test for function directory_present
def test_directory_present():
    try:
        directory_present('~/tmp/foo')
    except ValueError:
        print('ValueError:')
    except FileExistsError:
        print('FileExistsError:')


# Generated at 2022-06-25 17:40:12.582161
# Unit test for function chmod
def test_chmod():
    print('chmod: ', end='')
    f_name = 'flutils.tests.osutils.txt'
    f_path = Path(os.path.expanduser('~/tmp/' + f_name))
    try:
        f_path.touch()
        chmod(f_path, 0o660)
        if f_path.exists() is True and f_path.stat().st_mode == 33152:
            print('Success')
        else:
            print('Failed')
    finally:
        if f_path.exists() is True:
            f_path.unlink()


# Generated at 2022-06-25 17:40:27.856128
# Unit test for function path_absent
def test_path_absent():
    """
    testing function path_absent
    """
    path = Path('~/tmp/test_path')
    path = normalize_path(path)

    path_absent(path)
    assert not os.path.exists(path)

    path.mkdir(mode=0o700)
    assert path.exists()

    path_absent(path)
    assert not os.path.exists(path)

    path.mkdir(mode=0o700)
    assert path.exists()

    child_path = path / 'test_dir'
    child_path.mkdir(mode=0o700)
    assert child_path.exists()

    path_absent(path)
    assert not os.path.exists(path)
    assert not child_path.exists()


# Generated at 2022-06-25 17:40:40.024701
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('.') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/dev/tty') == 'character device'
    assert exists_as('/dev/log') == 'socket'
    assert exists_as('/var/log/syslog') == 'file'
    assert exists_as('/tmp/foo') == ''
    assert exists_as('/proc') == 'directory'
    assert exists_as('/proc/tty') == 'directory'
    assert exists_as('/proc/tty/drivers') == 'file'
    assert exists_as('/proc/tty/foo') == ''
    assert exists_as('/proc/self') == 'directory'

# Generated at 2022-06-25 17:40:49.832961
# Unit test for function exists_as
def test_exists_as():
    with pytest.raises(FileNotFoundError) as e:
        file_exists = exists_as('~/tmp/flutils.tests.pathutils')
        assert file_exists == ''
    assert str(e.value) == 'The path: ~/tmp/flutils.tests.pathutils does not exist.'

    with pytest.raises(FileNotFoundError) as e:
        file_exists = exists_as('~/tmp/flutils.tests.pathutils/')
        assert file_exists == ''
    assert str(e.value) == 'The path: ~/tmp/flutils.tests.pathutils/ does not exist.'


# Generated at 2022-06-25 17:40:58.694122
# Unit test for function chmod
def test_chmod():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_file = tmp_dir + '/' + 'flutils.tests.osutils.txt'
        path_0 = Path(tmp_file)
        path_0.touch()

        path_1 = Path(tmp_dir + '/' + 'flutils.tests.osutils.d')
        path_1.mkdir()

        struct_group_0 = get_os_group()

        # Test case 0
        chmod(path_0, 0o600)
        assert path_0.stat().st_mode & 0o777 == 0o600

        chmod(path_0, 0o666)
        assert path_0.stat().st_mode & 0o777 == 0o666

        chmod(str(path_0), 0o644)

# Generated at 2022-06-25 17:41:10.949474
# Unit test for function exists_as
def test_exists_as():
    if 'linux' in sys.platform:
        assert exists_as('/dev') == 'directory'
        assert exists_as('/dev/null') == 'char device'
        assert exists_as('/dev/console') == 'char device'
        assert exists_as('/dev/kmsg') == 'char device'
        assert exists_as('/dev/tty') == 'char device'
        assert exists_as('/dev/pts') == 'directory'
        assert exists_as('/dev/ptmx') == 'char device'
        assert exists_as('/dev/pts/ptmx') == ''
        assert exists_as('/dev/core') == 'block device'
        assert exists_as('/dev/full') == 'char device'
        assert exists_as('/dev/random') == 'char device'
       