

# Generated at 2022-06-25 17:32:21.266627
# Unit test for function find_paths
def test_find_paths():
    import subprocess
    subprocess.call("mkdir -p ./tmp/test",shell=True)
    subprocess.call("touch ./tmp/test/file_one",shell=True)
    subprocess.call("touch ./tmp/test/file_two",shell=True)
    subprocess.call("touch ./tmp/test/file_three",shell=True)
    subprocess.call("mkdir -p ./tmp/test/dir_one",shell=True)
    subprocess.call("mkdir -p ./tmp/test/dir_two",shell=True)

    files = list(find_paths("./tmp/test/*"))
    assert len(files) == 5
    subprocess.call("rm -rf ./tmp/test/*",shell=True)

# Generated at 2022-06-25 17:32:25.487748
# Unit test for function path_absent
def test_path_absent():
    import pytest
    norm_path = os.path.normpath('~/tmp/test_path')
    path_absent(norm_path)
    assert not os.path.exists(norm_path)


# Generated at 2022-06-25 17:32:37.374728
# Unit test for function chown
def test_chown():
    test_root = os.path.join(os.path.dirname(__file__), 'test_chown')
    test_dir = os.path.join(test_root, 'test_dir')
    test_file = os.path.join(test_dir, 'test_file')

    # Clean up previous run, if any
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)

    os.mkdir(test_dir)
    with open(test_file, 'w') as f:
        f.write('abc')

    # Test chown on dir
    chown(test_dir)
    assert os.stat(test_dir)[4] == os.getuid()
    assert os.stat(test_dir)[5] == os.getgid()

   

# Generated at 2022-06-25 17:32:43.977201
# Unit test for function path_absent
def test_path_absent():
    proc_fname = 'proc_fname_pid' + str(os.getpid())
    proc_fname_path = Path(proc_fname)
    assert not proc_fname_path.exists()
    proc_fname_path.touch()
    assert proc_fname_path.exists()
    path_absent(proc_fname_path)
    assert not proc_fname_path.exists()

if __name__ == "__main__":
    print("Unit test for Pathutils.get_os_group()")
    test_case_0()
    print("... OK")
    print("Unit test for Pathutils.path_absent()")
    test_path_absent()
    print("... OK")

# Generated at 2022-06-25 17:32:49.225291
# Unit test for function path_absent
def test_path_absent():
    # Create the base path.
    base_path = normalize_path('~/tmp/test_dir')
    path_present(base_path, mode=0o700)

    # Create a path absent path that should be removed.
    target_path = base_path / 'test_path'
    path_present(target_path, mode=0o700)

    # Ensure everything is setup right.
    base = base_path.as_posix()
    target = target_path.as_posix()
    assert os.path.exists(base) is True, 'Base path does NOT exist.'
    assert os.path.exists(target) is True, 'Target path does NOT exist.'

    # Run the function.
    path_absent(target_path)

    # Ensure that the target does not exist.

# Generated at 2022-06-25 17:32:51.127865
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:33:03.637688
# Unit test for function path_absent
def test_path_absent():
    path_exists = os.path.exists

    test_dir_name = 'test_path_absent'
    test_dir = os.path.join(os.getcwd(), test_dir_name)
    test_file = os.path.join(test_dir, 'test_file')
    test_link = os.path.join(test_dir, 'test_link')
    test_link_target = os.path.join(test_dir, 'test_link_target')

    if path_exists(test_file):
        os.unlink(test_file)
    if path_exists(test_link):
        os.unlink(test_link)
    if path_exists(test_link_target):
        os.unlink(test_link_target)

# Generated at 2022-06-25 17:33:10.836002
# Unit test for function chmod
def test_chmod():
    #  Set up test data
    test_data_0 = [
        {
            'path': '~/tmp/flutils.tests.osutils.txt',
            'mode_file': 0o660,
            'expected_output': None,
            'return_value': None
            }
    ]
    for test_case_counter in range (0,1):
        chmod(test_data_0[test_case_counter]['path'],test_data_0[test_case_counter]['mode_file'])
        if None == test_data_0[test_case_counter]['expected_output']:
            assert test_data_0[test_case_counter]['return_value'] == None

# Generated at 2022-06-25 17:33:18.529403
# Unit test for function chown
def test_chown():
    chown('.')
    chown('./', include_parent=True)
    chown('..', include_parent=True)
    chown('../*', include_parent=True)
    chown('../test_algorithms.py')
    chown('../test_algorithms.py', include_parent=True)
    chown('../test_algorithms.py', user='-1')
    chown('../test_algorithms.py', user='-1', group='-1')
    chown('../test_algorithms.py', include_parent=True, user='-1', group='-1')
    chown('../test_algorithms.py', group='-1')
    chown('../test_algorithms.py', group='-1', include_parent=True)


# Generated at 2022-06-25 17:33:26.416217
# Unit test for function directory_present
def test_directory_present():
    if getpass.getuser() == 'root':
        directory_present('/tmp/flutils')
        directory_present('/tmp/flutils/parent')
        directory_present('/tmp/flutils/parent/child')
    else:
        directory_present('~/tmp/flutils')
        directory_present('~/tmp/flutils/parent')
        directory_present('~/tmp/flutils/parent/child')


# Generated at 2022-06-25 17:33:47.901295
# Unit test for function path_absent
def test_path_absent():
    import tempfile

    def new_path():
        d = tempfile.mkdtemp()
        p = os.path.join(d, 'test_file')
        open(p, 'w').close()
        return p


    def assert_not_exists(path: _PATH) -> None:
        path = normalize_path(path)
        try:
            os.stat(path.as_posix())
        except OSError as err:
            if err.errno != errno.ENOENT:
                raise
        else:
            assert False, 'Path still exists: %r' % path.as_posix()


    def test_path_absent_0():
        p = new_path()
        assert_not_exists(p)
        test_path_absent()



# Generated at 2022-06-25 17:33:54.783050
# Unit test for function chmod
def test_chmod():
    assert os.path.isfile('flutils.tests.osutils.txt')
    assert os.stat('flutils.tests.osutils.txt').st_mode & 0o777 != 0o600
    chmod('flutils.tests.osutils.txt', 0o600)
    assert os.stat('flutils.tests.osutils.txt').st_mode & 0o777 == 0o600


# Generated at 2022-06-25 17:34:02.741140
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()
    struct_passwd_1 = get_os_user(name=struct_passwd_0.pw_name)
    struct_passwd_2 = get_os_user(name=struct_passwd_0.pw_uid)
    assert struct_passwd_0 == struct_passwd_1
    assert struct_passwd_0 == struct_passwd_2

    assert isinstance(struct_passwd_0.pw_name, str)
    assert isinstance(struct_passwd_0.pw_passwd, str)
    assert isinstance(struct_passwd_0.pw_uid, int)
    assert isinstance(struct_passwd_0.pw_gid, int)

# Generated at 2022-06-25 17:34:09.631135
# Unit test for function find_paths
def test_find_paths():
    paths = list(find_paths('~/tmp/*'))
    os_name = get_os_name()
    if os_name == 'Windows':
        assert paths == [
            WindowsPath('C:\\Users\\test_user\\tmp\\file_one'),
            WindowsPath('C:\\Users\\test_user\\tmp\\dir_one')
        ]
    else:
        assert paths == [
            PosixPath('/home/test_user/tmp/file_one'),
            PosixPath('/home/test_user/tmp/dir_one')
        ]



# Generated at 2022-06-25 17:34:15.540480
# Unit test for function chmod
def test_chmod():
    """Test chmod."""
    print('Testing chmod.')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')
    print('Done testing chmod.')


# Generated at 2022-06-25 17:34:18.782545
# Unit test for function exists_as
def test_exists_as():
    assert exists_as("test_pathutils.py") == 'file'
    assert exists_as("test_does_not_exist") == ''
    assert exists_as("/test_pathutils.py") == 'file'


# Generated at 2022-06-25 17:34:30.679306
# Unit test for function find_paths
def test_find_paths():
    import sys
    import os
    import pathlib
    import tempfile
    # Make a temporary directory that will be deleted
    # when the program exits.
    temp_dir = tempfile.TemporaryDirectory()

    ptmp = pathlib.Path(temp_dir.name)
    paths = [
        ptmp / 'flutils.tests.osutils.txt',
        ptmp / 'flutils.tests.osutils.txt.gz',
        ptmp / 'flutils.tests.osutils.txt.xz',
        ptmp / 'flutils.tests.osutils.txt.bz2',
        ptmp / 'flutils.tests.osutils.txt.zip',
    ]
    for path in paths:
        path.touch()


# Generated at 2022-06-25 17:34:35.286254
# Unit test for function path_absent
def test_path_absent():
    # Test removal of a file.
    #
    # Setup
    path_0 = normalize_path('~/tmp/test_path_0')
    path_0.touch()
    assert os.path.exists(path_0)

    # Do the actual test.
    #
    # If anything in the function body raises an error the
    # test will fail.
    path_absent(path_0)
    assert os.path.exists(path_0) is False

    # Test removal of a non-existant file.
    #
    # If anything in the function body raises an error the
    # test will fail.
    path_absent(path_0)
    assert os.path.exists(path_0) is False

    # Test removal of a directory.
    #
    # Setup
    path_

# Generated at 2022-06-25 17:34:41.311171
# Unit test for function chmod
def test_chmod():
    print("Testing function chmod")
    try:
        from pathlib import Path
        from flutils.pathutils import chmod
    except ImportError:
        print("Unable to import Path or chmod")
        return
    print("Testing the chmod function with a case statement")
    test_case_0()


# Generated at 2022-06-25 17:34:44.707355
# Unit test for function chmod
def test_chmod():
    path_0 = normalize_path('tmp/*')
    mode_file_0 = 0o600
    chmod(path_0, mode_file=mode_file_0)


# Generated at 2022-06-25 17:35:01.537515
# Unit test for function directory_present

# Generated at 2022-06-25 17:35:07.798832
# Unit test for function exists_as
def test_exists_as():
    cwd = Path.cwd()
    for _path in ('/', '/etc', cwd, cwd / 'non_existent_path',
                  cwd / 'non_existent_directory',
                  cwd / 'non_existent_file.txt'):
        _path = Path(_path)
        _exists_as = exists_as(_path)
        if _path.exists():
            assert _exists_as
        else:
            assert _exists_as == ''

        if _path.is_dir():
            assert _exists_as == 'directory'
        elif _path.is_file():
            assert _exists_as == 'file'
        elif _path.is_block_device():
            assert _exists_as == 'block device'

# Generated at 2022-06-25 17:35:08.830163
# Unit test for function chmod
def test_chmod():
    pass


# Generated at 2022-06-25 17:35:18.971505
# Unit test for function path_absent
def test_path_absent():
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        # Test with a file
        test_path = os.path.join(temp_dir, 'foo.txt')
        with open(test_path, 'w') as test_file:
            test_file.write('foo')
        path_absent(test_path)
        assert os.path.exists(test_path) is False

        # Test with a directory
        test_dir = os.path.join(temp_dir, 'foo_dir')
        os.mkdir(test_dir)
        test_path_1 = os.path.join(test_dir, 'foo_1.txt')

# Generated at 2022-06-25 17:35:30.761017
# Unit test for function path_absent
def test_path_absent():
    """Ensure the path_absent functions.

    *New in version 0.5.*
    """
    path = os.path.expanduser('~/tmp/path_absent_test')
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)
    # Change the path to a link to the directory
    try:
        os.remove(path)
    except FileNotFoundError:
        # Path is a file on Windows
        os.remove(path + '.lnk')
    os.symlink(path, path)
    assert os.path.exists(path)
    assert os.path.exists(path + '.lnk')
    # Run the path_absent function
    path_absent(path)
    assert not os.path

# Generated at 2022-06-25 17:35:31.820432
# Unit test for function chmod
def test_chmod():
    test_case_0()


# Generated at 2022-06-25 17:35:37.234669
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import mkdtemp
    import shutil

    base_dir = mkdtemp()
    directory = Path(base_dir, 'directory')
    assert not directory.exists()
    directory_present(directory)
    assert directory.exists() and directory.is_dir()
    shutil.rmtree(base_dir)



# Generated at 2022-06-25 17:35:49.174931
# Unit test for function path_absent
def test_path_absent():
    # Make a temp directory and add a file (temp_dir_0/temp_file_0)
    temp_dir_path_0 = tempfile.TemporaryDirectory()
    temp_dir_path_0.name = normalize_path(temp_dir_path_0.name)
    temp_dir_path_0.name = temp_dir_path_0.name.as_posix()

    temp_file_path_0 = Path(
        os.path.join(temp_dir_path_0.name, 'temp_file_0')
    )
    temp_file_path_0 = normalize_path(temp_file_path_0)
    temp_file_path_0 = temp_file_path_0.as_posix()

# Generated at 2022-06-25 17:35:56.850880
# Unit test for function chmod
def test_chmod():
    if sys.version_info < (3, 6):
        # This is a hard test case to write/execute due to race conditions.
        # So instead use an instance attribute that is used in the
        # osutils.chmod function.
        path = normalize_path('~/tmp/flutils.tests.osutils.txt')

        # Create an empty file
        with open(path, 'w') as f:
            pass

        assert os.stat(path).st_mode & 0o777 == 0o600
        chmod(path)
        assert os.stat(path).st_mode & 0o777 == 0o700
    else:
        raise NotImplementedError('Need to create tests for py >= 3.6.')



# Generated at 2022-06-25 17:36:04.496038
# Unit test for function path_absent
def test_path_absent():

    print('\nTesting path_absent():')

    # 1. Create a directory that does not exist.
    path = os.path.join(os.getcwd(), 'test_path')
    path_absent(path)

    # 2. Create a directory
    os.mkdir(path)
    assert os.path.exists(path) is True

    # 3. Remove the directory
    path_absent(path)
    assert os.path.exists(path) is False


if __name__ == '__main__':
    if os.name == 'nt':
        test_case_0()

# Generated at 2022-06-25 17:36:27.332811
# Unit test for function chown
def test_chown():
    import grp
    import pwd
    from typing import Tuple, Optional
    from os import getuid, getgid, chown
    from os import PathLike
    from pathlib import Path
    from random import choice
    from string import ascii_uppercase, digits

    uid = getuid()
    gid = getgid()

    user_name = getpass.getuser()
    group_name = grp.getgrgid(gid).gr_name

    # Create random file
    new_file_name = ''
    for _ in range(28):
        new_file_name += choice(ascii_uppercase + digits)
    new_file_name += '.txt'
    new_file = Path('/home') / user_name / new_file_name
    new_file.touch()

# Generated at 2022-06-25 17:36:31.692213
# Unit test for function exists_as
def test_exists_as():
    try:
        p = Path().cwd() / 'exists_as.txt'
        print(p.as_posix())
        with p.open('w+'):
            pass
        assert exists_as(p) == 'file'
    finally:
        p.unlink()



# Generated at 2022-06-25 17:36:35.353956
# Unit test for function directory_present
def test_directory_present():
    # test case 1
    #directory_present('~/tmp/flutils.tests.test_directory_present.txt')
    print("test case 1: test directory_present")
    path = normalize_path('~/tmp/test_directory_present')
    directory_present(path)
    if not path.exists() or not path.is_dir():
        return False
    else:
        return True




# Generated at 2022-06-25 17:36:38.333690
# Unit test for function exists_as
def test_exists_as():
    # Test case 0
    struct_group_0 = get_os_group()
    test_path_0 = Path(struct_group_0.gr_name)
    assert exists_as(test_path_0) == 'directory'



# Generated at 2022-06-25 17:36:45.267153
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests.osutils/'

# Generated at 2022-06-25 17:36:57.565870
# Unit test for function path_absent
def test_path_absent():
    path = '/tmp/path_absent.test'
    path_absent(path)
    path_absent(path)
    os.mkdir(path)
    path_absent(path)
    dir0 = path + '/dir0'
    dir1 = path + '/dir1'
    dir2 = path + '/dir2'
    os.mkdir(dir0)
    os.mkdir(dir1)
    os.mkdir(dir2)
    path_absent(path)
    os.mkdir(path)
    file0 = path + '/file0'
    create_file(file0)
    path_absent(path)
    os.mkdir(path)
    os.mkdir(dir0)
    os.mkdir(dir1)
    os.mkdir(dir2)


# Generated at 2022-06-25 17:36:58.856240
# Unit test for function chown
def test_chown():
    chown('~/tmp/chown/', )


# Generated at 2022-06-25 17:37:05.927160
# Unit test for function chown
def test_chown():
    chown_path = normalize_path('~/tmp/flutils-tests/chown')
    chown_path.mkdir(parents=True)
    chown_path.chmod(0o700)

    curr_user = getpass.getuser()
    curr_group = get_os_group(getpass.getuser()).gr_gid
    chown_path.stat().st_uid == os.getuid()
    chown_path.stat().st_gid == curr_group
    chown_path.stat().st_size == 4096
    chown_path.stat().st_mode == 16832

    os.utime(chown_path.as_posix())

# Generated at 2022-06-25 17:37:12.387735
# Unit test for function exists_as
def test_exists_as():
    os_path = Path('/etc/passwd')
    if exists_as(os_path) == 'file':
        print('The file: ' + os_path.as_posix() + ' exists on this OS\n')
    else:
        print('The file: ' + os_path.as_posix() + ' does NOT exist on this OS\n')


if __name__ == '__main__':
    test_exists_as()

# Generated at 2022-06-25 17:37:23.065720
# Unit test for function chown
def test_chown():
    try:
        path = normalize_path("/bin/ls")
        gid_0 = get_os_group().gr_gid
        chown(path, group=gid_0)
        gid_1 = get_os_group(path)
        assert gid_0 == gid_1
    except OSError as e:
        print(f"test_chown raised OSError: {e.strerror}")
        print(f"test_chown path: {path}")
        print(f"test_chown group: {gid_0}")
        return False
    except AssertionError as e:
        print(f"test_chown raised AssertionError: {e.strerror}")
        return False
    return True



# Generated at 2022-06-25 17:37:38.961269
# Unit test for function chown
def test_chown():
    struct_parent_dir_0 = get_os_group(group=20)
    struct_parent_dir_2 = get_os_group(group=20)
    struct_parent_dir_1 = get_os_group(group=20)



# Generated at 2022-06-25 17:37:43.321857
# Unit test for function chmod
def test_chmod():
    # This test case uses the sample file created by test_case_0
    path = '~/tmp/flutils.tests.osutils.txt'
    chmod(path, include_parent=True)
    path_info = os.stat(path)
    assert path_info.st_mode == 33261


# Generated at 2022-06-25 17:37:51.188910
# Unit test for function chown
def test_chown():
    path0 = PosixPath('~/tmp/flutils.tests.osutils.txt')
    path1 = PosixPath('~/tmp/flutils.tests.osutils.txt')
    user0 = getpass.getuser()
    group0 = get_os_group().gr_gid
    chown(path0, user0, group0)
    chown(path1, user0, group0)
    name0 = path0.as_posix()
    name1 = path1.as_posix()
    assert name0 == name1
    assert os.path.exists(name0)


# Generated at 2022-06-25 17:37:59.683109
# Unit test for function directory_present
def test_directory_present():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    # Test case 0
    directory_present('test_directory_present_0')
    pytest.fail('function test_directory_present has not been implemented.')
    # Test case 1
    directory_present('test_directory_present_1')
    pytest.fail('function test_directory_present has not been implemented.')



# Generated at 2022-06-25 17:38:03.937321
# Unit test for function directory_present
def test_directory_present():
    directory_present('a/b/c')
    directory_present('a')
    directory_present('a/b/c', user='root')
    directory_present('a/b/c', user='root', group='wheel')
    directory_present('a/b/c', user='root', mode=0o777, group='wheel')


# Generated at 2022-06-25 17:38:14.887694
# Unit test for function chown
def test_chown():
    path = posix('~/tmp/flutils.tests.osutils.txt')
    group = grp.getgrgid(os.getegid()).gr_name
    try:
        os.chown(path.as_posix(), -1, -1)
    except OSError as e:
        # When doing os.chown() on a path that does not exist,
        # an OSError will be raised.
        print('Error', e)
        print('Traceback', sys.exc_info()[2])
    os.chown(path.as_posix(), -1, -1)
    chown(path.as_posix())
    chown(path.as_posix(), user=os.getlogin(), group=group)

# Generated at 2022-06-25 17:38:22.509107
# Unit test for function chmod
def test_chmod():
    # Test 1 of chmod
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 484
    mode_dir = 560
    include_parent = False
    chmod(path, mode_file, mode_dir, include_parent)

    # Test 2 of chmod
    path = '~/tmp/**'
    mode_file = 420
    mode_dir = 448
    include_parent = False
    chmod(path, mode_file, mode_dir, include_parent)

    # Test 3 of chmod
    path = '~/tmp/*'
    mode_file = None
    mode_dir = None
    include_parent = False
    chmod(path, mode_file, mode_dir, include_parent)



# Generated at 2022-06-25 17:38:28.660214
# Unit test for function path_absent
def test_path_absent():

    with open("/home/test_user/tmp/test_path.txt", "w") as f:
        f.write("This is a test.")
    path_absent("/home/test_user/tmp/test_path.txt")

if __name__ == "__main__":
    test_path_absent()

    # if len(sys.argv) > 1 and sys.argv[1] == "2":
    #     test_case_2()
    # else:
    #     test_case_0()

# Generated at 2022-06-25 17:38:33.423408
# Unit test for function chmod
def test_chmod():
    user_name = 'test_user'
    group_name = 'test_group'
    user = get_os_user('root')
    print(user)
    group = get_os_group('root')
    print(group)
    struct_passwd = pwd.getpwnam('root')
    print(struct_passwd)
    struct_group = grp.getgrnam('root')
    print(struct_group)

# Generated at 2022-06-25 17:38:37.831285
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-25 17:39:00.688429
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:39:04.526792
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-25 17:39:05.189110
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-25 17:39:09.029893
# Unit test for function chown
def test_chown():
    sys.stdout.write('Testing chown():\n')

    # Test case 0
    sys.stdout.write('Test case 0:\n')
    test_case_0()


# Generated at 2022-06-25 17:39:17.957591
# Unit test for function chown
def test_chown():
    # Verify that chown works with a pathlib.PurePosixPath object
    # as its first parameter.
    path = Path('/tmp')
    chown(path)
    assert not path.lchown(0, 0)

    # Verify that chown works for files and directories.
    path_dir = Path(__file__).parent.joinpath('sample_dir')
    path_file = path_dir.joinpath('sample_file')

# Generated at 2022-06-25 17:39:22.840884
# Unit test for function get_os_user
def test_get_os_user():
    import getpass
    test_user = getpass.getuser()
    struct_passwd_0 = get_os_user(test_user)
    assert isinstance(struct_passwd_0, pwd.struct_passwd)
    assert struct_passwd_0.pw_name == test_user


# Generated at 2022-06-25 17:39:32.475865
# Unit test for function directory_present
def test_directory_present():
    # Test case 0
    struct_group_0 = get_os_group()
    struct_passwd_0 = get_os_user()
    # Test case 1
    struct_group_1 = struct_group_0
    struct_passwd_1 = struct_passwd_0
    group_0 = struct_group_0.gr_name
    group_1 = group_0
    user_0 = struct_passwd_0.pw_name
    user_1 = user_0
    temp_0 = directory_present('/home/vagrant/flutils/testing/tmp/directory_present_0', 0o777, -1, -1)
    temp_1 = directory_present('/home/vagrant/flutils/testing/tmp/directory_present_1', 0o777, user_1, group_1)


# Generated at 2022-06-25 17:39:36.923133
# Unit test for function exists_as
def test_exists_as():
    print("Testing function exists_as(...)")

    tester = unittest.TestCase()

    path = Path("/tmp/foo")
    if path.exists():
        path.unlink()
    tester.assertEqual(exists_as(path), "")

    path.mkdir()
    tester.assertEqual(exists_as(path), "directory")

    path = "/tmp/foo/bar/baz"
    tester.assertEqual(exists_as(path), "")

    path = Path("/tmp/foo/bar/baz")
    path.mkdir(parents=True)
    tester.assertEqual(exists_as(path), "directory")

if __name__ == '__main__':
    test_exists_as()
    #test_case_

# Generated at 2022-06-25 17:39:41.222278
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('../pathutils.py')
    expected = 'file'
    actual = exists_as(path)
    assert actual == expected
    print(path)



# Generated at 2022-06-25 17:39:42.256272
# Unit test for function chmod
def test_chmod():
    test_case_0()


# Generated at 2022-06-25 17:40:16.508919
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__ + '_') == ''
    assert exists_as(__file__ + '_' + os.sep) == ''
    assert exists_as(os.path.dirname(__file__)) == 'directory'
    assert exists_as(os.path.dirname(__file__) + os.sep) == 'directory'
    assert exists_as(os.path.dirname(__file__) + '_') == ''
    assert exists_as(os.path.dirname(__file__) + '_' + os.sep) == ''


# Generated at 2022-06-25 17:40:19.233739
# Unit test for function chmod
def test_chmod():
    chmod(Path(os.path.join(os.path.expanduser('~'), 'test.txt')), 0o660)
    os.remove('~/test.txt')


# Generated at 2022-06-25 17:40:28.023147
# Unit test for function path_absent
def test_path_absent():
    """Test path_absent function."""
    assert sys.version_info.major >= 3
    assert sys.version_info.minor >= 6

    cwd = Path(os.getcwd())
    paths = [
        cwd / 'tmp',
        cwd / 'tmp' / 'dir_0',
        cwd / 'tmp' / 'dir_0' / 'file_0',
        cwd / 'tmp' / 'dir_0' / 'file_1'
    ]


# Generated at 2022-06-25 17:40:32.127578
# Unit test for function chown
def test_chown():
    test_path = '/tmp/'
    chown(test_path, include_parent=True)
    test_path = '/tmp/'
    chown(test_path, '-1', '-1')


# Generated at 2022-06-25 17:40:42.129642
# Unit test for function chmod
def test_chmod():
    # Test case 0
    chmod("test_dir2/testdirA/testdir1/testdir2/testdir3", 0o777, 0o777)
    assert os.access("test_dir2/testdirA/testdir1/testdir2/testdir3", os.W_OK) == True and os.access("test_dir2/testdirA/testdir1/testdir2/testdir3", os.R_OK) == True and os.access("test_dir2/testdirA/testdir1/testdir2/testdir3", os.X_OK) == True
    chmod("test_dir2/testdirA/testdir1/testdir2/testdir3", 0o500, 0o500)



# Generated at 2022-06-25 17:40:44.743380
# Unit test for function chown
def test_chown():
    test_path = '/tmp/some_path_that_does_not_exist'
    chown(test_path)



# Generated at 2022-06-25 17:40:47.786059
# Unit test for function chown
def test_chown():    
    chown('~/tmp/**', user='foo', group='bar')
    return None


# Generated at 2022-06-25 17:40:55.753360
# Unit test for function path_absent
def test_path_absent():
    tmp_path = '~/tmp/test_path_absent'
    try:
        os.makedirs(normalize_path(tmp_path))
    except Exception as e:
        print('error:', e)
    else:
        print(tmp_path, 'created')
        path_absent(tmp_path)
        if os.path.exists(normalize_path(tmp_path)):
            print(tmp_path, 'not removed as expected')
        else:
            print(tmp_path, 'removed as expected')
    print()



# Generated at 2022-06-25 17:41:08.199281
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/bin') == 'directory'
    assert exists_as('/usr/bin') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/loop0') == 'block device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sdb') == 'block device'
    assert exists_as('/dev/sdc') == 'block device'