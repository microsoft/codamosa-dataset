

# Generated at 2022-06-25 17:31:57.596271
# Unit test for function find_paths
def test_find_paths():
    # Create a folder tree with test files
    dir_0 = directory_present('~/tmp/dir0')
    file_0 = dir_0.as_posix() + '/file0'
    fh_0 = open(file_0, 'w')
    fh_0.write('Hello\n')
    fh_0.write('World\n')
    fh_0.close()

    dir_1 = dir_0.as_posix() + '/dir1'
    os.mkdir(dir_1)
    file_1 = dir_1 + '/file1'
    fh_1 = open(file_1, 'w')
    fh_1.write('Hello\n')
    fh_1.write('World\n')
    fh_1.close()


# Generated at 2022-06-25 17:31:59.939569
# Unit test for function chmod
def test_chmod():
    test_path = '~/tmp/flutils.tests.osutils.txt'
    chmod(test_path, 0o666)
    stat_test_path = os.stat(test_path)
    if stat_test_path.st_mode & 0o400:
        return True
    else:
        return False


# Generated at 2022-06-25 17:32:03.447214
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths"""
    path = Path(__file__)
    paths = list(find_paths(path))
    assert len(paths) == 1
    assert paths[0].is_file() is True


# Generated at 2022-06-25 17:32:04.892020
# Unit test for function find_paths
def test_find_paths():
    pattern = '~/private/*test*'
    result = [i for i in find_paths(pattern)]
    print (result)


# Generated at 2022-06-25 17:32:10.319377
# Unit test for function chown
def test_chown():
    file_path = normalize_path('/tmp/foo/bar')
    try:
        os.makedirs(file_path, 0o755)
    except FileExistsError:
        pass
    try:
        os.chown(file_path, 8888, 8888)
    except FileNotFoundError:
        pass




# Generated at 2022-06-25 17:32:14.274203
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'
    path = Path(__file__).parent
    assert exists_as(path) == 'directory'


# Generated at 2022-06-25 17:32:23.320971
# Unit test for function chown
def test_chown():
    # Function should throw if neither user nor group are passed
    with pytest.raises(OSError):
        chown("~/")
    # Function should throw if chown fails
    with pytest.raises(OSError):
        chown("~/", user=-1, group=-1)
    # Function should set user and group to one of the current users
    # if they are not specified in parameters
    assert get_os_user(getpass.getuser()).pw_name == get_os_user().pw_name
    assert get_os_group(grp.getgrgid(os.getgid()).gr_name).gr_name == \
           get_os_group().gr_name



# Generated at 2022-06-25 17:32:27.484011
# Unit test for function find_paths
def test_find_paths():
    from pathlib import Path
    from typing import List, Tuple
    from flutils.pathutils import find_paths

    g = find_paths('~/tmp/')

    p = list(g)
    t = Tuple(p, Path)

    assert isinstance(p, List) is True  # type: ignore
    assert isinstance(p[0], Path) is True



# Generated at 2022-06-25 17:32:28.155961
# Unit test for function find_paths
def test_find_paths():
    # Test case 0
    find_paths('./tests/')



# Generated at 2022-06-25 17:32:39.249806
# Unit test for function chown
def test_chown():
    p = Path('/tmp/testdir')

    if p.exists():
        p.rmdir()

    p.mkdir()
    struct_group_0 = get_os_group()
    struct_group_1 = get_os_group(group=-1)
    struct_group_2 = get_os_group(group=struct_group_0.gr_gid)
    struct_group_3 = get_os_group(group=struct_group_0.gr_name)
    struct_group_4 = get_os_group(group=0)
    struct_group_5 = get_os_group(group='-1')
    struct_group_6 = get_os_group(group='all')
    struct_group_7 = get_os_group(group='0')


# Generated at 2022-06-25 17:33:07.286515
# Unit test for function exists_as
def test_exists_as():
    """Unit test for exists_as()."""
    path = Path().joinpath('tests', 'data', 'exists_as.txt')
    assert exists_as(path) == 'file'
    path = Path().joinpath('tests', 'data', 'not_there')
    assert exists_as(path) == ''


# Generated at 2022-06-25 17:33:17.002975
# Unit test for function chown
def test_chown():
    import shutil
    import tempfile
    import unittest
    import os

    def _ensure_file_ownership(file_path, expected_user, expected_group):
        stat_result = os.stat(file_path)
        assert stat_result.st_uid == expected_user.pw_uid, 'Wrong user'
        assert stat_result.st_gid == expected_group.gr_gid, 'Wrong group'

    def _ensure_dir_ownership(dir_path, expected_user, expected_group):
        stat_result = os.stat(dir_path, follow_symlinks=False)
        assert stat_result.st_uid == expected_user.pw_uid, 'Wrong user'

# Generated at 2022-06-25 17:33:22.647434
# Unit test for function path_absent
def test_path_absent():
    # Create a directory, file, and link that are temporary.
    test_path = Path(tempfile.mkdtemp())

    # Verify that the test path exists.
    assert os.path.exists(test_path)

    # Delete the test path.
    path_absent(test_path)

    # Verify the test path no longer exists.
    assert not os.path.exists(test_path)



# Generated at 2022-06-25 17:33:24.969338
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(sys.executable) == 'file'
    assert 'file' not in (exists_as("/tmp"), exists_as("/sru"), exists_as(""))


# Generated at 2022-06-25 17:33:28.816391
# Unit test for function exists_as
def test_exists_as():
    # Test passing a path that does not exist.
    assert exists_as('./foo/bar/baz') == ''

    # Test passing a path that exists as file.
    assert exists_as('./README.md') == 'file'

    # Test passing a path that exists as directory.
    assert exists_as('./flutils') == 'directory'



# Generated at 2022-06-25 17:33:30.006939
# Unit test for function chmod
def test_chmod():
    chmod(b'~/tmp/**', mode_file=0o644, mode_dir=0o770)


# Generated at 2022-06-25 17:33:37.641845
# Unit test for function chown
def test_chown():
    """Unit tests for chown function."""
    from tempfile import TemporaryDirectory
    from pathlib import Path

    test_dir = Path(TemporaryDirectory().name)

    # 1. Test with default (uid, gid)
    # 1.1 Test single path
    file_0 = test_dir / "flutils.test.file_0.txt"
    file_0.touch()
    chown(file_0)
    uid_1 = os.stat(file_0).st_uid
    gid_1 = os.stat(file_0).st_gid
    chown(file_0, include_parent=True)
    uid_2 = os.stat(file_0).st_uid
    gid_2 = os.stat(file_0).st_gid

# Generated at 2022-06-25 17:33:46.037998
# Unit test for function exists_as
def test_exists_as():
    # Get the current working directory
    cwd = Path().cwd()
    assert exists_as(cwd) == 'directory'
    assert exists_as(cwd/'setup.py') == 'file'
    assert exists_as(cwd/'does_not_exist.txt') == ''
    assert exists_as(cwd/'setup.py'/'foo.txt') == ''
    assert exists_as(cwd/'setup.py'/'..') == 'directory'
    assert exists_as(cwd/'.git') == ''
    assert exists_as(cwd/'.git'/'HEAD') == ''



# Generated at 2022-06-25 17:33:49.740438
# Unit test for function path_absent
def test_path_absent():
    test_dir = "/tmp/flutils_test_dir"
    if os.path.isdir(test_dir):
        path_absent(test_dir)
    os.makedirs(test_dir, 0o700)
    assert os.path.isdir(test_dir)
    path_absent(test_dir)
    assert not os.path.exists(test_dir)



# Generated at 2022-06-25 17:33:56.130782
# Unit test for function exists_as
def test_exists_as():
    # Testing directory paths
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/') == 'directory'
    assert exists_as('~/tmp/..') == 'directory'
    assert exists_as('~/tmp/../') == 'directory'
    assert exists_as('~/tmp/*') == ''
    assert exists_as('~/tmp/**') == ''

    # Testing file paths
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt/..') == 'directory'
    assert exists_as('~/tmp/*.txt') == ''

    #

# Generated at 2022-06-25 17:34:18.943937
# Unit test for function directory_present
def test_directory_present():
    user_0 = getpass.getuser()
    group_0 = grp.getgrgid(os.getgid()).gr_name

    dir_0 = directory_present('~/tmp/flutils.tests.pathutils.dir_0')
    assert dir_0.exists() is True
    assert dir_0.as_posix() == os.path.expanduser('~/tmp/flutils.tests.pathutils.dir_0')

    struct_stat_0 = os.stat(dir_0.as_posix())
    assert struct_stat_0.st_uid == pwd.getpwnam(user_0).pw_uid
    assert struct_stat_0.st_gid == grp.getgrnam(group_0).gr_gid

# Generated at 2022-06-25 17:34:23.543876
# Unit test for function path_absent
def test_path_absent():
    # Set up
    path = Path('~/tmp/test_path')
    path.mkdir()
    path.joinpath('test_file').touch()
    path.joinpath('test_dir').mkdir()
    path.joinpath('test_dir').joinpath('test_file').touch()
    path.joinpath('test_dir_2').mkdir()

    # Test
    path_absent(path)

    # Asserts
    try:
        assert not path.exists()
    except: raise
    finally:
        # Tear down
        if path.exists(): path.rmdir()


# Generated at 2022-06-25 17:34:33.408907
# Unit test for function chmod
def test_chmod():
    from os import chmod, getuid
    import stat

    file_path, mode_file_path, mode_dir_path = (
        Path.home() / 'tmp' / 'flutils.tests.osutils.tmp.txt',
        Path.home() / 'tmp' / 'flutils.tests.osutils.tmp',
        Path.home() / 'tmp' / 'flutils.tests.osutils.mode_dir_path',
    )

    # Set up tests
    chmod('~/tmp', 0o777)
    chmod('~/tmp/flutils.tests.osutils.tmp*', 0o777)
    file_path.touch()
    mode_dir_path.mkdir()
    mode_dir_path.chmod(0o700)

    # Set up tests that chown will not be called
   

# Generated at 2022-06-25 17:34:38.324147
# Unit test for function directory_present
def test_directory_present():
    p = directory_present('/tmp/flutils_test_directory_present/test')
    assert p.as_posix() == '/tmp/flutils_test_directory_present/test'
    assert p.is_dir()


# Generated at 2022-06-25 17:34:48.486309
# Unit test for function directory_present
def test_directory_present():
    try:
        directory_present('~/tmp/test_dir_pres_0')
    except FileExistsError as error:
        print('Error caught:', error)
    else:
        assert os.path.exists('/Users/len/tmp/test_dir_pres_0') is True
    directory_present('~/tmp/test_dir_pres_1')
    assert os.path.exists('/Users/len/tmp/test_dir_pres_1') is True
    try:
        directory_present('~/tmp/test_dir_pres_2')
    except FileExistsError as error:
        print('Error caught:', error)
    else:
        assert os.path.exists('/Users/len/tmp/test_dir_pres_2') is True

# Generated at 2022-06-25 17:34:54.114786
# Unit test for function directory_present
def test_directory_present():
    test_path = directory_present('~/tmp/flutils.tests.osutils.txt')
    test_path = directory_present('~/tmp/flutils.tests.osutils.txt')
    test_path = directory_present('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:35:01.187601
# Unit test for function chmod
def test_chmod():
    file_path = Path(__file__).parent
    file_path.joinpath('chmod.test').touch()
    chmod('chmod.test', 0o777)
    assert os.stat('chmod.test').st_mode & 0o777 == 0o777
    os.unlink('chmod.test')
    directory_path = Path(__file__).parent
    directory_path.joinpath('chmoddirtest').mkdir(mode=0o700)
    chmod('chmoddirtest', 0o777)
    assert os.stat('chmoddirtest').st_mode & 0o777 == 0o777
    os.rmdir('chmoddirtest')


# Generated at 2022-06-25 17:35:10.404127
# Unit test for function chmod
def test_chmod():
    file = "test.txt"
    tmp_dir = '/tmp'
    path = os.path.join(tmp_dir, file)
    with open(path, 'w+') as file_obj:
        file_obj.write('foo')
    chmod(path, mode_file=0o777, mode_dir=0o777)
    path = os.path.join(tmp_dir, file)
    assert os.path.isfile(path)
    os.remove(path)

# Generated at 2022-06-25 17:35:17.492327
# Unit test for function directory_present
def test_directory_present():
    # Test case 0
    normal_path = '~/tmp/test_path'
    expected_result = PosixPath('/Users/len/tmp/test_path')
    actual_result = directory_present(normal_path)
    try:
        assert actual_result == expected_result
    except:
        print('Test case 0 Failed')
        print('Expected:')
        print(expected_result)
        print('Actual:')
        print(actual_result)

    # Test case 1
    normal_path = '/tmp/test_path'
    expected_result = WindowsPath('/tmp/test_path')
    actual_result = directory_present(normal_path)
    try:
        assert actual_result == expected_result
    except:
        print('Test case 1 Failed')
        print('Expected:')


# Generated at 2022-06-25 17:35:24.585624
# Unit test for function chmod
def test_chmod():
    test_dir = Path('~/tmp/flutils.tests.osutils/').expanduser()
    test_txt = test_dir / 'chmod.txt'
    test_dir.mkdir(parents=True, exist_ok=True)
    test_txt.touch()
    chmod('~/tmp/flutils.tests.osutils/*', 0o660)
    assert test_txt.stat().st_mode & 0o777 == 0o660


# Generated at 2022-06-25 17:35:37.831297
# Unit test for function chmod
def test_chmod():
    chown('~/tmp/flutils.tests.osutils.txt', 'www-data', 'www-data')



# Generated at 2022-06-25 17:35:49.718209
# Unit test for function chown
def test_chown():
    """Test if a given path can be created.

    A path can be created if:

    - The parent directory exists
    - The `mode_dir` is valid for the parent directory
    - The `mode_file` is valid for the parent directory
    - The given `user` can write to the parent directory
    - The given `group` can write to the parent directory

    """

    # Test that a relative path is supported
    path = Path('flutils.tests.pathutils.txt')
    assert path.exists() is True
    assert path.parent.exists() is True

    stat_before = path.stat()
    chown(path, user='-1', group='-1')
    stat_after = path.stat()

    assert stat_before.st_uid == stat_after.st_uid
    assert stat_before.st

# Generated at 2022-06-25 17:35:57.376450
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from pathlib import Path

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    if path.exists():
        path.unlink()

    path.touch()
    assert path.exists() is True
    assert path.is_file() is True

    assert path.stat().st_mode & 0o777 == 0o600

    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660

    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660

    # parent directory
    # to which the file belongs
    path_parent = path.parent

    assert path_parent.stat().st_mode & 0o777 == 0

# Generated at 2022-06-25 17:36:02.668155
# Unit test for function directory_present
def test_directory_present():

    path = directory_present('/home/brit/directory_present_test')
    path_parent = path.parent
    assert(str(path.absolute()) == '/home/brit/directory_present_test')
    assert(str(path_parent.absolute()) == '/home/brit')
    print('passed unit tests')

test_directory_present()


# Generated at 2022-06-25 17:36:09.180880
# Unit test for function exists_as
def test_exists_as():
    test_path = Path('/tmp/foo')
    test_path.mkdir(mode=0o700, parents=True)

    # This will pass
    assert exists_as(test_path) == 'directory'

    test_path.rmdir()

    # This will pass
    assert exists_as(test_path) == ''


# Generated at 2022-06-25 17:36:10.993743
# Unit test for function path_absent
def test_path_absent():
    # Create a directory
    create_directory('test_path')
    path_absent('test_path')
    assert not os.path.exists('test_path')


# Generated at 2022-06-25 17:36:18.569444
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    uid = os.getuid()
    gid = os.getgid()
    path.touch()
    chown(path, uid, gid)
    path.chown(uid, gid)
    chown(path, user='-1', group='-1')
    path.chown(uid, gid)
    chown(path, user='-1', group=-1)
    path.chown(uid, gid)
    chown(path, user=-1, group='-1')
    path.chown(uid, gid)
    chown(path, user=-1, group=-1)
    path.chown(uid, gid)
    path.unlink()



# Generated at 2022-06-25 17:36:21.190566
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='bar')


# Generated at 2022-06-25 17:36:32.003000
# Unit test for function chown
def test_chown():
    # x = user name
    # y = group name
    x, y = getpass.getuser(), getpass.getuser()
    chown('test.text', x, y)
    assert Path('test.text').owner() == x
    assert Path('test.text').group() == y
    chown('test.text', -1, y)
    assert Path('test.text').owner() == x
    assert Path('test.text').group() == y
    chown('test.text', x, -1)
    assert Path('test.text').owner() == x
    assert Path('test.text').group() == y
    chown('test.text', -1, -1)
    assert Path('test.text').owner() == x
    assert Path('test.text').group() == y


# Generated at 2022-06-25 17:36:42.328979
# Unit test for function exists_as
def test_exists_as():
    # If path is not a string object the function normalize_path will raise
    # TypeError.
    try:
        exists_as(1)
    except TypeError:
        pass
    else:
        assert False,'Path should be a "str" or "bytes" or "pathlib.Path" object.'
    # If path is not a string object the function exists_as will raise
    # TypeError.
    try:
        exists_as(1)
    except TypeError:
        pass
    else:
        assert False,'Path should be a "str" or "bytes" or "pathlib.Path" object.'
    # If path is a valid string the function exists_as should return True
    assert exists_as("~/Documents") == 'directory'
    assert exists_as("~/Desktop") == 'directory'
    assert exists_as

# Generated at 2022-06-25 17:36:57.695750
# Unit test for function chmod
def test_chmod():
    path_to_test = Path('/tmp/flutils.tests/osutils.txt')
    path_to_test.write_text('This is a test of chmod')
    chmod(path_to_test, 0o600, 0o700)
    assert path_to_test.stat().st_mode == 0o100600


# Generated at 2022-06-25 17:36:58.559039
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-25 17:36:59.600937
# Unit test for function get_os_user
def test_get_os_user():
    pw_struct = get_os_user()
    assert pw_struct.pw_name == getpass.getuser()


# Generated at 2022-06-25 17:37:06.397030
# Unit test for function chmod
def test_chmod():
    from pathlib import Path
    from pathlib import PosixPath
    from typing import AnyStr
    import shutil
    import tempfile
    import unittest

    class Test_Chmod(unittest.TestCase):

        def setUp(self) -> None:
            self.test_dir = tempfile.TemporaryDirectory()
            self.test_dir_path = Path(self.test_dir.name)
            self.test_file_path = self.test_dir_path / 'flutils.tests.osutils.txt'
            self.test_file_path.touch()

        def test_case_0(self) -> None:
            chmod(self.test_dir_path)
            mode = self.test_dir_path.stat().st_mode
            self.assertEqual(mode, 0o40700)

# Generated at 2022-06-25 17:37:08.386661
# Unit test for function chown
def test_chown():
    assert chown('/Users/davidjnelson/tmp') == None



# Generated at 2022-06-25 17:37:18.564454
# Unit test for function chmod
def test_chmod():
    test_0 = '~/tmp/flutils.tests.osutils.txt'
    test_1 = '~/tmp/flutils.tests.osutils.txt'
    test_2 = '~/tmp/**'
    test_3 = '~/tmp/*'
    test_4 = '~/tmp/**'
    test_5 = '~/tmp/flutils.tests.osutils.txt'

    chmod(test_0)
    chmod(test_1, mode_file=0o660)
    chmod(test_2, mode_file=0o644, mode_dir=0o770)
    chmod(test_3)
    chmod(test_4, mode_file=0o644, mode_dir=0o770)

# Generated at 2022-06-25 17:37:28.594482
# Unit test for function chown
def test_chown():
    temp_path = normalize_path('/tmp/foo')
    root_uid = 0
    current_uid = get_os_user().pw_uid
    new_uid = pwd.getpwnam('daemon').pw_uid
    new_gid = grp.getgrnam('daemon').gr_gid
    if temp_path.exists():
        if temp_path.is_dir():
            temp_dir = temp_path
        else:
            temp_dir = temp_path.parent
        temp_dir.chown(current_uid, -1)
        temp_dir.chown(new_uid, -1)
        assert temp_dir.stat().st_uid == new_uid
        temp_dir.chown(-1, new_gid)
        assert temp_dir.stat().st

# Generated at 2022-06-25 17:37:39.990220
# Unit test for function chown
def test_chown():
    os.environ['USERNAME'] = 'user_1'
    group = get_os_group()
    group = group.gr_name
    chown('~/tmp/flutils.tests.osutils.txt', include_parent=True)
    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    info = os.stat(path)
    uid = info.st_uid
    gid = info.st_gid
    user = get_os_user(uid)
    user = user.pw_name
    #print('User: ' + user)
    #print('Group: ' + group)
    assert(user == 'user_1')
    assert(group == 'user_1')



# Generated at 2022-06-25 17:37:41.778099
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') is None


# Generated at 2022-06-25 17:37:51.604909
# Unit test for function chmod
def test_chmod():

    # Test if the function acts as expected
    def test_chmod_case_0():
        """
        Test if the function acts as expected
        """

        # Create a test path and use it as the argument
        path = Path(__file__)

        # Call the function
        chmod(path, mode_file=0o600)

        # Test if the path's mode is changed as expected
        assert path.stat().st_mode & 0o777 == 0o600

        # Test if the function raises the
        # correct exception if a path that
        # does not exist is passed as the argument
        with pytest.raises(FileNotFoundError):
            chmod('/tmp/flutils.tests.pathutils.txt')

    def test_chmod_case_1():
        """
        Test if the function acts as expected
        """

# Generated at 2022-06-25 17:38:11.265686
# Unit test for function exists_as
def test_exists_as():

    # Unit test for function exists_as using pathlib.Path objects
    pathlib_path = Path().home()
    assert exists_as(pathlib_path) == 'directory'
    assert exists_as(pathlib_path.joinpath('tmp')) == 'directory'
    assert exists_as(pathlib_path.joinpath('does_not_exist')) == ''

    # Unit test for function exists_as using strings
    pathlib_path = str(Path().home())
    assert exists_as(pathlib_path) == 'directory'
    assert exists_as(str(pathlib_path) + '/tmp') == 'directory'
    assert exists_as(str(pathlib_path) + '/does_not_exist') == ''

    # Unit test for function exists_as using bytes

# Generated at 2022-06-25 17:38:17.543625
# Unit test for function path_absent
def test_path_absent():
    """Test ensuring a path does NOT exist."""
    path = normalize_path('/tmp/foo')
    if path.exists():
        path.unlink()
    if path.exists():
        raise AssertionError('The path: %s should NOT exist.' % path.as_posix())
    path_absent('/tmp/foo')
    if path.exists():
        raise AssertionError('The path: %s should NOT exist.' % path.as_posix())



# Generated at 2022-06-25 17:38:24.771477
# Unit test for function directory_present
def test_directory_present():
    path = "~/tmp/directory"
    path = directory_present(path)
    print(path)
    print(exists_as(path))
    path = "~/tmp/directory/directory"
    path = directory_present(path)
    print(path)
    print(exists_as(path))

test_directory_present()


# Generated at 2022-06-25 17:38:33.674671
# Unit test for function chmod
def test_chmod():
    path_tmp = Path('/tmp/flutils.utils.test_osutils.chmod.txt')

    if path_tmp.exists():
        path_tmp.unlink()

    with open(path_tmp, 'w') as f_:
        f_.write('')
    path_tmp.chmod(0o400)
    mode = path_tmp.stat().st_mode & 0o777
    assert mode == 0o400
    chmod(path_tmp, 0o644)
    mode = path_tmp.stat().st_mode & 0o777
    assert mode == 0o644
    path_tmp.unlink()


# Generated at 2022-06-25 17:38:40.902531
# Unit test for function exists_as
def test_exists_as():
    path = Path('/tmp/foo') # noqa
    if path.exists():
        path.unlink()
    assert exists_as(path) == ''
    path.touch()
    assert exists_as(path) == 'file'
    path.unlink()
    assert exists_as(path) == ''
    path.mkdir()
    assert exists_as(path) == 'directory'
    path.rmdir()
    assert exists_as(path) == ''


# Generated at 2022-06-25 17:38:45.285194
# Unit test for function path_absent
def test_path_absent():
    if not os.path.isdir('/tmp/test_dir_01/test_dir_00'):
        os.mkdir('/tmp/test_dir_01/test_dir_00')
    for f in os.listdir('/tmp/test_dir_01'):
        print(f)
    path_absent('/tmp/test_dir_01')


# Generated at 2022-06-25 17:38:55.800248
# Unit test for function chmod
def test_chmod():
    # Test for setting mode on existing file
    # Check that the file currently has the correct permissions
    assert os.stat("tests/flutils/osutils/chmod.txt").st_mode & 511 != 0o660
    # Call function
    chmod("tests/flutils/osutils/chmod.txt", mode_file=0o660)
    # Check that the file now has the correct permissions
    assert os.stat("tests/flutils/osutils/chmod.txt").st_mode & 511 == 0o660
    # Reset permissions
    chmod("tests/flutils/osutils/chmod.txt", mode_file=0o600)
    # Check that the file now has the correct permissions
    assert os.stat("tests/flutils/osutils/chmod.txt").st_mode & 511 == 0o600

   

# Generated at 2022-06-25 17:39:02.775447
# Unit test for function directory_present
def test_directory_present():
    from flutils.osutils import user_exists_on_os as user_exists_on_os_orig
    from flutils.osutils import user_home_dir as user_home_dir_orig
    from flutils.osutils import user_primary_group_name as user_primary_group_name_orig

    def user_exists_on_os(*args, **kwargs):
        return True

    def user_home_dir(*args, **kwargs):
        return 'test'

    def user_primary_group_name(*args, **kwargs):
        return 'test_group'

    import flutils.osutils

    flutils.osutils.user_exists_on_os = user_exists_on_os
    flutils.osutils.user_home_dir = user_home_dir
    flutils

# Generated at 2022-06-25 17:39:03.988283
# Unit test for function chown
def test_chown():
    test_case_0()


# Generated at 2022-06-25 17:39:05.027091
# Unit test for function chown
def test_chown():
    chown('~/tmp/')


# Generated at 2022-06-25 17:39:27.396563
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('./test_data/t0_file.txt') == 'file'
    assert exists_as('./test_data/t0_dir') == 'directory'
    assert exists_as('./test_data/t0_bdev') == 'block device'
    assert exists_as('./test_data/t0_cdev') == 'char device'
    assert exists_as('./test_data/t0_fifo') == 'FIFO'
    assert exists_as('./test_data/t0_lnk_file.txt') == 'file'
    assert exists_as('./test_data/t0_lnk_dir') == 'directory'
    assert exists_as('./test_data/t0_lnk_bdev') == 'block device'
   

# Generated at 2022-06-25 17:39:30.321775
# Unit test for function exists_as
def test_exists_as():
    non_existing_path = 'foo'
    assert exists_as(non_existing_path) == ''

    existing_path = os.path.abspath(__file__)
    assert exists_as(existing_path) == 'file'

    os.makedirs('/tmp/flutils/foo')
    directory_path = '/tmp/flutils/foo'
    assert exists_as(directory_path) == 'directory'
    shutil.rmtree('/tmp/flutils')


# Generated at 2022-06-25 17:39:37.217442
# Unit test for function directory_present
def test_directory_present():
    # Create a directory with default parameters.
    path = directory_present(os.path.dirname(__file__) + '/../test_directory_present/test_case_0')
    assert exists_as(path) == 'directory'
    assert path.is_absolute()
    # Remove the directory.
    if os.path.exists(path):
        os.rmdir(path)
        assert exists_as(path) == ''
    else:
        assert False
    # Create a directory with custom parameters.
    path = directory_present(os.path.dirname(__file__) + '/../test_directory_present/test_case_1', 0o755, None, None)
    assert exists_as(path) == 'directory'
    assert path.is_absolute()
    # Remove the directory.

# Generated at 2022-06-25 17:39:40.924528
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/.local/share/flutils/test_file.txt')
    assert exists_as(path) == 'file'


# Generated at 2022-06-25 17:39:51.535963
# Unit test for function exists_as
def test_exists_as():
    with pytest.raises(FileExistsError) as excinfo:
        directory_present('/etc', user='foo', group='bar')

    assert excinfo.type == FileExistsError
    assert excinfo.value.args == (
        'The path: /etc can NOT be created as a directory because it '
        'already exists as a directory.',
    )

    with pytest.raises(FileExistsError) as excinfo:
        directory_present('flutils.tests.osutils.txt', user='foo', group='bar')

    assert excinfo.type == FileExistsError
    assert excinfo.value.args == (
        'The path: flutils.tests.osutils.txt can NOT be created as a '
        'directory because it already exists as a file.',
    )


# Generated at 2022-06-25 17:40:00.404703
# Unit test for function exists_as
def test_exists_as():
    struct_group_0 = get_os_group()
    struct_passwd_0 = get_os_user()
    
    # Test 1
    if exists_as('/tmp') != 'directory':
        print('Failure for Test 1')
    else:
        print('Success for Test 1')

    # Test 2
    if exists_as('{0}/tmp'.format(os.getcwd())) != 'directory':
        print('Failure for Test 2')
    else:
        print('Success for Test 2')

    # Test 3
    if exists_as('~/tmp') != 'directory':
        print('Failure for Test 3')
    else:
        print('Success for Test 3')
    
    # Test 4

# Generated at 2022-06-25 17:40:03.369779
# Unit test for function exists_as
def test_exists_as():
    # Test for directory
    assert exists_as('/tmp/') == 'directory'
    # Test for file
    assert exists_as('/etc/hosts') == 'file'


# Generated at 2022-06-25 17:40:13.159847
# Unit test for function exists_as
def test_exists_as():
    path = './tests/exists_as/test_dir/test_file'
    assert exists_as(path) == 'file'

    path = './tests/exists_as/test_dir'
    assert exists_as(path) == 'directory'

    path = './tests/exists_as'
    assert exists_as(path) == ''

    path = './'
    assert exists_as(path) == 'directory'

if __name__ == '__main__':
    test_exists_as()

# Generated at 2022-06-25 17:40:17.878591
# Unit test for function directory_present
def test_directory_present():
    TEST_DIRECTORY = '/tmp/foo'
    test_case_directory_path_0 = directory_present(TEST_DIRECTORY)
    test_case_directory_path_1 = directory_present('/var/empty')
    test_case_directory_path_2 = directory_present('/var/empty/foo')



# Generated at 2022-06-25 17:40:22.989958
# Unit test for function chmod
def test_chmod():
    path = 'test.txt'
    data = b'foo\n'
    mode_file = 0o661
    mode_dir = 0o711
    with open(path, 'wb') as stream:
        stream.write(data)
    chmod(path, mode_file, mode_dir)
    assert stat.S_IMODE(os.lstat(path).st_mode) == mode_file



# Generated at 2022-06-25 17:40:41.531511
# Unit test for function chmod
def test_chmod():
    import tempfile
    import os

    tmpdir = tempfile.mkdtemp()
    fname = os.path.join(tmpdir, "flutils.tests.pathutils.txt")
    with open(fname, "w") as f:
        f.write("")

    # check default permission
    assert os.stat(fname).st_mode == 33060

    # change permission
    chmod(fname, 0o660)
    assert os.stat(fname).st_mode == 33188

    os.remove(fname)
    os.rmdir(tmpdir)



# Generated at 2022-06-25 17:40:50.799313
# Unit test for function chown
def test_chown():
    assert callable(chown)
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as dir_0:
        # Create a normal user for testing.
        import subprocess
        p = subprocess.Popen(
            [
                'useradd',
                '--create-home',
                '--shell',
                '/bin/bash',
                'flutils_test_user'
            ],
            text=True
        )
        p.wait()

        # Get user and group infromation
        assert isinstance(get_os_group(), grp.struct_group)
        assert isinstance(get_os_group('flutils_test_user'), grp.struct_group)
        assert isinstance(get_os_group(os.getgid()), grp.struct_group)


# Generated at 2022-06-25 17:40:56.852246
# Unit test for function exists_as
def test_exists_as():
    struct_group_0 = get_os_group()
    struct_group_0_2 = get_os_group(struct_group_0.gr_name)
    struct_group_0_3 = get_os_group(struct_group_0.gr_gid)
    assert struct_group_0.gr_gid == struct_group_0_2.gr_gid
    assert struct_group_0.gr_gid == struct_group_0_3.gr_gid



# Generated at 2022-06-25 17:41:06.770531
# Unit test for function directory_present
def test_directory_present():
    d2 = directory_present('~/tmp/test_directory_present')
    d2.as_posix() == os.path.abspath(os.path.expanduser('~/tmp/test_directory_present'))
    print(os.path.abspath(os.path.expanduser('~/tmp/test_directory_present')))
    print(d2)
    print(d2.resolve())
    print(d2.as_posix())

    d2.exists()
    #d2.rmdir()


# Generated at 2022-06-25 17:41:08.597126
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('/tmp/my_dir') == PosixPath('/tmp/my_dir')



# Generated at 2022-06-25 17:41:15.044678
# Unit test for function exists_as
def test_exists_as():
    path_posix = '/tmp/flutils.tests.osutils.txt'
    path_exists = Path(path_posix)
    path_not_exist = '/tmp/flutils.tests.osutils.does_not_exist'
    if not path_exists.exists():
        path_exists.touch()
    assert exists_as(path_posix) == 'file'
    try:
        exists_as(path_not_exist)
    except FileNotFoundError:
        assert True
    else:
        assert False
