

# Generated at 2022-06-25 17:31:51.784993
# Unit test for function exists_as

# Generated at 2022-06-25 17:31:57.422664
# Unit test for function find_paths
def test_find_paths():
    pattern_0: _PATH = Path('/home/test_user/tmp/*')
    pattern_0_list: List[Path] = list(find_paths(pattern_0))
    pattern_0_list_expected = [Path('/home/test_user/tmp/file_one'), Path('/home/test_user/tmp/dir_one')]
    assert pattern_0_list == pattern_0_list_expected, 'Failed test_case_0'


# Generated at 2022-06-25 17:32:04.057736
# Unit test for function find_paths
def test_find_paths():
    """Find all paths that match the given :term:`glob pattern`.
    """
    result = find_paths('~/tmp')
    assert type(result) is generator
    assert tuple(result) == (PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one'))
    result = find_paths('/tmp/*')
    assert type(result) is generator
    assert tuple(result) == tuple()


# Generated at 2022-06-25 17:32:10.820956
# Unit test for function chown
def test_chown():
    # Remove if a file exists
    path = Path(__file__).parent.joinpath('test.txt')
    if path.is_file():
        path.unlink()
    # Create a file
    path.touch()
    # Test the default
    chown(path)
    # Set the uid and gid for the current user
    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(getpass.getuser()).pw_gid).gr_name
    chown(path, user=user, group=group)
    # Remove the file
    path.unlink()

    # Create a file again
    path.touch()
    # Test when user and group is -1
    chown(path, user='-1', group='-1')
    #

# Generated at 2022-06-25 17:32:15.609470
# Unit test for function directory_present
def test_directory_present():
    struct_passwd_0 = get_os_user()
    d = directory_present('~/tmp/dir_present', user=struct_passwd_0.pw_name, group="everyone")
    # d.exists() and d.is_dir()


# Generated at 2022-06-25 17:32:18.847444
# Unit test for function exists_as
def test_exists_as():
    path = Path('.')
    assert exists_as(path) == 'directory'

    path = Path(__file__)
    assert exists_as(path) == 'file'



# Generated at 2022-06-25 17:32:24.931287
# Unit test for function find_paths
def test_find_paths():
    pattern = '/tmp/*'
    search_paths = list(find_paths(pattern))
    # print(search_paths)
    # Test if returned value is generator
    assert isinstance(find_paths(pattern), types.GeneratorType)
    # Test if returned value is pathlib path object
    assert isinstance(search_paths[0], Path)
    # Test if function accepts pathlib path object
    assert isinstance(find_paths(Path(pattern)), types.GeneratorType)


# Generated at 2022-06-25 17:32:29.698931
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/tmp') == 'directory'
    assert exists_as(Path('~/tmp')) == 'directory'
    assert exists_as('/etc/login.defs') == 'file'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/urandom') == 'block device'
    assert exists_as('/dev/random') == 'block device'
    assert exists_as('/dev/zero') == 'character device'
    assert exists_as('/dev/full') == 'character device'
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/etc/shadow') == ''


# Generated at 2022-06-25 17:32:30.331319
# Unit test for function find_paths
def test_find_paths():
    assert find_paths('/Users/len/tmp')



# Generated at 2022-06-25 17:32:34.365241
# Unit test for function find_paths
def test_find_paths():
    data_dir = Path('~/test_data_dir').expanduser()
    test_dir = data_dir / 'test_dir'
    test_dir.mkdir(mode=0o700,parents=True,exist_ok=True)
    test_dir_b = test_dir / 'test_dir_b'
    test_dir_b.mkdir(mode=0o700,parents=True,exist_ok=True)
    test_file_a = Path(test_dir / 'test_file_a.txt')
    test_file_a.touch(mode=0o600)
    test_file_b = Path(test_dir / 'test_file_b.txt')
    test_file_b.touch(mode=0o600)

# Generated at 2022-06-25 17:32:50.493921
# Unit test for function path_absent
def test_path_absent():
    path_a = Path('/tmp/test_path_absent')
    path_absent(path_a)


# Generated at 2022-06-25 17:32:57.673033
# Unit test for function directory_present
def test_directory_present():
    import os, stat, sys
    from pathlib import Path
    user = getpass.getuser()
    directory = Path("~/new_directory")
    assert directory == directory_present(directory), "Expected to return a Path object, which doesn't happen"
    directory = Path("~/new_directory")
    assert str(directory) == str(directory_present(directory)), "Expected to return a Path object, which doesn't happen"


# Generated at 2022-06-25 17:33:06.080891
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    test_uid_0 = struct_passwd_0.pw_uid
    test_gid_0 = struct_passwd_0.pw_gid
    test_path_0 = Path('file_0')
    Path(test_path_0).touch()
    test_path_1 = Path('file_1')
    Path(test_path_1).touch()
    chown('file_*',user=test_uid_0,group=test_gid_0)
    chown(test_path_0,user=test_uid_0,group=test_gid_0)
    chown(test_path_1,user=test_uid_0,group=test_gid_0)



# Generated at 2022-06-25 17:33:10.934409
# Unit test for function chown
def test_chown():
    test_path = Path(test_case_0())
    chown(test_path)
    chown(test_path, '-1')
    chown(test_path, user='-1')
    chown(test_path, user=get_os_user())


# Generated at 2022-06-25 17:33:12.552685
# Unit test for function chmod
def test_chmod():
    chmod('path/file', 0o600)


# Generated at 2022-06-25 17:33:16.209857
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-25 17:33:24.606649
# Unit test for function chmod
def test_chmod():
    # Test 0
    # Function to test chmod
    # Usage: chmod(path, mode_file=None, mode_dir=None, include_parent=False)
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    os.chdir('../../')
    path_for_test = 'ansible_collections/flutils/tests/files/chmod.txt'
    chmod(path_for_test, 0o755)
    tmpfile = Path(path_for_test)
    assert tmpfile.is_file()
    assert oct(tmpfile.stat().st_mode & 0o777) == '0o755'



# Generated at 2022-06-25 17:33:28.743327
# Unit test for function chown
def test_chown():
    chown("~/flutils/tests/test_dir", "nobody", "nogroup")
    struct_passwd = get_os_user("nobody")
    struct_group = get_os_group("nogroup")
    chown("~/flutils/tests/test_dir", struct_passwd.pw_uid, struct_group.gr_gid)


# Generated at 2022-06-25 17:33:30.181152
# Unit test for function chown
def test_chown():
    # Setup
    import flutils.pathutils as pathutils
    pathutils.chown('/tmp/hello', user='root', group='root')


# Generated at 2022-06-25 17:33:32.431514
# Unit test for function path_absent
def test_path_absent():
    """
    Unit test for function path_absent
    """
    test_dir_absent = Path("/tmp/test_dir")
    normalize_path(test_dir_absent)
    path_absent(test_dir_absent)
    assert test_dir_absent.exists() == False

# Generated at 2022-06-25 17:33:50.212744
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/bin/python') == 'file'
    assert exists_as('/dev/random') == 'block device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('~/bin') == 'directory'
    assert exists_as('~/bin/foo.d') == ''
    assert exists_as('~test_dir') == ''


# Generated at 2022-06-25 17:34:02.471081
# Unit test for function path_absent
def test_path_absent():
    _basedir = '/tmp/test_flutils_pathutils_path_absent.tmp.d'
    _path = Path(_basedir)
    # remove any previous run test data
    path_absent(_path)
    # create a directory tree
    _path.mkdir(mode=0o700, parents=True)
    (_path / 'file0').touch(mode=0o700)
    (_path / 'file1').touch(mode=0o700)
    _path2 = _path / 'dir0'
    _path2.mkdir(mode=0o700, parents=False)
    (_path2 / 'file2').touch(mode=0o700)
    (_path2 / 'file3').touch(mode=0o700)
    path_absent(_path)
    assert not _path.exists()

# Generated at 2022-06-25 17:34:04.397396
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:34:08.357998
# Unit test for function exists_as
def test_exists_as():
    path = Path('/tmp')
    path = normalize_path(path)
    assert exists_as(path) == 'directory'
    path = Path('/tmp/foo/bar')
    path = normalize_path(path)
    assert exists_as(path) == ''


# Generated at 2022-06-25 17:34:18.944976
# Unit test for function path_absent
def test_path_absent():
    tmpdir = None

# Generated at 2022-06-25 17:34:21.545232
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.osutils.txt', user='-1', group='-1')


# Generated at 2022-06-25 17:34:24.749992
# Unit test for function chown
def test_chown():
    chown(
        './tmp/', user='-1', group='-1')
# end function test_chown


# Generated at 2022-06-25 17:34:34.142856
# Unit test for function directory_present

# Generated at 2022-06-25 17:34:43.671120
# Unit test for function chmod
def test_chmod():
    # Setup test data
    path = 'test_file'
    fd = open(path, 'w')
    fd.close()
    mode_file = 0o600
    mode_dir = 0o700
    include_parent = False

    # Execute the code being tested
    try:
        chmod(path, mode_file, mode_dir, include_parent)
    finally:
        # Clean up
        try:
            os.remove(path)
        except OSError as e:
            if e.errno != os.errno.ENOENT:
                raise


# Generated at 2022-06-25 17:34:52.241088
# Unit test for function chmod
def test_chmod():
    path = Path('./README.rst')
    assert path.exists() is True
    assert path.is_file() is True
    assert path.is_dir() is False
    assert path.stat().st_mode == 33206
    chmod(path, 0o600, 0o700)
    assert path.stat().st_mode == 33430
    chmod(path, 0o640, 0o750)
    assert path.stat().st_mode == 33454



# Generated at 2022-06-25 17:35:38.211047
# Unit test for function chmod
def test_chmod():
    test_dir = 'tmpdir_for_tests'

    if os.path.exists(test_dir) is False:
        os.mkdir(test_dir)

    mode_dir = 0o700
    mode_file = 0o660
    test_file = os.path.join(test_dir, 'test_file_chmod')

    if os.path.exists(test_file):
        os.remove(test_file)

    with open(test_file, 'w') as f:
        f.write('test_file_chmod')

    os.chmod(test_file, mode_file)
    assert os.stat(test_file).st_mode & 0o777 == mode_file

    chmod(test_file, mode_file + 1, mode_dir - 1)
    assert os.stat

# Generated at 2022-06-25 17:35:42.488458
# Unit test for function chown
def test_chown():
    try:
        os.remove('test.txt')
    except FileNotFoundError:
        pass
    open('test.txt', 'w').close()
    chown('test.txt')
    os.remove('test.txt')


# Generated at 2022-06-25 17:35:51.625260
# Unit test for function chmod
def test_chmod():
    import tempfile
    import pytest
    import os

    tmp_fd, tmp_path = tempfile.mkstemp()
    os.close(tmp_fd)
    test_chmod.tmp_path = tmp_path
    test_chmod.test_values = {
        'test_case_0': {
            'path': '~/tmp/flutils.tests.osutils.txt',
            'mode_file': 0o660,
            'mode_dir': 0o770,
            'include_parent': False
        }
    }
    for key, value in test_chmod.test_values.items():
        yield chmod_test, key, value


# Generated at 2022-06-25 17:35:54.036610
# Unit test for function chmod
def test_chmod():
    # Test case for chmod:
    chmod('~/tmp/**', mode_file= 0o644, mode_dir=0o770)


# Generated at 2022-06-25 17:35:58.602172
# Unit test for function path_absent
def test_path_absent():
    test_path = normalize_path("/tmp")
    path_absent(test_path)
    assert not os.path.exists(test_path)

# Unit test function to test function exists_as

# Generated at 2022-06-25 17:36:06.552796
# Unit test for function chown
def test_chown():
    '''
    Test function chown
    '''
    chown_parent_recursive = functools.partial(chown,include_parent=True)
    chown_parent_norecursive = functools.partial(chown, include_parent=False)

    chown_parent_recursive('/tmp/foobar_not_exist',group='bar',user='foo')
    chown_parent_norecursive('/tmp/foobar_not_exist', group='bar', user='foo')
    chown_parent_recursive('/tmp/foobar', group='bar', user='foo')
    chown_parent_norecursive('/tmp/foobar', group='bar', user='foo')
    chown_parent_recursive('/tmp/foobar/*', group='bar', user='foo')


# Generated at 2022-06-25 17:36:17.450014
# Unit test for function directory_present
def test_directory_present():
    # Make sure the directory is empty before running the test.
    from flutils.tests.osutils import tmp_dir
    tmp_dir.cleanup()

    # Create a directory using directory_present.
    new_dir = directory_present(
        Path('~/tmp/test_path'),
        mode=0o770,
        user=getpass.getuser(),
        group=grp.getgrgid(os.getgid()).gr_name
    )
    assert exists_as(new_dir) == 'directory'
    assert new_dir.is_dir() is True
    assert new_dir.is_symlink() is False
    assert new_dir.is_socket() is False
    assert new_dir.is_fifo() is False
    assert new_dir.is_block_device() is False
   

# Generated at 2022-06-25 17:36:29.622048
# Unit test for function chmod
def test_chmod():
    # test_case_0:
    test_path = normalize_path('/tmp/test_chmod_0')
    if test_path.exists():
        os.remove(test_path)
    test_path.open('x').close()
    assert test_path.is_file() is True
    assert test_path.stat().st_mode & 0o777 == 0o600
    # test_case_1:
    test_path.chmod(0o660)
    assert test_path.stat().st_mode & 0o777 == 0o660
    # test_case_3:
    chmod(test_path, 0o664)
    assert test_path.stat().st_mode & 0o777 == 0o664
    # test_case_4:
    test_path.unlink()


# Generated at 2022-06-25 17:36:35.399250
# Unit test for function exists_as
def test_exists_as():
    path = Path('~/tmp/flutils.tests.osutils.txt')
    assert exists_as(path) == 'file'
    path.unlink()
    assert exists_as(path) == ''


# Generated at 2022-06-25 17:36:41.927069
# Unit test for function chmod
def test_chmod():
    if not os.path.isdir('./test'):
        os.mkdir('./test')
    f0 = open('./test/f0', 'w')
    f1 = open('./test/f1', 'w')
    f2 = open('./test/f2', 'w')
    d0 = open('./test/d0', 'w')
    d1 = open('./test/d1', 'w')
    d2 = open('./test/d2', 'w')
    chmod('./test', 0o111, 0o222, include_parent=True)


# Generated at 2022-06-25 17:36:53.039415
# Unit test for function get_os_user
def test_get_os_user():
    test_case_0()


# Generated at 2022-06-25 17:36:56.760950
# Unit test for function chown
def test_chown():
    path = '/Users/hans/notes/blubber'
    chown(path, user='hans', group='staff')
    print()
    return


# Generated at 2022-06-25 17:37:00.172858
# Unit test for function get_os_user
def test_get_os_user():
    # Test a valid login name
    assert isinstance(get_os_user('len'), pwd.struct_passwd)
    
    # Test a valid uid
    assert isinstance(get_os_user(1001), pwd.struct_passwd)
    
    # Test an invalid login name
    with pytest.raises(OSError):
        assert isinstance(get_os_user('not_a_login_name'), pwd.struct_passwd)

    # Test an invalid uid
    with pytest.raises(OSError):
        assert isinstance(get_os_user(-100), pwd.struct_passwd)


# Generated at 2022-06-25 17:37:01.270556
# Unit test for function chown
def test_chown():
    chown('/tmp/test_chown.txt')


# Generated at 2022-06-25 17:37:04.791158
# Unit test for function path_absent
def test_path_absent():
    d = '~/tmp/test_path_0'
    path_present(d)
    assert exists_as(d) != ''
    path_absent(d)
    assert exists_as(d) == ''


# Generated at 2022-06-25 17:37:15.977926
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory to work within.
    with tempfile.TemporaryDirectory() as tempdir:
        path = Path(tempdir) / 'path'
        path.touch()
        # Call the path_absent function to have it remove the file.
        path_absent(path)
        path = path.resolve()
        # Check to make sure the file was removed.
        assert path.exists() is False

        path = Path(tempdir) / 'path'
        path.mkdir()
        (path / 'file').touch()
        (path / 'dir').mkdir()
        # Call the path_absent function to have it remove the directory.
        path_absent(path)
        path = path.resolve()
        # Check to make sure the directory was removed.
        assert path.exists() is False



# Generated at 2022-06-25 17:37:21.009281
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    directory_present(str(path.parent))
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert path.parent.stat().st_mode & 0o777 == 0o660


# Generated at 2022-06-25 17:37:23.971614
# Unit test for function directory_present
def test_directory_present():
    try:
        test_dir = Path(os.path.dirname(os.path.realpath(__file__)), "test_output")
        test_dir.mkdir(exist_ok=True)
        test_file = Path(test_dir, "test_directory_present.test")

        directory_present(test_file)
        if test_file.is_dir():
            return True
        else:
            return False
    except Exception as e:
        print(e)
        return False



# Generated at 2022-06-25 17:37:25.301166
# Unit test for function chmod
def test_chmod():
    chmod('a.txt', 0o600)
    


# Generated at 2022-06-25 17:37:30.771994
# Unit test for function chmod
def test_chmod():
    # Sample input
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o660
    mode_dir = 0o770
    # Expected output
    expected_path = '/home/benjaminkoenig/tmp/flutils.tests.osutils.txt'

    # Run the function
    chmod(path, mode_file, mode_dir)

    # Check the output
    assert path == expected_path

    return True

test_case_1 = test_chmod()



# Generated at 2022-06-25 17:37:49.483951
# Unit test for function exists_as
def test_exists_as():
    # Exists and is a directory
    assert exists_as('/usr/bin') == 'directory'

    # Exists and is a file
    assert exists_as('/etc/profile') == 'file'

    # Exists and is a block device
    assert exists_as('/dev/sda2') == 'block device'

    # Exists and is a character device
    assert exists_as('/dev/tty0') == 'char device'

    # Exists and is a FIFO
    assert exists_as('/dev/fd') == 'FIFO'

    # Does NOT exist
    assert exists_as('/usr/does_not_exist') == ''



# Generated at 2022-06-25 17:37:50.126348
# Unit test for function chmod
def test_chmod():
    test_case_0()



# Generated at 2022-06-25 17:37:59.492673
# Unit test for function chown
def test_chown():
    if sys.platform == 'win32':
        path = 'c:\\temp\\temp.txt'
        chown(path)
        mode = os.stat(path).st_mode
        assert oct(mode)[-3:] == '660'
        os.remove(path)
    else:
        path = '/tmp/temp.txt'
        chown(path)
        mode = os.stat(path).st_mode
        assert oct(mode)[-3:] == '600'
        os.remove(path)


# Generated at 2022-06-25 17:38:09.836632
# Unit test for function directory_present
def test_directory_present():

    path = directory_present(os.getcwd())
    assert(path == Path(os.getcwd()))

    path = directory_present(os.path.join(os.getcwd(), 'tmp/foo/bar/baz'))
    assert(path == Path(os.path.join(os.getcwd(), 'tmp/foo/bar/baz')))

    path = directory_present(os.path.join(os.getcwd(), 'tmp/foo/bar'))
    assert(path == Path(os.path.join(os.getcwd(), 'tmp/foo/bar')))

    path = directory_present(os.path.join(os.getcwd(), 'tmp/foo'))
    assert(path == Path(os.path.join(os.getcwd(), 'tmp/foo')))



# Generated at 2022-06-25 17:38:19.240203
# Unit test for function chmod
def test_chmod():
    print('Testing function chmod...', end='')
    # CASE 0: {
    #   'path': '~/tmp/flutils.tests.osutils.txt',
    #   'mode': 0o660
    # }
    check_val = normalize_path(
        '~/tmp/flutils.tests.osutils.txt'
    )
    check_ok = (
        check_val.owner() == 'root'
        and check_val.group() == 'wheel'
        and check_val.stat().st_mode == 33204
    )
    assert check_ok is True

    struct_passwd_0 = get_os_user()

    chmod(
        '~/tmp/flutils.tests.osutils.txt',
        0o660,
        include_parent=True
    )



# Generated at 2022-06-25 17:38:30.499817
# Unit test for function chmod
def test_chmod():
    import os
    import stat

    def get_mode(path):
        mode = path.stat(follow_symlinks=False).st_mode
        if os.name == "posix":
            return stat.S_IMODE(mode)
        else:
            return mode

    import tempfile
    tmpdir = tempfile.TemporaryDirectory()
    tmpdir_path = Path(tmpdir.name)
    file_0_path = tmpdir_path.joinpath("file_0.txt")
    file_1_path = tmpdir_path.joinpath("file_1.txt")
    dir_1_path = tmpdir_path.joinpath("dir_1")

    with file_0_path.open("x") as fd:
        fd.write("file_0")


# Generated at 2022-06-25 17:38:37.456172
# Unit test for function path_absent
def test_path_absent():
    # Test that it deletes a directory.
    path_absent('/tmp/foo')
    assert os.path.exists('/tmp/foo') is False

    # Test that it deletes a file.
    path_absent('/tmp/bar')
    assert os.path.exists('/tmp/bar') is False

    # Test that it deletes a symlink.
    path_absent('/tmp/baz')
    assert os.path.exists('/tmp/baz') is False

    # Test that it does not delete something that is not present.
    path_absent('/tmp/baz')
    assert os.path.exists('/tmp/baz') is False
    path_absent('/tmp/foo')
    assert os.path.exists('/tmp/foo') is False


# Generated at 2022-06-25 17:38:40.368218
# Unit test for function chmod
def test_chmod():
    """Test chmod()"""

    print()
    print('*** chmod()')

    test_case_0()
    print()
    print('(Passed)')
    print()



# Generated at 2022-06-25 17:38:52.066386
# Unit test for function directory_present
def test_directory_present():
    """
    Test directory_present. Make sure that a directory is created, and
    chown/chmod are called on it
    """
    with mock.patch('os.chmod') as mock_chmod:
        with mock.patch('os.chown') as mock_chown:
            with mock.patch('shutil.chown') as mock_shutil_chown:
                test_dir = directory_present('/tmp/test_dir')
                mock_chmod.assert_called_once_with(
                    '/tmp/test_dir',
                    0o700
                )
                mock_chown.assert_called_once_with(
                    '/tmp/test_dir',
                    get_os_user().pw_uid,
                    os.getgid()
                )
                mock_shutil_chown.assert_

# Generated at 2022-06-25 17:38:53.511451
# Unit test for function get_os_user
def test_get_os_user():
    expected_type = typing.Union[pwd.struct_passwd, None]
    actual_type = test_case_0()
    assert isinstance(actual_type, expected_type)



# Generated at 2022-06-25 17:39:14.859673
# Unit test for function chmod
def test_chmod():
    print('Testing chmod() ...')
    # Create temporary file
    try:
        f = open('tmp.txt', 'w')
        f.write('Hello World')
        f.close()
        # Get pathname and check access to file
        path = Path('tmp.txt')
        access = path.stat().st_mode & 0o777
        assert access == 0o600
        chmod('tmp.txt', 0o666)
        # Get pathname and check access to file
        path = Path('tmp.txt')
        access = path.stat().st_mode & 0o777
        assert access == 0o666

    finally:
        if os.path.exists('tmp.txt'):
            os.remove('tmp.txt')



# Generated at 2022-06-25 17:39:27.214761
# Unit test for function chown
def test_chown():
    os.mkdir('/tmp/t0')
    os.mkdir('/tmp/t0/t1')
    os.mkdir('/tmp/t0/t1/t2')
    os.mknod('/tmp/t0/t1/t2/t3')
    os.mknod('/tmp/t0/t1/t2/t4')
    chown('/tmp/t0', user='root')
    chown('/tmp/t0/t1/**', user='root')
    chown('/tmp/t0/t1/*')
    os.remove('/tmp/t0/t1/t2/t3')
    os.remove('/tmp/t0/t1/t2/t4')

# Generated at 2022-06-25 17:39:35.803619
# Unit test for function chown
def test_chown():
    #os.getcwd()
    #os.chdir("/")
    pwd = os.getcwd()
    print(pwd)

    import os
    import stat
    import pwd
    import grp
    # Get the uid/gid from the current user name
    user = pwd.getpwnam("nobody")
    user_uid = user.pw_uid
    user_gid = user.pw_gid
    #path = ""
    path = pwd
    print("Setting owner:group to {0}:{1}".format(user_uid, user_gid))
    os.chown(path, user_uid, user_gid)
    # Set the group id bit
    os.chmod(path, stat.S_ISGID | 0o711)
   

# Generated at 2022-06-25 17:39:40.753034
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')


# Generated at 2022-06-25 17:39:44.517650
# Unit test for function chmod
def test_chmod():
    chmod('~/git/flutils/flutils/tests/fixtures/test.txt', 0o444)
    chmod('~/git/flutils/flutils/tests/fixtures/test.txt', 0o644)


# Generated at 2022-06-25 17:39:45.909284
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')



# Generated at 2022-06-25 17:39:55.924817
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import time
    import shlex
    from subprocess import check_call
    from tempfile import TemporaryDirectory

    # Create a temp directory.
    tmp_0 = TemporaryDirectory(prefix='tmp_')
    tmp_1 = Path(tmp_0.name)
    path_0 = tmp_1 / 'test_path'
    path_0.mkdir(mode=0o700)
    path_0 = path_0.resolve()
    dir_0 = path_0 / 'dir_0'
    link_0 = path_0 / 'link_0'
    file_0 = dir_0 / 'file_0'
    path_1 = path_0 / 'path_1'
    dir_1 = path_0 / 'dir_1'
    link_1 = path_

# Generated at 2022-06-25 17:39:59.227784
# Unit test for function chmod
def test_chmod():
    test_file = '/tmp/flutils.tests.pathutils.chmod.txt'
    with open(test_file, 'w') as f:
        pass
    chmod(test_file, mode_file=0o660)
    os.unlink(test_file)


# Generated at 2022-06-25 17:40:11.819125
# Unit test for function chown
def test_chown():
    file_path = '/tmp/foo.txt'
    directory_path = '/tmp/foo/'

    if os.path.exists(file_path):
        os.remove(file_path)
    if os.path.exists(directory_path):
        os.rmdir(directory_path)

    assert not os.path.exists(file_path)
    assert not os.path.exists(directory_path)

    os.system('touch {}'.format(file_path))
    os.system('mkdir {}'.format(directory_path))

    assert os.path.exists(file_path)
    assert os.path.exists(directory_path)

    # test chown on existing file/directory
    chown(file_path, user=getpass.getuser())
    struct_passwd_0

# Generated at 2022-06-25 17:40:17.831482
# Unit test for function path_absent
def test_path_absent():

    # create a dummy file in a temporary directory
    with tempfile.TemporaryDirectory() as td:
        filename = os.path.join(td, 'test_file')
        with open(filename, 'w') as f:
            f.write('Test\n')

        assert os.path.isfile(filename)

        # Now, test the meta function
        path_absent(filename)
        assert not os.path.isfile(filename)

# Generated at 2022-06-25 17:40:40.271173
# Unit test for function chown
def test_chown():
    tst_fqsp = '.' + '/tests/unit/flutils/pathutils/tst_chown.txt'
    chown(tst_fqsp) # Run chown on the test file
    pwd_struct = pwd.getpwuid(os.getuid()) # Extract user info
    grp_struct = grp.getgrgid(os.getgid()) # Extract group info
    tst_stat = os.stat(tst_fqsp)            # Extract file info
    tst_stat_du = tst_stat.st_uid           # Extract owner field
    tst_stat_dg = tst_stat.st_gid           # Extract group field
    assert (tst_stat_du == pwd_struct.pw_uid) # Compare uid

# Generated at 2022-06-25 17:40:43.047124
# Unit test for function directory_present
def test_directory_present():

    x = directory_present('/Users/len/flutils/tests/tmp/test1')
    print("Returned value: ", x)



# Generated at 2022-06-25 17:40:46.769283
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o660

    chmod(path, mode_file)


# Generated at 2022-06-25 17:40:52.027659
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    mode_file = 0o666
    chmod(path, mode_file=mode_file)
    assert path.lstat().st_mode & 0b111111111 == mode_file



# Generated at 2022-06-25 17:40:56.246297
# Unit test for function chown
def test_chown():
    chown('./tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:40:59.579341
# Unit test for function chmod
def test_chmod():
    chmod(
        "~/tmp/flutils.tests.osutils.txt",
        mode_file=0o444,
        mode_dir=0o777
    )


# Generated at 2022-06-25 17:41:02.376039
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')


# Generated at 2022-06-25 17:41:13.236325
# Unit test for function exists_as
def test_exists_as():

    CHARS = string.ascii_letters + string.digits + '_'
    t = tempfile.TemporaryDirectory()