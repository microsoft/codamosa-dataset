

# Generated at 2022-06-25 17:31:50.896030
# Unit test for function chown
def test_chown():
    if not os.path.exists("/tmp/flutils.tests.osutils.txt"):
        open("/tmp/flutils.tests.osutils.txt", "w").close()
    chown("/tmp/flutils.tests.osutils.txt", user='root', group='root')
    os.chmod("/tmp/flutils.tests.osutils.txt", 0o777)
    # print("pw_uid = " + str(struct_passwd_0.pw_uid))
    # print("gr_gid = " + str(struct_passwd_0.gr_gid))
    os.chown("/tmp/flutils.tests.osutils.txt", struct_passwd_0.pw_uid, struct_passwd_0.gr_gid)



# Generated at 2022-06-25 17:32:00.737389
# Unit test for function chmod
def test_chmod():
    import shutil

    path_0 = Path() / 'tmp/flutils.tests/pathutils/osutils/chmod/file_0.txt'
    path_1 = Path() / 'tmp/flutils.tests/pathutils/osutils/chmod/dir_0'
    path_2 = Path() / 'tmp/flutils.tests/pathutils/osutils/chmod/dir_1'
    path_to_copy = Path() / 'tmp/flutils.tests/pathutils/osutils/chmod/dir_0/file_1.txt'
    path_3 = Path() / 'tmp/flutils.tests/pathutils/osutils/chmod/dir_1/file_1.txt'

    dir_path_0 = path_0.parent
    dir_path_1 = path_1.parent
    dir

# Generated at 2022-06-25 17:32:03.632641
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils/tests/osutils.txt', 0o660)
    # Supports a :term:`glob pattern`.  So to recursively change the mode
    # of a directory just do:
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    # To change the mode of a directory's immediate contents:
    chmod('~/tmp/*')


# Generated at 2022-06-25 17:32:08.626319
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod
    for test case 1:
        path is invalid
        mode_file is 630
        mode_dir is 740
        include_parent is True
    expected result:
        path must exist
    """
    path = "~/tmp/flutils.tests.osutils.txt"
    mode_file = 0o630
    mode_dir = 0o740
    include_parent = True
    chmod(path, mode_file, mode_dir, include_parent)


# Generated at 2022-06-25 17:32:10.265558
# Unit test for function chmod
def test_chmod():
    assert(test_case_0)


# Generated at 2022-06-25 17:32:21.672638
# Unit test for function chmod
def test_chmod():
    # Test case 0
    # Create a file and a directory, set the file and directory's mode,
    # run the function, and check that the file and directory's mode
    # are the correct mode.
    struct_passwd_0 = get_os_user()
    uid = struct_passwd_0.pw_uid
    gid = struct_passwd_0.pw_gid
    file_path = PosixPath('/home/') / struct_passwd_0.pw_name / 'flutils.tests.pathutils'
    dir_path = PosixPath('/home/') / struct_passwd_0.pw_name / 'flutils.tests.pathutils/dir'
    file_path.mkdir()
    (file_path / 'testfile.txt').touch()

# Generated at 2022-06-25 17:32:33.981588
# Unit test for function chmod
def test_chmod():
    """Tests

    -   chmod
    """

    import flutils.pathutils
    import os

    os.system('mkdir -p ./tests_flutils_pathutils_chmod/A/B/C')
    os.system('rm -f ./tests_flutils_pathutils_chmod/A/B/C/Y')
    os.system('rm -f ./tests_flutils_pathutils_chmod/A/B/C/Z')
    os.system('rm -f ./tests_flutils_pathutils_chmod/A/B/X')
    os.system('rm -f ./tests_flutils_pathutils_chmod/A/B/Y')
    os.system('rm -f ./tests_flutils_pathutils_chmod/A/B/Z')

# Generated at 2022-06-25 17:32:35.149698
# Unit test for function directory_present
def test_directory_present():
    directory_present('./tmp/')


# Generated at 2022-06-25 17:32:36.694815
# Unit test for function directory_present
def test_directory_present():
  test_dir = directory_present("/tmp/test")
  print("test dir: ", test_dir)


# Generated at 2022-06-25 17:32:37.760773
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-25 17:33:02.263335
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/test')

    # create a test file
    Path(path).touch()

    # test that the file was created
    assert Path(path).exists() is True

    # test that the file does not have the user foo
    assert Path(path).owner() != 'foo'

    # change the owner to foo
    chown(path, user='foo')

    # test that the file now has owner foo
    assert Path(path).owner() == 'foo'

    # change the group to bar
    chown(path, group='bar')

    # test that the file now has group bar
    assert Path(path).group() == 'bar'


# Generated at 2022-06-25 17:33:10.056925
# Unit test for function chown
def test_chown():
    #GIVEN
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()
    path = '~/tmp/flutils.tests.osutils.txt'
    path2 = '~/tmp/flutils.tests.osutils.txt2'
    Path(path2).expanduser().parent.mkdir(parents=True, exist_ok=True)
    with Path(path).expanduser() as test_file:
        test_file.touch()
        os.chmod(test_file, 0o700)
    with Path(path2).expanduser() as test_file2:
        test_file2.touch()
        os.chmod(test_file2, 0o700)
    uid = struct_passwd_0.pw_uid


# Generated at 2022-06-25 17:33:13.924921
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) == None
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770) == None
    assert chmod('~/tmp/*') == None


# Generated at 2022-06-25 17:33:19.775364
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.pathutils.chmod/2017-01-02')

    if path.exists():
        path_absent(path)
    directory_present(path)
    chmod(path, 0o700)
    uid_0 = struct_passwd_0.pw_uid
    gid_0 = struct_passwd_0.pw_gid
    chown(path, uid_0, gid_0)


# Generated at 2022-06-25 17:33:26.918289
# Unit test for function chown
def test_chown():
    user_name = getpass.getuser()
    password_entry = pwd.getpwnam(user_name)
    if password_entry.pw_uid != os.getuid():
        print('assertion failed')
    group_name = grp.getgrgid(os.getuid()).gr_name

    # Test case 1
    if test_case_0():
        print("test case 0 passed")

    # Test case 3
    if test_case_3():
        print("test case 3 passed")


# Generated at 2022-06-25 17:33:30.067014
# Unit test for function chown
def test_chown():
    path = "tmp/osutils_test"
    user = "nobody"
    group = "nobody"
    chown(path, user, group)
    assert os.stat(path).st_uid == get_os_user(user).pw_uid
    assert os.stat(path).st_gid == get_os_group(group).pw_gid




# Generated at 2022-06-25 17:33:35.998922
# Unit test for function chmod
def test_chmod():
    struct_passwd_0 = get_os_user()
    try:
        new_file_path = os.path.join(struct_passwd_0.pw_dir, 'flutils_tests')
        open(new_file_path, 'w').close()
        chmod(new_file_path, 0o660)
        new_file_stat = os.stat(new_file_path)
        assert new_file_stat.st_mode & 0o777 == 0o660
    finally:
        os.remove(new_file_path)



# Generated at 2022-06-25 17:33:39.259128
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('/tmp/test_path')
    directory_present(test_path)
    assert test_path.exists() is True


# Generated at 2022-06-25 17:33:48.923197
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/flutils.tests.osutils.txt', '-1')
    chown('~/tmp/flutils.tests.osutils.txt', '-1', '-1')
    chown('/tmp/flutils.tests.osutils.txt')
    chown('/tmp/flutils.tests.osutils.txt', '-1')
    chown('/tmp/flutils.tests.osutils.txt', '-1', '-1')
    chown('/tmp/flutils.tests.osutils.txt', 'root')
    chown('/tmp/flutils.tests.osutils.txt', 'root', 'root')

# Generated at 2022-06-25 17:33:52.438859
# Unit test for function find_paths
def test_find_paths():
    from glob import glob
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    path = normalize_path('~/tmp/*')
    assert '*' in path.as_posix()
    assert path.is_absolute() is True

    pattern = normalize_path('~/tmp/*')
    globs = glob(pattern.as_posix())
    yield from find_paths(pattern)
    for glob_result, find_path_result in zip(glob, globs):
        assert find_path_result == glob_result

# Generated at 2022-06-25 17:34:00.833580
# Unit test for function find_paths
def test_find_paths():
    return_value = find_paths('*')
    print(list(next(return_value)))
    return return_value



# Generated at 2022-06-25 17:34:04.944428
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function"""
    # creating test directory and files
    # creating test directories
    path1 = Path('testdir')
    path1.mkdir()
    path2 = path1 / 'testdir1'
    path2.mkdir()
    path3 = path2 / 'testdir2'
    path3.mkdir()
    path4 = path3 / 'testdir3'
    path4.mkdir()
    test_dir = [path1, path2, path3, path4]
    # creating test files
    path2 = path1 / 'test1'
    path2.touch()
    path3 = path2 / 'test2'
    path3.touch()
    path4 = path2 / 'test3'
    path4.touch()

# Generated at 2022-06-25 17:34:09.394994
# Unit test for function chown
def test_chown():
    os.chown('/tmp/fltest.txt', 0, 0)
    os.chown('/tmp/fltest.txt', 'root', 'root')
    os.chown('/tmp/*.txt', 'root', 'root')
    os.chown('/tmp/foo', 'root', 'root')




# Generated at 2022-06-25 17:34:13.775031
# Unit test for function find_paths
def test_find_paths():
    with tempdir() as tmpdir:
        filepath = os.path.join(tmpdir, 'file')
        dirpath = os.path.join(tmpdir, 'dir')
        os.makedirs(dirpath)
        open(filepath, 'w').close()
        assert list(find_paths(os.path.join(tmpdir, '*'))) == [Path(filepath), Path(dirpath)]


# Generated at 2022-06-25 17:34:21.648037
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    # Test 0
    struct_passwd_0 = get_os_user()
    path_0 = directory_present(
        '~/tmp/flutils.test_flutils.test_pathutils.test_case_0',
        user=struct_passwd_0.pw_name
    )
    # Test 1
    struct_passwd_1 = get_os_user('_www')
    path_1 = directory_present(
        '~/tmp/flutils.test_flutils.test_pathutils.test_case_1/dot_dot/dot_dot',
        user=struct_passwd_1.pw_name
    )

    # Test cleanup
    if path_0.exists():
        path_0.rmdir()

# Generated at 2022-06-25 17:34:26.663483
# Unit test for function directory_present
def test_directory_present():
    test_path = normalize_path('~/tmp/test_path')
    # If this function fails the test will raise an exception
    try:
        directory_present(test_path)
    finally:
        test_path.parent.rmdir()



# Generated at 2022-06-25 17:34:28.621263
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-25 17:34:30.337025
# Unit test for function get_os_user
def test_get_os_user():
    result = get_os_user()
    print("test_get_os_user(): %s" % result)
    assert isinstance(result, type(pwd.struct_passwd(0, "", 0, 0, "", "", "")))

# Test for case where the specified user exists and is a valid login.

# Generated at 2022-06-25 17:34:33.054289
# Unit test for function find_paths
def test_find_paths():
    # Test 0
    # Test absolute glob pattern
    pattern = normalize_path('/Users/len/tmp/*')

    paths = find_paths(pattern)
    assert next(paths) == normalize_path('/Users/len/tmp/file_one')
    assert next(paths) == normalize_path('/Users/len/tmp/dir_one')


# Unit tests for function get_os_user()

# Generated at 2022-06-25 17:34:34.207003
# Unit test for function chown
def test_chown():
    test_case_0()
# test_chown()



# Generated at 2022-06-25 17:34:56.709362
# Unit test for function directory_present
def test_directory_present():
    directory_name = 'test_directory'
    directory_path = normalize_path(directory_name)

    if os.path.exists(directory_name):
        os.rmdir(directory_name)

    is_dir = os.path.isdir(directory_name)

    # The path "test_directory" does not exist.
    # directory_present should create the path.
    directory_present(directory_name)

    # After directory_present is executed,
    # the path should exist.
    is_dir = os.path.isdir(directory_name)
    assert is_dir == True

    # Clean up the test directory.
    if os.path.exists(directory_name):
        os.rmdir(directory_name)


# Generated at 2022-06-25 17:35:06.050080
# Unit test for function exists_as
def test_exists_as():
    test_path = '~/tmp/flutils.tests.test_exists_as'
    test_sub_path = '~/tmp/flutils.tests.test_exists_as/sub_path'
    test_sub_sub_path = '~/tmp/flutils.tests.test_exists_as/sub_path/sub_sub_path'

    # Test with an invalid path
    assert exists_as('/foo/bar/baz') == ''

    # Test with an absolute path that does not exist
    assert exists_as(normalize_path(test_path)) == ''

    # Test with an absolute path that exists as a directory
    directory_present(test_path)
    assert exists_as(normalize_path(test_path)) == 'directory'

    # Test with a sub path that does not exist


# Generated at 2022-06-25 17:35:06.878733
# Unit test for function directory_present
def test_directory_present():
    directory_present('/tmp/ruby-2.4.4')


# Generated at 2022-06-25 17:35:09.156641
# Unit test for function chown
def test_chown():
    root_path = '~/.pytest_cache/pathutils'
    chown(root_path, '-1', '-1')


# Generated at 2022-06-25 17:35:19.466753
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    # Test that an empty directory gets deleted
    path = Path('/tmp/test_path_absent_0')
    path.mkdir()
    path_absent(path)
    assert path.exists() is False
    # Test that a non-empty directory gets deleted
    path = Path('/tmp/test_path_absent_1')
    path.mkdir()
    (path / 'a_file').touch()
    path_absent(path)
    assert path.exists() is False
    # Test that a symbolic link gets deleted
    path = Path('/tmp/test_path_absent_2')
    path.touch()
    path.symlink_to('/tmp/test_path_absent_3')
    path_absent(path)


# Generated at 2022-06-25 17:35:31.309420
# Unit test for function chown
def test_chown():
    # Test a file
    path = normalize_path('./test_path')
    os.makedirs(path, exist_ok=True)
    chown(path, '', 'root')
    os.rmdir(path)
    chown(path)
    os.rmdir(path)
    chown(path, include_parent=True)
    os.rmdir(path)

    path = normalize_path('./test_path')
    chown(path)
    os.rmdir(path)
    chown(path, include_parent=True)
    os.rmdir(path)

    path = normalize_path('./test_path/file')
    os.makedirs(os.path.dirname(path), exist_ok=True)

# Generated at 2022-06-25 17:35:38.872638
# Unit test for function path_absent
def test_path_absent():
    #import pdb; pdb.set_trace()
    path = "test_path"
    path_absent(path)
    assert path not in os.listdir(os.getcwd())
    with open(path, 'w') as f:
        f.write("Test Path")
    path_absent(path)
    assert path not in os.listdir(os.getcwd())
    os.makedirs(path)
    path_absent(path)
    assert path not in os.listdir(os.getcwd())


# Generated at 2022-06-25 17:35:45.688406
# Unit test for function exists_as
def test_exists_as():
    with patch('flutils.pathutils._get_os_user_0', return_value='nobody') as mock_get_os_user_0:
        user_passwd_0 = get_os_user()
    user_passwd_1 = get_os_user('root')
    user_passwd_2 = get_os_user('nobody')
    user_passwd_3 = get_os_user('fake_user')



# Generated at 2022-06-25 17:35:49.403695
# Unit test for function exists_as
def test_exists_as():
    struct_passwd = get_os_user()
    cwd = Path.cwd()
    print(f"{cwd}")

    # raise FileNotFoundError('The file does not exist')



# Generated at 2022-06-25 17:35:52.381161
# Unit test for function get_os_user
def test_get_os_user():
    test_user = get_os_user()
    assert isinstance(test_user, pwd.struct_passwd), 'The return value must be a struct_passwd object, instead got %s' % type(test_user)


# Generated at 2022-06-25 17:36:17.054663
# Unit test for function path_absent
def test_path_absent():
    ####
    # Normal usage.
    ####
    root: Path = normalize_path('~/tmp')
    test_dir: Path = root / 'testdir'
    test_dir.mkdir(parents=True, exist_ok=True)
    test_file: Path = root / 'testfile'
    test_file.touch()
    test_link: Path = root / 'testlink'
    test_link.symlink_to(test_file.as_posix())
    assert test_dir.is_dir() is True
    assert test_file.is_file() is True
    assert test_link.is_symlink() is True

    path_absent(test_dir)

    assert test_dir.exists() is False
    assert test_file.is_file() is True
    assert test

# Generated at 2022-06-25 17:36:28.857608
# Unit test for function chmod
def test_chmod():
    passwd = get_os_user()
    path = Path('/tmp/chmod.test')

    if path.exists():
        chmod(path, 0o750)
    else:
        path.touch()
        chmod(path, 0o700)

    os.chmod('/tmp/chmod.test', 0o700)

    assert path.stat().st_mode == 0o0100770
    assert path.stat().st_uid == passwd.pw_uid
    assert path.stat().st_gid == passwd.pw_gid

    assert path.exists() is True

    path.unlink()

    assert path.exists() is False

    try:
        os.chmod('/tmp/chmod.test', 0o700)
    except PermissionError:
        assert True


# Generated at 2022-06-25 17:36:32.340220
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/test_path')



# Generated at 2022-06-25 17:36:40.786468
# Unit test for function directory_present
def test_directory_present():
    # Since this function uses os.path.expanduser() we need to set the
    # environment's HOME variable on OSX before running the tests.
    if sys.platform == 'darwin':
        os.environ['HOME'] = str(Path('~').expanduser())

    # Test passing in a Path object.
    path = Path('~/tmp/test_directory_present')
    result = directory_present(path)
    assert result == path.expanduser().resolve()
    assert path.exists() is True

    # Test passing in a PosixPath object.
    path = PosixPath('~/tmp/test_directory_present')
    result = directory_present(path)
    assert result == path.expanduser().resolve()
    assert path.exists() is True

    # Test passing in a WindowsPath object

# Generated at 2022-06-25 17:36:52.118219
# Unit test for function chmod
def test_chmod():
    
    # Test case 0
    # Check first user of /etc/passwd
    # No glob pattern
    # No include_parent
    test_passwd_0 = '/etc/passwd'
    os.path.exists(test_passwd_0) is True
    result_0 = os.stat(test_passwd_0)[0]
    # mode_file is None
    # mode_dir is None
    chmod(test_passwd_0)
    result_1 = os.stat(test_passwd_0)[0]
    assert result_0 != result_1
    
    # Test case 0
    # Check first user of /etc/passwd
    # No glob pattern
    # No include_parent
    # mode_file = 0o777
    # mode_dir = 0o444
    test_pass

# Generated at 2022-06-25 17:37:02.388283
# Unit test for function chown
def test_chown():
    test_passwd_0 = pwd.getpwnam(getpass.getuser())
    test_group_0 = grp.getgrgid(test_passwd_0.pw_gid)

    testpath = '/tmp/test.txt'
    open(testpath, 'a').close()

    chown(testpath,
          user=test_passwd_0.pw_uid,
          group=test_group_0.gr_gid)
    assert test_passwd_0.pw_uid == os.stat(testpath).st_uid
    assert test_group_0.gr_gid == os.stat(testpath).st_gid


# Generated at 2022-06-25 17:37:04.868053
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path'
    path_absent(path)
    assert os.path.exists(path) == False

# Generated at 2022-06-25 17:37:07.516118
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-25 17:37:17.670052
# Unit test for function chmod
def test_chmod():
    # Arrange
    os_ut_file = 'tmp/3_os.ut.txt'
    os_ut_user = 'os.ut'
    os_ut_uid = 1001
    os_ut_gid = 1001
    os_ut_path = 'flutils.tests.osutils.OSUtils'

    # Act
    with open(os_ut_file, 'w') as fh:
        fh.write('o.O\n')
    chmod(os_ut_file, 0o660)

    # Assert
    assert os.path.exists(os_ut_file)
    assert os.path.isfile(os_ut_file)
    assert os.access(os_ut_file, os.R_OK) is True

# Generated at 2022-06-25 17:37:23.111271
# Unit test for function directory_present
def test_directory_present():
    project_root = os.getenv('PYTHONPATH')
    path_0 = os.path.join(project_root, 'test_directory_0')
    path_1 = os.path.join(project_root, 'test_directory_0', 'test_directory_1')
    directory_present(path_0)
    directory_present(path_1)


# Generated at 2022-06-25 17:37:43.137812
# Unit test for function chmod
def test_chmod():
    chmod('test_case_0', 0o660)


# Generated at 2022-06-25 17:37:45.588934
# Unit test for function exists_as
def test_exists_as():
    with pytest.raises(FileNotFoundError):
        exists_as('/')
    assert exists_as('/etc') == 'directory'


# Generated at 2022-06-25 17:37:52.858855
# Unit test for function path_absent
def test_path_absent():
    """Test :obj:`path_absent` function."""

    path_dir_0 = Path(__file__)
    path_dir_0 = path_dir_0.parent
    path_dir_1 = path_dir_0.joinpath('test_path')
    if exists_as(path_dir_1):
        path_absent(path_dir_1)

    assert exists_as(path_dir_1) == ''

    path_dir_1.mkdir(mode=0o700)
    path_absent(path_dir_1)

    assert exists_as(path_dir_1) == ''



# Generated at 2022-06-25 17:37:58.028977
# Unit test for function chown
def test_chown():
    Path(os.path.expanduser('~/tmp/pathutils/chown/test_chown.txt')).touch()
    chown('~/tmp/pathutils/chown/test_chown.txt')
    #assert get_os_user().pw_uid ==




# Generated at 2022-06-25 17:38:00.690909
# Unit test for function path_absent
def test_path_absent():
    # Function is tested by pydev_path_absent.py
    # Function is tested by pyflocker_path_absent
    pass


# Generated at 2022-06-25 17:38:03.806059
# Unit test for function directory_present
def test_directory_present():
    temp_path = Path('~/tmp/') / '.tests/pathutils'
    directory_present(temp_path)
    assert temp_path.exists() is True
    assert temp_path.is_dir() is True


# Generated at 2022-06-25 17:38:14.752506
# Unit test for function path_absent
def test_path_absent():
    def _path_absent(path: _PATH) -> None:
        path = normalize_path(path)

        if path.exists():
            if path.is_dir():
                for f in path.iterdir():
                    f.unlink()
            path.unlink()
        if path.exists():
            if path.is_dir():
                for f in path.iterdir():
                    _path_absent(f.resolve())
            path.unlink()
        if path.exists():
            if path.is_dir():
                for f in path.iterdir():
                    _path_absent(f.resolve())
            path.unlink()
    for path in find_paths('/tmp/flutils*'):
        _path_absent(path)

# Generated at 2022-06-25 17:38:26.628175
# Unit test for function chown
def test_chown():

    path = Path('/tmp/file_1')
    # Assuming 'file_1' doesn't exist, we can check if chown() is working
    if not path.exists():
        with path.open(mode="w") as tmpfile:
            tmpfile.write("test_string")
        print("'file_1' does exist.")
        print("'file_1' belongs to user: " + str(get_os_user(path.stat().st_uid).pw_name) +
              " and group: " + str(get_os_group(path.stat().st_gid).gr_name))

# Generated at 2022-06-25 17:38:28.093400
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)
    test_case_0()


# Generated at 2022-06-25 17:38:31.303148
# Unit test for function exists_as
def test_exists_as():
    test_data = [
        # (path, expected_result)
        ('~/tmp', 'directory'),
        ('~/tmp2', '')
    ]
    for path, expected_result in test_data:
        assert exists_as(path) == expected_result


# Generated at 2022-06-25 17:38:52.967085
# Unit test for function chmod
def test_chmod():
    osutils_test_0 = subprocess.run(
        ['touch', '-f', '~/tmp/flutils.tests.osutils.txt'],
        capture_output=True,
        check=True,
        shell=True,
        text=True,
    )
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    osutils_test_1 = subprocess.run(
        ['stat', '-c', '%a', '~/tmp/flutils.tests.osutils.txt'],
        capture_output=True,
        check=True,
        shell=True,
        text=True,
        universal_newlines=True,
    )
    assert osutils_test_1.stdout.strip() == '660'

# Generated at 2022-06-25 17:38:56.679902
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__.split('/')[0]) == 'directory'
    assert exists_as('fake_file') == ''
    assert exists_as('/usr/sbin/test') == ''
    assert exists_as('/test') == ''


# Generated at 2022-06-25 17:38:59.325211
# Unit test for function directory_present
def test_directory_present():

    tmp_path_0 = '~/tmp/flutils.tests.pathutils.test_case_0'
    directory_present(tmp_path_0)
    assert os.path.isdir(tmp_path_0)



# Generated at 2022-06-25 17:39:04.414426
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('test_exists_as()_1') == ''
    open('test_exists_as()_1','w+').close()
    assert exists_as('test_exists_as()_1') == 'file'
    remove('test_exists_as()_1')



# Generated at 2022-06-25 17:39:14.628485
# Unit test for function chown
def test_chown():
    import tempfile

    dirname = tempfile.mkdtemp()
    with open(os.path.join(dirname, 'test_file'), 'w') as fp:
        fp.write('test')

    chown(dirname + '/test_file', 'nobody')
    assert os.stat(dirname + '/test_file').st_uid == pwd.getpwnam('nobody').pw_uid
    assert os.stat(dirname + '/test_file').st_gid == pwd.getpwnam('nobody').pw_gid

    os.remove(dirname + '/test_file')
    os.rmdir(dirname)


# Generated at 2022-06-25 17:39:19.153172
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o660
    mode_dir = 0o770

    chmod(path, mode_file, mode_dir)


# Generated at 2022-06-25 17:39:21.253006
# Unit test for function chmod
def test_chmod():
    print(sys._getframe().f_code.co_name)
    # Test case 0
    # chmod
    test_case_0()


# Generated at 2022-06-25 17:39:31.334055
# Unit test for function chmod
def test_chmod():
    # handle an existing path with no glob pattern and no parent
    chmod(
        '~/tmp/flutils.tests.osutils.txt',
        0o660
    )
    # handle an existing path with no glob pattern and a parent
    chmod(
        '~/tmp/flutils.tests.osutils.txt',
        0o660,
        include_parent = True
    )
    # handle a non existing path
    chmod(
        '~/tmp/flutils.tests.osutils_file_does_not_exist.txt',
        0o660,
        include_parent = True
    )
    # handle a glob pattern
    chmod('~/tmp/*', mode_file=0o644, mode_dir=0o770)
    # handle a glob pattern

# Generated at 2022-06-25 17:39:42.517934
# Unit test for function chmod
def test_chmod():
    import os
    import pathlib
    import stat
    import tempfile
    import tests.pathutils.test_utils as test_utils

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = pathlib.Path(tmp_dir.name)
    tmp_path = tmp_dir_path / 'test'
    tmp_path.touch()


# Generated at 2022-06-25 17:39:49.129755
# Unit test for function chown
def test_chown():
    path_chown = normalize_path('./')
    path_chown_new = path_chown /  'tmp_test_chown'
    path_chown_new.mkdir()
    chown(path_chown_new,
          user=getpass.getuser(),
          group=grp.getgrgid(os.getgid()).gr_name,
          include_parent=True)
    path_chown_new.rmdir()


# Generated at 2022-06-25 17:40:07.203499
# Unit test for function directory_present
def test_directory_present():
    directory_present('../')
    directory_present('../', mode=0o777)
    directory_present('../', mode=0o777, user=get_os_user())
    directory_present('../', mode=0o777, user=get_os_user(), group=get_os_group())
    print('directory_present test passed')


# Generated at 2022-06-25 17:40:10.009095
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-25 17:40:13.729584
# Unit test for function exists_as
def test_exists_as():
    try:
        exists_as("/SomeDirec/SomeFile.txt")
    except Exception as e:
        print("AssertionError: {}".format(e))


# Generated at 2022-06-25 17:40:17.022801
# Unit test for function chmod
def test_chmod():
    # Test case 0
    # Do not supply mode_file and mode_dir
    chmod('~/tmp/flutils.tests.osutils.txt')
    # Test case 1
    # Supplied mode_file and mode_dir
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660, 0o770)


# Generated at 2022-06-25 17:40:20.022761
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/open_jd_sunny_day') == 'file'
    assert exists_as('~/tmp/does_not_exist') == ''

# Generated at 2022-06-25 17:40:26.708358
# Unit test for function exists_as
def test_exists_as():
    """Test exists_as function

    :return:
    """
    # Repeat this test 20 times
    for i in range(20):
        # Check if test file exists
        path = 'test_file.txt'
        res = exists_as(path)
        assert res == 'file'

        # Check if directory exists
        path = './'
        res = exists_as(path)
        assert res == 'directory'

        # Check imaginary path
        path = './invalid'
        res = exists_as(path)
        assert res == ''


# Generated at 2022-06-25 17:40:39.270855
# Unit test for function exists_as
def test_exists_as():
    # Write a test result to a file
    file_name = './test_exists_as.txt'
    fp = open(file_name, 'w')
    fp.write('Test of function exists_as\n')

    # Remove a file before testing
    if exists_as(file_name) == 'file':
        os.remove(file_name)
    assert exists_as(file_name) == ''
    fp.write('    File not found: %s\n' % file_name)

    # Create the file for testing
    fp = open(file_name, 'w')
    fp.close()
    assert exists_as(file_name) == 'file'
    fp.write('    File found: %s\n' % file_name)

    # Remove the test file
    os

# Generated at 2022-06-25 17:40:49.420195
# Unit test for function chmod
def test_chmod():
    directory = Path("/tmp/flutils_test/test_chmod")
    if directory.exists():
        directory.rmdir()
    directory.mkdir()
    mode = directory.stat().st_mode
    assert mode == 16895
    chmod(directory.as_posix(), mode_file=0o660)
    mode = directory.stat().st_mode
    assert mode == 16895

    file = Path(directory.as_posix() + "/file.txt")
    if file.exists():
        file.unlink()
    file.write_text("test")
    mode = file.stat().st_mode
    assert mode == 33188
    chmod(file.as_posix(), mode_file=0o660)
    mode = file.stat().st_mode
    assert mode == 33060

   

# Generated at 2022-06-25 17:40:51.421781
# Unit test for function chmod
def test_chmod():
    try:
        chmod('/etc/sudoers', 0o770)
    except PermissionError:
        pass
    else:
        assert False, 'chmod did not behave as expected'


# Generated at 2022-06-25 17:41:00.598406
# Unit test for function chown
def test_chown():
    # normalize_path is unit tested in test_pathutils.py
    # chown has a dependency on normalize_path
    #
    # Here we'll just make sure the logics is correct
    tmp_path = Path('/tmp/flutils.test.chown.txt')

    tmp_path.touch()
    chown(tmp_path, user='root')
    chown(tmp_path, user='root')
    chown(tmp_path, user='root')
    chown(tmp_path, user='root')
    chown(tmp_path, user='root')

    pwd_struct = pwd.getpwnam('root')
    chown_stat = os.stat(tmp_path)
    assert chown_stat.st_uid == pwd_struct.pw_uid
