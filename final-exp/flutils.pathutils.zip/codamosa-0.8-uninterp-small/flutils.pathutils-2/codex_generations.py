

# Generated at 2022-06-25 17:32:01.122641
# Unit test for function chown
def test_chown():
    test_user = get_os_user()
    if test_user.pw_name == 'root':
        raise OSError
    test_dir = normalize_path('~/flutils.tests/osutils/test_dir')
    directory_present(test_dir)
    chown(test_dir, user=test_user.pw_name, group=test_user.pw_name, include_parent=True)
    # Check for pass here
    # assert get_os_user(test_dir, include_parent=True) == test_user
    path_absent(test_dir)


# Generated at 2022-06-25 17:32:02.147219
# Unit test for function find_paths
def test_find_paths():
    pass


# Generated at 2022-06-25 17:32:09.781348
# Unit test for function find_paths
def test_find_paths():
    from pathlib import PosixPath, WindowsPath
    from flutils.pathutils import find_paths
    import platform
    import pytest
    import random

    if platform.system() == 'Windows':
        path_class: type = WindowsPath
    else:
        path_class: type = PosixPath

    p = path_class()
    pattern_path: str = ''

    rand_int = random.randint(1, 9)
    while rand_int > 0:
        pattern_path += '*/'
        rand_int = rand_int - 1

    pattern_path += '*'

    yielded_paths: Set[Path] = set()

    for yielded_path in find_paths(pattern_path):
        yielded_paths.add(yielded_path)


# Generated at 2022-06-25 17:32:13.385849
# Unit test for function directory_present
def test_directory_present():
    assert directory_present("/Users/len/tmp/flutils/tests/osutils") == PosixPath("/Users/len/tmp/flutils/tests/osutils")


# Generated at 2022-06-25 17:32:23.569554
# Unit test for function chmod
def test_chmod():
    os.makedirs('/tmp/flutils.tests.osutils', exist_ok=True, mode=0o700)
    Path('/tmp/flutils.tests.osutils.txt').touch(mode=0o600)
    chmod('/tmp/flutils.tests.osutils/**', mode_file=0o644, mode_dir=0o770)
    assert Path('/tmp/flutils.tests.osutils.txt').stat().st_mode & 0o777 == 0o644
    assert Path('/tmp/flutils.tests.osutils').stat().st_mode & 0o777 == 0o770

    os.makedirs('/tmp/flutils.tests.osutils/case_0', exist_ok=True, mode=0o600)

# Generated at 2022-06-25 17:32:27.714753
# Unit test for function directory_present
def test_directory_present():
    base_path = '/tmp/flutils/test_case_0/test_directory_present'
    path_0 = Path(base_path).expanduser()
    path_1 = directory_present(
        path=path_0,
        user='-1',
        group='-1'
    )
    assert path_0 == path_1
    path_1.rmdir()


# Generated at 2022-06-25 17:32:33.598188
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = Path('~/tmp/test_case_0').expanduser()
    tmp_dir.mkdir(parents=True, exist_ok=True)
    Path('~/tmp/test_case_0/file_one').expanduser().touch()
    Path('~/tmp/test_case_0/file_two').expanduser().touch()
    Path('~/tmp/test_case_0/file_three').expanduser().touch()
    Path('~/tmp/test_case_0/dir_one').expanduser().mkdir()
    Path('~/tmp/test_case_0/dir_two').expanduser().mkdir()
    Path('~/tmp/test_case_0/dir_three').expanduser().mkdir()


# Generated at 2022-06-25 17:32:35.617458
# Unit test for function exists_as
def test_exists_as():
    path = Path('/tmp/foo')
    path.touch()
    assert exists_as(path) == "file"



# Generated at 2022-06-25 17:32:43.377338
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    from flutils.pathutils import chmod

    def callback_mkdir_and_touch():
        os.mkdir(temp_dir_path)
        temp_file_path = os.path.join(temp_dir_path, temp_file_name)
        with open(temp_file_path, 'w') as raw_file:
            temp_file_content = 'hello world'
            raw_file.write(temp_file_content)

        return temp_file_path, temp_file_content

    def callback_assertions(test_case_path, test_case_mode):
        temp_file_path_out, temp_file_mode_out = test_case_path, test_case_mode


# Generated at 2022-06-25 17:32:48.681645
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    from flutils.pathutils import exists_as
    from flutils.pathutils import path_absent

    path = Path(tempfile.gettempdir())
    path = path / 'Test_1'
    path = path / 'Test_2'

    if path.exists():
        raise RuntimeError('The path: %r already exists.' % path.as_posix())

    path_absent(path)
    assert (exists_as(path) == '') is True

    path.mkdir(parents=True)
    path_absent(path)
    assert (exists_as(path) == '') is True

    path.mkdir(parents=True)
    (path / 'Readme.txt').touch()
    path.mkdir(parents=True)

# Generated at 2022-06-25 17:33:10.547930
# Unit test for function directory_present
def test_directory_present():
    import inspect
    import logging
    import time
    import unittest
    from pathlib import Path
    cwd = Path('.')
    # TODO update test to work on Windows as well
    test_dir1 = cwd / 'test_dir_a'
    test_dir2 = cwd / 'test_dir_b'
    test_file1 = cwd / 'test_file_a'
    test_file2 = cwd / 'test_file_b'
    exists_as(test_dir1).rmtree()
    exists_as(test_dir2).rmtree()
    exists_as(test_file1).unlink()
    exists_as(test_file2).unlink()
    directory_present(test_dir1)
    assert exists_as(test_dir1) == 'directory'

# Generated at 2022-06-25 17:33:18.369307
# Unit test for function find_paths
def test_find_paths():
    expected = [
        'file_one',
        'file_two',
        'dir_one',
        'dir_two']
    for i, result in enumerate(find_paths('~/tmp/*')):
        if expected[i] != result.name:
            raise AssertionError(
                'find_paths failed the result %s does not match expected: %s'
                % (result.name, expected[i]))
    for i, result in enumerate(find_paths('./tests/osutils/tmp/*')):
        if expected[i] != result.name:
            raise AssertionError(
                'find_paths failed the result %s does not match expected: %s'
                % (result.name, expected[i]))

# Generated at 2022-06-25 17:33:29.752973
# Unit test for function chown
def test_chown():
    # Test chown of a directory
    tmp_dir = Path('~/tmp/flutils/chown').expanduser().resolve()
    os.makedirs(str(tmp_dir), exist_ok=True)
    chown(str(tmp_dir), user='foo', group='bar')
    pw = pwd.getpwnam('foo')
    gr = grp.getgrnam('bar')
    tp = tmp_dir.stat()
    assert tp.st_uid == pw.pw_uid
    assert tp.st_gid == gr.gr_gid
    # Test chown of file
    tmp_file = tmp_dir / 'flutils.tests.osutils.txt'
    tmp_file.touch()

# Generated at 2022-06-25 17:33:37.417231
# Unit test for function chmod
def test_chmod():
    # Create a test directory and fill it with some content.
    os.mkdir('tmp')
    os.mkdir('tmp/dir_0')
    os.mkdir('tmp/dir_1')
    os.mkdir('tmp/dir_3')
    os.mkdir('tmp/dir_4')
    os.mkdir('tmp/dir_5')
    os.mkdir('tmp/dir_6')
    os.mkdir('tmp/dir_7')
    os.mkdir('tmp/dir_8')
    os.mkdir('tmp/dir_9')
    os.mkdir('tmp/dir_10')
    os.mkdir('tmp/dir_11')
    os.mkdir('tmp/dir_12')
    os.mkdir('tmp/dir_13')

# Generated at 2022-06-25 17:33:41.069743
# Unit test for function chmod
def test_chmod():
    f = '~/tmp/flutils.tests.osutils.txt'
    chmod(f, 0o600, 0o700)
    assert os.stat(f).st_mode & 0o777 == 0o600



# Generated at 2022-06-25 17:33:46.830146
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    import glob
    import os
    import tempfile
    import unittest
    import pathlib

    class find_paths_TestCase(unittest.TestCase):
        # Tests that find_paths can be used to find a list of
        # files and directories.
        def test_case_0(self):
            image_count = 0
            directory_count = 0
            with tempfile.TemporaryDirectory() as base_directory:
                for i in range(0, 10):
                    # Create a directory
                    directory = os.path.join(base_directory, "test_dir_%03d" % i)
                    os.makedirs(directory)
                    directory_count = directory_count + 1
                    # Create an image file in the directory

# Generated at 2022-06-25 17:33:53.530375
# Unit test for function path_absent
def test_path_absent():
    # Create some paths.
    os.chdir(os.getcwd())
    PATHS = [
        "0_normalize_path.py",
        "paths/",
        "paths/0_normalize_path.py",
        "paths/paths/",
        "paths/paths/0_normalize_path.py",
        "paths/paths/paths/",
        "paths/paths/paths/0_normalize_path.py",
        "paths/paths/paths/paths/",
        "paths/paths/paths/paths/0_normalize_path.py",
        "paths/paths/tmp_file.tmp"
    ]
    for path in PATHS:
        normalize_path.fset.cache_

# Generated at 2022-06-25 17:33:57.266178
# Unit test for function exists_as
def test_exists_as():
    test_path = Path('~/tmp/test_path')
    test_path.touch()

    test_result = exists_as(test_path)
    assert test_result == 'file'

    test_path.unlink()


# Generated at 2022-06-25 17:34:07.384893
# Unit test for function chown
def test_chown():
    test_case_0()

# def _directory_present(
#         path: _PATH,
#         user: Optional[str] = None,
#         group: Optional[str] = None,
#         mode: Optional[int] = None,
#         recursive: bool = True,
#         realpath: bool = True
# ) -> None:

# Generated at 2022-06-25 17:34:17.467407
# Unit test for function chown
def test_chown():
    # Test case #0
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o644
    mode_dir = 0o755
    include_parent = False
    chown(
        path,
        mode_file=mode_file,
        mode_dir=mode_dir,
        include_parent=include_parent,
    )
    # Test case #1
    path = '~/tmp/**'
    mode_file = 0o600
    mode_dir = 0o700
    include_parent = False
    chown(
        path,
        mode_file=mode_file,
        mode_dir=mode_dir,
        include_parent=include_parent,
    )


# Generated at 2022-06-25 17:34:40.862308
# Unit test for function exists_as
def test_exists_as():
    if os.environ.get('TEST_DO_CLEAN_UP', 'True') == 'True':
        path = Path().home() / 'flutils_test_case_0'
        if path.is_dir():
            shutil.rmtree(path.as_posix())

    path = Path().home() / 'flutils_test_case_0'
    if path.is_dir():
        shutil.rmtree(path.as_posix())

    path.mkdir(mode=0o700)

    sub_path_0 = path / 'temp_file_0.txt'
    sub_path_0.touch()

    sub_path_1 = path / 'temp_file_1.txt'
    sub_path_1.write_text('I am a file')

    sub_path_2

# Generated at 2022-06-25 17:34:42.980046
# Unit test for function chown
def test_chown():
    test_case_0()


# Generated at 2022-06-25 17:34:56.346810
# Unit test for function chown
def test_chown():
    # Arrange
    if os.getuid() != 0:
        raise Exception('Must be root user to test chown.')

    # Act

# Generated at 2022-06-25 17:35:00.211862
# Unit test for function find_paths
def test_find_paths():
    test_paths = [
        '~/tmp/flutils.tests/find_paths/*',
        '~/tmp/flutils.tests/find_paths/**',
        '~/tmp/flutils.tests/find_paths/*.py'
    ]
    for p in test_paths:
        for f in find_paths(p):
            print(f)



# Generated at 2022-06-25 17:35:05.040733
# Unit test for function directory_present
def test_directory_present():
    dir_path = Path('./temp/')
    dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    dir_path = directory_present('./temp/')

    assert dir_path.exists()
    assert dir_path.is_dir()
    assert dir_path.parent.exists()
    assert dir_path.parent.is_dir()

    # This will not work on the CI:
    #assert dir_path.stat().st_mode == 16895
    #assert dir_path.stat().st_uid == 1000
    #assert dir_path.stat().st_gid == 1000

    dir_path.rmdir()
    dir_path.parent.rmdir()



# Generated at 2022-06-25 17:35:09.116243
# Unit test for function exists_as
def test_exists_as():
    myPath = Path('/Users/len/tmp/flutils.tests.osutils')
    assert exists_as(myPath) == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.does_not_exist') == ''


# Generated at 2022-06-25 17:35:10.512870
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'


# Generated at 2022-06-25 17:35:17.079372
# Unit test for function exists_as
def test_exists_as():
    """Tests the function exists_as"""
    path = Path('~/tmp/test')
    assert exists_as(path) == 'directory'
    assert exists_as(Path('~/tmp/test/flutils.tests.pathutils.test_case_0.txt')) == 'file'
    assert exists_as(Path('~/tmp/test/flutils.tests.pathutils.test_case_0.no_exist')) == ''


# Generated at 2022-06-25 17:35:29.149883
# Unit test for function find_paths
def test_find_paths():
    # Create the test directory.
    test_dir = directory_present('~/tmp/test_find_paths')
    # Create the test files.
    f_path = test_dir / 'file_one'
    f_path.touch(exist_ok=True)
    f_path = test_dir / 'file_two'
    f_path.touch(exist_ok=True)
    # Create the test directories.
    d_path = test_dir / 'dir_one'
    d_path.mkdir(exist_ok=True)
    d_path = test_dir / 'dir_two'
    d_path.mkdir(exist_ok=True)
    # Run the function.
    test_pattern = test_dir / '*'
    match_paths = find_paths(test_pattern)


# Generated at 2022-06-25 17:35:37.369799
# Unit test for function chown
def test_chown():
    with open('test_chown_user.txt', 'w') as f:
        f.write('test_chown_user.txt')
    with open('test_chown_user.txt', 'w') as f:
        os.chown('test_chown_user.txt', 1000, 1000)
        f.write('test_chown_user.txt')
    with open('test_chown_user.txt', 'w') as f:
        os.chown('test_chown_user.txt', 1000, 1000)
        f.write('test_chown_user.txt')



# Generated at 2022-06-25 17:35:54.690867
# Unit test for function directory_present
def test_directory_present():
    try:
        # Test that a path object can be a Path object
        test_path = directory_present(Path('/tmp/test_path'))
        # Test that the returned path is of type Path
        assert isinstance(test_path, Path)
    except:
        raise
    finally:
        # Remove the test directory if it exists.
        test_path.rmdir()


# Generated at 2022-06-25 17:36:05.222723
# Unit test for function chown
def test_chown():
    import os
    import getpass
    import grp
    from flutils.pathutils import chown
    from pathlib import Path

    from_ = os.path.join('~', 'tmp', 'test')
    with open(from_, 'w') as f:
        f.write('test')

    chown(from_)

    with open(from_) as f:
        assert f.read() == 'test'

    from_ = os.path.join('~', 'tmp', 'test')
    with open(from_, 'w') as f:
        f.write('test')

    chown(from_, group=grp.getgrgid(os.getgid()).gr_name)

    with open(from_) as f:
        assert f.read() == 'test'


# Generated at 2022-06-25 17:36:08.542885
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/test_path')
    assert path.exists()



# Generated at 2022-06-25 17:36:19.382343
# Unit test for function chown
def test_chown():
    testdir = "/tmp/testdir"
    testdirnotexists = "/tmp/testdirnotexists"
    testfile = "/tmp/testdir/testfile"
    testfile2 = "/tmp/testdir/testfile2"
    # Path should not exist
    if os.path.exists(testdirnotexists):
        os.unlink(testdirnotexists)
    # Path should exists
    if not os.path.exists(testfile):
        os.mkdir(testdir, 0o755)
        with open(testfile, "w") as f:
            f.write("hello world")
        with open(testfile2, "w") as f:
            f.write("hello world")
    chown(testdir, user="root")
    chown(testfile, user="root")


# Generated at 2022-06-25 17:36:30.896725
# Unit test for function chown

# Generated at 2022-06-25 17:36:42.386193
# Unit test for function get_os_user

# Generated at 2022-06-25 17:36:54.091858
# Unit test for function exists_as
def test_exists_as():
    # exists_as(path)
    assert exists_as('/etc') == 'directory'
    assert exists_as('/Users/len/') == 'directory'
    assert exists_as('~/') == 'directory'
    assert exists_as('~/todo.txt') == 'file'
    assert exists_as('test_pathutils.py') == 'file'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/fd/0') == 'char device'

# Generated at 2022-06-25 17:37:00.010723
# Unit test for function path_absent
def test_path_absent():
    # Test the case where the path doesn't exist
    path_absent('/tmp/non_existing_path')

    # Test the case where the path is a directory
    if os.path.exists('/tmp/test_path') is False:
        os.mkdir('/tmp/test_path')
    path_absent('/tmp/test_path')
    if os.path.exists('/tmp/test_path') is True:
        raise RuntimeError('/tmp/test_path is not removed')

    # Test the case where the path is a regular file
    if os.path.exists('/tmp/test_file') is False:
        open('/tmp/test_file', 'w').close()
    path_absent('/tmp/test_file')

# Generated at 2022-06-25 17:37:08.112614
# Unit test for function find_paths
def test_find_paths():
    dt = datetime.now()
    for i in range(4):
        f = Path.cwd().joinpath(dt.strftime(f'%Y-%m-%d_%H-%M-%S_{i}'))
        f.write_text('foo')
        f.chmod(0o600)
        f.chown(0, 0)
        f.touch()
    m = find_paths(f'{Path.cwd()}/*')
    return m

if __name__ == '__main__':
    print(test_find_paths())

# Generated at 2022-06-25 17:37:18.298281
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    # Test that an exception will be raised if a file exists and is not a
    # directory.
    test_file: str = '~/tmp/test_file'
    test_file = cast(str, normalize_path(test_file))
    open(test_file, 'w+').close()
    with pytest.raises(OSError) as e_info:
        path_absent(test_file)
    assert 'File exists' in str(e_info.value)
    os.unlink(test_file)
    # Test that a directory can be deleted if it is empty.
    test_dir: str = '~/tmp/test_dir'
    test_dir = cast(str, normalize_path(test_dir))

# Generated at 2022-06-25 17:37:36.610676
# Unit test for function chmod
def test_chmod():
    # Create a test file
    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    if path.exists():
        path.unlink()
    path.write_text('text')

    # Set the mode to 0o600
    chmod(path)
    assert path.stat().st_mode == 33204




# Generated at 2022-06-25 17:37:40.591790
# Unit test for function get_os_user
def test_get_os_user():
    struct_passwd_0 = get_os_user()
    assert struct_passwd_0.pw_uid == os.getuid()
    struct_passwd_1 = get_os_user(struct_passwd_0.pw_uid)
    assert struct_passwd_0.pw_name == struct_passwd_1.pw_name
    struct_passwd_1 = get_os_user(struct_passwd_0.pw_name)
    assert struct_passwd_0.pw_uid == struct_passwd_1.pw_uid


# Generated at 2022-06-25 17:37:48.160544
# Unit test for function chmod
def test_chmod():
    """Test function ``chmod``."""
    path = Path("~/tmp/flutils.tests.osutils.txt")
    path.touch()
    chmod("~/tmp/flutils.tests.osutils.txt", 0o660)

    # Supports a glob pattern.
    chmod("~/tmp/**", mode_file=0o644, mode_dir=0o770)

    # Suppresses the warning message.
    chmod("~/tmp/flutils.tests.osutils.txt", 0o660)

    path.unlink()


# Generated at 2022-06-25 17:37:59.081978
# Unit test for function find_paths
def test_find_paths():
    assert tuple(
        find_paths('~/tmp')
    ) == tuple(
        Path().glob('~/tmp')
    )

    assert tuple(
        find_paths('~/tmp/find_paths.tests.txt')
    ) == tuple(
        Path().glob('~/tmp/find_paths.tests.txt')
    )

    assert tuple(
        find_paths('~/tmp/*')
    ) == tuple(
        Path().glob('~/tmp/*')
    )

    assert tuple(
        find_paths('~/tmp/**')
    ) == tuple(
        Path().glob('~/tmp/**')
    )


# Generated at 2022-06-25 17:38:01.962791
# Unit test for function exists_as
def test_exists_as():
    os.path.isdir(exists_as('.'))
    os.path.isfile(exists_as('.'))
    os.path.isfile(exists_as('os.py'))



# Generated at 2022-06-25 17:38:12.608776
# Unit test for function chmod
def test_chmod():

    test_file = '~/tmp/tests/file.txt'
    test_dir = '~/tmp/tests/dir/'

    os.system('rm -rf '+test_file)
    os.system('rm -rf '+test_dir)
    os.system('mkdir -p '+test_dir)
    os.system('touch '+test_file)

    chmod(test_file, 0o660)
    chmod(test_dir, 0o770)

    for test_path in [test_file, test_dir]:
        stats = os.stat(test_path)
        m = stats.st_mode
        octal_mode = oct(m)
        if test_path == test_file:
            assert octal_mode[-3:] == '660'

# Generated at 2022-06-25 17:38:16.013044
# Unit test for function chmod
def test_chmod():
    path = Path() / "test_dir"
    try:
        os.mkdir(path)
    except FileExistsError as e:
        print(e)
    else:
        chmod(path, mode_dir=0o700)


# Generated at 2022-06-25 17:38:20.928152
# Unit test for function find_paths
def test_find_paths():
    # Simple test.  See if we can find our self:
    current_filename = sys.argv[0]
    my_paths = find_paths(current_filename)
    my_paths = list(my_paths)
    # There should be only one match
    assert len(my_paths) == 1
    # And that match should match our __file__ value
    assert my_paths[0].as_posix() == Path(current_filename).as_posix()


# Generated at 2022-06-25 17:38:21.884528
# Unit test for function directory_present
def test_directory_present():
    directory_present("../tmp/test_directory_present_0")


# Generated at 2022-06-25 17:38:27.149361
# Unit test for function directory_present
def test_directory_present():

    directory_present('./tmp')
    directory_present('./tmp2/tmp3')

    directory_present('./tmp/tmp2')
    directory_present('./tmp/tmp2/tmp3')
    directory_present('./tmp/tmp2/tmp3/tmp4')
    directory_present('./tmp/tmp2/tmp3/tmp4/tmp5')



# Generated at 2022-06-25 17:38:41.804021
# Unit test for function path_absent
def test_path_absent():
    path_absent("/tmp/test_flutils_pathutils_normalize_path.txt")

if __name__ == '__main__':
    test_path_absent()

# Generated at 2022-06-25 17:38:47.995824
# Unit test for function exists_as
def test_exists_as():
    tmp_path = Path(tempfile.gettempdir())
    tmp_file = tmp_path / 'tmp_file'
    tmp_dir = tmp_path / 'tmp_dir'
    tmp_fifo = tmp_path / 'tmp_fifo'

    # test for file
    with open(tmp_file, 'w') as f:
        f.write('foo')
    assert exists_as(tmp_file) == 'file'

    # test for directory
    os.mkdir(tmp_dir)
    assert exists_as(tmp_dir) == 'directory'

    # test for FIFO
    os.mkfifo(tmp_fifo)
    assert exists_as(tmp_fifo) == 'FIFO'

    os.unlink(tmp_file)
    os.rmdir(tmp_dir)

# Generated at 2022-06-25 17:38:50.258817
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'

    path = Path('/')
    assert exists_as(path) == 'directory'

    path = Path('/')
    assert exists_as(path) == 'directory'



# Generated at 2022-06-25 17:38:52.899901
# Unit test for function exists_as
def test_exists_as():
    # Test if broken symbolic link is detected
    with tempfile.TemporaryDirectory() as temp_dir:
        link_path = Path(temp_dir) / 'broken_symlink'
        link_path.symlink_to('/no/such/path')
        assert exists_as(link_path) == '', 'Broken link should return empty string'


# Generated at 2022-06-25 17:39:01.979358
# Unit test for function path_absent
def test_path_absent():
    test_dir = Path(__file__).parent
    # Make a directory for tests
    test_dir /= get_random_string()

# Generated at 2022-06-25 17:39:12.571107
# Unit test for function chown
def test_chown():
    os.chdir(os.path.abspath(__file__))
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'foo.txt')
    with open(path, 'w') as f:
        f.write('test')
    os.chown(path, os.getuid(), os.getgid())
    os.fchown(f.fileno(), os.getuid(), os.getgid())
    os.lchown(path, os.getuid(), os.getgid())
    os.lchown(path, os.getuid(), os.getgid())
    os.remove(path)


# Generated at 2022-06-25 17:39:23.753959
# Unit test for function path_absent
def test_path_absent():
    """Unit test for :func:`path_absent`."""
    tmp = Path('/tmp')
    try:
        path_absent(tmp)
    except Exception as e:
        print(e)

    test_path = tmp / 'flutils-pathutils'
    test_path.mkdir()
    test_path.chmod(mode=0o700)
    f = test_path / 'test_file'
    f.touch(mode=0o400)
    test_subdir = test_path / 'test_subdir'
    test_subdir.mkdir()
    test_subdir.chmod(mode=0o700)
    f = test_subdir / 'test_subdir_file'
    f.touch(mode=0o400)
    path_absent(test_subdir)

# Generated at 2022-06-25 17:39:29.168812
# Unit test for function exists_as
def test_exists_as():
    test_path = Path('~/tmp/flutils.tests.test_path.tmp')
    try:
        test_path.touch()

        assert exists_as(test_path) == 'file'

        test_path.unlink()

        assert exists_as(test_path) == ''

    finally:
        if test_path.exists():
            test_path.unlink()



# Generated at 2022-06-25 17:39:32.800062
# Unit test for function chown
def test_chown():
    test_1()
    test_2()
    test_3()
    test_4()
    test_5()
    test_6()
    test_7()
    test_8()
    test_9()
    test_10()
    test_11()
    test_12()
    test_13()
    test_14()


# Generated at 2022-06-25 17:39:44.425680
# Unit test for function chown
def test_chown():
    home_dir = Path.home()
    test_dir = Path(home_dir, 'tmp')
    test_file = Path(test_dir, 'flutils.tests.osutils.txt')
    try:
        test_file.touch()
        assert test_file.exists() is True
        chown(test_file, user='root', group='root')
        with suppress(OSError):
            get_os_group(group='root').gr_gid
        with suppress(OSError):
            get_os_user(user='root').pw_uid
    finally:
        if test_file.is_file() is True:
            test_file.unlink()
        if test_dir.is_dir() is True:
            test_dir.rmdir()


# Generated at 2022-06-25 17:40:18.380519
# Unit test for function path_absent
def test_path_absent():

    # Flush out any possible tests path to ensure its absence
    path_absent(TEST_PATH)

    # Create a file
    with open(TEST_PATH, 'w'):
        pass
    assert os.path.exists(TEST_PATH) is True
    assert os.path.isfile(TEST_PATH) is True
    path_absent(TEST_PATH)
    assert os.path.exists(TEST_PATH) is False

    with open(TEST_PATH, 'w'):
        pass
    assert os.path.exists(TEST_PATH) is True
    os.symlink(TEST_PATH, TEST_PATH_SYM)
    assert os.path.exists(TEST_PATH_SYM) is True

# Generated at 2022-06-25 17:40:27.337464
# Unit test for function chown
def test_chown():
    from io import StringIO
    from unittest import TestCase

    from flutils.systemutils import get_grp_groups

    from . import pathutils

    ###########################################################################
    # The following has been commented out because of the calls to getgrnam()
    # and getpwnam() which will get the information for the current user on
    # the system the tests are being run on.  This information could change
    # over time and cause the tests to fail.  Hard-coding the results is not
    # an ideal solution either.

    # class _TestCase(TestCase):
    #     def __init__(self, *args, **kwargs):
    #         super().__init__(*args, **kwargs)
    #         self.user = getpass.getuser()
    #         self.group = get_grp_

# Generated at 2022-06-25 17:40:39.225716
# Unit test for function chmod
def test_chmod():
    if os.path.isdir('_tmp_test_chmod') is True:
        shutil.rmtree('_tmp_test_chmod')

    os.makedirs('_tmp_test_chmod')
    path = '_tmp_test_chmod/test_file.txt'

    with open(path, 'w') as fh:
        fh.write('testtest')

    chmod(path, 0o660)

    with open(path, 'r') as fh:
        assert fh.read() == 'testtest'

    chmod('_tmp_test_chmod', mode_file=0o660, mode_dir=0o770)

    shutil.rmtree('_tmp_test_chmod')


# Generated at 2022-06-25 17:40:49.382069
# Unit test for function exists_as
def test_exists_as():
    local_dir = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(local_dir, 'file')
    path_type = exists_as(path)
    assert path_type == 'file'
    
    path = os.path.join(local_dir, 'dir')
    path_type = exists_as(path)
    assert path_type == 'directory'
    
    path = os.path.join(local_dir, 'should_not_exist')
    path_type = exists_as(path)
    assert path_type == ''
    
    path = os.path.join(local_dir, 'broken_link')
    path_type = exists_as(path)
    assert path_type == ''
    

# Generated at 2022-06-25 17:40:54.629665
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('/')
    assert exists_as(path) == 'directory'
    path = normalize_path('/etc/hosts')
    assert exists_as(path) == 'file'

if __name__ == '__main__':
    test_exists_as()
    test_case_0()
    print("Success!")

# Generated at 2022-06-25 17:41:07.137155
# Unit test for function directory_present
def test_directory_present():
    path = Path.home() / 'test_directory_present'

    for _ in range(2):
        directory_present(path)
        # Check that the directory path exists
        assert path.exists() is True
        # Check that the given path is a directory
        assert path.is_dir()

        # Check the modes of the given path and it's parent
        assert path.stat().st_mode & 0o0777 == 0o700
        assert path.parent.stat().st_mode & 0o0777 == 0o700

        # Check the Owner and Group of the given path and it's parent
        assert path.stat().st_uid == os.getuid()
        assert path.stat().st_gid == os.getgid()
        assert path.parent.stat().st_uid == os.getuid()
        assert path.parent

# Generated at 2022-06-25 17:41:15.852435
# Unit test for function path_absent
def test_path_absent():
    # First create some files and directories
    dirs = ['~/tmp/test_path_absent_1', '~/tmp/test_path_absent_1/foo',
            '~/tmp/test_path_absent_1/bar']
    files = ['~/tmp/test_path_absent_1/foo.txt',
             '~/tmp/test_path_absent_1/bar.txt']
    for d in dirs:
        mkdir(d)
    for f in files:
        with open(f, 'w'):
            pass

    # Now let's remove them
    path_absent('~/tmp/test_path_absent_1')
    for d in dirs:
        d = normalize_path(d)
        assert not d.is_dir()