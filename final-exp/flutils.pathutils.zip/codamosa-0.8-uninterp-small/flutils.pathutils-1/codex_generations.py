

# Generated at 2022-06-25 17:32:08.335462
# Unit test for function chmod
def test_chmod():
    print(chmod.__doc__)
    chmod('/home/user/somedir/somename.txt', 0o660)

# unit test for function chown

# Generated at 2022-06-25 17:32:09.704780
# Unit test for function exists_as
def test_exists_as():
    pass


# Generated at 2022-06-25 17:32:17.980927
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('esto_no_existe') == ''
    assert exists_as('~/Library/Preferences/Xcode') == 'directory'
    assert exists_as('~/.bash_profile') == 'file'
    assert exists_as('/dev/disk1s1') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/null') == 'FIFO'
    assert exists_as('/var/run/syslog') == 'socket'



# Generated at 2022-06-25 17:32:22.038315
# Unit test for function find_paths
def test_find_paths():
    assert len(list(find_paths('~/tmp/*'))) == 2
    assert len(list(find_paths('~/tmp/**'))) == 5
    assert len(list(find_paths('/tmp/*'))) == 2
    assert len(list(find_paths('/tmp/**'))) == 5
    try:
        result = list(find_paths('/home/test_user/tmp/*'))
    except NotImplementedError:
        pass
    else:
        assert len(result) == 2
    try:
        result = list(find_paths('/home/test_user/tmp/**'))
    except NotImplementedError:
        pass
    else:
        assert len(list(find_paths('/home/test_user/tmp/**'))) == 5

# Generated at 2022-06-25 17:32:24.881404
# Unit test for function chmod
def test_chmod():
    chmod(Path('/home/mike/test/test.txt'))
    chmod(Path('/home/mike/test/test.txt'), 0o750)



# Generated at 2022-06-25 17:32:26.774411
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-25 17:32:31.618516
# Unit test for function path_absent
def test_path_absent():
    for path in ['./test_path_absent', '/tmp/test_path_absent']:
        try:
            os.mkdir(path)
        except FileExistsError:
            pass
        assert path_absent(path) is None
        assert exists_as(path) == ''



# Generated at 2022-06-25 17:32:41.488436
# Unit test for function chmod
def test_chmod():
    path_to_create = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path_to_create)
    if os.path.exists(path):
        os.remove(path)
    assert os.path.exists(path) is False
    chmod(path)
    assert os.path.exists(path) is True
    assert os.stat(path).st_mode == 33152
    os.remove(path)
    assert os.path.exists(path) is False
    chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o760, mode_dir=0o760)
    assert os.path.exists(path) is True
    assert os.stat(path).st_mode == 33152

# Generated at 2022-06-25 17:32:50.499540
# Unit test for function chmod
def test_chmod():
    # Test for function chmod

    # Setup
    path = normalize_path('./tmp/flutils.tests.osutils.txt')

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w') as f:
        f.write('Hello World!')

    # Actual call
    assert os.stat(path).st_mode & 0o777 == 0o644
    chmod(path, mode_file=0o660)

    # Asserts
    assert os.stat(path).st_mode & 0o777 == 0o660
    assert os.stat(path.parent).st_mode & 0o777 == 0o700

    # Teardown
    # Removes the resulting file
    path.parent.rmdir()



# Generated at 2022-06-25 17:32:54.752304
# Unit test for function path_absent
def test_path_absent():
    create_directories('~/tmp/test_absent')
    path_absent('~/tmp/test_absent')
    assert exists_as('~/tmp/test_absent') == '', 'the path should be removed'


# Generated at 2022-06-25 17:33:12.497359
# Unit test for function path_absent
def test_path_absent():
    tmp_dir_path = Path('~/tmp')
    if tmp_dir_path.exists():
        path_absent(tmp_dir_path)
    assert not tmp_dir_path.exists()


# Generated at 2022-06-25 17:33:18.254550
# Unit test for function chown
def test_chown():
    r1 = chown(path="~/tmp/flutils.tests.osutils.txt", user="-1", group="-1")
    r2 = chown(path="~/tmp/**", user="-1", group="-1")
    r3 = chown(path="~/tmp/*", user="foo", group="bar")


# Generated at 2022-06-25 17:33:23.813911
# Unit test for function chmod
def test_chmod():
    passwd = get_os_user()
    path = Path("/home/%s/flutils.test.txt" % passwd.pw_name)
    if path.exists():
        chmod("/home/%s/flutils.test.txt" % passwd.pw_name, 0o644)
    else:
        print("No such file")


# Generated at 2022-06-25 17:33:31.321324
# Unit test for function exists_as
def test_exists_as():
    # Python 3.8+ pathlib.Path methods that support symlinks:
    #
    #     Path.is_block_device()
    #     Path.is_char_device()
    #     Path.is_dir()
    #     Path.is_fifo()
    #     Path.is_file()
    #     Path.is_mount()
    #     Path.is_socket()
    #     Path.is_symlink()
    #

    def exists_as_test(dname, ttype, tstr):
        dpath = normalize_path(dname)
        assert exists_as(dpath) == ttype, ('Expected type: %s, found: %s'
                                            % (ttype, exists_as(dpath)))
        print('Test case "%s" passed' % tstr)

# Generated at 2022-06-25 17:33:36.506236
# Unit test for function exists_as
def test_exists_as():
    my_file = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    with my_file.open('w') as f:
        f.write('Test.\n')

    assert exists_as(my_file) == 'file'

if __name__ == '__main__':
    print(__file__)
    print(directory_present('~/tmp/flutils.tests.pathutils'))
    print(get_os_user())


# ##########################################################################
# vim:set et ts=4 sw=4:

# Generated at 2022-06-25 17:33:41.336128
# Unit test for function chown
def test_chown():
    p = Path(getpass.getuser()) / 'tmp/flutils.tests.pathutils.txt'
    p.touch(mode=0o600)
    chown(p, user='root')
    path = normalize_path(p)
    assert path.stat().st_uid == 0


# Generated at 2022-06-25 17:33:50.461134
# Unit test for function path_absent
def test_path_absent():
    # Test case #0
    case_name = 'Test case #0'
    try:
        path = '~/tmp/test_path'
        path_absent(path)
        if os.path.isdir(path):
            raise AssertionError(
                '%s: %r should **NOT** be a directory.' % (case_name, path)
            )
        if os.path.isfile(path):
            raise AssertionError(
                '%s: %r should **NOT** be a file.' % (case_name, path)
            )
    except Exception as err:
        print('%s: FAILED!' % case_name)
        raise err
    else:
        print('%s: PASSED' % case_name)
    # Test case #1

# Generated at 2022-06-25 17:33:52.410746
# Unit test for function path_absent
def test_path_absent():
    'Unit test for function path_absent'
    path = normalize_path('~/tmp/test_path')
    with path.open('w', encoding='utf-8') as test_file:
        pass
    path_absent(path)
    assert os.path.exists(path.as_posix()) is False


# Generated at 2022-06-25 17:33:54.453133
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-25 17:34:04.697981
# Unit test for function path_absent
def test_path_absent():
    """Test path_absent()
    """
    # create a test directory
    curdir = os.getcwd()
    testdir = os.path.join(curdir, 'test_path_absent')
    if os.path.isdir(testdir):
        shutil.rmtree(testdir)
    os.mkdir(testdir)
    os.chdir(testdir)
    # create various files and dirs
    os.mkdir('subdir0')
    os.mkdir('subdir1')
    os.mkdir('subdir1/subsubdir0')
    os.mkdir('subdir2')
    os.mkdir('subdir2/subsubdir0')
    os.mkdir('subdir2/subsubdir1')

# Generated at 2022-06-25 17:34:25.512223
# Unit test for function path_absent
def test_path_absent():
    # Test if function works on standard path
    path_absent('~/tmp/test_path')
    assert not os.path.exists('~/tmp/test_path'), '~/tmp/test_path removed'
    # Test not on path
    path_absent('~/tmp/test_path_not_exist')
    assert not os.path.exists('~/tmp/test_path_not_exist'), \
    '~/tmp/test_path_not_exist not removed'
    # Test if function works on path with globbing
    path_absent('~/tmp/test_path*')
    assert not os.path.exists('~/tmp/test_path_not_exist'), \
    '~/tmp/test_path removed'
    # Test if function fails on an existing directory

# Generated at 2022-06-25 17:34:27.807746
# Unit test for function path_absent
def test_path_absent():
    """Test function: path_absent"""
    path = Path('/tmp/test_path_absent/foo/bar')
    path.mkdir(parents=True)
    try:
        assert path.exists()
        path_absent(str(path))
        assert path.exists() is False
    finally:
        if path.exists():
            shutil.rmtree(path)


# Generated at 2022-06-25 17:34:35.111865
# Unit test for function exists_as
def test_exists_as():
    non_existant_path = Path(Path().home() / 'non_existant_path')
    assert exists_as(non_existant_path) == ''

    directory_path = Path(Path().home() / 'tmp')
    assert exists_as(directory_path) == 'directory'

    file_path = Path(Path().home() / 'file_0')
    assert exists_as(file_path) == 'file'

    fifo_path = Path(Path().home() / 'fifo_0')
    assert exists_as(fifo_path) == 'FIFO'

    socket_path = Path(Path().home() / 'socket_0')
    assert exists_as(socket_path) == 'socket'

# Generated at 2022-06-25 17:34:38.410773
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('/tmp/test_directory_present_0') == '/tmp/test_directory_present_0'


# Generated at 2022-06-25 17:34:41.862092
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'



# Generated at 2022-06-25 17:34:55.456867
# Unit test for function path_absent
def test_path_absent():
    tmp = Path('.').joinpath('flutils', 'tests', 'tmp')
    path = tmp.joinpath('test_path')
    tmp.mkdir(parents=True, exist_ok=True)
    path.mkdir()
    path_absent(path)
    assert not os.path.exists(path)
    path.mkdir()
    path.joinpath('sub_tmp').mkdir()
    path_absent(path)
    assert not os.path.exists(path)
    path.touch()
    path_absent(path)
    assert not os.path.exists(path)
    path.mkdir()
    path.write_text('foo')
    path_absent(path)
    assert not os.path.exists(path)



# Generated at 2022-06-25 17:35:05.992591
# Unit test for function exists_as
def test_exists_as():
    struct_passwd_0 = get_os_user()
    struct_passwd_1 = get_os_user(struct_passwd_0.pw_uid)
    struct_passwd_2 = get_os_user(struct_passwd_0.pw_name)
    assert struct_passwd_0.pw_name == struct_passwd_1.pw_name, (
        'The results of get_os_user() with user name and uid should be '
        'equivalent'
    )
    assert struct_passwd_0.pw_name == struct_passwd_2.pw_name, (
        'The results of get_os_user() with user name and uid should be '
        'equivalent'
    )

# Generated at 2022-06-25 17:35:12.026477
# Unit test for function path_absent
def test_path_absent():
    dt = datetime.datetime.now()
    dt_str = dt.strftime('%Y-%m-%d-%H-%M-%S-%f')
    tmp_path = Path(os.environ['HOME']) / 'tmp'
    p = tmp_path / 'test_path' / dt_str
    assert p.exists() is False
    p.mkdir()
    assert p.exists() is True
    p_one = p / 'one'
    p_one.write_text('one')
    p_two = p / 'two'
    p_two.mkdir()
    p_three = p_two / 'three'
    p_three.mkdir()
    p_four = p_three / 'four'

# Generated at 2022-06-25 17:35:13.915723
# Unit test for function chmod
def test_chmod():
    path = Path('./file_1.txt')
    chmod(path)


# Generated at 2022-06-25 17:35:26.368751
# Unit test for function chown
def test_chown():
    test_path = '~/tmp/flutils.pathutils.tests.txt'
    test_path = normalize_path(test_path)

    def test_case_0():
        # This should fail since we have not created the path yet
        chown(test_path)
    assert_raises(FileNotFoundError, test_case_0)

    open(test_path.as_posix(), 'x').close()

    def test_case_1():
        chown(test_path, user='-1', group='-1')
    test_case_1()

    # The call to chown() set the path to the current user, this
    # value should equal the username of the current user.

# Generated at 2022-06-25 17:35:55.238713
# Unit test for function directory_present
def test_directory_present():
    dir_path = directory_present('/tmp/unittest_flutils.pathutils')
    dir_path = directory_present('/tmp/unittest_flutils.pathutils/a/b/c')
    dir_path = directory_present('/tmp/unittest_flutils.pathutils/a/d/e')



# Generated at 2022-06-25 17:36:03.297196
# Unit test for function chown
def test_chown():
    test_dir = Path('./test_dir')
    test_dir.mkdir()
    os.chown(test_dir.as_posix(), 0, 0)
    chown(test_dir.as_posix(), 'nobody', 'nobody')
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()
    assert struct_passwd_0.pw_name == 'nobody'
    assert struct_group_0.gr_name == 'nobody'
    test_dir.rmdir()


# Generated at 2022-06-25 17:36:04.423405
# Unit test for function path_absent
def test_path_absent():
    path_absent('~/tmp/test_path')



# Generated at 2022-06-25 17:36:11.641237
# Unit test for function path_absent
def test_path_absent():
    # Test that a path can be removed if it is a file
    path_absent('~/tmp/test_file')
    assert(not exists_as('~/tmp/test_file'))

    # Test that an absent file does nothing
    path_absent('~/tmp/test_file_2')
    assert(not exists_as('~/tmp/test_file_2'))

    # Test that a symbollic link to a file can be removed
    path_present('~/tmp/test_file_3', type='symlink')
    path_absent('~/tmp/test_file_3')
    assert(not exists_as('~/tmp/test_file_3'))

    # Test that an absent symbollic link does nothing
    path_absent('~/tmp/test_file_4')

# Generated at 2022-06-25 17:36:20.845830
# Unit test for function chmod
def test_chmod():
    import flutils.pathutils

    # Test path without glob pattern
    path = 'test_fxc/ut/pathutils/test_chmod/test1.txt'
    os.makedirs(os.path.dirname(path), mode=0o644, exist_ok=True)
    with open(path,'w') as f:
        f.write("Test")
    flutils.pathutils.chmod(path, 0o644)
    assert os.stat(path).st_mode & 0o777 == 0o644


    # Test glob pattern with **
    path = 'test_fxc/ut/pathutils/test_chmod/test2.txt'
    os.makedirs(os.path.dirname(path), mode=0o644, exist_ok=True)

# Generated at 2022-06-25 17:36:31.729555
# Unit test for function exists_as
def test_exists_as():
    if os.getuid() == 0:
        user = 'root'
        group = 'wheel'
    else:
        user = os.getlogin()
        group = grp.getgrgid(os.getgid()).gr_name

    test_dir = directory_present(
        os.path.expanduser('~/tmp/flutils.tests.pathutils'),
        user=user,
        group=group,
    )
    assert exists_as(test_dir) == 'directory', exists_as(test_dir)

    test_file = test_dir / 'test.txt'
    open(test_file, mode='w').close()
    assert exists_as(test_file) == 'file', exists_as(test_file)

    test_block_dev = test_dir / 'test_block'


# Generated at 2022-06-25 17:36:35.382398
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/test_path', user='-1', group='-1')
    assert os.path.exists('~/tmp/test_path')
    assert os.path.isdir('~/tmp/test_path')
    assert os.path.isfile('/etc/passwd') == False
    assert os.path.islink('/etc/passwd') == False


# Generated at 2022-06-25 17:36:40.627720
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    with tempfile.TemporaryDirectory() as tdir:
        tdir = Path(tdir)
        test_dir = tdir / 'test'
        test_dir_2 = tdir / 'test/test_2'
        test_file = tdir / 'test_file'
        test_file_2 = tdir / 'test/test_file_2'
        link_1 = tdir / 'link_1'
        link_2 = tdir / 'test/link_2'
        test_dir.mkdir()
        test_dir_2.mkdir()
        test_file.touch()
        test_file_2.touch()
        link_1.symlink_to('/bin/sh')
        link_2.symlink_to('/bin/dash')

# Generated at 2022-06-25 17:36:42.138490
# Unit test for function path_absent
def test_path_absent():
    path = pathlib.Path("/home/test/test_file")
    path_absent(path)
    assert not os.path.exists("/home/test/test_file")


# Generated at 2022-06-25 17:36:47.781987
# Unit test for function chown
def test_chown():
    test_dir = Path.cwd() / 'tmp_chown_test_dir'
    test_file = test_dir / 'tmp_chown_test_file'
    test_file.touch()

    chown(test_file)

    test_file.unlink()
    test_dir.rmdir()



# Generated at 2022-06-25 17:37:17.499218
# Unit test for function chmod
def test_chmod():
    path = './test/pathutils/tmp/chmod.txt'
    chmod(path, 0o660)
    assert os.stat(path).st_mode & 0o777 == 0o660
    os.remove(path)

    path = './test/pathutils/tmp/chmod'
    chmod(path, None, 0o770)
    assert os.stat(path).st_mode & 0o777 == 0o770
    os.rmdir(path)


# Generated at 2022-06-25 17:37:22.243090
# Unit test for function chmod
def test_chmod():

    myfile = '/tmp/myfile.txt'
    mydir = '/tmp/mydir'

    Path(myfile).touch()
    Path(mydir).mkdir()

    chmod(myfile, include_parent=True)
    chmod(mydir, include_parent=True)


# Generated at 2022-06-25 17:37:30.771308
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group(struct_passwd_0.pw_name)
    test_path = '~/tmp/test'
    path_0 = chown(normalize_path(test_path))
    with open(path_0, 'w') as fp:
        fp.write('This is test_chown.py')
    path_1 = chown(normalize_path(test_path), user=struct_passwd_0.pw_name,
                   group=struct_passwd_0.pw_name)
    path_2 = chown(normalize_path(test_path), user=struct_passwd_0.pw_name,
                   group=struct_group_0.gr_gid)


# Generated at 2022-06-25 17:37:42.957238
# Unit test for function exists_as
def test_exists_as():
    ''' Test the exists_as function with several path inputs'''

    def test_path_helper(path, expected):
        '''Helper function used to test the exists_as function with several inputs'''
        assert exists_as(path) == expected

    test_path_helper('/Users/Len/tmp/flutils.tests.osutils.txt', 'file')
    test_path_helper('/', 'directory')
    test_path_helper('~/tmp', 'directory')
    test_path_helper('~/', 'directory')
    test_path_helper('/dev', 'directory')
    test_path_helper('/dev/null', 'char device')
    test_path_helper('/dev/zero', 'char device')

# Generated at 2022-06-25 17:37:52.484505
# Unit test for function chmod
def test_chmod():
    import tempfile
    import pathlib
    import os.path
    import os
    import shutil

    curr_temp_path = os.path.join(tempfile.gettempdir(), "flutils")
    curr_temp_file = os.path.join(curr_temp_path, 
                                  "flutils.tests.osutils.txt")
    curr_temp_dir = os.path.join(curr_temp_path, "test1")

    
    # creating temporary file
    #print("Testing chmod function: creating temporary file...")
    with open(curr_temp_file, 'w') as f:
        f.write("test string")

    # creating temporary directory
    #print("Testing chmod function: creating temporary directory...")
    os.mkdir(curr_temp_dir)


# Generated at 2022-06-25 17:38:03.892751
# Unit test for function exists_as
def test_exists_as():
    exists_as_test_path = Path(os.path.expanduser('~/tmp/tmp_test_file.txt'))
    exists_as_test_path_2 = Path(os.path.expanduser('~/tmp/tmp_test_file_2.txt'))
    exists_as_test_path_3 = Path(os.path.expanduser('~/tmp/tmp_test_dir'))
    exists_as_test_path_4 = Path(os.path.expanduser('~/tmp/tmp_test_dir/dir_tmp_test_file.txt'))

    exists_as_test_path_3.mkdir(mode=0o700)
    chown(exists_as_test_path_3)


# Generated at 2022-06-25 17:38:09.535287
# Unit test for function chmod
def test_chmod():
    struct_passwd_0 = test_case_0()
    chmod("./flutils_test_directory", mode_file=0o770)
    chmod("./flutils_test_directory/test_file", mode_file=0o770)
    chmod("./flutils_test_directory/test_file", mode_file=0o770)



# Generated at 2022-06-25 17:38:18.965704
# Unit test for function chmod
def test_chmod():
    home = Path.home()
    temp_dir = home / 'tmp' / 'flutils.tests.osutils'
    if not temp_dir.exists():
        temp_dir.mkdir(parents=True, exist_ok=True)
    num_files = 0
    filename = temp_dir / 'file.txt'
    filename.touch(mode=0o664, exist_ok=True)
    num_files += 1
    sub_dir = temp_dir / 'sub'
    sub_dir.mkdir(parents=True, exist_ok=True)
    filename = sub_dir / 'file.txt'
    filename.touch(mode=0o664, exist_ok=True)
    num_files += 1
    sub_sub_dir = sub_dir / 'sub'
    sub_sub_dir.mk

# Generated at 2022-06-25 17:38:30.192321
# Unit test for function exists_as
def test_exists_as():

    class TestExistsAs(unittest.TestCase):
        # Test the given path is not a directory
        def test_0(self):
            self.assertEqual(exists_as('~/.bash_profile'), 'file')

        # Test the given path is a directory
        def test_1(self):
            self.assertEqual(exists_as('~/'), 'directory')

        # Test the given path is a directory
        def test_2(self):
            self.assertEqual(exists_as('~/tmp'), 'directory')

        # Test the given path does not exist
        def test_3(self):
            self.assertEqual(exists_as('~/tmp/foo'), '')

        # Test the given path does not exist
        def test_4(self):
            self.assertEqual

# Generated at 2022-06-25 17:38:36.156535
# Unit test for function chmod
def test_chmod():
    chmod('/home/adam/tmp/flutils.test.chmod.txt', 0o660)

    """
    user_0 = get_os_user()
    group_0 = get_os_group(user_0)
    chown('/home/adam/tmp/flutils.test.chmod.txt', user_0, group_0)
    """


# Generated at 2022-06-25 17:39:12.143738
# Unit test for function path_absent
def test_path_absent():
    base_dir = Path(__file__).parent
    test_dir = Path(base_dir, 'test_data')
    test_dir.mkdir(exist_ok=True, parents=True)
    os.chdir(base_dir)


# Generated at 2022-06-25 17:39:18.563344
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/opt') == 'directory'
    assert exists_as('/opt/') == 'directory'
    assert exists_as(b'/') == 'directory'
    assert exists_as(b'/opt') == 'directory'
    assert exists_as('/bin/bash') == 'file'
    assert exists_as('/bin/bash/') == ''
    assert exists_as('/bin/bash/foo') == ''
    assert exists_as('/bin/bash/foo/') == ''
    assert exists_as('/bin/bash/foo/bar') == ''
    assert exists_as('/bin/bash/foo/bar/') == ''


# Generated at 2022-06-25 17:39:29.089088
# Unit test for function chown
def test_chown():
    from os import chown, getgid, getuid, stat
    args = [
        'test_1',
        'test_2',
        'test_3',
        'test_4'
    ]
    # test if path is not a string and instance of Path
    # raises TypeError
    # path, user, group
    # path (:obj:`bytes` or :obj:`Path <pathlib.Path>`): The path...
    chown(False)
    chown(None, 1, 1)
    chown(1, None, None)
    chown(1, 1, None)
    chown(1, None, 1)
    # test if user is not an int or a string
    chown('~/tmp/flutils.tests.osutils.txt', True)
    # test if group is

# Generated at 2022-06-25 17:39:36.384433
# Unit test for function chown
def test_chown():
    import os
    import os.path
    import pwd
    import pytest

    def _chown(path, user, group, check_mode=False):

        uid = pwd.getpwnam(user).pw_uid
        gid = grp.getgrnam(group).gr_gid

        if path.exists():
            if path.is_dir():
                path.chmod(0o750)
                path.chown(uid, gid)

                if path.exists():
                    if path.is_dir():
                        if check_mode is True:
                            assert path.stat().st_mode & 0o700
                        assert path.stat().st_uid == uid
                        assert path.stat().st_gid == gid


# Generated at 2022-06-25 17:39:48.237217
# Unit test for function directory_present
def test_directory_present():
    test_path_0 = '~/tmp/test_path_0'
    test_path_1 = '~/tmp/test_path_1'
    test_path_2 = '~/tmp/test_path_2'
    test_path_3 = '~/tmp/test_path_3'
    test_path_4 = '~/tmp/test_path_4'
    test_path_5 = '~/tmp/test_path_5'
    test_path_6 = '~/tmp/test_path_6'
    test_path_7 = '~/tmp/test_path_7'
    struct_passwd_0 = get_os_user()
    struct_group_0 = get_os_group()
    uid = struct_passwd_0.pw_uid
    g

# Generated at 2022-06-25 17:39:54.882688
# Unit test for function chmod
def test_chmod():
    # Create a file and set its permissions
    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    path.touch()
    chmod(path, mode_file=0o660)
    # Assert that the file has the correct permissions
    os_instance = os.stat(path.as_posix())
    assert oct(os_instance.st_mode & 0o777) == '0o660'
    # Remove the file
    path.unlink()


# Generated at 2022-06-25 17:40:02.579835
# Unit test for function chmod
def test_chmod():
    try:
        # Create a file to test chmod with
        os.system(
            "echo '' > ./test_flutils_io.txt"
        )
    except Exception as err:
        print(
            str(err),
            file=sys.stderr
        )
        sys.exit(1)


# Generated at 2022-06-25 17:40:15.689042
# Unit test for function chmod
def test_chmod():
    """
    Returns:

    """
    import subprocess
    import tempfile
    import time

    tmp_dir = Path(
        tempfile.mkdtemp(prefix='flutils_test_chmod_')
    )

# Generated at 2022-06-25 17:40:17.384912
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.tmp', user='root', group='root')


# Generated at 2022-06-25 17:40:26.898561
# Unit test for function chmod
def test_chmod():
    # Check the mode of a newly created directory
    the_dir = Path('/tmp/flutils.tests.osutils.test_chmod.Cx18QQ')

    mode_dir = 0o700

    the_dir.mkdir(parents=True)
    try:
        assert the_dir.is_dir() is True
        assert the_dir.stat().st_mode & 0o777 == mode_dir

    # Change the mode of the directory, and check the change.
    finally:
        chmod(
            the_dir,
            mode_file=0o660,
            mode_dir=0o770
        )

        the_dir_stat = the_dir.stat()
        assert (the_dir_stat.st_mode & 0o777) == 0o770

        the_dir.rmdir()

   

# Generated at 2022-06-25 17:40:59.164678
# Unit test for function path_absent
def test_path_absent():
    test_dir = Path('/tmp/flutils/pathutils_test')
    subdir_1 = test_dir.joinpath('subdir_1')
    subdir_2 = test_dir.joinpath('subdir_2')
    file_1 = subdir_1.joinpath('file_1')
    file_2 = subdir_2.joinpath('file_2')

    path_parent(test_dir)
    path_directory(subdir_1)
    path_directory(subdir_2)
    path_file(file_1)
    path_file(file_2)

    path_absent(test_dir)

    try:
        path_absent(test_dir)
    except Exception:
        assert False

    assert path_exists(test_dir) is False



# Generated at 2022-06-25 17:41:04.049757
# Unit test for function path_absent
def test_path_absent():
    """
    Unit test for path_absent
    """
    try:
        os.mkdir('test_path')
        assert os.path.exists('test_path')
        path_absent('test_path')
        assert not os.path.exists('test_path')
    finally:
        if os.path.exists('test_path'):
            os.rmdir('test_path')


# Generated at 2022-06-25 17:41:09.832710
# Unit test for function path_absent
def test_path_absent():
    path = './tmp.test'
    path_absent(path)

    # Call again to verify no failure occurs
    path_absent(path)

    open(path, 'a').close()

    path_absent(path)

if __name__ == '__main__':
    test_case_0()
    test_path_absent()