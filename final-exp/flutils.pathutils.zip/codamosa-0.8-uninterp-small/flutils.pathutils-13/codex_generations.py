

# Generated at 2022-06-25 17:31:28.199966
# Unit test for function exists_as
def test_exists_as():
    path_0 = '~/tmp'
    assert exists_as(path_0) == 'directory'


# Generated at 2022-06-25 17:31:38.345350
# Unit test for function chmod
def test_chmod():
    path_0 = '/sbin/launchd' # Variable path_0
    chmod(path_0, 0o600, 0o700)
    path_1 = '/Users/jackson/tmp/flutils.tests.osutils.txt' # Variable path_1
    chmod(path_1, 0o660)
    path_2 = '/home/jackson/tmp/flutils.tests.osutils.txt' # Variable path_2
    chmod(path_2, 0o660)
    path_3 = '/' # Variable path_3
    chmod(path_3, 0o600, 0o700)
    path_4 = '/Users/jackson/tmp' # Variable path_4
    chmod(path_4, 0o600, 0o700)

# Generated at 2022-06-25 17:31:45.657821
# Unit test for function find_paths
def test_find_paths():
    path = Path('/Users/len/tmp/flutils.tests.osutils')
    path.mkdir(0o700, parents=True, exist_ok=True)
    path.joinpath('file_one').touch()
    path.joinpath('dir_one').mkdir(0o700)
    path.joinpath('dir_one').joinpath('file_two').touch()
    expected = [
        Path('/Users/len/tmp/flutils.tests.osutils/file_one'),
        Path('/Users/len/tmp/flutils.tests.osutils/dir_one/file_two')
    ]
    actual = list(find_paths('~/tmp/flutils.tests.osutils/*'))
    assert actual == expected

# Generated at 2022-06-25 17:31:47.527118
# Unit test for function exists_as
def test_exists_as():
    path = '/tmp/foo'
    path_0 = exists_as(path)
    assert path_0 == ''



# Generated at 2022-06-25 17:31:49.881293
# Unit test for function path_absent
def test_path_absent():
    path = '/tmp/test_path'
    path_absent(path)
    path_absent('~/tmp/test_path')
    path_absent('~test_user/tmp/test_path')


# Generated at 2022-06-25 17:31:52.969088
# Unit test for function find_paths
def test_find_paths():
    pattern = os.path.expanduser('~/tmp/file_one')
    with pytest.warns(DeprecationWarning, match=r'.*find_paths'):
        find_paths(pattern)



# Generated at 2022-06-25 17:32:02.831587
# Unit test for function chown

# Generated at 2022-06-25 17:32:05.305111
# Unit test for function find_paths
def test_find_paths():
    from glob import glob

    path_like_0 = '~/tmp/*'
    list_0 = list(find_paths(path_like_0))
    list_1 = glob(path_like_0)
    assert list_0 == list_1


# Generated at 2022-06-25 17:32:07.237154
# Unit test for function find_paths
def test_find_paths():
    path = find_paths('~/tmp')
    assert path is None


# Generated at 2022-06-25 17:32:12.435689
# Unit test for function chown
def test_chown():
    path_0 = normalize_path('directory_with_colon')
    path_1 = normalize_path('directory_with_colon')
    chown(path_0, '0', '1', True)


# Generated at 2022-06-25 17:32:36.831467
# Unit test for function chmod
def test_chmod():
    test_dir = '~/tmp/flutils.tests.osutils'
    test_dir = Path(test_dir).expanduser()
    if test_dir.exists() is False:
        Path.mkdir(test_dir, parents=True)

    test_fn = test_dir / 'test_chmod.txt'
    Path.touch(test_fn)
    if test_fn.exists() is False:
        raise Exception('Assertion error!')
    if test_fn.is_dir() is True:
        raise Exception('Assertion error!')
    if test_fn.is_file() is False:
        raise Exception('Assertion error!')
    if test_fn.is_symlink() is True:
        raise Exception('Assertion error!')

# Generated at 2022-06-25 17:32:47.758773
# Unit test for function exists_as
def test_exists_as():
    # Create directory
    tempdir = 'flutils_test_exists_as'
    directory_present('/tmp/{}'.format(tempdir))
    # Test directory
    assert exists_as('/tmp/{}'.format(tempdir)) == 'directory'

    # Create file flutils_test_exists_as_file
    with open('/tmp/{}/flutils_test_exists_as_file'.format(tempdir), 'w'):
        pass
    # Test file
    assert exists_as('/tmp/{}/flutils_test_exists_as_file'.format(tempdir)) == 'file'

    # Create broken symbolic link
    os.symlink('/does/not/exist', '/tmp/{}/broken_symlink'.format(tempdir))
    # Test broken symbolic

# Generated at 2022-06-25 17:33:01.474411
# Unit test for function chown
def test_chown():
    struct_passwd_0 = get_os_user()
    struct_passwd_1 = get_os_user("root")
    assert struct_passwd_1.pw_uid != struct_passwd_0.pw_uid

    assert 0 == len(find_paths("*", "~/tmp/test_chown"))
    normalize_path("~/tmp/test_chown").mkdir(parents=True, exist_ok=True)
    normalize_path("~/tmp/test_chown/tmp").mkdir(parents=True, exist_ok=True)
    normalize_path("~/tmp/test_chown/bar").mkdir(parents=True, exist_ok=True)

# Generated at 2022-06-25 17:33:05.656916
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Supports a glob pattern.  So to recursively change the mode
    # of a directory just do:
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # To change the mode of a directory's immediate contents:
    chmod('~/tmp/*')


# Generated at 2022-06-25 17:33:07.701853
# Unit test for function chown
def test_chown():
    assert chown("C:\\Users\\s3.txt")

# Generated at 2022-06-25 17:33:17.261914
# Unit test for function exists_as
def test_exists_as():
    print('Testing exists_as...')
    if exists_as('/usr/bin') != 'directory':
        print('exists_as(): Failure')
        return 1
    if exists_as('/usr/bin/python') != 'file':
        print('exists_as(): Failure')
        return 1
    if exists_as('/dev/tty') != 'char device':
        print('exists_as(): Failure')
        return 1
    if exists_as('/dev/sda1') != 'block device':
        print('exists_as(): Failure')
        return 1
    if exists_as('/dev/log') != 'socket':
        print('exists_as(): Failure')
        return 1

# Generated at 2022-06-25 17:33:23.565702
# Unit test for function exists_as
def test_exists_as():
    if exists_as('/') != 'directory':
        raise Exception('Expected directory. Got: %s' % exists_as('/'))
    if exists_as('.') != 'directory':
        raise Exception('Expected directory. Got: %s' % exists_as('.'))
    if exists_as('/etc/fstab') != 'file':
        raise Exception('Expected file. Got: %s' % exists_as('/etc/fstab'))


# Generated at 2022-06-25 17:33:31.098512
# Unit test for function chown
def test_chown():
    path = '/tmp/flutils.tests.osutils.txt'
    pathlib_path = Path(path)
    if pathlib_path.exists():
        pathlib_path.unlink()

    if pathlib_path.exists():
        raise RuntimeError("Could not remove {}".format(path))

    pathlib_path.touch()
    if not pathlib_path.exists():
        raise RuntimeError("Could not create {}".format(path))

    chown(path)
    stat_result = pathlib_path.stat()
    struct_passwd = get_os_user()
    result_user_id = stat_result.st_uid
    if result_user_id != struct_passwd.pw_uid:
        raise RuntimeError("Invalid user id")


# Generated at 2022-06-25 17:33:37.504778
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')
    # Test with chmod with invalid path and arbitrary mode values

# Generated at 2022-06-25 17:33:38.729386
# Unit test for function chown
def test_chown():
    chown(user='-1')


# Generated at 2022-06-25 17:33:50.711496
# Unit test for function exists_as
def test_exists_as():
    path_0 = '/home/gdf001/Downloads/'
    path_1 = Path('home/gdf001/Downloads/')
    print(Path.exists(path_0))
    print(exists_as(path_1))

test_exists_as()

# Generated at 2022-06-25 17:33:56.220293
# Unit test for function chown
def test_chown():
    """To test chown function with correct inputs"""
    chown('/tmp/flutils.tests.osutils-txt', user='root', group='root')
    assert path_absent('/tmp/flutils.tests.osutils-txt') == True
    
    

# Generated at 2022-06-25 17:34:06.452149
# Unit test for function chown
def test_chown():
    import shutil
    cur_user = getpass.getuser()
    cur_group = getpass.getuser()
    tmp_dir = Path("/tmp") / f"ft_chown_{cur_user}"
    tmp_file = Path("/tmp") / f"ft_chown_{cur_user}.txt"
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)
    if tmp_file.exists():
        tmp_file.unlink()

    os.makedirs(tmp_dir)
    Path(tmp_file).touch()

    assert get_os_user(getpass.getuser())
    assert get_os_group(getpass.getuser())

    chown(tmp_file, getpass.getuser())

    file_stat = tmp_file.stat()
   

# Generated at 2022-06-25 17:34:13.325557
# Unit test for function exists_as
def test_exists_as():
    test_path=normalize_path('test_exists_as')
    if exists_as(test_path):
        directory_present(test_path)
        assert exists_as(test_path) == 'directory'
    else:
        directory_present(test_path)
        assert exists_as(test_path) == 'directory'
    if exists_as(test_path / 'test_exists_as_1'):
        assert exists_as(test_path / 'test_exists_as_1') == ''
    else:
        assert exists_as(test_path / 'test_exists_as_1') == ''
    

# Generated at 2022-06-25 17:34:14.544316
# Unit test for function chown
def test_chown():
    os.chown(path='~/tmp/foo.txt', user='foo', group='bar')


# Generated at 2022-06-25 17:34:15.384792
# Unit test for function chmod
def test_chmod():
    pass


# Generated at 2022-06-25 17:34:19.587537
# Unit test for function chmod
def test_chmod():
    test_file = '~/tmp/flutils_test.txt'

    chmod('/tmp/flutils_test.txt', 0o660)
    assert os.stat(test_file).st_mode

    chmod('/tmp/flutils_test.txt', 0o660)
    assert os.stat(test_file).st_mode


# Generated at 2022-06-25 17:34:23.967727
# Unit test for function chmod
def test_chmod():
    path = Path(os.getcwd(), 'unit_tests') / 'unit_tests.py'
    chmod(path, mode_file=0o660)
    chmod(path, mode_file=0o600)


# Generated at 2022-06-25 17:34:26.372783
# Unit test for function chmod
def test_chmod():
    # TODO: Todo

    # TODO: Lint
    # TODO: Codecov
    # TODO: Unittest
    pass


# Generated at 2022-06-25 17:34:35.080260
# Unit test for function exists_as
def test_exists_as():
    # Test 0
    assert exists_as('/') == 'directory'

    # Test 1
    assert exists_as('/usr/bin') == 'directory'

    # Test 2
    assert exists_as('/etc/passwd') == 'file'

    # Test 3
    assert exists_as('/dev/zero') == 'char device'

    # Test 4
    assert exists_as('/dev/disk0s1') == 'block device'

    # Test 5
    assert exists_as('/var/run/docker.sock') == 'socket'

    # Test 6
    assert exists_as('/bin/bash') == 'file'

    # Test 7
    assert exists_as('/foo/bar') == ''

    # Test 8
    assert exists_as('~/tmp') == 'directory'

    # Test 9


# Generated at 2022-06-25 17:34:52.241068
# Unit test for function directory_present
def test_directory_present():
    root_path = '/tmp/flutils_test/test_directory_present'
    print(root_path)
    test_paths = [
        '',
        'a sub path',
        'another sub path',
        'another sub path/and another sub path',
        'another sub path/and another sub path/another sub path',
    ]
    for test_path in test_paths:
        print(test_path)
        directory_present(root_path + '/' + test_path)



# Generated at 2022-06-25 17:34:57.981655
# Unit test for function chown
def test_chown():
    assert struct_passwd_0 == struct_passwd_1, struct_passwd_0 == struct_passwd_1
    assert struct_passwd_0 == struct_passwd_2, struct_passwd_0 == struct_passwd_2
    assert struct_passwd_0 == struct_passwd_3, struct_passwd_0 == struct_passwd_3


# Generated at 2022-06-25 17:35:08.262429
# Unit test for function chown
def test_chown():

    import subprocess as sp
    import tempfile as tf

    with tf.TemporaryDirectory() as tmpd:
        path = tmpd + '/foo'
        proc = sp.Popen(['touch', path],
                        stdout=sp.PIPE, stderr=sp.PIPE)
        assert proc.wait() == 0
        with open(path, 'w') as fio:
            pass
        st = os.stat(path)
        os.chown(path, -1, st.st_gid)
        chown(path)
        assert os.stat(path).st_uid == os.getuid()
        chown(path, user='nobody', group='nogroup')
        assert os.stat(path).st_uid == -2

# Generated at 2022-06-25 17:35:14.466945
# Unit test for function directory_present
def test_directory_present():
    PASS,FAIL="PASS","FAIL"

    result = FAIL
    lcl_path = Path("./TMP/test_directory_present")
    lcl_path.mkdir(exist_ok=True,parents=True)
    try:
        directory_present(lcl_path)
        exists_as_ = exists_as(lcl_path)
        if exists_as_ == 'directory':
            result = PASS
        else:
            result = FAIL
    finally:
        lcl_path.rmdir()

    return(result)



# Generated at 2022-06-25 17:35:18.971686
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('./test_path')
    directory_present(test_path)
    test_path.mkdir(mode=0o700)
    directory_present(test_path)


# Generated at 2022-06-25 17:35:30.762724
# Unit test for function chmod
def test_chmod():
    mode_file = 0o644
    mode_dir = 0o755
    file_path = Path('test_chmod.txt')
    dir_path = Path('test_chmod')
    dir_path.mkdir(parents=True, exist_ok=True)

    if file_path.exists() is True:
        os.remove(str(file_path))

    if dir_path.exists() is True:
        os.rmdir(str(dir_path))


# Generated at 2022-06-25 17:35:40.342616
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    import argparse
    import random
    rand = random.randint(1000,9999)
    rand = str(rand)
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(dir_path, "../../tmp/flutils.tests.osutils.txt")
    file_path_rand = os.path.join(dir_path, "../../tmp/flutils.tests.osutils.txt." + rand)
    file_path_2_rand = os.path.join(dir_path, "../../tmp/flutils.tests.osutils.txt." + rand)
    temp_dir_path = os.path.join(dir_path, "../../tmp/")
    import subprocess
    cmd

# Generated at 2022-06-25 17:35:51.371393
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests.osutils.txt'
    user = getpass.getuser()
    group = getpass.getuser()
    try:
        chown(path, '-1', '-1')
    except FileNotFoundError:
        pass
    with open(path, 'w') as f:
        f.write('test')
    chown(path, user, group)
    assert get_os_user(path).pw_name == user
    assert get_os_group(path).pw_name == group

# Generated at 2022-06-25 17:36:02.498048
# Unit test for function chmod

# Generated at 2022-06-25 17:36:14.786036
# Unit test for function chmod
def test_chmod():
    test_dir = 'test_dir'
    test_path_0 = Path(test_dir + '/' + 'test.txt')
    test_path_1 = Path(test_dir + '/' + 'test_1')
    test_path_2 = Path(test_dir + '/' + 'test_2')
    test_path_3 = Path(test_dir + '/' + 'test_3')
    test_path_4 = Path(test_dir + '/' + 'test_4')
    test_path_5 = Path(test_dir + '/' + 'test_5')
    test_path_6 = Path(test_dir + '/' + 'test_6')
    test_path_7 = Path(test_dir + '/' + 'test_7')

# Generated at 2022-06-25 17:36:32.279661
# Unit test for function chmod
def test_chmod():
    path = "~/tmp/flutils.tests.osutils.txt"
    # chmod(path)
    # chmod(path, 0o660)
    # chmod(path, 0o660, 0o770)
    # chmod(path, 0o660, 0o770, True)
    chmod(path, 0o660, 0o770)

# test_chmod()



# Generated at 2022-06-25 17:36:36.651177
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp')
    if path.exists() is True:
        chmod('~/tmp/**', mode_file=0o660, mode_dir=0o770)
        chmod('~/tmp/*', mode_file=0o660)


# Generated at 2022-06-25 17:36:38.871085
# Unit test for function path_absent
def test_path_absent():
    # Test Case 0:
    # Delete the root directory
    try:
        path_absent('/')
    except FileNotFoundError:
        pass
    except OSError:
        pass


# Generated at 2022-06-25 17:36:51.781981
# Unit test for function chown
def test_chown():
    # Get and assert the user as a string
    cuser_str = getpass.getuser()
    assert isinstance(cuser_str, str)
    assert len(cuser_str) > 0

    # Get and assert the user as a struct
    cuser_struct = get_os_user()
    assert isinstance(cuser_struct, pwd._struct_passwd)
    assert len(cuser_struct) == 7

    # Get and assert the user's group as a string
    cgroup_str = getpass.getuser()
    assert isinstance(cgroup_str, str)
    assert len(cgroup_str) > 0

    # Get and assert the user's group as a struct
    cgroup_struct = get_os_group(cuser_struct.pw_name)

# Generated at 2022-06-25 17:36:57.159887
# Unit test for function directory_present
def test_directory_present():
    path = directory_present(
        '~/tmp/test_directory_present',
        mode=0o600,
        user='test_directory_present',
        group='test_directory_present',
    )
    print(path)
    assert path == Path('~/tmp/test_directory_present')



# Generated at 2022-06-25 17:37:04.840955
# Unit test for function chown
def test_chown():
    tst_chown_dir = './tmpdir'
    tst_chown_file = './tmpdir/test_file'
    tst_chown_file_1 = './tmpdir/test_file_1'
    tst_chown_file_2 = './tmpdir/test_file_2'
    tst_chown_file_3 = './tmpdir/test_file_3'
    tst_chown_file_4 = './tmpdir/test_file_4'
    tst_chown_file_5 = './tmpdir/test_file_5'
    tst_chown_file_6 = './tmpdir/test_file_6'
    tst_chown_file_7 = './tmpdir/test_file_7'
    tst_

# Generated at 2022-06-25 17:37:07.882343
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    chown('~/tmp/flutils.tests.osutils.txt', user)


# Generated at 2022-06-25 17:37:11.382100
# Unit test for function directory_present
def test_directory_present():
    directory_present("/tmp/my_directory")
    directory_present("/tmp/my_directory/my_sub_directory")
    directory_present("/tmp/my_directory/my_sub_directory/my_sub_sub_directory")


# Generated at 2022-06-25 17:37:22.057298
# Unit test for function chown
def test_chown():
    print("Testing chown()")
    current_user = get_os_user()
    current_dir_path = Path("/tmp")
    file_0_path = current_dir_path / "flutils_test_chown_file.out"
    dir_0_path = current_dir_path / "flutils_test_chown_dir"
    file_1_path = dir_0_path / "flutils_test_chown_file_1.out"
    dir_1_path = dir_0_path / "flutils_test_chown_dir_1"
    file_2_path = dir_1_path / "flutils_test_chown_file_2.out"
    file_0_path.touch()
    dir_0_path.mkdir()

# Generated at 2022-06-25 17:37:30.141436
# Unit test for function chown
def test_chown():
    test_path = Path('/tmp/flutils.pathutils.chown.test0')
    try:
        test_path.mkdir(mode=0o700, parents=True)
        chown(
            test_path,
            user=getpass.getuser(),
            group=getpass.getuser(),
            include_parent=False
        )
        stat_info = test_path.stat()
        assert stat_info.st_uid == os.getuid()
        assert stat_info.st_gid == os.getgid()
    except AssertionError as error:
        print(error)
    finally:
        if test_path.exists() is True:
            test_path.rmdir()



# Generated at 2022-06-25 17:37:47.123807
# Unit test for function chmod
def test_chmod():
    # Basic test for changing the mode of a file
    import pathlib
    test_directory = pathlib.Path('/tmp/flutils_test_files')
    test_directory.mkdir(parents=True, exist_ok=True)
    path_file = pathlib.Path(test_directory, 'test.txt')
    path_file.touch()
    chmod(path_file, mode_file=0o660, mode_dir=0o770)
    assert path_file.stat().st_mode & 0o777 == 0o660
    # Basic test for changing the mode of a directory
    path_directory = pathlib.Path(test_directory, 'test_dir')
    path_directory.mkdir()
    chmod(path_directory, mode_file=0o660, mode_dir=0o770)
    assert path

# Generated at 2022-06-25 17:37:54.502615
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/flutils.tests.osutils.txt', user='-1')
    chown('~/tmp/flutils.tests.osutils.txt', group='-1')
    chown('~/tmp/flutils.tests.osutils.txt', user='foo')
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='bar')
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='-1')
    chown('~/tmp/flutils.tests.osutils.txt', group='bar', user='-1')


# Generated at 2022-06-25 17:37:57.771027
# Unit test for function directory_present
def test_directory_present():
    directory_path = directory_present('~/.flutils_tests/from_python/from_python_dir_0/from_python_dir_1')


# Generated at 2022-06-25 17:38:04.019105
# Unit test for function chown
def test_chown():
    path = '/home/q/tmp/flutils-tests/chown/flutils.tests.osutils.txt'
    assert get_os_user().pw_name != 'myuser'
    chown(path, user='myuser')
    struct_passwd = get_os_user()
    assert struct_passwd.pw_name == 'myuser'
    os.chown(path, struct_passwd.pw_uid, -1)


# Generated at 2022-06-25 17:38:06.546630
# Unit test for function get_os_user
def test_get_os_user():
    test_case_0()
    print('test_get_os_user success!')


# Generated at 2022-06-25 17:38:08.325553
# Unit test for function chmod
def test_chmod():
    assert chmod('/tmp/myfile', 0o600, 0o700, False) is None


# Generated at 2022-06-25 17:38:17.963777
# Unit test for function chown
def test_chown():
    test_path = normalize_path('.')
    test_user = getpass.getuser()
    test_group = grp.getgrnam(test_user).gr_gid

    # Save the original values
    orig_user, orig_group = test_path.stat().st_uid, test_path.stat().st_gid

    chown('.', user=test_user)
    assert test_path.stat().st_uid == test_user

    chown('.', group=test_group)
    assert test_path.stat().st_gid == test_group

    chown('.', user=test_user, group=test_group)
    assert test_path.stat().st_uid == test_user
    assert test_path.stat().st_gid == test_group


# Generated at 2022-06-25 17:38:28.766964
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/home') == 'directory'
    assert exists_as('./flutils') == 'directory'
    assert exists_as('./flutils/pathutils.py') == 'file'
    assert exists_as('./flutils/test_pathutils.py') == 'file'
    assert exists_as('/dev/console') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('./flutils/pathutils.py') == 'file'

# Generated at 2022-06-25 17:38:40.637319
# Unit test for function chown

# Generated at 2022-06-25 17:38:47.551638
# Unit test for function path_absent
def test_path_absent():
    from pathlib import PurePath, Path
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as tmpdir:
        p = PurePath(tmpdir) / 'test_path'
        assert (
            os.path.exists(p) is False
        ), 'Sanity check that the directory is absent failed.'
        os.makedirs(p.as_posix())
        assert (
            os.path.exists(p) is True
        ), 'Sanity check that the directory exists failed.'
        path_absent(p)
        assert (
            os.path.exists(p) is False
        ), 'path_absent failed.'

        p = PurePath(tmpdir) / 'test_path'

# Generated at 2022-06-25 17:38:55.703515
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-25 17:38:58.059144
# Unit test for function directory_present
def test_directory_present():
    #tests for function directory_present
    test_dir = '~/tmp/flutils/pathutils/'
    directory_present(test_dir)
    assert os.path.isdir(test_dir)


# Generated at 2022-06-25 17:39:03.414616
# Unit test for function chmod
def test_chmod():
    # Set up environment
    path = '/tmp/flutils.tests.osutils.txt'
    assert(os.path.exists(path) is False)

    # Create file
    open(path, 'w+').close()

    # Execute test
    chmod(path, 0o660)

    # Verify test
    assert(os.path.exists(path) is True)
    assert(os.path.isfile(path) is True)
    assert(os.stat(path).st_mode == 0o100660)

    # Tear down environment
    os.remove(path)
    assert(os.path.exists(path) is False)


# Generated at 2022-06-25 17:39:15.158355
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

    test_root = Path(
        '/tmp/flutils.tests.pathutils.test_chown.{0}'.format(getpass.getuser())
    )
    test_root.mkdir(parents=True, exist_ok=True)

    test_path = test_root / 'test_file.txt'
    with test_path.open('w') as stream:
        stream.write('test_file')

    pw_uid = pwd.getpwnam(getpass.getuser()).pw_uid
    gr_gid = grp.getgrnam(getpass.getuser()).gr_gid

    path = test_root

    Path(test_root / 'file01.txt').touch()

# Generated at 2022-06-25 17:39:27.307120
# Unit test for function chmod
def test_chmod():
    # Verify if function chmod exists
    assert chmod

    # Test 1
    test_file_0 = normalize_path('./flutils.tests.osutils.txt')
    test_file_1 = normalize_path('./flutils.tests.osutils.txt.tmp')
    test_file_2 = normalize_path('./flutils.tests.osutils.bak')
    test_dir_0 = normalize_path('./flutils_temp/')
    test_dir_1 = normalize_path('./flutils_temp_backup/')
    assert test_file_0.exists() is True
    assert test_file_1.exists() is False
    assert test_file_2.exists() is False
    assert test_dir_0.exists() is False
   

# Generated at 2022-06-25 17:39:31.257915
# Unit test for function get_os_user
def test_get_os_user():
    import getpass
    os_user = get_os_user()
    assert os_user
    assert os_user is not None
    assert os_user.pw_name is not None
    assert os_user.pw_name == getpass.getuser()
    assert os_user.pw_gecos is not None


# Generated at 2022-06-25 17:39:32.936820
# Unit test for function path_absent
def test_path_absent():
    path = '/var/tmp/test_flutils'
    # Create a directory to remove.
    path_present(path)
    path_absent(path)
    assert not os.path.exists(path)
    assert not os.path.isdir(path)


# Generated at 2022-06-25 17:39:34.688202
# Unit test for function path_absent
def test_path_absent():
    test_path = Path('~/tmp/test_path')
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    path_absent(test_path)
    assert exists_as(test_path) == ''


# Generated at 2022-06-25 17:39:45.102936
# Unit test for function chmod
def test_chmod():
    dirname_0 = Path('/tmp/flutils.test.chmod')
    test_filename_0 = dirname_0 / 'test_chmod.tmp'
    os.makedirs(dirname_0)
    open(test_filename_0, 'w').close()
    try:
        chmod(dirname_0, 0o755, include_parent = True)
        assert os.stat(dirname_0).st_mode == 0o40755
        assert os.stat(test_filename_0).st_mode == 0o100644
    finally:
        os.unlink(test_filename_0)
        os.rmdir(dirname_0)


# Generated at 2022-06-25 17:39:55.167318
# Unit test for function path_absent
def test_path_absent():
    test_path = Path.home() / 'tmp' / 'flutils_test_path'

    # Ensure the test path does not exist
    path_absent(test_path)

    # Ensure it is deleted recursively
    test_path.mkdir(parents=True, exist_ok=True)
    with open(test_path / 'test_file', 'w') as out_fh:
        out_fh.write('test_data')
    os.symlink(test_path / 'test_file', test_path / 'test_link')
    with open(test_path / 'test_file2', 'w') as out_fh:
        out_fh.write('test_data2')
    path_absent(test_path)

    # Ensure the test path does not exist

# Generated at 2022-06-25 17:40:12.027799
# Unit test for function exists_as
def test_exists_as():
    """Test the exists_as function for correct output.

    Returns:
        :obj:`bool`

        * :obj:`True` on success.
        * :obj:`False` if test fails.

    """
    test_path = Path('flutils_test_pathutils_exists_as')
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    test_path.rmdir()
    assert exists_as(test_path) == ''
    return True



# Generated at 2022-06-25 17:40:13.676340
# Unit test for function chown
def test_chown():
    chown('/home/ec2-user/tmp/flutils/pathutils/', user='root', group='root')


# Generated at 2022-06-25 17:40:20.562130
# Unit test for function exists_as
def test_exists_as():
    directory_present('~/tmp/test_exists_as')
    assert exists_as('~/tmp/test_exists_as') == 'directory'
    file_present('~/tmp/test_exists_as/test_file')
    assert exists_as('~/tmp/test_exists_as/test_file') == 'file'
    directory_present('~/tmp/test_exists_as/test_directory')
    assert exists_as('~/tmp/test_exists_as/test_directory') == 'directory'



# Generated at 2022-06-25 17:40:28.960108
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        file_path = Path(tmpdirname).joinpath('foo.txt')
        file_path.touch()

        dir_path = Path(tmpdirname).joinpath('bar')
        dir_path.mkdir()

        sub_dir_path = Path(tmpdirname).joinpath('bar', 'baz')
        sub_dir_path.mkdir(parents=True)

        sub_file_path = Path(tmpdirname).joinpath('bar', 'baz', 'qux.txt')
        sub_file_path.touch()

        # Only files
        chmod(tmpdirname, mode_file=0o600)
        assert 0o600 == oct(file_path.stat().st_mode & 0o777)
        assert 0o700

# Generated at 2022-06-25 17:40:31.530923
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    return


# Generated at 2022-06-25 17:40:42.268530
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils.pathutils import chmod
    import os
    import stat
    # Test case 0 for function chmod
    struct_passwd_0 = pwd.getpwuid(os.getuid())
    #fname = os.path.join(struct_passwd_0.pw_dir, 'test_flutils.txt')
    fname = os.path.join(
        '/home',
        struct_passwd_0.pw_name,
        'test_flutils.txt')

    dname = os.path.join(
        '/home',
        struct_passwd_0.pw_name,
        'test_flutils')

    open(fname, 'w').close()
    os.mkdir(dname)

# Generated at 2022-06-25 17:40:46.856964
# Unit test for function directory_present
def test_directory_present():
    test_path_0 = directory_present(
        '~/tmp/flutils/osutils/directory_present',
        mode=0o755,
        user="len",
    )
    assert test_path_0.as_posix() == '/Users/len/tmp/flutils/osutils/directory_present'



# Generated at 2022-06-25 17:40:54.857973
# Unit test for function chmod
def test_chmod():
    # Expected
    expected_path = Path('/tmp')
    expected_mode_dir = 0o700

    # Test
    chmod(expected_path, include_parent=False)

    # Result
    actual_result = expected_path.stat().st_mode & 0o777

    print('{}: {}'.format(expected_mode_dir,'{0:o}'.format(actual_result)))
    # Assert
    assert(actual_result == expected_mode_dir)


# Generated at 2022-06-25 17:40:57.995277
# Unit test for function exists_as
def test_exists_as():
    '''
    pathutils.exists_as is a function whose sole purpose is to identify
    the type of path that is given to it
    '''
    assert exists_as('/etc') == 'directory'


# Generated at 2022-06-25 17:41:04.717998
# Unit test for function exists_as
def test_exists_as():
    # Test 0
    path1 = Path(__file__)
    found = exists_as(path1)
    assert(found == 'file')
    # Test 1
    path2 = Path(__file__).parent
    found = exists_as(path2)
    assert(found == 'directory')
    # Test 2
    path3 = Path('/no/such/path')
    found = exists_as(path3)
    assert(found == '')
    # Test 3
    path4 = Path(__file__)
    found = exists_as(path4)
    assert(found == 'file')
