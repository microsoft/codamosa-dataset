

# Generated at 2022-06-21 12:56:00.969994
# Unit test for function chmod
def test_chmod():
    from flutils.tests.pathutils import TESTFILE_A
    from flutils.pathutils import chmod
    chmod(TESTFILE_A, mode_file=0o664, mode_dir=0o765)



# Generated at 2022-06-21 12:56:10.224367
# Unit test for function get_os_user
def test_get_os_user():
    from os import getuid
    from pwd import getpwuid
    from tempfile import NamedTemporaryFile
    from unittest import TestCase
    from typing import Tuple
    from unittest.mock import patch

    from flutils.pathutils import get_os_user

    class TestGetOSUser(TestCase):
        """Test class for the ``get_os_user()`` function."""

        def test_default(self):
            """Test the function returns the current OS user info."""
            os_user = get_os_user()
            self.assertEqual(getuid(), os_user.pw_uid)
            self.assertEqual(getpwuid(getuid()), os_user)

        def test_int(self):
            """Test the function returns a struct_passwd object."""
            os

# Generated at 2022-06-21 12:56:15.514275
# Unit test for function path_absent
def test_path_absent():
    from pathlib import Path

    path = Path.home() / '.test_path_absent'

    path_absent(path.as_posix())

    assert path.exists() is False

    path.mkdir()

    assert path.is_dir()

    path_absent(path.as_posix())

    assert path.exists() is False

    file_path = path / 'test.txt'

    file_path.touch()

    assert file_path.is_file()

    path_absent(file_path.as_posix())

    assert path.exists() is False

    path.mkdir()

    file_path = path / 'test.txt'

    with file_path.open('w') as f:
        f.write('Test text.')

    file_path.touch()

   

# Generated at 2022-06-21 12:56:27.537695
# Unit test for function normalize_path
def test_normalize_path():
    # Set the current working directory
    cur_cwd = os.getcwd()
    cwd_path = Path(cur_cwd)
    new_cwd = '/tmp'
    os.chdir(new_cwd)
    assert os.getcwd() != cur_cwd
    if os.getcwd() != new_cwd:
        raise ValueError(
            'Unable to change the current working directory.  '
            'This test requires administrative privileges.'
        )

    # Test values

# Generated at 2022-06-21 12:56:32.925109
# Unit test for function get_os_user
def test_get_os_user():
    # Executes get_os_user('None')
    existing_user = pwd.getpwuid(os.getuid())
    os_user = get_os_user()
    assert os_user == existing_user

    # Executes get_os_user(existing_user.pw_name)
    os_user = get_os_user(existing_user.pw_name)
    assert os_user == existing_user

    # Executes get_os_user(existing_user.pw_uid)
    os_user = get_os_user(existing_user.pw_uid)
    assert os_user == existing_user

    # Executes get_os_user(non_existing_user)
    non_existing_user = 'foo'

# Generated at 2022-06-21 12:56:36.089987
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'


# Generated at 2022-06-21 12:56:47.731859
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    test_path = Path('/home/test_user/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') == test_path
    assert normalize_path('~/tmp/foo/../bar/') == test_path
    assert normalize_path('~/tmp/./foo/../bar') == test_path
    assert normalize_path('~///tmp///foo/../bar') == test_path
    assert normalize_path('~\\tmp\\foo/../bar') == test_path
    assert normalize_path('tmp/foo/../bar') == test_path
    assert normalize_path('/tmp/foo/../bar') == test_path
    assert normalize_path('/tmp/foo/../bar/') == test_path

# Generated at 2022-06-21 12:57:00.102373
# Unit test for function chown
def test_chown():
    assert callable(chown)

    if os.name == 'nt':
        assert_raises(OSError, chown, './foo')
        assert_raises(OSError, chown, './foo', '-1', '-1')
        assert_raises(OSError, chown, './foo', '-1')
        assert_raises(OSError, chown, './foo', group='-1')
    else:
        foo_mode = Path('./foo').stat().st_mode
        os.mkdir('./foo')
        chown('./foo')
        assert Path('./foo').stat().st_uid == os.getuid()
        assert Path('./foo').stat().st_gid == os.getgid()
        assert Path('./foo').stat().st_

# Generated at 2022-06-21 12:57:04.964112
# Unit test for function exists_as
def test_exists_as():
    test_path = Path('./tests/test_osutils.py')
    assert exists_as(test_path) == 'file'
    directory_present('foo')
    assert exists_as(Path('foo')) == 'directory'
    os.unlink('foo')
    assert exists_as(Path('foo')) == ''



# Generated at 2022-06-21 12:57:09.098912
# Unit test for function directory_present
def test_directory_present():
    directory_present(pathlib.Path('/tmp/test_directory_present'))
    assert pathlib.Path('/tmp/test_directory_present').exists() is True


# Generated at 2022-06-21 12:57:32.852534
# Unit test for function find_paths
def test_find_paths():
    import os
    import tempfile

# Generated at 2022-06-21 12:57:43.464035
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory(dir='~/tmp') as tmpdir:
        tmpdir = Path(tmpdir)

        file1 = tmpdir / 'flutils.tests.file1.txt'
        file2 = tmpdir / 'flutils.tests.file2.txt'
        dir1 = tmpdir / 'flutils.tests.dir1'
        dir2 = tmpdir / 'flutils.tests.dir2'
        dir3 = tmpdir / 'flutils.tests.dir3'

        # Create dirs and files for test.
        file1.touch()
        file2.touch()
        dir1.mkdir()
        dir2.mkdir()
        dir3.mkdir()

        chmod(file1, 0o600)
        chmod(file2, 0o644)

# Generated at 2022-06-21 12:57:46.411701
# Unit test for function chown
def test_chown():
    chown('tests/test_file', user='nginx', group='nginx')
    os.chown('tests/test_file', 33, 33)



# Generated at 2022-06-21 12:57:48.699367
# Unit test for function find_paths
def test_find_paths():
    from .test_pathutils import test_find_paths as _test_find_paths
    _test_find_paths()



# Generated at 2022-06-21 12:57:55.228202
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o600)
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660, 0o770)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')



# Generated at 2022-06-21 12:57:56.173287
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_uid == 0

# Generated at 2022-06-21 12:58:05.376870
# Unit test for function path_absent
def test_path_absent():
    import logging
    import pathlib
    import random
    import shutil
    import tempfile

    _ = logging.getLogger(__name__)

    directory = pathlib.Path(tempfile.gettempdir(), 'flutils_tests')
    if directory.exists():
        shutil.rmtree(directory.as_posix())
    directory.mkdir()
    paths: List[pathlib.Path] = []

    for i in range(random.randrange(1, 1000)):
        name = str(random.randrange(1, 1000000))
        path = pathlib.Path(directory, name)
        path_absent(path)
        assert path.exists() is False
        paths.append(path)

    for path in paths:
        path.touch()
        assert path.exists() is True


# Generated at 2022-06-21 12:58:14.170858
# Unit test for function chmod
def test_chmod():
    try:
        import flutils.pathutils
    except ImportError:
        import sys
        import os
        sys.path.insert(0, os.path.abspath('..'))

        import flutils.pathutils

    import os
    import stat
    import tempfile

    import pytest

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_file = os.path.join(tmp_dir.name, 'foo.txt')
    with open(tmp_file, 'a') as f:
        f.write('bar')
    os.chmod(tmp_file, 0o600)

    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o600

    flutils.pathutils.chmod(tmp_file, 0o660)
    assert stat.S_IM

# Generated at 2022-06-21 12:58:23.543095
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.testingutils import assert_plain_equal

    assert_plain_equal(
        normalize_path(Path('~')).as_posix(),
        os.path.expanduser(Path('~').as_posix())
    )

    assert_plain_equal(
        normalize_path(Path('~/tmp')).as_posix(),
        os.path.expanduser(Path('~/tmp').as_posix())
    )

    assert_plain_equal(
        normalize_path(Path('foo')).as_posix(),
        os.path.expanduser(os.path.join(os.getcwd(), 'foo'))
    )


# Generated at 2022-06-21 12:58:28.245562
# Unit test for function normalize_path
def test_normalize_path():
    """Test function flutils.pathutils.normalize_path."""
    path = normalize_path(__file__)
    assert isinstance(path, Path)
    assert path.is_absolute() is True


normalize_path.register(bytes, lambda x: normalize_path(x.decode()))
normalize_path.register(PosixPath, lambda x: normalize_path(x.as_posix()))
normalize_path.register(WindowsPath, lambda x: normalize_path(x.as_posix()))



# Generated at 2022-06-21 12:58:54.766065
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~')
    assert exists_as(path) == 'directory'

    path = normalize_path('~/.bash_profile')
    assert exists_as(path) == 'file'

    path = normalize_path('/dev/ttys0')
    assert exists_as(path) == 'char device'

    path = normalize_path('/dev/disk0')
    assert exists_as(path) == 'block device'

    path = normalize_path('~/.bash_profile/notthere')
    assert exists_as(path) == ''

    path = normalize_path('~/tmp/notthere')
    assert exists_as(path) == ''

    path = normalize_path('/dev/disk0/notthere')
    assert exists_as(path) == ''


# Generated at 2022-06-21 12:59:07.814148
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from flutils.tests.makeclass import make_temp_dir

    class TestFindPaths(TestCase):
        def test_find_paths(self):
            self.assertListEqual(
                find_paths('~/tmp/*'),
                self.expected
            )

    # Make a temp dir
    with make_temp_dir() as tmp_dir:
        # Populate the temp dir with some stuff
        os.mkdir(os.path.join(tmp_dir, 'sub_dir'))
        with open(os.path.join(tmp_dir, 'sub_dir', 'file_foo'), 'w'):
            pass
        with open(os.path.join(tmp_dir, 'file_bar'), 'w'):
            pass


# Generated at 2022-06-21 12:59:10.398958
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')



# Generated at 2022-06-21 12:59:15.466308
# Unit test for function directory_present
def test_directory_present():
    path = '/tmp/flutils/pathutils/tests/directory_present'

    assert directory_present(path) == Path(path)

    assert directory_present(path, user='root', group='wheel') == Path(path)

# Generated at 2022-06-21 12:59:17.935601
# Unit test for function directory_present
def test_directory_present():
    test_path = Path(__file__).parent / 'test_path'
    assert directory_present(test_path).is_dir()



# Generated at 2022-06-21 12:59:21.084758
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~') == normalize_path('/home/test_user')

# Generated at 2022-06-21 12:59:30.686316
# Unit test for function directory_present
def test_directory_present():
    # Ensure a new directory is created as a directory.
    directory_present(
        '/tmp/test_directory_present/test_directory_present.txt',
        mode=0o770,
        user=getpass.getuser(),
        group=os.getgroups()[0],
    )
    assert True is Path(
        '/tmp/test_directory_present/test_directory_present.txt'
    ).exists()
    assert 'directory' == exists_as(
        '/tmp/test_directory_present/test_directory_present.txt'
    )

    # Ensure a new directory is created as a directory,
    # but the parent does not exist.

# Generated at 2022-06-21 12:59:36.173963
# Unit test for function chown
def test_chown():
    from os import makedirs
    from os.path import expanduser
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        base_path = Path(g.tmp_path) / 'foo'
        makedirs(base_path)
        file_path = Path(g.tmp_path) / 'foo' / 'bar' / 'baz.txt'

        with file_path.open('w') as f:
            f.write('foo')


# Generated at 2022-06-21 12:59:48.900495
# Unit test for function chown
def test_chown():
    """ Tests the chown funciton. """
    import flutils.testingutils
    expected = NotImplementedError
    if flutils.testingutils.is_unix() is True:
        expected = OSError
    with flutils.testingutils.import_sitecustomize_for_exceptions():
        with flutils.testingutils.captured_stdout() as (out, _):
            flutils.pathutils.chown('/etc/passwd', include_parent=True)
            assert out.getvalue().strip() == ''
        with flutils.testingutils.captured_stdout() as (out, _):
            flutils.pathutils.chown('/etc/passwd', include_parent=True)
            assert out.getvalue().strip() == ''

# Generated at 2022-06-21 12:59:52.650564
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group('root'), grp.struct_group)
    assert isinstance(get_os_group(0), grp.struct_group)
    with pytest.raises(OSError):
        get_os_group('foo')
    with pytest.raises(OSError):
        get_os_group(123)



# Generated at 2022-06-21 13:00:18.099301
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        test_path = Path(tmpdir, 'test_path')
        test_path_file = Path(tmpdir, 'test_path', 'test_path_file')
        test_path_symlink = Path(tmpdir, 'test_path_symlink')
        create_dirs(test_path)
        test_path_file.touch()
        test_path_symlink.symlink_to(test_path_file)

        assert test_path.exists() is True
        assert test_path_file.exists() is True
        assert test_path_symlink.is_symlink() is True

        path_absent(test_path)

        assert test_path.exists

# Generated at 2022-06-21 13:00:25.441413
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from flutils.testutils import BaseTestCase
    from flutils.testutils import setUpModule  # noqa: F401
    from flutils.testutils import tearDownModule  # noqa: F401

    class TestPathAbsent(BaseTestCase):
        """Unit tests for :obj:`path_absent`.

        This test module is designed to be run from the root of the project
        directory using:

        .. code:: bash

            python -m unittest flutils.pathutils.test_path_absent
        """

        def test_absent(self):
            """Test the path_absent function with an absent path."""
            path = Path('~/tmp/path_absent')
            path = path.expanduser()
            path = path.as_posix

# Generated at 2022-06-21 13:00:38.105048
# Unit test for function chown
def test_chown():
    """Unit tests for chown.
    """
    import pytest

    from flutils.pathutils import chown
    from flutils.pathutils import path_absent

    with Path('~/tmp/flutils.tests.osutils.txt').expanduser().open(
            'w', encoding='utf-8') as tmp_file:
        tmp_file.write(
            'These are the voyages of the Starship Enterprise\n'
            'Its five-year mission: to explore strange new worlds, '
            'to seek out new life and new civilizations, to boldly '
            'go where no man has gone before.\n'
        )

    with pytest.raises(OSError) as err:
        chown(Path('~/tmp/flutils.tests.osutils.txt'), user='foobar')
    assert err.value

# Generated at 2022-06-21 13:00:47.501575
# Unit test for function exists_as
def test_exists_as():
    """Test the exists_as function."""
    import tempfile
    import os
    import shutil
    from flutils.pathutils import exists_as
    tmpdir = tempfile.mkdtemp()
    dirname = os.path.join(tmpdir, 'dirname')
    os.mkdir(dirname)
    assert exists_as(dirname) == 'directory'
    os.close(os.open(os.path.join(tmpdir, 'myfile'), os.O_CREAT))
    assert exists_as(os.path.join(tmpdir, 'myfile')) == 'file'
    shutil.rmtree(tmpdir)



# Generated at 2022-06-21 13:00:55.237374
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.funcutils import (
        get_test_data,
        get_test_data_path,
    )
    from flutils.tests.osutils import (
        OS_GROUP,
        OS_USER,
        reset_file_attrs_for_unit_testing,
    )
    reset_file_attrs_for_unit_testing()

    # Test setting file ownership to the current user
    test_path = get_test_data_path('flutils.tests.osutils.txt')
    chown(test_path)
    assert test_path.owner() == OS_USER

    # Test setting file ownership to the current user's primary group
    chown(test_path, '-1', str(OS_GROUP))
    assert test_path.group

# Generated at 2022-06-21 13:01:04.846286
# Unit test for function normalize_path
def test_normalize_path():
    try:
        normalize_path(b'~/tmp')
    except TypeError:
        pass
    except Exception as error:
        raise AssertionError(
            'Expected a TypeError for normalizing the path: ~/tmp as bytes. '
            'Got: %s' % error
        ) from error
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')
    assert isinstance(normalize_path('~/tmp'), Path) is True
    assert normalize_path(normalize_path('~/tmp')) == Path('/home/test_user/tmp')
    assert isinstance(
        normalize_path(normalize_path('~/tmp')),
        Path
    ) is True

# Generated at 2022-06-21 13:01:11.045435
# Unit test for function find_paths
def test_find_paths():  # noqa
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from pathvalidate import sanitize_filename
    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        file_one = tmp_path.joinpath('file_one')
        dir_one = tmp_path.joinpath('dir_one')
        dir_one.mkdir()
        file_two = dir_one.joinpath('file_two')
        file_one_path = Path('file_one')
        file_one_path.touch(exist_ok=True)
        file_two_path = Path('file_two')
        file_two_path.touch()
        tmp_path.joinpath('dir_one').mkdir()

# Generated at 2022-06-21 13:01:12.826850
# Unit test for function normalize_path
def test_normalize_path():
    # Set some values for the test case
    posix = '~/tmp/foo/../bar'
    expected = '/home/test_user/tmp/bar'
    # Call function normalize_path and check for expected result
    assert normalize_path(posix).as_posix() == expected



# Generated at 2022-06-21 13:01:14.559526
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-21 13:01:26.530736
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('.') == 'directory'
    assert exists_as('./test_fixtures/root/') == 'directory'
    assert exists_as(
        './test_fixtures/root/bar/'
    ) == 'directory'
    assert exists_as('./test_fixtures/root/bar/SOURCES') == 'file'
    assert exists_as('./test_fixtures/root/bar/SPECS') == 'directory'
    assert exists_as('./test_fixtures/root/bar/SPECS/bar.spec') == 'file'
    assert exists_as('./test_fixtures/root/foo/') == 'directory'
    assert exists_as('./test_fixtures/root/foo/SPECS/foo.spec') == 'file'
    assert exists_

# Generated at 2022-06-21 13:01:43.999764
# Unit test for function normalize_path
def test_normalize_path():
    assert str(normalize_path('~/tmp/foo/../bar')) == os.path.expanduser('~/tmp/foo/../bar')
test_normalize_path()



# Generated at 2022-06-21 13:01:56.381783
# Unit test for function normalize_path
def test_normalize_path():  # pragma: no cover
    from io import StringIO
    from pathlib import Path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from sys import stdout
    from typing import TextIO
    from typing import List
    from typing import Union


    if sys.platform == 'win32':
        path_type = WindowsPath
        path_class = 'Windows'
        path_sep = '\\'
        u_tmp = 'U:\\'
        u_tmp_file = 'U:\\tmp\\foo'
        v_path = 'COM1'
        v_tmp = 'V:\\'
        v_tmp_file = 'V:\\tmp\\foo'
        w_path = '\\Windows\\'
        w_tmp = 'W:\\'

# Generated at 2022-06-21 13:02:01.281376
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory(prefix='test_find_paths') as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        found = list(find_paths(tmpdir))
        assert len(found) == 2



# Generated at 2022-06-21 13:02:13.793879
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')
    assert normalize_path(b'~/tmp') == Path('/home/test_user/tmp')
    assert normalize_path(Path('~/tmp')) == Path('/home/test_user/tmp')
    assert normalize_path(Path(b'~/tmp')) == Path('/home/test_user/tmp')

    assert normalize_path('$PATH') == os.getenv('PATH')
    assert normalize_path(b'$PATH') == os.getenv('PATH')
    assert normalize_path(Path('$PATH')) == os.getenv('PATH')
    assert normalize_path(Path(b'$PATH')) == os.getenv('PATH')


# Generated at 2022-06-21 13:02:19.233593
# Unit test for function find_paths
def test_find_paths():
    with TempDirectory() as tmp:
        path = Path(tmp.name)
        sub_dir = path.joinpath('sub_dir_1')
        file_1 = path.joinpath('file_1')
        file_2 = sub_dir.joinpath('file_2')
        sub_dir.mkdir(mode=0o700)
        file_1.touch()
        file_2.touch()
        assert list(find_paths(f'{path}/file*')) == [file_1]
        assert list(find_paths(f'{path}/sub*')) == [sub_dir]
        assert list(find_paths(f'{path}/sub_*/file*')) == [file_2]

# Generated at 2022-06-21 13:02:29.873228
# Unit test for function chown
def test_chown():
    tmpdir = Path('/tmp/flutils.tests.pathutils')
    os.makedirs(tmpdir, exist_ok=True)
    subdir = tmpdir / 'foo'
    subdir.mkdir(mode=0o775, parents=True, exist_ok=True)
    file = tmpdir / 'flutils.tests.osutils.txt'
    with open(file, 'w') as f:
        f.write('foo')

    chown(tmpdir / '*', 'root', 'root')
    assert stat.S_IMODE(os.stat(
        subdir.as_posix()
    ).st_mode) == stat.S_IMODE(0o775)

# Generated at 2022-06-21 13:02:32.343564
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('foo') == get_os_user(1001)



# Generated at 2022-06-21 13:02:39.775395
# Unit test for function exists_as
def test_exists_as():
    from flutils.randomutils import random_int
    from . import _Path, Path

    pwd = _Path(__file__).parent
    path = Path(pwd).joinpath(
        'test_dir_{}'.format(random_int(0, 10000000, 7))
    )

    assert exists_as(path) == ''
    path.mkdir()
    assert exists_as(path) == 'directory'
    path.rmdir()
    assert exists_as(path) == ''



# Generated at 2022-06-21 13:02:41.792496
# Unit test for function path_absent
def test_path_absent():
    _test_path_absent()


# Generated at 2022-06-21 13:02:45.963250
# Unit test for function exists_as
def test_exists_as():
    """
    Test flutils.osutils.exists_as()

    """
    from flutils.osutils import exists_as
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        tmp_path = Path(tmpdirname)
        assert exists_as(tmp_path) == 'directory'
        assert exists_as(tmp_path.parent) == ''



# Generated at 2022-06-21 13:03:09.430944
# Unit test for function exists_as
def test_exists_as(): # noqa
    tmp_path = Path('/tmp/flutils.tests/exists_as')
    tmp_path.mkdir(parents=True, exist_ok=True)
    tmp_file = Path('%s/flutils.tests.osutils.txt' % tmp_path.as_posix())
    tmp_file.touch()

    result = exists_as(tmp_file)
    assert result == 'file'
    result = exists_as(tmp_path)
    assert result == 'directory'
    result = exists_as(Path('%s/fake_file' % tmp_path.as_posix()))
    assert result == ''
    result = exists_as(Path('%s/../flutils/tests.py' % tmp_path.as_posix()))
    assert result == 'file'

    remove_

# Generated at 2022-06-21 13:03:16.017449
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(tmp_dir, 'test_dir')
    test_path = os.path.join(test_dir, 'test_file')
    os.makedirs(test_dir)
    with open(test_path, 'w') as tp:
        tp.write('Test file.')
    path_absent(test_path)
    assert not os.path.exists(test_path)
    path_absent(test_dir)
    assert not os.path.exists(test_dir)
    path_absent(tmp_dir)
    assert not os.path.exists(tmp_dir)



# Generated at 2022-06-21 13:03:22.843316
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(name=os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(name=getpass.getuser()) == pwd.getpwnam(getpass.getuser())



# Generated at 2022-06-21 13:03:27.976606
# Unit test for function directory_present
def test_directory_present():
    assert(
        isinstance(
            directory_present('~/tmp/foobar'),
            Path
        ) is True
    )
    assert(
        directory_present(
            '~/tmp/foobar',
            mode=0o700,
            user='foo',
            group='bar'
        ).as_posix()
        ==
        '%s/tmp/foobar' % os.path.expanduser('~')
    )


# Generated at 2022-06-21 13:03:37.261296
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path function."""
    import types

    # Test with os.fsencode(b'~/tmp/foo/../bar').decode()
    if sys.platform.startswith(('darwin', 'linux')):
        assert normalize_path(os.fsencode(b'~/tmp/foo/../bar').decode()) == \
               Path('/home/test_user/tmp/bar')
    if sys.platform == 'win32':
        assert normalize_path(os.fsencode(b'~/tmp/foo/../bar').decode()) == \
               Path('C:/Users/test_user/tmp/bar')

    # Test with os.fsencode(b'~/tmp/foo/../bar')

# Generated at 2022-06-21 13:03:44.818408
# Unit test for function get_os_group
def test_get_os_group():
    if sys.platform == 'win32':
        with pytest.raises(OSError):
            get_os_group()
    else:
        result = get_os_group()
        assert isinstance(result, grp.struct_group)
        assert isinstance(result.gr_gid, int)
        assert isinstance(result.gr_name, str)
        assert isinstance(result.gr_passwd, str)
        assert isinstance(result.gr_mem, list)



# Generated at 2022-06-21 13:03:54.161700
# Unit test for function get_os_user
def test_get_os_user():
    assert "uid" in get_os_user().pw_name
    assert "pw_name" in get_os_user().pw_name
    assert "pw_passwd" in get_os_user().pw_name
    assert "pw_uid" in get_os_user().pw_name
    assert "pw_gid" in get_os_user().pw_name
    assert "pw_gecos" in get_os_user().pw_name
    assert "pw_dir" in get_os_user().pw_name
    assert "pw_shell" in get_os_user().pw_name

# Generated at 2022-06-21 13:04:02.695365
# Unit test for function chmod
def test_chmod():
    temp_dir = '/tmp/test_chmod'
    print(f"{os.getcwd()}")
    print(f"{temp_dir}")
    Path(temp_dir).mkdir(mode=0o700, exist_ok=True)
    for sub_dir in ['dir_1', 'dir_2', 'dir_3']:
        (Path(temp_dir) / sub_dir).mkdir(mode=0o700, exist_ok=True)
        for sub_dir2 in ['dir_1', 'dir_2', 'dir_3']:
            (Path(temp_dir) / sub_dir / sub_dir2).mkdir(mode=0o700, exist_ok=True)

# Generated at 2022-06-21 13:04:13.772064
# Unit test for function path_absent
def test_path_absent():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        # Create a directory structure
        file_one = tmpdir.joinpath('file_one')
        file_one.touch()
        file_two = tmpdir.joinpath('file_two')
        file_two.touch()
        file_three = tmpdir.joinpath('file_three')
        file_three.touch()
        # Create a directory in tmpdir
        subdir = tmpdir.joinpath('subdir')
        subdir.mkdir()
        # Create a file in the subdir
        file_four = subdir.joinpath('file_four')
        file_four.touch()
        # Create a link in the subdir
        file_five = subdir.joinpath

# Generated at 2022-06-21 13:04:15.690582
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test function for function get_os_group."""
    assert 'struct_group' in repr(get_os_group())



# Generated at 2022-06-21 13:04:40.566881
# Unit test for function chmod
def test_chmod():
    # These are the expected file and directory modes
    # for each of the tests.
    test_modes = {
        'mode_file': 0o644,
        'mode_dir': 0o755,
        'mode_file_symlink': 0o600,
        'mode_dir_symlink': 0o700,
    }

    # Reset the modes of the test directory and files
    Path('~/tmp/flutils.tests').chmod(0o755)
    for sub_path in Path('~/tmp/flutils.tests').rglob('*'):
        if sub_path.is_dir():
            sub_path.chmod(0o755)
        elif sub_path.is_file() or sub_path.is_symlink():
            sub_path.chmod(0o644)

# Generated at 2022-06-21 13:04:42.021461
# Unit test for function chown
def test_chown():
    assert chown.__name__ == 'chown'



# Generated at 2022-06-21 13:04:50.033164
# Unit test for function path_absent
def test_path_absent():
    from . import Path_

    test_path = Path_('~/tmp/test_path')
    Path_(test_path).touch()
    assert os.path.exists(Path_(test_path)) is True

    path_absent(test_path)
    assert os.path.exists(Path_(test_path)) is False

    test_path = Path_('~/tmp/test_path')
    Path_(test_path).mkdir()
    assert os.path.exists(Path_(test_path)) is True

    Path_(test_path).joinpath('foo').touch()
    assert os.path.exists(Path_(test_path).joinpath('foo')) is True

    path_absent(test_path)
    assert os.path.exists(Path_(test_path)) is False

    test_path

# Generated at 2022-06-21 13:04:50.872355
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 13:05:04.829480
# Unit test for function chmod
def test_chmod():
    from flutils.osutils import find_paths
    from os import stat
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)

        # Create a directory and several files with modes that
        # are not the default.
        path = tmpdirname / 'test_chmod'
        path.mkdir(mode=0o777)
        path = path / 'test_chmod.txt'
        path.touch(mode=0o666)

        path = tmpdirname / 'test_chmod1'
        path.mkdir(mode=0o777)
        path = path / 'test_chmod1.txt'
        path.touch(mode=0o666)

        path = tmpdirname / 'test_chmod2'

# Generated at 2022-06-21 13:05:08.015516
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(normalize_path('~/does_not_exist')) == ''
    assert exists_as(normalize_path('/')) == 'directory'
    assert exists_as(normalize_path('/dev/null')) == 'char device'
    assert exists_as(normalize_path('/dev/random')) == 'character or block device'
    assert exists_as(normalize_path('/dev/zfs')) == 'character or block device'



# Generated at 2022-06-21 13:05:16.180402
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function: exists_as"""
    from os import mkdir, remove
    from os.path import join
    from random import randint
    from time import time
    from tempfile import gettempdir
    from flutils.pathutils import exists_as
    from flutils.pathutils import file_present
    from flutils.pathutils import directory_present

    tmp_dir = join(gettempdir(), str(time()))
    mkdir(tmp_dir)

    assert exists_as(tmp_dir) == 'directory'
    assert exists_as('/usr/bin/python3') == 'file'


# Generated at 2022-06-21 13:05:26.749990
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpd:
        tmpd = Path(tmpd)
        fn = tmpd / 'foo'
        fn.touch()
        fn = tmpd / 'foo2'
        os.symlink(fn.as_posix(), tmpd / 'foo2.ln')
        subd = tmpd / 'subd'
        subd.mkdir()
        fn = subd / 'bar'
        fn.touch()
        fn = subd / 'bar2'
        os.symlink(fn.as_posix(), subd / 'bar2.ln')
        path_absent(tmpd.as_posix())
        assert tmpd.exists() is False
        assert fn.exists() is False
        assert subd.exists() is False