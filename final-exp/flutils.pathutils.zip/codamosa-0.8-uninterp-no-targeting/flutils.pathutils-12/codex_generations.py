

# Generated at 2022-06-21 12:55:54.506760
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('./tmp_dir_present')

    # Remove the directory that was just created
    path.rmdir()



# Generated at 2022-06-21 12:56:07.932970
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for the normalize_path function."""
    for path in ['~/tmp/foo/../bar', '$HOME/tmp/foo/../bar']:
        assert normalize_path(path) == Path('~/tmp/bar')
    assert normalize_path(cast(Path, Path('~/tmp/foo/../bar'))) == Path(
        '~/tmp/bar'
    )

# Add type hints to the normalize_path function
normalize_path.register(bytes, lambda x: normalize_path(x.decode()))
normalize_path.register(PosixPath, lambda x: normalize_path(x.as_posix()))
normalize_path.register(WindowsPath, lambda x: normalize_path(x.as_posix()))



# Generated at 2022-06-21 12:56:14.876513
# Unit test for function chown
def test_chown():
    path = Path(tempfile.mkdtemp(
        prefix=f'{__name__}.',
        dir=os.path.realpath(tempfile.gettempdir())
    ))

    try:
        fpath = path / 'flutils.tests.osutils.txt'
        fpath.touch()
        chown(fpath, '0')
    finally:
        shutil.rmtree(path)



# Generated at 2022-06-21 12:56:16.299855
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent

    assert path_absent('/tmp/test_flutils_pathutils_path_absent')



# Generated at 2022-06-21 12:56:23.568764
# Unit test for function find_paths
def test_find_paths():
    path = '~/tmp/*'
    for found_path in find_paths(path):
        filepath = Path(found_path, 'file_one')
        if filepath.exists():
            filepath.unlink()
        dirpath = Path(found_path, 'dir_one')
        if dirpath.exists():
            dirpath.rmdir()
    assert list(find_paths(path)) == []



# Generated at 2022-06-21 12:56:32.307753
# Unit test for function find_paths
def test_find_paths():
    from os import chdir
    from os import getcwd
    from os import mkdir
    from os import rmdir
    from os import symlink
    from tempfile import TemporaryDirectory

    from pathlib import Path

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        chdir(tmp_dir)
        cwd = getcwd()

        # Create directories, files and symlinks in the temporary directory:
        #                                             cwd
        #                                              |
        #                                              +--tmp
        #                                              |
        #                                              +--tmp/dir_one
        #                                                    |
        #                                                    +--tmp/dir_one/file_one
        #                                                    |
        #                                                    +--tmp/dir_one/file_

# Generated at 2022-06-21 12:56:41.043118
# Unit test for function chown
def test_chown():
    # Initialize flags
    status_success = False

    # Check that a directory with the glob pattern is changed
    try:
        chown('/tmp/*', user='root', group='testing')
        status_success = True
    except OSError as e:
        if 'does not exist' in str(e):
            path = e.filename
            if path and isinstance(path, str) and '/tmp/' in path:
                status_success = True
    assert status_success is True



# Generated at 2022-06-21 12:56:47.082896
# Unit test for function find_paths
def test_find_paths():
    pattern = '~/tmp/*'
    found_paths = list(find_paths(pattern))

    for each in found_paths:
        assert isinstance(each, Path)

    assert isinstance(found_paths[0], PosixPath)



# Generated at 2022-06-21 12:56:50.316079
# Unit test for function get_os_user
def test_get_os_user():
    pwd.getpwuid = MagicMock(return_value='THE_PWD')

    get_os_user(1001)
    pwd.getpwuid.assert_called_with(1001)



# Generated at 2022-06-21 12:56:59.225845
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/test_path_absent')
    try:
        path.mkdir()
        sub_path = path / 'sub'
        sub_path.mkdir()
        with open(sub_path / 'test_file', 'w') as test_file:
            test_file.write('test_file')
        path_absent(path)
        assert not os.path.exists(path)
    finally:
        try:
            os.rmdir(path)
        except FileNotFoundError:
            pass

# Generated at 2022-06-21 12:57:22.843951
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    from shutil import rmtree

    temp_dir = tempfile.mkdtemp()
    try:
        tmp_path = directory_present(
            temp_dir + '/directory_present',
            0o777,
            getpass.getuser(),
            grp.getgrgid(os.getgid()).gr_name
        )

        assert tmp_path.is_dir() is True

    finally:
        rmtree(temp_dir)



# Generated at 2022-06-21 12:57:30.465006
# Unit test for function directory_present
def test_directory_present():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import directory_present

    class Test_directory_present(unittest.TestCase):
        def setUp(self):
            self.path = directory_present(os.path.join('/tmp', 'flutils'))

        def tearDown(self):
            shutil.rmtree(self.path)

        def test_directory_present(self):
            self.assertTrue(self.path.exists())
            self.assertTrue(self.path.is_dir())

    unittest.main()



# Generated at 2022-06-21 12:57:36.317560
# Unit test for function chmod
def test_chmod():
    # Setup
    from tempfile import gettempdir
    tmpdir = Path(gettempdir())
    path = tmpdir.joinpath('flutils.tests.bogus.txt')
    path.write_text('no data here')

    # Exercise
    chmod(str(path), mode_dir=0o700)

    # Verify
    assert path.stat().st_mode == 33152

    # Cleanup
    path.unlink()

# Generated at 2022-06-21 12:57:38.359183
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()


# Generated at 2022-06-21 12:57:48.525269
# Unit test for function directory_present
def test_directory_present():
    """Unit test for directory_present()

    """
    import doctest
    from flutils.pathutils import directory_present
    from flutils.testutils import test_failure_message

    test_path = '~/tmp/flutils.tests.osutils.test_directory_present.txt'

# Generated at 2022-06-21 12:57:55.152360
# Unit test for function normalize_path

# Generated at 2022-06-21 12:57:56.086498
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user  # noqa


# Generated at 2022-06-21 12:58:04.233785
# Unit test for function exists_as
def test_exists_as():
    # osutils.py:15: Path('~/tmp').is_dir() -> True
    test_list = [('~/tmp', 'directory'), ('/tmp', 'directory'), ('~/.bashrc', 'file'), ('~/.bash_profile', 'file')]
    for arg, expected in test_list:
        actual = exists_as(arg)
        assert actual == expected, 'exists_as({0!r}) should return {1!r} but returned {2!r}'.format(arg, expected, actual)
    # osutils.py:15: Path('~/tmp').is_dir() -> True
    # osutils.py:15: Path('~/.bashrc').is_file() -> True
    # osutils.py:15: Path('~/.bash_profile').is_file() -> True
    return True




# Generated at 2022-06-21 12:58:05.017903
# Unit test for function get_os_group
def test_get_os_group():
    pass



# Generated at 2022-06-21 12:58:13.912765
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import directory_present
    from os import chmod
    from os.path import expanduser
    from pathlib import PosixPath


    with TemporaryDirectory() as temp_dir:
        temp_dir_path = PosixPath(temp_dir)

        # Test: if the given path does not exist, it will be created
        # as a directory.
        dir_path = directory_present(
            temp_dir_path.joinpath('test_dir')
        )
        assert dir_path.exists() is True
        assert dir_path.is_dir() is True

        # Test: if the given path exists as a directory, the `mode`,
        # `user` and `group` will be applied.

# Generated at 2022-06-21 12:58:43.763763
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 12:58:57.498476
# Unit test for function path_absent
def test_path_absent():

    path = Path('~/tmp/flutils/path_absent').expanduser()
    path.mkdir(parents=True, exist_ok=True)

    path = path / 'file_one'
    with path.open('wt') as fd:
        fd.write('Blah blah blah.')

    path = path.with_name('dir_one')
    assert not path.is_dir()
    path.mkdir()

    assert path.is_dir()
    path_absent(path)
    assert not path.is_dir()

    path = path.with_name('dir_one')
    assert not path.is_dir()
    path.mkdir()

    path = path / 'file_two'

# Generated at 2022-06-21 12:59:05.085514
# Unit test for function directory_present
def test_directory_present():
    import shutil
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    tmp_path = Path(tmp_dir)
    tmp_path.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-21 12:59:15.258735
# Unit test for function find_paths
def test_find_paths():
    # Test for no glob patterns found
    pattern = '~/tmp/*'
    with mock.patch('os.path.expanduser',
                    return_value='/home/test_user/tmp/*'):
        result = find_paths(pattern)
        assert type(result) == GeneratorType
        with mock.patch.object(
                Path,
                'glob',
                return_value=[]
        ):
            assert list(result) == []
    # Test Good Case
    with mock.patch('os.path.expanduser',
                    return_value='/home/test_user/tmp/*'):
        result = find_paths(pattern)
        assert type(result) == GeneratorType

# Generated at 2022-06-21 12:59:16.697139
# Unit test for function get_os_group
def test_get_os_group():
    with raises(OSError):
        get_os_group('invalid')



# Generated at 2022-06-21 12:59:28.931380
# Unit test for function directory_present
def test_directory_present():
    from unittest import TestCase

    from flutils.pathutils import directory_present

    class Test_directory_present(TestCase):

        def test_create_path(self):
            path = directory_present('~/tmp/test_path')
            self.assertTrue(path.exists() is True)

        def test_create_parent_path(self):
            path = directory_present('~/tmp/test_path1/test_path2')
            self.assertTrue(path.parent.exists() is True)


# Generated at 2022-06-21 12:59:29.822757
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-21 12:59:38.661788
# Unit test for function directory_present
def test_directory_present():

    from os.path import exists
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from flutils.pathutils import directory_present

    with TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)
        base.mkdir(mode=0o770)
        sub = base / 'sub'
        create_sub_dir = True
        if create_sub_dir:
            sub.mkdir(mode=0o770)
        sub_sub = sub / 'sub_sub'
        create_sub_sub_dir = True
        if create_sub_sub_dir:
            sub_sub.mkdir(mode=0o770)
        sub_sub_sub = sub_sub / 'sub_sub_sub'
        create_sub_sub_sub_dir = True

# Generated at 2022-06-21 12:59:44.333652
# Unit test for function get_os_group

# Generated at 2022-06-21 12:59:49.690800
# Unit test for function path_absent
def test_path_absent():
    path = os.path.join(tempfile.gettempdir(), '_flutils_pathutils_test.txt')
    open(path, 'w+').close()

    assert os.path.exists(path) is True

    path_absent(path)

    assert os.path.exists(path) is False



# Generated at 2022-06-21 13:00:15.856206
# Unit test for function find_paths
def test_find_paths():
    os.environ["HOME"] = '/home/test_user'


# Generated at 2022-06-21 13:00:24.100569
# Unit test for function chmod
def test_chmod():
    from tempfile import mkdtemp

    tmp_dir_path = Path(mkdtemp())

    file_path = (tmp_dir_path / 'foo.txt')
    file_path.touch()

    sub_dir_path = tmp_dir_path / 'bar'
    sub_dir_path.mkdir()

    file_path2 = sub_dir_path / 'baz.txt'
    file_path2.touch()


# Generated at 2022-06-21 13:00:36.722156
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    h_dir1 = tempfile.TemporaryDirectory()
    h_dir2 = tempfile.TemporaryDirectory()
    with NamedTemporaryFile('w', dir=h_dir1.name) as fh:
        fh.write('Test 1\n')
        fh.flush()
        path_absent(h_dir1.name)
        assert not os.path.exists(h_dir1.name)
        assert not os.path.exists(fh.name)
    with NamedTemporaryFile('w', dir=h_dir2.name) as fh:
        fh.write('Test 2')
        fh.flush()
        path_absent(fh.name)
        assert not os.path.exists(fh.name)
        assert os.path.exists

# Generated at 2022-06-21 13:00:40.260049
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user()
    with pytest.raises(OSError):
        get_os_user(name='not_a_user')
    get_os_user(name='root')



# Generated at 2022-06-21 13:00:50.421707
# Unit test for function path_absent
def test_path_absent():
    # Unit test to ensure paths are deleted
    path = normalize_path("~/tmp/test_path")

    # Create a directory
    path.mkdir(exist_ok=True, parents=True)

    # This should delete the directory
    path_absent("~/tmp/test_path")
    assert not path.exists()

    # Create a directory
    path_absent("~/tmp/test_path")
    path.touch()

    # This should delete the file
    path_absent("~/tmp/test_path")
    assert not path.exists()

    # Create a directory
    path.mkdir()
    child_path = path / "child_path"
    child_path.touch()

    # This should delete the directory
    path_absent("~/tmp/test_path")
   

# Generated at 2022-06-21 13:01:01.857418
# Unit test for function normalize_path
def test_normalize_path():
    pth = normalize_path('~/tmp/foo/../bar')
    assert type(pth) == type(Path.home())
    assert pth.exists() is False
    assert pth.as_posix().startswith(str(Path.home()))
    assert pth.as_posix() == os.path.expanduser('~/tmp/bar')

    pth: Path = Path('~/tmp/bar')
    assert type(pth) == type(Path.home())
    assert pth.exists() is False
    assert pth.as_posix().startswith(str(Path.home()))
    assert pth.as_posix() == os.path.expanduser('~/tmp/bar')
test_normalize_path()



# Generated at 2022-06-21 13:01:06.776560
# Unit test for function get_os_group
def test_get_os_group():
    msg = 'Failed to get the current user\'s group'
    grp_obj = get_os_group()
    assert isinstance(grp_obj, grp.struct_group), msg

    grp_obj = get_os_group(grp_obj.gr_gid)
    assert isinstance(grp_obj, grp.struct_group), msg

    msg = 'Failed to raise OSError on invalid group name'
    with pytest.raises(OSError):
        get_os_group('_invalid_group')

    msg = 'Failed to raise OSError on invalid group id'
    invalid_gid = int(grp_obj.gr_gid) + 1
    with pytest.raises(OSError):
        get_os_group(invalid_gid)



# Generated at 2022-06-21 13:01:14.378555
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths()."""
    from flutils.pathutils import find_paths
    from flutils.testing import TempDirectory
    with TempDirectory() as tmpdir:
        for _ in range(2):
            Path(tmpdir / 'test*').touch()
        for _ in range(2):
            Path(tmpdir / 'test*' / 'child*').touch()

        paths = find_paths(tmpdir / 'test*' / 'child*')
        paths = list(paths)
        assert len(paths) == 4

# Generated at 2022-06-21 13:01:26.357219
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import (
        directory_present,
        path_absent,
    )
    import os

    test_path = Path('~/tmp/flutils.tests.directory_present')

    try:
        directory_present(test_path)
        assert (
            os.stat(test_path.as_posix()).st_mode & 0o777
            == 0o700
        )
    finally:
        path_absent(test_path)

    os.mkdir(test_path.as_posix(), mode=0o755)


# Generated at 2022-06-21 13:01:30.525982
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent
    """
    # Test invalid path exceptions
    with pytest.raises(TypeError) as excinfo:
        path_absent()  # type: ignore
    assert (
        'an integer is required (got type NoneType)'
    ) in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        path_absent(b'badpath')  # type: ignore
    assert (
        'expected str, bytes or os.PathLike object, not bytes'
    ) in str(excinfo.value)

    # Test if path is not present when not present
    with pytest.raises(FileNotFoundError) as excinfo:
        path_absent('/tmp/doesnotexist/badpath')

# Generated at 2022-06-21 13:02:12.768533
# Unit test for function directory_present
def test_directory_present():
    with temporary_directory() as temp_dir:

        temp_path = cast(Path, temp_dir)

        # Test chown with default values
        directory_present(temp_path / 'root')
        stat = os.stat(temp_path / 'root')
        assert stat.st_uid == os.getuid()
        assert stat.st_gid == os.getgid()

        # Test mode changes
        directory_present(temp_path / 'root', mode=0o600)
        stat = os.stat(temp_path / 'root')
        assert stat.st_mode == 0o40700

        # Test user and group
        directory_present(temp_path / 'root', user='root', group='_www')
        directory_present(temp_path / 'root', user='_www', group='_www')
       

# Generated at 2022-06-21 13:02:20.055937
# Unit test for function get_os_user
def test_get_os_user():
    """Test for function flutils.pathutils.get_os_user()"""
    get_os_user('root')
    get_os_user('daemon')
    try:
        get_os_user('foo')
    except OSError:
        pass
    else:
        raise RuntimeError('Test raised no exceptions.  Should have failed.')
    get_os_user(501)
    get_os_user(502)
    try:
        get_os_user(1)
    except OSError:
        pass
    else:
        raise RuntimeError('Test raised no exceptions.  Should have failed.')



# Generated at 2022-06-21 13:02:28.931047
# Unit test for function chown
def test_chown():
    if sys.platform == 'win32':
        return

    p = Path('~/.flutils.tests.pathutils.test_chown').expanduser()
    p.mkdir(parents=True, exist_ok=True)
    try:
        chown(p, user='1')
        chown(p, group='1')
        chown(p, user='1', group='1')
        if os.geteuid() == 0:
            chown(p, user='root', group='root')
            chown(p, user='-1', group='-1')
    finally:
        if p.exists() is True:
            p.rmdir()



# Generated at 2022-06-21 13:02:41.501121
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmp_dir / 'dir_two'
        dir_two.mkdir()
        file_one = tmp_dir / 'file_one'
        file_one.touch()

        file_one.as_posix()
        dir_one.as_posix()
        dir_two.as_posix()

        path_absent(tmp_dir.as_posix())

        assert file_one.exists() is False
        assert dir_one.exists() is False
        assert dir_two.exists() is False

# Generated at 2022-06-21 13:02:44.461642
# Unit test for function get_os_group
def test_get_os_group():
    """Test the get_os_group function."""
    from flutils.pathutils import get_os_group
    from flutils.tests.pathutils import get_current_os_group
    assert get_os_group() is get_current_os_group()



# Generated at 2022-06-21 13:02:52.871545
# Unit test for function chown
def test_chown():
    from pathlib import Path
    from flutils.pathutils import chown

    TEST_PATH = Path(__file__).parent / 'tmp' / 'flutils.tests' / 'osutils.txt'
    TEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    TEST_PATH.touch()

    # Test chown of a single file
    chown(TEST_PATH)

    # Test chown of a glob pattern
    chown(str(Path(__file__).parent / 'tmp' / '**'))

    # Test chown of a glob pattern with the parent dir included
    chown(str(Path(__file__).parent / 'tmp' / '**'), include_parent=True)

    # Test chown of a glob pattern with the parent dir included
    # and changing the user and group.


# Generated at 2022-06-21 13:03:04.913040
# Unit test for function path_absent
def test_path_absent():
    # Create the test file to remove
    with open(os.path.join(TEST_TMP_DIR, 'test_absent_file'), 'w') as f:
        f.write('Test file for path_absent function')
    # Remove the test file
    path_absent(os.path.join(TEST_TMP_DIR, 'test_absent_file'))
    assert os.path.exists(os.path.join(TEST_TMP_DIR, 'test_absent_file')) is False
    # Create the test directory to remove
    os.mkdir(os.path.join(TEST_TMP_DIR, 'test_absent_dir'))
    # Remove the test directory

# Generated at 2022-06-21 13:03:11.654652
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory(prefix='test_path_absent_') as tmpdir:
        f = Path(tmpdir) / 'file'
        d = Path(tmpdir) / 'dir'
        f.touch()
        d.mkdir()
        g = d / 'file_under'
        g.touch()

        path_absent(f.as_posix())
        path_absent(d.as_posix())

        assert not f.is_file()
        assert not d.is_dir()
        assert not g.is_file()

# Generated at 2022-06-21 13:03:16.035548
# Unit test for function find_paths
def test_find_paths():
    assert [x.as_posix() for x in find_paths('~/tmp/*')] == [
        normalize_path('~/tmp/file_one').as_posix(),
        normalize_path('~/tmp/dir_one').as_posix()
    ]



# Generated at 2022-06-21 13:03:27.204736
# Unit test for function chown
def test_chown():
    from flutils.osutils import get_os_user
    from flutils.pathutils import chown
    from io import StringIO
    from os import remove
    from os.path import expanduser
    from random import randint
    from tempfile import NamedTemporaryFile

    out_file = NamedTemporaryFile('w', delete=False)
    uid = get_os_user().pw_uid
    gid = get_os_gid().gr_gid
    os.chown(out_file.name, uid, gid)
    out_file.close()

    try:
        chown(out_file.name, '-1', '-1')
    except OSError:
        pass
    else:
        assert False, f'Wanted the function to raise OSError'


# Generated at 2022-06-21 13:04:40.382780
# Unit test for function chown
def test_chown():
    assert chown(__file__, user=__file__) is None
    assert chown(__file__, user=-1) is None
    assert chown(__file__, group=__file__) is None
    assert chown(__file__, group=-1) is None
    assert chown(__file__) is None
    assert chown(__file__, include_parent=True) is None
    assert chown(__file__, user=__file__, include_parent=True) is None
    assert chown(__file__, user=-1, include_parent=True) is None
    assert chown(__file__, group=__file__, include_parent=True) is None
    assert chown(__file__, group=-1, include_parent=True) is None



# Generated at 2022-06-21 13:04:41.063465
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-21 13:04:44.744459
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()[0] == os.getlogin()
    assert get_os_user().pw_uid == os.getuid()
    assert get_os_user('len').pw_uid == os.getuid()



# Generated at 2022-06-21 13:04:46.446781
# Unit test for function chown
def test_chown():
    assert chown.__doc__ is not None

# Generated at 2022-06-21 13:05:00.370164
# Unit test for function find_paths
def test_find_paths():
    with Tempdir() as tmpdir:
        for iter_tmpdir in tmpdir:
            dir_path = Path(iter_tmpdir.as_posix(), 'tmp')
            dir_path.mkdir()
            Path(dir_path, 'file_one').touch()
            Path(dir_path, 'file_two').touch()
            Path(dir_path, 'file_three').touch()
            Path(dir_path, 'file_four').touch()
            Path(dir_path, 'folder_one').mkdir()
            Path(dir_path, 'folder_two').mkdir()
            Path(dir_path, 'folder_three').mkdir()


# Generated at 2022-06-21 13:05:09.527232
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        _tmp_dir = Path(tmp_dir)
        _tmp_path = directory_present(_tmp_dir / 'flutils.tests.pathutils.txt')
        assert _tmp_path.as_posix() == \
            str(_tmp_dir / 'flutils.tests.pathutils.txt')
        assert _tmp_path.exists() is True
        assert _tmp_path.is_dir() is True
        assert _tmp_path.is_file() is False
        assert _tmp_path.is_symlink() is False



# Generated at 2022-06-21 13:05:17.145899
# Unit test for function path_absent
def test_path_absent():
    import time
    import getpass
    test_user = getpass.getuser()
    tmp_dir = os.path.join('/tmp', time.strftime('%Y_%m_%d'))
    if not os.path.exists(tmp_dir):
        os.mkdir(tmp_dir)
    path_to_create = os.path.join(tmp_dir, 'test_path')
    if os.path.exists(path_to_create):
        if os.path.isfile(path_to_create):
            os.unlink(path_to_create)