

# Generated at 2022-06-21 12:56:01.115075
# Unit test for function find_paths
def test_find_paths():
    from .osutils import create_file
    from .osutils import create_directory

    path = create_directory('~/tmp/test_find_paths')
    create_file(path / 'file_one')
    create_file(path / 'file_two')
    create_directory(path / 'dir_one')

    matched_paths = []
    for path in find_paths(path / '**'):
        matched_paths.append(path)

    assert len(matched_paths) == 3
    assert matched_paths == [
        Path(path).expanduser() / 'file_one',
        Path(path).expanduser() / 'file_two',
        Path(path).expanduser() / 'dir_one',
    ]
    assert matched_paths[0].exists() is True

# Generated at 2022-06-21 12:56:10.259361
# Unit test for function get_os_group
def test_get_os_group():
    group_name = 'test_group'
    group_id = 0o2001
    group_members = ['test_user']
    group_password = '*'

    test_group = grp.struct_group(
        gr_name=group_name,
        gr_passwd=group_password,
        gr_gid=group_id,
        gr_mem=group_members,
    )
    test_group_dict: _DICT_GRP = dict(
        gr_name=group_name,
        gr_passwd=group_password,
        gr_gid=group_id,
        gr_mem=group_members,
    )
    with mock.patch.object(grp, 'getgrnam', return_value=test_group):
        test_result = get_os_group()

# Generated at 2022-06-21 12:56:15.448874
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function **get_os_user** located in the module **pathutils**."""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument

    from pathlib import Path

    from pytest import raises
    from pytest_mock import MockFixture

    from flutils.pathutils import get_os_user

    from flutils.systemutils import get_user_name
    from flutils.systemutils import get_user_uid


    def test_no_user_name_or_uid(mocker: MockFixture) -> None:
        """Test the function with no user name or uid."""

# Generated at 2022-06-21 12:56:23.517618
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from pathlib import PurePosixPath
    from pathlib import PureWindowsPath
    from random import choice
    from shutil import rmtree

    # Make a random string for the test directory name.
    rnd_str = ''.join(
        choice('abcdefghijklmnopqrstuvwxyz') for i in range(8)
    )


# Generated at 2022-06-21 12:56:32.275774
# Unit test for function find_paths
def test_find_paths():
    test_path = 'test_path'
    test_file = 'test_file'
    test_file_path = pure_path(test_path, test_file)

    # Create the test path by calling directory_present.
    test_path = directory_present(test_path)

    # Create a test file.
    _create_file(test_file_path)

    paths = list(find_paths(test_path))

    # Check that the test_path is included in the
    # results.
    assert test_path.as_posix() in (path.as_posix() for path in paths)

    # Check that the test_file is included in the
    # results.
    assert test_file_path.as_posix() in (path.as_posix() for path in paths)

    # Clean-

# Generated at 2022-06-21 12:56:44.145322
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import shutil

    def _helper(path):
        # Test on directories.
        chmod(path, mode_dir=0o700, mode_file=0o660)
        assert stat.S_IMODE(os.stat(path).st_mode) == 0o660

        # Test on files
        file_path = os.path.join(path, 'foo.txt')
        with open(file_path, 'a') as fp:
            pass
        chmod(path, mode_dir=0o700, mode_file=0o660)
        assert stat.S_IMODE(os.stat(file_path).st_mode) == 0o660

        # Test that nothing happens when the path doesn't exist.

# Generated at 2022-06-21 12:56:49.592529
# Unit test for function exists_as
def test_exists_as():
    test_path = Path(__file__).parent.joinpath('exists_as_test.txt')
    try:
        # Test does not exist
        assert exists_as(test_path) == ''
        # Test exists as file
        test_path.write_text('')
        assert exists_as(test_path) == 'file'
        # Test exists as directory
        test_path.unlink()
        test_path.mkdir(parents=True)
        assert exists_as(test_path) == 'directory'
    finally:
        test_path.rmdir()


# The following functions are used in file_present.
# They are NOT meant to be used independently.

# Generated at 2022-06-21 12:56:55.408083
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'osutils.txt'
    chown(path)
    assert os.stat(path.as_posix()).st_uid == get_os_user().pw_uid
    assert os.stat(path.as_posix()).st_gid == get_os_group().gr_gid



# Generated at 2022-06-21 12:56:59.272676
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    tmp_dir = directory_present(
        Path(__file__).parent.parent / 'tmp' / 'unit_tests'
    )
    assert tmp_dir.is_dir() is True



# Generated at 2022-06-21 12:57:05.832529
# Unit test for function chown
def test_chown():
    """Unit test for function chown
    """
    p = Path(__file__).parent.joinpath('test_chown.txt')
    if p.exists():
        p.unlink()
    p.touch()
    m = p.stat().st_mode
    chown(p, user='-1', group='-1')
    assert p.stat().st_mode == m
    x = get_os_user()
    y = get_os_group()
    chown(p, user=x.pw_name, group=y.gr_name)
    assert p.stat().st_uid == x.pw_uid
    assert p.stat().st_gid == y.gr_gid
    p.unlink()



# Generated at 2022-06-21 12:57:24.676091
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-21 12:57:26.932694
# Unit test for function get_os_group
def test_get_os_group():
    """Test the function: get_os_group."""
    # Simple function so just smoke test it.
    get_os_group()



# Generated at 2022-06-21 12:57:29.016759
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    get_os_user(get_os_user().pw_name)

# Generated at 2022-06-21 12:57:36.118567
# Unit test for function chown
def test_chown():
    from test.utils.helpers import paths as _paths, remove_test_paths as _remove
    _test_paths = ['~/tmp/flutils.tests.osutils/chown.txt', ]
    _paths(_test_paths)

    chown(os.path.expanduser(_test_paths[0]))

    with Path(os.path.expanduser(_test_paths[0])).open('wt') as _f:
        _f.write('foo')

    chown(os.path.expanduser(_test_paths[0]))
    chown(os.path.expanduser(_test_paths[0] + '*'))
    chown(os.path.expanduser(_test_paths[0] + '*'), group='-1')
    ch

# Generated at 2022-06-21 12:57:46.801329
# Unit test for function chown
def test_chown():
    import pytest
    from io import StringIO
    from tempfile import TemporaryDirectory
    # Let's first create a directory
    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        # We need to touch a file and
        # we need to create a subdirectory
        # and touch a file in it
        touch('{}/foo.txt'.format(tmpdir))
        mkdir('{}/bar'.format(tmpdir))
        touch('{}/bar/baz.txt'.format(tmpdir))
        # Let's get the current user
        current_user = getpass.getuser()
        # Let's get the current user's
        # group
        current_group = grp.getgrgid(os.getgid()).gr_name
        # Let's confirm our directory permissions


# Generated at 2022-06-21 12:57:48.319379
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    pass



# Generated at 2022-06-21 12:57:53.762701
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user() function."""
    # Test as named user
    test_user_obj = get_os_user('user1')
    assert test_user_obj.pw_name == 'user1'
    assert test_user_obj.pw_uid > 0
    assert test_user_obj.pw_gid > 0
    # Test as uid
    test_user_obj = get_os_user(1000)
    assert test_user_obj.pw_uid == 1000
    assert test_user_obj.pw_name != ''



# Generated at 2022-06-21 12:57:54.395051
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-21 12:57:56.085586
# Unit test for function find_paths
def test_find_paths():
    for sub_path in find_paths('~/.config/**'):
        assert sub_path.is_dir() or sub_path.is_file()



# Generated at 2022-06-21 12:58:05.301254
# Unit test for function chown
def test_chown():
    import pytest
    from flutils.pathutils import chown
    from pytest_mock import mocker
    from os import path
    from sys import platform

    with mocker.patch(
            'flutils.pathutils.normalize_path'
    ) as mock_normalize_path:
        with mocker.patch(
                'flutils.pathutils.get_os_user'
        ) as mock_get_os_user:
            with mocker.patch(
                    'flutils.pathutils.get_os_group'
            ) as mock_get_os_group:
                with mocker.patch(
                        'flutils.pathutils.os.chown'
                ) as mock_chown:

                    mock_normalize_path.return_value = Path('~/tmp').expanduser()
                    mock_

# Generated at 2022-06-21 12:58:23.148778
# Unit test for function normalize_path
def test_normalize_path():
    with mock.patch('os.path.expanduser', side_effect=lambda x: x):
        with mock.patch('os.path.expandvars', side_effect=lambda x: x):
            with mock.patch('os.path.normpath', side_effect=lambda x: x):
                with mock.patch('os.path.normcase', side_effect=lambda x: x):
                    with mock.patch('flutils.pathutils.Path'):
                        with pytest.raises(TypeError):
                            normalize_path(path=None)
    #
    # TypeError: normalize_path() missing 1 required positional
    # argument: 'path'
    #

# Generated at 2022-06-21 12:58:29.567542
# Unit test for function find_paths
def test_find_paths():
    # Create the test files.
    with tempfile.TemporaryDirectory(dir='.') as dir_path:
        # Create files
        dir_one = Path(dir_path, 'dir_one')
        file_one = Path(dir_one, 'file_one')
        file_two = Path(dir_one, 'file_two')

        dir_one.touch()
        file_one.touch()
        file_two.touch()

        expected_paths = [
            Path(dir_one),
            Path(file_one),
            Path(file_two)
        ]
        for path in find_paths(dir_one):
            assert path in expected_paths
        for path in find_paths(file_one):
            assert path in expected_paths

# Generated at 2022-06-21 12:58:42.307088
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import _os_name, directory_present
    from os import (
        mkdir,
        rmdir,
    )
    from pathlib import Path

    # Setup directory to test the function.
    test_path = Path(__file__).parent / 'tmp_flutils_test_directory_present'
    Path.mkdir(test_path, mode=0o700, exist_ok=True)

    if _os_name == 'posix':
        result = test_path / 'new_dir'
        assert result == directory_present(result)
        result.mkdir(mode=0o777)
        try:
            directory_present(result)
            raise NotImplementedError
        except FileExistsError:
            pass
        else:
            raise NotImplementedError

# Generated at 2022-06-21 12:58:55.005155
# Unit test for function get_os_user
def test_get_os_user():
    name = test_get_os_group(assert_value=True).gr_name
    assert get_os_user(name=name).pw_name == name
    assert get_os_user(name=name).pw_name == name
    assert get_os_user(name=name).pw_gid == get_os_group(name=get_os_user(name=name).pw_gid).gr_gid
    name = 'foo'
    assert get_os_user(name=name).pw_name == name
    assert get_os_user(name=name).pw_name == name
    assert get_os_user(name=name).pw_gid == get_os_group(name=get_os_user(name=name).pw_gid).gr_gid




# Generated at 2022-06-21 12:59:08.008725
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import pytest
    from pathlib import Path

    dir_name = 'path_absent'
    path = Path.home() / 'tmp' / dir_name
    path.mkdir(parents=True)
    path = path / 'test_path'
    path_absent(path)
    assert path.exists() is False

    path = Path.home() / 'tmp' / dir_name
    path.mkdir(parents=True)
    path = path / 'test_path'
    path.touch()
    path_absent(path)
    assert path.exists() is False

    path = Path.home() / 'tmp' / dir_name / 'file_path'
    path.touch()
    path_absent(path)
    assert path.ex

# Generated at 2022-06-21 12:59:16.451420
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    path = Path('/tmp/test_path')
    try:
        path.mkdir(0o755, exist_ok=True)
        path.touch()
        path.mkdir(0o755, exist_ok=True)
        path.joinpath('foo').mkdir(0o755, exist_ok=True)
        path.joinpath('foo').touch()
        path.joinpath('foo', 'bar').touch()
        path.joinpath('baz').mkdir(0o755, exist_ok=True)
        path.joinpath('baz').write_bytes(b'baz')
        path_absent(path.as_posix())
        assert not path.exists()
    finally:
        path_absent(path.as_posix())



# Generated at 2022-06-21 12:59:22.920827
# Unit test for function get_os_group
def test_get_os_group():
    ''' Check if get_os_group can return the current user's group '''
    cur_user = get_os_user()
    cur_grp = get_os_group(cur_user.pw_gid)
    assert(cur_user.pw_gid == cur_grp.gr_gid)



# Generated at 2022-06-21 12:59:32.477202
# Unit test for function chown
def test_chown():
    import tempfile
    import unittest
    import uuid
    class ChownUnitTests(unittest.TestCase):
        def setUp(self):
            self.test_dir = Path(tempfile.gettempdir(), uuid.uuid4().hex)
            self.test_dir.mkdir()
            self.test_sub_dir = Path(self.test_dir, uuid.uuid4().hex)
            self.test_sub_dir2 = Path(self.test_sub_dir, uuid.uuid4().hex)
            self.test_sub_dir.mkdir()
            self.test_sub_dir2.mkdir()
            self.test_sub_dir3 = Path(self.test_sub_dir2, uuid.uuid4().hex)
            self.test_sub_

# Generated at 2022-06-21 12:59:40.234189
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    tmp_dir = Path('~/tmp').expanduser()
    test_path = tmp_dir / 'test_path'
    test_file = test_path / 'test_file.txt'
    test_file_bytes = test_path / b'test_file_bytes.txt'
    test_file_str = test_path / 'test_file_str.txt'
    test_file_unicode = test_path / 'test_file_unicode.txt'
    test_dir = test_path / 'test_dir'
    test_dir_bytes = test_path / b'test_dir_bytes'
    test_dir_str = test_path / 'test_dir_str'

# Generated at 2022-06-21 12:59:43.088353
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent

    assert path_absent('/tmp/foo/bar') is None



# Generated at 2022-06-21 13:00:01.417769
# Unit test for function get_os_user
def test_get_os_user():
    # Test using the current user
    current_user = get_os_user()
    assert isinstance(current_user, pwd.struct_passwd)

    # Test using the current user's "login name"
    current_user = get_os_user(getpass.getuser())
    assert isinstance(current_user, pwd.struct_passwd)

    # Test using the current user's uid
    current_user = get_os_user(os.getuid())
    assert isinstance(current_user, pwd.struct_passwd)

    # Test using a random "login name"
    random_name = "flutils_{}".format(str(uuid.uuid4()))
    # TODO: Create a new user object and pass it to the function
    # try:
    #     os_user = pwd

# Generated at 2022-06-21 13:00:02.696801
# Unit test for function find_paths
def test_find_paths():
    list(find_paths('~/tmp/*'))



# Generated at 2022-06-21 13:00:14.145406
# Unit test for function chown
def test_chown():
    from unittest.mock import patch
    from testdata import TestData

    with TestData.temp_dir() as temp_dir:
        home = temp_dir
        user = 'foobar'
        group = 'foozbar'

        # create user and group

# Generated at 2022-06-21 13:00:23.283966
# Unit test for function get_os_user
def test_get_os_user():
    user_one = get_os_user('user_one')
    assert isinstance(user_one, pwd.struct_passwd)
    assert user_one.pw_name == 'user_one'
    assert user_one.pw_passwd == 'x'
    assert user_one.pw_uid == 1001
    assert user_one.pw_gid == 1001
    assert user_one.pw_gecos == 'User One,,,'
    assert user_one.pw_dir == '/home/user_one'
    assert user_one.pw_shell == '/bin/bash'
    user_two = get_os_user(1001)
    assert user_one.pw_name == user_two.pw_name
    assert user_one.pw_passwd == user_two

# Generated at 2022-06-21 13:00:35.853520
# Unit test for function find_paths
def test_find_paths():
    """Test function ``find_paths``"""
    tmpdir = tempfile.TemporaryDirectory(prefix='flutils.tests.')
    tmpdir_path = pathlib.Path(tmpdir.name)
    test_file_one = tmpdir_path / 'file_one'
    test_file_two = tmpdir_path / 'file_two'
    test_dir_one = tmpdir_path / 'dir_one'

    test_file_one.touch()
    test_file_two.touch()
    test_dir_one.mkdir()

    assert list(find_paths(tmpdir_path / 'file_*')) == [test_file_one, test_file_two]

# Generated at 2022-06-21 13:00:38.469876
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    assert normalize_path('~/tmp') == normalize_path(Path('~/tmp'))



# Generated at 2022-06-21 13:00:49.255310
# Unit test for function chmod
def test_chmod():
    import pathlib
    import shutil

    path_1 = pathlib.Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path_2 = pathlib.Path('~/tmp/flutils.tests.osutils.dir').expanduser()
    path_2_1 = pathlib.Path(str(path_2) + '/flutils.tests.osutils.txt').expanduser()
    path_3 = pathlib.Path('~/tmp/flutils.tests.osutils.dir2').expanduser()

    if path_1.exists() is False:
        path_1.touch()

    if path_2.exists() is False:
        path_2.mkdir()

    if path_2_1.exists() is False:
        path_2_1.touch

# Generated at 2022-06-21 13:00:51.293716
# Unit test for function get_os_user
def test_get_os_user():
    """Test the ``get_os_user`` function.
    """
    assert get_os_user() == pwd.getpwuid(os.getuid())



# Generated at 2022-06-21 13:00:54.375951
# Unit test for function get_os_group
def test_get_os_group():
    try:
        # This should raise a KeyError because this group does not exist.
        get_os_group('does_not_exist')
    except OSError:
        pass
    else:
        assert False

    get_os_group('root')
    get_os_group(0)



# Generated at 2022-06-21 13:01:04.006333
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent"""
    # Create a temporary directory to work in.
    temp_dir = tempfile.TemporaryDirectory()
    path = Path(temp_dir.name)

    path = path / 'test_file'
    path.touch()
    path_absent(path)
    assert not path.exists()

    path = path.parent / 'test_dir'
    path.mkdir()
    path_absent(path)
    assert not path.exists()

    path = path.parent / 'test_dir_with_contents'
    path.mkdir()
    (path / 'file').touch()
    (path / 'dir').mkdir()
    (path / 'dir' / 'file').touch()

    path_absent(path)
    assert not path.exists()

    temp

# Generated at 2022-06-21 13:01:21.004563
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')

    try:
        import_module('.pathutils', package=__package__)
        path_absent(path)
        assert not path.exists()

        # Test directory absent
        path.mkdir()
        path2 = path / 'tmp2'
        path2.touch()
        path_absent(path)
        assert not path.exists()
        assert not path2.exists()

    finally:
        if path.exists():
            shutil.rmtree(path)



# Generated at 2022-06-21 13:01:23.214001
# Unit test for function exists_as
def test_exists_as():
    from flutils import exists_as
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('tmp') == ''



# Generated at 2022-06-21 13:01:31.215295
# Unit test for function path_absent
def test_path_absent():

    # Create test directories.
    tmpdir = Path(get_temp_dir())
    tmpdir.mkdir(mode=0o700, exist_ok=True)
    tmpdir = normalize_path(tmpdir)
    tmpdir = tmpdir.as_posix()
    tmpdir = cast(str, tmpdir)
    orig_cwd = os.getcwd()
    os.chdir(tmpdir)

    t = normalize_path('~')
    t = t.as_posix()
    t = cast(str, t)
    os.environ['TEST_STR'] = t
    del t

    # Create a test file.
    path = normalize_path('~/tmp/file_one')
    path = path.as_posix()
    path = cast(str, path)
    open

# Generated at 2022-06-21 13:01:45.321920
# Unit test for function find_paths
def test_find_paths():
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from flutils.pathutils import find_paths, path_exists

    with TemporaryDirectory(prefix='test_flutils.pathutils') as tmp_path:
        tmp_path = Path(tmp_path)

        test_file_one = tmp_path / 'file_one'
        test_file_two = tmp_path / 'file_two'
        test_dir_one = tmp_path / 'dir_one'
        test_dir_two = tmp_path / 'dir_two'
        test_dir_one.mkdir(mode=0o700, parents=True)
        test_dir_two.mkdir(mode=0o700, parents=True)
        test_file_one.touch(mode=0o600, exist_ok=False)

# Generated at 2022-06-21 13:01:57.961781
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('/this/does/not/exist') == ''
    assert exists_as('/this/does/not/exists/neither') == ''
    assert exists_as('/etc/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/pts') == 'directory'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/stdin') == 'symlink'
    assert exists_as('/dev/stdout') == 'symlink'
    assert exists_as('/dev/stderr') == 'symlink'

# Generated at 2022-06-21 13:02:03.737545
# Unit test for function get_os_group
def test_get_os_group():
    g = get_os_group('foo')
    assert g.gr_name == 'foo'
    assert g.gr_passwd == '*'
    assert g.gr_gid == 1999
    assert g.gr_mem == ['foo']

    g = get_os_group('bar')
    assert g.gr_name == 'bar'
    assert g.gr_passwd == '*'
    assert g.gr_gid == 2001
    assert g.gr_mem == ['foo']


# Generated at 2022-06-21 13:02:06.653458
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user(1000).pw_name == 'nobody'



# Generated at 2022-06-21 13:02:09.692404
# Unit test for function get_os_user
def test_get_os_user():
    expected: pwd.struct_passwd = os.getpwnam(getpass.getuser())
    assert expected == get_os_user()



# Generated at 2022-06-21 13:02:18.145882
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path function for all possible arguments."""
    assert (normalize_path('~/tmp/foo/../bar')
            ==
            Path('/home/test_user/tmp/bar'))
    from pathlib import PurePosixPath, PureWindowsPath
    assert (normalize_path(PurePosixPath('~/tmp/foo/../bar'))
            ==
            Path('/home/test_user/tmp/bar'))
    assert (normalize_path(PureWindowsPath('~/tmp/foo/../bar'))
            ==
            Path('C:\\Users\\test_user\\tmp\\bar'))



# Generated at 2022-06-21 13:02:24.483113
# Unit test for function normalize_path
def test_normalize_path():
    # Type str
    assert normalize_path('~/tmp/foo/../bar') == \
        Path(os.path.expanduser('~/tmp/foo/../bar'))
    assert normalize_path('/tmp/foo/../bar') == \
        Path(os.path.expanduser('/tmp/foo/../bar'))
    assert normalize_path('foo/../bar') == \
        Path(os.path.expanduser('foo/../bar'))
    assert normalize_path('../foo/../bar') == \
        Path(os.path.expanduser('../foo/../bar'))
    assert normalize_path('../../foo/../bar') == \
        Path(os.path.expanduser('../../foo/../bar'))

# Generated at 2022-06-21 13:02:42.660739
# Unit test for function directory_present
def test_directory_present():
    """Unit test for normalize_path."""
    path = directory_present('/tmp/test_dir_present')
    assert path.as_posix() == '/tmp/test_dir_present'

    path = directory_present('test_dir_present_2')
    assert path.as_posix() == '/tmp/test_dir_present_2'

    path = directory_present('/tmp/test_dir_present/test_dir_present_3')
    assert path.as_posix() == '/tmp/test_dir_present/test_dir_present_3'

    try:
        directory_present('/etc/test_dir_present_4')
    except FileExistsError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 13:02:51.161296
# Unit test for function exists_as
def test_exists_as():

    with TemporaryDirectory() as tmp_dir:
        # Create a directory for testing.
        test_dir = Path(tmp_dir) / 'test_dir'
        test_dir.mkdir()

        assert exists_as(test_dir) == 'directory'

        # Create a file for testing.
        test_file = test_dir / 'test_file.txt'
        test_file.touch()

        assert exists_as(test_file) == 'file'

        (test_dir / 'broken_link').symlink_to('does_not_exist')
        assert exists_as(test_dir / 'broken_link') == ''

        folders = ['folder1', 'folder2', 'folder3']
        for folder in folders:
            (test_dir / folder).mkdir()

        # Create a glob pattern of directories.
       

# Generated at 2022-06-21 13:03:03.234146
# Unit test for function directory_present
def test_directory_present():
    # TODO: Need to determine how to test a few of the error conditions.
    test_dir = Path() / 'tmp' / 'flutils.tests.osutils'
    # TODO: Need to add a test with different modes and user/group (os.chmod)
    assert isinstance(directory_present(test_dir, 0o775), PosixPath)
    assert isinstance(directory_present(test_dir, 0o775), PosixPath)
    test_file = Path() / 'tmp' / 'flutils.tests.osutils' / 'test.txt'
    with open(test_file, 'w') as fp:
        fp.write('Just a test file.')

    with pytest.raises(FileExistsError):
        directory_present(test_file)

    test_dir.rmdir()

# Generated at 2022-06-21 13:03:12.656396
# Unit test for function path_absent
def test_path_absent():
    import os
    import shutil
    import sys
    import tempfile
    import textwrap
    import time

    try:
        import pytest
    except ImportError:
        raise ImportError(
            'Please install pytest: https://pypi.org/project/pytest/'
        )

    from flutils import pathutils

    from . import conftest
    from . import tempdir

    with tempdir.tempdir() as tmpdir:
        t0 = time.time()
        tmpdir.create_file('empty_file', 0, t0)
        empty_file = tmpdir.path() / 'empty_file'
        assert os.path.exists(empty_file)
        assert os.path.isfile(empty_file)
        assert os.path.getsize(empty_file) == 0
        last

# Generated at 2022-06-21 13:03:19.105572
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp') == Path.home().joinpath('tmp')
    assert normalize_path('~/tmp/*') == Path.home().joinpath('tmp/*')
    assert normalize_path('~/tmp/foo/../bar') == \
        Path.home().joinpath('tmp/bar')



# Generated at 2022-06-21 13:03:24.705982
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/foo/../bar')
    assert path == Path(os.path.join(os.getenv('HOME'), 'tmp/bar'))
    path = cast(Path, normalize_path(Path(os.path.dirname(__file__))))
    assert path == Path(os.path.dirname(__file__))



# Generated at 2022-06-21 13:03:32.887741
# Unit test for function normalize_path
def test_normalize_path():
    """Test function flutils.pathutils.normalize_path()

    Test all of the normalize_path() function's edge cases:

    #. bytes path;
    #. PosixPath path;
    #. WindowsPath path;
    #. path with ~ in it;
    #. path with environment variables in it;
    #. non absolute path;
    #. redundant separators;
    #. up-level references.

    """
    # -------------------------------------------------------------------------
    # bytes
    if sys.platform.startswith('win'):
        bpath = ntpath.join(ntpath.abspath(os.getcwd()), 'foo\\..\\bar')
    else:
        bpath = posixpath.join(posixpath.abspath(os.getcwd()), 'foo/../bar')
    bpath

# Generated at 2022-06-21 13:03:43.970178
# Unit test for function get_os_user
def test_get_os_user():
    # pylint: disable=invalid-name
    pwd_foo = pwd.struct_passwd(
        pw_name='foo',
        pw_passwd='********',
        pw_uid=1001,
        pw_gid=2001,
        pw_gecos='Foo Bar',
        pw_dir='/home/foo',
        pw_shell='/usr/local/bin/bash'
    )
    with patch('pwd.getpwnam', autospec=True, return_value=pwd_foo):
        result = get_os_user('foo')
    assert result == pwd_foo
    with pytest.raises(OSError):
        # pylint: disable=no-value-for-parameter
        get_os_user('not_a_user')

# Generated at 2022-06-21 13:03:47.389581
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError):
        get_os_user(9999999999)
    user = get_os_user()
    assert type(user) == pwd.struct_passwd


# Generated at 2022-06-21 13:03:57.645389
# Unit test for function exists_as

# Generated at 2022-06-21 13:04:11.188130
# Unit test for function get_os_group
def test_get_os_group():
    """Function get_os_group unit test.

    This function is called by the doctest test runner.
    """
    from .test_pathutils import (
        get_test_gid,
        get_test_gname,
    )
    group = get_os_group(get_test_gid()).gr_name
    assert group == get_test_gname()



# Generated at 2022-06-21 13:04:14.435704
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')

    chown('~/*', user='foo', group='bar')

    chown('~/tmp/**')



# Generated at 2022-06-21 13:04:16.813345
# Unit test for function chown
def test_chown():
    with path_absent('/tmp/flutils.test1.txt', 'w'):
        chown('/tmp/flutils.test1.txt', user='root', group='root')


# Generated at 2022-06-21 13:04:25.636000
# Unit test for function get_os_group
def test_get_os_group():
    # posix
    if os.name == 'posix':
        assert get_os_group() == grp.struct_group(
            gr_name='users', gr_passwd='*',
            gr_gid=100, gr_mem=['test_user']
        )
        assert get_os_group('users').gr_name == 'users'
        assert get_os_group(100).gr_name == 'users'
    # windows
    elif os.name == 'nt':
        assert get_os_group().gr_name == 'Users'
        assert get_os_group('Users').gr_name == 'Users'



# Generated at 2022-06-21 13:04:37.379188
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path.
    """

    test_path_str = '~/tmp/foo/../bar'
    test_path = normalize_path(test_path_str)
    assert isinstance(test_path, Path)
    assert str(test_path) == os.path.expanduser(test_path_str)
    assert str(test_path) == os.path.normpath(test_path_str)
    assert str(test_path) == os.path.normcase(test_path_str)

    test_path_str = '~/tmp/foo/../bar'
    test_path = normalize_path(test_path_str)
    assert isinstance(test_path, Path)

# Generated at 2022-06-21 13:04:47.675757
# Unit test for function chmod
def test_chmod():
    # try:
    import subprocess
    import stat

    path = normalize_path('~/tmp/flutils.osutils.chmod.txt')

    # Create a file
    with open(path.as_posix(), 'w') as f:
        f.write('{}\n'.format('test_chmod'))

    mode = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP
    chmod(path.as_posix(), mode)
    st_mode = os.stat(path.as_posix()).st_mode & 0o7777
    assert st_mode == mode

    # Clean up
    subprocess.run(['rm', '-f', path.as_posix()])

    # except (ImportError,

# Generated at 2022-06-21 13:04:52.500620
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar',
        gr_passwd='*',
        gr_gid=2001,
        gr_mem=['foo'],
    )



# Generated at 2022-06-21 13:05:06.095079
# Unit test for function chmod
def test_chmod():
    import os
    import pathlib
    import shutil
    import tempfile
    import time
    from pytest import approx, raises

    # Setup
    def create_file_or_dir(
            tmp_path,
            file_or_dir: str,
            relative_path: Optional[str] = None,
            *args,
            **kwargs) -> None:
        if relative_path is not None:
            path = tmp_path.joinpath(relative_path)
            if file_or_dir == 'file':
                path.touch()
            elif file_or_dir == 'directory':
                path.mkdir(parents=True)
        else:
            path = tmp_path
            if file_or_dir == 'file':
                path.touch()

# Generated at 2022-06-21 13:05:12.503202
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.geteuid())
    assert get_os_user(os.geteuid()) == pwd.getpwuid(os.geteuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())

    with pytest.raises(OSError):
        get_os_user('foo')
    with pytest.raises(OSError):
        get_os_user(-1)



# Generated at 2022-06-21 13:05:17.434460
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('/home/test_user/tmp/*')
    assert set(find_paths(pattern)) == {
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one'),
    }

