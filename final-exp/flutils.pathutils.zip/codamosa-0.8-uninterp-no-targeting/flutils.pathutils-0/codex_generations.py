

# Generated at 2022-06-21 12:55:57.506139
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 12:56:08.782995
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')
    assert normalize_path(Path('~/tmp')) == Path('/home/test_user/tmp')
    assert normalize_path(Path('/home/test_user/tmp')) == Path('/home/test_user/tmp')
normalize_path.register(bytes, lambda _: normalize_path(os.fsdecode(_)))
normalize_path.register(PosixPath, lambda _: normalize_path(_.as_posix()))
normalize_path.register(WindowsPath, lambda _: normalize_path(_.as_posix()))


# Generated at 2022-06-21 12:56:11.353547
# Unit test for function directory_present
def test_directory_present():
    # remove exited directories
    os.system("rm -rf ~/tmp/test_path")
    assert test_directory_present() == "PosixPath('/Users/len/tmp/test_path')"






# Generated at 2022-06-21 12:56:13.896901
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError):
        get_os_user('invalid_user_name')

    invalid_uid = get_os_user('root').pw_uid + 1
    with pytest.raises(OSError):
        get_os_user(invalid_uid)

    get_os_user('root')

    get_os_user()



# Generated at 2022-06-21 12:56:14.671838
# Unit test for function get_os_group
def test_get_os_group():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:56:15.242376
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()



# Generated at 2022-06-21 12:56:27.492089
# Unit test for function exists_as
def test_exists_as():
    # 1. Create the directories and files needed for testing.
    from flutils.systemutils import get_temp_directory
    tempd = get_temp_directory()

# Generated at 2022-06-21 12:56:35.219543
# Unit test for function directory_present
def test_directory_present():
    home = str(Path.home())
    base_path = os.path.join(home, 'tmp', 'flutils.tests.osutils')

    if os.path.exists(base_path):
        shutil.rmtree(base_path)

    dir_path = os.path.join(base_path, 'test_directory')
    dir_path2 = os.path.join(base_path, 'test_sub_directory', 'sub_sub_directory')

    try:
        test_path = directory_present(dir_path)
    except FileExistsError:
        raise SystemError(
            'The function: directory_present failed.  It should NOT have '
            'returned a FileExistsError.'
        )
    else:
        assert str(test_path.as_posix()) == dir_path

# Generated at 2022-06-21 12:56:40.224987
# Unit test for function normalize_path
def test_normalize_path():
    test_path = os.path.join(tempfile.gettempdir(), 'tmp/foo/../bar')
    expect_path = '%s/tmp/bar' % tempfile.gettempdir()
    assert str(normalize_path(test_path)) == expect_path
    assert str(normalize_path(Path(test_path))) == expect_path
    assert str(normalize_path(test_path.encode())) == expect_path
# -- end test_normalize_path



# Generated at 2022-06-21 12:56:51.063255
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('wheel').gr_mem == ['root']
    # Should return the same group object.
    assert get_os_group() == get_os_group(
        get_os_user().pw_gid
    )
    # Bad gid.
    with pytest.raises(OSError):
        get_os_group(4294967295)
    # Bad name.
    with pytest.raises(OSError):
        get_os_group('bad_group_name')
    # bad type.
    with pytest.raises(TypeError):
        get_os_group(object())



# Generated at 2022-06-21 12:57:11.885740
# Unit test for function get_os_group
def test_get_os_group():
    # Create a group object for the current user.
    group = get_os_group()

    assert isinstance(group, grp.struct_group)
    assert hasattr(group, 'gr_name')
    assert hasattr(group, 'gr_passwd')
    assert hasattr(group, 'gr_gid')
    assert hasattr(group, 'gr_mem')

# Generated at 2022-06-21 12:57:23.770601
# Unit test for function directory_present
def test_directory_present():
    test_path = '/tmp/directory_present_test'
    returned_path = directory_present(test_path)
    assert returned_path.is_dir()
    assert '/tmp/directory_present_test' == returned_path.as_posix()
    assert returned_path.group() == grp.getgrgid(os.getgid()).gr_name
    assert returned_path.owner() == pwd.getpwuid(os.getuid()).pw_name
    assert returned_path.stat().st_mode & 0o777 == 0o700
    assert returned_path.stat().st_nlink == 1
    test_path_2 = '%s/test_2' % test_path
    returned_path = directory_present(test_path_2)
    assert returned_path.is_dir()

# Generated at 2022-06-21 12:57:32.888872
# Unit test for function directory_present
def test_directory_present():
    tmp_dir = Path('~/tmp').expanduser()
    path = tmp_dir / 'dir_present'

# Generated at 2022-06-21 12:57:43.550895
# Unit test for function exists_as
def test_exists_as():
    with tempfile.TemporaryDirectory() as tmp_d:
        d_path = Path(tmp_d)
        f_path = d_path / 'tmp' / 'flutils.txt'
        f_path.parent.mkdir()
        f_path.touch()
        assert exists_as(d_path) == 'directory'
        assert exists_as(f_path) == 'file'

        b_path = d_path / 'tmp' / 'block_file'
        b_path.parent.mkdir()
        io.open(b_path.as_posix(), 'wb').close()
        assert exists_as(b_path) == 'block device'

        c_path = d_path / 'tmp' / 'char_file'
        c_path.parent.mkdir()

# Generated at 2022-06-21 12:57:51.473675
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir, chmod
    import os
    import shutil
    import sys
    import tempfile


# Generated at 2022-06-21 12:58:01.896134
# Unit test for function get_os_group
def test_get_os_group():
    # Test on a Linux system
    try:
        get_os_group()
    except OSError:
        pass
    else:
        raise AssertionError(
            'The expected OSError exception was NOT raised on a Linux system.'
        )

    # Test on a MacOS system
    try:
        get_os_group()
    except OSError:
        pass
    else:
        raise AssertionError(
            'The expected OSError exception was NOT raised on a MacOS system.'
        )

    # Test on a Windows system
    try:
        get_os_group()
    except OSError:
        pass
    else:
        raise AssertionError(
            'The expected OSError exception was NOT raised on a Windows '
            'system.'
        )




# Generated at 2022-06-21 12:58:09.853555
# Unit test for function find_paths
def test_find_paths():
    # We have a directory with a couple of paths in it.
    tmpdir = Path('tmp')
    for path in ['foo', 'bar']:
        path = tmpdir / Path(path)
        path.touch()

    found_paths = set(find_paths(tmpdir / '*'))
    assert found_paths == {
            tmpdir / 'bar',
            tmpdir / 'foo'
        }

    found_paths = set(find_paths(tmpdir / '**'))
    assert found_paths == {
            tmpdir,
            tmpdir / 'bar',
            tmpdir / 'foo'
        }



# Generated at 2022-06-21 12:58:16.987236
# Unit test for function chmod
def test_chmod():
    import shutil
    from flutils.configutils import get_config
    from flutils.pathutils import get_path
    from tests.pathutils.support import (
        TestChown,
        TestCrud,
        TestExistsAs,
        TestFindPaths,
        TestNormalizePath,
        TestPathAbsent,
        TestPathUtils,
        TestPathUtils,
    )

    config = get_config(
        paths=[
            get_path(__file__, 'configs/test_pathutils.toml')
        ]
    )
    tmp_dir = config.get('test_pathutils', 'test_dir')

    test_obj = TestPathUtils(
        temp_dir=tmp_dir,
    )
    test_obj.setup()

# Generated at 2022-06-21 12:58:27.762192
# Unit test for function exists_as
def test_exists_as():
    from os import symlink, remove
    from tempfile import mkdtemp

    path = Path().cwd().joinpath('pathutils_test.txt')
    symlink_path = Path(mkdtemp()).joinpath('pathutils_test_sym.txt')

    try:
        with path.open('w') as fd:
            fd.write("testing")
        assert exists_as(path) == 'file'
        symlink(path.as_posix(), symlink_path.as_posix())
        assert exists_as(symlink_path) == 'file'
    finally:
        path.unlink()
        try:
            symlink_path.unlink()
        except FileNotFoundError:
            pass

# Generated at 2022-06-21 12:58:33.391973
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists

    path = tempfile.mkdtemp()
    os.mkdir(os.path.join(path, 'subdir'))
    with open(os.path.join(path, 'file'), 'w') as f:
        f.write('file content')


# Generated at 2022-06-21 12:58:56.411591
# Unit test for function get_os_user
def test_get_os_user():
    os_user = get_os_user()
    assert isinstance(os_user.pw_shell, str)
    assert os_user.pw_shell
    assert isinstance(os_user.pw_dir, str)
    assert os_user.pw_dir
    assert isinstance(os_user.pw_gecos, str)
    assert os_user.pw_gecos
    assert isinstance(os_user.pw_gid, int)
    assert os_user.pw_gid
    assert isinstance(os_user.pw_name, str)
    assert os_user.pw_name
    assert isinstance(os_user.pw_passwd, str)
    assert os_user.pw_passwd

# Generated at 2022-06-21 12:59:09.137711
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present"""

    from flutils.pathutils import directory_present, find_paths, remove_paths

    old_wd = os.getcwd()
    test_dir = 'tmp'
    test_path = Path(test_dir) / 'test_directory_present'
    os.chdir(test_dir)


# Generated at 2022-06-21 12:59:16.874862
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown


# Generated at 2022-06-21 12:59:29.029932
# Unit test for function normalize_path
def test_normalize_path():
    # Test case with a bytes type.
    bytes_path = b'/tmp/foo/../bar'
    normalized_bytes_path = normalize_path(bytes_path)
    assert normalized_bytes_path.as_posix() == b'/tmp/bar'

    # Test case with a str type.
    str_path = '/home/test_user/foo/../bar'
    normalized_str_path = normalize_path(str_path)
    assert normalized_str_path.as_posix() == '/home/test_user/bar'

    # Test case with a PosixPath
    posix_path = PosixPath('/home/test_user/foo/../bar')
    normalized_posix_path = normalize_path(posix_path)

# Generated at 2022-06-21 12:59:38.315855
# Unit test for function find_paths
def test_find_paths():
    from os.path import join

    root = normalize_path('~/tmp')
    for file_name in ('file_one', 'file_two'):
        with open(join(root, file_name), 'w') as f:
            f.write('This is a test file.')

    for dir_name in ('dir_one', 'dir_two', 'dir_three'):
        directory_present(join(root, dir_name))

    # Test glob pattern that is an empty string.
    assert list(find_paths(join(root, ''))) == [Path(root)]

    # Test glob pattern that contains an asterisk prefix.

# Generated at 2022-06-21 12:59:50.431857
# Unit test for function chmod
def test_chmod():
    import os
    import pathlib
    from pathlib import Path
    from flutils.pathutils import (
        chmod,
        path_absent,
        directory_present
    )

    # Create test files and directories, for testing
    tmpdir = '~/tmp/flutils.tests.pathutils.chmod'
    directory_present(tmpdir)
    dir1 = Path(tmpdir) / 'dir1'
    dir2 = Path(tmpdir) / 'dir2'
    file1 = Path(tmpdir) / 'file1.txt'
    file2 = Path(tmpdir) / 'file2.txt'
    link1 = Path(tmpdir) / 'link1'
    link2 = Path(tmpdir) / 'link2'

    dir1.mkdir()
    dir2.mkdir()
    file

# Generated at 2022-06-21 12:59:59.463431
# Unit test for function chown
def test_chown():
    import os

    import pytest

    @pytest.fixture
    def tmp_path(tmp_path):
        ret = tmp_path / 'tmp'
        ret.mkdir()
        return ret

    @pytest.fixture
    def filepath(tmp_path):
        ret = tmp_path / 'flutils.tests.osutils.txt'
        with ret.open("w") as fp:
            fp.write("foo")
        return ret

    def test_chown_default(filepath):
        chown(filepath)
        assert os.stat(filepath).st_uid == os.getuid()
        assert os.stat(filepath).st_gid == os.getgid()


# Generated at 2022-06-21 13:00:11.058878
# Unit test for function path_absent
def test_path_absent():
    """Unit tests for the :func:`path_absent` function."""
    testpath = normalize_path('~/tmp')
    path = testpath.joinpath('foo')
    assert exists_as(path) == ''
    assert isinstance(path, Path)
    path_present(path)
    assert exists_as(path) == 'directory'
    assert isinstance(path, Path)
    path = testpath.joinpath('foo/bar')
    assert exists_as(path) == ''
    assert isinstance(path, Path)
    path_present(path)
    assert exists_as(path) == 'directory'
    assert isinstance(path, Path)
    path = testpath.joinpath('foo/file')
    assert exists_as(path) == ''
    assert isinstance(path, Path)
   

# Generated at 2022-06-21 13:00:20.689769
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent()."""

    # Assume the test_path does NOT exist
    test_path = Path('~/tmp/test_path')
    test_path.mkdir(parents=True, exist_ok=True)
    assert os.path.exists(test_path)

    # Just check it, if it exists, it will get deleted.
    path_absent(test_path)
    assert not os.path.exists(test_path)

    # Now test with a file
    file_path = test_path / 'test_file.txt'
    file_path.touch()
    assert os.path.isfile(file_path)
    file_path.unlink()
    assert not os.path.exists(file_path)

    # And with a link
    link_path

# Generated at 2022-06-21 13:00:24.220910
# Unit test for function directory_present
def test_directory_present():
    test_path = '/tmp/flutils_tests.osutils'
    directory_present(test_path)

    test_path = Path(test_path)
    assert test_path.exists() is True
    assert test_path.is_dir() is True

    assert os.stat(test_path.as_posix()).st_mode & 0o777 == 0o700



# Generated at 2022-06-21 13:00:36.627472
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user('root')
    get_os_user(0)
    get_os_user(None)

# Generated at 2022-06-21 13:00:41.116448
# Unit test for function exists_as
def test_exists_as():
    path = '/etc/fstab'
    if isinstance(path, str):
        path = Path(path)
    elif isinstance(path, (bytes, bytearray)):
        path = Path(path.decode())
    return exists_as(path)



# Generated at 2022-06-21 13:00:50.946722
# Unit test for function directory_present
def test_directory_present():
    """
    Test that ``directory_present(...)``
    """
    from flutils.pathutils import directory_present, path_absent
    from flutils.tests.helpers import Callback

    # Define the callback for the unit tests of this function.
    @Callback
    def test_directory_present_callback(host, *args):
        import os

        test_path = host.tmp_path / 'test_directory_present.txt'
        test_dir = host.tmp_path / 'directory_present'

        if args[0] == '001':
            directory_present(test_path, mode=0o770, user='-1', group='-1')

        elif args[0] == '002':
            pass


# Generated at 2022-06-21 13:00:52.602335
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/tmp') == 'directory'

# Generated at 2022-06-21 13:00:57.202827
# Unit test for function exists_as
def test_exists_as():
    """Unit test for module function normalize_path"""
    # Create some test paths
    import tempfile
    file_name = tempfile.mktemp()
    with open(file_name, 'w') as fd:
        fd.write('test')

    dir_name = os.path.join(tempfile.gettempdir(), 'test_dir')
    os.mkdir(dir_name)

    assert exists_as(file_name) == 'file'
    assert exists_as(dir_name) == 'directory'

# Generated at 2022-06-21 13:01:03.150649
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/../foo/../bar'
    new_path = normalize_path(path)
    assert new_path.as_posix() == os.path.join(os.path.expanduser('~'), 'bar')
    path = 'foo/../bar'
    new_path = normalize_path(path)
    assert new_path.as_posix() == os.path.normpath('foo/../bar')



# Generated at 2022-06-21 13:01:13.273265
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    name = get_os_user().pw_name
    assert get_os_user() == get_os_user(name)

    uid = get_os_user().pw_uid
    assert get_os_user(uid) == get_os_user(name)

    assert get_os_user().pw_name == getpass.getuser()

    try:
        get_os_user(1000)
    except OSError as err:
        assert 'uid: 1000' in str(err)

    try:
        get_os_user('12345678910')
    except OSError as err:
        assert 'name: \'12345678910\'' in str(err)



# Generated at 2022-06-21 13:01:24.361332
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from pathlib import Path

    pattern = Path('test_dir/test_subdir/test_subsubdir/test_subsubsubdir/**')

    found_paths = find_paths(pattern)

    expected_paths = ['file1', 'dir1', 'dir2', 'file2', 'file3', 'dir3', 'file4']

    found_paths_itr = iter(found_paths)

    for expected_path in expected_paths:
        found_path = next(found_paths_itr)
        assert found_path.name in expected_paths

    assert 'file5' != next(found_paths_itr).name



# Generated at 2022-06-21 13:01:31.781848
# Unit test for function get_os_group
def test_get_os_group():
    is_posix_os()
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )
    assert get_os_group('baz') == grp.struct_group(
        gr_name='baz', gr_passwd='*', gr_gid=2002, gr_mem=['foo']
    )
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )

# Generated at 2022-06-21 13:01:45.562880
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('foo') == Path('foo')
    assert normalize_path('foo/bar') == Path('foo/bar')

    assert normalize_path('~/foo') == Path(os.path.expanduser('~/foo'))
    assert normalize_path('~/foo/bar') == Path(os.path.expanduser('~/foo/bar'))

    assert normalize_path('$HOME/foo') == Path(
        os.path.expandvars('$HOME/foo')
    )
    assert normalize_path('$HOME/foo/bar') == Path(
        os.path.expandvars('$HOME/foo/bar')
    )

    assert normalize_path('/foo') == Path('/foo')
    assert normalize_path('/foo/bar') == Path

# Generated at 2022-06-21 13:02:04.556564
# Unit test for function normalize_path
def test_normalize_path():
    test_path = '/foo/bar/../baz'
    result_path = posixpath.normpath(test_path)
    path = normalize_path(test_path)
    assert result_path == path.as_posix()

    test_path = '/foo//bar/baz/'
    result_path = posixpath.normpath(test_path)
    path = normalize_path(test_path)
    assert result_path == path.as_posix()

    test_path = '/foo/./bar/../baz'
    result_path = posixpath.normpath(test_path)
    path = normalize_path(test_path)
    assert result_path == path.as_posix()

    # Normalize a relative path
    test_path = 'foo/../bar'
   

# Generated at 2022-06-21 13:02:16.598524
# Unit test for function get_os_user
def test_get_os_user():
    func = get_os_user
    assert isinstance(func(), pwd.struct_passwd)
    assert isinstance(func(name=''), pwd.struct_passwd)
    assert isinstance(func(name=0), pwd.struct_passwd)
    assert func() != func(name='')
    try:
        func(name='does_not_exist')
        assert False
    except OSError as e:
        assert str(e) == (
            'The given name: \'does_not_exist\', is not a valid "login name" '
            'for this operating system.'
        )

# Generated at 2022-06-21 13:02:28.919413
# Unit test for function chown
def test_chown():
    from pathlib import Path
    from subprocess import Popen, PIPE, STDOUT
    p = Path('/tmp/flutils_test_chown/chowned_file')
    p.parent.mkdir(parents=True, exist_ok=True)
    p.touch()
    try:
        chown(p, '-1', group='-1')
        assert True
    except:
        assert False
    try:
        chown(p, '-1', group='foobar')
        assert False
    except:
        assert True
    try:
        chown(p, 'foobar', group='-1')
        assert False
    except:
        assert True
    try:
        chown(p, '-1', group='-1')
        assert True
    except:
        assert False

# Generated at 2022-06-21 13:02:39.679859
# Unit test for function normalize_path
def test_normalize_path():
    import platform
    if platform.system() == 'Windows':
        assert isinstance(
            normalize_path(
                './'
            ),
            WindowsPath
        )
        assert isinstance(
            normalize_path(
                '../'
            ),
            WindowsPath
        )
    else:
        assert isinstance(
            normalize_path(
                './'
            ),
            PosixPath
        )
        assert isinstance(
            normalize_path(
                '../'
            ),
            PosixPath
        )
test_normalize_path()



# Generated at 2022-06-21 13:02:48.531030
# Unit test for function get_os_group
def test_get_os_group():
    # What about the current user's group?
    grp_name = get_os_group().gr_name
    assert get_os_group(grp_name).gr_name == grp_name

    # What about the current user's gid?
    gid = get_os_user().pw_gid
    assert get_os_group(gid).gr_gid == gid

    # What about a bad value?
    gid = 9999999
    try:
        assert get_os_group(gid)
        assert False
    except OSError:
        assert True


# Generated at 2022-06-21 13:02:55.193649
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function."""
    assert normalize_path('') == Path()
    assert normalize_path('.') == Path(os.getcwd())
    assert normalize_path('..') == Path(os.getcwd()).parent
    assert normalize_path('/foo/bar/') == Path('/foo/bar')
    assert normalize_path('~') == Path(os.path.expanduser('~'))
    assert normalize_path('~/foo/bar') == Path(
        os.path.join(os.path.expanduser('~'), 'foo', 'bar')
    )
    assert normalize_path('~/foo/bar/..') == Path(
        os.path.join(os.path.expanduser('~'), 'foo')
    )
   

# Generated at 2022-06-21 13:03:06.643017
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group
    """
    try:
        assert get_os_group() is not None
    except OSError as e:
        if 'is not a valid gid' in e.args[0]:
            # The current user's group was not found, so just skip
            # setting the 'gid' property.
            pass
        else:
            raise
    try:
        assert get_os_group(get_os_user().pw_gid) is not None
    except OSError as e:
        if 'is not a valid gid' in e.args[0]:
            # The current user's group was not found, so just skip
            # setting the 'gid' property.
            pass
        else:
            raise

# Generated at 2022-06-21 13:03:12.068515
# Unit test for function chmod
def test_chmod():
    _test_path = '~/tmp/flutils.tests.osutils.txt'
    with open(normalize_path(_test_path), mode='w') as f:
        f.write('test')
    chmod(_test_path, mode_file=0o660)
    assert os.stat(normalize_path(_test_path)).st_mode & 0o7777 == 0o660
    os.remove(normalize_path(_test_path))



# Generated at 2022-06-21 13:03:14.753198
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    with pytest.raises(OSError):
        assert get_os_group('foo')

# Generated at 2022-06-21 13:03:20.714826
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == (
        [PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one')]
    )

# Generated at 2022-06-21 13:03:44.439724
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/zero') == 'character device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/full') == 'character device'
    assert exists_as('/dev/urandom') == 'character device'
    assert exists_as('/dev/disk0') == 'block device'
    assert exists_as('/dev/disk1') == 'block device'
    assert exists_as('/dev/tty') == 'character device'
    assert exists_as('/dev/ttyUSB0') == 'character device'
    assert exists_as('/dev/ttyACM0') == 'character device'
    assert exists_as('/dev/ttyAPP0') == 'character device'
    assert exists_as('/dev/ttyAMA0') == 'character device'


# Generated at 2022-06-21 13:03:55.271842
# Unit test for function get_os_group
def test_get_os_group():
    """Test the function get_os_group."""
    from flutils._compat import get_real_uid

    current_gid = get_os_group().gr_gid
    real_uid = get_real_uid()
    if real_uid == 0:
        assert get_os_group('0') == get_os_group(0)
        assert get_os_group('root') == get_os_group(0)
    assert get_os_group(current_gid) == get_os_group()
    assert get_os_group(current_gid).gr_gid == get_os_group().gr_gid
    assert get_os_group() == get_os_group(get_os_user().pw_gid)
    assert get_os_group().gr_gid == get_os

# Generated at 2022-06-21 13:04:03.386120
# Unit test for function find_paths
def test_find_paths():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    osutils.rmtree(os.path.join(current_dir, 'tmp'))
    os.mkdir(os.path.join(current_dir, 'tmp'))
    os.mkdir(os.path.join(current_dir, 'tmp', 'dir_one'))
    os.mkdir(os.path.join(current_dir, 'tmp', 'dir_two'))
    with open(os.path.join(current_dir, 'tmp', 'file_one'), 'w') as wfile:
        wfile.write('Test data')

# Generated at 2022-06-21 13:04:04.153965
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-21 13:04:13.869937
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.tests.load_data import load_data
    from flutils.pathutils import get_os_group
    import grp

    try:
        _ = get_os_group()
    except OSError:
        res = False
    else:
        res = True
    assert res is True

    try:
        _ = get_os_group('-1')
    except OSError:
        res = False
    else:
        res = True
    assert res is False

    res = get_os_group(get_os_user().pw_gid)
    assert isinstance(res, grp.struct_group)



# Generated at 2022-06-21 13:04:25.218389
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    if Path(path).exists():
        Path(path).unlink()
    Path(path).touch()
    chmod(path, 0o660)
    assert oct(Path(path).stat().st_mode)[-3:] == '660'
    chmod(path, 0o644)
    assert oct(Path(path).stat().st_mode)[-3:] == '644'
    Path(path).unlink()

    files = ['file1.txt', 'file2.txt', 'file3.txt']
    dirs = ['dir1', 'dir2']
    for file_ in files:
        p = Path('~/tmp/' + file_)
        if p.exists():
            p.unlink()
        p.touch()

# Generated at 2022-06-21 13:04:36.999470
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown, get_os_user
    from flutils.pathutils import directory_present as makedirs
    import os
    import shutil
    import tempfile
    from distutils.version import LooseVersion
    from pathlib import Path

    tmpdir = Path(tempfile.mkdtemp())
    path = tmpdir / 'foo' / 'bar.txt'

    uid = os.getuid()
    try:
        makedirs(path.parent)
    except:
        chown(str(tmpdir), os.getlogin())
        shutil.rmtree(str(tmpdir))
        raise

    chown(str(tmpdir), os.getlogin())


# Generated at 2022-06-21 13:04:47.406447
# Unit test for function chmod
def test_chmod():
    import flutils.pathutils as futils
    import shutil
    import tempfile

    mod_file = 0o660
    mod_dir = 0o770

    # Create a temp directory
    path = tempfile.mkdtemp()

    # Create a file
    file_path = os.path.join(path, 'file1.txt')
    open(file_path, 'a').close()

    # Create a subdir
    subdir_path = os.path.join(path, 'subdir')
    os.mkdir(subdir_path)

    # Create another file in the subdir
    file2_path = os.path.join(subdir_path, 'file2.txt')
    open(file2_path, 'a').close()

    # Make sure file1.txt and file2.txt both start with 0

# Generated at 2022-06-21 13:05:01.622875
# Unit test for function chmod
def test_chmod():
    dirname_path = "/tmp/flutils.tests.osutils/chmod"
    filename_path = os.path.join(dirname_path, "file")

    os.makedirs(dirname_path, 0o770, exist_ok=True)
    open(filename_path, "w").close()

    with chown(dirname_path, user="www-data", group="www-data",
               recursive=True):
        with chown(filename_path, user="www-data", group="www-data"):

            # Test that using the default mode, the user,
            # and the group can read and write the directory
            chmod(dirname_path)

            # Test that using the default mode, the user and
            # the group can read write and execute the file
            chmod(filename_path)

           

# Generated at 2022-06-21 13:05:12.076735
# Unit test for function chown