

# Generated at 2022-06-21 12:55:59.994170
# Unit test for function get_os_group
def test_get_os_group():
    try:
        get_os_group()
    except Exception as e:
        print(e)
    else:
        raise Exception('Test failure')



# Generated at 2022-06-21 12:56:00.610652
# Unit test for function chown
def test_chown():
    assert 1 == 2



# Generated at 2022-06-21 12:56:05.105426
# Unit test for function path_absent
def test_path_absent():
    tmp_dir = '~/tmp'
    tmp_dir = normalize_path(tmp_dir)
    tmp_dir = tmp_dir.as_posix()

    test_dir = normalize_path(tmp_dir + '/test_path_absent')
    test_file = normalize_path(tmp_dir + '/test_path_absent/test_file')

    test_absent = test_file

    make_dir(test_dir)
    make_file(test_file)

    path_absent(test_absent)
    assert not os.path.exists(test_absent)

    test_absent = test_dir
    path_absent(test_absent)
    assert not os.path.exists(test_absent)




# Generated at 2022-06-21 12:56:14.721478
# Unit test for function directory_present
def test_directory_present():
    """Test directory_present()"""
    # pylint: disable=protected-access
    from flutils.pathutils import directory_present

    path = Path.home().joinpath('tmp', 'flutils.tests.osutils', 'test_dir')
    # Just ensure the directory is created.
    created = directory_present(path)
    assert created.exists() is True
    assert created.is_dir() is True
    assert created.owner() == getpass.getuser()

    # Ensure the directory is created with the given mode.
    created = directory_present(path, mode=0o740)
    assert created.exists() is True
    assert created.is_dir() is True
    assert created.stat().st_mode & 0o700 == 0o740
    assert created.owner() == getpass.getuser()

    #

# Generated at 2022-06-21 12:56:20.934606
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        # Create test file and directory to search
        test_file = tmpdir / 'file_one'
        test_file.touch()

        test_dir = tmpdir / 'dir_one'
        test_dir.mkdir()

        # Search for 'test*'
        paths = find_paths(test_dir / 'test*')
        assert set(paths) == set([test_dir, test_file])

# Generated at 2022-06-21 12:56:21.465914
# Unit test for function get_os_user
def test_get_os_user():
    pass
    #assert True



# Generated at 2022-06-21 12:56:21.915318
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-21 12:56:28.331896
# Unit test for function normalize_path
def test_normalize_path():
    if sys.platform.startswith('win'):
        assert normalize_path(r'C:\foo\bar') == Path(r'c:\foo\bar')
        assert normalize_path(r'c:/foo/bar') == Path(r'c:\foo\bar')
        assert normalize_path(r'c:/foo/bar\\') == Path(r'c:\foo\bar')
    else:
        assert normalize_path('/foo/bar') == Path('/foo/bar')



# Generated at 2022-06-21 12:56:31.777381
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('foo/bar') == Path().cwd().joinpath('foo/bar')
    assert normalize_path('/foo/bar') == Path('/foo/bar')
    assert normalize_path('~/foo/bar') == Path('~/foo/bar').expanduser()

# Generated at 2022-06-21 12:56:36.286632
# Unit test for function exists_as
def test_exists_as():
    assert 'directory' == exists_as('/')
    assert 'file' == exists_as('/etc/hosts')
    assert 'block device' == exists_as('/dev/urandom')
    assert 'char device' == exists_as('/dev/null')
    assert 'FIFO' == exists_as('/dev/fd')
    assert 'socket' == exists_as('/var/run/docker.sock')
    assert '' == exists_as('/does_not_exist')



# Generated at 2022-06-21 12:56:54.151335
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()
    assert get_os_user('root')



# Generated at 2022-06-21 12:56:59.617237
# Unit test for function chown
def test_chown():
    test_path = Path(__file__).parent / 'osutils.txt'
    chown(test_path)
    if os.getuid() == 0:
        chown(test_path, user='root')
        chown(test_path, group='root')
        chown(test_path, user='root', group='root')
test_chown()


# Generated at 2022-06-21 12:57:11.886954
# Unit test for function exists_as
def test_exists_as():
    test_path = Path('/tmp/test_exists_as')
    if test_path.exists():
        # Ensure the test path is an empty dir.
        if test_path.is_dir():
            shutil.rmtree(test_path)
        else:
            test_path.unlink()

    assert exists_as(test_path) == ''

    # Create the test path as a dir.
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'

    # Remove the dir.
    test_path.rmdir()
    assert exists_as(test_path) == ''

    # Create the test path as a file.
    test_path.touch()
    assert exists_as(test_path) == 'file'

    # Remove the file.
    test_

# Generated at 2022-06-21 12:57:16.339204
# Unit test for function get_os_group
def test_get_os_group():
    # raise if name is int and can't be resolved
    # raise if name is str and can't be resolved
    # returns named group if name is str
    # returns group for name is None
    # returns group for name is int
    assert True



# Generated at 2022-06-21 12:57:26.756372
# Unit test for function get_os_group
def test_get_os_group():
    """Test the function: get_os_group"""
    from .utils import USER, UID, GID, HOME, GROUP, PWD

    if sys.platform.startswith('linux') or sys.platform.startswith('darwin'):
        assert get_os_group() == GROUP
    elif sys.platform.startswith('win'):
        assert get_os_group().gr_name == 'None'

    assert get_os_group(GID) == GROUP
    assert get_os_group(USER) == GROUP

    os_user = get_os_user()
    assert get_os_group(os_user.pw_gid) == GROUP
    assert get_os_group(os_user.pw_name) == GROUP



# Generated at 2022-06-21 12:57:33.070920
# Unit test for function get_os_group
def test_get_os_group():
    os.environ['USERNAME'] = 'flutils'
    name = 'flutils'
    os.environ['USER'] = 'flutils'
    os.environ['HOME'] = '/home/flutils'
    os.environ['LOGNAME'] = 'flutils'
    group = get_os_group()
    expected_result = grp.struct_group(
        gr_name='flutils', gr_passwd='*', gr_gid=2001, gr_mem=['flutils']
    )
    assert expected_result == group



# Generated at 2022-06-21 12:57:43.761952
# Unit test for function get_os_group
def test_get_os_group():
    # Test "group name"
    assert get_os_group('root') == grp.struct_group(
        gr_name='root', gr_passwd='x', gr_gid=0, gr_mem=['root'])

    # Test gid
    assert get_os_group(0) == grp.struct_group(
        gr_name='root', gr_passwd='x', gr_gid=0, gr_mem=['root'])

    # Test return current users's group
    assert get_os_group() == grp.struct_group(
        gr_name='test_user', gr_passwd='x', gr_gid=2003, gr_mem=['test_user'])

    # Test gid that does not exist
    with pytest.raises(OSError):
        get_os_

# Generated at 2022-06-21 12:57:49.712205
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path"""
    actual = normalize_path('~/tmp/foo/../bar')
    expected = os.path.normcase(os.path.normpath(
        os.path.expanduser(
            os.path.expandvars('~/tmp/foo/../bar')
        )
    ))
    expected = Path(expected)
    assert actual == expected



# Generated at 2022-06-21 12:57:56.414683
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user"""
    import sys
    import unittest
    from unittest.mock import patch
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    class TestGetOSUser(unittest.TestCase):
        """Test get_os_user"""

        def test_no_args(self):
            """Test function with no arguments."""
            with patch('getpass.getuser', return_value='TEST'):
                user = get_os_user()
                self.assertEqual(user.pw_name, 'TEST')

        def test_name_int(self):
            """Test function with name (int)."""
            with self.assertRaises(OSError):
                get_os_user(100)

       

# Generated at 2022-06-21 12:57:59.563919
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function :obj:`~flutils.pathutils.get_os_group`."""
    msg = 'get_os_group should return a grp.struct_group object.'
    group_obj = get_os_group()
    assert isinstance(group_obj, grp.struct_group), msg



# Generated at 2022-06-21 12:59:00.513894
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present
    from flutils.pathutils import touch
    from flutils.pathutils import exists_as
    from flutils.pathutils import is_directory
    from flutils.pathutils import is_existing_path

    directory_present('~/tmp/test_dir')
    touch('~/tmp/test_dir/testfile1')
    touch('~/tmp/test_dir/testfile2')

    # Test is_directory.
    assert is_directory('~/tmp/test_dir/testfile1') == False
    assert is_directory('~/tmp/test_dir/testfile2') == False
    assert is_directory('~/tmp/test_dir') == True

    # Test exists_as.
    assert exists_as('~/tmp/no_exists') == ''


# Generated at 2022-06-21 12:59:12.164457
# Unit test for function get_os_user
def test_get_os_user():
    """Unit tests for function get_os_user.

    Requires the following data to be stored in the temp
    directory of the user running the test:
        .
        ├── test_get_os_user_data
        │   ├── 23
        │   ├── 24
        │   └── 25
        ├── test_get_os_user_data-1
        │   ├── 23
        │   ├── 24
        │   └── 25
        └── test_get_os_user_data-2
            ├── 23
            ├── 24
            └── 25
    """
    temp_dir = Path(tempfile.gettempdir())
    uids = [23, 24, 25]
    gids = [2001, 2002, 2003]

# Generated at 2022-06-21 12:59:14.461215
# Unit test for function chmod
def test_chmod():
    try:
        chmod('/tmp')
    except OSError:
        assert True


# Generated at 2022-06-21 12:59:21.741308
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user(name='test') == pwd.struct_passwd(pw_name='test', pw_passwd='********', pw_uid=1001,
        pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo',
        pw_shell='/usr/local/bin/bash')


# Generated at 2022-06-21 12:59:24.145267
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-21 12:59:25.125530
# Unit test for function chown
def test_chown():
    return 0



# Generated at 2022-06-21 12:59:36.624297
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as."""
    import stat
    import tempfile
    from pathlib import Path

    test_file = Path(tempfile.mkstemp()[1])

    assert exists_as(test_file) == 'file'

    test_file.chmod(0o755)
    test_file.chmod(stat.S_IMODE(test_file.lstat().st_mode))
    assert exists_as(test_file) == 'file'

    test_dir = Path(tempfile.mkdtemp())

    assert exists_as(test_dir) == 'directory'

    test_dir.chmod(0o755)
    test_dir.chmod(stat.S_IMODE(test_dir.lstat().st_mode))
    assert exists_as(test_dir) == 'directory'



# Generated at 2022-06-21 12:59:49.272657
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    assert normalize_path(ROOT_DIR) == ROOT_DIR
    assert normalize_path(TMP_DIR) == TMP_DIR
    assert normalize_path('~/tmp') == TMP_DIR
    assert normalize_path('.') == CWD
    assert normalize_path('./tmp') == TMP_DIR
    assert normalize_path('foo/../tmp') == TMP_DIR
    assert normalize_path('foo//bar') == str(TMP_DIR.joinpath('foo', 'bar'))
    # Assert bytes is converted to str by os.path.expanduser
    assert normalize_path(
        b'~/tmp'
    ) == normalize_path('~/tmp')
    # Assert bytes is converted to str by os

# Generated at 2022-06-21 12:59:57.791893
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from os import chmod
    from stat import S_IRUSR, S_IWUSR, S_IXUSR

    file_mode = S_IRUSR | S_IWUSR
    dir_mode = S_IRUSR | S_IWUSR | S_IXUSR

    with TemporaryDirectory() as tmp:
        # Create a directory and a file
        dir_path = Path(tmp) / 'dir'
        dir_path.mkdir(dir_mode)

        file_path = dir_path / 'file.txt'
        file_path.touch(file_mode)

        assert dir_path.stat().st_mode == dir_mode | S_IFDIR
        assert file_path.stat().st_mode == file_mode | S_IFREG

        # Change the mode

# Generated at 2022-06-21 13:00:05.929485
# Unit test for function chmod
def test_chmod():
    """Test for function chmod.
    """
    import logging
    import shutil
    import tempfile
    from os import (
        mkdir,
        stat,
        symlink,
    )
    from stat import S_IMODE
    from pathlib import (
        Path,
    )

    TEST_DIR = Path(tempfile.mkdtemp())

    TEST_FILE = Path(TEST_DIR, 'test_file.txt')
    with open(TEST_FILE, 'w') as fd:
        fd.write('')

    TEST_DIR_B = Path(TEST_DIR, 'dir_b')
    mkdir(TEST_DIR_B)

    TEST_SYMLINK_TO_FILE = Path(TEST_DIR, 'symlink_to_file.txt')
    TEST_

# Generated at 2022-06-21 13:00:45.773590
# Unit test for function directory_present
def test_directory_present():
    """Test function directory_present.

    """

    test_wd = os.path.join(
        os.path.dirname(__file__),
        'tmp',
        'directory_present'
    )
    if os.path.isdir(test_wd) is False:
        os.makedirs(test_wd, mode=0o700)

    test_dir = os.path.join(test_wd, 'test')
    test_path = os.path.join(test_dir, 'present.txt')
    if os.path.exists(test_dir) is True:
        os.rmdir(test_dir)

    if os.path.exists(test_path) is True:
        os.unlink(test_path)

    from flutils.pathutils import directory_present
    assert directory

# Generated at 2022-06-21 13:00:54.046209
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import (
        directory_present,
        exists_as,
        get_os_user,
        path_absent,
    )

    from .test_utils import (
        random_string,
        random_unicode,
        SystemInfo,
    )

    system_info = SystemInfo()
    if system_info.android:
        # Android OS does not support proper group
        # permissions.
        return

    # Test directory_present works with all supported path types.
    # str
    test_path = random_string()
    test_path = directory_present(test_path)
    assert exists_as(test_path) == 'directory'

    path_absent(test_path)
    # bytes
    test_path = random_string().encode()
    test_path = directory_present

# Generated at 2022-06-21 13:00:55.570190
# Unit test for function find_paths
def test_find_paths():
    with temporary_directory() as tmpdir:
        for path in find_paths(tmpdir):
            assert Path(tmpdir) in path.parents



# Generated at 2022-06-21 13:01:01.588539
# Unit test for function exists_as
def test_exists_as():
    from os import makedirs

    from flutils.py23 import random_string

    tmp_dir = '~/.tmp'
    paths: Dict = {
        'block': '%s/%s' % (tmp_dir, random_string()),
        'char': '%s/%s' % (tmp_dir, random_string()),
        'dir': '%s/%s' % (tmp_dir, random_string()),
        'file': '%s/%s' % (tmp_dir, random_string()),
        'fifo': '%s/%s' % (tmp_dir, random_string()),
        'socket': '%s/%s' % (tmp_dir, random_string()),
    }
    makedirs(paths['dir'], mode=0o700)


# Generated at 2022-06-21 13:01:03.572231
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    pass



# Generated at 2022-06-21 13:01:04.193787
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 13:01:10.482847
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as."""
    from flutils.pathutils import exists_as
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/full') == 'char device'



# Generated at 2022-06-21 13:01:15.483011
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user()
    """
    user = get_os_user()
    assert isinstance(user.pw_gid, int)
    assert isinstance(user.pw_name, str)
    user = get_os_user(getpass.getuser())
    assert isinstance(user.pw_gid, int)
    assert isinstance(user.pw_name, str)



# Generated at 2022-06-21 13:01:20.865422
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(b'~/tmp') == Path('~/tmp')
    assert normalize_path('~/tmp') == Path('~/tmp')



# Generated at 2022-06-21 13:01:29.765114
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group(), grp.struct_group)
    assert get_os_group(1000) == grp.getgrgid(1000)
    assert get_os_group('foobar') == grp.getgrnam('foobar')
    with pytest.raises(OSError) as exc:
        get_os_group(1000000000)  # Probably not a valid gid
    assert str(exc.value) == (
        'The given gid: 1000000000, is not a valid gid for this operating '
        'system.'
    )
    with pytest.raises(OSError) as exc:
        get_os_group('not_a_valid_group_name')

# Generated at 2022-06-21 13:02:44.493799
# Unit test for function get_os_user
def test_get_os_user():
    try:
        with patch.object(pwd, 'getpwnam', Mock(return_value='foo')):
            assert get_os_user('foo') == 'foo'
    except (KeyError, OSError):
        pass
    try:
        with patch.object(pwd, 'getpwuid', Mock(return_value='foo')):
            assert get_os_user(0) == 'foo'
    except (KeyError, OSError):
        pass
    with patch.object(os.getuid, Mock(return_value=1001)):
        mock_pw = Mock(pw_name='foo')
        mock_pw.pw_uid = 1001

# Generated at 2022-06-21 13:02:54.800122
# Unit test for function find_paths
def test_find_paths():
    from flutils.osutils import temp_working_directory
    from flutils.pathutils import find_paths, normalize_path

    file_names = [
        'file_one',
        'file_two',
        'file_three',
    ]

    sub_dir_names = [
        'dir_one',
        'dir_two',
        'dir_three',
    ]

    sub_file_names = [
        'sub_file_one',
        'sub_file_two',
        'sub_file_three',
    ]

    with temp_working_directory() as temp_path:
        test_path = Path().cwd()

        for file_name in file_names:
            Path(test_path, file_name).touch()


# Generated at 2022-06-21 13:03:06.415653
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    from unittest.mock import patch
    import pytest  # type: ignore

    from flutils.pathutils import exists_as

    with patch('flutils.pathutils.normalize_path', return_value=Path('/tmp')):
        with patch('pathlib.Path.is_dir', return_value=True):
            assert exists_as('/tmp') == 'directory'

        with patch('pathlib.Path.is_file', return_value=True):
            assert exists_as('/tmp') == 'file'

        with patch('pathlib.Path.is_block_device', return_value=True):
            assert exists_as('/tmp') == 'block device'


# Generated at 2022-06-21 13:03:08.061172
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/flutils.tests.osutils.d')
    assert path.as_posix().startswith('/Users')



# Generated at 2022-06-21 13:03:13.610209
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    # Mock the current working directory.
    cwd = Path(os.getcwd())
    with mock.patch('os.getcwd', return_value=cwd):
        assert normalize_path('~') == Path.home()
        assert normalize_path('.') == Path(cwd)
        assert normalize_path('/tmp') == Path('/tmp')
        assert normalize_path('~/tmp') == Path.home()/'tmp'
        assert normalize_path('foo/../bar') == Path('bar')
        assert normalize_path('/tmp/../foo/') == Path('/foo')
        assert normalize_path(
            '/tmp/../foo/') == Path('/foo')

# Generated at 2022-06-21 13:03:25.958685
# Unit test for function chmod
def test_chmod():
    import pytest
    from os import (
        chmod,
        chown,
        getuid,
        makedirs,
        stat,
    )
    from os.path import (
        isdir,
        isfile,
        join,
    )
    from pwd import getpwuid
    from tempfile import gettempdir

    from flutils.pathutils import (
        find_paths,
        normalize_path,
    )

    username = getpwuid(getuid()).pw_name
    tmppath = gettempdir()
    testpath = join(
        tmppath, 'flutils.tests.pathutils.%s' % username
    )
    path1 = join(testpath, 'file1')
    path2 = join(testpath, 'file2')
    path

# Generated at 2022-06-21 13:03:34.471757
# Unit test for function chown
def test_chown():
    import flutils
    from flutils.pathutils import directory_present
    from flutils.tests.old_tests.shutils import _get_random_str
    from flutils.tests.old_tests.shutils import get_temp_dir
    from flutils.tests.old_tests.shutils import remove_all

    temp_dir = get_temp_dir('flutils.tests.osutils')
    dir_path = os.path.join(temp_dir, _get_random_str('test_chown'))
    directory_present(dir_path)
    file_path = os.path.join(temp_dir, _get_random_str('test_chown'))
    with open(file_path, 'w') as f:
        f.write('This is a test.')
    chown(dir_path)

# Generated at 2022-06-21 13:03:45.816844
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as"""
    import os
    import pathlib

    path = pathlib.Path('/tmp')
    assert exists_as(path) == 'directory'

    path = pathlib.Path('/tmp/flutils.tests.osutils.txt')
    with open(path, 'w') as f:
        f.write('TEST')
    assert exists_as(path) == 'file'
    os.unlink(path)

    assert exists_as('/dev/null') == 'char device'

    if os.path.exists('/dev/random'):
        assert exists_as('/dev/random') == 'block device'

    path = pathlib.Path('/run/flutils.tests.osutils')
    os.mkfifo(path)
    assert exists_as(path)

# Generated at 2022-06-21 13:03:56.342032
# Unit test for function chmod
def test_chmod():
    import tempfile

    def _assert_mode(_path: Path, _mode: int) -> None:
        assert isinstance(_path, Path)
        assert isinstance(_mode, int)
        assert _path.stat().st_mode & 0o777 == _mode

    with tempfile.TemporaryDirectory() as _tmp:
        _path = Path(_tmp).joinpath('flutils.test.txt')
        _path.touch()

        _assert_mode(_path, 0o600)
        chmod(_path, mode_file=0o660)
        _assert_mode(_path, 0o660)

        _sub_dir = Path(_tmp).joinpath('flutils.test.d')
        _sub_dir.mkdir()

        _assert_mode(_sub_dir, 0o700)

# Generated at 2022-06-21 13:04:02.254624
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory(prefix='temp_') as temp_dir:
        p: Path = Path(temp_dir)
        for n in range(3):
            p.joinpath(f'file_{n}').write_text('test_file_%d' % n)

        assert len(list(find_paths(p))) == 3
        assert len(list(find_paths(p.joinpath('file_*')))) == 3
        assert len(list(find_paths(p.joinpath('file_0')))) == 1

