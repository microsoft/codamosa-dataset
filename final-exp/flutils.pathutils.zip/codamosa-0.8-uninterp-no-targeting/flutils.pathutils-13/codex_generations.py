

# Generated at 2022-06-21 12:56:06.007429
# Unit test for function chown
def test_chown():
    from flutils.tests.pathutils import (
        TEST_DIR_USER,
        TEST_DIR_GROUP
    )

    target = Path(
        os.path.join(TEST_DIR_USER, 'Target')
    )

    # Make sure the directory exists
    target.mkdir(parents=True, exist_ok=True)

    # Test when user and group are not given
    assert target.owner() != getpass.getuser()
    assert target.group() != TEST_DIR_GROUP
    chown(target)
    assert target.owner() == getpass.getuser()
    assert target.group() == TEST_DIR_GROUP

    # Test when user and group are the same as the current
    chown(target, '-1', '-1')
    assert target.owner() == getpass.getuser()

# Generated at 2022-06-21 12:56:09.158792
# Unit test for function chmod
def test_chmod():
    try:
        chmod('~/tmp/temp.txt')
        chmod('~/tmp/temp2.txt')
        chmod('~/tmp/new_dir/**', mode_dir=0o777)
    except:
        raise



# Generated at 2022-06-21 12:56:12.895372
# Unit test for function find_paths
def test_find_paths():
    for path in find_paths(Path.home() / 'tmp' / '*'):
        print(path)
    assert len(list(find_paths(Path.home() / 'tmp' / '*'))) == 2


# Generated at 2022-06-21 12:56:21.757936
# Unit test for function directory_present
def test_directory_present():
    from os import getcwd, remove
    from os.path import exists, join, sep
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from shutil import rmtree

    test_path = Path(mkdtemp(prefix='flutils_test_1_'))
    test_path.mkdir(mode=0o700, parents=True, exist_ok=True)

# Generated at 2022-06-21 12:56:27.739694
# Unit test for function path_absent
def test_path_absent():
    import subprocess
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        file_dir_path : Path = Path('dir_one/file_one')
        dir_path : Path = Path('dir_two')
        link_path : Path = Path('dir_three/file_two')
        base_path : Path = Path('dir_four/file_three')
        base_path.parent.mkdir(parents=True)

        subprocess.run(['touch', base_path.as_posix()], check=True)
        subprocess.run(['ln', '-s', base_path.as_posix(), link_path.as_posix()], check=True)

# Generated at 2022-06-21 12:56:33.160733
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.systemutils import on_posix, on_windows
    from tempfile import mkdtemp
    import shutil
    dir_path = Path(mkdtemp())

    if on_posix():
        dir_path.joinpath('one.txt').touch(mode=0o777)
        dir_path.joinpath('two.txt').touch(mode=0o777)
        dir_path.joinpath('three.txt').touch(mode=0o777)

        dir_path.joinpath('one').mkdir(mode=0o777, parents=True)
        dir_path.joinpath('one').joinpath('one.txt').touch(mode=0o777)


# Generated at 2022-06-21 12:56:36.722537
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert user.pw_name == getpass.getuser()
    assert user.pw_uid == os.getuid()

    assert get_os_user(get_os_user().pw_uid) == get_os_user()
    assert get_os_user(get_os_user().pw_name) == get_os_user()

    with pytest.raises(OSError):
        get_os_user(0)

    with pytest.raises(OSError):
        get_os_user('root')


# Generated at 2022-06-21 12:56:38.212408
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.devnull) == 'character device'



# Generated at 2022-06-21 12:56:41.351834
# Unit test for function chown
def test_chown():
    # Tests chown() with a non-existent path
    assert exists_as('/does/not/exist') == 'absent'
    chown('/does/not/exist')


# Generated at 2022-06-21 12:56:47.411952
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/nonexistent') == ''
    assert exists_as(__file__) == 'file'
    assert exists_as('/dev/null') == 'block device'



# Generated at 2022-06-21 12:57:08.404905
# Unit test for function exists_as
def test_exists_as():
    '''Test function exists_as.'''
    from flutils.pathutils import exists_as

    assert exists_as('/usr/local/share/python') == 'directory'
    assert exists_as('/usr/local/share/python/../python') == 'directory'
    assert exists_as('~/some/nonexistent/path') == ''
    assert exists_as('~/some/nonexistent/path/..') == ''
    assert exists_as('.') == 'directory'
    assert exists_as('..') == 'directory'
    assert exists_as('./..') == 'directory'
    assert exists_as('./../..') == 'directory'
    assert exists_as('./../../..') == 'directory'
    assert exists_as('./../../../..') == 'directory'
   

# Generated at 2022-06-21 12:57:19.211666
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    # Create a temporary test directory
    test_dir_path = Path(tempfile.gettempdir()) / 'test_path_absent'
    test_dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    assert os.path.exists(test_dir_path)

    # Create a test path
    test_path = test_dir_path / 'test_path_absent'
    test_path.touch(mode=0o600, exist_ok=False)
    assert os.path.exists(test_path)

    # Remove the test path
    path_absent(test_path)
    assert not os.path.exists(test_path)
    assert os.path.exists(test_dir_path)

# Generated at 2022-06-21 12:57:29.331769
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    import mock

    # Test the default case.
    test_user = os.environ.get('USER', 'root')
    with mock.patch('getpass.getuser', return_value=test_user):
        user = get_os_user()
        assert user.pw_name == test_user

    # Test an integer uid
    with mock.patch('getpass.getuser', return_value=test_user):
        user = get_os_user(0)
        assert user.pw_uid == 0

    # Test a nonexistant uid
    with pytest.raises(OSError) as err:
        get_os_user(123456789)

# Generated at 2022-06-21 12:57:36.268891
# Unit test for function directory_present
def test_directory_present():
    import os
    import os.path
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        test_path = os.path.join(tmp_dir, 'hello')
        assert directory_present(test_path) == test_path

        test_path = os.path.join(tmp_dir, 'goodbye', 'world')
        assert directory_present(test_path) == test_path

        test_path = os.path.join(
          tmp_dir, 'goodbye', 'world', 'hello'
        )
        assert directory_present(test_path) == test_path

        if 'posix' == os.name:
            test_path = os.path.join(tmp_dir, 'goodbye', 'world')
            uid = os.getuid

# Generated at 2022-06-21 12:57:46.998089
# Unit test for function path_absent
def test_path_absent():
    print('test_path_absent')
    tmp_path = Path('~/tmp').expanduser()
    test_path = tmp_path.joinpath('test_path_absent')
    test_path_absent_a = test_path.joinpath('a')
    test_path_absent_a_file_1 = test_path_absent_a.joinpath('file_1')
    test_path_absent_a_file_2 = test_path_absent_a.joinpath('file_2')
    test_path_absent_a_dir_1 = test_path_absent_a.joinpath('dir_1')

# Generated at 2022-06-21 12:57:48.030875
# Unit test for function chown
def test_chown():
    print("Test chown")
    chown('~/tmp/**', '-1', '-1')


# Generated at 2022-06-21 12:57:55.293464
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function ``find_paths``."""
    from flutils import pathutils as pathutils
    from flutils import osutils as osutils


    @contextmanager
    def make_test_dirs(path: _PATH):
        """Test directory.

        Args:
            path (:obj:`str`, :obj:`bytes` or :obj:`Path <pathlib.Path>`):
                The path to the parent directory that will contain the test
                data.

        Yields:
            :obj:`str`: The path to the parent directory that will contain the
            test data.
        """

        path = pathutils.normalize_path(path)
        osutils.mkdir(path)


# Generated at 2022-06-21 12:58:04.746836
# Unit test for function get_os_group

# Generated at 2022-06-21 12:58:07.692074
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group('bar')
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_mem == ['foo']



# Generated at 2022-06-21 12:58:10.463380
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError):
        get_os_group('foo')
    with pytest.raises(OSError):
        get_os_group(100000)

    assert get_os_group().gr_name == 'test_user'
    assert get_os_group('test_user').gr_name == 'test_user'



# Generated at 2022-06-21 12:58:54.696772
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmpdir:
        file = os.path.join(tmpdir, 'file.txt')
        dir = os.path.join(tmpdir, 'dir')
        dir2 = os.path.join(tmpdir, 'dir2')

        os.mkdir(dir)
        os.mkdir(dir2)
        with open(file, 'w'):
            pass

        chmod(file, mode_file=0o600)
        assert os.path.isfile(file) is True
        assert oct(os.stat(file).st_mode)[-3:] == '600'

        chmod(dir, mode_dir=0o700)
        assert os.path.isdir(dir) is True

# Generated at 2022-06-21 12:59:01.754400
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('root')
    try:
        get_os_group('foo')
    except OSError as error:
        assert error.args[0].startswith(
            'The given name: \'foo\', is not a valid "group'
        )
        assert True
    else:
        assert False
    assert get_os_group(0)
    try:
        get_os_group(990)
    except OSError as error:
        assert error.args[0].startswith('The given gid: 990, is not a valid')
        assert True
    else:
        assert False
    assert get_os_group() is not None



# Generated at 2022-06-21 12:59:03.877586
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert user.pw_gid == user.pw_uid



# Generated at 2022-06-21 12:59:05.827866
# Unit test for function get_os_group
def test_get_os_group():
    '''Test: get_os_group
    '''
    assert get_os_group().gr_gid == os.getgid()
    assert get_os_group('foo').gr_name == 'foo'


# Generated at 2022-06-21 12:59:15.675599
# Unit test for function chown
def test_chown():
    with tempfile.NamedTemporaryFile(delete=False) as tempfh:
        tempfh.write(b'foo')
        tempfh.flush()
        path_str = tempfh.name
    try:
        user = getpass.getuser()
        group = grp.getgrgid(os.getgid())[0]
        subprocess.check_call(['chown', f'{user}.{group}', path_str])
    except Exception as err:
        print(f'Unable to set the chown attributes {err}')
    else:
        uid = pwd.getpwnam(user).pw_uid
        gid = grp.getgrnam(group).gr_gid

# Generated at 2022-06-21 12:59:25.968594
# Unit test for function chown
def test_chown():
    tmp_path = Path('/tmp/flutils.pathutils.test')
    if tmp_path.exists():
        tmp_path.unlink()
    tmp_path.touch()
    assert tmp_path.stat().st_uid != os.getuid()

    t = threading.Thread(target=chown, args=(tmp_path,), kwargs=dict(user='-1'))
    t.start()
    t.join()
    assert tmp_path.stat().st_uid == os.getuid()

    os.remove(tmp_path.as_posix())

# Generated at 2022-06-21 12:59:35.407686
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil

    path = tempfile.mkdtemp()
    p = Path(path)

    path_absent(p)
    assert not p.exists()

    p.mkdir()
    path_absent(p)
    assert not p.exists()

    p.mkdir()
    with p.joinpath('subdir').open('x'):
        pass
    path_absent(p)
    assert not p.exists()

    p.mkdir()
    (p / 'file').touch()
    path_absent(p)
    assert not p.exists()

    shutil.rmtree(path)



# Generated at 2022-06-21 12:59:38.179217
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_uid == get_os_group().gr_gid



# Generated at 2022-06-21 12:59:50.275133
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as(Path('~/tmp')) == 'directory'
    assert exists_as(b'/tmp') == 'directory'
    assert exists_as(Path('/tmp')) == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as(Path('~/tmp/flutils.tests.osutils.txt')) == 'file'
    assert exists_as(b'~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.fifa') == ''
    assert exists_as(Path('~/tmp/flutils.tests.osutils.fifa')) == ''
    assert exists

# Generated at 2022-06-21 12:59:59.288252
# Unit test for function directory_present
def test_directory_present():
    """Unit tests for the function directory_present."""
    from tests.utils import (
        setup,
        teardown,
    )
    setup()

    from tempfile import mkdtemp
    import os
    import shutil
    import stat
    from flutils.pathutils import directory_present
    from flutils.pyutils import get_funcname

    test_path = Path(mkdtemp()).joinpath('test_file')
    result_path = directory_present(test_path)
    assert result_path.is_dir() is True

    assert result_path.as_posix() == test_path.as_posix()
    assert os.stat(test_path.as_posix()).st_mode == 0o40700

    user_path = Path(mkdtemp()).joinpath('test_file')


# Generated at 2022-06-21 13:00:21.566993
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize path with absolute and relative paths."""
    if IS_OS_WINDOWS:
        test_path_1 = 'C:/tmp/foo/../bar'
    else:
        test_path_1 = '/tmp/foo/../bar'
    # noinspection PyTypeChecker
    result_path_1 = normalize_path(test_path_1)
    assert result_path_1.as_posix() == os.path.normpath(test_path_1)
    test_path_2 = 'bar'
    # noinspection PyTypeChecker
    result_path_2 = normalize_path(test_path_2)
    assert result_path_2.as_posix() == os.getcwd() + '/bar'

# Generated at 2022-06-21 13:00:34.454085
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import file_present
    from flutils.pathutils import directory_present
    from flutils.systemutils import temp_directory

    with temp_directory() as directory:

        assert exists_as(directory) == 'directory'
        assert exists_as(directory / 'foo') == ''
        assert exists_as(directory / 'foo' / 'bar') == ''
        assert exists_as(directory / 'foo' / 'bar' / 'file.txt') == ''

        directory_present(directory / 'foo' / 'bar')
        assert exists_as(directory / 'foo') == 'directory'
        assert exists_as(directory / 'foo' / 'bar') == 'directory'


# Generated at 2022-06-21 13:00:35.405989
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-21 13:00:47.073644
# Unit test for function path_absent
def test_path_absent():
    if os.name == 'nt':
        # On Windows, os.chmod seems to have no effect on directories
        return None
    path = Path('~/tmp/test_path')
    path = path.expanduser()
    path = path.as_posix()
    assert os.path.exists(path) is False
    os.makedirs(path, mode=0o700)
    assert os.path.isdir(path) is True
    path2 = Path(path, 'test_file')
    path2 = path2.as_posix()
    assert os.path.exists(path2) is False
    with open(path2, 'w') as fh:
        fh.write('foo')
    assert os.path.isfile(path2) is True

# Generated at 2022-06-21 13:00:51.567253
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory(
            prefix='tmp.flutils.pathutils',
            dir=Path('~/tmp').expanduser()
    ) as dir_:
        done: Set[str] = set()
        fname_base: str = 'flutils.tests.pathutils.find_paths'
        for i in range(1, 4):
            fname_ = fname_base + f'.{i}.txt'
            new_path = Path(dir_) / fname_
            new_path.touch()
            done.add(new_path.name)
        file_paths = list(find_paths(Path(dir_) / '*.txt'))
        for file_path in file_paths:
            done.discard(file_path.name)
        assert not done



# Generated at 2022-06-21 13:00:53.246956
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/test_path_not_exist') == ''



# Generated at 2022-06-21 13:00:59.661213
# Unit test for function exists_as
def test_exists_as():
    # Test file
    path = pathlib.Path('unittests/test_file')
    assert exists_as(path) == 'file'

    path = pathlib.Path('unittests/test_file/')
    assert exists_as(path) == ''

    path = pathlib.Path('unittests/test_file/doesnotexist')
    assert exists_as(path) == ''

    path = pathlib.Path('unittests/test_file/doesnotexist/')
    assert exists_as(path) == ''

    # Test block device
    path = pathlib.Path('/dev/null')
    assert exists_as(path) == 'block device'

    path = pathlib.Path('/dev/null/')
    assert exists_as(path) == ''


# Generated at 2022-06-21 13:01:02.989624
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-21 13:01:13.491566
# Unit test for function directory_present
def test_directory_present():
    # Remove the directory that may have been
    # created in a previous test.
    (Path(__file__).parent / 'test_dir').rmdir()

    path = directory_present(
        Path(__file__).parent / 'test_dir'
    )

    assert path.as_posix() == (Path(__file__).parent / 'test_dir').as_posix()
    assert path.is_dir() is True

    path = directory_present(
        Path(__file__).parent / 'test_dir'
    )

    assert path.as_posix() == (Path(__file__).parent / 'test_dir').as_posix()
    assert path.is_dir() is True

    (Path(__file__).parent / 'test_dir').rmdir()



# Generated at 2022-06-21 13:01:23.450394
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for the flutils.pathutils.get_os_group function."""
    from _flutils import pathutils, osutils

    tester = osutils.Tester(
        get_os_group, (
            (
                 # 1 = use the current user's primary group
                1,
                osutils.check_gid_group,
                (
                    True,  # passed
                    pathutils.get_os_user().pw_name
                )
            ),
        )
    )
    tester.run_tests()
    # Set the tester to None so that we can get the coverage stats
    tester = None



# Generated at 2022-06-21 13:01:35.716261
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-21 13:01:37.072423
# Unit test for function find_paths
def test_find_paths():
    return



# Generated at 2022-06-21 13:01:41.322950
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo'])



# Generated at 2022-06-21 13:01:42.846517
# Unit test for function chmod
def test_chmod():
    """Test for function chmod"""
    return



# Generated at 2022-06-21 13:01:49.450154
# Unit test for function get_os_user
def test_get_os_user():
    if platform.system() == 'Windows':
        assert get_os_user().pw_name == getpass.getuser()
        assert get_os_user(getpass.getuser()).pw_name == getpass.getuser()
    else:
        assert get_os_user().pw_name == getpass.getuser()
        assert get_os_user(getpass.getuser()).pw_name == getpass.getuser()
        assert get_os_user(os.getuid()).pw_uid == os.getuid()
# end def test_get_os_user


# Generated at 2022-06-21 13:02:00.904649
# Unit test for function chmod
def test_chmod():
    """Test the chmod() function."""
    import os

    from flutils.pathutils import chmod

    path = cast(str, os.getenv('HOME'))
    if path is not None:
        path = os.path.join(path, '.flutils.tests.osutils.txt')
    if path is None or os.path.exists(path) is False:
        return

    for mode in (0o600, 0o666):
        chmod(path, mode_file=mode)
        stat = os.stat(path)
        assert stat.st_mode & 0o777 == mode

    for mode in (0o700, 0o777):
        chmod(path, mode_file=mode)
        stat = os.stat(path)
        assert stat.st_mode & 0o777 == mode



# Generated at 2022-06-21 13:02:02.853037
# Unit test for function chown
def test_chown():
    """Test the chown function.

    """
    pass
    # TODO: write unit test



# Generated at 2022-06-21 13:02:15.338188
# Unit test for function get_os_group
def test_get_os_group():
    """Test for function get_os_group"""
    from os.path import expanduser
    import shutil

    os_name = os.name


# Generated at 2022-06-21 13:02:27.974658
# Unit test for function directory_present
def test_directory_present():
    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(mode=0o700, parents=True)
    path.touch(mode=0o600)

    try:
        directory_present(path)
    except FileExistsError as exc:
        assert cast(str, exc.args[0]) == \
            'The path: %r can NOT be created as a directory because it ' \
            'already exists as a file.' % path.as_posix()
    else:
        assert False

    path.unlink()
    assert directory_present(path) == path
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o40700
    assert path.stat().st_

# Generated at 2022-06-21 13:02:35.911862
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path.
    """
    path = '~/tmp/test_path'
    response = normalize_path(path)
    assert (
        str(response) == f'{os.path.expanduser(path)}'
        f'{os.path.normpath(path)}'
        f'{os.path.normcase(path)}'
    )



# Generated at 2022-06-21 13:03:03.768481
# Unit test for function get_os_group
def test_get_os_group():
    pass



# Generated at 2022-06-21 13:03:07.557663
# Unit test for function find_paths
def test_find_paths():
    from pathlib import WindowsPath, PosixPath

    assert list(find_paths(WindowsPath('c:\\tmp\\*'))) == []
    assert (
        list(find_paths(PosixPath('~/tmp/*'))) ==
        [PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one')]
    )



# Generated at 2022-06-21 13:03:14.170119
# Unit test for function path_absent
def test_path_absent():
    out: str = 'tmp/test_path_absent/foo/bar'
    path: Path = Path(out)
    path_absent(path)
    assert path.exists() is False
    path.parent.parent.mkdir()
    path_absent(path)
    assert path.exists() is False
    path.parent.parent.mkdir()
    path.parent.mkdir()
    path_absent(path)
    assert path.exists() is False
    path.parent.mkdir()
    path.touch()
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-21 13:03:22.518782
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from tests import test_osutils
    grp_ = get_os_group(test_osutils.TEST_NAME.decode())

    assert isinstance(grp_, grp.struct_group)
    assert isinstance(grp_.gr_name, str)
    assert grp_.gr_name == test_osutils.TEST_NAME.decode()



# Generated at 2022-06-21 13:03:31.269065
# Unit test for function path_absent
def test_path_absent():
    # Given
    path = Path('/tmp/test_path')
    path_as_str = path.as_posix()
    p_two = path / 'p_two'
    p_two_as_str = p_two.as_posix()

    # Ensure
    if os.path.exists(path_as_str):
        if os.path.islink(path_as_str):
            os.unlink(path_as_str)
        elif os.path.isdir(path_as_str):
            for root, dirs, files in os.walk(
                path_as_str, topdown=False
            ):
                for name in files:
                    p = os.path.join(root, name)

# Generated at 2022-06-21 13:03:36.287067
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group as f
    from .fixtures import groups # noqa pylint: disable=I0011,import-error
    for group in groups:
        assert isinstance(f(group.gr_gid), grp.struct_group)
        for wanted in group.gr_mem:
            assert wanted in f(wanted).gr_mem



# Generated at 2022-06-21 13:03:36.951097
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-21 13:03:40.655086
# Unit test for function normalize_path
def test_normalize_path():
    from flutils import normalize_path
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-21 13:03:51.974749
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group, get_os_user
    from flutils.osutils import get_uid
    assert get_os_group().gr_name == get_os_user().pw_name
    assert get_os_group(get_uid()).gr_name == get_os_user().pw_name
    assert callable(get_os_group().gr_mem)
    assert isinstance(get_os_group().gr_mem, property)
    assert 'foo' in get_os_group('bar').gr_mem
    test_gid = get_os_group('bar').gr_gid
    assert get_os_group(test_gid).gr_name == get_os_group('bar').gr_name
    with pytest.raises(OSError):
        get_os

# Generated at 2022-06-21 13:04:01.202098
# Unit test for function chown
def test_chown():
    from flutils.testutils import UnitTester
    assert_errors = []
    tester = UnitTester(assert_errors)
    tester.run_test(chown, normalize_path('~/tmp'), 'foo', 'bar')
    tester.run_test(chown, '~/tmp', 'foo', 'bar')
    tester.run_test(chown, normalize_path('~/tmp'), 'foo', -1)
    tester.run_test(chown, normalize_path('~/tmp'), 'foo', '-1')
    tester.run_test(chown, normalize_path('~/tmp'), -1, 'bar')
    tester.run_test(chown, normalize_path('~/tmp'), '-1', 'bar')
    tester.run_test

# Generated at 2022-06-21 13:04:43.289054
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    def test_normalize_path(path: _PATH, expected: _PATH) -> None:
        actual = normalize_path(path)
        assert expected == actual, f'Expected: {expected!r}, but got: {actual!r}'

    test_normalize_path('~/tmp', os.path.expanduser('~/tmp'))
    test_normalize_path('~/tmp/../tmp', os.path.expanduser('~/tmp'))

    if sys.version_info >= (3, 6, 0):
        test_normalize_path(PosixPath('~/tmp'), PosixPath(os.path.expanduser('~/tmp')))

# Generated at 2022-06-21 13:04:50.445257
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.osutils import is_posix
    from os import makedirs
    from os.path import isdir, join

    path = str(directory_present('/tmp/test_dir_present/A'))
    assert path == '/tmp/test_dir_present/A'
    assert isdir(path)

    makedirs('/tmp/test_dir_present/B', mode=0o755)
    path = directory_present('/tmp/test_dir_present/B')
    assert isdir(path.as_posix())

    path = str(directory_present(path))
    assert path == str(path)
    assert isdir(path)

# Generated at 2022-06-21 13:05:00.129238
# Unit test for function chown
def test_chown():
    """Unit testing for chown
    """
    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name
    normalize_path = functools.partial(
        cast(_PATH, PosixPath),
        Path(sys.argv[0]).parent,
    )
    path = normalize_path('flutils/__init__.py')
    if path.exists():
        chown(path, user, group)



# Generated at 2022-06-21 13:05:11.103728
# Unit test for function normalize_path
def test_normalize_path():  # pragma: no cover
    wd = os.getcwd()
    os.chdir('/home/test_user')

# Generated at 2022-06-21 13:05:13.920822
# Unit test for function chown
def test_chown():
    try:
        chown('./flutils.tests.pathutils.txt')
    except OSError as e:
        assert False
    finally:
        os.remove('./flutils.tests.pathutils.txt')



# Generated at 2022-06-21 13:05:25.081061
# Unit test for function normalize_path
def test_normalize_path():
    import unittest

    class TestNormalizePath(unittest.TestCase):
        """Unit tests for function normalize_path."""

        # pylint: disable=no-member
        # Method names are functions in unittest. TestCase.
        # pylint: disable=protected-access
        # Test asserts are protected access.

        def setUp(self):
            self.maxDiff = None

            # A dummy function used to test if the function can
            # be used as a single dispatch function.
            @functools.singledispatch
            def _dummy_func(path: PathLike) -> Path:  # pragma: no cover
                return Path(path)

            self._dummy_func = _dummy_func
