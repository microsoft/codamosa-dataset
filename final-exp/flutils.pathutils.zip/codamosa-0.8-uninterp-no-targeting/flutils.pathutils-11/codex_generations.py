

# Generated at 2022-06-21 12:56:04.309643
# Unit test for function find_paths
def test_find_paths():
    # Test case: no paths found
    with tempfile.TemporaryDirectory() as temp_dir:
        with pytest.raises(NotImplementedError):
            list(find_paths(os.path.join(temp_dir, '*')))

        with pytest.raises(NotImplementedError):
            list(find_paths(os.path.join(temp_dir, 'file_*')))

    # Test case: one file found
    with tempfile.TemporaryDirectory() as temp_dir:
        tmp_file = os.path.join(temp_dir, 'file.txt')
        with open(tmp_file, 'w') as handle:
            handle.write('temp_file')

        file_paths = list(find_paths(os.path.join(temp_dir, '*')))

# Generated at 2022-06-21 12:56:04.877349
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-21 12:56:11.725355
# Unit test for function get_os_user
def test_get_os_user():
    import getpass
    import pwd
    import unittest
    class TestGetOSUser(unittest.TestCase):

        def test_no_arguments(self):
            self.assertEqual(
                get_os_user(),
                pwd.getpwnam(getpass.getuser())
            )

        def test_valid_uid(self):
            self.assertEqual(
                get_os_user(0),
                pwd.getpwuid(0)
            )

        def test_invalid_uid(self):
            self.assertRaises(OSError, get_os_user, 999999)

        def test_valid_name(self):
            self.assertEqual(
                get_os_user('ftp'),
                pwd.getpwnam('ftp')
            )

# Generated at 2022-06-21 12:56:23.781979
# Unit test for function get_os_group
def test_get_os_group():
    """Test function get_os_group"""
    # Test if it raises an OSError if a bogus grp is passed
    get_os_group_mock = patch('flutils.pathutils.grp.getgrnam')
    mock_getgrnam = get_os_group_mock.start()
    mock_getgrnam.side_effect = KeyError()
    mock_getgrnam.return_value = None
    with raises(OSError):
        get_os_group('bar')
    get_os_group_mock.stop()

    # Test if it returns a valid grp
    get_os_group_mock = patch('flutils.pathutils.grp.getgrnam')
    mock_getgrnam = get_os_group_mock.start()
    mock_getgrnam.side_

# Generated at 2022-06-21 12:56:27.742029
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'



# Generated at 2022-06-21 12:56:35.391016
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('/tmp/pyflutils/test_path')
    directory_present(test_path)
    assert test_path.is_dir() is True
    test_path.rmdir()
    assert test_path.exists() is False
    try:
        directory_present('/tmp/pyflutils/test*.txt')
    except ValueError:
        assert True
    except:
        assert False
    try:
        directory_present('test_path')
    except ValueError:
        assert True
    except:
        assert False
    test_file = Path('/tmp/pyflutils/test.txt')
    test_file.touch()
    try:
        directory_present('/pyflutils/test.txt')
    except FileExistsError:
        assert True

# Generated at 2022-06-21 12:56:44.972796
# Unit test for function chmod
def test_chmod():
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    tmp_dir = TemporaryDirectory()
    sub_dir = Path(tmp_dir.name, 'sub_dir')
    sub_dir.mkdir()
    sub_dir_file = Path(sub_dir, 'sub_dir_file.txt')

    sub_dir_file.write_text('hello world')


# Generated at 2022-06-21 12:56:47.528681
# Unit test for function path_absent
def test_path_absent():
    test_path = '~/tmp/test_path'
    path_absent(test_path)
    assert not os.path.exists(test_path)
    os.makedirs(test_path)
    path_absent(test_path)
    assert not os.path.exists(test_path)


# Generated at 2022-06-21 12:56:51.662892
# Unit test for function normalize_path
def test_normalize_path():
    path = '/home/test_user/tmp/foo/../bar'
    assert normalize_path(path).as_posix() == path

    path = b'/home/test_user/tmp/foo/../bar'
    assert normalize_path(path).as_posix() == path



# Generated at 2022-06-21 12:57:02.010239
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function.

    .. Note:: This function assumes that the directory given in the
        ``paths_to_create`` list does not exist before running this test.
        If the given directory exists, it will be deleted by the
        :obj:`tearDown <flutils.testutils.TempDirBaseTestCase.tearDown>`
        method in the :obj:`TestCase <unittest.TestCase>`.

    """
    def _create_paths():
        nonlocal paths_to_create
        for path in paths_to_create:
            if path.endswith('_dir'):
                _mkdir(path)
            else:
                _touch(path)

    def _paths_exist():
        nonlocal paths_to_create

# Generated at 2022-06-21 12:57:16.445448
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )



# Generated at 2022-06-21 12:57:27.195368
# Unit test for function chmod
def test_chmod():
    """
    Placeholder for unit test.
    """
    path = Path(os.getcwd()).joinpath('tmp', 'flutils.tests.osutils.txt')
    test_mode = 0o777
    if path.exists():
        path.unlink()
    if path.parent.exists() is False:
        path.parent.mkdir(parents=True)
    with path.open('w') as tmp_file:
        pass
    stat_info = path.stat()
    assert stat_info.st_mode != test_mode
    chmod(path, test_mode, include_parent=True)
    stat_info2 = path.stat()
    assert stat_info2.st_mode == test_mode
    path.chmod(0o600)

# Generated at 2022-06-21 12:57:28.974828
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    assert get_os_user()

# Generated at 2022-06-21 12:57:36.097645
# Unit test for function get_os_user
def test_get_os_user():
    """Test :obj:`~flutils.pathutils.get_os_user`."""
    test_user = get_os_user()
    assert isinstance(test_user, pwd.struct_passwd)
    assert test_user.pw_name == getpass.getuser()

    if 'foo' in test_user.pw_gecos:
        try:
            test_user = get_os_user('foo')
        except OSError:
            pass
        else:
            assert isinstance(test_user, pwd.struct_passwd)
            assert test_user.pw_name == 'foo'

        try:
            test_user = get_os_user(1001)
        except OSError:
            pass

# Generated at 2022-06-21 12:57:42.594654
# Unit test for function normalize_path
def test_normalize_path():
    sys.modules['__main__'].__file__ = '/home/test_user/tmp/foo/bar.py'
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')


normalize_path.register(bytes, normalize_path_bytes)
normalize_path.register(Path, normalize_path_path)
normalize_path.register(str, normalize_path_str)



# Generated at 2022-06-21 12:57:46.994352
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()[0] == 'len'
    assert get_os_user(getpass.getuser())[0] == 'len'
    assert get_os_user('len')[0] == 'len'
    assert get_os_user(1000)[0] == 'len'


# Generated at 2022-06-21 12:57:53.281505
# Unit test for function directory_present
def test_directory_present():
    from tests.conftest import TMPDIR

    path = '%s/foo/bar/baz' % TMPDIR.as_posix()
    path_py = directory_present(path, mode=0o660, user='root', group='wheel')
    assert isinstance(path_py, PosixPath)
    assert path_py.as_posix() == path
    assert path_py.is_file() is False
    assert path_py.is_dir() is True
    assert path_py.exists() is True
    assert path_py.stat().st_mode == 0o770



# Generated at 2022-06-21 12:58:02.980426
# Unit test for function get_os_group
def test_get_os_group():
    from .systemutils import get_test_user

    if get_test_user():
        os_group = get_os_group()
        with pytest.raises(OSError):
            get_os_group('-1')
        os_group_foo = get_os_group('foo')
        os_group_bar = get_os_group('bar')
        assert os_group.gr_name == get_test_user()
        assert os_group_foo.gr_gid == 2000
        assert os_group_bar.gr_gid == 2001
        assert os_group_foo.gr_mem[0] == 'foo'
        assert os_group_bar.gr_mem[0] == 'foo'
    else:
        os_group = get_os_group()

# Generated at 2022-06-21 12:58:12.381635
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    import os
    import os.path
    import tempfile

    tmp_dir = tempfile.gettempdir()
    naming = 'directory_present'

    test_dir_name = '%s/%s.%s' % (tmp_dir, naming, os.getpid())
    test_dir_path = directory_present(test_dir_name)

    assert test_dir_path.as_posix() == test_dir_name
    assert os.path.exists(test_dir_name)

    with pytest.raises(FileExistsError):
        directory_present(test_dir_name, mode=0o777)


# Generated at 2022-06-21 12:58:19.069499
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        (tmp / 'a').touch()
        (tmp / 'b').mkdir()
        (tmp / 'b' / 'c').touch()
        (tmp / 'd').symlink_to(tmp / 'b')
        (tmp / 'b' / 'e').symlink_to(tmp / 'a')
        path_absent(tmp)
        assert tmp.exists() is False



# Generated at 2022-06-21 12:58:41.331856
# Unit test for function exists_as
def test_exists_as():
    """Test the :obj:`flutils.pathutils.exists_as` function."""
    # Create a directory for testing exists_as().
    test_dir = directory_present(
        Path(tempfile.tempdir, 'dir_exists_as_test')
    )

    # Create a file for testing exists_as().
    test_file = Path(test_dir, 'file_exists_as_test')
    with open(test_file.as_posix(), 'w') as tfile:
        tfile.write('testing')

    # Create a symlink for testing exists_as().
    test_symlink = Path(test_dir, 'symlink_exists_as_test')
    os.symlink(test_file.as_posix(), test_symlink.as_posix())

# Generated at 2022-06-21 12:58:54.432640
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        newdir = tmpdir / 'some_dir'

        # Test the creation of a new directory.
        directory_present(newdir)
        assert newdir.exists()
        assert newdir.is_dir()
        newdir.chmod(0o600)
        newdir.chmod(0o700)
        directory_present(newdir)
        assert newdir.exists()
        assert newdir.is_dir()
        newdir.chmod(0o600)
        newdir.chmod(0o700)

        # Test the chown change.
        directory_present(newdir, user='nobody', group='nobody')

# Generated at 2022-06-21 12:58:55.209369
# Unit test for function exists_as
def test_exists_as():
    pass



# Generated at 2022-06-21 12:59:02.987738
# Unit test for function chown
def test_chown():
    import faker
    from faker.providers.python import Provider
    from pathlib import Path

    fake = faker.Faker()
    fake.add_provider(Provider)

    flask_test_path = Path(fake.user_name())
    flask_test_path.mkdir(parents=True)

    chown(flask_test_path, user=fake.user_name(), group=fake.user_name())
    assert flask_test_path.exists



# Generated at 2022-06-21 12:59:14.068807
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from os import chmod as os_chmod
    from os import mkdir, remove
    from os.path import join
    from stat import S_IRUSR, S_IRGRP, S_IROTH, S_IWUSR, S_IWGRP, S_IWOTH
    from tempfile import mkdtemp
    from unittest.mock import patch

    tmp = mkdtemp()
    p = join(tmp, 'testfile.txt')
    with open(p, 'w') as f:
        f.write('foo')

    assert (os.stat(p).st_mode & 0o777) == 0o644
    chmod(p, 0o660)
    assert (os.stat(p).st_mode & 0o777) == 0o660


# Generated at 2022-06-21 12:59:27.260016
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    from flutils.pathutils import chmod
    from tempfile import mkdtemp

    test_dir = Path(mkdtemp(prefix='flutils.tests.osutils.', dir='tmp'))
    test_txt = test_dir / 'flutils.tests.osutils.txt'
    test_txt.touch()

    with test_txt.open('w') as fh:
        fh.write('Hello World')


# Generated at 2022-06-21 12:59:29.056498
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path(__file__)) == 'file'



# Generated at 2022-06-21 12:59:36.866088
# Unit test for function chmod
def test_chmod():
    path = pathlib.Path(tempfile.mkdtemp())
    def cleanup():
        with pathutils.Path(path).rmtree_p():
            pass
    request.addfinalizer(cleanup)

    child1 = pathlib.Path(path).joinpath('child1.txt')
    child2 = pathlib.Path(path).joinpath('child2.txt')
    child3 = pathlib.Path(path).joinpath('child3')

    with open(child1, 'w') as f:
        f.write('some content')
    with open(child2, 'w') as f:
        f.write('some content')
    os.mkdir(child3)

    for c in (child1, child2, child3):
        assert c.is_file() is False
        assert c.is_dir()

# Generated at 2022-06-21 12:59:49.351539
# Unit test for function exists_as
def test_exists_as():
    """Test :obj:`~flutils.pathutils.exists_as`.
    """
    import os
    import tempfile
    import types
    from flutils.miscutils import get_random_string

    tmp_path = tempfile.gettempdir()
    tmp_name = get_random_string(prefix='test_exists_as')
    tmp_file = os.path.join(tmp_path, tmp_name)
    open(tmp_file, 'a').close()
    assert exists_as(tmp_file) == 'file'

    os.mkdir(tmp_file)
    assert exists_as(tmp_file) == 'directory'

    os.remove(tmp_file)
    assert exists_as(tmp_file) == ''

    uid = os.getuid()
    gid = os.getg

# Generated at 2022-06-21 12:59:57.948298
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    td = TemporaryDirectory()

    test_path = '%s/test' % td.name
    test_path_obj = directory_present(test_path)
    assert isinstance(test_path_obj, Path)
    assert test_path_obj.exists() is True
    assert test_path_obj.is_dir() is True

    test_path_abs = Path(test_path).resolve()
    test_path_abs_obj = directory_present(test_path_abs)
    assert isinstance(test_path_abs_obj, Path)
    assert test_path_abs_obj.exists() is True
    assert test_path_abs_obj.is_dir() is True

    test_path = '%s/build/sub/path' % td.name
    test_

# Generated at 2022-06-21 13:00:22.861507
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for the normalize_path function."""
    # Test for str input.
    assert normalize_path('.') == Path.cwd()

    # Test for bytes input.
    assert normalize_path(b'.') == Path.cwd()

    # Test for pathlib input.
    assert normalize_path(Path('.')) == Path.cwd()

    # Test ~ is a home directory.
    assert normalize_path('~') == Path.home()

    # Test ~username is a home directory of username.
    assert normalize_path('~root') == Path('/root')

    # Test environment variables are expanded.
    assert normalize_path('$HOME') == Path.home()

    # Test non absolute paths are absolute.

# Generated at 2022-06-21 13:00:35.439897
# Unit test for function path_absent
def test_path_absent():
    """Simple unit test for function path_absent."""
    def _test_path_absent_file_exists(
            path: _PATH,
    ) -> None:
        """Auxiliary function to test path absent file exists."""
        exists_as(path)
        path_absent(path)
        assert not os.path.exists(path)

    def _test_path_absent_dir_exists(
            path: _PATH,
    ) -> None:
        """Auxiliary function to test path absent directory exists."""
        exists_as(path)
        path_absent(path)
        assert not os.path.exists(path)

    path = Path() / 'tmp' / 'subdir' / 'subsubdir'
    _test_path_absent_dir_exists(path)

# Generated at 2022-06-21 13:00:47.119150
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/python') == ''
    assert exists_as('./flutils/tests.py') == 'file'
    assert exists_as('./flutils/__init__.py') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/stdout') == 'char device'
    assert exists_as('/dev/console') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/proc/self') == 'directory'

# Generated at 2022-06-21 13:00:58.219016
# Unit test for function path_absent
def test_path_absent():
    import stat
    import tempfile

    dir_path = tempfile.mkdtemp()
    dir_path = Path(dir_path)
    file_path = dir_path / "test_file"
    file_path.touch()
    link_path = dir_path / "test_link"
    link_path.symlink_to(file_path)
    dir_path.mkdir(mode=0o700)

    file_path.chmod(stat.S_IREAD)
    dir_path.chmod(stat.S_IREAD)
    link_path.chmod(stat.S_IREAD)

    assert os.path.exists(dir_path.as_posix())
    assert os.path.isfile(file_path.as_posix())

# Generated at 2022-06-21 13:01:10.159038
# Unit test for function chown
def test_chown():
    import stat
    import tempfile
    from shutil import rmtree
    from unittest import TestCase

    from flutils.datastructuresutils import AttrDict, FrozenAttrDict
    import pytest

    class TestChown(TestCase):
        def setUp(self):
            super().setUp()
            # create a temp directory
            self.temp_dir = Path(tempfile.mkdtemp())
            # create a file and dirs inside temp_dir
            Path(self.temp_dir / 'flutils.tests.osutils.txt').touch()
            Path(self.temp_dir / 'foo').mkdir(parents=True, exist_ok=True)
            Path(self.temp_dir / 'bar').mkdir(parents=True, exist_ok=True)
            self.temp_dir = Path

# Generated at 2022-06-21 13:01:18.492468
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        create_paths = [
            os.path.join(tmpdir, 'file_one'),
            os.path.join(tmpdir, 'file_two'),
            os.path.join(tmpdir, 'file_*'),
            os.path.join(tmpdir, 'dir_one'),
            os.path.join(tmpdir, 'dir_two'),
            os.path.join(tmpdir, 'dir_*'),
        ]

        for path in create_paths:
            if '*' in path:
                os.mkdir(path)
            else:
                with open(path, 'w') as file_obj:
                    file_obj.write('Hello World!')


# Generated at 2022-06-21 13:01:19.180344
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-21 13:01:25.025063
# Unit test for function directory_present
def test_directory_present():
    """flutils.pathutils.directory_present"""
    import tempfile
    from flutils.pathutils import directory_present
    tmp_dir = tempfile.gettempdir()
    abs_path = os.path.join(tmp_dir, 'flutils', 'pathutils', 'test')
    directory_present(abs_path)
    assert os.path.isdir(abs_path) is True
    # Cleanup
    os.remove(abs_path)
    os.removedirs(os.path.dirname(abs_path))
    # Verify the error conditions
    # 1. Invalid mode.

# Generated at 2022-06-21 13:01:37.123594
# Unit test for function exists_as
def test_exists_as():
    # Create a temporary file.
    temp_path = Path(tempfile.gettempdir()) / next(tempfile._get_candidate_names())
    with temp_path.open('w') as fp:
        fp.write('Hello World!')
    temp_path.close()

    # Create a temporary directory
    safe_mkdir(temp_path)

    try:
        assert exists_as(temp_path) == 'directory'
        assert exists_as(temp_path.with_suffix('.txt')) == 'file'
    finally:
        try:
            os.remove(temp_path)
        except FileNotFoundError:
            pass
        safe_rmdir(temp_path)


# Generated at 2022-06-21 13:01:48.517981
# Unit test for function chmod
def test_chmod():
    # Arrange
    import tempfile
    import os
    import stat
    import time

    tmp_path = Path(tempfile.mkdtemp())

# Generated at 2022-06-21 13:02:15.979331
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import temp_dir, temp_file

    test_path = Path(temp_dir()) / 'test_exists_as_dir'
    assert exists_as(test_path) == ''

    test_path.mkdir()
    assert exists_as(test_path) == 'directory'

    test_path.rmdir()
    assert exists_as(test_path) == ''

    test_path = Path(temp_file()) / 'test_exists_as_file'
    assert exists_as(test_path) == ''

    with open(test_path.as_posix(), mode='w') as fp:
        fp.write('Testing file')

    assert exists_as(test_path) == 'file'

    os.remove(test_path.as_posix())

# Generated at 2022-06-21 13:02:20.219348
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group"""
    assert get_os_group(1).gr_gid == 1
    assert get_os_group('root').gr_gid == 0
    with pytest.raises(OSError):
        get_os_group('foobarbaz')
    with pytest.raises(OSError):
        get_os_group(500)



# Generated at 2022-06-21 13:02:30.072033
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for the :obj:`~flutils.pathutils.get_os_user` function."""
    import sys
    sys.path.append('.')
    from flutils.pathutils import get_os_user

    user = get_os_user()
    assert user.pw_name == getpass.getuser()

    user = get_os_user(getpass.getuser())
    assert user.pw_name == getpass.getuser()

    user = get_os_user(user.pw_uid)
    assert user.pw_name == getpass.getuser()

    assert get_os_user('-1') == -1
    assert get_os_user(-1) == -1


# Generated at 2022-06-21 13:02:41.871177
# Unit test for function path_absent
def test_path_absent():
    path_name = '~/tmp/test_path'

# Generated at 2022-06-21 13:02:51.255715
# Unit test for function directory_present
def test_directory_present():
    from .osutils import (
        current_user,
        current_group,
    )
    path = normalize_path('~/tmp/flutils.tests.pathutils')
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 33279
    assert path.stat().st_uid == current_user().pw_uid
    assert path.stat().st_gid == current_group().gr_gid

    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 33279
    assert path.stat().st_uid == current_user().pw_uid
    assert path.stat().st_gid == current_

# Generated at 2022-06-21 13:02:51.945891
# Unit test for function chown
def test_chown():
    assert False



# Generated at 2022-06-21 13:03:04.024353
# Unit test for function exists_as
def test_exists_as():
    """Unit tests for exists_as()."""
    from . import _create_temp_directory
    from . import _close_open_fds

    from unittest.mock import patch

    import tempfile

    # Test the exists_as() function for a path that does NOT exist.
    path = _create_temp_directory(suffix='exists_as')
    assert exists_as(path) == ''
    path.rmdir()

    # Test the exists_as() function for a directory.
    path = _create_temp_directory(suffix='exists_as')
    assert exists_as(path) == 'directory'
    path.rmdir()

    # Test the exists_as() function for a file.
    path = tempfile.NamedTemporaryFile(suffix='exists_as')
    assert exists

# Generated at 2022-06-21 13:03:07.494855
# Unit test for function chmod
def test_chmod():
    # The path is missing.
    chmod('/tmp/flutils.tests.osutils.chmod.txt')
    # The path exists.
    chmod('~/flutils.tests.osutils.chmod.txt')
    # The path and glob pattern.
    chmod('~/tmp/**')
    # Test include_parent.
    chmod('~/tmp/*', include_parent=True)



# Generated at 2022-06-21 13:03:13.194782
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path
    from pathlib import PurePath, Path

    path = PurePath('~/tmp/foo/../bar')
    assert normalize_path(path) == Path('/Users/len/tmp/bar')
    path = PurePath('~/tmp/foo/../bar/')
    assert normalize_path(path) == Path('/Users/len/tmp/bar')
    path = PurePath('~/tmp/foo/././bar/')
    assert normalize_path(path) == Path('/Users/len/tmp/foo/bar')
    path = PurePath('~/tmp/foo/../../bar/')
    assert normalize_path(path) == Path('/Users/len/bar')
    path = PurePath('~/tmp/foo/../../../bar/')


# Generated at 2022-06-21 13:03:25.672043
# Unit test for function find_paths
def test_find_paths():
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.pathutils import find_paths
    from flutils.pathutils import rmdirs
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as tmp_file:
        tmp_file.write(b'This is a test file.')
        tmp_dir_path = tmp_file.name
        # Make sure tmp_dir_path is a directory so we
        # can use it to store test files.
        if os.path.isdir(tmp_dir_path) is True:
            pass
        else:
            os.makedirs(tmp_dir_path)


# Generated at 2022-06-21 13:03:51.835200
# Unit test for function exists_as
def test_exists_as():
    path = Path('~/tmp')
    assert exists_as(path) == 'directory'

    path = Path('/dev/null')
    assert exists_as(path) == 'character device'

    path = Path('/dev/zero')
    assert exists_as(path) == 'character device'

    path = Path('/dev/random')
    assert exists_as(path) == 'character device'

    path = Path('/dev/urandom')
    assert exists_as(path) == 'character device'

    path = Path('/proc/self/fd/')
    assert exists_as(path) == 'directory'

    path = Path('~/flutils/test/test_pathutils.py')
    assert exists_as(path) == 'file'


# Generated at 2022-06-21 13:04:01.088241
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function."""
    assert(
        normalize_path(Path('~/tmp/foo/../bar'))
        == Path(os.path.join(Path.home(), 'tmp', 'bar'))
    )
    assert(
        normalize_path(Path(normalize_path('~/tmp/foo/../bar')))
        == Path(os.path.join(Path.home(), 'tmp', 'bar'))
    )
    assert(
        normalize_path('/tmp/foo/../bar')
        == Path(os.path.normpath('/tmp/foo/../bar'))
    )

# Generated at 2022-06-21 13:04:09.062363
# Unit test for function chown
def test_chown():
    from os import access
    from os import getuid, getgid
    from os import lstat
    from os import mkdir
    from os import remove
    from os import R_OK
    from os import W_OK
    from os.path import exists
    from os.path import isdir, isfile
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from flutils.pathutils import chown, normalize_path
    from flutils.userutils import get_os_current_user, get_os_group

    # test edge cases
    with TemporaryDirectory() as tmp:
        tmp_path = normalize_path(tmp)
        single_file_path = tmp_path / 'file_only'
        single_file_path.touch()

        # test include parent

# Generated at 2022-06-21 13:04:12.168248
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )

# Generated at 2022-06-21 13:04:12.785786
# Unit test for function get_os_group
def test_get_os_group():
    pass



# Generated at 2022-06-21 13:04:17.631546
# Unit test for function exists_as
def test_exists_as():
    path = Path(tempfile.gettempdir()).joinpath('flutils.tests.pathutils')
    assert exists_as(path) == ''

    path.mkdir()
    assert exists_as(path) == 'directory'

    path.rmdir()
    assert exists_as(path) == ''

    with path.open('w') as fd:
        fd.write('foo')
    assert exists_as(path) == 'file'



# Generated at 2022-06-21 13:04:21.417730
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group()
    if isinstance(get_os_group().gr_gid, int):
        assert get_os_group(get_os_group().gr_gid)
    assert get_os_group(get_os_group().gr_name)


# Generated at 2022-06-21 13:04:25.062198
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/tmp/tmp_*')) == [Path('/tmp/tmp_file_one'),Path('/tmp/tmp_file_two')]
test_find_paths()



# Generated at 2022-06-21 13:04:27.869076
# Unit test for function chown
def test_chown():
    normalize_path()
    get_os_group()
    get_os_user()
    assert callable(chown)



# Generated at 2022-06-21 13:04:39.280890
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.osutils import get_current_user_name
    from flutils.pathutils import get_os_group
    from flutils.testing.decorators import raises

    # Should return the current user's primary group as a grp.struct_group
    # with a gr_name of 'foo'
    g = get_os_group()
    assert g
    assert isinstance(g, grp.struct_group)
    assert isinstance(g.gr_name, str)
    assert isinstance(g.gr_passwd, str)
    assert isinstance(g.gr_gid, int)
    assert isinstance(g.gr_mem, list)
    assert g.gr_name == 'foo'

    # Should return the current user's primary group as a grp.struct_group
    # with a gr_name

# Generated at 2022-06-21 13:04:59.009498
# Unit test for function get_os_group
def test_get_os_group():
    """ Function to unit test get_os_group """
    assert get_os_group().gr_gid == os.getgid()
    assert get_os_group('root').gr_gid == 0
    assert get_os_group(0).gr_name == 'root'



# Generated at 2022-06-21 13:05:10.400931
# Unit test for function chown
def test_chown():
    from unittest.mock import call, patch
    from tests import *
    import os.path

    if 'HOME' in os.environ:
        home_dir = os.environ['HOME']
    else:
        home_dir = os.path.expandvars('$HOME')

    mock_file_join = os.path.join(home_dir, 'tmp', 'flutils.tests.osutils.txt')

    mock_glob = [os.path.join(home_dir, 'tmp', 'flutils.tests.osutils.txt')]


# Generated at 2022-06-21 13:05:17.457062
# Unit test for function exists_as
def test_exists_as():
    path = os.path.expanduser('~/tmp/flutils.tests.pathutils/exists_as/')
    directory_present(path)

    assert exists_as(path) == 'directory'
    assert exists_as(path + 'test.txt') == ''

    with open(path + 'test.txt', 'w'):
        pass

    assert exists_as(path + 'test.txt') == 'file'
    os.remove(path + 'test.txt')

    try:
        os.symlink(path, path + 'test.txt')
    except PermissionError:
        pass
    else:
        assert exists_as(path + 'test.txt') == 'directory'
        os.remove(path + 'test.txt')



# Generated at 2022-06-21 13:05:27.494885
# Unit test for function chmod
def test_chmod():
    # chmod on a file and check mode
    file_path = Path('~/.flutils.tests.pathutils.txt').expanduser()
    file_path.write_text('')
    chmod(file_path, mode_file=0o660)
    file_path.chmod(0o777)

    # chmod on a directory and check mode
    dir_path = Path('~/.flutils.tests.pathutils.dir').expanduser()
    dir_path.mkdir(parents=True, exist_ok=True)
    chmod(dir_path, mode_dir=0o770)

    # chmod on non-existent path
    chmod(file_path.parent / '.this.does.not.exist')

    # chmod on symlinks