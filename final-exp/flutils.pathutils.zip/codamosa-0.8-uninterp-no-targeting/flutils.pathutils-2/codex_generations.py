

# Generated at 2022-06-21 12:55:56.649016
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as"""
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/README.md') == 'file'



# Generated at 2022-06-21 12:56:00.292434
# Unit test for function normalize_path
def test_normalize_path():
    # Not a total test, but check the coverage
    assert normalize_path(b'/tmp/foo/bar') == Path('/tmp/foo/bar')
    assert normalize_path(Path('/tmp/foo/bar')) == Path('/tmp/foo/bar')



# Generated at 2022-06-21 12:56:08.021270
# Unit test for function chown
def test_chown():
    """Unit test for function chown"""
    path = pathlib.Path(__file__)
    path = path.resolve()
    path = path.parent
    path = path.parent
    path = path.joinpath('tmp')
    path = path.joinpath('test_chown')
    path = path.joinpath('flutils.tests.pathutils.txt')
    path = path.normpath()
    path.touch()
    chown(path, user='nobody', group='nobody')

    pass



# Generated at 2022-06-21 12:56:15.190388
# Unit test for function get_os_group
def test_get_os_group():
    """Test get_os_group(name: _STR_OR_INT_OR_NONE)->grp.struct_group function."""
    from flutils.testing import test_get_os_user
    os_user = test_get_os_user.test_get_os_user()
    os_group = get_os_group(os_user.pw_gid)
    assert (
        os_group.gr_name
        == os_user.pw_name
    ), 'Failed to retrieve os_user.pw_name, {} using get_os_group() function.'.format(os_user.pw_name)



# Generated at 2022-06-21 12:56:23.411999
# Unit test for function chmod
def test_chmod():
    '''Test case for function chmod.'''
    import tempfile

    tmpdir = Path(tempfile.gettempdir())
    testdir = tmpdir / 'flutils_osutils_testdir'
    testdir.mkdir(mode=0o700, parents=True, exist_ok=True)

    testfile = testdir / 'testfile.txt'
    testfile.touch()

    testdir_subdir = testdir / 'subdir'
    testdir_subdir.mkdir(mode=0o700, parents=True, exist_ok=True)

    testfile_subfile = testdir_subdir / 'subfile.txt'
    testfile_subfile.touch()

    chmod(testdir, mode_file=0o600, mode_dir=0o700, include_parent=True)

    # Default

# Generated at 2022-06-21 12:56:28.623079
# Unit test for function path_absent
def test_path_absent():
    import pytest
    from os import getcwd
    from os.path import join, normpath, normcase
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp

    from flutils.pathutils import path_absent

    # Setup a temporary directory for testing.
    tmp = mkdtemp()
    tmp = normpath(normcase(tmp))

    path = join(tmp, 'foo')
    Path(path).mkdir()
    path_absent(path)

    path = join(tmp, 'foo')
    assert Path(path).is_dir() is False

    path = join(tmp, 'bar')
    Path(path).touch()
    path_absent(path)

    path = join(tmp, 'bar')
    assert Path(path).is_file() is False

# Generated at 2022-06-21 12:56:30.983170
# Unit test for function path_absent
def test_path_absent():
    tmp_dir = Path('~/tmp/test_path').expanduser()
    path_present(tmp_dir, contents=[
        ('test_file', 'hello world'),
        ('test_dir', [
            ('test_file', 'hello world'),
        ])
    ])
    path_absent(tmp_dir)
    assert exists_as(tmp_dir) == ''



# Generated at 2022-06-21 12:56:31.653434
# Unit test for function chown
def test_chown():
    assert 1



# Generated at 2022-06-21 12:56:42.209844
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        # from flutils.pathutils import directory_present
        path = Path(tmp_dir) / 'foo' / 'bar' / 'baz'

        directory_present(path)
        assert path.is_dir() is True

        # Nothing should get created if the path already exists.
        directory_present(path)
        assert path.exists() is True

        # The given path already exists as a directory, so this will
        # just try to set the mode.
        directory_present(path, mode=0o750)
        assert path.stat().st_mode == 0o40750



# Generated at 2022-06-21 12:56:54.262396
# Unit test for function find_paths
def test_find_paths():
    # Expect 0 matches
    assert not list(find_paths('/home/test_user/tmp/does_not_exist'))
    # Expect 0 matches
    assert not list(find_paths('/home/test_user/tmp/test_file_*'))
    # Expect 1 match
    assert list(find_paths('/home/test_user/tmp/*')) == [
        Path('/home/test_user/tmp/file_one')
    ]
    # Expect 1 match
    assert list(find_paths('/home/test_user/tmp/**')) == [
        Path('/home/test_user/tmp/file_one')
    ]
    # Expect 1 match

# Generated at 2022-06-21 12:57:15.646956
# Unit test for function chown
def test_chown():
    """
    Unit test for function flutils.pathutils:chmod
    """
    import flutils.pathutils
    import os.path
    import os
    import pwd
    import grp
    import stat
    import tempfile

# Generated at 2022-06-21 12:57:26.294729
# Unit test for function get_os_group
def test_get_os_group():
    """Test the get_os_group() function."""
    from flutils.pathutils import get_os_group
    from flutils.systemutils import get_os_release

    os_release = get_os_release()
    if os_release['id'] == 'centos':
        assert get_os_group('root').gr_name == 'root'
        assert get_os_group().gr_name == 'root'
        assert get_os_group(0).gr_name == 'root'
        assert get_os_group('foo')
    elif os_release['id'] == 'darwin':
        assert get_os_group('wheel').gr_name == 'wheel'
        assert get_os_group().gr_name == 'staff'
        assert get_os_group(0).gr_name == 'wheel'
       

# Generated at 2022-06-21 12:57:28.549466
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user"""
    if os.name == 'nt':
        assert get_os_user(1).pw_name == 'SYSTEM'
    else:
        assert get_os_user(0).pw_name == 'root'



# Generated at 2022-06-21 12:57:35.847116
# Unit test for function directory_present
def test_directory_present():
    try:
        home = str(Path.home())
    except NotImplementedError:
        home = str(Path.cwd())
    path = directory_present(home+'/tmp/flutils.tests.osutils')
    assert path.as_posix() == f"{home}/tmp/flutils.tests.osutils"
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.is_symlink() is False
    assert path.is_file() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path.is_block_device() is False
    assert path.is_char_device() is False
    assert path.is_absolute() is True
    stat = path.stat()


# Generated at 2022-06-21 12:57:46.515039
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import find_paths, touch_path
    from flutils.systemutils import get_os_user

    user = get_os_user('~').pw_name

    with TemporaryDirectory() as dir_path:
        touch_path(dir_path + '/file_one')
        touch_path(dir_path + '/file_two')
        touch_path(dir_path + '/file_three')
        touch_path(dir_path + '/file_four')

        mkdir(dir_path + '/dir_one')
        mkdir(dir_path + '/dir_two')

        touch_path(dir_path + '/dir_one/file_one')
        touch_path(dir_path + '/dir_one/file_two')


# Generated at 2022-06-21 12:57:53.540423
# Unit test for function path_absent
def test_path_absent():
    # Because this function is recursive and uses walk(), it is
    # difficult to test it with a single function.
    # pylint: disable=missing-docstring,too-many-locals
    import tempfile
    from flutils.pathutils import path_absent

    # Do NOT use Path() for the temp directories. We need to
    # test the bytes type and other types.
    temp_1 = tempfile.mkdtemp(dir=os.getcwd())
    temp_2 = tempfile.mkdtemp(dir=temp_1)
    temp_3 = tempfile.mkdtemp(dir=temp_2)
    temp_4 = tempfile.mkdtemp(dir=temp_3)


# Generated at 2022-06-21 12:57:54.831689
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='bar')


# Generated at 2022-06-21 12:57:57.101290
# Unit test for function chown
def test_chown():
    """
    >>> from flutils.pathutils import chown
    >>> chown('/root/foo')
    """



# Generated at 2022-06-21 12:57:58.986372
# Unit test for function path_absent
def test_path_absent():
    path = os.path.join(Path('.').absolute(), 'foo')
    os.mkdir(path)
    path_absent(path)
    assert os.path.exists(path) is False



# Generated at 2022-06-21 12:58:08.727005
# Unit test for function directory_present
def test_directory_present():
    from pathlib import PosixPath, WindowsPath
    from unittest.mock import patch
    from flutils.pathutils import (
        normalize_path,
        directory_present,
        exists_as,
    )

    def __mock_getpwuid(uid):
        from pwd import getpwuid
        from ctypes import byref, sizeof, create_string_buffer, Structure
        from ctypes.util import find_library
        from ctypes.util import find_library


# Generated at 2022-06-21 12:58:25.828446
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for get_os_group."""
    with pytest.raises(OSError, match='group name'):
        get_os_group('dummy')
    assert get_os_group() == grp.getgrgid(os.getgid())
    with pytest.raises(OSError, match='given gid'):
        get_os_group(123456)



# Generated at 2022-06-21 12:58:27.396187
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    get_os_user()


# Generated at 2022-06-21 12:58:30.208817
# Unit test for function get_os_group
def test_get_os_group():
    import pytest

    with pytest.raises(OSError):
        get_os_group('group that does not exist')

    with pytest.raises(OSError):
        get_os_group(999999999999999)

    with pytest.raises(OSError):
        get_os_group(-9999999999)



# Generated at 2022-06-21 12:58:41.333583
# Unit test for function normalize_path
def test_normalize_path():
    from .test import TestCase

    class Test_normalize_path(TestCase):
        def test_expect_string_return(self):
            self.assertIsInstance(normalize_path('/home/tmp'), Path)

        def test_expect_bytes_return(self):
            self.assertIsInstance(
                normalize_path(b'/home/tmp'),
                Path
            )

        def test_expect_path_return(self):
            self.assertIsInstance(
                normalize_path('/home/tmp'.__to_path__()),
                Path
            )

        def test_expect_equivalent_return(self):
            self.assertEqual(
                normalize_path('//home/tmp/..'),
                normalize_path('/home/')
            )


# Generated at 2022-06-21 12:58:54.568559
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        pattern = Path(tmpdir) / '*'
        for item in ['file_one', 'file_two']:
            with open(pattern.parent / item, 'w') as file_obj:
                file_obj.write(item)
        for item in ['dir_one', 'dir_two']:
            os.mkdir(pattern.parent / item)
        actual = list(find_paths(pattern))
        assert len(actual) == 4
        assert isinstance(actual[0], pattern.__class__)
        assert pattern.parent / 'file_one' in actual
        assert pattern.parent / 'file_two' in actual
        assert pattern.parent / 'dir_one' in actual
        assert pattern.parent / 'dir_two' in actual



# Generated at 2022-06-21 12:59:07.664761
# Unit test for function path_absent
def test_path_absent():
    from flutils.tests.pathutils import (
        TEST_DIRECTORY,
        TEST_DIRECTORY_LINK,
        TEST_FILE,
        TEST_FILE_LINK,
        TEST_SOCKET,
        TEST_SYMLINK_LOOP,
    )

    path_absent(TEST_DIRECTORY)
    assert exists_as(TEST_DIRECTORY) == ''
    path_absent(TEST_DIRECTORY_LINK)
    assert exists_as(TEST_DIRECTORY_LINK) == ''
    path_absent(TEST_FILE)
    assert exists_as(TEST_FILE) == ''
    path_absent(TEST_FILE_LINK)
    assert exists_as(TEST_FILE_LINK) == ''

# Generated at 2022-06-21 12:59:08.320809
# Unit test for function path_absent
def test_path_absent():
    return


# Generated at 2022-06-21 12:59:16.596758
# Unit test for function chown
def test_chown():
    test_path = cast(Path, Path(__file__).parent.joinpath('./tmp/current_user.txt'))
    test_path.parent.mkdir(parents=True, exist_ok=True)
    test_path.touch(0o700)
    current_user = getpass.getuser()
    example_user = 'saint'
    example_group = 'www'
    with test_path.open('r+') as f:
        f.write(f'{current_user}')
    # change to another user and try to chown as the other user
    if current_user == 'root':
        with pytest.raises(OSError):
            chown(test_path, user=example_user, group=example_group)

# Generated at 2022-06-21 12:59:19.496684
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user()."""
    user = get_os_user()
    assert user.pw_name == getpass.getuser()



# Generated at 2022-06-21 12:59:28.964902
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = Path(tmpdirname)
        with tempfile.TemporaryDirectory(dir=tmpdirname) as tmpdirsub:
            tmpdirsub = Path(tmpdirsub)
            with tempfile.NamedTemporaryFile() as f:
                f.close()
                tmpfile = Path(f.name)
                tmpfile.rename(tmpdirsub / tmpfile.name)
                paths = find_paths(tmpdirsub)
                assert [tmpdirsub / tmpfile.name] == list(paths)


# Generated at 2022-06-21 12:59:46.875263
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group('foo'), grp.struct_group)
    assert isinstance(get_os_group(1), grp.struct_group)
    with pytest.raises(OSError) as error_msg:
        get_os_group('bar') # type: ignore[attr-defined]
    assert 'is not a valid "group name" for this' in str(error_msg.value)
    with pytest.raises(OSError) as error_msg:
        get_os_group(2001) # type: ignore[attr-defined]
    assert 'is not a valid gid for this' in str(error_msg.value)



# Generated at 2022-06-21 12:59:49.349738
# Unit test for function directory_present
def test_directory_present():
    test_path = directory_present('./tmp/test_path')

    assert test_path.is_dir()

    test_path.rmdir()



# Generated at 2022-06-21 12:59:54.944846
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.pathutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.pathutils.symlink') == ''
    assert exists_as('~/tmp/flutils.tests.pathutils.broken_symlink') == ''
    assert exists_as('~/tmp/flutils.tests.pathutils.txt.not_there') == ''



# Generated at 2022-06-21 13:00:02.578064
# Unit test for function chown
def test_chown():
    os.chdir('/tmp')
    with open('flutils.tests.osutils.txt', 'w') as f:
        f.write('Testing flutils.osutils.chown() function...')
    chown('flutils.tests.osutils.txt')
    try:
        os.stat('flutils.tests.osutils.txt').st_uid
        os.stat('flutils.tests.osutils.txt').st_gid
        os.remove('flutils.tests.osutils.txt')
    except Exception as e:
        print(e)
        os.remove('flutils.tests.osutils.txt')



# Generated at 2022-06-21 13:00:14.020179
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import (
        normalize_path,
    )
    pp: Path
    pp = normalize_path('~/tmp/foo/../bar')
    assert pp.as_posix() == os.path.join(os.path.expanduser('~'), 'tmp/bar')
    # Normalize a path with a relative path.
    pp = normalize_path('foo/../bar')
    assert pp.as_posix() == os.path.join(os.getcwd(), 'bar')
    # Normalize a path with an absolute path.
    pp = normalize_path('/foo/../bar')
    assert pp.as_posix() == '/bar'
    # Normalize a path with an absolute path.
    pp = normalize_path('/foo/bar')

# Generated at 2022-06-21 13:00:23.197832
# Unit test for function chmod
def test_chmod():
    with TempDirectory() as temp_dir:
        p = Path(temp_dir)

        file1_path: Path = p / 'file1.txt'
        file1_path.touch()
        file1_path.chmod(0o600)
        assert file1_path.stat().st_mode & 0o777 == 0o600

        file2_path: Path = p / 'file2.txt'
        file2_path.touch()
        file2_path.chmod(0o600)
        assert file2_path.stat().st_mode & 0o777 == 0o600

        chmod(file2_path, 0o660)
        assert file2_path.stat().st_mode & 0o777 == 0o660

        chmod(file1_path, 0o660)

# Generated at 2022-06-21 13:00:35.774932
# Unit test for function find_paths
def test_find_paths():
    """Test find_paths()."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp:
        root = Path(tmp)
        dir_one = root / 'dir_one'
        dir_one.mkdir()
        file_one = dir_one / 'file_one'
        file_one.touch()

        results = find_paths(str(root.as_posix() + '/**'))

        assert [x.as_posix() for x in results] == [
            str(root.as_posix()),
            str(dir_one.as_posix()),
            str(file_one.as_posix())
        ]


# Generated at 2022-06-21 13:00:40.943880
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as(b'') == ''
    assert exists_as('/dev/null') != ''
    assert exists_as('/etc/hosts') != ''
    assert exists_as(Path('/etc/hosts')) != ''



# Generated at 2022-06-21 13:00:46.711059
# Unit test for function get_os_group
def test_get_os_group():
    test_user = cast(pwd.struct_passwd, get_os_user())
    test_group = cast(grp.struct_group, get_os_group(test_user.pw_name))
    assert test_group.gr_gid == test_user.pw_gid
    assert test_group.gr_name == test_user.pw_name

# Generated at 2022-06-21 13:00:52.613568
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function `get_os_group`.

    Raises:
        AssertionError: if the unit test fails.

    """
    def _check_gid(gid):
        group = get_os_group(name=gid)
        assert group.gr_gid == gid

    def _check_name(name):
        group = get_os_group(name=name)
        assert group.gr_name == name

    _check_gid(-1)
    _check_gid(0)
    _check_gid(6)
    _check_name('root')
    _check_name('bin')
    _check_name('sys')
    _check_name('tty')
    _check_name('disk')



# Generated at 2022-06-21 13:01:23.550578
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-21 13:01:28.122522
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(0) == grp.struct_group(gr_name='root', gr_passwd='x', gr_gid=0, gr_mem=[])
    assert get_os_group('root') == grp.struct_group(gr_name='root', gr_passwd='x', gr_gid=0, gr_mem=[])

# Generated at 2022-06-21 13:01:42.914912
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import TemporaryDirectory, TemporaryFile

    # Test a normalize path
    test_path = Path('~/tmp/unit-tests').expanduser().resolve()

    # Test some error conditions

    # Test error if the given path is not absolute,
    try:
        assert test_directory_present('./tmp/testing')
    except ValueError as err:
        assert str(err) == 'The path: %r must be an absolute path.  A path '\
            'is considered absolute if it has both a root and (if the '\
            'flavour allows) a drive.' % Path('./tmp/testing').resolve()

    # Test error if the path contains a glob pattern.

# Generated at 2022-06-21 13:01:46.552600
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    tmpdir = tempfile.TemporaryDirectory()
    path_absent(tmpdir.name)
    assert not os.path.isdir(tmpdir.name)
    tmpdir.cleanup()



# Generated at 2022-06-21 13:01:59.281170
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from grp import struct_group
    from unittest import mock
    from unittest.mock import MagicMock
    from typing import Type
    import pytest

    # get the current "login name" for this operating system
    current_user_name = getpass.getuser()

    @pytest.fixture()
    def mocked_get_os_user(mocker: mock.MockFixture):
        """A test fixture to mock :obj:`get_os_user`.

        The mock is activated with:
            >>> from flutils.pathutils import get_os_user
            >>> _mocked_get_os_user = mocker.patch('flutils.pathutils.get_os_user')

        """

# Generated at 2022-06-21 13:02:04.440322
# Unit test for function chmod
def test_chmod():
    tmp_dir = '~/tmp/'
    with open(str(Path(tmp_dir+'flutils.tests.osutils.txt')), 'w') as fh:
        print('Can you see this?', file=fh)
    chmod(tmp_dir+'flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-21 13:02:06.692098
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(os.getgid()).gr_name == 'root'



# Generated at 2022-06-21 13:02:14.313237
# Unit test for function path_absent
def test_path_absent():
    # pylint: disable=protected-access
    import os
    import shutil
    import tempfile
    import unittest
    from pathlib import Path
    from unittest import mock

    import pytest

    from flutils.pathutils import path_absent
    from flutils.tests import (
        BaseTestCase,
        threaded_test_case,
    )

    class PathAbsentTestCase(BaseTestCase):
        def setUp(self):
            super().setUp()
            self.tmpdir = tempfile.mkdtemp()
            self.add_to_remove(self.tmpdir)

        def test_path_absent_1(self):
            # GIVEN
            test_path = Path(self.tmpdir).joinpath('test_path_absent')

            # WHEN
            path_abs

# Generated at 2022-06-21 13:02:19.678230
# Unit test for function get_os_group
def test_get_os_group(): # pylint: disable=unused-variable
    """Test the get_os_group() function."""
    from flutils.pathutils import get_os_group
    from flutils.testingutils import temp_dir
    from os.path import basename

    with temp_dir(basename('test_get_os_group')) as tmp_dir:
        group_name = 'my_test_group'
        user_name = 'my_test_user'
        try:
            grp.getgrnam(group_name)
        except KeyError:
            os.environ['HOME'] = tmp_dir
            os.environ['USER'] = user_name
            os.environ['LOGNAME'] = user_name

            return_code = os.system(
                'groupadd %s' % group_name
            )

           

# Generated at 2022-06-21 13:02:26.105004
# Unit test for function find_paths
def test_find_paths():
    paths = [
        '~/tmp/file_one',
        '~/tmp/dir_one',
        '~/tmp/dir_two/dir_three/dir_four',
        '~/tmp/dir_two/dir_three/dir_five',
        '~/tmp/dir_two/dir_three/file_two'
    ]
    for path in paths:
        normalize_path(path).touch()


# Generated at 2022-06-21 13:02:58.405410
# Unit test for function path_absent
def test_path_absent():
    tmp = Path('~/tmp/test_path')
    tmp.mkdir(parents=True, exist_ok=True)
    tmp_file = tmp / 'foo'
    with tmp_file.open('w') as f:
        f.write('hello')
    path_absent(tmp)
    assert not tmp_file.exists()
    assert not tmp.exists()



# Generated at 2022-06-21 13:03:09.058553
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    tmp_dir = str(Path(__file__).parent.joinpath('tmp'))
    os.mkdir(tmp_dir)
    sub_dir = str(Path(__file__).parent.joinpath('tmp/sub_dir'))
    os.mkdir(sub_dir)

    def clean_up():
        for fpath in [sub_dir, tmp_dir]:
            if os.path.exists(fpath):
                if os.path.isdir(fpath) is True:
                    os.rmdir(fpath)
                else:
                    os.unlink(fpath)


# Generated at 2022-06-21 13:03:12.004989
# Unit test for function find_paths
def test_find_paths():
    for path in find_paths('~/tmp/file_one'):
        assert isinstance(path, Path)
        assert path.as_posix() == normalize_path('~/tmp/file_one')



# Generated at 2022-06-21 13:03:18.229475
# Unit test for function get_os_user
def test_get_os_user():
    path = Path('/home/foo/bar')
    path_str = path.as_posix()
    assert path_str == '/home/foo/bar'
    assert isinstance(path.as_posix(), str)
    assert isinstance(path, Path)

    path_str_bytes = path.as_posix().encode('utf-8')
    assert path_str_bytes == path.as_posix().encode('utf-8')
    assert isinstance(path_str_bytes, bytes)

    path_2 = normalize_path(path_str_bytes)
    assert path_2.as_posix() == path_str

    path_3 = normalize_path(path_str)
    assert path_3.as_posix() == path_str


# Generated at 2022-06-21 13:03:20.524199
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    with open('/dsk1/users/jvargo/tmp/testexists_as.txt', 'w') as fh:
        fh.write('test')
    assert exists_as('/dsk1/users/jvargo/tmp/testexists_as.txt') == 'file'



# Generated at 2022-06-21 13:03:28.879783
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as temp_dir_path:
        # Create some content that the find_paths function
        # will return.
        file_one_path = Path(temp_dir_path, 'file_one.txt')
        file_one_path.touch()

        dir_one_path = Path(temp_dir_path, 'dir_one')
        dir_one_path.mkdir()

        file_two_path = Path(dir_one_path, 'file_two.text')
        file_two_path.touch()

        test_path = Path(temp_dir_path, '*')
        assert list(find_paths(test_path)) == [file_one_path, dir_one_path]



# Generated at 2022-06-21 13:03:34.303849
# Unit test for function chmod
def test_chmod():

    fname = ('/tmp/flutils.tests.osutils.txt')
    p = Path(fname)
    p.touch()
    p.chmod(0o600)
    assert stat.S_IMODE(p.stat().st_mode) == 0o600

    p.chmod(0o660)
    assert stat.S_IMODE(p.stat().st_mode) == 0o660

    p.chmod(0o660)
    assert stat.S_IMODE(p.stat().st_mode) == 0o660
    p.unlink()


# Generated at 2022-06-21 13:03:41.925530
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    assert get_os_group() is not None
    assert get_os_group('root').gr_name == 'root'
    try:
        get_os_group('bar')
    except OSError:
        pass
    else:
        raise Exception('Should have raised an OSError.')
    try:
        get_os_group(1999)
    except OSError:
        pass
    else:
        raise Exception('Should have raised an OSError.')



# Generated at 2022-06-21 13:03:53.174416
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert isinstance(user.pw_name, str)
    assert isinstance(user.pw_passwd, str)
    assert isinstance(user.pw_uid, int)
    assert isinstance(user.pw_gid, int)
    assert isinstance(user.pw_gecos, str)
    assert isinstance(user.pw_dir, str)
    assert isinstance(user.pw_shell, str)
    assert hasattr(user, 'pw_class')
    assert hasattr(user, 'pw_change')
    assert hasattr(user, 'pw_expire')
    assert hasattr(user, 'pw_fields')



# Generated at 2022-06-21 13:03:58.634926
# Unit test for function directory_present
def test_directory_present():
    path_string = str(normalize_path('~/tmp/test_path'))
    assert str(directory_present(path_string)) == path_string
    assert directory_present(path_string).exists() is True

    # The path must be absolute.
    try:
        directory_present('tmp/test_path')
    except ValueError:
        pass
    else:
        assert False

    # Path must not have a glob pattern.
    try:
        directory_present('~/tmp/*')
    except ValueError:
        pass
    else:
        assert False

    # The directory must not exist as anything but a directory.

# Generated at 2022-06-21 13:04:32.427250
# Unit test for function get_os_group
def test_get_os_group():
    from grp import getgrnam
    from os import getgid
    from pwd import getpwuid

    from flutils.pathutils import get_os_group

    group = getgrnam(getpwuid(getgid()).pw_name)
    assert group == get_os_group()
    assert group == get_os_group(group.gr_gid)
    assert group == get_os_group(group.gr_name)



# Generated at 2022-06-21 13:04:43.921611
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('C:\\tmp\\foo\\..\\bar') == Path('C:/tmp/bar')
    assert normalize_path('C:/tmp/foo/../bar') == Path('C:/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') == str(Path.home() / 'tmp/bar')
    assert normalize_path('~/../tmp/foo/../bar') == str(Path.home() / '../tmp/bar')
    assert normalize_path(b'c:\\tmp\\foo\\..\\bar') == Path('c:/tmp/bar')
    assert normalize_path(b'/tmp/foo/../bar') == Path('/tmp/bar')



# Generated at 2022-06-21 13:04:57.303307
# Unit test for function exists_as
def test_exists_as():
    from tempfile import NamedTemporaryFile
    from flutils import pathutils
    from flutils.testingutils import temp_chdir, temp_umask
    from flutils.pathutils import exists_as

    with temp_chdir() as tmp_dir:
        with temp_umask(0o022):
            # Directory
            path = Path(tmp_dir).joinpath('dir')
            path.mkdir()
            assert exists_as(path) == 'directory'

            # File
            file = NamedTemporaryFile(dir=tmp_dir)
            file_path = Path(file.name)
            assert exists_as(file_path) == 'file'

            # Block Device
            # All block device files must be on the same directory.
            # So we have to create a symlink on the tmp_dir.

# Generated at 2022-06-21 13:05:04.425785
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from pwd import getpwuid
    from grp import getgrnam
    from os import getuid
    current_uid = getuid()
    current_user = getpwuid(current_uid)
    current_group = getgrnam(current_user.pw_name)
    assert get_os_group(current_uid) == current_group



# Generated at 2022-06-21 13:05:05.160303
# Unit test for function exists_as
def test_exists_as():
    pass



# Generated at 2022-06-21 13:05:08.789669
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/') == 'directory'
    assert exists_as(Path('~/tmp')) == 'directory'
    assert exists_as(Path('~/tmp/')) == 'directory'


# Generated at 2022-06-21 13:05:16.696882
# Unit test for function path_absent
def test_path_absent():
    base_dir = Path(__file__).parent
    tmp_dir: Path = base_dir / 'tmp'
    tmp_dir.mkdir(exist_ok=True)
    orig_cwd: Path = Path.cwd()

# Generated at 2022-06-21 13:05:24.981000
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from pytest import raises

    group = get_os_group('bar')
    assert isinstance(group, grp.struct_group)
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_gid == 2001
    assert group.gr_mem == ['foo']

    with raises(OSError):
        get_os_group('does_not_exist')

    with raises(OSError):
        get_os_group(1)

