

# Generated at 2022-06-21 12:55:54.179275
# Unit test for function chown
def test_chown():
    import unittest
    import os

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.user = getpass.getuser()
            self.group = grp.getgrgid(os.getgid()).gr_name

        def test_chown(self):
            """test_chown: Ensure that chown is working as expected.
            """

            path = '/tmp/flutils.tests.osutils.test_chown'
            if os.path.exists(path):
                os.unlink(path)

            with open(path, 'a') as f:
                f.write('foo\n')

            chown(path)
            self.assertEqual(os.stat(path).st_uid, os.getuid())

# Generated at 2022-06-21 12:55:59.992970
# Unit test for function chmod
def test_chmod():
    from .osutils import create_dir
    create_dir('~/tmp/flutils.tests.osutils.txt')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-21 12:56:07.749330
# Unit test for function chmod
def test_chmod():
    from .osutils import make_file_or_dir
    import os

    with make_file_or_dir(
            '~/tmp/flutils.tests.osutils.txt',
            content='hello world'
    ) as path:
        assert os.stat(path).st_mode & 0o777 == 0o600
        chmod(path, 0o660, 0o660)
        assert os.stat(path).st_mode & 0o777 == 0o660
    os.system('rm -r ~/tmp')



# Generated at 2022-06-21 12:56:11.988086
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/flutils.tests.*')) == [
        PosixPath('/home/test_user/tmp/flutils.tests.py')
    ]



# Generated at 2022-06-21 12:56:12.391255
# Unit test for function get_os_user
def test_get_os_user():
    pass



# Generated at 2022-06-21 12:56:22.092965
# Unit test for function get_os_group
def test_get_os_group():
    assert_is_instance(get_os_group(), grp.struct_group)
    assert_is_instance(get_os_group('root'), grp.struct_group)
    assert_raises_regex(
        OSError,
        r'^The given gid',
        get_os_group,
        9999999999999999999999,
    )
    assert_raises_regex(
        OSError,
        r'^The given name',
        get_os_group,
        'this_group_does_not_exist',
    )



# Generated at 2022-06-21 12:56:23.763517
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

    chmod('~/tmp/', 0o666, 0o777)



# Generated at 2022-06-21 12:56:32.568955
# Unit test for function exists_as
def test_exists_as():
    import os
    import os.path
    import sys
    import tempfile
    import types
    import unittest

    import flutils

    class TestCase(unittest.TestCase):
        temp_paths: List = []

        def create_temp_path(
                self,
                path: str,
                exists: str = 'file',
                raise_on_failure: bool = True
        ) -> Path:
            """Create a temporary file or directory to test with."""
            if isinstance(path, str) is False:
                raise TypeError(
                    'The given path: %r is NOT a string.' % path
                )

            temp_path = os.path.abspath(path)


# Generated at 2022-06-21 12:56:44.371826
# Unit test for function path_absent
def test_path_absent():
    from flutils.testfutils import (
        wrap_testf,
        C_TMPDIR,
        TEST_DIR,
        pytest_wrap_testf,
    )
    from os import makedirs
    from os.path import join

    @wrap_testf
    def test_path_absent_broken_symlink(test_dir):
        paths = []
        for path in (
                '/foo',
                '/bar',
                '/baz',
                '/foo/bar',
                '/foo/baz',
                '/foo/bar/baz',
        ):
            full_path = join(test_dir, path)
            paths.append(full_path)
            os.makedirs(full_path)

# Generated at 2022-06-21 12:56:55.127454
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    import os
    import os.path
    import pytest
    from random import getrandbits
    from string import hexdigits
    from tempfile import gettempdir
    from typing import Tuple

    def _random_hex(size: int = 10) -> str:
        """Generate random hex of given ``size``.

        Args:
            size (:obj:`int`, optional): The size of the random hex to return.
            Defaults to ``10``.

        :rtype: :obj:`str`
        """
        return ''.join(
            [hexdigits[getrandbits(4)] for _ in range(0, size)]
        )


# Generated at 2022-06-21 12:57:41.607245
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    assert chmod('~/tmp/*')


# Generated at 2022-06-21 12:57:46.667301
# Unit test for function normalize_path
def test_normalize_path():
    func_name = sys._getframe().f_code.co_name[5:]
    param1 = '~/tmp/foo/../bar'
    result = normalize_path(param1)
    assert isinstance(
        result,
        pathlib.PurePath
    ), '%s failed with first parameter: %r' % (func_name, param1)



# Generated at 2022-06-21 12:57:47.265468
# Unit test for function chmod
def test_chmod():
    pass


# Generated at 2022-06-21 12:57:51.043681
# Unit test for function chmod
def test_chmod():
    # import flutils.pathutils
    # test_data = ('/tmp', 0o660, None, False)
    # flutils.pathutils._chmod(*test_data)
    # Disabling tests until I can figure out how to
    # test this code with chmod.
    pass



# Generated at 2022-06-21 12:58:01.850865
# Unit test for function get_os_group
def test_get_os_group():
    try:
        grp.getgrnam('foo')
    except KeyError:
        group = grp.struct_group(gr_name='foo', gr_passwd='*', gr_gid=2000,
                                 gr_mem=[])
    else:
        group = grp.struct_group(gr_name='foo', gr_passwd='*', gr_gid=2000,
                                 gr_mem=[])
        grp.struct_group()
    try:
        grp.getgrnam('bar')
    except KeyError:
        group = grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2000,
                                 gr_mem=['foo'])

# Generated at 2022-06-21 12:58:11.980396
# Unit test for function exists_as
def test_exists_as():
    # Setup test case 1
    t1_path = normalize_path('~/tmp')
    t1_path.mkdir(mode=0o700, exist_ok=True)
    
    # Setup test case 2
    t2_path = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    t2_path.write_text('')
    
    # Setup test case 3
    t3_path = normalize_path('~/tmp/flutils.tests.pathutils.lnk')
    t3_path.symlink_to(t2_path, target_is_directory=False)
    
    # Setup test case 4
    if os.name == 'nt':
        raise NotImplementedError('Testing on Windows is not supported.')
    t4_path = normalize

# Generated at 2022-06-21 12:58:21.925515
# Unit test for function normalize_path
def test_normalize_path():
    for path in [
        '~', '~/tmp/foo/../bar', '.',  '~/foo/../bar', '../../foobar',
        _PATH('foo'), _PATH('~/tmp/foo/../bar'), _PATH.home()
    ]:
        p1 = normalize_path(path)
        p2 = normalize_path(str(p1))
        assert p1.as_posix() == p2.as_posix(), (
            'The path: %r is not normalized properly.' % p1.as_posix(),
            'The expected path: %r.' % p2.as_posix()
        )
        for _ in range(4):
            p3 = normalize_path(Path(p1))
            assert p1.as_posix() == p3.as_

# Generated at 2022-06-21 12:58:28.151011
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/foo/../bar'
    path = normalize_path(path)
    assert path == Path.home() / 'tmp' / 'bar'
    path = '.'
    path = normalize_path(path)
    assert path == Path.cwd()
    path = Path.cwd() / 'foo'
    path = normalize_path(path)
    assert path == Path.cwd() / 'foo'
    path = b'tmp/foo/../bar'
    path = normalize_path(path)
    assert path == Path.cwd() / 'tmp' / 'bar'



# Generated at 2022-06-21 12:58:33.492441
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path), 'file'

    path = path.parent
    assert exists_as(path), 'directory'



# Generated at 2022-06-21 12:58:45.026911
# Unit test for function directory_present
def test_directory_present():
    from .pathutils import directory_present
    import os
    import tempfile
    tmp_dir = tempfile.gettempdir()
    other_dir = tempfile.gettempdir().replace(os.sep, '.')
    p1 = directory_present(Path(tmp_dir) / 'test_directory_present')
    assert p1.as_posix() == tmp_dir + '/test_directory_present'
    assert p1.exists() == True
    assert p1.is_dir() == True
    p2 = directory_present(os.path.join(tmp_dir, 'test_directory_present2'))
    assert p2.as_posix() == tmp_dir + '/test_directory_present2'
    assert p2.exists() == True
    assert p2.is_dir() == True


# Generated at 2022-06-21 12:59:05.003258
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar').as_posix() == \
        os.path.expanduser('~/tmp/bar')
    assert normalize_path('.//tmp///file.txt').as_posix() == \
        os.path.normpath('/'+os.getcwd()+'/tmp/file.txt')
    assert normalize_path(b'/tmp/file.txt').as_posix() == \
        os.path.normpath('/tmp/file.txt')

# Generated at 2022-06-21 12:59:05.677126
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-21 12:59:07.831130
# Unit test for function get_os_group
def test_get_os_group():
    try:
        gid = grp.getgrnam('bar').gr_gid
        group = get_os_group('bar')
        assert type(group) == grp.struct_group
        assert group.gr_gid == gid
    except KeyError:
        pass



# Generated at 2022-06-21 12:59:18.279434
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    from os import getegid
    from flutils.tests.pathutils.conftest import get_paths
    assert get_os_group().gr_gid == getegid()
    assert cast(str, get_os_group().gr_name) == get_paths()['group_name']
    assert cast(int, get_os_group(get_paths()['group_id']).gr_gid) == get_paths()['group_id']
    assert cast(str, get_os_group(get_paths()['group_name']).gr_name) == get_paths()['group_name']



# Generated at 2022-06-21 12:59:24.193773
# Unit test for function chmod
def test_chmod():
    path = Path('tmp/flutils.tests.osutils.txt')
    chmod(path)
    path.chmod(0o600)
    assert path.stat().st_mode & 0o777 == 0o600
    path.unlink()
    path.parent.rmdir()

# Generated at 2022-06-21 12:59:33.376408
# Unit test for function normalize_path
def test_normalize_path():
    normalize_path('~/tmp/foo/../bar').as_posix() == os.path.expanduser('~/tmp/bar')
    normalize_path(Path('~/tmp/foo/../bar')).as_posix() == os.path.expanduser('~/tmp/bar')
    normalize_path('~/tmp/bar.txt').as_posix() == os.path.expanduser('~/tmp/bar.txt')
    normalize_path(Path('~/tmp/bar.txt')).as_posix() == os.path.expanduser('~/tmp/bar.txt')

normalize_path.register(bytes, normalize_path)
normalize_path.register(PosixPath, lambda path: Path(path.as_posix()))
normalize_path.register

# Generated at 2022-06-21 12:59:39.156920
# Unit test for function chmod
def test_chmod():
    import os
    import os.path as op

    if op.exists('test_chmod.txt') is True:
        os.remove('test_chmod.txt')

    with open('test_chmod.txt', 'wt') as fp:
        fp.write('This is a test')

    chmod('test_chmod.txt', 0o770)
    assert op.exists('test_chmod.txt') is True
    assert chmod('test_chmod.txt') == 0o770

    os.remove('test_chmod.txt')



# Generated at 2022-06-21 12:59:44.404351
# Unit test for function exists_as
def test_exists_as():
    directory = Path(__file__).parent
    assert exists_as(directory) == 'directory'
    assert exists_as(directory / Path('fake.txt')) == ''
    assert exists_as(directory / Path('mock_flutils.py')) == 'file'



# Generated at 2022-06-21 12:59:45.596533
# Unit test for function chown
def test_chown():
    assert False



# Generated at 2022-06-21 12:59:50.729219
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.testing import run_as_main
    from . import osutils
    from .osutils import get_os_user
    from .osutils import get_os_group

    @run_as_main
    def main():
        print(get_os_group())
        print(get_os_group(osutils.get_os_user().pw_gid))
        print(get_os_group('test_group'))
    main()
get_os_group.__test__ = False  # type: ignore



# Generated at 2022-06-21 13:01:03.043270
# Unit test for function exists_as
def test_exists_as():
    path = '~/tmp'
    result = exists_as(path)
    assert result == 'directory'

    # Test a symlink to a reg file
    path = '~/tmp/flutils.tests.osutils.txt'
    result = exists_as(path)
    assert result == 'file'

    # Test a symlink to a directory
    path = '~/tmp/flutils.tests.osutils'
    result = exists_as(path)
    assert result == 'directory'

    # Test a broken symlink
    path = '~/tmp/brokenlink'
    result = exists_as(path)
    assert result == ''

    # Test a broken path
    path = '~/foobar'
    result = exists_as(path)
    assert result == ''


# Generated at 2022-06-21 13:01:13.534705
# Unit test for function chown
def test_chown():
    from os import (
        stat_result,
        ustat,
    )

    def stat(fname):
        return stat_result((
            33204,
            5,
            ustat(0, 0),
            12,
            20,
            40960,
            1593293224,
            1593293204,
            1593293204,
        ))

    m = Mock(spec=os)
    m.chown.return_value = None
    m.stat.side_effect = stat
    m.pw_uid = 20
    m.gr_gid = 20
    m.getuid.return_value = 10
    m.getgid.return_value = 10
    m.isfile.return_value = True


# Generated at 2022-06-21 13:01:25.471618
# Unit test for function exists_as
def test_exists_as():
    try:
        _ = exists_as('/tmp/does_not_exist')
        assert False
    except FileNotFoundError:
        assert True

    with TemporaryDirectory() as tmpdirname:
        dirpath = Path(tmpdirname)
        filepath = dirpath / 'test_file.txt'
        filepath.touch()
        assert exists_as(str(filepath)) == 'file'
        assert exists_as(str(Path(tmpdirname))) == 'directory'

        try:
            _ = exists_as('/dev/null/foo')
            assert False
        except NotADirectoryError:
            assert True

        try:
            _ = exists_as('/dev/null')
            assert False
        except PermissionError:
            assert True


# Generated at 2022-06-21 13:01:39.819109
# Unit test for function directory_present
def test_directory_present():
    """Test directory_present()."""
    from tempfile import TemporaryDirectory
    from flutils.pathutils import directory_present
    from flutils.osutils import _get_caller

    # Get the home directory
    home_dir = Path.home()

    with TemporaryDirectory() as tmp_dir:
        # Check that a directory created with relative path raises
        # a ValueError.
        rel_dir = Path('%s/%s') % (tmp_dir, 'flutils')
        caller = _get_caller()

# Generated at 2022-06-21 13:01:44.330297
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    assert isinstance(get_os_group(), grp.struct_group)
    assert isinstance(get_os_group('foo'), grp.struct_group)



# Generated at 2022-06-21 13:01:47.416283
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests._constants import TESTS_TEMP_DIRECTORY
    directory_present(TESTS_TEMP_DIRECTORY)



# Generated at 2022-06-21 13:01:59.824315
# Unit test for function get_os_group
def test_get_os_group():
    # Test get_os_group() without any args or kwargs
    # Defaults to the current user's group.
    os_user = get_os_user()
    os_group = get_os_group()
    assert os_user.pw_gid == os_group.gr_gid

    user_name = get_os_user().pw_name
    group_name = get_os_group().gr_name
    assert group_name == user_name

    # Test that get_os_group() raises an
    # OSError when a given name does not exist
    # as a group name in the system.
    with pytest.raises(OSError):
        get_os_group('blah')

    # Test that get_os_group() raises an
    # OSError when a given g

# Generated at 2022-06-21 13:02:01.350301
# Unit test for function get_os_group
def test_get_os_group():
    assert 'bar' == get_os_group('bar').gr_name



# Generated at 2022-06-21 13:02:13.842356
# Unit test for function chmod
def test_chmod():
    import os
    import stat

    def _get_mode(path: Path) -> int:
        """Just get the mode of a path."""
        mode = os.stat(path).st_mode
        return mode

    def _mode_is(path: Path, mode: int) -> bool:
        """Check to see if the mode of a path is the given mode."""
        return _get_mode(path) == mode

    def _create_tree(tempdir: Path, mode: int):
        """Create a test directory tree."""

        tempdir.mkdir()
        os.chmod(tempdir, mode)  # nosec

        test1 = tempdir.joinpath('test1')
        test1.write_text('test1')
        os.chmod(test1, mode)  # nosec

        test2 = temp

# Generated at 2022-06-21 13:02:19.276858
# Unit test for function exists_as
def test_exists_as():
    # Test a directory
    test_dir = Path(__file__).parent / 'path_ututils_dir'
    test_dir.mkdir(0o770, parents=True, exist_ok=True)
    try:
        assert exists_as(test_dir) == 'directory'
    finally:
        shutil.rmtree(test_dir)

    # Test a file
    test_file = test_dir / 'test_file.txt'
    test_file.touch(0o770, exist_ok=True)
    try:
        assert exists_as(test_file) == 'file'
    finally:
        test_file.unlink()

    # Test a block device
    test_block_device = test_dir / 'test_block_device'

# Generated at 2022-06-21 13:02:54.798691
# Unit test for function find_paths
def test_find_paths():
    # Make a temp directory and it's children.
    with TemporaryDirectory(dir='/tmp') as temp_dir:
        temp_dir = Path(temp_dir)
        temp_dir_path = temp_dir.as_posix()
        file_one = temp_dir_path + '/file_one'
        with open(file_one, 'w') as file_one_fd:
            file_one_fd.write('Test')
        file_two = temp_dir_path + '/file_two'
        with open(file_two, 'w') as file_two_fd:
            file_two_fd.write('Test')
        dir_one = temp_dir_path + '/dir_one'
        os.mkdir(dir_one)
        file_one_one = dir_one + '/file_one_one'

# Generated at 2022-06-21 13:03:06.416309
# Unit test for function find_paths
def test_find_paths():
    import flutils.osutils as osutils
    import tempfile
    tmp_dir = tempfile.mkdtemp(prefix='test_flutils')
    tmp_dir_path = Path(tmp_dir)
    osutils.directory_present(tmp_dir_path / 'dir_a')
    (tmp_dir_path / 'dir_b').mkdir(mode=0o755, parents=True)
    (tmp_dir_path / 'file_a').touch(mode=0o755)
    (tmp_dir_path / 'dir_b' / 'file_b').touch(mode=0o755)

# Generated at 2022-06-21 13:03:09.752632
# Unit test for function get_os_user
def test_get_os_user():
    # For coverage:
    try:
        _ = get_os_user()
    except KeyError:
        assert True

    # For coverage:
    try:
        _ = get_os_user('foo')
    except KeyError:
        assert True

    # For coverage:
    try:
        _ = get_os_user(1001)
    except KeyError:
        assert True



# Generated at 2022-06-21 13:03:11.164488
# Unit test for function directory_present
def test_directory_present():
    """
    Unit test for directory_present.
    """
    tmp_dir = Path('.tmp')

# Generated at 2022-06-21 13:03:11.586819
# Unit test for function exists_as
def test_exists_as():
    pass



# Generated at 2022-06-21 13:03:14.535750
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/foo/../bar') == Path('/home/test_user/bar')
    assert normalize_path(b'~/foo/../bar') == Path('/home/test_user/bar')



# Generated at 2022-06-21 13:03:26.357314
# Unit test for function find_paths
def test_find_paths():
    '''
    >>> from flutils.pathutils import find_paths
    >>> from tempfile import TemporaryDirectory
    >>> import shutil
    >>> with TemporaryDirectory() as td:
    ...     test_dir = Path(td, 'test_dir')
    ...     test_dir.mkdir()
    ...     dir_1 = test_dir.joinpath('dir_one')
    ...     dir_1.mkdir()
    ...     file_1 = dir_1.joinpath('file_one')
    ...     file_1.touch()
    ...     assert [p.as_posix() for p in find_paths(dir_1 / '*')] == [file_1.as_posix()]
    ...     shutil.rmtree(test_dir.as_posix())
    '''
    pass



# Generated at 2022-06-21 13:03:29.398534
# Unit test for function normalize_path
def test_normalize_path():
    """ Test function normalize_path.
    """
    path = normalize_path('~/tmp/foo/../bar')
    assert isinstance(path, Path)
    assert path == Path(os.path.expanduser('~/tmp/bar'))
test_normalize_path()



# Generated at 2022-06-21 13:03:34.641625
# Unit test for function get_os_group
def test_get_os_group():
    """Unit tests function get_os_group."""
    test_arg = 'wheel'
    test_gid = cast(int, get_os_group(test_arg).gr_gid)
    assert isinstance(get_os_group(test_arg), grp.struct_group)
    assert get_os_group(test_arg).gr_name == test_arg
    assert isinstance(get_os_group(test_gid).gr_gid, int)
    assert get_os_group(test_gid).gr_gid == test_gid



# Generated at 2022-06-21 13:03:45.973743
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    tmp_dir = '/tmp/{}'.format(user)
    with (Path(tmp_dir) / 'test_chown').open('a') as _f:
        _f.close()

    assert (Path(tmp_dir) / 'test_chown').exists() is True
    assert (Path(tmp_dir) / 'test_chown').stat().st_uid == os.getuid()
    assert (Path(tmp_dir) / 'test_chown').stat().st_gid == os.getgid()

    chown(Path(tmp_dir) / 'test_chown', user=user, group=group)


# Generated at 2022-06-21 13:04:46.299341
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()
    prefix = 'test_path_absent'
    test_file = tempfile.mkstemp(suffix='.txt', prefix=prefix, dir=temp_dir, text=True)
    test_file_name = test_file[1]
    test_file = Path(test_file_name)
    test_link = Path(temp_dir, 'file_link')
    test_link.symlink_to(test_file)
    test_dir = Path(temp_dir, 'dir_one')
    test_dir.mkdir(parents=True)
    test_dir_link = Path(temp_dir, 'dir_link')
    test_dir_link.symlink_to(test_dir)
    assert path

# Generated at 2022-06-21 13:04:52.319725
# Unit test for function get_os_user
def test_get_os_user():
    # Test get_os_user using uid
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    # Test get_os_user using user name
    user = get_os_user('root')
    assert isinstance(user, pwd.struct_passwd)


# Generated at 2022-06-21 13:05:03.219736
# Unit test for function get_os_group
def test_get_os_group():
    if POSIX:
        assert get_os_group('root').gr_name == 'root'
        # Ensure spaces that are used in a name are removed.
        assert get_os_group('new_users').gr_name == 'new_users'
        assert get_os_group('None').gr_name == 'None'
        # Ensure a group can be found by gid.
        assert get_os_group(0).gr_gid == 0
        # Ensure a group that does not exist raises an OSError.
        with pytest.raises(OSError):
            get_os_group('foobar')



# Generated at 2022-06-21 13:05:09.215053
# Unit test for function path_absent
def test_path_absent():
    path = tempfile.mkdtemp()
    path = Path(path)
    test_path = path / 'test_path'
    test_path.mkdir()
    path_absent(test_path)
    assert not os.path.exists(test_path)
    test_path.mkdir()
    path_absent(test_path)
    assert not os.path.exists(test_path)



# Generated at 2022-06-21 13:05:10.734154
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.home()) == 'directory'
    assert exists_as(Path.home()/'.bash_history') == 'file'



# Generated at 2022-06-21 13:05:13.921307
# Unit test for function find_paths
def test_find_paths():
    pattern = '/home/test_user/tmp/*'
    assert list(find_paths(pattern)) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-21 13:05:25.081119
# Unit test for function chown
def test_chown():
    from flutils.sysutils import getuid, getgid
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils import tests

    # Test a path that does not exist.
    path = Path('/opt/flutils.tests/pathutils/osutils/chown.txt')
    path_absent(path)

    user = 'nobody'
    group = 'nobody'
    chown(path)
    assert (
        getuid(path) == pwd.getpwnam(user).pw_uid
        and
        getgid(path) == grp.getgrnam(group).gr_gid
    )

    chown(path, user=user, group=group)