

# Generated at 2022-06-21 12:56:15.346646
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(PosixPath('~/tmp/foo/../bar')) == \
        PosixPath('/home/test_user/tmp/bar')
    assert normalize_path(WindowsPath(r'C:\Users\test_user\tmp\foo\..\bar')) == \
        WindowsPath('C:\\Users\\test_user\\tmp\\bar')
    home_dir = os.environ.get('HOME', '')
    if home_dir:
        home_dir = Path(home_dir)
        assert normalize_path(home_dir / 'tmp' / 'foo' / '..' / 'bar') == \
            home_dir / 'tmp' / 'bar'

# Generated at 2022-06-21 12:56:15.786041
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-21 12:56:27.620293
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from shutil import rmtree
    tmp_path = Path('~/tmp/flutils.tests.osutils').expanduser()
    sub_path = tmp_path / 'test_dir'
    sub_sub_path = sub_path / 'sub_dir'
    path = sub_sub_path / 'test_dir'

    assert directory_present(path, mode=0o770).as_posix()\
        == sub_sub_path.as_posix()
    assert directory_present(path, mode=0o770).as_posix()\
        == sub_sub_path.as_posix()
    assert directory_present(path, mode=0o770).as_posix()\
        == sub_sub_path.as_posix()

    assert sub_sub_path

# Generated at 2022-06-21 12:56:35.335947
# Unit test for function find_paths
def test_find_paths():
    # 1
    expected = Path('/home/test_user/tmp') / 'file_one'
    actual = list(find_paths('/home/test_user/tmp/*'))
    assert actual == [expected]

    # 2
    expected = Path('/home/test_user/tmp') / 'dir_one'
    actual = list(find_paths('/home/test_user/tmp/*'))
    assert actual == [expected]

    # 3
    expected = [
        Path('/home/test_user/tmp') / 'file_one',
        Path('/home/test_user/tmp') / 'dir_one'
    ]
    actual = list(find_paths(Path('/home/test_user/tmp/*')))
    assert actual == expected

    # 4

# Generated at 2022-06-21 12:56:45.774959
# Unit test for function normalize_path
def test_normalize_path():
    """Test :func:`normalize_path` function."""
    assert normalize_path('~/test/test_path') == \
        Path(os.path.expanduser('~/test/test_path'))
    assert normalize_path('foo') == Path(os.getcwd()) / 'foo'
    assert normalize_path('../foo') == Path(os.getcwd()) / '..' / 'foo'
    assert normalize_path('foo/../bar') == Path(os.getcwd()) / 'foo' / '..' / 'bar'
    assert normalize_path('foo//bar') == Path(os.getcwd()) / 'foo' / 'bar'
    assert normalize_path('foo///bar') == Path(os.getcwd()) / 'foo' / 'bar'
   

# Generated at 2022-06-21 12:56:55.544845
# Unit test for function normalize_path
def test_normalize_path():  # noqa
    assert normalize_path('~/workspace').as_posix() == \
        get_os_user().pw_dir + '/workspace'

    assert normalize_path('/workspace').as_posix() == '/workspace'
    assert normalize_path('/tmp/../workspace').as_posix() == '/workspace'
    assert normalize_path('/workspace/foo///../bar').as_posix() == \
        '/workspace/bar'

    # Accept Dict and List
    assert normalize_path(['~/workspace']).as_posix() == \
        get_os_user().pw_dir + '/workspace'

    assert normalize_path({'~/workspace'}).as_posix() == \
        get_os_user().pw

# Generated at 2022-06-21 12:57:04.525669
# Unit test for function chown
def test_chown():
    #  chown(path, user=None, group=None, include_parent=False)
    import unittest

    class TestChown(unittest.TestCase):
        def __init__(self, methodName: str = ...) -> None:
            super().__init__(methodName)

        def setUp(self) -> None:
            self.test_dir = Path('/tmp/flutils_tests')
            self.test_dir.mkdir()

        def tearDown(self) -> None:
            import shutil
            shutil.rmtree(str(self.test_dir.as_posix()), ignore_errors=True)


# Generated at 2022-06-21 12:57:15.220903
# Unit test for function chmod
def test_chmod():
    mode_tmp = 0o700
    mode_file = 0o600
    path = Path('~/tmp/flutils.tests.osutils.txt')
    path_tmp = path.parent

    if path.exists() is False:
        path.touch()
        path.chmod(mode_file)

    current_mode = path.stat().st_mode
    current_mode_tmp = path_tmp.stat().st_mode

# Generated at 2022-06-21 12:57:18.084404
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user."""
    assert isinstance(get_os_user(), pwd.struct_passwd)



# Generated at 2022-06-21 12:57:28.417408
# Unit test for function get_os_user
def test_get_os_user():
    """Test all return types for get_os_user()."""
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user(''), pwd.struct_passwd)
    assert isinstance(get_os_user(' '), pwd.struct_passwd)
    assert isinstance(get_os_user(None), pwd.struct_passwd)
    assert isinstance(get_os_user(get_os_user().pw_name), pwd.struct_passwd)
    assert isinstance(get_os_user(get_os_user().pw_uid), pwd.struct_passwd)
    assert isinstance(get_os_user(os.getuid()), pwd.struct_passwd)

# Generated at 2022-06-21 12:57:50.701006
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/foo/../bar'
    os.environ['FOO'] = 'foo'
    os.environ['BAZ'] = '/foo/bar/baz'
    os.environ['FOOBAR'] = '${FOO}bar'
    os.environ['TEST_PATH'] = '${FOO${FOO}}'
    os.environ['HOME'] = '/home/test_user'
    result = normalize_path(path)
    assert result.as_posix() == '/home/test_user/tmp/bar'
    assert result.as_posix() == str(result)
    path = 'A//B'
    result = normalize_path(path)
    assert result.as_posix() == 'A/B'
    path = 'A/B/'


# Generated at 2022-06-21 12:58:01.628134
# Unit test for function chmod
def test_chmod():
    from shutil import rmtree
    from tempfile import gettempdir
    from flutils.pathutils import chmod, normalize_path

    tempdir = normalize_path(gettempdir()) / 'fltemp'
    tempdir.mkdir(mode=0o700, parents=True, exist_ok=True)

    x = (tempdir / 'dir1')
    x.mkdir(mode=0o700, parents=False, exist_ok=True)
    y = (tempdir / 'dir1' / 'dir2')
    y.mkdir(mode=0o700, parents=False, exist_ok=True)
    z = (tempdir / 'dir1' / 'dir2' / 'file1.txt')
    z.touch(mode=0o600, exist_ok=True)


# Generated at 2022-06-21 12:58:06.531357
# Unit test for function chown
def test_chown():
    path = Path('/tmp/flutils-tests/foo.txt')
    path.parent.mkdir(exist_ok=True)
    path.touch()
    chown(path, 'wheel')
    assert path.owner() == pwd.getpwnam('wheel').pw_name
    path.unlink()
    path.parent.rmdir()



# Generated at 2022-06-21 12:58:09.379196
# Unit test for function directory_present
def test_directory_present():
    pytest.dbgfunc()
    path = '~/tmp/flutils.tests.osutils'
    directory_present(path)
    assert Path(path).exists() is True



# Generated at 2022-06-21 12:58:16.690820
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(prefix='flutils.tests.') as tmp_dir:

        tmp_dir = Path(tmp_dir)

        test_path0 = tmp_dir.joinpath('test_path0.txt')
        test_path1 = tmp_dir.joinpath('test_path1.txt')
        test_path1.mkdir()
        test_path2 = tmp_dir.joinpath('test_path2.txt')
        test_path2.touch()

        # A path that does not exist and the mode and chown will be applied.

# Generated at 2022-06-21 12:58:21.474126
# Unit test for function get_os_user
def test_get_os_user():
    """The function should return a tuple-like object."""
    assert isinstance(get_os_user(), pwd.struct_passwd)



# Generated at 2022-06-21 12:58:32.448554
# Unit test for function exists_as
def test_exists_as():
    from normpath import normpath
    from os import path, makedirs, remove
    from shutil import rmtree

    test_dir = '.test_dir'
    test_file = 'test_file'
    test_dir_file = path.join(test_dir, test_file)
    test_glob_dir = test_dir + '*'
    test_glob_file = test_file + '*'

    def exists_as_helper(test_path, expected_type):
        assert exists_as(test_path) == expected_type

    def exists_as_helper_error(test_path):
        with pytest.raises(ValueError):
            exists_as(test_path)

    # test a directory that does not exist
    exists_as_helper(test_dir, '')



# Generated at 2022-06-21 12:58:35.365610
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar',
        gr_passwd='*',
        gr_gid=2001,
        gr_mem=['foo'],
    )

# Generated at 2022-06-21 12:58:38.358211
# Unit test for function get_os_user
def test_get_os_user():
    # Test pw_name is a valid loginname
    # Test pw_name is not a loginname
    pass
    # Test pw_name is a valid uid
    # Test pw_name is not a valid uid



# Generated at 2022-06-21 12:58:47.619167
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == os.path.expanduser('~/tmp/bar')
    assert normalize_path('/tmp/foo/../bar') == '/tmp/bar'
    assert normalize_path('~/tmp/bar') == os.path.expanduser('~/tmp/bar')
    assert normalize_path('/tmp/bar') == '/tmp/bar'
    assert normalize_path('~/') == os.path.expanduser('~/')
    assert normalize_path('/') == '/'
    assert (
        normalize_path('~/.foo/../bar') ==
        os.path.expanduser('~/.foo/../bar')
    )

# Generated at 2022-06-21 12:59:05.464752
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.testing.helpers import capture

    with capture() as (stdout, stderr):
        grp = get_os_group()
        stdout.seek(0)
        stderr.seek(0)
        assert stdout.read() == b''
        assert stderr.read() == b''
        assert grp.gr_name == os.getenv('USER')
        assert grp.gr_passwd == '*'
        assert grp[2] == os.getenv('USER')

    with capture() as (stdout, stderr):
        grp = get_os_group(os.getgid())
        stdout.seek(0)
        stderr.seek(0)
        assert stdout.read() == b''
        assert stderr.read() == b''


# Generated at 2022-06-21 12:59:15.497970
# Unit test for function get_os_user
def test_get_os_user():  # noqa: D103
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == os.getuid()
    assert user.pw_name == getpass.getuser()

    # Test with uid
    uid = -1
    user = get_os_user(uid)
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == uid
    assert user.pw_name == os.getlogin()

    # Test with login name
    login = user.pw_name
    user = get_os_user(login)
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == os.getuid()
    assert user.pw

# Generated at 2022-06-21 12:59:27.677985
# Unit test for function get_os_group
def test_get_os_group():
    from os import getgid
    from typing import NamedTuple

    group = get_os_group()
    assert isinstance(group, grp.struct_group)
    assert group.gr_gid == getgid()
    assert group.gr_name == get_os_user().pw_name

    group_data = NamedTuple(
        'GroupData',
        [('name', str), ('passwd', str), ('gid', int), ('members', list)]
    )

    _group = get_os_group('bar')
    assert isinstance(_group, grp.struct_group)
    assert _group.gr_gid == 2001
    assert _group.gr_mem == ['foo']
    assert isinstance(_group, group_data)



# Generated at 2022-06-21 12:59:37.639525
# Unit test for function chmod
def test_chmod():
    import shutil

    try:
        test_file = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
        test_file.parent.mkdir(exist_ok=True)
        chmod(test_file, 0o666)
        assert test_file.stat().st_mode & 0o777 == 0o666
    finally:
        if test_file.exists():
            test_file.unlink()
        if test_file.parent.exists():
            shutil.rmtree(test_file.parent)


# Generated at 2022-06-21 12:59:46.823529
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from pathlib import Path
    path = Path('~/tmp/foo/bar')
    assert path.exists() is False
    path_absent(path)
    assert path.exists() is False
    path.mkdir(parents=True, exist_ok=True)
    assert path.exists() is True
    path.joinpath('baz').touch()
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-21 12:59:55.619799
# Unit test for function chown
def test_chown():
    test_dir = Path(__file__).parent
    user = getpass.getuser()
    path = test_dir / 'foo.txt'
    assert path.exists() is False
    path.write_bytes(b'Hello, world!')
    chown(path, user=user)
    p_stat = path.stat()
    assert p_stat.st_uid == pwd.getpwnam(user).pw_uid
    assert p_stat.st_gid == grp.getgrgid(p_stat.st_gid).gr_gid
    path.unlink()
    path.mkdir(parents=True)
    chown(path, user=user)
    p_stat = path.stat()

# Generated at 2022-06-21 13:00:00.480324
# Unit test for function get_os_user
def test_get_os_user():
    # Success
    name = getpass.getuser()
    user = get_os_user(name)
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == name

    # Failure
    with pytest.raises(OSError):
        get_os_user('foo_bar')



# Generated at 2022-06-21 13:00:12.234919
# Unit test for function chmod
def test_chmod():
    # If a file exists and is not a symlink (includes a symlink target),
    # execute the chmod.  The chmod should have an effect.
    root = Path('~/tmp').expanduser()
    path = root / 'flutils.tests.osutils.txt'
    try:
        if path.is_symlink() is True:
            path.unlink()
    except OSError:
        pass

    if path.exists() is False:
        path.touch()

    assert path.exists() is True
    try:
        if path.is_symlink() is True:
            path.unlink()
    except OSError:
        pass

    assert path.is_symlink() is False
    assert path.is_file() is True
    mode = path.stat

# Generated at 2022-06-21 13:00:14.814275
# Unit test for function find_paths
def test_find_paths():
    # TODO: Generate a temp directory and create some files
    # and dirs in the temp dir.
    pass



# Generated at 2022-06-21 13:00:19.213599
# Unit test for function normalize_path
def test_normalize_path():

    path = normalize_path('~/tmp/foo/../bar')
    assert path == Path(os.path.join(user_home, 'tmp', 'bar'))

    path = normalize_path('/tmp/foo/../bar')
    assert path == Path('/tmp/bar')


# Generated at 2022-06-21 13:00:36.143111
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path"""
    path = normalize_path(os.getcwd())
    assert isinstance(path, Path)
    assert path == Path(os.getcwd())
test_normalize_path()



# Generated at 2022-06-21 13:00:38.580891
# Unit test for function directory_present
def test_directory_present():
    temp_path = directory_present('/tmp/test_path')
    assert str(temp_path) == '/tmp/test_path'



# Generated at 2022-06-21 13:00:49.341215
# Unit test for function normalize_path

# Generated at 2022-06-21 13:00:50.702970
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 13:01:02.133984
# Unit test for function directory_present
def test_directory_present():
    Path('/tmp').mkdir(mode=0o755, parents=True, exist_ok=True)
    Path('/tmp/flutils.tests.pathutils.d1').rmdir()
    assert directory_present('/tmp/flutils.tests.pathutils.d1') == \
        cast(Path, Path('/tmp/flutils.tests.pathutils.d1'))

    Path('/tmp').mkdir(mode=0o755, parents=True, exist_ok=True)
    Path('/tmp/flutils.tests.pathutils.d2').mkdir(mode=0o755)
    assert directory_present('/tmp/flutils.tests.pathutils.d2') == \
        cast(Path, Path('/tmp/flutils.tests.pathutils.d2'))



# Generated at 2022-06-21 13:01:12.874544
# Unit test for function chown
def test_chown():
    # Test -1 leave unchanged user
    user = os.getuid()
    chown('/tmp/test_ft.txt', user='-1')
    assert get_os_user(os.stat('/tmp/test_ft.txt').st_uid).pw_uid == user

    #Test -1 leave unchanged group
    group = os.getgid()
    chown('/tmp/test_ft.txt', group='-1')
    assert get_os_group(os.stat('/tmp/test_ft.txt').st_gid).gr_gid == group

    # Test username
    chown('/tmp/test_ft.txt', user='flutils_test')

# Generated at 2022-06-21 13:01:20.487091
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.path.expanduser('~')) == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as(None) == ''
    assert exists_as('') == ''
    assert exists_as('foo') == ''
    assert exists_as(Path('foo').resolve()) == ''
    assert exists_as(Path('foo/bar').resolve()) == ''



# Generated at 2022-06-21 13:01:21.899817
# Unit test for function chown
def test_chown():

    assert chown('~/tmp/foo') is None



# Generated at 2022-06-21 13:01:26.992034
# Unit test for function get_os_user
def test_get_os_user():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-return-statements
    # pylint: disable=too-many-return-statements
    # pylint: disable=unidiomatic-typecheck
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=no-else-return
    from copy import copy
    from platform import system
    from subprocess import CalledProcessError
    from typing import Dict, List
    from unittest.mock import patch
    from unittest.mock import MagicMock


# Generated at 2022-06-21 13:01:34.076145
# Unit test for function normalize_path
def test_normalize_path():
    """Test function flutils.pathutils.normalize_path.
    """
    if os.name == 'nt':
        assert normalize_path('C:\\tmp') == Path('C:\\tmp')
        assert normalize_path('c:\\tmp') == Path('C:\\tmp')
    else:
        assert normalize_path('/tmp') == Path('/tmp')



# Generated at 2022-06-21 13:02:12.717645
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import find_paths
    with TemporaryDirectory() as test_dir:
        for path in [
            '~/tmp',
            os.path.join(test_dir, 'tmp'),
            os.path.join(test_dir, '**'),
        ]:
            assert len(list(find_paths(path))) == 0
        # Create some files and directories

# Generated at 2022-06-21 13:02:18.594918
# Unit test for function get_os_user
def test_get_os_user():
    user_name = getpass.getuser()
    user_info = get_os_user(user_name)
    assert user_info.pw_name == user_name
    user_info = get_os_user()
    assert user_info.pw_name == user_name
    uid = user_info.pw_uid
    user_info = get_os_user(uid)
    assert user_info.pw_uid == uid



# Generated at 2022-06-21 13:02:24.800881
# Unit test for function path_absent
def test_path_absent():
    # Delete the tmp directory if it exists.
    path_absent('~/tmp')
    assert exists_as('~/tmp') == ''

    # Create a folder to test with.
    path_present('~/tmp/test_path')
    assert exists_as('~/tmp/test_path') == 'directory'

    path_absent('~/tmp/test_path')
    assert exists_as('~/tmp/test_path') == ''

    path_present('~/tmp/test_path/test_file')
    assert exists_as('~/tmp/test_path/test_file') == 'file'

    path_absent('~/tmp/test_path')
    assert exists_as('~/tmp/test_path') == ''

    path_present('~/tmp/test_link')

# Generated at 2022-06-21 13:02:36.524967
# Unit test for function find_paths
def test_find_paths():
    """Test the flutils.pathutils.find_paths function.
    """
    import os
    import shutil
    import tempfile

    from flutils.pathutils import find_paths

    # Test 1
    try:
        tmpdir = tempfile.mkdtemp(prefix='flutils.tests.')
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('foo').mkdir()
        tmpdir.joinpath('bar').mkdir()
        tmpdir.joinpath('baz').mkdir()

        expected = tmpdir.glob('*')
        actual = find_paths(tmpdir)
        assert list(actual) == list(expected)
    finally:
        shutil.rmtree(tmpdir.as_posix())

    # Test 2

# Generated at 2022-06-21 13:02:40.626570
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as"""
    directory_present(
        '~/tmp/test_path',
        user=getuser(),
        group=getgroup(),
    )

    assert exists_as('~/tmp/test_path') == 'directory'

    directory_present(
        '~/tmp/test_path/sub_dir',
        user=getuser(),
        group=getgroup(),
    )
    assert exists_as('~/tmp/test_path/sub_dir') == 'directory'

    with open('~/tmp/test_path/sub_dir/test_file.txt', 'w') as file_obj:
        file_obj.write('test')

    assert exists_as('~/tmp/test_path/sub_dir/test_file.txt') == 'file'

    os.symlink

# Generated at 2022-06-21 13:02:41.542639
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 13:02:47.228709
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('$HOME/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('tmp/foo/../') == Path(os.getcwd() + '/tmp')
    assert normalize_path('foo/../bar') == Path(os.getcwd() + '/bar')
    assert normalize_path(Path('foo/../bar')) == Path(os.getcwd() + '/bar')



# Generated at 2022-06-21 13:02:48.637410
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('nobody').pw_uid == -2


# Generated at 2022-06-21 13:03:00.732364
# Unit test for function path_absent
def test_path_absent():
    SHELL_CMD_TEMPLATE = ('set -e; umask 0022; cd "%s"; eval "%%s"')
    SHELL_CMD_TEMPLATE = SHELL_CMD_TEMPLATE.replace('%', '%%')
    SHELL_CMD_TEMPLATE = SHELL_CMD_TEMPLATE.replace('"', '\\"')

    def shell(command):
        cmd = command.replace('"', '\\"')
        cmd = SHELL_CMD_TEMPLATE % (os.getcwd(), cmd)
        return subprocess.run(cmd, shell=True, check=True)

    path = '~/tmp/test_flutils_path_absent'
    path_absent(path)


# Generated at 2022-06-21 13:03:07.473781
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function ``find_paths``."""
    import pytest
    from pathlib import Path
    from typing import List
    from flutils.pathutils import find_paths

    paths: List[Path] = list(find_paths(str(Path.cwd())))

    assert isinstance(paths, list) is True
    assert isinstance(paths[0], Path) is True
    assert find_paths.__doc__ is not None



# Generated at 2022-06-21 13:03:39.283157
# Unit test for function chown
def test_chown():
    test_path = Path('/tmp/flutils.tests.osutils.txt')
    test_path.write_text('Hello World', 'utf-8')
    chown(test_path, '', '', include_parent=True)
    test_path.unlink()

    failed = False
    try:
        chown('/tmp/flutils.tests.osutils.txt', user='foo', group='bar')
    except OSError:
        failed = True
    else:
        test_path.unlink()

    assert failed is True

# Generated at 2022-06-21 13:03:50.433538
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path
    from pathlib import Path
    # test for bytes
    for path in [b'foo', b'~/foo', b'~/foo/../bar', b'foo/bar/']:
        assert normalize_path(path) == Path(os.path.normcase(path.decode()))
    # test for str
    for path in ['foo', '~/foo', '~/foo/../bar', 'foo/bar/']:
        assert normalize_path(path) == Path(os.path.normcase(path))
    # test for Path
    for path in ['foo', '~/foo', '~/foo/../bar', 'foo/bar/']:
        path = Path(path)

# Generated at 2022-06-21 13:03:52.600341
# Unit test for function get_os_group
def test_get_os_group():
    gr = get_os_group('bar')
    assert isinstance(gr, grp.struct_group)



# Generated at 2022-06-21 13:04:01.638107
# Unit test for function path_absent
def test_path_absent():
    """Unit tests for function path_absent.

    This function is a part of the pathutils module.
    """
    from flutils.pathutils import path_absent

    a = Path(tempfile.mkdtemp())
    p = a / 'tmp'
    p.mkdir()
    path_absent(p)
    assert p.exists() is False

    p = a / 'tmp'
    p.mkdir()
    p = p / 'tmp.del'
    p.touch()
    path_absent(p)
    assert p.exists() is False

    p = a / 'tmp'
    p.mkdir()
    p = p / 'tmp'
    p.mkdir()
    p = p / 'tmp.del'
    p.touch()
    path_absent(p)


# Generated at 2022-06-21 13:04:09.436443
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_path:
        tmp_path = normalize_path(tmp_path)

        Path(tmp_path.as_posix() + '/file_one').touch()
        Path(tmp_path.as_posix() + '/file_two').touch()
        Path(tmp_path.as_posix() + '/dir_one').mkdir()

        result: List[Path] = list(
            find_paths(
                '%s/*'
                % tmp_path.as_posix()
            )
        )

# Generated at 2022-06-21 13:04:18.034451
# Unit test for function normalize_path
def test_normalize_path():
    tmp = Path(os.getcwd()) / 'tmp'
    print(type(tmp))
    print(type(tmp.as_posix()))
    print(tmp.as_posix())
    norm_tmp = normalize_path(tmp.as_posix())
    print(type(norm_tmp))
    print(norm_tmp)
    print(type(normalize_path('~/tmp/foo')))
    print(normalize_path('~/tmp/foo'))
    print(type(normalize_path(b'~/tmp/foo')))
    print(normalize_path(b'~/tmp/foo'))
    print(type(normalize_path('~/tmp/foo/../bar')))
    print(normalize_path('~/tmp/foo/../bar'))
    print

# Generated at 2022-06-21 13:04:25.317329
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    from flutils.pathutils import get_os_user
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user('root'), pwd.struct_passwd)
    import pytest
    with pytest.raises(OSError):
        get_os_user(0)
    with pytest.raises(OSError):
        get_os_user('not_a_user')



# Generated at 2022-06-21 13:04:32.159594
# Unit test for function exists_as
def test_exists_as():
    from tempfile import NamedTemporaryFile

    path = Path('/tmp').expanduser()
    assert exists_as(path) == 'directory'

    path = path.joinpath('flutils.tests.osutils.txt')
    assert exists_as(path) == ''

    with NamedTemporaryFile(dir=path.parent.as_posix()) as file_:
        assert exists_as(file_.name) == 'file'

    return



# Generated at 2022-06-21 13:04:43.750080
# Unit test for function path_absent
def test_path_absent():
    path = '%s/flutils_test_path_absent/test_path' % os.getcwd()
    path = normalize_path(path)
    path_absent(path)
    assert os.path.exists(path) is False
    path.mkdir(parents=True)
    path = path.as_posix()
    with open('%s/test.txt' % path, 'w') as fh:
        fh.write('Test')
    path_absent(path)
    assert os.path.exists(path) is False
    path_absent(path)
    assert os.path.exists(path) is False
    path.mkdir(parents=True)

# Generated at 2022-06-21 13:04:50.383625
# Unit test for function get_os_group
def test_get_os_group():
    """Tests ``get_os_group``."""
    name = 'bar'
    test_user = get_os_user(name)
    group = get_os_group(name)
    assert group.gr_name == name
    assert test_user.pw_gid == group.gr_gid
    assert isinstance(group, grp.struct_group) is True

