

# Generated at 2022-06-21 12:56:06.975467
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path(b'~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path(Path('~/tmp/foo/../bar')) == Path('/home/test_user/tmp/bar')

pathlib.Path.register(normalize_path)
bytes.register(normalize_path)  # noqa: WPS609, B950



# Generated at 2022-06-21 12:56:14.919513
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.pathutils import directory_present

    for path in (
        'a/b/c',
        '/a/b/c',
        '~/a/b/c',
        '~/a/b/c{}',
        r'~\a\b\c',
        r'~\a\b\c{}',
    ):
        with TemporaryDirectory() as tmpdir:
            path = str(Path(tmpdir) / path)
            path = directory_present(path)
            # The given path should now exist as a directory
            assert path.exists() is True
            assert path.is_dir() is True



# Generated at 2022-06-21 12:56:23.193281
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths

    tmp_dir = Path('/tmp/unit-test-flutils.pathutils.test_find_paths')
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)

    tmp_dir.mkdir()

    (tmp_dir / 'level_one' / 'level_two' / 'file_one').touch()
    (tmp_dir / 'level_one' / 'level_two' / 'file_two.txt').touch()
    (tmp_dir / 'level_one' / 'level_two' / 'file_three').touch()


# Generated at 2022-06-21 12:56:31.871150
# Unit test for function chown
def test_chown():
    from flutils.pathutils import rm_rf

    # Setup
    tmp_dir = Path('~/tmp/flutils.tests.pathutils.test_chown').expanduser().resolve()
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_file = Path(
        '~/tmp/flutils.tests.pathutils.test_chown/test_chown.txt'
    ).expanduser().resolve()
    tmp_file.write_bytes(b'')
    tmp_file_mode = tmp_file.stat().st_mode

    assert tmp_file_mode == 33204

    test_user = getpass.getuser()
    test_user_info = pwd.getpwnam(test_user)

# Generated at 2022-06-21 12:56:34.319995
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('.') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'



# Generated at 2022-06-21 12:56:37.896455
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user(getpass.getuser()), pwd.struct_passwd)
    assert isinstance(get_os_user(get_os_user().pw_uid), pwd.struct_passwd)
    with pytest.raises(OSError):
        get_os_user(get_os_user().pw_uid + 1)
    with pytest.raises(OSError):
        get_os_user(get_os_user().pw_name + '_INVALID')



# Generated at 2022-06-21 12:56:46.553243
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from os.path import exists
    from pathlib import Path
    from time import time

    tmp_path = Path('~/tmp/flutils.tests.pathutils.test_directory_present.%d'
                    % time()).expanduser()

    p = directory_present(tmp_path)
    assert p == tmp_path
    assert exists(tmp_path.as_posix()) is True

    tmp_path = Path('~/tmp/flutils.tests.pathutils.test_directory_present.%d'
                    % time()).expanduser()

    p = directory_present(tmp_path, mode=0o666)
    assert p == tmp_path
    assert exists(tmp_path.as_posix()) is True

# Generated at 2022-06-21 12:56:55.741247
# Unit test for function directory_present
def test_directory_present():
    import pytest
    from os import PathLike, rmdir
    from pathlib import Path

    def _cleanup(path: PathLike) -> None:
        rmdir(Path(path).as_posix())

    path = '~/tmp/test/dir_present.dir'
    path = directory_present(path)
    assert path.is_dir() is True

    path = '~/tmp/test/dir_present'
    path = directory_present(path)
    assert path.is_dir() is True

    path = '~/tmp/*/dir_present'
    with pytest.raises(ValueError) as excinfo:
        directory_present(path)
    assert 'must NOT contain any glob patterns' in str(excinfo.value)

    path = './tmp/dir_present'

# Generated at 2022-06-21 12:56:59.610034
# Unit test for function directory_present
def test_directory_present():
    test_path = Path(__file__).parent.parent
    assert directory_present(test_path).as_posix() == test_path.as_posix()
    assert (directory_present('/tmp/foo/bar/baz')).as_posix() == \
        '/tmp/foo/bar/baz'
    assert (directory_present('/tmp/baz/bar/foo')).as_posix() == \
        '/tmp/baz/bar/foo'
    assert (directory_present('/tmp/foo/foo/foo')).as_posix() == \
        '/tmp/foo/foo/foo'

# Generated at 2022-06-21 12:57:11.884096
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/home') == 'directory'
    assert exists_as('/home/foo') == 'directory'
    assert exists_as('~/tmp/test_path') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/shadow') == 'file'
    assert exists_as('/run/utmp') == 'file'
    assert exists_as('/sys/class/net/lo/device') == 'char device'
    assert exists_as('/tmp/test_socket') == ''
    assert exists_as('/tmp/test_path') == ''




# Generated at 2022-06-21 12:57:20.208765
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-21 12:57:30.255706
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present, normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp:
        tmp = Path(tmp)

        dir_path = directory_present(
            Path(tmp, 'new_directory')
        )
        assert isinstance(dir_path, Path)
        assert dir_path.name == 'new_directory'
        assert dir_path.is_dir()
        assert dir_path.exists()

        dir_path = directory_present(
            Path(tmp, 'new_directory', 'second_dir')
        )
        assert isinstance(dir_path, Path)
        assert dir_path.name == 'second_dir'
        assert dir_path.is_dir()
        assert dir_path.exists()

        sub_

# Generated at 2022-06-21 12:57:30.797247
# Unit test for function directory_present
def test_directory_present():
    pass

# Generated at 2022-06-21 12:57:41.565304
# Unit test for function find_paths
def test_find_paths():
    import os
    import tempfile

    os_name = os.name

    with tempfile.TemporaryDirectory() as tmpdir:
        files = ['file_one', 'file_two']
        dirs = ['dir_one', 'dir_two']

        [Path(tmpdir).joinpath(x).touch() for x in files]
        [Path(tmpdir).joinpath(x).mkdir() for x in dirs]

        results = list(find_paths(Path(tmpdir).joinpath('*')))

        assert len(results) == len(files + dirs)


# Generated at 2022-06-21 12:57:50.477908
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('C:\\Program Files\\Microsoft Visual Studio 14.0') == Path('C:/Program Files/Microsoft Visual Studio 14.0')


if PY_VER == 2:
    _normalize_path_bytes = normalize_path

    @_normalize_path_bytes.register(bytes)
    def normalize_path_bytes(path: bytes) -> Path:
        path = path.decode(sys.getfilesystemencoding())
        return normalize_path(path)

    _normalize_path_path = normalize_path

    @_normalize_path_path.register(PurePath)
    def normalize_path_path(path: PurePath) -> Path:
        path = path.as_posix()
        return normalize_path(path)



# Generated at 2022-06-21 12:57:52.351394
# Unit test for function chmod
def test_chmod():
    print(chmod.__doc__)



# Generated at 2022-06-21 12:57:53.877065
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('foo') == get_os_group('foo')



# Generated at 2022-06-21 12:57:56.524438
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.pathutils.txt') == 'file'



# Generated at 2022-06-21 12:58:05.689120
# Unit test for function get_os_group
def test_get_os_group():
    # Test the default case.
    foo = get_os_user()
    gid = foo.pw_gid
    bar = grp.getgrgid(gid)
    baz = get_os_group()
    assert bar == baz

    # Test with a valid "group name"
    foo = get_os_group('bar')
    assert foo.gr_name == 'bar'

    # Test with an integer that is a valid gid
    foo = get_os_group(2001)
    assert foo.gr_name == 'bar'

    # Test with an invalid "group name"
    with pytest.raises(OSError):
        get_os_group('baz')

    # Test with an integer that is NOT a valid gid
    with pytest.raises(OSError):
        get_os

# Generated at 2022-06-21 12:58:06.652929
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-21 12:58:14.831249
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(name='root').gr_gid == 0



# Generated at 2022-06-21 12:58:24.000764
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tempdir:
        onedir, otherdir, subdir, newdir = create_paths(
            root=tempdir,
            root_count=0,
            other_count=1,
            subdir_count=1,
            newdir_count=1
        )
        file_one, newfile = create_test_file(
            root=onedir, file_count=1, newfile_count=1
        )
        file_two = create_test_file(root=otherdir, file_count=1)

        result = list(find_paths(tempdir.as_posix()))
        print(result)
        assert newdir in result
        assert subdir in result
        assert onedir in result
        assert file_one in result
        assert newfile in result
        assert file

# Generated at 2022-06-21 12:58:28.058222
# Unit test for function find_paths
def test_find_paths():
    from flutils.testingutils import mkdtemp
    from flutils.testingutils import rmtree

    pattern = mkdtemp()
    with mkdtemp(suffix='-1', prefix=pattern.as_posix()) as d1, \
            mkdtemp(suffix='-2', prefix=pattern.as_posix()) as d2:
        found = tuple(find_paths(pattern))
        assert d1 in found
        assert d2 in found

    rmtree(pattern)

# Generated at 2022-06-21 12:58:41.344799
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('./foo/bar') == Path('./foo/bar')
    assert normalize_path('./foo/../bar') == Path('./bar')
    assert normalize_path('./foo/../bar') != Path('./foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') != Path('~/tmp/foo/../bar')
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('/tmp/foo/../bar') != Path('/tmp/foo/../bar')

# Generated at 2022-06-21 12:58:54.504380
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    import getpass
    # Test that it uses the current user
    exp_name = getpass.getuser()
    got_name = get_os_user().pw_name
    assert exp_name == got_name, (
        'The default value for the name, did not use the current user. '
        'Expected: %r, Got: %r' % (exp_name, got_name)
    )
    # Test that it returns the expected user using a name.
    exp_name = 'nobody'
    got_name = get_os_user(exp_name).pw_name

# Generated at 2022-06-21 12:59:07.618341
# Unit test for function path_absent
def test_path_absent():
    def tester(path: str, delete: bool = True):
        if path is not None:
            path_absent(path)
            assert not os.path.exists(path)
        if delete is True:
            if os.path.exists(test_dir) is True:
                os.rmdir(test_dir)

    path_file = Path(test_dir, 'test_file')
    path_symlink = Path(test_dir, 'test_symlink')
    try:
        os.mkdir(test_dir)
    except FileExistsError:
        pass
    with path_file.open('w') as f:
        f.write('Foo bar')
    with path_symlink.open('w') as f:
        f.write('Foo bar')

    tester

# Generated at 2022-06-21 12:59:12.375969
# Unit test for function normalize_path
def test_normalize_path():
    normalize_path('/tmp/foo')
    normalize_path('~/tmp/bar')
    normalize_path('$HOME/tmp/bar')
    normalize_path('./hello.txt')
    normalize_path(b'~/tmp/foo')
    normalize_path(Path('/tmp/foo'))



# Generated at 2022-06-21 12:59:16.122148
# Unit test for function chown
def test_chown():
    assert chown(__file__)
    assert chown(__file__, user='-1')
    assert chown(__file__, group='-1')



# Generated at 2022-06-21 12:59:16.701694
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 12:59:19.572799
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function."""
    # This is supposed to test that that the environment variable $HOME is
    # expanded, the tilde becomes the home directory and that the path is
    # absolute.
    test_path = '~/tmp/foo/../bar'

    path = normalize_path(test_path)

    assert isinstance(path, Path)
    assert isinstance(path, PosixPath)
    assert path.as_posix() == '/home/test_user/tmp/bar'

# Generated at 2022-06-21 12:59:53.100771
# Unit test for function normalize_path
def test_normalize_path():
    def make_path(path: PathLike) -> Path:
        """Create a Path object from the given path.

        This is a internal function used for testing only.
        """
        return Path(path)

    def is_normalize_path(path: _PATH) -> Path:
        """Return a Path object for testing.

        This is a internal function used for testing only.
        """
        return normalize_path(path)

    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:59:54.860213
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt', '-1', '-1')



# Generated at 2022-06-21 13:00:03.919188
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import stat
    import tempfile

    from flutils.pathutils import chmod, normalize_path

    test_path = normalize_path(os.path.join(
        tempfile.gettempdir(),
        'flutils.tests.osutils.txt'
    ))
    test_path_dir = test_path.parent

    def _get_mode(path: _PATH) -> 'Optional[int]':
        if path.exists():
            if path.is_dir():
                return os.stat(test_path_dir).st_mode
            elif path.is_file():
                return os.stat(test_path).st_mode

        return None


# Generated at 2022-06-21 13:00:15.050646
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for the flutils.pathutils.normalize_path function."""
    import traceback
    import shutil

# Generated at 2022-06-21 13:00:23.136543
# Unit test for function chmod
def test_chmod():
    with _contextlib.suppress(FileExistsError):
        _os.mkdir('tmp_flutils_tests_osutils')
    _pathlib.Path('tmp_flutils_tests_osutils/flutils.tests.osutils.txt').touch()
    chmod('tmp_flutils_tests_osutils/flutils.tests.osutils.txt', 0o660)
    _pathlib.Path('tmp_flutils_tests_osutils/flutils.tests.osutils2.txt').touch()
    chmod('tmp_flutils_tests_osutils/flutils.tests.osutils*.txt', 0o660)
    _shutil.rmtree('tmp_flutils_tests_osutils')



# Generated at 2022-06-21 13:00:31.104795
# Unit test for function directory_present
def test_directory_present():
    from shutil import rmtree
    from tempfile import mkdtemp

    path = mkdtemp()
    directory_present(path)
    directory_present(path + '/foo')
    directory_present(path + '/foo/bar')
    directory_present(path + '/foo/bar/baz')
    directory_present(path + '/foo/bar/baz/qux/quux/quuz/corge')
    rmtree(path)



# Generated at 2022-06-21 13:00:41.339586
# Unit test for function get_os_group
def test_get_os_group():
    # pylint: disable=protected-access
    _default_group = get_os_group().gr_gid
    _group = grp.struct_group(
        gr_name=None,
        gr_passwd='*',
        gr_gid=_default_group,
        gr_mem=None
    )
    if sys.version_info.major == 3:  # pragma: no cover
        _group = grp.struct_group(
            gr_name=None,
            gr_passwd='*',
            gr_gid=_default_group,
            gr_mem=[]
        )

# Generated at 2022-06-21 13:00:47.457404
# Unit test for function get_os_group
def test_get_os_group():
    if get_os_group().pw_gid == 0:
        assert get_os_group(0).gr_name == 'root'
    else:
        assert get_os_group(get_os_group().pw_gid).gr_name == get_os_group().gr_name
        assert get_os_group(get_os_group().gr_name).gr_gid == get_os_group().gr_gid


# Generated at 2022-06-21 13:00:55.205846
# Unit test for function chown
def test_chown():
    with TemporaryDirectory() as tmpdirname:
        path = tmpdirname + '/file.txt'
        with open(path, 'w') as tmpfile:
            tmpfile.write('tmp')

        user = getpass.getuser()
        group = grp.getgrgid(os.getgid())[0]

        chown(path, user, group)
        assert os.lstat(path).st_uid == os.getuid()
        assert os.lstat(path).st_gid == os.getgid()

        chown(path, '-1', group)
        assert os.lstat(path).st_uid == os.getuid()
        assert os.lstat(path).st_gid == os.getgid()

        chown(path, user, '-1')

# Generated at 2022-06-21 13:00:56.013793
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-21 13:01:28.086037
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    from flutils.pathutils import path_absent
    p1 = Path(tempfile.gettempdir()) / 'tmp' / 'file_one'
    p2 = p1.parent / 'dir_one'
    p3 = p2 / 'file_two'

    for p in (p1, p2, p3):
        p.touch()

    path_absent(p1)
    assert exists_as(p1) == ''

    path_absent(p2)
    assert exists_as(p2) == ''
    assert exists_as(p3) == ''

    path_absent(p3)
    assert exists_as(p3) == ''



# Generated at 2022-06-21 13:01:42.909104
# Unit test for function normalize_path

# Generated at 2022-06-21 13:01:49.105547
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory(prefix='flutils.tests') as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert set(find_paths(tmpdir)) == {file_one, dir_one}



# Generated at 2022-06-21 13:02:00.605269
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == PosixPath('/home/test_user/tmp/bar')
    assert normalize_path('/home/test_user/tmp/foo/../bar') == PosixPath('/home/test_user/tmp/bar')
    assert normalize_path('/home/test_user/tmp/foo/../././bar') == PosixPath('/home/test_user/tmp/bar')
    assert normalize_path('${HOME}/tmp/foo/../././bar') == PosixPath('/home/test_user/tmp/bar')
    assert normalize_path('${HOME}/tmp/${USER}/../././bar') == PosixPath('/home/test_user/tmp/bar')

# Generated at 2022-06-21 13:02:12.930167
# Unit test for function find_paths
def test_find_paths():
    import os
    import shutil
    import tempfile
    import unittest

    class TestFindPaths(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.TemporaryDirectory()
            self.test_dir = Path(self.test_dir.name)
            self.test_dir.mkdir(parents=True)

            self.test_dir_contents = [
                self.test_dir.joinpath('file_one'),
                self.test_dir.joinpath('file_two'),
                self.test_dir.joinpath('dir_one'),
                self.test_dir.joinpath('dir_two'),
            ]


# Generated at 2022-06-21 13:02:17.971973
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from flutils import osutils as osu
    result = get_os_group()
    assert isinstance(result, grp.struct_group) is True
    assert isinstance(result.gr_gid, int) is True
    assert isinstance(result.gr_name, str) is True
    assert isinstance(result.gr_mem, list) is True
    result = get_os_group(get_os_user().pw_gid)
    assert isinstance(result, grp.struct_group) is True
    assert isinstance(result.gr_gid, int) is True
    assert isinstance(result.gr_name, str) is True
    assert isinstance(result.gr_mem, list) is True

# Generated at 2022-06-21 13:02:29.501429
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.testutils import BaseTestCase
    from flutils.testutils import TEST_PATH_ROOT
    from flutils.testutils import TEST_USER
    from flutils.testutils import TEST_GROUP
    from flutils.testutils import TEST_DIR_MODE
    from flutils.testutils import TEST_FILE_MODE
    from flutils.testutils import TEST_FILE_CONTENT
    import os
    import shutil
    import tempfile

    class TestCase(BaseTestCase):

        def setUp(self):
            super().setUp()
            self.temp_dir = tempfile.mkdtemp()
            os.chmod(self.temp_dir, TEST_DIR_MODE)

        def tearDown(self):
            super().tearDown()
            shutil

# Generated at 2022-06-21 13:02:36.529248
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for get_os_group."""
    import os
    import pwd
    try:
        from unittest import mock
        from unittest.mock import patch
    except ImportError:
        import mock
        from mock import patch

    user_group = get_os_group()

    assert isinstance(user_group, grp.struct_group)

    with patch.object(pwd, 'getpwnam') as mock_getpwnam:
        mock_getpwnam.return_value = pwd.struct_passwd(
            ('test_user', 'x', 1000, 1001, 'Test User', '/home/test_user',
             '/bin/bash'))

# Generated at 2022-06-21 13:02:42.996709
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('~/tmp/bar')
    path = Path('~/tmp/foo/../bar')
    normpath = normalize_path(path)
    assert path is not normpath
    assert path == normpath
normalize_path.register(bytes, normalize_path)
normalize_path.register(Path, normalize_path)

###############################################################################
# Test Functions
###############################################################################

# Generated at 2022-06-21 13:02:48.654600
# Unit test for function chmod
def test_chmod():
    path = PosixPath('/tmp/flutils.tests.osutils.txt')
    assert path.exists() is False
    path.touch()
    assert path.stat().st_mode == 384
    chmod(path, 0o600)
    assert path.stat().st_mode == 384
    chmod(path.as_posix(), 0o660)
    assert path.stat().st_mode == 420
    path.unlink()

# Generated at 2022-06-21 13:04:51.561735
# Unit test for function exists_as
def test_exists_as():
    # Taken from the pathlib documentation, examples section.
    # https://docs.python.org/3/library/pathlib.html#pathlib.Path.exists
    p = Path('.') / 'test-file'
    p.write_text('')
    assert exists_as(p) == 'file'



# Generated at 2022-06-21 13:04:52.326896
# Unit test for function find_paths
def test_find_paths():
    return

# Generated at 2022-06-21 13:05:01.092928
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path.

    Example:
        >>> from flutils.pathutils import normalize_path
        >>> normalize_path('~/tmp/foo/../bar')
        PosixPath('/home/test_user/tmp/bar')
    """
    assert normalize_path('~/tmp/foo/../bar') == Path(
        '/home/test_user/tmp/bar'
    )



# Generated at 2022-06-21 13:05:11.680889
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.testing.helpers import capture_sys_output

    with capture_sys_output() as (stdout, stderr):
        try:
            get_os_group(name='does_not_exist')  # NOQA
        except OSError:
            msg = stdout.getvalue()
        else:
            msg = stderr.getvalue()
    assert msg == (
        'OSError: The given name: "does_not_exist", is not a valid "group '
        'name" for this operating system.\n'
    )

    it = get_os_group()
    assert isinstance(it, grp.struct_group)
    assert isinstance(it.gr_name, str)
    assert isinstance(it.gr_gid, int)



# Generated at 2022-06-21 13:05:23.870462
# Unit test for function normalize_path
def test_normalize_path():
    from tempfile import mkdtemp
    from os.path import join
    from os import chdir