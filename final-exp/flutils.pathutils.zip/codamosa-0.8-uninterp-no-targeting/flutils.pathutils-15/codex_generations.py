

# Generated at 2022-06-21 12:55:51.096061
# Unit test for function chown
def test_chown():

    env = dict(os.environ)
    env['TRAVIS'] = 'true'
    if os.environ.get('TRAVIS', None) is not None:
        return

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    try:
        path.touch()
    except FileNotFoundError as err:
        # pylint: disable=unused-variable
        # noinspection PyUnusedLocal
        err_str = '''ERROR: Unable to create path:
\t{}

\t{}
'''.format(path.as_posix(), err)
        return

    if path.exists() is not True:
        print('WARNING: Unable to create path:', path.as_posix())
        return


# Generated at 2022-06-21 12:55:55.089939
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user function

    Parameters
    ----------
    name : str
        Get user object by name
    """
    assert get_os_user('root')
    assert type(get_os_user('root')) == pwd.struct_passwd

    assert get_os_user('1000')
    assert type(get_os_user('1000')) == pwd.struct_passwd


# Generated at 2022-06-21 12:56:00.594213
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.pathutils.txt', user='foo', group='bar')
    with open('~/tmp/flutils.tests.pathutils.txt', 'w') as f:
        f.write('foo')



# Generated at 2022-06-21 12:56:00.964826
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-21 12:56:05.565235
# Unit test for function path_absent
def test_path_absent():
    user_tmp: Path = Path(get_os_user().pw_dir).joinpath('tmp')
    test_path: Path = user_tmp.joinpath(
        'test_%s' % str(threading.currentThread().ident)
    )
    # Test that a single file is deleted
    test_file = test_path.joinpath('test_file.txt')
    test_file.write_text('test_data')
    path_absent(test_file)
    assert test_file.exists() is False
    # Test that a single directory is deleted
    test_dir = test_path.joinpath('test_dir')
    test_dir.mkdir(parents=True, exist_ok=True)
    path_absent(test_dir)
    assert test_dir.exists() is False
   

# Generated at 2022-06-21 12:56:07.567749
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for ``get_os_user()``."""
    user = get_os_user()
    assert user.pw_name == getpass.getuser()



# Generated at 2022-06-21 12:56:10.231248
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(name='bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo'])


# Generated at 2022-06-21 12:56:15.427586
# Unit test for function get_os_user
def test_get_os_user():
    """Test cases for function get_os_user"""
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == getpass.getuser()
    user = get_os_user('root')
    assert user.pw_name == 'root'
    try:
        get_os_user(0)
    except OSError as excinfo:
        assert 'uid: 0' in str(excinfo)
    try:
        get_os_user('user_not_exist')
    except OSError as excinfo:
        assert 'name: \'user_not_exist\'' in str(excinfo)
    user = get_os_user(1000)
    assert isinstance(user, pwd.struct_passwd)

# Generated at 2022-06-21 12:56:17.286246
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user(1000) == pwd.getpwuid(1000)
    assert get_os_user('mike') == pwd.getpwnam('mike')
    assert get_os_user() == pwd.getpwnam(getpass.getuser())



# Generated at 2022-06-21 12:56:19.739954
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
# ...



# Generated at 2022-06-21 12:56:32.457349
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group(), grp.struct_group)
    assert get_os_group()
    assert get_os_group() == grp.getgrgid(os.getgid())



# Generated at 2022-06-21 12:56:35.888282
# Unit test for function chown
def test_chown():
    out = chown()
    assert out is None


# Generated at 2022-06-21 12:56:47.411891
# Unit test for function normalize_path
def test_normalize_path():
    tmp_dir = Path(tempfile.mkdtemp()).resolve()
    tmp_file = Path(tempfile.NamedTemporaryFile().name).resolve()
    tmp_file.touch()
    env_var_key = '__TMP_ENV_VAR__'
    env_var_value = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    env_var = '$%s' % env_var_key
    os.environ[env_var_key] = env_var_value
    test_dir = Path(os.path.join(tmp_dir, 'tmp'))
    test_file = Path(os.path.join(test_dir, 'test'))
    test_dir.mkdir(parents=True)

# Generated at 2022-06-21 12:56:56.964546
# Unit test for function chmod
def test_chmod():
    import os
    import stat

    from .osutils import remove_file, remove_path

    from .testing import (
        an_existing_directory,
        an_existing_file,
        an_existing_link,
        an_existing_symlink_to_a_directory,
        an_existing_symlink_to_a_file,
        a_glob_pattern_of_an_existing_file,
    )

    path1 = an_existing_directory
    path2 = an_existing_file
    path3 = an_existing_link
    path4 = an_existing_symlink_to_a_file
    path5 = an_existing_symlink_to_a_directory
    path6 = a_glob_pattern_of_an_existing_file


# Generated at 2022-06-21 12:56:57.600124
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-21 12:57:05.319319
# Unit test for function path_absent
def test_path_absent():
    path = Path(tempfile.mkdtemp())
    p: Path
    for p in (
            path / 'foo',
            path / 'bar',
            path / 'foo' / 'baz',
            path / 'foo' / 'bat',
            path / 'one' / 'two' / 'three',
            (path / 'one' / 'two' / 'four').as_posix(),
    ):
        p.mkdir(parents=True, exist_ok=True)

# Generated at 2022-06-21 12:57:15.421174
# Unit test for function get_os_group
def test_get_os_group():
    # Test with an name and a gid, both of which should exist.
    os_group = get_os_group('bar')
    assert os_group.gr_gid == 2001
    # Test with a gid that should NOT exist.
    with pytest.raises(OSError) as excinfo:
        get_os_group(2001)
    assert str(excinfo.value) == (
        'The given gid: 2001, is not a valid gid for this '
        'operating system.'
    )
    # Test with a name that should NOT exist.
    with pytest.raises(OSError) as excinfo:
        get_os_group('barbar')

# Generated at 2022-06-21 12:57:26.202299
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from pathlib import Path

    from flutils.osutils import remove_directory

    test_path = Path('~/tmp/flutils.tests.pathutils.directory_present')
    if test_path.exists() is True:
        remove_directory(test_path)

    res = directory_present(test_path)
    assert isinstance(res, Path)
    assert res == test_path

    res = directory_present(test_path, mode=0o700, user='root', group='_appserverusr')
    assert isinstance(res, Path)
    assert res == test_path
    # This directory should already exist so this will raise an error
    # and the test will fail.

# Generated at 2022-06-21 12:57:32.180528
# Unit test for function find_paths
def test_find_paths():
    TEST_PATHS = {
        '/home/test_user/tmp/file_one',
        '/home/test_user/tmp/dir_one',
        '/home/test_user/tmp/dir_two',
    }

    with path_context('/home/test_user/tmp', TEST_PATHS) as paths:
        found_paths = list(find_paths('/home/test_user/tmp/*'))
        assert set(found_paths) == paths



# Generated at 2022-06-21 12:57:37.889766
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    try:
        get_os_user()
    except OSError:
        pass
    get_os_user('root')
    try:
        get_os_user(0)
    except OSError:
        pass
    get_os_user(int(getpass.getuser()))

# Generated at 2022-06-21 12:57:55.324270
# Unit test for function get_os_group
def test_get_os_group():
    user = os.getenv('USER')
    if os.getenv('USER') == 'root':
        os.environ['USER'] = 'root'
        assert os.getenv('USER') == get_os_group().gr_name
        assert os.getgid() == get_os_group().gr_gid
    else:
        # We are not root but need to be for this test.
        try:
            os.setegid(0)
        except OSError:
            assert True
        else:
            assert os.getenv('USER') == get_os_group().gr_name
            assert os.getgid() == get_os_group().gr_gid

    os.environ['USER'] = user




# Generated at 2022-06-21 12:58:04.785692
# Unit test for function exists_as
def test_exists_as():
    """Tests for function exists_as"""
    from unittest.mock import MagicMock
    from unittest.mock import patch

    path = MagicMock()
    path.is_dir.return_value = False
    path.is_file.return_value = False
    path.is_block_device.return_value = False
    path.is_char_device.return_value = False
    path.is_fifo.return_value = False
    path.is_socket.return_value = False

    patch_obj = patch(
        'flutils.pathutils.normalize_path',
        MagicMock(return_value=path)
    )
    with patch_obj as mock_normalize_path:
        assert exists_as(path) == ''
        mock_normalize_path.assert_called

# Generated at 2022-06-21 12:58:13.730008
# Unit test for function path_absent
def test_path_absent():
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_path = Path(tmp_dir.name)
    # Make a test file
    tmp_file = os.path.join(tmp_path.as_posix(), 'test_file')
    with open(tmp_file, 'w+') as tmp_file_obj:
        tmp_file_obj.write("Test File")
    # Make a test dir
    tmp_dir_path = os.path.join(tmp_path.as_posix(), 'test_dir')
    tmp_dir_obj = os.mkdir(tmp_dir_path)
    tmp_dir_file = os.path.join(tmp_dir_path, 'test_file')
    with open(tmp_dir_file, 'w+') as tmp_dir_file_obj:
        tmp_

# Generated at 2022-06-21 12:58:23.222723
# Unit test for function find_paths
def test_find_paths():
    import os
    import tempfile
    from pathlib import Path
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        with open(file_one, 'w') as f:
            f.write('file_one')
        dir_one = tmpdir / 'dir_one'
        os.mkdir(dir_one)
        assert list(find_paths(tmpdir.as_posix() + '/*')) == [
            Path('%s/file_one') % tmpdir,
            Path('%s/dir_one') % tmpdir
        ]

# Generated at 2022-06-21 12:58:29.684352
# Unit test for function get_os_group
def test_get_os_group():
    """ ``get_os_group()`` unit tests. """
    from flutils.pathutils import get_os_group

    # Test default name of get_os_group
    assert get_os_group().gr_name == grp.getgrgid(os.getgid()).gr_name

    # Test name by group id
    assert get_os_group(10).gr_name == grp.getgrgid(10).gr_name

    # Test name by group name
    assert get_os_group('wheel').gr_name == grp.getgrnam('wheel').gr_name

    # Test group name that does not exist
    try:
        get_os_group('not_a_group')
        assert False
    except OSError:
        assert True

    # Test gid that does not exist

# Generated at 2022-06-21 12:58:31.511250
# Unit test for function chmod
def test_chmod():
    pass

# Generated at 2022-06-21 12:58:38.442131
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    from flutils.pathutils import chmod
    tmpd = tempfile.mkdtemp(prefix='flutils')
    path = os.path.join(tmpd, 'chmod.txt')
    with open(path, 'w') as fh:
        fh.write('This is a test file')
    chmod(path, mode_file=0o660)
    mode = os.stat(path).st_mode
    assert mode == 33152

# Generated at 2022-06-21 12:58:44.352602
# Unit test for function get_os_group
def test_get_os_group():
    import flutils.osutils as osutils
    assert isinstance(osutils.get_os_group('root'), osutils.grp.struct_group)
    assert isinstance(osutils.get_os_group(0), osutils.grp.struct_group)
    assert isinstance(osutils.get_os_group(osutils.get_os_user().pw_gid), osutils.grp.struct_group)



# Generated at 2022-06-21 12:58:52.967480
# Unit test for function exists_as
def test_exists_as():
    ddir = Path('/tmp/flutils_test/')
    dir_path = ddir / 'dir_exists'
    dir_path.mkdir(parents=True, exist_ok=True)
    file_path = ddir / 'file_exists'
    file_path.touch()
    assert exists_as(dir_path) == 'directory'
    assert exists_as(file_path) is True
    assert exists_as(ddir) is False
    ddir.rmdir()
    
test_exists_as()



# Generated at 2022-06-21 12:59:05.724021
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths()."""

# Generated at 2022-06-21 12:59:33.144317
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    import getpass
    import grp
    import os

    assert get_os_group() == grp.getgrgid(os.getgid())
    assert get_os_group(getpass.getuser()) == \
        grp.getgrnam(getpass.getuser())
    assert get_os_group(os.getgid()) == grp.getgrgid(os.getgid())



# Generated at 2022-06-21 12:59:37.277968
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    from flutils.pathutils import normalize_path
    from pathlib import PosixPath, WindowsPath
    if os.name == 'nt':
        assert isinstance(normalize_path('~/tmp/foo/../bar'), WindowsPath)
    else:
        assert isinstance(normalize_path('~/tmp/foo/../bar'), PosixPath)



# Generated at 2022-06-21 12:59:49.521770
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as temp_dir:
        directory = Path(temp_dir)
        file_one = directory / 'file_one'
        file_two = directory / 'file_two'
        dir_one = directory / 'dir_one'
        dir_two = directory / 'dir_two'

        file_one.touch()
        file_two.touch()
        dir_one.mkdir()
        dir_two.mkdir()

        expected = [file_one, dir_one]
        results = list(find_paths(directory / '*'))
        assert expected == results

        expected = [dir_one]
        results = list(find_paths(directory / 'dir_one'))
        assert expected == results


# Generated at 2022-06-21 12:59:58.250405
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present as _dp

    target_dir = _dp('~/tmp/flutils.tests.pathutils/directory_present', mode=0o770)

    assert target_dir.as_posix() == '~/tmp/flutils.tests.pathutils/directory_present'
    assert target_dir.is_dir()

    target_dir = _dp('~/tmp/flutils.tests.pathutils/directory_present/inner_1')

    assert target_dir.as_posix() == '~/tmp/flutils.tests.pathutils/directory_present/inner_1'
    assert target_dir.is_dir()

    target_dir = _dp('~/tmp/flutils.tests.pathutils/directory_present/inner_1/inner_2')

    assert target_dir

# Generated at 2022-06-21 13:00:00.465607
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    assert directory_present('/tmp/foo') == Path('/tmp/foo')
    assert directory_present('/tmp') == Path('/tmp')



# Generated at 2022-06-21 13:00:12.226179
# Unit test for function chown
def test_chown():
    from os import mkdir, rmdir
    from pathlib import Path
    from tempfile import gettempdir
    from unittest import TestCase
    from .datautils import make_test_path, remove_test_path

    # Default chown
    path = make_test_path(gettempdir(), 'test_chown.txt', is_file=True)
    pw = getpwnam(getuser())
    gr = getgrgid(pw[3])
    chown(path)
    assert Path(path).stat().st_uid == pw[2]
    assert Path(path).stat().st_gid == gr[2]
    remove_test_path(path)

    # Change user, leave group

# Generated at 2022-06-21 13:00:16.598298
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user()
    get_os_user(None)
    get_os_user(0)
    get_os_user('foo')
    try:
        get_os_user(777)
        assert False
    except OSError:
        pass



# Generated at 2022-06-21 13:00:22.043304
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/loop0') == 'block device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/log') == 'socket'
    assert exists_as('/var/log/daemon.log') == ''


# Generated at 2022-06-21 13:00:34.782322
# Unit test for function get_os_user
def test_get_os_user():
    import pwd
    import grp
    import os
    with open(os.devnull, 'w') as devnull:
        with contextlib.redirect_stderr(devnull):
            with contextlib.redirect_stdout(devnull):
                get_os_user('root')
                get_os_user('test_user')
                get_os_user(0)
                get_os_user(1001)
                get_os_user(1002)
                get_os_user(1003)
                get_os_user(1004)
                get_os_user(1005)
                get_os_user(1006)
                get_os_user(1007)
                get_os_user(1008)
                get_os_user(1009)

# Generated at 2022-06-21 13:00:46.745950
# Unit test for function chown
def test_chown():
    Path('/tmp/flutils.tests.osutils.txt').chmod(0o644)
    Path('/tmp/flutils.tests.osutils.txt').unlink()

# Generated at 2022-06-21 13:01:11.708217
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'

# Generated at 2022-06-21 13:01:23.032049
# Unit test for function chown
def test_chown():
    from tempfile import NamedTemporaryFile
    from uuid import uuid4
    from .osutils import get_os_group
    from .osutils import get_os_user

    # FIXME: This test needs a mock for Path.glob().
    #        This is VERY tricky as the function
    #        tested ends up calling Path.glob()
    #        internally.
    #
    # For now, just test with a simple file.
    with NamedTemporaryFile(dir='/tmp') as fp:
        chown(fp.name)
        assert get_os_user(os.stat(fp.name).st_uid).pw_name == getpass.getuser()
        assert get_os_group(os.stat(fp.name).st_gid).gr_name == getpass.getuser()

        current_

# Generated at 2022-06-21 13:01:31.096790
# Unit test for function chmod
def test_chmod():
    _test_chmod = os.getenv('FLUTILS_TEST_CHMOD', '')
    if not _test_chmod:
        return
    _test_mode = int(_test_chmod)
    temp_path = Path(
        '/tmp/flutils.osutils.chmod.{user}.{mode}.tmp'.format(
            mode=_test_mode,
            user=getpass.getuser(),
        )
    )
    try:
        if temp_path.exists():
            temp_path.unlink()
        chmod(temp_path, mode_file=_test_mode)
        assert temp_path.stat().st_mode & 0o777 == (_test_mode & 0o777)
    finally:
        temp_path.unlink()

# Generated at 2022-06-21 13:01:37.907417
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group

    test_group = get_os_group('bar')
    assert test_group.gr_name == 'bar'
    assert test_group.gr_passwd == '*'
    assert test_group.gr_gid == 2001
    assert test_group.gr_mem == ['foo']



# Generated at 2022-06-21 13:01:48.965327
# Unit test for function get_os_group
def test_get_os_group():
    from typing import Union
    from flutils.pathutils import get_os_group
    from flutils.testing import make_data_path
    from flutils.testing import run_pytest
    from flutils.testing import TestCase


    def _get_os_group(name: Union[str, int]) -> str:
        return cast(str, get_os_group(name).gr_name)


    class TestGetOSGroup(TestCase):
        def test_get_os_group_str(self):
            result = _get_os_group('bar')
            self.assertEqual(result, 'bar')


        def test_get_os_group_int(self):
            result = _get_os_group(2001)
            self.assertEqual(result, 'bar')



# Generated at 2022-06-21 13:01:54.125607
# Unit test for function get_os_group
def test_get_os_group():
    """Test for function get_os_group."""
    assert get_os_group()
    assert get_os_group(get_os_group().gr_gid)
    assert get_os_group(get_os_group().gr_name)



# Generated at 2022-06-21 13:02:02.671030
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import _PATH
    from flutils.pathutils import exists_as
    existing_path = './test/test_data/test.txt'
    assert exists_as(existing_path) == 'file'
    assert exists_as(existing_path) == exists_as(_PATH(existing_path))
    assert exists_as('./test/test_data/test_dir') == 'directory'
    assert exists_as('./test/test_data/test_not_exists') == ''
    assert exists_as('./test/test_data/test_no_access') == ''
    assert exists_as('./test/test_data/test_broken_link.txt') == ''
    assert exists_as('./test/test_data/test_broken_link/') == ''

# Generated at 2022-06-21 13:02:15.132634
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('/tmp/flutils', mode_dir=0o775)
    path = directory_present(path / 'foo')
    path = directory_present(path / 'bar')
    with path.joinpath('file.txt').open('a') as fh:
        fh.write('hello world')

    assert path.stat().st_mode == 0o40755
    assert path.parent.stat().st_mode == 0o40755
    assert path.parent.parent.stat().st_mode == 0o40755
    assert path.joinpath('file.txt').stat().st_mode == 0o100644

    stat_ = os.stat(path.joinpath('file.txt').as_posix())
    assert stat_.st_uid == os.getuid()

# Generated at 2022-06-21 13:02:17.232500
# Unit test for function get_os_user
def test_get_os_user():
    USER = getpass.getuser()
    NAME = get_os_user().pw_name
    UID = get_os_user().pw_uid
    return [USER == NAME, UID == pwd.getpwuid(UID)[2]]



# Generated at 2022-06-21 13:02:24.934884
# Unit test for function get_os_group
def test_get_os_group():
    print(get_os_group())
    print(get_os_group('root'))
    print(get_os_group('admin'))
    print(get_os_group(0))
    print(get_os_group(20))
    try:
        print(get_os_group('foo'))
    except OSError:
        pass



# Generated at 2022-06-21 13:02:53.592895
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from pathlib import Path

    assert exists_as(Path('/dev/null')) == 'char device'



# Generated at 2022-06-21 13:02:56.252501
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    chmod(path, 0o660)



# Generated at 2022-06-21 13:02:59.241586
# Unit test for function chmod
def test_chmod():
    assert chmod(
        '~/tmp/flutils.testutils.osutils.test_chmod.txt',
        0o660, 0o770) is None



# Generated at 2022-06-21 13:03:09.760146
# Unit test for function chmod
def test_chmod():
    import tempfile

    raw_data = [
        (0o666, 0o777),
        (0o773, 0o764),
    ]
    for mode_dir, mode_file in raw_data:
        with tempfile.TemporaryDirectory() as testdir:

            # Create a directory to test chmod on
            testdir = Path(testdir)
            testdir.mkdir(mode=0o700, parents=True)
            assert testdir.stat().st_mode & 0o777 == 0o700

            # Create a file to test chmod on
            testfile = testdir / 'testfile.txt'
            with open(testfile, 'w') as fh:
                fh.write('testing')
            assert testfile.stat().st_mode & 0o777 == 0o666

            # Now test it


# Generated at 2022-06-21 13:03:19.753055
# Unit test for function path_absent
def test_path_absent():
    # Test the path_absent function
    tmp_path: Path = Path('~/tmp').expanduser()
    tmp_base: Path = tmp_path / 'flutils_path_absent_test_base'
    tmp_base.mkdir(parents=True, exist_ok=True)
    os.chdir(tmp_base)
    test_dir_one: Path = Path('test_dir_one')
    test_dir_one.mkdir(parents=True, exist_ok=True)
    with open(test_dir_one / 'test_file_one', 'w') as test_file:
        test_file.write('test')
    test_dir_two: Path = test_dir_one / 'test_dir_two'

# Generated at 2022-06-21 13:03:29.360679
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/dev/zero') == 'character device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/urandom') == 'character device'
    assert exists_as('/dev/tty') == 'character device'
    assert exists_as('/dev/tty0') == 'character device'
    assert exists_as('/dev/tty1') == 'character device'
    assert exists_as('/dev/tty2') == 'character device'
    assert exists_as('/dev/tty3') == 'character device'
    assert exists_as('/dev/tty4') == 'character device'
    assert exists_as('/dev/tty5') == 'character device'
    assert exists_as

# Generated at 2022-06-21 13:03:35.059025
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        fpath = tmpdir / 'foo'
        fpath.write_text('test text')
        dpath = tmpdir / 'bar'
        dpath.mkdir()
        spath = dpath / 'file_one'
        spath.symlink_to(fpath, target_is_directory=False)
        cpath = dpath / 'file_two'
        cpath.touch()
        path_absent(tmpdir)
        assert not os.path.exists(tmpdir)



# Generated at 2022-06-21 13:03:46.670179
# Unit test for function chmod
def test_chmod():
    import stat
    from tempfile import TemporaryDirectory
    from pathlib import PosixPath

    with TemporaryDirectory(prefix='/tmp/flutils.tests.osutils.') as tmp:
        tmp_path = PosixPath(tmp)

        # Prepare paths.
        file1 = (tmp_path / 'file1.txt').expanduser()
        file2 = (tmp_path / 'file2.txt').expanduser()
        dir1 = (tmp_path / 'dir1').expanduser()
        dir2 = (tmp_path / 'dir2').expanduser()

        file1.write_text('unit test')
        file2.write_text('unit test')
        dir1.mkdir()
        dir2.mkdir()

        # Test setting modes with default modes.
        chmod(file1)
        assert file

# Generated at 2022-06-21 13:03:53.316306
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('${HOME}/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('foo/../bar') == Path('/home/test_user/foo/../bar')



# Generated at 2022-06-21 13:04:02.160814
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/foo/../bar')
    assert path.as_posix() == os.path.normpath(os.path.join('~/tmp/foo/../bar'))

    path = normalize_path('/tmp/foo/../bar')
    assert path.as_posix() == os.path.normpath('/tmp/foo/../bar')

    path = normalize_path('$HOME/tmp/foo/../bar')
    assert path.as_posix() == os.path.normpath(
        os.path.expandvars('$HOME/tmp/foo/../bar')
    )

    path = normalize_path(Path('tmp/foo/../bar'))

# Generated at 2022-06-21 13:04:36.122446
# Unit test for function exists_as
def test_exists_as():

    # Setup exists_as test
    test_file = Path('%s/%s' % (TEST_DIR, 'exists_as.txt'))
    test_file_mode = 0o700
    open(test_file, 'w').close
    chmod(test_file, mode_file=test_file_mode)

    assert exists_as(test_file) == 'file'

    # Setup exists_as test
    test_dir = Path('%s/%s' % (TEST_DIR, 'exists_as'))
    test_dir_mode = 0o700
    os.mkdir(test_dir)
    chmod(test_dir, mode_dir=test_dir_mode)

    assert exists_as(test_dir) == 'directory'


# Generated at 2022-06-21 13:04:46.117765
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp') == Path('~/tmp')
    assert normalize_path('~/tmp').as_posix() == '~/tmp'
    assert normalize_path('/tmp') == Path('/tmp')
    assert normalize_path('/tmp').as_posix() == '/tmp'
    assert normalize_path(Path('~/tmp')) == Path('~/tmp')
    assert normalize_path(Path('~/tmp')).as_posix() == '~/tmp'
    assert normalize_path(Path('/tmp')) == Path('/tmp')
    assert normalize_path(Path('/tmp')).as_posix() == '/tmp'



# Generated at 2022-06-21 13:04:52.756096
# Unit test for function get_os_group
def test_get_os_group():
    # test for a valid gid
    assert get_os_group(0).gr_gid == 0
    # test for a valid group name
    assert get_os_group('root').gr_name == 'root'
    # test for a group name that does not exist
    with pytest.raises(OSError):
        get_os_group('does_not_exist')



# Generated at 2022-06-21 13:04:59.073088
# Unit test for function get_os_group
def test_get_os_group():
    """Test for function get_os_group."""
    assert get_os_group('root').gr_gid == 0
    assert get_os_group('root').gr_name == 'root'
    assert get_os_group('root').gr_gid == get_os_user('root').pw_gid



# Generated at 2022-06-21 13:05:01.150861
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'



# Generated at 2022-06-21 13:05:11.736929
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""

# Generated at 2022-06-21 13:05:19.969654
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent

    path = os.path.join('/tmp', 'test_filler.txt')
    with open(path, 'w+') as f:
        pass
    path_absent(path)
    assert os.path.exists(path) is False

    path = os.path.join('/tmp', 'test_dir')
    os.mkdir(path)
    path_absent(path)
    assert os.path.exists(path) is False

