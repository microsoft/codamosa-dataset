

# Generated at 2022-06-21 12:56:22.186306
# Unit test for function directory_present
def test_directory_present():
    from os import makedirs, unlink
    from tempfile import mkdtemp

    path = Path(mkdtemp())
    dir_path = path / 'test_directory'
    file_path = path / 'test_file.txt'

    makedirs(dir_path.as_posix())
    with open(file_path.as_posix(), 'w') as fp:
        fp.write('test_data')


# Generated at 2022-06-21 12:56:25.835901
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/dev/tty') == 'char device'



# Generated at 2022-06-21 12:56:34.243833
# Unit test for function find_paths
def test_find_paths():
    '''
    Unit test for function find_paths
    '''
    from os.path import expanduser
    from pathlib import PosixPath
    import pytest

    assert list(find_paths('~/tmp/*')) == [
        PosixPath(expanduser('~/tmp/file_one')),
        PosixPath(expanduser('~/tmp/dir_one'))
    ]

    # Test pattern with no results
    assert list(find_paths('~/tmp/foo*')) == []

    # Test Path() with no results
    assert list(find_paths(Path(
        expanduser('~/tmp/foo*')).as_posix()
    )) == []

    # Test Path() with a match

# Generated at 2022-06-21 12:56:35.347231
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 12:56:37.515862
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils')
    if path.exists():
        path.chown()



# Generated at 2022-06-21 12:56:41.803229
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.tests.paths import BUILD_PATH
    from flutils.tests.paths import TEST_FILE

    assert exists_as(TEST_FILE) == 'file'
    assert exists_as(BUILD_PATH) == 'directory'



# Generated at 2022-06-21 12:56:48.798559
# Unit test for function chmod
def test_chmod():
    # import time
    import random
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    mode_file = random.choice((0o600, 0o644, 0o660, 0o775, 0o770))
    mode_dir = random.choice((0o700, 0o774, 0o755, 0o770))
    path = tempfile.mkdtemp()

    path_file = Path(path) / 'flutils_chmod_test_file.txt'

    path_file.touch()
    chmod(path_file, mode_file)
    assert path_file.stat().st_mode & 0o777 == mode_file
    path_file.unlink()

    chmod(path, mode_dir)
    assert path.stat().st_mode & 0o777 == mode_dir

# Generated at 2022-06-21 12:56:59.617222
# Unit test for function get_os_user
def test_get_os_user():
    # verify current user
    assert get_os_user()[0] == getpass.getuser()
    # verify known user name
    assert get_os_user('root')[0] == 'root'
    # verify unknown user name
    with pytest.raises(OSError) as err:
        get_os_user('doesnotexist')
    assert 'doesnotexist' in str(err.value)
    # verify known uid
    assert get_os_user(0)[2] == 0
    # verify unknown uid
    with pytest.raises(OSError) as err:
        get_os_user(1)
    assert '1' in str(err.value)


# Generated at 2022-06-21 12:57:11.897585
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present, exists_as
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from pathlib import Path

    # Path pointing to a directory.
    with TemporaryDirectory(
            prefix='flutils-test-',
            dir='/tmp'
    ) as tmpdir:
        assert exists_as(tmpdir) == 'directory'

    # Path pointing to a file.
    with NamedTemporaryFile(
            prefix='flutils-test-',
            dir='/tmp'
    ) as tmpfile:
        assert exists_as(tmpfile.name) == 'file'

    # Path pointing to a symbolic link.

# Generated at 2022-06-21 12:57:23.771473
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    tmpdir = tempfile.mkdtemp()
    testdir = os.path.join(tmpdir, 'dir')
    os.mkdir(testdir)
    testfile = os.path.join(tmpdir, 'file')
    open(testfile, 'w').close()

    os.chmod(testdir, 0o700)
    os.chmod(testfile, 0o600)

    chmod(testdir, mode_file=0o644)
    assert stat.S_IMODE(os.lstat(testfile).st_mode) == 0o644

    chmod(testdir, mode_dir=0o775)
    assert stat.S_IMODE(os.lstat(testfile).st_mode) == 0o644


# Generated at 2022-06-21 12:58:25.227158
# Unit test for function directory_present
def test_directory_present():
    from flutils.testutils import TempDirTestCase

    class TestDirectoryPresent(TempDirTestCase):

        def test_directory_present_absolute_path(self):
            result = directory_present(
                self._test_dir.joinpath(
                    'test_directory_present1',
                    'test_directory_present2',
                    'test_directory_present3.txt'
                ).as_posix()
            )
            self.assertEqual(
                str(result),
                self._test_dir.joinpath(
                    'test_directory_present1',
                    'test_directory_present2'
                ).as_posix()
            )


# Generated at 2022-06-21 12:58:28.027525
# Unit test for function get_os_group
def test_get_os_group():
    os_group = get_os_group()
    assert hasattr(os_group, 'gr_name')
    assert hasattr(os_group, 'gr_gid')
    assert hasattr(os_group, 'gr_passwd')
    assert hasattr(os_group, 'gr_mem')



# Generated at 2022-06-21 12:58:34.427345
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    try:
        get_os_user('foo')
    except OSError as err:
        if 'is not a valid "login name"' not in str(err):
            raise
    else:
        raise



# Generated at 2022-06-21 12:58:40.690535
# Unit test for function path_absent
def test_path_absent():
    if os.path.exists('tests/tmp/test_path.txt'):
        os.unlink('tests/tmp/test_path.txt')
    if os.path.exists('tests/tmp/test_path'):
        os.rmdir('tests/tmp/test_path')
    path_absent('tests/tmp/test_path.txt')
    path_absent('tests/tmp')



# Generated at 2022-06-21 12:58:53.513699
# Unit test for function exists_as
def test_exists_as():
    """Test function: exists_as."""

# Generated at 2022-06-21 12:59:06.237737
# Unit test for function get_os_user
def test_get_os_user():
    # Tuple[str, str, int, int, str, str, str]
    pwd.struct_passwd = namedtuple(
        'struct_passwd', 'pw_name, pw_passwd, pw_uid, pw_gid, pw_gecos, '
        'pw_dir, pw_shell'
    )
    os_user = pwd.struct_passwd(
        pw_name='test_user', pw_passwd='********', pw_uid=1001, pw_gid=2001,
        pw_gecos='Test User', pw_dir='/home/test_user',
        pw_shell='/usr/local/bin/bash'
    )

# Generated at 2022-06-21 12:59:07.610367
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group().gr_name == 'test_user'
    assert get_os_group(-1).gr_name == 'test_user'



# Generated at 2022-06-21 12:59:13.001806
# Unit test for function path_absent
def test_path_absent():
    assert os.path.isdir('/tmp/test_path_absent') is False
    os.mkdir('/tmp/test_path_absent')
    assert os.path.isdir('/tmp/test_path_absent') is True
    path_absent('/tmp/test_path_absent')
    assert os.path.isdir('/tmp/test_path_absent') is False



# Generated at 2022-06-21 12:59:16.220922
# Unit test for function chown
def test_chown():
    return_value = chown('~/tmp/flutils.tests.osutils.txt')
    assert return_value is None


# Generated at 2022-06-21 12:59:28.262982
# Unit test for function get_os_user
def test_get_os_user():
    if os.getuid() == 0:
        print('This function cannot be unit tested when running with root.')
        return
    try:
        user = get_os_user(os.getuid())
    except OSError:
        print('Error: unable to get the current user!')
        return

    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == os.getuid()

    try:
        user = get_os_user(user.pw_name)
    except OSError:
        print('Error: unable to get the current user!')
        return

    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == os.getuid()


# Generated at 2022-06-21 13:00:25.079269
# Unit test for function path_absent
def test_path_absent():
    tmpdir: str = tempfile.mkdtemp()

# Generated at 2022-06-21 13:00:37.829993
# Unit test for function normalize_path
def test_normalize_path():
    try:
        path_b = os.fsencode(b'/tmp/foo')
    except AttributeError:
        # On Python 3.5 os.fsencode() does not exist.
        path_b = cast(_PATH, b'/tmp/foo')
    path_p = Path('/tmp/foo')

    path = Path(__file__).parent
    cwd = os.getcwd()
    path = path.as_posix()
    os.chdir(path)

    assert normalize_path(path) == Path(path)
    assert normalize_path(path_b) == Path(path)
    assert normalize_path(path_p) == Path(path)

    path = os.path.join(path, '..')
    path = os.path.normpath(path)
    path = os

# Generated at 2022-06-21 13:00:38.490437
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-21 13:00:49.299666
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    os_group = get_os_group()
    assert isinstance(os_group.gr_name, str)
    assert isinstance(os_group.gr_passwd, str)
    assert isinstance(os_group.gr_gid, int)
    assert isinstance(os_group.gr_mem, list)

    if IS_POSIX is True:
        assert os_group.gr_name == 'wheel'
        assert os_group.gr_passwd == '*'
        assert os_group.gr_gid == 0
        assert os_group.gr_mem == ['root']

    if IS_WINDOWS is True:
        assert os_group.gr_name == 'Users'
        assert os_group.gr_passwd == '*'
        assert os

# Generated at 2022-06-21 13:01:01.523158
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    test_dir = Path('~/tmp/test_path').expanduser()
    if test_dir.exists():
        rmtree(test_dir)
    test_dir.mkdir(parents=True)
    file_one = test_dir / 'file_one'
    file_one.touch()
    file_two = test_dir / 'file_two'
    file_two.touch()
    dir_one = test_dir / 'dir_one'
    dir_one.mkdir()
    dir_two = test_dir / 'dir_two'
    dir_two.mkdir()
    sub_dir = dir_one / 'sub_dir'
    sub_dir.mkdir()
    readme = sub_dir / 'README.txt'
    read

# Generated at 2022-06-21 13:01:03.673902
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/foo/../bar')
    home = os.path.expanduser('~')
    assert path == Path(os.path.join(home, 'tmp', 'bar'))
# Test: test_normalize_path



# Generated at 2022-06-21 13:01:14.084641
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir_path = Path(temp_dir)

        # Test with path=None
        with pytest.raises(TypeError):
            directory_present(None)

        # Test with path=None, user='foo'
        with pytest.raises(TypeError):
            directory_present(None, user='foo')

        # Test with empty path
        with pytest.raises(ValueError):
            directory_present('')

        # Test with empty path, user='foo'
        with pytest.raises(ValueError):
            directory_present('', user='foo')

        # Test with path=temp_dir_path, user='foo'
        temp_dir_path = directory_present(temp_dir_path, user='root')


# Generated at 2022-06-21 13:01:26.097297
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from flutils import pathutils


    with TemporaryDirectory(prefix='flutils_test', dir='~/tmp') as temp_dir:
        temp_dir = Path(temp_dir)
        assert temp_dir.is_dir() is True
        temp_file = temp_dir / 'temp_file.txt'
        assert temp_file.is_file() is False
        temp_file.write_text('A test file.')
        assert temp_file.is_file() is True
        directory = temp_dir / 'a_dir'
        assert directory.is_dir() is False
        pathutils.directory_present(directory, mode=0o755)
        assert directory.is_dir() is True
        assert directory.stat().st_mode == 0o40755

# Generated at 2022-06-21 13:01:26.706607
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-21 13:01:33.471009
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function."""
    path = os.sep.join(['foo', 'bar'])
    path = normalize_path(path)
    assert path.as_posix() == os.path.abspath(path)
    assert path.is_absolute()
    assert path.anchor == '/'



# Generated at 2022-06-21 13:01:58.390474
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar').gr_gid == 2001



# Generated at 2022-06-21 13:02:05.376691
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp:
        path = str(Path(tmp, 'foo.txt'))
        Path(path).touch()
        assert Path(path).chown() == -1
        chown(path)
        assert Path(path).chown() == os.getuid()

        chown(path, user='-1')
        assert Path(path).chown() == -1

        chown(path, group='-1')
        assert Path(path).chgrp() == -1

    try:
        chown('', user='root')
    except OSError:
        pass
    else:
        assert False



# Generated at 2022-06-21 13:02:09.996890
# Unit test for function get_os_user
def test_get_os_user():
    from unittest import TestCase
    from unittest.mock import patch

    from .contextutils import forced_env
    from .testingutils import random_string

    class GetOSUserTestCase(TestCase):
        def test_no_name(self):
            res = get_os_user()
            self.assertIsInstance(res, pwd.struct_passwd)
            if os.name == 'nt':
                self.assertEqual(res.pw_name, os.environ['USERNAME'])
            else:
                self.assertEqual(res.pw_name, getpass.getuser())

        def test_uid(self):
            res = get_os_user(0)
            self.assertIsInstance(res, pwd.struct_passwd)

# Generated at 2022-06-21 13:02:13.173424
# Unit test for function get_os_group
def test_get_os_group():
    # pylint: disable=unused-variable
    assert isinstance(
        get_os_group('nobody'),
        grp.struct_group
    )

# Generated at 2022-06-21 13:02:21.488033
# Unit test for function chmod
def test_chmod():
    import pytest

    from flutils.pathutils import (
        chmod,
        path_absent,
    )

    from flutils.tests._constants import (
        TMP_DIR,
    )

    from .test_osutils import which

    from .test_fileutils import ( # pylint: disable=unused-variable
        tmp_file_present,
        tmp_directory_present,
    )

    ##########################################################################
    # chmod()
    ##########################################################################

    # -----------------------------------------------------
    # Tests for issues identified by coverage.py's "missing"
    # -----------------------------------------------------

    # Test find_paths() with a non-matching glob pattern
    # See: https://coverage.readthedocs.io/en/coverage-5.3/missing.html
    assert list

# Generated at 2022-06-21 13:02:22.161408
# Unit test for function get_os_user
def test_get_os_user():
    pass



# Generated at 2022-06-21 13:02:29.363479
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user(name='root').pw_uid == 0
    assert get_os_user(name=0).pw_uid == 0
    assert get_os_user(name=0).pw_name == 'root'
    assert get_os_user(name='root').pw_name == 'root'
    with pytest.raises(OSError):
        get_os_user(name='not_a_real_user')
    with pytest.raises(OSError):
        get_os_user(name=99999)



# Generated at 2022-06-21 13:02:41.545388
# Unit test for function find_paths
def test_find_paths():
    home = Path.home()
    testdir = home.joinpath('tmp/flutils.tests.pathutils')
    testdir.mkdir(parents=True, exist_ok=True)
    path_one = testdir.joinpath('file_one.txt')
    with open(path_one, 'w') as test_file:
        test_file.write('test_file')
    path_two = testdir.joinpath('file_two.txt')
    with open(path_two, 'w') as test_file:
        test_file.write('test_file')
    dir_one = testdir.joinpath('dir_one')
    dir_one.mkdir()

    paths = list(find_paths('~/tmp/*'))

# Generated at 2022-06-21 13:02:45.621574
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar').gr_name == 'bar'
    if os.name == 'posix':
        assert get_os_group('root').gr_gid == 0
    elif os.name == 'nt':
        assert get_os_group('S-1-5-32-544').gr_gid == 544
    else:
        assert get_os_group('wheel').gr_gid == 0



# Generated at 2022-06-21 13:02:50.605586
# Unit test for function path_absent
def test_path_absent():
    """Test path_absent
    """

    def _cleanup():
        try:
            path_absent(tmp_dir)
        except Exception as e:
            print("Caught: %r" % e)

    # Create a temp directory
    test_dir = Path(__file__).resolve().parent
    cm: TestCase = TestCase('__init__')
    tmp_dir = TestCase.get_temp_dir(test_dir)
    cm.addCleanup(_cleanup)
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_dir = normalize_path(tmp_dir)

    path_absent(tmp_dir)
    assert tmp_dir.exists() is False

    tmp_file = tmp_dir / 'tmp_file'

# Generated at 2022-06-21 13:03:16.123452
# Unit test for function chown
def test_chown():
    """Test the chown() function.
    """
    import os
    import pathlib
    import shutil
    import tempfile

    from unittest import TestCase

    from flutils import pathutils

    class _TestChown(TestCase):
        """Test for the chown() function.
        """

        def setUp(self):
            """Initialize each test.
            """
            self.tempdir = tempfile.mkdtemp(prefix='flutils.pathutils.')
            self.file_path = pathlib.Path(
                pathlib.Path(self.tempdir) / pathlib.Path('file.txt')
            )
            self.file_path.touch()

        def tearDown(self):
            """Clean-up each test.
            """
            shutil.rmtree(self.tempdir)

       

# Generated at 2022-06-21 13:03:23.943181
# Unit test for function get_os_user
def test_get_os_user():
    """Test for flutils.pathutils.get_os_user()."""
    from flutils.pathutils import get_os_user
    struct = get_os_user()
    assert struct.pw_name == getpass.getuser()
    struct = get_os_user('root')
    assert struct.pw_name == 'root'
    struct = get_os_user(0)
    assert struct.pw_name == 'root'



# Generated at 2022-06-21 13:03:28.244247
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    # test normalize_path
    path = normalize_path(r'~/foo')
    assert path == Path.home() / 'foo'
    path = normalize_path(r'$HOME/foo')
    assert path == Path.home() / 'foo'



# Generated at 2022-06-21 13:03:28.773636
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-21 13:03:30.082358
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group()
    assert get_os_group(0)


# Generated at 2022-06-21 13:03:36.474066
# Unit test for function chown
def test_chown():
    import pytest
    from os import fsync
    from os.path import join
    from tempfile import mkdtemp
    from unittest import mock

    from flutils.pathutils import chown

    temp_dir = mkdtemp()
    test_file = join(temp_dir, 'test_chown.txt')
    with open(test_file, 'w+') as fobj:
        fobj.write('flutils')
        fobj.flush()
        fsync(fobj.fileno())

    # 'user' and 'group' left as default values None
    with mock.patch.object(os, 'chown') as mock_chown:
        chown(test_file, include_parent=True)
        # Should try to chown the file and directory if
        # 'include_parent'=True and path is

# Generated at 2022-06-21 13:03:48.277747
# Unit test for function directory_present
def test_directory_present():
    path = normalize_path('./test_directory_present')
    test_path = directory_present(path)
    _mode = os.stat(test_path.as_posix()).st_mode
    assert test_path.exists() is True
    assert stat.S_ISDIR(_mode) is True
    _mode = stat.S_IMODE(_mode)
    assert _mode == 0o700
    assert test_path.name == 'test_directory_present'

    test_path.rmdir()
    assert test_path.exists() is False

    try:
        directory_present('~/foo/bar/**')
    except ValueError:
        True
    else:
        False

    try:
        directory_present('foo/bar')
    except ValueError:
        True

# Generated at 2022-06-21 13:03:50.229181
# Unit test for function get_os_group
def test_get_os_group():
    # noinspection PyUnresolvedReferences
    from . import osutils
    _ = osutils



# Generated at 2022-06-21 13:04:00.005955
# Unit test for function get_os_group
def test_get_os_group():
    """
    This function is the unit test for function `get_os_group`.
    """
    test_group = get_os_group('bar')
    assert isinstance(test_group, grp.struct_group), \
        'test_group is not instance of grp.struct_group'
    assert test_group.gr_name == 'bar', 'test_group.gr_name != \'bar\''
    assert test_group.gr_passwd == '*', 'test_group.gr_passwd != \'*\''
    assert test_group.gr_gid == 2001, 'test_group.gr_gid != 2001'
    assert test_group.gr_mem == ['foo'], 'test_group.gr_mem != [\'foo\']'
    test_group = get_os_group(2001)
   

# Generated at 2022-06-21 13:04:07.030027
# Unit test for function get_os_group
def test_get_os_group():
    user = get_os_user().pw_name
    group = get_os_user().pw_gid
    group = cast(int, group)
    group_object = get_os_group(user)
    assert group_object.gr_name == user
    assert group_object.gr_gid == group
    assert group_object.gr_mem == [user]
    group_object = get_os_group(group)
    assert group_object.gr_name == user
    assert group_object.gr_gid == group
    assert group_object.gr_mem == [user]
    with pytest.raises(OSError):
        get_os_group('foobar')



# Generated at 2022-06-21 13:04:56.928862
# Unit test for function directory_present
def test_directory_present():
    # Test creating a directory with different modes
    def _mkdir(mode_arg, mode_unpack):
        directory_present(
            '~/tmp/flutils_tests_pathutils/test_directory_present/%s' % mode_arg,
            mode=mode_unpack,
        )
        os_stat = os.stat('~/tmp/flutils_tests_pathutils/test_directory_present/%s' % mode_arg)
        assert (mode_unpack & 0xFFF) == (os_stat.st_mode & 0xFFF)

    _mkdir('0o654', 0o654)
    _mkdir('0o777', 0o777)
    _mkdir('0o654', 0o654)

    # Test creating a directory with different owners and groups

# Generated at 2022-06-21 13:05:08.899572
# Unit test for function find_paths
def test_find_paths():
    from sys import platform
    from pathlib import PosixPath, WindowsPath
    from flutils.pathutils import find_paths

    def get_path_type(pattern):
        if platform == 'win32':
            return WindowsPath
        return PosixPath

    def test_find_paths_case(pattern, expected_results):
        # type: (str, List[Union[PosixPath, WindowsPath]]) -> None
        result = list(find_paths(pattern))
        assert sorted(result) == sorted(expected_results)
        assert all(isinstance(path, get_path_type(pattern)) for path in result)
        assert all(path.is_absolute() for path in result)

    def test_find_paths_case__TRUE(pattern):
        # type: (str) -> None
        result = list

# Generated at 2022-06-21 13:05:15.241405
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.osutils import get_test_file_path
    from flutils.tests.osutils import make_test_file
    from flutils.tests.osutils import remove_test_file

    path = get_test_file_path('*')
    for name in ('file_one', 'file_two'):
        make_test_file(name)

    paths = find_paths(path)
    assert isinstance(paths, Generator)
    assert list(paths)
    remove_test_file('*')



# Generated at 2022-06-21 13:05:20.527114
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('/tmp/flutils.tests.pathutils.txt')) == 'file'
    assert exists_as(Path('/tmp/flutils.tests.pathutils')) == 'directory'
    assert exists_as(Path('/tmp/flutils.tests.pathutils.does_not_exist')) == ''

