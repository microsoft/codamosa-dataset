

# Generated at 2022-06-21 12:55:53.011368
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    assert path.exists() is False
    path.write_text('foo')
    assert path.is_file() is True
    chown(path.as_posix())
    assert path.exists() is True
    assert path.is_file() is True
    user = get_os_user()
    assert user.pw_uid == path.stat().st_uid
    assert user.pw_gid == path.stat().st_gid



# Generated at 2022-06-21 12:55:58.680458
# Unit test for function get_os_user
def test_get_os_user():
    _ = get_os_user()
    _ = get_os_user(1000)
    with pytest.raises(OSError) as excinfo:
        get_os_user(10002)
    assert 'uid: 10002, is not a valid uid' in str(excinfo.value)
    with pytest.raises(OSError) as excinfo:
        get_os_user('foobar')
    assert 'name: \'foobar\', is not a valid "login name"' in str(excinfo.value)



# Generated at 2022-06-21 12:56:09.669051
# Unit test for function normalize_path
def test_normalize_path():
    """Test :func:`normalize_path`."""
    tmp_path: Path = tempfile.mkdtemp()
    os.chdir(tmp_path)

    def _test_normalize_path(
            path: _PATH,
            expected_result: _PATH = None
    ) -> None:
        expected_result = str(normalize_path(expected_result))

        result = normalize_path(path)

        assert str(result) == expected_result

    # Test with a str
    _test_normalize_path('~/tmp/bar', '~/tmp/bar')
    _test_normalize_path('/foo/../bar', '/bar')
    _test_normalize_path('foo/../../bar', '../bar')

# Generated at 2022-06-21 12:56:12.803853
# Unit test for function normalize_path
def test_normalize_path():
    pattern = '~/tmp/test_path'
    expected = normalize_path(pattern)
    assert normalize_path(Path(pattern)) == expected
    assert normalize_path(bytes(pattern, 'utf-8')) == expected



# Generated at 2022-06-21 12:56:13.638493
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-21 12:56:24.463575
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group()
    assert isinstance(group, grp.struct_group)
    group = get_os_group(group.gr_gid)
    assert isinstance(group, grp.struct_group)
    group = get_os_group(group.gr_name)
    assert isinstance(group, grp.struct_group)
    try:
        get_os_group('foo')
    except OSError as except_info:
        assert 'Invalid' in str(except_info)
    try:
        get_os_group(100000)
    except OSError as except_info:
        assert 'Invalid' in str(except_info)

# Generated at 2022-06-21 12:56:29.588323
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    test_path: Path
    with TemporaryDirectory() as tmpdirname:
        tdir = Path(tmpdirname)
        test_path = directory_present(tdir / 'sub_dir' / 'sub_sub_dir')
    assert exists_as(test_path) == 'directory'
    assert test_path == cast(
        Path, normalize_path('%s/sub_dir/sub_sub_dir' % tmpdirname)
    )



# Generated at 2022-06-21 12:56:33.582057
# Unit test for function path_absent
def test_path_absent():
    """Unit tests for function path_absent."""
    import tempfile

    path = Path('~/tmp/test_path') / tempfile.gettempdir()
    p = normalize_path(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.touch()
        path_absent(p)
        assert not p.exists()
        p.mkdir(mode=0o750)
        (p / 'child').touch()
        child = p / 'child'
        assert child.exists()
        path_absent(p)
        assert not p.exists()
        assert not child.exists()
    finally:
        path_absent(p.parent)



# Generated at 2022-06-21 12:56:44.480931
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from os import chown
    from flutils.pathutils import directory_present

    with TemporaryDirectory() as test_dir:
        user = getpass.getuser()
        group = grp.getgrgid(os.getgid()).gr_name
        test_path = Path(test_dir).joinpath('test')
        if sys.platform != 'win32':
            test_path.chmod(0o000)
            test_path.mkdir()
            chown(test_path.as_posix(), uid=-1, gid=-1)

        assert not os.access(test_path.as_posix(), os.W_OK)
        assert directory_present(test_path, user=user, group=group)

# Generated at 2022-06-21 12:56:47.365060
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user().pw_name == 'root'
    assert get_os_user(0).pw_name == 'root'
    with pytest.raises(OSError):
        get_os_user('foo')



# Generated at 2022-06-21 12:57:04.597255
# Unit test for function chown
def test_chown():
    # Setup
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.touch()
    if sys.platform in ['linux', 'darwin']:
        try:
            os.chown(str(path), -1, -1)
        except PermissionError:
            # File that was created has ownership of root:root
            # so it will fail for non-root user
            pass
    owner = pwd.getpwuid(os.stat(str(path)).st_uid).pw_name
    group = grp.getgrgid(os.stat(str(path)).st_gid).gr_name
    os.chown(str(path), -1, grp.getgrnam(group).gr_gid)

# Generated at 2022-06-21 12:57:15.274232
# Unit test for function find_paths
def test_find_paths():
    import os
    import tempfile
    pathlib = __import__('pathlib')
    home_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 12:57:26.202479
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    for prefix in (
            'flutils.tests.pathutils.',
            'flutils.tests.pathutils-',
    ):
        for suffix in (
                '.txt',
                '.tmp',
                '',
        ):
            with tempfile.TemporaryDirectory() as tmpdir:
                filepath = os.path.join(
                    tmpdir,
                    prefix + suffix
                )
                Path(filepath).touch()
                mode_dir = 0o700
                mode_file = 0o600
                chmod(filepath, mode_file=mode_file)
                assert oct(os.stat(filepath).st_mode & 0o777) == oct(mode_file)
                chmod(filepath, mode_dir=mode_dir)

# Generated at 2022-06-21 12:57:32.996535
# Unit test for function normalize_path
def test_normalize_path():
    # bytes
    path = b"~/tmp/foo"
    path = normalize_path(path)
    assert isinstance(path, PurePosixPath)
    assert path.as_posix() == \
        cast(str, os.path.expanduser("~/tmp/foo"))
    # str
    path = "~/tmp/foo"
    path = normalize_path(path)
    assert isinstance(path, PurePosixPath)
    assert path.as_posix() == \
        cast(str, os.path.expanduser("~/tmp/foo"))
    # PosixPath
    path = PurePosixPath("~/tmp/foo")
    path = normalize_path(path)
    assert isinstance(path, PurePosixPath)

# Generated at 2022-06-21 12:57:43.678402
# Unit test for function directory_present
def test_directory_present():
    from flutils.tests.helpers import (
        POS,
        WINS,
        assert_posixpath,
        assert_windowspath,
        assert_path_exists,
    )

    # Happy path
    mkdir_mock = MagicMock()
    with patch.multiple(
        Path,
        mkdir=mkdir_mock,
        is_absolute=DEFAULT,
        is_dir=DEFAULT,
        is_file=DEFAULT,
        is_symlink=DEFAULT,
        parent=DEFAULT,
    ):
        patchchown = patch(
            'flutils.pathutils.chown',
            autospec=True,
            spec_set=True,
            spec=True
        )

# Generated at 2022-06-21 12:57:52.905797
# Unit test for function chmod
def test_chmod():
    assert chmod.__name__ == 'chmod'

    path_dir = normalize_path('~/tmp/')
    path_file = normalize_path(path_dir / 'flutils-test-file.txt')

    if path_dir.exists():
        shutil.rmtree(path_dir.as_posix())

    path_dir.mkdir()
    with open(path_file, 'w'):
        pass

    chmod(path_file, 0o660)
    assert oct(os.stat(path_file).st_mode)[-3:] == '660'
    chmod(path_file, 0o600)
    assert oct(os.stat(path_file).st_mode)[-3:] == '600'

    chmod(path_dir, 0o670)

# Generated at 2022-06-21 12:58:02.851674
# Unit test for function chown
def test_chown():
    import shutil
    from os import makedirs, stat
    from os.path import basename, dirname, isdir, isfile, join, normpath
    from pwd import getpwnam
    from tempfile import gettempdir
    from unittest import TestCase, main
    from flutils.pathutils import chown

    gettempdir = functools.partial(gettempdir, dir=None)

    class TestChown(TestCase):
        """Test class for the :func:`~chown` function."""

        def setUp(self):
            """Copy the contents of :file:`tests/fixtures/pathutils`
            to the system temporary directory.
            """
            self.path = Path(gettempdir()) / 'flutils.tests.pathutils'

# Generated at 2022-06-21 12:58:09.551607
# Unit test for function get_os_user
def test_get_os_user():
    # for each user, check if the call works with no arg and arg of the
    # user name, uid, and uid-1 (which will throw OSError)
    for osuser in pwd.getpwall():
        pwnam, pwuid = osuser[:2]
        assert get_os_user(pwnam) == osuser
        assert get_os_user(pwuid) == osuser
        with pytest.raises(OSError):
            get_os_user(pwuid-1)


# Generated at 2022-06-21 12:58:14.345669
# Unit test for function path_absent
def test_path_absent():
    # New in version 0.4.
    # Setup
    path = '~/tmp/test_dir'
    mkdir(path)
    path = '~/tmp/test_dir/test_dir2'
    mkdir(path)
    path = '~/tmp/test_dir/test_dir2/test_dir3'
    mkdir(path)
    path = '~/tmp/test_dir/test_dir2/test_dir3/test_file'
    with open(path, 'w'):
        pass
    # Execute
    try:
        path_absent('~/tmp/test_dir')
    # Teardown
    finally:
        path_absent('~/tmp/test_dir')



# Generated at 2022-06-21 12:58:23.648225
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    import tempfile
    # Create a temporary directory
    temp_dirpath = tempfile.mkdtemp()
    # Traverse the temp directory tree to create test directories and files
    tmpdirs = ['dir_one', 'dir_two', 'dir_three']
    for d in tmpdirs:
        t = os.path.join(temp_dirpath, d)
        cast(Path, Path(t)).mkdir(mode=0o700)
    t = os.path.join(temp_dirpath, 'dir_three', 'file_one')
    cast(Path, Path(t)).touch()
    # Call function path_absent
    path_absent(temp_dirpath)
    # Assert the temporary directory is empty
    assert os.listdir(temp_dirpath)

# Generated at 2022-06-21 12:58:47.025583
# Unit test for function chmod
def test_chmod():
    """Test ``chmod`` function."""
    import os
    import secrets

    from flutils.pathutils import chmod, path_absent
    from flutils.pyutils import get_tempdir

    path = Path(get_tempdir(), secrets.token_hex(16))

# Generated at 2022-06-21 12:59:00.426252
# Unit test for function path_absent
def test_path_absent():
    test_dir = '/tmp/test_dir'
    test_dir_file = '/tmp/test_dir/test_dir_file'
    test_dir_link = '/tmp/test_dir_link'
    files = '/tmp/test_dir/test_file1', '/tmp/test_dir/test_file2'
    dirs = '/tmp/test_dir/test_dir1', '/tmp/test_dir/test_dir2'
    dirs_files = '/tmp/test_dir/test_dir1/test_dir1_file', '/tmp/test_dir/test_dir2/test_dir2_file'
    links = '/tmp/test_dir/test_link1', '/tmp/test_dir/test_link2'
    path_absent(test_dir)

# Generated at 2022-06-21 12:59:12.077162
# Unit test for function path_absent
def test_path_absent():
    try:
        path_absent('/tmp/_flutils_test_path/foo/bar')
    except (OSError, IOError) as err:
        raise AssertionError(str(err))
    try:
        path_absent('/tmp/_flutils_test_path/foo/baz')
    except (OSError, IOError) as err:
        raise AssertionError(str(err))
    try:
        path_absent('/tmp/_flutils_test_path/foo')
    except (OSError, IOError) as err:
        raise AssertionError(str(err))
    try:
        path_absent('/tmp/_flutils_test_path')
    except (OSError, IOError) as err:
        raise AssertionError(str(err))



# Generated at 2022-06-21 12:59:22.310031
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group("root") == grp.getgrnam("root")
    assert get_os_group(0) == grp.getgrgid(0)
    try:
        get_os_group("this-group-does-not-exist")
    except OSError:
        assert True
    try:
        get_os_group(99999999999999999)
    except OSError:
        assert True
    assert get_os_group(os.getgid()) == grp.getgrgid(os.getgid())



# Generated at 2022-06-21 12:59:26.470443
# Unit test for function find_paths
def test_find_paths():
    pattern = _DATA_DIR / '*'
    expected = {_DATA_DIR / 'flutils', _DATA_DIR / 'pathutils'}
    result = set(find_paths(pattern))
    assert result == expected



# Generated at 2022-06-21 12:59:36.855476
# Unit test for function path_absent
def test_path_absent():
    path = Path(tempfile.mkdtemp(prefix='flutils_test_'))
    assert path.is_dir()
    test_file = Path(os.path.join(path, 'test_file'))
    with test_file.open(mode='w', encoding='utf-8') as f:
        f.write('Test file content')
    assert test_file.is_file()
    test_dir = Path(os.path.join(path, 'test_dir'))
    test_dir.mkdir()
    assert test_dir.is_dir()
    test_dir_file = Path(os.path.join(test_dir, 'test_dir_file'))

# Generated at 2022-06-21 12:59:38.463972
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')



# Generated at 2022-06-21 12:59:43.513823
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('./setup.py') == 'file'
    assert exists_as('../README.rst') == 'file'
    assert exists_as('./does_not_exist.txt') == ''
    assert exists_as('/dev/tty') == 'char device'



# Generated at 2022-06-21 12:59:50.699406
# Unit test for function get_os_user
def test_get_os_user():
    got = get_os_user()
    assert isinstance(got, pwd.struct_passwd)
    with pytest.raises(OSError):
        get_os_user('this_is_not_a_login_name')
    got = get_os_user(1001)
    assert isinstance(got, pwd.struct_passwd)
    with pytest.raises(OSError):
        get_os_user(999999)



# Generated at 2022-06-21 13:00:00.229809
# Unit test for function normalize_path
def test_normalize_path():
    from pathlib import Path
    from flutils.pathutils import normalize_path
    import os

    # Test for an existing non absolute path
    # type(bytes)
    path_bytes = os.fspath(Path() / 'foo' / 'bar').encode()
    path = normalize_path(path_bytes)
    assert type(path) == Path
    assert path.as_posix() == os.path.normpath(os.path.join('foo', 'bar'))
    # type(str)
    path = normalize_path(path)
    assert type(path) == Path
    assert path.as_posix() == os.path.normpath(os.path.join('foo', 'bar'))
    os.chdir(path)
    # type(pathlib.PosixPath)

# Generated at 2022-06-21 13:00:22.234845
# Unit test for function directory_present
def test_directory_present():
    from os import makedirs
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    test_value = 'test value'

    temp_dir = TemporaryDirectory()

    path_str = os.path.join(temp_dir.name, 'foo', 'bar')

    assert directory_present(path_str) == PosixPath(path_str)
    assert directory_present(path_str).is_dir() is True
    assert directory_present(path_str).exists() is True

    makedirs(path_str)
    assert directory_present(path_str) == PosixPath(path_str)
    assert directory_present(path_str).is_dir() is True
    assert directory_present(path_str).exists() is True


# Generated at 2022-06-21 13:00:34.917347
# Unit test for function path_absent
def test_path_absent():
    """Unit tests for flutils.pathutils.path_absent."""
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='temp_dir_')
    file_one = os.path.join(temp_dir, 'file_one')
    file_two = os.path.join(temp_dir, 'tmp', 'file_two')
    link_one = os.path.join(temp_dir, 'tmp', 'link_one')
    link_two = os.path.join(temp_dir, 'tmp', 'link_two')
    link_three = os.path.join(temp_dir, 'tmp', 'link_three')
    dir_one = os.path.join(temp_dir, 'tmp', 'dir_one')

# Generated at 2022-06-21 13:00:37.943863
# Unit test for function directory_present
def test_directory_present():
    print('Testing flutils.pathutils.directory_present()')
    print('- No test exists.')
    print()



# Generated at 2022-06-21 13:00:48.796817
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / 'directory_present_test'
        directory_present(path)

        assert path.is_dir() is True

        mode = stat.S_IMODE(path.stat().st_mode)
        assert mode == 0o700

        uid = os.getuid()
        assert path.stat().st_uid == uid

        gid = os.getgid()
        assert path.stat().st_gid == gid

        os.chmod(path.as_posix(), 0o755)
        chmod(path, mode_dir=0o700)

        mode = stat.S_IMODE(path.stat().st_mode)
        assert mode == 0o700

        # Test when the path already exists as a directory
        directory

# Generated at 2022-06-21 13:00:56.111288
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir('dir1')
        tmpdir.mkdir('dir2')
        tmpdir.mkdir('dir3')
        tmpdir.mkdir('dir4')
        tmpdir.mkdir('dir5')
        tmpdir.mkdir('.hidden1')
        tmpdir.mkdir('.hidden2')
        tmpdir.mkdir('.hidden3')
        tmpdir.touch('file.txt')
        tmpdir.touch('.hidden_file.txt')
        tmpdir.mkdir('foo')
        tmpdir.mkdir('bar')
        tmpdir.mkdir('moo')


# Generated at 2022-06-21 13:00:58.671255
# Unit test for function chown
def test_chown():
    chown("/home/mssergio/tmp/flutils.tests.osutils.txt", include_parent=True)


# Generated at 2022-06-21 13:01:10.920321
# Unit test for function path_absent
def test_path_absent():
    import os
    import pathlib
    from shutil import rmtree
    from tempfile import mkdtemp

    from flutils.pathutils import path_absent

    # Create a temporary directory so we can create the test paths.
    tmp_dir = mkdtemp()

    # Create the paths
    test_paths = []
    for x in range(3):
        test_path = pathlib.Path(
            os.path.join(tmp_dir, str(x))
        )
        test_path = test_path.resolve()
        test_path.touch()
        test_paths.append(test_path)

    # Test
    path_absent(test_paths[0])
    assert test_paths[0].is_symlink() is False
    assert test_paths[0].exists

# Generated at 2022-06-21 13:01:14.071953
# Unit test for function normalize_path
def test_normalize_path():
    home_dir = os.path.expanduser('~')
    assert normalize_path('~/tmp/foo/../bar') == Path(
        os.path.join(home_dir, 'tmp', 'bar')
    )



# Generated at 2022-06-21 13:01:17.461824
# Unit test for function chmod
def test_chmod():
    chmod.__wrapped__('~/tmp/flutils.tests.osutils.txt', 0o660)

# Generated at 2022-06-21 13:01:27.820209
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    dirname = '/tmp/flutils.tests.pathutils.directory_present'

    directory_present(dirname, mode=0o700, user='nobody', group='nobody')

    path = Path(dirname)
    assert path.is_dir() is True
    assert path.stat().st_uid == pwd.getpwnam('nobody').pw_uid
    assert path.stat().st_gid == grp.getgrnam('nobody').gr_gid
    assert path.stat().st_mode == 0o40700

    directory_present(dirname, mode=0o700, user=None, group=None)

    assert path.is_dir() is True

# Generated at 2022-06-21 13:02:02.106687
# Unit test for function find_paths
def test_find_paths():
    pass  # TODO: Write this!
# vim: set ft=python :

# Generated at 2022-06-21 13:02:14.741159
# Unit test for function path_absent
def test_path_absent():
    path = get_os_user().pw_dir + '/.ssh/flutils_test'
    path = Path(path)
    path.touch()
    path_absent(path)
    assert path.exists() is False
    path.mkdir()
    tmp = path / 'tmp'
    tmp.mkdir()
    touch(tmp, mode='file')
    path_absent(path)
    assert path.exists() is False
    path.mkdir()
    tmp = path / 'tmp'
    tmp.mkdir()
    touch(tmp, mode='link')
    path_absent(path)
    assert path.exists() is False
    path.mkdir()
    tmp = path / 'tmp'
    tmp.mkdir()
    touch(tmp, mode='socket')
    path_absent

# Generated at 2022-06-21 13:02:27.255072
# Unit test for function path_absent
def test_path_absent():

    # Test if given a Path object as the path name that it works as
    # expected.
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmpfile = tmpdirname / 'tmpfile'
        tmpfile.touch()
        tmpfile.chmod(0o700)
        path_absent(tmpfile)
        assert not tmpfile.exists()

        tmpfile = tmpdirname / 'tmpfile'
        tmpfile.touch()
        tmpfile.chmod(0o700)
        path_absent(str(tmpfile))
        assert not tmpfile.exists()

        tmpfile = tmpdirname / 'tmpfile'
        tmpfile.touch()
        tmpfile.chmod(0o700)
       

# Generated at 2022-06-21 13:02:39.823221
# Unit test for function normalize_path
def test_normalize_path():
    """Run unit tests for function normalize_path."""
    path = normalize_path('~/foo/../bar')
    assert isinstance(path, Path)
    assert path.as_posix() == os.path.join(os.path.expanduser('~'), 'bar')
    env_value = 'TMP'
    path = normalize_path(env_value)
    assert isinstance(path, Path)
    assert path.is_absolute() is True
    assert path.as_posix() == os.path.expandvars(env_value)
    path = normalize_path('not/absolute')
    assert isinstance(path, Path)
    assert path.as_posix() == os.path.normpath(path.as_posix())

# Generated at 2022-06-21 13:02:50.500047
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = os.path.join(os.path.expanduser('~'), 'tmp_flutils_test')
    os.makedirs(tmp_dir, mode=0o700)

# Generated at 2022-06-21 13:02:56.251532
# Unit test for function directory_present
def test_directory_present():
    import unittest
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    try:
        path = Path(temp_dir.name) / 'test_dir'
        directory_present(path)
        assert(path.exists())
    finally:
        temp_dir.cleanup()
    return



# Generated at 2022-06-21 13:02:57.952891
# Unit test for function chmod
def test_chmod():
    pass
# Unit tests for module osutils
import sys
import unittest

# Generated at 2022-06-21 13:02:58.633287
# Unit test for function find_paths
def test_find_paths():
    pass

# Generated at 2022-06-21 13:03:09.265954
# Unit test for function path_absent
def test_path_absent():
    import random
    import string
    import tempfile
    CWD: PathLike = cast(PathLike, os.getcwd())
    SEP: str = os.path.sep
    with tempfile.TemporaryDirectory() as tempdir:
        p = Path(tempdir)
        q = p.joinpath(
            ''.join(random.choice(string.ascii_letters) for _ in range(32))
        )
        path_absent(q)
        assert os.path.exists(q.as_posix()) is False
        q.mkdir()
        assert os.path.exists(q.as_posix()) is True
        assert os.path.isdir(q.as_posix()) is True
        path_absent(q)

# Generated at 2022-06-21 13:03:14.596741
# Unit test for function exists_as
def test_exists_as():
    import tempfile
    from flutils.pathutils import exists_as

    try:
        tmpdir = Path(tempfile.mkdtemp())
        with tmpdir.joinpath('exists_as.txt').open('w') as f:
            f.write('This is a test for the function exists_as()')

        assert exists_as(tmpdir) == 'directory'
        assert exists_as(tmpdir / 'exists_as.txt') == 'file'

    finally:
        tmpdir.rmdir()



# Generated at 2022-06-21 13:03:58.923902
# Unit test for function directory_present
def test_directory_present():
    test_path = directory_present('~/tmp/flutils.test_directory_present')
    assert test_path.exists() is True
    test_path.rmdir()
    assert test_path.exists() is False



# Generated at 2022-06-21 13:04:08.729477
# Unit test for function find_paths
def test_find_paths():
    from pprint import pformat

    # GIVEN a file and directory in a given path
    test_dir = Path(__file__).resolve()

    # WHEN we call find_paths
    result = find_paths(test_dir.parent)

    # THEN they all should be discovered
    parent_files = [
        Path('setup.py'),
        Path('tests'),
        Path('site-packages'),
        Path('scripts'),
        Path('README.rst'),
        Path('venv'),
        Path('requirements.txt'),
        Path('MANIFEST.in'),
        Path('setup.cfg'),
        Path('flutils'),
        Path('bin'),
        Path('docs'),
        Path('__init__.py'),
    ]

# Generated at 2022-06-21 13:04:12.179169
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(get_os_user().pw_gid) == get_os_group()
    assert get_os_group().gr_gid == get_os_user().pw_gid



# Generated at 2022-06-21 13:04:13.551743
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user(name='foo')
    except:
        return 1
    else:
        return 0


# Generated at 2022-06-21 13:04:19.659793
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import chmod

    def test_chmod_dir() -> None:
        with TemporaryDirectory() as dirname:
            path = Path(dirname)
            sub_dir = path / 'sub_dir'
            sub_dir.mkdir()
            chmod(sub_dir.as_posix(), mode_dir=0o775)
            assert sub_dir.stat().st_mode == 16895

    def test_chmod_file() -> None:
        with TemporaryDirectory() as dirname:
            path = Path(dirname)
            sub_dir = path / 'sub_dir'
            sub_dir.mkdir()
            sub_file = sub_dir / 'sub_file.txt'
            sub_file.touch()

# Generated at 2022-06-21 13:04:31.282240
# Unit test for function exists_as
def test_exists_as():
    """Test for function: exists_as."""

    # pylint: disable=protected-access
    from pathlib import Path
    from unittest.mock import patch

    from flutils.pathutils import exists_as

    with patch('flutils.pathutils.normalize_path') as normalize_path:
        normalize_path.return_value = Path('/tmp')
        assert exists_as('tmp') == ''

        normalize_path.return_value.is_dir.return_value = True
        assert exists_as('tmp') == 'directory'
        normalize_path.return_value.is_dir.return_value = False

        normalize_path.return_value.is_file.return_value = True
        assert exists_as('tmp') == 'file'

# Generated at 2022-06-21 13:04:42.865337
# Unit test for function normalize_path

# Generated at 2022-06-21 13:04:50.272716
# Unit test for function normalize_path
def test_normalize_path():
    cur_dir = os.getcwd()
    #
    # current dir ends in /
    #
    expected = cur_dir + '/foo/bar'
    os.chdir('/')
    assert normalize_path('foo/bar').as_posix() == expected
    assert normalize_path('foo\\bar').as_posix() == expected
    #
    # current dir does not end in /
    #
    os.chdir(cur_dir)
    assert normalize_path('foo/bar').as_posix() == expected
    assert normalize_path('foo\\bar').as_posix() == expected
    #
    # slash at the end of the path
    #
    assert normalize_path('./foo/bar/').as_posix() == expected
    #
    # Do NOT normalizes


# Generated at 2022-06-21 13:05:04.154284
# Unit test for function exists_as
def test_exists_as():
    """Test function flutils.pathutils.exists_as."""
    from collections import namedtuple
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase
    import unittest

    from flutils.pathutils import exists_as
    from flutils.systemutils import get_os_user
    from flutils.systemutils import get_os_group
    from flutils.systemutils import get_os_cwd

    class TestExistsAs(TestCase):
        """Unit tests to validate flutils.pathutils.exists_as."""

        @classmethod
        def setUpClass(cls):
            """Create initial test directory/file structure."""
            cls.test_dir = Path(mkdtemp())
            cls.test_dir.mkdir()
            cl

# Generated at 2022-06-21 13:05:08.081194
# Unit test for function get_os_user
def test_get_os_user():
    cuser = get_os_user()
    name = get_os_user()[0]
    cuser = get_os_user(name)
    uid = get_os_user()[2]
    cuser = get_os_user(uid)

