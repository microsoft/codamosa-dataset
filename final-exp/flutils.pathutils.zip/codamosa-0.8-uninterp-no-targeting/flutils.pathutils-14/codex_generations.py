

# Generated at 2022-06-21 12:55:50.108355
# Unit test for function get_os_user
def test_get_os_user():
    """Test function ``get_os_user``."""
    pwd = get_os_user('foo')
    assert pwd.pw_name == 'foo'
    assert pwd.pw_uid == 1001
    assert pwd.pw_gid == 2001
    assert pwd.pw_gecos == 'Foo Bar'
    assert pwd.pw_dir == '/home/foo'
    assert pwd.pw_shell == '/usr/local/bin/bash'



# Generated at 2022-06-21 12:55:54.288968
# Unit test for function path_absent
def test_path_absent():
    TEST_DIR: str = '~/tmp/pytest_test_path_absent'
    TEST_DIR = expanduser(TEST_DIR)
    TEST_DIR = cast(str, TEST_DIR)
    assert os.path.exists(TEST_DIR) is False
    os.makedirs(TEST_DIR, mode=0o755)
    assert os.path.isdir(TEST_DIR) is True
    path_absent(TEST_DIR)
    assert os.path.exists(TEST_DIR) is False



# Generated at 2022-06-21 12:55:57.783362
# Unit test for function chmod
def test_chmod():
    """Test that the function chmod works as expected."""

    pass



# Generated at 2022-06-21 12:56:04.650699
# Unit test for function get_os_group
def test_get_os_group():
    from .osutils import get_os_user
    assert isinstance(get_os_group(), grp.struct_group)
    assert get_os_group().gr_gid == get_os_user().pw_gid
    assert get_os_group(get_os_user().pw_gid) == get_os_group()
    assert isinstance(get_os_group(get_os_user().pw_gid), grp.struct_group)


# Generated at 2022-06-21 12:56:10.578079
# Unit test for function get_os_user
def test_get_os_user():
    # For some reason this needs to be done here.
    # It might be because the system is switching
    # the context from the test_get_os_user
    # context to this context.
    try:
        assertTrue(get_os_user('root') is not None)
    except OSError:
        skipTest('The operating system does not have a user with'
                 'the "login name": root')
    assertTrue(get_os_user() is not None)
    assertRaises(OSError, get_os_user, 'bad_user')
    assertRaises(OSError, get_os_user, 10000)



# Generated at 2022-06-21 12:56:18.806505
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.test.test_pathutils import _test_get_os_group
    test_data = [
        # name, expected, expected_group_name
        (None, grp.struct_group, 'test_user'),
        ('test_user', grp.struct_group, 'test_user'),
        ('test_group', grp.struct_group, 'test_group'),
        (1001, grp.struct_group, 'test_group'),
    ]
    _test_get_os_group(test_data)



# Generated at 2022-06-21 12:56:22.416457
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2001,
    gr_mem=['foo'])



# Generated at 2022-06-21 12:56:30.377672
# Unit test for function chown
def test_chown():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from os import (
        getuid,
        getgid,
        makedirs,
        path,
        stat,
        symlink,
    )
    from flutils.pathutils import (
        chown,
        find_paths,
    )
    with TemporaryDirectory(prefix='flutils.tests.osutils') as temp_dir:
        tmp_path = Path(temp_dir)
        assert tmp_path.is_dir() is True

        # Test with a directory.
        test_path_str = tmp_path / 'foo'
        makedirs(test_path_str.as_posix())

        uid = getuid()
        gid = getgid()

        test_path = Path(test_path_str)

# Generated at 2022-06-21 12:56:42.918081
# Unit test for function directory_present
def test_directory_present():
    import logging
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def _tmp_dir() -> Generator[Path, None, None]:
        path = Path(tempfile.mkdtemp())
        yield path
        path.rmdir()

    with _tmp_dir() as tmp_dir:
        path = Path(tmp_dir.as_posix(), 'dir_present_test')
        path_exists_as = exists_as(path)
        if path_exists_as != '':
            raise Exception(
                'The test file: %r already exists as a %s.  This '
                'file will be deleted.  However, it needs to exist '
                'as a directory.'
                % (path.as_posix(), path_exists_as)
            )


# Generated at 2022-06-21 12:56:54.875152
# Unit test for function normalize_path
def test_normalize_path():
    """Test the flutils.normalize_path function.

    :return: :obj:`None`

    """
    _CWD = os.getcwd()
    HOME = os.path.expanduser('~')

    def get_path(path: PathLike) -> Path:
        return normalize_path(path)

    path_str = '~/tmp/foo/../bar'
    path_path = Path(path_str)
    assert get_path(path_str) == get_path(path_path)
    assert get_path(path_str) == Path(
        os.path.join(HOME, 'tmp', 'foo', '..', 'bar')
    )

    path_str = '/tmp/foo/../bar'
    path_path = Path(path_str)

# Generated at 2022-06-21 12:57:10.806699
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user('foo')
    get_os_user()
    get_os_user(1001)



# Generated at 2022-06-21 12:57:20.631449
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    if IS_POSIX is True:
        os_group = get_os_group(get_os_user().gr_gid)
        assert os_group.gr_gid == get_os_user().gr_gid
        assert os_group.gr_name == get_os_user().gr_name
        with pytest.raises(OSError):
            get_os_group(-1)
        with pytest.raises(OSError):
            get_os_group('x')
    if IS_WINDOWS is True:
        # Windows does not support get_os_group().
        pass



# Generated at 2022-06-21 12:57:22.425249
# Unit test for function get_os_user
def test_get_os_user(): # noqa: D103
    get_os_user('test_user')

# Generated at 2022-06-21 12:57:31.745669
# Unit test for function chmod
def test_chmod():
    import pathlib
    import os

    file_path = pathlib.Path(__file__)
    with file_path.open('w') as fh:
        fh.write('blah')

    file_path.chmod(0o444)
    assert 0o444 == stat.S_IMODE(os.lstat(str(file_path)).st_mode)

    file_path.chmod(0o660)
    assert 0o660 == stat.S_IMODE(os.lstat(str(file_path)).st_mode)

    file_path.chmod(0o664)
    assert 0o664 == stat.S_IMODE(os.lstat(str(file_path)).st_mode)

    file_path.chmod(0o600)
    assert 0o600 == stat.S

# Generated at 2022-06-21 12:57:42.418938
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )
    assert get_os_group(2000) == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )
    assert get_os_group() == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )

    with pytest.raises(OSError) as excinfo:
        get_os_group('bar')
    assert 'is not a valid "group name" for this operating system.' in str(
        excinfo.value
    )

# Generated at 2022-06-21 12:57:48.550963
# Unit test for function chmod
def test_chmod():
    # Test for function chmod
    # Change the mode of a path.

    # This function processes the given path with
    # normalize_path.

    # If the given path does NOT exist, nothing will be done.

    # This function will **NOT** change the mode of:

    # - symlinks (symlink targets that are files or directories will be changed)
    # - sockets
    # - fifo
    # - block devices
    # - char devices

    assert chmod('README.md') is None



# Generated at 2022-06-21 12:57:57.970297
# Unit test for function find_paths
def test_find_paths():
    with NamedTemporaryDirectory() as tmpdir:
        dpath = Path(tmpdir)
        file1 = dpath / 'file1'
        file1.touch()
        file2 = dpath / 'file2'
        file2.touch()
        yield from dpath.glob('file*')
        assert list(find_paths(dpath / 'file1')) == [file1]
        assert list(find_paths(dpath / 'file2')) == [file2]
        assert list(find_paths(dpath / 'file*')) == [file1, file2]
        assert list(find_paths(dpath / 'file?.txt')) == []



# Generated at 2022-06-21 12:58:06.624098
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import directory_present
    from pathlib import Path
    from shutil import rmtree

    test_path = Path('~/tmp').expanduser()
    directory_present(test_path)

    test_path = Path('~/tmp/test_path')
    directory_present(test_path)

    path = Path('~/tmp/test_path/test1.txt').expanduser()
    path.touch()

    path = Path('~/tmp/test_path/test2.txt').expanduser()
    path.touch()

    list(find_paths('~/tmp/test_path/*.txt'))
    assert len(list(find_paths('~/tmp/test_path/*.txt'))) == 2

   

# Generated at 2022-06-21 12:58:14.948312
# Unit test for function find_paths
def test_find_paths():
    assert find_paths('/tmp/') == Path('/tmp/').glob('*')
    assert find_paths('~/tmp/') != Path(os.path.expanduser('~/tmp/')).glob('*')
    assert find_paths('~/tmp/') == Path(os.path.expanduser('~/tmp')).glob('*')
    assert find_paths('~/tmp') == Path(os.path.expanduser('~/tmp')).glob('*')
    assert find_paths('/tmp') == Path('/tmp').glob('*')
    assert find_paths('~') == Path(os.path.expanduser('~')).glob('*')
    assert find_paths('/') == Path('/').glob('*')

# Generated at 2022-06-21 12:58:24.091566
# Unit test for function chmod
def test_chmod():
    with freeze_time(
            '2020-01-01T00:00:00',
            tz_offset=0,
            ignore=['cryptography', 'pytz']):
        with NamedTemporaryFile(dir='/tmp') as tmp_file:
            tmp_file_path = Path(tmp_file.name)
            assert tmp_file_path.exists() is True
            assert tmp_file_path.stat().st_mode == 33188
            chmod(tmp_file_path, mode_file=0o660)
            assert tmp_file_path.stat().st_mode == 33192
            tmp_file_path.unlink()
            assert tmp_file_path.exists() is False

        with TemporaryDirectory(dir='/tmp') as tmp_dir:
            tmp_dir_path = Path(tmp_dir)

# Generated at 2022-06-21 12:58:50.995076
# Unit test for function get_os_group
def test_get_os_group():
    # Function name: get_os_group
    # Test case:
    #   The gid argument is provided as None.
    #   Should return a grp.struct_group
    #   with the current user's group.
    group = get_os_group()

    if isinstance(group, grp.struct_group) is False:
        raise AssertionError(
            "Invoking get_os_group() with a None argument {} "
            "did NOT return a grp.struct_group."
        )
    # Test case:
    #   The gid argument is provided as None,
    #   but the current user is not a member of any groups.
    #   Should return a grp.struct_group with the
    #   current user's 'group name'.

# Generated at 2022-06-21 12:58:59.336162
# Unit test for function path_absent
def test_path_absent():
    """Test path_absent function."""

    path = Path('~/tmp/test_path')
    path.mkdir(parents=True)
    for x in range(1, 6):
        (path / "file_%s" % x).touch()

    path_absent(path)
# Test main
if __name__ == '__main__':
    test_path_absent()

# Generated at 2022-06-21 12:59:02.177445
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == get_os_user(getpass.getuser())
    assert get_os_user(get_os_user().pw_name) == get_os_user()



# Generated at 2022-06-21 12:59:13.584281
# Unit test for function path_absent
def test_path_absent():
    test_path = Path(tempfile.gettempdir(), 'test_path')
    assert test_path.exists() is False

# Generated at 2022-06-21 12:59:21.277542
# Unit test for function chown
def test_chown():
    from pytest import raises
    from flutils.pathutils import _get_user_group

    _user, group = _get_user_group()

    with raises(OSError):
        chown('~/tmp/flutils.tests.osutils.txt', user=group)

    with raises(OSError):
        chown('~/tmp/flutils.tests.osutils.txt', group=group)



# Generated at 2022-06-21 12:59:21.831945
# Unit test for function path_absent
def test_path_absent():
    _path_absent()

# Generated at 2022-06-21 12:59:24.939366
# Unit test for function get_os_group
def test_get_os_group():
    name = get_os_group().gr_name
    assert isinstance(get_os_group(name), grp.struct_group)
test_get_os_group()



# Generated at 2022-06-21 12:59:33.659695
# Unit test for function normalize_path
def test_normalize_path():
    """Test function ``normalize_path``."""
    assert normalize_path('~') == Path(os.path.expanduser('~'))

    assert normalize_path('/tmp') == Path('/tmp')
    assert normalize_path('/tmp/') == Path('/tmp')

    assert normalize_path('~/tmp') == Path('%s/tmp' % os.path.expanduser('~'))
    assert normalize_path('~/tmp/') == Path('%s/tmp' % os.path.expanduser('~'))

    assert normalize_path('~/tmp/foo') == Path('%s/tmp/foo' % os.path.expanduser('~'))

# Generated at 2022-06-21 12:59:39.669422
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    test_path = r'~/tmp/foo/../bar'
    original = normalize_path(test_path)
    result = Path(os.path.expanduser(test_path))
    result = Path(os.path.expandvars(result.as_posix()))
    if os.path.isabs(result.as_posix()) is False:
        result = Path(os.path.join(os.getcwd(), result.as_posix()))
    result = Path(os.path.normpath(result.as_posix()))
    result = Path(os.path.normcase(result.as_posix()))
    assert original == result



# Generated at 2022-06-21 12:59:51.528632
# Unit test for function find_paths
def test_find_paths():
    path = Path.home() / 'tmp' / 'test_search'
    path.mkdir(parents=True, exist_ok=True)
    Path.mkdir(path / 'dir_one', exist_ok=True)
    Path.mkdir(path / 'dir_two', exist_ok=True)
    Path.mkdir(path / 'dir_three', exist_ok=True)
    Path.touch(path / 'file_one.py')
    Path.touch(path / 'file_two.py')
    Path.touch(path / 'file_three.py')

# Generated at 2022-06-21 13:00:04.900260
# Unit test for function get_os_group
def test_get_os_group():
    expected_struct_group: grp.struct_group = grp.struct_group(
        gr_name='bar',
        gr_passwd='*',
        gr_gid=2001,
        gr_mem=[],
    )
    assert get_os_group('bar') == expected_struct_group



# Generated at 2022-06-21 13:00:06.041537
# Unit test for function chown
def test_chown():
    # TODO
    pass



# Generated at 2022-06-21 13:00:10.614997
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-21 13:00:18.478390
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    try:
        current_user = get_os_user()
    except OSError:
        current_user = get_os_user().pw_name
    assert get_os_user('root') == pwd.getpwnam('root')
    assert get_os_user(current_user.pw_uid) == current_user
    with pytest.raises(OSError):
        get_os_user(9999)
    with pytest.raises(OSError):
        get_os_user('foo')



# Generated at 2022-06-21 13:00:25.709738
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""

    with tempfile.TemporaryDirectory() as temp_dir:
        test_path = os.path.join(temp_dir, 'test_path')
        os.makedirs(test_path)

        contents = [
            'file_one',
            'file_two',
            'dir_one',
            'dir_two',
        ]

        for item in contents:
            path = test_path + os.path.sep + item
            if item.startswith('file'):
                with open(path, 'w') as _:
                    pass
            else:
                os.makedirs(path)

        pattern = Path(temp_dir) / 'test_path/*'

        paths = set(find_paths(pattern))
        assert len(paths) == 4

# Generated at 2022-06-21 13:00:38.292150
# Unit test for function path_absent
def test_path_absent():
    import os
    import pathlib
    import tempfile
    import shutil
    import test.fixtures.pathutils as fixtures
    import flutils.pathutils as pathutils

    # Setup
    unsorted = fixtures.unsorted
    sorted = fixtures.sorted

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = tmp_dir.name

    file_list = [os.path.join(tmp_dir.name, path) for path in unsorted]

    for path in file_list:
        pathlib.Path(path).touch()


# Generated at 2022-06-21 13:00:49.125944
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import directory_present
    from flutils.pyutils import get_mro
    from flutils.testutils import (
        TestStructure,
        create_test_file,
    )
    tmpdir = TemporaryDirectory()

    # Test directory_present()

# Generated at 2022-06-21 13:00:57.331666
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path"""
    if sys.platform == 'win32':
        path = 'C:/Users/user/foo/../bar'
    else:
        path = '~/foo/../bar'
    path = normalize_path(path)
    assert path.is_absolute() is True
    assert path.as_posix() == os.path.join(os.getcwd(), 'bar')



# Generated at 2022-06-21 13:00:59.459418
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError) as excinfo:
        get_os_user('bad_user_name')
    assert 'is not a valid "login name" for this operating system.' in str(excinfo.value)



# Generated at 2022-06-21 13:01:12.039366
# Unit test for function normalize_path
def test_normalize_path():
    # For documentation of the following formatting options see:
    # https://docs.python.org/3/library/string.html#formatspec
    # https://docs.python.org/3/library/string.html#str.format
    # https://docs.python.org/3/library/string.html#format-specification-mini-language
    # __doc__ (as of 2020-03-05) for os.path.expanduser states:
    # "Unlike expandvars(), unexpandable variables are left unchanged.
    #  At most one initial component of a path is expanded."
    # This means the following test will fail.
    # assert normalize_path('/home/$USER') == '/home/$USER'
    assert normalize_path('~') == Path().home()

# Generated at 2022-06-21 13:01:26.699410
# Unit test for function path_absent
def test_path_absent():
    path = normalize_path('~/tmp/test_path')
    pdir = path.parent
    try:
        pdir.mkdir()
        path.touch()
        assert path.exists()
    finally:
        path_absent(path)
        path_absent(pdir)
        assert path.exists() is False
        assert pdir.exists() is False



# Generated at 2022-06-21 13:01:28.739664
# Unit test for function normalize_path
def test_normalize_path():
    # _PATH  == Union[PathLike, str, bytes, Path]
    assert isinstance(normalize_path('~/tmp/foo/../bar'), Path)

# Generated at 2022-06-21 13:01:43.506234
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path()."""
    path1 = normalize_path('~/tmp/test_path')
    path2 = normalize_path(path1)
    assert path1 == path2
    assert path1.as_posix() == path2.as_posix()
    assert path1.as_uri() == path2.as_uri()
    assert path1.cwd() == path2.cwd()
    assert path1.cwf() == path2.cwf()
    assert path1.cwd().as_posix() == path2.cwd().as_posix()
    assert path1.cwd().as_uri() == path2.cwd().as_uri()
    assert path1.cwf().as_posix() == path2.cwf().as_posix()

# Generated at 2022-06-21 13:01:47.186869
# Unit test for function get_os_user
def test_get_os_user():
    try:
        assert get_os_user('root').pw_uid == 0
    except OSError:
        pass
    try:
        assert get_os_user(0).pw_name == 'root'
    except OSError:
        pass



# Generated at 2022-06-21 13:01:49.991909
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-21 13:02:01.241609
# Unit test for function path_absent
def test_path_absent():
    print('Test path_absent():')
    prefix = 'path_absent'
    test_dir = get_temp_dir(prefix)
    abs_path = os.path.join(test_dir, 'abs_path')
    with open(abs_path, 'w') as out:
        out.write('')
    rel_path = 'rel_path'
    with open(rel_path, 'w') as out:
        out.write('')
    print('  * Create absolute path')
    print('  * Create relative path')
    dir_path = os.path.join(test_dir, 'dir_path')
    os.mkdir(dir_path)
    sub_path = os.path.join(dir_path, 'sub_path')

# Generated at 2022-06-21 13:02:13.746732
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        tempdir = Path(tempdir)
        foo_dir = tempdir.joinpath('foo').as_posix()
        bar_dir = tempdir.joinpath('bar').as_posix()
        foo_file = tempdir.joinpath('foo', 'foo.txt').as_posix()
        bar_file = tempdir.joinpath('bar', 'bar.txt').as_posix()
        open(foo_file, 'w').close()
        open(bar_file, 'w').close()
        os.mkdir(foo_dir)
        os.mkdir(bar_dir)
        path_absent(foo_file)
        assert os.path.exists(foo_file) == False

# Generated at 2022-06-21 13:02:19.189588
# Unit test for function find_paths
def test_find_paths():
    test_dir = create_temp_dir(suffix='_test_pathutils_find_paths')
    sub_dir = Path(test_dir).joinpath('sub_dir')
    sub_dir.mkdir()
    test_file_1 = Path(test_dir).joinpath('file_1.txt')
    test_file_1.touch()
    test_file_2 = Path(sub_dir).joinpath('file_2.txt')
    test_file_2.touch()
    matches = sorted(find_paths(str(Path(test_dir).joinpath('**'))))
    matches = sorted(str(r) for r in matches)

# Generated at 2022-06-21 13:02:26.484975
# Unit test for function get_os_user
def test_get_os_user():
    if sys.platform == 'darwin':
        user = 'root'
    elif sys.platform == 'linux':
        user = 'nobody'
    elif sys.platform == 'win32':
        user = getpass.getuser()
    else:
        user = 'foo'
    uid = get_os_user(user).pw_uid
    assert get_os_user(uid).pw_name == user



# Generated at 2022-06-21 13:02:37.568490
# Unit test for function get_os_group
def test_get_os_group():
    from unittest import TestCase
    import grp
    from flutils.pathutils import get_os_group

    logger.debug('Test get_os_group function.')
    tc = TestCase()
    tc.assertIsInstance(get_os_group(), grp.struct_group)
    tc.assertIsInstance(get_os_group('foo'), grp.struct_group)
    tc.assertRaises(OSError, get_os_group, 'does_not_exist')
    tc.assertIsInstance(get_os_group(get_os_group().gr_gid), grp.struct_group)
    tc.assertRaises(OSError, get_os_group, -1)



# Generated at 2022-06-21 13:02:54.311933
# Unit test for function path_absent
def test_path_absent():
    with TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        mkdir_p('/test_dir_1/test_dir_2/test_dir_3')
        assert os.path.isdir('/test_dir_1/test_dir_2/test_dir_3')
        Path('/test_dir_1/test_dir_2/test_dir_3/test_file.txt').touch()
        assert os.path.isfile(
            '/test_dir_1/test_dir_2/test_dir_3/test_file.txt'
        )

# Generated at 2022-06-21 13:03:00.499156
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.tests.helpers import get_group_data

    gid = get_os_group(get_group_data('gid')).gr_gid
    assert gid == get_group_data('gid')
    group_name = get_os_group(get_group_data('gid')).gr_name
    assert group_name == get_group_data('name')

# Generated at 2022-06-21 13:03:10.856198
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present"""
    import os
    import shutil
    import tempfile
    import unittest

    class TestDirectoryPresent(unittest.TestCase):
        """Tests for function directory_present"""
        # pylint: disable=R0904
        def setUp(self):
            """Setup the Unit Test"""
            self._user = getpass.getuser()
            self._group = grp.getgrgid(os.getgid()).gr_name
            self._test_dir = tempfile.mkdtemp()

        def tearDown(self):
            """Teardown the Unit Test"""
            shutil.rmtree(self._test_dir)

        def test_general_usage(self):
            """Test the general usage of directory_present"""

# Generated at 2022-06-21 13:03:22.424118
# Unit test for function path_absent
def test_path_absent():
    def assert_path_absent(path: str) -> None:
        if os.path.exists(path):
            raise AssertionError(
                'The given path %r, still exists.' % path
            )

    tempdir = mkdtemp(dir='.', prefix='flutils_')

# Generated at 2022-06-21 13:03:31.195850
# Unit test for function chown
def test_chown():
    import stat
    import tempfile
    import time
    import unittest

    from flutils.pathutils import chown, get_os_group, get_os_user

    class TestPathUtilsChown(unittest.TestCase):

        def setUp(self):
            self.user = get_os_user()
            self.group = get_os_group()
            self.tmpdir = tempfile.TemporaryDirectory(prefix='tmp.flutils.')

        def tearDown(self):
            self.tmpdir.cleanup()

        def test_chown(self):
            tmpfile = self.tmpdir.name / 'foo'
            tmpfile.touch()

            uid = get_os_user('root').pw_uid
            gid = get_os_group('root').gr_gid

            #

# Generated at 2022-06-21 13:03:40.113773
# Unit test for function find_paths
def test_find_paths():
    # Test for glob pattern
    path = Path(DATA_DIR, 'flutils', 'glob', '*', 'find_paths.txt')
    pattern = normalize_path(path)
    result = list(find_paths(pattern))
    assert len(result) == 1, \
        'The number of results returned by find_paths() was not 1, but was %d' \
        % len(result)
    assert result[0].as_posix() == path.as_posix(), \
        'The actual result: %r does NOT match the expected result: %r' \
        % (result[0].as_posix(), path.as_posix())



# Generated at 2022-06-21 13:03:51.449813
# Unit test for function get_os_group
def test_get_os_group():
    import os
    import test.support
    from pathlib import Path
    from flutils.pathutils import get_os_group

    try:
        import grp as grp_test
    except ImportError:
        test.support.import_module('grp')
        import grp as grp_test

    user = get_os_user()
    group = get_os_group()
    assert isinstance(group, grp_test.struct_group), (
        'Object returned: %r, is not an instance of %r.'
        % (group, grp_test.struct_group)
    )

# Generated at 2022-06-21 13:04:00.772862
# Unit test for function directory_present
def test_directory_present():
    test_path = Path.home() / 'tmp' / 'test_flutils' / 'test_directory_present'
    test_path.mkdir(parents=True, exist_ok=True)
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name

    # Test path does not exist
    test_path = test_path / Path('unit_test')
    assert test_path.exists() is False
    test_path = directory_present(test_path)
    assert isinstance(test_path, Path)
    assert test_path.exists() is True
    assert test_path.is_dir() is True
    assert test_path.owner() == user
    assert test_path.group() == group
    test_path.rmdir()



# Generated at 2022-06-21 13:04:08.813254
# Unit test for function directory_present
def test_directory_present():
    import shutil
    from os import remove
    from os.path import dirname, exists, join
    from pathlib import PosixPath, WindowsPath
    from tempfile import mkdtemp
    from unittest.mock import patch

    from flutils.pathutils import directory_present

    class TestDirectoryPresent:

        def setup(self):
            self.tmp = mkdtemp()
            self.path = join(self.tmp, 'flutils')

            # Change the mode of the temporary directory and the
            # parents.  So we can test if this function will reset
            # permissions.
            os.chmod(dirname(self.path), 0o444)
            os.chmod(self.tmp, 0o444)

            self.path_obj = Path(self.path)

        def teardown(self):
            shutil

# Generated at 2022-06-21 13:04:09.778807
# Unit test for function chmod
def test_chmod():
    return True

# Generated at 2022-06-21 13:04:35.838861
# Unit test for function chown
def test_chown():
    normalize_path(test_chown.__code__.co_filename).touch()
    chown(test_chown.__code__.co_filename)
    chown(test_chown.__code__.co_filename, user='-1', group='-1')
    chown(test_chown.__code__.co_filename, user='root', group='root')
    chown(test_chown.__code__.co_filename, user=0, group=0)
    normalize_path(test_chown.__code__.co_filename).unlink()



# Generated at 2022-06-21 13:04:46.583432
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        test_dir = temp_dir.joinpath('test_dir')
        test_dir.mkdir()

        file_one = test_dir.joinpath('file_one')
        file_one.touch()

        dir_one = test_dir.joinpath('dir_one')
        dir_one.mkdir()

        file_two = Path(temp_dir.joinpath('file_two'))
        file_two.touch()

        glob_path = test_dir.joinpath('*')
        assert set(find_paths(glob_path)) == {
            dir_one,
            file_one,
        }

        glob_path = temp_dir.joinpath('*')

# Generated at 2022-06-21 13:05:00.559259
# Unit test for function exists_as
def test_exists_as():
    import unittest
    import tempfile
    import os
    import shutil
    from pathlib import Path

    class TestExistsAs(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.fifo_path = Path(self.test_dir, 'fifo')
            self.file_path = Path(self.test_dir, 'file')
            self.dir_path = Path(self.test_dir, 'dir')
            self.broken_link_path = Path(self.test_dir, 'broken_link')
            self.link_path = Path(self.test_dir, 'link')
            self.socket_path = Path(self.test_dir, 'socket')

            self.file_path.touch()
            self.dir

# Generated at 2022-06-21 13:05:02.948055
# Unit test for function chmod
def test_chmod():
    from os import PathLike
    from pathlib import (
        Path,
    )
    from typing import (
        Union,
    )

    _PATH = Union[
        PathLike,
        Path,
    ]

    path = Path('/tmp/foo')
    chmod(path, 0o640)
    assert path.stat().st_mode == 0o40640
    chmod(str(path), 0o664)
    assert path.stat().st_mode == 0o40664
    del path

# Generated at 2022-06-21 13:05:12.820131
# Unit test for function chmod

# Generated at 2022-06-21 13:05:24.967978
# Unit test for function get_os_group
def test_get_os_group():
    check_user_group()
    assert get_os_group('root').gr_name == 'root'
    assert get_os_group(0).gr_name == 'root'
    assert get_os_group('root') == get_os_group(0)
    assert get_os_group().gr_gid == get_os_user().pw_gid
    assert get_os_group('foo').gr_name == 'foo'
    assert get_os_group(2002).gr_name == 'foo'
    assert get_os_group('foo') == get_os_group(2002)
    assert get_os_group('bar').gr_name == 'bar'
    assert get_os_group(2001).gr_name == 'bar'