

# Generated at 2022-06-21 12:56:07.436712
# Unit test for function directory_present
def test_directory_present():  # noqa: D202
    path = normalize_path('~/tmp/test_directory')
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True

    path.rmdir()
    assert path.exists() is False

    path = normalize_path('~/tmp/*/test_directory')
    with pytest.raises(ValueError):
        directory_present(path)
        pytest.fail('directory_present() did NOT raise an error for a '
                    'glob pattern.')

    path = normalize_path('tmp/test_directory')
    with pytest.raises(ValueError):
        directory_present(path)
        pytest.fail('directory_present() did NOT raise an error for a '
                    'non-absolute path.')



# Generated at 2022-06-21 12:56:13.898191
# Unit test for function chmod
def test_chmod():
    f = os.environ.get('TEST_FLUTILS_PATHUTILS_CHMOD_FILE')
    d = os.environ.get('TEST_FLUTILS_PATHUTILS_CHMOD_DIR')
    chmod(f, 0o660, 0o770)
    chmod(d, 0o660, 0o770, include_parent=True)



# Generated at 2022-06-21 12:56:16.934719
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == 'root'


from pathlib import PosixPath, WindowsPath
from typing import Any, Generator, Deque, Union
from typing import TYPE_CHECKING

from ._types import _PATH, _STR_OR_INT_OR_NONE

if TYPE_CHECKING:
    _PathGenerator = Generator[PosixPath, None, None]
else:
    _PathGenerator = Generator[Union[PosixPath, WindowsPath], None, None]



# Generated at 2022-06-21 12:56:25.058772
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        file_path = Path.joinpath(Path(tmp_dir), 'flutils.tests.osutils.txt')
        file_path.touch()
        uid = pwd.getpwnam('root').pw_uid
        gid = grp.getgrnam('root').gr_gid
        chown(file_path, user='root', group='root')
        assert file_path.stat().st_uid == uid
        assert file_path.stat().st_gid == gid



# Generated at 2022-06-21 12:56:30.192493
# Unit test for function path_absent
def test_path_absent():
    from pyfakefs.fake_filesystem_unittest import TestCase
    from flutils.pathutils import path_absent

    class TestPathAbsent(TestCase):
        """TestCase for the path_absent function."""
        def setUp(self):
            self.setUpPyfakefs()
            self.new_path = Path('/new/path')
            self.new_path_file = Path('/new/path/file')
            self.old_path = Path('/old/path')
            self.old_path_file = Path('/old/path/file')
            self.system_path = Path('/system/path')
            self.system_path_file = Path('/system/path/file')
            self.filesystem.create_file(self.new_path_file, contents='test')


# Generated at 2022-06-21 12:56:42.779841
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present, path_absent
    from flutils.osutils import get_user_id
    from pathlib import PosixPath
    from os import geteuid
    from stat import S_ISDIR
    from tempfile import TemporaryDirectory

    # Setup data
    uid = geteuid()
    gid = get_user_id(getpass.getuser()).pw_gid
    with TemporaryDirectory() as tmpdir:
        path_str = PosixPath(tmpdir).joinpath('test_path')
        mode = 0o777

        # Test creation of a non-existent path.
        path_absent(path_str)
        path = directory_present(path_str, mode=mode)
        assert path.exists() is True
        assert path.is_dir() is True


# Generated at 2022-06-21 12:56:54.498861
# Unit test for function get_os_user
def test_get_os_user():
    pass
    #assert get_os_user('foo') == pwd.struct_passwd(pw_name='foo',
    #pw_passwd='********', pw_uid=1001, pw_gid=2001, pw_gecos='Foo Bar',
    #pw_dir='/home/foo', pw_shell='/usr/local/bin/bash')
    #assert get_os_user(1002) == pwd.struct_passwd(pw_name='bar',
    #pw_passwd='********', pw_uid=1002, pw_gid=2002, pw_gecos='Bar Foo',
    #pw_dir='/home/bar', pw_shell='/usr/local/bin/bash')



# Generated at 2022-06-21 12:57:03.959624
# Unit test for function path_absent
def test_path_absent():
    """Test function: path_absent
    """

    import os
    import shutil
    import tempfile

    from flutils.pathutils import path_absent

    assert os.path.isdir('./test_temp') is False

    with tempfile.TemporaryDirectory(dir='.') as tmpdir:
        tmpdir = os.path.abspath(tmpdir)
        if os.path.exists(tmpdir) is False:
            os.makedirs(tmpdir)
        fname = os.path.join(tmpdir, 'test_file')
        with open(fname, 'w'):
            pass
        assert os.path.exists(fname) is True
        path_absent(fname)
        assert os.path.exists(fname) is False

# Generated at 2022-06-21 12:57:14.690627
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    from flutils.pathutils import get_os_user

    user = get_os_user()
    assert user
    assert isinstance(user, pwd.struct_passwd)
    user = get_os_user(get_os_user().pw_uid)
    assert user
    assert isinstance(user, pwd.struct_passwd)
    with pytest.raises(OSError) as exc_info:
        get_os_user(-1)
    assert exc_info.match('The given uid')
    with pytest.raises(OSError) as exc_info:
        get_os_user('not a valid user')
    assert exc_info.match('The given name')



# Generated at 2022-06-21 12:57:20.028271
# Unit test for function exists_as
def test_exists_as():
    test_file_path = _get_test_file()

    assert exists_as(test_file_path.as_posix()) == 'file'

    assert exists_as('/tmp/does/not/exist') == ''

    assert exists_as('/dev/null') == 'character device'



# Generated at 2022-06-21 12:57:35.223468
# Unit test for function path_absent
def test_path_absent():
    with Path('~/tmp/test_path_absent/file_one').open('w'):
        pass
    mkdir('~/tmp/test_path_absent/dir_one', mode=0o755)
    path_absent('~/tmp/test_path_absent')
    paths = []
    for path in find_paths('~/tmp/test_path_absent/*'):
        paths.append(path)
    assert [] == paths



# Generated at 2022-06-21 12:57:46.153809
# Unit test for function chmod
def test_chmod():
    # Setup
    from flutils.pathutils import (
        chmod,
        find_paths,
    )
    from os import PathLike
    from pathlib import (
        Path,
        PosixPath,
        WindowsPath,
    )
    from shlex import split as shsplit
    from shutil import (
        rmtree,
        move,
        copytree,
    )
    from subprocess import run
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    # Setup paths
    dir_workdir = Path(TemporaryDirectory().name)
    dir_this = Path(__file__).parent.resolve()
    dir_this_flutils = dir_this.parent
    dir_this_tests = dir_this.joinpath('tests')
    dir_tmp = dir_workdir.joinpath

# Generated at 2022-06-21 12:57:46.811226
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-21 12:57:53.677560
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    from flutils.pathutils import normalize_path

    abspath = os.path.normpath(os.path.abspath(__file__))

    # PosixPath
    p = normalize_path(Path(abspath))
    assert isinstance(p, PosixPath)

    # WindowsPath
    p = normalize_path(Path(abspath.replace(os.path.sep, '/')))
    assert isinstance(p, WindowsPath)

    # bytes
    p = normalize_path(abspath.encode(sys.getfilesystemencoding()))
    assert isinstance(p, PosixPath)

    # str
    p = normalize_path(abspath)
    assert isinstance(p, PosixPath)



# Generated at 2022-06-21 12:58:03.358588
# Unit test for function chmod
def test_chmod():
    from pathlib import Path
    from os import environ

    from .osutils import remove

    assert chmod('flutils.txt') is None
    # A non-existant path is safe
    assert chmod('/tmp/foobar.txt') is None

    path = Path(environ.get('HOME'), 'tmp', 'flutils.tests.osutils.txt')
    if not path.exists():
        path.touch()

    # Changing the mode of a file
    assert chmod(path, 0o660) is None
    assert oct(path.stat().st_mode)[-3:] == '660'

    # Changing the mode of a directory
    path = path.parent
    assert chmod(path, mode_dir=0o770) is None

# Generated at 2022-06-21 12:58:05.263033
# Unit test for function get_os_group
def test_get_os_group():
    g = get_os_group('bar')
    assert g.gr_name == 'bar'
    assert g.gr_gid == 2001


# Generated at 2022-06-21 12:58:12.963024
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('/etc/hosts')) == 'file'
    assert exists_as(Path('/etc')) == 'directory'
    assert exists_as(Path('/dev/fd0')) == 'block device'
    assert exists_as(Path('/dev/tty')) == 'char device'
    assert exists_as(Path('/dev/urandom')) == ''
    assert exists_as(Path('/dev/tty')) == 'char device'
    assert exists_as(Path('/dev/random')) == 'FIFO'
    assert exists_as(Path('/dev/pts')) == 'directory'



# Generated at 2022-06-21 12:58:22.878240
# Unit test for function directory_present
def test_directory_present():
    import shutil

    from pathlib import PosixPath

    from .osutils import (
        make_directory,
        make_file,
    )

    with make_directory() as directory:
        with make_file(directory / 'test_file') as test_file:
            assert test_file.parent.exists() is True
            try:
                directory_present(test_file)
            except FileExistsError as err:
                assert str(err) == (
                    'The path: %s can NOT be created as a directory because '
                    'it already exists as a file.'
                    % test_file.as_posix()
                )
            else:
                raise AssertionError(
                    'Expected directory_present() to raise a '
                    'FileExistsError but it did not.'
                )

# Generated at 2022-06-21 12:58:28.970939
# Unit test for function get_os_group
def test_get_os_group():

    # Current user's gid
    user = get_os_group()
    assert isinstance(user, grp.struct_group)

    # Invalid gid
    with pytest.raises(OSError):
        get_os_group(9999)

    # Invalid group name
    with pytest.raises(OSError):
        get_os_group('_!%*!')

    # Valid gid, the current user's gid.
    user = get_os_group()
    assert get_os_group(user.gr_gid).gr_name == user.gr_name

    # Valid group name
    group = get_os_group()
    assert get_os_group(group.gr_name).gr_name == group.gr_name



# Generated at 2022-06-21 12:58:41.588488
# Unit test for function chmod
def test_chmod():
    path = Path('~/tmp/flutils.tests.osutils.txt')
    if path.exists():
        os.remove(path)
    path = Path('~/tmp/flutils.tests.osutils.dir')
    if path.exists():
        os.rmdir(path)

    with pytest.raises(FileNotFoundError):
        path.chmod(0o644)

    path.touch()
    path.chmod(0o644)
    path_stat = path.stat()
    mode_file = path_stat.st_mode & 0o777
    assert mode_file == 0o644

    path = path.parent
    path.mkdir()
    path.chmod(0o750)
    path_stat = path.stat()
    mode_dir = path_stat.st_

# Generated at 2022-06-21 12:59:17.028432
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from flutils.pathutils import directory_present
    from tests.pathutils.test_common import TEST_PATH, _teardown_mkdir


# Generated at 2022-06-21 12:59:29.093389
# Unit test for function directory_present
def test_directory_present():
    from .test_osutils import get_test_path
    from datetime import datetime
    from tempfile import NamedTemporaryFile
    from time import sleep

    # Test: exists as directory
    test_path = get_test_path('test_dir_dir')

    assert test_path.exists()
    assert exists_as(test_path) == 'directory'

    directory_present(test_path)

    test_path_stat = os.stat(test_path)
    test_path_uid = test_path_stat.st_uid
    test_path_gid = test_path_stat.st_gid
    test_path_mode = test_path_stat.st_mode

    assert test_path_stat.st_atime == 0
    assert test_path_stat.st_ctime == 0
   

# Generated at 2022-06-21 12:59:31.727878
# Unit test for function get_os_group
def test_get_os_group():
    get_os_group()
# vim modeline
# vim: autoindent tabstop=4 shiftwidth=4 expandtab softtabstop=4 filetype=python

# Generated at 2022-06-21 12:59:39.753504
# Unit test for function chmod
def test_chmod():
    """Unit tests for function chmod."""

    from tempfile import TemporaryDirectory

    # Since we are creating the files,
    # lets limit the chmod to u+rw
    mode_file = 0o600
    mode_dir = 0o700

    with TemporaryDirectory() as tmp_dir:

        # Lets create a directory
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()

        # Lets test a file
        file_path = tmp_dir.joinpath('flutils.tests.file')
        file_path.write_text('some text')

        chmod(file_path, mode_file)
        assert file_path.stat().st_mode == mode_file

        file_path.unlink()

        # Lets test a directory

# Generated at 2022-06-21 12:59:40.901740
# Unit test for function chown
def test_chown():
    assert True


# Generated at 2022-06-21 12:59:46.238143
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from flutils.randomutils import get_random_alpha_str
    from flutils.permissions import is_readable, is_writable
    from flutils.pathutils import chmod

    with TemporaryDirectory() as tmp:
        test_txt = Path(tmp).joinpath(get_random_alpha_str(12) + '.txt')
        test_txt.touch()

        # Do not set a mode
        chmod(test_txt)
        assert test_txt.is_file() is True
        assert test_txt.stat().st_mode & 0o777 == 0o600
        assert is_readable(test_txt) is True
        assert is_writable(test_txt) is True

        # Set a mode
        chmod(test_txt, mode_file=0o666)
        assert test

# Generated at 2022-06-21 12:59:55.164000
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path(Path('~/tmp/foo/../bar'))
    assert path.as_posix() == os.path.join(
        os.path.expanduser('~'),
        'tmp/bar'
    )
    assert path.as_posix() == '/tmp/bar'
    path = normalize_path('~/tmp/foo/../bar')
    assert path.as_posix() == os.path.join(
        os.path.expanduser('~'),
        'tmp/bar'
    )
    assert path.as_posix() == '/tmp/bar'
    path = normalize_path('/tmp/foo/../bar')
    assert path.as_posix() == '/tmp/bar'
    path = normalize_path('TMP/foo/../bar')


# Generated at 2022-06-21 12:59:59.679409
# Unit test for function directory_present
def test_directory_present():
    '''Test directory_present function'''
    try:
        with tempfile.TemporaryDirectory() as temp:
            temp = Path(temp)
            directory_present(f'{temp}/foo/bar')
            assert temp.joinpath('foo/bar').exists()
    except:
        pass

# Generated at 2022-06-21 13:00:04.586250
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from shutil import chown
    from pathlib import Path
    from getpass import getuser

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir_path = tmp_dir / 'dir_present'
        dir_present = tmp_dir / 'dir_present' / 'dir_present'
        assert dir_present.exists() is False

        # Check GLOB
        test_dir = directory_present('%s/*' % tmp_dir_path.as_posix())
        assert test_dir == dir_present
        assert test_dir.exists() is True
        assert test_dir.is_dir() is True

        # Check absolute path
        test_dir = directory_present(str(tmp_dir_path))
        assert test_

# Generated at 2022-06-21 13:00:11.835805
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    if path.is_file():
        path.unlink()
    assert exists_as(path) == ''
    assert exists_as(normalize_path('~')) == 'directory'
    path.touch()
    assert exists_as(path) == 'file'
    path.unlink()
    assert exists_as(path) == ''



# Generated at 2022-06-21 13:00:43.949108
# Unit test for function get_os_group
def test_get_os_group():
    """Test function get_os_group."""
    assert get_os_group('root').gr_gid == 0
    assert get_os_group(12).gr_gid == 12
    with pytest.raises(OSError):
        get_os_group(9000)
    with pytest.raises(OSError):
        get_os_group('foo-bar')



# Generated at 2022-06-21 13:00:52.816654
# Unit test for function get_os_group
def test_get_os_group():
    _msg = 'Did user: %s have expected gid?  Expected: %r; Got: %r'
    _user = get_os_user()
    _grp = get_os_group(_user.pw_name)
    assert _user.pw_gid == _grp.gr_gid, _msg \
        % (_user.pw_name, _user.pw_gid, _grp.gr_gid)

    if 'bar' in str(get_os_user()):
        _grp = get_os_group('bar')
        assert _grp.gr_gid == 2001, _msg \
            % ('bar', 2001, _grp.gr_gid)
    else:
        with raises(OSError):
            get_os_group('bar')


# Generated at 2022-06-21 13:01:01.650136
# Unit test for function path_absent
def test_path_absent():
    path = os.path.join('~', 'tmp', 'test_dir')
    path_dir = os.path.join(path, 'dir_one')
    path_file = os.path.join(path, 'file_one')

    pathlib.Path(path_dir).mkdir(mode=0o770, parents=True)
    pathlib.Path(path_file).touch(mode=0o760)

    assert path_file == os.path.join(path, 'file_one')

    path_absent(path)

    path = pathlib.Path(path)
    assert path.exists() is False

# Generated at 2022-06-21 13:01:05.410972
# Unit test for function chmod
def test_chmod():
    test_file = Path(os.getcwd()) / 'tmp' / 'flutils.tests.osutils.txt'
    test_file.parent.mkdir(exist_ok=True, mode=0o770)
    test_file.touch(mode=0o660)

    chmod(test_file, include_parent=True)



# Generated at 2022-06-21 13:01:11.464207
# Unit test for function path_absent
def test_path_absent():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    from pathlib import Path
    from unittest.mock import patch

    from flutils.pathutils import path_absent

    cwd = os.getcwd()
    test_path = Path(tempfile.mkdtemp())

    def _make_symlink():
        from pathlib import Path
        from os import symlink

        target = Path('../non_existant_file_or_dir')
        symlink_path = Path(tempfile.mkdtemp(), 'target_link')
        symlink(target, symlink_path)
        return symlink_path

    def _rmtree(path: str) -> None:
        from pathlib import Path
        import shutil


# Generated at 2022-06-21 13:01:22.649661
# Unit test for function path_absent
def test_path_absent():
    test_path = '/tmp/test_path'
    if os.path.exists(test_path):
        shutil.rmtree(test_path)
    os.makedirs(test_path)
    assert os.path.exists(test_path)
    with open(os.path.join(test_path, 'foobar'), 'w') as f:
        f.write('foobar')
    path_absent(test_path)
    assert not os.path.exists(test_path)
    os.makedirs(test_path)
    with open(os.path.join(test_path, 'foobar'), 'w') as f:
        f.write('foobar')
    path_absent('/tmp/test_path/foobar')

# Generated at 2022-06-21 13:01:25.452370
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    if _PYVER > 3.2:
        assert get_os_user().pw_uid == os.getuid()
    assert get_os_user(1001).pw_uid == 1001
    assert get_os_user(os.getuid()).pw_name == getpass.getuser()



# Generated at 2022-06-21 13:01:39.758029
# Unit test for function directory_present
def test_directory_present():
    expected = (
        'Unable to create the directory: \'%s\' because the'
        'parent path: \'%s\' exists as a %s.'
    )

    with pytest.raises(ValueError) as excinfo:
        directory_present(
            '~/tmp/**/foo', mode=0o700, user='foo', group='bar'
        )

    excinfo.match(
        'The path: \'~/tmp/**/foo\' must NOT contain any glob patterns.'
    )

    with pytest.raises(ValueError) as excinfo:
        directory_present('tmp/foo', mode=0o700, user='foo', group='bar')


# Generated at 2022-06-21 13:01:47.225604
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from tempfile import TemporaryDirectory
    from tests.data.contextmanagers import working_directory

    with TemporaryDirectory() as tmpdir:
        with working_directory(tmpdir):
            path = Path('foo')
            path.mkdir(0o755)
            assert exists_as(path) == 'directory'

            filepath = path / 'file'
            filepath.touch(mode=0o644)
            assert exists_as(filepath) == 'file'



# Generated at 2022-06-21 13:01:59.780988
# Unit test for function get_os_group
def test_get_os_group():
    import getpass
    u = getpass.getuser()
    # Try to get the current user.
    assert isinstance(get_os_group(u).gr_name, str)
    assert isinstance(get_os_group(u).gr_passwd, str)
    assert isinstance(get_os_group(u).gr_gid, int)
    assert isinstance(get_os_group(u).gr_mem, list)
    assert get_os_group(u).gr_name == u
    # Try to get a default for the current user.
    assert isinstance(get_os_group().gr_name, str)
    assert isinstance(get_os_group().gr_passwd, str)
    assert isinstance(get_os_group().gr_gid, int)

# Generated at 2022-06-21 13:03:22.796507
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')

# Generated at 2022-06-21 13:03:31.485732
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths"""
    env_file = TESTS_DOT_ENV_FILE
    ensure_dot_env_file(env_file)
    if env_file is not None:
        load_dot_env_file(env_file)

    with TemporaryDirectory(prefix='tmp_') as tmp_dir:
        # Create some directories and files to search for.
        dirs: Dict = {
            'dir_one': (0o750, 'foo', 'bar'),
            'dir_two': (0o755, 'foo', 'bar'),
            'dir_three': None,
        }


# Generated at 2022-06-21 13:03:33.170560
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group() == grp.getgrgid(os.getgid())



# Generated at 2022-06-21 13:03:44.251854
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('foo').pw_name == 'foo'
    assert str(get_os_user('foo').pw_uid) == str(1001)
    assert get_os_user('foo').pw_gid == 2001
    assert get_os_user('foo').pw_gecos == 'Foo Bar'
    assert get_os_user('foo').pw_dir == '/home/foo'
    assert get_os_user('foo').pw_shell == '/usr/local/bin/bash'
    assert get_os_user(1001).pw_name == 'foo'
    assert str(get_os_user(1001).pw_uid) == str(1001)
    assert get_os_user(1001).pw_gid == 2001
    assert get_os_user(1001).p

# Generated at 2022-06-21 13:03:55.103404
# Unit test for function chmod
def test_chmod():
    """Test chmod function."""
    # Create a file to work with.
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()

    # Test chmod on the file.
    assert path.exists() is True
    assert path.is_file() is True
    assert path.stat().st_mode & 0o777 == 0o600
    chmod(path, 0o644)
    assert path.stat().st_mode & 0o777 == 0o644

    # Test chmod on the directory.
    assert path.parent.exists() is True
    assert path.parent.is_dir() is True
    assert path.parent.stat().st_mode & 0o777 == 0o700

# Generated at 2022-06-21 13:04:03.302601
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory(dir=os.getcwd()) as tmpdir:
        (Path(tmpdir) / 'file_one').touch()
        (Path(tmpdir) / 'dir_one').mkdir()
        globs = find_paths((Path(tmpdir) / '*').as_posix())
        assert globs is not None
        paths = [path.as_posix() for path in globs]
        assert paths
        assert (Path(tmpdir) / 'file_one').as_posix() in paths
        assert (Path(tmpdir) / 'dir_one').as_posix() in paths
        assert (Path(tmpdir) / 'file_two').as_posix() not in paths
        assert (Path(tmpdir) / 'dir_two').as_posix() not in paths



# Generated at 2022-06-21 13:04:14.634039
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.get_os import is_posix

    if is_posix():
        # Name
        assert get_os_group('root').gr_name == 'root'
        assert get_os_group('root').gr_gid == 0

        # Gid
        assert get_os_group(99).gr_name == 'nobody'
        assert get_os_group(99).gr_gid == 99
    else:
        # Name
        assert get_os_group('Administrators').gr_name == 'Administrators'
        assert get_os_group('Administrators').gr_gid == 544

        # Gid
        assert get_os_group(513).gr_name == 'NETWORK SERVICE'
        assert get_os_group(513).gr_gid == 513



# Generated at 2022-06-21 13:04:26.347036
# Unit test for function find_paths
def test_find_paths():
    base_path = '~/tmp/glob_find_paths'
    base_path = normalize_path(base_path)
    base_path.mkdir(parents=True)

    # Create a file
    file_path = base_path / 'file_one'
    file_path.touch()

    # Create a directory
    dir_path = base_path / 'dir_one'
    dir_path.mkdir()

    # Test a glob pattern that should find both the file and the directory
    pattern = base_path / '*'
    assert file_path.as_posix() in [path.as_posix() for path in find_paths(pattern)]
    assert dir_path.as_posix() in [path.as_posix() for path in find_paths(pattern)]

    # Test a

# Generated at 2022-06-21 13:04:35.783445
# Unit test for function normalize_path
def test_normalize_path():
    users_home = Path(os.path.expanduser('~'))
    assert normalize_path('~/tmp') == users_home / 'tmp'
    assert normalize_path('/tmp') == Path('/tmp')
    try:
        assert normalize_path('$HOME/tmp') == users_home / 'tmp'
    except AssertionError:
        assert normalize_path('${HOME}/tmp') == users_home / 'tmp'
    assert normalize_path('foo/../bar') == Path('bar')
    assert normalize_path(users_home / 'tmp') == users_home / 'tmp'



# Generated at 2022-06-21 13:04:46.542059
# Unit test for function normalize_path
def test_normalize_path():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(test_dir)

    test_path_1 = '~/tmp/foo/../bar'
    test_path_2 = '$HOME/tmp/foo/../bar'
    test_path_3 = '~/tmp/foo/../../bar'
    test_path_4 = '../test/test_pathutils.py'
    test_path_5 = 'test/test_pathutils.py'

    # test_path_1 should return the same as test_path_2
    assert normalize_path(test_path_1) == normalize_path(test_path_2)

    # test_path_1 should NOT be the same as test_path_3