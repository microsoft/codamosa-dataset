

# Generated at 2022-06-17 19:29:08.010936
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:29:10.827189
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        paths = list(find_paths(tmpdir / '*'))
        assert len(paths) == 2
        assert file_one in paths
        assert dir_one in paths



# Generated at 2022-06-17 19:29:21.451196
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rmtree

    temp_dir = get_temp_dir()
    test_dir = mkdir(temp_dir / 'test_dir')
    test_file = touch(test_dir / 'test_file')


# Generated at 2022-06-17 19:29:31.964460
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import find_paths
    from flutils.systemutils import get_os_name
    from flutils.systemutils import get_os_version
    from flutils.systemutils import get_os_release
    from flutils.systemutils import get_os_distribution
    from flutils.systemutils import get_os_distribution_version
    from flutils.systemutils import get_os_

# Generated at 2022-06-17 19:29:39.254543
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_a_link') == ''



# Generated at 2022-06-17 19:29:45.723192
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:29:50.095433
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path.mkdir()
        path_absent(path)
        assert path.exists() is False



# Generated at 2022-06-17 19:30:01.044211
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch
    from pathlib import Path
    from typing import Generator

    temp_dir = get_temp_dir()
    temp_dir = normalize_path(temp_dir)
    file_one = temp_dir.joinpath('file_one')
    file_two = temp_dir.joinpath('file_two')
    dir_one = temp_dir.joinpath('dir_one')
    dir_two = temp_dir.joinpath('dir_two')
    dir_three = temp_dir.joinpath('dir_three')

# Generated at 2022-06-17 19:30:10.338807
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert path.exists()
        path_absent(path)
        assert not path.exists()
        path_present(path)
        assert path.exists()
        path_present(path / 'foo')
        assert (path / 'foo').exists()
        path_absent(path)
        assert not path.exists()
        assert not (path / 'foo').exists()
        path_present(path)
        assert path.exists()
        path_present(path / 'foo')

# Generated at 2022-06-17 19:30:19.147030
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_homedir
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:30:48.075964
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:30:59.542214
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_user

    path = directory_present('~/tmp/flutils.tests.pathutils.test_directory_present')
    assert path.is_absolute() is True
    assert path.exists() is True
    assert path.is_dir() is True
    assert exists_as(path) == 'directory'
    assert path.owner() == get_os_user().pw_name
    assert path.group() == get_os_user().pw_name

    path_absent(path)



# Generated at 2022-06-17 19:31:03.816310
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as

    path = '~/tmp/test_path'
    path_present(path)
    path = normalize_path(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''



# Generated at 2022-06-17 19:31:13.825012
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_chmod_file(self):
            path = os.path.join(self.tmpdir, 'test.txt')
            with open(path, 'w') as f:
                f.write('test')

            chmod(path, 0o660)
            self.assertEqual(
                oct(os.stat(path).st_mode)[-3:],
                '660'
            )


# Generated at 2022-06-17 19:31:25.915715
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one', 'file_two').touch()
        tmp_dir.joinpath('dir_one', 'dir_two').mkdir()
        tmp_dir.joinpath('dir_one', 'dir_two', 'file_three').touch()


# Generated at 2022-06-17 19:31:36.790251
# Unit test for function chmod
def test_chmod():
    # Test with a glob pattern
    path = Path('~/tmp/flutils.tests.osutils.txt')
    path.touch()
    chmod(path.parent.as_posix() + '/*', 0o660)
    assert path.stat().st_mode == 0o100660
    path.unlink()

    # Test with a glob pattern that does not exist
    path = Path('~/tmp/flutils.tests.osutils.txt')
    chmod(path.parent.as_posix() + '/*', 0o660)
    assert path.exists() is False

    # Test with a glob pattern that does not exist with include_parent
    path = Path('~/tmp/flutils.tests.osutils.txt')

# Generated at 2022-06-17 19:31:37.345447
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:31:48.141017
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6')

# Generated at 2022-06-17 19:31:59.157806
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('/dev/pts/2') == 'char device'
    assert exists_as('/dev/pts/3') == 'char device'
    assert exists_as('/dev/pts/4') == 'char device'

# Generated at 2022-06-17 19:32:08.878281
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        file_two = tmpdir / 'file_two'
        file_two.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmpdir / 'dir_two'
        dir_two.mkdir()

        assert list(find_paths(tmpdir)) == [tmpdir]

# Generated at 2022-06-17 19:32:39.817962
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    tmpdir = tempfile.TemporaryDirectory()
    tmpdir_path = Path(tmpdir.name)

    # Create a file
    file_path = tmpdir_path / 'file.txt'
    file_path.touch()

    # Create a directory
    dir_path = tmpdir_path / 'dir'
    dir_path.mkdir()

    # Create a symlink
    symlink_path = tmpdir_path / 'symlink'
    symlink_path.symlink_to(file_path)

    # Create a symlink to a directory
    dir_symlink_path = tmpdir_path / 'dir_symlink'
    dir_symlink_path.symlink_

# Generated at 2022-06-17 19:32:48.531810
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from tempfile import TemporaryDirectory
    from tempfile import TemporaryFile
    from typing import Optional
    from typing import Union
    from unittest import TestCase
    from unittest.mock import patch

    _PATH = Union[
        PathLike,
        PosixPath,
        WindowsPath,
        bytes,
        str,
    ]



# Generated at 2022-06-17 19:32:57.645645
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_group_members

# Generated at 2022-06-17 19:33:01.215978
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:33:11.461068
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readonly
    from flutils.pathutils import path_is_writable
   

# Generated at 2022-06-17 19:33:19.558929
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:33:27.748651
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one', 'file_two').touch()
        tmpdir.joinpath('dir_one', 'dir_two').mkdir()

        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('dir_one'),
            tmpdir.joinpath('file_one')
        ]


# Generated at 2022-06-17 19:33:38.984864
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_file_name
    from flutils.pathutils import temp_path
    from flutils.pathutils import temp_path_name
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmp_file = temp_file(tmpdir)
        tmp_dir = temp_directory(tmpdir)

        assert list(find_paths(tmpdir)) == [tmp_dir, tmp_file]

# Generated at 2022-06-17 19:33:44.105500
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''



# Generated at 2022-06-17 19:33:57.504274
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'flutils.tests.osutils.txt'
        tmpfile.touch()
        tmpfile.chmod(0o600)
        assert tmpfile.stat().st_mode == 33152

        chmod(tmpfile, 0o660)
        assert tmpfile.stat().st_mode == 33188

        tmpdir.chmod(0o700)
        assert tmpdir.stat().st_mode == 16895

        chmod(tmpdir, 0o770)
        assert tmpdir.stat().st_mode == 17007

        chmod(tmpdir / '*', 0o770)
        assert tmpfile.stat().st_mode == 17007


# Generated at 2022-06-17 19:34:21.606521
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uid_name
    from flutils.osutils import get_os_gid_name
    from flutils.osutils import get_os_user_home

# Generated at 2022-06-17 19:34:32.980679
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import chown
    from flutils.osutils import chmod as os_chmod
    from flutils.osutils import chown as os_chown
    from flutils.osutils import get_os_group as os_get_os_group
    from flutils.osutils import get_os_user as os_get_os_user
    from flutils.osutils import normalize

# Generated at 2022-06-17 19:34:35.991722
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') is None
    assert chown('~/tmp/**') is None
    assert chown('~/tmp/*', user='foo', group='bar') is None


# Generated at 2022-06-17 19:34:45.172894
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:34:52.867146
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gids
    from flutils.osutils import get_os_group_users

# Generated at 2022-06-17 19:34:59.527237
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:35:11.459706
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import temp_dir
    from pathlib import Path

    with temp_dir(prefix='test_find_paths_') as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()
        tmp_dir = normalize_path(tmp_dir)

        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_two').mkdir()


# Generated at 2022-06-17 19:35:21.662184
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_version
    from flutils.osutils import get_os_release
    from flutils.osutils import get_os_system
    from flutils.osutils import get_os_machine
    from flutils.osutils import get_os_processor
    from flutils.osutils import get_os_platform
    from flutils.osutils import get_os_uname

# Generated at 2022-06-17 19:35:34.252652
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import write_file
    from flutils.pathutils import directory_present
    from flutils.pathutils import remove_paths
    from flutils.pathutils import remove_path
    from flutils.pathutils import remove_file

    test_dir = normalize_path('~/tmp/flutils.tests.pathutils.find_paths')
    test_dir.mkdir(parents=True, exist_ok=True)
    test_file = test_dir / 'test_file.txt'
    test_file.touch()

    test_dir_one = test_dir / 'test_dir_one'
    test_dir_one.mkdir()

    test_dir_two = test_dir

# Generated at 2022-06-17 19:35:46.823463
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_ABS,
        TEST_DIR_REL,
        TEST_FILE,
        TEST_FILE_ABS,
        TEST_FILE_REL,
        TEST_SYMLINK,
        TEST_SYMLINK_ABS,
        TEST_SYMLINK_REL,
    )

    assert exists_as(TEST_DIR) == 'directory'
    assert exists_as(TEST_DIR_ABS) == 'directory'
    assert exists_as(TEST_DIR_REL) == 'directory'

    assert exists_as(TEST_FILE) == 'file'

# Generated at 2022-06-17 19:36:05.373551
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import remove
    from flutils.osutils import stat
    from flutils.osutils import stat_mode

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    mkdir(path.parent, mode=0o700)
    touch(path, mode=0o600)
    chmod(path, mode_file=0o660)
    assert stat_mode(path) == 0o660
    remove(path)
    remove(path.parent)



# Generated at 2022-06-17 19:36:15.764321
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch

    temp_dir = get_temp_dir()
    temp_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

# Generated at 2022-06-17 19:36:24.581700
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown
    from flutils.pathutils import chmod
    from flutils.pathutils import path_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown
    from flutils.pathutils import chmod

# Generated at 2022-06-17 19:36:30.269532
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from os import PathLike
    from os import chmod as os_chmod
    from os import chown as os_chown

# Generated at 2022-06-17 19:36:33.902782
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
    )
    chown(TEST_DIR, include_parent=True)
    chown(TEST_FILE)



# Generated at 2022-06-17 19:36:39.510192
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    # Test that a directory is created.
    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    path_absent(path)

    # Test that a directory is created with a mode.
    path = directory_present('~/tmp/test_path', mode=0o755)
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    path_absent(path)

    # Test that a directory is created with a user.


# Generated at 2022-06-17 19:36:47.750313
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, 'foo.txt')
            with open(self.tempfile, 'w') as f:
                f.write('foo')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_chown_file(self):
            chown(self.tempfile)
            self.assertEqual(os.stat(self.tempfile).st_uid, os.getuid())

# Generated at 2022-06-17 19:36:58.497320
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir()
        assert exists_as(tmpdir) == 'directory'

        tmpfile = tmpdir / 'tmpfile'
        tmpfile.touch()
        assert exists_as(tmpfile) == 'file'

        tmpdir2 = tmpdir / 'tmpdir'
        tmpdir2.mkdir()
        assert exists_as(tmpdir2) == 'directory'

        tmpfile2 = tmpdir2 / 'tmpfile2'
        tmpfile2.touch()
        assert exists_as(tmpfile2) == 'file'


# Generated at 2022-06-17 19:37:06.963886
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('dir_three').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('dir_three').joinpath

# Generated at 2022-06-17 19:37:17.816501
# Unit test for function chmod
def test_chmod():
    # Test with a file
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660
    path.unlink()

    # Test with a directory
    path = Path('/tmp/flutils.tests.osutils')
    path.mkdir()
    chmod(path, mode_dir=0o770)
    assert path.stat().st_mode & 0o777 == 0o770
    path.rmdir()

    # Test with a glob pattern
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    chmod('/tmp/flutils.tests.osutils.*', 0o660)
    assert path.stat

# Generated at 2022-06-17 19:38:02.688843
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_all
    from flutils.osutils import get_os_group_members_recursive_all_groups

# Generated at 2022-06-17 19:38:10.398487
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import Optional
    from unittest import TestCase

    class TestDirectoryPresent(TestCase):
        def setUp(self):
            self.tmp_dir = TemporaryDirectory()
            self.tmp_dir_path = Path(self.tmp_dir.name)
            self.test_path = self.tmp_dir_path / 'test_path'

# Generated at 2022-06-17 19:38:15.864428
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:38:25.018248
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_version
    from flutils.osutils import get_os_release
    from flutils.osutils import get_os_system
    from flutils.osutils import get_os_machine
    from flutils.osutils import get_os_processor