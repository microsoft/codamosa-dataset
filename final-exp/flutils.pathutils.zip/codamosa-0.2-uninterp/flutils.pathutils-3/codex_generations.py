

# Generated at 2022-06-17 19:29:12.049680
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')
    tmp_dir_two = os.path.join(tmp_dir_one, 'tmp_dir_two')
    tmp_file_one = os.path.join(tmp_dir_one, 'tmp_file_one')
    tmp_file_two = os.path.join(tmp_dir_two, 'tmp_file_two')

    with open(tmp_file, 'w') as f:
        f.write('Test')


# Generated at 2022-06-17 19:29:22.385490
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'
    assert exists_as('/dev/tty5') == 'char device'
    assert exists_as

# Generated at 2022-06-17 19:29:32.344113
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.txt')

    chmod(tmp_file, 0o660)
    assert os.stat(tmp_file).st_mode & 0o777 == 0o660

    chmod(tmp_file, 0o600)
    assert os.stat(tmp_file).st_mode & 0o777 == 0o600

    chmod(tmp_file, 0o660)

# Generated at 2022-06-17 19:29:41.672345
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    assert exists_as(normalize_path('~/tmp')) == 'directory'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt')) == 'file'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/')) == ''
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/foo')) == ''
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/foo/bar')) == ''

# Generated at 2022-06-17 19:29:50.977814
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a temporary directory
    tmp_dir_2 = os.path.join(tmp_dir, 'tmp_dir_2')
    os.mkdir(tmp_dir_2)

    # Create a temporary file
    tmp_file_2 = os.path.join(tmp_dir_2, 'tmp_file_2')

# Generated at 2022-06-17 19:29:57.089156
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmp_dir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:30:07.406729
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

# Generated at 2022-06-17 19:30:16.302522
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / 'flutils.tests.osutils.txt'
        tmp_file.touch()
        tmp_file.chmod(0o600)

        # Test chmod() with a single file.

# Generated at 2022-06-17 19:30:16.813319
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:30:23.822490
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import mkdir as os_mkdir
    from os import stat as os_stat
    from os import utime as os_utime
    from os import path as os_path
    from os import remove as os_remove
    from os import rmdir as os_rmdir


# Generated at 2022-06-17 19:30:57.634168
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_

# Generated at 2022-06-17 19:31:05.945564
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    import stat
    import pytest
    from flutils.pathutils import chown

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    fname = os.path.join(tmpdir, 'testfile')
    with open(fname, 'w') as f:
        f.write('test')

    # Get the uid/gid of the current user
    uid = pwd.getpwuid(os.getuid()).pw_uid
    gid = grp.getgrgid(os.getgid()).gr_gid

    # Change the ownership of the file
    chown(fname)

    # Check the ownership of the file

# Generated at 2022-06-17 19:31:12.162029
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''



# Generated at 2022-06-17 19:31:20.011328
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file

    with temp_directory() as tmpdir:
        with temp_file(dir=tmpdir) as tmpfile:
            assert exists_as(tmpdir) == 'directory'
            assert exists_as(tmpfile) == 'file'

    assert exists_as(normalize_path('/dev/null')) == 'char device'
    assert exists_as(normalize_path('/dev/zero')) == 'char device'
    assert exists_as(normalize_path('/dev/random')) == 'char device'

# Generated at 2022-06-17 19:31:30.368368
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    tmp_dir_one = os.path.join(tmp_dir, 'test_dir_one')
    tmp_dir_two = os.path.join(tmp_dir_one, 'test_dir_two')
    tmp_file_one = os.path.join(tmp_dir_one, 'test_file_one')
    tmp_file_two = os.path.join(tmp_dir_two, 'test_file_two')

# Generated at 2022-06-17 19:31:31.127210
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:31:39.576741
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_group, get_os_user
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_MODE,
        TEST_FILE_OWNER,
        TEST_FILE_GROUP,
        TEST_DIR_MODE,
        TEST_DIR_OWNER,
        TEST_DIR_GROUP,
    )

    # Test changing the mode of a file
    chmod(TEST_FILE, mode_file=0o660)
    assert oct(TEST_FILE_MODE) == '0o660'

    # Test changing the mode of a directory
    chmod(TEST_DIR, mode_dir=0o770)
    assert oct(TEST_DIR_MODE) == '0o770'

# Generated at 2022-06-17 19:31:48.965327
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_ONE,
        TEST_DIR_TWO,
        TEST_FILE_ONE,
        TEST_FILE_TWO,
    )
    from flutils.tests.osutils import (
        TEST_USER,
        TEST_GROUP,
    )

    # Create the test directory
    directory_present(TEST_DIR, mode=0o700, user=TEST_USER, group=TEST_GROUP)

    # Create the test directory one
    directory_present(
        TEST_DIR_ONE,
        mode=0o700,
        user=TEST_USER,
        group=TEST_GROUP
    )

    # Create the

# Generated at 2022-06-17 19:31:58.088477
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import remove
    from flutils.osutils import get_mode
    from flutils.osutils import get_uid
    from flutils.osutils import get_gid
    from flutils.osutils import get_user
    from flutils.osutils import get_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_home

# Generated at 2022-06-17 19:32:08.018163
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_set
    from flutils.osutils import get_os_group_members_set
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:32:42.162667
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_present
    from flutils.pathutils import path_present_as_file
    from flutils.pathutils import path_present_as_directory
    from flutils.pathutils import path_present_as_symlink
    from flutils.pathutils import path_present_as_block_device
    from flutils.pathutils import path_present_as_char_device
    from flutils.pathutils import path_present_as_fifo
    from flutils.pathutils import path_present_as_socket

    # Create a temporary directory to work in.
    tmpdir = tempfile.mkdtemp()

    # Create a file

# Generated at 2022-06-17 19:32:52.947617
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.osutils import create_temp_dir
    from flutils.osutils import create_temp_file
    from flutils.osutils import remove_path

    with create_temp_dir() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        with create_temp_file(dir=tmp_dir) as tmp_file:
            tmp_file = Path(tmp_file)
            with create_temp_dir(dir=tmp_dir) as tmp_dir_two:
                tmp_dir_two = Path(tmp_dir_two)
                paths = list(find_paths(tmp_dir / '*'))
                assert tmp_file in paths
                assert tmp_dir_two in paths


# Generated at 2022-06-17 19:33:00.618710
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import remove_path
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_CONTENTS,
        TEST_FILE_MODE,
        TEST_FILE_MODE_DIR,
        TEST_FILE_MODE_FILE,
        TEST_FILE_MODE_FILE_NEW,
        TEST_FILE_MODE_DIR_NEW,
        TEST_FILE_MODE_FILE_NEW_STR,
        TEST_FILE_MODE_DIR_NEW_STR,
    )

    # Test that a file is chmod'd
    remove_path(TEST_FILE)
    with open(TEST_FILE, 'w') as f:
        f.write(TEST_FILE_CONTENTS)

# Generated at 2022-06-17 19:33:11.064034
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path

# Generated at 2022-06-17 19:33:23.036790
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:33:30.060784
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:33:39.849907
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths

    path = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    path.touch()
    assert exists_as(path, 'file') is True
    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660
    path.unlink()
    assert path_absent(path) is True

    path = normalize_path('~/tmp/flutils.tests.pathutils')
    directory_present(path)
    assert exists_as

# Generated at 2022-06-17 19:33:44.563838
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:33:49.911090
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-17 19:34:00.368215
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:34:14.440034
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-17 19:34:23.579453
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_passwd
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_

# Generated at 2022-06-17 19:34:35.284910
# Unit test for function path_absent
def test_path_absent():
    # Test that the function works with a directory.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(mode=0o700)
        path = tmpdir / 'test_path'
        path.mkdir(mode=0o700)
        path_absent(path)
        assert path.exists() is False
        assert tmpdir.exists() is True
        path_absent(tmpdir)
        assert tmpdir.exists() is False

    # Test that the function works with a file.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(mode=0o700)
        path = tmpdir / 'test_path'
        path.touch(mode=0o700)

# Generated at 2022-06-17 19:34:46.329800
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import Generator
    from typing import Optional
    from typing import Any
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import Deque
    from typing import Dict

# Generated at 2022-06-17 19:34:53.635632
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:35:03.261393
# Unit test for function chown
def test_chown():
    """Test the chown function."""
    import os
    import tempfile
    from flutils.pathutils import chown

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path.as_posix())
    tmp_file_path = Path(tmp_file.name)

    # Create a temporary sub-directory
    tmp_sub_dir = tempfile.TemporaryDirectory(dir=tmp_dir_path.as_posix())
    tmp_sub_dir_path = Path(tmp_sub_dir.name)

    # Create a temporary sub-file

# Generated at 2022-06-17 19:35:03.920917
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:35:15.553973
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gids
    from flutils.osutils import get_os_group_users

# Generated at 2022-06-17 19:35:23.420033
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        # Create a temporary file
        with tempfile.NamedTemporaryFile(dir=tmpdir) as tmpfile:
            tmpfile = Path(tmpfile.name)
            # Create a temporary directory
            with tempfile.TemporaryDirectory(dir=tmpdir) as tmpdir2:
                tmpdir2 = Path(tmpdir2)
                # Create a temporary file
                with tempfile.NamedTemporaryFile(dir=tmpdir2) as tmpfile2:
                    tmpfile2 = Path(tmpfile2.name)
                    # Create a temporary symbolic link
                    with tempfile.NamedTemporaryFile(dir=tmpdir2) as tmpfile3:
                        tmpfile3 = Path(tmpfile3.name)


# Generated at 2022-06-17 19:35:27.202718
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:36:25.279696
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_uidgidname
    from flutils.osutils import get_os_uidgid_from_name

# Generated at 2022-06-17 19:36:35.851194
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_dir

# Generated at 2022-06-17 19:36:40.296956
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temporary_directory
    from flutils.pathutils import temporary_file

    with temporary_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        assert exists_as(tmp_dir) == 'directory'

        with temporary_file(dir=tmp_dir) as tmp_file:
            tmp_file = normalize_path(tmp_file)
            assert exists_as(tmp_file) == 'file'



# Generated at 2022-06-17 19:36:48.024513
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_giduid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get

# Generated at 2022-06-17 19:36:59.189576
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_ids
    from flutils.osutils import get_os_group_members_ids
    from flutils.osutils import get_os_group_members_recursive_ids
   

# Generated at 2022-06-17 19:36:59.751361
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:37:06.296223
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    path = normalize_path('~/tmp/test_path')
    path = path.as_posix()
    path = cast(str, path)

    path_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''



# Generated at 2022-06-17 19:37:15.836673
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path_absent(path)
    assert not path.exists()
    path.mkdir(parents=True)
    path_absent(path)
    assert not path.exists()
    path.mkdir(parents=True)
    Path(path, 'file_one').touch()
    Path(path, 'file_two').touch()
    Path(path, 'dir_one').mkdir()
    Path(path, 'dir_two').mkdir()
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:37:27.892852
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_chmod.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o660

    chmod(tmp_file, 0o600)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o600

    chmod(tmp_file, 0o660, 0o770)

# Generated at 2022-06-17 19:37:39.615591
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import path_absent
    from flutils.pathutils import chmod
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:38:01.939615
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:38:08.121988
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_MODE,
        TEST_DIR_MODE,
    )

    chmod(TEST_FILE, mode_file=TEST_FILE_MODE)
    chmod(TEST_DIR, mode_dir=TEST_DIR_MODE)



# Generated at 2022-06-17 19:38:15.940646
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_version
    from flutils.osutils import get_os_release
    from flutils.osutils import get_os_system
    from flutils.osutils import get_os_machine
    from flutils.osutils import get_os_processor
    from flutils.osutils import get_os_platform

# Generated at 2022-06-17 19:38:22.814063
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__ + '_foo') == ''
    assert exists_as(__file__ + '_foo') == ''
    assert exists_as(__file__ + '_foo') == ''
    assert exists_as(__file__ + '_foo') == ''
    assert exists_as(__file__ + '_foo') == ''
    assert exists_as(__file__ + '_foo') == ''

