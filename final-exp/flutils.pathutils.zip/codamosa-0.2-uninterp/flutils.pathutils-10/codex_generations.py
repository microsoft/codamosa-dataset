

# Generated at 2022-06-17 19:28:58.188096
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import remove_path

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mk

# Generated at 2022-06-17 19:29:06.034479
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as

    temp_dir = tempfile.mkdtemp()
    try:
        path = os.path.join(temp_dir, 'test_path')
        path_present(path, mode_file=0o600)
        assert exists_as(path) == 'file'
        path_absent(path)
        assert exists_as(path) == ''
    finally:
        shutil.rmtree(temp_dir)



# Generated at 2022-06-17 19:29:16.359980
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') != Path('/home/test_user/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') != Path('/home/test_user/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') != Path('/home/test_user/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') != Path('/home/test_user/tmp/foo/../bar')

# Generated at 2022-06-17 19:29:23.739912
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir_p
    from flutils.osutils import touch
    from flutils.osutils import rm_rf
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown

    tmp_dir = get_temp_dir()
    tmp_dir = normalize_path(tmp_dir)
    tmp_dir = mkdir_p(tmp_dir)

# Generated at 2022-06-17 19:29:24.357228
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:29:33.250584
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir.mkdir()
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()

        paths = list(find_paths(tmpdir.joinpath('*')))
        assert len(paths) == 2
        assert tmpdir.joinpath('file_one') in paths
        assert tmpdir.joinpath('dir_one') in paths

        paths = list(find_paths(tmpdir.joinpath('**')))


# Generated at 2022-06-17 19:29:42.214110
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_group_shell
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_group_gid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_

# Generated at 2022-06-17 19:29:51.275131
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert exists_as(path) == 'directory'
        path_absent(path)
        assert exists_as(path) == ''
        path_present(path)
        assert exists_as(path) == 'directory'
        path_present(path / 'test_file', content='test')
        assert exists_as(path / 'test_file') == 'file'
        path_absent

# Generated at 2022-06-17 19:30:02.632462
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('foo').mkdir()
        tmpdir.joinpath('foo/bar').mkdir()
        tmpdir.joinpath('foo/bar/baz').mkdir()
        tmpdir.joinpath('foo/bar/baz/test_file').touch()
        path_absent(tmpdir.joinpath('foo'))
        assert tmpdir.joinpath('foo').exists() is False
        assert tmpdir.joinpath('foo/bar').exists() is False
        assert tmpdir.joinpath('foo/bar/baz').exists() is False
        assert tmpdir.joinpath('foo/bar/baz/test_file').ex

# Generated at 2022-06-17 19:30:07.000572
# Unit test for function directory_present
def test_directory_present():
    path = Path('~/tmp/flutils.tests.pathutils.directory_present')
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True
    path.rmdir()
    assert path.exists() is False



# Generated at 2022-06-17 19:30:29.792768
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch
    from flutils.osutils import umask

    with umask(0o022):
        tmp_dir = get_temp_dir()
        tmp_file = tmp_dir / 'flutils.tests.osutils.txt'
        touch(tmp_file)

        # Test a file
        chmod(tmp_file, 0o660)
        assert tmp_file.stat().st_mode == 0o100660

        # Test a directory
        chmod(tmp_dir, 0o770)
        assert tmp_dir.stat().st_mode == 0o40770

        # Test a glob pattern

# Generated at 2022-06-17 19:30:34.321151
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory.
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file.
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f.write('foo')

    # Create a temporary directory.
    temp_dir_two = os.path.join(temp_dir, 'temp_dir')
    os.mkdir(temp_dir_two)

    # Create a temporary file in the temporary directory.
    temp_file_two = os.path.join(temp_dir_two, 'temp_file_two')

# Generated at 2022-06-17 19:30:38.665249
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user('root').pw_uid == 0
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-17 19:30:43.144573
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not') == ''



# Generated at 2022-06-17 19:30:57.812974
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    import os
    import tempfile
    import shutil
    import pathlib
    import stat

    # Create a temporary directory to work in.
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = pathlib.Path(tmp_dir)
    tmp_dir = normalize_path(tmp_dir)

    # Create a temporary file to work with.
    tmp_file = tmp_dir / 'tmp_file'
    tmp_file = normalize_path(tmp_file)
    tmp_

# Generated at 2022-06-17 19:31:09.956491
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    import stat
    from flutils.pathutils import chown

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:31:16.596297
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')
    chown('~/tmp/flutils.tests.osutils.txt', user='-1', group='-1')
    chown('~/tmp/**', user='-1', group='-1')
    chown('~/tmp/*', user='foo', group='bar', include_parent=True)



# Generated at 2022-06-17 19:31:28.417236
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys
    import pathlib
    import getpass
    import grp
    import pwd
    import functools
    import typing
    from typing import Any, Callable, Dict, Generator, List, Optional, Union
    from pathlib import Path
    from flutils.pathutils import path_absent, normalize_path, exists_as
    from flutils.pathutils import get_os_user, get_os_group
    from flutils.pathutils import chmod, chown
    from flutils.pathutils import create_dir
    from flutils.pathutils import find_paths
    from flutils.pathutils import get_os_user, get_os_group
    from flutils.pathutils import normalize_path


# Generated at 2022-06-17 19:31:35.921305
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir_p
    from flutils.osutils import touch
    from flutils.osutils import remove_path

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    mkdir_p(path.parent)
    touch(path)
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152
    remove_path(path)



# Generated at 2022-06-17 19:31:44.723114
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:32:27.614909
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('/dev/pts/2') == 'char device'
    assert exists_as('/dev/pts/3') == 'char device'

# Generated at 2022-06-17 19:32:39.775023
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == '/Users/len/tmp/flutils.tests.pathutils.directory_present'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == '/Users/len/tmp/flutils.tests.pathutils.directory_present'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')

# Generated at 2022-06-17 19:32:44.738673
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    from flutils.pathutils import get_os_user
    assert get_os_user() == get_os_user(getpass.getuser())
    assert get_os_user(get_os_user().pw_uid) == get_os_user()
    assert get_os_user(get_os_user().pw_name) == get_os_user()



# Generated at 2022-06-17 19:32:56.681843
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils import TEST_DIR
    from flutils.tests.pathutils import TEST_FILE
    from flutils.tests.pathutils import TEST_FILE_CONTENTS
    from flutils.tests.pathutils import TEST_FILE_NAME
    from flutils.tests.pathutils import TEST_FILE_NAME_2
    from flutils.tests.pathutils import TEST_FILE_NAME_3
    from flutils.tests.pathutils import TEST_FILE_NAME_4
    from flutils.tests.pathutils import TEST_FILE_NAME_5
    from flutils.tests.pathutils import TEST_FILE_NAME_6
    from flutils.tests.pathutils import TEST_FILE_NAME_7
    from flutils.tests.pathutils import TEST_FILE_NAME_8

# Generated at 2022-06-17 19:33:07.944494
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_path = normalize_path(tmp_dir.name)
    tmp_file = tmp_path / 'flutils.tests.osutils.txt'
    tmp_file.touch()
    assert tmp_file.exists() is True
    assert tmp_file.is_file() is True

    # Test changing the owner of a file
    chown(tmp_file, user='root')

# Generated at 2022-06-17 19:33:15.476831
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import List

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').joinpath('dir_two').mkdir()

        # Test a glob pattern that matches a directory and a file.
        pattern = normalize_path(tmpdir.joinpath('*'))

# Generated at 2022-06-17 19:33:18.895625
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-17 19:33:22.902418
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user()
    assert get_os_user(os.getuid())
    assert get_os_user(os.getlogin())
    assert get_os_user(os.getlogin()) == get_os_user(os.getuid())
    assert get_os_user(os.getlogin()) == get_os_user()



# Generated at 2022-06-17 19:33:36.077918
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from pathlib import Path
    from os import stat
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import makedirs
    from os import remove
    from os import rmdir
    from os import symlink
    from os import unlink
   

# Generated at 2022-06-17 19:33:48.933330
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(mode=0o700)
        tmpdir.chmod(0o700)
        tmpdir.chown(user=get_os_user().pw_uid, group=get_os_group().gr_gid)
        tmpdir = tmpdir.as_posix()
        tmpdir = cast(str, tmpdir)
        tmpdir = os.path.join(tmpdir, 'foo')
        os.mkdir(tmpdir)
        os.chmod(tmpdir, 0o700)
        os.chown(tmpdir, get_os_user().pw_uid, get_os_group().gr_gid)
        tmpdir = os.path.join(tmpdir, 'bar')


# Generated at 2022-06-17 19:34:12.772908
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken_link.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken_link.link.broken_link') == ''

# Generated at 2022-06-17 19:34:22.119427
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path
    import pathlib
    import stat
    import sys
    import unittest

    class TestPathAbsent(unittest.TestCase):
        """Unit test for function path_absent."""

        def setUp(self):
            """Set up the test fixture."""
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.test_file = os.path.join(self.test_dir, 'test_file')
            with open(self.test_file, 'w') as f:
                f.write('test')

# Generated at 2022-06-17 19:34:30.993101
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_passwd

# Generated at 2022-06-17 19:34:39.145392
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gid
    from flutils.osutils import get_os_group_members_gids

# Generated at 2022-06-17 19:34:48.998926
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from .testutils import TEST_DIR
    from .testutils import TEST_FILE
    from .testutils import TEST_LINK
    from .testutils import TEST_SOCKET
    from .testutils import TEST_SYMLINK
    from .testutils import TEST_TMP_DIR
    from .testutils import TEST_TMP_FILE
    from .testutils import TEST_TMP_LINK
    from .testutils import TEST_TMP_SOCKET
    from .testutils import TEST_TMP_SYMLINK
    from .testutils import TEST_TMP_TMP_DIR
    from .testutils import TEST_TMP_TMP_FILE
    from .testutils import TEST_TMP_TMP_LINK
    from .testutils import TEST_TMP_TMP

# Generated at 2022-06-17 19:35:00.220682
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import pathlib
    import random
    import string
    import sys

    def _random_string(length: int = 10) -> str:
        """Return a random string of letters and digits.

        Args:
            length (:obj:`int`, optional): The length of the string.
                Defaults to 10.

        :rtype: :obj:`str`
        """
        out = ''
        for _ in range(length):
            out += random.choice(string.ascii_letters + string.digits)
        return out


# Generated at 2022-06-17 19:35:04.366265
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:35:04.989343
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:35:16.426432
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent

    # Test to make sure that chmod does not change the mode of a symlink
    # target.

# Generated at 2022-06-17 19:35:23.974476
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from os import chmod
    from os import chown
    from os import stat
    from os import mkdir
    from os import rmdir
    from os import remove
    from os import makedirs
    from os import listdir
    from os import utime
    from os import symlink
    from os import path
    from os import getcwd
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getpid
    from os import getppid

# Generated at 2022-06-17 19:35:56.164473
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link') == ''



# Generated at 2022-06-17 19:36:03.357105
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/console') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'

# Generated at 2022-06-17 19:36:04.294127
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:36:05.503312
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-17 19:36:11.889959
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from pathlib import Path
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_dir = normalize_path(tmp_dir)
    tmp_dir = cast(Path, tmp_dir)

    tmp_file = tmp_dir / 'tmp_file'
    tmp_file = cast(Path, tmp_file)

    tmp_dir_one = tmp_dir / 'tmp_dir_one'
    tmp_dir_one = cast(Path, tmp_dir_one)

    tmp_file_one = tmp_dir_one / 'tmp_file_one'

# Generated at 2022-06-17 19:36:21.677709
# Unit test for function chown
def test_chown():
    # Test with a glob pattern
    chown('~/tmp/**', user='foo', group='bar')
    # Test with a glob pattern and include_parent
    chown('~/tmp/**', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent
    chown('~/tmp/*', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent
    chown('~/tmp/*', user='foo', group='bar')
    # Test with a glob pattern and include_parent
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='bar')
    # Test with a glob pattern and include_parent

# Generated at 2022-06-17 19:36:28.829121
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.osutils import get_uid
    from flutils.osutils import get_gid
    from flutils.osutils import get_user_name
    from flutils.osutils import get_group_name
    from flutils.osutils import get_user_home
    from flutils.osutils import get_user_shell
    from flutils.osutils import get_user_groups
    from flutils.osutils import get_group_members

# Generated at 2022-06-17 19:36:29.990707
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:36:38.084665
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_chmod_file(self):
            path = os.path.join(self.tmpdir, 'test.txt')
            with open(path, 'w') as f:
                f.write('test')

            chmod(path, 0o660)
            self.assertEqual(oct(os.stat(path).st_mode & 0o777), '0o660')


# Generated at 2022-06-17 19:36:46.969052
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:37:20.094046
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod


# Generated at 2022-06-17 19:37:29.873506
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user

# Generated at 2022-06-17 19:37:41.301458
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert path.exists()
        path_absent(path)
        assert path.exists() is False
        path_present(path)
        assert path.exists()
        path_present(path / 'foo')
        assert (path / 'foo').exists()
        path_absent(path)
        assert path.exists() is False
        path_present(path)
        assert path.exists()

# Generated at 2022-06-17 19:37:52.904975
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path_absent(path)
    assert exists_as(path) == ''

    path = directory_present('~/tmp/test_path', mode=0o770)
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path_absent(path)
    assert exists_as(path) == ''


# Generated at 2022-06-17 19:38:04.005261
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_link = os.path.join(tmp_dir, 'tmp_link')
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')
    tmp_dir_two = os.path.join(tmp_dir, 'tmp_dir_two')
    tmp_dir_three = os.path.join(tmp_dir, 'tmp_dir_three')
    tmp_dir_four = os.path.join(tmp_dir, 'tmp_dir_four')

# Generated at 2022-06-17 19:38:13.978024
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_groups
    from flutils.osutils import get_os_groups_ids
    from flutils.osutils import get_os_groups_names
    from flutils.osutils import get_os_groups_users
    from flutils.osutils import get_os_groups_users_ids
   

# Generated at 2022-06-17 19:38:17.643739
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:38:26.136262
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from pathlib import Path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from typing import Deque
    from typing import Generator
    from typing import Optional
    from typing import Union