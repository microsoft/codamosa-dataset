

# Generated at 2022-06-17 19:28:57.418596
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = os.path.normpath(tmp_dir)

    # Create a file
    tmp_file = os.path.join(tmp_dir, 'test_file')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a directory
    tmp_dir_one = os.path.join(tmp_dir, 'test_dir_one')
    os.mkdir(tmp_dir_one)

    # Create a file in the directory

# Generated at 2022-06-17 19:29:01.083017
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'test_path')
        with open(path, 'w') as f:
            f.write('test')
        assert os.path.exists(path)
        path_absent(path)
        assert not os.path.exists(path)
    finally:
        os.rmdir(tmpdir)



# Generated at 2022-06-17 19:29:01.634746
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:29:11.650292
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group

# Generated at 2022-06-17 19:29:15.250368
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:29:25.841821
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Create a temporary directory.
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)

        # Create a file and a directory.
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()

        # Test the find_paths function.
        paths = list(find_paths(tmp_dir / '*'))
        assert len(paths) == 2
        assert file_one in paths
        assert dir_one in paths



# Generated at 2022-06-17 19:29:36.197248
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:29:47.338192
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:29:53.276115
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmp_dir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:30:00.853477
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file

    with temp_directory() as tmpdir:
        with temp_file(tmpdir) as tmpfile:
            assert exists_as(tmpdir) == 'directory'
            assert exists_as(tmpfile) == 'file'
            assert exists_as(normalize_path('~/tmp/does_not_exist')) == ''



# Generated at 2022-06-17 19:30:17.947223
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:30:26.836256
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_gid

# Generated at 2022-06-17 19:30:38.418218
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH

    # Test the path does not exist.
    path = directory_present('~/tmp/flutils.tests.pathutils.test_directory_present')
    assert path.as_posix() == normalize_path('~/tmp/flutils.tests.pathutils.test_directory_present').as_posix()


# Generated at 2022-06-17 19:30:41.912742
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:30:51.090874
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:31:02.059622
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one', 'file_two').touch()
        tmpdir.joinpath('dir_one', 'dir_two').mkdir()
        tmpdir.joinpath('dir_one', 'dir_two', 'file_three').touch()

# Generated at 2022-06-17 19:31:08.803931
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_pwd


# Generated at 2022-06-17 19:31:12.488989
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'flutils.tests.osutils.txt')
    with open(tmpfile, 'w') as f:
        f.write('flutils.tests.osutils')

    try:
        chmod(tmpfile, 0o660)
        assert os.stat(tmpfile).st_mode == 33152
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-17 19:31:20.039554
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory

    with temp_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()

# Generated at 2022-06-17 19:31:28.515923
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path)
    tmp_file_path = Path(tmp_file.name)

    # Create a temporary sub-directory
    tmp_sub_dir = tempfile.TemporaryDirectory(dir=tmp_dir_path)
    tmp_sub_dir_path = Path(tmp_sub_dir.name)

    # Create a temporary file in the sub-directory
    tmp_sub_

# Generated at 2022-06-17 19:31:59.106295
# Unit test for function chmod
def test_chmod():
    # Test with a file
    path = Path('~/tmp/flutils.tests.osutils.txt')
    path.touch()
    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660
    path.unlink()

    # Test with a directory
    path = Path('~/tmp/flutils.tests.osutils.dir')
    path.mkdir()
    chmod(path, mode_file=0o660, mode_dir=0o770)
    assert path.stat().st_mode & 0o777 == 0o770
    path.rmdir()

    # Test with a glob pattern
    path = Path('~/tmp/flutils.tests.osutils.dir')
    path.mkdir()

# Generated at 2022-06-17 19:32:08.842971
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_link = os.path.join(tmp_dir, 'tmp_link')
    tmp_dir_link = os.path.join(tmp_dir, 'tmp_dir_link')
    tmp_dir_link_file = os.path.join(tmp_dir_link, 'tmp_file')
    tmp_dir_link_link = os.path.join(tmp_dir_link, 'tmp_link')
   

# Generated at 2022-06-17 19:32:18.919963
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home_dir
    from flutils.osutils import get_os_user_temp_dir
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_g

# Generated at 2022-06-17 19:32:27.583117
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import List

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_two').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_three').touch()
        tmpdir.joinpath('dir_one').joinpath('file_four').touch()
        tmpdir.joinpath('dir_two').joinpath('file_five').touch()

# Generated at 2022-06-17 19:32:39.650392
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path

    # Test that a directory is created with the default mode.
    path = directory_present('~/tmp/test_directory_present')
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o700
    assert path.stat().st_uid == get_os_user().pw_uid
    assert path.stat().st_gid == get_os_group().gr_gid

# Generated at 2022-06-17 19:32:48.382955
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:32:57.515281
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one', 'file_two').touch()
        tmpdir.joinpath('dir_one', 'dir_two').mkdir()
        tmpdir.joinpath('dir_one', 'dir_two', 'file_three').touch()

        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('dir_one')
        ]

# Generated at 2022-06-17 19:33:08.697233
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_set
    from flutils.osutils import get_os_group_members_set
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:33:13.508815
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import find_paths
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:33:24.148522
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:33:39.169427
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch

    tmp_dir = get_temp_dir()
    mkdir(tmp_dir / 'test_dir')
    touch(tmp_dir / 'test_dir' / 'test_file')
    assert list(find_paths(tmp_dir / 'test_dir' / 'test_file')) == [
        tmp_dir / 'test_dir' / 'test_file'
    ]



# Generated at 2022-06-17 19:33:46.487260
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''



# Generated at 2022-06-17 19:33:58.814900
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH_OR_STR
    from flutils.pathutils import _PATH_OR_STR_OR_NONE
    from flutils.pathutils import _STR_OR_NONE

# Generated at 2022-06-17 19:34:10.565460
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_env_path
    from flutils.osutils import get_os_env_path_sep
    from flutils.osutils import get_os_env_path_sep_char
    from flutils.osutils import get_os_env_path_sep

# Generated at 2022-06-17 19:34:20.807243
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_home

# Generated at 2022-06-17 19:34:29.928355
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as

    tmp_dir = Path('~/tmp/flutils.tests.osutils.test_chmod').expanduser()
    tmp_dir.mkdir(parents=True, exist_ok=True)

    tmp_file = tmp_dir / 'test_chmod.txt'
    tmp_file.touch()

    tmp_file_mode = 0o660
    tmp_dir_mode = 0o770

    chmod(tmp_file, mode_file=tmp_file_mode)

# Generated at 2022-06-17 19:34:38.583121
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    tmp_link = os.path.join(tmp_dir, 'test_link')
    tmp_dir_link = os.path.join(tmp_dir, 'test_dir_link')
    tmp_dir_link_file = os.path.join(tmp_dir_link, 'test_file')

    path_present(tmp_file)
    path_present(tmp_link, link_to=tmp_file)

# Generated at 2022-06-17 19:34:45.296324
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Create a directory that does not exist.
    path = directory_present('~/tmp/test_directory_present')
    assert path.is_dir() is True
    assert path.exists() is True
    assert path.is_absolute() is True
    assert path.is_symlink() is False
    assert path.is_file() is False
    assert path.is_socket

# Generated at 2022-06-17 19:34:52.956014
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_env_path
    from flutils.osutils import get_os_env_path_split
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:34:57.832763
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/test_path/test_path2')
    assert path.as_posix() == '/Users/len/tmp/test_path/test_path2'
    assert exists_as(path) == 'directory'

# Generated at 2022-06-17 19:35:21.405016
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one/file_two').touch()
        tmpdir.joinpath('dir_one/dir_two').mkdir()
        tmpdir.joinpath('dir_one/dir_two/file_three').touch()
        tmpdir.joinpath('dir_one/dir_two/dir_three').mkdir()
        tmpdir.joinpath('dir_one/dir_two/dir_three/file_four').touch()
        tmpdir.joinpath('dir_one/dir_two/dir_three/dir_four').mkdir()

# Generated at 2022-06-17 19:35:26.887765
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:35:37.014760
# Unit test for function find_paths
def test_find_paths():
    # Create a temporary directory
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        # Create a file and directory in the temporary directory
        tmp_file = tmp_dir / 'file_one'
        tmp_file.touch()
        tmp_dir_one = tmp_dir / 'dir_one'
        tmp_dir_one.mkdir()
        # Create a file in the temporary directory's sub-directory
        tmp_file_two = tmp_dir_one / 'file_two'
        tmp_file_two.touch()
        # Create a glob pattern for the temporary directory
        glob_pattern = tmp_dir / '*'
        # Find all paths that match the glob pattern
        found_paths = list(find_paths(glob_pattern))
        # Assert that the file and directory

# Generated at 2022-06-17 19:35:47.685647
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_chmod_file(self):
            path = os.path.join(self.tmp_dir, 'test.txt')
            with open(path, 'w') as f:
                f.write('test')

            chmod(path, 0o660)
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o660)


# Generated at 2022-06-17 19:35:59.749474
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Create a directory for testing
    test_dir = normalize_path('~/tmp/test_find_paths')
    test_dir.mkdir(parents=True, exist_ok=True)

    # Create a file for testing
    test_file = normalize_path('~/tmp/test_find_paths/test_file')
    test_file.touch()

    # Create a symlink for testing
    test_symlink = normalize_path('~/tmp/test_find_paths/test_symlink')
    test_symlink.symlink_to(test_file)

    # Create a broken symlink for testing
    test_broken_symlink = normalize_path

# Generated at 2022-06-17 19:36:08.414131
# Unit test for function chmod
def test_chmod():
    """Test function chmod."""
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uid_name
    from flutils.osutils import get_os_gid_name
    from flutils.osutils import get_os_username_name
    from flutils.osutils import get_os_groupname_name
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:36:17.590331
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:36:26.570141
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path

    # Test with a glob pattern
    pattern = normalize_path('~/tmp/*')
    paths = list(find_paths(pattern))
    assert len(paths) == 2
    assert isinstance(paths[0], Path)
    assert isinstance(paths[1], Path)
    assert paths[0].as_posix() == '/home/test_user/tmp/file_one'
    assert paths[1].as_posix() == '/home/test_user/tmp/dir_one'

    # Test with a non-glob pattern
    pattern = normalize_path('~/tmp/file_one')
    paths = list(find_paths(pattern))

# Generated at 2022-06-17 19:36:36.178945
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import path_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

# Generated at 2022-06-17 19:36:45.947670
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''

# Generated at 2022-06-17 19:37:04.846548
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''



# Generated at 2022-06-17 19:37:16.860212
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as, normalize_path
    from flutils.tests.pathutils import TEST_DIR
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir_path = tmpdir / 'tmpdir'
        tmpdir_path.mkdir()
        tmpfile_path = tmpdir / 'tmpfile'
        tmpfile_path.touch()
        tmpfifo_path = tmpdir / 'tmpfifo'
        tmpfifo_path.mkfifo()
        tmpsocket_path = tmpdir / 'tmpsocket'
        tmpsocket_path.touch()
        tmpsocket_path.chmod(0o600)

# Generated at 2022-06-17 19:37:23.063007
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:37:29.924160
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils import (
        _TEST_DIR,
        _TEST_FILE,
        _TEST_FILE_MODE,
        _TEST_DIR_MODE,
    )

    chmod(_TEST_FILE, mode_file=0o660)
    assert oct(_TEST_FILE.stat().st_mode & 0o777) == oct(_TEST_FILE_MODE)

    chmod(_TEST_DIR, mode_dir=0o770)
    assert oct(_TEST_DIR.stat().st_mode & 0o777) == oct(_TEST_DIR_MODE)



# Generated at 2022-06-17 19:37:41.342390
# Unit test for function chown
def test_chown():
    """Test chown function."""
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import find_paths
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    import pytest
    import stat

    # Test chown on a file
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'tmpfile'
        tmpfile.touch()
        chown

# Generated at 2022-06-17 19:37:52.945780
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.tests.pathutils import TEST_DIR
    from flutils.tests.pathutils import TEST_FILE

    # Test with a non-existent path.
    test_path = TEST_DIR / 'test_directory_present'
    assert test_path.exists() is False
    assert exists_as(test_path) == ''
    assert directory_present(test_path) == test_path
    assert test

# Generated at 2022-06-17 19:38:02.843632
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert exists_as(path) == 'directory'
        path_absent(path)
        assert exists_as(path) == ''
        path_present(path)
        assert exists_as(path) == 'directory'
        path_present(path / 'foo')
        assert exists_as(path / 'foo') == 'directory'
        path_absent(path)
        assert exists_as(path) == ''
        assert exists_as(path / 'foo') == ''

# Generated at 2022-06-17 19:38:10.229233
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert exists_as(path) == 'directory'
        path_absent(path)
        assert exists_as(path) == ''



# Generated at 2022-06-17 19:38:22.855875
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_temp_