

# Generated at 2022-06-17 19:29:01.901702
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_env_path
    from flutils.osutils import get_os_env_path_sep
    from flutils.osutils import get_os_env_path_ext
    from flutils.osutils import get_os_env_path_ext_sep


# Generated at 2022-06-17 19:29:10.654747
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_username_from_uid
    from flutils.osutils import get_os_groupname_from_gid
    from flutils.osutils import get_os_uid_from_username
    from flutils.osutils import get_os_gid_

# Generated at 2022-06-17 19:29:18.648576
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link.link') == ''



# Generated at 2022-06-17 19:29:28.312567
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:29:38.685650
# Unit test for function chown
def test_chown():
    import os
    import stat
    import tempfile
    import unittest

    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.TemporaryDirectory()
            self.tmpdir_path = Path(self.tmpdir.name)
            self.test_file = self.tmpdir_path / 'test_file.txt'
            self.test_file.touch()

        def tearDown(self):
            self.tmpdir.cleanup()

        def test_chown_file(self):
            chown(self.test_file, user='root', group='root')

# Generated at 2022-06-17 19:29:49.441904
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import create_temp_dir
    from flutils.osutils import create_temp_file

    with create_temp_dir() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        with create_temp_file(dir=tmp_dir) as tmp_file:
            tmp_file = normalize_path(tmp_file)
            tmp_dir_one = tmp_dir.joinpath('dir_one')
            tmp_dir_one.mkdir()
            tmp_dir_two = tmp_dir.joinpath('dir_two')
            tmp_dir_two.mkdir()
            tmp_file_one = tmp

# Generated at 2022-06-17 19:29:57.628571
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:30:07.886430
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils.test_normalize_path import (
        TEST_DIR,
        TEST_FILE,
        TEST_SYMLINK,
        TEST_SYMLINK_TARGET,
    )

    # Test that the function returns a pathlib.Path object.
    assert isinstance(directory_present(TEST_DIR), Path)

    # Test that the function returns the same path as given.
    assert directory_present(TEST_DIR).as_posix() == TEST_DIR

    # Test that the function creates a directory if it does not exist.
    assert directory_present(TEST_DIR).exists() is True

    # Test that the function raises a FileExistsError if the given path
    # exists as a file.

# Generated at 2022-06-17 19:30:16.775423
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        Path(tmpdir / 'file_one').touch()
        Path(tmpdir / 'file_two').touch()
        Path(tmpdir / 'dir_one').mkdir()
        Path(tmpdir / 'dir_two').mkdir()
        Path(tmpdir / 'dir_one' / 'file_three').touch()
        Path(tmpdir / 'dir_one' / 'file_four').touch()
        Path(tmpdir / 'dir_two' / 'file_five').touch()

# Generated at 2022-06-17 19:30:23.811353
# Unit test for function chown
def test_chown():
    # Test chown() with a glob pattern
    path = Path('/tmp/flutils.tests.pathutils.test_chown.txt')
    path.touch()
    chown(path, user='-1', group='-1')
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    chown(path, user='root', group='root')
    assert path.stat().st_uid == 0
    assert path.stat().st_gid == 0
    chown(path, user='-1', group='-1')
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    path.unlink()



# Generated at 2022-06-17 19:30:58.757513
# Unit test for function find_paths
def test_find_paths():
    """Test find_paths()."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Test with a non-glob pattern.
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    assert list(find_paths(path)) == [path]

    # Test with a glob pattern.
    path = normalize_path('~/tmp/*')

# Generated at 2022-06-17 19:31:06.602640
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths

# Generated at 2022-06-17 19:31:14.936731
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    # Test that a directory is created with the given mode, user and group.
    path = directory_present(
        '~/tmp/test_directory_present',
        mode=0o700,
        user='root',
        group='wheel'
    )
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o40700
    assert path.stat().st_uid == 0

# Generated at 2022-06-17 19:31:27.021486
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()

        assert list(find_paths(tmp_dir.joinpath('file_one'))) == [
            normalize_path(tmp_dir.joinpath('file_one'))
        ]


# Generated at 2022-06-17 19:31:38.037691
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils.test_pathutils import (
        TEST_DIR,
        TEST_FILE_ONE,
        TEST_FILE_TWO,
        TEST_DIR_ONE,
        TEST_DIR_TWO,
    )

    assert list(find_paths(TEST_DIR)) == [
        Path(TEST_FILE_ONE),
        Path(TEST_FILE_TWO),
        Path(TEST_DIR_ONE),
        Path(TEST_DIR_TWO),
    ]

    assert list(find_paths(TEST_DIR_ONE)) == [
        Path(TEST_DIR_ONE)
    ]


# Generated at 2022-06-17 19:31:46.774200
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_sep
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_environ
    from flutils.osutils import get_os_environ_path
    from flutils.osutils import get_os_environ_path_sep

# Generated at 2022-06-17 19:31:55.626245
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.testutils import TestCase

    class TestFindPaths(TestCase):
        """Unit test for function find_paths."""

        def test_find_paths(self):
            """Test function find_paths."""
            self.assertEqual(
                list(find_paths('~/tmp/*')),
                [Path('/home/test_user/tmp/file_one'),
                 Path('/home/test_user/tmp/dir_one')]
            )

    return TestFindPaths



# Generated at 2022-06-17 19:32:03.983687
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_temp_dir
    from flutils.osutils import get_temp_file
    from flutils.osutils import remove_path

    # Test a file
    tmp_file = get_temp_file()
    chmod(tmp_file, 0o660)
    assert os.stat(tmp_file).st_mode == 33152
    remove_path(tmp_file)

    # Test a directory
    tmp_dir = get_temp_dir()
    chmod(tmp_dir, mode_dir=0o770)
    assert os.stat(tmp_dir).st_mode == 16832
    remove_path(tmp_dir)

    # Test a glob pattern
    tmp_dir = get_temp_dir()
    tmp_file = get_temp_

# Generated at 2022-06-17 19:32:15.624205
# Unit test for function chown
def test_chown():
    # Test with a path that does not exist
    chown('/tmp/flutils.tests.osutils.txt')

    # Test with a path that does exist
    with open('/tmp/flutils.tests.osutils.txt', 'w') as f:
        f.write('foo')
    chown('/tmp/flutils.tests.osutils.txt')

    # Test with a glob pattern
    chown('/tmp/flutils.tests.osutils.*')

    # Test with a glob pattern and include_parent
    chown('/tmp/flutils.tests.osutils.*', include_parent=True)

    # Test with a glob pattern and include_parent and a user
    chown('/tmp/flutils.tests.osutils.*', user='root', include_parent=True)

    # Test with a glob pattern and

# Generated at 2022-06-17 19:32:21.948648
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Test with a glob pattern that does not exist.
    assert list(find_paths('/tmp/foo/bar/baz')) == []

    # Test with a glob pattern that does exist.
    assert list(find_paths('/tmp/*')) == list(normalize_path('/tmp/*'))



# Generated at 2022-06-17 19:32:46.708886
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    import os
    import shutil
    import tempfile
    import unittest

    class TestPathAbsent(unittest.TestCase):
        """Test the function path_absent."""

        def setUp(self):
            """Set up the test fixture."""
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_dir = normalize_path(self.tmp_dir)
            self.tmp_dir = self.tmp

# Generated at 2022-06-17 19:32:57.344315
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_name).pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_uid).pw_name == getpass.getuser()
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user(1).pw_name == 'daemon'
    assert get_os_user(2).pw_name == 'bin'
    assert get_os_user(3).pw_name == 'sys'

# Generated at 2022-06-17 19:33:02.450063
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_dir
    from flutils.pathutils import temp_file

    with temp_dir() as tmp_dir:
        tmp_file = normalize_path(tmp_dir / 'tmp_file')
        tmp_dir = normalize_path(tmp_dir)

        assert exists_as(tmp_dir) == 'directory'
        assert exists_as(tmp_file) == ''

        with temp_file(tmp_file) as tmp_file:
            assert exists_as(tmp_file) == 'file'



# Generated at 2022-06-17 19:33:12.243484
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    test_user = get_os_user()
    test_group = get_os_group()
    test_path = normalize_path('~/tmp/test_path')
    test_path_str = test_path.as_posix()
    test_path_str = cast(str, test_path_str)
    test_file = test_path / 'test_file'
    test_file_str

# Generated at 2022-06-17 19:33:23.773448
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:33:36.259144
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_group_gid
    from flutils.osutils import get_os_group_members

# Generated at 2022-06-17 19:33:49.012672
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod as chmod_osutils
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_shell
    from flutils.osutils import get_

# Generated at 2022-06-17 19:33:58.236644
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase

    class TestDirectoryPresent(TestCase):
        def setUp(self):
            self.temp_dir = TemporaryDirectory()
            self.temp_dir_path = Path(self.temp_dir.name)

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_directory_present(self):
            test_path = self.temp_dir_path / 'test_path'
            result = directory_present(test_path)
            self.assertEqual(result, test_path)
            self.assertTrue(test_path.exists())
            self.assertTrue(test_path.is_dir())


# Generated at 2022-06-17 19:34:10.158405
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_euid
    from flutils.osutils import get_os_egid
    from flutils.osutils import get_os_groups
    from flutils.osutils import get_os_egroups
    from flutils.osutils import get_os_supp_groups
    from flutils.osutils import get_os_supp_egroups
    from flutils.osutils import get_os_groups_ids
    from flutils.osutils import get_os_egroups_ids

# Generated at 2022-06-17 19:34:11.011557
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:34:35.322739
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'flutils.tests.txt')
            with open(self.temp_file, 'w') as f:
                f.write('flutils.tests')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_chmod_file(self):
            chmod(self.temp_file, 0o660)

# Generated at 2022-06-17 19:34:46.329400
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/shadow') == 'file'
    assert exists_as('/etc/sudoers') == 'file'
    assert exists_as('/etc/sudoers.d') == 'directory'

# Generated at 2022-06-17 19:34:51.246735
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_file_mode
    from flutils.osutils import get_os_file_owner
    from flutils.osutils import get_os_file_group
    from flutils.osutils import get_os_file_type
    from flutils.osutils import get_os_file_type_str
    from flutils.osutils import get_os_file_type_str_short
    from flutils.osutils import get_os_file_type_str_long
    from flutils.osutils import get_os_file_type_str_long_short
    from flutils.osutils import get_os_file_type_

# Generated at 2022-06-17 19:35:01.874068
# Unit test for function chown
def test_chown():
    import tempfile
    import os
    import pwd
    import grp
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fname = os.path.join(tmpdir, 'foo.txt')
    with open(fname, 'w') as f:
        f.write('foo')

    # Create a directory
    dname = os.path.join(tmpdir, 'bar')
    os.mkdir(dname)

    # Create a symlink
    lname = os.path.join(tmpdir, 'baz')
    os.symlink(fname, lname)

    # Create a socket
    sname = os.path.join(tmpdir, 'sock')

# Generated at 2022-06-17 19:35:02.490051
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-17 19:35:14.037030
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.testutils import TempDir
    with TempDir() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('foo').mkdir()
        tmpdir.joinpath('foo').joinpath('bar').mkdir()
        tmpdir.joinpath('foo').joinpath('bar').joinpath('baz').mkdir()
        tmpdir.joinpath('foo').joinpath('bar').joinpath('baz').joinpath('file').touch()
        tmpdir.joinpath('foo').joinpath('bar').joinpath('baz').joinpath('link').symlink_to('file')
        path_absent(tmpdir.joinpath('foo'))
        assert tmpdir.joinpath('foo').exists() is False



# Generated at 2022-06-17 19:35:22.607321
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:35:34.948674
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from pathlib import Path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from typing import Deque
    from typing import Generator
    from typing import Optional
    from typing import Union

# Generated at 2022-06-17 19:35:39.972084
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__.replace('.py', '.txt')) == ''
    assert exists_as(__file__.replace('.py', '.txt').replace('tests', 'tmp')) == 'file'



# Generated at 2022-06-17 19:35:49.480441
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('/dev/pts/2') == 'char device'
    assert exists_as('/dev/pts/3') == 'char device'
    assert exists_as('/dev/pts/4') == 'char device'


# Generated at 2022-06-17 19:36:12.703902
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_exists_as
    from flutils.pathutils import path_is_directory
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_absolute


# Generated at 2022-06-17 19:36:16.873747
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')


# Generated at 2022-06-17 19:36:25.697322
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_sep
    from flutils.osutils import get_os_pathsep
    from flutils.osutils import get_os_linesep
    from flutils.osutils import get_os_name

# Generated at 2022-06-17 19:36:35.889740
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups

# Generated at 2022-06-17 19:36:41.299597
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_set
    from flutils.osutils import get_os_group_members_set
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:36:48.428365
# Unit test for function chown
def test_chown():
    import os
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    # Test chown with a glob pattern
    chown('~/tmp/**', user='root', group='root')
    for sub_path in Path().glob('~/tmp/**'):
        if sub_path.is_dir() or sub_path.is_file():
            assert os.stat(sub_path.as_posix()).st_uid == get_os_uid('root')
            assert os.stat(sub_path.as_posix()).st_gid == get_os_gid('root')

   

# Generated at 2022-06-17 19:36:59.460692
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils.test_normalize_path import (
        _TEST_DIR,
        _TEST_FILE,
    )

    chmod(_TEST_FILE, 0o660)
    chmod(_TEST_DIR, 0o770)

    assert _TEST_FILE.stat().st_mode & 0o777 == 0o660
    assert _TEST_DIR.stat().st_mode & 0o777 == 0o770

    chmod(_TEST_FILE, 0o600)
    chmod(_TEST_DIR, 0o700)

    assert _TEST_FILE.stat().st_mode & 0o777 == 0o600
    assert _TEST_DIR.stat().st_mode & 0o777 == 0o700



# Generated at 2022-06-17 19:37:07.942830
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    import unittest

    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.TemporaryDirectory()
            self.tmpdir_path = Path(self.tmpdir.name)
            self.tmpdir_path.mkdir(parents=True)
            self.tmpdir_path.joinpath('foo.txt').touch()
            self.tmpdir_path.joinpath('bar.txt').touch()
            self.tmpdir_path.joinpath('baz').mkdir()
            self.tmpdir_path.joinpath('baz', 'baz.txt').touch()

        def tearDown(self):
            self.tmpdir.cleanup()


# Generated at 2022-06-17 19:37:12.200222
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:37:20.179995
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    path_absent(path)

    path = directory_present('~/tmp/test_path', mode=0o770)
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    path_absent(path)

    path = directory_present('~/tmp/test_path', user='root', group='wheel')

# Generated at 2022-06-17 19:37:40.625653
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:37:47.393838
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_login
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive

# Generated at 2022-06-17 19:37:59.533102
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:38:10.584310
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/shadow') == 'file'
    assert exists_as('/etc/sudoers') == 'file'
    assert exists_as('/etc/sudoers.d') == 'directory'
    assert exists

# Generated at 2022-06-17 19:38:22.932610
# Unit test for function chown
def test_chown():
    import os
    import stat
    import tempfile
    import unittest

    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_dir_path = Path(self.temp_dir.name)

            self.file_path = self.temp_dir_path / 'file.txt'
            self.file_path.touch()

            self.dir_path = self.temp_dir_path / 'dir'
            self.dir_path.mkdir()

            self.sub_dir_path = self.dir_path / 'sub_dir'
            self.sub_dir_path.mkdir()
