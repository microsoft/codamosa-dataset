

# Generated at 2022-06-17 19:28:49.216231
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_readable
    from flutils.pathutils import path_is_writable
    from flutils.pathutils import path_is_executable
   

# Generated at 2022-06-17 19:28:58.155727
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils')

    # Create a sub-directory in the temporary directory
    tmp_sub_dir = os.path.join(tmp_dir, 'sub_dir')
    os.mkdir(tmp_sub_dir)

    # Create a file in the sub-directory
    tmp_sub_file = os.path.join(tmp_sub_dir, 'flutils.tests.osutils.txt')

# Generated at 2022-06-17 19:29:07.038615
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_group_gid

# Generated at 2022-06-17 19:29:13.571408
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    test_dir = normalize_path('~/tmp/flutils.tests.osutils')
    test_file = test_dir / 'test_chown.txt'

    directory_present(test_dir)
    path_absent(test_file)

    test_file.touch()
    assert exists_as(test_file, 'file') is True

    chown(test_file, user='-1', group='-1')
    assert test_file.stat().st_uid == os.getuid()

# Generated at 2022-06-17 19:29:20.166468
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path_present(path)
        assert path.exists()
        path_absent(path)
        assert path.exists() is False



# Generated at 2022-06-17 19:29:29.211100
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:29:39.476325
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_ids
    from flutils.osutils import get_os_group_members_names
    from flutils.osutils import get_os_group_members_homes
    from flutils.osutils import get

# Generated at 2022-06-17 19:29:49.846867
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_uidgidname
    from flutils.osutils import get_os_uidgidnamenumber

# Generated at 2022-06-17 19:30:00.788329
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.pathutils import (
        _TEST_DIR,
        _TEST_FILE,
        _TEST_FILE_CONTENTS,
    )
    from flutils.tests.osutils import (
        _TEST_USER,
        _TEST_GROUP,
    )
    from flutils.tests.testutils import (
        _cleanup,
        _setup,
    )

    _setup()

# Generated at 2022-06-17 19:30:08.135961
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_2,
    )
    from flutils.tests.osutils import (
        TEST_USER,
        TEST_GROUP,
    )
    from flutils.tests.osutils import (
        TEST_USER_2,
        TEST_GROUP_2,
    )
    from flutils.tests.osutils import (
        TEST_USER_3,
        TEST_GROUP_3,
    )
    from flutils.tests.osutils import (
        TEST_USER_4,
        TEST_GROUP_4,
    )

# Generated at 2022-06-17 19:30:50.934198
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    import pathlib
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = pathlib.Path(tmp_dir)
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        file_two = tmp_dir / 'file_two'
        file_two.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmp_dir / 'dir_two'
        dir_two.mkdir()


# Generated at 2022-06-17 19:31:00.494160
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chmod

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:31:09.640804
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''



# Generated at 2022-06-17 19:31:18.630525
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.osutils import get_os_name
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getgroups
    from os import getlogin
    from os import getpwuid
    from os import getgrgid
    from os import getenv
    from os import chmod as os_chmod
    from os import chown as os_chown

# Generated at 2022-06-17 19:31:23.033149
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-17 19:31:30.200901
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import tempfile

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    tmp_file_path = tmp_dir_path / 'flutils.tests.osutils.txt'


# Generated at 2022-06-17 19:31:38.513983
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()

        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            normalize_path(tmp_dir.joinpath('file_one')),
            normalize_path(tmp_dir.joinpath('dir_one'))
        ]



# Generated at 2022-06-17 19:31:46.624324
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmpdir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()

        # Test with a glob pattern.

# Generated at 2022-06-17 19:31:56.963110
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import shutil
    import tempfile
    from flutils.pathutils import path_absent

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')
    tmp_dir_two = os.path.join(tmp_dir, 'tmp_dir_two')
    tmp_dir_three = os.path.join(tmp_dir, 'tmp_dir_three')
    tmp_dir_four = os.path.join(tmp_dir, 'tmp_dir_four')
    tmp_dir_five = os.path.join(tmp_dir, 'tmp_dir_five')
    tmp_dir_

# Generated at 2022-06-17 19:32:07.616850
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    tmp_link = os.path.join(tmp_dir, 'test_link')
    tmp_dir_link = os.path.join(tmp_dir, 'test_dir_link')
    tmp_dir_link_file = os.path.join(tmp_dir_link, 'test_file')
    tmp_dir_link_link = os.path.join(tmp_dir_link, 'test_link')
    tmp_dir_link_dir_link = os.path.join(tmp_dir_link, 'test_dir_link')
    tmp_dir_link_dir

# Generated at 2022-06-17 19:32:26.887992
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path
    from flutils.pathutils import PathType

    # Test a glob pattern that does not exist.
    assert list(find_paths('~/tmp/does_not_exist')) == []

    # Test a glob pattern that does exist.
    assert list(find_paths('~/tmp/*')) == [
        normalize_path('~/tmp/file_one'),
        normalize_path('~/tmp/dir_one')
    ]

    # Test a glob pattern that does exist with a Path object.

# Generated at 2022-06-17 19:32:38.718044
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Create a directory to test with.
    test_dir = normalize_path('~/tmp/flutils.tests.pathutils.find_paths')
    test_dir.mkdir(parents=True, exist_ok=True)

    # Create a file to test with.
    test_file = test_dir / 'test_file.txt'
    test_file.touch()

    # Create a directory to test with.
    test_dir_2 = test_dir / 'test_dir'
    test_dir_2.mkdir()

    # Create a file to test with.
    test_file_2 = test_dir_2 / 'test_file_2.txt'
    test_file_2.touch()



# Generated at 2022-06-17 19:32:47.854309
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_ABS,
        TEST_DIR_ABS_PARENT,
        TEST_DIR_REL,
        TEST_DIR_REL_PARENT,
        TEST_FILE_ABS,
        TEST_FILE_REL,
        TEST_FILE_SYMLINK_ABS,
        TEST_FILE_SYMLINK_REL,
        TEST_SOCKET_ABS,
        TEST_SOCKET_REL,
        TEST_SYMLINK_ABS,
        TEST_SYMLINK_REL,
    )

    # Test that the given path is created as a directory.
    path = directory_present(TEST_DIR_REL)
    assert path.is_dir() is True

# Generated at 2022-06-17 19:32:55.694180
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''



# Generated at 2022-06-17 19:33:06.625789
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import find_paths
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths

# Generated at 2022-06-17 19:33:14.467156
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user

    tmp_dir = Path('~/tmp/flutils.tests.osutils').expanduser()
    tmp_dir.mkdir(parents=True, exist_ok=True)

    tmp_file = tmp_dir / 'chmod.txt'
    tmp_file.touch()

    chmod(tmp_file, 0o660)
    assert tmp_file.stat().st_mode & 0o777 == 0o660

    chmod(tmp_dir, 0o770)
    assert tmp_dir.stat().st_mode & 0o777 == 0o770

    chmod(tmp_dir / '*', 0o660)
    assert tmp_file.stat().st_mode & 0o777 == 0o660


# Generated at 2022-06-17 19:33:24.276727
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert os.stat(tmp_file).st_mode & 0o777 == 0o660

    chmod(tmp_file, 0o600)
    assert os.stat(tmp_file).st_mode & 0o777 == 0o600

    chmod(tmp_file, 0o644)
    assert os.stat(tmp_file).st_mode & 0o777 == 0o644


# Generated at 2022-06-17 19:33:36.696969
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    # Create a temporary directory to work in.

# Generated at 2022-06-17 19:33:44.747802
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:33:57.952272
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/console') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'
    assert exists_as('/dev/pts') == 'directory'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1')

# Generated at 2022-06-17 19:34:14.589646
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod as os_chmod
    from tempfile import TemporaryDirectory
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import stat
    from os import mkdir
    from os import makedirs
    from os import remove
    from os import rmdir
    from os import symlink
    from os import unlink
   

# Generated at 2022-06-17 19:34:22.161629
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    # Test the function with a file.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        test_file = tmpdir / 'test_file'
        test_file.touch()
        path_absent(test_file)
        assert not os.path.exists(test_file)

    # Test the function with a directory.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        test_dir = tmpdir / 'test_dir'
        test_dir.mkdir()
        test_file = test_dir / 'test_file'
        test_file.touch()
        path

# Generated at 2022-06-17 19:34:31.022259
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import time

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:34:39.175889
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()
    chmod(path, 0o660)
    assert exists_as(path, 'file') is True
    assert path.stat().st_mode == 33152
    path.unlink()
    assert path_absent(path) is True

    path = Path('~/tmp/flutils.tests.osutils.dir').expanduser()
    path.mkdir(parents=True, exist_ok=True)

# Generated at 2022-06-17 19:34:45.349178
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_mount_point
    from flutils.pathutils import path_is_readable
   

# Generated at 2022-06-17 19:34:52.981513
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_temp_file
    from flutils.osutils import get_os_temp_dir_name
    from flutils.osutils import get_os_temp_file_name
    from flutils.osutils import get_os_temp_file_path
    from flutils.osutils import get_os_temp_dir_path
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:34:57.858382
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_names
    from flutils.osutils import get_os_group_members_homes
    from flutils.osutils import get_os_group_members_uids
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:35:02.549285
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils import (
        _TEST_DIR,
        _TEST_DIR_FILE,
        _TEST_DIR_FILE_SYMLINK,
        _TEST_DIR_SYMLINK,
    )
    from flutils.tests.osutils import (
        _TEST_DIR_FILE_MODE,
        _TEST_DIR_FILE_SYMLINK_MODE,
        _TEST_DIR_MODE,
        _TEST_DIR_SYMLINK_MODE,
    )

    chmod(_TEST_DIR_FILE, mode_file=_TEST_DIR_FILE_MODE)
    assert _TEST_DIR_FILE.stat().st_mode & 0o777 == _TEST_DIR_FILE_MODE


# Generated at 2022-06-17 19:35:14.080909
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_shell
    from flutils.osutils import get_os_user_info
    from flutils.osutils import get_os_group_info
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members

# Generated at 2022-06-17 19:35:22.635755
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths

    # Create a directory to test with
    test_dir = normalize_path('~/tmp/flutils.tests.pathutils.chmod')
    directory_present(test_dir)

    # Create a file to test with
    test_file = normalize_path(f'{test_dir}/test_file.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a symlink to test with

# Generated at 2022-06-17 19:35:59.515054
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    import os
    import stat

    # Create a temporary directory
    tmp_dir = Path('/tmp/flutils.tests.osutils.chmod')
    directory_present(tmp_dir)

    # Create a temporary file
    tmp_file = tmp_dir / 'flutils.tests.osutils.txt'
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.chmod')

    # Get the current user and group
    user = get_os_

# Generated at 2022-06-17 19:36:08.230904
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_member_names
    from flutils.osutils import get_os_group_member_ids
    from flutils.osutils import get_os_group_member_users
    from flutils.osutils import get_os_group_member_groups
    from flutils.osutils import get_os_group_member_users_groups
    from flutils.osutils import get_os_group_member_groups_users


# Generated at 2022-06-17 19:36:12.319423
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__.replace('.py', '.txt')) == ''
    assert exists_as(__file__.replace('.py', '')) == 'directory'
    assert exists_as(__file__.replace('.py', '.txt').replace('txt', 'py')) == 'file'
    assert exists_as(__file__.replace('.py', '.txt').replace('txt', 'py').replace('py', 'txt')) == ''
    assert exists_as(__file__.replace('.py', '.txt').replace('txt', 'py').replace('py', 'txt').replace('txt', 'py')) == 'file'

# Generated at 2022-06-17 19:36:21.835385
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import pwd
    import grp
    import sys

    if sys.platform == 'win32':
        raise unittest.SkipTest('Windows does not support chown')

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:36:28.905561
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_uidgidname
    from flutils.osutils import get_

# Generated at 2022-06-17 19:36:34.978063
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_uid == 0
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user().pw_name == getpass.getuser()
    with pytest.raises(OSError):
        get_os_user('foo')
    with pytest.raises(OSError):
        get_os_user(1)



# Generated at 2022-06-17 19:36:45.827324
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == '/Users/len/tmp/flutils.tests.pathutils.directory_present'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == '/Users/len/tmp/flutils.tests.pathutils.directory_present'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present/foo')

# Generated at 2022-06-17 19:36:58.069002
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from pathlib import Path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from typing import Deque
    from typing import Generator
    from typing import Optional
    from typing import Union

# Generated at 2022-06-17 19:37:05.843025
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Change to the temporary directory
    os.chdir(tmpdir)

    # Create a file
    with open('file_one', 'w') as f:
        f.write('foo')

    # Create a directory
    os.mkdir('dir_one')

    # Create a symbolic link to a file
    os.symlink('file_one', 'file_one_link')

    # Create a symbolic link to a directory
    os.symlink('dir_one', 'dir_one_link')

    # Create a symbolic link to a file that does not exist

# Generated at 2022-06-17 19:37:17.479736
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')
    tmp_dir_two = os.path.join(tmp_dir, 'tmp_dir_two')
    tmp_file_one = os.path.join(tmp_dir_one, 'tmp_file_one')
    tmp_file_two = os.path.join(tmp_dir_one, 'tmp_file_two')
    tmp_file_three = os.path.join(tmp_dir_two, 'tmp_file_three')

# Generated at 2022-06-17 19:37:54.064171
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.systemutils import get_os_user
    from flutils.systemutils import get_os_group
    from flutils.systemutils import get_os_username
    from flutils.systemutils import get_os_groupname
    from flutils.systemutils import get_os_uid
    from flutils.systemutils import get_os_gid
    from flutils.systemutils import get_os_euid
    from flutils.systemutils import get_os_egid
    from flutils.systemutils import get_os_groups
    from flutils.systemutils import get_os

# Generated at 2022-06-17 19:38:03.391567
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import remove_path
    from flutils.tests.pathutils import (
        _TEST_DIR,
        _TEST_FILE,
        _TEST_FILE_CONTENTS,
    )

    remove_path(_TEST_FILE)
    _TEST_DIR.mkdir(parents=True, exist_ok=True)

    with open(_TEST_FILE, 'w') as f:
        f.write(_TEST_FILE_CONTENTS)

    chmod(_TEST_FILE, 0o660)
    assert oct(os.stat(_TEST_FILE).st_mode & 0o777) == '0o660'

    chmod(_TEST_DIR, 0o770)

# Generated at 2022-06-17 19:38:11.030746
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:38:23.142997
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import path_absent
    from flutils.pathutils import chmod
    from flutils.pathutils import find_paths
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path