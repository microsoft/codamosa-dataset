

# Generated at 2022-06-17 19:29:02.598216
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:29:11.774152
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('/dev/pts/2') == 'char device'
    assert exists_as('/dev/pts/3') == 'char device'
    assert exists_as('/dev/pts/4') == 'char device'


# Generated at 2022-06-17 19:29:22.359710
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown
    from flutils.pathutils import chmod
    from flutils.pathutils import create_dir
    from flutils.pathutils import create_file
    from flutils.pathutils import create_symlink
    from flutils.pathutils import create_fifo
    from flutils.pathutils import create_socket
    from flutils.pathutils import create_block_device
    from flutils.pathutils import create

# Generated at 2022-06-17 19:29:32.317689
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one', 'file_two').touch()
        tmpdir.joinpath('dir_one', 'dir_two').mkdir()
        tmpdir.joinpath('dir_one', 'dir_two', 'file_three').touch()

        assert list(find_paths(tmpdir.joinpath('file_one'))) == [
            tmpdir.joinpath('file_one')
        ]

# Generated at 2022-06-17 19:29:42.268538
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readable

# Generated at 2022-06-17 19:29:46.935988
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import getuid
    from os import getgid
    from os import mkdir
    from os import remove
    from os import rmdir
    from os import stat
    from os import symlink
    from os import unlink
    from os import utime
    from os import walk
   

# Generated at 2022-06-17 19:29:57.490671
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_two').mkdir()


# Generated at 2022-06-17 19:30:07.768025
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:30:13.866771
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys
    import pathlib
    import flutils.pathutils

    # Create a temporary directory.
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = pathlib.Path(tmp_dir)
    tmp_dir = tmp_dir.as_posix()
    tmp_dir = cast(str, tmp_dir)

    # Create a temporary file.
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    tmp_file = pathlib.Path(tmp_file.name)
    tmp_file = tmp_file.as_posix()
    tmp_file = cast(str, tmp_file)

    # Create a temporary directory

# Generated at 2022-06-17 19:30:21.809800
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:30:49.289211
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_symlink

    with temp_directory() as tmpdir:
        assert exists_as(tmpdir) == 'directory'
        assert exists_as(normalize_path(tmpdir)) == 'directory'

        with temp_file(dir=tmpdir) as tmpfile:
            assert exists_as(tmpfile) == 'file'
            assert exists_as(normalize_path(tmpfile)) == 'file'

        with temp_symlink(dir=tmpdir) as tmpsym:
            assert exists_as(tmpsym) == ''

# Generated at 2022-06-17 19:31:01.317696
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import chown
    from flutils.osutils import chmod as _chmod
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_

# Generated at 2022-06-17 19:31:13.250967
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Test find_paths with a glob pattern.
    pattern = normalize_path('~/tmp/*')
    results = list(find_paths(pattern))
    assert len(results) == 2
    assert results[0].as_posix() == '/home/test_user/tmp/file_one'
    assert results[1].as_posix() == '/home/test_user/tmp/dir_one'

    # Test find_paths with a glob pattern that does not exist.
    pattern = normalize_path('~/tmp/does_not_exist')
    results = list(find_paths(pattern))
    assert len(results) == 0

   

# Generated at 2022-06-17 19:31:19.116396
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import remove_path
    from flutils.pathutils import touch
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    touch(path)
    assert path_present(path) is True

    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660

    ch

# Generated at 2022-06-17 19:31:28.090882
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    from flutils.pathutils import get_os_user
    import os
    import pwd
    import getpass
    import pytest

    # Test for invalid uid
    with pytest.raises(OSError):
        get_os_user(99999999)

    # Test for invalid login name
    with pytest.raises(OSError):
        get_os_user('invalid_login_name')

    # Test for valid uid
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())

    # Test for valid login name
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())

    # Test for None
    assert get_os_user()

# Generated at 2022-06-17 19:31:34.063849
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:31:43.938183
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_login
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_all
    from flutils.osutils import get_os_group_members_recursive_all_nested
    from flutils.osutils import get_os_group_members_recursive_all_nested

# Generated at 2022-06-17 19:31:54.583291
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()

    # Create a temporary file
    tmp_file = os.path.join(tmp_dir.name, 'tmp_file.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a temporary directory
    tmp_dir_2 = os.path.join(tmp_dir.name, 'tmp_dir')
    os.mkdir(tmp_dir_2)

    # Create a temporary file
    tmp_file_2 = os.path.join(tmp_dir_2, 'tmp_file_2.txt')
    with open(tmp_file_2, 'w') as f:
        f

# Generated at 2022-06-17 19:32:03.816051
# Unit test for function directory_present
def test_directory_present():
    path = directory_present(
        '~/tmp/flutils.tests.pathutils.test_directory_present'
    )
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o700
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()

    path = directory_present(
        '~/tmp/flutils.tests.pathutils.test_directory_present',
        mode=0o755,
        user='root',
        group='wheel'
    )
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o755
    assert path.stat().st_uid == 0

# Generated at 2022-06-17 19:32:15.592085
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_all
    from flutils.osutils import get_os_group_members_recursive_all_usernames

# Generated at 2022-06-17 19:32:56.709444
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:33:07.991945
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_version
    from flutils.osutils import get_os_release
    from flutils.osutils import get_os_system
    from flutils.osutils import get_os_machine
    from flutils.osutils import get_os_processor
    from flutils.osutils import get_os_platform
   

# Generated at 2022-06-17 19:33:13.126059
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    # Test that the function returns a pathlib.Path object.
    assert isinstance(directory_present('~/tmp/flutils.tests.pathutils.txt'),
                      Path)

    # Test that the function returns a pathlib.Path object of the correct
    # type for the system.

# Generated at 2022-06-17 19:33:20.215064
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils import (
        _TEST_DIR,
        _TEST_FILE,
    )

    chmod(_TEST_FILE, 0o660)
    chmod(_TEST_DIR, 0o770)

    assert _TEST_FILE.stat().st_mode & 0o777 == 0o660
    assert _TEST_DIR.stat().st_mode & 0o777 == 0o770



# Generated at 2022-06-17 19:33:28.195171
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    # Test that the given path is created as a directory.
    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
   

# Generated at 2022-06-17 19:33:33.817696
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path.mkdir()
        path_absent(path)
        assert path.exists() is False



# Generated at 2022-06-17 19:33:41.365501
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os
    import os.path
    import sys

    # Create a temporary directory to work in.
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:33:51.067198
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_group


# Generated at 2022-06-17 19:34:00.949841
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod as os_chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_

# Generated at 2022-06-17 19:34:12.171634
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
   

# Generated at 2022-06-17 19:34:45.775988
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from os import getuid
    from os import getgid
    from os import stat
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import mkdir
    from os import remove
    from os import rmdir
    from os import symlink
    from os import unlink
    from os import utime

# Generated at 2022-06-17 19:34:53.352828
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:35:02.689629
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        tmp_dir = tmp_dir.as_posix()
        tmp_dir = cast(str, tmp_dir)
        path = os.path.join(tmp_dir, 'test_path')
        path_present(path)
        assert exists_as(path) == 'directory'
        path_absent(path)
        assert exists_as(path) == ''



# Generated at 2022-06-17 19:35:14.575740
# Unit test for function chmod
def test_chmod():
    # Test with a file
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'flutils.tests.osutils.txt'
        path.touch()
        chmod(path, 0o660)
        assert path.stat().st_mode & 0o777 == 0o660

    # Test with a directory
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'flutils.tests.osutils.dir'
        path.mkdir()
        chmod(path, mode_dir=0o770)
        assert path.stat().st_mode & 0o777 == 0o770

    # Test with a glob pattern

# Generated at 2022-06-17 19:35:22.479429
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils')

    try:
        chmod(tmp_file, 0o660)
        assert os.stat(tmp_file).st_mode == 33152
        chmod(tmp_dir, 0o770)
        assert os.stat(tmp_dir).st_mode == 40960
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:35:34.799698
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_dict
    from flutils.osutils import get_os_group_members_dict
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:35:46.865695
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_

# Generated at 2022-06-17 19:35:59.219321
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_group_user
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_users
    from flutils.osutils import get_os_user_group_names
    from flutils.osutils import get_os_group_user_names

# Generated at 2022-06-17 19:36:06.801764
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import shutil
    import tempfile

    test_path = Path(tempfile.mkdtemp())
    test_file = test_path / 'test_file'
    test_file.touch()
    test_dir = test_path / 'test_dir'
    test_dir.mkdir()
    test_sub_file = test_dir / 'test_sub_file'
    test_sub_file.touch()
    test_sub_dir = test_dir / 'test_sub_dir'
    test_sub_dir.mkdir()
    test_sub_sub_file = test_sub_dir / 'test_sub_sub_file'
    test_sub_sub_file.touch()

    path_absent(test_path)
    assert not test_path.ex

# Generated at 2022-06-17 19:36:13.581622
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Supports a glob pattern.  So to recursively change the mode
    # of a directory just do:
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # To change the mode of a directory's immediate contents:
    chmod('~/tmp/*')



# Generated at 2022-06-17 19:36:37.274517
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    # Test that chown works with a non-existent path
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path_absent(path)
    chown(path)
    assert exists_as(path, 'file') is False

    # Test that chown works with a file
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    directory_present(path.parent)

# Generated at 2022-06-17 19:36:37.976237
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:36:46.905156
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import tempfile

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path)
    tmp_file_path = Path(tmp_file.name)

    tmp_dir_path.chmod(0o700)
    tmp_file_path.chmod(0o600)

    assert os.stat(tmp_dir_path).st_mode == 16832
    assert os.stat(tmp_file_path).st_mode == 33152

    chmod(tmp_dir_path, mode_file=0o644, mode_dir=0o755)

# Generated at 2022-06-17 19:36:58.286243
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_giduid
    from flutils.osutils import get_os_usernamegid
    from flutils.osutils import get

# Generated at 2022-06-17 19:37:01.488377
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    try:
        tmp_file = Path(tmp_dir) / 'flutils.tests.osutils.txt'
        tmp_file.touch()
        tmp_file.chmod(0o600)
        assert tmp_file.stat().st_mode == 33152
        chmod(tmp_file, 0o660)
        assert tmp_file.stat().st_mode == 33188
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:37:09.257188
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'
    assert exists_as('/dev/pts') == 'directory'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'

# Generated at 2022-06-17 19:37:09.727020
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-17 19:37:10.265220
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:37:19.694247
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:37:29.787824
# Unit test for function chown

# Generated at 2022-06-17 19:38:14.428481
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readable
    from flutils.pathutils import path_is_writable

# Generated at 2022-06-17 19:38:21.204531
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/foo') == ''

