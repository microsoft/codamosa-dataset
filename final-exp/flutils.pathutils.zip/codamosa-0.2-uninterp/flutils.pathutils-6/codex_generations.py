

# Generated at 2022-06-17 19:28:58.672367
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:29:03.318882
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:29:12.121124
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.chmod(0o700)
        tmpdir.joinpath('flutils.tests.osutils.txt').touch()
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o600)

# Generated at 2022-06-17 19:29:21.717050
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:29:25.072741
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:29:35.639097
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir_path)
    tmp_file_path = Path(tmp_file.name)

    # Test that chmod does nothing if the path does not exist
    chmod(tmp_file_path.as_posix() + '.txt')
    assert os.stat(tmp_file_path).st_mode == stat.S_IFREG | 0o600

    # Test that chmod does nothing if the path is a symlink
    tmp_file_symlink = tmp_file_path.with_suffix('.symlink')
    tmp

# Generated at 2022-06-17 19:29:43.348556
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_ids
    from flutils.osutils import get_os_group_members_names
    from flutils.osutils import get_os_group_members_homes
    from flutils.osutils import get

# Generated at 2022-06-17 19:29:53.930867
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH_TYPE
    from flutils.pathutils import _PATH_TYPES
    from flutils.pathutils import _PATH_TYPES_STR
    from flutils.pathutils import _PATH

# Generated at 2022-06-17 19:29:58.289502
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-17 19:30:06.823243
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path

    # Test that the function returns a Path object.
    path = directory_present('~/tmp/test_path')
    assert isinstance(path, Path)

    # Test that the function returns a PosixPath object.
    path = directory_present('~/tmp/test_path')
    assert isinstance(path, PosixPath)

    # Test that the function returns a WindowsPath object.
    path = directory_present

# Generated at 2022-06-17 19:30:26.833924
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/test_path/sub_dir')
    assert path.as_posix() == '/Users/len/tmp/test_path/sub_dir'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/test_path/sub_dir/sub_sub_dir')

# Generated at 2022-06-17 19:30:38.376771
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o660

    chmod(tmp_dir, 0o770)
    assert stat.S_IMODE(os.stat(tmp_dir).st_mode) == 0o770

    chmod(os.path.join(tmp_dir, '*'), 0o660)

# Generated at 2022-06-17 19:30:49.080073
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import find_paths
    from flutils.pathutils import get_path_mode
    from flutils.pathutils import get_path_owner
    from flutils.pathutils import get_path_group
    from flutils.pathutils import get_path_stat
    from flutils.pathutils import get_path_type

# Generated at 2022-06-17 19:31:01.201626
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Create a directory to test chmod
    test_dir = normalize_path('~/tmp/flutils.tests.osutils.chmod')
    directory_present(test_dir)

    # Create a file to test chmod
    test_file = normalize_path('~/tmp/flutils.tests.osutils.chmod/file.txt')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a symlink to test chmod
    test_sy

# Generated at 2022-06-17 19:31:08.002107
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert path.is_dir() is True
    assert path.exists() is True
    assert path.stat().st_mode == 0o40700



# Generated at 2022-06-17 19:31:15.777936
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    import unittest
    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.txt')
            with open(self.test_file, 'w') as f:
                f.write('test')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_chown(self):
            chown(self.test_file)
            self.assertEqual(
                os.stat(self.test_file).st_uid,
                os.getuid()
            )

# Generated at 2022-06-17 19:31:27.739583
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path
    from flutils.pathutils import PathLike
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _STR_OR_INT
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _STR_OR_INT
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _STR_OR_INT
    from flutils.pathutils import _STR_OR

# Generated at 2022-06-17 19:31:32.456051
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:31:43.027932
# Unit test for function path_absent
def test_path_absent():
    # Test for a file.
    path = Path('~/tmp/test_path')
    path.touch()
    path_absent(path)
    assert path.exists() is False

    # Test for a directory.
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True)
    path_absent(path)
    assert path.exists() is False

    # Test for a broken symbolic link.
    path = Path('~/tmp/test_path')
    path.symlink_to('/tmp/foo/bar')
    path_absent(path)
    assert path.exists() is False

    # Test for a symbolic link to a file.
    path = Path('~/tmp/test_path')
    path.symlink_to('/tmp/foo')

# Generated at 2022-06-17 19:31:57.534469
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link2') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link3') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link4') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link5') == ''

# Generated at 2022-06-17 19:32:07.784841
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:32:10.028938
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:32:20.316413
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_ids
    from flutils.osutils import get_os_group_members_names
    from flutils.osutils import get_os_group_members_homes
    from flutils.osutils import get

# Generated at 2022-06-17 19:32:28.396936
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_group, get_os_user
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_fullname
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_passwd
    from flutils.osutils import get_os_user_passwd_expire


# Generated at 2022-06-17 19:32:40.191878
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Test with a glob pattern.
    pattern = normalize_path('~/tmp/*')
    assert list(find_paths(pattern)) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]

    # Test with a glob pattern that does not exist.
    pattern = normalize_path('~/tmp/foo*')
    assert list(find_paths(pattern)) == []

    # Test with a path that does not exist.
    pattern = normalize_path('~/tmp/foo')
    assert list(find_paths(pattern))

# Generated at 2022-06-17 19:32:48.797664
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_ids
    from flutils.osutils import get_os_group_members_names
    from flutils.osutils import get_os_group_members_homes
    from flutils.osutils import get

# Generated at 2022-06-17 19:32:56.788982
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_uid == 0
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user(get_os_user().pw_uid).pw_name == get_os_user().pw_name
    assert get_os_user(get_os_user().pw_name).pw_uid == get_os_user().pw_uid
    assert get_os_user(get_os_user().pw_name).pw_name == get_os_user().pw_name



# Generated at 2022-06-17 19:33:08.085124
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from pathlib import Path
    from shutil import rmtree

    tmp_dir = get_temp_dir()
    tmp_dir = normalize_path(tmp_dir)
    tmp_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    tmp_dir_path = Path(tmp_dir)
    tmp_dir_path.joinpath('file_one').touch()
    tmp_dir_path.joinpath('dir_one').mkdir(mode=0o700, parents=True,
                                           exist_ok=True)


# Generated at 2022-06-17 19:33:08.469888
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:33:15.351427
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_uidgidname
    from flutils.osutils import get_os_uidgidnamenumber

# Generated at 2022-06-17 19:33:37.373703
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:33:49.521441
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import mkdir as os_mkdir
    from os import remove as os_remove
    from os import rmdir as os_rmdir
    from os import stat as os_stat
    from os import symlink as os_symlink
    from os import utime as os

# Generated at 2022-06-17 19:33:58.632856
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_env_path
    from flutils.osutils import get_os_env_path_split
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:33:59.175769
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:34:03.027700
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())



# Generated at 2022-06-17 19:34:04.234815
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:34:13.153919
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import make_dir
    from flutils.pathutils import make_file
    from flutils.pathutils import make_link
    from flutils.pathutils import make_fifo
    from flutils.pathutils import make_socket
    from flutils.pathutils import make_block_device
    from flutils.pathutils import make_char_device
    from flutils.pathutils import make_

# Generated at 2022-06-17 19:34:22.526008
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from os import getuid
    from os import getgid
    from os import stat
    from os import mkdir
    from os import rmdir
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import path as os_path
    from os import makedirs
    from os import remove
    from os import symlink
    from os import unlink


# Generated at 2022-06-17 19:34:23.019184
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:34:31.631516
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    # Create a temporary directory to use as the current working directory.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        # Change the current working directory to the temporary directory.
        os.chdir(tmpdir.as_posix())
        # Create a file and directory to test against.
        file_path = tmpdir / 'file_path'
        file_path.touch()
        dir_path = tmpdir / 'dir_path'
        dir_path.mkdir()
        # Test the file path.
        path_absent(file_path)
        assert file_path.exists() is False
        # Test the directory path.
        path_absent(dir_path)
        assert dir_path.exists() is False




# Generated at 2022-06-17 19:34:56.842551
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:35:01.382148
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    # Test that a directory is created.
    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path.is_

# Generated at 2022-06-17 19:35:11.977467
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from pathlib import Path
    import os
    import tempfile

    tmp_dir = Path(tempfile.mkdtemp())
    tmp_file = tmp_dir / 'tmp_file'
    tmp_dir_one = tmp_dir / 'tmp_dir_one'
    tmp_dir_two = tmp_dir_one / 'tmp_dir_two'
    tmp_file_one = tmp_dir_two / 'tmp_file_one'
    tmp_file_two = tmp_dir_two / 'tmp_file_two'
    tmp_file_three = tmp

# Generated at 2022-06-17 19:35:22.060585
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    import tempfile
    import shutil
    import os
    import sys
    import stat
    import getpass

    # Create a temporary directory to work in.
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Get the current user and group.
    user = get_os_user()
    group = get_os_group()

    # Create a test directory.
    test_dir = os.path.join(tmp_dir, 'test_dir')


# Generated at 2022-06-17 19:35:34.584047
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:35:38.619398
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('/')) == 'directory'
    assert exists_as(Path('/dev/null')) == 'char device'
    assert exists_as(Path('/dev/zero')) == 'char device'
    assert exists_as(Path('/dev/random')) == 'char device'
    assert exists_as(Path('/dev/urandom')) == 'char device'
    assert exists_as(Path('/dev/tty')) == 'char device'
    assert exists_as(Path('/dev/tty0')) == 'char device'
    assert exists_as(Path('/dev/tty1')) == 'char device'
    assert exists_as(Path('/dev/tty2')) == 'char device'

# Generated at 2022-06-17 19:35:48.782918
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_pwd


# Generated at 2022-06-17 19:35:58.788973
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    # Test the default behavior.
    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o700
    assert path.stat().st_uid == get_os_uid()
    assert path.stat().st_gid == get_os_gid()

    # Test the default behavior with a user and group.

# Generated at 2022-06-17 19:36:06.532134
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rm
    from flutils.osutils import rmdir
    from flutils.osutils import get_mode
    from flutils.osutils import get_uid
    from flutils.osutils import get_gid
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_id

# Generated at 2022-06-17 19:36:16.530908
# Unit test for function chmod
def test_chmod():
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:36:28.088434
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:36:37.188596
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:36:46.435925
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_env_var
    from flutils.osutils import get_os_env_vars
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:36:58.262019
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:37:02.841033
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(0o700)
        tmpdir.joinpath('foo.txt').touch()
        tmpdir.joinpath('bar.txt').touch()
        tmpdir.joinpath('baz.txt').touch()
        tmpdir.joinpath('qux.txt').touch()

        chmod(tmpdir.joinpath('foo.txt'), mode_file=0o660)
        chmod(tmpdir.joinpath('bar.txt'), mode_file=0o660)
        chmod(tmpdir.joinpath('baz.txt'), mode_file=0o660)

# Generated at 2022-06-17 19:37:10.372886
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'

    path_absent('~/tmp/test_path')
    path = directory_present('~/tmp/test_path/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path/test_path'

# Generated at 2022-06-17 19:37:19.751749
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user

    # Test chmod()
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.touch()
    assert path.exists() is True
    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660
    path.unlink()
    assert path_absent(path) is True

    # Test chmod() with a glob pattern
    path = normalize_

# Generated at 2022-06-17 19:37:27.420582
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''



# Generated at 2022-06-17 19:37:39.146395
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_symlink
    from flutils.pathutils import temp_symlink_target

    with temp_directory() as tmpdir:
        with temp_file(tmpdir) as tmpfile:
            assert exists_as(tmpfile) == 'file'
            assert exists_as(normalize_path(tmpfile)) == 'file'

        with temp_symlink(tmpdir) as tmpsym:
            assert exists_as(tmpsym) == ''
            assert exists_as(normalize_path(tmpsym)) == ''


# Generated at 2022-06-17 19:37:39.758129
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:38:10.361507
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    tmp_file_glob = os.path.join(tmp_dir, '*')
    tmp_file_glob_recursive = os.path.join(tmp_dir, '**')

# Generated at 2022-06-17 19:38:22.898690
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
