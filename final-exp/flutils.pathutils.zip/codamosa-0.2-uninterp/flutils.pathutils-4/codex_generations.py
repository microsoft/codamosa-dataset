

# Generated at 2022-06-17 19:28:49.328920
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_group_id
    from flutils.osutils import get_os_group_users
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_group_ids
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:28:58.221072
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod

    # Create a temporary directory to work in.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir = cast(Path, tmpdir)

        # Create a temporary file to work with.

# Generated at 2022-06-17 19:29:07.971826
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_

# Generated at 2022-06-17 19:29:19.154153
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/log') == 'socket'
    assert exists_as('/dev/random') == 'FIFO'
    assert exists_as('/dev/urandom') == 'FIFO'
    assert exists_as('/dev/zero') == 'FIFO'
    assert exists_as('/dev/full') == 'FIFO'
    assert exists_as('/dev/tty0') == 'FIFO'

# Generated at 2022-06-17 19:29:23.377306
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )
    assert get_os_group(2001) == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )



# Generated at 2022-06-17 19:29:32.840254
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    from flutils.pathutils import chmod

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)

    tmp_file_path = tmp_dir_path / 'flutils.tests.osutils.txt'
    tmp_file_path.touch()

    tmp_file_path_glob = tmp_dir_path / 'flutils.tests.osutils.*'
    tmp_file_path_glob.touch()

    tmp_dir_path_glob = tmp_dir_path / 'flutils.tests.osutils.*'
    tmp_dir_path_glob.mkdir()

    tmp_dir_path_glob_2 = tmp_dir_path / 'flutils.tests.osutils.**'
    tmp_dir

# Generated at 2022-06-17 19:29:42.416679
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')
    tmp_dir_two = os.path.join(tmp_dir, 'tmp_dir_two')
    tmp_dir_three = os.path.join(tmp_dir, 'tmp_dir_three')
    tmp_dir_four = os.path.join(tmp_dir, 'tmp_dir_four')
    tmp_dir_five = os.path.join(tmp_dir, 'tmp_dir_five')
    tmp_dir_six = os.path.join(tmp_dir, 'tmp_dir_six')
   

# Generated at 2022-06-17 19:29:53.318488
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import makedirs
    from flutils.osutils import remove
    from flutils.osutils import touch
    from flutils.osutils import write_file
    from flutils.osutils import write_file_lines

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    makedirs(path.parent)
    touch(path)
    write_file(path, 'test')
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152
    remove(path)
    makedirs(path.parent)
    touch(path)
    write_file_lines(path, ['test'])
    chmod(path, 0o660)

# Generated at 2022-06-17 19:30:02.769316
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import stat

    # Create a file and directory
    file_path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    dir_path = Path('~/tmp/flutils.tests.osutils.dir').expanduser()
    file_path.touch()
    dir_path.mkdir()

    # Test chmod()
    chmod(file_path, 0o660)
    assert stat.S_IMODE(os.stat(file_path).st_mode) == 0o660
    chmod(dir_path, 0o770)
    assert stat.S_IMODE(os.stat(dir_path).st_mode) == 0o770

    # Test chmod() with a glob pattern

# Generated at 2022-06-17 19:30:08.082873
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''



# Generated at 2022-06-17 19:30:50.065617
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import tmpdir
    from flutils.pathutils import tmpfile

    with tmpdir() as tmp_dir:
        with tmpfile(dir=tmp_dir) as tmp_file:
            assert exists_as(tmp_dir) == 'directory'
            assert exists_as(tmp_file) == 'file'

            # Test broken symlink
            broken_symlink = normalize_path(tmp_dir / 'broken_symlink')
            broken_symlink.symlink_to(tmp_file)
            broken_symlink.unlink()
            assert exists_as(broken_symlink) == ''

            # Test symlink to

# Generated at 2022-06-17 19:30:59.534622
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        tmp_dir.mkdir()
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()

        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one'),
        ]



# Generated at 2022-06-17 19:31:11.767116
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    # Test that the function raises an exception if the given path
    # contains a glob pattern.
    with pytest.raises(ValueError):
        directory_present('~/tmp/*')

    # Test that the function raises an exception if the given path
    # is not an absolute path.
    with pytest.raises(ValueError):
        directory_present('tmp')

    # Test that the function raises an exception if the given path
    # exists and is not a directory.


# Generated at 2022-06-17 19:31:19.982307
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from tempfile import TemporaryDirectory
    from tempfile import TemporaryFile
    from tempfile import NamedTemporaryFile
    from tempfile import mkstemp
    from tempfile import mkdtemp
    from tempfile import mktemp
    from tempfile import gettempdir
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    class TestPathAbsent(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.tempdir_path = Path(self.tempdir.name)
            self.tempdir_path.mk

# Generated at 2022-06-17 19:31:28.081284
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths"""
    # Test that the function returns an empty list if the given pattern
    # does not match any paths.
    assert list(find_paths('~/tmp/no_match')) == []

    # Test that the function returns a list of paths if the given pattern
    # matches paths.
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-17 19:31:35.998172
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:31:44.752964
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import remove_path

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    remove_path(path)
    assert path_absent(path) is True
    directory_present(path.parent)
    assert path_absent(path) is True
    with open(path, 'w') as f:
        f.write('test')
    assert path_absent(path) is False
    chmod(path, 0o660)
    assert path_absent(path) is False
    remove_path(path)
    assert path_absent(path) is True



# Generated at 2022-06-17 19:31:58.163378
# Unit test for function chown
def test_chown():
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    chown(path)
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    chown(path, user='root', group='root')
    assert path.stat().st_uid == 0
    assert path.stat().st_gid == 0
    chown(path, user='-1', group='-1')
    assert path.stat().st_uid == 0
    assert path.stat().st_gid == 0
    chown(path, user='-1', group='root')
    assert path.stat().st_uid == 0
    assert path.stat().st_gid == 0

# Generated at 2022-06-17 19:32:08.089367
# Unit test for function chmod
def test_chmod():
    """Test function chmod."""
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uid_from_username
    from flutils.osutils import get_os_gid_from_groupname

# Generated at 2022-06-17 19:32:18.462827
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user

# Generated at 2022-06-17 19:32:52.884927
# Unit test for function path_absent
def test_path_absent():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import path_absent

    class TestPathAbsent(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')
            self.test_link = os.path.join(self.test_dir, 'test_link')
            self.test_dir_link = os.path.join(self.test_dir, 'test_dir_link')
            self.test_dir_link_file = os.path.join(
                self.test_dir_link, 'test_dir_link_file'
            )
            self.test_dir_link_

# Generated at 2022-06-17 19:33:03.370088
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    import os

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == os.path.expanduser('~/tmp/flutils.tests.pathutils.directory_present')

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present')
    assert path.as_posix() == os.path.expanduser('~/tmp/flutils.tests.pathutils.directory_present')

    path = directory_present('~/tmp/flutils.tests.pathutils.directory_present/subdir')
    assert path.as_posix() == os.path.expanduser('~/tmp/flutils.tests.pathutils.directory_present/subdir')



# Generated at 2022-06-17 19:33:12.696674
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_login
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_

# Generated at 2022-06-17 19:33:23.848713
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from os import chmod as os_chmod
    from stat import S_IRUSR, S_IWUSR, S_IXUSR, S_IRGRP, S_IWGRP, S_IXGRP, S_IROTH, S_IWOTH, S_IXOTH

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir()
        tmpdir.joinpath('flutils.tests.osutils.txt').touch()
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o600)
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o600)
        tmpdir.join

# Generated at 2022-06-17 19:33:36.347442
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_group_id
    from flutils.osutils import get_os_user_group_name
    from flutils.osutils import get_os_user_group_ids
    from flutils.osutils import get_os_user_group_names
    from flutils.osutils import get_os_user_groups

# Generated at 2022-06-17 19:33:49.055887
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there/**') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there/**/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there/**/*') == ''

# Generated at 2022-06-17 19:33:58.313794
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_link = os.path.join(tmp_dir, 'tmp_link')
    tmp_dir_link = os.path.join(tmp_dir, 'tmp_dir_link')
    tmp_dir_link_file = os.path.join(tmp_dir_link, 'tmp_dir_link_file')
    tmp_dir_link_link = os.path.join(tmp_dir_link, 'tmp_dir_link_link')
    tmp_dir_link_dir = os.path.join(tmp_dir_link, 'tmp_dir_link_dir')


# Generated at 2022-06-17 19:34:10.157235
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home_dir
    from flutils.osutils import get_os_user_temp_dir
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_g

# Generated at 2022-06-17 19:34:14.006145
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:34:23.238658
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert os.stat(tmp_file).st_mode == 33152

    chmod(tmp_file, 0o644)
    assert os.stat(tmp_file).st_mode == 33188

    chmod(tmp_dir, 0o770)
    assert os.stat(tmp_dir).st_mode == 40960

    chmod(tmp_dir, 0o755)

# Generated at 2022-06-17 19:34:50.055561
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there') == ''



# Generated at 2022-06-17 19:35:00.937499
# Unit test for function chown
def test_chown():
    """Test for function chown."""
    import tempfile
    import os
    import stat
    import pwd
    import grp
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('foo')

    # Test chown with a file
    chown(tmp_file)
    assert os.stat(tmp_file).st_uid == pwd.getpwuid(os.getuid()).pw_uid
    assert os.stat(tmp_file).st_gid == grp.getgrgid(os.getgid()).gr_gid

    # Test chown with a directory
    chown

# Generated at 2022-06-17 19:35:06.288497
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.does.not.exist') == ''



# Generated at 2022-06-17 19:35:17.515277
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from os import PathLike
    from os import chmod as os_chmod
    from os import chown as os_chown
    from os import getuid
    from os import getgid
    from os import geteuid
    from os import getegid
    from os import getgroups
    from os import stat
    from os import mkdir


# Generated at 2022-06-17 19:35:24.695885
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Change to the temporary directory
    os.chdir(tmpdir)

    # Create a directory
    os.mkdir('test_dir')

    # Create a file
    with open('test_file', 'w') as f:
        f.write('test file')

    # Create a symbolic link to a file
    os.symlink('test_file', 'test_file_link')

    # Create a symbolic link to a directory
    os.symlink('test_dir', 'test_dir_link')

    # Create a FIFO

# Generated at 2022-06-17 19:35:35.414071
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import remove_path
    from flutils.osutils import touch
    from flutils.osutils import mkdir

    path = '~/tmp/flutils.tests.osutils.txt'
    remove_path(path)
    touch(path)
    chmod(path, 0o660)
    assert os.stat(path).st_mode & 0o777 == 0o660

    path = '~/tmp/flutils.tests.osutils.dir'
    remove_path(path)
    mkdir(path)
    chmod(path, mode_dir=0o770)
    assert os.stat(path).st_mode & 0o777 == 0o770


# Generated at 2022-06-17 19:35:43.241399
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_isdir
    from flutils.pathutils import path_isfile
    from flutils.pathutils import path_islink
    from flutils.pathutils import path_issock
    from flutils.pathutils import path_isfifo
    from flutils.pathutils import path_isblk
    from flutils.pathutils import path_ischr
    from flutils.pathutils import path_mode
    from flutils.pathutils import path_owner
    from flutils.pathutils import path_group
    from flutils.pathutils import path_type
    from flutils.osutils import get

# Generated at 2022-06-17 19:35:44.088633
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:35:57.593126
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import remove_path
    from flutils.osutils import touch
    from flutils.osutils import mkdir

    # Test with a file
    touch('~/tmp/flutils.tests.osutils.txt')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert os.stat('~/tmp/flutils.tests.osutils.txt').st_mode == 33152
    remove_path('~/tmp/flutils.tests.osutils.txt')

    # Test with a directory
    mkdir('~/tmp/flutils.tests.osutils.dir')
    chmod('~/tmp/flutils.tests.osutils.dir', mode_dir=0o770)

# Generated at 2022-06-17 19:36:05.619194
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:36:26.339858
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present

    with directory_present('~/tmp/flutils.tests.pathutils.chmod'):
        with open('~/tmp/flutils.tests.pathutils.chmod/test.txt', 'w') as f:
            f.write('test')

        chmod('~/tmp/flutils.tests.pathutils.chmod/test.txt', 0o660)

        assert os.stat('~/tmp/flutils.tests.pathutils.chmod/test.txt').st_mode == 33152

        chmod('~/tmp/flutils.tests.pathutils.chmod/**', mode_file=0o644, mode_dir=0o770)

        assert os.stat

# Generated at 2022-06-17 19:36:33.017317
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists

    # Create a directory and file to test with
    directory_present('~/tmp/flutils.tests.osutils')
    with open('~/tmp/flutils.tests.osutils/test_chmod.txt', 'w') as f:
        f.write('test')

    # Test with a file
    chmod('~/tmp/flutils.tests.osutils/test_chmod.txt', 0o660)
    assert path_exists('~/tmp/flutils.tests.osutils/test_chmod.txt') is True

# Generated at 2022-06-17 19:36:36.782690
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    path = normalize_path('~/tmp/flutils.tests.pathutils.directory_present')
    path_absent(path)
    path = directory_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)



# Generated at 2022-06-17 19:36:46.177108
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH_TYPE
    from flutils.pathutils import _PATH_TYPE_OR_STR
    from flutils.pathutils import _STR_OR_INT_OR_NONE_OR_PATH
   

# Generated at 2022-06-17 19:36:51.942812
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path = normalize_path(path)
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:37:02.161779
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'

# Generated at 2022-06-17 19:37:02.711805
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:37:10.291485
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils.test_pathutils import (
        TEST_DIR,
        TEST_DIR_PATH,
        TEST_FILE_PATH,
        TEST_FILE_PATH_2,
    )
    from flutils.tests.pathutils.test_pathutils import (
        TEST_DIR_PATH_2,
        TEST_DIR_PATH_3,
        TEST_DIR_PATH_4,
        TEST_DIR_PATH_5,
    )
    from flutils.tests.pathutils.test_pathutils import (
        TEST_DIR_PATH_6,
        TEST_DIR_PATH_7,
        TEST_DIR_PATH_8,
        TEST_DIR_PATH_9,
    )

# Generated at 2022-06-17 19:37:19.750711
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())
    assert get_os_user('root') == pwd.getpwnam('root')
    assert get_os_user(0) == pwd.getpwuid(0)
    assert get_os_user(1) == pwd.getpwuid(1)
    assert get_os_user(2) == pwd.getpwuid(2)
    assert get_os_user(3) == pwd.getpwuid

# Generated at 2022-06-17 19:37:29.816627
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    import os
    import tempfile

    # Test a path that does not exist.
    assert exists_as('/tmp/does_not_exist') == ''

    # Test a path that exists as a directory.
    assert exists_as('/tmp') == 'directory'

    # Test a path that exists as a file.
    with tempfile.NamedTemporaryFile() as tmp_file:
        assert exists_as(tmp_file.name) == 'file'

    # Test a path that exists as a block device.
    assert exists_as('/dev/null') == 'block device'

    # Test a path that exists as a character device.

# Generated at 2022-06-17 19:37:44.843118
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())
    with pytest.raises(OSError):
        get_os_user(0)
    with pytest.raises(OSError):
        get_os_user('root')



# Generated at 2022-06-17 19:37:54.755559
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user

# Generated at 2022-06-17 19:38:07.236739
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

# Generated at 2022-06-17 19:38:14.041479
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os
    import stat

    # Create a test directory.
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = Path(tmp_dir)

    # Create a test file.
    tmp_file = tmp_dir / 'test_file'
    with tmp_file.open('w') as f:
        f.write('test')

    # Create a test directory.
    tmp_dir_2 = tmp_dir / 'test_dir'
    tmp_dir_2.mkdir()

    # Create a test file in the test directory.
    tmp_file_2 = tmp_dir_2 / 'test_file_2'

# Generated at 2022-06-17 19:38:24.158064
# Unit test for function chown
def test_chown():
    """Unit test for function chown"""
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_group_ids
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_