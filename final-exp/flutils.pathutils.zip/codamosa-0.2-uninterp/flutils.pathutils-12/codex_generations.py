

# Generated at 2022-06-17 19:28:53.345239
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.pathutils import find_paths

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()

        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:29:00.566449
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import get_temp_file
    from flutils.osutils import get_temp_dir_name
    from flutils.osutils import get_temp_file_name
    from flutils.osutils import get_temp_path
    from flutils.osutils import get_temp_path_name
    from flutils.osutils import get_temp_path_name_ext
    from flutils.osutils import get_temp_path_name_ext_suffix
    from flutils.osutils import get_temp_path_name_suffix
    from flutils.osutils import get_temp_path_name_suffix_ext

# Generated at 2022-06-17 19:29:07.748483
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_file_path
    from flutils.pathutils import temp_path
    from flutils.pathutils import temp_path_path


# Generated at 2022-06-17 19:29:14.683412
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    assert exists_as(normalize_path('~/tmp')) == 'directory'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt')) == 'file'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt.bak')) == ''



# Generated at 2022-06-17 19:29:25.878862
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('/') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/shadow') == 'file'
    assert exists_as('/etc/sudoers') == 'file'

# Generated at 2022-06-17 19:29:33.827575
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths"""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_two').mkdir()

        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('dir_one'),
            tmpdir.joinpath('dir_two'),
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('file_two'),
        ]



# Generated at 2022-06-17 19:29:42.527768
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:29:53.402035
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import stat
    import pwd
    import grp
    import pytest
    from flutils.pathutils import chown

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:30:02.969505
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.systemutils import get_temp_dir
    from pathlib import Path
    from tempfile import mkdtemp
    from typing import Generator

    tmp_dir = Path(mkdtemp(dir=get_temp_dir()))
    tmp_dir.joinpath('file_one').touch()
    tmp_dir.joinpath('dir_one').mkdir()
    tmp_dir.joinpath('dir_two').mkdir()


# Generated at 2022-06-17 19:30:09.082042
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    import os
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:30:26.587039
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import chown

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir('foo')
        tmpdir.mkdir('bar')
        tmpdir.mkdir('baz')
        tmpdir.joinpath('foo').mkdir('baz')
        tmpdir.joinpath('foo').joinpath('baz').touch()
        tmpdir.joinpath('foo').joinpath('baz').chmod(0o777)
        tmpdir.joinpath('foo').joinpath('baz').chown(0, 0)
        tmpdir.joinpath('bar').touch()
        tmpdir.joinpath('bar').chmod(0o777)
        tmpdir.joinpath('bar').chown(0, 0)
        tmpdir

# Generated at 2022-06-17 19:30:27.070196
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:30:29.121771
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:30:29.743212
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:30:39.424272
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.osutils import rm_rf
    from flutils.tests.pathutils import (
        TEST_DIR_ABS,
        TEST_DIR_REL,
        TEST_FILE_ABS,
        TEST_FILE_REL,
        TEST_LINK_ABS,
        TEST_LINK_REL,
        TEST_SOCKET_ABS,
        TEST_SOCKET_REL,
    )

    # Test that the function raises an exception if the given path
    # contains a glob pattern.
    try:
        directory_present('~/tmp/flutils.tests.pathutils.*')
    except ValueError:
        pass

# Generated at 2022-06-17 19:30:49.471381
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch

    tmp_dir = get_temp_dir()

# Generated at 2022-06-17 19:31:01.391365
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_shell
    from flutils.osutils import get_os_uid_name
    from flutils.osutils import get_os_gid_name
    from flutils.osutils import get_os_uid_group
    from flutils.osutils import get_os_gid_group

# Generated at 2022-06-17 19:31:13.252367
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gid

# Generated at 2022-06-17 19:31:19.115559
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.osutils import get_os_user

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path.is_block_device() is False
    assert path.is_char_device() is False
    assert path.stat().st_uid == get_os

# Generated at 2022-06-17 19:31:27.476645
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as

    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'test_path')
    path_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''
    shutil.rmtree(tmpdir)



# Generated at 2022-06-17 19:31:44.875115
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:31:52.120213
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    from flutils.pathutils import get_os_user
    assert get_os_user()
    assert get_os_user(get_os_user().pw_uid)
    assert get_os_user(get_os_user().pw_name)
    assert get_os_user(get_os_user().pw_name).pw_uid == get_os_user().pw_uid
    assert get_os_user(get_os_user().pw_uid).pw_name == get_os_user().pw_name



# Generated at 2022-06-17 19:32:02.526295
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    import tempfile
    import shutil
    import os
    import stat
    import getpass
    import pwd
    import grp
    import sys
    import pytest
    import pathlib

    # Test with a file.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = pathlib.Path(tmp_dir)
        tmp_file = tmp_dir / 'tmp_file'
        tmp_file.touch()
        path_absent(tmp_file)

# Generated at 2022-06-17 19:32:13.623964
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path

    # Test that a path is created as a directory.
    path = directory_present('~/tmp/test_path')
    assert path.is_dir() is True
    assert path.exists() is True
    assert path.as_posix() == normalize_path('~/tmp/test_path').as_posix()

    # Test that a path is created as a directory with a mode.
    path = directory

# Generated at 2022-06-17 19:32:22.033624
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    import os
    import tempfile

    path = normalize_path(tempfile.mkdtemp())
    path = path / 'foo'
    path_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert os.path.exists(path) is False



# Generated at 2022-06-17 19:32:22.544567
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:32:29.792048
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    import os
    import pathlib
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:32:41.098847
# Unit test for function directory_present
def test_directory_present():
    """Test the function directory_present."""
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from flutils.pathutils import directory_present

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        test_path = tmpdir / 'test_path'
        assert test_path.exists() is False
        assert directory_present(test_path) == test_path
        assert test_path.exists() is True
        assert test_path.is_dir() is True

        test_path = tmpdir / 'test_path'
        assert test_path.exists() is True
        assert directory_present(test_path) == test_path
        assert test_path.exists() is True
        assert test_path.is_dir() is True


# Generated at 2022-06-17 19:32:48.173207
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:32:54.288565
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:33:13.812303
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.testingutils import TempDir

    with TempDir() as tmp_dir:
        tmp_dir.create_file('file_one')
        tmp_dir.create_file('file_two')
        tmp_dir.create_dir('dir_one')
        tmp_dir.create_dir('dir_two')

        assert list(find_paths(tmp_dir.path / '*')) == [
            tmp_dir.path / 'dir_one',
            tmp_dir.path / 'dir_two',
            tmp_dir.path / 'file_one',
            tmp_dir.path / 'file_two'
        ]


# Generated at 2022-06-17 19:33:24.175159
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:33:30.392232
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:33:37.985829
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import remove

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)

    mkdir(path.parent)
    touch(path)

    chmod(path, 0o660)

    assert path.stat().st_mode == 33152

    remove(path)
    remove(path.parent)

# Generated at 2022-06-17 19:33:49.581283
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()

        # Test a glob pattern that matches a file and a directory.

# Generated at 2022-06-17 19:33:56.791834
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'
    assert exists_as('/dev/tty5')

# Generated at 2022-06-17 19:34:04.320414
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())
    assert get_os_user('root') == pwd.getpwnam('root')
    assert get_os_user('-1') == pwd.getpwuid(-1)
    assert get_os_user(0) == pwd.getpwuid(0)
    assert get_os_user(1) == pwd.getpwuid(1)
    assert get_os_user(2) == pwd.getpw

# Generated at 2022-06-17 19:34:13.239357
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path
    from flutils.pathutils import PathType

    # Test a glob pattern that will return results.
    pattern = normalize_path('~/tmp/*')
    assert isinstance(pattern, PathType)
    assert pattern.as_posix() == '/home/test_user/tmp/*'
    assert list(find_paths(pattern)) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]

    # Test a glob pattern that will NOT return results.
    pattern = normalize_path('~/tmp/*.txt')
    assert isinstance(pattern, PathType)
    assert pattern

# Generated at 2022-06-17 19:34:22.563096
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/Users/len/tmp') == 'directory'
    assert exists_as('/Users/len/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/Users/len/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('/Users/len/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('/Users/len/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('/Users/len/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''

# Generated at 2022-06-17 19:34:30.413127
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()

        assert list(find_paths(tmpdir.joinpath('*'))) == [
            normalize_path(tmpdir.joinpath('file_one')),
            normalize_path(tmpdir.joinpath('dir_one'))
        ]



# Generated at 2022-06-17 19:34:50.928286
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

# Generated at 2022-06-17 19:35:01.245663
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:35:11.932709
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / 'flutils.tests.osutils.txt'
        tmp_file.touch()

        assert os.stat(tmp_file).st_mode & stat.S_IRWXU == 0o600

        chmod(tmp_file, 0o660)
        assert os.stat(tmp_file).st_mode & stat.S_IRWXU == 0o660

        chmod(tmp_dir / '*', 0o660)
        assert os.stat(tmp_file).st_mode & stat.S_IRWXU == 0o660


# Generated at 2022-06-17 19:35:22.025327
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:35:34.583061
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import path_absent

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = normalize_path(tmp_dir.name)

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir.name)
    tmp_file_path = normalize_path(tmp_file.name)

    # Get the current user's login name
    user = getpass.getuser()
    # Get the current user's

# Generated at 2022-06-17 19:35:42.769024
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import pwd
    import grp
    import pytest

    # Test chown()
    def test_chown_basic():
        # Create a temporary directory
        tmpdir = tempfile.mkdtemp()
        # Create a file in the temporary directory
        f = open(os.path.join(tmpdir, 'test.txt'), 'w')
        f.close()
        # Get the uid/gid of the current user
        uid = pwd.getpwnam(getpass.getuser()).pw_uid
        gid = grp.getgrnam(getpass.getuser()).gr_gid
        # Change the ownership of the file

# Generated at 2022-06-17 19:35:49.721849
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link.link') == ''



# Generated at 2022-06-17 19:35:59.441616
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:36:06.899883
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_path
    from flutils.osutils import get_os_tmp_path_str
    from flutils.osutils import get_os_tmp_path_bytes
    from flutils.osutils import get_os_tmp_path_path

# Generated at 2022-06-17 19:36:16.711760
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.testutils import TempDir
    with TempDir() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_path'
        path.mkdir()
        path_absent(path)
        assert path.exists() is False
        path.mkdir()
        (path / 'test_file').touch()
        path_absent(path)
        assert path.exists() is False
        path.mkdir()
        (path / 'test_file').touch()
        path_absent(path)
        assert path.exists() is False
        path.mkdir()
        (path / 'test_file').touch()
        path_absent(path)
        assert path.exists() is False

# Generated at 2022-06-17 19:37:07.780573
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user

# Generated at 2022-06-17 19:37:16.494635
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.pathutils import (
        _create_test_dir,
        _remove_test_dir,
    )
    from flutils.tests.osutils import (
        _get_test_dir,
        _get_test_file,
    )

    test_dir = _get_test_dir()
    test_file = _get_test_file()

    _create_test_dir()

    chmod(test_file, 0o660)
    chmod(test_dir, 0o770)

    _remove_test_dir()



# Generated at 2022-06-17 19:37:27.966487
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    tmp_file_path = tmp_dir_path / 'flutils.tests.osutils.txt'
    tmp_file_path.touch()

    # Test that chmod does not change the mode of a file that does not exist.
    chmod(tmp_dir_path / 'flutils.tests.osutils.txt.does.not.exist')
    assert os.stat(tmp_file_path.as_posix()).st_mode == 33188

    # Test that chmod does not change the mode of a directory that does not
    # exist.

# Generated at 2022-06-17 19:37:39.706478
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from os import PathLike
    from pathlib import PosixPath
    from pathlib import WindowsPath
    from typing import Union
    from unittest import TestCase
    from unittest.mock import patch
    from unittest.mock import sentinel


# Generated at 2022-06-17 19:37:46.820251
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.osutils import get_current_user
    from flutils.osutils import get_current_group
    from flutils.osutils import get_current_user_id
    from flutils.osutils import get_current_group_id
    from flutils.osutils import get_current_user_name
    from flutils.osutils import get_current_group_name
    from flutils.osutils import get_current_user_home

# Generated at 2022-06-17 19:37:59.211128
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members

# Generated at 2022-06-17 19:38:07.456975
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import remove
    from flutils.osutils import get_mode

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    mkdir(path.parent)
    touch(path)
    chmod(path, 0o660)
    assert get_mode(path) == 0o660
    remove(path)
    remove(path.parent)



# Generated at 2022-06-17 19:38:15.655176
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    from flutils.pathutils import chmod

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(parents=True, exist_ok=True)
        tmpdir.joinpath('flutils.tests.osutils.txt').touch()
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o600)
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o660)
        assert os.stat(tmpdir.joinpath('flutils.tests.osutils.txt')).st_mode == 33152
        chmod(tmpdir.joinpath('flutils.tests.osutils.txt'), 0o600)