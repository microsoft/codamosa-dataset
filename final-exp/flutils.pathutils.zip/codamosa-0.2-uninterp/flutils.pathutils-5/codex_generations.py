

# Generated at 2022-06-17 19:29:04.845125
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmpdir / 'dir_two'
        dir_two.mkdir()
        dir_three = dir_two / 'dir_three'
        dir_three.mkdir()
        file_two = dir_three / 'file_two'
        file_two.touch()


# Generated at 2022-06-17 19:29:16.333451
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one/file_two').touch()

        paths = list(find_paths(tmpdir.joinpath('*')))
        assert len(paths) == 2
        assert normalize_path(paths[0]) == normalize_path(tmpdir.joinpath('file_one'))

# Generated at 2022-06-17 19:29:26.876276
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys
    import pathlib
    import random
    import string

    # Create a temporary directory to use for testing.
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = pathlib.Path(tmp_dir)

    # Create a random string to use for the file name.
    rand_str = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
    rand_str = cast(str, rand_str)

    # Create a file to test with.
    tmp_file = tmp_dir / rand_str
    tmp_file = cast(pathlib.Path, tmp_file)
    tmp_file.touch

# Generated at 2022-06-17 19:29:36.770392
# Unit test for function path_absent
def test_path_absent():
    # Test that a file is removed.
    path = Path('~/tmp/test_path')
    path.touch()
    path_absent(path)
    assert path.exists() is False

    # Test that a directory is removed.
    path = Path('~/tmp/test_path')
    path.mkdir()
    path_absent(path)
    assert path.exists() is False

    # Test that a directory with contents is removed.
    path = Path('~/tmp/test_path')
    path.mkdir()
    Path('~/tmp/test_path/test_file').touch()
    path_absent(path)
    assert path.exists() is False

    # Test that a symbolic link is removed.
    path = Path('~/tmp/test_path')
    path.touch()

# Generated at 2022-06-17 19:29:43.930567
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'block device'
    assert exists_as('/dev/urandom') == 'block device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'

# Generated at 2022-06-17 19:29:54.316941
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    path = directory_present('~/tmp/flutils.tests.pathutils.txt')
    assert path.as_posix() == '~/tmp/flutils.tests.pathutils.txt'
    assert exists_as(path) == 'directory'

    path = directory_present('~/tmp/flutils.tests.pathutils.txt')
    assert path.as_posix() == '~/tmp/flutils.tests.pathutils.txt'
    assert exists_as(path) == 'directory'


# Generated at 2022-06-17 19:30:04.257189
# Unit test for function find_paths
def test_find_paths():
    """Test :func:`~flutils.pathutils.find_paths`."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Test a single file.
    file_one = normalize_path('~/tmp/file_one')
    file_one.touch()
    assert list(find_paths('~/tmp/file_one')) == [file_one]

    # Test a single directory.
    dir_one = normalize_path('~/tmp/dir_one')
    dir_one.mkdir()
    assert list(find_paths('~/tmp/dir_one')) == [dir_one]

    # Test a glob pattern.

# Generated at 2022-06-17 19:30:13.501814
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_group_user
    from flutils.osutils import get_os_user_group_id
    from flutils.osutils import get_os_group_user_id

    # Test with user and group
    chown('~/tmp/flutils.tests.osutils.txt', user='foo', group='bar')
    assert get_os_user_group('~/tmp/flutils.tests.osutils.txt') == ('foo', 'bar')

# Generated at 2022-06-17 19:30:21.772864
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from tempfile import TemporaryDirectory
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir = tmpdir.as_posix()
        tmpdir = cast(str, tmpdir)

        # Test that path_absent does not error when the given path does not
        # exist.
        path_absent(os.path.join(tmpdir, 'test_path'))

        # Test that path_absent removes a file.
        path_present(os.path.join(tmpdir, 'test_path'))
       

# Generated at 2022-06-17 19:30:28.427753
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_group_shell
    from flutils.osutils import get_os_user_shell_path
    from flutils.osutils import get_os_group_shell_path
    from flutils.osutils import get_os_user_shell_path_exists
    from flutils.osutils import get_

# Generated at 2022-06-17 19:30:55.378327
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1')

# Generated at 2022-06-17 19:31:06.836657
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert exists_as(path) == 'directory'
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path

# Generated at 2022-06-17 19:31:15.777863
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwnam(getpass.getuser())

# Generated at 2022-06-17 19:31:16.461125
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:31:28.295162
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:31:38.545181
# Unit test for function chown
def test_chown():
    import os
    import stat
    import tempfile
    import unittest

    from flutils.pathutils import chown

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.TemporaryDirectory()
            self.tmp_dir_path = Path(self.tmp_dir.name)
            self.tmp_file_path = self.tmp_dir_path / 'foo.txt'
            self.tmp_file_path.touch()

        def tearDown(self):
            self.tmp_dir.cleanup()

        def test_chown_file(self):
            chown(self.tmp_file_path, user='-1', group='-1')

# Generated at 2022-06-17 19:31:46.624525
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_giduid
    from flutils.osutils import get_os_usernamegid
    from flutils.osutils import get

# Generated at 2022-06-17 19:31:47.585467
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:31:58.944725
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys

    # Create a temporary directory.
    tmpdir = tempfile.mkdtemp()
    tmpdir = os.path.join(tmpdir, 'test_path_absent')
    os.mkdir(tmpdir)

    # Create a temporary file.
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Create a temporary directory.
    tmpdir2 = os.path.join(tmpdir, 'tmpdir2')
    os.mkdir(tmpdir2)

    # Create a temporary file.

# Generated at 2022-06-17 19:32:05.629792
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''



# Generated at 2022-06-17 19:33:00.024048
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_home_dir
    from flutils.osutils import get_os_user_temp_dir

# Generated at 2022-06-17 19:33:10.641756
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_home_dir
    from flutils.osutils import get_os_user_home_path
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:33:16.978374
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_fifo
    from flutils.pathutils import temp_socket
    from flutils.pathutils import temp_symlink

    with temp_directory() as tmp_dir:
        assert exists_as(tmp_dir) == 'directory'

        with temp_file(tmp_dir) as tmp_file:
            assert exists_as(tmp_file) == 'file'

        with temp_fifo(tmp_dir) as tmp_fifo:
            assert exists_as(tmp_fifo) == 'FIFO'


# Generated at 2022-06-17 19:33:17.596011
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:33:25.893155
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.link.link.link.link') == ''

# Generated at 2022-06-17 19:33:37.841831
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_homedir

# Generated at 2022-06-17 19:33:49.553969
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_temp_

# Generated at 2022-06-17 19:33:56.750285
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    import os

    # Test chmod() with a file
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert exists_as('~/tmp/flutils.tests.osutils.txt', 'file') is True
    assert os.stat('~/tmp/flutils.tests.osutils.txt').st_mode & 0o777 == 0o660
    path_absent('~/tmp/flutils.tests.osutils.txt')

    # Test chmod() with a directory

# Generated at 2022-06-17 19:34:04.256785
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown
    from flutils.pathutils import chmod
    from flutils.pathutils import create_dir
    from flutils.pathutils import create_file
    from flutils.pathutils import create_symlink
    from flutils.pathutils import create_fifo
    from flutils.pathutils import create_socket
    from flutils.pathutils import create_block_device
    from flutils.pathutils import create_char_device

# Generated at 2022-06-17 19:34:04.881883
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:34:56.765519
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a file
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.txt')

    # Create a directory
    tmp_dir2 = os.path.join(tmp_dir, 'flutils.tests.osutils')
    os.mkdir(tmp_dir2)

    # Create a file in the directory
    tmp_file2 = os.path.join(tmp_dir2, 'flutils.tests.osutils.txt')

# Generated at 2022-06-17 19:35:03.823739
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o660

    chmod(tmp_dir, 0o770)
    assert stat.S_IMODE(os.stat(tmp_dir).st_mode) == 0o770

    shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:35:15.482875
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile

    from flutils.pathutils import chmod

    # Create a temp directory
    tmp_dir = tempfile.TemporaryDirectory()

    # Create a file in the temp directory
    tmp_file = os.path.join(tmp_dir.name, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.txt')

    # Create a sub-directory in the temp directory
    tmp_sub_dir = os.path.join(tmp_dir.name, 'subdir')
    os.mkdir(tmp_sub_dir)

    # Create a file in the sub-directory

# Generated at 2022-06-17 19:35:23.391276
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('/tmp/flutils.tests.osutils.txt')
    chown('/tmp/flutils.tests.osutils.txt', user='-1')
    chown('/tmp/flutils.tests.osutils.txt', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='-1', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='root', group='root')
    chown('/tmp/flutils.tests.osutils.txt', user='root', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='-1', group='root')

# Generated at 2022-06-17 19:35:35.332456
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('foo')

    # Test chown with no args
    chown(tmp_file)
    assert get_os_uid(tmp_file) == get_os_user().pw_uid

# Generated at 2022-06-17 19:35:41.523620
# Unit test for function chmod
def test_chmod():
    """Test function chmod."""
    from flutils.pathutils import chmod

    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')



# Generated at 2022-06-17 19:35:50.040383
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user


# Generated at 2022-06-17 19:35:59.481162
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:36:03.964064
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    test_path = Path('~/tmp/flutils.tests.pathutils.test_directory_present')
    test_path = directory_present(test_path)
    assert exists_as(test_path) == 'directory'
    path_absent(test_path)



# Generated at 2022-06-17 19:36:15.065030
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-17 19:36:39.434518
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys
    import time

    # Create a temporary directory.
    temp_dir = tempfile.mkdtemp()
    temp_dir = os.path.normpath(temp_dir)
    temp_dir = os.path.normcase(temp_dir)

    # Create a temporary file.
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()
    temp_file = os.path.normpath(temp_file.name)
    temp_file = os.path.normcase(temp_file)

    # Create a temporary directory.

# Generated at 2022-06-17 19:36:47.709582
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir_p
    from flutils.osutils import touch
    from flutils.osutils import rm_rf
    from flutils.osutils import symlink
    from flutils.osutils import which
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_nested
   

# Generated at 2022-06-17 19:36:59.114052
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:37:06.554066
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user_group
    from flutils.pathutils import get_os_user_groups
    from flutils.pathutils import get_os_user_home
    from flutils.pathutils import get_os_user_shell
    from flutils.pathutils import get_os_user_uid
    from flutils.pathutils import get_os_user_gid
    from flutils.pathutils import get_os_user_gecos
    from flutils.pathutils import get_os_user_passwd
    from flutils.pathutils import get_os_user_dir

    assert get_os_user() == get_

# Generated at 2022-06-17 19:37:17.783228
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils import (
        TEST_DIR_ABS,
        TEST_DIR_REL,
        TEST_FILE_ABS,
        TEST_FILE_REL,
        TEST_SYMLINK_ABS,
        TEST_SYMLINK_REL,
    )

    # Test a path that does not exist.
    test_path = directory_present(TEST_DIR_REL)
    assert test_path.as_posix() == TEST_DIR_ABS

    # Test a path that exists as a directory.
    test_path = directory_present(TEST_DIR_REL)
    assert test_path.as_posix() == TEST_DIR_ABS

    # Test a path that exists as a file.

# Generated at 2022-06-17 19:37:23.653419
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists

# Generated at 2022-06-17 19:37:30.829276
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_shell
    from flutils.osutils import get_os_gecos
    from flutils.osutils import get_os_uid_range
    from flutils.osutils import get_os_gid_range
    from flutils.osutils import get_os_uid_min
    from flutils.osutils import get_

# Generated at 2022-06-17 19:37:42.009671
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:37:53.268401
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'

# Generated at 2022-06-17 19:38:04.783577
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_group_gid
    from flutils.osutils import get_os_user_uid