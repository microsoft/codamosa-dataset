

# Generated at 2022-06-17 19:28:46.551981
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as

    test_path = Path('~/tmp/test_path').expanduser()
    path_absent(test_path)
    assert exists_as(test_path) == ''
    directory_present(test_path)
    assert exists_as(test_path) == 'directory'
    path_absent(test_path)



# Generated at 2022-06-17 19:28:56.420945
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uid_from_username
    from flutils.osutils import get_os_gid_from_groupname
    from flutils.osutils import get_os_username_from_uid
   

# Generated at 2022-06-17 19:29:06.116367
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gids
    from flutils.osutils import get_os_group_users

# Generated at 2022-06-17 19:29:16.397845
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:29:25.101042
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uid_from_name
    from flutils.osutils import get_os_gid_from_name

# Generated at 2022-06-17 19:29:35.691931
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from pathlib import (
        Path,
        PosixPath,
        WindowsPath,
    )
    from typing import (
        Deque,
        Generator,
        Optional,
        Union,
        cast,
    )


# Generated at 2022-06-17 19:29:46.845937
# Unit test for function find_paths
def test_find_paths():
    """Test the :obj:`find_paths` function."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.osutils import remove_path

    with temp_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()

        assert list(find_paths(tmp_dir / '*')) == [file_one, dir_one]
        assert list(find_paths(tmp_dir / 'file_*')) == [file_one]

# Generated at 2022-06-17 19:29:56.838370
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'

# Generated at 2022-06-17 19:30:02.961203
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as

    path = Path('~/tmp/test_path')
    path_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''



# Generated at 2022-06-17 19:30:11.586058
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_temp_file
    from flutils.osutils import get_os_temp_dir_name
    from flutils.osutils import get_os_temp_file_name

# Generated at 2022-06-17 19:30:39.022497
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_home

# Generated at 2022-06-17 19:30:49.550259
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import (
        get_os_group,
        get_os_user,
    )

    from tempfile import TemporaryDirectory
    from unittest import TestCase

    from os import (
        chmod,
        chown,
        getegid,
        geteuid,
        getgid,
        getuid,
        lstat,
        mkdir,
        stat,
        symlink,
        unlink,
    )

    from os.path import (
        exists,
        join,
    )

    from stat import (
        S_IMODE,
        S_ISDIR,
        S_ISLNK,
        S_ISREG,
    )


# Generated at 2022-06-17 19:31:01.427303
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/ptmx') == 'char device'
    assert exists_as('/dev/pts/0') == 'char device'
    assert exists_as('/dev/pts/1') == 'char device'
    assert exists_as('/dev/pts/2') == 'char device'
    assert exists_as('/dev/pts/3') == 'char device'

# Generated at 2022-06-17 19:31:13.251151
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_uid_name
    from flutils.osutils import get_os_gid_name
    from flutils.osutils import get_os_uid_home
    from flutils.osutils import get_os_gid_home

# Generated at 2022-06-17 19:31:19.116073
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

# Generated at 2022-06-17 19:31:29.765457
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_shell
    from flutils.osutils import get_os_realname
    from flutils.osutils import get_os_homedir
    from flutils.osutils import get_os_uid_from_username
    from flutils.osutils import get_os_gid_from_groupname

# Generated at 2022-06-17 19:31:37.967999
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert os.stat(tmp_file).st_mode == 33152

    chmod(tmp_dir, 0o770)
    assert os.stat(tmp_dir).st_mode == 40960

    shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:31:48.369184
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rm
    from flutils.osutils import rmdir

    tmp_dir = get_temp_dir()
    tmp_dir = Path(tmp_dir)
    tmp_dir = tmp_dir / 'find_paths'

    mkdir(tmp_dir)
    touch(tmp_dir / 'file_one')
    mkdir(tmp_dir / 'dir_one')
    touch(tmp_dir / 'dir_one' / 'file_two')

    paths = list(find_paths(tmp_dir / '*'))
    assert len(paths) == 2

# Generated at 2022-06-17 19:31:59.222213
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    import os
    import tempfile
    import shutil
    import stat
    import sys

    # Create a temporary directory to work in.
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)

    # Create a temporary file.
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a temporary directory.

# Generated at 2022-06-17 19:32:07.062926
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing_link') == ''



# Generated at 2022-06-17 19:32:38.035662
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.symlink') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_symlink') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing.symlink') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.missing.broken_symlink') == ''

# Generated at 2022-06-17 19:32:49.604252
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Test a glob pattern that does not exist.
    assert list(find_paths('~/tmp/does_not_exist')) == []

    # Test a glob pattern that exists.
    assert list(find_paths('~/tmp/*')) == [
        normalize_path('~/tmp/file_one'),
        normalize_path('~/tmp/dir_one')
    ]

    # Test a glob pattern that exists with a recursive search.

# Generated at 2022-06-17 19:33:00.119896
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir

    tmp_dir = get_temp_dir()
    tmp_dir = normalize_path(tmp_dir)

    tmp_dir_one = mkdir(tmp_dir / 'dir_one')
    tmp_dir_two = mkdir(tmp_dir / 'dir_two')
    tmp_dir_three = mkdir(tmp_dir / 'dir_three')

    tmp_file_one = tmp_dir / 'file_one'
    tmp_file_one.touch()

    tmp_file_two = tmp_dir / 'file_two'
    tmp_file

# Generated at 2022-06-17 19:33:10.721897
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gids
    from flutils.osutils import get_os_group_users

# Generated at 2022-06-17 19:33:22.649266
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    import os

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == os.path.expanduser('~/tmp/test_path')
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.exists() is True

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == os.path.expanduser('~/tmp/test_path')
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.exists() is True

    path = directory_present('~/tmp/test_path/test_path2')

# Generated at 2022-06-17 19:33:35.831306
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmpdir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()


# Generated at 2022-06-17 19:33:48.674421
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path
    from flutils.pathutils import PosixPath
    from flutils.pathutils import WindowsPath

    # Test the find_paths function with a glob pattern
    # that matches a single file.
    pattern = '~/tmp/flutils.tests.osutils.txt'
    paths = list(find_paths(pattern))
    assert len(paths) == 1
    assert isinstance(paths[0], PosixPath)
    assert paths[0].as_posix() == normalize_path(pattern).as_posix()

    # Test the find_paths function with a glob pattern
    # that matches multiple files.
   

# Generated at 2022-06-17 19:33:59.774744
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_temp_file
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_temp_file
    from flutils.osutils import get_os_temp_dir

# Generated at 2022-06-17 19:34:00.630537
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:34:11.733740
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Test with a glob pattern that does not exist.
    assert list(find_paths('~/tmp/does_not_exist')) == []

    # Test with a glob pattern that does exist.
    assert list(find_paths('~/tmp/*')) == [
        normalize_path('~/tmp/file_one'),
        normalize_path('~/tmp/dir_one')
    ]

    # Test with a glob pattern that does exist.

# Generated at 2022-06-17 19:34:37.961323
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.txt')

    try:
        chmod(tmp_file, 0o660)
        assert os.stat(tmp_file).st_mode == 33152
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:34:44.861882
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:34:52.655831
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    tmp_link = os.path.join(tmp_dir, 'tmp_link')
    tmp_dir_link = os.path.join(tmp_dir, 'tmp_dir_link')
    tmp_dir_link_file = os.path.join(tmp_dir_link, 'tmp_dir_link_file')
    tmp_dir_link_dir = os.path.join(tmp_dir_link, 'tmp_dir_link_dir')

# Generated at 2022-06-17 19:35:02.975990
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    user = get_os_user()
    group = get_os_group()
    uid = get_os_uid(user.pw_name)
    gid = get_os_gid(group.gr_name)

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir('foo')
        tmpdir.joinpath('foo', 'bar').mkdir()

# Generated at 2022-06-17 19:35:14.484306
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    # Test that the function returns a pathlib.Path object.
    assert isinstance(directory_present('~/tmp/test_path'), Path)

    # Test that the function returns a pathlib.PosixPath object
    # on a Posix system.
    if os.name == 'posix':
        assert isinstance(directory_present('~/tmp/test_path'), PosixPath)

    # Test that the function returns a pathlib.WindowsPath object
    # on a Windows system.

# Generated at 2022-06-17 19:35:15.040694
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:35:19.559032
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:35:25.896318
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import chmod, mkdir, makedirs, remove
    from os.path import join

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir_sub = tmpdir / 'sub'
        tmpdir_sub.mkdir()
        tmpdir_sub_sub = tmpdir_sub / 'sub'
        tmpdir_sub_sub.mkdir()
        tmpdir_sub_sub_file = tmpdir_sub_sub / 'file.txt'
        tmpdir_sub_sub_file.touch()
        tmpdir_sub_file = tmpdir_sub / 'file.txt'
        tmpdir_sub_file.touch()
        tmpdir_file = tmpdir / 'file.txt'
        tmpdir_file

# Generated at 2022-06-17 19:35:36.344663
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(getpass.getuser()).pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_uid).pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_uid).pw_uid == get_os_user().pw_uid
    assert get_os_user(get_os_user().pw_gid).pw_gid == get_os_user().pw_gid
    assert get_os_user(get_os_user().pw_gid).pw_name == getpass.getuser()
    assert get

# Generated at 2022-06-17 19:35:41.649485
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user('root'), pwd.struct_passwd)
    assert isinstance(get_os_user(0), pwd.struct_passwd)
    with pytest.raises(OSError):
        get_os_user('does_not_exist')
    with pytest.raises(OSError):
        get_os_user(9999999999)



# Generated at 2022-06-17 19:36:04.213742
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_fifo
    from flutils.pathutils import temp_symlink

    with temp_directory() as tmp_dir:
        assert exists_as(tmp_dir) == 'directory'

        with temp_file(dir=tmp_dir) as tmp_file:
            assert exists_as(tmp_file) == 'file'

        with temp_fifo(dir=tmp_dir) as tmp_fifo:
            assert exists_as(tmp_fifo) == 'FIFO'


# Generated at 2022-06-17 19:36:15.342435
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_tmp_file
    from flutils.osutils import get_os_tmp_path
    from flutils.osutils import get_os_tmp_path_dir
    from flutils.osutils import get_os_tmp_path_file
    from flutils.osutils import get_os_tmp_path_dir_file

# Generated at 2022-06-17 19:36:24.038155
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_gids
    from flutils.osutils import get_os_group_users

# Generated at 2022-06-17 19:36:31.051277
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'
    assert exists_as('/dev/tty5') == 'char device'
    assert exists_as

# Generated at 2022-06-17 19:36:36.399098
# Unit test for function exists_as
def test_exists_as():
    # Test for a directory
    assert exists_as(Path().cwd()) == 'directory'

    # Test for a file
    assert exists_as(__file__) == 'file'

    # Test for a broken symlink
    assert exists_as(Path('/tmp/flutils.tests.pathutils.broken_symlink')) == ''

    # Test for a non-existent path
    assert exists_as(Path('/tmp/flutils.tests.pathutils.does_not_exist')) == ''



# Generated at 2022-06-17 19:36:44.924673
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_tmpfile
    from flutils.osutils import get_os_tempfile


# Generated at 2022-06-17 19:36:57.650063
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_tempdir
    from flutils.osutils import get_os_tmpdir
    from flutils.osutils import get_os_tmp_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_temp_path
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:37:05.464729
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import find_paths
    from flutils.pathutils import chmod
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH_OR_STR
    from flutils.pathutils import _PATH_OR_STR_OR_NONE
    from flutils.pathutils import _PATH_OR_STR_OR_NONE_

# Generated at 2022-06-17 19:37:17.129468
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('/tmp/flutils.tests.osutils.txt')
    chown('/tmp/flutils.tests.osutils.txt', user='-1')
    chown('/tmp/flutils.tests.osutils.txt', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='-1', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='root', group='root')
    chown('/tmp/flutils.tests.osutils.txt', user='root', group='-1')
    chown('/tmp/flutils.tests.osutils.txt', user='-1', group='root')

# Generated at 2022-06-17 19:37:28.038040
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_

# Generated at 2022-06-17 19:37:53.300646
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:38:04.782957
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_group, get_os_user
    from flutils.osutils import get_os_group_id, get_os_user_id
    from flutils.osutils import get_os_group_name, get_os_user_name
    from flutils.osutils import get_os_groups, get_os_users
    from flutils.osutils import get_os_groups_id, get_os_users_id
    from flutils.osutils import get_os_groups_name, get_os_users_name
    from flutils.osutils import get_os_groups_members, get_os_users_groups
    from flutils.osutils import get_os_users_members, get_os_users_name

# Generated at 2022-06-17 19:38:14.461689
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_present
    from flutils.pathutils import temp_dir
    from flutils.pathutils import temp_file

    with temp_dir() as tmp_dir:
        with temp_file(dir=tmp_dir) as tmp_file:
            path_absent(tmp_file)
            assert path_exists(tmp_file) is False

        with temp_dir(dir=tmp_dir) as tmp_dir_one:
            with temp_file(dir=tmp_dir_one) as tmp_file_one:
                path_absent(tmp_dir_one)
                assert path_exists(tmp_dir_one) is False

# Generated at 2022-06-17 19:38:19.429517
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists