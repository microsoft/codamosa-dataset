

# Generated at 2022-06-17 19:29:00.047701
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

# Generated at 2022-06-17 19:29:05.465837
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmp_dir, 'test_path')
        os.mkdir(path)
        path_absent(path)
        assert os.path.exists(path) is False
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:29:15.630115
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_symlink

    with temp_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        assert exists_as(tmp_dir) == 'directory'

        with temp_file(tmp_dir) as tmp_file:
            tmp_file = normalize_path(tmp_file)
            assert exists_as(tmp_file) == 'file'


# Generated at 2022-06-17 19:29:26.355279
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:29:36.650749
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile

    from flutils.pathutils import chmod

    # Create a temp directory
    tmp_dir = tempfile.TemporaryDirectory()

    # Create a file in the temp directory
    tmp_file = os.path.join(tmp_dir.name, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a sub directory in the temp directory
    tmp_sub_dir = os.path.join(tmp_dir.name, 'sub')
    os.mkdir(tmp_sub_dir)

    # Create a file in the sub directory
    tmp_sub_file = os.path.join(tmp_sub_dir, 'flutils.tests.osutils.txt')

# Generated at 2022-06-17 19:29:40.372285
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:29:50.346467
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    file_path = os.path.join(tmpdir, 'file_one')
    with open(file_path, 'w') as f:
        f.write('This is a test file.')

    # Create a directory
    dir_path = os.path.join(tmpdir, 'dir_one')
    os.mkdir(dir_path)

    # Create a symlink to a file
    file_link = os.path.join(tmpdir, 'file_link')
    os.symlink(file_path, file_link)

    # Create a symlink to a directory

# Generated at 2022-06-17 19:29:56.237305
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]



# Generated at 2022-06-17 19:30:04.142948
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:30:13.501683
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_ONE,
        TEST_DIR_TWO,
        TEST_FILE_ONE,
        TEST_FILE_TWO,
        TEST_FILE_THREE,
        TEST_FILE_FOUR,
        TEST_FILE_FIVE,
        TEST_FILE_SIX,
        TEST_FILE_SEVEN,
        TEST_FILE_EIGHT,
        TEST_FILE_NINE,
        TEST_FILE_TEN,
    )

    # Test with a glob pattern that matches multiple files.

# Generated at 2022-06-17 19:30:40.942250
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import chmod
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as

# Generated at 2022-06-17 19:30:50.867691
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch
    from flutils.osutils import mkdir
    import os
    import pathlib
    import tempfile

    # Create a temporary directory to work in.
    temp_dir = get_temp_dir()
    temp_dir = normalize_path(temp_dir)

    # Create a temporary directory to work in.
    temp_dir = get_temp_dir()
    temp_dir = normalize_path(temp_dir)

    # Create a temporary directory to work in.
    temp_dir = get_temp_dir()


# Generated at 2022-06-17 19:31:01.993091
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    import tempfile
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()

        paths = list(find_paths(tmpdir.joinpath('*')))
        assert len(paths) == 2
        assert paths[0].name == 'file_one'
        assert paths[1].name == 'dir_one'

        paths = list(find_paths(tmpdir.joinpath('*/*')))
       

# Generated at 2022-06-17 19:31:13.309506
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_ONE,
        TEST_DIR_TWO,
        TEST_FILE_ONE,
        TEST_FILE_TWO,
        TEST_FILE_THREE,
        TEST_FILE_FOUR,
        TEST_FILE_FIVE,
        TEST_FILE_SIX,
    )

    # Test a glob pattern that matches multiple paths.

# Generated at 2022-06-17 19:31:25.353513
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:31:36.124157
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one', 'file_two').touch()

        paths = list(find_paths(tmpdir.joinpath('*')))
        assert len(paths) == 2
        assert normalize_path(paths[0]) == normalize_path(
            tmpdir.joinpath('file_one')
        )

# Generated at 2022-06-17 19:31:44.809674
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys

    from flutils.pathutils import path_absent

    # Create a temporary directory to work in.
    tmp_dir = tempfile.mkdtemp()
    tmp_dir = os.path.normpath(tmp_dir)
    tmp_dir = os.path.normcase(tmp_dir)

    # Create a temporary file.
    tmp_file = os.path.join(tmp_dir, 'tmp_file')
    with open(tmp_file, 'w') as f:
        f.write('This is a test file.')

    # Create a temporary directory.
    tmp_dir_one = os.path.join(tmp_dir, 'tmp_dir_one')

# Generated at 2022-06-17 19:31:58.143636
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_temp
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:32:06.461416
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent

    # Create a directory to test chmod
    directory_present('~/tmp/flutils.tests.osutils.chmod')

    # Create a file to test chmod
    Path('~/tmp/flutils.tests.osutils.chmod/test.txt').touch()

    # Test chmod
    chmod('~/tmp/flutils.tests.osutils.chmod/test.txt', 0o660)

    # Test chmod with a glob pattern
    chmod('~/tmp/flutils.tests.osutils.chmod/**', 0o660, 0o770)

    # Test chmod with a glob pattern and include_parent

# Generated at 2022-06-17 19:32:16.894679
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        temp_file(temp_dir / 'file_one')
        temp_file(temp_dir / 'file_two')
        temp_directory(temp_dir / 'dir_one')
        temp_directory(temp_dir / 'dir_two')


# Generated at 2022-06-17 19:32:40.868719
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.pathutils import TEST_DIR
    from flutils.tests.pathutils import TEST_DIR_FILE_ONE
    from flutils.tests.pathutils import TEST_DIR_DIR_ONE
    from flutils.tests.pathutils import TEST_DIR_DIR_TWO
    from flutils.tests.pathutils import TEST_DIR_DIR_TWO_FILE_ONE
    from flutils.tests.pathutils import TEST_DIR_DIR_TWO_FILE_TWO
    from flutils.tests.pathutils import TEST_DIR_DIR_TWO_FILE_THREE
    from flutils.tests.pathutils import TEST_DIR_DIR_THREE
    from flutils.tests.pathutils import TEST_DIR_DIR_THREE_FILE_ONE

# Generated at 2022-06-17 19:32:49.032873
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_present
    from flutils.pathutils import path_present_as_dir
    from flutils.pathutils import path_present_as_file
    from flutils.pathutils import path_present_as_symlink

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:32:57.963406
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    import shutil
    from flutils.pathutils import chmod

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:33:09.035697
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    from flutils.pathutils import chown
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import directory_present

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:33:15.954413
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_two').mkdir()
        tmp_dir.joinpath('dir_two/file_two').touch()
        tmp_dir.joinpath('dir_two/file_three').touch()


# Generated at 2022-06-17 19:33:16.596886
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:33:25.404638
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:33:37.523782
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temporary_directory
    from pathlib import Path

    with temporary_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        file_one = tmp_dir / 'file_one'
        file_one.touch()
        dir_one = tmp_dir / 'dir_one'
        dir_one.mkdir()

        assert list(find_paths(tmp_dir / '*')) == [file_one, dir_one]
        assert list(find_paths(tmp_dir / 'file_one')) == [file_one]

# Generated at 2022-06-17 19:33:49.550094
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Create a temporary directory to test in.
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir()

        # Create a file and a directory in the temporary directory.
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()

        # Test find_paths()
        pattern = normalize_path(tmpdir / '*')
        paths = list(find_paths(pattern))
        assert len(paths) == 2
        assert file_

# Generated at 2022-06-17 19:33:56.748458
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_SYMLINK,
    )

    # Test that a directory is created.
    test_dir = directory_present(TEST_DIR)
    assert test_dir.is_dir() is True

    # Test that a directory is NOT created if it already exists.
    test_dir = directory_present(TEST_DIR)
    assert test_dir.is_dir() is True

    # Test that a directory is NOT created if it already exists as a file.
    with open(TEST_FILE, 'w') as f:
        f.write('foo')

    with pytest.raises(FileExistsError):
        directory_present(TEST_FILE)

    # Test that

# Generated at 2022-06-17 19:34:13.706076
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_umask
    from flutils.osutils import get_os_umask_str
    from flutils.osutils import get_os_umask_int
    from flutils.osutils import get_os_umask_oct
    from flutils.osutils import get_os_umask_bin

# Generated at 2022-06-17 19:34:23.011466
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home_dir
    from flutils.osutils import get_os_temp_dir
    from flutils.osutils import get_os_temp_dir_path
    from flutils.osutils import get_os_temp_file_path
    from flutils.osutils import get_os_temp_file
    from flutils.osutils import get

# Generated at 2022-06-17 19:34:31.606209
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    # Test with a glob pattern
    pattern = normalize_path('~/tmp/*')
    paths = list(find_paths(pattern))
    assert len(paths) == 2
    assert paths[0].as_posix() == '/home/test_user/tmp/file_one'
    assert paths[1].as_posix() == '/home/test_user/tmp/dir_one'

    # Test with a path that does not exist
    pattern = normalize_path('~/tmp/does_not_exist')
    paths = list(find_paths(pattern))
    assert len(paths) == 0

    # Test with a path that is not a glob

# Generated at 2022-06-17 19:34:39.423439
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    test_path = Path('~/tmp/flutils.tests.pathutils.test_directory_present')
    path_absent(test_path)

    # Test the default mode and user/group.
    test_path = directory_present(test_path)
    assert exists_as(test_path) == 'directory'
    assert test_path.stat().st_mode & 0o777 == 0o700
    assert test_path.stat().st_uid == get_

# Generated at 2022-06-17 19:34:49.174645
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_home

# Generated at 2022-06-17 19:35:00.409516
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_2,
        TEST_FILE_3,
        TEST_FILE_4,
    )
    from flutils.tests.osutils import (
        TEST_GROUP,
        TEST_GROUP_2,
        TEST_USER,
        TEST_USER_2,
    )
    from flutils.tests.testutils import (
        get_test_file_path,
        get_test_file_path_2,
        get_test_file_path_3,
        get_test_file_path_4,
    )

    # Test that chown works with a single file
    chown(TEST_FILE, TEST_USER, TEST_GROUP)
    assert os

# Generated at 2022-06-17 19:35:05.189989
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        assert list(find_paths(tmpdir / '*')) == [file_one, dir_one]
        assert list(find_paths(tmpdir / '*_one')) == [file_one, dir_one]

# Generated at 2022-06-17 19:35:16.594765
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_member_names
    from flutils.osutils import get_os_group_member_uids
    from flutils.osutils import get_os_group_member_us

# Generated at 2022-06-17 19:35:19.770008
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''



# Generated at 2022-06-17 19:35:32.384636
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:35:45.589759
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/foo') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/foo/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/foo/bar') == ''

# Generated at 2022-06-17 19:35:55.449990
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rm
    from flutils.osutils import rmdir
    from flutils.osutils import get_mode
    from flutils.osutils import get_mode_octal

    # Test a single file
    mkdir('~/tmp/flutils.tests.osutils')
    touch('~/tmp/flutils.tests.osutils/test_chmod.txt')
    chmod('~/tmp/flutils.tests.osutils/test_chmod.txt', 0o660)
    assert get_mode_octal(
        '~/tmp/flutils.tests.osutils/test_chmod.txt'
    ) == '0660'

# Generated at 2022-06-17 19:36:02.846642
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import directory_present
    from flutils.osutils import path_absent
    from flutils.osutils import exists_as
    from flutils.osutils import chown
    from flutils.osutils import chmod as os_chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_group_home

# Generated at 2022-06-17 19:36:14.783210
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    tmp_file_2 = os.path.join(tmp_dir, 'flutils.tests.osutils.txt.2')
    tmp_file_3 = os.path.join(tmp_dir, 'flutils.tests.osutils.txt.3')
    tmp_file_4 = os.path.join(tmp_dir, 'flutils.tests.osutils.txt.4')
    tmp_file_5 = os.path.join(tmp_dir, 'flutils.tests.osutils.txt.5')

# Generated at 2022-06-17 19:36:25.054396
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_set
    from flutils.osutils import get_os_group_members_set
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:36:35.815982
# Unit test for function chown
def test_chown():
    # Test with a glob pattern
    chown('~/tmp/**', user='foo', group='bar')
    # Test with a glob pattern and include_parent=True
    chown('~/tmp/**', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent=True
    chown('~/tmp/**', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent=True
    chown('~/tmp/**', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent=True
    chown('~/tmp/**', user='foo', group='bar', include_parent=True)
    # Test with a glob pattern and include_parent=True

# Generated at 2022-06-17 19:36:45.907818
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/shadow') == 'file'
    assert exists_as('/etc/sudoers') == 'file'
    assert exists_as('/etc/sudoers.d') == 'directory'
    assert exists_as('/etc/sudoers.d/README') == 'file'

# Generated at 2022-06-17 19:36:56.823189
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_uid == 0
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_uid).pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_name).pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_name).pw_uid == get_os_user().pw_uid



# Generated at 2022-06-17 19:37:04.704542
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_set
    from flutils.osutils import get_os_group_members_set
    from flutils.osutils import get_os_

# Generated at 2022-06-17 19:37:16.738238
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    import os
    import pwd
    import grp

    # Test that a directory is created.
    path = directory_present('~/tmp/test_directory_present')
    assert path.is_dir() is True
    assert exists_as(path) == 'directory'
    assert path.stat().st_mode == 0o700
    assert path.stat().st_uid == pwd.getpwnam(os.getlogin()).pw_uid
    assert path.stat().st_gid == grp.getgrgid(os.getgid()).gr_gid



# Generated at 2022-06-17 19:37:37.817327
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user

# Generated at 2022-06-17 19:37:41.666000
# Unit test for function chown
def test_chown():
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    chown(path)
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    path.unlink()



# Generated at 2022-06-17 19:37:53.059120
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_groups

# Generated at 2022-06-17 19:37:59.764811
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import remove

    path = '~/tmp/flutils.tests.osutils.txt'
    path = normalize_path(path)
    mkdir(path.parent)
    touch(path)
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152
    remove(path)
    remove(path.parent)



# Generated at 2022-06-17 19:38:09.761369
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user

    tmp_dir = tempfile.mkdtemp()
    try:
        tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
        with open(tmp_file, 'w') as f:
            f.write('foo')

        chown(tmp_file, user='root')
        assert get_os_user(os.stat(tmp_file).st_uid).pw_name == 'root'
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:38:16.182096
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False

