

# Generated at 2022-06-17 19:28:56.050921
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import write_file
    from flutils.osutils import rm
    from flutils.osutils import rmdir

    temp_dir = get_temp_dir()
    mkdir(temp_dir / 'test_dir')
    touch(temp_dir / 'test_dir' / 'test_file_one')
    write_file(temp_dir / 'test_dir' / 'test_file_two', 'test_file_two')
    mkdir(temp_dir / 'test_dir' / 'test_dir_one')

# Generated at 2022-06-17 19:29:06.068241
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os

# Generated at 2022-06-17 19:29:16.717868
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        file_two = tmpdir / 'file_two'
        file_two.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmpdir / 'dir_two'
        dir_two.mkdir()

        assert list(find_paths(tmpdir / 'file_*')) == [file_one, file_two]

# Generated at 2022-06-17 19:29:26.914845
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('dir_three').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('dir_three').joinpath('file_four').touch()

# Generated at 2022-06-17 19:29:36.809265
# Unit test for function chown
def test_chown():
    """Test function chown."""
    import os
    import tempfile

    from flutils.pathutils import chown

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'tmpfile.txt'
        tmpfile.touch()
        chown(tmpfile, user='-1', group='-1')
        assert os.stat(tmpfile.as_posix()).st_uid == os.getuid()
        assert os.stat(tmpfile.as_posix()).st_gid == os.getgid()
        chown(tmpfile, user=os.getuid(), group=os.getgid())
        assert os.stat(tmpfile.as_posix()).st_uid == os.getuid()

# Generated at 2022-06-17 19:29:43.819940
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:29:53.198178
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os
    import pathlib
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present

    tmp_dir = tempfile.mkdtemp()
    tmp_path = pathlib.Path(tmp_dir)
    test_path = tmp_path / 'test_path'
    path_present(test_path)
    assert os.path.exists(test_path)
    path_absent(test_path)
    assert os.path.exists(test_path) is False
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:30:02.733295
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown, get_os_user, get_os_group

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'foo.txt'
        tmpfile.touch()
        tmpfile.chmod(0o600)
        tmpfile.chown(get_os_user().pw_uid, get_os_group().gr_gid)
        assert os.stat(tmpfile.as_posix()).st_uid == get_os_user().pw_uid
        assert os.stat(tmpfile.as_posix()).st_gid == get_os_group().gr_gid
        chown(tmpfile, '-1', '-1')

# Generated at 2022-06-17 19:30:08.932396
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir('dir_one')
        tmpdir.mkdir('dir_two')
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('file_two').touch()
        assert list(find_paths(tmpdir.joinpath('*'))) == [
            tmpdir.joinpath('dir_one'),
            tmpdir.joinpath('dir_two'),
            tmpdir.joinpath('file_one'),
            tmpdir.joinpath('file_two')
        ]
        assert list(find_paths(tmpdir.joinpath('dir_*'))) == [
            tmpdir.joinpath('dir_one'),
            tmpdir.joinpath('dir_two')
        ]



# Generated at 2022-06-17 19:30:09.932885
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:30:27.785308
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import pwd
    import grp
    import pytest
    from flutils.pathutils import chown

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    file_path = os.path.join(tmpdir, 'foo.txt')
    with open(file_path, 'w') as f:
        f.write('foo')

    # Create a directory
    dir_path = os.path.join(tmpdir, 'bar')
    os.mkdir(dir_path)

    # Create a symlink
    symlink_path = os.path.join(tmpdir, 'baz')
    os.symlink(file_path, symlink_path)

# Generated at 2022-06-17 19:30:37.452388
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os
    import stat

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    chmod(tmp_file, 0o660)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o660

    chmod(tmp_dir, 0o770)
    assert stat.S_IMODE(os.stat(tmp_dir).st_mode) == 0o770

    shutil.rmtree(tmp_dir)



# Generated at 2022-06-17 19:30:44.317426
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir.mkdir()
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        dir_two = tmpdir / 'dir_two'
        dir_two.mkdir()
        file_two = dir_two / 'file_two'
        file_two.touch()

        assert list(find_paths(tmpdir)) == [tmpdir]

# Generated at 2022-06-17 19:30:58.517315
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory

    with temp_directory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        file_one = tmpdir.joinpath('file_one')
        file_one.touch()
        dir_one = tmpdir.joinpath('dir_one')
        dir_one.mkdir()
        dir_two = tmpdir.joinpath('dir_two')
        dir_two.mkdir()
        file_two = dir_two.joinpath('file_two')
        file_two.touch()
        dir_three = dir_two.joinpath('dir_three')
        dir_three.mkdir()

# Generated at 2022-06-17 19:31:10.781422
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_giduid
    from flutils.osutils import get_os_usernamegid
    from flutils.osutils import get

# Generated at 2022-06-17 19:31:23.086760
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_group_id
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_group_id_from_path
    from flutils.osutils import get_os_user_id_from_path
    from flutils.osutils import get_os_group_

# Generated at 2022-06-17 19:31:32.180785
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown
    from flutils.pathutils import chmod
    from flutils.pathutils import create_dir
    from flutils.pathutils import create_file
    from flutils.pathutils import create_symlink
    from flutils.pathutils import create_fifo
    from flutils.pathutils import create_socket
    from flutils.pathutils import create_block_device
    from flutils.pathutils import create

# Generated at 2022-06-17 19:31:40.097505
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_all
    from flutils.osutils import get_os_group_members_recursive_all_users
    from flutils.osutils import get_os_group_members_recursive_all_groups
    from flutils.osutils import get_os_group_members_recursive_all_users_groups
   

# Generated at 2022-06-17 19:31:47.072434
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:31:58.730454
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/flutils.tests.pathutils.txt')
    directory_present('~/tmp/flutils.tests.pathutils.txt', mode=0o700)
    directory_present('~/tmp/flutils.tests.pathutils.txt', mode=0o700, user='foo', group='bar')
    directory_present('~/tmp/flutils.tests.pathutils.txt', mode=0o700, user='foo')
    directory_present('~/tmp/flutils.tests.pathutils.txt', mode=0o700, group='bar')
    directory_present('~/tmp/flutils.tests.pathutils.txt', user='foo', group='bar')
    directory_present('~/tmp/flutils.tests.pathutils.txt', user='foo')

# Generated at 2022-06-17 19:32:24.789054
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:32:27.185884
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-17 19:32:38.937976
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory

    with temp_directory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        assert exists_as(tmpdir) == 'directory'
        assert exists_as(tmpdir / 'foo') == ''
        assert exists_as(tmpdir / 'foo.txt') == ''
        assert exists_as(tmpdir / 'foo.txt') == ''
        assert exists_as(tmpdir / 'foo.txt') == ''
        assert exists_as(tmpdir / 'foo.txt') == ''
        assert exists_as(tmpdir / 'foo.txt') == ''

# Generated at 2022-06-17 19:32:47.896147
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.symlink') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_symlink') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there.symlink') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there.broken_symlink') == ''



# Generated at 2022-06-17 19:32:52.788746
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''



# Generated at 2022-06-17 19:32:56.180240
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests.osutils.txt'
    chown(path)
    assert os.path.exists(path)
    assert os.path.isfile(path)
    os.remove(path)



# Generated at 2022-06-17 19:33:07.399637
# Unit test for function chmod
def test_chmod():
    import pytest
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'test.txt')
    with open(tmp_file, 'w') as f:
        f.write('test')

    # Create a temporary directory
    tmp_dir2 = os.path.join(tmp_dir, 'test2')
    os.mkdir(tmp_dir2)

    # Create a temporary file
    tmp_file2 = os.path.join(tmp_dir2, 'test.txt')
    with open(tmp_file2, 'w') as f:
        f.write('test')

    # Create a temporary directory

# Generated at 2022-06-17 19:33:14.945263
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rm

    tmp_dir = get_temp_dir()
    mkdir(tmp_dir / 'tmp')
    touch(tmp_dir / 'tmp/file_one')
    mkdir(tmp_dir / 'tmp/dir_one')
    touch(tmp_dir / 'tmp/dir_one/file_two')
    touch(tmp_dir / 'tmp/dir_one/file_three')
    mkdir(tmp_dir / 'tmp/dir_one/dir_two')

# Generated at 2022-06-17 19:33:24.546695
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readable
    from flutils.pathutils import path_is_writable

# Generated at 2022-06-17 19:33:36.900656
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_FILE,
        TEST_FILE_CONTENTS,
        TEST_FILE_MODE,
        TEST_FILE_OWNER,
        TEST_FILE_GROUP,
        TEST_FILE_PATH,
        TEST_FILE_PATH_ABS,
        TEST_FILE_PATH_REL,
        TEST_FILE_PATH_REL_ABS,
    )
    from flutils.tests.osutils import (
        TEST_USER,
        TEST_GROUP,
        TEST_USER_ID,
        TEST_GROUP_ID,
    )

    # Test with a non-existent path
    chown('/tmp/flutils.tests.osutils.txt')

    # Test with a file

# Generated at 2022-06-17 19:33:57.952576
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_members_recursive
    from flutils.osutils import get_os_group_members_recursive_all
    from flutils.osutils import get_os_group_members_recursive_all_users
    from flutils.osutils import get_os_group_members_recursive_all_groups
    from flutils.osutils import get_os_group_members_recursive_all_users_groups
    from flutils.osutils import get_os_group_members_rec

# Generated at 2022-06-17 19:34:09.761585
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:34:20.513334
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(mode=0o700)
        tmpdir.chmod(0o700)
        tmpdir.chown(os.getuid(), os.getgid())
        tmpdir.joinpath('file_one').touch()
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_one').chmod(0o700)
        tmpdir.joinpath('dir_one').chown(os.getuid(), os.getgid())
        tmpdir.joinpath('dir_one').joinpath('file_two').touch()
        tmpdir.joinpath('dir_one').joinpath('file_two').chmod(0o700)

# Generated at 2022-06-17 19:34:23.572110
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:34:35.322699
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

# Generated at 2022-06-17 19:34:35.787663
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:34:47.068563
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    import tempfile
    import shutil
    import os
    import stat

    # Create a temporary directory and change to it.
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    # Create a test directory.
    test_dir = os.path.join(temp_dir, 'test_dir')
    os.mkdir(test_dir)

    # Create a test file.
    test_file = os.path.join(temp_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Create a test symlink.
    test_symlink = os.path.join(temp_dir, 'test_symlink')
    os.symlink

# Generated at 2022-06-17 19:34:47.925989
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:34:59.833416
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as

    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()

    chmod(path, 0o660)
    assert exists_as(path, 'file') is True
    assert path.stat().st_mode == 33152

    path.unlink()
    assert path_absent(path) is True

    path = Path('~/tmp/flutils.tests.osutils.dir').expanduser()
    path.mkdir(parents=True, exist_ok=True)


# Generated at 2022-06-17 19:35:11.604057
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/ttyS0') == 'char device'
    assert exists_as('/dev/ttyUSB0') == 'char device'
    assert exists_as('/dev/ttyACM0') == 'char device'
    assert exists_as('/dev/ttyAMA0') == 'char device'
    assert exists_as('/dev/ttyS1') == 'char device'

# Generated at 2022-06-17 19:35:25.843038
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path

    # Test a simple glob pattern.
    pattern = normalize_path('~/tmp/*')
    assert list(find_paths(pattern)) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]

    # Test a glob pattern that has a glob pattern in the path.
    pattern = normalize_path('~/tmp/*/file_two')
    assert list(find_paths(pattern)) == [
        Path('/home/test_user/tmp/dir_one/file_two')
    ]

    # Test a

# Generated at 2022-06-17 19:35:36.260910
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from tempfile import TemporaryDirectory
    from os import chmod as os_chmod
    from os import stat
    from os import mkdir
    from os import makedirs
    from os import remove
    from os import symlink
    from os import utime
    from os import path as os_path
    from os import getuid
    from os import getgid
    from stat import S_IMODE

# Generated at 2022-06-17 19:35:47.203802
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import Path
    from flutils.osutils import get_temp_dir
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import write_file
    from flutils.osutils import write_file_lines
    from flutils.osutils import write_file_json
    from flutils.osutils import write_file_yaml
    from flutils.osutils import write_file_toml
    from flutils.osutils import write_file_xml
    from flutils.osutils import write_file_csv
    from flutils.osutils import write_file_pickle

# Generated at 2022-06-17 19:35:59.373174
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import touch
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        path = tmpdir / 'flutils.tests.osutils.txt'
        touch(path)

        # Test that the file exists
        assert path_present(path) is True

        # Test that the file's ownership is the current user
        assert path.stat().st_uid == get_os_user().pw_uid

# Generated at 2022-06-17 19:35:59.962970
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:36:08.445907
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_temp_dir
    from flutils.osutils import get_temp_file
    from flutils.osutils import remove_path
    from flutils.osutils import remove_paths

    tmp_dir = get_temp_dir()
    tmp_file = get_temp_file(tmp_dir)
    tmp_file_2 = get_temp_file(tmp_dir)
    tmp_file_3 = get_temp_file(tmp_dir)
    tmp_file_4 = get_temp_file(tmp_dir)
    tmp_file_5 = get_temp_file(tmp_dir)
    tmp_file_6 = get_temp_file(tmp_dir)
    tmp_file_7 = get_temp_file(tmp_dir)

# Generated at 2022-06-17 19:36:12.182489
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_uidgid
    from flutils.osutils import get_os_giduid
    from flutils.osutils import get_os_uidgroup
   

# Generated at 2022-06-17 19:36:12.951205
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:36:22.180088
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils.test_pathutils import (
        TEST_PATH,
        TEST_PATH_ABSENT,
        TEST_PATH_FILE,
        TEST_PATH_SYMLINK,
    )

    # Test that a directory is created.
    directory_present(TEST_PATH)
    assert TEST_PATH.is_dir() is True

    # Test that a directory is created with a mode.
    directory_present(TEST_PATH_ABSENT, mode=0o755)
    assert TEST_PATH_ABSENT.is_dir() is True
    assert TEST_PATH_ABSENT.stat().st_mode == 0o40755

    # Test that a directory is created with a user and group.

# Generated at 2022-06-17 19:36:28.757592
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rmdir

    tmp_dir = mkdir('~/tmp/find_paths')
    touch(tmp_dir / 'file_one')
    mkdir(tmp_dir / 'dir_one')
    assert list(find_paths(tmp_dir / '*')) == [
        Path(tmp_dir / 'file_one'),
        Path(tmp_dir / 'dir_one')
    ]
    rmdir(tmp_dir)



# Generated at 2022-06-17 19:36:45.985953
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:36:58.122925
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_uidname
    from flutils.osutils import get_os_gidname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_uid_home
    from flutils.osutils import get_os_gid_home
    from flutils.osutils import get_os_uid_home_dir

# Generated at 2022-06-17 19:37:06.633774
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:37:17.784519
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_user_name
    from flutils.osutils import get_os_group_name
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_dir
    from flutils.osutils import get_os_user_passwd
    from flutils.osutils import get_os_group_passwd


# Generated at 2022-06-17 19:37:28.464265
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.mkdir(0o700)
        tmpdir.joinpath('flutils.tests.osutils.txt').touch(0o600)
        tmpdir.joinpath('flutils.tests.osutils.txt').chmod(0o600)

        chmod(tmpdir.joinpath('flutils.tests.osutils.txt'), 0o660)
        assert tmpdir.joinpath('flutils.tests.osutils.txt').stat().st_mode == 33152

        chmod(tmpdir.joinpath('flutils.tests.osutils.txt'), 0o660, include_parent=True)

# Generated at 2022-06-17 19:37:40.187780
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent."""
    import tempfile
    import shutil
    import os
    import os.path

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    with open(tmpfile, 'w') as f:
        f.write('test')
    tmpdir2 = os.path.join(tmpdir, 'tmpdir')
    os.mkdir(tmpdir2)
    tmpfile2 = os.path.join(tmpdir2, 'tmpfile2')
    with open(tmpfile2, 'w') as f:
        f.write('test')
    path_absent(tmpdir)
    assert not os.path.exists(tmpdir)
    shutil.rmtree(tmpdir)



# Generated at 2022-06-17 19:37:47.136996
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):

        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_file = os.path.join(self.tmp_dir, 'flutils.tests.txt')
            with open(self.tmp_file, 'w') as f:
                f.write('flutils.tests.txt')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_chmod_file(self):
            chmod(self.tmp_file, 0o660)

# Generated at 2022-06-17 19:37:48.023859
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:37:55.958107
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chown

    tmp_dir = tempfile.mkdtemp()
    tmp_dir = normalize_path(tmp_dir)
    tmp_dir = tmp_dir.as_posix()
    tmp_dir = cast(str, tmp_dir)
    os.chdir(tmp_dir)

    # Test a file
    test_file = 'test_file'
    path_present(test_file)
   

# Generated at 2022-06-17 19:38:07.937769
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    import os
    import tempfile
    import shutil
    import stat

    # Setup
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    with open(tmp_file, 'w') as f:
        f.write('foo')

    # Test