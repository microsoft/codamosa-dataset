

# Generated at 2022-06-17 19:28:50.637346
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import chown
    from flutils.osutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user_id
    from flutils.osutils import get_os_group_id
    from flutils.osutils import get_os_user_home

# Generated at 2022-06-17 19:29:00.312507
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_group, get_os_user
    from flutils.tests.pathutils import (
        TEST_DIR,
        TEST_DIR_CHMOD,
        TEST_DIR_CHOWN,
        TEST_FILE_CHMOD,
        TEST_FILE_CHOWN,
    )

    # Create test files and directories
    TEST_DIR.mkdir(parents=True, exist_ok=True)
    TEST_DIR_CHMOD.mkdir(parents=True, exist_ok=True)
    TEST_DIR_CHOWN.mkdir(parents=True, exist_ok=True)
    TEST_FILE_CHMOD.touch()
    TEST_FILE_CHOWN.touch()

    # Test chmod on a file

# Generated at 2022-06-17 19:29:07.449425
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_two').mkdir()


# Generated at 2022-06-17 19:29:14.335285
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_directory
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device

    import os
    import shutil
    import tempfile

    # Create a temporary directory.
    tmp_dir = tempfile.mk

# Generated at 2022-06-17 19:29:20.960694
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        assert list(find_paths(tmp_dir.joinpath('*'))) == [
            tmp_dir.joinpath('file_one'),
            tmp_dir.joinpath('dir_one')
        ]



# Generated at 2022-06-17 19:29:31.903027
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    # Create a temporary directory to test with.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()
        tmp_dir.joinpath('file_one').touch()
        tmp_dir.joinpath('dir_one').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('file_two').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').mkdir()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('file_three').touch()
        tmp_dir.joinpath('dir_one').joinpath('dir_two').joinpath('dir_three').mkdir()

        # Test with a glob

# Generated at 2022-06-17 19:29:42.236407
# Unit test for function chown
def test_chown():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    from flutils.pathutils import chown

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    tmp_file = os.path.join(tmp_dir, 'tmp.txt')
    with open(tmp_file, 'w') as f:
        f.write('foo')

    # Create a temporary subdirectory
    tmp_subdir = os.path.join(tmp_dir, 'subdir')
    os.mkdir(tmp_subdir)

    # Create a temporary file in the subdirectory
    tmp_subfile = os.path.join(tmp_subdir, 'tmp.txt')
    with open(tmp_subfile, 'w') as f:
        f

# Generated at 2022-06-17 19:29:53.229234
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import directory_present
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import path_absent
    from flutils.pathutils import normalize_path
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent

# Generated at 2022-06-17 19:29:54.924631
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:30:03.123959
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path
    from pathlib import Path

    # Test for a single path.
    pattern = normalize_path('~/tmp/flutils.tests.osutils.txt')
    result = list(find_paths(pattern))
    assert result == [Path(pattern)]

    # Test for a glob pattern.
    pattern = normalize_path('~/tmp/*')
    result = list(find_paths(pattern))
    assert result == [Path('~/tmp/flutils.tests.osutils.txt')]

    # Test for a glob pattern that does not exist.
    pattern = normalize_path('~/tmp/foo*')

# Generated at 2022-06-17 19:30:35.414081
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import chown
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
   

# Generated at 2022-06-17 19:30:43.020345
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.tests.pathutils import TEST_DIR
    from flutils.tests.pathutils import TEST_DIR_ABS
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT_PARENT
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT_PARENT_PARENT
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT_PARENT_PARENT_PARENT
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT_PARENT_PARENT_PARENT_PARENT
    from flutils.tests.pathutils import TEST_DIR_ABS_PARENT_PARENT_PARENT_

# Generated at 2022-06-17 19:30:57.745255
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:31:09.871525
# Unit test for function chmod
def test_chmod():
    import os
    import pathlib
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_chmod(self):
            path = pathlib.Path(self.tmpdir) / 'flutils.tests.osutils.txt'
            path.touch()
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            chmod(path, 0o660)
            self.assertEqual(path.stat().st_mode & 0o777, 0o660)

            path = path

# Generated at 2022-06-17 19:31:18.661682
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import normalize_path
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_user_home
    from flutils.osutils import get_os_user_shell
    from flutils.osutils import get_os_user_uid
    from flutils.osutils import get_os_user_gid
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_user_fullname
    from flutils.osutils import get_os_user_gecos
    from flutils.osutils import get_os_user_homedir
    from flutils.osutils import get_os_user_

# Generated at 2022-06-17 19:31:19.118021
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:31:19.549119
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-17 19:31:25.159466
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link.link.link') == ''

# Generated at 2022-06-17 19:31:30.956648
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk.lnk.lnk.lnk.lnk') == ''

# Generated at 2022-06-17 19:31:41.534845
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid

    path = Path('/tmp/flutils.tests.pathutils.chown.txt')
    if path.exists():
        path.unlink()
    path.touch()

    assert path.exists() is True
    assert path.is_file() is True

    chown(path, user='root')
    assert get_os_uid(path) == 0

    chown(path, group='root')
    assert get_os_gid(path) == 0


# Generated at 2022-06-17 19:32:23.552584
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_temp_dir
    from flutils.osutils import remove_path
    from flutils.osutils import touch

    tmp_dir = get_temp_dir()
    path = tmp_dir / 'flutils.tests.osutils.txt'
    touch(path)
    chmod(path, 0o660)
    assert path.stat().st_mode == 33152
    remove_path(path)



# Generated at 2022-06-17 19:32:30.291888
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'flutils.tests.osutils.txt')
    tmp_file_mode = 0o660
    tmp_dir_mode = 0o770
    tmp_file_mode_str = oct(tmp_file_mode)[2:]
    tmp_dir_mode_str = oct(tmp_dir_mode)[2:]

    with open(tmp_file, 'w') as f:
        f.write('flutils.tests.osutils.txt')

    chmod(tmp_file, mode_file=tmp_file_mode)
    chmod(tmp_dir, mode_dir=tmp_dir_mode)

    assert os

# Generated at 2022-06-17 19:32:41.457522
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    tmpdir = tempfile.mkdtemp()
    path = os.path.join(tmpdir, 'test_path')
    path_present(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''
    path_present(path)
    assert exists_as(path) == 'directory'
    path = os.path.join(path, 'test_file')
    path_present(path, mode_file=0o600)

# Generated at 2022-06-17 19:32:52.309843
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import os.path

    from flutils.pathutils import chown

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:32:55.811408
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-17 19:33:06.766696
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_environ
    from flutils.osutils import get_os_environ_path
    from flutils.osutils import get_os_environ_pathsep

# Generated at 2022-06-17 19:33:14.546119
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_chmod(self):
            tmpdir = self.tmpdir
            file_path = os.path.join(tmpdir, 'flutils.tests.osutils.txt')
            with open(file_path, 'w') as f:
                f.write('test')

            chmod(file_path, 0o660)
            self.assertEqual(oct(os.stat(file_path).st_mode)[-3:], '660')



# Generated at 2022-06-17 19:33:23.078551
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import mkdir
    from flutils.osutils import touch
    from flutils.osutils import rm

    mkdir('~/tmp/flutils.tests.osutils.dir')
    touch('~/tmp/flutils.tests.osutils.dir/flutils.tests.osutils.txt')
    chmod('~/tmp/flutils.tests.osutils.dir/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/flutils.tests.osutils.dir', 0o770)
    rm('~/tmp/flutils.tests.osutils.dir')



# Generated at 2022-06-17 19:33:28.154573
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')



# Generated at 2022-06-17 19:33:39.201598
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_name
    from flutils.osutils import get_os_version
    from flutils.osutils import get_os_release
    from flutils.osutils import get_os_system
    from flutils.osutils import get_os_machine
    from flutils.osutils import get_os_processor
    from flutils.osutils import get_os_platform

# Generated at 2022-06-17 19:33:55.410713
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.bak/') == ''



# Generated at 2022-06-17 19:34:03.251414
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'

# Generated at 2022-06-17 19:34:06.691298
# Unit test for function path_absent
def test_path_absent():
    path = Path('~/tmp/test_path')
    path.mkdir(parents=True, exist_ok=True)
    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-17 19:34:14.485120
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    import shutil
    import os

    # Create a temporary directory.
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:34:23.580513
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link2') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link3') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link4') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link5') == 'file'

# Generated at 2022-06-17 19:34:35.329231
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import chmod
    from flutils.pathutils import find_paths
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import chmod
    from flutils.pathutils import find_paths

# Generated at 2022-06-17 19:34:42.722497
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link.broken.link') == ''



# Generated at 2022-06-17 19:34:51.653063
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import temp_directory
    from flutils.pathutils import temp_file
    from flutils.pathutils import temp_symlink

    with temp_directory() as tmp_dir:
        tmp_dir = normalize_path(tmp_dir)
        assert exists_as(tmp_dir) == 'directory'

        with temp_file(dir=tmp_dir) as tmp_file:
            tmp_file = normalize_path(tmp_file)
            assert exists_as(tmp_file) == 'file'


# Generated at 2022-06-17 19:35:02.508834
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from flutils.pathutils import _PATH_OR_STR_OR_INT
    from flutils.pathutils import _PATH_OR_STR
    from flutils.pathutils import _PATH_OR_STR_OR_NONE
   

# Generated at 2022-06-17 19:35:14.037228
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_user_groups
    from flutils.osutils import get_os_group_members
    from flutils.osutils import get_os_group_users
    from flutils.osutils import get_os_group_memberships
    from flutils.osutils import get_os_user_memberships
    from flutils.osutils import get_os_user_groups

# Generated at 2022-06-17 19:35:33.543050
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readable
    from flutils.pathutils import path_is_writable

# Generated at 2022-06-17 19:35:46.741070
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from tempfile import gettempdir
    import os

    # Test 1
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_directory_present'
        assert path_absent(path) is True
        assert exists_as(path) == ''

# Generated at 2022-06-17 19:35:59.122037
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 19:36:06.742536
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    # Test that the function raises an error if the path
    # contains a glob pattern.
    try:
        directory_present('~/tmp/*')
    except ValueError:
        pass
    else:
        raise AssertionError(
            'The function directory_present did NOT raise a ValueError '
            'when given a path with a glob pattern.'
        )

    # Test that the function raises an error if the path
    # is not an absolute path.
    try:
        directory_present('tmp')
    except ValueError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-17 19:36:16.622606
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    path = directory_present('~/tmp/flutils.tests.pathutils.test_directory_present')
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.is_file() is False
    assert path.is_symlink() is False
    assert path.is_socket() is False
    assert path.is_fifo() is False
    assert path.is_block_device() is False

# Generated at 2022-06-17 19:36:17.106098
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-17 19:36:25.987721
# Unit test for function chmod
def test_chmod():
    # Test chmod() with a file
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'tmpfile'
        tmpfile.touch()
        chmod(tmpfile, 0o660)
        assert tmpfile.stat().st_mode & 0o777 == 0o660

    # Test chmod() with a directory
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        chmod(tmpdir, mode_dir=0o770)
        assert tmpdir.stat().st_mode & 0o777 == 0o770

    # Test chmod() with a glob pattern
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'tmpfile'

# Generated at 2022-06-17 19:36:29.052253
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent

    path = directory_present('~/tmp/flutils.tests.pathutils.test_directory_present')
    assert path.exists() is True
    assert path.is_dir() is True

    path_absent(path)



# Generated at 2022-06-17 19:36:37.865916
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_file = os.path.join(self.tmp_dir, 'flutils.tests.txt')
            with open(self.tmp_file, 'w') as f:
                f.write('flutils.tests')

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_chmod_file(self):
            chmod(self.tmp_file, 0o660)

# Generated at 2022-06-17 19:36:46.834511
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
   

# Generated at 2022-06-17 19:37:00.053873
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.link') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.broken_link') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt.not_there') == ''



# Generated at 2022-06-17 19:37:08.320476
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists
    from flutils.pathutils import path_is_dir
    from flutils.pathutils import path_is_file
    from flutils.pathutils import path_is_symlink
    from flutils.pathutils import path_is_socket
    from flutils.pathutils import path_is_fifo
    from flutils.pathutils import path_is_block_device
    from flutils.pathutils import path_is_char_device
    from flutils.pathutils import path_is_mount
    from flutils.pathutils import path_is_readable
    from flutils.pathutils import path_is_writable

# Generated at 2022-06-17 19:37:18.528760
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.tmpfile = os.path.join(self.tmpdir, 'flutils.tests.osutils.txt')
            with open(self.tmpfile, 'w') as fp:
                fp.write('test')

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_chmod_file(self):
            chmod(self.tmpfile, 0o660)
            self.assertEqual(oct(os.stat(self.tmpfile).st_mode)[-3:], '660')

# Generated at 2022-06-17 19:37:28.933560
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile

    from flutils.pathutils import chmod

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'flutils.tests.osutils.txt'
        tmpfile.touch()

        assert os.stat(tmpfile).st_mode & stat.S_IRWXU == 0o700
        assert os.stat(tmpfile).st_mode & stat.S_IRWXG == 0o000
        assert os.stat(tmpfile).st_mode & stat.S_IRWXO == 0o000

        chmod(tmpfile, 0o660)

        assert os.stat(tmpfile).st_mode & stat.S_IRWXU == 0o660

# Generated at 2022-06-17 19:37:40.624747
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as."""
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path

    assert exists_as(normalize_path('~/tmp')) == 'directory'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt')) == 'file'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/')) == ''
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/foo')) == ''
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt/foo/')) == ''

# Generated at 2022-06-17 19:37:41.067042
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-17 19:37:52.865555
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_username
    from flutils.osutils import get_os_groupname
    from flutils.osutils import get_os_home
    from flutils.osutils import get_os_tmp
    from flutils.osutils import get_os_cwd
    from flutils.osutils import get_os_env
    from flutils.osutils import get_os_environ
    from flutils.osutils import get_os_env_path
    from flutils.osutils import get_os_env_

# Generated at 2022-06-17 19:38:02.804828
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import chmod

    class TestChmod(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_chmod_file(self):
            path = os.path.join(self.tmp_dir, 'flutils.tests.osutils.txt')
            with open(path, 'w') as f:
                f.write('test')

            chmod(path, 0o660)
            self.assertEqual(oct(os.stat(path).st_mode)[-3:], '660')


# Generated at 2022-06-17 19:38:10.469728
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import chown
    from flutils.osutils import chmod as chmod_os
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    from flutils.osutils import get_os_mode

# Generated at 2022-06-17 19:38:22.895370
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import exists_as
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    from flutils.pathutils import normalize_path
    from flutils.pathutils import find_paths
    from flutils.pathutils import _PATH
    from flutils.pathutils import _STR_OR_INT_OR_NONE
    from os import PathLike
    from pathlib import (
        Path,
        PosixPath,
        WindowsPath,
    )