

# Generated at 2022-06-11 22:36:29.896324
# Unit test for function chmod
def test_chmod():
    assert True is not False



# Generated at 2022-06-11 22:36:39.349092
# Unit test for function chown
def test_chown():
    # Normalize the given path
    path = Path('./flutils.tests.osutils_test.txt')
    chown(path)
    # Assert the group and owner are changed
    user = pwd.getpwuid(os.stat(path.as_posix()).st_uid).pw_name
    group = grp.getgrgid(os.stat(path.as_posix()).st_gid).gr_name
    assert user == getpass.getuser()
    assert group == grp.getgrgid(os.getegid()).gr_name



# Generated at 2022-06-11 22:36:51.344486
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    from flutils.tests.helpers import (
        assert_file_exists,
        mktempfile,
        mktempdir,
    )

    tmp_file = mktempfile(mode=0o600, text='foo')
    tmp_dir = mktempdir(mode=0o700)

    chmod(tmp_file, 0o660)
    assert stat.S_IMODE(os.stat(tmp_file).st_mode) == 0o660

    chmod(tmp_dir, mode_dir=0o770)
    assert stat.S_IMODE(os.stat(tmp_dir).st_mode) == 0o770

    tmp_sub_dir = mktempdir(dirname=tmp_dir, mode=0o640)


# Generated at 2022-06-11 22:36:54.531672
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    from flutils.pathutils import exists_as
    assert exists_as(Path('~/')) == 'directory'
    assert exists_as(Path('~/.vimrc')) == 'file'
    assert exists_as(Path('~/.bash_profile')) == ''



# Generated at 2022-06-11 22:37:07.400367
# Unit test for function path_absent
def test_path_absent():
    # create / test directory
    dir_path = normalize_path('path_absent_test_dir')
    if dir_path.is_dir():
        path_absent(dir_path)
    dir_path.mkdir()
    assert dir_path.is_dir()
    # create / test file
    file_path = normalize_path('path_absent_test_dir/file_path')
    if file_path.is_file():
        path_absent(file_path)
    file_path.touch()
    assert file_path.is_file()
    # get path in current dir
    cwd_path = normalize_path('path_absent_test_dir/.')
    # create symlink to file

# Generated at 2022-06-11 22:37:15.785269
# Unit test for function chmod
def test_chmod():
    """Test function ``chmod``."""
    from pathlib import Path
    from random import randint
    from shutil import rmtree
    from tempfile import gettempdir

    from flutils.pathutils import chmod

    tmpdir = Path(gettempdir()) / f'flutils.pathutils.chmod{randint(0, sys.maxsize)}'


# Generated at 2022-06-11 22:37:27.659976
# Unit test for function path_absent
def test_path_absent():
    import sys
    import tempfile
    import shutil
    import mock

    def os_walk_mock(path, topdown=False):
        files = {'foo': 644, 'baz': 644}
        subdir = {'bar': 755}
        yield path, subdir.keys(), files.keys()
        for k, v in subdir.items():
            yield os.path.join(path, k), [], []
        for k, v in files.items():
            yield os.path.join(path, k), [], []

    if sys.version_info < (3, 6):
        from typing import Deque

        paths: Deque = deque()
        for root, dirs, files in os_walk_mock('foo'):
            paths.append((root, dirs, files))
       

# Generated at 2022-06-11 22:37:36.160226
# Unit test for function chown
def test_chown():
    from flutils.pathutils import (chown, get_os_user, get_os_group)
    import time
    import tempfile

    # no user or group
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / Path('sub') / Path('sub2')
        path.mkdir(mode=0o755, parents=True, exist_ok=True)
        chown(path)
        assert path.stat().st_uid == get_os_user().pw_uid
        assert path.stat().st_gid == get_os_group().gr_gid

    # no user or group for non-existent path
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / Path('sub') / Path('sub2')
       

# Generated at 2022-06-11 22:37:44.032629
# Unit test for function chmod
def test_chmod():
    path = Path(__file__).parent
    path = path / 'flutils.tests.osutils.txt'
    mode_file = 0o666
    mode_dir = 0o777
    chmod(path, mode_file, mode_dir)
    assert path.stat().st_mode & stat.S_IRWXU == stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH | stat.S_IWOTH

# Generated at 2022-06-11 22:37:51.294532
# Unit test for function find_paths
def test_find_paths():
    pattern = '~/tmp/*'
    search = '*'
    anchor = expanduser('~/tmp')
    expected = [
        PosixPath(posixpath.join(anchor, 'file_one')),
        PosixPath(posixpath.join(anchor, 'dir_one'))
    ]
    result = list(find_paths(pattern))
    assert result == expected
# End unit test



# Generated at 2022-06-11 22:38:13.041661
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:38:25.246227
# Unit test for function chown
def test_chown():  # type: () -> None
    import shutil
    from time import time
    from .filesystem import temporary_path

    tmp_dir = temporary_path(prefix='flutils.test_chown.')
    apath = Path(tmp_dir / 'test_chown.txt')
    apath.touch()

    apath.chown(0, 0)
    assert apath.stat().st_uid == 0
    assert apath.stat().st_gid == 0

    chown(apath, '', '')
    assert apath.stat().st_uid == 0
    assert apath.stat().st_gid == 0

    chown(apath, getpass.getuser(), grp.getgrgid(os.getgid()).gr_name)

# Generated at 2022-06-11 22:38:32.387936
# Unit test for function chmod
def test_chmod():
    path = Path('/tmp/flutils.tests.pathutils.txt')
    path.touch()
    try:
        chmod(path, 0o660)
        flag = True
        assert path.stat().st_mode & 0o777 == 0o660
    except AssertionError:
        flag = False
    finally:
        path.unlink()
    return flag



# Generated at 2022-06-11 22:38:44.017585
# Unit test for function find_paths
def test_find_paths():
    from . import assert_contains
    from . import assert_is
    from . import assert_is_instance
    from . import assert_raises
    test_path = Path('~/tmp/flutils/tests/find_paths').expanduser()
    test_path.mkdir(parents=True, exist_ok=True)


# Generated at 2022-06-11 22:38:52.571239
# Unit test for function find_paths
def test_find_paths():
    paths_dir = str(Path().cwd().parent / 'test' / 'test_resources' / 'paths')


# Generated at 2022-06-11 22:39:01.249177
# Unit test for function find_paths
def test_find_paths():
    """Test :func:`~flutils.pathutils.find_paths`."""

    with NamedTemporaryDirectory(prefix='test_find_paths') as tmpdir:
        tmpdir = Path(tmpdir)

        file_one = Path(tmpdir / 'file_one')
        file_one.touch()

        dir_one = Path(tmpdir / 'dir_one')

        file_two = Path(dir_one / 'file_two')
        file_two.touch()

        dir_two = Path(dir_one / 'dir_two')

        file_three = Path(dir_two / 'file_three')
        file_three.touch()

        glob_paths = list(find_paths(tmpdir.as_posix() + '/*'))

# Generated at 2022-06-11 22:39:02.533836
# Unit test for function chmod
def test_chmod():
    from flutils.testutils import run_doctest
    results = run_doctest('flutils', 'pathutils.chmod')
    assert results.outcome is True



# Generated at 2022-06-11 22:39:05.494377
# Unit test for function find_paths
def test_find_paths():
    print('Test find_paths()')
    pattern = '~/tmp/*'
    results = list(find_paths(pattern))
    print(results)

# Generated at 2022-06-11 22:39:16.806517
# Unit test for function chown
def test_chown():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import pytest

    with tempfile.TemporaryDirectory(prefix='test_chown_') as tmpdir:
        conda_env = os.environ['CONDA_PREFIX']

# Generated at 2022-06-11 22:39:28.704128
# Unit test for function chmod
def test_chmod():
    import stat
    import pytest
    from flutils.pathutils import chmod
    from flutils.tests import (
        mkdir,
        mknode,
        touch,
    )
    from flutils.tests.namedtuples import (
        PathList,
    )
    from flutils.tests.pathutils import (
        remove_all,
    )

    tempdir = PathList(
        Path('~/tmp').expanduser().as_posix(),
        Path('~/tmp/flutils').expanduser().as_posix(),
        Path('~/tmp/flutils/pathutils').expanduser().as_posix(),
        Path('~/tmp/flutils/pathutils/chmod').expanduser().as_posix(),
    )


# Generated at 2022-06-11 22:39:42.645684
# Unit test for function find_paths
def test_find_paths():
    """
    """
    from os.path import expanduser
    path = Path(expanduser('~')) / 'tmp'
    if not path.exists():
        path.mkdir(0o700)
    file_one = path / 'file_one'
    file_one.touch()
    dir_one = path / 'dir_one'
    dir_one.mkdir(0o700)
    paths = list(find_paths('~/tmp/*'))
    assert paths[0] == file_one
    assert paths[1] == dir_one



# Generated at 2022-06-11 22:39:56.051993
# Unit test for function chmod
def test_chmod():
    from os.path import expanduser

    from . import get_optional_arg
    from . import get_required_arg
    from .osutils import chmod

    path = get_required_arg('--path')
    path = Path(expanduser(path))

    mode_file = get_optional_arg('--mode-file', int, 0o660)
    mode_dir = get_optional_arg('--mode-dir', int, 0o770)

    if mode_file is None:
        mode_file = 0o600

    if mode_dir is None:
        mode_dir = 0o700

    chmod(path, mode_file, mode_dir)



# Generated at 2022-06-11 22:39:58.797378
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""

    return chmod(
        f'{str(Path(__file__.parent).absolute())}/flutils.tests.osutils.txt',
        mode_file=0o660
    )



# Generated at 2022-06-11 22:40:10.105710
# Unit test for function directory_present
def test_directory_present():
    import os.path
    abs_path = os.path.abspath(__file__)
    dirname = os.path.dirname(abs_path)
    dirname2 = os.path.join(dirname, '..', '..', '..', 'bin')
    dirname3 = os.path.join(dirname2, 'lib')
    dirname4 = os.path.join(dirname3, 'python3.*', 'site-packages', 'pathlib2')
    dirname5 = os.path.join(dirname4, 'tests')
    dirname6 = os.path.join(dirname5, 'test_pathutils.py')
    #from pathlib2 import Path
    from flutils.pathutils import directory_present
    #from flutils.pathutils import exists_as
    d = directory_

# Generated at 2022-06-11 22:40:21.680875
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from flutils.pathutils import chmod

    # Test when path is a file.
    with TemporaryDirectory() as temp_dir:
        _path = Path(temp_dir)
        _path.joinpath('flutils_test.txt').touch()
        chmod(str(_path.joinpath('flutils_test.txt')), mode_file=0o640)

    # Test when path is a directory.
    with TemporaryDirectory() as temp_dir:
        _path = Path(temp_dir)
        _path.mkdir('flutils_test')
        chmod(str(_path.joinpath('flutils_test')), mode_dir=0o750)

    # Test when path is a glob pattern of a directory.

# Generated at 2022-06-11 22:40:29.174496
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    from flutils.pathutils import get_os_user
    from pathlib import Path
    from pytest import raises

    func = get_os_user

    with raises(OSError):
        func(1)

    assert isinstance(func(), pwd.struct_passwd)

    assert isinstance(func(Path('~').expanduser().as_posix()), pwd.struct_passwd)

    assert isinstance(func(1), pwd.struct_passwd)

    return True



# Generated at 2022-06-11 22:40:30.024946
# Unit test for function get_os_user
def test_get_os_user():
    raise NotImplementedError



# Generated at 2022-06-11 22:40:30.926646
# Unit test for function chmod
def test_chmod():
    return True
# vim: set ft=python :

# Generated at 2022-06-11 22:40:43.271153
# Unit test for function path_absent

# Generated at 2022-06-11 22:40:56.011292
# Unit test for function path_absent
def test_path_absent():
    import shutil
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        f = tmp / 'file'
        f.touch()
        d = tmp / 'dir'
        d.mkdir()
        symlink_f = tmp / 'symlink_file'
        symlink_f.symlink_to(f.as_posix())
        symlink_d = tmp / 'symlink_dir'
        symlink_d.symlink_to(d.as_posix())
        path_absent(symlink_f)
        assert f.exists()
        assert d.exists()
        assert symlink_f.exists() is False
        assert symlink_d.exists()
        path_

# Generated at 2022-06-11 22:41:14.820036
# Unit test for function path_absent
def test_path_absent():
    import pathlib
    import shutil

    with tempfile.TemporaryDirectory() as tmp_dir:
        file_path = pathlib.Path(tmp_dir, 'foo.txt')
        file_path.touch()

        dir_path = pathlib.Path(tmp_dir, 'test_dir')
        dir_path.mkdir()

        sub_dir_path = pathlib.Path(dir_path, 'sub_dir')
        sub_dir_path.mkdir()

        sub_file_path = pathlib.Path(sub_dir_path, 'sub_foo.txt')
        sub_file_path.touch()

        link_path = pathlib.Path(dir_path, 'link_foo.txt')
        link_path.symlink_to(file_path)


# Generated at 2022-06-11 22:41:21.622517
# Unit test for function find_paths
def test_find_paths():
    """Run tests against the find_paths function."""
    import shutil
    import tempfile

    base_path = tempfile.mkdtemp()
    file_one = os.path.join(base_path, 'file_one')
    with open(file_one, 'w') as f:
        f.write('test')

    dir_one = os.path.join(base_path, 'dir_one')
    os.mkdir(dir_one)

    file_two = os.path.join(dir_one, 'file_two')
    with open(file_two, 'w') as f:
        f.write('test')

    dir_two = os.path.join(dir_one, 'dir_two')
    os.mkdir(dir_two)

    file_three = os.path.join

# Generated at 2022-06-11 22:41:22.173006
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:27.424475
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    path = Path('~/tmp/test_path')
    try:
        os.mkdir(path)
        assert os.path.exists(path) is True
        path_absent(path)
        assert os.path.exists(path) is False
    finally:
        if os.path.exists(path):
            shutil.rmtree(str(path))



# Generated at 2022-06-11 22:41:38.101825
# Unit test for function chmod
def test_chmod():
    expected = [
        b'~/tmp/flutils.tests.osutils.txt',
        b'~/tmp/flutils.tests.osutils.txt2',
        b'~/tmp/flutils.tests.osutils.txt3',
        b'~/tmp/flutils.tests.osutils.txt4',
        b'~/tmp/flutils.tests.osutils2.txt',
        b'~/tmp/flutils.tests.osutils2.txt2',
        b'~/tmp/flutils.tests.osutils2.txt3',
        b'~/tmp/flutils.tests.osutils2.txt4',
        b'~/tmp/flutils.tests.osutils_dir1',
        b'~/tmp/flutils.tests.osutils_dir2',
    ]

# Generated at 2022-06-11 22:41:48.335443
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from flutils.pathutils import exists_as
    from flutils.systemutils import get_username
    import os
    import tempfile

    temp_directory = normalize_path(tempfile.mkdtemp(prefix='flutils_tests'))
    test_path = temp_directory.joinpath('test_exists_as.txt')
    test_symlink_path = temp_directory.joinpath('test_exists_as.symlink')
    test_directory = directory_present(
        temp_directory.joinpath('test_exists_as.dir')
    )

    test_path.write_text('')

# Generated at 2022-06-11 22:41:55.824622
# Unit test for function exists_as
def test_exists_as():
    normal_p = Path('normal_path')
    with normal_p.open('w'):
        pass
    assert exists_as(normal_p) == 'file'
    os.unlink(normal_p)
    assert exists_as(normal_p) == ''

    normal_p = Path('normal_path')
    normal_p.mkdir()
    assert exists_as(normal_p) == 'directory'
    normal_p.rmdir()
    assert exists_as(normal_p) == ''

    normal_p = Path('normal_path')
    os.mknod(normal_p)
    assert exists_as(normal_p) == 'file'
    os.unlink(normal_p)
    assert exists_as(normal_p) == ''

    normal_p = Path('normal_path')

# Generated at 2022-06-11 22:41:56.556096
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:42:08.021327
# Unit test for function directory_present
def test_directory_present():
    from . import pathutils

    test_path = pathutils.directory_present(
        '~/tmp/test_path/foo/bar/baz/quux',
        mode=0o700,
        user='foo',
        group='bar',
    )
    assert test_path == Path('~/tmp/test_path/foo/bar/baz/quux').expanduser()

    import os
    import pwd
    import grp
    assert test_path.stat().st_mode == 0o40700
    assert test_path.stat().st_uid == pwd.getpwnam(os.getlogin()).pw_uid

# Generated at 2022-06-11 22:42:12.548270
# Unit test for function directory_present
def test_directory_present():
    directory_present('/tmp/test_parent/test_dir')
    test_dir = Path('/tmp/test_parent/test_dir')
    assert test_dir.exists() is True
    assert test_dir.is_dir() is True
    test_dir.rmdir()
    test_dir.parent.rmdir()


# Generated at 2022-06-11 22:42:26.815552
# Unit test for function chmod
def test_chmod():
    import pytest
    from flutils.pathutils import chmod

    tmp_dir = Path('/tmp/flutils.tests/pathutils')
    tmp_file = tmp_dir.joinpath('test_chmod.txt')
    tmp_dir.mkdir(exist_ok=True)
    tmp_file.touch()

    try:
        chmod(str(tmp_dir), 0o770)
        chmod(str(tmp_file), 0o660)
        assert tmp_dir.stat().st_mode & 0o770 == 0o770
        assert tmp_file.stat().st_mode & 0o660 == 0o660

        chmod(str(tmp_file), 0o640, include_parent=True)
        assert tmp_dir.stat().st_mode & 0o640 == 0o640
    finally:
        tmp

# Generated at 2022-06-11 22:42:34.842195
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path'
    path_dir = path + '/test_dir/test_file'
    path_file = path + '/test_file'
    path_link = path + '/test_link'
    path_link_dir = path_link + '/test_dir/test_file'
    path = normalize_path(path)
    path_dir = normalize_path(path_dir)
    path_file = normalize_path(path_file)
    path_link = normalize_path(path_link)
    path_link_dir = normalize_path(path_link_dir)
    path.mkdir(parents=True, exist_ok=True)
    assert path.exists()
    path_dir.parent.mkdir(parents=True)
    assert path_dir.parent

# Generated at 2022-06-11 22:42:46.638596
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    from flutils.pathutils import directory_present
    from os import geteuid, getegid

    log_details = {'caller': 'test_exists_as'}
    path = directory_present('~/tmp/flutils.tests.osutils.dir')

    # Test the handling of a directory
    assert exists_as(path) == 'directory'

    # Test the handling of a file
    path = path / 'tmp.txt'
    path.touch()
    chmod(path, 0o600)  # nosec
    assert exists_as(path) == 'file'

    # Test the handling of a char device
    path = path.parent / 'null'
    if not path.exists():
        path = path.parent / 'tty'

# Generated at 2022-06-11 22:42:51.062291
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('~/.ssh') == 'directory'
    assert exists_as('') == ''



# Generated at 2022-06-11 22:42:58.713870
# Unit test for function chown
def test_chown():
    from tests.pathutils.constants import (
        DIR_TMP,
        FILE_1,
        FILE_2,
    )

    def _test(
            path: Path,
            user: Optional[str] = None,
            group: Optional[str] = None,
            include_parent: bool = False
    ):
        if user is None:
            user = getpass.getuser()
        if group is None:
            group = getpass.getuser()

        if DIR_TMP.exists() is False:
            DIR_TMP.mkdir()

        FILE_1.touch()
        FILE_2.touch()

        path = Path(path)
        path = path.expanduser()
        path = path.absolute()


# Generated at 2022-06-11 22:43:08.650709
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    parent = '/tmp/flutils_tests_chown'
    Path('/tmp').mkdir(0o555, True)
    for x in ('a', 'b'):
        Path(os.path.join(parent, x, x)).touch()

    chown(os.path.join(parent, '*'), user=user, group=group)
    assert os.stat(os.path.join(parent, 'a', 'a')).st_uid == os.getuid()
    assert os.stat(os.path.join(parent, 'a', 'a')).st_gid == os.getgid()

# Generated at 2022-06-11 22:43:09.931466
# Unit test for function chown
def test_chown():
    import os
    os.chown('/home/user/test2.txt', 1000, 1000)
test_chown()



# Generated at 2022-06-11 22:43:10.692942
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:43:21.652206
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    if path.exists() is False:
        path.write_text('some text')

    file_exists = exists_as(path)
    path.unlink()
    assert file_exists == 'file', \
        '\nFAILED exists_as() file test\n' \
        'Expected: %r\n' \
        'Actual: %r\n' % ('file', file_exists)

    if path.exists() is False:
        path.write_bytes(b'\x01\x02\x0a\x0b\x0c\x0d\x7f')
    file_exists = exists_as(path)
    path.unlink()
    assert file_

# Generated at 2022-06-11 22:43:24.693714
# Unit test for function find_paths
def test_find_paths():

    root = normalize_path('~')
    result = find_paths(root)

    if result is not None:
        if isinstance(result, Generator):
            assert isinstance(next(result), PosixPath)
        else:
            pass
    else:
        assert False



# Generated at 2022-06-11 22:43:46.418316
# Unit test for function chmod
def test_chmod():
    """Test function chmod."""
    from .fileutils import (
        create_file,
        create_tree,
    )
    from .osutils import (
        get_os_group,
        get_os_user,
    )

    def _test_created_permissions(
            path: Path,
            mode_file: Optional[int] = None,
            mode_dir: Optional[int] = None,
            include_parent: bool = False,
    ) -> None:
        if isinstance(path, (str, bytes)):
            path = Path(path)

        if mode_file is None:
            mode_file = 0o600

        if mode_dir is None:
            mode_dir = 0o700


# Generated at 2022-06-11 22:43:54.194904
# Unit test for function chown
def test_chown():
    with patch('flutils.pathutils.os.chown') as mock_chown:
        chown('foo')
        mock_chown.assert_called_once_with(
            'foo', getpass.getuser(), os.getegid()
        )
        chown('foo', group='bar')
        mock_chown.assert_called_with(
            'foo', getpass.getuser(), grp.getgrnam('bar').gr_gid
        )
        mock_chown.reset_mock()
        chown('foo', user='bar')
        mock_chown.assert_called_with(
            'foo', pwd.getpwnam('bar').pw_uid, os.getegid()
        )
        mock_chown.reset_mock()

# Generated at 2022-06-11 22:44:01.670066
# Unit test for function exists_as
def test_exists_as():
    exists_as('~/tmp') == ''
    exists_as('/dev/null') == 'file'
    exists_as('/var') == 'directory'
    exists_as('/dev/sda1') == 'block device'
    exists_as('/dev/tty0') == 'char device'
    exists_as('/var/run/dovecot/login/default') == 'socket'
    exists_as('~/tmp/fifo') == ''
    mkfifo('~/tmp/fifo')
    exists_as('~/tmp/fifo') == 'FIFO'



# Generated at 2022-06-11 22:44:12.724550
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as().
    """

    class Mock:  # pylint: disable=too-few-public-methods
        """Mock object to be used for testing path.
        """
        def __init__(self, is_dir, is_file, is_block_device, is_char_device,
                     is_fifo, is_socket):
            self.is_dir = is_dir
            self.is_file = is_file
            self.is_block_device = is_block_device
            self.is_char_device = is_char_device
            self.is_fifo = is_fifo
            self.is_socket = is_socket

    def test(mock_obj, expected):
        """Test function exists_as() with a mock object and an expected value.
        """
       

# Generated at 2022-06-11 22:44:15.539581
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:44:24.697945
# Unit test for function chown
def test_chown():
    """
    Unit test for function ``chown``.
    """
    assert isinstance(chown(__file__), type(None))
    assert isinstance(chown("/"), type(None))

    assert isinstance(chown("/"), type(None))
    assert isinstance(chown("foo", user="-1"), type(None))
    assert isinstance(chown("foo", user=None, group="-1"), type(None))
    assert isinstance(
        chown("foo", user=None, group=None, include_parent=True), type(None)
    )

    try:
        chown("foo", user="this_user_id_does_not_exist")
        assert False, "unexpected success"
    except OSError:
        assert True

# Generated at 2022-06-11 22:44:25.723858
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.home()) == 'directory'
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-11 22:44:33.346570
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from pathlib import Path
    import os
    import tempfile

    temp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(temp_dir, 'tmp.txt')
    Path(tmp_path).touch()
    path_absent(tmp_path)
    assert_false(os.path.exists(tmp_path))



# Generated at 2022-06-11 22:44:34.690795
# Unit test for function exists_as
def test_exists_as():
    # Initialize variables
    path = Path('/etc')
    file_type = 'directory'
    assert exists_as(path) == file_type


# Generated at 2022-06-11 22:44:39.429040
# Unit test for function exists_as
def test_exists_as():
    from flutils.osutils import set_umask
    import tempfile
    # Ensure that broken symlinks report back correctly.
    with tempfile.TemporaryDirectory() as tmpdir, set_umask(0o0):

        # Create a regular directory and file within it.
        tmpdir_path = Path(tmpdir)
        dir_path = tmpdir_path / 'flutils'
        dir_path.mkdir()
        file_path = dir_path / '__init__.py'
        file_path.touch()

        # Create a broken symlink to the directory.
        broken_dir_path = tmpdir_path / 'broken_dir'
        broken_dir_path.symlink_to(dir_path)

        # Create a broken symlink to the file.
        broken_file_path = tmpdir_path

# Generated at 2022-06-11 22:44:51.564829
# Unit test for function find_paths
def test_find_paths():
    pattern = Path.home().joinpath('tmp/*')
    found = find_paths(pattern)
    assert len(list(found)) == 2



# Generated at 2022-06-11 22:44:57.776659
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    chmod('test.txt')
    chmod('test.txt', mode_file=0o644)
    chmod('test.txt', mode_file=0o644, mode_dir=0o755)
    chmod('test.txt', mode_file=0o644, mode_dir=0o755, include_parent=True)

# Generated at 2022-06-11 22:45:07.633067
# Unit test for function find_paths
def test_find_paths():
        with TemporaryDirectory() as tmpdir:
            p1 = Path(tmpdir, 'file_one')
            p1.touch()
            p2 = Path(tmpdir, 'file_two')
            p2.touch()
            p3 = Path(tmpdir, 'dir_one')
            p3.mkdir()
            p4 = Path(p3, 'file_three')
            p4.touch()
            p5 = Path(tmpdir, 'file_three')
            p5.touch()
            p6 = Path(tmpdir, 'file_four')
            p6.touch()

            assert list(find_paths(Path(tmpdir, '*'))) == [p1, p2, p3, p5, p6]

# Generated at 2022-06-11 22:45:18.408231
# Unit test for function directory_present
def test_directory_present():
    # Unit test for function directory_present
    from flutils.pathutils import directory_present

    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert path.is_dir() is True

    # Create another path to test that it does not fail
    # if the path already exists.
    path = directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'
    assert path.is_dir() is True



# Generated at 2022-06-11 22:45:23.910190
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    assert directory_present('/tmp/test') == Path('/tmp/test')
    assert directory_present('/tmp/test') == Path('/tmp/test')

    assert directory_present('/tmp/test', mode=0xFFF) == Path('/tmp/test')



# Generated at 2022-06-11 22:45:35.673543
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    import pytest

    with pytest.raises(ValueError) as err:
        directory_present('')
    assert str(err.value) == (
        'The path: \'\' must be an absolute path.  A path is considered '
        'absolute if it has both a root and (if the flavour allows) a '
        'drive.'
    )
    with pytest.raises(ValueError) as err:
        directory_present('foo')
    assert str(err.value) == (
        'The path: \'foo\' must be an absolute path.  A path is considered '
        'absolute if it has both a root and (if the flavour allows) a '
        'drive.'
    )
    with pytest.raises(ValueError) as err:
        directory_present

# Generated at 2022-06-11 22:45:43.977730
# Unit test for function chmod
def test_chmod():
    from shutil import rmtree
    from tempfile import mkdtemp

    tmp = mkdtemp()
    path = Path(tmp) / 'flutils.tests.osutils.txt'
    path.touch()
    chmod(path, 0o600)
    assert oct(path.lstat().st_mode)[-3:] == '600'
    path.unlink()
    rmtree(tmp)
    return None



# Generated at 2022-06-11 22:45:52.137587
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        path = tmp / Path('tmp/file_one')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
        path = tmp / Path('tmp/file_two')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
        path = tmp / Path('tmp/dir_one')
        path.mkdir()

        assert sorted(find_paths(Path('tmp/*'))) == sorted(
            [
                Path(tmp, 'tmp/dir_one'),
                Path(tmp, 'tmp/file_one'),
                Path(tmp, 'tmp/file_two'),
            ]
        )


# Generated at 2022-06-11 22:46:02.687363
# Unit test for function directory_present
def test_directory_present():
    test_path = Path().home() / 'tmp/flutils.tests/flutils/pathutils'
    expected_path = test_path / 'directory_present'

    # Test basic functionality
    result = directory_present(str(expected_path))
    assert result == expected_path
    assert result.exists() is True
    assert result.is_dir() is True

    # Test all parents are created
    test_path_parents = test_path / 'parents_created_too' / 'and_more'
    expected_path = test_path_parents / 'directory_present'
    result = directory_present(str(expected_path))
    assert result == expected_path
    assert result.exists() is True
    assert result.is_dir() is True

    # Test standard permissions
    assert result.stat().st_mode == 0