

# Generated at 2022-06-11 22:36:32.283883
# Unit test for function chmod
def test_chmod():
    with pytest.raises(TypeError):
        chmod(path=123)

# Generated at 2022-06-11 22:36:43.691017
# Unit test for function exists_as
def test_exists_as():  # noqa: D103
    from flutils.datautils import in_travis

    path = Path().cwd() / '.git'
    result = exists_as(path)
    assert result == 'directory'

    path = Path().cwd() / '.travis.yml'
    result = exists_as(path)
    assert result == 'file'

    if in_travis() is True:
        # travis-ci does not allow binding to port 80 and
        # this test will fail.
        path = Path('/dev/ttys000')
        result = exists_as(path)
        assert result == 'char device'
    else:
        path = Path('/dev/ttys000')
        result = exists_as(path)
        assert result == 'char device'

    path = Path('/dev/disk0')

# Generated at 2022-06-11 22:36:51.728031
# Unit test for function find_paths
def test_find_paths():
    tdir = tempfile.mkdtemp()

# Generated at 2022-06-11 22:36:58.215923
# Unit test for function get_os_user
def test_get_os_user():
    assert 'foo' == get_os_user('foo').pw_name
    assert 1001 == get_os_user('foo').pw_uid
    assert '********' == get_os_user('foo').pw_passwd
    assert 2001 == get_os_user('foo').pw_gid
    assert 'Foo Bar' == get_os_user('foo').pw_gecos
    assert '/home/foo' == get_os_user('foo').pw_dir
    assert '/usr/local/bin/bash' == get_os_user('foo').pw_shell
    assert 'foo' == get_os_user(1001).pw_name
    assert 1001 == get_os_user(1001).pw_uid
    assert '********' == get_os_user(1001).pw_passwd

# Generated at 2022-06-11 22:37:08.605016
# Unit test for function chmod
def test_chmod():
    """Test function chmod from module pathutils."""
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory
    from os import chmod as os_chmod

    with TemporaryDirectory() as td:

        # test chmod with a path to a file
        test_file = Path(td, 'test_file')
        test_file.touch()
        chmod(test_file, 0o660)
        assert (os_chmod(test_file, 0o660) is None), ('Function chmod did not '
                                                      'change the mode of path '
                                                      'to {}.')

        # test chmod with a path to a directory
        test_dir = Path(td, 'test_dir')
        test_dir.mkdir()

# Generated at 2022-06-11 22:37:09.116238
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:37:17.697549
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as."""
    assert exists_as(__file__) == 'file'
    assert exists_as(__file__ + 'fitz') == ''
    assert exists_as(__file__.replace('/pytest', '/Tests')) == 'directory'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'



# Generated at 2022-06-11 22:37:28.977843
# Unit test for function chown
def test_chown():
    from tempfile import mkdtemp
    import shutil
    from os import chmod

    # Just testing some basic stuff. The `os.chown()` function is
    # already tested by the Python tests.

    # Create a test directory
    tmp_path = mkdtemp()
    # Create a file tmp_path
    tmp_file = tmp_path / 'chown_test.txt'
    tmp_file.touch()
    tmp_file.chmod(0o444)
    tmp_file_stat = tmp_file.stat()
    # Create a subdire
    tmp_subdir = tmp_path / 'chown_test_subdir'
    tmp_subdir.mkdir()
    tmp_subdir_stat = tmp_subdir.stat()

    # Make sure the tmp_subdir is not the same as tmp_

# Generated at 2022-06-11 22:37:31.850397
# Unit test for function path_absent
def test_path_absent():
    from .bltutils import TreeGenerator

    with TreeGenerator() as gen:
        pass

    assert os.path.exists(gen.root) is True
    path_absent(gen.root)
    assert os.path.exists(gen.root) is False



# Generated at 2022-06-11 22:37:36.964780
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as root_dir:
        for i in range(1,3):
            parent = os.path.join(root_dir, 'parent_%s' % i)
            os.mkdir(parent)
            for j in range(1,5):
                child = os.path.join(parent, 'child_%s' % j)
                open(child, 'w').close()
            for j in range(1,3):
                link = os.path.join(parent, 'link_%s' % j)
                os.symlink(child, link)
        path_absent(root_dir)
        assert not os.path.exists(root_dir)
    return root_dir



# Generated at 2022-06-11 22:38:02.917173
# Unit test for function chmod
def test_chmod():
    import os
    from flutils.pathutils import chmod

    fname = FuncName()
    path = normalize_path('/tmp/flutils_%s.txt' % fname)
    with open(path.as_posix(), 'w') as f:
        f.write('test')
    assert mode(path.as_posix()) == 0o600

    chmod(path.as_posix(), 0o666)
    assert mode(path.as_posix()) == 0o666

    os.remove(path.as_posix())



# Generated at 2022-06-11 22:38:06.062652
# Unit test for function path_absent
def test_path_absent():
    from .test import test_pathutils
    assert test_pathutils



# Generated at 2022-06-11 22:38:15.494981
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent.
    """
    import pathlib
    import random
    import shutil
    import string

    test_folder = os.getenv('__TEST_PATH__')
    test_path = pathlib.Path(test_folder) / 'test_path'
    test_path.mkdir(parents=True, exist_ok=True)
    test_file = test_path / 'test_file'
    test_file.write_bytes(b'TEST DATA')
    test_link = test_path / 'test_link'
    test_link.symlink_to(test_file)

    random_string = ''.join(
        [
            random.choice(string.ascii_lowercase) for _ in range(10)
        ]
    )

# Generated at 2022-06-11 22:38:19.357361
# Unit test for function exists_as
def test_exists_as():
    """Test flutils.pathutils.exists_as for basic function."""
    assert exists_as(Path(__file__)) == 'file'
    assert exists_as(Path(__file__).parent) == 'directory'



# Generated at 2022-06-11 22:38:30.143319
# Unit test for function chown
def test_chown():
    """Coverage testing for chown
    """
    # No args - exception
    try:
        chown()
        assert False, 'Expected exception'
    except TypeError:
        pass
    # All args - norm
    try:
        path = normalize_path('~/tmp/foo.txt')
        chown(path, '-1', '-1')
        chown(
            path,
            user=getpass.getuser(),
            group=grp.getgrgid(os.getgid()).gr_name
        )
    except OSError:
        assert False, 'Unexpected OSError'
    # Error on bad user

# Generated at 2022-06-11 22:38:42.374311
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from pathlib import Path

    home = str(Path.home())
    if sys.platform.startswith('win'):
        tmp = 'tests/tmp'
    else:
        tmp = 'tests/tmp'
    path = os.path.join(home, tmp)

    # A file
    path_absent(path)
    path_absent(path)

    with open(path, 'wt') as f:
        f.write('file one')

    path_absent(path)
    assert os.path.exists(path) is False

    # A directory
    path_absent(path)
    path_absent(path)

    os.mkdir(path)
    path_absent(path)

# Generated at 2022-06-11 22:38:52.168315
# Unit test for function chown
def test_chown():
    test_user = 'test_user'
    test_group = 'test_group'
    test_dir = 'test_dir'
    test_file = 'test_file'
    try:
        chown(test_dir, test_user, test_group)
        chown(test_file, test_user, test_group)
        test_file_group = os.stat(test_file).st_gid
        test_dir_group = os.stat(test_dir).st_gid
        assert test_dir_group == test_file_group
    finally:
        try:
            subprocess.call(['sudo', 'rm', '-r', test_dir+'/'], shell=False)
        except:
            pass

# Generated at 2022-06-11 22:39:01.039731
# Unit test for function find_paths
def test_find_paths():
    from shutil import rmtree
    from tempfile import mkdtemp
    from flutils.pathutils import find_paths, normalize_path

    os_pathsep = os.pathsep
    test_dir = Path(mkdtemp(suffix='_test_find_paths'))
    file_one = test_dir / 'file_one'
    file_one.touch()
    file_two = test_dir / 'file_two'
    file_two.touch()
    file_three = test_dir / 'file_three'
    file_three.touch()
    dir_one = test_dir / 'dir_one'
    dir_one.mkdir()
    dir_one_file = dir_one / 'dir_one_file'
    dir_one_file.touch()
    dir_two

# Generated at 2022-06-11 22:39:03.379691
# Unit test for function find_paths
def test_find_paths():
    assert len(list(find_paths('~/tmp/*'))) > 0



# Generated at 2022-06-11 22:39:05.903328
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as

    assert exists_as('/tmp') == 'directory'
    assert exists_as.__name__ == 'exists_as'



# Generated at 2022-06-11 22:39:30.342519
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from pathlib import Path
    from typing import Iterable

    def get_paths(pattern) -> Iterable[str]:
        """Helper function used for unit testing."""
        for p in pattern:
            yield p.as_posix()

    osutils = Path(__file__).parent
    assert get_paths(find_paths(osutils)) == [osutils.as_posix()]

    # Test if the given path is not an absolute path.
    with pytest.raises(ValueError) as err:
        find_paths('flutils')
    assert 'must be an absolute path' in str(err.value)

    # Test if the given path contains a glob pattern.
    assert not list(find_paths(osutils.parent / '*'))


# Generated at 2022-06-11 22:39:44.024852
# Unit test for function exists_as
def test_exists_as():

    path_str = '~/tmp/flutils.tests.osutils.txt'
    path = Path(path_str)
    path += '.exists_as'


# Generated at 2022-06-11 22:39:58.692929
# Unit test for function path_absent
def test_path_absent():
    # Setup test directory
    cwd = os.getcwd()
    test_dir = Path(__file__).parent / 'test_dir'
    if not test_dir.is_dir():
        test_dir.mkdir(exist_ok=True)
    os.chdir(test_dir)
    # Create test contents
    test_path = Path('test_path')
    if test_path.is_dir():
        shutil.rmtree(str(test_path))
    test_path.mkdir(exist_ok=True)
    test_file = Path(test_path / 'test_file')
    test_file.touch()
    test_link = Path(test_path / 'test_link')
    test_link.symlink_to(test_file)
    # Test directory and file exist


# Generated at 2022-06-11 22:40:10.070053
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path

    from flutils.pathutils import (
        directory_present,
        path_exists,
        path_absent,
        exists_as,
        get_os_group,
        get_os_user,
    )

    # A directory already exists, just change mode, user, and group.
    test_path = Path('/tmp/test_directory_present/')
    path_absent(test_path)
    test_path.mkdir(mode=0o755)
    assert path_exists(test_path) is True
    assert exists_as(test_path) == 'directory'

    # A directory already exists and can change mode, user, and group.

# Generated at 2022-06-11 22:40:13.199088
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')

# Generated at 2022-06-11 22:40:25.954581
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths().
    """
    # Create a test directory.
    test_dir = Path(__file__).parent / 'find_paths'
    test_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    # Create a test file.
    test_file = test_dir / 'find_me.txt'
    with test_file.open('wt', encoding='utf-8') as fp:
        fp.write('find me')

    # Ensure that the glob pattern will work and find the test file.
    # This test is needed for Windows environments.
    for _path in find_paths(test_dir / 'find_me.*'):
        break

    for _path in find_paths(test_file):
        break

    # Test the function.

# Generated at 2022-06-11 22:40:30.307475
# Unit test for function path_absent
def test_path_absent():
    tmpdir = tempfile.mkdtemp()
    path = Path(tmpdir)/'dir_one'/'dir_two'/'dir_three'
    try:
        path.mkdir(parents=True)
        path_absent(path)
        assert not path.exists()
    finally:
        path.parent.parent.parent.rmdir()



# Generated at 2022-06-11 22:40:42.361963
# Unit test for function path_absent
def test_path_absent():
    test_path = Path(tempfile.mkdtemp())
    Path(test_path / 'foo.txt').touch()
    assert exists_as(test_path / 'foo.txt') == 'file'
    path_absent(test_path / 'foo.txt')
    assert not exists_as(test_path / 'foo.txt')
    Path(test_path / 'foo.txt').touch()

    Path(test_path / 'bar').mkdir()
    assert exists_as(test_path / 'bar') == 'directory'
    path_absent(test_path / 'bar')
    assert not exists_as(test_path / 'bar')

    shutil.rmtree(test_path)
    assert not exists_as(test_path)



# Generated at 2022-06-11 22:40:55.179342
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        # Test with an empty directory
        assert list(find_paths(temp_dir)) == []

        # Test with files and directories
        file_one = temp_dir / 'file_one'
        file_one.touch()

        dir_one = temp_dir / 'dir_one'
        dir_one.mkdir()

        # Try pattern without the anchor
        assert list(find_paths('file*')) == []

        # Try pattern with the anchor
        assert list(find_paths(temp_dir/'file*')) == [file_one]

        assert list(find_paths(temp_dir/'*')) == [file_one, dir_one]



# Generated at 2022-06-11 22:41:07.252511
# Unit test for function chown
def test_chown():
    import os
    import shutil
    from tempfile import TemporaryDirectory
    from flutils.pathutils import chown

    with TemporaryDirectory() as tmp_dir:
        dir_path = Path(tmp_dir)

# Generated at 2022-06-11 22:41:32.693664
# Unit test for function chown
def test_chown():
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    import pwd
    import grp
    import os
    import tempfile
    filename = tempfile.mktemp()
    username = pwd.getpwuid(os.getuid()).pw_name
    group = grp.getgrgid(os.getgid()).gr_name
    with open(filename, 'w') as f:
        f.write('blah')
    os.chown(filename, -1, -1)
    uid = get_os_user(username).pw_uid
    gid = get_os_group(group).gr_gid
    chown(filename)
    os.stat(filename).st_uid
    os.stat(filename).st_

# Generated at 2022-06-11 22:41:44.187293
# Unit test for function chown
def test_chown():
    """Unit test for flutils.pathutils.chown."""

    import stat

    # This can't be tested with a regular user.
    if getpass.getuser() == 'root':
        path = Path('/tmp/foo/bar.txt')
        os.makedirs(path.parent.as_posix())
        with path.open('w') as f:
            f.write('foo')

        # ====  POSITIVE TESTS  ====

        # Change owner to 'root' and group to 'root'.
        this_path = path.as_posix()  # type: ignore
        chown(this_path, user='root', group='root')
        path_stat = os.stat(this_path)
        assert path_stat.st_uid == 0
        assert path_stat.st_gid

# Generated at 2022-06-11 22:41:56.932141
# Unit test for function find_paths
def test_find_paths():
    """Unit tests for function find_paths."""
    # Create two files.
    with open('tmp/file_one', 'w') as file_one:
        file_one.write('Hello World!')

    with open('tmp/file_two', 'w') as file_two:
        file_two.write('Hello World!')

    # Create two directories.
    os.makedirs('tmp/subdir_one/subsubdir_one')
    os.makedirs('tmp/subdir_two/subsubdir_two')

    expected_paths: List[Path] = []

# Generated at 2022-06-11 22:41:58.351295
# Unit test for function chown
def test_chown():
    # This is tested in test_directory_present()
    return

# Generated at 2022-06-11 22:42:06.959393
# Unit test for function find_paths
def test_find_paths():
    import pathlib

    paths = list(find_paths('/tmp/*'))
    assert isinstance(paths, list)
    assert isinstance(paths[0], pathlib.PosixPath)

    paths = list(find_paths('~/tmp/*'))
    assert isinstance(paths, list)
    assert isinstance(paths[0], pathlib.PosixPath)

    paths = list(find_paths('~/tmp/{file,dir}*'))
    assert isinstance(paths, list)
    assert isinstance(paths[0], pathlib.PosixPath)



# Generated at 2022-06-11 22:42:15.898075
# Unit test for function chown

# Generated at 2022-06-11 22:42:28.401418
# Unit test for function find_paths
def test_find_paths():
    from sys import platform
    from collections import deque
    from flutils.testingutils import _set_test_tmp_dir
    from flutils.pathutils import directory_present, find_paths

    test_tmp_dir = _set_test_tmp_dir()

    dir_paths = deque()
    for i in range(0, 5):
        dir_path = directory_present(
            '%s%sdir_%s' % (test_tmp_dir, os.sep, i)
        )
        dir_paths.append(dir_path)

    file_paths = deque()
    for i in range(0, 5):
        file_path = dir_paths[0].joinpath(
            'file_%s.txt' % i
        )

# Generated at 2022-06-11 22:42:35.032018
# Unit test for function find_paths
def test_find_paths():
    for path, expected_type in (
            ('~/tmp', List),
            ('~/tmp/does_not_exist', List),
            ('~/tmp/*', List),
            ('~/tmp/file_one', List),
            ('~/tmp/file_two', List),
            ('~/tmp/dir_one', List),
            ('~/tmp/dir_one/*', List),
            ('~/tmp/dir_two', List),
            ('~/tmp/dir_three', List),
            ('~/tmp/dir_three/*', List)
    ):
        result = [x for x in find_paths(path)]
        assert isinstance(result, expected_type)



# Generated at 2022-06-11 22:42:40.006871
# Unit test for function chown
def test_chown():
    path = normalize_path("/tmp/flutils.tests.osutils.txt")
    with path.open("x") as fh:
        fh.write("test")
    chown("/tmp/flutils.tests.osutils.txt")



# Generated at 2022-06-11 22:42:52.314478
# Unit test for function find_paths
def test_find_paths():
    from pathlib import Path

    from flutils.pathutils import find_paths
    from flutils.pathutils import tmpdir

    with tmpdir(prefix='flutils_tests.') as d:

        p = Path(d).joinpath('foo')
        p.mkdir()

        p = Path(d).joinpath('foo', 'flutils.TEST.txt')
        p.write_text('This text file was created by a unit test.')

        p = Path(d).joinpath('foo', 'bar')
        p.mkdir()

        p = Path(d).joinpath('foo', 'bar', 'baz')
        p.mkdir()

        p = Path(d).joinpath('foo', 'bar', 'baz', 'flutils.TEST.md')

# Generated at 2022-06-11 22:43:07.437331
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    path_absent('~/tmp/test_path')
    assert True



# Generated at 2022-06-11 22:43:10.559736
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-11 22:43:18.454498
# Unit test for function chmod
def test_chmod():
    from pathlib import Path

    from . import pathutils

    test_paths = [
        '~/tmp/test_chmod_tmp/glob/**',
        '~/tmp/test_chmod_tmp/glob/*',
        '~/tmp/test_chmod_tmp/file.txt',
    ]

    for test_path in test_paths:
        pathutils.chmod(test_path, 0o600)

    assert Path('~/tmp/test_chmod_tmp/glob/a_dir/a_file').stat().st_mode & 0o700 == 0o700
    assert Path('~/tmp/test_chmod_tmp/glob/a_dir').stat().st_mode & 0o700 == 0o700

# Generated at 2022-06-11 22:43:26.109474
# Unit test for function find_paths
def test_find_paths():
    f_pattern = '~/tmp/*'
    d_pattern = '~/tmp/**'
    g_pattern = '~/tmp/foobar'

    d_one = Path.home() / 'tmp' / 'dir_one/'
    f_one = Path.home() / 'tmp' / 'file_one'
    d_one.mkdir(parents=True, exist_ok=True)
    f_one.touch()

    f_results = list(find_paths(f_pattern))
    assert f_results == [f_one]
    d_results = list(find_paths(d_pattern))
    assert d_results == [d_one]
    g_results = list(find_paths(g_pattern))
    assert g_results == []

    d_one.rmdir()


# Generated at 2022-06-11 22:43:34.219743
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown, is_group_owner, is_user_owner
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    username = getpass.getuser()
    user = get_os_user(username)
    group = get_os_group(user.pw_gid)
    chown(path, user.pw_name, group.gr_name)
    assert is_user_owner(path, user=username) is True
    assert is_group_owner(path, group=group.gr_name) is True
    chown(path, '-1', '-1')
    path.unlink()



# Generated at 2022-06-11 22:43:39.216965
# Unit test for function chown
def test_chown():  # noqa: D102
    # Just check to make sure the function runs...
    chown('/tmp/foo')



# Generated at 2022-06-11 22:43:47.199366
# Unit test for function find_paths
def test_find_paths():
    import os
    import shutil

    from flutils.pathutils import find_paths
    from flutils.pathutils import normalize_path


# Generated at 2022-06-11 22:43:54.442177
# Unit test for function find_paths
def test_find_paths():
    """Test function flutils.pathutils.find_paths()."""
    from os import mkdir
    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase

    from flutils.pathutils import normalize_path
    from flutils.testutils import BaseLibTest

    class Test_find_paths(TestCase):
        """Test function flutils.pathutils.find_paths()."""

        def setUp(self):
            """Setup for each test."""
            BaseLibTest.__init__(self)
            self.test_directory = mkdtemp()
            self.test_file = join(self.test_directory, 'test_file')
            open(self.test_file, 'w').close()


# Generated at 2022-06-11 22:44:03.347298
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, f'flutils.tests.osutils.txt'), 'w') as f:
            f.write('foo')
        for d in [tmp, '~/tmp']:
            for mode_file in [0o600, 0o660, 0o666, 0o700, 0o755]:
                for mode_dir in [0o700, 0o755, 0o770, 0o777]:
                    os.chmod(
                        os.path.normpath(os.path.expanduser(os.path.join(d, 'flutils.tests.osutils.txt'))),
                        0o700
                    )

# Generated at 2022-06-11 22:44:13.245512
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    path = directory_present('~/tmp/exists_as_test')
    try:
        directory_present('~/tmp/exists_as_test/foo')
    except FileExistsError:
        pass
    else:
        assert False, (
            'Failed to raise FileExistsError when trying to create a '
            'directory with a parent that exists as a file.'
        )
    try:
        directory_present('~/tmp/exists_as_test/test_socket.sock')
    except FileExistsError:
        pass
    else:
        assert False, (
            'Failed to raise FileExistsError when trying to create a '
            'directory with a parent that exists as a socket.'
        )

# Generated at 2022-06-11 22:44:41.711920
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path(__file__)) == 'file'
    assert exists_as(Path(__file__).parent) == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda2') == 'block device'
    assert exists_as('/dev/sda3') == 'block device'
    assert exists_as('/dev/sda4') == 'block device'
    assert exists_as('/dev/sda5') == 'block device'
    assert exists_as('/dev/sda6') == 'block device'

# Generated at 2022-06-11 22:44:46.309937
# Unit test for function chown
def test_chown():
    path = '/tmp/foo/bar/baz'

    os.makedirs(path, exist_ok=True)
    chown(path, user='-1', group='-1')
    statinfo = os.stat(path)
    assert statinfo.st_uid == getpass.getuser()
    assert statinfo.st_gid == getpass.getuser()



# Generated at 2022-06-11 22:44:57.868235
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        tmpdir.mkdir(parents=True)

        tmpdir.joinpath('file_one.txt').touch()
        tmpdir.joinpath('dir_one').mkdir()

        found = list(find_paths(tmpdir.as_posix() + '/*'))
        assert len(found) == 2
        assert found[0] == normalize_path('file_one.txt')
        assert found[1] == normalize_path('dir_one')

        found = list(find_paths(tmpdir.as_posix() + '/*'))
        assert len(found) == 2
        assert found[0] == normalize_path('file_one.txt')

# Generated at 2022-06-11 22:45:07.708273
# Unit test for function chown
def test_chown():
    test_data = {
        'path': './flutils.tests.osutils.txt',
        'user': getpass.getuser(),
        'group': getpass.getuser()
    }

    f = open(test_data['path'], 'w')
    f.write('foo')
    f.close()
    stat_info = os.stat(test_data['path'])
    assert test_data['user'] == pwd.getpwuid(stat_info.st_uid).pw_name
    assert test_data['group'] == grp.getgrgid(stat_info.st_gid).gr_name

    chown(test_data['path'], include_parent=True)
    stat_info = os.stat(test_data['path'])
    assert test_data['user']

# Generated at 2022-06-11 22:45:20.536427
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        dirone = tmpdir.joinpath('dir_one')
        dirone.mkdir()
        fileone = dirone.joinpath('file_one.txt')
        fileone.touch()
        filetwo = tmpdir.joinpath('file_two.txt')
        filetwo.touch()
        assert list(find_paths('*.txt')) == []
        assert list(find_paths(tmpdir.as_posix() + '/*')) == [dirone, filetwo]
        assert list(find_paths(dirone.as_posix() + '/*')) == [fileone]
        assert list(find_paths('*' + dirone.name)) == [dirone]

# Generated at 2022-06-11 22:45:33.959416
# Unit test for function exists_as
def test_exists_as():
    """Unit tests for :obj:`~flutils.pathutils.exists_as`."""
    #@TODO Test broken sym link
    from flutils.pathutils import directory_present, exists_as
    from flutils.systemutils import get_temp_dir
    from flutils.testingutils import TestCase

    data_dir = directory_present(
        '/tmp/%s.%s'
        % (get_temp_dir('flutils.tests'), TestCase.__name__)
    )

    assert exists_as(data_dir) == 'directory'
    data_dir.joinpath('foo.txt').touch()
    assert exists_as(data_dir.joinpath('foo.txt')) == 'file'

# Generated at 2022-06-11 22:45:41.244356
# Unit test for function find_paths
def test_find_paths():
    in_dir = Path('/tmp/flutils.tests.osutils_test_find_paths')
    in_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

# Generated at 2022-06-11 22:45:44.364464
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*.txt')) == []



# Generated at 2022-06-11 22:45:52.326947
# Unit test for function exists_as
def test_exists_as():
    """Test the flutils.pathutils.exists_as function."""
    from flutils.pathutils import directory_present, exists_as
    from tempfile import NamedTemporaryFile
    import os

    test_path = directory_present('~/tmp/flutils.tests/osutils/')
    assert exists_as(test_path) == 'directory'

    with NamedTemporaryFile(dir=test_path.as_posix()) as ntf:
        assert exists_as(Path(ntf.name)) == 'file'
        # Remove the file by closing the NamedTemporaryFile handle.
        ntf.close()
        assert exists_as(Path(ntf.name)) == ''

    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'


# Generated at 2022-06-11 22:46:02.678083
# Unit test for function find_paths
def test_find_paths():
    from .osutils import chdir
    from .osutils import mkdir
    from .osutils import touch
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        chdir(tmpdir)
        mkdir('test.tmp')
        touch('test.tmp/file_one')
        mkdir('test.tmp/dir_one')
        touch('test.tmp/dir_one/file_two')

        results = list(find_paths('test.tmp/*'))
        assert len(results) == 2
        assert results[0].as_posix() == f'{tmpdir}/test.tmp/file_one'
        assert results[1].as_posix() == f'{tmpdir}/test.tmp/dir_one'
