

# Generated at 2022-06-11 22:36:28.665301
# Unit test for function exists_as
def test_exists_as():
    # Test with a directory.
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        assert 'directory' == exists_as(tmp_path)

    # Test with a broken symlink.
    # The symlink target does not exist.
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        tmp_broken_path = tmp_path / 'broken_symlink'
        tmp_broken_path.touch(exist_ok=False)
        os.unlink(tmp_broken_path.as_posix())
        os.symlink(tmp_broken_path.as_posix(), tmp_broken_path.as_posix())
        assert '' == exists_as(tmp_broken_path)

    # Test with a file.
   

# Generated at 2022-06-11 22:36:31.152360
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/')) == [
        Path('/Users/len/tmp')
    ]



# Generated at 2022-06-11 22:36:37.671223
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths()."""
    if sys.platform.startswith('win'):
        pattern = Path('C:\\Program Files\\Internet Explorer\\*.exe')
    else:
        pattern = Path('/etc/rc.*')
    assert list(find_paths(pattern)) == glob.glob(pattern.as_posix())



# Generated at 2022-06-11 22:36:48.529295
# Unit test for function chown
def test_chown():
    if Path('/').is_mount():
        path = '/tmp/test_chown'
        if not path.exists():
            path.mkdir()
        os.chown(path, os.geteuid(), os.getegid())
        chown(path, user='-1', group='-1')
        assert path.stat().st_uid == os.geteuid()
        assert path.stat().st_gid == os.getegid()
        chown(path, user=os.geteuid(), group=os.getegid())
        assert path.stat().st_uid == os.geteuid()
        assert path.stat().st_gid == os.getegid()



# Generated at 2022-06-11 22:36:56.655803
# Unit test for function chmod
def test_chmod():

    with TemporaryDirectory() as tmp_dirname:
        test_path = Path(tmp_dirname)
        test_file = test_path / 'test.file'
        test_file.touch()
        test_dir = test_path / 'dir1'
        test_dir.mkdir()
        test_dir2 = test_dir / 'dir2'
        test_dir2.mkdir()
        test_dir3 = test_dir2 / 'dir3'
        test_dir3.mkdir()
        test_dir4 = test_dir3 / 'dir4'
        test_dir4.mkdir()
        test_dir5 = test_dir4 / 'dir5'
        test_dir5.mkdir()

        chmod(test_file)

# Generated at 2022-06-11 22:37:04.353557
# Unit test for function path_absent
def test_path_absent():
    tmp = normalize_path('~/tmp')
    tmp = tmp.as_posix()
    test_path = os.path.join(tmp, 'test_path')
    test_file = os.path.join(test_path, 'test_file')
    os.mkdir(test_path)
    open(test_file, 'a').close()
    path_absent(test_path)
    assert not os.path.exists(test_path)



# Generated at 2022-06-11 22:37:15.055746
# Unit test for function directory_present
def test_directory_present():
    """Test flutils.pathutils.directory_present

    """
    from tests.test_pathutils import (
        POSIX_TEST_PATHS,
        WINDOWS_TEST_PATHS,
    )

    test_path = cast(Path, normalize_path(POSIX_TEST_PATHS['dir']))

    # Create the test path
    directory_present(test_path)
    # Verify the function works to ensure the path exists
    # as a directory.
    assert exists_as(test_path) == 'directory'

    # Test the function's ability to create a path.
    sub_path = cast(Path, normalize_path(
        os.path.join(POSIX_TEST_PATHS['dir'], 'sub_dir')
    ))

# Generated at 2022-06-11 22:37:16.282750
# Unit test for function chown
def test_chown():
    assert Falset


# Generated at 2022-06-11 22:37:16.962179
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-11 22:37:21.545656
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    test = chown('/tmp/flutils.tests.osutils', user=user, group=group)
    assert test is None



# Generated at 2022-06-11 22:37:36.040783
# Unit test for function exists_as
def test_exists_as():# pragma: no cover
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-11 22:37:45.983500
# Unit test for function chown
def test_chown():
    from flutils.testutils import temp_directory
    from .testutils import random_port

    with temp_directory() as tmp_path:
        path1 = tmp_path / 'path1'
        path1.mkdir()

        path2 = path1 / 'path2'
        path2.mkdir()

        path3 = path2 / 'path3'
        path3.mkdir()

        path4 = path3 / 'path4'
        path4.mkdir()

        path5 = path4 / 'path5'
        path5.mkdir()

        path6 = path5 / 'path6'
        path6.mkdir()

        path7 = path6 / 'path7'
        path7.mkdir()

        path8 = path7 / 'path8.txt'
        path8.touch()

        path9

# Generated at 2022-06-11 22:37:54.990260
# Unit test for function chmod
def test_chmod():
    """Simple unit test for chmod()."""

    new_pwd = getpass.getuser()
    new_grp = getpass.getuser()

    if os.getuid() == 0:
        new_pwd = 'nobody'
        new_grp = 'nogroup'

    test_file = 'flutils.tests.pathutils.txt'
    test_dir = 'flutils.tests.pathutils'

    with Path(test_file).open('w') as f:
        f.write('This is a text file.')

    os.mkdir(test_dir)


# Generated at 2022-06-11 22:38:05.994336
# Unit test for function chown
def test_chown():
    from pathlib import Path

    try:
        from flutils.pathutils import (
            chown,
            get_os_user,
            get_os_group,
        )
    except (ImportError, AttributeError):
        return

    user = get_os_user()
    group = get_os_group()
    path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    path.parent.mkdir(exist_ok=True, parents=True)
    path.touch()

# Generated at 2022-06-11 22:38:13.232728
# Unit test for function path_absent
def test_path_absent():
    test_dir = Path('~/tmp/test_path_absent').expanduser()
    if test_dir.exists():
        test_dir.unlink()

    test_dir.mkdir()

    file_foo = Path(test_dir / 'foo.txt')
    file_foo.touch()
    assert(file_foo.exists())

    path_absent(test_dir)
    assert(test_dir.exists() is False)
    assert(file_foo.exists() is False)



# Generated at 2022-06-11 22:38:25.340228
# Unit test for function chown
def test_chown():
    """
    Unit test for function chown
    """
    from os import getuid, getgid, chmod
    from faker import Faker
    from pathlib import Path
    from tempfile import TemporaryDirectory

    fake = Faker()

    with TemporaryDirectory() as td:
        td = Path(td)
        sub_dirs = [
            Path(td, fake.word()).joinpath(fake.word()) for _ in range(3)
        ]
        for sd in sub_dirs:
            sd.mkdir(mode=0o775, parents=True)

        # Create a file that is NOT a symlink
        new_file = sub_dirs[0].joinpath(fake.word())
        new_file.touch()

        # Create a symlink to a directory

# Generated at 2022-06-11 22:38:35.211878
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path'
    if not os.path.exists(path):
        os.makedirs(path)
    assert exists_as(path) == 'directory', 'The test path did not exist as a directory'
    path_absent(path)
    assert not os.path.exists(path), 'The test path was not deleted'
    path = '~/tmp/test_file'
    if not os.path.exists(path):
        open(path, 'w').close()
    assert exists_as(path) == 'file', 'The test file did not exist'
    path_absent(path)
    assert not os.path.exists(path), 'The test file was not deleted'



# Generated at 2022-06-11 22:38:45.546854
# Unit test for function path_absent
def test_path_absent():
    _init_temp_dir()
    test_path1 = os.path.join(_temp_dir.name, 'test_path1')
    test_path2 = os.path.join(_temp_dir.name, 'test_path2')
    test_link = os.path.join(_temp_dir.name, 'test_link')
    test_file = os.path.join(test_path2, 'test_file')
    os.mkdir(test_path1)
    os.mkdir(test_path2)
    os.symlink(test_path1, test_link)
    with open(test_file, 'w') as fd:
        fd.write(test_file)
    path_absent(test_path1)

# Generated at 2022-06-11 22:38:50.416491
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.commonutils import temp_path

    with temp_path('flutils.tests.osutils.txt', 'w'):
        chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
        assert os.stat('~/tmp/flutils.tests.osutils.txt').st_mode == 0o100660



# Generated at 2022-06-11 22:39:00.195885
# Unit test for function find_paths
def test_find_paths():
    """Unit testing for the function find_paths."""
    from flutils.pathutils import find_paths

    from pathlib import Path
    import tempfile

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        assert list(find_paths(td)) == []

        # Create a sub-directory.
        (td / 'sub').mkdir()

        assert list(find_paths(td)) == [td / 'sub']

        # Create a file in the sub-directory.
        (td / 'sub' / 'file_one').touch()

        # Check the root directory.
        assert list(find_paths(td)) == [td / 'sub']

        # Check the sub-directory.

# Generated at 2022-06-11 22:39:18.835175
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    from shutil import rmtree
    from flutils.osutils import (
        get_current_os_user,
    )
    from flutils.pathutils import (
        directory_present,
        exists_as,
    )

    with tempfile.TemporaryDirectory() as td:
        test_dir = cast(Path, Path(td) / 'sub/sub2/sub3')
        directory_present(test_dir)

        # Verify the created directories can be seen.
        assert test_dir.resolve().as_posix() == (
            Path.cwd().resolve() / test_dir.as_posix()
        ).as_posix()

        # Verify the directories exist as directories
        assert exists_as(test_dir) == 'directory'

        # Verify the user and group
        user

# Generated at 2022-06-11 22:39:20.078141
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/file_one')) == [Path('/home/test_user/tmp/file_one')]



# Generated at 2022-06-11 22:39:29.307728
# Unit test for function chmod
def test_chmod():
    test_dir = '/tmp/test_dir'
    test_file = test_dir + '/test_file'
    os.mkdir(test_dir)
    open(test_file,'w').close()
    os.chmod(test_dir, 0o777)
    os.chmod(test_file, 0o777)
    chmod(test_file, 0o666)
    assert os.stat(test_file).st_mode == 33188
    chmod(test_dir, 0o770, 0o750)
    assert os.stat(test_dir).st_mode == 16832
    chmod(test_dir + '/*', 0o666, 0o660)
    assert os.stat(test_file).st_mode == 33060
    os.remove(test_file)

# Generated at 2022-06-11 22:39:29.939874
# Unit test for function exists_as
def test_exists_as():
    return True



# Generated at 2022-06-11 22:39:43.779455
# Unit test for function chown
def test_chown():
    tmp_path = os.path.join(os.getcwd(), 'tmp', 'chown.tmp')
    with open(tmp_path, 'w+') as f:
        f.write('foo')

    _user = getpass.getuser()
    user_info = get_os_user(_user)

    # Test the following cases:
    # 1) the file exists and the given user exists
    # 2) the file exists and the given user does not exist
    # 3) the file exists and the given user is '-1'
    # 4) the file exists and the given group does not exist
    # 5) the file exists and the given group is '-1'
    chown(tmp_path)
    assert os.stat(tmp_path).st_uid == user_info.pw_uid


# Generated at 2022-06-11 22:39:58.442544
# Unit test for function find_paths
def test_find_paths():
    import shutil
    from pathlib import Path
    from flutils.pathutils import find_paths

    # Create a temporary directory to work in.
    temp = Path(tempfile.mkdtemp(prefix='tmp_flutils_test_'))

    # Create a directory that will be found.
    found_dir = Path(temp, 'dir_one')
    found_dir.mkdir()

    # Create a file that will be found.
    found_file = Path(temp, 'file_one')
    found_file.touch()

    # Create a file that will be excluded.
    exclude_file = Path(temp, 'file_two')
    exclude_file.touch()

    # Make sure the path is found.

# Generated at 2022-06-11 22:40:09.923725
# Unit test for function chown
def test_chown():
    import os
    import stat
    import tempfile

    import pytest

    user = getpass.getuser()
    group = grp.getgrgid(os.stat(os.getcwd()).st_gid).gr_name

    # Test chown with a non-existent path
    path = Path(tempfile.mkdtemp()) / 'foo'
    with pytest.raises(FileNotFoundError):
        chown(
            path,
            user=user,
            group=group,
        )

    # Test chown with a file
    path = Path(tempfile.mkdtemp()) / 'foo'
    with path.open('wt'):
        pass
    chown(
        path,
        user=user,
        group=group,
    )

# Generated at 2022-06-11 22:40:13.067565
# Unit test for function find_paths
def test_find_paths():
    with cwd('~/tmp'):
        mkdir('test_dir')
        touch('test_dir/test_file')
        assert len(list(find_paths('test_dir/test_*'))) == 1


# Generated at 2022-06-11 22:40:14.011841
# Unit test for function path_absent
def test_path_absent():
    assert True is False



# Generated at 2022-06-11 22:40:26.752805
# Unit test for function chown
def test_chown():
    from .pathutils import temp_directory

    orig_getpwnam, getpwnam = pwd.getpwnam, lambda name: pwd.struct_passwd(('foo', 'bar', 1000, 1000, 'foo bar', '/home/foo', '/bin/sh'))
    try:
        tmpdir = temp_directory(prefix='flutils.pathutils.chown')
        fname = tmpdir / 'foo.txt'
        fname.touch()
        assert fname.exists()
        assert fname.is_file()

        chown(fname, user='foo', group='bar')
        stat = fname.stat()
        assert stat.uid == 1000
        assert stat.gid == 1000
    finally:
        pwd.getpwnam = orig_getpwnam



# Generated at 2022-06-11 22:40:47.495791
# Unit test for function path_absent
def test_path_absent():
    """Unit test for flutils.pathutils.path_absent."""
    from flutils.pathutils import path_absent
    from pathlib import Path
    from tempfile import mkdtemp
    from uuid import uuid4

    def mkdir(
            path: _PATH,
            mode: _MODE = None,
            user: _STR_OR_INT_OR_NONE = None,
            group: _STR_OR_INT_OR_NONE = None,
    ) -> _PATH:
        if mode is None:
            mode = 0o700
        path.mkdir(mode=mode)
        chown(path, user=user, group=group)
        return path


# Generated at 2022-06-11 22:40:51.943934
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'block device'
    assert exists_as('/dev/random') == 'block device'
    assert exists_as('/dev/urandom') == 'block device'



# Generated at 2022-06-11 22:40:55.607270
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.cwd()) == 'directory'
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-11 22:41:04.391244
# Unit test for function get_os_user
def test_get_os_user():
    _get_os_user = get_os_user()
    assert _get_os_user.pw_name == getpass.getuser()
    assert (
        _get_os_user.pw_uid == get_os_user(getpass.getuser()).pw_uid ==
        get_os_user(get_os_user().pw_uid).pw_uid
    )
    assert isinstance(_get_os_user.pw_uid, int)



# Generated at 2022-06-11 22:41:11.218387
# Unit test for function chown
def test_chown():
    from .pathutils import directory_present
    import pytest
    from unittest.mock import patch


# Generated at 2022-06-11 22:41:19.995387
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os.path import expanduser
    from pathlib import PosixPath
    from pathlib import WindowsPath

    from flutils.pathutils import chmod

    tmpdir = TemporaryDirectory()

# Generated at 2022-06-11 22:41:23.258038
# Unit test for function chown
def test_chown():
    """Unit tests for flutils.pathutils.chown."""
    func = 'flutils.pathutils.chown'
    path = '~/tmp/flutils.tests.osutils.txt'
    chown(path)
    assert callable(chown)

# Generated at 2022-06-11 22:41:31.518348
# Unit test for function find_paths
def test_find_paths():
    tmp_path = Path('/tmp')
    tmp_path.mkdir(exist_ok=True)
    path = Path('/tmp/file1')
    path.touch()
    dir1 = Path('/tmp/dir1')
    dir1.mkdir()
    path = Path('/tmp/dir1/file1')
    path.touch()
    path = Path('/tmp/dir1/file2')
    path.touch()
    dir2 = Path('/tmp/dir1/dir2')
    dir2.mkdir()
    path = Path('/tmp/dir1/dir2/file1')
    path.touch()
    path = Path('/tmp/dir1/dir2/file2')
    path.touch()
    path = Path('/tmp/dir1/dir2/file3')
    path

# Generated at 2022-06-11 22:41:37.909448
# Unit test for function find_paths
def test_find_paths():
    if sys.platform.startswith('win'):
        pattern = Path('C:/temp/test_file')
        expected = Path('C:/temp/test_file')
    else:
        pattern = Path('~/temp/test_file')
        expected = Path('/home/test_user/temp/test_file')


    if pattern.exists():
        pattern.unlink()

    pattern.touch()

    res = list(find_paths(pattern))
    assert res == [expected]

    pattern.unlink()



# Generated at 2022-06-11 22:41:39.485897
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:49.693250
# Unit test for function chmod
def test_chmod():
    pass
# Docstring for test_chmod

# Generated at 2022-06-11 22:42:02.298665
# Unit test for function directory_present
def test_directory_present():
    from os import getuid
    from subprocess import run
    from tempfile import gettempdir
    from shutil import rmtree
    from pathlib import PosixPath
    from textwrap import dedent
    from ..osutils import get_os_user
    from . import exists_as

    cmd_mkdir = ['/bin/mkdir']
    cmd_chmod = ['/bin/chmod']
    cmd_chown = ['/bin/chown']
    cmd_touch = ['/bin/touch']
    cmd_ln = ['/bin/ln']
    cmd_rm = ['/bin/rm']

    # We need to do the following within a subprocess so
    # we do not modify '/tmp' within the current process
    pid = os.fork()
    if pid == 0:
        os.setpgrp()


# Generated at 2022-06-11 22:42:10.176182
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'tmp'
        directory_present(path)
        (path / 'file_one').touch()
        (path / 'dir_one').mkdir()
        assert list(find_paths(path / '*')) == [
            path / 'file_one', path / 'dir_one']



# Generated at 2022-06-11 22:42:17.571567
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    from tempfile import TemporaryDirectory
    from pwd import getpwnam

    if getpass.getuser() == 'root':
        # Have the temp directory be owned by someone other
        # than root.
        user = getpwnam('nobody')
        uid = user.pw_uid
        gid = user.pw_gid

        with TemporaryDirectory(prefix='flutils.tests.osutils',
                                dir='/tmp',
                                uid=uid,
                                gid=gid) as tmp_dir:
            tmp_dir = Path(tmp_dir)
            tmp_dir.chmod(0o700)

            tmp_file = tmp_dir / 'file.txt'
            tmp_file.touch()

# Generated at 2022-06-11 22:42:22.312159
# Unit test for function chmod
def test_chmod():
    with NamedTemporaryDirectory() as tmpdir:
        path = Path(tmpdir) / 'flutils.tests.osutils.txt'
        path.touch()
        chmod(path, 0o660)
        assert path.stat().st_mode & 0o777 == 0o660



# Generated at 2022-06-11 22:42:27.360591
# Unit test for function exists_as
def test_exists_as():
    path = Path().home() / 'tmp' / 'flutils.tests.osutils.txt'
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    assert exists_as(path) == ''
    path.write_text('Hello world!')
    assert exists_as(path) == 'file'



# Generated at 2022-06-11 22:42:31.809889
# Unit test for function get_os_user
def test_get_os_user():
    """Test ``Test_get_os_user``.

    >>> from flutils.tests.pathutils import get_os_user
    """
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-11 22:42:32.341380
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-11 22:42:35.595347
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    test_path = directory_present('~/tmp/flutils.tests.osutils')
    assert test_path.is_dir() is True
    assert test_path.exists() is True



# Generated at 2022-06-11 22:42:36.792811
# Unit test for function chmod
def test_chmod():
    assert True is True



# Generated at 2022-06-11 22:43:04.250805
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'test_paths' / 'chown'
    chown(
        path,
        user=getpass.getuser(),
        group=grp.getgrgid(os.getgid()).gr_name
    )
    assert path.exists() is True
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()

    chown(
        path,
        user=grp.getgrgid(os.getgid()).gr_name,
        group=getpass.getuser()
    )
    assert grp.getgrgid(path.stat().st_uid).gr_name == getpass.getuser()

# Generated at 2022-06-11 22:43:05.068197
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:43:12.366971
# Unit test for function path_absent
def test_path_absent():
    input_path = '/tmp/foo'
    create_dir(input_path, mode=0o777, user=getpass.getuser(),
               group=get_os_group().gr_gid)
    path_absent(input_path)
    assert not exists_as(input_path)
# End unit test


# Generated at 2022-06-11 22:43:23.585465
# Unit test for function chmod
def test_chmod():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'tmpfile.txt'
        tmpfile.write_text('test')
        assert tmpfile.stat().st_mode != 33152
        assert tmpdir.stat().st_mode != 40960
        chmod(tmpfile, 0o660)
        assert tmpfile.stat().st_mode == 33152
        chmod(str(tmpdir / 'tmpfile*'), mode_file=0o660)
        assert tmpfile.stat().st_mode == 33152
        assert tmpdir.stat().st_mode == 40960
        chmod(tmpdir / 'tmpfile*', mode_file=0o660, mode_dir=0o770, include_parent=True)

# Generated at 2022-06-11 22:43:31.747431
# Unit test for function chmod
def test_chmod():
    import tempfile
    import os

    for path_type in (
            tempfile.TemporaryDirectory,
            tempfile.TemporaryFile,
    ):
        with path_type() as temp_path:
            temp_path = Path(temp_path)
            chmod(temp_path, 0o660)

            if temp_path.is_dir():
                mode = os.stat(temp_path).st_mode
                assert mode == 0o700
            else:
                mode = os.stat(temp_path).st_mode
                assert mode == 0o660


# Generated at 2022-06-11 22:43:38.650772
# Unit test for function chown
def test_chown():
    import shutil
    import tempfile
    import uuid
    from flutils.pathutils import chown

    tmpdir = Path(tempfile.mkdtemp())

# Generated at 2022-06-11 22:43:46.286033
# Unit test for function path_absent
def test_path_absent():
    """Unit test function for function path_absent."""
    test_path = Path(__file__).parent.joinpath('test_path_absent')
    test_path.mkdir(mode=0o755, parents=True)
    test_path.joinpath('file_one').touch(mode=0o644)
    test_path.joinpath('file_two').touch(mode=0o644)
    test_path.joinpath('dir_one').mkdir(mode=0o755, parents=True)
    test_path.joinpath('dir_one').joinpath('file_three').touch(mode=0o644)
    test_path.joinpath('dir_one').joinpath('file_four').touch(mode=0o644)

# Generated at 2022-06-11 22:43:48.788622
# Unit test for function chmod
def test_chmod():
    # type: () -> None
    """Test for the chmod function."""
    # Do things for the test
    pass



# Generated at 2022-06-11 22:43:55.120543
# Unit test for function chmod
def test_chmod():
    from os import getcwd
    from os.path import join as joinp
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from flutils.pathutils import chmod
    from flutils.osutils import rm

    with TemporaryDirectory() as tmp_dir_name:
        tmp_dir = Path(tmp_dir_name)

        # Test with a single path
        path_1 = tmp_dir / 'path_1'
        path_2 = path_1 / 'path_2'

        path_1.mkdir(mode=0o777)
        path_2.mkdir(mode=0o777)

        path_1_stat = os.stat(path_1)
        path_2_stat = os.stat(path_2)

        assert (path_1_stat.st_mode & 0o777)

# Generated at 2022-06-11 22:43:58.926759
# Unit test for function directory_present
def test_directory_present():
    result = directory_present('/tmp/flutils.tests/test_directory_present')
    expected = Path('/tmp/flutils.tests/test_directory_present')
    assert result == expected
    result.rmdir()
    result.parent.rmdir()



# Generated at 2022-06-11 22:44:21.762449
# Unit test for function find_paths
def test_find_paths():
    from pathlib import PosixPath
    from typing import Generator

    try:
        list(find_paths('~/tmp/*'))
    except StopIteration:
        raise AssertionError(
            'The Generator object needs to be exhausted in order to'
            'test the find_paths() function.'
        )
    else:
        expected = [
            PosixPath('/home/test_user/tmp/file_one'),
            PosixPath('/home/test_user/tmp/dir_one')
        ]
        result = list(find_paths('~/tmp/*'))
        assert result == expected, (
            'The expected result: %r does not match the actual result: %r.'
            % (expected, result)
        )



# Generated at 2022-06-11 22:44:29.460345
# Unit test for function chown
def test_chown():
    try:
        os.mkdir('/tmp/flutils.tests')
        os.chmod('/tmp/flutils.tests', 0o711)
    except FileExistsError:
        pass

    try:
        import pwd
        import grp
        uid = cast(int, pwd.getpwnam(getpass.getuser()).pw_uid)
        gid = cast(int, grp.getgrnam(getpass.getuser()).gr_gid)
    except KeyError:
        raise RuntimeError(
            'You must be a valid user with a valid primary group '
            'to run this unit test.'
        )


# Generated at 2022-06-11 22:44:41.876751
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths().

    This test will create two paths and then search for them using a :term:
    `glob pattern`.
    """
    # Test setup
    # Create a temporary directory for testing
    with TemporaryDirectory() as test_dir:
        # Create the first test path
        test_file_one = Path(test_dir).joinpath('tmp_file_one.txt')
        test_file_one.touch()

        # Create the second test path
        test_file_two = Path(test_dir).joinpath('tmp/tmp_file_two.txt')
        test_file_two.parent.mkdir(parents=True)
        test_file_two.touch()

        # Unit test
        test_pattern = Path(test_dir).joinpath('tmp/*')

# Generated at 2022-06-11 22:44:49.190551
# Unit test for function find_paths
def test_find_paths():
    path = '~/tmp'
    with directory_present(path):
        paths = [
            path + '/file_one',
            path + '/file_two',
            path + '/dir_one',
            path + '/dir_two',
        ]
        for path in paths:
            Path(path).touch()
        dir_paths = list(find_paths('~/tmp/dir*'))
        file_paths = list(find_paths('~/tmp/file*'))
        assert dir_paths[0] == Path('~/tmp/dir_one')
        assert dir_paths[1] == Path('~/tmp/dir_two')
        assert file_paths[0] == Path('~/tmp/file_one')

# Generated at 2022-06-11 22:45:02.128762
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory('/tmp') as tmpdir:
        tmpdir = Path(tmpdir)
        test_path = tmpdir / 'test_dir'
        directory_present(test_path, mode=0o775)
        assert exists_as(test_path) == 'directory'
        assert test_path.stat().st_mode == 16826
        assert test_path.owner() == getpass.getuser()

        test2_path = tmpdir / 'test_dir2'
        test3_path = test2_path / 'test_dir3'
        directory_present(test3_path, mode=0o775)
        assert exists_as(test2_path) == 'directory'
        assert exists_as(test3_path) == 'directory'

# Generated at 2022-06-11 22:45:06.420114
# Unit test for function find_paths
def test_find_paths():
    test_root_path = Path(__file__).parent
    if test_root_path.name == 'tests':
        pattern = test_root_path.parent / 'setup.py'
    else:
        pattern = test_root_path / 'setup.py'
    assert find_paths(pattern) is not None
    assert find_paths(pattern) == Path(pattern).glob()



# Generated at 2022-06-11 22:45:19.437581
# Unit test for function chmod
def test_chmod():

    from flutils.pathutils import chmod
    import os
    import stat

    if os.path.isdir('/tmp'):
        def _check_mode(path, mode_file, mode_dir):
            assert os.stat(path)[stat.ST_MODE] == mode_dir
            assert os.stat(os.path.join(path, 'flutils.tests.osutils.txt'))[stat.ST_MODE] == mode_file

        _path = '/tmp/flutils.tests.osutils.txt'
        os.makedirs('/tmp/flutils.tests.osutils', exist_ok=True)
        with open(_path, 'w') as f:
            f.write('foo')
        _sample_mode_dir = 0o755
        _sample_mode_file = 0o644

        chmod

# Generated at 2022-06-11 22:45:32.953575
# Unit test for function chmod
def test_chmod():
    """Functional test for :obj:`chmod <flutils.pathutils.chmod>`."""

    import tempfile

    import pytest

    from flutils.pathutils import find_paths
    from flutils.pytest import raises

    # Create a temporary directory
    tmpdir = Path(tempfile.mkdtemp())

    tmpfile = Path(tmpdir, 'chmod.test.txt')
    tmpfile.touch()

    tmpdir2 = Path(tmpdir, 'chmod.test')
    tmpdir2.mkdir()

    tmpfile2 = Path(tmpdir2, 'chmod.test.txt')
    tmpfile2.touch()

    def teardown_module() -> None:
        """Remove the newly created directory."""
        tmpdir.rmdir()

    # Test that cache is updated when


# Generated at 2022-06-11 22:45:39.273979
# Unit test for function find_paths
def test_find_paths():
    directory = directory_present('~/tmp/flutils.pathutils.test_find_paths')
    os.chdir(directory.as_posix())
    file_one_path = Path('file_one')
    file_one_path.touch()
    file_two_path = Path('file_two')
    file_two_path.touch()
    dir_one_path = directory_present('dir_one')
    dir_two_path = directory_present('dir_two')
    found_paths = list(find_paths('*'))
    assert file_one_path in found_paths
    assert file_two_path in found_paths
    assert dir_one_path in found_paths
    assert dir_two_path in found_paths
    found_paths.append(directory)


# Generated at 2022-06-11 22:45:46.441972
# Unit test for function path_absent
def test_path_absent():
    # Setup
    tmpdir = Path(tempfile.mkdtemp())
    d = tmpdir / 'deleted_dir'
    f = tmpdir / 'deleted_file'
    d.mkdir()
    f.touch()

    # Test
    path_absent(d)
    path_absent(f)

    # Verify
    assert not d.exists()
    assert not f.exists()
    tmpdir.rmdir()

