

# Generated at 2022-06-11 22:36:28.420430
# Unit test for function get_os_user
def test_get_os_user():
    import pytest
    from unittest.mock import patch
    from flutils.osutils import OSUtils
    from flutils.osutils import OSUtilsError
    from flutils.osutils import is_windows

    if is_windows() is True:
        with pytest.raises(NotImplementedError):
            get_os_user()
    else:
        with patch.object(OSUtils, 'get_uid', return_value=1000):
            get_os_user()
            try:
                get_os_user('foo')
            except pwd.struct_passwd:
                pass
            else:
                raise AssertionError(
                    'OSError not raised when retrieving user object by'
                    'login name.'
                )

            with pytest.raises(OSError):
                get_os_

# Generated at 2022-06-11 22:36:30.445639
# Unit test for function chown
def test_chown():
    assert True

# Generated at 2022-06-11 22:36:42.503508
# Unit test for function directory_present
def test_directory_present():
    # Verify the path does not exist and create a directory.
    msg = (
        '``directory_present`` failed when verifying a path does not exist '
        'and creating a directory.'
    )
    path = normalize_path('./test_directory_present')
    assert exists_as(path) == '', msg
    directory_present(path)
    assert os.path.isdir(path.as_posix()), msg
    assert exists_as(path) == 'directory', msg
    path.rmdir()

    # Verify the path is a file and fail to create a directory.
    msg = (
        '``directory_present`` failed when verifying a path as a file and '
        'attempting to create a directory.'
    )
    path = normalize_path('./test_directory_present.txt')
   

# Generated at 2022-06-11 22:36:43.862640
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:36:53.925150
# Unit test for function directory_present
def test_directory_present():

    directory_present('/etc/nginx')
    directory_present('/etc/nginx/conf.d', mode=0o777)

    directory_present('./test_dir', mode=0o777)
    directory_present('/tmp/test_dir_dir/test_dir_dir', user='root', group='root')

    with pytest.raises(FileExistsError):
        directory_present('/etc/nginx/conf.d/1.txt')

    with pytest.raises(ValueError):
        directory_present('*.txt')

    # with pytest.raises(ValueError):
    #     directory_present('./test_dir/test_dir')

    with pytest.raises(ValueError):
        directory_present('~/test_dir')



# Generated at 2022-06-11 22:37:06.964610
# Unit test for function find_paths
def test_find_paths():
    with temporary_working_directory() as temp_dir:
        os.mkdir('tmp2')
        Path('tmp2/file_one').touch()
        Path('tmp2/dir_one').mkdir()
        os.mkdir('tmp2/dir_one/dir_two')
        Path('tmp2/dir_one/dir_three').mkdir()
        Path('tmp2/dir_one/dir_two/file_two').touch()

        directory = normalize_path(temp_dir)
        file_one = directory / 'tmp2/file_one'
        file_two = directory / 'tmp2/dir_one/dir_two/file_two'
        dir_one = directory / 'tmp2/dir_one'
        dir_three = directory / 'tmp2/dir_one/dir_three'


# Generated at 2022-06-11 22:37:18.774602
# Unit test for function find_paths
def test_find_paths():
    """Test find_paths."""
    from flutils.testutils import UnitTester
    from flutils import pathutils

    tester = UnitTester()

    tester.test.test_func(pathutils.find_paths)
    # Empty string
    tester.test.assert_equal(
        list(pathutils.find_paths('')),
        []
    )
    # Invalid pattern
    tester.test.assert_equal(
        list(pathutils.find_paths('[')),
        []
    )
    # No match
    tester.test.assert_equal(
        list(pathutils.find_paths('foo')),
        []
    )
    # File does not exist

# Generated at 2022-06-11 22:37:29.572332
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(None) == ''
    assert exists_as('') == ''
    assert exists_as('/') == 'directory'
    assert exists_as('/private/etc') == 'directory'
    assert exists_as('/private/etc/passwd') == 'file'
    assert exists_as('/private/etc/_local_path_aliases.py') == ''
    assert exists_as('/private/etc/test.test') == ''
    assert exists_as('/dev/console') == ''
    assert exists_as('/dev/log') == 'socket'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty1') == ''

# Generated at 2022-06-11 22:37:37.477885
# Unit test for function directory_present
def test_directory_present():

    # Test when path already exists as a directory
    test_path = Path('/tmp/directory_present_test')
    if test_path.exists():
        test_path.rmdir()
    test_path.mkdir()
    assert test_path.exists() and test_path.is_dir()
    assert directory_present(test_path).as_posix() == '/tmp/directory_present_test'
    test_path.rmdir()

    # Test when path does not exist
    assert directory_present(test_path).as_posix() == '/tmp/directory_present_test'
    test_path.rmdir()

    # Test when a parent path exists as a directory and the last path
    # does not exist.
    test_path_parent = Path('/tmp')
    assert test_path_

# Generated at 2022-06-11 22:37:38.107700
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:38:19.310578
# Unit test for function find_paths
def test_find_paths():
    from tempfile import mkdtemp

    test_dir = Path(mkdtemp())
    file_one = test_dir / 'file_one'
    file_one.touch()
    dir_one = test_dir / 'dir_one'
    dir_one.mkdir()

    assert list(find_paths(test_dir)) == [file_one, dir_one]
    assert list(find_paths('{}/*'.format(test_dir))) == [file_one, dir_one]
    assert list(find_paths('{}/*'.format(test_dir.as_posix()))) == \
        [file_one, dir_one]
    assert list(find_paths('{}/file_one'.format(test_dir))) == [file_one]



# Generated at 2022-06-11 22:38:30.105619
# Unit test for function chmod
def test_chmod():
    with pytest.raises(TypeError):
        chmod(None)
    with pytest.raises(TypeError):
        chmod(None, 1, 2)
    with pytest.raises(TypeError):
        chmod(None, mode_file=1, mode_dir=2)
    with pytest.raises(TypeError):
        chmod(None, mode_file=None, mode_dir='test')
    with pytest.raises(TypeError):
        chmod(None, mode_file='test', mode_dir=1)
    with pytest.raises(TypeError):
        chmod(None, mode_file=1, mode_dir=1, include_parent='test')

    # Actually test the chmod
    # Make sure the test file is not there

# Generated at 2022-06-11 22:38:38.693276
# Unit test for function chown
def test_chown():
    for path in [
        Path('~/tmp/flutils.tests.osutils.txt'),
        '~/tmp/flutils.tests.osutils.txt',
    ]:
        try:
            chown(path)
        except FileNotFoundError:
            pass
        else:
            os.chmod(path.as_posix(), 0o777)
            chown(path)
            chown(path, user='-1')
            chown(path, group='-1')

        if path.exists() is True:
            os.remove(path.as_posix())

    # Test glob pattern

# Generated at 2022-06-11 22:38:39.397332
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-11 22:38:49.889109
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        os.mkdir('test_dir')
        os.mkdir('test_dir_2')
        Path('test_dir/test_file').touch()
        Path('test_dir_2/test_file_2').touch()
        paths = list(find_paths('test_dir*'))
        assert len(paths) == 2
        assert 'test_dir' in paths[0].as_posix()
        assert 'test_dir_2' in paths[1].as_posix()
        assert 'test_file' in paths[0].as_posix()
        assert 'test_file_2' in paths[1].as_posix()
        assert all([p.is_dir() for p in paths]) is False


# Generated at 2022-06-11 22:38:59.773492
# Unit test for function chown
def test_chown():
    """Test function flutils.pathutils.chown."""
    root_dir = Path(__file__).parent.parent
    origin_path = root_dir / 'test.txt'
    origin_path.touch()

    target_path = root_dir / 'tmp' / 'flutils.pathutils.test_chown.txt'
    target_path.parent.mkdir(parents=True, exist_ok=True)
    origin_path.replace(target_path)
    uid = pwd.getpwnam(getpass.getuser()).pw_uid
    gid = grp.getgrgid(uid).gr_gid

    chown(target_path)
    owning = target_path.stat()
    assert uid == owning.st_uid
    assert gid == owning.st_gid



# Generated at 2022-06-11 22:39:03.843445
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user()
    except OSError:
        pass
    else:
        assert False, 'Expected OSError'



# Generated at 2022-06-11 22:39:08.715359
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmpdir:
        parent = Path(tmpdir)
        parent.chmod(0o777)
        (parent / 'file').touch()
        (parent / 'dir').mkdir()
        chmod(parent / 'file', 0o600)
        chmod(parent / 'dir', 0o700)



# Generated at 2022-06-11 22:39:15.129947
# Unit test for function chown
def test_chown():
    if os.name == 'nt':
        return

    # pylint: disable=protected-access
    if sys.version_info >= (3, 6):
        # pylint: disable=no-member
        # pylint: disable=unused-argument
        def _chown(  # noqa: F811
                path: _PATH,
                uid: int,
                gid: int
        ) -> None:
            pass

    else:
        # pylint: disable=no-member
        # pylint: disable=unused-argument
        def _chown(  # noqa: F811
                path: _PATH,
                uid: int,
                gid: Optional[str]
        ) -> None:
            pass

    _org_chown = os.chown

# Generated at 2022-06-11 22:39:27.535663
# Unit test for function chown
def test_chown():
    """Unit test for function chown
    """
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import (
        chown,
        find_paths,
    )

    from flutils.tests.pathutils import (
        TMP_BASE,
        TMP_PREFIX,
    )

    class TestChown(unittest.TestCase):

        _multiprocess_can_split_ = True

        @classmethod
        def setUpClass(cls) -> None:
            cls._tst_dir = Path(tempfile.mkdtemp(
                dir=TMP_BASE, prefix=TMP_PREFIX))
            os.chdir(cls._tst_dir)
            os.makedirs('dir1')
            os.m

# Generated at 2022-06-11 22:40:00.017072
# Unit test for function directory_present
def test_directory_present():

    path = directory_present('/tmp/flutils.tests.pathutils.test_directory_present')
    assert(path == Path('/tmp/flutils.tests.pathutils.test_directory_present'))

    path = directory_present('/tmp/flutils.tests.pathutils.test_directory_present')
    assert(path == Path('/tmp/flutils.tests.pathutils.test_directory_present'))
    assert(path.exists() is True)
    assert(path.is_dir() is True)

    with pytest.raises(ValueError):
        directory_present('/tmp/*')

    with pytest.raises(ValueError):
        directory_present('tmp')


# Generated at 2022-06-11 22:40:09.433588
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = getpass.getuser()
    tmpfile = Path(__file__).parent.joinpath('osutils.txt')
    tmpfile.touch()
    try:
        chown(tmpfile, user)
        assert tmpfile.owner() == user
        chown(tmpfile, group=group)
        assert tmpfile.group() == group
        chown(tmpfile, '-1', '-1')
        assert tmpfile.owner() == user
        assert tmpfile.group() == group
    finally:
        tmpfile.unlink()



# Generated at 2022-06-11 22:40:12.795567
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == []
    assert len(list(find_paths('/nonexistent'))) == 0
    assert len(list(find_paths('/nonexistent/*'))) == 0



# Generated at 2022-06-11 22:40:25.532040
# Unit test for function chmod
def test_chmod():
    path = Path('~/tmp/flutils.tests.osutils.txt')

    if path.is_file():
        path.unlink()

    if path.is_dir():
        shutil.rmtree(path.as_posix())

    assert chmod(path, mode_file=0o600, mode_dir=0o700)

    path.touch()

    try:
        assert path.stat().st_mode == 0o100600
    finally:
        path.unlink()

    path.mkdir()

    try:
        assert path.stat().st_mode == 0o40700
    finally:
        path.rmdir()

    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o555)


# Generated at 2022-06-11 22:40:33.539632
# Unit test for function chown
def test_chown():
    import os
    import stat
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import (
        chown
    )
    from flutils.osutils import (
        which_bin
    )


    class Tests(unittest.TestCase):
        def test_chown(self):
            """
            """
            pw_info = pwd.getpwnam(getpass.getuser())
            if pw_info.pw_uid == 0:
                # Can't run this as root
                pass
            else:
                user = getpass.getuser()
                group = grp.getgrgid(pw_info.pw_gid).gr_name
                # Test that a non-existant user does not get set

# Generated at 2022-06-11 22:40:43.808494
# Unit test for function find_paths
def test_find_paths():
    from pytest import raises
    from flutils.pathutils import find_paths
    from flutils.regexutils import get_regex_pattern
    from flutils.pathutils import get_temp_dir
    from flutils.osutils import HierarchicalTempDir

    with HierarchicalTempDir(prefix='flutils.tests.', keep_on_error=True) as tmp:
        with tmp.cd():
            tmp.create_file('foo.txt')
            tmp.create_file('bar.txt')
            tmp.create_file('baz.txt')
            pattern = get_regex_pattern('file_name', r'\.txt$')
            assert isinstance(pattern, re.Pattern)
            matches = [p.name for p in find_paths(pattern)]

# Generated at 2022-06-11 22:40:48.360362
# Unit test for function chmod
def test_chmod():
    from pathlib import Path

    test_file = '/tmp/flutils.tests.osutils.txt'
    try:
        Path(test_file).touch()
    except Exception:
        pass
    else:
        chmod(test_file, 0o660)

# Generated at 2022-06-11 22:40:55.130446
# Unit test for function directory_present
def test_directory_present():
    """Test the function directory_present."""
    from flutils.pathutils import directory_present

    path = directory_present('/tmp/pathutils_tests/directory_present/foo/bar')
    assert path.exists() is True
    path.rmdir()
    path = path.parent
    assert path.exists() is True
    path.rmdir()



# Generated at 2022-06-11 22:41:07.211925
# Unit test for function find_paths
def test_find_paths():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('dir_one').mkdir()
        tmpdir.joinpath('dir_two').mkdir()
        tmpdir.joinpath('file_one.txt').touch()
        tmpdir.joinpath('file_two.txt').touch()
        tmpdir.joinpath('file_one.py').touch()
        tmpdir.joinpath('file_two.py').touch()

        pattern = tmpdir.joinpath('*.txt').as_posix()
        assert list(find_paths(pattern)) == [
            tmpdir.joinpath('file_one.txt'),
            tmpdir.joinpath('file_two.txt')
        ]


# Generated at 2022-06-11 22:41:14.106757
# Unit test for function path_absent
def test_path_absent():
    '''Test function path_absent.'''
    # path_absent(path: str,
    # ) -> None:
    #
    path = '~/tmp/test_dir'
    mkdir_p(path)
    assert exists_as(path) == 'directory'
    path_absent(path)
    assert exists_as(path) == ''



# Generated at 2022-06-11 22:41:30.160288
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    dir_path = Path('~/tmp/test_path')
    test_path = directory_present(dir_path)
    assert test_path.as_posix() == dir_path.expanduser().as_posix()
    assert dir_path.exists() is True

# Generated at 2022-06-11 22:41:31.564641
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*'))



# Generated at 2022-06-11 22:41:43.209574
# Unit test for function find_paths
def test_find_paths():
    from .pathutils import find_paths
    from .osutils import make_temp_directory

    with make_temp_directory(prefix='flutils_') as temp_dir:
        posix_path = temp_dir / 'file_one'
        posix_path.touch()
        result = list(find_paths(temp_dir / 'file_one'))
        assert result == [posix_path]

        posix_path = temp_dir / 'dir_one'
        posix_path.mkdir()
        result = list(find_paths(temp_dir / 'dir_one'))
        assert result == [posix_path]

        result = list(find_paths(temp_dir / '*'))

# Generated at 2022-06-11 22:41:44.791577
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('~') == 'directory'

# Generated at 2022-06-11 22:41:45.427617
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:41:57.613965
# Unit test for function path_absent
def test_path_absent():
    with NamedTemporaryFile(suffix='.txt') as tf:
        tf.seek(0)
        tf_contents = tf.read().decode()
        path_absent(tf.name)
        assert not os.path.exists(tf.name)
        with TemporaryDirectory() as td:
            path_to_dir = os.path.join(td, 'dir')
            path_to_file = os.path.join(path_to_dir, 'file.txt')
            os.mkdir(path_to_dir)
            with open(path_to_file, mode='w') as fi:
                fi.write(tf_contents)
            path_absent(path_to_dir)
            assert not os.path.exists(path_to_dir)
            assert not os.path.exists

# Generated at 2022-06-11 22:41:59.192166
# Unit test for function chown
def test_chown():
    chown('foo')
test_chown()


# Generated at 2022-06-11 22:42:10.569666
# Unit test for function directory_present
def test_directory_present():
    directory = directory_present('/tmp/directory_present')
    assert isinstance(directory, PosixPath)
    assert directory.exists() is True
    assert directory.is_dir() is True
    assert directory_present('/tmp/directory_present/other', mode=0o750).exists() is True
    assert directory_present('/tmp/directory_present/other').exists() is True
    assert directory_present('/tmp/directory_present/other', mode=0o750).exists() is True
    directory_present('/tmp/directory_present/another/other/other/other')
    assert directory_present('/tmp/directory_present/another/other/other/other').exists() is True
    assert directory_present('/tmp/directory_present/another/other/other/another').exists() is True
   

# Generated at 2022-06-11 22:42:23.883905
# Unit test for function find_paths
def test_find_paths():
    test_dir = Path().home() / 'tmp' / 'find_paths'
    test_dir.mkdir(parents=True, exist_ok=True)
    test_dir = test_dir.resolve()

    test_dir_one = test_dir / 'dir_one'
    test_dir_one.mkdir(parents=True, exist_ok=True)

    test_dir_two = test_dir / 'dir_two'
    test_dir_two.mkdir(parents=True, exist_ok=True)

    (test_dir_one / 'file_one_one').touch()
    (test_dir_one / 'file_one_two').touch()
    (test_dir_two / 'file_two_one').touch()
    (test_dir_two / 'file_two_two').touch

# Generated at 2022-06-11 22:42:25.492783
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o660) is None



# Generated at 2022-06-11 22:42:37.077881
# Unit test for function find_paths
def test_find_paths():
    pattern = ''
    assert list(find_paths(pattern)) is None
    # Need Windows version of this.
    pattern = '~/tmp/*'
    assert 'test_user' in list(find_paths(pattern))



# Generated at 2022-06-11 22:42:41.785833
# Unit test for function path_absent
def test_path_absent():
    test_path = os.path.expanduser('~/tmp/test_path')
    if os.path.exists(test_path):
        path_absent(test_path)
    assert not os.path.exists(test_path)


# Generated at 2022-06-11 22:42:53.744686
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as, directory_present
    import tempfile

    tempdir = tempfile.TemporaryDirectory()

    path = Path(tempdir.name) / 'file'
    path.touch()

    assert exists_as(path) == 'file'
    assert exists_as('/tmp/blah') == ''

    # Test exists_as when the given path is a broken symlink.
    path.unlink()
    path.symlink_to('/tmp/blah')
    assert exists_as(path) == ''
    path.unlink()

    assert exists_as(directory_present(Path(tempdir.name) / 'blah')) == 'directory'

    # Test exists_as when the given path is a symlink to a directory.

# Generated at 2022-06-11 22:43:05.351366
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import time

    try:
        import pathlib
    except ImportError:
        import pathlib2 as pathlib

    from flutils.pathutils import (
        chmod,
        path_absent,
    )

    from .pathutils import (
        directory_present,
        find_paths,
        normalize_path,
    )

    # Normal use case
    test_file = os.fspath(pathlib.Path('~/tmp/flutils.tests.osutils.txt'))
    directory_present('~/tmp')
    path_absent(test_file)
    with open(test_file, 'w') as fp:
        fp.write('test for chmod')


# Generated at 2022-06-11 22:43:10.728042
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')



# Generated at 2022-06-11 22:43:21.714659
# Unit test for function chown
def test_chown():
    from os import (
        setuid,
        getuid
    )
    from pathlib import Path
    from pwd import getpwuid
    
    test_path = Path('~/tmp/tests/owner')
    test_path.expanduser().mkdir(parents=True)
    if os.getuid() == 0:
        # turn off root privs
        setuid(getpwuid(getuid()).pw_uid)

    test_path.touch()
    # create a test file
    old_stats = test_path.stat()
    
    # change ownership to the current user
    chown(
        test_path,
        user=getpwuid(getuid()).pw_name,
        group=getpwuid(getuid()).pw_gid
    )
    
   

# Generated at 2022-06-11 22:43:29.386779
# Unit test for function directory_present
def test_directory_present():
    """Check function directory_present."""
    from flutils.tests.helpers import (
        iterate_test_templates,
        TempFileMixin,
    )
    from flutils.tests.loaddata import load_test_data


# Generated at 2022-06-11 22:43:32.798973
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [Path('/home/test_user/tmp/file_one'),
                                           Path('/home/test_user/tmp/dir_one')]



# Generated at 2022-06-11 22:43:38.840211
# Unit test for function chmod
def test_chmod():
    print('Running test_chmod')
    path = '~/tmp/flutils.tests.osutils.txt'
    try:
        chmod(path, 0o600)
    except:
        print('Failed to unit test function chmod')
        return False
    else:
        return True



# Generated at 2022-06-11 22:43:45.495713
# Unit test for function exists_as
def test_exists_as():
    # Remove directory if it exists.
    test_dir = normalize_path('~/tmp/flutils.tests.pathutils')
    shutil.rmtree(test_dir.as_posix(), ignore_errors=True)
    test_dir.mkdir(parents=True)
    test_file = Path(test_dir, 'exists_as.txt')
    test_file.touch()
    assert exists_as(test_dir) == 'directory'
    assert exists_as(test_file) == 'file'
    # Remove directories if they exist
    shutil.rmtree(test_dir.as_posix(), ignore_errors=True)



# Generated at 2022-06-11 22:44:03.292814
# Unit test for function directory_present
def test_directory_present():
    """Test function directory_present."""
    import shutil
    import tempfile
    from flutils.pathutils import directory_present
    from pathlib import PosixPath
    import pwd
    import subprocess


# Generated at 2022-06-11 22:44:13.244553
# Unit test for function find_paths
def test_find_paths():
    with temporary_directory(cleanup=False) as tmp_path:
        tmp_path = Path(tmp_path)
        file_one = tmp_path / 'file_one'
        file_two = tmp_path / 'file_two'
        dir_one = tmp_path / 'dir_one'
        dir_two = tmp_path / 'dir_two'
        dir_one_one = dir_one / 'dir_one_one'
        file_one_two = dir_one / 'file_one_two'
        file_one.touch()
        file_two.touch()
        dir_one.mkdir()
        dir_two.mkdir()
        dir_one_one.mkdir()
        file_one_two.touch()

        # Test with a directory path

# Generated at 2022-06-11 22:44:24.305353
# Unit test for function find_paths
def test_find_paths():
    from pathlib import Path
    from flutils.pathutils import find_paths

    Path('/tmp/flutils.tests.pathutils.test_find_paths.dir/').mkdir(
        parents=True
    )
    Path('/tmp/flutils.tests.pathutils.test_find_paths.dir/file').touch()
    Path('/tmp/flutils.tests.pathutils.test_find_paths.dir/file.txt').touch()


# Generated at 2022-06-11 22:44:25.002142
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'



# Generated at 2022-06-11 22:44:36.319417
# Unit test for function chown
def test_chown():
    _result = []
    target_path = Path(
        '/tmp/flutils.tests.osutils.chown.test_chown.target.path'
    )

# Generated at 2022-06-11 22:44:47.075847
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory
    with TemporaryDirectory(prefix='flutils.tests.pathutils') as dir_path:
        dir_path = Path(dir_path)
        sub_path = dir_path / 'sub'
        sub_path.mkdir()
        file_path = dir_path / 'file.txt'
        file_path.touch()
        file_path.chmod(0o600)
        sub_path.chmod(0o700)
        assert file_path.stat().st_mode & 0o777 == 0o600
        assert sub_path.stat().st_mode & 0o777 == 0o700
        chmod('~/tmp/*', mode_file=0o644, mode_dir=0o770)
        # Both path's should be changed
       

# Generated at 2022-06-11 22:44:58.859858
# Unit test for function find_paths
def test_find_paths():

    with TemporaryDirectory(prefix='test_find_paths', dir='~/tmp') as test_dir:
        test_dir = Path(test_dir).expanduser()
        test_dir.mkdir(mode=0o755, parents=True)

        Path(test_dir / 'dir_one').mkdir(mode=0o755)
        Path(test_dir / 'dir_two').mkdir(mode=0o755)

        Path(test_dir / 'file_one.txt').write_text('this is a test')
        Path(test_dir / 'file_one.txt').chmod(0o600)
        Path(test_dir / 'file_two.txt').write_text('this is a test')
        Path(test_dir / 'file_two.txt').chmod(0o600)

        result

# Generated at 2022-06-11 22:45:08.310024
# Unit test for function exists_as
def test_exists_as():
    if PY3:
        path = Path(__file__)
    else:
        path = Path(__file__.decode(sys.getfilesystemencoding()))
    assert exists_as(path) == 'file'
    assert exists_as(path.parent) == 'directory'

    # Test on the root path '/'.
    assert exists_as(path.root) == 'directory'
    if sys.platform == 'win32':
        assert exists_as(path.root.as_posix()[:-1]) == 'directory'

    # Test on a path that does not exist.
    assert exists_as(path.parent / 'doesnotexist') == ''
    # Test on a path that exists as a symbolic link.

# Generated at 2022-06-11 22:45:09.714036
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-11 22:45:21.398934
# Unit test for function chmod
def test_chmod(): # noqa
    from stat import S_IMODE
    from tempfile import TemporaryDirectory
    from flutils.osutils import make_file

    try:
        from pathlib import Path

    except ImportError:
        from pathlib2 import Path

    with TemporaryDirectory() as tmpdir:
        parent_dir = Path(tmpdir)
        file_path = make_file(parent_dir / 'testfile.txt')

        chmod(file_path, mode_file=0o660)
        assert S_IMODE(file_path.stat().st_mode) == 0o660
        chmod(file_path)
        assert S_IMODE(file_path.stat().st_mode) == 0o600
        chmod(parent_dir / 'testfile.txt', mode_file=0o660)

# Generated at 2022-06-11 22:45:47.351623
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

    assert callable(chmod)

    # Create a temporary file and directory that we can use for
    # testing.
    with Path('.').joinpath('tmp_dir').mkdir() as temp_dir:
        temp_dir.chmod(0o700)
        with Path(temp_dir).joinpath('tmp_file').open('w'):
            pass

        assert Path(temp_dir).joinpath('tmp_file').stat().st_mode & 0o777 == 0o600

        chmod(temp_dir.joinpath('tmp_file'), 0o666)

        assert Path(temp_dir).joinpath('tmp_file').stat().st_mode & 0o777 == 0o666



# Generated at 2022-06-11 22:45:59.373939
# Unit test for function find_paths
def test_find_paths():
    # Test with a glob pattern
    test_dir = Path('~/flutils_tests').expanduser()
    assert list(find_paths(str(test_dir))) == [test_dir]
    assert list(find_paths(test_dir)) == [test_dir]

    # Test without a glob pattern
    test_dir_pattern = Path('~/flutils_tests/tmp/test_pattern').expanduser()
    assert test_dir_pattern.mkdir(parents=True) is None
    assert list(find_paths(str(test_dir_pattern))) == [test_dir_pattern]
    assert list(find_paths(test_dir_pattern)) == [test_dir_pattern]

