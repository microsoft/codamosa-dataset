

# Generated at 2022-06-11 22:36:46.354913
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        file_path = tmp_dir / 'one'
        file_path.touch()
        file_path = tmp_dir / 'two'
        file_path.touch()
        dir_path = tmp_dir / 'three'
        dir_path.mkdir()
        dir_path = tmp_dir / 'four'
        dir_path.mkdir()
        files = list(find_paths(tmp_dir / '*'))
        assert len(files) == 4
        files = list(find_paths(tmp_dir / 'o*'))
        assert len(files) == 2
        files = list(find_paths(tmp_dir / 'o*e'))
        assert len(files) == 1

# Generated at 2022-06-11 22:36:48.721226
# Unit test for function chown
def test_chown():
    # as root
    assert chown(__file__) is None
    # as user
    assert chown(__file__) is None

# Generated at 2022-06-11 22:36:52.481920
# Unit test for function chown
def test_chown():
    path = 'banana_file'
    with open(path, 'w') as f:
        f.write('foo')

    from flutils.osutils import geteuid
    user = geteuid()
    chown(path, user)
    os.remove(path)



# Generated at 2022-06-11 22:37:05.668745
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod"""
    import pytest

    fixture_path = \
        Path(__file__).parent.parent / 'tests/fixtures/pathutils/fileutils'

    with pytest.raises(TypeError):
        chmod(path=1)

    with pytest.raises(TypeError):
        chmod(path='.', mode_file='foo')

    with pytest.raises(NotImplementedError):
        chmod(path='/foo/bar')

    with pytest.raises(NotImplementedError):
        chmod(path='/foo/bar', mode_file=0o600)

    with pytest.raises(NotImplementedError):
        chmod(path='/foo/bar', mode_file=0o600)

    # Make a file
    file

# Generated at 2022-06-11 22:37:07.243786
# Unit test for function find_paths
def test_find_paths():
    pattern = '~/tmp/*'
    list(find_paths(pattern))



# Generated at 2022-06-11 22:37:19.111702
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.pathutils import file_present
    from tempfile import gettempdir

    tmpdir = Path(gettempdir())
    flutils_dir = directory_present(tmpdir / 'flutils')
    flutils_tests_dir = directory_present(flutils_dir / 'tests')

    assert exists_as(flutils_tests_dir) == 'directory'
    os.rmdir(flutils_tests_dir.as_posix())
    assert exists_as(flutils_tests_dir) == ''

    assert exists_as(flutils_dir) == 'directory'
    os.rmdir(flutils_dir.as_posix())
    assert exists_as(flutils_dir) == ''

    #

# Generated at 2022-06-11 22:37:27.876084
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as, directory_present
    from pathlib import Path
    from flutils.osutils import tempdir

    with tempdir() as tmpdir:
        with directory_present(tmpdir + 'dir'):
            pass

        test_file = tmpdir + 'file.txt'
        Path(test_file).touch()

        assert exists_as(tmpdir) == 'directory'
        assert exists_as(tmpdir + 'dir') == 'directory'
        assert exists_as(test_file) == 'file'
        assert exists_as('fake_path') == ''



# Generated at 2022-06-11 22:37:30.858269
# Unit test for function find_paths
def test_find_paths():
    from pathlib import PosixPath
    return list(find_paths('~/tmp/*')) == [PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one')]



# Generated at 2022-06-11 22:37:37.987919
# Unit test for function chown
def test_chown():
    """Unit test for function chown"""
    import shutil
    import stat
    import tempfile
    import time
    TMP_DIR = tempfile.mkdtemp()
    FILE_NAME = 'file.txt'
    FILE_PATH = os.path.join(TMP_DIR, FILE_NAME)

# Generated at 2022-06-11 22:37:43.513189
# Unit test for function directory_present
def test_directory_present():
    abs_path = os.path.abspath('~/tmp/dummy_path')
    p = Path(abs_path)
    if p.exists():
        p.rmdir()
    directory_present(p)
    assert p.exists()
    p.rmdir()



# Generated at 2022-06-11 22:38:15.886091
# Unit test for function chmod
def test_chmod():
    import tests.osutils as osutils
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert osutils.os.stat('~/tmp/flutils.tests.osutils.txt').st_mode == 33152
    chmod('~/tmp/flutils.tests.osutils.txt', 0o600)
    assert osutils.os.stat('~/tmp/flutils.tests.osutils.txt').st_mode == 33024



# Generated at 2022-06-11 22:38:16.550796
# Unit test for function find_paths
def test_find_paths():
    assert True



# Generated at 2022-06-11 22:38:17.948535
# Unit test for function chown
def test_chown():
    normalize_path('/tmp/foo',  create_path=True)



# Generated at 2022-06-11 22:38:29.378783
# Unit test for function exists_as
def test_exists_as():
    from os import makedirs, mkfifo, mknod, mkdir

    from flutils.pathutils import exists_as


# Generated at 2022-06-11 22:38:33.024813
# Unit test for function find_paths
def test_find_paths():
    assert set(find_paths('~/tmp/*')) == {
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    }



# Generated at 2022-06-11 22:38:43.089007
# Unit test for function path_absent
def test_path_absent():
    with ExitStack() as stack:
        dpath = stack.enter_context(tempfile.TemporaryDirectory())
        path = Path(dpath) / 'tmp' / 'tmpfile'
        path.parent.mkdir()
        path.touch()
        assert exists_as(path) == 'file'
        path_absent(path)
        assert exists_as(path) == ''
        path = Path(dpath) / 'tmp' / 'tmpdir'
        path.parent.mkdir()
        path.mkdir()
        assert exists_as(path) == 'directory'
        path_absent(path)
        assert exists_as(path) == ''

# Generated at 2022-06-11 22:38:52.287821
# Unit test for function chown
def test_chown():
    import subprocess
    import tempfile
    import shutil

    tempdir = tempfile.mkdtemp()

    path1 = os.path.join(tempdir, 'dir1', 'dir2', 'dir3')
    path2 = os.path.join(path1, 'file2')

    os.makedirs(path1, mode=0o700)
    Path(path2).touch(exist_ok=True)

    if sys.platform == 'darwin':
        # The ownership of a file created by calling the os.makedirs()
        # function on macOS defaults to the user, group root.
        shutil.chown(tempdir, user='root')

    # Make the initial ownership any user other than root.

# Generated at 2022-06-11 22:39:01.093165
# Unit test for function chown
def test_chown():
    def _test_chown(
            path: Union[Path, bytes, str],
            user: Optional[str] = None,
            group: Optional[str] = None,
            include_parent: bool = False,
            test_user: str = 'testuser',
            test_group: str = 'testgroup'
    ) -> None:
        assert path.exists() is False
        path.mkdir(0o700, parents=True)
        current_user = getpass.getuser()
        current_group = grp.getgrgid(os.getgid()).gr_name
        chown(path, user, group, include_parent)
        assert path.exists() is True
        if isinstance(user, str) and user == '-1':
            assert path.owner() == current_user

# Generated at 2022-06-11 22:39:02.710054
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == \
        [Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')]



# Generated at 2022-06-11 22:39:12.361986
# Unit test for function find_paths
def test_find_paths():
    import textwrap
    import flutils.tests.osutils

    # Test for empty glob pattern
    with flutils.tests.osutils.TemporaryDirectory(delete=True) as test_dir:
        # Test for empty glob pattern
        os.makedirs(os.path.join(test_dir, 'foo'))
        assert (
            list(find_paths('%s/**' % test_dir))
            == [Path(test_dir).resolve()]
        )
        assert (
            list(find_paths('%s/**/foo' % test_dir))
            == [Path('%s/foo' % test_dir).resolve()]
        )
        assert (
            list(find_paths('%s/*' % test_dir))
            == []
        )

        # Test for glob pattern not

# Generated at 2022-06-11 22:39:30.474973
# Unit test for function find_paths
def test_find_paths():
    assert len(list(find_paths('~/tmp/*.txt'))) == 2
    assert len(list(
        find_paths('~/tmp/flutils.tests.osutils.txt')
    )) == 1

# Generated at 2022-06-11 22:39:31.649819
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:39:44.468958
# Unit test for function find_paths
def test_find_paths():
    """Test for function find_paths."""
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as parent_dir:
        file_one = Path(parent_dir, 'file_one')
        file_one.touch()
        file_two = Path(parent_dir, 'file_two')
        file_two.touch()
        dir_one = Path(parent_dir, 'dir_one')
        dir_one.mkdir()
        dir_two = Path(parent_dir, 'dir_one', 'dir_two')
        dir_two.mkdir()

        # 1.
        pattern = Path(parent_dir, 'file_one')
        results = list(find_paths(pattern))
        assert len(results) == 1
        assert results[0].as_posix() == file_one.as_pos

# Generated at 2022-06-11 22:39:47.528831
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/a_file'
    chmod(path, 0o644, 0o755)

# Generated at 2022-06-11 22:39:55.308898
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/') == 'directory'
    assert exists_as('/proc/') == 'directory'
    assert exists_as('/') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/tmp/') == 'directory'
    assert exists_as('/not_a_valid_path') == ''
    assert exists_as('/not_a_valid_path/') == ''
    assert exists_as('/tmp/not_a_valid_path') == ''
   

# Generated at 2022-06-11 22:40:07.044707
# Unit test for function path_absent
def test_path_absent():
    """
    Test for path_absent.
    """
    tmp_dir = './tests/tmp'
    test_path = os.path.join(tmp_dir, "test_path")
    if os.path.exists(test_path):
        os.unlink(test_path)
    if os.path.exists(tmp_dir):
        os.rmdir(tmp_dir)
    os.makedirs(tmp_dir)
    path_present(test_path)
    path_absent(test_path)
    assert not os.path.exists(test_path)
    assert os.path.exists(tmp_dir)
    os.unlink(test_path)
    os.rmdir(tmp_dir)



# Generated at 2022-06-11 22:40:07.647576
# Unit test for function exists_as
def test_exists_as():
    pass



# Generated at 2022-06-11 22:40:18.806223
# Unit test for function directory_present
def test_directory_present():
    import os
    import shutil
    import tempfile

    os_path = os.path
    if os.name == 'posix':
        os_path = '/tmp/test/path'
    if os.name == 'nt':
        os_path = 'c:\\temp\\test\\path'
    assert directory_present(os_path) == os_path

    # Test directory creation with mode.
    test_dir = tempfile.mkdtemp()

    # Create the test directory manually to force permission mode.
    os.mkdir(
        os.path.join(test_dir, 'test_dir'),
        0o777
    )
    directory_present(os.path.join(test_dir, 'test_dir'), 0o700)

    # Remove the test directory to force its creation.

# Generated at 2022-06-11 22:40:20.778723
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/hosts') == 'file'



# Generated at 2022-06-11 22:40:25.095171
# Unit test for function chown
def test_chown():
    import pytest
    from tempfile import TemporaryDirectory
    from flutils.pathutils import chown
    from flutils.testingutils import suppress_stderr
    ########################
    # Test -1 w/ user and
    # group
    ########################
    def test_func_chown_minus1_w_user_and_group() -> None:
        with TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            test_path = tmpdir / 'tmp_file'
            test_path.write_text('stuff')
            chown(test_path, user='root', group='-1')
            assert test_path.owner() == 'root'
            assert test_path.group() == getpass.getuser()
    test_func_chown_minus1_w_user_and_group

# Generated at 2022-06-11 22:40:57.096726
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import path_absent
    from flutils.pathutils import directory_present

    base_path = Path(sys.argv[0]).parent / 'directory_present'
    path_absent(base_path, include_children=True)

    saved_umask = os.umask(0o0)

# Generated at 2022-06-11 22:41:07.435394
# Unit test for function chmod
def test_chmod():
    import shutil
    from tempfile import mkdtemp

    with mkdtemp() as tmp:
        os.chmod(tmp, 0o700)

        # First test glob pattern.
        sub_path = Path(tmp).joinpath('foo')
        sub_path.write_text('bar')
        os.chmod(sub_path.as_posix(), 0o600)

        # Will change the file mode
        chmod(Path(tmp).joinpath('foo'))
        assert os.stat(sub_path).st_mode == 0o100600

        # Will not change the file mode
        chmod(Path(tmp).joinpath('foo'), mode_file=0o660)
        assert os.stat(sub_path).st_mode == 0o100600

        # Will change the file mode

# Generated at 2022-06-11 22:41:18.507379
# Unit test for function chmod
def test_chmod():
    from os import getcwd, path

    from flutils.pathutils import chmod

    tmp_cwd = path.join(getcwd(), 'info/tmp')

    parent_path = path.join(tmp_cwd, 'parent')
    path1 = path.join(parent_path, 'a.txt')
    path2 = path.join(parent_path, 'b.txt')
    path3 = path.join(parent_path, 'c.txt')
    path4 = path.join(parent_path, 'd.txt')

    sub_path1 = path.join(tmp_cwd, 'sub1')
    sub_path2 = path.join(tmp_cwd, 'sub2')
    sub_path3 = path.join(tmp_cwd, 'sub3')

    sub_path1_path1

# Generated at 2022-06-11 22:41:25.911229
# Unit test for function find_paths
def test_find_paths():
    path = Path(__file__).parent / 'data'
    result = [s for s in find_paths(path)]
    expected = [
        Path(__file__).parent / 'data' / 'dir_one',
        Path(__file__).parent / 'data' / 'dir_two',
        Path(__file__).parent / 'data' / 'dir_two/dir_three',
        Path(__file__).parent / 'data' / 'dir_two/file_two',
        Path(__file__).parent / 'data' / 'file_one',
    ]
    assert result == expected,\
        'Result %r did NOT match expected %r.' % (result, expected)



# Generated at 2022-06-11 22:41:33.082537
# Unit test for function find_paths
def test_find_paths():
    # Create a temp path
    tmp_path = './test_find_paths'
    # Create a path object from the tmp path
    tmp_path_obj = Path(tmp_path)
    # Make the tmp dir
    tmp_path_obj.mkdir(0o700, parents=True)
    # Save the current working directory
    cwd = Path.cwd()
    # Change working directory to the tmp dir
    os.chdir(tmp_path_obj.as_posix())
    # Create a test file and dir
    Path('file').touch()
    Path('dir').touch()
    # Setup the expected list of files
    expected = [
        'file',
        'dir'
    ]
    # Run the code to test
    actual = list(find_paths(tmp_path_obj))
    # Ass

# Generated at 2022-06-11 22:41:36.840856
# Unit test for function find_paths
def test_find_paths():
    list_gen = [p.as_posix() for p in find_paths('~/tmp/*')]
    assert list_gen == [
        '/Users/len/tmp/flutils.tests.osutils.txt',
        '/Users/len/tmp/flutils.tests'
    ]



# Generated at 2022-06-11 22:41:37.416638
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:47.952294
# Unit test for function chmod
def test_chmod():
    """Test for function chmod."""

    from flutils.tests.helpers import (
        all_args_as_kwargs,
        delete_tree,
        mkdir_tree,
        create_file,
    )

    import os
    import stat

    # A path tree that will be created and deleted
    # before and after each test.

# Generated at 2022-06-11 22:42:00.192981
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.systemutils import tmp_directory
    from pathlib import PosixPath

    with tmp_directory() as tmpdir:

        # Test with a directory that does not exist.
        expect_path = PosixPath(tmpdir) / 'foo' / 'bar'
        path = directory_present(expect_path)
        assert path == expect_path
        assert path.is_dir() is True
        path_absent(path)

        # Test with a directory that exists as a file.
        path = directory_present(tmpdir)
        assert path.is_dir() is True
        expect_path = PosixPath(tmpdir) / 'foo' / 'bar'
        path = directory_present(expect_path)

# Generated at 2022-06-11 22:42:11.354906
# Unit test for function path_absent
def test_path_absent():
    """Test the function path_absent."""
    # Test with a link
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('test_file').touch()
        tmpdir.joinpath('test_link').symlink_to(tmpdir.joinpath('test_file'))
        path_absent(tmpdir)
        assert tmpdir.exists() is False
    # Test with a file
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('test_file').touch()
        path_absent(tmpdir)
        assert tmpdir.exists() is True
        path_absent(tmpdir.joinpath('test_file'))

# Generated at 2022-06-11 22:42:58.768149
# Unit test for function exists_as
def test_exists_as():
    # from flutils.pathutils import exists_as
    assert exists_as('/') == 'directory'
    assert exists_as(__file__) == 'file'
    assert exists_as('/dev/console') == 'file'
    if sys.platform == 'linux':
        assert exists_as('/dev/sda') == 'block device'
        assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/proc') == 'directory'
    assert exists_as('/nonexistant') == ''
    assert exists_as('~/does/not/exist') == ''

# Generated at 2022-06-11 22:43:08.650508
# Unit test for function chmod
def test_chmod():
    import os
    from flutils.pathutils import chmod

    # Single file test
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    assert os.stat(path.as_posix()).st_mode & 0o777 == 0o600

    chmod(path, mode_file=0o660)
    assert os.stat(path.as_posix()).st_mode & 0o777 == 0o660

    path.unlink()

    # Glob pattern test
    path = Path('/tmp/flutils.tests.pathutils.txt')
    path.touch()

    chmod('/tmp/*.pathutils.txt', mode_file=0o660)
    assert os.stat(path.as_posix()).st_mode & 0o777 == 0o660



# Generated at 2022-06-11 22:43:10.549917
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(os.path.dirname(__file__)) == 'directory'
    assert exists_as('~/.bash_profile') == ''

# Generated at 2022-06-11 22:43:17.759330
# Unit test for function chown
def test_chown():
    # set up
    from tempfile import TemporaryDirectory
    from os import chmod, mkdir
    from os.path import join, expanduser, sep
    from shutil import rmtree
    from pathlib import Path
    tmp = TemporaryDirectory()
    path = Path(join(tmp.name, 'folder'))
    os.mkdir(path)
    path = path.joinpath('test.txt')
    path.touch()
    chown(path)
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()

    # cleanup
    rmtree(tmp.name, ignore_errors=True)



# Generated at 2022-06-11 22:43:25.957291
# Unit test for function chmod
def test_chmod():
    for path in ['~/tmp/flutils.tests.osutils.txt', '~/tmp/flutils.tests.osutils']:
        chmod(path, 0o660)
        assert oct(os.stat(path).st_mode & 0o777) == '0o660'
        chmod(path, 0o755)
        assert oct(os.stat(path).st_mode & 0o777) == '0o755'
        chmod(path, 0o750)
        assert oct(os.stat(path).st_mode & 0o777) == '0o750'
        chmod(path, 0o400)
        assert oct(os.stat(path).st_mode & 0o777) == '0o400'
        chmod(path, 0o444)

# Generated at 2022-06-11 22:43:32.247279
# Unit test for function chown
def test_chown():
    _, fname = tempfile.mkstemp()
    os.chown(fname, 0, 0)
    # Test where path is a file
    os.chown(fname, 100, 100)

    # Test where path is a directory
    dname = tempfile.mkdtemp()
    os.chown(dname, 100, 100)

    # Test where path is a glob pattern
    glob = dname + '/*'
    os.chown(glob, 100, 100)

    # Test where path does not exist
    os.chown('/tmp/invalid', 100, 100)


# Generated at 2022-06-11 22:43:35.524210
# Unit test for function chown
def test_chown():
    os.mkdir('/tmp/test_chown')
    os.chown('/tmp/test_chown', 0, 1000)
    chown('/tmp/test_chown', '-1', 1000)
    os.chown('/tmp/test_chown', 0, 1000)



# Generated at 2022-06-11 22:43:45.124306
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    # Create a test directory and some paths.
    test_dir = Path(
        '/tmp/test_path_absent'
    ) / 'test_path'
    mkdir(test_dir)
    for dir_ in [
            test_dir / 'foo',
            test_dir / 'bar',
            test_dir / 'foo/baz',
            test_dir / 'foo/foo'
    ]:
        mkdir(dir_)
    for f in [
            test_dir / 'foo/bar.txt',
            test_dir / 'foo/baz/bar.txt',
            test_dir / 'foo/foo/bar.txt'
    ]:
        Path(f).touch()

# Generated at 2022-06-11 22:43:51.261584
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present
    """
    path_name = normalize_path('~/tmp/test_dir_present')
    if path_name.exists():
        path_name.unlink()

    try:
        directory_present(path_name)
        assert path_name.exists()
        assert path_name.is_dir()
        path_name.unlink()
    except BaseException as err:
        path_name.unlink()
        raise err



# Generated at 2022-06-11 22:44:02.296990
# Unit test for function chmod
def test_chmod():

    path = os.path.join(
        os.path.expanduser('~'),
        'tmp',
        'flutils.tests.osutils',
        'test_chmod.txt'
    )

    f = open(path, 'wt')
    f.write('Hello World!')
    f.close()

    os.chmod(path, 0o777)
    original_mode = os.stat(path).st_mode

    chmod(path, 0o660)
    assert 0o660 == os.stat(path).st_mode
    os.chmod(path, original_mode)

    chmod(path, 0o664, 0o770)
    assert 0o664 == os.stat(path).st_mode
    os.chmod(path, original_mode)


# Generated at 2022-06-11 22:44:22.926451
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import (
        get_os_group,
        get_os_user,
    )

    from flutils.osutils import set_gid
    from flutils.osutils import set_uid

    from flutils.fileutils import file_present
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent

    from pyfakefs.fake_filesystem_unittest import TestCase
    from shutil import go_home
    from shutil import rmtree

    # Get the group name and gid
    os_group = get_os_group()
    if os_group is not None:
        os_gid = grp.getgrnam(os_group).gr_gid
    else:
        os_gid = -1

    user = get_

# Generated at 2022-06-11 22:44:33.772186
# Unit test for function chmod
def test_chmod():
    from . import osutils
    from . import sysutils
    from .chardet.compat import text_type

    def get_chmod(path: str) -> text_type:
        # NOTE: stat.S_IMODE(mode) will always return the mode
        # in octal notation; hence, the string formatting...
        mode = osutils.os.stat(path).st_mode
        return '{0:o}'.format(osutils.stat.S_IMODE(mode))

    with sysutils.temporary_directory() as temp_dir:
        temp_dir = Path(temp_dir)
        path = temp_dir.joinpath('chmod.txt')
        path.touch()
        assert get_chmod(path) == '644'
        chmod(path)

# Generated at 2022-06-11 22:44:35.395159
# Unit test for function chmod
def test_chmod():
    assert os.stat('./tests/files').st_mode & 0o777 == 0o777

# Generated at 2022-06-11 22:44:46.107108
# Unit test for function path_absent
def test_path_absent():

    with tempfile.TemporaryDirectory(prefix='tmp_fluentils_path_absent_') as d:
        td = Path(d)

        path = td / 'foo'
        path.touch()
        path_absent(path)
        assert((path.exists() is False) is True)

        path_present(
            td / 'bar/fubar/',
            user='foo',
        )
        path_absent(td / 'bar/fubar')
        assert((td / 'bar/fubar').exists() is False)
        assert((td / 'bar').exists() is True)



# Generated at 2022-06-11 22:44:57.544774
# Unit test for function exists_as
def test_exists_as():
    exists_as('~/tmp')
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/Users/len/tmp') == 'directory'
    assert exists_as('/Users/len/tmp') != 'file'

    # Set up a test dir and files
    with temporary_directory(prefix='flutils_test_') as tmpdir:
        os.chmod(tmpdir.as_posix(), 0o700)
        file_path = tmpdir.joinpath('file_test')
        dir_path = tmpdir.joinpath('dir_test')
        fifo_path = tmpdir.joinpath('fifo_test')
        socket_path = tmpdir.joinpath('socket_test')
        chrdev_path = tmpdir.joinpath('char_dev_test')
        blkdev

# Generated at 2022-06-11 22:45:07.441621
# Unit test for function chown
def test_chown():
    """
    Test flutils.osutils.chown()
    """
    import tempfile

    fd, file_name = tempfile.mkstemp()
    os.close(fd)


# Generated at 2022-06-11 22:45:20.373167
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'
    assert exists_as(str(path)) == 'file'
    assert exists_as(bytes(path)) == 'file'

    path = path.parent
    assert exists_as(path) == 'directory'

    path = path.parent
    path = path.joinpath('tmp')
    assert exists_as(path) == 'directory'

    path = path.joinpath('test_file.txt')
    open(path, 'w').close()

    assert exists_as(path) == 'file'

    path.unlink()

    path = path.parent
    assert exists_as(path) == 'directory'
    path.rmdir()


# Generated at 2022-06-11 22:45:33.797341
# Unit test for function path_absent
def test_path_absent():
    tmp_dir = mkdtemp(prefix='flutils-test_')
    user = getpass.getuser()
    path = os.path.join(tmp_dir, 'test_dir')
    path_absent(path)
    assert os.path.exists(path) is False
    os.mkdir(path)
    assert os.path.exists(path) is True
    path_absent(path)
    assert os.path.exists(path) is False

    path = os.path.join(tmp_dir, 'test_file')
    path_absent(path)
    assert os.path.exists(path) is False
    open(path, 'w').close()
    assert os.path.exists(path) is True
    path_absent(path)
    assert os.path.ex

# Generated at 2022-06-11 22:45:36.722015
# Unit test for function chown
def test_chown():
    """Test for function chown."""
    from . import test_functions
    chown('.', user='root')
    test_functions.test_func(test_chown)



# Generated at 2022-06-11 22:45:48.638097
# Unit test for function chown
def test_chown():
    import tempfile
    import os
    import shutil
    def _chown_test(path, owner, group):
        path = Path(path)
        if path.exists() is True:
            # Check/verify the current owner/group
            import pwd
            import grp
            assert pwd.getpwuid(os.stat(path.as_posix()).st_uid).pw_name == owner
            assert grp.getgrgid(os.stat(path.as_posix()).st_gid).gr_name == group

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        myfile = temp_dir / 'file_test'
        myfile.touch()

        mydir = temp_dir / 'dir_test'
       