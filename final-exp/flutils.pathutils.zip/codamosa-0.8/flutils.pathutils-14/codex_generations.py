

# Generated at 2022-06-11 22:36:42.202125
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tempdir:
        tmppath = os.path.join(tempdir, 'test_path')
        os.mkdir(tmppath)
        assert os.path.isdir(tmppath)
        path_absent(tmppath)
        assert os.path.exists(tmppath) is False



# Generated at 2022-06-11 22:36:44.229397
# Unit test for function chown
def test_chown():
    assert 'foo' == 'foo'

# Generated at 2022-06-11 22:36:54.168134
# Unit test for function chown
def test_chown():
    import tempfile
    from flutils.systemutils import Platform

    if 'posix' in Platform.current_os_name():
        test_dir = tempfile.TemporaryDirectory()
        test_file = open(
            os.path.join(test_dir.name, 'test.txt'),
            mode='w',
            encoding='utf-8'
        )
        test_file.write('This is a test file.')
        test_file.flush()
        test_file.close()
        gid = grp.getgrnam(getpass.getuser()).gr_gid
        uid = pwd.getpwnam(getpass.getuser()).pw_uid
        p = Path(test_file.name)
        chown(p, user='-1', group='-1')
        p_stats

# Generated at 2022-06-11 22:37:07.123955
# Unit test for function exists_as
def test_exists_as():
    import flutils.tests.unit.osutils
    with directory_present(
            flutils.tests.unit.osutils.TEST_DIR,
            mode=0o777
    ) as test_dir:
        path = test_dir / 'exists_as.txt'

        # Tests:
        #  * If path does not exist.
        assert exists_as(path) == ''

        # Test:
        #  * Write a file.
        path.write_text('This is a test')
        assert exists_as(path) == 'file'

        # Test:
        #  * Create a directory.
        test_sub_dir = test_dir / 'sub_dir'
        test_sub_dir.mkdir()
        assert exists_as(test_sub_dir) == 'directory'

        # Cleanup:


# Generated at 2022-06-11 22:37:12.321966
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    path = normalize_path(f'~/tmp/{user}/{group}')
    path.mkdir(parents=True, exist_ok=True)
    chown(path)
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()



# Generated at 2022-06-11 22:37:13.636026
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:37:25.046591
# Unit test for function find_paths
def test_find_paths():
    import subprocess
    from pathlib import Path

    with directory_present('/tmp/test_find_paths') as test_dir:
        subprocess.run(['touch',  '/tmp/test_find_paths/file_one'])
        subprocess.run(['mkdir', '/tmp/test_find_paths/dir_one'])

        list_of_paths = list(find_paths('/tmp/test_find_paths/*'))
        assert len(list_of_paths) == 2, (
            'find_paths("/tmp/test_find_paths/*") did not return '
            '2 paths'
        )


# Generated at 2022-06-11 22:37:29.688326
# Unit test for function find_paths
def test_find_paths():

    assert list(
        find_paths('~/tmp/test_user/*')
    ) == [
        POSIX_PATH('/home/test_user/tmp/test_user/test_file'),
        POSIX_PATH('/home/test_user/tmp/test_user/test_dir')
    ]



# Generated at 2022-06-11 22:37:35.895814
# Unit test for function exists_as
def test_exists_as():
    """Test results for flutils.pathutils.exists_as()."""
    from .mockcontext import MockContext
    from pathlib import Path
    from flutils.pathutils import exists_as

    with MockContext('tests.unit_tests.test_osutils.test_exists_as'):
        fp = Path(__file__).resolve().as_posix()
        assert exists_as(fp) == 'file'

        fp = fp + 'x'
        assert exists_as(fp) == ''

        # Test the '~' expansion results in the same string.
        fp = Path(__file__).resolve().parent.as_posix()
        fp2 = '~/' + fp.lstrip('/Users/')
        assert exists_as(fp2) == 'directory'




# Generated at 2022-06-11 22:37:45.929007
# Unit test for function find_paths
def test_find_paths():
    from flutils.test.test_io import cleandir

    # Test empty dirs
    pth = cleandir('./tmp/')
    lst = list(find_paths(pth))
    assert lst == list()
    pth.rmdir()

    # Test single dir
    pth = cleandir('./tmp/one')
    lst = list(find_paths(pth))
    assert lst == [Path('tmp/one')]
    pth.rmdir()

    # Test with files
    pth = cleandir('./tmp/one')
    pth.joinpath('a.txt').touch()
    pth.joinpath('b.txt').touch()
    lst = list(find_paths(pth))

# Generated at 2022-06-11 22:38:11.829834
# Unit test for function path_absent
def test_path_absent():

    # Test with a directory that is empty.
    path = Path(tempfile.gettempdir()) / 'test_path'
    path.mkdir(exist_ok=True)
    path_absent(path)
    assert not path.exists()

    # Test with a directory that has a file in it.
    path = Path(tempfile.gettempdir()) / 'test_path'
    path.mkdir(exist_ok=True)
    (path / 'foo').touch()
    path_absent(path)
    assert not path.exists()

    # Test with a directory that has a file in it.
    path = Path(tempfile.gettempdir()) / 'test_path'
    path.mkdir(exist_ok=True)
    (path / 'foo').touch()
    path_absent(path)

# Generated at 2022-06-11 22:38:24.183417
# Unit test for function path_absent
def test_path_absent():
    import shutil
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present

    def build_cleanup_tree():
        now = int(time.time())

        path = Path(tempfile.gettempdir()) / 'tmp' / 'flutils' / str(now)
        path_present(path.as_posix())

        path = path / 'foo'
        path_present(path.as_posix())

        path = path / 'bar'
        path_present(path.as_posix())

        path = path / 'baz'
        path_present(path.as_posix())

        path = path / 'qux'
        path_present(path.as_posix())

        path = path / 'quux'

# Generated at 2022-06-11 22:38:32.518083
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    path = Path('~/tmp/flutils.tests.osutils.txt')
    assert path.exists() is False
    path.touch()
    assert path.exists() is True
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    chown(path, user, group)
    assert path.stat().st_uid == os.getuid()
    assert path.stat().st_gid == os.getgid()
    path.unlink()



# Generated at 2022-06-11 22:38:39.107529
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Supports a glob pattern.  So to recursively change the mode
    # of a directory just do:
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # To change the mode of a directory's immediate contents:
    chmod('~/tmp/*')



# Generated at 2022-06-11 22:38:49.664858
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    import tempfile
    import shutil
    import os
    # Create temp dir
    tempdir = tempfile.TemporaryDirectory()
    os.chdir(tempdir.name)
    # Test if pathing to a file works
    tmp_file = os.path.join(tempdir.name, 'tmp_file')
    open(tmp_file, 'w').close()
    test_file = os.path.join(tempdir.name, 'test_file')
    open(test_file, 'w').close()
    assert os.path.exists(tmp_file)
    path_absent(tmp_file)
    assert not os.path.exists(tmp_file)
    path_absent(test_file)
    # Test if pathing to a directory works


# Generated at 2022-06-11 22:38:55.676591
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('/Users/len/tmp')) == 'directory'
    assert exists_as(Path('/Users/len/tmp/foo.txt')) == 'file'

    path = Path('/Users/len/tmp/foo.txt')
    path.touch()
    assert exists_as(path) == 'file'
    path.unlink()
    assert exists_as(path) == ''



# Generated at 2022-06-11 22:38:59.468910
# Unit test for function chown
def test_chown():
    with patch('os.chown') as chown_mock:
        path = Path(__file__).as_posix()
        assert chown(path) == chown_mock.assert_called_once_with(path,
                                                                 os.getuid(),
                                                                 os.getgid())

        assert chown_mock.call_count == 1



# Generated at 2022-06-11 22:39:04.650145
# Unit test for function exists_as
def test_exists_as():
    here = Path(__file__).parent
    assert exists_as(here) == 'directory'
    assert exists_as(here / 'not_there') == ''
    assert exists_as(here / '__init__.py') == 'file'


# Generated at 2022-06-11 22:39:13.311533
# Unit test for function directory_present
def test_directory_present():
    """Unit test for the function directory_present."""
    from shutil import rmtree

    # Setup for default mode tests.
    path = Path('/tmp/test_directory_present/test_1')
    dir_present = directory_present(path)
    assert(
        dir_present.as_posix() == '/tmp/test_directory_present/test_1'
    )

    path = Path('/tmp/test_directory_present/test_1/test_2')
    dir_present = directory_present(path)
    assert(
        dir_present.as_posix() == '/tmp/test_directory_present/test_1/test_2'
    )
    path.parent.rmdir()


# Generated at 2022-06-11 22:39:27.125364
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')

    mode = 0o600
    mode_dir = 0o700
    if path.exists() is False:
        Path(path).touch()
    assert path.is_file()
    assert path.stat().st_mode & mode == mode
    chmod(path, 0o660)
    assert path.is_file()
    assert path.stat().st_mode & 0o660 == 0o660
    chmod(path, mode_dir)
    assert path.is_file()
    assert path.stat().st_mode & mode_dir == mode_dir
    chmod(path, mode)
    assert path.is_file()
    assert path.stat().st_mode & mode == mode


# Generated at 2022-06-11 22:39:54.868711
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import ensure_path_absent

    with TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'test_path'
        path = cast(PosixPath, path)
        assert ensure_path_absent(path) is True
        result = directory_present(path)
        assert result.exists() is True
        assert result.is_dir() is True
        assert result.stat().st_mode & 0o777 == 0o700


# Generated at 2022-06-11 22:39:56.000244
# Unit test for function path_absent
def test_path_absent():
    _test_path_absent()



# Generated at 2022-06-11 22:39:59.543765
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths

    paths = list(find_paths('~/tmp/*'))
    for path in paths:
        assert isinstance(path, (PosixPath, WindowsPath))



# Generated at 2022-06-11 22:40:10.572646
# Unit test for function chmod
def test_chmod():
    tmp_path = _get_tmp_path()
    path_a = os.path.join(tmp_path, 'chmod.a')
    path_b = os.path.join(path_a, 'chmod.b')
    path_c = os.path.join(path_a, 'chmod.c')
    path_d = os.path.join(path_b, 'chmod.d')
    path_e = os.path.join(path_d, 'chmod.e')
    path_f = os.path.join(path_e, 'chmod.f')
    path_g = os.path.join(path_f, 'chmod.g')
    path_h = os.path.join(path_g, 'chmod.h')
    path_i = os.path.join

# Generated at 2022-06-11 22:40:17.334012
# Unit test for function path_absent
def test_path_absent():
    # testing a symbolic link
    _t = Path('/tmp/test_path_absent')
    os.symlink(_t, _t.parent / 'symlink')
    # assert symlinks is present
    assert os.path.exists('/tmp/symlink') is True
    # remove
    path_absent(_t)
    # assert symlinks is NOT present
    assert os.path.exists('/tmp/symlink') is False


# Generated at 2022-06-11 22:40:27.240730
# Unit test for function path_absent
def test_path_absent():
    import os

    os.path.exists = lambda _: True
    os.path.islink = lambda _: False
    os.path.isdir = lambda _: True

    os.walk = lambda _, **kwargs: [
        ('test_root', ('test_dir',), ('test_file',)),
        ('test_root/test_dir', (), ('test_file',)),
    ]

    os.rmdir = os.remove = lambda _: None
    os.unlink = lambda _: True

    path_absent('foo')
    assert os.unlink.called
    assert os.remove.called
    assert os.rmdir.called



# Generated at 2022-06-11 22:40:33.907849
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('~').expanduser() / 'flutils.tests'
    with pytest.raises(ValueError):
        directory_present(test_path / '*.txt')

    test_path.mkdir(0o755)
    with pytest.raises(FileExistsError):
        directory_present(test_path)

    test_path.rmdir()
    with pytest.raises(FileExistsError):
        directory_present('~/flutils.tests/../flutils.tests')
    # For some reason this test fails on travis-ci
    # with pytest.raises(FileExistsError):
    #    directory_present('.')



# Generated at 2022-06-11 22:40:43.904627
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths"""
    from os import makedirs
    from shutil import rmtree

    test_dir = Path().home() / 'tmp' / 'flutils.tests.pathutils'
    rmtree(test_dir.as_posix(), ignore_errors=True)
    makedirs(test_dir.as_posix())
    makedirs(str(test_dir / 'dir_one'))
    (test_dir / 'file_one').touch()
    (test_dir / 'dir_two' / 'file_two').touch()

    assert list(find_paths('~/tmp/flutils.tests.pathutils/dir_*'))[0] == \
        Path().home() / 'tmp' / 'flutils.tests.pathutils' / 'dir_one'



# Generated at 2022-06-11 22:40:56.464771
# Unit test for function directory_present
def test_directory_present():
    if os.name == 'nt':
        raise NotImplementedError(
            'This function is not supported on this platform.'
        )

    path = Path('~/tmp/flutils_tests/').expanduser()
    func = functools.partial(directory_present, path)

    path_exists_as = exists_as(path)
    if path_exists_as == '':
        path.mkdir(mode=0o755)
    elif path_exists_as != 'directory':
        raise Exception(
            'The path: %r can NOT be created as a directory because it '
            'already exists as a %s.' % (path.as_posix(), path_exists_as)
        )


# Generated at 2022-06-11 22:41:02.509522
# Unit test for function path_absent
def test_path_absent():
    import tempfile

    path = tempfile.mkdtemp()

    path_absent(path)

    try:
        from pathlib import Path

        Path(path).exists()
    except OSError as e:
        assert isinstance(e, FileNotFoundError)
        if hasattr(e, 'errno') and hasattr(e, 'winerror'):
            errno = getattr(e, 'errno', None)
            winerror = getattr(e, 'winerror', None)
            assert errno == 2 or errno == 3
            assert winerror == 2 or winerror == 3
    else:
        assert False



# Generated at 2022-06-11 22:41:27.858542
# Unit test for function chown
def test_chown():
    pass
    # import unittest
    # import os
    # import pwd
    # import grp
    # from flutils.pathutils import chown

    # class TestChown(unittest.TestCase):
    #     def test_chown(self):
    #         import shutil
    #         import tempfile
    #         # Create test directory/file
    #         tmp_dir = tempfile.mkdtemp()
    #         tmp_file = os.path.join(tmp_dir, 'testfile')
    #         with open(tmp_file, 'w'):
    #             pass
    #         # Make sure directory/file have same user/group
    #         current_user = pwd.getpwuid(os.geteuid())
    #         current_group = grp.getgrgid(

# Generated at 2022-06-11 22:41:37.947664
# Unit test for function find_paths
def test_find_paths():
    testpath = '/tmp/test_find_paths/{}'
    result = list(
        sorted(
            find_paths(testpath.format('**')), key=lambda x: x.parts
        )
    )

    assert result == [
        PosixPath('/tmp/test_find_paths/one'),
        PosixPath('/tmp/test_find_paths/two'),
        PosixPath('/tmp/test_find_paths/two/a'),
        PosixPath('/tmp/test_find_paths/two/a/a'),
        PosixPath('/tmp/test_find_paths/two/a/b'),
        PosixPath('/tmp/test_find_paths/two/b')
    ]



# Generated at 2022-06-11 22:41:48.335386
# Unit test for function chown
def test_chown():
    """Test chown()."""
    from .dictutils import merge_dicts
    from .testutils import BaseTestCase, TEST_DATA_DIR

    class TestCase(BaseTestCase):
        """Unit test for function chown()."""

        def test_posix(self) -> None:
            """Test chown()."""
            from .osutils import temp_dir, temp_file
            from .osutils import set_dir_mode, set_file_mode
            from .osutils import set_file_owner, set_dir_owner
            from .osutils import get_file_mode, get_dir_mode
            from .osutils import get_file_owner, get_dir_owner
            from .osutils import make_symlinks


# Generated at 2022-06-11 22:41:54.306906
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.testing import cd_tmpdir
    from tempfile import mkdtemp
    from os.path import basename

    name = basename(mkdtemp())
    with cd_tmpdir():
        assert directory_present(name)



# Generated at 2022-06-11 22:41:55.404458
# Unit test for function chmod
def test_chmod():
    # Basic test of chmod
    pass



# Generated at 2022-06-11 22:42:01.582384
# Unit test for function exists_as
def test_exists_as():
    d = tmpdir()
    p = d.join('test_pathutils_exists_as.txt')
    assert exists_as(p) == ''
    p.write_text('test_pathutils_exists_as')
    assert exists_as(p) == 'file'
    with pytest.raises(ValueError):
        exists_as('~/tmp/*')



# Generated at 2022-06-11 22:42:08.831140
# Unit test for function directory_present
def test_directory_present():
    assert (
        directory_present('/tmp/flutils/test_directory_present/bar') ==
        Path('/tmp/flutils/test_directory_present/bar')
    )
    assert (
        directory_present('/tmp/flutils/test_directory_present/foo') ==
        Path('/tmp/flutils/test_directory_present/foo')
    )



# Generated at 2022-06-11 22:42:16.938923
# Unit test for function exists_as
def test_exists_as():
    if sys.platform == 'win32':
        try:
            import win32file  # type: ignore[import]
        except ImportError:
            pytest.skip('The win32file module is not available.')

        # Create a named pipe/FIFO
        pipe_name = '\\\\.\\pipe\\flutils_test'
        handle = win32file.CreateNamedPipe(
            pipe_name,
            win32file.PIPE_ACCESS_DUPLEX,
            win32file.PIPE_TYPE_MESSAGE | win32file.PIPE_WAIT,
            1, 65536, 65536,
            300,
            None
        )

        assert exists_as(pipe_name) == 'FIFO'

        # Create a char device

# Generated at 2022-06-11 22:42:27.507105
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tempdir:
        path = pathlib.Path(tempdir) / 'foo' / 'bar'
        path.mkdir(parents=True)
        path_absent(path)
        assert exists_as(path) == ''

        path = pathlib.Path(tempdir) / 'foo' / 'bar.file'
        path.touch()
        path_absent(path)
        assert exists_as(path) == ''

        path = pathlib.Path(tempdir) / 'foo' / 'bar.link'
        path.parent.symlink_to(path.name)
        path_absent(path)
        assert exists_as(path) == ''



# Generated at 2022-06-11 22:42:28.182527
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-11 22:43:24.038690
# Unit test for function chown
def test_chown():
    chown('/tmp/foo/bar')
    pass



# Generated at 2022-06-11 22:43:26.282883
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.cwd()) == 'directory'
    assert exists_as(Path(__file__)) == 'file'



# Generated at 2022-06-11 22:43:32.457633
# Unit test for function directory_present
def test_directory_present():
    test_path = Path(__file__).parent.parent.parent.joinpath('tmp')
    if test_path.exists() is True:
        print('delete', test_path)
        test_path.rmdir()
    assert test_path.exists() is False
    directory_present(test_path)
    assert test_path.exists() is True
test_directory_present.unittest = ['.test_path']



# Generated at 2022-06-11 22:43:40.658896
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(dir_path) == 'directory'
    assert exists_as(dir_path.joinpath('file1.txt')) == 'file'
    assert exists_as(dir_path.joinpath('symlink1.txt')) == 'file'
    assert exists_as(dir_path.joinpath('symlink2.txt')) == ''
    assert exists_as(dir_path.joinpath('not_a_path.txt')) == ''



# Generated at 2022-06-11 22:43:51.260672
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory

    def _test(path):
        testpath = Path(path).expanduser().resolve()
        path_dir = testpath.parent
        if testpath.is_dir():
            for root, dirs, files in os.walk(testpath, topdown=False):
                for name in files:
                    p = os.path.join(root, name)
                    if os.path.isfile(p) or os.path.islink(p):
                        os.unlink(p)
                for name in dirs:
                    p = os.path.join(root, name)
                    if os.path.islink(p):
                        os.unlink(p)
                    else:
                        os.rmdir(p)

# Generated at 2022-06-11 22:44:02.295819
# Unit test for function path_absent
def test_path_absent():
    path = normalize_path('~/tmp/test_path')
    path = path.as_posix()
    path = cast(str, path)
    os.makedirs(path)
    dir_path = normalize_path(os.path.join(path, 'dir')).as_posix()
    os.makedirs(dir_path)
    file_path = normalize_path(os.path.join(path, 'file')).as_posix()
    with open(file_path, 'wt') as f:
        f.write('file')
    symlink_path = normalize_path(os.path.join(path, 'symlink'))
    symlink_path = symlink_path.as_posix()

# Generated at 2022-06-11 22:44:05.528640
# Unit test for function chmod
def test_chmod():
    # No coverage because a better test case
    # is the doc string example.
    pass



# Generated at 2022-06-11 22:44:10.721525
# Unit test for function exists_as
def test_exists_as():
    p = directory_present('./tmp/dir_existing')
    assert exists_as(p) == 'directory'
    p.rmdir()
    f = Path('./tmp/file_existing').touch()
    assert exists_as(f) == 'file'
    f.unlink()
    assert exists_as("./tmp/not_existing") == ''



# Generated at 2022-06-11 22:44:22.317618
# Unit test for function directory_present
def test_directory_present():
    import pytest
    from flutils.pathutils import directory_present, get_target_dir


# Generated at 2022-06-11 22:44:22.893350
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:44:40.548492
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/tmp') == ''
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/ttyS0') == 'char device'



# Generated at 2022-06-11 22:44:43.299816
# Unit test for function chown
def test_chown():
    path = pathlib.Path('.')
    chown(path)
# Set up logging
logger = logging.getLogger(__name__)



# Generated at 2022-06-11 22:44:46.783625
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt.gz') == ''



# Generated at 2022-06-11 22:44:47.350229
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:44:48.222984
# Unit test for function chown
def test_chown():
    assert chown.__doc__



# Generated at 2022-06-11 22:45:00.801253
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    def _test_directory_present(
            path: _PATH,
            include_parent: bool
    ) -> Generator[None, None, None]:
        tmp_dir = TemporaryDirectory()
        try:
            parent = Path(tmp_dir.name).joinpath('sub_dir')
            directory_present(parent, mode=0o700)
            # There is no mention of a parent path that should
            # be created in the docs.
            if include_parent is True:
                path = parent.joinpath(path)
            directory_present(path, mode=0o700)

            assert path.is_dir() is True
        finally:
            tmp_dir.cleanup()


# Generated at 2022-06-11 22:45:09.241287
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils import get_os_user
    from tests import osutils
    user = get_os_user()
    
    def test_pass(path, expected):
        assert exists_as(path) == expected
    def test_fail(path, expected):
        try:
            exists_as(path)
        except Exception as err:
            assert type(err) == type(expected)
        else:
            raise Exception("Test failed to error out")

    path = osutils.TEST_DATA_PATH / 'exists_as.txt'
    test_pass(path, 'file')

    # NOTE: It is not possible to test for the socket
    # type without the socket type being created.

    # Test for broken symlinks
    tmp_path = osutils.TMP_DIR

# Generated at 2022-06-11 22:45:10.807683
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:45:21.789341
# Unit test for function chmod
def test_chmod():

    # Unit test for function chmod
    import tempfile
    for is_file in (True, False):
        with tempfile.TemporaryDirectory() as tmpdirname:
            tmpdirname = Path(tmpdirname)
            if is_file is True:
                tmp_path = tmpdirname / 'flutils_tests_osutils_txt.txt'
                tmp_path.touch()
            else:
                tmp_path = tmpdirname / 'flutils_tests_osutils'
                tmp_path.mkdir()

            assert exists_as(tmp_path, is_file) is True
            mode = 0o660
            chmod(tmp_path, mode_file=mode, mode_dir=mode)
            assert oct(tmp_path.stat().st_mode & 0o777) == oct(mode)



# Generated at 2022-06-11 22:45:28.378275
# Unit test for function chmod
def test_chmod():
    # os.environ['TEST_CHMOD'] = 'True'
    # # Test pattern placed in ~/.zshrc that reads:
    # #   alias emacs="emacsclient -t"
    # # If this is true, then test this pattern
    # if _get_os_user() == 'jeremy':
    #     chmod('~/.zshrc')
    #     return 0

    chmod('/tmp/flutils.tests.osutils.file_target.txt')
    chmod('/tmp/flutils.tests.osutils.dir')
    chmod('/tmp/flutils.tests.osutils.dir_target')
    chmod('/tmp/flutils.tests.osutils.dir/flutils.tests.osutils.file')

# Generated at 2022-06-11 22:45:50.899851
# Unit test for function find_paths
def test_find_paths():
    import tempfile
    tmp_dir = tempfile.mkdtemp(prefix='ut_', dir='/tmp')
    test_dir = Path(tmp_dir).joinpath('test_dir')
    test_dir.mkdir(mode=0o700)

    # Create a test file
    test_file = Path(tmp_dir).joinpath('test_file')
    test_file.touch(mode=0o600)
    test_file.name = 'file_one'

    test_file2 = Path(tmp_dir).joinpath('test_file2')
    test_file2.touch(mode=0o600)
    test_file2.name = 'file_two'

    test_dir2 = Path(tmp_dir).joinpath('test_dir2')

# Generated at 2022-06-11 22:45:51.816311
# Unit test for function chown
def test_chown():
    chown('~/tmp/**')



# Generated at 2022-06-11 22:46:02.359418
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.randomutils import gen_string
    from flutils.testutils import TempDirectory
    from os import getuid, getgid

    with TempDirectory() as tmp_dir:
        p = Path(tmp_dir)
        tmp_file = p / gen_string()
        tmp_file.touch()

        st = os.stat(tmp_file.as_posix())

        chown(
            tmp_file,
            user=getuid(),
            group=getgid(),
        )

        st2 = os.stat(tmp_file.as_posix())

        assert st.st_uid == st2.st_uid
        assert st.st_gid == st2.st_gid

