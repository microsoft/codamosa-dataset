

# Generated at 2022-06-11 22:36:43.522684
# Unit test for function chown
def test_chown():
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import chmod
    from flutils.pathutils import chown

    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name

    path = normalize_path('~/tmp/chown.flutils.tests.osutils')
    chmod(str(path), 0o777)
    chown(str(path), user, group)

    try:
        directory_present(str(path))
        chmod(str(path), 0o777)
        chown(str(path), user, group)
        chown(str(path), user, group)

    finally:
        path_abs

# Generated at 2022-06-11 22:36:45.082905
# Unit test for function chmod
def test_chmod():
    """

    .. todo:: Add tests

    """
    pass



# Generated at 2022-06-11 22:36:52.956795
# Unit test for function chown
def test_chown():
    # Given a directory path that is NOT created
    path = Path(os.path.expanduser('~/tmp/chown')).resolve()
    # When
    chown(path, user='nobody', group='nogroup', include_parent=True)
    # Then it should be created with owner and group
    assert os.lstat(path.as_posix()).st_uid == pwd.getpwnam('nobody').pw_uid
    assert os.lstat(path.as_posix()).st_gid == grp.getgrnam('nogroup').gr_gid

# Generated at 2022-06-11 22:37:06.200550
# Unit test for function chmod
def test_chmod():
    import errno

    from flutils.pathutils import chmod

    from .osutils import RANDOM_STRING, RandomDir

    abs_path = Path(os.getcwd()).as_posix()

    with RandomDir(RANDOM_STRING) as rnd_dir:
        # Test a single file
        file_path = os.path.join(rnd_dir, 'flutils')
        with open(file_path, 'w'):
            pass

        # ... and then test a glob pattern
        with open(os.path.join(rnd_dir, 'flutils.tests'), 'w'):
            pass

        # ... and then test a glob pattern
        with open(os.path.join(rnd_dir, 'flutils.other'), 'w'):
            pass

        # NOTE: Not using parent

# Generated at 2022-06-11 22:37:16.489606
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path'
    path = normalize_path(path)
    # Ensure given path does NOT exist.
    if path.exists():
        path_absent(path)
    # Create a directory, contents and files.
    path.mkdir()
    if path.exists():
        dir_one = path.joinpath('dir_one')
        dir_one.mkdir()
        file_one = dir_one.joinpath('file_one')
        file_one.touch()
        path_absent(path)
        assert(not path.exists())
    # Ensure given path does NOT exist.
    if path.exists():
        path_absent(path)

# Generated at 2022-06-11 22:37:28.113180
# Unit test for function path_absent
def test_path_absent():
    import flutils.pathutils as pt
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    test_path = os.path.join(temp_dir, 'test_path')
    file_path = os.path.join(temp_dir, 'test_path', 'foo.txt')
    dir_path = os.path.join(temp_dir, 'test_path', 'bar')
    # Test 1 - test removing an non-existent path
    pt.path_absent(test_path)
    # Test 2 - test removing a file
    with open(file_path, 'w+') as f:
        f.write('hello')
    pt.path_absent(test_path)
    # Test 3 - test removing a superflous directory

# Generated at 2022-06-11 22:37:30.236339
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'



# Generated at 2022-06-11 22:37:30.780649
# Unit test for function chmod
def test_chmod():
    return



# Generated at 2022-06-11 22:37:36.611819
# Unit test for function path_absent
def test_path_absent():
    # Test empty directory
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = Path(tmpdirname)
        newdir = tmpdir / 'dir_one'
        path_present(newdir)
        path_absent(newdir)
        assert newdir.exists() is False
        # Test empty file
        newfile = tmpdir / 'file_one'
        path_present(newfile)
        path_absent(newfile)
        assert newfile.exists() is False
        # Test symbolic link
        newfile = tmpdir / 'file_one'
        newfile.touch()
        newlink = tmpdir / 'link_one'
        newlink.symlink_to(newfile, target_is_directory=False)
        path_absent(newlink)
        assert newfile

# Generated at 2022-06-11 22:37:45.201903
# Unit test for function exists_as
def test_exists_as():
    from flutils.testingutils import sample_file, sample_directory

    def make_paths_and_assert_exists_as():
        sample_file_path = sample_file(path='/tmp/exists_as.txt')
        assert exists_as(sample_file_path) == 'file'
        sample_directory_path = sample_directory(path='/tmp/exists_as.d')
        assert exists_as(sample_directory_path) == 'directory'
        assert exists_as('/tmp/exists_as/i_dont_exist') == ''

    make_paths_and_assert_exists_as()



# Generated at 2022-06-11 22:38:03.176345
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from tempfile import NamedTemporaryFile, TemporaryDirectory
    with NamedTemporaryFile() as tmpfile:
        path_absent(tmpfile.name)
    with TemporaryDirectory() as tmpdir:
        path_absent(tmpdir)



# Generated at 2022-06-11 22:38:06.800580
# Unit test for function find_paths
def test_find_paths():
    expected = {
        '~/tmp/file_one',
        '~/tmp/dir_one'
    }
    result = {
        path.as_posix()
        for path in find_paths('~/tmp/*')
    }
    assert result == expected

# Generated at 2022-06-11 22:38:17.715938
# Unit test for function find_paths
def test_find_paths():
    """Test the function find_paths()."""
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    from random import random
    from tempfile import temporary_directory

    # Make a temporary test directory.
    with temporary_directory(prefix='flutils_ut_find_paths_test_') as tmpdir:
        # pylint: disable=invalid-name
        root_path = Path(tmpdir)
        sub_path = root_path / 'tmp'
        sub_path.mkdir()

        # Paths to ignore.
        broken_path = sub_path / 'broken_%s' % (random())
        broken_path.touch()

# Generated at 2022-06-11 22:38:29.171902
# Unit test for function exists_as
def test_exists_as():
    from tests.pathutils import random_path
    from tempfile import TemporaryDirectory

    def test_path(path: Path) -> Tuple[Path, str]:
        for fn in path.iterdir():
            if fn.is_dir():
                test_dir(fn)
            else:
                test_file(fn)

    def test_dir(path: Path) -> Tuple[Path, str]:
        assert exists_as(path) == 'directory'
        return path, 'directory'

    def test_file(path: Path) -> Tuple[Path, str]:
        assert exists_as(path) == 'file'
        return path, 'file'

    with TemporaryDirectory() as tmp_path:
        l_file, l_dir = random_path(tmp_path)

# Generated at 2022-06-11 22:38:38.109922
# Unit test for function chown
def test_chown():
    if sys.platform.startswith('win'):
        return

    from tempfile import TemporaryDirectory, mkdtemp
    from subprocess import check_call

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # chown expects unicode
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    with TemporaryDirectory(prefix='flutils_test_') as tmp_dir:
        tmp_path = Path(tmp_dir)
        tmp_sub_path = tmp_path / 'sub_dir'

        os.makedirs(tmp_sub_path.as_posix())

        check_call(['chown', '-R', 'foo:bar', tmp_path.as_posix()])

        uid = getpass.getuser()

# Generated at 2022-06-11 22:38:38.725006
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:38:48.997056
# Unit test for function path_absent
def test_path_absent():
    test_file_1 = normalize_path('~/tmp/test_path/file_one')
    test_file_2 = normalize_path('~/tmp/test_path/file_two')
    test_dir_1 = normalize_path('~/tmp/test_path/dir_one')
    test_dir_2 = normalize_path('~/tmp/test_path/dir_two')
    test_dir_3 = normalize_path('~/tmp/test_path/dir_one/dir_three')
    test_dir_4 = normalize_path('~/tmp/test_path/dir_one/dir_four')
    test_dir_5 = normalize_path('~/tmp/test_path/dir_one/dir_three/dir_five')
    test_dir_6 = normal

# Generated at 2022-06-11 22:38:51.614255
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as(Path(__file__).parent) == 'directory'

# Generated at 2022-06-11 22:39:00.753922
# Unit test for function find_paths
def test_find_paths():
    from glob import glob
    from pathlib import Path
    from tempfile import mkdtemp, mkstemp

    from flutils.pathutils import find_paths

    # Create all the actual paths
    tmp_dir = Path(mkdtemp())

    # Create the test file paths
    file1_path = tmp_dir / 'file_one'
    file1_path.touch()
    file2_path = tmp_dir / 'file_two'
    file2_path.touch()

    # Create the test directory paths
    dir1_path = tmp_dir / 'dir_one'
    dir1_path.mkdir()
    dir2_path = tmp_dir / 'dir_two'
    dir2_path.mkdir()

    # Test with the pathlib.Path object

# Generated at 2022-06-11 22:39:11.616803
# Unit test for function find_paths
def test_find_paths():
    pattern = normalize_path('~/tmp')
    # Test that the pattern is a Path() object.
    assert isinstance(pattern, Path)

    # Test that the pattern has a length of two elements.
    assert len(pattern.parts) == 2

    assert pattern.parts[0] == '~'
    assert pattern.parts[1] == 'tmp'

    # Test that '/home/test_user/tmp' is the absolute path.
    assert pattern.as_posix() == '/home/test_user/tmp'

    # Test that the resolved path is '/home/test_user/tmp'.
    assert pattern.resolve().as_posix() == '/home/test_user/tmp'

    # Test that the pattern has an absolute path.
    assert pattern.is_absolute() == True
    # Test that the pattern is a directory

# Generated at 2022-06-11 22:39:28.022708
# Unit test for function chown
def test_chown():
    assert 1 == 1


# Generated at 2022-06-11 22:39:42.577770
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import stat
    import time
    import tempfile

    from flutils.pathutils import chown

    temp_dir = tempfile.mkdtemp()

    #
    # Test a basic file
    #
    path = Path(temp_dir) / 'testownership.txt'
    path.touch()
    chown(path, 'wheel', 'wheel')
    assert (os.stat(path.as_posix()).st_uid == 0) and (os.stat(path.as_posix()).st_gid == 0)
    path.unlink()

    #
    # Test a basic directory
    #
    path = Path(temp_dir) / 'testownership.dir'
    path.mkdir()
    chown(path, 'wheel', 'wheel')

# Generated at 2022-06-11 22:39:57.626260
# Unit test for function chown
def test_chown():
    with tempfile.TemporaryDirectory() as tmpdir:
        child_path = os.path.join(tmpdir, 'child')
        os.makedirs(child_path)
        parent_path = os.path.join(tmpdir, 'parent')
        os.makedirs(parent_path)
        with open(os.path.join(child_path,
                               'child.txt'), 'w') as c_file:
            c_file.write('child')
        with open(os.path.join(parent_path,
                               'parent.txt'), 'w') as p_file:
            p_file.write('parent')
        chown(os.path.join(tmpdir, '*'))
        assert os.getuid() == os.stat(child_path).st_uid
        assert os.get

# Generated at 2022-06-11 22:39:59.593987
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-11 22:40:10.603687
# Unit test for function path_absent
def test_path_absent():
    tmp_dir: Path = Path('~/tmp').expanduser()
    test_dir: Path = tmp_dir / 'test_path'
    test_dir = test_dir.resolve()
    test_sub_dir: Path = test_dir / 'test_sub_dir'
    test_sub_dir = test_sub_dir.resolve()
    test_file: Path = test_dir / 'test_file'
    test_file = test_file.resolve()
    test_sub_file: Path = test_sub_dir / 'test_sub_file'
    test_sub_file = test_sub_file.resolve()

    if not tmp_dir.exists():
        tmp_dir.mkdir()

    # Create the test files and directories
    test_dir.mkdir()
    test_sub_

# Generated at 2022-06-11 22:40:22.649660
# Unit test for function chown
def test_chown():
    from . import assert_paths_equal
    from . import tempfile_context
    from . import tempdir_context
    from .. import pathutils
    from .. import osutils

    # Normal usage
    # =========================================================================
    with tempdir_context() as tmpdir:
        testdir = Path(tmpdir) / 'testdir'
        testdir.mkdir()
        testfile = testdir / 'testfile.txt'
        testfile.touch()
        pathutils.chown(testdir)
        osutils.chown(testfile, user='-1')
        osutils.chown(testfile, user='-1', group='-1')
        osutils.chown(testfile, user='root', group='root')

    # Path().glob patterns
    # =========================================================================

# Generated at 2022-06-11 22:40:28.445285
# Unit test for function chmod
def test_chmod():
    import pytest

    with pytest.raises(TypeError):
        chmod(path=None)

    tmp = Path('~/tmp').expanduser()
    if not tmp.exists():
        tmp.mkdir(mode=0o770)

    _file = tmp / 'flutils.tests.osutils.test_chmod.txt'
    _file.write_text('')
    _file.chmod(0o700)
    assert _file.exists() is True
    assert _file.is_file() is True
    assert _file.stat().st_mode & 0o777 == 0o700

    chmod(str(_file), 0o660)
    assert _file.stat().st_mode & 0o777 == 0o660

    chmod('~/tmp/**', include_parent=True)
   

# Generated at 2022-06-11 22:40:40.718606
# Unit test for function exists_as
def test_exists_as():
    tmpdir = Path().cwd().resolve() / Path('tmp')
    # Create a temp directory for testing
    if not tmpdir.exists():
        tmpdir.mkdir()
    # Create a temp file for testing
    testfile = tmpdir / Path('test.txt')
    if not testfile.exists():
        testfile.touch()
    # Create a symlink for testing
    tmpdir_link = Path().cwd().resolve() / Path('tmp_link')
    if not tmpdir_link.exists():
        tmpdir_link.symlink_to(tmpdir)
    assert exists_as(testfile) == 'file'
    assert exists_as(tmpdir) == 'directory'
    assert exists_as(tmpdir_link) == 'directory'
    # Delete test file

# Generated at 2022-06-11 22:40:50.917870
# Unit test for function find_paths

# Generated at 2022-06-11 22:40:55.513326
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('./tests/flutils/tmp/')
    assert path == Path('./tests/flutils/tmp/')
    assert path.is_dir()
    path.rmdir()



# Generated at 2022-06-11 22:41:33.260849
# Unit test for function directory_present
def test_directory_present():
    from .temppath import TempPath
    from .osutils import sudo
    with TempPath() as temp_path:
        path = normalize_path(temp_path.path).joinpath('test_path')
        path_str = path.as_posix()
        result = directory_present(path_str)
        assert result.as_posix() == path_str
        assert result.is_dir()
        assert exists_as(path_str) == 'directory'
    with TempPath() as temp_path:
        path = normalize_path(temp_path.path).joinpath('test_path')
        path_str = path.as_posix()
        directory_present(path_str)
        assert exists_as(path_str) == 'directory'

# Generated at 2022-06-11 22:41:44.753495
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    new_path = directory_present(Path(__file__).parent)
    assert isinstance(new_path, PosixPath)
    assert new_path == Path(__file__).parent

    new_path = directory_present(Path(__file__).parent, user='-1')
    assert isinstance(new_path, PosixPath)
    assert new_path == Path(__file__).parent

    new_path = directory_present(Path(__file__).parent, group='-1')
    assert isinstance(new_path, PosixPath)
    assert new_path == Path(__file__).parent

    new_path = directory_present(Path(__file__).parent, 0o770, '-1', '-1')

# Generated at 2022-06-11 22:41:45.383901
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:41:54.949627
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('~/tmp/*')
    pattern_dir = Path('~/tmp/*/')
    pattern_dir_recursive = Path('~/tmp/**/')
    list_pattern = list(find_paths(pattern))
    list_pattern_dir = list(find_paths(pattern_dir))
    list_pattern_dir_recursive = list(find_paths(pattern_dir_recursive))
    assert len(list_pattern) == 2
    assert len(list_pattern_dir) == 2
    assert len(list_pattern_dir_recursive) == 4



# Generated at 2022-06-11 22:41:56.211493
# Unit test for function chown
def test_chown():
    assert not False


# Generated at 2022-06-11 22:41:56.589843
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:57.514379
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'

# Generated at 2022-06-11 22:42:09.179498
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import user_in_group
    import pytest

    pw = get_os_user()
    gr = get_os_group()

    with pytest.raises(OSError):
        chown('/tmp', user='foobar')

    with pytest.raises(OSError):
        chown('/tmp', group='foobar')

    chown('/tmp', user=pw.pw_name)
    assert user_in_group(pw, gr) is True

    chown('/tmp', user='-1')
    assert user_in_group(pw, gr) is False



# Generated at 2022-06-11 22:42:10.707125
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'



# Generated at 2022-06-11 22:42:19.595048
# Unit test for function find_paths
def test_find_paths():
    """Provide unit tests for the find_paths function."""
    file_one = Path('/var/tmp/file_one').touch()
    dir_one = Path('/var/tmp/dir_one').mkdir()
    test_list = list(find_paths('/var/tmp/*'))
    assert file_one in test_list and dir_one in test_list
    file_one.unlink()
    dir_one.rmdir()



# Generated at 2022-06-11 22:42:54.146603
# Unit test for function chmod
def test_chmod():
    # test_chmod_file
    f = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    f.write_text('')
    chmod(f, mode_file=0o660)
    # test_chmod_dir
    dir_path = Path(__file__).parent / 'tests'
    os.chmod(dir_path, 0o000)
    chmod(dir_path, mode_dir=0o770)
    assert str(dir_path.stat().st_mode).endswith('770')
    # test_chmod_dir_recursive
    dir_path = Path(__file__).parent / 'tests'
    os.chmod(dir_path, 0o000)

# Generated at 2022-06-11 22:43:01.292252
# Unit test for function find_paths
def test_find_paths():
    test_path = Path(tempfile.gettempdir()) / 'find_paths_test'
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    assert (test_path / 'sub1').mkdir()
    assert (test_path / 'sub2').mkdir()
    assert (test_path / 'sub1' / 'subsub1').mkdir()
    assert (test_path / 'sub1' / 'subsubsub1').mkdir()
    assert (test_path / 'sub1' / 'subsubsub2').mkdir()

    assert len(list(find_paths(test_path / 'sub1' / '**'))) == 5
    assert len(list(find_paths(test_path / 'sub1'))) == 2

# Generated at 2022-06-11 22:43:09.695838
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory, TemporaryFile
    from flutils.pathutils import directory_present

    with TemporaryDirectory() as td:
        td = Path(td)
        tmp = directory_present(td / 'tmp')
        assert tmp.is_dir() is True

        td_file = directory_present(td / 'file')
        assert td_file.is_file() is True

    with TemporaryFile() as f:
        try:
            directory_present(f)
        except ValueError as e:
            assert str(e) == (
                'The path: %r must be an absolute path.  A path is considered '
                'absolute if it has both a root and (if the flavour allows) a '
                'drive.' % f.name
            )


# Generated at 2022-06-11 22:43:12.812742
# Unit test for function find_paths
def test_find_paths():
    result = list(find_paths('~/tmp/*'))
    assert result == [PosixPath('/home/test_user/tmp/file_one'),
                      PosixPath('/home/test_user/tmp/dir_one')]


# Generated at 2022-06-11 22:43:23.985692
# Unit test for function find_paths
def test_find_paths():
    import os

    with directory_present(os.path.join('~', 'tmp', 'find_paths')) as tmp_dir:
        tmp_dir = Path(tmp_dir)

        file_one = tmp_dir.joinpath('file_one')
        file_one.touch()

        file_two = tmp_dir.joinpath('file_two')
        file_two.touch()

        file_three = tmp_dir.joinpath('dir_one', 'file_three')
        file_three.parent.mkdir()
        file_three.touch()

        result = find_paths(tmp_dir.joinpath('*'))

        expected = [file_one, file_two]

        assert result
        assert list(result) == expected


# Generated at 2022-06-11 22:43:34.061800
# Unit test for function find_paths
def test_find_paths():
    tmpdir = tmpdir_factory.mktemp('test_find_paths')
    os.chdir(tmpdir)

    # Create a set of dummy directories and files to test with
    test_dir_set = [
        Path('test_dir/test1/t1/test1.txt'),
        Path('test_dir/test1/test1.txt'),
        Path('test_dir/test2/test2.txt'),
        Path('test_dir/test3/test3.txt'),
        Path('test_dir/test3/test_link')
    ]
    for test_path in test_dir_set:
        directory_present(test_path.parent, mode=0o777)
        test_path.touch(mode=0o666)

    # Create a set of symbolic links.

# Generated at 2022-06-11 22:43:40.532634
# Unit test for function find_paths
def test_find_paths():
    pattern = '~/tmp/*'
    paths = find_paths(pattern)
    assert isinstance(paths, Generator)
    assert list(paths) == [
        PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one'),
    ]



# Generated at 2022-06-11 22:43:51.152048
# Unit test for function find_paths
def test_find_paths():
    import io
    import os
    import shutil
    import tempfile


# Generated at 2022-06-11 22:44:02.187131
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir).resolve()
        subdir = tmpdir / 'subdir'
        subdir.mkdir()

        for name in ('file1', 'file2'):
            # create file
            with open(subdir / name, 'w') as f:
                f.write('')

        # Test that it works on a single file
        chmod(subdir / 'file1', mode_file=0o640)
        s = os.stat(subdir / 'file1')
        assert stat.S_ISREG(s.st_mode)
        assert s.st_mode & 0o777 == 0o640

        # Test that it works on a directory
        chmod(subdir, mode_dir=0o755)

# Generated at 2022-06-11 22:44:11.450206
# Unit test for function chmod
def test_chmod():
    from unittest import mock

    from pyfakefs.fake_filesystem_unittest import TestCase

    from flutils.pathutils import chmod

    with mock.patch('flutils.pathutils.normalize_path', autospec=True):
        with mock.patch('pathlib.Path.glob', autospec=True):

            test_case = TestCase()
            test_case.setUpPyfakefs()

            p = Path('/tmp/flutils.tests.pathutils.txt')
            p.parent.mkdir(parents=True)
            p.touch()

            chmod('/tmp/**')

# Generated at 2022-06-11 22:44:20.026353
# Unit test for function exists_as
def test_exists_as():
    """Test the function :func:`flutils.pathutils.exists_as`."""
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-11 22:44:27.821591
# Unit test for function chown
def test_chown():
    from textwrap import dedent
    from flutils.tests.helpers import capture_io
    from flutils.pathutils import (
        chown,
        get_os_user,
    )

    with capture_io() as (out, err):
        chown('/var/tmp/foo.txt')
        assert out.getvalue().strip() == dedent('''\
        No path listed to change ownership of.
        ''').strip()

    user = get_os_user()
    with capture_io() as (out, err):
        chown(os.devnull)
        assert out.getvalue().strip() == dedent('''\
        Changing ownership of /dev/null to '{}:{}'
        '''.format(user.pw_name, user.pw_gid)).strip()

   

# Generated at 2022-06-11 22:44:33.181134
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import get_unique_name
    from flutils.systemutils import get_user

    path = get_unique_name()
    user = get_user()

    directory_present(path)
    assert exists_as(path) == 'directory'

    group = get_group(user)
    directory_present(path, group=group)
    assert exists_as(path) == 'directory'

    directory_present(path, mode=0o770)
    assert exists_as(path) == 'directory'

    directory_present(path, mode=0o770, user=user)
    assert exists_as(path) == 'directory'



# Generated at 2022-06-11 22:44:43.816927
# Unit test for function path_absent
def test_path_absent():
    new_file = normalize_path('~/tmp/test_path/file_one')
    new_dir = normalize_path('~/tmp/test_path/dir_one')
    new_dir = new_dir.as_posix()
    new_dir = cast(str, new_dir)
    new_file = new_file.as_posix()
    new_file = cast(str, new_file)
    path_present(new_dir, mode=0o700)
    with open(new_file, 'w') as fh:
        fh.write('prefix: /home/test_user/tmp/test_path/file_one')
    path_absent('~/tmp/test_path')
    assert not os.path.exists(new_dir)

# Generated at 2022-06-11 22:44:45.063861
# Unit test for function chown
def test_chown():
    try:
        assert chown('~/tmp/**')
    except Exception:
        print("test_chown failed.")
        assert False



# Generated at 2022-06-11 22:44:51.572574
# Unit test for function exists_as
def test_exists_as():
    with directory_present('./tmp/'):
        file_path = Path('./tmp/flutils.tests.pathutils.txt')
        file_path.touch()
        assert exists_as(file_path) == 'file'
        file_path.unlink()
        assert exists_as(file_path) == ''

        link_path = Path('./tmp/flutils.tests.pathutils.link')
        if link_path.exists():
            link_path.unlink()
        link_path.symlink_to(file_path)
        assert exists_as(link_path) == 'file'



# Generated at 2022-06-11 22:45:03.069603
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    with TemporaryDirectory() as tmpdir_name:
        from pathlib import Path
        from flutils.pathutils import find_paths
        from flutils.pathutils import normalize_path

        test_path = Path(tmpdir_name).joinpath('test_path')
        test_path.mkdir()
        sub_paths = ['sub_file', 'sub_dir']
        for path in sub_paths:
            test_path.joinpath(path).touch()

        # Must include the empty string to recognize the end of the glob
        # pattern.
        test_glob_pattern = (
            'test_*/sub_*',
            'test_*',
            'test_*/sub_?'
        )

# Generated at 2022-06-11 22:45:15.258941
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod, find_paths, path_absent

    path = '~/tmp/flutils.tests.osutils.1.txt'

    path = chmod(path, 0o660)
    assert path is None

    paths = find_paths('~/tmp/flutils.tests.osutils.*.txt')
    assert paths
    for p in paths:
        assert p.stat().st_mode == 33188

    path = '~/tmp/flutils.tests.osutils.*.txt'
    path = chmod(path, 0o660)
    assert path is None

    paths = find_paths('~/tmp/flutils.tests.osutils.*.txt')
    assert paths
    for p in paths:
        assert p.stat().st_mode == 33188


# Generated at 2022-06-11 22:45:24.379943
# Unit test for function chown
def test_chown():
    path = normalize_path('/tmp/flutils.tests.osutils.txt')
    with path.open('w'):
        pass
    try:
        chown(path, include_parent=True)
    finally:
        path.unlink()
    path = normalize_path('/tmp/flutils.tests.osutils.txt')
    with path.open('w'):
        pass
    try:
        chown('/tmp/flutils.tests.osutils.*', include_parent=True)
    finally:
        if path.exists():
            path.unlink()
    path = normalize_path('/tmp/flutils.tests.osutils.txt')
    with path.open('w'):
        pass

# Generated at 2022-06-11 22:45:35.958411
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    from os import environ
    from os import mkdir
    from os import remove
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        absolute_path = tmpdir / 'tmp/file_one'
        with absolute_path.open('wb') as file_obj:
            file_obj.write(b'foo')

        environ['HOME'] = str(tmpdir)
        home_path = tmpdir / 'tmp/file_one'
        relative_path = tmpdir / 'tmp/dir_one'
        glob_path = tmpdir / 'tmp/*'

        assert str(absolute_path) == str(next(find_paths(absolute_path)))

# Generated at 2022-06-11 22:45:50.483986
# Unit test for function chown
def test_chown():
    from flutils.pathutils import tmpdir
    from flutils.pathutils import touch
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_uid
    from flutils.osutils import get_os_gid
    import tempfile

    c_user = get_os_user().pw_name
    c_group = get_os_group().gr_name

    # Normal error checking
    with pytest.raises(OSError):
        chown(tmpdir(), user='foo')
    with pytest.raises(OSError):
        chown(tmpdir(), group='bar')

    # Test when the path is

# Generated at 2022-06-11 22:46:01.824084
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from tempfile import TemporaryDirectory
    import shutil

    def build_test_dir():
        tmpdir = TemporaryDirectory()
        path = Path(tmpdir.name)
        sub_dir_one = path.joinpath('test_dir_one')
        sub_dir_one.mkdir()
        sub_dir_two = path.joinpath('test_dir_two')
        sub_dir_two.mkdir()
        test_file_one = sub_dir_one.joinpath('test_file_one.txt')
        test_file_one.touch()
        test_file_two = sub_dir_two.joinpath('test_file_two.txt')
        test_file_two.touch()