

# Generated at 2022-06-11 22:36:13.338543
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:36:24.269103
# Unit test for function directory_present
def test_directory_present():
    tmp_path = '~/tmp/flutils/pathutils/test_directory_present/'
    tmp = directory_present(tmp_path)

    # The path was normalized
    assert tmp == Path('/Users/len/tmp/flutils/pathutils/test_directory_present')

    # The path was created AND the parent directories were created
    assert tmp.exists()

    # The path was created as a directory
    assert tmp.is_dir()

    # The path was created with mode 700
    assert tmp.stat().st_mode == 0o40700

    # The path was created with the current user as the owner
    assert tmp.stat().st_uid == get_os_user().pw_uid

    # The path was created with the current user's group as the group
    assert tmp.stat().st_gid == get_os

# Generated at 2022-06-11 22:36:27.506287
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770) is None
    assert chmod('~/tmp/*') is None

# Function chown

# Generated at 2022-06-11 22:36:35.748886
# Unit test for function chmod
def test_chmod():
    def _chmod(**kwargs):
        chmod(**kwargs)

    from hypothesis import assume
    from hypothesis import given
    from hypothesis.strategies import booleans
    from hypothesis.strategies import integers
    from hypothesis.strategies import sampled_from
    from hypothesis.strategies import text
    from pathlib import Path
    from pytest import fail
    from tempfile import TemporaryDirectory

    from pathutils import config


# Generated at 2022-06-11 22:36:45.461064
# Unit test for function chown
def test_chown():
    """
    ::

        $ pytest tests/pathutils/test_pathutils.py::test_chown
    """
    import shutil
    import tempfile

    import flutils.pathutils

    path = Path(tempfile.mkdtemp(), 'flutils.tests.pathutils.txt')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch()
    path.chmod(0o600)
    path.chown(getpass.getuser(), -1)
    user_info = pwd.getpwnam(getpass.getuser())


# Generated at 2022-06-11 22:36:48.306214
# Unit test for function chown
def test_chown():
    """Test chown function."""
    chown(path='~/tmp/flutils.tests.osutils.txt', user='-1', group='-1')


# Generated at 2022-06-11 22:36:50.316894
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()
    import flutils
    assert flutils.testing.user_name == get_os_user().pw_name


# Generated at 2022-06-11 22:36:53.321874
# Unit test for function get_os_user
def test_get_os_user():
    assert pwd.getpwuid(os.getuid()) == get_os_user()
    assert get_os_user(-1) == pwd.getpwuid(-1)



# Generated at 2022-06-11 22:37:04.590577
# Unit test for function find_paths
def test_find_paths():
    """Test find_paths"""
    # Setup
    path = Path('~/tmp')
    if not path.exists():
        path.mkdir()
    Path('~/tmp/file_one').touch()
    Path('~/tmp/dir_one').mkdir()

    # Function under test
    listed_paths = list(find_paths('~/tmp/*'))

    # Asserts
    assert Path('~/tmp/file_one') in listed_paths
    assert Path('~/tmp/dir_one') in listed_paths

    # Clean up
    Path('~/tmp').rmdir()


# Generated at 2022-06-11 22:37:15.227485
# Unit test for function chmod
def test_chmod():
    from os import mkdir
    from os.path import isdir
    from shlex import split
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent
    from unittest import TestCase
    from unittest.mock import MagicMock, patch
    from flutils.pathutils import chmod
    from flutils.randomutils import random_password

    _SYSPATH = sys.path[:]
    sys.path.append('/usr/local/lib')
    import pwd, grp
    sys.path = _SYSPATH[:]

    class _Test(TestCase):
        _wd = ''
        _usr = ''

        def setUp(self):
            self._wd = mkdtemp(prefix='unit-test-flutils-')
            self._usr = getpass

# Generated at 2022-06-11 22:37:34.072673
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    import subprocess
    from subprocess import PIPE
    from tempfile import TemporaryFile
    from flutils.pathutils import exists_as
    tmp_dir = Path() / 'tmp' / 'flutils' / 'tests'
    tmp_dir.mkdir(parents=True, exist_ok=True)
    txt_file = tmp_dir.joinpath('exists_as_test.txt')
    txt_file.write_text('Text')
    assert exists_as(txt_file) == 'file'
    assert exists_as(tmp_dir) == 'directory'
    # Create a broken symbolic link

# Generated at 2022-06-11 22:37:36.889677
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    path = exists_as('~/tmp')
    assert path == 'directory'
test_exists_as()


# Generated at 2022-06-11 22:37:46.059802
# Unit test for function path_absent
def test_path_absent():
    """Tests that directory and its contents are removed."""

    # Create a directory and two files.  Then remove them
    test_dir = Path(tempfile.mkdtemp())
    try:
        for n in ('test_file_one', 'test_file_two'):
            Path(test_dir, n).write_text('bar', 'utf-8')
        path_absent(test_dir)
        assert Path(test_dir).is_dir() is False
        assert Path(test_dir, 'test_file_one').is_file() is False
        assert Path(test_dir, 'test_file_two').is_file() is False
    finally:
        path_absent(test_dir)



# Generated at 2022-06-11 22:37:51.402688
# Unit test for function exists_as
def test_exists_as():
    from . import cleanup
    from . import get_test_dir
    from . import touch

    test_dir = get_test_dir()
    cleanup(**{'recursive': True})

    assert exists_as(test_dir) == ''

    test_dir.mkdir(mode=0o700)
    assert exists_as(test_dir) == 'directory'

    test_file = touch(test_dir.joinpath('.test_osutils_path_utils'))
    assert exists_as(test_file) == 'file'

    import posix

# Generated at 2022-06-11 22:37:57.965845
# Unit test for function chmod
def test_chmod():
    # Type check: (PathLike, optional int, optional int, optional bool) -> None
    assert callable(chmod)

    # Ensures function raises TypeError if invalid types are given.
    with pytest.raises(TypeError):
        chmod(None)                # type: ignore

    # Ensures function raises TypeError if invalid types are given.
    with pytest.raises(TypeError):
        chmod(1)                   # type: ignore

    # Ensures function raises TypeError if invalid types are given.
    with pytest.raises(TypeError):
        chmod(b'file')             # type: ignore

    # Ensures function raises TypeError if invalid types are given.
    with pytest.raises(TypeError):
        chmod('file', None)        # type: ignore

    # Ensures function raises TypeError if

# Generated at 2022-06-11 22:37:58.932869
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:38:06.305990
# Unit test for function find_paths
def test_find_paths():
    from .osutils import get_test_file

    path = get_test_file(__file__, 'test_find_paths.txt')
    path.touch()
    path = path.parent / 'test_find_paths.d'
    path.mkdir()
    path.mkdir()
    pattern = path.parent / '*'
    expected = [x.name for x in find_paths(pattern)]
    path.parent.rmdir()
    assert expected == ['test_find_paths.d', 'test_find_paths.d.1']



# Generated at 2022-06-11 22:38:09.312857
# Unit test for function directory_present
def test_directory_present():
    assert str(directory_present('/tmp/foo/bar/baz')) == '/tmp/foo/bar/baz'



# Generated at 2022-06-11 22:38:15.991731
# Unit test for function exists_as
def test_exists_as():
    """Test the normalization of paths in exists_as."""
    path = '/Users/len/Documents/flutils/flutils/pathutils.py'
    assert exists_as(path) == 'file'

    path = '~/tmp'
    assert exists_as(path) == 'directory'

    path = '~/fake_path'
    assert exists_as(path) == ''

# Generated at 2022-06-11 22:38:27.803546
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    import osutils
    from osutils import make_dir
    from osutils import make_file

    def _chown(path, user, group, content=None):
        osutils.chown(path, user, group)
        if content is not None:
            osutils.write_text(path, content)

    make_dir('~/tmp/foo/bar')
    make_file('~/tmp/foo/bar/file.txt')
    make_file('~/tmp/foo/bar/baz/file.txt')
    _chown('~/tmp/foo/bar/baz/file.txt', 'foo', 'bar', 'baz')
    _chown('~/tmp/foo/bar/file.txt', 'foo', 'bar', 'foo')
    ch

# Generated at 2022-06-11 22:38:46.055036
# Unit test for function directory_present
def test_directory_present():
    log_values_to_stdout = functools.partial(
        print,
        'Chmod: {}, chown: {}'.format(
            str(os.stat(path).st_mode).zfill(4),
            (os.stat(path).st_uid, os.stat(path).st_gid)
        )
    )

    path = '/tmp/foo/bar/baz/a'
    directory_present(path)
    log_values_to_stdout()
    assert os.stat(path).st_mode == 0o40700
    assert os.stat(path).st_uid == os.geteuid()
    assert os.stat(path).st_gid == os.getgid()

    path = '/tmp/foo/bar/baz/b'

# Generated at 2022-06-11 22:38:53.616403
# Unit test for function path_absent
def test_path_absent():
    import os
    import tempfile
    import uuid
    from pathlib import Path

    from flutils.pathutils import path_absent

    path1 = Path(tempfile.gettempdir()).joinpath(str(uuid.uuid4()))
    path1.mkdir()
    path2 = path1.joinpath(str(uuid.uuid4()))
    path2.mkdir()
    path3 = path2.joinpath(str(uuid.uuid4()))
    path3.mkdir()
    file1 = path1.joinpath(str(uuid.uuid4()))
    os.symlink(path3.as_posix(), file1.as_posix())
    file2 = path2.joinpath(str(uuid.uuid4()))
    os.syml

# Generated at 2022-06-11 22:39:01.739971
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import random
    import string

    # Directory
    tmp = tempfile.mkdtemp()
    try:
        fn = os.path.join(tmp, 'flutils.tests.pathutils.txt')
        fn_dir = os.path.join(tmp, 'dir')

        os.makedirs(fn_dir)
        open(fn, 'a').close()

        chmod(fn)
        chmod(fn_dir)

        assert os.stat(fn).st_mode == 33152
        assert os.stat(fn_dir).st_mode == 16895

    finally:
        shutil.rmtree(tmp)

    # File
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-11 22:39:02.154073
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:39:12.112760
# Unit test for function chmod
def test_chmod():
    import group as group_mod
    import pwd as pwd_mod
    import shutil
    import stat
    import tempfile
    import unittest


# Generated at 2022-06-11 22:39:26.860023
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""

    _test_path = Path(sys.argv[0]).with_suffix('.exists_as')
    # Test with a path that does not exist.
    assert exists_as(_test_path) == ''

    # Test with a path that exists
    _test_path.touch()
    assert exists_as(_test_path) == 'file'

    # Test with a path that exists but is a directory.
    _test_path.unlink()
    _test_path.mkdir(mode=0o700)
    assert exists_as(_test_path) == 'directory'

    # Test with a path that exists but is a broken symbolic link.
    _test_path.unlink()  # remove the directory

# Generated at 2022-06-11 22:39:27.954596
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:39:42.539594
# Unit test for function find_paths
def test_find_paths():
    test_tmp_path = Path(tempfile.mkdtemp())

    # Create test files, including the tempfile.mkdtemp()
    # directory.
    assert test_tmp_path.exists() is True 

    file_one = test_tmp_path / 'file_one'
    file_one.touch()
    assert file_one.exists() is True 

    dir_one = test_tmp_path / 'dir_one'
    dir_one.mkdir()
    assert dir_one.exists() is True 

    dir_two = test_tmp_path / 'dir_one' / 'dir_two'
    dir_two.mkdir()
    assert dir_two.exists() is True 

    file_two = test_tmp_path / 'dir_one' / 'file_two'
   

# Generated at 2022-06-11 22:39:57.578850
# Unit test for function exists_as
def test_exists_as():
    from tempfile import mkdtemp
    from os import rmdir
    from pathlib import Path

    if os.name != 'nt':
        # Test a non-existent path
        assert exists_as('~/bad_path') == ''

        # Test a path that exists as a directory
        assert exists_as('~/tmp') == 'directory'

        # Test a path that exists as a file
        assert exists_as('~/tmp/flutils.tests.pathutils.txt') == 'file'

        # Test a path that exists as a socket
        tmp_path = Path(mkdtemp(prefix='flutils.tests.osutils.'))
        tmp_path.touch()
        assert exists_as(tmp_path) == 'file'
        tmp_path.unlink()

        # Test a path that exists as a broken symbolic link


# Generated at 2022-06-11 22:40:09.276049
# Unit test for function exists_as
def test_exists_as():
    # Create a temporary directory for the tests.
    test_dir = mkdtemp()

# Generated at 2022-06-11 22:40:16.367785
# Unit test for function exists_as
def test_exists_as():
    # When the given path does not exist...
    assert exists_as('path/does/not/exist') == ''



# Generated at 2022-06-11 22:40:28.300500
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present, path_absent
    from os import chmod, chown
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from unittest.mock import patch

    class TestDirectoryPresent(TestCase):
        @patch('stat.S_IMODE')
        def test_directory_present(self, *args):
            mode = 0o700
            path = 'foo'
            tmp_dir = TemporaryDirectory()
            parent_dir = directory_present(tmp_dir.name)
            tmp_dir_path = parent_dir / path
            tmp_dir_path.mkdir()

            captured_path_dir = directory_present(tmp_dir_path)

            self.assertEqual(tmp_dir_path, captured_path_dir)


# Generated at 2022-06-11 22:40:35.032970
# Unit test for function path_absent
def test_path_absent():
    test_path = os.path.join('~', 'tmp', 'test_path')
    try:
        os.mkdir(test_path)
        path_absent(test_path)
        assert not os.path.exists(test_path)
    finally:
        if os.path.exists(test_path):
            path_absent(test_path)



# Generated at 2022-06-11 22:40:39.598014
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory(prefix='flutils.test_find_paths') as tmp_dir:
        tmp_path = Path(tmp_dir)
        tmp_path.joinpath('file_one').touch()
        tmp_path.joinpath('dir_one').mkdir()
        tmp_path.joinpath('hidden_file').touch(exist_ok=True)

        tmp_path.joinpath('dir_one/file_two').touch()
        tmp_path.joinpath('dir_one/dir_two').mkdir()
        tmp_path.joinpath('dir_one/dir_two/dir_three').mkdir()
        tmp_path.joinpath('dir_one/dir_two/dir_three/file_three').touch()

# Generated at 2022-06-11 22:40:44.122334
# Unit test for function exists_as
def test_exists_as():
    path = Path('~/tmp/flutils.tests.osutils.txt')
    if path.is_file() is False:
        path.touch()
    assert exists_as(path) == 'file', \
        'exists_as(path) == \'file\' failed with: %r' % path.as_posix()
    return True
# Test for function exists_as
test_exists_as()



# Generated at 2022-06-11 22:40:55.560619
# Unit test for function chmod
def test_chmod():
    path = Path(__file__).parent / 'tmp' / 'foo.txt'

    if path.is_file() is True:
        sys.exit(1)

    try:
        # create a file
        Path(path).touch()

        # chmod it and change the mode to 0644
        chmod(path, mode_file=0o644)
        if os.stat(path.as_posix()).st_mode & 0o777 == 0o644:
            sys.exit(0)
        else:
            sys.exit(1)
    finally:
        try:
            Path(path).unlink()
        except Exception:
            sys.exit(1)

    sys.exit(0)



# Generated at 2022-06-11 22:41:07.290352
# Unit test for function directory_present
def test_directory_present():
    """Test the flutils.pathutils.directory_present function."""
    import shutil

    # Ensure the given path is processed as an absolute path.
    path = directory_present('tmp')
    assert path.is_absolute()

    shutil.rmtree(path.as_posix())

    # Ensure the path will be created with a default mode of 0o700.
    directory_present('tmp/test_path')
    stat = os.stat('tmp/test_path')
    assert stat.st_mode == 448

    shutil.rmtree('tmp')

    # Ensure the path will be created with the given mode.
    directory_present('tmp/test_path', mode=0o444)
    stat = os.stat('tmp/test_path')
    assert stat.st_mode == 292

    # Ensure the path will be

# Generated at 2022-06-11 22:41:18.357420
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(UnixPath('/tmp/')) == 'directory'
    assert exists_as(WindowsPath('C:\\Windows\\')) == 'directory'
    assert exists_as(WindowsPath('C:\\Windows\\foo.txt')) == 'file'
    assert exists_as(WindowsPath('C:\\')) == ''
    assert exists_as(WindowsPath('C:\\foo')) == ''
    assert exists_as(UnixPath('/tmp/foo')) == ''
    assert exists_as(UnixPath('/tmp/foo.txt')) == ''
    assert exists_as(UnixPath('/etc')) == 'directory'
    assert exists_as(UnixPath('/etc/foo')) == ''

# Generated at 2022-06-11 22:41:20.775455
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    with directory_present('/tmp/flutils.tests.pathutils.txt'):
        pass



# Generated at 2022-06-11 22:41:29.228272
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as."""
    from flutils.pathutils import exists_as
    import platform

    assert exists_as(__file__) == 'file'
    assert exists_as(os.path.dirname(__file__)) == 'directory'

    if platform.system() == 'Linux':
        assert exists_as('/proc/self') == 'directory'
        assert exists_as('/dev/null') == 'char device'
        assert exists_as('/dev/random') == 'char device'
        assert exists_as('/dev/urandom') == 'char device'
        assert exists_as('/dev/tty') == 'char device'
        assert exists_as('/dev/kmsg') == 'char device'
        assert exists_as('/dev/fd') == 'directory'
        assert exists_as

# Generated at 2022-06-11 22:42:02.506195
# Unit test for function chmod
def test_chmod():
    import os

    import pytest

    _DIR = 'flutils/tmp/io/pathutils/chmod'
    _TEXT_FILE = _DIR + '/text.txt'
    _BINARY_FILE = _DIR + '/binary.txt'
    _SYMLINK_FILE = _DIR + '/symlink.txt'
    _SYMLINK_TARGET = _TEXT_FILE

    _BINARY_DATA = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B'

    _INITIAL_MODE_FILE = 0o600
    _INITIAL_MODE_DIR = 0o700

    _EXPECTED_MODE_FILE = 0o640
    _EXPECTED_MODE_DIR = 0o750



# Generated at 2022-06-11 22:42:11.270771
# Unit test for function exists_as
def test_exists_as():
    # Test directory
    assert exists_as('~/tmp') == 'directory'

    # Test file
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'

    # Test broken symlink
    assert exists_as('~/tmp/flutils.tests.osutils.txt.lnk') == ''

    # Test not exists
    assert exists_as('~/flutils.tests.osutils.txt') == ''



# Generated at 2022-06-11 22:42:24.741102
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present, exists_as
    temp_path = directory_present('~/tmp/flutils/exists_as')
    assert exists_as(temp_path) == 'directory'
    temp_path.rmdir()
    assert exists_as(temp_path) == ''
    temp_path.mkdir(mode=0o777)
    assert exists_as(temp_path) == 'directory'
    temp_path.rmdir()
    assert exists_as(temp_path) == ''

    temp_path.mkdir(mode=0o777)
    (temp_path / 'file.txt').touch()
    assert exists_as(temp_path / 'file.txt') == 'file'
    (temp_path / 'file.txt').unlink()

# Generated at 2022-06-11 22:42:29.630426
# Unit test for function exists_as
def test_exists_as():
    path = Path.home() / 'tmp'
    assert exists_as(path) == 'directory'

    path = path.as_posix()
    assert exists_as(path) == 'directory'

    path = path.encode()
    assert exists_as(path) == 'directory'


# Generated at 2022-06-11 22:42:37.204467
# Unit test for function chown
def test_chown():
    from os import getuid, getgroups, stat
    from pwd import getpwuid, getpwnam
    from grp import getgrgid, getgrnam
    from .osutils import call

    with tempfile.TemporaryDirectory() as dirname:
        logfile = dirname / 'log.log'
        dirname = Path(dirname)
        logfile.write_text('test')
        # Confirm we can chown the directory
        tmp_uid = getuid()
        tmp_gid = getgroups()[0]
        cmd = ['sudo', 'chown', str(tmp_uid), str(tmp_gid), dirname]
        rtn = call(cmd)
        assert rtn == 0
        # change ownership back

# Generated at 2022-06-11 22:42:39.976811
# Unit test for function directory_present
def test_directory_present():
    path = directory_present(os.path.expanduser('~/tmp/temp_dir'))
    try:
        assert exists_as(path) == 'directory'
    finally:
        path.rmdir()
    path = directory_present(os.path.expanduser('~/tmp/temp_dir'))
    try:
        assert exists_as(path) == 'directory'
    finally:
        path.rmdir()



# Generated at 2022-06-11 22:42:52.273879
# Unit test for function path_absent
def test_path_absent(): # pragma: no cover
    path = '/tmp/test_path'
    if os.path.exists(path):
        # Cleanup if needed
        os.removedirs(path)
    assert os.path.exists(path) is False
    path = Path(path)
    path.mkdir(parents=True)
    assert os.path.isdir(path)
    path_absent(path)
    assert os.path.exists(path) is False

    path = '/tmp/test_path_2'
    path_two = Path(path)
    path_two.mkdir()
    path_three = path_two / 'foo'
    path_three.mkdir()
    assert os.path.isdir(path_two)
    assert os.path.isdir(path_three)

    path_

# Generated at 2022-06-11 22:43:04.189629
# Unit test for function chown
def test_chown():
    # Test change ownership of file
    with TemporaryDirectory() as tmpdir_path:
        tmpdir_path = Path(tmpdir_path)
        with tmpdir_path.joinpath('test.txt').open(mode='w') as test_file:
            test_file.write('Hello, World!')
        # Change ownership of file to 'root'
        chown(tmpdir_path.joinpath('test.txt'), user='root')
        # Check file ownership
        assert os.stat(tmpdir_path.joinpath('test.txt')).st_uid == 0
        assert pwd.getpwuid(os.stat(tmpdir_path.joinpath('test.txt')).st_uid).pw_name == 'root'
    # Test change the ownership of a directory

# Generated at 2022-06-11 22:43:16.150132
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('flutils.tests.osutils.txt').touch()
        tmpdir.joinpath('flutils.tests.osutils2.txt').touch()
        tmpdir.joinpath('flutils.tests.osutils3.txt').touch()

        # find_paths() creates a Generator, so use a generator expression
        # to convert to a list. Also, use the sorted() function to sort
        # the list items.

# Generated at 2022-06-11 22:43:24.991605
# Unit test for function exists_as
def test_exists_as():
    with TemporaryDirectory() as tmp_dir:
        # Test a symbolic link
        tmp_dir_path = Path(tmp_dir)
        sub_path = Path(tmp_dir_path / 'test_file')
        sub_path.touch()
        assert exists_as(sub_path) == 'file'
        sub_link = tmp_dir_path / 'test_link'
        sub_link.symlink_to(sub_path)
        assert exists_as(sub_link) == 'file'

        # Test a broken symbolic link
        sub_link.unlink()
        sub_link.symlink_to('/non/existent/path')
        assert exists_as(sub_link) == ''

        # Test a directory
        assert exists_as(tmp_dir_path) == 'directory'

        # Test a regular

# Generated at 2022-06-11 22:44:43.052838
# Unit test for function path_absent
def test_path_absent():
    import os
    import pathlib
    import stat

    def _path_exists(path: pathlib.Path, recursive: bool = False) -> bool:
        try:
            if recursive is True:
                for name in path.glob('**/*'):
                    if name.is_dir():
                        yield from _path_exists(name)
            else:
                return path.exists()
        except EnvironmentError as e:
            raise AssertionError(
                'Unable to assert existence of %r because of %r'
                % (path, e)
            )

    # Test deleting a file.
    test_path = pathlib.Path('/tmp/test_file')

# Generated at 2022-06-11 22:44:48.446373
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        test_dir = Path(tmpdir) / 'test_directory_present'
        test_path = directory_present(test_dir)

        assert test_dir == test_path

        assert test_dir.exists() is True
        assert test_dir.is_dir() is True
        assert test_dir.is_file() is False

        test_dir_parent = test_dir.parent
        test_dir_grandparent = test_dir_parent.parent

        assert test_dir_parent.exists() is True
        assert test_dir_parent.is_dir() is True
        assert test_dir_parent.is_file() is False

        assert test_dir_grandparent.exists() is True
        assert test_dir_grandparent.is_dir

# Generated at 2022-06-11 22:44:57.017057
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path(__file__)) == 'file'
    assert exists_as(Path(__file__).parent) == 'directory'
    assert exists_as(Path(__file__).parent.parent) == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as(Path('/tmp')) == 'directory'
    assert exists_as('/fakepath') == ''
    assert exists_as(Path('/fakepath')) == ''



# Generated at 2022-06-11 22:45:01.379723
# Unit test for function directory_present
def test_directory_present():
    path = Path(os.getcwd(), 'tmp')
    if path.exists():
        shutil.rmtree(path)

    path = directory_present(path)
    assert path.exists()
    assert path.is_dir()



# Generated at 2022-06-11 22:45:09.582800
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent, create_tmp_dir
    from flutils.pathutils import make_path
    from flutils.pathutils import normalize_path
    from flutils.pathutils import exists_as

    with create_tmp_dir() as tmp_dir:
        path = tmp_dir / 'dir_one' / 'dir_two' / 'dir_three'
        path.mkdir(parents=True, exist_ok=True)

        path = path / 'foo'
        make_path(path, mode=0o700)

        path = tmp_dir / 'dir_one' / 'dir_two' / 'bar'
        make_path(path, mode=0o700)

        path = tmp_dir / 'dir_one' / 'dir_two' / 'qux'
        make_

# Generated at 2022-06-11 22:45:19.435308
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / 'flutils.tests.pathutils.directory'
        assert path.exists() is False
        directory_present(path.as_posix())
        assert path.is_dir()
        assert os.stat(path).st_mode & 0o700 == 0o700
        assert os.stat(path).st_mode & 0o007 == 0
        assert 'directory_present.test_directory_present' in path.as_posix()
        assert path.parent.as_posix() == temp_dir



# Generated at 2022-06-11 22:45:32.952863
# Unit test for function path_absent

# Generated at 2022-06-11 22:45:41.124430
# Unit test for function directory_present
def test_directory_present():
    assert (
        directory_present(
            './tmp/flutils_tests_pathutils/foo/bar', mode=0o711
        ).as_posix() == './tmp/flutils_tests_pathutils/foo/bar'
    )
    assert (
        directory_present(
            './tmp/flutils_tests_pathutils/foo/bar',
            mode=0o711,
            user='root'
        ).as_posix() == './tmp/flutils_tests_pathutils/foo/bar'
    )

# Generated at 2022-06-11 22:45:48.391193
# Unit test for function chown
def test_chown():
    from  flutils.testing import assert_raises
    from flutils.testing import mk_temp_dir
    from flutils.testing import rm_rf
    from flutils.testing import run_test_module_with_coverage
    from pathlib import Path

    #  Create a test file for use in the chown test
    test_file = Path(mk_temp_dir()) / 'test_file.txt'
    test_file.touch()

    #  Test expected success
    assert chown(test_file) is None
    assert chown(test_file, user='-1') is None
    assert chown(test_file, group='-1') is None
    assert chown(test_file, user='-1', group='-1') is None

    #  Test bad arguments and expected failure

# Generated at 2022-06-11 22:45:54.428250
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    # Run the code with different user values
    get_os_user('foo')
    get_os_user('root')
    get_os_user(1)
    get_os_user(-1)
    get_os_user(user.pw_uid)

