

# Generated at 2022-06-11 22:36:30.320720
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from shutil import chown
    from os import (
        stat,
    )
    from pwd import (
        getpwnam,
    )
    from grp import (
        getgrnam,
    )
    from itertools import (
        chain,
    )

    with TemporaryDirectory(dir='~') as tmpdir:
        cwd = Path(tmpdir)
        user = getpwnam(getpass.getuser()).pw_name
        group = getgrnam(getpass.getgrent().gr_name).gr_name
        new_user = 'nobody'
        new_group = 'nogroup'


# Generated at 2022-06-11 22:36:42.430458
# Unit test for function directory_present
def test_directory_present():
    from os import PathLike

    from flutils.pathutils import (
        directory_present,
        find_paths,
        normalize_path,
    )

    def _cleanup():
        directory_present(test_path, mode=0o700, user=0, group=0)

    test_parent_path = normalize_path(
        os.path.join(os.path.dirname(__file__), '_test_data', 'tmp')
    )

    # Test if a directory already exists.
    test_path = os.path.join(test_parent_path, 'directory_present_exists')
    directory_present(test_path, mode=0o700, user=0, group=0)
    directory_present(test_path, mode=0o700, user=0, group=0)


# Generated at 2022-06-11 22:36:53.439573
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    from os.path import join as join_paths
    from os import chmod
    from flutils.pathutils import chown
    from .files import TempDirMixin

    class TestChown(TempDirMixin):
        def test_chown(self):
            path = join_paths(self.tmp_dir.name, 'flutils.tests.pathutils.txt')
            with open(path, 'a'):
                pass
            f_perms = 0o660
            d_perms = 0o770
            chmod(path, f_perms)
            self.assertEqual(os.stat(path).st_mode & 0o777, f_perms)

            chown(path, include_parent=True)

# Generated at 2022-06-11 22:37:06.502401
# Unit test for function directory_present
def test_directory_present():
    test_dir = '~/tmp/flutils.tests.pathutils.directory_present'
    dir_path = normalize_path(test_dir)
    if dir_path.exists() is True and dir_path.is_dir():
        shutil.rmtree(dir_path.as_posix())

    assert directory_present(dir_path).as_posix() == \
        '%s/%s' % (Path('~/tmp').expanduser().as_posix(), test_dir)

    assert directory_present(dir_path).as_posix() == \
        '%s/%s' % (Path('~/tmp').expanduser().as_posix(), test_dir)


# Generated at 2022-06-11 22:37:09.988286
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as td:
        td_files = _create_files(td)
        pattern = Path(td).joinpath('*.txt')
        paths = list(find_paths(pattern))
        assert len(paths) == len(td_files)
        for td_file in td_files:
            assert td_file in paths


# Generated at 2022-06-11 22:37:23.036308
# Unit test for function directory_present
def test_directory_present():
    from os import remove, rmdir
    from pathlib import Path
    from os.path import dirname
    from shutil import rmtree


# Generated at 2022-06-11 22:37:27.659204
# Unit test for function chown
def test_chown():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    dname = mkdtemp()
    p = Path(dname)
    try:
        chown(dname)
    finally:
        rmtree(p)



# Generated at 2022-06-11 22:37:33.031624
# Unit test for function find_paths
def test_find_paths():
    # Create a temporary directory to run the tests
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create a file in the temporary directory
        with open(os.path.join(temp_dir, 'test_file'), 'w') as test_file:
            test_file.write('The quick brown fox jumped over the lazy dog.')
        pattern = os.path.join(temp_dir, '*')
        result = list(find_paths(pattern))
        assert len(result) == 1
        assert result[0].is_file()



# Generated at 2022-06-11 22:37:44.432728
# Unit test for function find_paths
def test_find_paths():
    path1 = _PATH('/home/test_user/tmp/file_one')
    path2 = _PATH('/home/test_user/tmp/dir_one')
    parent = path1.parent

    with TempDirectory(dir=parent, prefix='tmp') as tmpdir:
        tmpdir = Path(_PATH(tmpdir))
        tmpdir = tmpdir.resolve()

        path1 = tmpdir / Path('file_one')
        path2 = tmpdir / Path('dir_one')
        path3 = path2 / Path('file_two')

        for test_path in [path1, path2, path3]:
            test_path.parent.mkdir(parents=True, exist_ok=True)

        found_paths = find_paths(tmpdir.as_posix() + '/*')

# Generated at 2022-06-11 22:37:53.394341
# Unit test for function path_absent
def test_path_absent():
    path_to_delete = Path('~/tmp/path_absent').expanduser()
    Path(path_to_delete).mkdir(parents=True, mode=0o700)
    with open(path_to_delete / 'some_file', 'w') as f:
        f.write('some content')
    path_to_delete_2 = path_to_delete / 'some_dir'
    Path(path_to_delete_2).mkdir(parents=True, mode=0o700)
    path_absent(path_to_delete)
    assert not os.path.exists(path_to_delete)



# Generated at 2022-06-11 22:38:20.564487
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.parent.mkdir(mode=0o660, parents=True)
    path.touch(mode=0o660)
    assert exists_as(path) == 'file'
    path.unlink()
    assert exists_as(path) == ''
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'



# Generated at 2022-06-11 22:38:30.832010
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import _PATH
    import glob
    import tempfile
    import shutil
    import subprocess

    path_tmp = normalize_path(tempfile.gettempdir())
    path_dir = path_tmp.joinpath('test_dir')
    path_dir_link = path_tmp.joinpath('test_dir_link')
    path_file = path_tmp.joinpath('test_file')
    path_file_link = path_tmp.joinpath('test_file_link')

    subprocess.call(['mkdir', path_dir.as_posix()])
    subprocess.call(['ln', '-s', path_dir.as_posix(), path_dir_link.as_posix()])
    subprocess.call(['touch', path_file.as_posix()])

# Generated at 2022-06-11 22:38:43.220974
# Unit test for function find_paths
def test_find_paths():
    from . import TestCase

    class TestFindPaths(TestCase):
        def test_no_pattern(self):
            with self.assertRaises(ValueError) as exc_info:
                find_paths('/home/test_user/file.txt')

            self.assertEqual(
                str(exc_info.exception),
                'The pattern: /home/test_user/file.txt must contain a '
                'glob pattern.'
            )

        def test_recursive_pattern(self):
            cwd = Path().resolve()
            tmp = cwd.joinpath('tmp')
            file_one = tmp.joinpath('file_one')
            file_two = tmp.joinpath('file_two')
            dir_one = tmp.joinpath('dir_one')
            dir_two = dir_

# Generated at 2022-06-11 22:38:45.272885
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-11 22:38:56.563812
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as, directory_present
    from flutils.datastructures import OrderedDeque
    import tempfile

    path = normalize_path('~/tmp')
    path_exists_as = exists_as(path)
    assert path_exists_as == 'directory'
    assert isinstance(path_exists_as, str)

    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path_exists_as = exists_as(path)
    assert path_exists_as == 'file'

    path = normalize_path('~/tmp/flutils.tests.osutils.txt**')
    with pytest.raises(ValueError):
        path_exists_as = exists_as(path)

    path = tempfile

# Generated at 2022-06-11 22:39:08.049002
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests import TEST_DIR


# Generated at 2022-06-11 22:39:08.976228
# Unit test for function chown
def test_chown():
    pass # no code coverage for this test



# Generated at 2022-06-11 22:39:13.233946
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    assert get_os_group().gr_name == get_os_user().pw_name
    assert get_os_group('bar').gr_gid == 2001
    assert get_os_group(2001).gr_gid == 2001
    assert get_os_group('foo').gr_name == 'foo'



# Generated at 2022-06-11 22:39:27.126218
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'tmp.txt')
    with open(tmp_file, 'w') as fp:
        fp.write('\n')

    tmp_file2 = os.path.join(tmp_dir, 'tmp2.txt')
    with open(tmp_file2, 'w') as fp:
        fp.write('\n')

    tmp_sub_dir = os.path.join(tmp_dir, 'tmp_sub')
    os.makedirs(tmp_sub_dir)
    tmp_sub_file = os.path.join(tmp_sub_dir, 'tmp.txt')

# Generated at 2022-06-11 22:39:42.134883
# Unit test for function path_absent
def test_path_absent():
    path = Path(__file__).parent.as_posix()
    path = os.path.join(path, 'test_path_absent')
    if os.path.exists(path):
        shutil.rmtree(path)
    os.mkdir(path)
    assert os.path.isdir(path)
    #
    path_one = os.path.join(path, '1.txt')
    with open(path_one, 'w', encoding='utf-8') as fh:
        fh.write('One')
    assert os.path.isfile(path_one)
    #
    path_dir_one = os.path.join(path, 'dir_one')
    os.mkdir(path_dir_one)

# Generated at 2022-06-11 22:39:59.281508
# Unit test for function find_paths
def test_find_paths():
    """Unit tests for function :func:`flutils.pathutils.find_paths`."""
    test_path = tempfile.mkdtemp()
    Path(test_path, 'file_one').touch()
    Path(test_path, 'dir_one').mkdir(mode=0o700)
    assert len(list(find_paths(test_path))) == 2
    shutil.rmtree(test_path)



# Generated at 2022-06-11 22:40:04.303452
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    # Get the current user's name.
    current_name = getpass.getuser()

    # Test the name of the current user.
    assert (get_os_user().pw_name == current_name)
    assert (get_os_user(current_name).pw_name == current_name)

    # Test using a uid.
    same_user = get_os_user()
    assert (get_os_user(same_user.pw_uid).pw_uid == same_user.pw_uid)

    # Test for an invalid user name.
    with pytest.raises(OSError) as err_info:
        get_os_user('_invalid_')

# Generated at 2022-06-11 22:40:12.416636
# Unit test for function chmod
def test_chmod():
    test_dir = Path(__file__).parent
    test_dir = test_dir.joinpath(
        'tmp_chmod_test_dir'
    )
    test_dir = test_dir.resolve()
    if test_dir.exists() is True:
        shutil.rmtree(test_dir)

    test_dir.mkdir(parents=True)
    test_file = test_dir.joinpath('test.txt')
    test_file.write_text('')

    chmod(test_dir.as_posix(), 0o700, 0o770)
    assert stat.S_IMODE(test_dir.stat().st_mode) == 0o770
    assert stat.S_IMODE(test_file.stat().st_mode) == 0o660


# Generated at 2022-06-11 22:40:25.090559
# Unit test for function chown
def test_chown():
    with TempDir() as temp_dir, TempUser() as temp_user, TempGroup() as temp_group:
        base_dir = Path(temp_dir)
        test_dir = base_dir / 'test_dir'
        test_dir.mkdir()

        if sys.platform.startswith('linux'):
            os.chown(test_dir.as_posix(), temp_user.uid, temp_group.gid, follow_symlinks=False)
            chown(test_dir, temp_user.name, temp_group.name)
            assert os.stat(test_dir.as_posix()).st_uid == temp_user.uid
            assert os.stat(test_dir.as_posix()).st_gid == temp_group.gid


# Generated at 2022-06-11 22:40:35.626108
# Unit test for function path_absent
def test_path_absent():
    """Test the :func:`~flutils.pathutils.path_absent` function."""
    from flutils.pathutils import path_absent, path_present

    tmp = Path('~/tmp/test_path_absent/').expanduser()
    path_present(tmp, mode_dir=0o700)

# Generated at 2022-06-11 22:40:42.885954
# Unit test for function exists_as
def test_exists_as():
    path_name = '~/tmp'
    path = normalize_path(path_name)
    if path.exists:
        if path.is_dir():
            return 'directory'
        if path.is_file():
            return 'file'
        if path.is_block_device():
            return 'block device'
        if path.is_char_device():
            return 'char device'
        if path.is_fifo():
            return 'FIFO'
        if path.is_socket():
            return 'socket'
    return ''


# Generated at 2022-06-11 22:40:55.968961
# Unit test for function find_paths
def test_find_paths():
    import os
    import shutil
    from tempfile import mkdtemp
    from typing import Generator

    dirs = [mkdtemp() for _ in range(2)]
    dirs[0] = os.path.join(dirs[0], 'foo')
    dirs[1] = os.path.join(dirs[1], 'foo')
    os.mkdir(dirs[0])

    files = [mkdtemp() for _ in range(3)]
    files[0] = os.path.join(files[0], 'foo')
    files[1] = os.path.join(files[1], 'foo')
    files[2] = os.path.join(files[2], 'bar')
    for file in range(3):
        with open(files[file], 'w') as f:
            f

# Generated at 2022-06-11 22:40:57.618293
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:04.965363
# Unit test for function chmod
def test_chmod():
    path = os.path.expanduser(os.path.join('~', 'tmp', 'flutils.tests.osutils.txt'))

    with open(path, 'wt') as f:
        f.write('testing')

    if os.path.exists(path):
        chmod(path, 0o660)
        assert Path(path).stat().st_mode == 0o100660

    if os.path.exists(path):
        os.unlink(path)




# Generated at 2022-06-11 22:41:11.564559
# Unit test for function find_paths
def test_find_paths():
    import os

    from . import PATHS  # noqa

    idx = 0
    for path in find_paths('%s*insert_file.txt' % PATHS[idx]):
        assert path.as_posix() == PATHS[0]

    idx += 1
    for path in find_paths('%s*' % PATHS[idx]):
        assert path.as_posix() == PATHS[1]

    idx += 1
    for path in find_paths('%s*' % PATHS[idx]):
        assert path.as_posix() == PATHS[2]

    idx += 1
    for path in find_paths('%s*' % PATHS[idx]):
        assert path.as_posix() == PATHS[3]

    idx

# Generated at 2022-06-11 22:42:11.538152
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree

    with TemporaryDirectory() as tmpdir:
        test_dir = Path(tmpdir).joinpath('test_dir')
        test_file = Path(tmpdir).joinpath('test_file.txt')
        test_file.touch()

        test_dir.mkdir()
        test_dir.joinpath('test_file_1.txt').touch()
        test_dir.joinpath('test_file_2.txt').touch()
        test_dir.joinpath('test_file_3.txt').touch()
        test_dir.joinpath('test_dir_2').mkdir()
        test_dir.joinpath('test_dir_2').joinpath('test_file_4.txt').touch()


# Generated at 2022-06-11 22:42:24.741823
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    import shutil
    dummy_tmp_dir = tempfile.mkdtemp()
    dummy_dir = Path('{}/dirA'.format(dummy_tmp_dir))
    dummy_dir.mkdir()
    dummy_file = Path('{}/dirA/file.txt'.format(dummy_tmp_dir))
    dummy_file.touch()
    chmod(dummy_tmp_dir, mode_file=0o664, mode_dir=0o775)
    st = os.stat(dummy_tmp_dir)
    assert st.st_mode == 33028
    st = os.stat(dummy_dir)
    assert st.st_mode == 33188
    st = os.stat(dummy_file)
    assert st.st_mode == 33188


# Generated at 2022-06-11 22:42:34.022323
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function `exists_as`."""

    # First lets get the directory type.
    #
    # Examples:
    #   $ stat -f '%HT' /
    #   directory
    #
    #   $ stat -f '%HT' /tmp
    #   directory
    #
    #   $ stat -f '%HT' /dev
    #   directory
    #
    #   $ stat -f '%HT' /proc
    #   directory
    stat_bin = Path('/usr/bin/stat')
    if exists_as(stat_bin) == 'file':
        cmd = '%s -f \'%%HT\' %s' % (stat_bin, '/')
        p = run(cmd, shell=True, stdout=PIPE, stderr=DEVNULL)

# Generated at 2022-06-11 22:42:44.203083
# Unit test for function exists_as
def test_exists_as():
    realpath = normalize_path('~/tmp/flutils.tests.osutils.txt').as_posix()
    with open(realpath, 'w') as fp:
        fp.write('test')

    assert exists_as(realpath) == 'file'
    assert exists_as(normalize_path(realpath)) == 'file'
    assert exists_as(os.path.join(realpath, 'test')) == ''
    assert exists_as(os.path.join(realpath, '/test')) == ''
    assert exists_as('~/tmp/foo') == ''
    assert exists_as('') == ''

    os.remove(realpath)



# Generated at 2022-06-11 22:42:44.817254
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:42:55.843995
# Unit test for function path_absent
def test_path_absent():
    test_root = Path(tempfile.gettempdir()) / 'test_utils_pathutils'
    if test_root.exists():
        path_absent(test_root)
    test_root.mkdir(mode=0o700)

    test_dir = test_root / 'test_dir'
    test_file_one = test_dir / 'file_one'
    test_file_two = test_dir / 'file_two'
    test_dir.mkdir(mode=0o700)
    test_file_one.touch(mode=0o600)
    test_file_two.touch(mode=0o600)

    assert test_root.exists()
    assert test_dir.exists()
    assert test_file_one.exists()
    assert test_file_two.exists()

# Generated at 2022-06-11 22:42:56.632350
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user('foo')



# Generated at 2022-06-11 22:42:57.218050
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-11 22:43:08.320231
# Unit test for function directory_present
def test_directory_present():
    """
    Unit test for ``directory_present``.
    """
    from pathlib import PosixPath
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_path:
        tmp_path = PosixPath(tmp_path)
        assert directory_present(tmp_path / 'temp', mode=0o700) == (
            tmp_path / 'temp')

        assert directory_present(tmp_path / 'temp', mode=0o700) == (
            tmp_path / 'temp')

        assert directory_present((tmp_path / 'temp') / 'temp2', mode=0o700) == (
            tmp_path / 'temp' / 'temp2')


# Generated at 2022-06-11 22:43:09.880038
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:43:43.638364
# Unit test for function chown
def test_chown():
    if sys.platform.startswith('linux') is False:
        return

    # Test the operation of chown() without a glob pattern.
    tmp_path = Path('/tmp/flutils.tests.osutils.test_chown')
    tmp_path.touch()

# Generated at 2022-06-11 22:43:44.173685
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:43:47.322209
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'pathutils.py'
    chown(path, user=getpass.getuser(), group='-1')
    assert path.owner() == getpass.getuser()



# Generated at 2022-06-11 22:43:53.434088
# Unit test for function chmod
def test_chmod():
    tmpdir = Path(os.path.join(os.getenv('HOME'), 'tmp'))
    tmpdir.mkdir(mode=0o700, parents=True, exist_ok=True)
    test_file = Path(os.path.join(os.getenv('HOME'), 'tmp', 'flutils.tests.osutils.txt'))
    with open(test_file, 'w') as fh:
        fh.write('flutils')
    test_file.chmod(0o644)
    chmod(test_file, mode_file=0o600)
    assert test_file.stat().st_mode == 33152



# Generated at 2022-06-11 22:43:55.360144
# Unit test for function chown
def test_chown():
    assert True is True



# Generated at 2022-06-11 22:44:03.844893
# Unit test for function find_paths
def test_find_paths():
    from tempfile import mkdtemp
    import shutil

    tmpdir = mkdtemp()

    def create_test_dir():
        testdir = Path(tmpdir).joinpath('testdir')
        testdir.mkdir()
        return testdir

    files = [
        'file_one',
        'file_two',
        'file_three',
        'file_four',
        'file_five',
        'file_six',
        'file_seven',
        'file_eight',
        'file_nine',
    ]

    def create_test_files(testdir: Path):
        for file in files:
            testdir.joinpath(file).touch()


# Generated at 2022-06-11 22:44:11.956604
# Unit test for function chmod
def test_chmod():
    """ Tests for function chmod
    """
    import shutil
    from flutils.pathutils import chmod

    # A directory
    tmpdir = Path('~/tmp/flutils.chmod.test').expanduser()
    if tmpdir.exists() is True:
        shutil.rmtree(tmpdir)

    Path(tmpdir).mkdir(parents=True)
    chmod(tmpdir, mode_file=0o644, mode_dir=0o755)

    assert tmpdir.stat().st_mode == 16877
    shutil.rmtree(tmpdir)



# Generated at 2022-06-11 22:44:23.437694
# Unit test for function directory_present
def test_directory_present():
    import os

    def get_path_info(path):
        path = os.path.expanduser(path)
        return path, os.path.exists(path), os.path.isdir(path)

    # Test parent path(s) needed to be created.
    _test_path = '~/tmp/unittest_pathutils/test_path_1'
    _test_path, exists, is_dir = get_path_info(_test_path)
    assert exists is False
    assert is_dir is False

    dir_present = directory_present(_test_path)
    assert dir_present.as_posix() == _test_path
    assert is_dir is True

    # Test create dir with the user and group unchanged.

# Generated at 2022-06-11 22:44:30.697768
# Unit test for function directory_present
def test_directory_present():
    from pathlib import PosixPath
    from os import getcwd, chdir, mkdir, rmdir, environ
    from shutil import rmtree

    dir_tmp = '/tmp/flutils.tests.pathutils'
    file_tmp = '/tmp/flutils.tests.pathutils/flutils.tests.pathutils.txt'
    if os.path.exists(dir_tmp) or os.path.exists(file_tmp):
        rmtree(dir_tmp)
    assert not os.path.exists(dir_tmp)
    assert not os.path.exists(file_tmp)
    os.makedirs(dir_tmp)
    assert os.path.isdir(dir_tmp)
    assert not os.path.exists(file_tmp)

# Generated at 2022-06-11 22:44:42.889104
# Unit test for function chmod
def test_chmod():
    import tempfile
    td = tempfile.TemporaryDirectory()
    test_file = Path(td.name) / 'test_file.txt'
    test_file.touch()
    test_file.chmod(0o600)
    chmod(test_file, 0o600)
    assert test_file.stat().st_mode & 0o700 == 0o600
    chmod(test_file, 0o700)
    assert test_file.stat().st_mode & 0o700 == 0o700
    chmod(test_file, 0o755)
    assert test_file.stat().st_mode & 0o700 == 0o755
    chown(test_file, 0, 0)
    assert test_file.stat().st_uid == 0
    assert test_file.stat().st_gid == 0
   

# Generated at 2022-06-11 22:45:21.473712
# Unit test for function chown
def test_chown():
    # check return type for positive case
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    assert isinstance(chown(path),None.__class__)
    # check return type for negative case
    with pytest.raises(OSError):
        chown(path, user='invalid')
    with pytest.raises(OSError):
        chown(path, group='invalid')
    with pytest.raises(OSError):
        chown(path, user='invalid', group='invalid')



# Generated at 2022-06-11 22:45:34.604140
# Unit test for function directory_present
def test_directory_present():
    from flutils.tests.helpers import random_string
    from flutils.tests.path_utils import random_path

    for _ in range(1000):
        random_dir = random_path()
        user = None
        group = None
        mode_dir = None
        if random.randint(0, 1) == 0:
            user = random_string()
        if random.randint(0, 1) == 0:
            group = random_string()
        if random.randint(0, 1) == 0:
            mode_dir = random.randint(0o400, 0o1777)
        directory_present(
            random_dir,
            user=user,
            group=group,
            mode=mode_dir
        )

# Generated at 2022-06-11 22:45:48.089849
# Unit test for function chown
def test_chown():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        file_path = tmp_dir / 'flutils.tests.osutils.txt'
        file_path.touch()

        chown(file_path, include_parent=True)
        file_stat = file_path.stat()
        assert file_stat.st_uid == os.getuid()
        assert file_stat.st_gid == os.getgid()

        user = os.getlogin()
        chown(file_path, user, include_parent=True)
        file_stat = file_path.stat()
        assert file_stat.st_uid == get_os_user(user).pw_uid
        assert file_stat.st_gid == os.getgid()

        chown

# Generated at 2022-06-11 22:46:00.850215
# Unit test for function chmod
def test_chmod():
    if os.getuid() != 0:
        import pytest
        pytest.skip('chmod tests require root privileges')

    from shutil import rmtree
    from tempfile import mkdtemp

    from flutils.pathutils import chmod

    tmpdir = mkdtemp()
