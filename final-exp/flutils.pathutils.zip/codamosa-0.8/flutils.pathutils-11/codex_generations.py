

# Generated at 2022-06-11 22:36:45.724408
# Unit test for function directory_present
def test_directory_present():
    path = '~/tmp/directory_present_test'
    assert directory_present(path) == Path(path)
    assert directory_present(path, mode=0o755) == Path(path)
    assert directory_present(path, user=getpass.getuser()) == Path(path)
    assert directory_present(path, group=grp.getgrgid(os.getgid()).gr_name) == Path(path)
    assert directory_present(path, user=getpass.getuser(), group=grp.getgrgid(os.getgid()).gr_name) == Path(path)


# Generated at 2022-06-11 22:36:55.106229
# Unit test for function chown
def test_chown():
    import tempfile
    from typing import Dict
    from pytest import fixture
    from pytest import mark
    from pytest import raises

    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    from flutils.pathutils import normalize_path
    from flutils.pathutils import path_absent
    from flutils.pathutils import chown
    if os.name == 'nt':
        pytestmark = mark.skip(reason='Not supported on Windows.')

    @fixture
    def settings() -> Dict[str, str]:
        settings = {}
        with tempfile.TemporaryDirectory() as tmpdir:
            settings['pw_dir'] = tmpdir
            group = get_os_group()
            settings['group'] = group.gr_name
            user

# Generated at 2022-06-11 22:37:04.865288
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert isinstance(user.pw_name, str)
    assert isinstance(user.pw_uid, int)
    try:
        get_os_user(-1)
    except OSError as e:
        assert str(e) == 'The given uid: -1, is not a valid uid for this operating system.'
        return
    assert False, 'Should have raised OSError!'



# Generated at 2022-06-11 22:37:15.293085
# Unit test for function directory_present
def test_directory_present():
    import shutil
    import tempfile
    import pytest

    temp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(temp_dir, 'foo/bar')

# Generated at 2022-06-11 22:37:27.297896
# Unit test for function chown
def test_chown():
    # Case 1: Test that OSError is raised when user does not exist.
    tmpdir = tempfile.mkdtemp()
    try:
        chown(tmpdir, user='nonexistent_user')
    except OSError:
        pass
    else:
        raise AssertionError('OSError not raised')
    finally:
        shutil.rmtree(tmpdir)

    # Case 2: Test that OSError is raised when group does not exist.
    tmpdir = tempfile.mkdtemp()
    try:
        chown(tmpdir, group='nonexistent_group')
    except OSError:
        pass
    else:
        raise AssertionError('OSError not raised')
    finally:
        shutil.rmtree(tmpdir)

    # Case 3: Test that

# Generated at 2022-06-11 22:37:35.963569
# Unit test for function find_paths
def test_find_paths():
    """Test function `find_paths`.."""
    pattern = str(TEST_DIR / '**' / '*')
    paths = tuple(find_paths(pattern))
    assert paths
    assert len(paths) == 6
    assert isinstance(paths[0], Path)
    assert str(paths[0]) == '/tmp/test_user/test_dir/test_file'
    assert str(paths[1]) == '/tmp/test_user/test_dir/test_link'
    assert str(paths[2]) == '/tmp/test_user/test_dir'
    assert str(paths[3]) == '/tmp/test_user/test_file'
    assert str(paths[4]) == '/tmp/test_user/test_link'

# Generated at 2022-06-11 22:37:37.319183
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/flutils.tests.osutils')
    

# Generated at 2022-06-11 22:37:41.731617
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    chmod(path, 0o660)
    assert os.stat(path).st_mode & 0o777 == 0o660



# Generated at 2022-06-11 22:37:42.839685
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:37:43.363481
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:38:14.069161
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'


# Generated at 2022-06-11 22:38:22.894008
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('~/tmp/*')
    expected = ['~/tmp/file_one', '~/tmp/dir_one']
    paths = find_paths(pattern)
    paths = sorted(
        [
            (
                ''.join(path.anchor),
                str(path)[len(path.anchor):],
            )
            for path in paths
        ]
    )
    paths = [
        os.path.join(path[0], path[1])
        for path in paths
    ]
    assert paths == expected

# Generated at 2022-06-11 22:38:23.538306
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:38:33.502732
# Unit test for function chmod
def test_chmod():
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', '/tmp'
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', 'a'
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', 'b'
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', '0'
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', '1'
    yield assert_raises, ValueError, chmod, '~/tmp/flutils.tests.osutils.txt', '2'
    yield assert_raises,

# Generated at 2022-06-11 22:38:44.752563
# Unit test for function chmod
def test_chmod():
    import shutil
    import tempfile

    tmp = Path(tempfile.mkdtemp())
    os.chmod(tmp, 0o700)
    os.makedirs(tmp / 'tmp', 0o777)
    os.makedirs(tmp / 'tmp' / 'tmp', 0o777)

    fp = tmp / 'tmp' / 'tmp' / 'flutils.tests.osutils.txt'
    fp.write_text('test')
    os.chmod(fp, 0o666)

    chmod(str(fp), 0o660)
    assert oct(os.stat(fp).st_mode)[-3:] == '660'

    chmod(str(tmp / 'tmp'), mode_dir=0o770)
    assert oct(os.stat(tmp / 'tmp').st_mode)[-3:]

# Generated at 2022-06-11 22:38:47.534791
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('~/tmp/flutils.tests.pathutils').expanduser()
    test_path.mkdir(parents=True)



# Generated at 2022-06-11 22:38:58.526815
# Unit test for function chmod
def test_chmod():
    get_tmp_dir = partial(tempfile.mkdtemp, dir=os.path.expanduser('~'))
    mkdir = partial(os.mkdir, mode=0o755)
    tmp_parent = get_tmp_dir(prefix='flutils.tests.osutils.')


# Generated at 2022-06-11 22:38:59.096689
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:39:03.225441
# Unit test for function path_absent
def test_path_absent():
    tmp, tmp_path = tempfile.mkstemp(prefix='tmp')
    path_absent(tmp_path)
    os.unlink(tmp)



# Generated at 2022-06-11 22:39:09.065214
# Unit test for function find_paths
def test_find_paths():
    from . import make_tmp_dir
    tmp_dir = make_tmp_dir()
    make_file(tmp_dir / 'file_one')
    make_directory(tmp_dir / 'dir_one')
    assert sorted(list(find_paths(f'{tmp_dir}/*'))) \
        == sorted([tmp_dir / 'file_one', tmp_dir / 'dir_one'])



# Generated at 2022-06-11 22:39:51.384313
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:40:03.946077
# Unit test for function find_paths
def test_find_paths():
    # create a temporary directory
    tmp_dir = mkdtemp()
    # create a test file in the temporary directory
    test_file = Path(tmp_dir).joinpath('testfile.txt')
    with test_file.open(mode='wb') as tmp_file:
        tmp_file.write(b'test_data')
    # find the path based on the temp directory path and a glob pattern
    # of testfile.txt
    search_pth = Path(tmp_dir).joinpath('testfile.txt')
    found = find_paths(search_pth)
    # check that the file exists
    assert test_file.exists()
    found_file = next(found)
    # check that the found file is equal to the test_file
    # which was created above
    assert found_file == test_file


# Generated at 2022-06-11 22:40:12.231881
# Unit test for function chmod
def test_chmod():
    import os
    import random
    import sys
    import tempfile
    import time
    import unittest

    from flutils.pathutils import chmod

    try:
        from tempfile import TemporaryDirectory
    except ImportError:
        from backports.tempfile import TemporaryDirectory

    # A bug in Python 3.6.0 - Python 3.6.3 causes infinite recursion
    # with TemporaryDirectory().
    # https://bugs.python.org/issue29525
    if sys.version_info[:3] in ((3, 6, 0), (3, 6, 1), (3, 6, 2), (3, 6, 3)):
        tmp_dir_obj = tempfile.mkdtemp(prefix='flutils.tests.')

        def _rmtree(*args, **kwargs):
            time.sleep(0.25)

# Generated at 2022-06-11 22:40:16.505614
# Unit test for function exists_as
def test_exists_as():
    """Test ``exists_as``.

    :rtype: :obj:`None`

    """
    from flutils.pathutils import directory_present, exists_as
    from flutils.temp import TempDir

    with TempDir() as temp_dir:
        # Test directory
        test_path = directory_present(temp_dir.name)
        assert exists_as(test_path) == 'directory'

        # Test file
        test_path = test_path / 'test_file.txt'
        with open(test_path, 'w') as test_file:
            test_file.write('test')
        assert exists_as(test_path) == 'file'

        # Test broken symlink
        link_path = test_path.with_name(test_path.stem + '_link')
        test_path

# Generated at 2022-06-11 22:40:18.701301
# Unit test for function get_os_user
def test_get_os_user():
    """Test for normal operation of function get_os_user."""
    from flutils.pathutils import get_os_user

    os_user = get_os_user()

    assert isinstance(os_user, pwd.struct_passwd)



# Generated at 2022-06-11 22:40:29.786359
# Unit test for function chmod
def test_chmod():
    tmp_dir = Path('~/tmp/flutils.osutils.chmod.test').expanduser()
    tmp_dir.mkdir(parents=True, exist_ok=True)

    tmp_file_1 = Path('~/tmp/flutils.osutils.chmod.test/file_1').expanduser()
    tmp_file_1.write_text('Testing.\n')

    tmp_file_2 = Path('~/tmp/flutils.osutils.chmod.test/file_2').expanduser()
    tmp_file_2.write_text('Testing.\n')

    tmp_dir.chmod(0o0700)
    tmp_file_1.chmod(0o0600)
    tmp_file_2.chmod(0o0600)


# Generated at 2022-06-11 22:40:34.833002
# Unit test for function exists_as
def test_exists_as():
    sub_path = Path('~/tmp/flutils.tests.osutils.txt')
    sub_path.touch()
    assert exists_as(sub_path) == 'file'



# Generated at 2022-06-11 22:40:38.563068
# Unit test for function exists_as
def test_exists_as():
    path = Path.home() / '.bash_profile'
    assert exists_as(path) == 'file'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/doesnotexist') == ''



# Generated at 2022-06-11 22:40:42.846335
# Unit test for function chown
def test_chown():

    # Test that the function chown works as expected by checking if the function
    # throws an error when an invalid group is passed
    try:
        chown('file.txt', group='bar')
    except OSError:
        return
    assert False, 'Expected OSError, did not get one'


# Generated at 2022-06-11 22:40:55.969180
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'

    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'

    assert exists_as('~/tmp/flutils.tests.osutils.bad') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.bad') == ''

    assert exists_as('~/tmp/flutils.tests.osutils.bad/') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.bad/') == ''

# Eliminate coverage warnings about branches not covered by tests.
test

# Generated at 2022-06-11 22:41:58.482378
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        filepath = tmpdir / 'testfile'
        filepath.write_text('test')

        assert filepath.exists() is True

        chmod(filepath.as_posix(), 0o600)
        assert filepath.stat().st_mode & 0o777 == 0o600

        # ------------------------

        dirpath = tmpdir / 'testdir'
        dirpath.mkdir()
        assert dirpath.exists() is True

        chmod(dirpath.as_posix(), 0o755)
        assert dirpath.stat().st_mode & 0o777 == 0o755

        # ------------------------

        dirpath = tmpdir / 'testdir2'
        dirpath.mkdir()
        assert dir

# Generated at 2022-06-11 22:42:07.395343
# Unit test for function chown
def test_chown():
    path = Path('/tmp/test_chown.txt')
    path.write_text('foo')
    chown(path)

    chown(path, '-1', '-1')
    assert os.stat(path).st_uid == os.getuid()
    assert os.stat(path).st_gid == os.getgid()

    chown(path, 'nobody', 'nobody')
    assert os.stat(path).st_uid == getpwnam('nobody').pw_uid
    assert os.stat(path).st_gid == getpwnam('nobody').pw_gid



# Generated at 2022-06-11 22:42:07.985196
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:42:16.468581
# Unit test for function chmod
def test_chmod():
    import shutil
    from io import StringIO
    from tempfile import TemporaryDirectory
    from unittest.mock import patch

    from pathlib import Path

    from .commonutils import (
        call_test,
        mkdir_test,
        rmdir_test,
    )

    from .osutils import (
        chmod,
        directory_present,
    )

    tmp = TemporaryDirectory()
    tmpdir = Path(tmp.name)
    dir_path = tmpdir / 'dir'
    file_path = tmpdir / 'dir' / 'file'
    dir_path.mkdir()
    file_path.touch()


# Generated at 2022-06-11 22:42:28.587831
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.py23 import makedirs

    paths = [
        '~/tmp/test_find_paths/one/one',
        '~/tmp/test_find_paths/one/two',
        '~/tmp/test_find_paths/one/three',
        '~/tmp/test_find_paths/two/one',
        '~/tmp/test_find_paths/two/two',
        '~/tmp/test_find_paths/two/three',
        '~/tmp/test_find_paths/three/one',
        '~/tmp/test_find_paths/three/two',
        '~/tmp/test_find_paths/three/three',
    ]


# Generated at 2022-06-11 22:42:36.735773
# Unit test for function chmod
def test_chmod():
    file_path = f'{Path.home()}/tmp/flutils.tests.osutils.txt'
    file_path = Path(file_path)
    file_path.touch()
    file_path.chmod(0o644)
    mode = file_path.stat().st_mode & 0o777
    assert mode == 0o644

    dir_path = os.path.dirname(file_path)
    dir_path = Path(dir_path)
    dir_path.chmod(0o775)
    mode = dir_path.stat().st_mode & 0o777
    assert mode == 0o775

    chmod(file_path, 0o660)
    mode = file_path.stat().st_mode & 0o777
    assert mode == 0o660


# Generated at 2022-06-11 22:42:37.748208
# Unit test for function chmod

# Generated at 2022-06-11 22:42:50.021280
# Unit test for function chown
def test_chown():
    def chown_func(path, user, group):
        stat = os.stat(path)
        return [stat.st_uid, stat.st_gid]

    with TempDirectory() as td:

        # Do a basic chown
        with open(os.path.join(td, 'file1.txt'), 'w+') as fd:
            fd.write("foo")
        chown(os.path.join(td, 'file1.txt'))
        assert chown_func(os.path.join(td, 'file1.txt'), '-1', '-1') == [getpass.getuid(), os.getgid()]

        # Do a chown, including parent
        with open(os.path.join(td, 'file2.txt'), 'w+') as fd:
            fd

# Generated at 2022-06-11 22:42:51.645667
# Unit test for function chown
def test_chown():
    assert chown("~/tmp/flutils.tests.osutils.txt") == None


# Generated at 2022-06-11 22:42:58.981919
# Unit test for function find_paths
def test_find_paths():
    """Test the function ``find_paths``."""
    from flutils.pathutils import find_paths

    def _test_find_paths(pattern, expected):
        """Test ``find_paths`` with the given ``pattern`` and ``expected``."""
        paths = list(find_paths(pattern))
        assert expected == paths

    paths = [
        '/home/test_user/tmp',
        '/home/test_user/tmp/file_one',
        '/home/test_user/tmp/file_two',
        '/home/test_user/tmp/dir_one',
        '/home/test_user/tmp/dir_one/file_three',
    ]
    for path in paths:
        Path(path).touch()


# Generated at 2022-06-11 22:43:30.686152
# Unit test for function find_paths
def test_find_paths():
    list(find_paths('~/tmp/*'))



# Generated at 2022-06-11 22:43:31.224059
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:43:35.177195
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev') == 'directory'
    assert exists_as('~/') == 'directory'
    assert exists_as('~/tmp') == ''
    assert exists_as('~/tmp/foo.txt') == ''
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/dev/zero') == 'character device'


# Generated at 2022-06-11 22:43:44.966652
# Unit test for function find_paths
def test_find_paths():
    # Test without glob pattern.
    with mock.patch.object(
            Path, 'glob', return_value=[Path('~/tmp/foo')]
    ) as mocked_glob:
        # Test with glob pattern.
        assert next(find_paths('~/tmp/foo')) == Path('~/tmp/foo')
        mocked_glob.assert_called_once_with(
            '~/tmp/foo'[len('~/'):]
        )

        # Test without glob pattern.
        assert next(find_paths('~/tmp/foo/')) == Path('~/tmp/foo/')  # noqa
        mocked_glob.assert_called_with(
            '~/tmp/foo/'[len('~/'):]
        )



# Generated at 2022-06-11 22:43:52.972188
# Unit test for function exists_as
def test_exists_as():
    for path, expected in {
            Path('/bin'): 'directory',
            Path('/bin/bash'): 'file',
            Path('/dev/sda'): 'block device',
            Path('/dev/amaster'): 'char device',
            Path('/dev/null'): 'char device',
            Path('/dev/full'): 'char device',
            Path('/dev/random'): 'char device',
            Path('/dev/zero'): 'char device',
            Path('/run/snapd.socket'): 'socket',
            Path('/proc'): 'directory',
            Path('/tmp/test/test'): '',
    }.items():
        assert exists_as(path) == expected



# Generated at 2022-06-11 22:43:55.618955
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt')

# Generated at 2022-06-11 22:44:03.983748
# Unit test for function chmod
def test_chmod():
    import os
    import sys
    import shutil
    import tempfile

    from flutils.pathutils import chmod

    temp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-11 22:44:13.315448
# Unit test for function chown
def test_chown():
    import pytest
    from flutils.pathutils import chown, dir_contains_files, exists_as, \
        get_os_group, get_os_user, path_absent, normalize_path
    from flutils.textutils import random_text

    path = Path(__file__).parent.joinpath(
        'chown.testdir'
    ).expanduser().resolve()

    if path.is_dir() is False:
        path.mkdir(parents=True)

    def _test(file_path, user, group):
        # If user/group is None, then we should get the
        # current user/group.
        if not isinstance(user, str):
            user = getpass.getuser()

        if group is None:
            group = get_os_group().gr_gid

# Generated at 2022-06-11 22:44:17.847830
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    assert exists_as('/usr/bin') == 'directory'
    assert exists_as('/bin/echo') == 'file'



# Generated at 2022-06-11 22:44:26.286448
# Unit test for function find_paths
def test_find_paths():
    # Create the test directory.
    root = Path(
        os.path.join(
            os.path.sep,
            'tmp',
            'flutils.pathutils.find_paths.test'
        )
    )
    directory_present(root)
    # Create test files and directories.
    file_one = Path(
        os.path.join(
            root.as_posix(),
            'file_one'
        )
    )
    file_one.touch()
    dir_one = Path(
        os.path.join(
            root.as_posix(),
            'dir_one'
        )
    )
    dir_one.mkdir()
    # Run the test.
    results = ''

# Generated at 2022-06-11 22:45:01.739273
# Unit test for function exists_as
def test_exists_as():
    exists_as('~/tmp/flutils.tests.osutils.txt')
    exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    exists_as('~/tmp') == 'directory'
    exists_as('~/tmp') == 'directory'
    exists_as('~/tmp') == 'directory'
    exists_as('~/tmp') == 'directory'
    exists_as('~/tmp') == 'directory'
    exists_as('~/tmp') == 'directory'



# Generated at 2022-06-11 22:45:08.340648
# Unit test for function chmod
def test_chmod():
    '''
    Tests for chmod
    '''
    path = '~/tmp/flutils_unit_test_tmp_dir/tmp/new_file'
    with Path(path).open('w') as new_file:
        new_file.write('')
    os.chmod(Path(path), 0o777)
    chmod(path, 0o666)
    # osutil.Chmod(path, 0o666)
    if os.stat(path).st_mode & 0o777 != 0o666:
        print('007')
        raise AssertionError()
# test_chmod



# Generated at 2022-06-11 22:45:21.020329
# Unit test for function chmod
def test_chmod():
    import filecmp
    import shutil
    import tempfile

    from flutils.osutils import chmod

    FILE_CONTENT = '''
    # flutils.tests

    foo

    bar
    '''

    tmpdir = tempfile.mkdtemp()

    tmp_file = Path(os.path.join(tmpdir, 'flutils.tests.osutils.txt'))
    tmp_file.touch(0o600)
    tmp_file.write_text(FILE_CONTENT)

    chmod(tmpdir, 0o670)
    chmod('{}/*'.format(tmpdir), 0o660)

    assert tmp_file.stat().st_mode & 0o777 == 0o660
    assert tmp_file.stat().st_uid == 0
    assert tmp_file.stat().st_gid == 0


# Generated at 2022-06-11 22:45:34.074754
# Unit test for function path_absent
def test_path_absent():
    from .flutils_testutils import check_function_invalid_params
    from .flutils_testutils import check_function_output
    from .flutils_testutils import check_function_results
    from .flutils_testutils import check_function_rm_results
    from ._pathutils_test_data import PATHS_ABSENT_RESULTS
    from ._pathutils_test_data import PATHS_ABSENT_RM_RESULTS

    check_function_rm_results(path_absent, PATHS_ABSENT_RM_RESULTS)
    check_function_invalid_params(path_absent)
    check_function_output(path_absent, PATHS_ABSENT_RESULTS)
    check_function_results(path_absent)



# Generated at 2022-06-11 22:45:39.813364
# Unit test for function chmod
def test_chmod():
    import stat
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        foo_dir = Path(tmpdir) / 'foo'
        foo_dir.mkdir(0o700)
        assert foo_dir.stat().st_mode == 0o40700

        chmod(foo_dir, mode_dir=0o770)
        assert foo_dir.stat().st_mode == 0o40770

        # Test mode with symlink
        foo_lnk = foo_dir / 'foo.txt'
        foo_lnk.symlink_to('/tmp/foo_lnk.txt')

        chmod(foo_lnk, 0o660)
        assert foo_lnk.stat().st_mode == 0o40666


# Generated at 2022-06-11 22:45:49.371256
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmp_dir:
        root_path = Path(tmp_dir)
        file_one = root_path / 'file_one'
        file_one.touch()
        file_two = root_path / 'file_two'
        file_two.touch()
        dir_one = root_path / 'dir_one'
        dir_one.mkdir()
        dir_two = root_path / 'dir_two'
        dir_two.mkdir()
        glob_patt = '**/*'
        assert list(find_paths(glob_patt)) == [dir_one, dir_two, file_one, file_two]



# Generated at 2022-06-11 22:45:54.248703
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]
test_find_paths()



# Generated at 2022-06-11 22:46:00.056561
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/tmp/*')) == list(Path('/tmp').glob('*'))
    assert list(find_paths('/tmp/*/')) == list(Path('/tmp').glob('*/'))
    assert list(find_paths('/tmp/*.txt')) == list(Path('/tmp').glob('*.txt'))

