

# Generated at 2022-06-11 22:36:46.030477
# Unit test for function find_paths
def test_find_paths():

    paths = []
    for path in find_paths('/home/test_user/tmp/*'):
        paths.append(path)

    assert len(paths) == 3
    assert paths[0] == Path('/home/test_user/tmp/file_one')
    assert paths[1] == Path('/home/test_user/tmp/dir_one')
    assert paths[2] == Path('/home/test_user/tmp/file_two')



# Generated at 2022-06-11 22:36:46.754341
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-11 22:36:54.430338
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_path = Path(test_dir).joinpath('test_path')
    test_path.mkdir()
    assert test_path.is_dir() is True
    test_path.joinpath('file_one').write_text('')
    test_path.joinpath('file_two').write_text('')
    test_path.joinpath('file_three').write_text('')
    assert test_path.joinpath('file_one').is_file() is True
    assert test_path.joinpath('file_two').is_file() is True
    assert test_path.joinpath('file_three').is_file() is True
    path_absent(test_path)
    assert test_path.ex

# Generated at 2022-06-11 22:37:02.140660
# Unit test for function find_paths
def test_find_paths():
    pattern = Path(__file__).parent / 'resources' / '*'
    paths = list(find_paths(pattern))
    assert len(paths) == 2
    assert Path('flutils/pathutils/resources/file_one') in paths
    assert Path('flutils/pathutils/resources/dir_one') in paths



# Generated at 2022-06-11 22:37:08.428215
# Unit test for function chmod
def test_chmod():
    with patch('os.chmod') as mock_chmod:
        chmod(Path('~/tmp/flutils.tests.osutils.txt'))
        assert mock_chmod.call_count == 1
        mock_chmod.assert_called_with(Path('~/tmp/flutils.tests.osutils.txt'),
                                      0o600)

    with patch('os.chmod', side_effect=OSError):
        chmod(Path('~/tmp/flutils.tests.osutils.txt'))



# Generated at 2022-06-11 22:37:21.038631
# Unit test for function path_absent
def test_path_absent():
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()
    path_absent(temp_dir)
    os.makedirs(temp_dir)
    assert os.path.isdir(temp_dir)
    path_absent(temp_dir)
    assert os.path.isdir(temp_dir) is False
    open(temp_dir, 'a').close()
    assert os.path.isfile(temp_dir)
    path_absent(temp_dir)
    assert os.path.isfile(temp_dir) is False
    os.makedirs(temp_dir)
    shutil.copy(__file__, temp_dir)
    path_absent(temp_dir)
    assert os.path.isdir(temp_dir) is False



# Generated at 2022-06-11 22:37:25.141879
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user."""
    # Setup
    try:
        os_user = get_os_user()
        os_user = get_os_user(os_user.pw_name)
        os_user = get_os_user(os_user.pw_uid)
        os_user = get_os_user('root')
        os_user = get_os_user(0)
    except OSError:
        pass
    else:
        assert os_user.pw_name == 'root'
        assert os_user.pw_uid == 0
        assert os_user.pw_gid == 0
        assert os_user.pw_gecos == 'root'
        assert os_user.pw_dir == '/root'
        assert os_user.pw_shell

# Generated at 2022-06-11 22:37:33.460073
# Unit test for function find_paths
def test_find_paths():
    from tests.testutils import TEST_DIR
    testdir = Path(__file__).parent / TEST_DIR

    if testdir.exists():
        for item in find_paths(testdir):
            item.unlink()
        testdir.rmdir()

    testdir.mkdir(mode=0o755)

    files = (
        testdir / 'file_one',
        testdir / 'file_two',
        testdir / 'file_three',
    )
    for item in files:
        item.touch()

    dirs = (
        testdir / 'dir_one',
        testdir / 'dir_two',
        testdir / 'dir_three',
    )
    for item in dirs:
        item.mkdir(mode=0o755)


# Generated at 2022-06-11 22:37:37.226605
# Unit test for function path_absent
def test_path_absent():
    tmp_dir = Path('~/tmp')
    with ExitStack() as stack:
        stack.enter_context(cd(tmp_dir))
        test_path_absent_one()
        test_path_absent_two()



# Generated at 2022-06-11 22:37:46.655459
# Unit test for function exists_as
def test_exists_as():
    from sys import platform as _platform
    from flutils.pathutils import exists_as

    if _platform == 'linux':
        assert exists_as('/dev/null') == 'block device'

    if _platform == 'darwin':
        assert exists_as('/dev/null') == 'char device'

    assert exists_as('/dev/urandom') == 'file'
    assert exists_as('/dev/random') == 'file'
    assert exists_as('/dev/zero') == 'file'

    assert exists_as('/dev/stdin') == 'char device'
    assert exists_as('/dev/stdout') == 'char device'
    assert exists_as('/dev/stderr') == 'char device'

if __name__ == '__main__':
    test_exists_as()



# Generated at 2022-06-11 22:38:18.869576
# Unit test for function chown
def test_chown():
    test_file = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    test_file.write_text('', encoding='utf-8')
    assert test_file.is_file() is True
    assert test_file.is_dir() is False
    assert test_file.stat().st_mode & 0o777 == 0o644
    assert get_os_user(test_file.stat().st_uid).pw_name.lower() == getpass.getuser().lower()
    assert get_os_group(test_file.stat().st_gid).gr_name == grp.getgrgid(os.getgid()).gr_name
    chown(test_file, include_parent=True)
    assert get_os_user(test_file.stat().st_uid).p

# Generated at 2022-06-11 22:38:29.851681
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_path'
    out_path = normalize_path(path)
    path_absent(out_path)
    assert exists_as(out_path) == ''
    path = '~/tmp/test_path'
    path_absent(path)
    assert exists_as(path) == ''
    path = Path('~/tmp/test_path')
    path_absent(path)
    assert exists_as(path) == ''
    path = '~/tmp/test_path/../test_path'
    path_absent(path)
    assert exists_as(path) == ''
    path = '~/tmp/test_path'
    os.mkdir(normalize_path(path))
    path_absent(path)
    assert exists_as(path)

# Generated at 2022-06-11 22:38:38.667199
# Unit test for function get_os_user
def test_get_os_user():
    import pytest
    from pathlib import Path

    from flutils.pathutils import get_os_user

    if str(Path('/').resolve()) == '/':
        with pytest.raises(OSError):
            get_os_user('len')
        user = get_os_user()
        result = get_os_user(user.pw_name)
        assert result.pw_name == user.pw_name
        result = get_os_user(user.pw_uid)
        assert result.pw_uid == user.pw_uid
    else:
        with pytest.raises(OSError):
            get_os_user('foo')
        user = get_os_user()
        assert user.pw_name == 'len'

# Generated at 2022-06-11 22:38:48.910511
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from os import (
        makedirs,
        unlink,
        stat,
        fstat,
        remove
    )
    from tempfile import gettempdir

    from sys import platform as _platform

    # Source: https://github.com/ActiveState/code/tree/master/recipes/Python/288097_Determining_current_user_name_on/
    if _platform == 'darwin':
        import ctypes

        _libc = ctypes.CDLL('libc.dylib')
        _libc.getlogin.restype = ctypes.c_char_p
        current_user = _libc.getlogin()
    else:
        current_user = getpass.getuser()
    # End source


# Generated at 2022-06-11 22:38:56.388082
# Unit test for function chmod
def test_chmod():
    import tempfile
    import stat

    p = PosixPath(tempfile.mkdtemp())
    d = p.joinpath('a')
    f = d.joinpath('b')

    d.mkdir()
    f.touch()

    chmod(d)
    chmod(f)

    assert stat.S_IMODE(f.stat().st_mode) == 0o600
    assert stat.S_IMODE(d.stat().st_mode) == 0o700

# Generated at 2022-06-11 22:39:07.787590
# Unit test for function path_absent
def test_path_absent():
    import shutil
    import tempfile

    def _create_temp_path() -> str:
        return os.path.join(tempfile.gettempdir(), 'flutils_test')

    tmp_path = _create_temp_path()
    assert os.path.exists(tmp_path) is False

    os.mkdir(tmp_path)
    assert os.path.isdir(tmp_path)

    path_absent(tmp_path)
    assert os.path.exists(tmp_path) is False

    os.mkdir(tmp_path)
    assert os.path.isdir(tmp_path)

    path_absent(tmp_path)
    assert os.path.exists(tmp_path) is False

    os.mkdir(tmp_path)

# Generated at 2022-06-11 22:39:16.928890
# Unit test for function path_absent
def test_path_absent():

    #
    # Test normal execution.
    #
    path_dir = '/tmp/test_dir'
    path_file = '/tmp/test_dir/test_file'
    try:
        path_absent('/tmp/test_dir')
        os.makedirs(path_dir, mode=0o700)
        open(path_file, 'a').close()
        path_absent('/tmp/test_dir')
        assert os.path.exists(path_dir) is False
    finally:
        if os.path.exists(path_dir):
            shutil.rmtree(path_dir)



# Generated at 2022-06-11 22:39:28.708039
# Unit test for function path_absent
def test_path_absent():
    tmpdir = Path(tempfile.mkdtemp())

# Generated at 2022-06-11 22:39:42.995548
# Unit test for function chmod
def test_chmod():
    with tempdir():
        # Create the base directory
        Path('base').mkdir()

        # Create a few files
        for x in range(10):
            Path('base/file%d.txt' % x).touch()

        # Create a file in an extra directory
        Path('base/extra/file.txt').touch()

        # Create a file in an extra directory
        Path('file.txt').touch()

        chmod('base')
        chmod('file.txt')

        assert os.stat('base').st_mode == 0o40700
        assert os.stat('file.txt').st_mode == 0o100600

        chmod('base/*.txt')
        chmod('base/extra/file.txt')


# Generated at 2022-06-11 22:39:44.096741
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-11 22:40:18.064204
# Unit test for function exists_as
def test_exists_as():
    exists_as('~') == 'directory'
    exists_as('~/foo') == ''
    exists_as('~/.bashrc') == 'file'



# Generated at 2022-06-11 22:40:19.618793
# Unit test for function chown
def test_chown():
    # TODO: Create unit test for chown
    pass

# Generated at 2022-06-11 22:40:21.221693
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__).parent
    assert exists_as(path) == 'directory'

    path = path / 'nonexistent'
    assert exists_as(path) == ''

# Generated at 2022-06-11 22:40:31.457889
# Unit test for function path_absent
def test_path_absent():
    import shutil

    path = '~/tmp/test_path'
    path = normalize_path(path)
    path = str(path)
    if os.path.exists(path):
        shutil.rmtree(path)

    path_absent(path)
    assert os.path.exists(path) is False
    os.makedirs(path)
    path_absent(path)
    assert os.path.exists(path) is False

    test_file = '~/tmp/test_file'
    test_file = normalize_path(test_file)
    test_file = str(test_file)
    assert os.path.exists(test_file) is False
    with open(test_file, 'w') as f:
        f.write('test')

# Generated at 2022-06-11 22:40:40.717378
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import exists_as, path_absent
    from pathlib import Path

    test_dir = Path('./tmp/test_dir')
    test_path = test_dir / 'test_file'
    test_dir.mkdir(parents=True, exist_ok=True)
    test_path.touch()
    assert(exists_as(test_path) == 'file')
    path_absent(test_path)
    assert(exists_as(test_path) == '')



# Generated at 2022-06-11 22:40:41.609380
# Unit test for function chown
def test_chown():
    chown('/tmp/foo')



# Generated at 2022-06-11 22:40:42.249776
# Unit test for function directory_present
def test_directory_present():
    return None



# Generated at 2022-06-11 22:40:42.772901
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:40:55.969036
# Unit test for function chown
def test_chown():

    import multiprocessing
    import tempfile
    import time

    from flutils.osutils import chown
    from flutils.pwutils import get_os_user

    test_user = 'flutils'
    test_group = 'flutils'

    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='w', prefix='flutils-') as f_ob:
        if f_ob.name is not None:
            path = Path(f_ob.name)

            # Create a user and group for this test
            pw_ob = get_os_user(test_user)
            if pw_ob is None:
                os.system(f'sudo adduser --disabled-password --home {path.parent} {test_user}')


# Generated at 2022-06-11 22:41:07.363219
# Unit test for function chmod
def test_chmod():
    path = Path(__file__).parent
    path.joinpath('osutils.txt').touch()
    assert path.joinpath('osutils.txt').is_file() is True
    assert path.joinpath('osutils.txt').is_dir() is False
    assert path.joinpath('osutils.txt').exists() is True
    assert path.joinpath('osutils.txt').stat().st_mode & 0o777 == 0o600
    chmod(path.joinpath('osutils.txt'), 0o660)
    assert path.joinpath('osutils.txt').stat().st_mode & 0o777 == 0o660

    chmod(path.joinpath('osutils.txt'), mode_file=0o666)

# Generated at 2022-06-11 22:41:48.487513
# Unit test for function chmod
def test_chmod():
    # Create a temporary directory to work in
    tmp_path = Path(__file__).parent / 'tmp'
    if tmp_path.exists() is False:
        tmp_path.mkdir(exist_ok=True)
    test_file = tmp_path / 'test_chmod.txt'
    test_file.write_text('Testing')
    chmod(test_file, 0o660)
    os.chmod(str(test_file), 0o444)
    assert test_file.stat().st_mode == 33152
    # We need to create a directory of files and sub directories
    test_dir = tmp_path / 'testing'
    test_dir.mkdir()
    test_sub_dir = test_dir / 'sub_dir'
    test_sub_dir.mkdir()
    test_sub_

# Generated at 2022-06-11 22:42:01.650208
# Unit test for function chmod
def test_chmod():
    from tests.osutils import TEST_DIR
    from flutils.pathutils import path_absent, temp_chdir
    from flutils.osutils import chmod
    from tempfile import TemporaryDirectory

    text = 'foobar'
    path = Path(TEST_DIR, 'chmod.txt')
    with path.open('w', encoding='utf-8') as f:
        f.write(text)

    # Test: file mode
    with temp_chdir(TEST_DIR):
        # test: change the mode of a file and ensure the mode was actually
        # changed
        chmod(path)
        assert path.stat().st_mode == 33152

        # test: chmod a file that doesn't exist
        tmp_dir = TemporaryDirectory()

# Generated at 2022-06-11 22:42:13.520392
# Unit test for function chmod
def test_chmod():
    r"""Test function `chmod` in module `pathutils`."""

    # Capture function `chmod`
    func = functools.partial(chmod, mode_file=0o644, mode_dir=0o755)

    # Make a path to a non-existing file and call function `chmod`
    func('/tmp/this/file/does/not/exist')

    # Make a path to a non-existing directory and call function `chmod`
    func('/tmp/this/dir/does/not/exist')

    # Make a path to an existing file and call function `chmod`
    path = Path('/tmp/flutils.pathutils.test_chmod.txt')
    path.write_text('')
    func(path)

    # Make a path to a non-existing directory and call function `ch

# Generated at 2022-06-11 22:42:23.837620
# Unit test for function directory_present
def test_directory_present():
    try:
        # Unit test for function directory_present
        from flutils.pathutils import directory_present
        from flutils.platformutils import path_separator
        test_path = directory_present(f"~{path_separator}tmp{path_separator}flutils_unittest_directory_present")
        assert isinstance(test_path, pathlib.PosixPath) is True
    finally:
        try:
            # Unit test for function directory_present
            test_path.rmdir()
        except:
            pass
test_directory_present()
del test_directory_present



# Generated at 2022-06-11 22:42:33.370161
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_dir'
    path_dir = normalize_path(path)
    path_dir.mkdir()

    open(str(path_dir / 'file1'), 'w').close()
    open(str(path_dir / 'file2'), 'w').close()
    os.symlink(str(path_dir / 'file1'), str(path_dir / 'file3'))
    os.symlink(str(path_dir / 'file2'), str(path_dir / 'file4'))

    path_absent(path)
    assert exists_as(path) == ''
    assert exists_as(path_dir / 'file1') == ''
    assert exists_as(path_dir / 'file2') == ''
    assert exists_as(path_dir / 'file3')

# Generated at 2022-06-11 22:42:35.008059
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user('root')
    assert user.pw_name == 'root'


# Generated at 2022-06-11 22:42:35.817334
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:42:48.518746
# Unit test for function path_absent
def test_path_absent():
    import shutil, tempfile

    dir_path = tempfile.mkdtemp()

    test_files = [
        'a',
        'b',
        (
            'c',
            'd'
        ),
        (
            'e',
            'f',
            'g'
        ),
        (
            'h',
            (
                'i',
                'j',
                'k'
            )
        ),
        (
            'l',
            (
                'm',
                'n',
                (
                    'o',
                    'p',
                    'q'
                )
            )
        ),
    ]

    for item in test_files:
        if len(item) == 1:
            f = open(os.path.join(dir_path, item), mode='w')


# Generated at 2022-06-11 22:42:49.975561
# Unit test for function chown
def test_chown():
    """Unit test for function chown."""
    pass



# Generated at 2022-06-11 22:43:00.383504
# Unit test for function chown
def test_chown():
    # Setup
    from tempfile import mkstemp
    from os import path

    (fp, fpath) = mkstemp()
    os.close(fp)
    try:
        # Test with a Path object
        os.remove(path.join(path.dirname(__file__), 'utils', 'temp2.tmp'))
    except FileNotFoundError:
        pass

    file = path.join(path.dirname(__file__), 'utils', 'temp.tmp')

    if sys.platform == 'darwin':
        # On macOS, you can only change a file's group if you are a member of
        # that group.  So I'm just going to have to assume that this is working
        # on macOS.
        return

# Generated at 2022-06-11 22:44:02.906854
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/random') == 'block device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/tmp/osutils_test_fifo') == 'FIFO'
    assert exists_as('/tmp/osutils_test_socket') == 'socket'
    assert exists_as('/tmp/this_does_not_exist') == ''


# Generated at 2022-06-11 22:44:11.450833
# Unit test for function chown
def test_chown():
    # Test with include_parent True
    try:
        os.makedirs('/tmp/flutils.utest.pathutils')
    except FileExistsError:
        pass
    chown('/tmp/flutils.utest.pathutils', '-1', '-1')
    Path('/tmp/flutils.utest.pathutils/foo').touch()
    chown('/tmp/flutils.utest.pathutils', include_parent=True)
    assert Path('/tmp/flutils.utest.pathutils/foo').owner() == getpass.getuser()



# Generated at 2022-06-11 22:44:22.926608
# Unit test for function directory_present
def test_directory_present():
    parent = directory_present('~/tmp/flutils/pathutils/test')
    assert parent.is_dir()
    assert parent.name == 'test'

    # Re-run the function to test when the path is
    # an absolute path.
    parent = directory_present(parent)
    assert parent.is_dir()
    assert parent.name == 'test'
    assert parent.parent.name == 'pathutils'

    # Test the function is idempotent.
    parent = directory_present(parent)
    assert parent.is_dir()
    assert parent.name == 'test'

    # Test the function when the path exists as a directory.
    parent = directory_present(parent)
    assert parent.is_dir()

    # Test the function when the path exists as a file.
    parent.touch()

# Generated at 2022-06-11 22:44:30.334863
# Unit test for function chmod
def test_chmod():
    func = chmod
    if sys.platform.startswith('win'):
        skip = True
    else:
        skip = False
    # noinspection PyShadowingNames
    def _test_chmod(path, *args, **kwargs) -> None:
        path = str(path)
        path_ = normalize_path(path)
        if path_.is_dir():
            old_mode = get_mode(path, is_dir=True)
        else:
            old_mode = get_mode(path)

        if 'mode_file' not in kwargs:
            kwargs['mode_file'] = 0o660
        if 'mode_dir' not in kwargs:
            kwargs['mode_dir'] = 0o770


# Generated at 2022-06-11 22:44:42.604622
# Unit test for function chown
def test_chown():
    def _test_chown(
            path: _PATH,
            user: str,
            group: str,
            include_parent: bool = False
    ) -> None:

        cwd = os.getcwd()


# Generated at 2022-06-11 22:44:44.204919
# Unit test for function chmod
def test_chmod():
    # FIXME: write unit test for chmod()
    assert 0
# vim: set ft=python :

# Generated at 2022-06-11 22:44:52.475304
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'tmp/chown.txt'
    path.parent.mkdir(exist_ok=True)
    path.touch()

    orig_uid = get_os_user(getpass.getuser()).pw_uid
    orig_gid = get_os_group(getpass.getuser()).gr_gid
    assert path.stat().st_uid == orig_uid
    assert path.stat().st_gid == orig_gid

    _uid = pwd.getpwnam('root').pw_uid
    _gid = grp.getgrnam('wheel').gr_gid
    chown(path, user='root', group='wheel')
    assert path.stat().st_uid == _uid
    assert path.stat().st_gid == _gid



# Generated at 2022-06-11 22:45:03.812114
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    # Create a temporary directory in the default directory.
    tmp_dir = Path(tempfile.gettempdir())
    # Create a temporary directory to test the path_absent function.
    with tempfile.TemporaryDirectory(dir=tmp_dir.as_posix()) as tmp_dir:
        tmp_dir = Path(tmp_dir)

        # Test a directory.
        tmp_dir_path = tmp_dir / 'dir_one'
        tmp_dir_path.mkdir()
        path_absent(tmp_dir_path.as_posix())
        assert exists_as(tmp_dir_path) == ''

        # Test a file.
        tmp_file_path = tmp_dir / 'file_one'
        tmp_file_path.touch()
        path_

# Generated at 2022-06-11 22:45:11.007887
# Unit test for function path_absent
def test_path_absent():
    with TemporaryDirectory() as d:
        create_dir(
            d,
            user='foo',
            group='bar',
            mode=0o700
        )
        create_dir(
            '%s/foo' % d,
            user='foo2',
            group='bar2',
            mode=0o700
        )
        create_dir(
            '%s/foo/bar' % d,
            user='foo3',
            group='bar3',
            mode=0o700
        )
        create_dir(
            '%s/foo/bar/foobar' % d,
            user='foo4',
            group='bar4',
            mode=0o700
        )

# Generated at 2022-06-11 22:45:21.948915
# Unit test for function directory_present
def test_directory_present():
    from os import rmdir
    from shutil import rmtree
    from string import ascii_letters
    from tempfile import mkdtemp

    from flutils.pathutils import directory_present


    # Testing for path containing a glob pattern
    try:
        directory_present('/tmp/test_directory_present/**')
    except ValueError:
        pass
    else:
        raise RuntimeError('The path "test_directory_present/**" should NOT '
                           'be accepted.')


    # Testing for return type
    assert isinstance(directory_present(mkdtemp()), PosixPath)


    # Testing for a path that does not exist
    test_path = mkdtemp(prefix='test_directory_present-')
    rmdir(test_path)

    assert directory_present(test_path) == Path