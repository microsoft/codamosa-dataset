

# Generated at 2022-06-11 22:36:26.765864
# Unit test for function find_paths
def test_find_paths():
    pattern = os.path.expanduser('~/tmp/*')
    result = list(find_paths(pattern))
    assert result == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-11 22:36:27.862531
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('__pycache__') == 'directory'


# Generated at 2022-06-11 22:36:35.429203
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests import TestCase
    from pathlib import Path
    from unittest.mock import patch

    path = Path('~/flutils.tests.tmp').expanduser()

    try:
        path.mkdir()

        f_path = path / 'f.txt'
        f_path.touch()

        d_path = path / 'd'
        d_path.mkdir()

        chmod('~/flutils.tests.tmp/**')

        os_path = Path('~/flutils.tests.tmp').expanduser()
        self.assertTrue(os_path.exists())

    finally:
        path.rmdir()



# Generated at 2022-06-11 22:36:40.057228
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.testhelpers import TestPaths
    path = TestPaths.pathlib
    path_absent(path)
    assert not path.exists()
    path_absent(path)

# Generated at 2022-06-11 22:36:52.346329
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.osutils import temp_dir
    with temp_dir() as temp_path:
        create_file(temp_path / 'file_one.txt', content='foo')
        create_file(temp_path / 'file_two.txt', content='foo')
        create_file(temp_path / 'file_three.txt', content='foo')
        (temp_path / 'other_dir').mkdir(mode=0o700)
        create_file(temp_path / 'other_dir' / 'file_four.txt', content='foo')
        create_file(temp_path / 'other_dir' / 'file_five.txt', content='foo')

# Generated at 2022-06-11 22:36:56.814125
# Unit test for function chown
def test_chown():
    path = '~/tests/flutils/pathutils/osutils/chown/'
    d = Path(path)
    d.mkdir(0o700, parents=True)
    with open(path + 'foo', 'wt') as f:
        f.write('foo')

    chown(path + 'foo')
    assert os.stat(path + 'foo').st_uid == os.getuid()
    assert os.stat(path + 'foo').st_gid == os.getgid()



# Generated at 2022-06-11 22:37:07.863150
# Unit test for function directory_present
def test_directory_present():
    """Unit test for directory_present."""

    def _test_path_func(path: Path) -> None:
        directory_present(path)
        assert exists_as(path) == 'directory'

    path = Path('~/tmp/flutils/.test_directory_present').expanduser()
    assert exists_as(path) == ''
    try:
        _test_path_func(path)
        assert exists_as(path) == 'directory'
        assert path.stat().st_mode == 16832
    finally:
        if path.exists():
            path.rmdir()

    path = None
    assert path is None
    try:
        _test_path_func(path)
    except TypeError:
        pass

# Generated at 2022-06-11 22:37:15.966630
# Unit test for function chmod
def test_chmod():
    import pytest

    from flutils.tests.pathutils.fixtures import basic_file, basic_dir

    def test_no_mode_file_or_mode_dir(basic_file):
        chmod(basic_file)
        assert basic_file.stat().st_mode == 0o100600
        chmod(basic_file.parent)
        assert basic_file.parent.stat().st_mode == 0o100700

    def test_given_mode_file(basic_file):
        chmod(basic_file, mode_file=0o600)
        assert basic_file.stat().st_mode == 0o100600
        chmod(basic_file, mode_file=0o660)
        assert basic_file.stat().st_mode == 0o100660


# Generated at 2022-06-11 22:37:22.509785
# Unit test for function chmod
def test_chmod():
    tmp_dir = PosixPath('~/tmp/flutils.tests.pathutils')
    tmp_file = tmp_dir / 'flutils.tests.pathutils.tmp'
    tmp_file.parent.mkdir(parents=True, exist_ok=True)
    tmp_file.touch()
    chmod(tmp_file, 0o640)
    try:
        assert tmp_file.stat().st_mode & 0o777 == 0o640

        tmp_file.unlink()
        tmp_dir.rmdir()
    except AssertionError:
        raise
    except Exception as exc:
        raise AssertionError() from exc

test_chmod.flutils_test = True



# Generated at 2022-06-11 22:37:30.931131
# Unit test for function exists_as
def test_exists_as():
    """Test for fixture directory_present."""
    try:
        test_path = directory_present('~/tmp/test_path')

        # os.symlink() is only supported on POSIX systems.
        if os.name == 'posix':
            os.symlink(
                test_path.as_posix(),
                test_path.parent.joinpath('target.link').as_posix()
            )
            assert exists_as(test_path.parent.joinpath('target.link')) == ''
            assert exists_as(test_path) == 'directory'

    finally:
        shutil.rmtree(test_path.as_posix())



# Generated at 2022-06-11 22:37:38.848729
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    list(find_paths('/foo/bar'))



# Generated at 2022-06-11 22:37:47.401975
# Unit test for function exists_as
def test_exists_as():
    _test_dir = Path('/tmp/flutils.test/exists_as')
    if _test_dir.is_dir():
        rmtree(_test_dir)
    symbols = ['nonexistent', 'broken', 'dir', 'file', 'block', 'char',
               'fifo', 'socket']
    files = ['/tmp/flutils.test/exists_as/{}'.format(f) for f in symbols]
    test_files = dict(list(zip(symbols, files)))
    for k, v in test_files.items():
        if k == 'nonexistent':
            pass
        elif k == 'broken':
            open(v, 'w').close()

# Generated at 2022-06-11 22:37:53.189470
# Unit test for function path_absent
def test_path_absent():
    # Test path_absent with a file that doesn't exista
    path_absent(__file__)
    # Test path_absent with a symlink that doesn't exist
    path_absent(__file__ + 'missing')
    # Test path_absent with a symlink that does exist
    path_absent(__file__ + 'link')
    # Test path_absent with a directory
    path_absent(__file__ + 'dir')



# Generated at 2022-06-11 22:38:03.974275
# Unit test for function chmod
def test_chmod():
    # For function chmod
    from flutils.pathutils import chmod, exists_as, normalize_path
    from pathlib import Path
    import pytest

    tests = (
        # Test for a file that does not exist where the mode is the
        # default.  Nothing should happen since the file must
        # exist before the mode can be changed.
        ({
            'mode_file': None,
            'path': '~/tmp/flutils.tests.osutils.tst',
        },),
    )

    @pytest.mark.parametrize(('params',), tests)
    def test(params):
        path = normalize_path(params['path'])
        chmod(path, **params)



# Generated at 2022-06-11 22:38:06.499628
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt') == None


# Generated at 2022-06-11 22:38:15.079250
# Unit test for function path_absent
def test_path_absent():
    assert not os.path.exists('./tmp')
    os.mkdir('./tmp')
    with open('./tmp/foo.txt', 'w') as f:
        f.write('foo')
    try:
        path_absent('./tmp/foo.txt')
        assert not os.path.exists('./tmp/foo.txt')
        path_absent('./tmp')
        assert not os.path.exists('./tmp')
    finally:
        shutil.rmtree('./tmp')
    assert not os.path.exists('./tmp')



# Generated at 2022-06-11 22:38:27.043252
# Unit test for function chown
def test_chown():
    '''
    Unit tests for function chown
    '''
    # pylint: disable=too-few-public-methods
    class MockOs:
        '''
        Mock class for os.chown()
        '''
        @staticmethod
        def chown(path, uid, gid):
            if uid != 1001:
                raise OSError()
            if gid != 1002:
                raise OSError()
            if path == 'path1':
                return
            if path == 'path2':
                return
            if path == 'path3':
                return

        @staticmethod
        def path_exists(_):
            return False

    mock_os = MockOs()
    orig_chown = os.chown
    orig_exists = os.path.exists

# Generated at 2022-06-11 22:38:28.662992
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:38:40.559684
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil

    d = tempfile.mkdtemp()
    test_dir = os.path.join(d, 'test_dir_absent')
    test_file = os.path.join(test_dir, 'test_file_absent')
    os.makedirs(test_dir)
    open(test_file, 'a').close()

    assert os.path.exists(test_file)
    assert os.path.isdir(test_dir)

    path_absent(test_file)

    assert not os.path.exists(test_file)
    assert os.path.isdir(test_dir)

    path_absent(test_dir)

    assert not os.path.exists(test_file)

# Generated at 2022-06-11 22:38:50.598891
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmp_dir:
        anchor = tmp_dir
        path = Path(anchor)
        with path.open('w') as test_file:
            test_file.write('')

        test_path = '%s/test' % path.as_posix()
        create_file(test_path)
        assert exists_as(test_path) == 'file'

        found_paths = []
        for found_path in find_paths('%s/*' % path.as_posix()):
            found_paths.append(found_path)

        assert len(found_paths) == 2



# Generated at 2022-06-11 22:38:56.597121
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:39:08.048303
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    from pathlib import Path

    from flutils.pathutils import (
        chmod,
        directory_present,
        path_absent,
    )

    from flutils.tests.constants import (
        TEST_VARS,
        DIR_BASE,
    )

    dp = Path(DIR_BASE, 'tests')
    p = Path(dp, 'flutils.tests.pathutils.txt')
    p_dir = Path(dp, 'dir')
    p_dir_subdir = Path(p_dir, 'subdir')
    p_dir_subdir_file = Path(p_dir_subdir, 'file.txt')

    def mode(mode_str: str) -> int:
        return int(mode_str, 8)


# Generated at 2022-06-11 22:39:12.725168
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/nonexistent') == ''



# Generated at 2022-06-11 22:39:26.999380
# Unit test for function chown
def test_chown():
    """Unit tests for function chown."""
    from os import PathLike, stat
    from pathlib import Path
    from unittest.mock import patch
    from unittest.mock import call

    from flutils.pathutils import chown

    from .mockutils import (
        get_os_group as mock_get_os_group,
        get_os_user as mock_get_os_user,
    )

    # Test normal call
    with patch('flutils.pathutils.get_os_group') as mock_os_group:
        with patch('flutils.pathutils.get_os_user') as mock_os_user:
            with patch('flutils.pathutils.os') as mock_os:
                mock_os_user.side_effect = mock_get_os_user
                mock_os

# Generated at 2022-06-11 22:39:42.092019
# Unit test for function chmod
def test_chmod():
    # Test: chmod file.
    file_test = Path('/tmp/flutils.tests.osutils.txt')
    with file_test.open('w'):
        pass
    chmod(file_test, 0o660)
    result = os.stat(file_test).st_mode
    assert result == 0o100660
    os.remove(file_test)

    # Test: chmod dir.
    dir_test = Path('/tmp/flutils.tests.osutils')
    dir_test.mkdir()
    chmod(dir_test, mode_dir=0o770)
    result = os.stat(dir_test).st_mode
    assert result == 0o40750
    os.rmdir(dir_test)

    # Test: chmod file with glob pattern.

# Generated at 2022-06-11 22:39:56.701525
# Unit test for function chmod
def test_chmod():
    from tempfile import TemporaryDirectory

    from flutils.pathutils import (
        chmod,
        path_absent,
        path_exists_as,
        normalize_path,
        umask,
    )

    with TemporaryDirectory() as tmpdirname:
        with umask(0o022):
            path = Path(tmpdirname) / normalize_path('flutils.tests.osutils.txt')
            path.touch()
            path = normalize_path(path)

        try:
            assert path_absent(path) is False
        except AssertionError:
            pass
        else:
            chmod(path, 0o0660)
            assert path_exists_as(path) == {'type': 'file'}

# Generated at 2022-06-11 22:40:08.505150
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    test_path = (
        Path(__file__)
        .parent
        .parent
        .joinpath('tmp')
        .joinpath('flutils.tests.pathutils.txt')
    )
    assert test_path != directory_present(test_path)
    assert test_path.parent == directory_present(test_path.parent)

    test_path = Path(__file__).parent.parents[1]
    assert directory_present(test_path.joinpath('tmp')) == (
        test_path
        .joinpath('tmp')
        .as_posix()
    )

    test_path = Path(__file__).parent.parents[1]

# Generated at 2022-06-11 22:40:09.777315
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:40:10.862243
# Unit test for function chown
def test_chown():
    assert callable(chown) is True



# Generated at 2022-06-11 22:40:12.578225
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(normalize_path('~/tmp')) == 'directory'
    assert exists_as(normalize_path('~/tmp/flutils.tests.osutils.txt')) == 'file'


# Generated at 2022-06-11 22:40:22.518236
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-11 22:40:31.348636
# Unit test for function find_paths
def test_find_paths():
    # Given
    pattern = '/tmp/*'
    path_one = '/tmp/file_one.txt'
    path_two = '/tmp/dir_one'

    _mkdir(path_two)
    _touch(path_one)

    # exec
    gen = find_paths(pattern)
    results = list(gen)

    # assert
    assert isinstance(results, list)
    assert isinstance(results[0], Path)
    assert results[0].as_posix() == '/tmp/file_one.txt'
    assert results[1].as_posix() == '/tmp/dir_one'

    # cleanup.
    for result in results:
        result.unlink()
    _rmdir(path_two)



# Generated at 2022-06-11 22:40:36.938719
# Unit test for function chown
def test_chown():
    path = Path('~/tmp/flutils.tests.pathutils.txt').expanduser()
    chown(path)
    assert path.owner() == getpass.getuser()
    assert path.group() == os.environ['USER']


# Generated at 2022-06-11 22:40:45.268155
# Unit test for function chmod
def test_chmod():
    from os import (
        makedirs,
        path
    )
    from tempfile import mkdtemp
    import contextlib

    from flutils.pathutils import chmod

    @contextlib.contextmanager
    def _test_chmod(
            path: str,
            mode_file: Optional[int] = None,
            mode_dir: Optional[int] = None,
            include_parent: bool = False
    ) -> None:
        if mode_file is None:
            mode_file = 0o600

        if mode_dir is None:
            mode_dir = 0o700

        # Create the path if it doesn't exist
        with contextlib.suppress(FileExistsError):
            makedirs(path, mode_dir)

        # Create the test file

# Generated at 2022-06-11 22:40:57.206994
# Unit test for function chmod
def test_chmod():
    bl_str = os.path.expanduser('~/tmp/flutils.tests.osutils.txt')
    bl_path = Path('~/tmp/flutils.tests.osutils.txt')
    bl_path.touch(exist_ok=True)

    chmod(bl_str, 0o660)
    assert (os.stat(bl_str).st_mode & 0o777) == 0o660
    chown(bl_str, get_os_user(), get_os_group())

    bl_str = os.path.expanduser('~/tmp/flutils.tests.osutils.txt')
    bl_path = Path('~/tmp/flutils.tests.osutils.txt')
    bl_path.touch(exist_ok=True)

    chmod(bl_path, 0o660)


# Generated at 2022-06-11 22:40:58.591339
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')



# Generated at 2022-06-11 22:40:59.439868
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-11 22:41:00.698313
# Unit test for function directory_present
def test_directory_present():
    return directory_present


# Generated at 2022-06-11 22:41:09.446758
# Unit test for function find_paths
def test_find_paths():
    tmp_root = Path(tempfile.mkdtemp())
    prefix = tmp_root / 'pathutils'
    file_one = prefix / 'file_one'
    dir_one = prefix / 'dir_one'
    dir_two = dir_one / 'dir_two'
    file_one.touch(exist_ok=True)
    dir_one.mkdir(parents=True, exist_ok=True)
    dir_two.mkdir(parents=True, exist_ok=True)
    pattern = prefix / '*'
    result = list(find_paths(pattern))
    assert prefix.exists() is True
    assert file_one.exists() is True
    assert dir_one.exists() is True
    assert dir_two.exists() is True
    assert pattern.exists() is False
   

# Generated at 2022-06-11 22:41:13.568771
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert Path('~/tmp/flutils.tests.osutils.txt').is_file() is True



# Generated at 2022-06-11 22:41:34.592724
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]
    assert list(find_paths('/tmp/*')) == [
        Path('/tmp/file_one'),
        Path('/tmp/dir_one')
    ]



# Generated at 2022-06-11 22:41:35.159086
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:41:46.325612
# Unit test for function chmod
def test_chmod():
    from os import chmod
    import tempfile

    test_parent = cast(Path, Path(tempfile.gettempdir()) / 'flutils.tests')
    if test_parent.exists() is False:
        test_parent.mkdir()

    test_path = Path(test_parent / 'osutils.txt')
    test_dir = Path(test_parent / 'osutils')
    if test_dir.exists() is False:
        test_dir.mkdir()
    test_path2 = Path(test_dir / 'test.txt')

    if test_path.exists():
        test_path.unlink()

    if test_path2.exists():
        test_path2.unlink()


# Generated at 2022-06-11 22:41:52.687388
# Unit test for function exists_as
def test_exists_as():
    """Test the ``exists_as()`` function."""

    # Setup
    paths = ('/var/log', '/does/not/exist')

    # Run
    for path in paths:
        exists_as(path)

    # Validate
    assert exists_as('/var/log') == 'directory'

    # Teardown
    del paths



# Generated at 2022-06-11 22:42:04.306999
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as tmpdir:
        test_path = Path(tmpdir, 'test_path')

        # Ensure that the path does not exist and that it is created.
        created_path = directory_present(test_path)
        assert created_path == test_path

        # Ensure that a path that exists as a file raises an error.
        with open(test_path.as_posix(), 'w'):
            with pytest.raises(FileExistsError):
                directory_present(test_path)

        # Ensure that a path that exists as a symlink raises an error.
        test_path_symlink = test_path.with_suffix('.symlink')
        test_path_symlink.symlink_to(test_path)

# Generated at 2022-06-11 22:42:09.305010
# Unit test for function exists_as
def test_exists_as():
    directory_present('/tmp/tests')
    assert exists_as('/tmp/tests') == 'directory'
    remove('/tmp/tests')
    assert exists_as('/tmp/tests') == ''



# Generated at 2022-06-11 22:42:17.219613
# Unit test for function directory_present
def test_directory_present():
    for user in (
        None,
        'root',
        'uid: %s' % getpass.getuser(),
    ):
        for group in (
            None,
            'root',
            'gid %s' % grp.getgrgid(os.getgid()).gr_name,
        ):
            for mode in (
                None,
                0o600,
            ):
                with tempfile.TemporaryDirectory() as tmpdir:
                    p = Path(tmpdir)
                    test_path = p / 'directory_present'
                    assert test_path.exists() is False
                    assert exists_as(test_path) == ''

                    path = directory_present(
                        test_path,
                        mode=mode,
                        user=user,
                        group=group,
                    )

# Generated at 2022-06-11 22:42:29.135285
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from flutils.osutils import user_is_root
    from flutils.osutils import user_is_sudoer
    from flutils.osutils import get_os_username
    from tempfile import TemporaryDirectory

    def create_dir(dir_path: Path) -> None:
        dir_path.mkdir(mode=0o777, parents=True, exist_ok=True)

    def create_file(file_path: Path) -> None:
        file_path.touch(mode=0o666, exist_ok=True)

    def _run_chmod(dir_path, file_path):
        chmod(dir_path, mode_dir=0o775, mode_file=0o664)

# Generated at 2022-06-11 22:42:34.995996
# Unit test for function chmod
def test_chmod():
    import flutils.osutils
    import os

    from flutils.osutils import chmod

    path = Path() / 'flutils.tests.osutils.txt'
    path.touch()
    os.chmod(path.as_posix(), 0o000)
    chmod(path, 0o660)
    assert os.stat(path.as_posix()).st_mode == (os.stat.S_IFREG | 0o660)
    path.unlink()




# Generated at 2022-06-11 22:42:42.370391
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths.

    .. note:: This test is only valid if the glob pattern will match
        something.  Otherwise the unit test will fail.

    """
    from flutils.pathutils import find_paths
    from pathlib import Path
    from typing import Generator
    paths = find_paths(Path().cwd())
    assert isinstance(paths, Generator)
    assert Path().cwd() in paths



# Generated at 2022-06-11 22:43:04.793210
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile
    import pytest
    from pathlib import Path
    from flutils.pathutils import chmod, normalize_path

    # Setup an empty temp directory
    temp_dir = tempfile.TemporaryDirectory()

    # Change the temp directory to the temp directory
    os.chdir(temp_dir.name)

    Path(temp_dir.name, 'banana').mkdir(mode=0o755, parents=False, exist_ok=True)
    Path(temp_dir.name, 'banana', 'file.txt').touch(mode=0o644, exist_ok=True)
    Path(temp_dir.name, 'banana', 'directory').mkdir(mode=0o755, parents=False, exist_ok=True)

    # chmod a file that exists
   

# Generated at 2022-06-11 22:43:10.625806
# Unit test for function exists_as
def test_exists_as():
    directory_present('/tmp/test_path')
    assert exists_as('/tmp/test_path') == 'directory'

    directory_present('/tmp/test_path_2')
    assert exists_as('/tmp/test_path_2') == 'directory'

    Path('/tmp/test_path_2/test_file').touch()
    assert exists_as('/tmp/test_path_2/test_file') == 'file'

    Path('/tmp/test_path/test_link').symlink_to('/tmp/test_path_2/test_file')
    assert exists_as('/tmp/test_path/test_link') == 'file'


# Generated at 2022-06-11 22:43:17.991112
# Unit test for function find_paths
def test_find_paths():
    # Create a temporary directory and file.
    tmp_dir = Path('~/tmp').expanduser().joinpath(
        'flutils.tests.pathutils.find_paths'
    )
    tmp_dir.mkdir(exist_ok=True)

    tmp_file = tmp_dir.joinpath('flutils.tests.pathutils.find_paths.txt')
    tmp_file.touch()

    found = list(find_paths(tmp_dir))

    # Cleanup temporary directory and file.
    tmp_file.unlink()
    tmp_dir.rmdir()

    assert len(found) == 2
    assert tmp_file in found
    assert tmp_dir in found



# Generated at 2022-06-11 22:43:26.078994
# Unit test for function directory_present
def test_directory_present():
    from shutil import rmtree
    from tempfile import mkdtemp
    from .osutils import file_present, _get_real_user, _get_real_group

    def _get_user_group(path: Path) -> dict:
        stat = path.stat()
        return dict(
            uid=stat.st_uid,
            gid=stat.st_gid,
        )

    def _get_mode(path: Path) -> int:
        return path.stat().st_mode & 0o7777

    user = _get_real_user()
    group = _get_real_group()

    rootdir = Path(mkdtemp())
    assert rootdir.exists() is True
    assert rootdir.is_dir() is True
    assert rootdir.is_symlink() is False
   

# Generated at 2022-06-11 22:43:28.949972
# Unit test for function path_absent
def test_path_absent():
    # Setup test
    assert getpass.getuser() == 'test_user'
    stream: TextIO = StringIO()
    sys.stdout = stream
    home: Path = Path(os.path.expanduser('~'))
    p = home / 'tmp' / 'test_path'
    p.mkdir(parents=True)
    assert p.exists()
    # Test the function
    path_absent(p)
    sys.stdout = sys.__stdout__
    assert not p.exists()



# Generated at 2022-06-11 22:43:37.097980
# Unit test for function find_paths
def test_find_paths():
    r"""Test function find_paths().

    Test scenarios:

        * Find existing paths that match a glob pattern, including a path
          with a glob pattern.
        * Find non-existing paths that match a glob pattern, including a path
          with a glob pattern.
        * Find existing paths that match glob patterns with a non-existing
          base directory.
        * Find non-existing paths that match glob patterns with a non-existing
          base directory.

    Test coverage: 100%

    """
    from flutils.pathutils import find_paths
    from flutils.testing import suppress_stderr

    # Paths in the directory will be tested.
    POSIX_TEST_DIR = Path('/tmp/flutils.test_pathutils/posix_test_dir/')

    # Paths outside of the directory will be tested.
    POSIX

# Generated at 2022-06-11 22:43:45.825058
# Unit test for function chown
def test_chown():
    from .tests import user
    from .tests import group

    # Create a file for test
    Path('/tmp/flutils.tests.osutils.txt').write_text('')

    # Change the user and group of the test file
    chown('/tmp/flutils.tests.osutils.txt', user=user, group=group)
    # Get the uid and gid of the test file
    uid, gid = os.stat('/tmp/flutils.tests.osutils.txt').st_uid, os.stat('/tmp/flutils.tests.osutils.txt').st_gid

    # Verify the user and group of the test file and cleanup
    assert uid == get_os_user(user).pw_uid
    assert gid == get_os_group(group).gr_gid
    os

# Generated at 2022-06-11 22:43:54.035815
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_path:
        res = directory_present(
            os.path.join(tmp_path, 'directory_present'),
            mode=0o777,
            user='-1',
            group='-1'
        )
        assert res.as_posix() == os.path.join(tmp_path, 'directory_present')
        assert res.is_dir() is True
        assert oct(res.stat().st_mode & 0o777) == '0o777'
        assert res.stat().st_uid == os.getuid()
        assert res.stat().st_gid == os.getgid()
        res = directory_present(
            os.path.join(tmp_path, 'directory_present')
        )

# Generated at 2022-06-11 22:43:56.752100
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.chown.1')
    chown('/tmp/flutils.tests.chown.2', user='-1')



# Generated at 2022-06-11 22:44:04.579773
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from flutils.testutils import TestCase
    import os

    class TestChown(TestCase):

        def test_non_existent_path(self):
            self.assertFalse(os.environ.get('TEST_NON_EXISTENT_PATH'))
            chown(os.environ['TEST_NON_EXISTENT_PATH'], user='-1')

        def test_change_user(self):
            with TemporaryDirectory() as td:
                path = Path(td) / 'foo'
                os.mkdir(path)
                chown(path, user=self.current_user)
                self.assertEqual(path.stat().st_uid, self.current_uid)


# Generated at 2022-06-11 22:44:22.885111
# Unit test for function chown
def test_chown():
    # This is a very basic test to see if an OSError gets raised.
    # So this only tests that the function works on the surface and
    # it's up to the osutils unit tests to make sure the function works
    # as expected.
    import pytest

    with pytest.raises(OSError):
        chown('/tmp', user='foobar')

    with pytest.raises(OSError):
        chown('/tmp', group='foobar')



# Generated at 2022-06-11 22:44:30.274197
# Unit test for function chown
def test_chown():
    import os
    import stat
    import tempfile
    from pathlib import Path
    from flutils.pathutils import chown

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        file_path = temp_dir / 'test_chown.txt'
        file_path.touch()

        # Verify mode is set correctly for file after chmod
        chown(file_path, user='-1', group='-1')
        if getpass.getuser() == 'root':
            assert file_path.owner() == 'root'
            assert file_path.group() == 'root'

        chown(file_path, user=getpass.getuser(), group=getpass.getuser())
        assert file_path.owner() == getpass.getuser()
        assert file

# Generated at 2022-06-11 22:44:42.567225
# Unit test for function find_paths
def test_find_paths():
    import pytest
    from unittest.mock import patch

    @patch('pathlib.Path.as_posix')
    def _test_find_paths(
            mock_as_posix:\
            # NOQA
            MagicMock,
            path: _PATH,
            search: str,
            root: str,
            glob_list: Iterable[str],
    ) -> None:
        mock_as_posix.return_value = path

        # Pre-mock the glob method to return a generator.
        path_class = (
            Path.glob
            if Path.glob.__code__.co_flags & 0x100 else  # NOQA
            Path.glob.__func__
        )

# Generated at 2022-06-11 22:44:50.922579
# Unit test for function find_paths
def test_find_paths():
    path = Path.home()
    from flutils.osutils import make_dirs_if_missing
    make_dirs_if_missing(
        paths=[
            path / 'tmp/dir_one',
            path / 'tmp/dir_two',
            path / 'tmp/dir_three',
            path / 'tmp/dir_one/file_four',
            path / 'tmp/dir_two/file_five',
            path / 'tmp/dir_two/file_six',
            path / 'tmp/dir_three/file_seven',
        ],
    )

# Generated at 2022-06-11 22:44:53.637046
# Unit test for function path_absent
def test_path_absent():
    path = '/tmp/test_path'
    open(path, 'w').close()
    assert os.path.exists(path)
    path_absent(path)
    assert not os.path.exists(path)



# Generated at 2022-06-11 22:45:04.878985
# Unit test for function chmod
def test_chmod():
    """Unit test for chmod."""

    from .osutils import (
        temp_chdir,
        temp_umask,
    )

    # Test both None and 0, which is a valid mode
    for mode_file in (None, 0):
        for mode_dir in (None, 0):
            with temp_chdir() as tmpdir:
                for fn in (
                        'file.txt',
                        'another-file.txt',
                        'dir-1',
                        'dir-2',
                        'dir-3',
                ):
                    Path(fn).touch()

                Path('dir-1').mkdir()
                Path('dir-2').mkdir()
                Path('dir-3').mkdir()

                # Test with an existing file

# Generated at 2022-06-11 22:45:18.035524
# Unit test for function find_paths
def test_find_paths():
    from typing import Generator
    from .osutils import makedirs
    from .osutils import remove_paths
    with makedirs('~/tmp/tests/flutils/pathutils'):
        with open('~/tmp/tests/flutils/pathutils/a.txt', 'w') as _:
            pass
        with open('~/tmp/tests/flutils/pathutils/b.txt', 'w') as _:
            pass
        with open('~/tmp/tests/flutils/pathutils/c.txt', 'w') as _:
            pass
    with open('~/tmp/tests/flutils/a.txt', 'w') as _:
        pass
    with open('~/tmp/tests/flutils/b.txt', 'w') as _:
        pass

# Generated at 2022-06-11 22:45:18.636353
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:45:19.165797
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:45:32.853898
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        path = Path(tmpdir).expanduser()
        file1 = path / 'file_one'
        file2 = path / 'file_two'
        file3 = path / 'file_three'
        dir1 = path / 'dir_one'
        dir1.mkdir(0o700, parents=True)
        file4 = dir1 / 'file_four'
        file5 = dir1 / 'file_five'
        file6 = dir1 / 'file_six'
        with file1.open('w') as fb, file2.open('w') as fb:
            fb.write('test')
        with file3.open('w') as fb:
            fb.write('test')