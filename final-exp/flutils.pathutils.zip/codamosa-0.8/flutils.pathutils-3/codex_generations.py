

# Generated at 2022-06-11 22:36:43.846351
# Unit test for function chown
def test_chown():

    temp_file = Path().joinpath('tmp', 'flutils.tests.pathutils.txt')

    if temp_file.is_file() is False:
        temp_file.touch()

    assert temp_file.is_file() is True
    chown(temp_file)
    assert temp_file.stat().st_uid == os.getuid()



# Generated at 2022-06-11 22:36:47.722134
# Unit test for function find_paths
def test_find_paths():
    # test with a single pattern
    pattern = normalize_path('~/tmp/file*')
    assert list(find_paths(pattern))[0] == \
           normalize_path('~/tmp/file_one')



# Generated at 2022-06-11 22:36:50.790895
# Unit test for function exists_as
def test_exists_as():
    path = '~/tmp'
    return_value = exists_as(path)
    expected_value = 'directory'
    #print(f'return_value: {return_value}')
    #print(f'expected_value: {expected_value}')
    assert return_value == expected_value
test_exists_as()



# Generated at 2022-06-11 22:36:57.893266
# Unit test for function chmod
def test_chmod():
    from pathlib import Path
    from time import time

    path = Path(f'/tmp/flutils.tests.osutils.{int(time()):x}.txt')
    path.touch()
    path.chmod(0o600)
    print(path, oct(path.stat().st_mode))
    assert oct(path.stat().st_mode) == '0o100600'

    chmod(str(path), 0o644)
    assert oct(path.stat().st_mode) == '0o100644'

    path.unlink()
    assert path.exists() is False

    path = Path(f'/tmp/flutils.tests.osutils.{int(time()):x}')
    path.mkdir()
    path.chmod(0o700)

# Generated at 2022-06-11 22:37:07.633968
# Unit test for function chmod
def test_chmod():
    from flutils.testutils import make_temp_dir, remove_temp_dir

    tmp_dir = make_temp_dir()

    try:
        file_ = tmp_dir / 'flutils.tests.pathutils.file.txt'
        directory = tmp_dir / 'flutils.tests.pathutils.directory'

        file_.write_text('foo')
        directory.mkdir()

        chmod(file_, 0o660)
        chmod(directory, 0o770)

        assert file_.stat().st_mode & 0o777 == 0o660
        assert directory.stat().st_mode & 0o777 == 0o770
    finally:
        remove_temp_dir(tmp_dir)



# Generated at 2022-06-11 22:37:12.105144
# Unit test for function find_paths
def test_find_paths():
    # Setup
    pattern = Path('~/tmp/*')
    # Exercise
    gen = find_paths(pattern)
    # Verify
    expected = Path('~/tmp/file_one')
    actual = next(gen)
    assert actual == expected
    # Cleanup - none necessary



# Generated at 2022-06-11 22:37:24.270326
# Unit test for function path_absent
def test_path_absent():
    import tempfile

    tests = []

    with tempfile.TemporaryDirectory() as tdir:
        tdir = Path(tdir)

        path = tdir / 'file'
        path.touch()
        tests.append((path, 'file'))

        path = tdir / 'link_broken'
        path.symlink_to('file_missing')
        tests.append((path, 'link'))

        path = tdir / 'link_ok'
        path.symlink_to(tdir / 'file')
        tests.append((path, 'link'))

        path = tdir / 'dir'
        path.mkdir()
        (path / 'file').touch()
        (path / 'link_broken').symlink_to('file_missing')
        (path / 'link_ok').symlink

# Generated at 2022-06-11 22:37:26.619996
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
test_exists_as()



# Generated at 2022-06-11 22:37:33.970279
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = '/tmp/flutils.tests.pathutils.find_paths/'
    file_one = tmp_dir + 'file_one'
    file_two = tmp_dir + 'file_two'
    dir_one = tmp_dir + 'dir_one'
    dir_two = tmp_dir + 'dir_two'
    paths = [dir_two, file_one, dir_one, file_two]


# Generated at 2022-06-11 22:37:42.145132
# Unit test for function find_paths
def test_find_paths():
    path = Path.home() / 'tmp'
    file_one = path / 'file_one'
    file_one.touch()
    dir_one = path / 'dir_one'
    dir_one.mkdir()
    for found_path in find_paths('~/tmp/*'):
        assert found_path.as_posix().endswith('/tmp/file_one') or \
            found_path.as_posix().endswith('/tmp/dir_one')


# Generated at 2022-06-11 22:38:08.608288
# Unit test for function chown
def test_chown():
    """Function which tests the functionality of chown."""
    path = Path(__file__)
    initial_owner = get_os_user().pw_name
    initial_group = get_os_group().gr_name
    chown(path)
    path_owner = get_os_user(os.stat(path.as_posix()).st_uid).pw_name
    path_group = get_os_group(os.stat(path.as_posix()).st_gid).gr_name
    assert initial_owner == path_owner
    assert initial_group == path_group
    second_user = get_os_user(getpass.getuser()).pw_uuid
    second_group = get_os_group(getpass.getuser()).gr_uuid

# Generated at 2022-06-11 22:38:14.868132
# Unit test for function chown
def test_chown():
    chown('./flutils.tests.pathutils.txt', user='-1', group='-1')
    chown('./flutils.tests.pathutils.txt', user='-1', group=None)
    chown('./flutils.tests.pathutils.txt', user=None, group='-1')
    chown('./flutils.tests.pathutils.txt', user=None, group=None)
    chown('./flutils.tests.pathutils.txt', user=None, group=None)
test_chown()



# Generated at 2022-06-11 22:38:24.793649
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    if path.exists():
        if path.is_file():
            os.chmod(path.as_posix(), mode=0o644)
            chown(path.as_posix(), user='root', group='root')
            assert os.stat(path.as_posix()).st_uid == 0
            assert os.stat(path.as_posix()).st_gid == 0
    else:
        Path('~/tmp/flutils.tests.osutils.txt').touch()
        test_chown()



# Generated at 2022-06-11 22:38:26.327506
# Unit test for function get_os_user
def test_get_os_user():
    assert bool(get_os_user().pw_name) is True



# Generated at 2022-06-11 22:38:26.899960
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-11 22:38:37.175689
# Unit test for function chown
def test_chown():
    from os import getuid
    from os.path import exists, join
    from tempfile import TemporaryDirectory
    from .pathutils import chown

    # Test with a user that does not exist
    with TemporaryDirectory() as folder:
        with pytest.raises(OSError) as err:
            chown(join(folder, 'file.txt'), user='foobar')
        assert str(err.value) == 'User "foobar" does not exist!'

    # Test with a group that does not exist
    with TemporaryDirectory() as folder:
        with pytest.raises(OSError) as err:
            chown(join(folder, 'file.txt'), group='foobar')
        assert str(err.value) == 'Group "foobar" does not exist!'

    # Test that the given user and/or group is applied

# Generated at 2022-06-11 22:38:41.866755
# Unit test for function find_paths
def test_find_paths():
    # from flutils.pathutils import find_paths
    assert type(find_paths('.')) == GeneratorType

    out = Path('.')
    for result in find_paths('~/tmp/*'):
        assert type(result) == out.__class__
        assert result.exists()



# Generated at 2022-06-11 22:38:47.969763
# Unit test for function find_paths
def test_find_paths():
    test_dir = directory_present(Path('~/tmp/test_dir').expanduser())
    with open(test_dir / 'test_file', 'w', encoding='utf-8') as f:
        f.write('test_data')
    file = find_paths(test_dir / 'test_file')
    assert file is not None



# Generated at 2022-06-11 22:38:52.651706
# Unit test for function chown
def test_chown():
    import os
    path = Path().cwd() / 'foo'
    path.touch()
    try:
        os.stat(path)
        chown(path.as_posix())
    finally:
        os.remove(path.as_posix())



# Generated at 2022-06-11 22:39:01.309801
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists

    tmp_dir = Path(__file__).parent.joinpath('tmp')
    tmp_dir.mkdir(parents=True, exist_ok=True)
    test_dir = tmp_dir.joinpath('path_absent')
    # Ensure the test directory is not there
    path_absent(test_dir)
    assert path_exists(test_dir) is False, 'Test directory exists when it ' \
        'should not.'
    # Create a directory and some files.
    test_dir.mkdir()
    test_dir.joinpath('file_one').touch()
    test_dir.joinpath('dir_one').mkdir()

# Generated at 2022-06-11 22:39:39.661169
# Unit test for function directory_present
def test_directory_present():
    from os import environ, mkdir, path
    from pathlib import Path
    from shutil import rmtree
    from tempfile import gettempdir

    from .osutils import temporary_directory

    from flutils.pathutils import directory_present, normalize_path

    # Test path is absolute.
    assert normalize_path('/tmp').is_absolute() is True

    # Test path from PosixPath().
    assert (
        TypeError(
            'The path: /home/len must NOT contain any glob patterns.'
        ) == directory_present(Path('/home/len/*'))
    )

# Generated at 2022-06-11 22:39:46.371211
# Unit test for function exists_as
def test_exists_as():
    file_path = Path('~/tmp/flutils.tests.pathutils.exists_as.txt').expanduser()
    dir_path = Path('~/tmp/flutils.tests.pathutils.exists_as.d').expanduser()
    os.makedirs(dir_path, exist_ok=True)
    fd, tfp = mkstemp(dir=str(dir_path))
    os.write(fd, b'#' * 25)
    os.close(fd)
    Path(tfp).rename(file_path)
    # Neither dir nor file should exist
    dir_exists_as = exists_as(dir_path)
    file_exists_as = exists_as(file_path)
    os.remove(file_path)

# Generated at 2022-06-11 22:39:53.690153
# Unit test for function find_paths
def test_find_paths():
    import sys
    import os
    import pytest
    from flutils.pathutils import find_paths

    def _setup_and_cleanup(test_path, *args, **kwargs):
        for arg in [item for sublist in args for item in sublist]:
            os.makedirs(os.path.join(test_path, arg[0]),
                        mode=arg[1], exist_ok=True)
            if arg[2] is None:
                with open(os.path.join(test_path, arg[0]), 'w') as arg_file:
                    arg_file.write(arg[0])

        # Use Path(test_path) because Path(test_path, '**') becomes
        # /test_path/test_path/ on Windows.

# Generated at 2022-06-11 22:39:55.951374
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)
    return True



# Generated at 2022-06-11 22:39:57.008924
# Unit test for function directory_present
def test_directory_present():
    # This need tests!
    pass



# Generated at 2022-06-11 22:39:59.762107
# Unit test for function chown
def test_chown():
    chown('/tmp/flutils.tests.osutils.txt')
    chown('/tmp/**')
    chown('/tmp/*', user='root', group='root')


# Generated at 2022-06-11 22:40:08.339900
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory as TD
    with TD() as tmpdir:
        path: Path = Path(tmpdir).joinpath('test_file')
        path.touch()
        path_absent(path)
        assert path.is_file() is False
        assert path.is_dir() is False
        path.mkdir()
        path.joinpath('test_file').touch()
        path_absent(path)
        assert path.is_file() is False
        assert path.is_dir() is False



# Generated at 2022-06-11 22:40:14.142334
# Unit test for function exists_as
def test_exists_as():
    import os
    import random
    import tempfile

    from flutils.encodingutils import to_bytes
    from flutils.pathutils import exists_as

    assert exists_as('') == ''
    assert exists_as(to_bytes(b'')) == ''
    assert exists_as(Path()) == ''
    assert exists_as(Path('')) == ''
    assert exists_as(Path(os.path.sep)) == 'directory'

    # Create a temp directory.
    tmp_dir = Path(tempfile.mkdtemp())

    # Create a temp file.
    tmp_file = Path(tempfile.mkstemp()[1])

    assert exists_as(tmp_dir) == 'directory'
    assert exists_as(tmp_file) == 'file'

    # Create a temp symbolic link in the temp directory

# Generated at 2022-06-11 22:40:26.887130
# Unit test for function chmod
def test_chmod():
    import shutil
    import tempfile
    import time

    tmp_path = Path(tempfile.mkdtemp())
    chmod(str(tmp_path), 0o000)
    assert tmp_path.exists() is True


# Generated at 2022-06-11 22:40:34.309404
# Unit test for function path_absent
def test_path_absent():
    try:
        path_absent.__wrapped__
    except AttributeError:
        pass
    else:
        raise AssertionError('path_absent should NOT have a __wrapped__.')
    assert path_absent.__name__.startswith('path_absent') is True
    assert path_absent.__doc__.startswith('Ensure the given') is True

    with tempfile.TemporaryDirectory(prefix='flutils_pathutils_test') as td:
        td_path = normalize_path(td)
        test_path = td_path / 'test_path'
        test_path.mkdir()
        file_path = test_path / 'file.txt'
        file_path.touch()
        dir_path = test_path / 'dir'
        dir_path.mk

# Generated at 2022-06-11 22:40:57.530289
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as"""
    path = Path.home() / 'tmp/flutils.tests.pathutils'
    path.parent.mkdir(mode=0o755, exist_ok=True, parents=True)
    path.touch()

    assert exists_as(path) == 'file'
    assert exists_as('~/tmp/flutils.tests.pathutils') == 'file'
    path.unlink()

    path.mkdir(mode=0o755)
    assert exists_as(path) == 'directory'
    assert exists_as('~/tmp/flutils.tests.pathutils') == 'directory'
    path.rmdir()

    assert exists_as(path) == ''
    assert exists_as('~/tmp/flutils.tests.pathutils') == ''



# Generated at 2022-06-11 22:41:07.753990
# Unit test for function find_paths
def test_find_paths():
    """Test the flutils.pathutils.find_paths function."""
    from shutil import copy
    from tempfile import TemporaryDirectory

    from flutils.pathutils import find_paths, normalize_path

    # File, Directory and Link tests for Posix and Windows
    for system in ('posix', 'windows'):
        with TemporaryDirectory(prefix=system) as temp_dir:
            temp_dir_path = normalize_path(temp_dir)
            # File
            file_path = temp_dir_path.joinpath(system + '_file')
            file_path.touch()
            assert list(find_paths(file_path)) == [file_path]
            assert list(find_paths(str(file_path))) == [file_path]

# Generated at 2022-06-11 22:41:18.507571
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        path = Path(tmpdir)
        fpath = path/'test.txt'
        fpath.touch()
        dpath = path/'test_dir'
        dpath.mkdir()

        npath = normalize_path(path)

        assert fpath.is_file() is True
        assert fpath.stat().st_mode == 33188
        assert dpath.is_dir() is True
        assert dpath.stat().st_mode == 16877

        chmod(fpath, 0o600)
        chmod(dpath, 0o700)
        assert fpath.stat().st_mode == 33152
        assert dpath.stat().st_mode == 16893


# Generated at 2022-06-11 22:41:26.645939
# Unit test for function chown
def test_chown():
    from flutils.pathutils import (
        ensure_path_absent,
        ensure_path_present,
    )
    chown('/root/.ssh', user='root', group='root')
    chown('/boot', user='root', group='root')
    ensure_path_present('/boot')
    chown('/boot', user='1000', group='root')
    chown('/boot', user='root', group='root')
    ensure_path_absent('/boot/foo.txt')
    ensure_path_present('/boot/foo.txt')
    chown('/boot/foo.txt', user='1000', group='root')
    chown('/boot/foo.txt', user='root', group='root')
    ensure_path_absent('/boot/bar')

# Generated at 2022-06-11 22:41:37.912389
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function ``exists_as``."""
    # Test that a given path that does NOT exist returns an empty string.
    tmp = normalize_path('/tmp/does_not_exist')
    assert exists_as(tmp) == ''

    # Test that a simple path that exists as a directory returns
    # the string 'directory'.
    tmp = normalize_path('/tmp')
    assert exists_as(tmp) == 'directory'

    # Test that a simple path that exists as a file returns
    # the string 'file'.
    tmp = normalize_path('/etc/hosts')
    assert exists_as(tmp) == 'file'

    # Test that a simple path that exists as a block device
    # returns the string 'block device'.

# Generated at 2022-06-11 22:41:48.307547
# Unit test for function find_paths
def test_find_paths():
    with chdir(TMP_DIR, mkdir=True):
        assert TMP_DIR.is_dir()
        for subdir_name, file_names in TMP_DIR_CONTENT:
            subdir = TMP_DIR / subdir_name
            subdir.mkdir()
            for file_name in file_names:
                (subdir / file_name).touch()

        for root, dirs, files in os.walk(TMP_DIR):
            for found in find_paths(root):
                assert found.is_dir()
                assert found.parts == Path(root).parts

            for dir_name in dirs:
                sub_path = Path(root) / dir_name
                found = next(find_paths(sub_path))
                assert found.is_dir()

# Generated at 2022-06-11 22:42:01.425912
# Unit test for function directory_present
def test_directory_present():
    with pytest.raises(ValueError) as err_info:
        directory_present('~/tmp/**')
    assert (
        str(err_info.value)
        == "The path: '~/tmp/**' must NOT contain any glob patterns."
    )

    with pytest.raises(ValueError) as err_info:
        directory_present('../tmp/test_path')
    assert (
        str(err_info.value)
        == "The path: '../tmp/test_path' must be an absolute path.  A path "
        "is considered absolute if it has both a root and (if the flavour "
        "allows) a drive."
    )


# Generated at 2022-06-11 22:42:11.616473
# Unit test for function directory_present
def test_directory_present():
    from pathlib import PurePosixPath, PureWindowsPath
    from shutil import rmtree
    from tempfile import mkdtemp

    tmp_path = Path(mkdtemp())

    # Test directory_present() returns the right type of path object.
    params_list = [
        ('directory_present() returns the right type of path object',
         ['~/tmp/directory_present_test'],
         PurePosixPath
        ),
        ('directory_present() returns the right type of path object',
         ['~\\tmp\\directory_present_test'],
         PureWindowsPath
        ),
    ]
    for tpl in params_list:
        params = tpl[0]
        expected = tpl[2]

        path = directory_present(tpl[1][0])

# Generated at 2022-06-11 22:42:24.786573
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths

    path = Path(__file__).resolve()
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        for i in (1, 2, 3):
            with path.open('rb') as src_stream, \
                    (tmp_dir / 'file_{}'.format(i)).open('wb') as dest_stream:
                dest_stream.write(src_stream.read())
        tmp_dir.joinpath('dir_1').mkdir(exist_ok=True)
        paths = find_paths(str(tmp_dir / '*'))
        paths = list(paths)
        assert len(paths) == 4
        assert tmp_dir.joinpath('file_1') in paths
        assert tmp_dir.joinpath

# Generated at 2022-06-11 22:42:34.081605
# Unit test for function directory_present
def test_directory_present():
    # Testing that a path present as a file and is not changed.
    dp_path = Path('~/tmp/flutils.tests.pathutils.txt')
    dp_path.touch()
    dp_path = directory_present(dp_path)
    assert dp_path.exists() is True
    assert dp_path.is_dir() is False
    # Cleanup
    dp_path.unlink()

    # Testing that a path present as a directory and is a created
    dp_path = Path('~/tmp/flutils.tests.pathutils')
    dp_path.mkdir()
    dp_path = directory_present(dp_path)
    assert dp_path.exists() is True
    assert dp_path.is_dir() is True
    # Cleanup
   

# Generated at 2022-06-11 22:42:56.769746
# Unit test for function chmod
def test_chmod():
    # initial test w/o glob pattern
    test_path = Path(__file__)
    test_path.chmod(0o777)
    chmod(test_path, 0o660)
    assert test_path.stat().st_mode == 0o660

    # test with glob pattern
    test_dir = Path(__file__).parent
    test_dir_paths = [test_dir / 'test_chmod.py', test_dir / 'test_chown.py']
    for path in test_dir_paths:
        path.chmod(0o777)
    chmod(test_dir / '{test_chmod,test_chown}.py', 0o660)
    for path in test_dir_paths:
        assert path.stat().st_mode == 0o660

    # test recursive glob

# Generated at 2022-06-11 22:43:08.074898
# Unit test for function chown
def test_chown():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    _temp_file = os.path.join(temp_dir, 'flutils.tests.pathutils.txt')
    with open(_temp_file, 'w') as f:
        f.write('')

    # Test chown with default args
    chown(_temp_file)
    os_stat = os.stat(_temp_file)
    assert os_stat.st_uid == os.getuid()
    assert os_stat.st_gid == os.getgid()

    # Test chown with glob pattern
    chown(os.path.join(temp_dir, '*.txt'), user='nobody')
    os_stat = os.stat(_temp_file)
    assert os_stat.st_uid == pwd.getpwnam

# Generated at 2022-06-11 22:43:17.892830
# Unit test for function chown
def test_chown():
    test_path = Path(__file__)
    assert test_path.exists() is True
    assert test_path.is_file() is True
    assert test_path.owner() == getpass.getuser()
    assert test_path.group() == grp.getgrgid(os.getgid()).gr_name
    test_path.chmod(0o600)  # so the file can be chown'd by the user

    chown(test_path)
    assert test_path.owner() == getpass.getuser()
    assert test_path.group() == grp.getgrgid(os.getgid()).gr_name

    # change ownership to a file using the current user and a given group
    chown(test_path, group=os.getgid())

# Generated at 2022-06-11 22:43:21.474446
# Unit test for function directory_present
def test_directory_present():
    path = Path('/tmp/flutils.tests.pathutils.test_directory_present')
    try:
        directory_present(path)
        assert path.exists() is True
    finally:
        path.rmdir()

# Generated at 2022-06-11 22:43:33.016338
# Unit test for function path_absent
def test_path_absent():
    path = '/tmp/flutils-pathutils-test-path-absent'
    path_tmp = path + '.tmp'

# Generated at 2022-06-11 22:43:43.779669
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(tempfile.mkdtemp()) == 'directory'
    assert exists_as(tempfile.mkstemp()[1]) == 'file'
    assert exists_as(tempfile.TemporaryDirectory().name) == 'directory'
    assert exists_as(tempfile.NamedTemporaryFile().name) == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/full') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/tty0') == 'char device'

# Generated at 2022-06-11 22:43:51.721396
# Unit test for function chown
def test_chown():
    test_path = os.path.expanduser('~/.flutils.tests.pathutils')
    os.mkdir(test_path)
    test_file = os.path.join(test_path, 'pathutils.txt')
    with open(test_file, 'w') as outfile:
        outfile.write('foo')
    chown(test_path, user=getpass.getuser(), group=getpass.getuser())
    assert os.stat(test_file).st_uid == os.stat(test_path).st_uid
    assert os.stat(test_file).st_gid == os.stat(test_path).st_gid
    os.remove(test_file)

# Generated at 2022-06-11 22:44:02.644315
# Unit test for function directory_present
def test_directory_present():
    import os
    import stat
    import shutil
    import tempfile

    root_dir = directory_present(tempfile.gettempdir())
    test_dir = root_dir / 'flutils' / 'tests'
    test_dir = directory_present(test_dir)
    test_dir = directory_present(test_dir)
    assert (
        os.stat(
            test_dir.as_posix(),
            follow_symlinks=False
        ).st_mode == (
            stat.S_IFDIR | 0o0700
        )
    )
    test_user = getpass.getuser()

# Generated at 2022-06-11 22:44:12.859245
# Unit test for function exists_as

# Generated at 2022-06-11 22:44:24.264986
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.files import (
        FileCache,
        TemporaryDirectory
    )
    test_cases = [
        '~/flutils.tests.pathutils.test_find_paths',
        '~/flutils.tests.pathutils.test_find_paths/**',
        '~/flutils.tests.pathutils.test_find_paths/test_cases/**',
    ]

    cache = FileCache(create=True)

    with TemporaryDirectory(
        parent_directory=cache.directory,
        prefix='tmp.',
    ) as tmpdir:

        # Create two files at the root of the tmpdir.
        first_file = Path(tmpdir).joinpath('file_one')
        first_file.touch()

        second_file = Path

# Generated at 2022-06-11 22:44:51.870178
# Unit test for function chmod
def test_chmod():
    import os
    import shlex
    import sys

    from scripttest import TestFileEnvironment

    from flutils.pathutils import chmod

    base_dir = Path(__file__).parent
    env = TestFileEnvironment(base_dir)

    file0 = Path('tmp', 'flutils', 'tests', 'file0')

    file0_path = Path(env.base_path, file0.as_posix())

# Generated at 2022-06-11 22:44:53.761882
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt', include_parent=True)



# Generated at 2022-06-11 22:45:04.960648
# Unit test for function path_absent
def test_path_absent():
    """Test that paths are deleted as expected."""
    # First, create all test directories and files.
    dir_one = '~/tmp/dir_one'
    dir_two = '~/tmp/dir_one/dir_two'
    dir_three = '~/tmp/dir_three'
    file_one = '~/tmp/file_one'
    file_two = '~/tmp/dir_one/file_two'
    file_three = '~/tmp/dir_one/dir_two/file_three'
    file_four = '~/tmp/dir_three/file_four'

# Generated at 2022-06-11 22:45:13.725385
# Unit test for function find_paths
def test_find_paths():
    with DirectoryPresent('/tmp/test_find_paths'):
        for path in find_paths('/tmp/test_find_paths/*'):
            pass

    with DirectoryPresent('/tmp/test_find_paths2'):
        for path in find_paths('/tmp/test_find_paths2'):
            pass

    with DirectoryPresent('/tmp/test_find_paths3/foo'):
        for path in find_paths('/tmp/test_find_paths3/foo'):
            pass



# Generated at 2022-06-11 22:45:23.505744
# Unit test for function chown
def test_chown():
    # test chown a non-existing file -
    chown('~/tmp/flutils.tests.osutils.txt')
    # test chown a directory that exits -
    chown('~/tmp/flutils/.tests.pathutils', user='root', group='root')
    # test chown a path containing a glob -
    chown('~/tmp/flutils.tests.osutils.*')
    # test chown a non-existing directory -
    chown('~/tmp/flutils.tests.osutils')
    # test chown a parent directory -
    chown('~/tmp/flutils/.tests.osutils.*', include_parent=True)
    # test chown a symlink target -
    chown('~/tmp/flutils.tests.osutils.txt.in')
    # test chown a

# Generated at 2022-06-11 22:45:27.193003
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.fileutils.txt') == 'file'



# Generated at 2022-06-11 22:45:37.011268
# Unit test for function find_paths

# Generated at 2022-06-11 22:45:48.823731
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    import shutil
    import stat

    TEST_DIR = '~/tmp'

    path = Path(TEST_DIR)
    path.mkdir(mode=0o755, parents=True, exist_ok=True)

    # Test chmod with a simple file
    Path(os.path.join(TEST_DIR, 'chmod1.txt')).write_text('chmod1')
    test_path = Path(os.path.join(TEST_DIR, 'chmod1.txt'))
    chmod(test_path, 0o644)
    assert os.stat(test_path).st_mode & 0o777 == 0o644

    # Test chmod with a glob pattern on a single file

# Generated at 2022-06-11 22:46:00.952323
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from glob import glob
    from flutils.pathutils import chown
    from flutils.osutils import is_file
    from flutils.tests._testingcore import get_tempdir
    tempdir = get_tempdir()
    with TemporaryDirectory(dir=str(tempdir)) as td:
        tmp_dir1 = Path(td).resolve()
        tmp_dir2 = tmp_dir1 / 'sub_dir'
        tmp_dir2.mkdir(parents=True)
        (tmp_dir2 / 'foo.txt').write_text('Hello, World!')
        chown(
            str(tmp_dir2),
            user=getpass.getuser(),
            group=getpass.getuser(),
        )