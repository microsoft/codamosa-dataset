

# Generated at 2022-06-11 22:36:30.986695
# Unit test for function chmod
def test_chmod():
    assert chmod(None) is None



# Generated at 2022-06-11 22:36:42.840652
# Unit test for function chown
def test_chown():
    try:
        import pathlib
    except ImportError:
        try:
            import pathlib2 as pathlib
        except ImportError:
            pathlib = None

    if pathlib is not None:
        Path = pathlib.Path
    else:
        Path = None

    import stat
    import tempfile
    import unittest

    from unittest import mock

    from flutils.pathutils import (
        chown,
        normalize_path,
    )

    class ChmodTestCase(unittest.TestCase):
        def setUp(self):
            self._uid = os.getuid()
            self._gid = os.getgid()

            self._temp = tempfile.TemporaryDirectory()
            self._temp_path = Path(self._temp.name)

            self._sub_file = self._

# Generated at 2022-06-11 22:36:51.156950
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/foo') == ''
    assert exists_as('~/tmp/foo') == ''
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/full') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/kmsg') == 'char device'



# Generated at 2022-06-11 22:37:00.854655
# Unit test for function path_absent
def test_path_absent():
    # Create the test path.
    path = normalize_path('~/tmp/pathutils_test/test_path')
    create_paths(path, mode=0o755, user=os.getuid(), group=os.getgid())
    assert exists_as(path) == 'directory'
    assert os.path.isdir(path.as_posix())

    # Delete the test path and verify it's gone.
    path_absent(path)
    assert exists_as(path) == ''
    assert os.path.isdir(path.as_posix()) is False

# Generated at 2022-06-11 22:37:01.330714
# Unit test for function chown
def test_chown():
    assert True == True



# Generated at 2022-06-11 22:37:07.822721
# Unit test for function find_paths
def test_find_paths():
    """Test :obj:`~flutils.pathutils.find_paths`."""
    from flutils.testingutils import TempDirectory
    from flutils.pathutils import find_paths
    with TempDirectory() as temp_dir:
        temp_dir.joinpath('file_one').touch()
        temp_dir.joinpath('dir_one').mkdir()
        assert set(find_paths(temp_dir.joinpath('*'))) == set(temp_dir.glob('*'))
    return True



# Generated at 2022-06-11 22:37:10.066720
# Unit test for function find_paths
def test_find_paths():
    assert sorted(find_paths('~/tmp/*')) == sorted([
        Path('~/tmp/file_one'),
        Path('~/tmp/dir_one'),
    ])



# Generated at 2022-06-11 22:37:23.126284
# Unit test for function chown
def test_chown():
    """
    Tests for :func:`~flutils.osutils.chown`

    """
    from tests.osutils.test_chmod import test_chmod

    def test_chown_user_group_none():
        """
        all `user` and `group` are `None`

        """
        orig_uid = os.getuid()
        orig_gid = os.getgid()
        user = None
        group = None
        path = Path('tmp/foo.txt')
        if path.exists():
            raise AssertionError
        path.touch()
        try:
            chown(path, user=user, group=group)
        finally:
            path.unlink()

# Generated at 2022-06-11 22:37:24.024147
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:37:29.348500
# Unit test for function chown
def test_chown():
    try:
        chown('/etc/shadow', user='foo', group='bar')
    except OSError:
        pass
    else:
        assert False, 'This should have failed with OSError'

    chown('/etc/shadow', user='-1', group='-1')



# Generated at 2022-06-11 22:38:02.478223
# Unit test for function path_absent
def test_path_absent():
    import shutil
    tmpdir = str(mkdtemp(prefix='flutils_test_path_absent'))
    tmpdir = Path(tmpdir)
    p1 = tmpdir.joinpath('a')
    p2 = tmpdir.joinpath('b')
    p1.mkdir()
    p2.mkdir()
    p1.joinpath('foo').touch()
    p1.joinpath('bar').touch()
    p2.joinpath('baz').touch()
    path_absent(tmpdir)
    assert len(list(tmpdir.glob('*'))) == 0



# Generated at 2022-06-11 22:38:14.404989
# Unit test for function chown
def test_chown():
    # Test identity of the current user
    assert getpass.getuser() == pwd.getpwuid(os.getuid()).pw_name
    # Test identity of the current group
    assert grp.getgrgid(os.getgid()).gr_name == grp.getgrnam(getpass.getuser()).gr_name
    # Test file ownership from shutil.copyfile
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        tmp_file_name = os.path.join(tmp_dir_name, 'test_chown.txt')
        shutil.copyfile(__file__, tmp_file_name)
        os.utime(tmp_file_name, None)

# Generated at 2022-06-11 22:38:26.529205
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.systemutils import (
        get_os_group,
        get_os_user,
    )

    os_user = get_os_user()
    os_group = get_os_group(os_user)

    def _create_file(
            path: _PATH,
            content: Optional[bytes] = None,
            mode: Optional[int] = None
    ) -> Path:
        if content is None:
            content = b''

        if mode is None:
            mode = 0o660

        Path(path).touch(mode=mode)
        Path(path).write_bytes(content)
        return Path(path)

    _test_dir_path = Path('__flutils_test_chmod').absolute()


# Generated at 2022-06-11 22:38:37.612791
# Unit test for function find_paths
def test_find_paths():
    # Simple case
    with TemporaryDirectory() as tmp_dir:
        Path(tmp_dir, 'test_file.txt').touch()
        assert list(find_paths(Path(tmp_dir, 'test_file.txt'))) == \
            [Path(tmp_dir, 'test_file.txt')]

    # Create cool path
    with TemporaryDirectory() as tmp_dir:
        file_path = Path(tmp_dir, 'level_one', 'level_two', 'test_file.txt')
        file_path.parent.mkdir(parents=True)
        file_path.touch()

        assert list(find_paths(Path(tmp_dir, '*', '*', 'test_file.txt'))) == [
            file_path
        ]


# Generated at 2022-06-11 22:38:38.955956
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user()."""
    pass



# Generated at 2022-06-11 22:38:49.572105
# Unit test for function chown
def test_chown():
    path = Path('/tmp/flutils.tests.pathutils.txt').expanduser()
    if path.exists() is True:
        path.unlink()
    path.write_text('foo')
    chown(path, user=os.getuid(), group=os.getgid())
    assert path.stat().st_mode == 33188
    chown(path, user=os.getuid(), group=os.getgid())
    assert path.stat().st_mode == 33188
    path.unlink()
    path.write_text('foo')
    chown(path, user='-1', group='-1')
    assert path.stat().st_mode == 33188
    chown(path, user='-1', group='-1')
    assert path.stat().st_mode == 33188
   

# Generated at 2022-06-11 22:38:51.484262
# Unit test for function chmod
def test_chmod():
    return chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-11 22:39:00.724830
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    def _test(pre_create_file=False,
              pre_create_dir=False,
              pre_create_symlink=False,
              mode_file=0o600,
              mode_dir=0o700,
              include_parent=False,
              glob_pattern=None,
              expected_mode_file=0o600,
              expected_mode_dir=0o700,
              expected_mode_parent=None,
              expected_mode_symlink=0o700):

        path = None
        parent_dir = None


# Generated at 2022-06-11 22:39:11.580685
# Unit test for function find_paths
def test_find_paths():
    assert isinstance(find_paths('/usr/bin/*'), typing.Generator)
    assert list(find_paths('/usr/bin/*')) == sorted(
        Path('/usr/bin').glob('*'), key=lambda x: x.as_posix()
    )
    assert list(find_paths('/tmp/*')) == sorted(
        Path('/tmp').glob('*'), key=lambda x: x.as_posix()
    )
    assert [x.as_posix() for x in find_paths('/tmp/*')] == [
        '/tmp/a.txt', '/tmp/flutils.tests.osutils.txt', '/tmp/tmp',
        '/tmp/tmp_dir_1'
    ]

# Generated at 2022-06-11 22:39:12.063134
# Unit test for function chmod
def test_chmod():
    return None



# Generated at 2022-06-11 22:39:21.712602
# Unit test for function chown
def test_chown():
    # Test path utils
    from flutils.pathutils import chown
    uname = getpass.getuser()
    chown(__file__, user=uname, group=uname)



# Generated at 2022-06-11 22:39:33.362953
# Unit test for function find_paths
def test_find_paths():
    import pytest

    with pytest.raises(ValueError):
        list(find_paths('~/tmp/foo.txt'))

    base_dir = Path(f'{tempfile.gettempdir()}/flutils.test')
    base_dir.mkdir(mode=0o755, parents=True, exist_ok=True)
    root_dir = base_dir / 'find_paths'
    root_dir.mkdir(mode=0o755, exist_ok=True)

    sub_dir1 = root_dir / 'sub_dir1'
    sub_dir2 = root_dir / 'sub_dir2'
    sub_dir3 = root_dir / 'sub_dir3'
    sub_dir4 = root_dir / 'sub_dir4'


# Generated at 2022-06-11 22:39:40.086973
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.pathutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-11 22:39:44.606020
# Unit test for function chmod
def test_chmod():
    tmp_dir = Path(tempfile.mkdtemp())
    tmp_path = tmp_dir.joinpath('flutils.tests.osutils.txt')
    tmp_path.touch()
    assert tmp_path.stat().st_mode != 0o600
    chmod(tmp_path)
    assert tmp_path.stat().st_mode == 0o600
    tmp_path.unlink()
    tmp_dir.rmdir()



# Generated at 2022-06-11 22:39:55.095020
# Unit test for function chown
def test_chown():
    with cd(cd_tempdir()):
        touch('foo')
        chown('foo', user='-1', group='-1')
        chown('foo', user=getpass.getuser(), group=grp.getgrgid(os.getgid()).gr_name)
        chown('foo', user=getpass.getuser())
        chown('foo', group=grp.getgrgid(os.getgid()).gr_name)



# Generated at 2022-06-11 22:40:07.283541
# Unit test for function path_absent
def test_path_absent():
    '''
    Unit test for function path_absent
    '''
    path = Path('~/tmp/test_path')
    path = path.expanduser()
    path = path.as_posix()
    path = cast(str, path)
    if os.path.exists(path):
        if os.path.islink(path):
            os.unlink(path)
        elif os.path.isdir(path):
            for root, dirs, files in os.walk(path, topdown=False):
                for name in files:
                    p = os.path.join(root, name)
                    if os.path.isfile(p) or os.path.islink(p):
                        os.unlink(p)

# Generated at 2022-06-11 22:40:18.091109
# Unit test for function chmod
def test_chmod():
    # Test no glob pattern
    with TemporaryDirectory(
        suffix=os.path.sep + 'flutils.tests.pathutils'
    ) as temp_dir:
        dir_path = Path(temp_dir)
        file_path = Path(os.path.join(temp_dir, 'flutils.tests.pathutils.txt'))
        file_path.touch()

        mode_dir = 0o777
        dir_path.chmod(mode_dir)
        assert dir_path.stat().st_mode & 0o777 == mode_dir

        mode_file = 0o666
        file_path.chmod(mode_file)
        assert file_path.stat().st_mode & 0o666 == mode_file

        chmod(dir_path)
        assert dir_path.stat().st_mode & 0o777

# Generated at 2022-06-11 22:40:20.363102
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'



# Generated at 2022-06-11 22:40:30.902527
# Unit test for function find_paths
def test_find_paths():
    fake_file_paths = [
        Path('~/tmp/file_one'),
        Path('~/tmp/file_two'),
        Path('~/tmp/file_three'),
        ]
    for path in fake_file_paths:
        path.touch()

    fake_dir_paths = [
        Path('~/tmp/dir_one'),
        Path('~/tmp/dir_two'),
        Path('~/tmp/dir_three'),
        ]
    for path in fake_dir_paths:
        path.mkdir()

    actual_file_paths = [
        path.as_posix() for path in find_paths('~/tmp/*')
        if path.is_file()
        ]
    assert len(actual_file_paths) == 3

    actual_dir_path

# Generated at 2022-06-11 22:40:36.783907
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') == None

    assert chown('~/tmp/**') == None


    assert chown('~/tmp/*', user='foo', group='bar') == None

# Generated at 2022-06-11 22:41:04.145583
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('~/tmp/flutils.tests.osutils.txt')
    if test_path.exists():
        test_path.unlink()
    test_dir = directory_present(test_path.parent)
    assert test_dir.is_dir() is True



# Generated at 2022-06-11 22:41:11.072818
# Unit test for function chown
def test_chown():
    from flutils import pathutils
    from os import makedirs
    from pathlib import Path
    from tempfile import gettempdir
    import time

    tmp_dir = Path(gettempdir()).joinpath(str(time.time()))
    if tmp_dir.exists() is True:
        tmp_dir.unlink()

    makedirs(tmp_dir.as_posix(), exist_ok=True)
    assert pathutils.chown(tmp_dir.as_posix(), '-1', '-1') is None
    #
    # Create a sibling directory
    #
    sibling_dir = os.path.join(tmp_dir.parent.as_posix(), 'foo')
    assert pathutils.chown(sibling_dir, '-1', '-1') is None
    #
    # Create

# Generated at 2022-06-11 22:41:13.186296
# Unit test for function chown
def test_chown():
    """Test function chown"""

    # Return value(s)
    assert True



# Generated at 2022-06-11 22:41:16.751372
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/test_path/test_sub_path')
    assert path.as_posix() == str(Path('~/tmp/test_path/test_sub_path').expanduser())
    path.rmdir()



# Generated at 2022-06-11 22:41:26.224274
# Unit test for function path_absent
def test_path_absent():
    # Test normal operation
    import shutil

    # Save a copy of the current working directory
    cwd = os.getcwd()
    dir = normalize_path('~/tmp/test_dir')
    dir = dir.as_posix()
    if os.path.exists(dir) is False:
        os.mkdir(dir)
    file = normalize_path('~/tmp/test_file')
    if os.path.exists(file) is False:
        open(file.as_posix(), 'a').close()
    link = normalize_path('~/tmp/test_link')
    if os.path.exists(link) is False:
        os.symlink(file.as_posix(), link.as_posix())

# Generated at 2022-06-11 22:41:33.184819
# Unit test for function directory_present
def test_directory_present():
    from flutils.test.pathutils import (
        mk_symlink_dir,
        mk_symlink_file,
    )
    # Create the tmp directory for testing.
    tmp_dir = directory_present('~/tmp/flutils.tests.pathutils')

    # Create a file in the testing directory.
    test_file = tmp_dir.joinpath('flutils.tests.pathutils.file')
    test_file.write_text('Testing directory_present.')

    # Test the function with a path that exists as a file.
    func = functools.partial(directory_present, test_file)
    assert_raises(
        FileExistsError,
        func,
        'Unable to create the directory: %r because it already exists as a '
        'file.'
    )

    # Test the

# Generated at 2022-06-11 22:41:44.674876
# Unit test for function chmod
def test_chmod():
    def _do_test_chmod(
            tmp_path: Path,
            path: _PATH,
            mode_file: Optional[int] = None,
            mode_dir: Optional[int] = None,
            include_parent: bool = False,
    ) -> None:
        chmod(
            path=os.fspath(path),
            mode_file=mode_file,
            mode_dir=mode_dir,
            include_parent=include_parent,
        )

        if include_parent is True:
            path_parent = cast(Path, path).parent
            stat_info = path_parent.lstat()
            assert stat_info.st_mode & 0o777 == mode_dir

# Generated at 2022-06-11 22:41:45.731951
# Unit test for function chown
def test_chown():
    assert True is True

# Generated at 2022-06-11 22:41:58.035395
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod, normalize_path
    from random import randint
    from tempfile import TemporaryDirectory
    from pathlib import Path

    with TemporaryDirectory() as tmp_dir:  # type: ignore
        tmp_dir_path = Path(tmp_dir)

        path_1_str = tmp_dir_path.joinpath('test.txt').as_posix()
        Path(path_1_str).touch()

        path_2_str = tmp_dir_path.joinpath('test2.txt').as_posix()
        Path(path_2_str).touch()

        path_3_str = tmp_dir_path.joinpath('test3.txt').as_posix()
        Path(path_3_str).touch()


# Generated at 2022-06-11 22:42:09.326690
# Unit test for function chown
def test_chown():
    import unittest.mock
    from flutils.pathutils import chown
    from flutils import pathutils
    from flutils.osutils import get_os_group
    from flutils.osutils import get_os_user
    import tempfile
    with unittest.mock.patch.object(
            pathutils,
            'get_os_user',
            return_value=get_os_user()
    ):
        with unittest.mock.patch.object(
                pathutils,
                'get_os_group',
                return_value=get_os_group()
        ):
            file_path = tempfile.NamedTemporaryFile()
            chown(file_path.name)
            file_path.close()



# Generated at 2022-06-11 22:42:18.688673
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == get_os_user('-1')



# Generated at 2022-06-11 22:42:21.237050
# Unit test for function chmod
def test_chmod():
    # This is not testing anything new, just runs the code.
    chmod('~/tmp')
test_chmod()



# Generated at 2022-06-11 22:42:31.276260
# Unit test for function chmod
def test_chmod():
    tmp_file = Path('/tmp/flutils.tests.chmod.txt')
    if tmp_file.exists() is True:
        tmp_file.unlink()

    chmod(tmp_file, mode_file=0o644)
    assert tmp_file.stat().st_mode == 33152

    tmp_dir = Path('/tmp/flutils.tests.chmod.dir')
    if tmp_dir.exists() is True:
        tmp_dir.rmdir()
    tmp_dir.mkdir()
    tmp_dir.chmod(0o700)

    chmod(tmp_dir)
    assert tmp_dir.stat().st_mode == 16832

    tmp_dir.rmdir()
    assert tmp_dir.exists() is False



# Generated at 2022-06-11 22:42:33.544948
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/etc/zshrc') == ''


# Generated at 2022-06-11 22:42:41.924274
# Unit test for function directory_present
def test_directory_present():
    test_dir_path = normalize_path('~/tmp/flutils.tests.test_directory_present')
    test_dir_path.mkdir(parents=True, exist_ok=True)
    t0 = test_dir_path.stat().st_mode
    directory_present('~/tmp/flutils.tests.test_directory_present', mode=0o700)
    t1 = test_dir_path.stat().st_mode
    test_dir_path.rmdir()
    assert t0.__xor__(t1) == 0o700



# Generated at 2022-06-11 22:42:53.759726
# Unit test for function exists_as
def test_exists_as():
    """Unit tests for flutils.pathutils.exists_as"""
    import os
    import tempfile

    def _test_for_files_and_dirs(
        path: _PATH,
        file_type: str,
        exists_as_func: Callable
    ) -> None:
        """Test the function exists_as against files and dirs."""
        # Basic check of all paths
        for directory in (os.getcwd(), os.path.dirname(__file__)):
            for invalid_dir in (
                    '/invalid/dir' + directory,
                    '/home/invalid-dir',
                    'invalid-dir'):
                assert exists_as_func(invalid_dir) == ''


# Generated at 2022-06-11 22:42:54.571098
# Unit test for function path_absent
def test_path_absent():  # pragma: no cover
    pass



# Generated at 2022-06-11 22:42:56.558858
# Unit test for function chown
def test_chown():
    # __salt__['file.chown']('/path/to/file', 'jerry')
    assert True



# Generated at 2022-06-11 22:43:07.920910
# Unit test for function chmod
def test_chmod():
    """Test function chmod()."""
    old_path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    if old_path.exists():
        old_path.unlink()
    old_path.parent.mkdir(mode=0o770, parents=True, exist_ok=True)
    old_path.touch(mode=0o640)

    try:
        chmod(old_path, 0o660)
        assert old_path.stat().st_mode == 0o100660
    finally:
        if old_path.exists():
            old_path.unlink()

    old_path.touch(mode=0o640)

# Generated at 2022-06-11 22:43:16.846628
# Unit test for function exists_as
def test_exists_as():
    """Tests for ``exists_as``."""
    # The following tests were taken from pathlib's:
    # test_unix_attributes.py
    tmppath = _TmpPath()
    os.mkdir(str(tmppath / 'adir'))
    os.mkfifo(str(tmppath / 'afifo'))
    os.mknod(str(tmppath / 'achar'), stat.S_IFCHR, os.makedev(10, 1))
    os.mknod(str(tmppath / 'ablock'), stat.S_IFBLK, os.makedev(10, 2))
    os.mknod(str(tmppath / 'asock'), stat.S_IFSOCK, 0)


# Generated at 2022-06-11 22:43:44.801851
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present, exists_as

    # Test with an empty directory
    test_dir = directory_present('/tmp/flutils/tests/exists_as')
    assert exists_as(test_dir) == 'directory'

    # Test with a directory that has contents
    test_file = test_dir / 'test_file'
    test_file.write_text('foo\n')
    assert exists_as(test_file) == 'file'

    # Test with a glob pattern
    glob_test_dir_1 = test_dir / 'glob1'
    glob_test_dir_1.mkdir()
    glob_test_dir_2 = test_dir / 'glob2'
    glob_test_dir_2.mkdir()

# Generated at 2022-06-11 22:43:48.828732
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/flutils.tests')
    directory_present('~/tmp/flutils.tests/directory_present')
    directory_present('~/tmp/flutils.tests/directory_present/foo/bar',
                      mode=0o766)

# Generated at 2022-06-11 22:43:55.138392
# Unit test for function chmod
def test_chmod():
    # Do not execute test function if the function is imported
    if __name__ == '__main__':
        # Test with no value being given.
        chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o600)

        # Test with a str being given.
        chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o600)

        # Test with a bytes being given.
        chmod(b'~/tmp/flutils.tests.osutils.txt', mode_file=0o600)

        # Test with a Path being given.
        chmod(Path('~/tmp/flutils.tests.osutils.txt'), mode_file=0o600)

        # Test with a Path being given and a glob pattern being used

# Generated at 2022-06-11 22:44:00.686421
# Unit test for function chown
def test_chown():
    from .testutils import temp_cwd

    with temp_cwd() as cwd:
        Path('1').touch()
        assert Path('1').stat().st_uid != 0
        assert Path('1').stat().st_gid != 0
        chown('*', 0, 0, False)
        assert Path('1').stat().st_uid == 0
        assert Path('1').stat().st_gid == 0



# Generated at 2022-06-11 22:44:07.527111
# Unit test for function chown
def test_chown():
    path = '~/tmp/foo.txt'
    if Path(path).exists() is True:
        Path(path).unlink()
    Path(path).touch()
    assert Path(path).exists() is True

    chown(path)

    Path(path).unlink()
    assert Path(path).exists() is False

    chown('~/tmp/*')



# Generated at 2022-06-11 22:44:09.872982
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.home()) == 'directory'
    assert exists_as('/does/not/exist/path') == ''


# Generated at 2022-06-11 22:44:14.369440
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group
    try:
        get_os_user('foo')
    except OSError:
        assert True
    else:
        assert False
    try:
        get_os_user(2002)
    except OSError:
        assert True
    else:
        assert False
    user = get_os_user()
    assert user.pw_name == getpass.getuser()
    assert user.pw_gid == get_os_group().gr_gid



# Generated at 2022-06-11 22:44:24.343639
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from os import path
    from pathlib import Path

    with TemporaryDirectory() as tmp_dir:
        chmod(tmp_dir)
        assert path.isdir(tmp_dir) is True
        assert path.isfile(tmp_dir) is False
        assert oct(Path(tmp_dir).stat().st_mode) == '0o40700'

        with NamedTemporaryFile(dir=tmp_dir) as tmp_fh:
            tmp_fh.write(b'test file')
            tmp_fh.flush()

            chmod(tmp_fh.name, 0o660)
            tmp_fh.seek(0)
            assert tmp_fh.read() == b'test file'

# Generated at 2022-06-11 22:44:35.520671
# Unit test for function chmod
def test_chmod():
    with patch.object(
        Path,
        'chmod'
    ) as chmod_patch:
        chmod('~/tmp/flutils.tests.osutils.txt')
        chmod_patch.assert_called_once_with(0o600)

        chmod(
            '~/tmp/flutils.tests.osutils.txt',
            mode_file=0o660
        )
        chmod_patch.assert_called_with(0o660)

        chmod(
            '~/tmp/flutils.tests.osutils.txt',
            mode_file=0o660,
            mode_dir=0o770
        )
        chmod_patch.assert_called_with(0o660)
        chmod_patch.assert_called_with(0o770)


# Generated at 2022-06-11 22:44:39.194875
# Unit test for function chmod
def test_chmod():
    assert True is True



# Generated at 2022-06-11 22:44:58.859414
# Unit test for function directory_present
def test_directory_present():

    import flutils.tests.pathutils.test_pathutils
    from flutils.pathutils import directory_present

    directory_present(
        os.path.join(
            flutils.tests.pathutils.test_pathutils.TEST_DATA_PATH,
            'test_directory_present'
        )
    )



# Generated at 2022-06-11 22:45:08.307966
# Unit test for function chmod
def test_chmod():
    for path in (
            str(Path.home() / 'tmp' / 'file_no_glob.txt'),
            bytes(Path.home() / 'tmp' / 'file_no_glob.txt')
    ):
        chmod(path, 0o600, 0o700)
        assert os.stat(path).st_mode == 0o600_00_0, '{}'.format(path)

        chmod(path, 0o750, 0o775)
        assert os.stat(path).st_mode == 0o750_00_0, '{}'.format(path)

        chmod(path, 0o600, 0o700)
        assert os.stat(path).st_mode == 0o600_00_0, '{}'.format(path)


# Generated at 2022-06-11 22:45:21.020468
# Unit test for function chmod
def test_chmod():
    # Path is str
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('/tmp/flutils.tests.osutils.txt', 0o660)
    assert os.stat('/tmp/flutils.tests.osutils.txt').st_mode == (stat.S_IFREG + 0o660)  # noqa: E252,E501
    chmod('/tmp/flutils.tests.osutils.txt', 0o700)
    assert os.stat('/tmp/flutils.tests.osutils.txt').st_mode == (stat.S_IFREG + 0o700)  # noqa: E252,E501
    chmod('/tmp/flutils.tests.osutils.txt', 0o600)

# Generated at 2022-06-11 22:45:34.376453
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    with tempfile.TemporaryDirectory() as test_dir:
        test_path = Path(test_dir, 'test_path')
        result = directory_present(test_path)
        assert result == test_path

        test_path = Path(test_dir, 'test_path1', 'test_path2')
        result = directory_present(test_path)
        assert result == test_path
        assert exists_as(test_path) == 'directory'

        test_path = Path(test_dir, 'test_path_file')
        test_path.touch()

# Generated at 2022-06-11 22:45:45.044497
# Unit test for function path_absent
def test_path_absent():
    from .pathutils import Path, path_absent
    from .test_fixtures import CDT, T, TEST_DIRECTORY
    path = CDT / T / 'my_file'
    path.mkdir()
    path = path / 'my_file2'
    path.write_text('This is a test')
    path = CDT / T / 'my_link'
    path.symlink_to('my_file')
    path_absent(TEST_DIRECTORY.as_posix())
    assert TEST_DIRECTORY.exists() is False



# Generated at 2022-06-11 22:45:46.838095
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None

# Generated at 2022-06-11 22:45:53.268247
# Unit test for function chmod
def test_chmod():
    """Test the chmod function."""
    import pytest
    from tempfile import TemporaryDirectory
    from os import (
        umask,
        mkdir,
        symlink,
        chmod,
    )
    from os.path import (
        exists as path_exists,
        join as path_join,
    )

    _umask: int = umask(0o022)
    umask(_umask)

    # _umask is a value between 0 and 0o777
    # in decimal.
    #
    # e.g.
    #   _umask = 0o022
    #
    # Pathlib.Path's chmod() mode value is
    # expected to be in octal.
    #
    # e.g.
    #   _mode_dir = 0o700
    #
   

# Generated at 2022-06-11 22:45:59.294862
# Unit test for function chown
def test_chown():
    import pytest
    from flutils.pathutils import chown

    with pytest.raises(OSError):
        chown('/', user='foo')

    with pytest.raises(OSError):
        chown('/', group='foo')

    chown('/', user='-1', group='-1')

