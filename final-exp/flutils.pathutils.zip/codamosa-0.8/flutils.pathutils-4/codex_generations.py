

# Generated at 2022-06-11 22:36:42.085868
# Unit test for function chmod
def test_chmod():
    import pytest
    from tests.pathutils import make_temp_directory
    from tests.textutils import make_rand_string
    from os import (
        chmod,
        stat,
    )
    from stat import (
        S_IRGRP,
        S_IROTH,
        S_IRUSR,
        S_IWGRP,
        S_IWOTH,
        S_IWUSR,
    )
    from flutils.pathutils import normalize_path

    path = normalize_path(make_temp_directory())

    # Testing a non-existent path
    path_inexistent = normalize_path(Path(path, make_rand_string()))
    with pytest.raises(NotImplementedError):
        chmod(path_inexistent, 0o660)

   

# Generated at 2022-06-11 22:36:50.467613
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    from flutils.pathutils import exists_as

    # Test case where the path is a directory.
    path = Path('.')
    result = exists_as(path)
    assert result == 'directory'

    # Test case where the path is a regular file.
    path = Path(__file__)
    result = exists_as(path)
    assert result == 'file'

    # Test case where the path is a block device.
    path = Path('/dev/random')
    result = exists_as(path)
    assert result == 'block device'

    # Test case where the path is a char device.
    path = Path('/dev/null')
    result = exists_as(path)
    assert result == 'char device'

    # Test case where the path is a FIFO.
   

# Generated at 2022-06-11 22:36:57.732886
# Unit test for function chmod
def test_chmod():

    # Test basic directory
    chmod('./trash', 0o770, include_parent=True)
    assert oct(os.lstat('./trash').st_mode)[-3:] == '770'
    assert oct(os.lstat('./').st_mode)[-3:] == '770'

    # Test basic file
    chmod('./trash/flutils.tests.osutils.txt', 0o660, include_parent=True)
    assert oct(os.lstat('./trash/flutils.tests.osutils.txt').st_mode)[-3:] == '660'
    assert oct(os.lstat('./trash').st_mode)[-3:] == '770'
    assert oct(os.lstat('./').st_mode)[-3:] == '770'

   

# Generated at 2022-06-11 22:37:07.895877
# Unit test for function chown
def test_chown():
    with open('./test_fixtures/osutils/test_chown.txt', 'w+') as fp:
        pass

    chown('./test_fixtures/osutils/test_chown.txt')

    path = Path('./test_fixtures/osutils/test_chown.txt')

    user = pwd.getpwuid(os.stat(path.as_posix()).st_uid).pw_name
    assert user == getpass.getuser()

    group = grp.getgrgid(os.stat(path.as_posix()).st_gid).gr_name
    assert group == getpass.getuser()

    os.remove(path.as_posix())



# Generated at 2022-06-11 22:37:20.114329
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/test_dir'
    path = normalize_path(path)
    if os.path.exists(path):
        rmtree(str(path))
    if os.path.exists(path) is False:
        path.mkdir(parents=True, exist_ok=True)
        fp = path / 'test_file'
        fp.touch()
        path_absent(path)
        assert os.path.exists(path) is False
    else:
        raise Exception(
            'The path: %r, already exists. Skipping test.' % path.as_posix()
        )
test_path_absent.function = path_absent
test_path_absent.path = 'tmp/test_dir'
del test_path_absent



# Generated at 2022-06-11 22:37:31.710024
# Unit test for function directory_present
def test_directory_present():
    import pytest
    import tempfile
    import shutil


# Generated at 2022-06-11 22:37:32.297951
# Unit test for function chown
def test_chown():
    assert 0


# Generated at 2022-06-11 22:37:43.427849
# Unit test for function path_absent
def test_path_absent(): #pylint: disable=W0613
    """Test function path_absent."""

    path = os.path.join(os.getcwd(), 'path_absent_test')
    if os.path.isdir(path):
        shutil.rmtree(path)
    os.mkdir(path)
    file = os.path.join(path, 'file')
    with open(file, 'w') as fp:
        fp.write('Hello World!\n')
    assert os.path.isfile(file)
    assert os.path.isdir(path)
    path_absent(path)
    assert not os.path.exists(path)


# Generated at 2022-06-11 22:37:54.436314
# Unit test for function chown
def test_chown():
    from flutils.helpers import TemporaryDir
    from flutils.pathutils import chown, path_absent

    with TemporaryDir() as tmp_dir:

        file = os.path.join(tmp_dir, 'file.txt')
        with open(file, 'w') as fh:
            fh.write('this is my file')

        chown(file, '-1', '-1')

        assert path_absent(file) is False

        chown(file)

        assert path_absent(file) is False

        chown(file, user='somedude', group='somegroup')

        assert path_absent(file) is False

        chown(file, group='someothergroup')

        assert path_absent(file) is False


# Generated at 2022-06-11 22:38:05.953804
# Unit test for function exists_as
def test_exists_as():
    from hypothesis import assume, given
    from hypothesis.strategies import composite, integers, text
    from flutils.pathutils import exists_as

    @composite
    def path_strategy(draw):
        assume(draw(text(min_size=2))[0] != '~')
        assume(draw(text(min_size=2))[-1] != '/')
        assume(os.path.isabs(draw(text(min_size=2))))
        return Path(os.path.normpath(draw(text(min_size=2))))

    @composite
    def non_path_strategy(draw):
        return draw(text(min_size=2)).strip()

    @given(path_strategy())
    def test_path(path):
        result = exists_as(path)

# Generated at 2022-06-11 22:38:35.505885
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-11 22:38:40.716571
# Unit test for function find_paths
def test_find_paths():
    setup_test_data('find_paths')
    paths = list(find_paths('/tmp/*'))
    assert paths == [Path('/tmp/file_one'), Path('/tmp/dir_one/')]
    setup_test_data('find_paths', delete=True)



# Generated at 2022-06-11 22:38:50.059007
# Unit test for function path_absent
def test_path_absent():
    assert normalize_path('~/tmp') in Path.cwd().parents
    path = Path('~/tmp/test_dir_one/test_dir_two/test_dir_three')
    path = normalize_path(path)
    path_absent(path)
    assert not path.exists()
    path = normalize_path('~/tmp')
    if path.exists():
        if path.is_dir():
            path_absent(path)
        else:
            path.unlink()
    assert not path.exists()


file_absent = path_absent

# Generated at 2022-06-11 22:38:59.955758
# Unit test for function path_absent
def test_path_absent():
    path = tempfile.mkdtemp()
    p1 = os.path.join(path, 'test_file')
    p2 = os.path.join(path, 'test_dir')
    p3 = os.path.join(p2, 'test_file')
    p4 = os.path.join(p2, 'test_dir')
    p5 = os.path.join(p4, 'test_file')
    p6 = os.path.join(p4, 'test_dir')
    for f in (p1, p3, p5):
        open(f, 'a').close()
    for d in (p2, p4, p6):
        os.mkdir(d)
    assert os.path.isfile(p1)
    assert os.path.isdir(p2)


# Generated at 2022-06-11 22:39:11.202498
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.joinpath(tmp_dir, 'file_one').touch()
        tmp_dir.joinpath(tmp_dir, 'dir_one').mkdir()
        assert (
            list(find_paths(tmp_dir.joinpath('*')))
            ==
            [tmp_dir / 'file_one', tmp_dir / 'dir_one']
        )
        assert (
            list(find_paths(tmp_dir.joinpath('file_one')))
            ==
            [tmp_dir / 'file_one']
        )
        assert list(find_paths(tmp_dir.joinpath('file_*'))) == []

# Generated at 2022-06-11 22:39:22.888205
# Unit test for function chmod
def test_chmod():
    str_path = '~/tmp/flutils.tests.osutils.txt'
    path = Path(str_path)
    # Ensure the path does not exist so the test can be run in
    # any environment.
    if path.exists():
        path.unlink()

    chmod(path, 0o660)
    assert path.exists() is True
    assert path.stat().st_mode == 0o660

    path.unlink()
    assert path.exists() is False

    chmod(path, 0o600, include_parent=True)
    assert path.parent.exists() is True
    assert path.parent.stat().st_mode == 0o700

    chmod(str_path, 0o620)
    assert path.stat().st_mode == 0o620


# Generated at 2022-06-11 22:39:31.501296
# Unit test for function chown
def test_chown():
    from os import chdir
    from os import getcwd
    from os import makedirs
    from os import path
    from os.path import exists
    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp

    cwd = getcwd()
    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name

    def _create_temp_dir():
        """Create a temporary dir."""
        with mkdtemp() as tmp_dir:
            tmp_dir = path.abspath(tmp_dir)
            makedirs(join(tmp_dir, 'foo/bar'))
            makedirs(join(tmp_dir, 'foo/baz'))
            m

# Generated at 2022-06-11 22:39:32.576431
# Unit test for function chown
def test_chown():
    assert True is True



# Generated at 2022-06-11 22:39:44.965685
# Unit test for function chmod
def test_chmod():
    user = getpass.getuser()
    tmp_path = f'/tmp/{user}/'
    sub_tmp_path = f'/tmp/{user}/flutils.tests.osutils.txt'
    sub_sub_tmp_path = f'/tmp/{user}/flutils.tests.osutils/'

    def get_mode(pth: PosixPath) -> int:
        return cast(PosixPath, pth).stat().st_mode & 0o777

    if not Path(sub_tmp_path).exists():
        os.makedirs(sub_tmp_path, 0o770)
    if not Path(sub_sub_tmp_path).exists():
        os.makedirs(sub_sub_tmp_path, 0o770)


# Generated at 2022-06-11 22:39:56.803508
# Unit test for function chown
def test_chown():
    test_path = '~/tmp/flutils.tests.osutils.txt'
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    chown(test_path, user=user, group=group)
    assert os.stat(normalize_path(test_path).as_posix()).st_uid == os.getuid()
    assert os.stat(normalize_path(test_path).as_posix()).st_gid == os.getgid()



# Generated at 2022-06-11 22:40:08.086481
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-11 22:40:16.230987
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    try:
        chown('~/tmp/flutils.tests.osutils.txt', user='-1')
    except Exception:
        pass
    else:
        assert True
    chown('~/tmp/flutils.tests.osutils.txt', group='-1')
    chown('~/tmp/**')
    try:
        chown('~/tmp/*', user='foo', group='bar')
    except Exception:
        pass
    else:
        assert True



# Generated at 2022-06-11 22:40:28.169545
# Unit test for function directory_present
def test_directory_present():
    # Test a simple use case
    path = Path('/tmp/flutils.pathutils.test_directory_present')
    path.mkdir(parents=True)
    expected_path = directory_present(path.as_posix())
    assert path.as_posix() == expected_path.as_posix()
    path.rmdir()

    # Test with an absolute path
    path = Path('/tmp/flutils.pathutils.test_directory_present')
    directory_present(path.as_posix())
    assert path.is_dir() is True
    path.rmdir()

    # Test with mode 0o755
    path = Path('/tmp/flutils.pathutils.test_directory_present')
    directory_present(path.as_posix(), mode=0o755)

# Generated at 2022-06-11 22:40:34.985262
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    tmp_path = directory_present('~/tmp/flutils/tests/unit/pathutils')

    with open(tmp_path.as_posix() + '/test_file.txt', 'w') as test_file:
        test_file.write('test contents')

    Path(tmp_path.as_posix() + '/test_dir').mkdir()

    search_pattern = '%s/*' % tmp_path.as_posix()
    match_list = list(find_paths(search_pattern))

    assert len(match_list) == 2
    assert match_list[1].as_posix() == '%s/test_dir' % tmp_path.as_posix()

# Generated at 2022-06-11 22:40:44.427455
# Unit test for function exists_as
def test_exists_as():
    tmp = tempfile.gettempdir()
    tmp_file = os.path.join(tmp, 'testfile.txt')
    tmp_symlink = os.path.join(tmp, 'testsymlink.txt')
    tmp_dir = os.path.join(tmp, 'testdir')

    # Clean up from previous runs.
    if os.path.exists(tmp_file):
        os.remove(tmp_file)

    if os.path.exists(tmp_dir):
        shutil.rmtree(tmp_dir)

    os.symlink(tmp_file, tmp_symlink)

    assert exists_as(tmp_symlink) == ''
    assert exists_as(tmp_file) == ''


# Generated at 2022-06-11 22:40:56.744395
# Unit test for function exists_as
def test_exists_as():
    assert(exists_as('~') == 'directory')
    assert(exists_as('~/.zshrc') == 'file')
    assert(exists_as('~/flutils') == 'directory')
    assert(exists_as('~/flutils/__init__.py') == 'file')
    assert(exists_as('/dev/stdin') == 'block device')
    assert(exists_as('/dev/tty') == 'char device')
    assert(exists_as('/dev/fuse') == 'char device')
    assert(exists_as('/dev/null') == 'char device')
    assert(exists_as('/dev/zero') == 'char device')
    assert(exists_as('/dev/random') == 'char device')

# Generated at 2022-06-11 22:40:57.671971
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:41:07.789871
# Unit test for function chmod
def test_chmod():
    from shlex import split
    from tempfile import TemporaryDirectory
    from unittest.mock import call, patch

    from flutils.pathutils import chmod

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        subdir = tmpdir / 'tmpdir'
        subdir.mkdir(0o222, parents=True)

        f_path_1 = subdir / 'file1.txt'
        with open(f_path_1, 'w') as f:
            f.write('foo')
        f_path_1.chmod(0o444)

        f_path_2 = tmpdir / 'file2.txt'
        with open(f_path_2, 'w') as f:
            f.write('foo')

# Generated at 2022-06-11 22:41:18.507445
# Unit test for function chown
def test_chown():
    with TemporaryDirectory() as d:
        child_path = Path(d) / 'child'
        child_path.mkdir()
        child2_path = Path(d) / 'child2'
        child2_path.mkdir()
        parent_path = Path(d) / 'parent'
        parent_path.mkdir()
        grand_path = Path(d) / 'parent' / 'grand'
        grand_path.mkdir()
        user = 'nobody'
        group = 'nogroup'
        user_exists = True
        try:
            os.getpwnam(user)
        except KeyError:
            user_exists = False
        group_exists = True
        try:
            os.getgrnam(group)
        except KeyError:
            group_exists = False

       

# Generated at 2022-06-11 22:41:26.645531
# Unit test for function chmod
def test_chmod():
    from os import makedirs, path
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from tests.test_utils import RESOURCE_DIR
    from textwrap import dedent

    from flutils.pathutils import (
        chmod,
        get_os_user,
        normalize_path,
    )

    # Specify the base path
    base_path = mkdtemp()

    # Create the directory structure that will be used
    # to test chmod
    makedirs(path.join(base_path, 'pathutils'))
    makedirs(path.join(base_path, 'pathutils', 'empty'))
    makedirs(path.join(base_path, 'pathutils', 'empty', 'nested_empty'))

    # Create some files

# Generated at 2022-06-11 22:41:48.888215
# Unit test for function exists_as
def test_exists_as():
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.pathutils import exists_as

    class PathExistsAsTests(TestCase):
        @patch('flutils.pathutils.normalize_path')
        def test_normalize_path(self, n_path):
            n_path.return_value = Path('')
            path = exists_as(Path(''))
            self.assertEqual('', path)

        def test_broken_symlink(self):
            path = Path('/path/to/symlink')
            path.symlink_to('/path/to/file')
            path.unlink()
            path = exists_as(path)
            self.assertEqual('', path)


# Generated at 2022-06-11 22:41:55.403246
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    assert Path('~/tmp/flutils.tests.osutils.txt').owner() == getpass.getuser()
    assert Path('~/tmp/flutils.tests.osutils.txt').group() == grp.getgrgid(os.getgid())[0]

# Generated at 2022-06-11 22:42:00.006523
# Unit test for function find_paths
def test_find_paths():
    paths = list(find_paths('~/tmp/**'))
    assert len(paths) == 1
    assert paths[0] == Path('~/tmp/dir_one/file_one')
    assert len(list(find_paths('~/tmp/*'))) == 2



# Generated at 2022-06-11 22:42:03.083484
# Unit test for function chmod
def test_chmod(): # return bool
    chmod('~/tmp/flutils.tests/test_chmod/')
    return True # test passed
test_chmod()



# Generated at 2022-06-11 22:42:07.270573
# Unit test for function path_absent
def test_path_absent():
    path_absent('/tmp/test_path_absent')



# Generated at 2022-06-11 22:42:16.014354
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import tempfile as tmp
    import shutil
    from contextlib import ExitStack as ect

    with ect() as ex:
        temp = ex.enter_context(tmp.TemporaryDirectory(
            prefix='flutils.tests.pathutils.'))
        temp = Path(temp)

        with ex.enter_context(ect()) as ex2:
            sub = ex2.enter_context(tmp.TemporaryDirectory(
                prefix='flutils.tests.pathutils.',
                dir=temp,
            ))
            sub = Path(sub)

            with ex2.enter_context(ect()) as ex3:
                fpath = ex3.enter_context(tmp.NamedTemporaryFile(
                    prefix='flutils.tests.pathutils.',
                    dir=temp,
                ))
               

# Generated at 2022-06-11 22:42:28.537991
# Unit test for function directory_present
def test_directory_present():
    from flutils.tests.checktypes import is_posix_path
    import os
    import stat
    import sys

    path = Path('~/tmp/flutils.tests.osutils.test_directory_present.dir')
    path.expanduser()
    if path.exists():
        path.rmdir()

    test_path = directory_present(path)
    assert is_posix_path(test_path)
    assert test_path == path.expanduser()
    assert test_path.exists() is True
    assert test_path.is_dir() is True
    assert test_path.is_file() is False
    assert test_path.is_symlink() is False
    assert test_path.is_socket() is False
    assert test_path.is_fifo() is False
   

# Generated at 2022-06-11 22:42:36.716448
# Unit test for function chown
def test_chown():
    """
    Unit tests for the :func:`~flutils.pathutils.osutils.chown` function.
    """
    from os import stat as os_stat
    from pwd import getpwuid
    from grp import getgrgid

    import pytest

    from flutils.pathutils import (
        chown,
        get_os_user,
        get_os_group,
    )

    test_path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    test_path.parent.mkdir(parents=True, exist_ok=True)
    test_path.touch()


# Generated at 2022-06-11 22:42:49.467349
# Unit test for function directory_present
def test_directory_present():
    funcname = 'directory_present'
    test_path = Path('/Users/len') / 'test'
    try:
        os.stat(test_path)
        raise FileExistsError(
            'The path /Users/len/test already exists.'
            '  Therefore, unable to test the function pathutils.%s'
            % funcname
        )
    except FileNotFoundError:
        pass
    else:
        raise
    func = getattr(pathutils, funcname)

    ##########################################################################
    # Test path does not exist and is an absolute path

    # Ensure the new path's parent directories are created with the right
    # permissions.  Ensure the target path is created with the right
    # permissions.

# Generated at 2022-06-11 22:42:57.925334
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths()."""
    # Change the working directory so any path resolution is proper
    os.chdir(Path('.').resolve().parent)
    with TemporaryDirectory(prefix='flutils.tests.') as tmp:
        os.mkdir(os.path.join(tmp, 'dir_one'))
        Path(os.path.join(tmp, 'dir_one', 'file_one')).touch()
        Path(os.path.join(tmp, 'dir_one', 'dir_two')).mkdir(0o700)
        Path(os.path.join(tmp, 'dir_one', 'file_two')).touch()
        Path(os.path.join(tmp, 'dir_three')).mkdir(0o700)

# Generated at 2022-06-11 22:43:17.840927
# Unit test for function directory_present
def test_directory_present():

    from flutils.pathutils import (
        directory_present,
        exists_as,
        normalize_path,
        path_absent,
    )

    base_path = normalize_path('~/tmp/flutils.tests.pathutils.test_directory_present')
    path_absent(base_path)

    d_foo = directory_present(base_path / 'foo', mode=0o700, user='root', group='root')
    d_foo_b = directory_present(base_path / 'foo/b', mode=0o750, user='len', group='len')
    d_foo_c = directory_present(base_path / 'foo/c', mode=0o655, user='len', group='len')

# Generated at 2022-06-11 22:43:25.988135
# Unit test for function chmod
def test_chmod():
    from stat import S_IMODE

    from .osutils import make_paths
    from .testingutils import random_string

    path_to_file = make_paths(1)[0]

    file_contents = random_string()
    with open(path_to_file, 'w') as f:
        f.write(file_contents)

    mode_file = 0o640
    mode_dir = 0o770
    chmod(path_to_file, mode_file=mode_file, mode_dir=mode_dir)

    assert S_IMODE(path_to_file.stat().st_mode) == mode_file

    path_to_dir_ = make_paths(1)[0]
    path_to_dir_.mkdir(parents=True)

    mode_file = 0o666
    mode

# Generated at 2022-06-11 22:43:29.604856
# Unit test for function directory_present
def test_directory_present():
    path = Path(__file__).parent
    path = path.joinpath('directory_present')
    path = path.resolve()

    if path.exists():
        path.rmdir()
    path = directory_present(path)
    assert path.as_posix() == str(path)



# Generated at 2022-06-11 22:43:37.550342
# Unit test for function chown
def test_chown():
    tl = []
    def _(path, user, group):
        tl.append((path, user, group))
    def _getpwent():
        return (0, 0, 0, 0)
    def _getgrent():
        return (1, 1, 1, 1)
    pw_mock = mock.patch('pwd.getpwent', _getpwent)
    gr_mock = mock.patch('grp.getgrent', _getgrent)
    os_mock = mock.patch('os.chown', _)
    with pw_mock, gr_mock, os_mock:
        chown('/tmp')
        chown('/tmp', 'a')
        chown('/tmp', 'a', 'b')

# Generated at 2022-06-11 22:43:45.941610
# Unit test for function chown
def test_chown():
    created = None

# Generated at 2022-06-11 22:43:54.117002
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmpdir:
        dir_path: Path = Path(tmpdir)
        dir_one = dir_path / 'dir_one'
        dir_two = dir_path / 'dir_two'

        file_one = dir_one / 'file_one'
        file_two = dir_two / 'file_two'

        dir_one.mkdir()
        dir_two.mkdir()

        file_one.touch()
        file_two.touch()

        val: List[Path] = list(find_paths(str(dir_path.as_posix() / '*')))
        assert val == [dir_one, dir_two]

        val = list(find_paths(str(dir_one.as_posix())))
        assert val == [dir_one]


# Generated at 2022-06-11 22:43:57.086961
# Unit test for function chown
def test_chown():
    assert chown('~/tmp', include_parent=True) is None
    assert chown('~/tmp/**') is None
    assert chown('~/tmp/*', include_parent=True) is None



# Generated at 2022-06-11 22:44:03.248617
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path().cwd()) == 'directory'
    assert exists_as(Path().cwd() / 'package.json') == 'file'
    assert exists_as(Path().cwd() / 'node_modules') == 'directory'
    assert exists_as(Path().cwd() / 'tmp') == ''
    if os.name == 'nt':
        assert exists_as(Path().cwd().as_posix() + ':') == 'block device'
    else:
        assert exists_as('/') == 'block device'



# Generated at 2022-06-11 22:44:09.951757
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-11 22:44:12.667015
# Unit test for function chown
def test_chown():
    path = Path() / 'tmp' / 'flutils.tests.osutils.txt'
    try:
        chown(path)
        assert True
    finally:
        if path.exists():
            path.unlink()

# Generated at 2022-06-11 22:44:31.224567
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from tempfile import NamedTemporaryFile
    import os

    # Create a temporary file
    tmp_file = NamedTemporaryFile(mode='w', delete=False)
    tmp_file.close()

    # Test chmod with just a file
    assert os.stat(tmp_file.name).st_mode == 33188
    chmod(tmp_file.name)
    assert os.stat(tmp_file.name).st_mode == 33152

    # Test chmod with a glob pattern that won't match
    # anything (the normalize_path changes the path
    # to a PosixPath() object)
    assert os.stat(tmp_file.name).st_mode == 33152
    chmod(f'{tmp_file.name}*')

# Generated at 2022-06-11 22:44:32.944159
# Unit test for function exists_as
def test_exists_as():
    # Test exists_as on a directory
    dir_path = Path('/tmp/flutils')
    if dir_path.exists() is True:
        exists_as_dir = 'directory'
    els

# Generated at 2022-06-11 22:44:43.632679
# Unit test for function chown
def test_chown():
    '''Test normalization of a path'''
    basepath = 'flutils.tests.pathutils'
    # Create a path
    path = Path(__file__).with_name(basepath)
    # Create a directory
    path.mkdir(parents=True, exist_ok=True)
    # Change the ownership of the directory
    os.chown(path.as_posix(), 1000, 1000)
    # Create a file in the directory
    path = path.joinpath('test_chown.txt')
    path.write_text('Some text.')
    # Change the ownership of the file
    os.chown(path.as_posix(), 1000, 1000)
    # Change the ownership of the file
    path.chown(10000)
    path.chown(1000, 1000)
    # Assert that

# Generated at 2022-06-11 22:44:51.755395
# Unit test for function chown
def test_chown():
    assert os.path.isfile('/tmp/flutils.tests.osutils.txt')
    assert os.path.isdir('/tmp/flutils.tests.osutils')
    assert not os.path.isfile('/tmp/flutils.tests.osutils/flutils.tests.osutils.txt')
    assert not os.path.isdir('/tmp/flutils.tests.osutils/flutils.tests.osutils')

    chown('/tmp/flutils.tests.osutils.txt')

    assert os.path.isfile('/tmp/flutils.tests.osutils.txt')
    assert os.path.isdir('/tmp/flutils.tests.osutils')
    assert not os.path.isfile('/tmp/flutils.tests.osutils/flutils.tests.osutils.txt')

# Generated at 2022-06-11 22:44:57.958785
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/') == 'directory'
    assert exists_as('~/tmp') == ''
    assert exists_as('~/Downloads') == 'directory'
    assert exists_as('~/Downloads/flutils-0.9.9.tar.gz') == 'file'
    assert exists_as('~/Downloads/flutils-0.9.9') == ''



# Generated at 2022-06-11 22:45:05.569720
# Unit test for function chown
def test_chown():
    n = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    try:
        n.touch()
        os.chmod(n.as_posix(), 0o755)
        assert n.exists() == True
        chown(n)
        n_stat = n.stat()
        assert n_stat.st_uid == os.getuid()
    except Exception:
        if n.exists():
            n.unlink()
        raise
    else:
        if n.exists():
            n.unlink()




# Generated at 2022-06-11 22:45:11.952918
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev') is 'directory'
    assert exists_as('/') is 'directory'
    assert exists_as('/full/path/that/does/not/exist') is ''
    assert exists_as('/dev/urandom') is 'char device'
    assert exists_as('/dev/full/path/that/does/not/exist') is ''


#: The :obj:`str` format to use with the
#: :obj:`~flutils.pathutils._log_relative_paths` function
# pylint: disable=line-too-long
RELATIVE_LOG_FORMAT = (
    '{levelname:7s}: {name} : {relative_path}'
    ' :: {message}'
)
# pylint: enable=line-too-long

#: The

# Generated at 2022-06-11 22:45:22.715867
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    # Write a file to /tmp
    with open('/tmp/test_user', 'w') as f:
        f.write('test')

    # Create a directory in /tmp
    Path('/tmp/test_dir').mkdir(mode=0o777, parents=False, exist_ok=False)

    # Verify the test file is in /tmp
    assert list(find_paths('/tmp')) == [Path('/tmp')]

    # Verify the test file is in /tmp
    assert list(find_paths('/tmp/test_user')) == [Path('/tmp/test_user')]

    # Verify the test file is in /tmp

# Generated at 2022-06-11 22:45:31.717702
# Unit test for function exists_as
def test_exists_as():
    tests = {
        '~/tmp/': 'directory',
        '~/tmp/flutils/io.py': 'file',
        '~/tmp/test.device': 'block device',
        '~/tmp/test.fifo': 'FIFO',
        '~/tmp/test.socket': 'socket',
        '~/tmp/test.not_there': '',
    }
    for path, expected in tests.items():
        assert exists_as(path) == expected



# Generated at 2022-06-11 22:45:37.697591
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('~/tmp/foo')
    list(find_paths(pattern))
    pattern = Path('~/tmp/foo*')
    list(find_paths(pattern))
    pattern = Path('~/tmp/*')
    list(find_paths(pattern))
    pattern = Path('~/tmp/**')
    list(find_paths(pattern))



# Generated at 2022-06-11 22:46:01.824508
# Unit test for function directory_present
def test_directory_present():
    import shutil
    import tempfile

    base_dir = tempfile.TemporaryDirectory(prefix='flutils_test')
    sub_dir = os.path.join(base_dir.name, 'sub', 'sub2', 'sub3')
    try:
        out_path = directory_present(sub_dir)
        assert out_path.as_posix() == sub_dir
        assert os.path.exists(sub_dir) is True
    finally:
        shutil.rmtree(base_dir.name)

    import pwd

    user = pwd.getpwuid(os.getuid()).pw_name
    group = grp.getgrgid(os.getgid()).gr_name

    base_dir = tempfile.TemporaryDirectory(prefix='flutils_test')
    sub