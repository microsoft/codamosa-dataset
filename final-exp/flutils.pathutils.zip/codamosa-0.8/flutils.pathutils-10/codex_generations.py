

# Generated at 2022-06-11 22:36:22.869421
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-11 22:36:33.971433
# Unit test for function directory_present
def test_directory_present():
    # Attempt to create an absolute path where the
    # parent directory does not exist.
    target_path = '/tmp/does_not_exist/new_dir'
    find_paths(target_path)[0].unlink(missing_ok=True)
    find_paths('/tmp/does_not_exist')[0].unlink(missing_ok=True)
    p = directory_present(target_path)
    assert p.as_posix() == target_path
    assert os.path.isdir(target_path) is True

    # Attempt to create /tmp/does_not_exist/another_dir
    # where the parent directory does exist.
    target_path = '/tmp/does_not_exist/another_dir'
    find_paths(target_path)[0].unlink(missing_ok=True)

# Generated at 2022-06-11 22:36:37.197040
# Unit test for function find_paths
def test_find_paths():
    # Unit test for function find_paths
    assert [isinstance(x, Path) for x in find_paths('~/tmp/*')]



# Generated at 2022-06-11 22:36:37.631477
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-11 22:36:40.256758
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None

    Path('~/tmp/flutils.tests.osutils.txt').chmod() == 0o660


# Generated at 2022-06-11 22:36:49.604469
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function flutils.pathutils.exists_as"""
    def exists_as_test_block_dev():
        """Test exists_as with a Linux block device"""
        assert exists_as('/dev/sda1') == 'block device'
        assert exists_as('/dev/sda1/') == ''
    if running_platform.os == 'linux':
        exists_as_test_block_dev()

    def exists_as_test_char_dev():
        """Test exists_as with a Linux character device"""
        assert exists_as('/dev/random') == 'char device'

    if running_platform.os == 'linux':
        exists_as_test_char_dev()

    def exists_as_test_dir():
        """Test exists_as with a directory"""

# Generated at 2022-06-11 22:37:00.453387
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.test import TestCase

    class TestExistsAs(TestCase):
        def test_exists_as_directory(self):
            path = '~/tmp/test_realpath'
            self.assertEqual(exists_as(path), '')

            directory_present(path)
            self.assertEqual(exists_as(path), 'directory')

            path.rmtree()
            self.assertEqual(exists_as(path), '')

        def test_exists_as_file(self):
            path = '~/tmp/test_realpath'
            self.assertEqual(exists_as(path), '')

            path.touch()
            self.assertEqual(exists_as(path), 'file')

           

# Generated at 2022-06-11 22:37:09.590497
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import os.path as op

    # create a test directory, set and verify ownership
    tmpdir = tempfile.mkdtemp(prefix='flutils-test-pathutils')
    owner = 'nobody'
    group = 'nogroup'
    chown(tmpdir, user=owner, group=group)
    uid = get_os_user(owner).pw_uid
    gid = get_os_group(group).gr_gid
    assert(os.stat(tmpdir).st_uid == uid)
    assert(os.stat(tmpdir).st_gid == gid)

    # create a test file, set and verify ownership
    testfile = op.join(tmpdir, 'testfile')

# Generated at 2022-06-11 22:37:22.574131
# Unit test for function chown
def test_chown():
    import os
    import shutil
    import tempfile
    from pathlib import Path
    from flutils.pathutils import chown
    from flutils.osutils import get_uid, get_gid, is_windows

    if not is_windows():
        # Setup a test dir
        tmp_dir = Path(tempfile.mkdtemp())
        source_dir = Path(shutil.which('python'))

        shutil.copytree(source_dir.as_posix(), tmp_dir.joinpath('python').as_posix())

        # Test if user and group change to file and directory
        chown(tmp_dir.joinpath('python').as_posix(), user='nobody', group='nobody')

        # Validate user and group
        # Directory

# Generated at 2022-06-11 22:37:32.134185
# Unit test for function chmod
def test_chmod():
    import tempfile
    from os import stat
    from shutil import rmtree
    from time import sleep
    from datetime import datetime

    tmpd = tempfile.mkdtemp()

    mtime_path1 = datetime(year=2019, month=1, day=1, hour=0, minute=0)
    mtime_path2 = datetime(year=2020, month=1, day=1, hour=0, minute=0)

    # Create the first test file.
    path1 = Path(tmpd, 'test1.txt')
    path1.write_text('This is test1.txt')
    statinfo = stat(path1.as_posix())
    assert statinfo.st_mode & 0o777 == 0o600
    path1.touch(mtime_path1)

    # Create the second

# Generated at 2022-06-11 22:37:41.623320
# Unit test for function chown
def test_chown():
    assert True

# Generated at 2022-06-11 22:37:53.231487
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import normalize_path
    from os import getenv
    from os.path import join as pjoin
    from uuid import uuid4

    tdir = TemporaryDirectory(prefix='/tmp')
    path = pjoin(tdir.name, uuid4().hex)

    with open(path, 'w'):
        pass

    test_usr = getenv('USER')

    if test_usr == 'root':
        test_usr = 'nobody'

    test_grp = getenv('USER')

    chown(path, user=test_usr, group=test_grp)

    stats = os.stat(path)
    tusr = pwd.getpwuid(stats.st_uid).pw_name
    tgrp = grp.getgr

# Generated at 2022-06-11 22:38:03.728397
# Unit test for function exists_as
def test_exists_as():

    from .osutils import get_temp_path
    from .random import get_random_int
    from .random import get_random_string

    path_name = get_random_string(length=get_random_int(min_=6, max_=12))
    path = get_temp_path(suffix=path_name)

    try:
        path.mkdir()
        assert exists_as(path) == 'directory'

        file_ = path.joinpath(get_random_string(length=get_random_int(min_=6, max_=12)))
        file_.touch()
        assert exists_as(file_) == 'file'
    finally:
        path.rmdir()



# Generated at 2022-06-11 22:38:06.687375
# Unit test for function exists_as
def test_exists_as():
    path = Path.cwd() / 'tests' / 'data'
    assert exists_as(path) == 'directory'
    test_file = path / 'osutils.txt'
    assert exists_as(test_file) == 'file'



# Generated at 2022-06-11 22:38:16.304626
# Unit test for function find_paths
def test_find_paths():
    test_dir = directory_present('~/tmp/find_paths')
    test_file = (test_dir / 'test_file.txt').touch()
    test_dir = (test_dir / 'test_dir')
    test_dir.mkdir()

    found_paths = find_paths(test_dir.as_posix() + '/*')
    if test_file not in found_paths or test_dir not in found_paths:
        print('test_find_paths() FAILED')
        sys.exit(1)

    test_file.unlink()
    test_dir.rmdir()
    test_dir.parent.rmdir()



# Generated at 2022-06-11 22:38:21.371199
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.path.abspath(os.curdir)) == 'directory'
    assert exists_as(os.path.join(os.path.abspath(os.curdir), 'README.md')) == 'file'



# Generated at 2022-06-11 22:38:31.014890
# Unit test for function exists_as
def test_exists_as():
    import pathlib
    exists_as = pathutils.exists_as
    test_dir = pathlib.Path.home() / 'tmp' / 'flutils' / 'tests'
    test_file = test_dir / 'osutils.txt'
    test_link = test_dir / 'osutils_link.txt'
    directory_present(test_dir)
    test_file.touch()
    test_link.symlink_to(test_file)
    assert exists_as(test_dir) == 'directory'
    assert exists_as(test_file) == 'file'
    assert exists_as(test_link) == 'file'
    assert exists_as(test_file.parent) == 'directory'
    assert exists_as(test_link.parent) == 'directory'

# Generated at 2022-06-11 22:38:33.369024
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_gid == get_os_group().gr_gid
    assert get_os_user().pw_uid == os.getuid()



# Generated at 2022-06-11 22:38:44.716059
# Unit test for function find_paths
def test_find_paths():
    from pathlib import PosixPath
    with tempfile.TemporaryDirectory() as temp_directory:
        path_one = os.path.join(temp_directory, 'path_one')
        path_two = os.path.join(temp_directory, 'path_two')
        path_three = os.path.join(temp_directory, 'path_three')
        paths = [path_one, path_two, path_three]
        for path in paths:
            with open(path, 'w', encoding='utf-8') as write_file:
                write_file.write('Test')

        results = list(find_paths(os.path.join(temp_directory, 'path_*')))
        assert len(results) == 3
        for path in paths:
            assert Path(path) in results
            assert PosixPath

# Generated at 2022-06-11 22:38:52.981921
# Unit test for function chown
def test_chown():
    path = '/tmp/flutils/tests/pathutils/my_dir/my_file'
    expected = """
    --------------------------------------------------
    chown(/tmp/flutils/tests/pathutils/my_dir/my_file)
    --------------------------------------------------
    path: /tmp/flutils/tests/pathutils/my_dir/my_file
    user: -1
    group: -1
    include_parent: False
    """
    try:
        os.makedirs('/tmp/flutils/tests/pathutils/my_dir')
    except OSError:
        pass
    with open(path, 'w') as fh:
        fh.write('foo')
    try:
        assert chown(path) == expected.strip()
    finally:
        os.unlink(path)
        os

# Generated at 2022-06-11 22:39:18.469274
# Unit test for function chmod
def test_chmod():
    import pytest
    from flutils.pathutils import (
        chmod,
        directory_present,
        path_absent,
    )
    from flutils.tests.data import paths

    #
    # Test path that does not exist
    #
    with pytest.raises(FileNotFoundError):
        chmod('/tmp/does/not/exist')

    #
    # Test directory
    #
    with directory_present(paths['directory']):
        chmod(paths['directory'])

        d_mode = paths['directory'].stat().st_mode
        assert oct(d_mode & 0o777) == oct(0o700)

    with directory_present(paths['directory']):
        chmod(paths['directory'], mode_dir=0o750)

        d_mode = paths

# Generated at 2022-06-11 22:39:27.318444
# Unit test for function chown
def test_chown():
    from unittest.mock import patch
    from flutils.pathutils import chown
    with patch(
        'flutils.pathutils.os.chown',
        spec_set=True,
        return_value=None
    ) as mock_chown:
        chown('foo', 'bar', 'baz')
        mock_chown.assert_called_once_with(
            'foo',
            getpass.getuser(),
            grp.getgrgid(os.getgid()).gr_gid
        )



# Generated at 2022-06-11 22:39:42.178048
# Unit test for function chmod
def test_chmod():
    tmp_dir = Path('/tmp/flutils_chmod_test')
    if tmp_dir.is_dir() is False:
        tmp_dir.mkdir(parents=True)


# Generated at 2022-06-11 22:39:45.113459
# Unit test for function path_absent
def test_path_absent():
    path = Path('~', 'tmp', 'test_path')
    path = path_absent(path)
    assert not path.exists()

# Generated at 2022-06-11 22:39:59.385845
# Unit test for function chown
def test_chown():
    class MockPwdStruct:
        pw_uid = 0
        pw_gid = 0

    mock_pwd_struct = MockPwdStruct()
    with mock.patch('os.chown') as mock_chown:
        mock_chown.return_value = None
        with mock.patch('pwd.getpwnam') as mock_getpwnam:
            mock_getpwnam.return_value = mock_pwd_struct
            with mock.patch('grp.getgrnam') as mock_getgrnam:
                mock_getgrnam.return_value = mock_pwd_struct
                chown('/tmp/foo')
                mock_chown.assert_called_once_with('/tmp/foo', 0, 0)



# Generated at 2022-06-11 22:40:05.773809
# Unit test for function chown
def test_chown():
    path = Path(__file__).resolve().parent / 'testdata/testchown'
    owner = os.stat(path.as_posix()).st_uid
    group = os.stat(path.as_posix()).st_gid
    chown(path, str(owner), str(group))

# Generated at 2022-06-11 22:40:11.525584
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import time
    with open('/tmp/test_chmod.txt', 'w') as fh:
        fh.write("testing")
    chmod('/tmp/test_chmod.txt', 0o600)
    assert os.stat("/tmp/test_chmod.txt").st_mode & 0o777 == 0o600
    os.remove("/tmp/test_chmod.txt")
    assert True



# Generated at 2022-06-11 22:40:23.799380
# Unit test for function chmod
def test_chmod():
    """Test for flutils.pathutils.chmod"""
    import pytest
    from flutils.pathutils import chmod

    tmpdir = pytest.ensuretemp('flutils.tests.osutils')
    tmpdir.mkdir()

    with pytest.raises(NotImplementedError):
        list(Path().glob('*'))

    test_paths = (
        tmpdir
            / 'flutils.tests.osutils.txt',
        tmpdir
            / 'flutils.tests.osutils.dir'
            / 'flutils.tests.osutils.txt',
    )

    for test_path in test_paths:
        test_path.parent.mkdir()
        test_path.touch()

    chmod(str(tmpdir / '*.txt'), 0o664)
    chmod

# Generated at 2022-06-11 22:40:32.550284
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        tmp_path.joinpath('file_one').touch()
        tmp_path.joinpath('file_two').touch()
        tmp_path.joinpath('dir_one').mkdir()
        tmp_path.joinpath('dir_two').mkdir()
        result = list(find_paths(tmp_path.as_posix() + '/*'))
        assert len(result) == 4, result
        assert result[0] == tmp_path.joinpath('dir_one'), result[0]
        assert result[1] == tmp_path.joinpath('dir_two'), result[1]
        assert result[2] == tmp_path.joinpath('file_one'), result[2]
        assert result[3] == tmp_path.joinpath

# Generated at 2022-06-11 22:40:35.799502
# Unit test for function chmod
def test_chmod():
    # Read documentation to see if there are any special requirements.
    assert chmod
#


# Generated at 2022-06-11 22:41:09.211936
# Unit test for function path_absent
def test_path_absent():
    path = os.path.join(os.getcwd(), 'tmp')
    path_at(os.getcwd(), 'tmp/file_one')
    path_at(path, 'dir_one')
    path_absent(path)
    assert os.path.exists(path) is False



# Generated at 2022-06-11 22:41:19.054804
# Unit test for function chown
def test_chown():
    # chown does not support windows
    if os.name == 'nt':
        return

    # Test with a non-existent user
    try:
        chown('~/tmp/flutils.tests.osutils.txt', user='Does_not_exist')
    except OSError:
        pass
    else:
        raise AssertionError("OSError not raised as expected.")

    # Test with a non-existent group
    try:
        chown('~/tmp/flutils.tests.osutils.txt', group='Does_not_exist')
    except OSError:
        pass
    else:
        raise AssertionError("OSError not raised as expected.")

    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-11 22:41:26.737604
# Unit test for function find_paths
def test_find_paths():
    import flutils.pathutils
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    def has_windows_file_types(items: list) -> bool:
        """Return value of :obj:`True` if ``items`` contains a WindowsPath."""
        for item in items:
            if isinstance(item, flutils.pathutils._windowsPath):
                return True
        return False

    def has_posix_file_types(items: list) -> bool:
        """Return value of :obj:`True` if ``items`` contains a PosixPath."""
        for item in items:
            if isinstance(item, flutils.pathutils._posixPath):
                return True
        return False


# Generated at 2022-06-11 22:41:36.186412
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__)
    assert exists_as(path) == 'file'
    path = Path(__file__).with_suffix('.faux')
    assert exists_as(path) == ''
    path = Path('.')
    assert exists_as(path) == 'directory'
    path = Path('.').with_name('faux').joinpath('faux')
    assert exists_as(path) == ''
    path = Path('.')
    assert exists_as(path) == 'directory'
    path = Path('faux')
    assert exists_as(path) == ''
test_exists_as()



# Generated at 2022-06-11 22:41:37.989199
# Unit test for function exists_as
def test_exists_as():
    path = exists_as('/etc/passwd')
    assert path == 'file'

# Generated at 2022-06-11 22:41:48.335852
# Unit test for function exists_as
def test_exists_as():
    """Test exists_as()."""

    path = Path(__file__).parent.joinpath('pytest.ini')
    assert exists_as(path) == 'file'

    path = Path(__file__).parent
    assert exists_as(path) == 'directory'

    path = Path(__file__)
    assert exists_as(path) == 'file'

    path = Path('/dev/sda')
    assert exists_as(path) == 'block device'

    path = Path('/dev/null')
    assert exists_as(path) == 'character device'

    path = Path('/dev/fd0')
    assert exists_as(path) == 'block device'

    path = Path('/dev/tty')
    assert exists_as(path) == 'character device'


# Generated at 2022-06-11 22:42:01.478541
# Unit test for function path_absent
def test_path_absent():
    """Test function path_absent"""
    from os import getcwd
    from os import unlink
    from os.path import exists
    from os.path import expanduser
    from os.path import isdir

    from pathlib import PosixPath
    from pathlib import WindowsPath
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    from flutils.pathutils import path_absent

    def create_tmp_tree():
        base_tmp_dir = mkdtemp(prefix='flutils-pathutils-')

# Generated at 2022-06-11 22:42:08.680018
# Unit test for function find_paths
def test_find_paths():
    fixture_dir = Path(
        'tests/fixtures/pathutils/find_paths'
    )
    cur_dir = osutils.getcwd()
    osutils.chdir(fixture_dir.parent)

    expected = [
        fixture_dir / 'one.txt',
        fixture_dir / 'two.txt',
    ]
    results = sorted(
        find_paths(fixture_dir)
    )

    assert expected == results
    osutils.chdir(cur_dir)



# Generated at 2022-06-11 22:42:16.854730
# Unit test for function chmod
def test_chmod():
    from subprocess import Popen, PIPE, run
    import stat

    # Setup
    tmp_txt_path = Path('tmp/flutils.tests.osutils.txt')
    tmp_path = Path('tmp/flutils.tests.osutils')
    with tmp_txt_path.open('w') as fh:
        fh.write('Hello World')
        fh.flush()

    assert tmp_txt_path.exists() is True
    assert tmp_path.exists() is True
    assert tmp_txt_path.is_file() is True
    assert tmp_path.is_dir() is True

    # Test missing path
    chmod('tmp/flutils.tests.osutils.bogus.txt')

# Generated at 2022-06-11 22:42:23.033347
# Unit test for function exists_as
def test_exists_as():
    import tempfile
    test_dir = Path(tempfile.mkdtemp())
    test_file = Path(test_dir, 'test')
    test_file.touch()
    assert exists_as(test_dir) == 'directory'
    assert exists_as(test_file) == 'file'
    test_file.unlink()
    test_dir.rmdir()


# Generated at 2022-06-11 22:42:44.614225
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/tmp/**')) == list(Path('/tmp').glob('**'))
    assert list(find_paths('/')) == [Path('/')]
    assert list(find_paths('~/tmp/*')) == list(Path('~/tmp').glob('*'))



# Generated at 2022-06-11 22:42:55.698065
# Unit test for function find_paths
def test_find_paths():
    """Testing function: find_paths."""

    # Test the find_paths() function with a glob pattern
    # that will yeild results.
    test_dir = directory_present(
        os.path.join('~', 'tmp', 'flutils.tests.pathutils')
    )

# Generated at 2022-06-11 22:42:59.078648
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == \
        [Path('~/tmp/file_one'), Path('~/tmp/dir_one')]
"""
Unit test for function find_paths.

To run this test type:

pytest -v --capture=no \
    tests/test_pathutils.py::test_find_paths
"""



# Generated at 2022-06-11 22:43:06.243264
# Unit test for function chown
def test_chown():
    from flutils.testutils import TempDir
    from flutils import chown

    with TempDir(prefix='flutils.tests.osutils') as tmpdir:
        fqdn = tmpdir / 'foo.txt'
        fqdn.touch()

        chown(fqdn, group='-1')
        assert fqdn.stat().st_gid == -1

        chown(fqdn, user='-1')
        assert fqdn.stat().st_uid == -1

# Generated at 2022-06-11 22:43:17.051508
# Unit test for function find_paths
def test_find_paths():
    from flutils.tests import get_test_item
    with TemporaryDirectory() as tmp_dir:
        for item in get_test_item():
            dir_path = Path(tmp_dir) / item
            dir_path.mkdir()
            for item2 in get_test_item():
                file_path = dir_path / item2
                file_path.touch()
        assert sorted(find_paths(str(dir_path) + '/*')) == \
            sorted([dir_path / item2 for item2 in get_test_item()])
        assert sorted(find_paths(str(dir_path) + '/*/*')) == \
            sorted([dir_path / item1 / item2
                    for item1 in get_test_item()
                    for item2 in get_test_item()])



# Generated at 2022-06-11 22:43:21.582303
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function ``find_paths``."""
    print()
    print(test_find_paths.__doc__)
    print()

    assert sorted(find_paths('~/tmp/*')) == sorted([
        Path('/tmp/file_one'), Path('/tmp/dir_one')
    ])



# Generated at 2022-06-11 22:43:31.709344
# Unit test for function get_os_user
def test_get_os_user():
    """Functional test of ``get_os_user``.

    Raises:
        AssertionError: if get_os_user() fails.

    """
    try:
        assert get_os_user() == pwd.getpwuid(os.getuid())
        assert get_os_user(get_os_user().pw_name) == pwd.getpwuid(
            os.getuid()
        )
        assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    except OSError:
        # This can happen when running through some automated
        # test suites.
        pass



# Generated at 2022-06-11 22:43:38.628368
# Unit test for function find_paths
def test_find_paths():
    TestFindPaths = namedtuple(
        'UnitTestFindPaths',
        ['path', 'pattern', 'expected']
    )

# Generated at 2022-06-11 22:43:49.649040
# Unit test for function chown
def test_chown():
    """Test the chown function."""

    print('Testing chown.')

    path = Path(__file__).parent.joinpath('test.tmp')
    if not path.exists():
        path.touch()


# Generated at 2022-06-11 22:44:01.050365
# Unit test for function chown
def test_chown():
    from flutils import osutils
    from flutils.pathutils import chown
    if osutils.is_windows() is False:
        print('Testing function chown... ', end='')

        dpath = normalize_path('~/tmp/flutils.tests.pathutils.chown.dir')
        fpath = normalize_path('~/tmp/flutils.tests.pathutils.chown.fpath')

        if normalize_path(dpath).exists() is True:
            os.rmdir(dpath)
        if normalize_path(fpath).exists() is True:
            os.unlink(fpath)

        os.mkdir(dpath)
        with open(fpath, 'w') as f:
            f.write('hello')

        # set chown glob, with group
       

# Generated at 2022-06-11 22:44:27.658043
# Unit test for function find_paths
def test_find_paths():
    # Get the path of this module.
    test_dir = Path(__file__).parent.as_posix()
    # Generate a randomly named directory, change to that dir, and create
    # a file in that directory.
    test_dir_name = str(uuid.uuid4())
    test_dir_path = Path(os.path.join(test_dir, test_dir_name))
    os.mkdir(test_dir_path.as_posix())
    os.chdir(test_dir_path.as_posix())
    test_file_name = 'foo.txt'
    test_file_path = Path(os.path.join(test_dir_path, test_file_name))
    open(test_file_path.as_posix(), 'w').close()
    # Find the

# Generated at 2022-06-11 22:44:31.280012
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('~/tmp/*')
    pattern = normalize_path(pattern)
    search = pattern.as_posix()[len(pattern.anchor):]
    assert search == 'tmp/*'
    assert list(find_paths('~/tmp/*')) == [Path('/home/test_user/tmp/file_one'), Path('/home/test_user/tmp/dir_one')]


# Generated at 2022-06-11 22:44:42.922231
# Unit test for function chown
def test_chown():
    from flutils.testutils import TestCase
    from textwrap import dedent

    from flutils.pathutils import chown

    # Test that an OSError is raised if an invalid user is given.
    with TestCase(expected_exception_type=OSError):
        chown('/dev/null', user='__foobar__')

    # Test that an OSError is raised given an invalid group is given.
    with TestCase(expected_exception_type=OSError):
        chown('/dev/null', user='__foobar__')

    # Test that chown will not process a path that does not exist.
    chown('/dev/null/foobar')


# Generated at 2022-06-11 22:44:44.502239
# Unit test for function chown
def test_chown():
    # OSError
    # Functionality is handled in function chmod
    pass



# Generated at 2022-06-11 22:44:49.113729
# Unit test for function chown
def test_chown():
    from . import get_temp_dir

    temp_dir = get_temp_dir()
    test_file = temp_dir / 'test.txt'
    if test_file.exists():
        test_file.unlink()
    test_file.touch()
    chown(test_file)
    test_file_stat = test_file.stat()
    assert test_file_stat.st_uid == os.getuid()



# Generated at 2022-06-11 22:45:02.037198
# Unit test for function chown
def test_chown():
    from flutils.osutils import mkdir
    from flutils.pathutils import path_absent
    from flutils.testingutils import CWDTempDir
    import tempfile
    with CWDTempDir() as temp_dir:
        path = temp_dir / 'flutils.tests.osutils.txt'
        path.touch()
        assert path.exists() is True
        chown(path, 'root', 'wheel')
        assert path.owner() == 'root'
        assert path.group() == 'wheel'
        assert path.exists() is True
        path = temp_dir / 'flutils.tests.osutils.txt'
        path.touch()
        path.chmod(0o777)
        assert path.exists() is True
        chown(path, -1, -1)
        assert path.owner

# Generated at 2022-06-11 22:45:12.695444
# Unit test for function chmod
def test_chmod():
    # No need to explicitly test the glob pattern
    # cases as those will be tested in
    # test_find_paths().
    #
    # Test when the path is a file or
    # symlink to a file.
    _test_file = Path('/tmp/flutils.tests.osutils.txt')
    if _test_file.exists():
        _test_file.unlink()
    _test_file.touch()
    old_stat = _test_file.stat()
    chmod(_test_file)
    assert old_stat.st_mode != _test_file.stat().st_mode
    _test_file.unlink()
    #
    # Test when the path is a directory or
    # symlink to a directory.

# Generated at 2022-06-11 22:45:21.325849
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown

    if os.name == 'nt':
        return

    test_file = tempfile.NamedTemporaryFile('w+')
    tmp_path = Path(test_file.name)

    assert chown(tmp_path, user='root') is None
    assert os.stat(tmp_path.as_posix()).st_uid == 0
    assert chown(tmp_path, group='root') is None
    assert os.stat(tmp_path.as_posix()).st_gid == 0



# Generated at 2022-06-11 22:45:34.524551
# Unit test for function chmod
def test_chmod():
    import pytest
    import platform
    import shutil
    import tempfile
    import uuid
    from flutils.pathutils import _normalize_path_posix
    from flutils.pathutils import _normalize_path_win

    # Using a function here to support _PATH
    # so that mypy is happy.
    def _get_tmp_dir() -> Path:
        return Path(tempfile.gettempdir())


# Generated at 2022-06-11 22:45:39.015488
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path(__file__)) == 'file'
    assert exists_as(Path(__file__).parent) == 'directory'

