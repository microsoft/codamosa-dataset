

# Generated at 2022-06-23 18:16:40.018659
# Unit test for function directory_present
def test_directory_present():
    import shutil
    from operator import itemgetter

    from pyfakefs.fake_filesystem_unittest import TestCase

    from flutils.pathutils import (
        directory_present,
        exists_as,
        normalize_path,
    )

    class TestDirectoryPresent(TestCase):

        def setUp(self) -> None:
            self.setUpPyfakefs()
            self.fs.add_real_directory(os.path.sep)

            self.cur_user = os.getenv('USER')
            self.cur_passwd = pwd.getpwnam(self.cur_user)
            self.cur_group = grp.getgrgid(os.getegid())

        def test_with_path(self) -> None:
            path = Path('/root/test/path')

# Generated at 2022-06-23 18:16:51.394275
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError) as err:
        get_os_group(1)
    assert err.value.errno == errno.ENOENT
    assert err.value.strerror == 'The given gid: 1, is not a valid gid for ' \
                                 'this operating system.'

    with pytest.raises(OSError) as err:
        get_os_group('foo')
    assert err.value.errno == errno.ENOENT
    assert err.value.strerror == 'The given name: "foo", is not a valid ' \
                                 '"group name" for this operating system.'



# Generated at 2022-06-23 18:16:53.330561
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/tmp/*')) == []
    assert list(find_paths('/tmpp/*')) == []



# Generated at 2022-06-23 18:17:01.636785
# Unit test for function exists_as
def test_exists_as():
    """ Test exists_as function."""
    assert(exists_as(Path().cwd()) == 'directory')
    assert(exists_as('~/tmp') == 'directory')
    assert(exists_as('~/tmp/flutils.tests.osutils.txt') == 'file')
    assert(exists_as('tmp.does_not_exist') == '')
# End of test exists_as



# Generated at 2022-06-23 18:17:03.029768
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/tmp/nope*')) == []


# Generated at 2022-06-23 18:17:14.551859
# Unit test for function directory_present
def test_directory_present():
    """Test the function directory_present."""

    import os
    import shutil
    import tempfile
    import traceback

    import pytest
    from testfixtures import log_capture
    from testfixtures.popen import MockPopen

    from flutils.pathutils import directory_present

    # Create test directory.
    tmp_dir = tempfile.mkdtemp()
    test_dir = os.path.join(tmp_dir, 'test_dir')
    test_dir_exist_as_file = os.path.join(test_dir, 'test_dir_file.txt')
    os.makedirs(test_dir)

    # Create test_dir_exist_as_file file.
    with open(test_dir_exist_as_file, 'w'):
        pass


# Generated at 2022-06-23 18:17:21.532000
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for flutils.pathutils.normalize_path."""
    normalize_path.register(bytes, normalize_path.registry[str])
    normalize_path.register(Path, normalize_path.registry[str])
    path = '~/tmp/foo/../bar'
    assert normalize_path(path) == Path.home().joinpath('tmp', 'bar')



# Generated at 2022-06-23 18:17:22.476270
# Unit test for function chown
def test_chown():
    pass # TODO

# Generated at 2022-06-23 18:17:24.088096
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('~/tmp/test_path') == Path(
        '/Users/len/tmp/test_path'
    )



# Generated at 2022-06-23 18:17:25.009209
# Unit test for function chmod
def test_chmod():
    assert callable(chmod)



# Generated at 2022-06-23 18:17:32.460508
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    get_os_user_uid = 2748
    get_os_user_name = 'root'
    get_os_user_name_as_uid = '0'
    user = get_os_user()
    assert user.pw_name == get_os_user_name
    assert user.pw_uid == get_os_user_uid
    user = get_os_user(get_os_user_name)
    assert user.pw_name == get_os_user_name
    assert user.pw_uid == get_os_user_uid
    user = get_os_user(get_os_user_name_as_uid)
    assert user.pw_name == get_os_user_name

# Generated at 2022-06-23 18:17:36.286828
# Unit test for function directory_present
def test_directory_present():
    dir_path = directory_present('/tmp/flutils.tests/directory_present')
    assert dir_path == Path('/tmp/flutils.tests/directory_present')
    assert exists_as(dir_path) == 'directory'



# Generated at 2022-06-23 18:17:44.347298
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    with pytest.raises(OSError) as exc_info:
        get_os_group(1_000)
    assert 'is not a valid gid for this operating system' in str(exc_info.value)
    assert exc_info.value.errno == errno.ESRCH
    with pytest.raises(OSError) as exc_info:
        get_os_group('foo')
    assert 'is not a valid "group name" for this operating system' in str(exc_info.value)
    assert exc_info.value.errno == errno.ESRCH



# Generated at 2022-06-23 18:17:50.750946
# Unit test for function chown
def test_chown():
    """
    >>> chown('~/tmp/does_not_exist')
    >>> chown('~/tmp/does_not_exist', '-1', '-1')
    >>> chown('~/tmp/does_not_exist', user='-1', group='-1')

    """
    curr_user = getpass.getuser()
    curr_group = grp.getgrgid(os.getgid()).gr_name

    out_txt = Path('~/tmp/flutils.tests.pathutils.txt')
    out_txt.parent.mkdir(mode=0o700, exist_ok=True)
    with open(out_txt.absolute(), 'w') as tmpf:
        tmpf.write('foobar')

    chown(out_txt.absolute())
    assert get_os

# Generated at 2022-06-23 18:17:56.387188
# Unit test for function exists_as
def test_exists_as():
    absolute_path = os.path.abspath(__file__)
    file_exists = exists_as(absolute_path)
    assert file_exists == 'file'
    nonexistent_file = absolute_path + '_foo'
    assert exists_as(nonexistent_file) == ''



# Generated at 2022-06-23 18:18:01.836431
# Unit test for function path_absent
def test_path_absent():
    if __name__ == '__main__':
        print('\n\n')
        print('========================================')
        print('Testing function:  path_absent')
        print('========================================')
        print('\n')
        # Create a directory to test against and put some files in it.
        tmpdir = Path(tempfile.mkdtemp())
        path_present(tmpdir / 'file_one')
        path_present(tmpdir / 'dir_one')
        path_present(tmpdir / 'dir_one' / 'file_two')
        path_absent(tmpdir / 'dir_one' / 'file_two')
        path_absent(tmpdir / 'dir_one')
        path_absent(tmpdir / 'file_one')
        path_absent(tmpdir)
        assert os.path

# Generated at 2022-06-23 18:18:05.775825
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as(os.path.sep) == 'directory'
    assert exists_as('~/tmp/does_not_exist') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt/does_not_exist') == ''



# Generated at 2022-06-23 18:18:07.143066
# Unit test for function directory_present
def test_directory_present():
    path = Path()
    result = directory_present(path, mode=0o777)
    assert result == path



# Generated at 2022-06-23 18:18:08.499733
# Unit test for function chown
def test_chown():
    chown('/tmp/foo')
    chown('/tmp/foo', user='foo', group='bar')



# Generated at 2022-06-23 18:18:13.002044
# Unit test for function directory_present
def test_directory_present():
    """Test for directory_present."""
    from flutils.pathutils import directory_present, path_absent

    path_to_test = '/tmp/directory_present_unit_test'
    path_absent(path_to_test)
    directory_present(path_to_test)
    path_absent(path_to_test)



# Generated at 2022-06-23 18:18:20.406476
# Unit test for function chmod
def test_chmod():
    # Make sure the `remove` argument to `chmod` works.
    if os.path.exists("~/tmp/flutils.tests.osutils.txt"):
        os.remove("~/tmp/flutils.tests.osutils.txt")
    chmod("~/tmp/flutils.tests.osutils.txt", 0o660)
    os.remove("~/tmp/flutils.tests.osutils.txt")

    # Test glob pattern change
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')
    chmod('~/tmp/')



# Generated at 2022-06-23 18:18:31.454013
# Unit test for function get_os_group
def test_get_os_group():
    """Test the function get_os_group."""
    from sys import version_info
    if version_info >= (3, 7):
        from unittest.mock import patch
    else:
        from unittest.mock import patch

    with patch('grp.getgrnam', return_value=grp.struct_group(
            gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo'])
            ) as mock_grp_getgrnam:

        group_obj_1 = get_os_group('bar')
        group_obj_2 = get_os_group(name='bar')
        assert group_obj_1.gr_gid == group_obj_2.gr_gid


# Generated at 2022-06-23 18:18:42.513619
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/test.txt') == 'file'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/stdin') == 'char device'
    assert exists_as('/dev/disk0') == 'block device'
    assert exists_as('/dev/disk1') == 'block device'
    assert exists_as('/dev/random') == 'FIFO'
    assert exists_as('/dev/.random') == ''
    assert exists_as('/dev/tcp') == ''



# Generated at 2022-06-23 18:18:52.894633
# Unit test for function path_absent
def test_path_absent():
    # Create a test directory
    with tempfile.TemporaryDirectory() as test_directory_name:
        test_directory_path = Path(test_directory_name)

        # Create two test directories
        test_dir_one = test_directory_path / 'test_dir_one'
        os.mkdir(test_dir_one)

        test_dir_two = test_dir_one / 'test_dir_two'
        os.mkdir(test_dir_two)

        # Create three test files
        test_file_one = test_dir_one / 'test_file_one'
        test_file_one.touch()

        test_file_two = test_dir_two / 'test_file_two'
        test_file_two.touch()


# Generated at 2022-06-23 18:18:55.992281
# Unit test for function path_absent
def test_path_absent():
    path_absent('~/tmp/foo')
    path_absent('~/tmp/bar')
    path_absent('~/tmp/baz')
    assert list(os.scandir('~/tmp')) == []
    path_absent('~/tmp')
    assert os.path.isdir('~/tmp') is False



# Generated at 2022-06-23 18:19:06.298680
# Unit test for function normalize_path
def test_normalize_path():
    # Testing normalize_path with int
    path = normalize_path(1)
    assert path == Path('1')
    assert path.is_absolute()
    # Testing normalize_path with float
    path = normalize_path(1.0)
    assert path == Path('1.0')
    assert path.is_absolute()
    # Testing normalize_path with str
    path = normalize_path('~/tmp/foo/../bar')
    if sys.platform.startswith('win'):
        assert path == Path('C:\\Users\\len\\tmp\\bar')
    else:
        assert path == Path('/Users/len/tmp/bar')
    assert path.is_absolute()
    # Testing normalize_path with bytes

# Generated at 2022-06-23 18:19:07.288993
# Unit test for function chmod
def test_chmod():
    assert chmod == 'chmod'



# Generated at 2022-06-23 18:19:14.697150
# Unit test for function path_absent
def test_path_absent():
    path_str = os.path.join(os.getcwd(), 'tmp_foo')
    path_absent(path_str)
    assert os.path.exists(path_str) is False
    path = os.path.join(os.getcwd(), 'tmp')
    os.mkdir(path)

# Generated at 2022-06-23 18:19:25.375768
# Unit test for function chmod
def test_chmod():
    """Test the behavior of ``chmod``.
    """
    path1 = Path('/tmp') / 'test_chmod' / 'path1'
    path1.mkdir(parents=True, exist_ok=True)
    Path(path1 / 'path2').mkdir(parents=True, exist_ok=True)
    Path(path1 / 'path2' / 'path3.txt').touch()
    Path(path1 / 'path2' / 'path4.txt').touch()


# Generated at 2022-06-23 18:19:26.300310
# Unit test for function chown
def test_chown():
    assert False

# Generated at 2022-06-23 18:19:31.167523
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~')
    assert os.path.isabs(path.as_posix()) is True
    assert path == Path(os.path.expanduser('~'))



# Generated at 2022-06-23 18:19:42.669425
# Unit test for function path_absent
def test_path_absent():
    import pytest
    from tempfile import TemporaryDirectory
    # Setup temp dir
    tmp_dir = TemporaryDirectory()
    tmp_dir_path = Path(tmp_dir.name)
    tmp_dir_path.mkdir()
    # Create test files/dirs
    tmp_dir_path.joinpath('file_one').touch()
    tmp_dir_path.joinpath('dir_one').mkdir()
    tmp_dir_path.joinpath('dir_one', 'file_two').touch()
    tmp_dir_path.joinpath('dir_one', 'dir_two').mkdir()
    tmp_dir_path.joinpath('dir_one', 'dir_two', 'file_three').touch()
    tmp_dir_path.joinpath('dir_one', 'dir_two', 'file_four').touch()
   

# Generated at 2022-06-23 18:19:52.926801
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    tmp_fn = os.path.join('tmp', 'flutils.tests.test_directory_present.txt')
    dir_path = directory_present(tmp_fn)
    assert dir_path.is_dir() is True
    for parent in dir_path.parents:
        assert parent.is_dir() is True
    os.remove(tmp_fn)
    for parent in dir_path.parents:
        os.rmdir(parent.as_posix())

# Generated at 2022-06-23 18:19:54.326899
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/foo/../bar'
    assert normalize_path(path) == Path('%s/tmp/bar' % get_home_dir())



# Generated at 2022-06-23 18:20:02.301444
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    try:
        user = get_os_user('-1')
    except OSError as err:
        assert 'is not a valid "login name"' in str(err)
    else:
        assert user.pw_name == 'nobody'
    try:
        user = get_os_user(100)
    except OSError as err:
        assert 'is not a valid uid' in str(err)



# Generated at 2022-06-23 18:20:09.598770
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for the function ``get_os_user``."""
    import os
    import pwd

    if os.getuid() != 0:
        with pytest.raises(OSError):
            get_os_user('__this_user_does_not_exist')
        pw_obj = get_os_user()
        assert isinstance(pw_obj, pwd.struct_passwd)
        assert pw_obj.pw_uid == os.getuid()
    else:
        with pytest.raises(OSError):
            get_os_user(0)



# Generated at 2022-06-23 18:20:12.414874
# Unit test for function get_os_user
def test_get_os_user():
    foo = pwd.getpwnam('foo')
    assert get_os_user('foo') == foo
    assert get_os_user(foo.pw_uid) == foo
    assert get_os_user() == foo



# Generated at 2022-06-23 18:20:16.607523
# Unit test for function chown
def test_chown():
    from .testing import assert_function

    _result = assert_function(
        chown,
        path='~/tmp',
        user=getpass.getuser(),
        group=grp.getgrgid(os.getgid()).gr_name
    )

    # Set the test result so it can be used in test reports
    globals()['__test_result'] = _result



# Generated at 2022-06-23 18:20:17.215522
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:20:30.701151
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import random
    import shutil

    d = tempfile.mkdtemp()
    sys.path.append(d)
    f1 = os.path.join(d, 'f1')
    f2 = os.path.join(d, 'f2')
    l1 = os.path.join(d, 'l1')
    l2 = os.path.join(d, 'l2')
    l3 = os.path.join(d, 'l3')
    d2 = os.path.join(d, 'd2')
    d3 = os.path.join(d, 'd3')
    f3 = os.path.join(d2, 'f3')
    f4 = os.path.join(d2, 'f4')
    l4 = os.path.join

# Generated at 2022-06-23 18:20:39.351333
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as temp_dir, \
            tempfile.TemporaryDirectory() as tmp, \
            tempfile.TemporaryDirectory() as tmp2:
        tmp = Path(tmp)
        tmp2 = Path(tmp2)
        temp = Path(temp_dir)

        tmp_dir = tmp / 'dir'
        tmp_dir.mkdir()
        tmp_dir2 = tmp / 'dir2'
        tmp_dir2.mkdir()
        file1 = tmp / 'file1'
        file1.touch()
        file2 = tmp / 'file2'
        tmp_dir2 /= 'file2'
        file2.touch()
        sym_link = tmp / 'sym_link'
        sym_link.symlink_to(file1)

# Generated at 2022-06-23 18:20:47.883058
# Unit test for function get_os_group
def test_get_os_group():
    """Get an operating system group object."""
    # gid = 2001
    # name = 'bar'
    user = cast(passwd.struct_passwd, get_os_user())
    get_os_group(name=user.pw_gid)
    get_os_group(name=user.pw_name)
    get_os_group(name='bar')
    get_os_group(name='foo')
    get_os_group(name='barfoo')



# Generated at 2022-06-23 18:20:54.855477
# Unit test for function path_absent
def test_path_absent():
    path_parent = Path('~/tmp/testing/was_deleted')
    path_parent.mkdir(parents=True, exist_ok=True)
    path_child = path_parent / 'path_was_deleted'
    path_child.touch()
    path_absent(path_parent)
    assert not path_parent.exists()
    assert not path_child.exists()



# Generated at 2022-06-23 18:21:02.934306
# Unit test for function find_paths
def test_find_paths():
    """Test flutils.pathutils.find_paths()"""
    cwd = os.getcwd()
    base_dir = Path(cwd) / 'flutils/tests/pathutils_test_dir'
    if not base_dir.exists():
        base_dir.mkdir(parents=True)

    file_one = base_dir / 'file_one'
    if not file_one.exists():
        file_one.touch()

    dir_one = base_dir / 'dir_one'
    if not dir_one.exists():
        dir_one.mkdir()

    file_two = base_dir / 'dir_one/file_two'
    if not file_two.exists():
        file_two.touch()


# Generated at 2022-06-23 18:21:05.315225
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group(name='bar').gr_gid == 2001
    assert get_os_group(name='bar').gr_name == 'bar'
    assert get_os_group(name='bar').gr_mem == ['foo']
    assert get_os_group(name='bar').gr_passwd == '*'



# Generated at 2022-06-23 18:21:11.122107
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(name=None).pw_name == getpass.getuser()
    assert get_os_user(name=get_os_user().pw_uid).pw_uid == get_os_user().pw_uid
    assert get_os_user(name=get_os_user().pw_name).pw_name == get_os_user().pw_name



# Generated at 2022-06-23 18:21:18.489461
# Unit test for function get_os_user
def test_get_os_user():
    """Functional style unit test to validate the output of the
    get_os_user function.
    """
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(-1) == pwd.getpwuid(-1)
    assert get_os_user(0) == pwd.getpwuid(0)
    assert get_os_user(1) == pwd.getpwuid(1)
    assert get_os_user('-1') == pwd.getpwuid(-1)
    assert get_os_user('0') == pwd.getpwuid(0)
    assert get_os_user('1') == pwd.getpwuid(1)
    assert get_os_user('root') == pwd.getpwn

# Generated at 2022-06-23 18:21:27.498579
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/bin') == 'directory'
    assert exists_as('/boot') == 'directory'
    assert exists_as('/sbin') == 'directory'
    assert exists_as('/lib') == 'directory'
    assert exists_as('/lib64') == 'directory'
    assert exists_as('/proc') == 'directory'

    with pytest.raises(FileNotFoundError):
        exists_as('/foo/bar/foobar') == ''
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/services') == 'file'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as

# Generated at 2022-06-23 18:21:40.143536
# Unit test for function normalize_path
def test_normalize_path():
    # pylint: disable=C0103,W0621
    import os
    import shlex
    import subprocess
    import sys
    import tempfile

    test_path = Path(os.path.expanduser('~/Documents/test_path'))
    test_dir = tempfile.TemporaryDirectory()
    test_dir_path = Path(test_dir.name)

    # Test PosixPath
    result = normalize_path(test_path.as_posix())
    assert isinstance(result, PosixPath)

    # Test WindowsPath
    result = normalize_path(test_path.as_windows())
    assert isinstance(result, WindowsPath)

    # Test str
    result = normalize_path(test_path.as_posix())
    assert isinstance(result, PosixPath)



# Generated at 2022-06-23 18:21:49.424869
# Unit test for function find_paths
def test_find_paths():
    """
    Test for find_paths

    Raises:
        AssertionError: if the test does not pass.

    """
    def setup():
        # Set up some test paths
        Path('/tmp/find_paths_tests').mkdir()
        Path('/tmp/find_paths_tests/file_one').touch()
        Path('/tmp/find_paths_tests/file_two').touch()
        Path('/tmp/find_paths_tests/file_three').touch()
        Path('/tmp/find_paths_tests/file_four').touch()

        # Set up some test directories
        Path('/tmp/find_paths_tests/dir_one').mkdir()
        Path('/tmp/find_paths_tests/dir_one/file_one_a').touch()
       

# Generated at 2022-06-23 18:21:54.356125
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as root:
        # Create a directory and file
        path = normalize_path(root) / 'tmp'
        directory_present(path)
        path = path / 'file_one'
        path.touch()

        # Create a symlink
        link = normalize_path(root) / 'link'
        path.symlink_to(link)

        # Create another symlink inside a directory.
        link = normalize_path(root) / 'tmp/link'
        path.symlink_to(link)

        # Create a sub directory and a file.
        path = normalize_path(root) / 'tmp/sub'
        directory_present(path)
        path = path / 'file_two'
        path.touch()

        # Create a sy

# Generated at 2022-06-23 18:21:56.914053
# Unit test for function get_os_group
def test_get_os_group():
    try:
        get_os_group(name='bar')
    except OSError:
        pass
    except Exception as ex:
        raise ex
    else:
        pass


# Generated at 2022-06-23 18:22:10.635845
# Unit test for function path_absent
def test_path_absent():
    import os
    import shutil
    from . import dirname_
    from . import path_exists_

    assert path_exists_('', False) is False

    # Assert path does not exist.
    assert path_exists_('~/tmp/foo', False) is False

    # Create a file and ensure it exists.
    open('~/tmp/foo/bar', 'w').close()
    assert path_exists_('~/tmp/foo/bar', True) is True

    # Create a directory and ensure it exists.
    os.mkdir('~/tmp/foo/dir_foo')
    assert path_exists_('~/tmp/foo/dir_foo', False) is True

    # Create a symbolic link to a file and ensure it exists.

# Generated at 2022-06-23 18:22:20.007313
# Unit test for function normalize_path
def test_normalize_path():
    def test(path, expected):
        assert normalize_path(path).as_posix() == expected
    test('/foo/bar/baz', '/foo/bar/baz')
    test(Path('/foo/bar/baz'), '/foo/bar/baz')
    if os.name == 'nt':
        test('c:\\foo\\bar\\baz', 'c:\\foo\\bar\\baz')
        test('c:/foo/bar/baz', 'c:\\foo\\bar\\baz')
        test('\\\\foo\\bar\\baz', '\\\\foo\\bar\\baz')
    test('/foo/bar/../baz', '/foo/baz')
    test('/foo/bar/../../baz', '/baz')

# Generated at 2022-06-23 18:22:30.059261
# Unit test for function exists_as
def test_exists_as():
    # Setup: Create a temp directory to work in.
    tmp_dir = Path(tempfile.mkdtemp())
    tmp_dir.chmod(0o770)
    tmp_dir.chown(get_login_name(), get_current_group())

    # Setup: Create a file.
    file_path = tmp_dir.joinpath('tmp_path.txt')
    file_path.touch()
    file_path.chmod(0o660)
    file_path.chown(get_login_name(), get_current_group())

    # Setup: Create a directory.
    dir_path = tmp_dir.joinpath('tmp_path_a')
    dir_path.mkdir()
    dir_path.chmod(0o770)

# Generated at 2022-06-23 18:22:35.443680
# Unit test for function exists_as
def test_exists_as():
    tmp_path = Path('~/tmp/ftests_pathutils_exists_as').expanduser()
    assert exists_as(tmp_path) == ''
    tmp_path.mkdir()
    assert exists_as(tmp_path) == 'directory'
    test_file = tmp_path / 'ftests_pathutils_exists_as.txt'
    test_file.touch()
    assert exists_as(test_file) == 'file'



# Generated at 2022-06-23 18:22:46.120032
# Unit test for function get_os_group
def test_get_os_group():
    # Assert function get_os_group returns the expected results
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo'])
    assert get_os_group('baz') == grp.struct_group(
        gr_name='baz', gr_passwd='*', gr_gid=2002, gr_mem=['foo', 'bar'])
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[])
    assert get_os_group('foobar') is None
    # Assert function get_os_group raises the expected errors

# Generated at 2022-06-23 18:22:50.642952
# Unit test for function normalize_path
def test_normalize_path():
    cwd = os.getcwd()
    os.chdir('/tmp')

# Generated at 2022-06-23 18:22:52.304788
# Unit test for function get_os_group
def test_get_os_group():
    assert grp.struct_group == get_os_group().__class__



# Generated at 2022-06-23 18:22:59.767057
# Unit test for function get_os_user
def test_get_os_user():
    kwargs = {
        'name': 'foo'
    }
    name = get_os_user(**kwargs)
    assert hasattr(name, 'pw_name')
    assert hasattr(name, 'pw_passwd')
    assert hasattr(name, 'pw_uid')
    assert hasattr(name, 'pw_gid')
    assert hasattr(name, 'pw_gecos')
    assert hasattr(name, 'pw_dir')
    assert hasattr(name, 'pw_shell')



# Generated at 2022-06-23 18:23:08.596227
# Unit test for function chmod
def test_chmod():
    import tempfile
    from flutils.pathutils import chmod

    with tempfile.TemporaryDirectory() as tmp_dir:
        # TemporaryDirectory returns a pathlib.Path
        tmp_dir = Path(tmp_dir)
        file_path = tmp_dir / 'flutils.tests.osutils.txt'

        # The mode of the file should be 0o600
        file_path.write_text('Hello World')
        assert file_path.stat().st_mode == 33152

        # Change the mode of the file
        chmod(file_path, mode_file=0o660)
        assert file_path.stat().st_mode == 33208

        # Change the mode of the file in the temporary directory
        chmod(tmp_dir / '*.txt', mode_file=0o666)

# Generated at 2022-06-23 18:23:21.451435
# Unit test for function chmod
def test_chmod():
    """Test the chmod function."""

    from pathlib import Path
    import os

    path = Path('/tmp/flutils/chmod')
    path.mkdir(parents=True)

    chmod(path.as_posix(), include_parent=True)

    # Check the mode of the dir that was chmod'ed.
    assert os.stat(path).st_mode & 0o777 == 0o700

    # Check the mode of the parent dir that was chmod'ed.
    assert os.stat(path.parent).st_mode & 0o777 == 0o700

    # Remove the created directory.
    path.rmdir()

    # This path doesn't exist.  Make sure nothing happens.
    chmod('/tmp/does/not/exist')

    assert True is True



# Generated at 2022-06-23 18:23:29.119561
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory
    from tempfile import NamedTemporaryFile
    import shutil
    from pathlib import Path
    from flutils.pathutils import path_absent

    with TemporaryDirectory() as td:
        tmp_dir = Path(td)
        tmp_dir.mkdir()

        f = NamedTemporaryFile(dir=td)
        f.close()
        file_path = Path(f.name)
        assert file_path.is_file() is True

        link = Path(os.path.join(td, 'test_link'))
        os.symlink(f.name, link.as_posix())
        assert link.is_symlink() is True

        path_absent(file_path)
        assert file_path.is_file() is False

        path_absent(link)

# Generated at 2022-06-23 18:23:29.782666
# Unit test for function chown
def test_chown():
    return



# Generated at 2022-06-23 18:23:42.016749
# Unit test for function chown
def test_chown():
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(
            tmp_dir, 'foo', 'bar', 'baz', 'qux')
        os.makedirs(path, exist_ok=True)
        path = PosixPath(path)

        # https://docs.python.org/3/library/pwd.html#pwd.struct_passwd
        group_name = pwd.getpwuid(os.getuid()).pw_name
        group_id = pwd.getpwuid(os.getuid()).pw_gid

        # https://docs.python.org/3/library/grp.html#grp.struct_group
        user_name = grp.getgrgid(os.getgid()).gr_name
        user

# Generated at 2022-06-23 18:23:51.426909
# Unit test for function get_os_user
def test_get_os_user():
    def get_os_user_mock(name: _STR_OR_INT_OR_NONE = None) -> pwd.struct_passwd:
        return pwd.struct_passwd(pw_name='foo', pw_passwd='********', pw_uid=1001,
        pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo',
        pw_shell='/usr/local/bin/bash')

    with patch('flutils.pathutils.get_os_user', new_callable=get_os_user_mock):
        get_os_user_mock = get_os_user()
        assert get_os_user_mock.pw_name == 'foo'


# Generated at 2022-06-23 18:23:54.926374
# Unit test for function directory_present
def test_directory_present():
    path = directory_present(Path(__file__).parent / "directory_present")
    assert path.exists() is True



# Generated at 2022-06-23 18:24:05.576827
# Unit test for function normalize_path
def test_normalize_path():
    """Test that normalize_path() functions as expected."""
    assert str(normalize_path('~')) == os.path.expanduser('~')
    assert str(normalize_path('~/tmp')) == os.path.join(
        os.path.expanduser('~'), 'tmp'
    )
    assert str(normalize_path('~/tmp/a/..')) == os.path.join(
        os.path.expanduser('~'), 'tmp'
    )
    assert str(normalize_path('/tmp/a/../b')) == '/tmp/b'
    assert str(normalize_path('tmp/a/../b')) == os.path.abspath('tmp/b')

# Generated at 2022-06-23 18:24:11.809805
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function.
    """
    # Test the normalize_path function.
    import unittest
    from os import getcwd
    from os.path import expanduser, isabs, join
    from pathlib import Path
    from typing import Dict
    from unittest.mock import patch
    from ..pathutils.base import normalize_path

    class NormalizePathTests(unittest.TestCase):
        """Tests the normalize_path function."""

        def setUp(self) -> None:
            """Set up test variables."""

# Generated at 2022-06-23 18:24:15.327230
# Unit test for function find_paths
def test_find_paths():
    """Test function :obj:`find_paths`."""
    import tests.osutils
    pattern = Path(tests.osutils.__file__).parent / '*.txt'
    assert list(find_paths(pattern))



# Generated at 2022-06-23 18:24:16.976788
# Unit test for function chown
def test_chown():
    return {
        'chmod': chmod,
        'chown': chown
    }



# Generated at 2022-06-23 18:24:22.711253
# Unit test for function chown
def test_chown():
    if os.name != 'nt':
        import pwd
        import grp
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            chown(td)
            assert pwd.getpwuid(os.stat(td).st_uid).pw_name == getpass.getuser()
            assert grp.getgrgid(os.stat(td).st_gid).gr_name == pwd.getpwuid(os.getuid()).pw_name
# end test_chown
test_chown()



# Generated at 2022-06-23 18:24:34.098664
# Unit test for function find_paths
def test_find_paths():
    # Tests where the pattern is relative.
    test_path = './flutils'
    result = list(find_paths(test_path))
    assert (
        result
        ==
        [
            Path('./flutils/pathutils/__init__.py'),
            Path('./flutils/pathutils/flutils.py')
        ]
    )

    # Tests where the pattern is relative, contains a glob pattern and
    # is the only match for the pattern in the current path.
    test_path = './file_one*'
    result = list(find_paths(test_path))
    assert (
        result
        ==
        [
            Path('./file_one')
        ]
    )

    # Tests where the pattern is relative, contains a glob pattern and
    # is a match to more

# Generated at 2022-06-23 18:24:40.689183
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert pwd.getpwuid(pwd.getuid()) == user
    assert get_os_user(user.pw_name) == user
    assert get_os_user(user.pw_uid) == user



# Generated at 2022-06-23 18:24:49.295968
# Unit test for function normalize_path
def test_normalize_path():
    from pathlib import PosixPath, WindowsPath
    from tempfile import TemporaryDirectory
    from .. import get_os_user, get_os_group

    def get_pathobj(
            usr: Optional[str] = None, grp: Optional[str] = None
    ) -> Path:
        """Return a unique path."""
        if usr is None:
            usr = get_os_user().pw_name
        if grp is None:
            grp = get_os_group().gr_name

        with TemporaryDirectory() as tmpdir:
            while True:
                path = os.path.join(tmpdir, usr, grp)
                if not os.path.exists(path):
                    break
        return Path(path)


# Generated at 2022-06-23 18:24:55.621698
# Unit test for function get_os_group
def test_get_os_group():
    """Unit tests for function get_os_group."""
    from flutils.pathutils import get_os_group
    assert get_os_group().gr_name == 'nogroup'
    assert get_os_group('root').gr_name == 'root'



# Generated at 2022-06-23 18:24:56.959847
# Unit test for function exists_as
def test_exists_as():
    normalize_path()
    return exists_as('~/tmp')



# Generated at 2022-06-23 18:25:07.089563
# Unit test for function find_paths
def test_find_paths():
    """Test for function find_paths."""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tests.common import USER_HOME
    from unittest.mock import patch

    with patch('os.getcwd', return_value=USER_HOME):
        gen = find_paths('~/tmp/**')
        assert type(gen) == GeneratorType

        paths = list(gen)
        assert paths == [Path('/home/test_user/tmp/file_one'), Path('/home/test_user/tmp/dir_one')]



# Generated at 2022-06-23 18:25:12.262261
# Unit test for function path_absent
def test_path_absent():
    with TemporaryDirectory() as d:
        path = Path(d) / 'test_path'
        path.mkdir()
        assert path.exists()
        path_absent(d)
        assert path.exists() is False



# Generated at 2022-06-23 18:25:24.614150
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import normalize_path
    from flutils.pathutils import touch_path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import find_paths
    from flutils.osutils import get_os_user
    from flutils.osutils import get_os_group

    # Change the permissions on the test directory so that it can be created.
    test_dir = normalize_path('~/tmp/tests/pathutils/find_paths')
    chmod(str(test_dir.parent))

    # Create directories and files
    touch_path(str(test_dir.joinpath('file_one')))
    touch_path(str(test_dir.joinpath('file_two')))

# Generated at 2022-06-23 18:25:26.702768
# Unit test for function get_os_group
def test_get_os_group():
    try:
        assert get_os_group() is not None
    except OSError:
        pass



# Generated at 2022-06-23 18:25:37.528308
# Unit test for function directory_present
def test_directory_present():
    tmp_path = Path(os.path.abspath(os.path.join(__file__, '..', 'tmp')))
    file_mode = 0o666
    file_path = tmp_path / 'flutils.pathutils.txt'
    dir_mode = 0o777
    dir_path = tmp_path / 'flutils.pathutils'
    dir_path = directory_present(dir_path, mode=dir_mode)
    file_path = directory_present(file_path, mode=file_mode)
    assert dir_path.stat().st_mode == 16895
    assert file_path.stat().st_mode == 33279
    file_path.unlink()
    dir_path.rmdir()



# Generated at 2022-06-23 18:25:40.374141
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('/tmp/flutils.tests.pathutils.directory.present.txt')
    assert path == Path('/tmp/flutils.tests.pathutils.directory.present.txt')



# Generated at 2022-06-23 18:25:48.640619
# Unit test for function get_os_group
def test_get_os_group():
    # Test an invalid gid.
    with pytest.raises(OSError) as excinfo:
        get_os_group(0xdeadbeef)
    assert excinfo.value.strerror == (
        'The given gid: 3735928559, is not a valid gid for this operating '
        'system.'
    )
    # Test an invalid name.
    with pytest.raises(OSError) as excinfo:
        get_os_group(0x0badc0de)
    assert excinfo.value.strerror == (
        'The given name: 123456789, is not a valid "group name" '
        'for this operating system.'
    )
    # Test the get_os_user() fallback.
    assert get_os_group().gr_name == get_os_user

# Generated at 2022-06-23 18:26:00.255556
# Unit test for function find_paths
def test_find_paths():
    # Set up and tear down the temporary directory
    with tempdir() as dir_path:
        # Set up a set of files and directories.
        path_one = Path(dir_path, 'file_one').touch()
        path_two = Path(dir_path, 'file_two').touch()
        path_three = Path(dir_path, 'dir_one').mkdir()
        path_four = Path(dir_path, 'dir_two').mkdir()
        path_five = Path(path_four, 'file_three').touch()

        # Run the find_paths command that will find all the
        # files in the dir_path directory.  Then ensure
        # that it matches known results.
        paths = find_paths(dir_path)

# Generated at 2022-06-23 18:26:10.256331
# Unit test for function chown
def test_chown():
    os.chdir(os.path.dirname(__file__))  # cd to pathutils_test_dir
    # Test for chown on directory, subdirectory and files.
    chown(Path.cwd(), user='foo', group='bar')
    stats  = os.stat(Path.cwd())
    # Test to make sure directory is owned by foo:bar
    assert stats.st_uid == pwd.getpwnam('foo').pw_uid
    assert stats.st_gid == grp.getgrnam('bar').gr_gid
    # Change ownership of files in subdirectory.
    chown(os.path.join(Path.cwd(), 'sub_dir', '*'))
    files = os.listdir(os.path.join(Path.cwd(), 'sub_dir'))

# Generated at 2022-06-23 18:26:22.550873
# Unit test for function chmod
def test_chmod():
    from .pathutils import directory_present, path_absent

    with directory_present('tmp'):
        with directory_present('tmp/foo/bar'):
            with directory_present('tmp/foo/bar/baz'):
                with directory_present('tmp/foo/bar/baz/bin'):
                    with directory_present('tmp/foo/bar/baz/qux'):
                        # Directory
                        with open('tmp/foo/bar/baz/qux/foobar.txt', 'w') as f:
                            f.write('hello world')

                        # Non-directory file
                        with open('tmp/foo/bar/baz/qux/foobar.txt', 'w') as f:
                            f.write('hello world')


# Generated at 2022-06-23 18:26:23.820086
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-23 18:26:33.616814
# Unit test for function get_os_user
def test_get_os_user():
    def _mock_pwd_getpwnam(name: str) -> pwd.struct_passwd:
        return namedtuple('struct_passwd',
                          ['pw_uid', 'pw_name', 'pw_passwd',
                           'pw_gid', 'pw_gecos', 'pw_dir', 'pw_shell'
                          ])(1001, name, '********', 2001, 'Foo Bar',
                            '/home/foo', '/usr/local/bin/bash')
