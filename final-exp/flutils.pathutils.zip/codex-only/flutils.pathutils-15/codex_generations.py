

# Generated at 2022-06-23 18:16:43.394309
# Unit test for function chown
def test_chown():
    if os.name=='posix':
        user=getpass.getuser()
        group=grp.getgrgid(os.getgid()).gr_name
        chown('/etc/passwd')
        assert isinstance(os.stat('/etc/passwd').st_uid, int)
        assert isinstance(os.stat('/etc/passwd').st_gid, int)
        assert (os.stat('/etc/passwd').st_uid==pwd.getpwnam(user).pw_uid)
        assert (os.stat('/etc/passwd').st_gid==grp.getgrnam(group).gr_gid)
        chown('/etc/passwd', user=user)

# Generated at 2022-06-23 18:16:48.608091
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt')
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')



# Generated at 2022-06-23 18:16:55.989002
# Unit test for function path_absent
def test_path_absent():  # noqa: D103
    with TemporaryDirectory() as tmp_dir:
        path = Path(tmp_dir) / 'test_path'
        path_absent(tmp_dir / 'test_path')
        path.mkdir()
        path_absent(tmp_dir / 'test_path')
        path.write_text('test file')
        path_absent(tmp_dir / 'test_path')
        path.mkdir()
        path / 'sub_path'.mkdir()
        path_absent(tmp_dir / 'test_path')
        (path / 'sub_path' / 'sub_sub_path').write_text('test file 2')
        path_absent(tmp_dir / 'test_path')



# Generated at 2022-06-23 18:17:01.722370
# Unit test for function chmod
def test_chmod():
    import os
    import pathlib
    import shutil
    import tempfile
    import time

    from flutils.pathutils import chmod

    # Test: Simple
    tmp_dir = tempfile.mkdtemp()
    tmp_file = pathlib.Path(os.path.join(tmp_dir, 'flutils.tests.osutils.txt'))
    tmp_file.touch()
    assert tmp_file.stat().st_mode & 0o777 == 0o666

    chmod(tmp_file, 0o660)
    assert tmp_file.stat().st_mode & 0o777 == 0o660

    shutil.rmtree(tmp_dir)

    # Test: Recursive
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:17:13.287509
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'tmp'
    path.mkdir(0o755, parents=True, exist_ok=True)

    for filename in ('a.txt', 'b.txt', 'c.txt'):
        fpath = path / filename
        if fpath.exists() is False:
            fpath.touch()
            fpath.chmod(0o600)

    chown(str(path), user='foo', group='bar')

    for filename in ('a.txt', 'b.txt', 'c.txt'):
        fpath = path / filename
        assert cast(PosixPath, fpath).stat().st_uid == get_os_user('foo').pw_uid
        assert cast(PosixPath, fpath).stat().st_gid == get_os_group('bar').gr

# Generated at 2022-06-23 18:17:18.096092
# Unit test for function get_os_user
def test_get_os_user():
    """

    """
    assert get_os_user(None) == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getlogin()) == pwd.getpwnam(os.getlogin())



# Generated at 2022-06-23 18:17:20.614336
# Unit test for function path_absent
def test_path_absent():
    with path_absent('~/tmp/test_path'):
        mkdir('~/tmp/test_path')
        assert os.path.exists('~/tmp/test_path') is True
    assert os.path.exists('~/tmp/test_path') is False



# Generated at 2022-06-23 18:17:21.869984
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_name == 'root'



# Generated at 2022-06-23 18:17:33.484859
# Unit test for function normalize_path
def test_normalize_path():
    '''Unit test for function normalize_path'''
    path = '~/tmp/foo/../bar'
    test_path = normalize_path(path)
    home_path = os.path.expanduser('~')
    assert str(test_path) == os.path.join(home_path, 'tmp', 'bar')
    path = '~/tmp/../foo/../bar'
    test_path = normalize_path(path)
    home_path = os.path.expanduser('~')
    assert str(test_path) == os.path.join(home_path, 'bar')
normalize_path.register(bytes, lambda path: normalize_path(str(path)))

# Generated at 2022-06-23 18:17:34.382821
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)


# Generated at 2022-06-23 18:17:44.681930
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import exists_as, path_absent

    path_str = os.path.join('/tmp', 'pathutils_test')

    path: Path
    path0 = Path(path_str)
    assert exists_as(path0) == ''
    path_absent(path0)
    path0.mkdir()
    assert exists_as(path0) == 'directory'
    path_absent(path0)

    path1 = Path(os.path.join(path_str, 'test1'))
    assert exists_as(path1) == ''
    path1.mkdir()
    assert exists_as(path1) == 'directory'
    path_absent(path1)

    path2 = Path(os.path.join(path_str, 'test2'))
    assert exists

# Generated at 2022-06-23 18:17:45.568591
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path(__file__)) == 'file'



# Generated at 2022-06-23 18:17:47.563684
# Unit test for function chown
def test_chown():

    chown('/var/tmp/flutils.tests.osutils.txt', group='nobody')



# Generated at 2022-06-23 18:18:00.444966
# Unit test for function directory_present
def test_directory_present():
    """Test flutils.pathutils.directory_present()."""
    import tempfile
    import pytest
    import glob
    import shutil
    import os
    import os.path

    from flutils.pathutils import directory_present

    tempdir = tempfile.mkdtemp()

    path = os.path.join(tempdir, 'tests', 'flutils', 'directory_present')
    os.makedirs(path)


# Generated at 2022-06-23 18:18:05.760488
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user('foo'), pwd.struct_passwd)
    assert isinstance(get_os_user(1001), pwd.struct_passwd)


# Generated at 2022-06-23 18:18:16.974164
# Unit test for function get_os_user
def test_get_os_user():
    """Unit tests for the get_os_user function."""
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.pathutils import get_os_user

    # Test for function get_os_user with all default arguments
    class TestGetOSUserDefaultArgs(TestCase):
        """Unit tests for the get_os_user function with all default arguments."""
        @patch('flutils.pathutils.getpass.getuser')
        @patch('flutils.pathutils.pwd.getpwnam')
        def test_function(self, mocked_getpwnam, mocked_getuser):
            """Test the function."""
            mocked_getuser.return_value = None
            mocked_getpwnam.return_value = None
            get_os_user()
            mocked_get

# Generated at 2022-06-23 18:18:28.742473
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path

    assert normalize_path('~') == Path('/home/test_user')
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')

    os.environ['FOO'] = '/home/test_user'
    assert normalize_path('${FOO}') == Path('/home/test_user')
    assert normalize_path('${FOO}/tmp') == Path('/home/test_user/tmp')
    del os.environ['FOO']

    assert normalize_path('.') == Path(os.getcwd())
    assert normalize_path('./') == Path(os.getcwd() + '/')

# Generated at 2022-06-23 18:18:33.173279
# Unit test for function directory_present
def test_directory_present():
    """Assert the behavior of the directory_present function."""
    p = directory_present('/tmp/flutils.tests.pathutils/test_directory_present')
    assert p.as_posix() == '/tmp/flutils.tests.pathutils/test_directory_present'
    assert p.exists() is True
    assert p.is_dir() is True



# Generated at 2022-06-23 18:18:43.879161
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('/tmp/flutils.tests.pathutils.directory_present')

    # Check for recursive creation of directory structure.
    path = directory_present(['/tmp', 'flutils', 'tests', 'pathutils', 'directory_present'])
    assert str(path) == '/tmp/flutils/tests/pathutils/directory_present'

    # Test error on path that exists and is NOT a directory.
    with open(path.as_posix(), 'w', encoding='utf-8') as fp:
        fp.write('This is a file')

    with pytest.raises(FileExistsError) as excinfo:
        directory_present('/tmp/flutils.tests.pathutils.directory_present')


# Generated at 2022-06-23 18:18:53.586301
# Unit test for function chmod
def test_chmod():
    from io import StringIO
    from os.path import join, exists
    from pathlib import Path
    from sys import stderr
    from tempfile import mkdtemp
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.pathutils import chmod

    class _FakeStderr(StringIO):
        def flush(self) -> None:
            pass

    class ChmodTestCase(TestCase):
        def setUp(self) -> None:
            self.path = mkdtemp(prefix='flutils_')

        def tearDown(self) -> None:
            if exists(self.path) is True:
                try:
                    Path(self.path).rmdir()
                except OSError:
                    pass


# Generated at 2022-06-23 18:19:01.696147
# Unit test for function directory_present
def test_directory_present():
    os.mkdir('tmp')
    directory_present('tmp/test_dir')
    os.chdir('tmp/test_dir')
    path = directory_present('test_dir2')
    assert path.as_posix() == '/Users/dun/tmp/test_dir/test_dir2'
    os.mkdir('../test_dir3')
    assert directory_present('../test_dir3')
    os.chdir('../')
    assert directory_present('./test_dir3')
    # Clean up created directories.
    os.chdir('..')
    shutil.rmtree('tmp')


# Generated at 2022-06-23 18:19:11.634711
# Unit test for function path_absent
def test_path_absent():
    path1 = Path('/tmp/flutils_pathutils_test').as_posix()
    if os.path.exists(path1):
        path_absent(path1)
    path_present(path1)
    path2 = os.path.join(path1, 'test1')
    path_present(path2)
    path3 = os.path.join(path2, 'test2')
    path_present(path3)
    path4 = os.path.join(path3, 'test3')
    path_present(path4)
    path_absent(path1)
    assert os.path.exists(path1) is False



# Generated at 2022-06-23 18:19:17.040766
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for get_os_user."""
    name = 'this_is_a_bad_name_that_should_not_exist'
    with pytest.raises(OSError) as exc_info:
        get_os_user(name)
    assert exc_info.match(
        'The given name: %r, is not a valid "login name" for this operating'
        ' system.' % name
    )
    bad_uid = 9999
    with pytest.raises(OSError) as exc_info:
        get_os_user(bad_uid)
    assert exc_info.match(
        'The given uid: %r, is not a valid uid for this operating system.'
        % bad_uid
    )

# Generated at 2022-06-23 18:19:22.779003
# Unit test for function path_absent
def test_path_absent():  # pylint: disable=redefined-outer-name; noqa: E302
    path = Path(tempfile.gettempdir()) / 'test_path'
    path_absent(path)
    assert not os.path.exists(path)
    path.mkdir(mode=0o700)
    path_absent(path)
    assert not os.path.exists(path)
    with open(path, 'w') as f:
        f.write('foo')
    path_absent(path)
    assert not os.path.exists(path)
    path = Path(tempfile.gettempdir()) / 'test_path'
    path.mkdir(mode=0o700)
    (path / 'foo').mkdir(mode=0o700)

# Generated at 2022-06-23 18:19:30.680560
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.path.expanduser("~")) == "directory"
    assert exists_as("/usr/share/dict/words") == "file"
    assert exists_as("/dev/null") == "block device"
    assert exists_as("/dev/tty") == "char device"
    assert exists_as("/var/run/httpd.pid") == "FIFO"
    assert exists_as("/var/run/mysqld/mysqld.sock") == "socket"
    assert exists_as("nonexistent") == ""



# Generated at 2022-06-23 18:19:41.681464
# Unit test for function directory_present
def test_directory_present():
    from . import utils
    from .osutils import _OS_NAME

    utils.init_test_paths()

    # Ensure directory does not already exist.
    try:
        utils.TEST_PATH_OBJ.rmdir()
    except FileNotFoundError:
        pass
    else:
        assert exists_as(utils.TEST_PATH_OBJ) == 'directory'

    # Create the test directory.
    test_path = directory_present(utils.TEST_PATH_OBJ)
    assert exists_as(utils.TEST_PATH_OBJ) == 'directory'

    # Test that a new directory gets the same attributes
    # as the parent created directory.
    sub_dir = test_path / 'sub_dir'
    sub_dir_path = directory_present(sub_dir)
   

# Generated at 2022-06-23 18:19:49.599015
# Unit test for function exists_as
def test_exists_as():
    """Ensure the function returns data as expected."""
    # pylint: disable=redefined-outer-name
    import os
    import random
    import shutil
    import time
    import tempfile

    assert exists_as('foo') == ''
    assert exists_as('~/foo') == ''

    fd, path1 = tempfile.mkstemp()
    os.close(fd)
    assert exists_as(path1) == 'file'
    try:
        os.remove(path1)
    except OSError:
        pass
    assert exists_as(path1) == ''

    dir_path = Path(tempfile.mkdtemp())
    sub_path = dir_path / 'test.txt'
    sub_path.touch()
    assert exists_as(sub_path) == 'file'

# Generated at 2022-06-23 18:19:52.048018
# Unit test for function exists_as
def test_exists_as():
    """Unit tests for function exists_as."""
    path = normalize_path('~/tmp')
    assert exists_as(path) == 'directory'



# Generated at 2022-06-23 18:19:58.698748
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        path = Path(tmpdir)
        path = path / 'test_path'
        path.touch()
        assert exists_as(path) == 'file'

        path = Path(tmpdir)
        path = path / 'test_path'
        path.mkdir()
        assert exists_as(path) == 'directory'

        path = Path(tmpdir)
        path = path / 'test_path'
        path.mkfifo()
        assert exists_as(path) == 'FIFO'

        path = Path(tmpdir)
        path.mkfifo()
        assert exists_as(path) == 'FIFO'

        path = Path(tmpdir)
        path.mkfifo

# Generated at 2022-06-23 18:20:06.399012
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from typing import List

    tmp_dir = Path(TemporaryDirectory().name)
    tmp_dir.mkdir()
    tmp_files: List[str] = [
        'file_one',
        'file_two',
        'file_three',
        'file_four',
        'file_five',
        'file_six',
        'file_seven',
        'file_eight',
        'file_nine',
        'file_ten'
    ]

# Generated at 2022-06-23 18:20:10.473899
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function ``exists_as``."""
    from flutils import pathutils
    assert pathutils.exists_as('~/tmp') == 'directory'
    assert pathutils.exists_as('~/tmp/foo') == ''
    assert pathutils.exists_as('/dev/stdin') == 'FIFO'



# Generated at 2022-06-23 18:20:13.311496
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    assert get_os_user()
    assert get_os_user('root')
    assert get_os_user('-1')
    assert get_os_user(0)


# Generated at 2022-06-23 18:20:16.394083
# Unit test for function get_os_group
def test_get_os_group():
    if six.PY3 is True and os.name == 'posix':
        from flutils.pathutils import get_os_group
        import __main__
        __main__.get_os_group = get_os_group
        import doctest
        doctest.testmod(verbose=True)


# Generated at 2022-06-23 18:20:29.502128
# Unit test for function get_os_user
def test_get_os_user():
    """Tests for function get_os_user."""
    if __debug__:
        user = get_os_user()
        assert isinstance(user.pw_name, str)
        assert isinstance(user.pw_passwd, str)
        assert isinstance(user.pw_uid, int)
        assert isinstance(user.pw_gid, int)
        assert isinstance(user.pw_gecos, str)
        assert isinstance(user.pw_dir, str)
        assert isinstance(user.pw_shell, str)
    if __debug__:
        user = get_os_user(1000)
        assert isinstance(user.pw_name, str)
        assert isinstance(user.pw_passwd, str)

# Generated at 2022-06-23 18:20:31.224779
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-23 18:20:39.591001
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/../path')
    assert path.as_posix() == '~/path'
    path = normalize_path(b'~/tmp/../bytes')
    assert path.as_posix() == '~/bytes'
    path = normalize_path('~/tmp/../$USER/test')
    assert path.as_posix() == '~/test'
    path = normalize_path('~/tmp/../')
    assert path.as_posix() == '~/'
    path = normalize_path('~/tmp/../..//')
    assert path.as_posix() == '~//'
    path = normalize_path('~/tmp/./../test')
    assert path.as_posix() == '~/test'

# Generated at 2022-06-23 18:20:52.025180
# Unit test for function chmod
def test_chmod():
    # import logging
    # logger = logging.getLogger(__name__)
    # logger.addHandler(logging.NullHandler())

    with tempfile.TemporaryDirectory() as tmpd:
        tmpd = Path(tmpd)
        os.chdir(tmpd)

        fp = tmpd / 'test.txt'
        Path('test.txt').touch()

        assert fp.stat().st_mode & 0o777 == 0o666

        chmod(fp, 0o660, include_parent=True)

        assert fp.stat().st_mode & 0o777 == 0o660
        assert tmpd.stat().st_mode & 0o777 == 0o755

        os.chmod(os.getcwd(), 0o777)
        chmod('test.txt', mode_dir=0o777)


# Generated at 2022-06-23 18:21:00.886129
# Unit test for function normalize_path
def test_normalize_path():
    path = '/'
    assert normalize_path(path).as_posix() == path
    path = '~/tmp'
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = normalize_path('~/tmp')
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = '~/tmp'
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = '~foo//bar/../baz'
    assert normalize_path(path).as_posix() == os.path.join(
        os.path.expanduser('~foo'), 'baz'
    )



# Generated at 2022-06-23 18:21:06.290770
# Unit test for function chmod
def test_chmod():
    path = Path() / 'tmp' / 'flutils.tests.osutils.txt'
    mode = 0o660
    try:
        chmod(path, mode_file=mode)
        assert path.exists() is True
        assert path.stat().st_mode & 0o777 == mode
    finally:
        path.unlink()



# Generated at 2022-06-23 18:21:08.200169
# Unit test for function chmod
def test_chmod():
    pass
# End unit test for function chmod



# Generated at 2022-06-23 18:21:08.706155
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:21:13.708355
# Unit test for function path_absent
def test_path_absent():
    # pylint: disable=missing-function-docstring
    p: Path = Path(TMP_DIR.as_posix(), 'path_absent')
    # Make sure the path does not exist before we begin.
    path_absent(p)
    # Remove a non-existing path should not fail.
    path_absent(p)
    p.mkdir(mode=0o700)
    assert p.exists() is True
    assert p.is_dir() is True
    # Remove an existing directory.
    path_absent(p)
    assert p.exists() is False

    p.mkdir(mode=0o700)
    assert p.exists() is True
    assert p.is_dir() is True


# Generated at 2022-06-23 18:21:24.175907
# Unit test for function chmod
def test_chmod():
    """Test :func:`flutils.pathutils.chmod` succeeds."""
    import tempfile

    tmp_dir = Path(tempfile.mkdtemp())

    txt_path = tmp_dir.joinpath('flutils.tests.osutils.txt')
    txt_path.write_text('This is a test file.')
    txt_path.chmod(0o600)
    assert txt_path.stat().st_mode & 0o777 == 0o600

    chmod(txt_path, 0o660)
    assert txt_path.stat().st_mode & 0o777 == 0o660

    chmod(txt_path, 0o600)
    assert txt_path.stat().st_mode & 0o777 == 0o600


# Generated at 2022-06-23 18:21:28.759954
# Unit test for function get_os_user
def test_get_os_user():
    pw = pwd.getpwnam(getpass.getuser())
    assert get_os_user() == pw
    assert get_os_user(getpass.getuser()) == pw
    assert get_os_user(pw.pw_uid) == pw
    with pytest.raises(OSError):
        get_os_user(pw.pw_uid + 1)
    with pytest.raises(OSError):
        get_os_user('test')



# Generated at 2022-06-23 18:21:41.559531
# Unit test for function exists_as
def test_exists_as():
    """Test the :obj:`~flutils.pathutils.exists_as` function."""
    from flutils.pathutils import exists_as  # noqa: F401
    from flutils.pathutils import normalize_path  # noqa: F401

    # Broken link
    assert exists_as(normalize_path('~/tmp/broken_link')) == ''

    # Directory
    assert exists_as(normalize_path('~/tmp')) == 'directory'

    # File
    assert exists_as(normalize_path('~/tmp/file')) == 'file'

    # Block device
    assert exists_as(normalize_path('/dev/disk0s2')) == 'block device'

    # Char device

# Generated at 2022-06-23 18:21:51.306329
# Unit test for function exists_as
def test_exists_as():
    from flutils.tests.utils.envutils import USER_TMPDIR
    tmppath = Path(USER_TMPDIR)
    testpath = tmppath / 'test_exists_as_directory'
    testpath.mkdir()
    assert exists_as(testpath) == 'directory'
    testpath.rmdir()
    testpath = tmppath / 'test_exists_as_file'
    testpath.touch()
    assert exists_as(testpath) == 'file'
    testpath.unlink()



# Generated at 2022-06-23 18:21:58.917870
# Unit test for function chmod
def test_chmod():
    from os import chmod as os_chmod
    from os.path import join
    from tempfile import gettempdir
    from shutil import rmtree

    from flutils.pathutils import chmod

    path = join(gettempdir(), 'flutils.test_pathutils.chmod')

# Generated at 2022-06-23 18:22:11.738015
# Unit test for function chmod
def test_chmod():
    from io import StringIO

    from flutils.miscutils import capture_output

    from tests.utils import (
        msg,
        mk_temp_file,
        mk_temp_dir,
    )

    def _assert(path):
        with capture_output() as (stdout, stderr):
            chmod(path)
            output = stdout.getvalue()

        assert not output
        assert not stderr.getvalue()
        assert path.stat().st_mode == 33279

    def _assert_dir(path):
        with capture_output() as (stdout, stderr):
            chmod(path, 0o755)
            output = stdout.getvalue()

        assert not output
        assert not stderr.getvalue()
        assert path.stat().st_mode == 16895


# Generated at 2022-06-23 18:22:14.585034
# Unit test for function get_os_user
def test_get_os_user():
    """
    Check that get_os_user returns a non-empty object.
    """
    assert get_os_user() != None


# Generated at 2022-06-23 18:22:17.951097
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-23 18:22:27.360385
# Unit test for function find_paths
def test_find_paths():
    if os.name == 'posix':
        expected = [
            PurePosixPath('/home/test_user/tmp/file_one'),
            PurePosixPath('/home/test_user/tmp/dir_one')
        ]
        assert list(find_paths('~/tmp/*')) == expected
    else:
        expected = [
            PureWindowsPath('c:/tmp/flutils.tests.osutils'),
            PureWindowsPath('c:/tmp/flutils.tests.osutils.txt')
        ]
        assert list(find_paths('c:/tmp/flutils.tests.osutils*')) == expected
test_find_paths()



# Generated at 2022-06-23 18:22:36.376257
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.testing import capture_stdout

    test_group_name = 'bar'
    test_group: grp.struct_group = get_os_group(test_group_name)
    assert test_group.gr_name == test_group_name

    # The group name does not exist.  Should raise an OSError.
    with pytest.raises(OSError):
        get_os_group('baz')

    # The gid does not exist.  Should raise an OSError.
    with pytest.raises(OSError):
        get_os_group(10)

    # The gid exists.  Should return a valid group.
    with capture_stdout() as (stdout, _):
        test_group = get_os_group(test_group.gr_gid)
       

# Generated at 2022-06-23 18:22:46.608271
# Unit test for function get_os_group
def test_get_os_group():
    from unittest.mock import patch

    grp_mock = patch('flutils.pathutils.grp').start()

    get_os_group()
    grp_mock.getgrgid.assert_called_with(
        get_os_user().pw_gid
    )

    get_os_group(2001)
    grp_mock.getgrgid.assert_called_with(2001)

    get_os_group('bar')
    grp_mock.getgrnam.assert_called_with('bar')

    try:
        get_os_group(2001)
    except OSError:
        pass
    else:
        raise RuntimeError('Expected OSError')

    grp_mock.reset_mock()
    grp_mock.get

# Generated at 2022-06-23 18:22:51.191609
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    # Test pattern that does not exist.
    assert [] == list(find_paths('~/tmp/does_not_exist'))
    assert [] == list(find_paths('~/tmp/does_not_exist/*'))
    assert [] == list(find_paths('~/tmp/does_not_exist/**'))
    # Test pattern for path that does not exist.
    assert [] == list(find_paths('~/tmp/does_not_exist/test.txt'))
    # Test pattern that exists.
    assert ['~/tmp/flutils.tests.pathutils.txt'] == \
        [i.as_posix() for i in find_paths('~/tmp/flutils.tests.pathutils.txt')]
    # Test pattern that

# Generated at 2022-06-23 18:23:01.570515
# Unit test for function exists_as
def test_exists_as():
    # create the test directory
    test_dir = directory_present('~/tmp/test_exists_as')
    # Create the test file
    test_file = Path(test_dir).joinpath('exists_as_test.txt')
    test_file.touch()
    # Create a symlink to a file within the test dir.
    test_lnk_to_file = Path(test_dir).joinpath('exists_as_test_lnk_to_file')
    test_lnk_to_file.symlink_to(test_file)
    # Create a symlink to a directory within the test dir.
    test_lnk_to_dir = Path(test_dir).joinpath('exists_as_test_lnk_to_dir')
    test_lnk_to_dir.sy

# Generated at 2022-06-23 18:23:13.267823
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from unittest import TestCase
    from urllib.error import URLError
    from unittest.mock import patch

    from flutils.pathutils import find_paths

    class TestFindPaths(TestCase):

        def test_find_paths(self):
            with TemporaryDirectory() as tmp_dir:
                tmp_dir = Path(tmp_dir)
                file_one = tmp_dir.joinpath('file_one').touch()
                dir_one = tmp_dir.joinpath('dir_one').mkdir()
                file_two = dir_one.joinpath('file_two').touch()

                pattern = tmp_dir.joinpath('*')
                result = find_paths(pattern)

# Generated at 2022-06-23 18:23:23.974077
# Unit test for function chown
def test_chown():
    import unittest.mock as mock
    import tempfile
    import shutil
    import os
    from flutils.pathutils import chown
    from flutils.osutils import get_os_user

    UID = os.getuid()
    GID = os.getgid()

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:23:28.142854
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    from flutils.pathutils import path_absent
    # Create a temporary directory to work in.
    tempdir = tempfile.mkdtemp()
    # Create a directory to remove.
    dirpath = os.path.join(tempdir, 'remove_me')
    os.mkdir(dirpath)
    # Create a link to remove.
    linkpath = os.path.join(tempdir, 'remove_me_link')
    os.symlink(dirpath, linkpath)
    # Create a file to remove.
    filepath = os.path.join(tempdir, 'remove_me_file')
    with open(filepath, 'w'):
        pass
    # Remove the files/directories and link.
    path_absent(tempdir)

# Generated at 2022-06-23 18:23:40.935144
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.tests.helpers import (
        HOME_DIR,
        FILE_DIR,
        FILE_NAME,
        FILE_PATH,
        exists_as,
    )
    from flutils.tests.pathutils import (
        set_up_file_for_testing,
        tear_down_file_for_testing,
    )
    set_up_file_for_testing(FILE_PATH)

# Generated at 2022-06-23 18:23:47.038458
# Unit test for function get_os_group
def test_get_os_group():
    try:
        get_os_group('-1')
        assert False
    except OSError:
        assert True

    try:
        get_os_group(1)
        assert False
    except OSError:
        assert True

    user = get_os_user().pw_name
    group = get_os_group(user).gr_name
    assert isinstance(group, str)
    assert group

    group = get_os_group(user).gr_gid
    assert isinstance(group, int)

    group = get_os_group(group).gr_name
    assert isinstance(group, str)
    assert group

    group = get_os_group(group).gr_gid
    assert isinstance(group, int)



# Generated at 2022-06-23 18:23:52.797894
# Unit test for function get_os_user
def test_get_os_user():
    """Test: pathutils.get_os_user()
    """
    assert get_os_user().pw_name == getpass.getuser()
    try:
        get_os_user('bogus')
        assert False, 'No exception thrown'
    except OSError:
        assert True
    assert get_os_user(501).pw_name == 'flutils'



# Generated at 2022-06-23 18:24:02.187843
# Unit test for function path_absent
def test_path_absent():
    from pathlib import PosixPath, WindowsPath
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as t:
        t = Path(t)
        f = t / 'foo'
        f.touch()
        assert f.exists()
        path_absent(f)
        assert f.exists() is False
        f = t / 'bar'
        f.mkdir()
        f = f / 'baz'
        f.symlink_to('/tmp')
        assert f.exists()
        path_absent(f)
        assert f.exists() is False
        f = t / 'doo'
        f.mkdir()
        f = f / 'der'
        f.mkdir()
        f.touch()
        assert f.exists()

# Generated at 2022-06-23 18:24:06.967228
# Unit test for function path_absent
def test_path_absent():
    # Create a test directory
    tmp_dir = Path(tempfile.mkdtemp())
    # Add a sub-directory and a file
    tmp_sub_dir = tmp_dir / "test_sub_dir"
    tmp_sub_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp_sub_file = tmp_sub_dir / "test_sub_file"
    tmp_sub_file.touch(mode=0o600)
    # Test to remove a file
    path_absent(tmp_sub_file)
    # Test to remove a directory
    path_absent(tmp_sub_dir)
    # Remove the test directory
    path_absent(tmp_dir)

# Generated at 2022-06-23 18:24:17.665525
# Unit test for function directory_present
def test_directory_present():
    test_path = directory_present('./tmp/flutils.directory_present/b')
    assert test_path.exists() is True
    assert test_path.is_dir() is True
    assert test_path.as_posix() == './tmp/flutils.directory_present/b'

    test_path = directory_present('./tmp/flutils.directory_present/a/b')
    assert test_path.exists() is True
    assert test_path.is_dir() is True
    assert test_path.as_posix() == './tmp/flutils.directory_present/a/b'

    test_path = directory_present('./tmp/flutils.directory_present/a/c/d/e/f')
    assert test_path.exists() is True
    assert test_

# Generated at 2022-06-23 18:24:21.136540
# Unit test for function chmod
def test_chmod():
    changed = chmod('~/tmp/**', mode_file=0o777, mode_dir=0o777)
    assert changed is None



# Generated at 2022-06-23 18:24:33.106759
# Unit test for function chmod
def test_chmod():

    with testing.tempdir() as tempdir:
        file_path = os.path.join(
            tempdir, 'flutils.tests.osutils.txt'
        )
        with open(file_path, 'w') as file_:
            file_.write('test')

        dir_path = os.path.join(
            tempdir, 'flutils.tests.osutils.folder'
        )
        os.mkdir(dir_path)

        chmod(file_path, 0o660)
        chmod(dir_path, mode_dir=0o770)

        assert os.stat(file_path).st_mode == 33188
        assert os.stat(dir_path).st_mode == 16832


# Generated at 2022-06-23 18:24:44.540936
# Unit test for function normalize_path
def test_normalize_path():

    # Test bytes path
    test_path = b'~/tmp/foo/../bar'
    assert type(test_path) is bytes
    assert normalize_path(test_path) == Path('/home/test_user/tmp/bar')
    assert isinstance(normalize_path(test_path), Path)

    # Test str path
    test_path = '~/tmp/foo/../bar'
    assert isinstance(test_path, str)
    assert normalize_path(test_path) == Path('/home/test_user/tmp/bar')
    assert isinstance(normalize_path(test_path), Path)

    # Test Path object
    test_path = Path('~/tmp/foo/../bar')
    assert isinstance(test_path, PurePath)

# Generated at 2022-06-23 18:24:53.015085
# Unit test for function normalize_path
def test_normalize_path():
    """
    """
#
#    # String.
#    try:
#        path = normalize_path(r'~/foo/bar')
#    except Exception:
#        assert False
#
#    # Bytes.
#    try:
#        path = normalize_path(b'~/foo/bar')
#    except Exception:
#        assert False
#
#    # PosixPath
#    try:
#        path = normalize_path(PosixPath('~/foo/bar'))
#    except Exception:
#        assert False
#
#    # WindowsPath
#    try:
#        path = normalize_path(WindowsPath('~/foo/bar'))
#    except Exception:
#        assert False
#
#    # Invalid object type (should raise exception)
#    try:

# Generated at 2022-06-23 18:24:58.741175
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    from flutils.pathutils import get_os_group
    return_value = get_os_group()
    assert isinstance(return_value, grp.struct_group)
    assert isinstance(return_value[0], str)
    assert isinstance(return_value[1], str)
    assert isinstance(return_value[2], int)
    assert isinstance(return_value[3], list)



# Generated at 2022-06-23 18:24:59.846664
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:25:06.249138
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-23 18:25:14.949894
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    path = '~/tmp/foo/../bar'

    path = normalize_path(path)

    assert path.is_absolute()
    assert path.is_dir() is False
    assert path.is_symlink() is False
    assert path.is_mount() is False
    assert path.as_posix() == os.path.normpath(os.path.expanduser(path))



# Generated at 2022-06-23 18:25:15.666910
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:25:23.458973
# Unit test for function chown
def test_chown():
    """
    Unit test for function :obj:`~flutils.pathutils.chown`

    Examples:
        >>> from flutils.pathutils import chown
        >>> chown('~/tmp/chown.txt', 'test', 'test')
    """
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    chown('~/tmp/chown.txt', user, group)


# Generated at 2022-06-23 18:25:29.639231
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file_one = tmpdir / 'file_one'
        file_one.touch()
        dir_one = tmpdir / 'dir_one'
        dir_one.mkdir()
        paths = list(find_paths(tmpdir / '*'))
        assert file_one in paths
        assert dir_one in paths
        assert len(paths) == 2



# Generated at 2022-06-23 18:25:41.026577
# Unit test for function chmod
def test_chmod():
    """Test function ``chmod``."""

    # #missing-type-info
    # # pylint: disable=W0612
    # from . import PathlikeStringIO
    # # pylint: enable=W0612

    from .osutils import (
        check_file_mode,
        check_dir_mode,
        create_temp_file,
        create_temp_dir,
    )


# Generated at 2022-06-23 18:25:49.014921
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.miscutils import temporary_directory
    from flutils.osutils import touch
    from typing import Iterator
    with temporary_directory() as tmp_dir:
        file_one = tmp_dir / 'file_one'
        file_two = file_one.parent / 'file_two.txt'
        directory = file_one.parent / 'dir_one'
        touch(file_one, mkdir=False)
        touch(file_two, mkdir=False)
        directory.mkdir(mode=0o775)
        matches: Iterator[Path] = find_paths(tmp_dir / '*')
        assert next(matches) == file_one
        assert next(matches) == file_two
        assert next(matches) == directory
       

# Generated at 2022-06-23 18:26:00.230864
# Unit test for function normalize_path
def test_normalize_path():
    """Code coverage for function normalize_path."""
    path = normalize_path(BytesIO())
    assert path == pathlib.PurePosixPath('/dev/null')
    path = normalize_path('~')
    assert path == pathlib.PurePosixPath('/home/test_user')
    path = normalize_path('~')
    os.environ['HOME'] = '/tmp'
    assert path == pathlib.PurePosixPath('/tmp')
    path = normalize_path('~tmp/foo/../bar')
    assert path == pathlib.PurePosixPath('/tmp/foo/../bar')
    path = normalize_path('~')
    os.environ['HOME'] = '/home/test_user'
    assert path == pathlib.PurePosixPath('/home/test_user')

# Generated at 2022-06-23 18:26:03.508166
# Unit test for function get_os_user
def test_get_os_user():

    user_info = get_os_user()

    assert isinstance(user_info.pw_uid, int)
    assert user_info.pw_name == getpass.getuser()



# Generated at 2022-06-23 18:26:08.706397
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == getpass.getuser()
    assert user.pw_gecos == os.getenv('USER', None)
    assert user.pw_uid == os.getuid()
    assert user.pw_gid == os.getgid()



# Generated at 2022-06-23 18:26:15.501926
# Unit test for function chown
def test_chown():
    import time
    import tempfile

    curr_user = getpass.getuser()
    curr_group = grp.getgrgid(os.getgid()).gr_name
    if curr_group == '0':
        curr_group = 'root'

    name = tempfile.mktemp()
    open(name, 'a').close()

    chown(name)
    assert os.stat(name).st_uid == pwd.getpwnam(curr_user).pw_uid
    assert os.stat(name).st_gid == grp.getgrnam(curr_group).gr_gid

    chown(name, user='root', group='foo')
    assert os.stat(name).st_uid == pwd.getpwnam('root').pw_uid
   

# Generated at 2022-06-23 18:26:27.040651
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from flutils.pathutils import get_os_user
    import os
    import pwd
    import grp
    import pytest
    group_name = 'tmp'
    group_gid = 0
    try:
        _ = get_os_group('tmp')
    except OSError:
        # Create a test user
        username = 'test_user'
        uid = os.getuid()
        user = pwd.getpwnam(username)
        if user is None:
            # Test user does not exist.
            # Create the Test user.
            # Recover the password database lock.
            os.setuid(0)

# Generated at 2022-06-23 18:26:35.591731
# Unit test for function path_absent