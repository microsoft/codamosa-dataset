

# Generated at 2022-06-23 18:16:42.750599
# Unit test for function find_paths
def test_find_paths():
    from flutils.tests import get_tests_dir

    tests_dir = get_tests_dir()
    test_find_paths = tests_dir / 'test_find_paths'
    test_find_paths.mkdir(parents=True, exist_ok=True)
    abs_path = '/'.join([test_find_paths.as_posix(), 'abs_path'])
    path = Path(abs_path)
    path.touch()
    pattern = '/'.join([test_find_paths.as_posix(), '*'])
    for found_path in find_paths(pattern):
        assert found_path == path
    path.unlink()
    test_find_paths.rmdir()



# Generated at 2022-06-23 18:16:44.507933
# Unit test for function chmod
def test_chmod():
    # TODO: This is just a placeholder for now.
    pass


# Generated at 2022-06-23 18:16:52.634942
# Unit test for function path_absent
def test_path_absent():
    here = Path(__file__).absolute().parent
    path = here / 'path_absent'
    path_absent(path)
    assert not path.exists()

    p1 = path / 'bar'
    p2 = path / 'foo'
    p1.mkdir()

    path_absent(path)
    assert not path.exists()

    p1 = path / 'bar' / 'bar'
    p2 = path / 'foo'
    p1.mkdir(parents=True)
    p2.touch()

    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-23 18:17:05.207716
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = os.path.join(TEST_DATA_PATH, 'tmp')
    os.mkdir(tmp_dir)
    for name in ['dir_one', 'dir_two']:
        os.mkdir(os.path.join(tmp_dir, name))
    for name in ['file_one', 'file_two']:
        with open(os.path.join(tmp_dir, name), 'w'):
            pass
    test_paths = set(os.path.join(tmp_dir, name) for name in ['dir_one',
                                                              'dir_two',
                                                              'file_one',
                                                              'file_two'])
    found_paths = set(str(path) for path in find_paths(tmp_dir))
    assert test_paths

# Generated at 2022-06-23 18:17:09.969409
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = cast(str, tmpdir)
        tmpdir = os.path.join(tmpdir, 'foo', 'bar')
        os.makedirs(tmpdir)
        path_absent(tmpdir)
        assert not os.path.exists(tmpdir)
# Test path_absent



# Generated at 2022-06-23 18:17:13.444819
# Unit test for function path_absent
def test_path_absent():
    from tempfile import mkdtemp

    tmp_dir = mkdtemp()
    path = Path(mkdtemp(dir=tmp_dir))

    path.mkdir()
    path_absent(path)
    assert not path.exists()

    path.mkdir()
    path_absent(path)
    assert not path.exists()

    path.touch()
    path_absent(path)
    assert not path.exists()
    path_absent(Path(tmp_dir))



# Generated at 2022-06-23 18:17:22.808692
# Unit test for function directory_present
def test_directory_present():
    """
    Test directory_present.

    This function is tested using a subprocess.  This is due to the
    following issues with testing a function that uses
    :obj:`~pathlib.Path`:

    - It is difficult to mock the ``Path()``, ``Path.exists()``,
      ``Path.mkdir()``, ``Path.chmod()``, and ``Path.chown()`` methods.

    - ``Path.mkdir()`` and ``Path.chmod()`` will raise an OSError
      if the path already exists.

    - ``Path.chmod()`` will not raise an OSError if the path does
      not exist.

    """

    # Test normalize_path() when the given path does not exist.
    from flutils.pathutils import directory_present

# Generated at 2022-06-23 18:17:34.309577
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    if path.exists() is True:
        mode = path.stat().st_mode
        chown(path, '-1', '-1', include_parent=True)
        new_mode = path.stat().st_mode
        if getpass.getuser() != 'root': # pragma: no cover
            assert new_mode == mode, \
                'Failed to maintain the mode of {}'.format(path)
        assert path.parent.stat().st_uid == os.getuid(), \
            'Failed to change the ownership of {}'.format(path.parent)
    else: # pragma: no cover
        raise FileNotFoundError(path)



# Generated at 2022-06-23 18:17:44.641303
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from pathlib import Path
    from flutils.pathutils import chown

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'flutils.tests.osutils.txt'
        path.touch()

        assert os.getuid() == path.stat().st_uid
        assert os.getgid() == path.stat().st_gid

        chown(path, user='root')
        assert 0 == path.stat().st_uid
        assert os.getgid() == path.stat().st_gid

        chown(path, group='root')
        assert 0 == path.stat().st_gid

        chown(tmpdir / '**', user='root', group='root')


# Generated at 2022-06-23 18:17:51.635185
# Unit test for function get_os_group
def test_get_os_group():
    # Normal usage
    get_os_group('foo')

    # Exception usage
    # The given name: 'foo', is not a valid "group name" for this operating
    # system.
    get_os_group('bar')

    # The given name: 'foo', is not a valid "group name" for this operating
    # system.
    get_os_group(-1)

    # The given gid: '-1', is not a valid gid for this operating system
    get_os_group('foo', -1)



# Generated at 2022-06-23 18:17:53.831151
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    pass



# Generated at 2022-06-23 18:17:59.812684
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function :func:`directory_present`."""
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as base_path:
        tmp_path = Path(base_path) / 'tmp_file.txt'
        if tmp_path.exists() is True:
            tmp_path.unlink()

        assert directory_present(
            tmp_path,
            mode=0o700,
            user=getpass.getuser(),
            group=grp.getgrgid(os.getgid()).gr_name
        ) == tmp_path
        assert tmp_path.is_dir() is True
        assert oct(tmp_path.stat().st_mode)[-3:] == '700'

# Generated at 2022-06-23 18:18:12.647912
# Unit test for function find_paths
def test_find_paths():

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        dir_1 = tmpdir / 'dir_one'
        dir_1.mkdir()

        file_1 = dir_1 / 'file_1'
        file_1.touch()

        file_2 = dir_1 / 'file_2'
        file_2.touch()

        file_1 = tmpdir / 'file_one'
        file_1.touch()

        file_2 = tmpdir / 'file_two'
        file_2.touch()

        pattern = tmpdir / '*'
        found = find_paths(pattern)
        result = [x for x in found]

        assert len(result) == 3
        assert dir_1.is_dir() is True
        assert dir_1.name in result

# Generated at 2022-06-23 18:18:20.004897
# Unit test for function get_os_group
def test_get_os_group():
    """Test the function get_os_group().
    """
    from flutils.pathutils import get_os_group
    user_group = get_os_group()
    assert isinstance(user_group, grp.struct_group)
    assert len(user_group) >= 4
    assert user_group[0] == user_group.gr_name
    assert user_group[1] == user_group.gr_passwd
    assert user_group[2] == user_group.gr_gid
    assert user_group[3] == user_group.gr_mem

    user_group = get_os_group('adm')
    assert isinstance(user_group, grp.struct_group)
    assert user_group.gr_name == 'adm'

# Generated at 2022-06-23 18:18:27.931868
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError):
        get_os_user('baz')
    with pytest.raises(OSError):
        get_os_user(4242)
    assert get_os_user('foo').pw_uid == 1001
    assert get_os_user(1001).pw_uid == 1001
    assert get_os_user().pw_uid == os.getuid()
    assert get_os_user().pw_name == os.getlogin()



# Generated at 2022-06-23 18:18:40.314738
# Unit test for function normalize_path

# Generated at 2022-06-23 18:18:41.589353
# Unit test for function chown
def test_chown():
    """ TODO: Unit test for function chown
    """
    pass



# Generated at 2022-06-23 18:18:52.348478
# Unit test for function find_paths
def test_find_paths():
    from sys import platform
    from pathlib import PosixPath, WindowsPath

    if platform == 'linux':
        class PosixPathLinux(PosixPath):
            pass
    elif platform == 'darwin':
        class PosixPathMacOS(PosixPath):
            pass
    elif platform == 'win32':
        class WindowsPathWindows(WindowsPath):
            pass

    pattern = '~/tmp/*'
    expected = set()
    if platform == 'linux':
        expected.add(PosixPathLinux('/home/test_user/tmp/file_one'))
        expected.add(PosixPathLinux('/home/test_user/tmp/dir_one'))
    elif platform == 'darwin':
        expected.add(PosixPathMacOS('/Users/test_user/tmp/file_one'))

# Generated at 2022-06-23 18:18:57.764961
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    with caplog.at_level(logging.DEBUG):
        assert get_os_user() is not None
        assert len(caplog.records) == 0

        assert get_os_user(os.getuid()) is not None
        assert len(caplog.records) == 0

        assert get_os_user(getpass.getuser()) is not None
        assert len(caplog.records) == 0

        assert get_os_user('-1') is not None
        assert len(caplog.records) == 0

        assert get_os_user(os.getuid()) is not None
        assert len(caplog.records) == 0

        assert get_os_user(9999999999) is not None

# Generated at 2022-06-23 18:19:04.175524
# Unit test for function normalize_path
def test_normalize_path():
    tmp_dir: Path = Path(tempfile.mkdtemp())

    sample_path_str = '~/tmp/foo/../bar'

    path: Path = Path(sample_path_str)
    assert path != normalize_path(sample_path_str)
    assert str(path) == normalize_path(sample_path_str).as_posix()



# Generated at 2022-06-23 18:19:11.572418
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present
    from tempfile import TemporaryDirectory
    from os import urandom

    with TemporaryDirectory() as tmp_dir:
        test_path = Path(tmp_dir).joinpath('test_path')
        directory_present(test_path)
        assert exists_as(test_path) == 'directory'

        test_path = Path(tmp_dir).joinpath('test_file')
        test_path.write_bytes(urandom(65536))
        assert exists_as(test_path) == 'file'



# Generated at 2022-06-23 18:19:14.005709
# Unit test for function chmod
def test_chmod():
    assert chmod
# End unit test for function chmod


# Generated at 2022-06-23 18:19:17.910358
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user('foobar').pw_name == 'foobar'
    with pytest.raises(OSError):
        get_os_user('foobarnotarealuser')
    with pytest.raises(OSError):
        get_os_user(8080808080)



# Generated at 2022-06-23 18:19:19.613319
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present."""
    assert directory_present('/tmp/flutils-tests/directory_present') == Path('/tmp/flutils-tests/directory_present')



# Generated at 2022-06-23 18:19:26.347880
# Unit test for function path_absent
def test_path_absent():
    with create_temp_dir() as tempdir:
        # Create a directory to test.
        testdir = Path(tempdir, 'testdir')

        # Create a file to test.
        testfile = Path(tempdir, 'testfile')
        with testfile.open('a') as f:
            f.write('test')

        # Test an empty path.
        path_absent('')

        # Test an existing path with no contents.
        os.mkdir(testdir)
        path_absent(testdir)
        assert not os.path.exists(testdir)

        # Test an existing path with a directory.
        os.mkdir(testdir)
        testdir = Path(testdir, 'testdir2')
        os.mkdir(testdir)
        path_absent(testdir)
       

# Generated at 2022-06-23 18:19:34.762168
# Unit test for function get_os_user
def test_get_os_user():
    # Get the current user's information.
    user = get_os_user()
    # If a user does not exist, an exception would have been
    # raised by this point.
    assert isinstance(user, pwd.struct_passwd)
    # Check if the name can be found by uid.
    assert user == get_os_user(user.pw_uid)
    # Check if the uid can be found by name.
    assert user == get_os_user(user.pw_name)
    bad_uid = 1234567890
    try:
        # Expecting an OSError
        get_os_user(bad_uid)
    except OSError:
        pass
    else:
        raise AssertionError('A bad uid should raise an OSError.')
    bad_name

# Generated at 2022-06-23 18:19:46.967947
# Unit test for function chmod
def test_chmod():
    import os
    import stat
    import tempfile
    from flutils.pathutils import chmod

    temp_dir = tempfile.mkdtemp()
    temp_file = Path(temp_dir) / 'flutils.osutils.test_chmod.txt'

    assert temp_file.is_file() is False

    with temp_file.open('w') as fb:
        fb.write('test')

    assert temp_file.is_file() is True

    # Ensure the file cannot be written to by
    # any user - including the owner
    temp_file.chmod(0o444)
    assert stat.S_IMODE(os.stat(temp_file.as_posix()).st_mode) == 0o444

    # Change the file back to the default
    # mode for a file (0o644

# Generated at 2022-06-23 18:19:53.060754
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    try:
        test_user = pwd.getpwnam('test_user')
    except KeyError:
        pass
    else:
        assert get_os_user('test_user') == test_user
        assert get_os_user(test_user.pw_uid) == test_user



# Generated at 2022-06-23 18:19:55.098089
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests/osutils.txt', 0o660)
    assert True is True, 'Unit test failed!'

# Generated at 2022-06-23 18:20:00.248342
# Unit test for function exists_as
def test_exists_as():

    tmp_path = directory_present('~/tmp/flutils.tests.pathutils.txt')

    # Test with file.
    assert exists_as(tmp_path) == 'file'

    # Test with directory.
    tmp_path.unlink()
    tmp_path.mkdir()
    assert exists_as(tmp_path) == 'directory'

    # Test with nonexistent path.
    tmp_path.rmdir()
    assert exists_as(tmp_path) == ''



# Generated at 2022-06-23 18:20:03.316062
# Unit test for function exists_as
def test_exists_as():
    """ Tests function exists_as()
        In order to run these tests you need to have an actual
        directory called 'test_dir' in your home directory.
    """
    test_path = Path('~/test_dir')
    assert exists_as(test_path) == 'directory'



# Generated at 2022-06-23 18:20:10.904613
# Unit test for function get_os_group
def test_get_os_group():
    os_group1 = get_os_group('root')
    assert isinstance(os_group1, grp.struct_group)
    assert os_group1.gr_name == 'root'
    assert os_group1.gr_gid == 0
    os_group2 = get_os_group()
    assert isinstance(os_group2, grp.struct_group)
    assert os_group2.gr_name == 'vagrant'
    assert os_group2.gr_gid == 1000
    with pytest.raises(OSError):
        get_os_group('test')
    with pytest.raises(OSError):
        get_os_group(10000)

# Generated at 2022-06-23 18:20:11.447443
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:20:18.552444
# Unit test for function directory_present
def test_directory_present():

    # Need a fairly unique name.
    unique_string = ''.join(
        [letter for letter in 'directory_present' if letter.isalpha()]
    )

    # Test a path that does not exist.
    test_path = '/tmp/{}'.format(unique_string)
    result = directory_present(test_path)

    assert result.absolute().as_posix() == test_path
    assert result.exists() is True
    assert result.is_dir() is True

    os.rmdir(test_path)

    # Test a path that does exist.
    result2 = directory_present(test_path)

    assert result2.absolute().as_posix() == test_path
    assert result2.exists() is True
    assert result2.is_dir() is True

    # test a path

# Generated at 2022-06-23 18:20:32.125069
# Unit test for function find_paths
def test_find_paths():
    def get_glob_paths(path):
        paths = []
        for path in Path().glob(path.as_posix()):
            paths.append(path)
        return paths

    def get_find_paths(path):
        paths = []
        for path in find_paths(path):
            paths.append(path)
        return paths

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        paths = Path('*/**')
        file_path = tmp_dir.joinpath('test_file.txt')
        file_path.touch()
        dir_path = tmp_dir.joinpath('test_dir')
        dir_path.mkdir()

# Generated at 2022-06-23 18:20:37.721535
# Unit test for function find_paths
def test_find_paths():
    test_str = '~/tmp/*'
    expected_strs = ['/Users/len/tmp/flutils.tests.osutils.txt', '/Users/len/tmp/test_path']
    paths = list(find_paths(test_str))
    assert len(paths) == len(expected_strs)
    for i, path in enumerate(paths):
        assert expected_strs[i] == path.as_posix()



# Generated at 2022-06-23 18:20:38.242327
# Unit test for function get_os_user
def test_get_os_user():
    return



# Generated at 2022-06-23 18:20:46.619814
# Unit test for function get_os_group
def test_get_os_group():
    # Tests for result
    assert isinstance(get_os_group(), tuple)
    # Tests for key errors
    with pytest.raises(OSError):
        get_os_group('bogus_group_name')
    with pytest.raises(OSError):
        get_os_group(876543)
    # Tests for type errors
    with pytest.raises(TypeError):
        get_os_group({})
    with pytest.raises(TypeError):
        get_os_group(True)
    with pytest.raises(TypeError):
        get_os_group([])



# Generated at 2022-06-23 18:20:49.606096
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown

    chown('testfiles/chown.test',
          user='testuser',
          group='testuser')
    assert True is True

# Generated at 2022-06-23 18:20:59.439499
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        tmp_base = Path(temp_dir)

        tmp_file = tmp_base / 'flutils.tests.osutils.txt'
        tmp_file.touch()

        tmp_dir = tmp_base / 'flutils.test.osutils.dir'
        tmp_dir.mkdir()

        tmp_symlink = tmp_base / 'flutils.test.osutils.symlink.txt'
        tmp_symlink.symlink_to(tmp_file.as_posix(), target_is_directory=False)

        tmp_dir_symlink = tmp_base / 'flutils.test.osutils.dir.symlink'
        tmp_dir_symlink.symlink_

# Generated at 2022-06-23 18:21:08.897023
# Unit test for function find_paths
def test_find_paths():
    from flutils.tests.pathutils.fixtures import (
        test_paths_fixture,
        test_create_paths,
    )

    with test_paths_fixture:
        test_create_paths()
        paths = tuple(find_paths('fixture_dir/*'))

    assert len(paths) == 3
    assert paths[0].as_posix() == '/tmp/fixture_dir/fixture_file'
    assert paths[1].as_posix() == '/tmp/fixture_dir/fixture_link'
    assert paths[2].as_posix() == '/tmp/fixture_dir/fixture_sub_dir'



# Generated at 2022-06-23 18:21:11.494403
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/foo') == ''



# Generated at 2022-06-23 18:21:22.893232
# Unit test for function chown
def test_chown():

    def _check_ownership(path, user, group):
        """
        :rtype: :obj:`Tuple[int, int]`
        """
        st = path.stat()
        return st.st_uid == user.pw_uid and st.st_gid == group.gr_gid

    # test unix
    if 'posix' in sys.builtin_module_names:
        base = Path(__file__).parent
        path = base.joinpath('chown_test')
        path.mkdir()

        path = path.joinpath('foo.txt')
        path.touch()

        # test _check_ownership
        user = pwd.getpwuid(os.getuid())
        group = grp.getgrgid(os.getgid())
        assert _check_

# Generated at 2022-06-23 18:21:35.289022
# Unit test for function directory_present
def test_directory_present():
    path = Path('/home/flutils_test')
    gid = grp.getgrgid(os.getgid()).gr_gid
    assert directory_present(path) == path
    assert os.stat(path.as_posix()).st_gid == gid
    assert os.stat(path.as_posix()).st_mode == 0o700
    assert os.stat(path.as_posix()).st_uid == os.getuid()
    assert exists_as(path) == 'directory'
    path.chmod(0o500)
    directory_present(path)
    assert os.stat(path.as_posix()).st_mode == 0o700

# Generated at 2022-06-23 18:21:46.175982
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user(1)
    except OSError as e:
        raise AssertionError('OSerror raised for valid uid.') from e
    with pytest.raises(OSError) as exc:
        get_os_user(123456789)
    assert exc.value.strerror.endswith('is not a valid uid for this operating system')
    try:
        get_os_user()
    except OSError as e:
        raise AssertionError('OSerror raised for current user.') from e
    with pytest.raises(OSError) as exc:
        get_os_user('not_a_login_name')
    assert exc.value.strerror.endswith('is not a valid "login name" for this operating system')


# Generated at 2022-06-23 18:21:54.383178
# Unit test for function path_absent
def test_path_absent():
    import json
    import shutil
    import tempfile
    import unittest

    from flutils.pathutils import path_absent as func
    from flutils.pathutils import normalize_path

    class Test(unittest.TestCase):

        def setUp(self):
            self._tmpdir = tempfile.mkdtemp()
            self._tmpdir = normalize_path(self._tmpdir)

        def tearDown(self):
            shutil.rmtree(self._tmpdir.as_posix())

        def test_dir(self):
            path = self._tmpdir / 'test_dir'
            path.mkdir(exist_ok=True)
            path = path.as_posix()

            if os.path.exists(path):
                func(path)

# Generated at 2022-06-23 18:22:04.575763
# Unit test for function chown
def test_chown():
    path = Path('~/tmp/flutils.tests.osutils.txt')
    if path.is_file():
        path.unlink()
    if not path.is_file():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.open('w').close()
    assert path.is_file()
    uid = os.getuid()
    gid = os.getgid()
    chown(path)
    assert path.stat().st_uid == uid
    assert path.stat().st_gid == gid
    path.parent.rmdir()

# Generated at 2022-06-23 18:22:15.270731
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == ''
    assert exists_as(directory_present('~/tmp')) == 'directory'
    assert exists_as(directory_present('~/tmp/test_dir')) == 'directory'
    assert exists_as(directory_present('~/tmp/test_dir/foo')) == 'directory'
    assert exists_as(directory_present('~/tmp/test_dir/foo/bar')) == 'directory'
    assert exists_as(directory_present('~/tmp/test_dir/foo/bar/baz')) == 'directory'
    assert exists_as(directory_present('~/tmp/test_dir/foo/bar/baz/bat')) == 'directory'

# Generated at 2022-06-23 18:22:25.876475
# Unit test for function chmod
def test_chmod():

    from tempfile import TemporaryDirectory
    from pathlib import Path

    import flutils.pathutils.osutils

    with TemporaryDirectory(prefix='test_flutils-') as tmpdir:
        tmpdir = Path(tmpdir)
        p = tmpdir / 'testfile.txt'
        p.touch()

        flutils.pathutils.osutils.chmod(p, mode_file=0o644, mode_dir=0o744)
        assert oct(p.stat().st_mode & 0o777) == '0o644'

        p = tmpdir / 'testdir'
        p.mkdir()

        flutils.pathutils.osutils.chmod(p, mode_file=0o644, mode_dir=0o744)

# Generated at 2022-06-23 18:22:35.476057
# Unit test for function normalize_path
def test_normalize_path():
    """Pytest for normalize_path function."""
    # pylint: disable=redefined-outer-name,no-self-use
    os.environ['TEST_VAR'] = '/home/test_user/tmp'
    test_path = '~/foo/bar/../baz'
    test_result = normalize_path(test_path)
    assert test_result.as_posix() == '/home/test_user/foo/baz'
    test_path = bytes('~/foo/bar/../baz', 'utf-8')
    test_result = normalize_path(test_path)
    assert test_result.as_posix() == '/home/test_user/foo/baz'
    test_path = Path('~/foo/bar/../baz')
    test_result

# Generated at 2022-06-23 18:22:45.426820
# Unit test for function find_paths
def test_find_paths():
    with pytest.raises(ValueError) as err:
        list(find_paths('~/tmp'))
    assert 'at least one wildcard' in str(err.value)

    base_path = Path().home() / 'tmp'
    file_one = base_path / 'file_one'
    file_two = base_path / 'file_two'
    dir_one = base_path / 'dir_one'

    for path in [file_one, file_two, dir_one]:
        path.touch()

    assert list(find_paths(base_path / '*')) == [file_one, file_two]
    assert list(find_paths(base_path / '**')) == [file_one, file_two, dir_one]

# Generated at 2022-06-23 18:22:48.652050
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') is None
    assert chown('~/tmp/**') is None
    assert chown('~/tmp/*', user='foo', group='bar') is None
    assert chown('~/tmp/flutils.tests.osutils.txt/foo', user='-1') is None



# Generated at 2022-06-23 18:22:53.673703
# Unit test for function find_paths
def test_find_paths():
    '''
    Unit test for function find_paths.

    :return: None
    '''
    from .temputils import temp_working_dir
    from .temputils import temp_file
    from .temputils import temp_directory

    with temp_working_dir() as tmp_path:
        for _ in range(3):
            temp_file(tmp_path)

        for _ in range(3):
            temp_directory(tmp_path)

        for path in find_paths(str(Path('**/*'))):
            assert path.exists()



# Generated at 2022-06-23 18:23:02.930692
# Unit test for function get_os_group
def test_get_os_group():
    # Test default.
    expected = grp.struct_group(
        gr_name='len',
        gr_passwd='x',
        gr_gid=1004,
        gr_mem=['len']
    )
    actual = get_os_group()
    assert actual == expected

    # Test gid.
    name = 1004
    expected = grp.struct_group(
        gr_name='len',
        gr_passwd='x',
        gr_gid=1004,
        gr_mem=['len']
    )
    actual = get_os_group(name)
    assert actual == expected

    # Test name.
    name = 'len'

# Generated at 2022-06-23 18:23:06.636910
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as"""
    assert exists_as('.') == 'directory'
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-23 18:23:15.460533
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for the function normalize_path."""
    assert(normalize_path('~/tmp') == Path('/home/test_user/tmp'))
    assert(normalize_path(b'~/tmp') == Path('/home/test_user/tmp'))
    assert(normalize_path(Path('~/tmp')) == Path('/home/test_user/tmp'))
    assert(normalize_path('$PATH/tmp') == Path('/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin/tmp'))
    assert(normalize_path(b'$PATH/tmp') == Path(b'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin/tmp'))

# Generated at 2022-06-23 18:23:27.531395
# Unit test for function find_paths
def test_find_paths():
    with temporary_directory() as tmp_dir:
        file1 = Path(tmp_dir) / 'file_one'
        file2 = Path(tmp_dir) / 'file_two'
        dir1 = Path(tmp_dir) / 'dir_one'

        file1.touch()
        file2.touch()
        dir1.mkdir()

        assert [
            file1.as_posix(),
            file2.as_posix(),
            dir1.as_posix()
        ] == [
            p.as_posix() for p in find_paths(Path(tmp_dir) / '*')
        ]


# Generated at 2022-06-23 18:23:39.281637
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from flutils.testing import unittest
    from flutils.testing import mock

    # Test case for the given name parameter does not exist as a
    # "group name" for this operating system.
    subject = mock.Mock(
        side_effect=KeyError(
            'The given name: \'foo\', is not a valid "group name" '
            'for this operating system.'
        )
    )
    with unittest.mock.patch('grp.getgrnam', subject):
        with unittest.assert_raises(OSError):
            get_os_group('foo')
    mock.assert_called_once(
        subject,
        'foo'
    )

    # Test case for if the given name parameter is a gid and it does


# Generated at 2022-06-23 18:23:43.622791
# Unit test for function get_os_user
def test_get_os_user():
    """ Test for function get_os_user """
    user_name = getpass.getuser()
    os_user = get_os_user(user_name)
    assert isinstance(os_user, pwd.struct_passwd)
    assert os_user.pw_name == user_name



# Generated at 2022-06-23 18:23:47.409257
# Unit test for function path_absent
def test_path_absent():
    foo = '/tmp/test_path'
    try:
        os.mkdir(foo)
        with open(os.path.join(foo, 'foo'), 'w') as fp:
            fp.write('')
        path_absent(foo)
        try:
            with open(foo) as fp:
                raise AssertionError()
        except IOError:
            pass
    finally:
        try:
            os.unlink(foo)
        except:
            pass




# Generated at 2022-06-23 18:23:53.139065
# Unit test for function get_os_user
def test_get_os_user():
    if sys.platform == 'win32':
        assert type(get_os_user()) == pwd.struct_passwd
        assert type(get_os_user('Administrator')) == pwd.struct_passwd
    else:
        assert type(get_os_user()) == pwd.struct_passwd
        assert type(get_os_user('root')) == pwd.struct_passwd



# Generated at 2022-06-23 18:24:04.723037
# Unit test for function directory_present
def test_directory_present():
    import shutil
    import tempfile

    _path = Path(tempfile.mkdtemp()) / __name__ / 'test_directory_present'


# Generated at 2022-06-23 18:24:10.669082
# Unit test for function find_paths
def test_find_paths():
    from . osutils import temp_test_directory

    with temp_test_directory() as tmp:
        tmp.make_dir('subdir')
        tmp.make_dir('subdir').make_dir('subdir')
        tmp.make_dir('subdir').make_dir('subdir').make_dir('subdir')

        tmp.make_dir('subdir_back')
        tmp.make_dir('subdir_back').make_dir('subdir_back')

        tmp.make_dir('subdir_back').make_dir('subdir_back').make_dir('subdir_back')

        tmp.write('flutils.tests.osutils.txt').close()
        tmp.write('subdir/flutils.tests.osutils.txt').close()


# Generated at 2022-06-23 18:24:20.022138
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    path = Path(tempfile.mkdtemp())
    # Test a path that does not exist and should be created.
    new_path = directory_present(
        path / 'flutils' / 'tests' / 'pathutils' / 'directory_present'
        / 'new_path'
    )

    # Test a path that already exists as a directory.
    new_path = directory_present(new_path)

    # Test a path that already exists as a file.

# Generated at 2022-06-23 18:24:21.830463
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('some/path/that/does/not/exist') == ''



# Generated at 2022-06-23 18:24:26.315921
# Unit test for function chmod
def test_chmod():
    # Glob pattern with a path that doesn't exist
    chmod('/var/tmp/**', mode_file=0o644, mode_dir=0o750)

    # Path that does exist
    chmod('/var/tmp/foobar.txt')



# Generated at 2022-06-23 18:24:37.217532
# Unit test for function chmod
def test_chmod():
    import pytest
    from flutils.pathutils import chmod as f_chmod

    with pytest.raises(TypeError):
        # PathLike
        path = PathLike('/tmp/flutils.tests.pathutils.txt')
        f_chmod(path)

    with pytest.raises(TypeError):
        # PosixPath
        path = PosixPath('/tmp/flutils.tests.pathutils.txt')
        f_chmod(path)

    with pytest.raises(TypeError):
        # WindowsPath
        path = WindowsPath('C:\\tmp\\flutils.tests.pathutils.txt')
        f_chmod(path)

    with pytest.raises(TypeError):
        # bytes
        path = b'C:\\tmp\\flutils.tests.pathutils.txt'

# Generated at 2022-06-23 18:24:47.869584
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as root:
        root_path = Path(root)
        path1 = root_path / 'test_path'

        path1.mkdir()
        test_path1 = path1 / 'sub_path1'
        test_path2 = path1 / 'sub_path2'
        test_path1.mkdir()
        test_path2.mkdir()
        (test_path1 / 'file1').touch()
        (test_path1 / 'file2').touch()
        (test_path2 / 'file1').touch()
        (test_path2 / 'file2').touch()
        path_absent(path1)
        assert not path1.exists()

        path1.mkdir()

# Generated at 2022-06-23 18:24:58.443119
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('~foo/tmp/foo/../bar') == Path('/home/foo/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert (normalize_path('/Users/len/tmp/foo/../bar') ==
            Path('/Users/len/tmp/bar'))
normalize_path.register(PosixPath, normalize_path)
normalize_path.register(WindowsPath, normalize_path)
normalize_path.register(bytes, normalize_path)



# Generated at 2022-06-23 18:25:09.353473
# Unit test for function chown
def test_chown():
    test_dir = Path('~/tmp/flutils.tests.osutils/').expanduser()
    test_dir.mkdir(parents=True, exist_ok=True)
    test_file = test_dir / 'foo'
    test_file.write_text('bar')
    if test_file.exists() is False:
        raise AssertionError("test_file doesn't exist")

    test_file_stat = os.stat(str(test_file))
    # test_file should have a uid/gid of 1000 which is ubuntu's default
    # for a user.  Now set the gid/uid to get_os_user()'s uid/gid and
    # then run the chown method and assert the results.
    test_file.chmod(0o644)

# Generated at 2022-06-23 18:25:20.031380
# Unit test for function normalize_path
def test_normalize_path():
    import datetime
    import tempfile

    # Setup test fixtures
    normpath_test = tempfile.TemporaryDirectory()
    normpath_test.cleanup()

    date_stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    normpath = os.path.join(normpath_test.name, date_stamp)

    file_one = os.path.join(normpath, 'file_one')
    file_two = os.path.join(normpath, 'sub_dir', 'file_two')

    directories = [
        normpath,
        os.path.join(normpath, 'sub_dir')
    ]

    files = [
        file_one,
        file_two,
    ]

    # Setup testing environment

# Generated at 2022-06-23 18:25:30.389656
# Unit test for function normalize_path
def test_normalize_path():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        # Test str
        path = normalize_path('./tmp/path')
        assert path.is_absolute()
        assert path.as_posix() == os.path.join(tmpdir, 'tmp', 'path')

        # Test Path
        path = Path('./tmp/path')
        assert path.is_absolute() is False
        path = normalize_path(path)
        assert path.is_absolute()
        assert path.as_posix() == os.path.join(tmpdir, 'tmp', 'path')

        # Test bytes

# Generated at 2022-06-23 18:25:37.618915
# Unit test for function path_absent
def test_path_absent():
    from shutil import copytree
    from tempfile import mkdtemp

    tmp_path = Path(mkdtemp(prefix='flutilstest_path_absent'))

    # Create a test directory.
    copytree('../tests/test_files/test_dir', tmp_path.as_posix())

    try:
        path_absent(tmp_path)
        assert tmp_path.exists() is False
    finally:
        tmp_path.rmdir()



# Generated at 2022-06-23 18:25:46.498664
# Unit test for function chown
def test_chown():
    path = Path('/tmp/flutils_test_chown')
    if path.exists():
        if path.is_file():
            path.unlink()
        else:
            path.rmdir()

    path.mkdir()

    try:
        chown(path.as_posix(), '-1', '-1')
        assert path.stat().st_uid == os.getuid()
        assert path.stat().st_gid == os.getgid()
        chown(path.as_posix())
        assert path.stat().st_uid == os.getuid()
        assert path.stat().st_gid == os.getgid()
    finally:
        if path.is_dir():
            path.rmdir()



# Generated at 2022-06-23 18:25:47.083705
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:25:58.851323
# Unit test for function get_os_user
def test_get_os_user():
    print('Testing get_os_user')
    from pprint import pformat
    from typing import List, Union
    from unittest import TestCase
    from flutils.pathutils import get_os_user
    from flutils.systemutils import get_user

    class TestGetOsUser(TestCase):
        """The unit test class for the function :obj:`get_os_user`."""

        def test_get_current_user(self) -> None:
            """Test getting the :term:`current user` object."""
            result = get_os_user()
            self.assertIsInstance(result, pwd.struct_passwd)
            self.assertEqual(result.pw_name, get_user())


# Generated at 2022-06-23 18:26:05.252289
# Unit test for function exists_as
def test_exists_as():
    import contextlib
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with contextlib.suppress(FileExistsError):
        Path().mkdir('~/tmp/flutils.tests.pathutils.exists_as')

    with TemporaryDirectory(dir='~/tmp/flutils.tests.pathutils.exists_as') \
            as tmpdir:
        assert exists_as(tmpdir) == 'directory'



# Generated at 2022-06-23 18:26:13.048934
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory.
    with tempfile.TemporaryDirectory() as tmpd:
        # Change the working directory to the temporary directory.
        os.chdir(tmpd)

        # Create a temporary file to be deleted.
        filename = os.path.join(tmpd, 'tmp_file')
        with open(filename, 'w') as tmpf:
            tmpf.write('foo')

        # Create a temporary symlink to be deleted.
        linkname = os.path.join(tmpd, 'tmp_link')
        os.symlink(filename, linkname)

        # Create a temporary directory with a subdirectory and a file.
        dirname = os.path.join(tmpd, 'tmp_dir')
        subdirname = os.path.join(dirname, 'tmp_subdir')
        subfile

# Generated at 2022-06-23 18:26:25.112605
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    from flutils.pathutils import exists_as
    # Create a dir
    directory = Path('~/tmp/foo/bar').expanduser()
    directory.mkdir(parents=True)
    assert exists_as('~/tmp/foo/bar') == 'directory'
    # Create 2 files
    file1 = Path('~/tmp/foo/bar/file1.txt').expanduser()
    file1.touch()
    assert exists_as(file1) == 'file'
    file2 = Path('~/tmp/foo/bar/file2.txt').expanduser()
    file2.touch()
    assert exists_as(file2) == 'file'
    # Remove created dir and files

# Generated at 2022-06-23 18:26:34.009195
# Unit test for function find_paths
def test_find_paths():
    from .conftest import TEST_USER
    from .conftest import create_test_structure
    import pathlib
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdir = pathlib.Path(tmpdirname)
        mypath = tmpdir / TEST_USER
        mypath.mkdir()
        create_test_structure(mypath)
        assert list(find_paths(mypath / '*')) == [mypath / 'dir_one', mypath / 'file_one']
        assert list(find_paths(mypath / 'dir_one' / '*')) == [mypath / 'dir_one' / 'dir_one_two', mypath / 'dir_one' / 'file_one_one']