

# Generated at 2022-06-23 18:16:35.716369
# Unit test for function directory_present
def test_directory_present():
    test_input = '~/tmp/flutils/pathutils/test_directory_present',
    test_expected_result = '/Users/len/tmp/flutils/pathutils/test_directory_present'
    test_result = directory_present(test_input).as_posix()
    assert test_result == test_expected_result

# Generated at 2022-06-23 18:16:47.542294
# Unit test for function path_absent
def test_path_absent():
    cwd = os.getcwd()
    tmp = os.path.join(cwd, "tmp")
    os.mkdir(tmp)

    test_file_one = os.path.join(tmp, "file_one")
    test_file_two = os.path.join(tmp, "file_two")
    test_file_three = os.path.join(tmp, "file_three")
    with open(test_file_one, 'w') as f:
        f.write("file_one")
    with open(test_file_two, 'w') as f:
        f.write("file_two")
    with open(test_file_three, 'w') as f:
        f.write("file_three")

    test_dir = os.path.join(tmp, "test_dir")


# Generated at 2022-06-23 18:16:55.800502
# Unit test for function directory_present
def test_directory_present():
    path = '~/tmp/flutils/tests/osutils.txt/'
    try:
        directory_present(path)
    except FileExistsError:
        pass
    else:
        assert False, 'The path exists as a file and should have raised.'

    directory_present('~/tmp/flutils/tests/osutils.txt/', mode=0o770)
    directory_present('~/tmp/flutils/tests/osutils.txt/', mode=0o770)
    directory_present('~/tmp/flutils/tests/osutils.txt/', mode=0o770)
    directory_present('~/tmp/flutils/tests/osutils.txt/', mode=0o770, user='root')

# Generated at 2022-06-23 18:17:01.684346
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.tests.flutils_testing import (
        assert_no_raise,
        assert_raises,
    )
    import io
    import os
    import subprocess

    _cwd = os.getcwd()

    def norm(x): return subprocess.check_output(
        ['stat', '-c', '%a', x],
        stderr=io.DEVNULL
    ).rstrip().decode()

    # When a path is a dir, mode_file should not be applied
    assert_no_raise(chmod, '~/*')
    assert norm('~/tmp') == norm(os.getcwd())

    # When a path is a file, mode_dir should not be applied

# Generated at 2022-06-23 18:17:07.112207
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(__file__) == Path(__file__)
    assert normalize_path(os.path.join('~', 'tmp', 'foo', '..', 'bar')) == Path(
        os.path.join(os.path.expanduser('~'), 'tmp', 'bar'))



# Generated at 2022-06-23 18:17:14.479219
# Unit test for function get_os_group
def test_get_os_group():
    name = get_os_user().pw_gid
    name = cast(int, name)
    assert get_os_group(name) == grp.getgrgid(name)
    assert get_os_group(get_os_group().gr_name) == grp.getgrnam(get_os_group().gr_name)


# Generated at 2022-06-23 18:17:25.919870
# Unit test for function path_absent
def test_path_absent():
    """Test for function path_absent."""

    from pathlib import Path
    import shutil

    os.chdir('/')

    # test_root = normalize_path('~/tmp/flutils/test_path_absent')
    test_root = Path.home()
    test_root = test_root / 'tmp'
    test_root = test_root / 'flutils'
    test_root = test_root / 'test_path_absent'
    test_root = test_root.absolute()

    test_root = cast(str, test_root)
    test_root = cast(PathLike, test_root)

    test_file = normalize_path(test_root / 'test_file')
    test_dir = normalize_path(test_root / 'test_dir')
    test_sub

# Generated at 2022-06-23 18:17:38.592003
# Unit test for function exists_as
def test_exists_as():
    from .._osutils import _create_tmp_file, _create_tmp_dir
    from datetime import datetime
    from itertools import product

    _, tmp_file = _create_tmp_file(
        owner='foo',
        mode=0o660,
        contents='Test file for flutils.pathutils.exists_as',
    )
    assert exists_as(tmp_file) == 'file'

    _, tmp_dir = _create_tmp_dir(owner='foo', mode=0o770)
    assert exists_as(tmp_dir) == 'directory'

    # Need different times and times >= the modification time
    times = [datetime.utcnow(), datetime.utcnow()]

# Generated at 2022-06-23 18:17:40.486332
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar')
    assert get_os_group('2001')



# Generated at 2022-06-23 18:17:42.878968
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user() returns an pwd.struct_passwd object."""
    assert isinstance(get_os_user(), pwd.struct_passwd)



# Generated at 2022-06-23 18:17:45.381929
# Unit test for function get_os_group
def test_get_os_group():
    g = get_os_group()
    assert isinstance(g, grp.struct_group)
# Unit testing for function get_os_group
test_get_os_group()



# Generated at 2022-06-23 18:17:51.945064
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    _user = get_os_user()
    assert isinstance(_user, pwd.struct_passwd)
    assert isinstance(_user.pw_name, str)
    assert isinstance(_user.pw_passwd, str)
    assert isinstance(_user.pw_uid, int)
    assert isinstance(_user.pw_gid, int)
    assert isinstance(_user.pw_gecos, str)
    assert isinstance(_user.pw_dir, str)
    assert isinstance(_user.pw_shell, str)



# Generated at 2022-06-23 18:17:58.956886
# Unit test for function chmod
def test_chmod():
    # Test paths that don't exist
    _ = Path('/tmp/test1.txt')
    _.unlink(missing_ok=True)
    chmod('/tmp/test1.txt', 0o644)
    assert not _.exists()
    _ = Path('/tmp/test2.txt')
    _.unlink(missing_ok=True)
    chmod('/tmp/test2.txt', 0o644, include_parent=True)
    assert not _.exists()
    _ = Path('/tmp/test3.txt')
    _.unlink(missing_ok=True)
    chmod('/tmp/test3.txt', mode_file=0o644, mode_dir=0o770)
    assert not _.exists()
    _ = Path('/tmp/test4.txt')

# Generated at 2022-06-23 18:18:06.530366
# Unit test for function directory_present
def test_directory_present():
    from flutils.plate import AssertThat
    from flutils.pathutils import directory_present

    path = directory_present('/tmp/flutils.tests.directory_present')
    AssertThat(path.is_dir()).IsTrue()
    AssertThat(path.stat().st_mode).Equals(0o40770)



# Generated at 2022-06-23 18:18:11.207619
# Unit test for function path_absent
def test_path_absent():
    from os.path import exists
    from pathlib import Path
    with set_cwd('~/tmp'):
        d = Path('./absent')
        d.mkdir()
        assert exists(d) is True
        path_absent(d)
        assert exists(d) is False



# Generated at 2022-06-23 18:18:16.887720
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present

    dir_path = directory_present(
        '{dirpath}/test_directory_present', mode=0o770
    )
    assert dir_path.as_posix() == '{dirpath}/test_directory_present'



# Generated at 2022-06-23 18:18:24.135746
# Unit test for function get_os_user
def test_get_os_user():
    # pylint: disable=missing-function-docstring
    from flutils.pathutils import get_os_user
    # pylint: enable=missing-function-docstring
    try:
        get_os_user('made_up_login_name')
    except OSError:
        pass
    try:
        get_os_user(1234)
    except OSError:
        pass



# Generated at 2022-06-23 18:18:33.673304
# Unit test for function normalize_path
def test_normalize_path():
    """Test function :func:`normalize_path`."""
    import subprocess
    from typing import Generator

    test_paths = (
        '~/tmp',
        '$HOME/tmp',
        '../../tmp',
        '$HOME/tmp/../../tmp',
        '$HOME/tmp/./../../tmp',
        '~/tmp/foo/../bar',
        '$HOME/tmp/foo/../bar',
        '/home/../tmp/foo/../bar',
        '$HOME/../tmp/foo/../bar',
        '$HOME/../tmp/foo/.././bar',
    )

    result: Generator[Path, None, None] = normalize_path(test_paths)
    assert type(result) is Generator
    assert type(next(result)) is Path
    assert next

# Generated at 2022-06-23 18:18:44.523991
# Unit test for function directory_present
def test_directory_present():
    _directory_present(
        'test_directory_present',
        mode_dir=0o777,
        use_globs=False,
    )
    _directory_present(
        'test_directory_present_absent_parent',
        mode_dir=0o777,
        use_globs=False,
        include_parent=True,
    )
    _directory_present(
        'test_directory_present_exist_parent_dir',
        mode_dir=0o777,
        use_globs=False,
        include_parent=True,
    )
    _directory_present(
        'test_directory_present_exist_parent_not_dir',
        mode_dir=0o777,
        use_globs=False,
        include_parent=True,
    )
    _directory_

# Generated at 2022-06-23 18:18:49.257685
# Unit test for function find_paths
def test_find_paths():
    """Tests for function find_paths"""
    from flutils.pathutils import find_paths
    assert list(find_paths('~/tmp/*')) == [Path('/home/test_user/tmp/file_one'), Path('/home/test_user/tmp/dir_one')]



# Generated at 2022-06-23 18:18:55.502920
# Unit test for function directory_present
def test_directory_present():
    """Test the following with various args:
    directory_present('/Users/len/tmp/test_path')
    directory_present('/Users/len/tmp/test_path/nested')

    """
    # Ensure the '~/tmp/test_path' directory path exists as a directory.
    top_path = directory_present('~/tmp/test_path')
    assert top_path.is_dir() is True
    # Directory exists as a directory, but not as the expected mode.
    directory_present('~/tmp/test_path', mode=0o700)
    nested_path = directory_present('~/tmp/test_path/nested')
    assert nested_path.is_dir() is True



# Generated at 2022-06-23 18:18:56.745350
# Unit test for function get_os_group
def test_get_os_group():
    """flutils.pathutils.get_os_group()"""
    # TODO: Add unit tests for function get_os_group
    pass



# Generated at 2022-06-23 18:19:01.024645
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )
    assert get_os_group(2000) == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=[]
    )



# Generated at 2022-06-23 18:19:10.842744
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import chown
    tmp = tempfile.TemporaryDirectory()

# Generated at 2022-06-23 18:19:22.940027
# Unit test for function find_paths
def test_find_paths():
    tmp_path = directory_present('/tmp/flutils_tests_pathutils_find_paths')

# Generated at 2022-06-23 18:19:26.735845
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    assert get_os_user('root').pw_uid == 0
    assert get_os_user(0).pw_name == 'root'
    assert get_os_user(0).pw_gid == 0
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-23 18:19:34.691816
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('~/tmp').expanduser()) == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/dev/disk0s2') == 'block device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/log') == 'socket'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/var/spool/mqueue') == 'directory'
    # assert exists_as('/sdcard') == 'directory'
    assert exists_as('/dev/fs') == 'block device'
    assert exists_as('/dev/snd') == 'directory'

# Generated at 2022-06-23 18:19:37.154840
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')


# Generated at 2022-06-23 18:19:49.311705
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user('foobar')
    assert isinstance(user, pwd.struct_passwd), 'user must be an instance of pwd.struct_passwd.'
    assert isinstance(user.pw_name, str), 'user.pw_name must be a str.'
    assert user.pw_name == 'foobar', 'user.pw_name must be foobar.'
    assert isinstance(user.pw_passwd, str), 'user.pw_passwd must be a str.'
    assert isinstance(user.pw_uid, int), 'user.pw_uid must be an int.'
    assert user.pw_uid == 4321, 'user.pw_uid must be 4321.'

# Generated at 2022-06-23 18:19:58.610204
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory(
            prefix='flutils.tests.pathutils.',
            dir='/tmp'
    ) as tmpdirname:
        tmpdir = Path(tmpdirname)
        Path(tmpdir, 'dir_one').mkdir(mode=0o700, parents=True)
        Path(tmpdir, 'dir_two').mkdir(mode=0o700, parents=True)
        Path(tmpdir, 'dir_three').mkdir(mode=0o700, parents=True)
        Path(tmpdir, 'file_one').touch(mode=0o600)
        Path(tmpdir, 'file_two').touch(mode=0o600)
        Path(tmpdir, 'file_three').touch(mode=0o600)


# Generated at 2022-06-23 18:20:01.752690
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group(), grp.struct_group)




# Generated at 2022-06-23 18:20:03.352837
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path('/tmp/does_not_exist')) == ''



# Generated at 2022-06-23 18:20:04.988119
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.chown.txt')



# Generated at 2022-06-23 18:20:13.832218
# Unit test for function chown
def test_chown():
    # Get home directory
    home = Path().home()

    # Paths to create
    dirs = [
        home / 'tmp',
        home / 'tmp' / 'flutils.tests.pathutils',
        home / 'tmp' / 'flutils.tests.pathutils' / 'foo',
        home / 'tmp' / 'flutils.tests.pathutils' / 'foo' / 'bar',
        home / 'tmp' / 'flutils.tests.pathutils' / 'foo' / 'bar' / 'baz',
    ]

    # Create a tmp directory that is owned and group by root
    dirs[0].mkdir(parents=True, exist_ok=True)
    os.chown(dirs[0].as_posix(), 0, 0)

    # Create the remaining directories

# Generated at 2022-06-23 18:20:27.167636
# Unit test for function find_paths
def test_find_paths():
    # Testing with PosixPaths
    with ExitStack() as stack:
        tmp_dir = stack.enter_context(TemporaryDirectory())
        tmp_dir_path = Path(tmp_dir) / 'test_tmp_dir'

        assert not tmp_dir_path.exists()
        tmp_dir_path.mkdir()
        assert tmp_dir_path.is_dir()
        assert tmp_dir_path.exists()

        sub_dir = tmp_dir_path / 'sub_dir'
        assert not sub_dir.exists()
        sub_dir.mkdir()
        assert sub_dir.is_dir()
        assert sub_dir.exists()

        file_one = tmp_dir_path / 'file_one.txt'
        assert not file_one.exists()
        file_one.touch

# Generated at 2022-06-23 18:20:37.120010
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory.
    with TemporaryDirectory() as tmp_d:
        tmp_d = Path(tmp_d)

        # Create some test directories and files.
        path_one = tmp_d / 'one'
        path_one.mkdir()
        path_one_file_one = path_one / 'file_one'
        path_one_file_one.touch()
        path_two = tmp_d / 'two'
        path_two.mkdir()
        path_two_file_one = path_two / 'file_one'
        path_two_file_one.touch()
        path_two_file_two = path_two / 'file_two'
        path_two_file_two.touch()

        # Test path_absent
        path_absent(tmp_d)

        #

# Generated at 2022-06-23 18:20:47.294193
# Unit test for function chown
def test_chown():
    # type: () -> None
    from flutils.helpers import mktemp_file
    from flutils.pathutils import exists_as

    ex_file = mktemp_file('chown.test')
    ex_path = os.path.dirname(ex_file.name)

    assert exists_as('file', ex_file.name, check_parent=True) is True
    assert exists_as('directory', ex_path, check_parent=True) is True

    chown(ex_file.name, user='root')
    chown(ex_path, user='root', include_parent=True)

    assert exists_as('file', ex_file.name, check_parent=True) is True
    assert exists_as('directory', ex_path, check_parent=True) is True


# Generated at 2022-06-23 18:20:57.614679
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=['bar']
    )
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )
    assert get_os_group(2000) == grp.struct_group(
        gr_name='foo', gr_passwd='*', gr_gid=2000, gr_mem=['bar']
    )

# Generated at 2022-06-23 18:21:09.756869
# Unit test for function directory_present
def test_directory_present():
    """Test the function: flutils.pathutils.directory_present with
    various parameters.
    """
    from flutils.pathutils import directory_present
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from unittest.mock import patch

    # Ensure that it fails with a glob pattern.
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'foo*bar'
        try:
            directory_present(path)
        except ValueError as e:
            assert 'The path: %r must NOT contain any glob patterns.' \
                % path.as_posix() in str(e)
        else:
            assert False, 'directory_present() did not raise ValueError.'

    # Ensure that it fails with a relative path.

# Generated at 2022-06-23 18:21:11.529613
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt') is None



# Generated at 2022-06-23 18:21:22.938106
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function."""
    from tempfile import TemporaryDirectory
    from .osutils import create_path

    with TemporaryDirectory(dir='~/tmp') as tmpdir:
        # tmpdir is pathlib.Path object
        file_one = create_path(
            path=tmpdir / 'file_one',
            content='file one content',
            mode=0o600
        )
        dir_one = create_path(
            path=tmpdir / 'dir_one',
            content='dir one content',
            mode=0o700
        )
        dir_one_sub_one = create_path(
            path=tmpdir / 'dir_one/sub_one',
            content='sub one content',
            mode=0o700
        )

# Generated at 2022-06-23 18:21:35.288741
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for normalize_path."""
    cwd = os.getcwd()
    ab_path = os.path.join(cwd, 'tmp', 'foo', '../bar')
    rel_path = os.path.join('tmp', 'foo', '../bar')

# Generated at 2022-06-23 18:21:46.133949
# Unit test for function exists_as
def test_exists_as():
    """Test ``flutils.exists_as()``.

    """
    # Test: Return an empty string if the given path does NOT exist.
    assert exists_as('/a/b/c/d') == ''

    # Test: Return 'directory' if the given path exists as a directory.
    directory_present('~/tmp/test_path')
    assert exists_as('~/tmp/test_path') == 'directory'

    # Test: Return 'file' if the given path exists as a file..
    directory_present('~/tmp/test_path_file')
    Path('~/tmp/test_path_file/test_file').touch()
    assert exists_as('~/tmp/test_path_file/test_file') == 'file'

    # Test: Return 'block device' if the given path exists as a

# Generated at 2022-06-23 18:21:48.483593
# Unit test for function get_os_group
def test_get_os_group():
    gid = get_os_group().gr_gid
    group = get_os_group(gid)

    assert gid == group.gr_gid



# Generated at 2022-06-23 18:21:56.662998
# Unit test for function find_paths
def test_find_paths():
    pattern = '**'

    paths = []
    for sub_path in find_paths(pattern):
        paths.append(sub_path.as_posix())
    paths.sort()


# Generated at 2022-06-23 18:22:10.329712
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert isinstance(user, tuple)
    assert user[0] == getpass.getuser()
    with pytest.raises(OSError):
        get_os_user('test_user_does_not_exist')
    within = 'tmp_dir_within'
    outside = 'tmp_dir_outside'
    user = get_os_user()
    user_id = -1
    if user[0] != 'root':
        # Because only root can set the user_id for a directory
        # to a user that does not exist, this test must be
        # skipped for "root".
        user_id = min(pwd.getpwall(), key=lambda x: x[2])[2] - 1
       

# Generated at 2022-06-23 18:22:11.622307
# Unit test for function chown
def test_chown():
    assert callable(chown)



# Generated at 2022-06-23 18:22:15.017816
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/random') == 'char device'



# Generated at 2022-06-23 18:22:25.598978
# Unit test for function exists_as
def test_exists_as():
    path_str = '~/tmp'
    path = normalize_path(path_str)

    with temporary_directory() as tmp_dir:
        file_path = tmp_dir / 'exists_as_file.txt'
        file_path.touch()
        assert exists_as(file_path) == 'file'
        assert exists_as(file_path.as_posix()) == 'file'
        assert exists_as(file_path.as_bytes()) == 'file'

        if path.exists() is False:
            path.mkdir(0o1777)
            assert exists_as(path) == 'directory'
            assert exists_as(path.as_posix()) == 'directory'
            assert exists_as(path.as_bytes()) == 'directory'
            path.rmdir()



# Generated at 2022-06-23 18:22:35.369105
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present, exists_as
    import tempfile

    def make_temp_dir() -> Path:
        """Create a temporary directory and return a :obj:`Path
        <pathlib.Path>` object that points to it.

        :rtype: :obj:`Path <pathlib.Path>`
            * :obj:`PosixPath <pathlib.PosixPath>` or
              :obj:`WindowsPath <pathlib.WindowsPath>` depending on the system.

        """
        with tempfile.TemporaryDirectory() as dname:
            dpath = Path(dname)
        return dpath


# Generated at 2022-06-23 18:22:46.047870
# Unit test for function get_os_group
def test_get_os_group():
    from . import osutils
    group_name = osutils.get_os_group().gr_name
    group_passwd = osutils.get_os_group().gr_passwd
    group_gid = osutils.get_os_group().gr_gid
    group_members = osutils.get_os_group().gr_mem
    assert isinstance(group_name, str)
    assert isinstance(group_passwd, str)
    assert isinstance(group_gid, int)
    assert isinstance(group_members, list)

    try:
        osutils.get_os_group('foo')
    except OSError as ex:
        assert isinstance(ex, OSError)
        assert ex.args[0] == 'The given name: \'foo\', is not a valid ' \
                

# Generated at 2022-06-23 18:22:51.034871
# Unit test for function get_os_user
def test_get_os_user():
    user_obj = get_os_user()
    assert isinstance(user_obj, pwd.struct_passwd)
    user_obj = get_os_user('-1')
    assert isinstance(user_obj, pwd.struct_passwd)
    with pytest.raises(OSError):
        user_obj = get_os_user('blahblah')
    with pytest.raises(OSError):
        user_obj = get_os_user(999999)



# Generated at 2022-06-23 18:23:01.479586
# Unit test for function directory_present
def test_directory_present():
    # Use the directory_present to create a test directory
    dir_path = directory_present('~/tmp/test_path')
    # Check if the created directory matches the expected
    assert dir_path.as_posix() == '/Users/len/tmp/test_path'
    # Check if the created directory has the expected mode
    assert dir_path.stat().st_mode == 16832
    # Check if the created directory has the expected name
    assert dir_path.name == 'test_path'
    # Check if the created directory has the expected user
    assert dir_path.owner() == getpass.getuser()
    # Check if the created directory has the expected group
    assert grp.getgrgid(dir_path.stat().st_gid).gr_name == getpass.getuser()

# Generated at 2022-06-23 18:23:07.729643
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == os.getlogin()
    assert get_os_user(os.getlogin()).pw_name == os.getlogin()
    assert get_os_user(os.getuid()).pw_uid == os.getuid()



# Generated at 2022-06-23 18:23:13.529179
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown, path_absent
    from flutils.test import get_var
    path = get_var('TEST_PATH')
    chown(path, user='-1', group='-1')



# Generated at 2022-06-23 18:23:25.116678
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') \
        == Path(os.path.expanduser('~/tmp/bar'))
    assert normalize_path('${USER}/tmp/foo/../bar') \
        == Path(os.path.expanduser('~/tmp/bar'))
    assert normalize_path('~/tmp/foo/',) \
        == Path(os.path.expanduser('~/tmp/foo'))
    assert normalize_path('foo/',) == Path(os.getcwd()) / 'foo'
    path = Path('/tmp/foo')
    assert normalize_path(path) == path

normalize_path.register(bytes, lambda path: normalize_path(path.decode()))

# Generated at 2022-06-23 18:23:37.053555
# Unit test for function exists_as

# Generated at 2022-06-23 18:23:47.672436
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths"""
    with TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        (tmpdirname / 'file_one').mkdir()
        (tmpdirname / 'file_two').touch()
        (tmpdirname / 'file_three').touch()
        (tmpdirname / 'file_one' / 'file_four').touch()
        (tmpdirname / 'file_one' / 'file_five').touch()
        (tmpdirname / 'file_one' / 'file_six').touch()
        (tmpdirname / 'file_one' / 'file_seven').touch()
        (tmpdirname / 'file_one' / 'file_eight').touch()
        (tmpdirname / 'file_one' / 'file_nine').touch()

# Generated at 2022-06-23 18:23:59.554425
# Unit test for function find_paths
def test_find_paths():
    paths = [
        '~/tmp/file_one',
        '~/tmp/dir_one',
        '~/tmp/dir_one/file_two'
    ]
    for path in paths:
        Path(path).touch()

    found_paths = list(find_paths('~/tmp/file_one'))
    assert len(found_paths) == 1
    assert found_paths[0] == Path('~/tmp/file_one')

    found_paths = list(find_paths('~/tmp/dir_one'))
    assert len(found_paths) == 1
    assert found_paths[0] == Path('~/tmp/dir_one')

    found_paths = list(find_paths('~/tmp/*'))

# Generated at 2022-06-23 18:24:06.041389
# Unit test for function find_paths
def test_find_paths():

    from flutils.pathutils import find_paths

    if hasattr(sys, '_called_from_test') and sys._called_from_test is True:
        tmp_dir = Path(__file__).resolve().parent.joinpath('tmp')
    else:
        tmp_dir = Path('.').joinpath('flutils.tests.tmp')

    # Clean up the tmp directory if it exists
    if tmp_dir.is_dir() is True:
        rmtree(tmp_dir)
    tmp_dir.mkdir(parents=True, exist_ok=False)

    assert(not tmp_dir.joinpath('file_one').exists())
    assert(not tmp_dir.joinpath('dir_one').exists())
    tmp_dir.joinpath('file_one').touch()
    tmp_dir.join

# Generated at 2022-06-23 18:24:11.875609
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(getpass.getuser()).pw_name == getpass.getuser()
    assert get_os_user('nobody').pw_name == 'nobody'
    assert get_os_user(-1) == get_os_user('nobody')

# Generated at 2022-06-23 18:24:20.669928
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory
    from os import fchown, getuid, lstat, umask, uname

    # Linux test only.
    if uname().sysname != 'Linux':
        return

    # Create a temporary directory.
    with TemporaryDirectory() as tempdir:
        # Create a file and directory with no permissions and owned by
        # root:root.
        uid = getuid()
        path1 = Path(tempdir) / 'file1'
        path1.touch()
        fchown(path1.open(mode='ab'), 0, 0)
        path2 = Path(tempdir) / 'dir1'
        path2.mkdir(mode=0o000)
        fchown(path2.open(mode='ab'), 0, 0)

        # Add some test files and links.

# Generated at 2022-06-23 18:24:32.970002
# Unit test for function chown
def test_chown():
    # create test file
    save_output_to_file(b'testfile', 'testfile.txt')
    # get current user and group
    current_user = pwd.getpwuid(os.getuid()).pw_name
    current_group = grp.getgrgid(os.getgid()).gr_name
    # set test paths
    testfile_path = Path(__file__).parent.joinpath(
        'testfile.txt').resolve()
    test_dir = Path(__file__).parent.resolve()
    # test group and user
    test_user = 'testuser'
    test_group = 'testgroup'
    # add test group

# Generated at 2022-06-23 18:24:44.414952
# Unit test for function directory_present
def test_directory_present():
    import os
    import tempfile

    test_path = normalize_path(tempfile.mkdtemp())

# Generated at 2022-06-23 18:24:52.865942
# Unit test for function get_os_user
def test_get_os_user():
    os_user = get_os_user()
    # Assert the function DOES NOT return None
    assert os_user is not None
    # Assert the function returns the expected type
    assert isinstance(os_user, pwd.struct_passwd)
    # Assert the expected methods are present
    assert hasattr(os_user, 'pw_name')
    assert hasattr(os_user, 'pw_passwd')
    assert hasattr(os_user, 'pw_uid')
    assert hasattr(os_user, 'pw_gid')
    assert hasattr(os_user, 'pw_gecos')
    assert hasattr(os_user, 'pw_dir')
    assert hasattr(os_user, 'pw_shell')
    # Asert the expected methods return non-empty strings


# Generated at 2022-06-23 18:24:56.870900
# Unit test for function chmod
def test_chmod():
    path = 'test_file_2.txt'
    mode = 0o777
    chmod(path, mode_file=mode)
    actual = os.stat(path)
    expected = os.stat('test_file_1.txt')
    assert actual.st_mode == expected.st_mode



# Generated at 2022-06-23 18:25:08.875823
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    import platform

    # Test with different systems.
    if platform.system() == 'Darwin':
        # Darwin is Mac OS X.
        pass
    elif platform.system() == 'Linux':
        # Linux is usually POSIX.
        pass
    elif platform.system() == 'FreeBSD':
        # FreeBSD is usually POSIX.
        pass
    elif platform.system() == 'Windows' and platform.release() == 'XP':
        # Windows XP is POSIX, even though the system is Windows.
        pass
    elif platform.system() == 'Windows' and platform.release() == '10':
        # Windows 10 is NTFS.
        pass

# Generated at 2022-06-23 18:25:19.371504
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for function normalize_path."""
    # bytes
    assert normalize_path(b'~/tmp/foo/../bar') == Path('~/tmp/bar')
    assert normalize_path(b'foo/../bar') == Path('bar')
    # str
    assert normalize_path('~/tmp/foo/../bar') == Path('~/tmp/bar')
    assert normalize_path('foo/../bar') == Path('bar')
    # PosixPath
    assert normalize_path(Path('~/tmp/foo/../bar')) == Path('~/tmp/bar')
    assert normalize_path(Path('foo/../bar')) == Path('bar')
    # WindowsPath
    assert normalize_path('c:\\Users\\bar') == Path('c:/Users/bar')
   

# Generated at 2022-06-23 18:25:28.811368
# Unit test for function exists_as
def test_exists_as():
    """Test the functional for exists_as."""
    unittest.TestCase()
    path = '~/tmp/flutils.tests.pathutils.txt'
    my_file = normalize_path(path)
    if my_file.exists() is True:
        my_file.unlink()

    assert exists_as(path) == ''
    my_file.touch()
    assert exists_as(path) == 'file'
    my_file.unlink()
    assert exists_as(path) == ''
    my_file.mkdir()
    assert exists_as(path) == 'directory'
    my_file.rmdir()



# Generated at 2022-06-23 18:25:31.889472
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/test_dir')
    path_absent(path)
    assert path.exists() == False



# Generated at 2022-06-23 18:25:33.792395
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group().gr_name == os.getlogin()


# Generated at 2022-06-23 18:25:38.423937
# Unit test for function chown
def test_chown():
    try:
        chown('*',include_parent=True)
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-23 18:25:45.431213
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group().gr_name == os.getgid()
    assert get_os_group('bar').gr_name == 'bar'
    assert get_os_group(2001).gr_gid == 2001
    raises(OSError, get_os_group,
           'this_is_not_a_group_name_for_the_current_os')
    raises(OSError, get_os_group,
           'this_is_not_a_group_name_for_the_current_os')
    raises(OSError, get_os_group, 999999999999)



# Generated at 2022-06-23 18:25:57.197865
# Unit test for function chmod
def test_chmod():
    test_path = Path(__file__).parent
    test_path2 = test_path / 'tests2'
    if test_path2.is_dir() is True:
        shutil.rmtree(test_path2)

    test_path2.mkdir(parents=True)

    assert test_path2.exists() is True
    assert (test_path2.parent / 'tests2').exists() is True

    chmod(test_path2, 0o666, 0o777, include_parent=True)

    assert test_path2.stat().st_mode == 16895
    assert (test_path2.parent / 'tests2').stat().st_mode == 16895

    shutil.rmtree(test_path2)

# Generated at 2022-06-23 18:25:58.616318
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'



# Generated at 2022-06-23 18:26:03.003152
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutilsfuncs.txt', 0o660)
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)
    chmod('~/tmp/*')



# Generated at 2022-06-23 18:26:10.340568
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('$HOME/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')

normalize_path.register(bytes, _normalize_path_bytes)  # type: ignore[assignment]
normalize_path.register(str, _normalize_path_str)  # type: ignore[assignment]
normalize_path.register(Path, _normalize_path_path)  # type: ignore[assignment]



# Generated at 2022-06-23 18:26:22.605891
# Unit test for function path_absent
def test_path_absent():
    """Test the flutils.pathutils.path_absent function."""
    import os
    import pathlib
    import tempfile
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists

    test_path = pathlib.Path(tempfile.mkdtemp())
    path_absent(test_path)
    assert path_exists(test_path) is False

    test_dir = test_path / 'test_dir'
    test_dir.mkdir()
    path_absent(test_dir)
    assert path_exists(test_dir) is False

    test_file = test_path / 'test_file'
    with test_file.open(mode='w', encoding='utf-8') as f:
        f.write('test_file')
    path

# Generated at 2022-06-23 18:26:24.341123
# Unit test for function directory_present
def test_directory_present():
    # TODO: Add some tests...
    pass



# Generated at 2022-06-23 18:26:26.993962
# Unit test for function path_absent
def test_path_absent():
    cwd = cast(str, os.getcwd())
    _call_func_under_cwd(path_absent)
    os.chdir(cwd)



# Generated at 2022-06-23 18:26:31.188166
# Unit test for function get_os_group
def test_get_os_group():
    assert_equals(get_os_group('root').gr_gid, 0)
    assert_equals(get_os_group('nobody').gr_gid, 65534)
    assert_equals(get_os_group(65534).gr_name, 'nobody')

