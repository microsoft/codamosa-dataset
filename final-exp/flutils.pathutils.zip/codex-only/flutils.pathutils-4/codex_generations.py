

# Generated at 2022-06-23 18:16:39.699860
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    path_absent('~/tmp/noexist')
    os.makedirs('~/tmp/test_path/test_path_one')
    os.makedirs('~/tmp/test_path/test_path_two')
    open('~/tmp/test_path/file.txt', 'w').close()
    open('~/tmp/test_path/test_path_one/file_one.txt', 'w').close()
    open('~/tmp/test_path/test_path_one/file_two.txt', 'w').close()
    open('~/tmp/test_path/test_path_two/file_three.txt', 'w').close()
    path_absent('~/tmp/test_path')

# Generated at 2022-06-23 18:16:47.542109
# Unit test for function get_os_user
def test_get_os_user():
    """Test :func:`~flutils.pathutils.get_os_user`."""
    from unittest.mock import patch

    with patch('flutils.pathutils.getpass.getuser') as mock:
        mock.return_value = 'test_user'
        user = get_os_user()
        assert user.pw_name == 'test_user'



# Generated at 2022-06-23 18:16:56.014367
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    func_name = 'get_os_user'

# Generated at 2022-06-23 18:17:02.124829
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    path = Path(tempfile.mkdtemp())
    file = path.joinpath('test')
    file.touch()
    dir = path.joinpath('testdir')
    dir.mkdir()
    dirfile = dir.joinpath('testdirfile')
    dirfile.touch()

    path_absent(dir)
    assert file.exists() is True
    assert dir.exists() is False
    assert dirfile.exists() is False

    path_absent(file)
    assert file.exists() is False
    assert path.exists() is True

    path_absent(path)
    assert path.exists() is False



# Generated at 2022-06-23 18:17:09.880348
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp_dir:
        with TemporaryDirectory(dir=temp_dir) as temp_dir_two:
            with TemporaryDirectory(dir=temp_dir_two) as temp_dir_three:
                test_file = Path(temp_dir_three, 'test_file')
                test_file.touch()
                path_absent(test_file)
                assert not test_file.exists()
                path_absent(temp_dir_two)
                assert not temp_dir_two.exists()



# Generated at 2022-06-23 18:17:20.762421
# Unit test for function chown
def test_chown():
    path = Path('/foo/bar/baz')
    path.mkdir(parents=True)
    os.chown(path.as_posix(), 1, 1)
    assert os.stat(path.as_posix()).st_uid == 1
    assert os.stat(path.as_posix()).st_gid == 1
    chown(path)
    assert os.stat(path.as_posix()).st_uid == os.getuid()
    assert os.stat(path.as_posix()).st_gid == os.getgid()
    chown(path, str(os.getuid()), str(os.getgid()))
    assert os.stat(path.as_posix()).st_uid == os.getuid()

# Generated at 2022-06-23 18:17:32.564780
# Unit test for function chown
def test_chown():
    from flutils.pathutils import directory_present

    def test_chown_user(user: str = None):
        with directory_present('/tmp/flutils.tests.osutils.txt') as tmp_path:
            from flutils.osutils import get_os_user
            uid = get_os_user(user).pw_uid
            assert os.stat(tmp_path.as_posix()).st_uid == uid

    def test_chown_group(group: str = None):
        with directory_present('/tmp/flutils.tests.osutils.txt') as tmp_path:
            from flutils.osutils import get_os_group
            gid = get_os_group(group).gr_gid
            assert os.stat(tmp_path.as_posix()).st_gid

# Generated at 2022-06-23 18:17:34.087862
# Unit test for function get_os_user
def test_get_os_user():
    assert 'foo' == get_os_user('foo').pw_name


# Generated at 2022-06-23 18:17:38.222952
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    assert get_os_user(1000) == pwd.getpwuid(1000)
    assert get_os_user() == pwd.getpwnam(getpass.getuser())



# Generated at 2022-06-23 18:17:47.037425
# Unit test for function path_absent
def test_path_absent():
    test_file = '/tmp/flutils_test_file'
    test_dir = '/tmp/flutils_test_dir'
    test_file_path = Path(test_file)
    test_dir_path = Path(test_dir)

    def _create_file():
        with open(test_file, 'w') as fh:
            fh.write('Hello World!')
        assert os.path.isfile(test_file) is True

    def _create_dir():
        test_dir_path.mkdir()
        assert os.path.isdir(test_dir) is True

    def _create_file_in_dir():
        _create_dir()
        _create_file()
        shutil.move(test_file, test_dir)

# Generated at 2022-06-23 18:18:00.064051
# Unit test for function chmod
def test_chmod():
    # Create a temporary file.
    with tempfile.NamedTemporaryFile() as tmp_file:
        # Change the mode of the file.
        chmod(tmp_file.name, mode_file=0o666)
        # Get the mode of the file.
        mode_file = cast(Peeker, Peeker(tmp_file.name)).mode

        # Change the mode of the directory that contains the file.
        chmod(tmp_file.name, mode_dir=0o777, include_parent=True)
        # Get the mode of the directory that contains the file.
        mode_dir = cast(Peeker, Peeker(tmp_file.name)).parent.mode

        # Assert the mode of the file.
        assert mode_file == 0o666

        # Assert the mode of the directory that contains the file.

# Generated at 2022-06-23 18:18:12.685394
# Unit test for function chown
def test_chown():
    """Test function chown.
    """
    import shutil

    try:
        import pytest
    except ImportError:
        raise ImportError(
            "Pytest is not available!  Cannot run unit tests without it."
        )
    else:
        import tempfile
        import pytest
        import flutils.pathutils

        TMPDIR = tempfile.TemporaryDirectory()
        GID = os.getgid()
        UID = os.getuid()
        USER = getpass.getuser()
        GROUP = getpass.getuser()
        _PATH = os.path.join(TMPDIR.name, USER)
        tmp_path = Path(_PATH)
        tmp_path.mkdir()

        def test_os_exception():
            with pytest.raises(OSError):
                flutils.path

# Generated at 2022-06-23 18:18:14.214635
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')


# Generated at 2022-06-23 18:18:20.350244
# Unit test for function path_absent
def test_path_absent():
    with pytest.raises(TypeError):
        path_absent(['~/tmp/test_dir'])

    str(path_absent('~/tmp'))

    path_absent('~/tmp/test_dir')

    mkdir(Path('~/tmp/test_dir'))

    path_absent('~/tmp')
    path_absent('~/tmp/test_dir')



# Generated at 2022-06-23 18:18:23.163524
# Unit test for function get_os_group
def test_get_os_group():
    """Unitest for function get_os_group"""
    # Insert code here
    return


# Generated at 2022-06-23 18:18:32.918854
# Unit test for function chown
def test_chown():
    """Tests for function chown."""
    # pathlib doesn't allow normalization of a path to a symbolic link.
    if sys.platform == 'darwin':
        path = PosixPath('/etc/resolv.conf')
    else:
        path = PosixPath('/etc/resolv.conf')
    # pylint: disable=protected-access
    if path._flavour == PosixPath._flavour:
        return True
    else:
        user = getpass.getuser()
        group = getpass.getuser()
        owner = path.stat().st_uid
        group = path.stat().st_gid
        if owner == 0 or group == 0:
            return True
        else:
            return False



# Generated at 2022-06-23 18:18:43.814879
# Unit test for function normalize_path

# Generated at 2022-06-23 18:18:52.562706
# Unit test for function chmod
def test_chmod():
    path = Path('/tmp/a/b/c/d/e.txt')
    path.parent.mkdir(parents=True, exist_ok=False)
    path.touch()

    assert path.stat().st_mode & 0o777 == 0o600
    assert path.parent.stat().st_mode & 0o777 == 0o700

    chmod(path, mode_file=0o640, mode_dir=0o750)

    assert path.stat().st_mode & 0o777 == 0o640
    assert path.parent.stat().st_mode & 0o777 == 0o750

    path.unlink()
    path.parent.rmdir()



# Generated at 2022-06-23 18:18:56.887690
# Unit test for function chown
def test_chown():
    test_path = os.path.expanduser('~/tmp/flutils.tests.osutils.txt')
    chown(test_path, user='foo', group='bar')
    assert True



# Generated at 2022-06-23 18:19:05.872700
# Unit test for function chmod
def test_chmod():
    """Unit test for `chmod`."""
    import unittest

    import os

    class Test_chmod(unittest.TestCase):
        def test_is_file(self):
            """Test changing the mode of a file."""
            self.assertEqual(os.stat('~/tmp/flutils.tests.osutils.txt').st_mode & 0o777, 0o600)
            self.assertIsNone(chmod('~/tmp/flutils.tests.osutils.txt', mode_file=0o660))
            self.assertEqual(os.stat('~/tmp/flutils.tests.osutils.txt').st_mode & 0o777, 0o660)

        def test_is_dir(self):
            """Test changing the mode of a directory."""

# Generated at 2022-06-23 18:19:12.945368
# Unit test for function path_absent
def test_path_absent():
    target_dir = normalize_path(os.path.join('~', 'tmp')).as_posix()
    if not os.path.exists(target_dir):
        os.mkdir(target_dir)
    target = normalize_path(os.path.join(target_dir, 'target')).as_posix()
    if not os.path.exists(target):
        with open(target, 'w') as f:
            f.write('Hello world!')
    path_absent(target_dir)
    assert not os.path.exists(target_dir)
    assert not os.path.exists(target)



# Generated at 2022-06-23 18:19:15.437672
# Unit test for function directory_present
def test_directory_present():
    test_input_1 = '~/tmp/test_path'
    test_expected_1 = '~/tmp/test_path'
    test_output_1 = directory_present(test_input_1)
    assert test_output_1.as_posix() == test_expected_1



# Generated at 2022-06-23 18:19:17.028656
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'char device'

# Generated at 2022-06-23 18:19:22.779109
# Unit test for function path_absent
def test_path_absent():
    """Unit test for ``path_absent``."""
    from collections import namedtuple
    from tempfile import NamedTemporaryFile

    PathData = namedtuple('PathData', ['item', 'perm'])


# Generated at 2022-06-23 18:19:26.975254
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    from flutils.pathutils import normalize_path
    from pathlib import Path
    assert normalize_path('~/tmp/foo/../bar') == Path('~/tmp/foo/../bar').expanduser()
test_normalize_path()



# Generated at 2022-06-23 18:19:34.848872
# Unit test for function directory_present
def test_directory_present():
    """
    Test the directory present method
    """

    # create temp folder and file
    directory_present('/tmp/flutils_test')
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Get the path of the temp folder and write file
        path = directory_present(tmpdirname)
        tmpfile = path / 'temp_file.txt'
        tmpfile.write_text('Hello World')
        assert tmpfile.is_file()
        assert tmpfile.exists()
        assert tmpfile.is_dir() == False
        # create temp folder with mode
        tmpdirname = tempfile.mkdtemp()
        tmpdir = directory_present(tmpdirname, mode=0o700)
        assert tmpdir.exists()
        assert tmpdir.is_dir()
        # create

# Generated at 2022-06-23 18:19:38.755316
# Unit test for function exists_as
def test_exists_as():
    from . import TEST_DIR, TEST_FILE
    assert exists_as(TEST_FILE) == 'file'
    assert exists_as(TEST_DIR) == 'directory'
    assert exists_as(TEST_DIR + '/foo') == ''



# Generated at 2022-06-23 18:19:44.299705
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError) as exc_info:
        get_os_user(99)
    assert 'is not a valid uid for this operating system' \
        in str(exc_info.value)



# Generated at 2022-06-23 18:19:45.473229
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user('root')
    get_os_user(get_os_user().pw_uid)
    get_os_user(None)



# Generated at 2022-06-23 18:19:54.134903
# Unit test for function path_absent
def test_path_absent():
    from shutil import rmtree
    from tempfile import mkdtemp
    from tests.pathutils.test_utils import _get_test_path_make_dir
    from tests.pathutils.test_utils import _get_test_path_make_file

    tmp_dir = mkdtemp()

# Generated at 2022-06-23 18:20:00.704710
# Unit test for function directory_present
def test_directory_present():
    def test():
        from flutils.pathutils import directory_present
        test_path = Path("/tmp/test_path")
        directory_present("/tmp/test_path")
        if not test_path.is_dir():
            print("The path %r was not created as", test_path)
            return False
        # test_path.unlink()
        return True
    return test



# Generated at 2022-06-23 18:20:05.071886
# Unit test for function chown
def test_chown():
    path = '~/tmp/flutils.tests/osutils.txt'
    chown(path)

    # Supports a glob pattern
    chown('~/tmp/**')

    # To change ownership of all the directory's immediate contents
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-23 18:20:05.547681
# Unit test for function get_os_user
def test_get_os_user():
    return True



# Generated at 2022-06-23 18:20:14.343510
# Unit test for function directory_present
def test_directory_present():
    tmp_dir = directory_present('~/tmp/test_directory_present')
    assert tmp_dir.exists() is True
    assert tmp_dir.is_dir() is True

    try:
        directory_present('~/tmp/test_directory_present/file.txt')
    except FileExistsError:
        assert True
    else:
        assert False

    with tmp_dir.open('w') as f:
        f.write('test')

    try:
        directory_present('~/tmp/test_directory_present')
    except FileExistsError:
        assert True
    else:
        assert False

    tmp_dir.unlink()


# Generated at 2022-06-23 18:20:22.664005
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    from grp import struct_group
    from pwd import getpwnam

    user = getpwnam('test_user')
    group = get_os_group(user.pw_gid)

    assert isinstance(group, struct_group), \
        'Function get_os_group did not return a group object.'



# Generated at 2022-06-23 18:20:34.599205
# Unit test for function normalize_path
def test_normalize_path():
    p = normalize_path('~/tmp/foo/../bar')
    assert p == Path(os.path.expanduser('~/tmp/bar'))

    p = normalize_path('${HOME}/tmp/foo/../bar')
    assert p == Path(os.path.expandvars('${HOME}/tmp/bar'))

    p = normalize_path('../tmp/foo/../bar')
    assert p == Path('../tmp/bar')

    p = normalize_path('../tmp/foo/../bar')
    assert p == Path('../tmp/bar')

    p = normalize_path('foo/../bar')
    assert p == Path('bar')

    p = normalize_path('foo//../bar')
    assert p == Path('bar')


# Generated at 2022-06-23 18:20:35.179297
# Unit test for function find_paths
def test_find_paths():
    return None



# Generated at 2022-06-23 18:20:35.636556
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:20:47.597995
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from flutils.pathutils import directory_present
    from flutils.systemutils import get_umask
    from flutils.systemutils import set_umask

    with TemporaryDirectory() as td:
        tdir = Path(td)
        rpath = tdir / 'test/123'
        rpath.mkdir(parents=True)

        umask_backup = get_umask()

# Generated at 2022-06-23 18:20:52.778031
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_name == 'root'
    with pytest.raises(OSError):
        get_os_user('does-not-exist')
    with pytest.raises(OSError):
        get_os_user(100000)



# Generated at 2022-06-23 18:21:01.290344
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import (
        chmod,
        Path,
    )

    from . import TEST_DIR

    from .osutils import (
        file_present,
        remove_file,
    )

    from .subprocess_utils import subprocess_run

    with remove_file(TEST_DIR / 'file.txt') as file_:
        assert file_present(file_) is False

        subprocess_run(
            ['/usr/bin/env', 'touch', file_],
            check=True
        )

        assert file_present(file_) is True
        assert Path(file_).stat().st_mode != 0o600

        chmod(file_)
        assert Path(file_).stat().st_mode == 0o600


# Generated at 2022-06-23 18:21:11.058409
# Unit test for function directory_present
def test_directory_present():
    import os
    import shutil
    from flutils.pathutils import (
        directory_present,
        exists_as,
        normalize_path,
    )
    from testfixtures import LogCapture
    from pathlib import (
        Path,
        PosixPath,
        WindowsPath,
    )
    from typing import TYPE_CHECKING

    if TYPE_CHECKING:
        from testfixtures.logcapture import LogCapture

    # Temporary directory to run tests in.
    temp_dir = Path('/tmp/test_directory_present')
    temp_dir.mkdir(exist_ok=True)

    # Unit test the function with a path that already exists
    # and is a directory.
    test_path = temp_dir / 'test_directory_present_1'

# Generated at 2022-06-23 18:21:11.935927
# Unit test for function directory_present
def test_directory_present():
    pass # TODO



# Generated at 2022-06-23 18:21:17.365748
# Unit test for function get_os_user
def test_get_os_user():
    print('Testing function get_os_user')
    user_obj = get_os_user()
    print(user_obj)
    assert user_obj.pw_name == getpass.getuser(), \
        'The user object\'s uid is not the same as the local system.'



# Generated at 2022-06-23 18:21:26.808404
# Unit test for function chown
def test_chown():
    from flutils.pathutils import (
        chown,
        get_os_group,
        get_os_user,
        path_absent,
        write_file,
    )
    from flutils.osutils import is_root

    username = getpass.getuser()

    # Change ownership/group of a non-existent file
    path = Path().cwd() / 'flutils.tests.pathutils.txt'
    path_absent(path)
    chown(path)

    write_file(path)
    assert path.exists() is True
    assert path.owner() == username

    # Change ownership/group of a file
    chown(path, '-1', is_root() is True and 'wheel' or '')
    assert path.owner() == username


# Generated at 2022-06-23 18:21:30.124828
# Unit test for function get_os_user
def test_get_os_user():
    try:
        pwd.getpwnam(getpass.getuser())
    except KeyError:
        assert get_os_user() == pwd.struct_passwd(pw_name='root', pw_passwd='*', pw_uid=0, pw_gid=0, pw_gecos='root', pw_dir='/root', pw_shell='/bin/bash')
    else:
        assert True



# Generated at 2022-06-23 18:21:43.113406
# Unit test for function find_paths
def test_find_paths():
    """ """
    test_directory = Path(__file__).parent.parent / 'tests'
    main_test_directory = test_directory / 'tmp'
    main_test_directory.mkdir(exist_ok=True)
    sub_test_directory = main_test_directory / 'tests'
    sub_test_directory.mkdir(exist_ok=True)

    (main_test_directory / 'test_file_1').touch()
    (main_test_directory / 'test_file_2').touch()
    (sub_test_directory / 'test_file_3').touch()

    paths_found = [path.as_posix() for path in find_paths(main_test_directory / '**') if path.is_file()]

# Generated at 2022-06-23 18:21:52.890274
# Unit test for function exists_as
def test_exists_as():
    tmpfile = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tmp', 'exists_as_test'))
    os.mkdir(tmpfile)
    assert exists_as(tmpfile) == 'directory'
    tmpfile += '/exists_as_test'
    open(tmpfile, 'w').close()
    assert exists_as(tmpfile) == 'file'
    os.remove(tmpfile)
    assert exists_as(tmpfile) == ''
    os.rmdir(os.path.dirname(tmpfile))
    assert exists_as(tmpfile) == ''



# Generated at 2022-06-23 18:21:58.845085
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    assert list(find_paths('~/tmp/*')) == [PosixPath('/home/test_user/tmp/file_one'), PosixPath('/home/test_user/tmp/dir_one')]
    assert list(find_paths('~/tmp/file*')) == [PosixPath('/home/test_user/tmp/file_one')]
    assert list(find_paths('~/tmp/**/file_one')) == [PosixPath('/home/test_user/tmp/dir_one/file_one')]

# Generated at 2022-06-23 18:22:11.740366
# Unit test for function chmod
def test_chmod():
    import os

    def test_dir(exists: bool, mode: Optional[int] = None):
        import stat
        import os

        dir_exists = os.path.exists('/tmp/flutils.tests.osutils/')

        if mode is None:
            mode = 0o700

        if exists is False:
            assert dir_exists is False
        else:
            assert dir_exists is True
            assert stat.S_IMODE(os.stat('/tmp/flutils.tests.osutils/').st_mode) == mode

    test_dir(False)
    chmod('/tmp/flutils.tests.osutils/', include_parent=True)
    test_dir(False)
    os.makedirs('/tmp/flutils.tests.osutils/')

# Generated at 2022-06-23 18:22:18.549323
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group() == grp.getgrgid(os.getgid())
    assert get_os_group('root') == grp.getgrnam('root')
    assert get_os_group('0') == grp.getgrgid(0)
    assert get_os_group('-1') == grp.getgrgid(os.getgid())
    assert get_os_group('nobody') == grp.getgrnam('nobody')
    assert get_os_group('65534') == grp.getgrgid(65534)



# Generated at 2022-06-23 18:22:29.088297
# Unit test for function find_paths
def test_find_paths():
    from flutils.tests.pathutils import TEST_DIR
    from pathlib import Path

    Path(TEST_DIR).mkdir(exist_ok=True)

    for file in ('test_file_one', 'test_file_two', 'test_file_three'):
        Path(TEST_DIR).joinpath(file).touch()

    for dir in ('test_dir_one', 'test_dir_two', 'test_dir_three'):
        Path(TEST_DIR).joinpath(dir).mkdir()


# Generated at 2022-06-23 18:22:35.202890
# Unit test for function get_os_user
def test_get_os_user():
    real_uname = getpass.getuser()
    assert real_uname == get_os_user().pw_name

    real_uid = pwd.getpwnam(real_uname).pw_uid
    assert real_uid == get_os_user().pw_uid

    real_gid = pwd.getpwnam(real_uname).pw_gid
    assert real_gid == get_os_user().pw_gid



# Generated at 2022-06-23 18:22:38.780783
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/foo/../bar') == Path('/home/test_user/bar')
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')



# Generated at 2022-06-23 18:22:48.009158
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user, get_os_group
    from getpass import getuser
    from os import getuid
    from sys import platform
    
    assert getuser() == get_os_user().pw_name
    assert getuid() == get_os_user().pw_uid
    assert platform == 'linux' or platform == 'darwin'
    if platform == 'linux':
        pw_name = 'root'
    else:
        pw_name = 'wheel'
    assert get_os_user(name=pw_name).pw_name == pw_name
    assert get_os_group(name=pw_name).gr_name == pw_name
    assert get_os_user(name=get_os_user().pw_gid).pw_name

# Generated at 2022-06-23 18:22:48.922697
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/') == 'directory'



# Generated at 2022-06-23 18:22:50.433094
# Unit test for function exists_as
def test_exists_as():
    ok_(exists_as('~/tmp') == 'directory')
    is_(exists_as('~/does_not_exist'), '')



# Generated at 2022-06-23 18:23:01.225034
# Unit test for function get_os_user
def test_get_os_user():
    # USER_ONE
    USER_ONE_NAME = 'fluserone'
    USER_ONE_UID = 2100
    USER_ONE_GID = 2300
    USER_ONE_GECOS = 'Foo Bar'
    USER_ONE_HOME = '/home/fluserone'
    USER_ONE_SHELL = '/usr/local/bin/bash'

    USER_ONE_UID_STR = str(USER_ONE_UID)
    USER_ONE_GID_STR = str(USER_ONE_GID)


# Generated at 2022-06-23 18:23:10.983665
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'test_path'
    chown(path, user='-1', group='-1')
    assert Path(path).owner() == os.getlogin()
    assert Path(path).group() == grp.getgrgid(os.getgid()).gr_name
    chown(path, user=os.getlogin(), group=grp.getgrgid(os.getgid()).gr_name)
    assert Path(path).owner() == os.getlogin()
    assert Path(path).group() == grp.getgrgid(os.getgid()).gr_name



# Generated at 2022-06-23 18:23:18.592023
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test get_os_group function."""
    group = get_os_group('test_group')
    assert group.gr_gid == TEST_GROUP_GID

    with pytest.raises(OSError):
        get_os_group('test_group_invalid')

    with pytest.raises(OSError):
        get_os_group(TEST_GROUP_GID_INVALID)



# Generated at 2022-06-23 18:23:23.951139
# Unit test for function find_paths
def test_find_paths():
    paths = find_paths('./tests/data/*')
    assert isinstance(paths, collections.abc.Generator)
    assert [p for p in paths] == [
        Path('tests/data/file_one'),
        Path('tests/data/file_two'),
        Path('tests/data/dir_one'),
        Path('tests/data/dir_two')
    ]



# Generated at 2022-06-23 18:23:30.530876
# Unit test for function exists_as
def test_exists_as():
    # import re
    import os
    from pathlib import Path

    current = Path().cwd()

    path = current.joinpath('exists_as')
    if path.exists():
        if path.is_dir():
            for file_path in path.iterdir():
                os.unlink(file_path.as_posix())
            os.rmdir(path.as_posix())
        elif path.is_file():
            os.unlink(path.as_posix())

    assert exists_as(path.as_posix()) == ''

    path.mkdir()

    assert exists_as(path.as_posix()) == 'directory'

    test_file = path.joinpath('file1')
    test_file.touch(mode=0o700)


# Generated at 2022-06-23 18:23:40.940027
# Unit test for function chown
def test_chown():
    path = Path().home() / 'tmp' / 'flutils.tests.osutils.txt'
    path.write_text('whatever')
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    chown(path, user, group)
    uid = os.stat(path.as_posix()).st_uid
    gid = os.stat(path.as_posix()).st_gid
    pwd.getpwuid(uid).pw_name == user
    grp.getgrgid(gid).gr_name == group



# Generated at 2022-06-23 18:23:47.260916
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for the get_os_group function."""
    assert isinstance(get_os_group(), grp.struct_group)
    assert isinstance(get_os_group(get_os_user().pw_name), grp.struct_group)
    assert isinstance(get_os_group(get_os_group().gr_name), grp.struct_group)
    assert isinstance(get_os_group(get_os_group().gr_gid), grp.struct_group)
    with pytest.raises(OSError) as excinfo:
        get_os_group('foo_bar')
    assert 'is not a valid "group name" for' in str(excinfo.value)
    with pytest.raises(OSError) as excinfo:
        get_os_group('-1')

# Generated at 2022-06-23 18:23:49.070341
# Unit test for function exists_as
def test_exists_as():
    path = '~/tmp/'
    assert exists_as(path) == 'directory'



# Generated at 2022-06-23 18:23:50.540941
# Unit test for function directory_present
def test_directory_present():
    return directory_present



# Generated at 2022-06-23 18:24:01.081655
# Unit test for function chmod
def test_chmod():
    import glob
    import os
    import os.path
    import shutil
    import stat
    import tempfile
    import unittest

    class chmodTestCase(unittest.TestCase):
        TEST_DIR = None

        @classmethod
        def setUpClass(cls):
            cls.TEST_DIR = tempfile.mkdtemp(suffix='-flutils-test')

        @classmethod
        def tearDownClass(cls):
            del cls.TEST_DIR
            cls.TEST_DIR = None
            shutil.rmtree(cls.TEST_DIR)

        def setUp(self):
            os.chmod(self.TEST_DIR, 0o700)
            dirpath = os.path.join(self.TEST_DIR, 'nested')
           

# Generated at 2022-06-23 18:24:07.317898
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/foo')
    assert path.as_posix() == os.path.normpath(
        os.path.normcase(os.path.expandvars(os.path.expanduser('~/tmp/foo')))
    ) or path.as_posix() == os.path.normpath(
        os.path.normcase(os.path.expandvars(os.path.expanduser('\\cygwin64/home/test_user/tmp/foo')))
    )


#: :obj:`list`: A list of valid "login names" for this system.
#:
#: Populated with :obj:`pwd.getpwall() <pwd.getpwall>`.
USERS: Optional[List[_STR_OR_INT]] = None



# Generated at 2022-06-23 18:24:15.877906
# Unit test for function directory_present
def test_directory_present():
    pathutils.directory_present('~/tmp/flutils.tests.pathutils.dir_present')
    home = Path('~').expanduser()
    path = Path('~/tmp/flutils.tests.pathutils.dir_present')
    path_exists_as = exists_as(path)
    assert path_exists_as == 'directory'
    assert path.is_dir() is True
    assert home.joinpath('tmp/flutils.tests.pathutils.dir_present').exists()
    assert path.as_posix().startswith(home.as_posix()) is True



# Generated at 2022-06-23 18:24:26.147234
# Unit test for function get_os_group
def test_get_os_group():
    """Testing the function ``get_os_group``."""
    assert get_os_group().gr_name == grp.getgrgid(os.getgid()).gr_name
    assert get_os_group().gr_gid == grp.getgrgid(os.getgid()).gr_gid
    assert get_os_group().gr_passwd == grp.getgrgid(os.getgid()).gr_passwd
    assert get_os_group().gr_mem == grp.getgrgid(os.getgid()).gr_mem

    assert get_os_group(os.getgid()).gr_name == grp.getgrgid(os.getgid()).gr_name
    assert get_os_group(os.getgid()).gr_g

# Generated at 2022-06-23 18:24:36.210273
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present, exists_as
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        path = directory_present(
            os.path.join(temp_dir, 'foo', 'bar')
        )

        assert path.exists() is True
        assert exists_as(path) == 'directory'
        path.rmdir()

        assert path.exists() is False

        path = directory_present(
            os.path.join(temp_dir, 'bar', 'foo')
        )

        assert path.exists() is True
        assert exists_as(path) == 'directory'
        path.rmdir()

        assert path.exists() is False



# Generated at 2022-06-23 18:24:39.786851
# Unit test for function find_paths
def test_find_paths():
    paths = find_paths('~/tmp/*')
    for path in paths:
        print('path:', path)
    assert True is True

# Generated at 2022-06-23 18:24:49.070107
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        test_dir = tmpdir_path / 'test_dir'
        test_file = tmpdir_path / 'test_file'
        test_link = tmpdir_path / 'test_link'

        # ensure test directory does not exist
        path_absent(test_dir)

        # ensure test file does not exist
        path_absent(test_file)

        # ensure test link does not exist
        path_absent(test_link)

        test_file.write_text('Test contents.')
        test_file.chmod(0o600)

        os.symlink(test_file, test_link)

        test_dir.mkdir(mode=0o700)
        test_dir_file1

# Generated at 2022-06-23 18:25:01.045385
# Unit test for function chown
def test_chown():

    os.chdir(os.path.dirname(__file__))
    shutil.rmtree(os.path.abspath('test_dir/test_chown/'), ignore_errors=True)
    os.makedirs(os.path.abspath('test_dir/test_chown/'))
    user = getpass.getuser()
    group = grp.getgrgid(os.stat('/').st_gid).gr_name

    #test_1
    chown(os.path.abspath('test_dir/test_chown/'), user, group)
    stat_info = os.stat(os.path.abspath('test_dir/test_chown/'))
    assert stat_info.st_uid == os.getuid()
    assert stat_info.st

# Generated at 2022-06-23 18:25:10.664563
# Unit test for function get_os_group
def test_get_os_group():
    try:
        get_os_group()
    except (OSError, KeyError):
        pass
    else:
        assert False, 'Must provide a valid group name.'
    try:
        get_os_group('-1')
    except (OSError, KeyError):
        pass
    else:
        assert False, 'Must provide a valid group name.'
    try:
        get_os_group(0o0777)
    except (OSError, KeyError):
        pass
    else:
        assert False, 'Must provide a valid group gid.'
    group = get_os_group('bar')
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_gid == 2001
    assert group.gr_mem == ['foo']



# Generated at 2022-06-23 18:25:17.729895
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user('foo')
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == 'foo'
    assert user.pw_passwd == '********'
    assert user.pw_uid == 1001
    assert user.pw_gid == 2001
    assert user.pw_gecos == 'Foo Bar'
    assert user.pw_dir == '/home/foo'
    assert user.pw_shell == '/usr/local/bin/bash'



# Generated at 2022-06-23 18:25:28.895390
# Unit test for function find_paths
def test_find_paths():
    """Unit tests for function find_paths"""
    tmp_dir = Path(tempfile.gettempdir()) / 'test_find_paths'
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_1 = tmp_dir / 'tmp_1.txt'
    tmp_1.touch()
    tmp_2 = tmp_dir / 'tmp_2.txt'
    tmp_2.touch()
    tmp_3 = tmp_dir / 'tmp_3.txt'
    tmp_3.touch()
    tmp_4 = tmp_dir / 'tmp_4.txt'
    tmp_4.touch()
    tmp_5 = tmp_dir / 'tmp_5.txt'
    tmp_5.touch()
    tmp_6 = tmp_dir / 'tmp_6.txt'
    tmp

# Generated at 2022-06-23 18:25:32.473956
# Unit test for function get_os_user
def test_get_os_user():
    from tests.test_pathutils import test_get_os_user
    return test_get_os_user.run_test('get_os_user', globals())

# Generated at 2022-06-23 18:25:35.607376
# Unit test for function path_absent
def test_path_absent():
    path = './tmp/path_absent'
    path_absent(path)
    assert os.path.exists(path) is False

# Generated at 2022-06-23 18:25:45.678136
# Unit test for function path_absent
def test_path_absent():
    """Test case for function: path_absent."""
    base = Path(__file__).parent
    base = base.absolute()
    path = base / 'path_absent_test'
    path.mkdir()
    path1 = path / 'dir1'
    path1.mkdir()
    path2 = path / 'dir2'
    path2.mkdir()
    path3 = path / 'dir3'
    path3.mkdir()
    path11 = path1 / 'dir11'
    path11.mkdir()
    path21 = path2 / 'dir21'
    path21.mkdir()
    path31 = path3 / 'dir31'
    path31.mkdir()
    path12 = path1 / 'dir12'
    path12.mkdir()

# Generated at 2022-06-23 18:25:52.187213
# Unit test for function normalize_path
def test_normalize_path():
    dirname = os.path.dirname(__file__)
    filename = 'normalize_path.test'
    path = os.path.join(
        os.path.abspath(os.path.normcase(dirname)),
        os.path.normcase(filename),
    )
    path = Path(path)
    assert normalize_path(path) == path

# Generated at 2022-06-23 18:26:01.297394
# Unit test for function chmod
def test_chmod():
    import pytest
    from flutils.pathutils import chmod

    # Set up test data, each entry is a tuple
    # of the form (path, stat) where:
    # path is the path to test
    # stat is the expected stat object to return
    test_data = [
        ('~/tmp/flutils.tests.osutils.txt', 0o660),
        ('~/tmp/flutils.tests.osutils.tmp', 0o770),
        ('~/tmp/**', 0o770),
        ('~/tmp/*', (0o600, 0o700)),
    ]

    test_results = deque()
    for xpath, xmode in test_data:
        abs_path = Path(xpath).expanduser().resolve()
        xpath = normalize_path(xpath)

# Generated at 2022-06-23 18:26:10.867329
# Unit test for function exists_as
def test_exists_as():
    directory_present('~/.flutils/tmp')
    directory_present('~/.flutils/bin')
    file_present('~/.flutils/bin/foo.txt')
    file_present('~/.flutils/bin/foo2.txt')
    file_present('~/.flutils/bin/foo3.txt')
    file_present('~/.flutils/bin/foo4.txt')
    file_present('~/.flutils/bin/foo5.txt')
    file_present('~/.flutils/bin/foo6.txt')
    file_present('~/.flutils/tmp/foo7.txt')
    file_present('~/.flutils/tmp/foo8.txt')
    file_present('~/.flutils/tmp/foo9.txt')

# Generated at 2022-06-23 18:26:11.820686
# Unit test for function chown
def test_chown():
    assert True




# Generated at 2022-06-23 18:26:23.102028
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_uid == 0
    assert get_os_user(get_os_user('root').pw_uid).pw_uid == get_os_user(
        'root').pw_uid
    assert get_os_user(get_os_user().pw_name).pw_name == get_os_user().pw_name
    with pytest.raises(OSError):
        get_os_user(100)
    with pytest.raises(OSError):
        get_os_user('test_user_does_not_exist')



# Generated at 2022-06-23 18:26:25.605341
# Unit test for function get_os_user
def test_get_os_user():
    """Function to run unit tests on get_os_user."""
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-23 18:26:34.712475
# Unit test for function directory_present
def test_directory_present():
    _path_exists_as = exists_as(temp_dir)
    if _path_exists_as == '':
        _path_exists_as = 'directory'
    assert directory_present(temp_dir).as_posix() == temp_dir
    assert os.path.isdir(temp_dir) is True
    assert exists_as(temp_dir) == _path_exists_as
    assert chown(temp_dir, user='-1').as_posix() == temp_dir
    assert chown(temp_dir, group='-1').as_posix() == temp_dir
    assert exists_as(temp_dir) == _path_exists_as