

# Generated at 2022-06-23 18:16:33.123311
# Unit test for function get_os_user
def test_get_os_user():
    # Set a valid uid that is known to exist.
    uid = get_os_user().pw_uid
    try:
        pwd.getpwuid(uid)
    except KeyError:
        # Set the uid to a valid one.
        uid = 0
    # Should be no error raised.
    assert get_os_user(uid) is not None
    # Set the uid to a value that does not exist.
    uid += 1
    # Expect an OSError to be raised.
    with pytest.raises(OSError):
        get_os_user(uid)



# Generated at 2022-06-23 18:16:43.616603
# Unit test for function chown
def test_chown():
    import pwd
    import grp
    import os
    import tempfile
    import shutil
    import platform
    import flutils.pathutils as pathutils

    # Setup
    tmp_dir = tempfile.mkdtemp()
    nonexistent = os.path.join(tmp_dir, 'nonexistent')
    os.mkdir(nonexistent)

    test_file = os.path.join(nonexistent, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test file')

    test_file2 = os.path.join(nonexistent, 'test_file2')
    with open(test_file2, 'w') as f:
        f.write('test file 2')


# Generated at 2022-06-23 18:16:54.287096
# Unit test for function get_os_group
def test_get_os_group():
    # This function is used as a unit test for get_os_group.
    # It will not be executed like a normal unit test.
    # pylint: disable=missing-class-docstring
    # pylint: disable=missing-function-docstring
    # pylint: disable=no-self-use
    # pylint: disable=too-few-public-methods
    # pylint: disable=unused-argument

    from unittest import TestCase
    from unittest import skipIf
    from unittest.mock import patch
    from unittest.mock import Mock
    from pathlib import Path
    from grp import struct_group
    from sys import version_info as version_info

    # Create a mock struct_group object.

# Generated at 2022-06-23 18:17:05.253792
# Unit test for function get_os_group
def test_get_os_group():
    """Validate that a given "group name" returns a valid
    :obj:`struct_group <grp>` object.
    """
    from flutils.testing.helpers import get_func_arguments
    from flutils.pathutils import get_os_group
    args = get_func_arguments(get_os_group)
    args.pop('name')
    ret = get_os_group('bar')
    assert isinstance(ret, grp.struct_group)
    assert ret.gr_name == 'bar'
    assert ret.gr_passwd == '*'
    assert ret.gr_gid == 2001
    assert ret.gr_mem == ['foo']



# Generated at 2022-06-23 18:17:16.561776
# Unit test for function find_paths
def test_find_paths():
    def _mk_tmp_dir(tmp_dir_name: str) -> Path:
        p = Path('~/tmp/' + tmp_dir_name)
        if p.is_dir():
            return p
        os.makedirs(p.as_posix(), mode=0o700)
        return p

    def _mk_tmp_file(
            tmp_file_name: str,
            content: str = '',
            tmp_dir: Optional[Path] = None
    ) -> Path:
        if tmp_dir is None:
            tmp_dir = _mk_tmp_dir('test_find_paths')
        _path = Path(str(tmp_dir) + '/' + tmp_file_name)
        _path.touch()
        if content:
            _path.write_text(content)
       

# Generated at 2022-06-23 18:17:25.072261
# Unit test for function get_os_group
def test_get_os_group():
    import os
    import random
    import getpass
    import grp
    try:
        os.getgrouplist(getpass.getuser())
    except NotImplementedError:
        pass
    else:
        user_group = grp.getgrnam(getpass.getuser())
        assert get_os_group() == user_group

        if os.getuid() == 0:
            try:
                os.getgrouplist(getpass.getuser(), 0)
            except NotImplementedError:
                pass
            else:
                # getgrouplist returns the groups for the current user (0)
                # and the groups for root (0).
                assert get_os_group(0) == grp.getgrgid(0)


# Generated at 2022-06-23 18:17:37.447470
# Unit test for function get_os_group
def test_get_os_group():
    _logger.debug('Test the function: get_os_group')

# Generated at 2022-06-23 18:17:38.113211
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:17:42.219451
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('foo').pw_name == 'foo'
    assert get_os_user('foo').pw_dir == '/home/foo'
    assert get_os_user(1001).pw_uid == 1001
    assert get_os_user(1001).pw_gid == 2001



# Generated at 2022-06-23 18:17:47.569794
# Unit test for function find_paths
def test_find_paths():
    import pytest
    from flutils.pathutils import find_paths

    with pytest.raises(NotImplementedError):
        list(find_paths('/invalid/glob/pattern'))

    paths = list(find_paths('~/tmp/*'))
    assert len(paths) == 2
    assert all([p.is_dir() or p.is_file() for p in paths])

    paths = list(find_paths('~/tmp/**'))
    assert len(paths) == 3



# Generated at 2022-06-23 18:18:00.444247
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/test_directory_present')
    assert path.as_posix() == '%s/test_directory_present' % Path().home()
    assert path.exists() is True

    try:
        directory_present('~/tmp/test_directory_present/*')
    except ValueError:
        pass
    else:
        raise AssertionError('glob pattern not raised.')

    try:
        directory_present('./tmp/test_directory_present')
    except ValueError:
        pass
    else:
        raise AssertionError('relative path not raised.')

    try:
        directory_present('~/tmp/test_directory_present', mode=0o400)
    except PermissionError:
        pass

# Generated at 2022-06-23 18:18:11.217965
# Unit test for function exists_as
def test_exists_as():
    path = Path('/tmp/flutils.tests.osutils.txt')
    if path.exists() is False:
        path.touch()
    assert exists_as(path) == 'file'
    path.unlink()
    path = Path('/tmp/flutils.tests.osutils.dir/flutils.tests.osutils.txt')
    if path.exists() is False:
        path.parent.mkdir()
        path.touch()
    assert exists_as(path.parent) == 'directory'
    path.unlink()
    path.parent.rmdir()
    Path('/tmp/flutils.tests.osutils.dir').rmdir()



# Generated at 2022-06-23 18:18:18.112957
# Unit test for function get_os_user
def test_get_os_user():
    # This unit test is currently commented out because it is not
    # cross platform compatible.
    # assert get_os_user('not_a_username') == pwd.struct_passwd(pw_name='foo', pw_passwd='********', pw_uid=1001, pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo', pw_shell='/usr/local/bin/bash')
    pass



# Generated at 2022-06-23 18:18:29.603809
# Unit test for function directory_present
def test_directory_present():
    from os import getuid
    from os import makedirs
    from os import remove
    from tempfile import TemporaryDirectory
    from pathlib import Path

    test_dir = TemporaryDirectory()
    test_path = Path(test_dir.name) / 'test_dir'
    os_user = pwd.getpwuid(getuid()).pw_name
    os_group = grp.getgrgid(os.getegid()).gr_name

    def clean_path(path: Path) -> None:
        if path.exists() is True:
            if path.is_dir() is True:
                for item in os.listdir(path.as_posix()):
                    item_path = path / item
                    if item_path.is_dir() is True:
                        clean_path(item_path)


# Generated at 2022-06-23 18:18:38.255807
# Unit test for function directory_present
def test_directory_present():
    path1 = directory_present('~/tmp/test_path')
    assert os.path.isdir(path1.as_posix()) is True

    mode = 0o750
    path2 = directory_present('~/tmp/test_path2', mode=mode)
    assert os.path.isdir(path2.as_posix()) is True
    assert oct(os.stat(path2.as_posix()).st_mode)[-3:] == oct(mode)[-3:]

    path3 = directory_present(path2)
    assert path2.as_posix() == path3.as_posix()

    path_glob = Path('~/tmp/*')
    with pytest.raises(ValueError):
        directory_present(path_glob.expanduser())


# Generated at 2022-06-23 18:18:39.733544
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root').pw_uid == 0



# Generated at 2022-06-23 18:18:50.604960
# Unit test for function chmod
def test_chmod():
    path = normalize_path(str(tempfile.mkdtemp()))

# Generated at 2022-06-23 18:18:56.740846
# Unit test for function exists_as
def test_exists_as():
    # That is a directory and a file.
    tmp_dir = Path().cwd() / 'tmp'
    tmp_file = tmp_dir / 'test_file.txt'

    tmp_file.touch()
    assert exists_as(tmp_dir) == 'directory'
    assert exists_as(tmp_dir / '*') == 'directory'
    assert exists_as(tmp_dir / '**') == 'directory'
    assert exists_as(tmp_dir) == 'directory'
    assert exists_as(tmp_file) == 'file'

    # These are all non-existent paths.
    assert exists_as(tmp_dir / 'foo') == ''
    assert exists_as(tmp_dir / 'foo' / 'bar') == ''
    assert exists_as(tmp_file / 'foo') == ''

    # These are

# Generated at 2022-06-23 18:19:00.239879
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = mkdtemp(prefix='test_find_paths')
    Path(tmp_dir).joinpath('foo.txt').touch()
    assert sorted(find_paths(tmp_dir)) == sorted(Path(tmp_dir).glob('*'))
    rmdir(tmp_dir)



# Generated at 2022-06-23 18:19:11.475948
# Unit test for function path_absent
def test_path_absent():  # noqa: D103
    """Test the path_absent function"""
    path_to_absent = _TMP.joinpath('path_to_absent')
    if path_to_absent.exists():
        path_to_absent.unlink()
    assert not path_to_absent.exists()
    path_to_absent.touch()
    assert path_to_absent.is_file()
    path_absent(path_to_absent)
    assert not path_to_absent.exists()

    dir_to_absent = _TMP.joinpath('dir_to_absent')
    if dir_to_absent.exists():
        shutil.rmtree(dir_to_absent)
    assert not dir_to_absent.exists()


# Generated at 2022-06-23 18:19:23.078198
# Unit test for function normalize_path
def test_normalize_path():
    import unittest.mock as mock
    from pathlib import PosixPath, WindowsPath

    from flutils.pathutils import normalize_path


# Generated at 2022-06-23 18:19:31.813732
# Unit test for function get_os_user
def test_get_os_user():
    # The following will raise an OSError if the user name and
    # gid do not exist on the current operating system.
    os_user = get_os_user()
    assert isinstance(os_user.pw_name, str)
    assert isinstance(os_user.pw_passwd, str)
    assert isinstance(os_user.pw_uid, int)
    assert isinstance(os_user.pw_gid, int)
    assert isinstance(os_user.pw_gecos, str)
    assert isinstance(os_user.pw_dir, str)
    assert isinstance(os_user.pw_shell, str)



# Generated at 2022-06-23 18:19:41.679511
# Unit test for function exists_as
def test_exists_as():
    path1 = Path().home()
    path2 = Path().home()/'foo.txt'
    path3 = Path().home()/'foo.txt'
    Path(path2).touch()
    result1 = exists_as(path1)
    result2 = exists_as(path2)
    result3 = exists_as(path3)
    assert result1 == 'directory'
    assert result2 == 'file'
    assert result3 == 'file'
    Path(path2).unlink()
    result1 = exists_as(path1)
    result2 = exists_as(path2)
    assert result1 == 'directory'
    assert result2 == ''
    assert result3 == 'file'



# Generated at 2022-06-23 18:19:51.966285
# Unit test for function get_os_group
def test_get_os_group():
    group_name = get_os_group().gr_name
    group_passwd = get_os_group().gr_passwd
    group_gid = get_os_group().gr_gid
    group_members = get_os_group().gr_mem
    group_object = get_os_group()
    group_object_name = group_object.gr_name
    group_object_passwd = group_object.gr_passwd
    group_object_gid = group_object.gr_gid
    group_object_members = group_object.gr_mem
    assert group_name == get_os_group().gr_name
    assert group_passwd == get_os_group().gr_passwd
    assert group_gid == get_os_group().gr_gid
    assert group_members == get

# Generated at 2022-06-23 18:19:53.853722
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]



# Generated at 2022-06-23 18:20:01.581700
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path(Path('/foo/bar'))
    assert path.as_posix() == '/foo/bar'
    path = normalize_path(Path('/foo//bar'))
    assert path.as_posix() == '/foo/bar'
    path = normalize_path(Path('/foo/./bar'))
    assert path.as_posix() == '/foo/bar'
    path = normalize_path(Path('/foo/../bar'))
    assert path.as_posix() == '/bar'
    path = normalize_path(Path('foo'))
    assert path.as_posix() == os.path.join(os.getcwd(), 'foo')
    path = normalize_path(Path('/foo/~/bar'))
    assert path.as_posix

# Generated at 2022-06-23 18:20:10.305720
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        path = tmpdir / 'test_directory_present'
        result = directory_present(path)
        assert result.as_posix() == path.as_posix()
        assert path.is_dir() is True
        assert path.is_file() is False

        mode = 0o0770
        path = tmpdir / 'test_directory_present_1'
        result = directory_present(path, mode=mode)
        assert result.as_posix() == path.as_posix()
        assert path.is_dir() is True
        assert path.is_file() is False
        assert path.stat().st_mode & 0o777 == mode

        mode = 0o0770
        user = os.getuid()


# Generated at 2022-06-23 18:20:12.645084
# Unit test for function normalize_path
def test_normalize_path():
    """Test flutils.pathutils.normalize_path"""
    path = normalize_path('~/tmp/foo/../bar')
    assert path == Path(os.path.expanduser('~/tmp/bar'))



# Generated at 2022-06-23 18:20:13.609125
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:20:16.817307
# Unit test for function get_os_group
def test_get_os_group():
    """Test function ``get_os_group``.
    """
    assert isinstance(get_os_group(), grp.struct_group)



# Generated at 2022-06-23 18:20:30.037178
# Unit test for function chmod
def test_chmod():
    # Check for NotImplementedError
    # This occurs with `path.glob()` when a pattern results in no
    # matching paths being found.
    with mock.patch('pathlib.Path.glob') as _mock:
        _mock.side_effect = NotImplementedError('Test')
        chmod('~/tmp/*.txt', mode_file=0o644)
        _mock.assert_called_once()

    # Good path, glob pattern, include_parent
    with mock.patch('pathlib.Path.chmod') as _mock:
        chmod('~/tmp/*.txt', mode_file=0o644, include_parent=True)
        assert _mock.call_count == 3

    # Good path, glob pattern

# Generated at 2022-06-23 18:20:37.147471
# Unit test for function exists_as
def test_exists_as():
    # The tmp dir will be deleted by the test framework
    path_dir = directory_present(os.path.join('~', 'tmp', 'test_dir'))
    path_dir.mkdir(mode=0o700)
    # The tmp file will be deleted by the test framework
    path_file = directory_present(os.path.join('~', 'tmp', 'test_file'))
    path_file.touch()

    assert exists_as(path_dir) == 'directory'
    assert exists_as(path_file) == 'file'



# Generated at 2022-06-23 18:20:44.992960
# Unit test for function directory_present
def test_directory_present():
    if exists_as('./test_results/test_directory_present') != 'directory':
        directory_present('./test_results/test_directory_present')
    assert exists_as('./test_results/test_directory_present') == 'directory'
    directory_present('./test_results/test_directory_present')
    assert exists_as('./test_results/test_directory_present') == 'directory'



# Generated at 2022-06-23 18:20:56.774033
# Unit test for function directory_present
def test_directory_present():
    # We need to be able to test this function from an
    # interactive python session (and be able to make
    # use of the imports of module flutils.pathutils)
    # But since flutils is installed into the python
    # environment, the import of flutils, along with
    # the import of flutils.pathutils, will not work
    # when running the tests from the root of the
    # project.  Therefore, we set the PYTHONPATH
    # to the root of the project.  This will allow
    # us to run an interactive python shell within
    # the same terminal session we run the test in.
    PYTHONPATH = os.environ.get('PYTHONPATH')
    PYTHONPATH = PYTHONPATH if PYTHONPATH is not None else ''

# Generated at 2022-06-23 18:21:01.025823
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group."""
    with pytest.raises(OSError):
        get_os_group('invalid.group')

    assert get_os_group(None) == get_os_group()
    assert isinstance(get_os_group(), grp.struct_group)
    assert isinstance(get_os_group(1001), grp.struct_group)



# Generated at 2022-06-23 18:21:01.697764
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-23 18:21:06.073512
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory to work in.
    with tempfile.TemporaryDirectory() as test_path:
        test_path = normalize_path(test_path)
        test_path = test_path.as_posix()
        test_path = cast(str, test_path)

        # Create one empty directory.
        os.makedirs(os.path.join(test_path, 'dir_one'))
        # Create a second empty directory.
        os.makedirs(os.path.join(test_path, 'dir_two'))

        # Create a subdirectory.
        sub_path = os.path.join(test_path, 'dir_one', 'sub_dir')
        os.makedirs(sub_path)

        # Create a file in the subdirectory.

# Generated at 2022-06-23 18:21:15.793829
# Unit test for function chmod
def test_chmod():
    """Test function chmod.

    :rtype: :obj:`None`

    """
    with ChangeDir(tmpdir):
        shutil.copy(
            src=f'{ROOTDIR}/data/chmod',
            dst='.'
        )

        assert os.system('chmod') == 0

        assert os.system('stat chmod') != 0

        chmod('chmod', 0o700)

        assert os.system('stat chmod') == 0

        # Removes the executable permissions on .../chmod
        chmod('chmod', 0o400)

        assert os.system('stat chmod') != 0

        # Add back the executable permission
        chmod('chmod', 0o700)

        assert os.system('stat chmod') == 0


# Generated at 2022-06-23 18:21:22.140329
# Unit test for function get_os_group
def test_get_os_group():
    """Test the functionality of ``get_os_group``."""
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals

    # Ensure correct return type.
    assert isinstance(get_os_group(), grp.struct_group)
    # Ensure given name does not exist.
    with pytest.raises(OSError):
        get_os_group('foo')

    # Ensure correct handling of given name being a gid.
    with patch('grp.getgrgid', side_effect=KeyError('foo')):
        with pytest.raises(OSError):
            get_os_group(1234)
    # pylint: disable=invalid-name
    class fake_grp_struct:
        gr_name = 'foo'
        gr_passwd

# Generated at 2022-06-23 18:21:28.621799
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user(0)
    except OSError:
        pass
    else:
        raise AssertionError
    try:
        get_os_user(99999999999)
    except OSError:
        pass
    else:
        raise AssertionError
    try:
        get_os_user('foo')
    except OSError:
        raise AssertionError
    try:
        get_os_user('bar')
    except OSError:
        raise AssertionError
    try:
        get_os_user()
    except OSError:
        raise AssertionError



# Generated at 2022-06-23 18:21:41.411000
# Unit test for function exists_as
def test_exists_as():
    """Unit tests for function ``exists_as``."""
    from os import name
    if name == 'nt':
        from ctypes import windll
        from ctypes import wintypes
    from random import randint
    from flutils.pathutils import exists_as
    from flutils.testutils import FakeFile
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_path = str(tmp_dir / ('tmp_%s.txt' % randint(100000, 999999)))
        with open(tmp_path, 'w') as temp_file:
            temp_file.write('testing tmp_path')
        f_path = tmp_dir / ('f_%s.txt' % randint(100000, 999999))

# Generated at 2022-06-23 18:21:44.425309
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/.tmp/flutils/test_directory_present/test_dir')
    assert Path('~/.tmp/flutils/test_directory_present/test_dir').exists()



# Generated at 2022-06-23 18:21:51.453053
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.geteuid())
    try:
        pwd.getpwuid(os.geteuid() + 1)
    except KeyError:
        uid = os.geteuid() + 1
        pwd.getpwuid(uid)
    else:
        uid = os.geteuid() - 1
        pwd.getpwuid(uid)
    assert get_os_user(uid) == pwd.getpwuid(uid)
    user = get_os_user().pw_name
    assert get_os_user(user) == pwd.getpwnam(user)

# Generated at 2022-06-23 18:21:57.839983
# Unit test for function chown
def test_chown():
    path = Path('/tmp')
    try:
        os.chmod(path.as_posix(), 0o777)
        chown(path, user=getpass.getuser(), group=getpass.getuser(), include_parent=False)
        mode = os.stat(path.as_posix())
        assert mode.st_uid == os.getuid()
        assert mode.st_gid == os.getgid()
    finally:
        os.chmod(path.as_posix(), 0o755)
        chown(path, user=getpass.getuser(), group=getpass.getuser(), include_parent=True)



# Generated at 2022-06-23 18:22:05.392427
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group('bar')
    assert group.gr_gid == 2001
    assert group.gr_name == 'bar'
    group = get_os_group()  # type: ignore
    assert isinstance(group, grp.struct_group)
    assert group.gr_name == 'bar'
    assert group.gr_gid == 2001



# Generated at 2022-06-23 18:22:14.146226
# Unit test for function get_os_group
def test_get_os_group():
    try:
        # Get the current user's group.
        get_os_group()
    except OSError:
        assert False, 'Unexpected OSError'

    try:
        get_os_group('-1')
    except OSError:
        assert False, 'Unexpected OSError'

    try:
        get_os_group('bar1')
    except OSError:
        assert False, 'Unexpected OSError'

    try:
        get_os_group(30)
    except OSError:
        assert False, 'Unexpected OSError'



# Generated at 2022-06-23 18:22:18.249167
# Unit test for function find_paths
def test_find_paths():

    for in_path, out_paths in PATH_TEST_DATA:
        try:
            results = list(find_paths(in_path))
        except TypeError as exc:
            raise SkipTest(str(exc))

        if not out_paths:
            assert results == []
        else:
            assert set(results) == set(out_paths)



# Generated at 2022-06-23 18:22:28.965536
# Unit test for function find_paths
def test_find_paths():
    # Need to create a fixtures directory.
    test_dir = Path('tests/fixtures')
    test_dir.mkdir(parents=True)

    # Need to create a file in the fixtures directory.
    file_path = Path('tests/fixtures/test_file.txt')
    file_path.touch()

    # Need to create a sub directory in the fixtures directory.
    dir_path = Path('tests/fixtures/test_dir')
    dir_path.mkdir(parents=True)

    assert set(find_paths('tests/fixtures/*')) == set([file_path, dir_path])

    # Remove the fixtures directory and the files created in it.
    # This is to prevent flutils from leaving test files behind.
    shutil.rmtree('tests/fixtures')



# Generated at 2022-06-23 18:22:38.553494
# Unit test for function chmod
def test_chmod():
    from ..testing import patch_open
    from .fsutils import is_mode

    if isinstance(sys.version_info, tuple):
        if sys.version_info[:2] >= (3, 6):
            with patch_open() as mocked_open:
                mocked_open.return_value.__enter__.return_value.is_dir.return_value = True
                mocked_open.return_value.__enter__.return_value.exists.return_value = True
                chmod('./flutils/tests/osutils.txt', mode_file=0o640, mode_dir=0o770, include_parent=True)
                mocked_open.assert_called_once_with('./flutils/tests/osutils.txt')

# Generated at 2022-06-23 18:22:47.850571
# Unit test for function normalize_path
def test_normalize_path():
    tmpdir = tempfile.mkdtemp()
    cwd = os.getcwd()
    os.chdir(tmpdir)

# Generated at 2022-06-23 18:22:54.871028
# Unit test for function exists_as
def test_exists_as():
    function_path_name = 'flutils.pathutils.exists_as'
    with TempPath() as tmp_path:
        file_path = tmp_path / 'file.txt'
        file_path.touch()
        file_path.chmod(0o600)
        assert exists_as(file_path) == 'file'

        dir_path = tmp_path / 'dir_path'
        dir_path.mkdir()
        dir_path.chmod(0o700)
        assert exists_as(dir_path) == 'directory'

        # Create a broken symbolic link that points to a file.
        ln_file_path = tmp_path / 'broken-symlink.txt'
        ln_file_path.touch()
        ln_file_path.chmod(0o600)
        l

# Generated at 2022-06-23 18:23:02.100275
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group

    # get_os_group()
    # Assert the group is retrieved and that the group
    # members are a list.
    result = get_os_group()
    assert isinstance(result, grp.struct_group)
    assert isinstance(result.gr_mem, list)

    # get_os_group(name='foo')
    # Assert that the group is retrieved and that the group
    # members are a list.
    result = get_os_group(name='foo')
    assert isinstance(result, grp.struct_group)
    assert isinstance(result.gr_mem, list)

    # get_os_group(name=1000)
    # Assert that the group is retrieved and that the group
    # members are a list.

# Generated at 2022-06-23 18:23:10.458878
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user"""
    from flutils.testutils import *
    test_get_os_user_helper(get_os_user(name=None))
    test_get_os_user_helper(get_os_user(name=getpass.getuser()))
    test_get_os_user_helper(get_os_user(name=uid))
    test_get_os_user_helper(get_os_user(name=get_os_user(name=None).pw_name))



# Generated at 2022-06-23 18:23:22.979872
# Unit test for function path_absent
def test_path_absent():
    temp_dir = tempfile.TemporaryDirectory()
    test_path = os.path.join(temp_dir.name, 'test_path')
    os.mkdir(test_path)
    assert os.path.exists(test_path)
    path_absent(test_path)
    assert os.path.exists(test_path) is False
    temp_dir.cleanup()

    temp_dir = tempfile.TemporaryDirectory()
    test_path = os.path.join(temp_dir.name, 'test_path')
    os.mkdir(test_path)
    nested_dir = os.path.join(temp_dir.name, 'test_path', 'nested')
    os.mkdir(nested_dir)
    assert os.path.exists(nested_dir)
   

# Generated at 2022-06-23 18:23:30.020431
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as base_dir:
        test_dir = Path(base_dir).joinpath('dir1')
        p1 = test_dir.joinpath('dir2')
        p2 = p1.joinpath('dir3')
        directory_present(p2, mode=0o766, user='root', group='wheel')
        assert p2.exists() is True
        assert p2.is_dir() is True
        assert p2.stat().st_mode == 33206
        assert p2.stat().st_uid == 0
        assert p2.stat().st_gid == 0

        p3 = p1.joinpath('non-dir')
        p3.touch()
        with pytest.raises(FileExistsError) as err:
            directory_present(p2)
       

# Generated at 2022-06-23 18:23:36.970260
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = cast(str, tmpdir)
        path = os.path.join(tmpdir, 'test_path')
        os.makedirs(path)
        assert os.path.isdir(path)
        path_absent(path)
        assert os.path.isdir(tmpdir)
        assert os.path.exists(tmpdir)
        assert os.path.exists(path) is False
        assert os.path.isdir(path) is False
#
# Unit test end


# Generated at 2022-06-23 18:23:47.583055
# Unit test for function chown
def test_chown():
    from flutils.pathutils import (
        chmod,
        chown,
        directory_present,
        exists_as,
        path_absent,
    )

    path = Path('/tmp/flutils.tests.osutils.txt')
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name

    # Set the directory that holds the file
    directory_present(path.parent)
    # Set the file to be chowned
    chmod(path, mode_file=0o666)
    path.touch()

    assert exists_as(path, 'file') is True
    assert exists_as(path, 'directory') is False
    assert exists_as(path, 'symlink') is False


# Generated at 2022-06-23 18:23:58.329494
# Unit test for function get_os_user
def test_get_os_user():
    import pwd
    import getpass
    def test_get_os_user_default():
        uid = getpass.getuser()
        pwd.getpwnam(uid)
    def test_get_os_user_int():
        get_os_user(0)
    def test_get_os_user_str():
        get_os_user('root')
    def test_get_os_user_uid():
        get_os_user(0)
    def test_get_os_user_fail_uid():
        try:
            get_os_user(int(1e6))
        except OSError:
            pass
        else:
            assert False, 'should have raised an exception'

# Generated at 2022-06-23 18:24:05.107313
# Unit test for function chmod
def test_chmod():
    try:
        test_file_path = normalize_path(
            '~/tmp/flutils.tests.osutils.chmod.txt'
        )
        test_file_path.touch()
        assert test_file_path.chmod(0o666) is None
        chmod(test_file_path, 0o660)
        assert test_file_path.stat().st_mode & 0o777 == 0o660
    finally:
        test_file_path.unlink()



# Generated at 2022-06-23 18:24:07.237362
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/') == 'directory'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'

# Generated at 2022-06-23 18:24:17.875088
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil
    import os

    with tempfile.TemporaryDirectory() as tmpdir:
        # Make some file and directories
        files = [
            os.path.join(tmpdir, x) for x in [
                'foo.txt',
                'bar.txt',
                'baz.txt',
                'subdir/bam.txt',
                'subdir/bim.txt'
            ]
        ]

        for f in files:
            if '/' in f:
                os.makedirs(os.path.dirname(f), exist_ok=True)
            fd = open(f, 'a')
            fd.close()

        chmod(os.path.join(tmpdir, '*'), mode_file=0o660)

# Generated at 2022-06-23 18:24:27.937502
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent"""
    # First test to assure that the function can not remove a directory if
    # there is a file inside it.
    with TmpDirCtx() as tmp_dir:
        test_path = tmp_dir.joinpath('a_file')
        assert not test_path.exists()
        test_path.touch()
        assert test_path.exists()
        path_absent(test_path)
        assert not test_path.exists()
    # Now test to assure that the function can remove a directory if
    # there are no files inside it.
    with TmpDirCtx() as tmp_dir:
        test_path = tmp_dir.joinpath('a_directory')
        assert not exists_as(test_path)
        mkdir(test_path)

# Generated at 2022-06-23 18:24:31.935591
# Unit test for function normalize_path
def test_normalize_path():
    # Simple test
    path = normalize_path('~/tmp/foo/../bar')
    assert path.as_posix() == os.path.expanduser('~/tmp/bar')
    # Make sure normalize_path is being memoized.
    path2 = normalize_path('~/tmp/foo/../bar')
    assert path is path2


# Generated at 2022-06-23 18:24:43.334532
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/etc/fstab') == 'file'
    assert exists_as('/dev/sda1') == 'block device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/tmp/test_fifo') == 'FIFO'

# Generated at 2022-06-23 18:24:44.514841
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'



# Generated at 2022-06-23 18:24:52.955495
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as
    from flutils.osutils import SilentMock
    import requests_mock as rm
    import os

    with rm.Mocker() as m:
        m.get(
            'https://raw.githubusercontent.com/sigmavirus24/github3.py/'
            'master/github3/GitHub.py',
            exc=requests.exceptions.SSLError
        )
        with pytest.raises(requests.exceptions.SSLError):
            try:
                import github3  # noqa
            except Exception as _err:
                raise _err


# Generated at 2022-06-23 18:25:04.874241
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    import os
    import platform
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(os.getlogin()).pw_name == getpass.getuser()
    assert get_os_user(os.getlogin()).pw_gecos == platform.node()
    assert get_os_user(os.getlogin()).pw_dir == Path.home()
    if os.path.exists('/usr/bin/whoami'):
        assert get_os_user(os.getlogin()).pw_shell == '/usr/bin/whoami'
    else:
        assert get_os_user(os.getlogin()).pw_shell == Path.home()
    assert get_os_user

# Generated at 2022-06-23 18:25:13.428423
# Unit test for function get_os_user
def test_get_os_user():
    """Check the function ``get_os_user``."""
    data = get_os_user()
    assert isinstance(data, pwd.struct_passwd)
    assert hasattr(data, 'pw_passwd')
    assert hasattr(data, 'pw_uid')
    assert hasattr(data, 'pw_gid')
    assert hasattr(data, 'pw_gecos')
    assert hasattr(data, 'pw_dir')
    assert hasattr(data, 'pw_shell')



# Generated at 2022-06-23 18:25:19.528780
# Unit test for function path_absent
def test_path_absent():
    expected = '[\r\n]'
    actual = '\n'
    compare(expected, actual)
    actual = '\r\n'
    compare(expected, actual)
    actual = '\r'
    compare(expected, actual)
    actual = '\r\r'
    compare(expected, actual)



# Generated at 2022-06-23 18:25:30.093542
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    from unittest.mock import patch

    from flutils.common import validate_callable_arg
    from flutils.pathutils import realpath

    path = Path(__file__).parent / 'test_chmod.txt'
    if path.is_file() is True:
        path.unlink()

    assert path.is_file() is False

    shutil.copy(
        Path(__file__).parent / '..' / '..' / '..' / 'README.md',
        path
    )
    assert os.path.exists(path) is True


# Generated at 2022-06-23 18:25:32.255715
# Unit test for function chown
def test_chown():
    assert chown('*', '-1') is None

# Generated at 2022-06-23 18:25:41.649383
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)  # type: ignore
        test_path = tmp_dir / 'test_path'
        test_file = test_path / 'test_file'
        test_dir = test_path / 'test_dir'

        test_path.mkdir()
        test_file.touch()
        test_dir.mkdir()

        path_absent(test_path)

        assert os.path.exists(test_path.as_posix()) is False
        assert os.path.exists(test_file.as_posix()) is False
        assert os.path.exists(test_dir.as_posix()) is False



# Generated at 2022-06-23 18:25:46.585833
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('foo') == pwd.struct_passwd(
        pw_name='foo', pw_passwd='********', pw_uid=1001,
        pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo',
        pw_shell='/usr/local/bin/bash'
    )



# Generated at 2022-06-23 18:25:47.157179
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:25:58.935756
# Unit test for function path_absent
def test_path_absent():
    """Test the path_absent function."""
    from shutil import rmtree
    from tempfile import mkdtemp

    temp_dir = mkdtemp(prefix='flutils_test_')
    path_utils_test_dir = os.path.abspath(os.path.join(
        temp_dir, 'path_utils_test_dir'
    ))
    path_utils_test_broken_symlink = os.path.abspath(os.path.join(
        temp_dir, 'path_utils_test_broken_symlink'
    ))
    path_utils_test_file = os.path.abspath(os.path.join(
        temp_dir, 'path_utils_test_file.txt'
    ))

# Generated at 2022-06-23 18:26:09.450823
# Unit test for function chown
def test_chown():
    from .osutils import chown
    from .pathutils import path_absent
    from .wrappers import get_os_group, get_os_user
    from functools import partial
    from os import PathLike
    from pathlib import Path

    def _test_chown(path: PathLike) -> None:
        path = Path(path)
        if path.exists():
            raise RuntimeError('{} already exists'.format(path.as_posix()))

        with path_absent(path.as_posix()):
            chown(path.as_posix())
            chown(path.as_posix(), user=partial(get_os_user, 'root'),
                  group=partial(get_os_group, 'root'))

# Generated at 2022-06-23 18:26:10.219227
# Unit test for function chmod
def test_chmod():
    return


# Generated at 2022-06-23 18:26:22.494583
# Unit test for function exists_as
def test_exists_as():
    """Test function ``exists_as``."""
    from pathlib import PosixPath

    # Test for does not exist.
    assert exists_as('/this/path/does/not/exist') == ''

    # Test for directory.
    assert exists_as('/etc') == 'directory'

    # Test for regular file.
    assert exists_as('/etc/hosts') == 'file'

    # Test for broken symbolic link.
    # /bin/sh is a symbolic link to /bin/dash.
    # The /bin/dash link is broken.
    # The shell command "rm /bin/dash" was used to break the link.
    # The shell command "ln -s /bin/bash /bin/dash" was used to set it back.
    assert exists_as('/bin/sh') == ''

    # Test for

# Generated at 2022-06-23 18:26:26.994170
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user.
    Check if there is an exception raised when the
    name given to get_os_user doesn't exist in this
    operating system."""
    with pytest.raises(OSError):
        get_os_user('this name does not exist on this machine')

# Generated at 2022-06-23 18:26:28.369735
# Unit test for function find_paths
def test_find_paths():
    pattern = Path('~/tmp/*')
    search = pattern.as_posix()[len(pattern.anchor):]
    yield from Path(pattern.anchor).glob(search)