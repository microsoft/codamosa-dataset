

# Generated at 2022-06-23 18:16:37.455454
# Unit test for function chmod
def test_chmod():
    file = '/tmp/flutils.tests.pathutils.txt'
    dir = '/tmp/flutils.tests.pathutils.d'
    try:
        Path(file).touch()
        chmod(file, 0o660)
        assert oct(Path(file).stat().st_mode & 0o777) == '0o660'

        Path(dir).mkdir()
        chmod(dir, mode_dir=0o770)
        assert oct(Path(dir).stat().st_mode & 0o777) == '0o770'

    finally:
        Path(file).unlink()
        Path(dir).rmdir()

# Generated at 2022-06-23 18:16:38.844681
# Unit test for function chmod
def test_chmod():
    from ..osutils import chmod
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    pass



# Generated at 2022-06-23 18:16:43.716560
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == getpass.getuser()



# Generated at 2022-06-23 18:16:53.844911
# Unit test for function find_paths
def test_find_paths():
    path = Path('~/tmp') / 'test_path'
    path_one = path / 'file_one'
    path_two = path / 'dir_one'
    path_three = path_two / 'file_three'

    path.mkdir(mode=0o700, parents=True)
    path_one.touch()
    path_two.mkdir(mode=0o700)
    path_three.touch()

    result = list(find_paths(path / '*'))
    assert len(result) == 2
    assert path_one in result
    assert path_two in result

    result = list(find_paths(path / '**'))
    assert len(result) == 3
    assert path_one in result
    assert path_two in result
    assert path_three in result

    path

# Generated at 2022-06-23 18:16:56.365421
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-23 18:17:06.522099
# Unit test for function chmod
def test_chmod():
    from .osutils import create_temp_file

    with create_temp_file() as fh:
        path = fh.name

    chmod(path)
    assert os.stat(path).st_mode & 0o777 == 0o660

    chmod(path, 0o777)
    assert os.stat(path).st_mode & 0o777 == 0o777

    os.remove(path)

    with create_temp_file(dir='.') as fh:
        path = Path(fh.name)

    chmod(path.parent, mode_dir=0o777)
    assert os.stat(path.parent).st_mode & 0o777 == 0o777

    os.remove(path)



# Generated at 2022-06-23 18:17:17.738165
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import os
    import stat
    u = getpass.getuser()
    g = grp.getgrgid(os.getgid()).gr_name

    t = tempfile.TemporaryDirectory()
    os.chmod(t.name, 0o755)
    if os.path.exists(t.name):
        assert stat.S_ISDIR(os.stat(t.name).st_mode)
    else:
        assert False

    p = os.path.join(t.name, 'foo.txt')
    Path(p).touch()
    os.chmod(p, 0o644)
    if os.path.exists(p):
        assert stat.S_ISREG(os.stat(p).st_mode)
    else:
        assert False

# Generated at 2022-06-23 18:17:23.108381
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group('foo'), grp.struct_group)
    assert isinstance(get_os_group(), grp.struct_group)
    with pytest.raises(OSError):
        get_os_group(123456789)
    with pytest.raises(OSError):
        get_os_group('bar')



# Generated at 2022-06-23 18:17:25.748982
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**', user='foo', group='bar')


# Generated at 2022-06-23 18:17:27.799133
# Unit test for function exists_as
def test_exists_as():
    path = Path('~/tmp')
    assert exists_as(path) == 'directory'



# Generated at 2022-06-23 18:17:30.099573
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'  # noqa E402



# Generated at 2022-06-23 18:17:41.912806
# Unit test for function find_paths
def test_find_paths():
    from flutils import pathutils
    from tempfile import mkdtemp
    from tempfile import TemporaryDirectory
    from tempfile import TemporaryFile

    path_dir = None

    with TemporaryDirectory(dir=pathutils.USER_TMP_DIR) as tmp_dir:
        path_dir = Path(tmp_dir)

        path_dir_file = path_dir.joinpath('file')
        path_dir_file = pathutils.touch(path_dir_file)

        path_dir_dir = path_dir.joinpath('dir')
        path_dir_dir = path_dir_dir.mkdir()

        path_dir_dir_file = path_dir_dir.joinpath('file')
        path_dir_dir_file = pathutils.touch(path_dir_dir_file)


# Generated at 2022-06-23 18:17:43.977848
# Unit test for function get_os_user
def test_get_os_user():
    pass



# Generated at 2022-06-23 18:17:46.838892
# Unit test for function directory_present
def test_directory_present():
    # Arrange
    from flutils.pathutils import directory_present
    path = '~/tmp'

    # Act
    dir_path = directory_present(path)

    # Assert
    assert dir_path.is_dir() is True
    assert dir_path.exists() is True
# End unit test for function directory_present



# Generated at 2022-06-23 18:17:53.776732
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user"""
    try:
        _ = get_os_user('__not_a_user__')
    except OSError as os_err:
        if 'login name' not in str(os_err):
            raise

    try:
        _ = get_os_user(999)
    except OSError as os_err:
        if 'valid uid' not in str(os_err):
            raise

    try:
        _ = get_os_user()
    except OSError as os_err:
        if 'login name' not in str(os_err):
            raise



# Generated at 2022-06-23 18:18:04.376013
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.pyutils import get_script_dir
    test_dir = get_script_dir() / 'data'
    assert exists_as(test_dir) == 'directory'
    assert exists_as(test_dir / 'foo') == ''
    assert exists_as(test_dir / 'foo.txt') == 'file'
    with open(test_dir / 'foo.txt', 'a') as fp:
        # Create a zero size file.
        pass
    assert exists_as(test_dir / 'foo.txt') == 'file'
    with open(test_dir / 'foo.txt', 'w') as fp:
        # Create a non-zero sized file.
        fp.write('foo')

# Generated at 2022-06-23 18:18:15.741249
# Unit test for function chown
def test_chown():
    import datetime
    import os

    from flutils.pathutils import (
        chown,
        find_paths
    )

    # Test when the path does not exist
    path = '~/tmp/flutils.pathutils.chown/noexist'
    with chown(path):
        assert os.path.exists(path) is False

    # Test when the path exists and then removed
    path = '~/tmp/flutils.pathutils.chown/removed'
    with open(path, 'w') as fd:
        fd.write(str(datetime.datetime.utcnow()))
    assert os.path.exists(path) is True
    with chown(path):
        os.remove(path)
        assert os.path.exists(path) is False
    assert os

# Generated at 2022-06-23 18:18:27.418151
# Unit test for function get_os_user
def test_get_os_user():
    from .testutils import BaseTestCase
    from .testutils import create_temp_directory_path

    class _TestCase(BaseTestCase):

        def setUp(self):
            super().setUp()
            self.test_dir_path = create_temp_directory_path()

        def test_get_os_user(self):
            self.assertEqual(
                get_os_user().pw_name, getpass.getuser()
            )
            self.assertEqual(
                get_os_user(name='root').pw_dir, '/root'
            )
            if not os.geteuid() == 0:
                with self.assertRaises(OSError):
                    get_os_user(name=0)

    return _TestCase



# Generated at 2022-06-23 18:18:36.176466
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.systemutils import command_present, get_os_exec
    from os import system
    from shlex import split
    import time

    if command_present('touch') is True:
        try:
            if get_os_exec() == 'system':
                # Windows does not support the -p option.
                system(split('touch /tmp/flutils.tests.chmod.txt'))
            else:
                system(split('touch -p /tmp/flutils.tests.chmod.txt'))
        except TypeError:
            print('WARNING: touch command failed to run!')
            return


# Generated at 2022-06-23 18:18:46.829954
# Unit test for function normalize_path
def test_normalize_path():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        os.makedirs('foo/bar')
        assert normalize_path('foo/bar') == Path(os.path.join(tmpdir, 'foo/bar'))
        assert normalize_path('foo/') == Path(os.path.join(tmpdir, 'foo'))
        assert normalize_path(os.path.join(tmpdir, 'foo/bar')) == Path(os.path.join(tmpdir, 'foo/bar'))
        assert normalize_path('foo/../bar') == Path(os.path.join(tmpdir, 'bar'))
        assert normalize_path('~/tmp') == Path(os.path.expanduser('~/tmp'))
        assert normalize

# Generated at 2022-06-23 18:18:50.178315
# Unit test for function get_os_group
def test_get_os_group():
    struct_group = get_os_group('foobar')
    assert struct_group.gr_gid == 2001
    struct_group = get_os_group(2001)
    assert struct_group.gr_gid == 2001



# Generated at 2022-06-23 18:18:56.301546
# Unit test for function normalize_path
def test_normalize_path():
    """Test for function normalize_path"""

# Generated at 2022-06-23 18:19:05.191337
# Unit test for function chmod
def test_chmod():
    test_path = '~/tmp/flutils.tests.pathutils.test_chmod.txt'
    try:
        Path(test_path).touch()
        Path(test_path).chmod(0o200)
        assert Path(test_path).stat().st_mode == 33060
        chmod(test_path, 0o660)
        assert Path(test_path).stat().st_mode == 33188
        os.remove(os.path.expanduser(test_path))
    except OSError:
        # Usually will get here:
        # [Errno 13] Permission denied
        pass
    test_dir = '~/tmp/flutils.tests.pathutils.test_chmod/'

# Generated at 2022-06-23 18:19:13.551380
# Unit test for function normalize_path
def test_normalize_path():
    import pytest

    @pytest.mark.parametrize(
        'path',
        [
            '/home/test_user/tmp/foo/../test_path',
            '~/tmp/foo/../test_path',
            b'/home/test_user/tmp/foo/../test_path'.decode(),
            Path('/home/test_user/tmp/foo/../test_path'),
            '../test_path',
        ]
    )
    def test_absolute(path):
        path = normalize_path(path)
        assert path.as_posix() == '/home/test_user/tmp/test_path'
        assert path.is_absolute()


# Generated at 2022-06-23 18:19:18.999283
# Unit test for function chmod
def test_chmod():
    test_path = Path('/tmp/flutils.tests.pathutils.chmod')


# Generated at 2022-06-23 18:19:29.947171
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from os import getuid
    from os import getgid
    from os import mkdir
    from os import sep
    from os.path import expanduser
    from os.path import expandvars
    from os.path import isdir
    from os.path import join as pjoin

    user = getpass.getuser()
    group = grp.getgrgid(getgid()).gr_name

    flag = False

    if sys.platform == 'win32':
        flag = True
        user = user[0]

    temp = Path(TemporaryDirectory().name)

    test_path = pjoin(temp.as_posix(), 'test2', 'test1', 'test_path')

# Generated at 2022-06-23 18:19:36.929951
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    from flutils.pathutils import normalize_path

    assert normalize_path('~/tmp/test_path') == Path.home() / 'tmp' / 'test_path'
    assert normalize_path('..') == Path.cwd().parent
    assert normalize_path('/home/tmp/../test_path') == Path('/home/test_path')
    assert normalize_path('/home//tmp') == Path('/home/tmp')
    assert normalize_path('/') == Path('/')
    assert normalize_path('/.') == Path('/')
# End unit test
normalize_path.register(bytes, lambda b: normalize_path(b.decode(sys.getfilesystemencoding())))



# Generated at 2022-06-23 18:19:49.112241
# Unit test for function find_paths
def test_find_paths():
    # Only directories are returned
    paths = [Path(p) for p in [
        '~/tmp/file_one',
        '~/tmp/dir_one'
    ]]
    for p in paths:
        p.parent.mkdir(exist_ok=True, parents=True)
        p.touch()
    paths = find_paths('~/tmp/*')
    assert next(paths).name == 'dir_one'
    assert next(paths).name == 'file_one'
    with pytest.raises(StopIteration):
        next(paths)

    # Only files are returned

# Generated at 2022-06-23 18:19:58.454427
# Unit test for function chown
def test_chown():
    chown('~/tmp/jljkdjkajsdkfajsldkfj.txt.txt', user='-1', group='-1')
    chown('~/tmp/jljkdjkajsdkfajsldkfj.txt', user='-1', group='-1')
    chown('~/tmp/jljkdjkajsdkfajsldkfj.txt.txt', include_parent=True)
    chown('~/tmp/jljkdjkajsdkfajsldkfj.txt.txtlskfj', include_parent=True)
    chown('~/tmp/*', include_parent=True)
    chown('~/tmp/*', user='-1', group='-1')
    chown('~/tmp/**')
    chown

# Generated at 2022-06-23 18:20:09.557655
# Unit test for function chown

# Generated at 2022-06-23 18:20:10.378497
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:20:17.829834
# Unit test for function directory_present
def test_directory_present():
    path = Path('~/tmp/flutils.tests.pathutils.path_present').expanduser()
    directory = directory_present(path, mode=0o700)
    assert directory.exists()
    assert directory.is_dir()
    assert directory.parent.exists()
    assert directory.parent.is_dir()
    assert directory.parent.parent.exists()
    assert directory.parent.parent.is_dir()
    assert directory.parent.parent.parent == Path().expanduser()
    os.chmod(directory.as_posix(), 0o770)
    os.chmod(directory.parent.as_posix(), 0o770)
    os.chmod(directory.parent.parent.as_posix(), 0o770)

# Generated at 2022-06-23 18:20:31.379916
# Unit test for function path_absent
def test_path_absent():
    import logging
    import os
    import pathlib
    import stat
    import tempfile
    import unittest
    import textwrap
    import flutils.pathutils

    def make_tree(
            base_dir: str,
            directory_mode: int = 0o700,
            file_mode: int = 0o644,
            **kwargs: str
    ) -> None:
        def _make_tree(
                path: pathlib.Path,
                mode: int = 0o700
        ) -> None:
            path.mkdir(mode=mode)
            if os.getuid() == 0:
                os.chmod(path.as_posix(), mode)
            else:
                os.chmod(path.as_posix(), mode)

# Generated at 2022-06-23 18:20:39.665445
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    path_types = [
        '~/tmp/foo/../bar',
        Path('~/tmp/foo/../bar'),
        Path(b'~/tmp/foo/../bar'),
    ]
    for path_type in path_types:
        assert (
            normalize_path(path_type) ==
            Path('/home/test_user/tmp/bar')
        )

    path = b'~/tmp/foo/../bar'
    assert (
        normalize_path(path) ==
        Path('/home/test_user/tmp/bar')
    )
    path = Path(b'~/tmp/foo/../bar')

# Generated at 2022-06-23 18:20:52.108199
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        file1 = tmpdir.joinpath('file_one')
        file2 = tmpdir.joinpath('file_two')
        file1.touch()
        file2.touch()
        dir1 = tmpdir.joinpath('dir_one')
        dir1.mkdir(parents=True, exist_ok=True)
        dir2 = tmpdir.joinpath('dir_two')
        dir2.mkdir(parents=True, exist_ok=True)
        dir3 = dir2.joinpath('dir_three')
        dir3.mkdir(parents=True, exist_ok=True)
        file3 = dir3.joinpath('file_three')
        file3.touch()

# Generated at 2022-06-23 18:21:00.936910
# Unit test for function directory_present
def test_directory_present():
    # Test files
    testfile_a = 'tmp/test_file_a.txt'
    testfile_b = 'tmp/test_file_b/test_file_b.txt'
    testfile_c = 'test_file_c.txt'
    testfile_d = 'test_file_d.txt'

    # Test directories
    testdir_a = 'tmp/testdir_a'
    testdir_b = 'tmp/testdir_b/testdir_b'
    testdir_c = 'testdir_c'
    testdir_d = 'testdir_d'

    # Create directory present tests

# Generated at 2022-06-23 18:21:10.781232
# Unit test for function chmod
def test_chmod():
    TEST_DIR = Path(os.getenv('HOME')) / 'tmp' / 'test_chmod'
    TEST_DIR.mkdir(parents=True, exist_ok=True)
    (TEST_DIR / 'file.txt').write_text('testing')

    chmod(TEST_DIR / 'file.txt', 0o600, 0o700)
    chmod(TEST_DIR / '*', 0o600, 0o700)
    chmod(TEST_DIR / '*', 0o600, 0o700, include_parent=True)

    assert stat.S_IMODE((TEST_DIR / 'file.txt').stat().st_mode) == 0o600
    assert stat.S_IMODE(TEST_DIR.stat().st_mode) == 0o700



# Generated at 2022-06-23 18:21:18.321503
# Unit test for function chmod
def test_chmod():
    from os import PathLike
    from pathlib import PosixPath, WindowsPath

    from flutils.pathutils import chmod

    # TODO: Test for glob pattern and include_parent

    # Test for symlinks (symlink target that is a file)
    #
    # Need to test for:
    #     - chmod of file target
    #     - chmod of symlink
    #     - chmod of file target and symlink (same mode)
    #     - chmod of file target and symlink (different modes)
    #     - chmod of file target and symlink that points to a file that does
    #       not exist (should still chmod the existing symlink)
    assert True is True

    # Test for symlinks (symlink target that is a directory)
    #
    # Need to test for

# Generated at 2022-06-23 18:21:23.837394
# Unit test for function get_os_group
def test_get_os_group():
    os_group = get_os_group('test_group')
    assert os_group == grp.struct_group(
        gr_name='test_group', gr_passwd='*', gr_gid=2002, gr_mem=['test_user', ]
    )
    os_group = get_os_group(2002)
    assert os_group == grp.struct_group(
        gr_name='test_group', gr_passwd='*', gr_gid=2002, gr_mem=['test_user', ]
    )
    os_group = get_os_group()
    # It's a bit of a hack but it works for testing.  There is no
    # test_user account or group but the real gid for the test_user
    # for this test system is 999 but in the test directory of this


# Generated at 2022-06-23 18:21:36.817885
# Unit test for function directory_present
def test_directory_present():
    from shutil import rmtree

    from flutils.pathutils import directory_present

    # Simple test
    path = '/tmp/{user}/tmp'.format(user=getpass.getuser())
    directory_present(path)
    try:
        assert Path(path).exists() is True, 'Test #1 Failed'
    finally:
        rmtree(path)

    # A full path that does not exist.
    path = '/tmp/{user}/tmp/foo/bar'.format(user=getpass.getuser())
    directory_present(path)
    try:
        assert Path(path).exists() is True, 'Test #2 Failed'
    finally:
        rmtree(path)

    # The path exists, but it is not a directory.

# Generated at 2022-06-23 18:21:38.004674
# Unit test for function path_absent
def test_path_absent():
    path = '~/tmp/pau/test_path'
    path_absent(path)
    assert not os.path.exists(path)



# Generated at 2022-06-23 18:21:47.933946
# Unit test for function normalize_path
def test_normalize_path():
    """Test the :obj:`normalize_path` function."""
    path_str = '~/tmp/foo/../bar'
    path_str_result = '/home/test_user/tmp/bar'
    assert normalize_path(path_str) == path_str_result

    path_bytes = path_str.encode('utf-8')
    assert normalize_path(path_bytes) == path_str_result

    posix_path = Path(path_str)
    assert normalize_path(posix_path) == path_str_result

    assert normalize_path(path_bytes) == normalize_path(path_str)
    assert normalize_path(path_bytes) == normalize_path(posix_path)



# Generated at 2022-06-23 18:21:50.622941
# Unit test for function get_os_group
def test_get_os_group():
    gid = grp.getgrnam(test_group).gr_gid
    assert get_os_group(test_group).gr_gid == gid
    assert get_os_group(gid).gr_gid == gid



# Generated at 2022-06-23 18:22:00.408053
# Unit test for function path_absent
def test_path_absent():
    path = Path(__file__).parent
    path = path / 'data' / '_path_absent'
    # Should not exist
    path_absent(path)

# Generated at 2022-06-23 18:22:12.734156
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from tempfile import TemporaryDirectory

    with TemporaryDirectory(prefix='test_flutils_') as td:
        p = Path(td) / 'tmp'
        p.mkdir()
        file_one = p / 'file_one'
        file_one.touch()
        dir_one = p / 'dir_one'
        dir_one.mkdir()

        # Test lookarounds
        assert list(find_paths(file_one.as_posix())) == [file_one]
        assert list(find_paths(dir_one.as_posix())) == [dir_one]
        # Test globbing
        result = list(find_paths(p.as_posix() + '/*'))

# Generated at 2022-06-23 18:22:14.723863
# Unit test for function path_absent
def test_path_absent():
    path_absent('~/tmp/test_path')
    assert not os.path.exists('~/tmp/test_path')



# Generated at 2022-06-23 18:22:25.849612
# Unit test for function normalize_path
def test_normalize_path():
    import unittest
    import unittest.mock as mock
    from flutils.pathutils import normalize_path
    from pathlib import PosixPath, WindowsPath

    class TestNormalizePath(unittest.TestCase):

        # No setUp or tearDown needed for this unit test

        def test_str(self):
            with mock.patch.object(os, 'getcwd', lambda: '/tmp'):
                self.assertTrue(
                    normalize_path('/bar/tmp')
                    == PosixPath('/bar/tmp')
                )


# Generated at 2022-06-23 18:22:32.176795
# Unit test for function exists_as
def test_exists_as():

    test_path = Path(__file__).parent / 'test.py'
    test_path_does_not_exist = test_path.with_name('test_does_not_exist')

    assert exists_as(test_path) == 'file'
    assert exists_as(test_path.as_posix()) == 'file'
    # Failure case does not exist
    assert exists_as(
        test_path_does_not_exist
    ) == ''



# Generated at 2022-06-23 18:22:43.525201
# Unit test for function exists_as
def test_exists_as():
    """Test the function exists_as()."""
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/io.py') == 'file'
    assert exists_as(Path('~/tmp/io.py')) == 'file'
    with open('/dev/null', 'w') as devnull:
        assert exists_as(Path(devnull.fileno())) == 'block device'
    assert exists_as('/dev/tty0') == 'char device'
    assert exists_as('/dev/tty1') == 'char device'
    assert exists_as('/dev/tty2') == 'char device'
    assert exists_as('/dev/tty3') == 'char device'
    assert exists_as('/dev/tty4') == 'char device'
    assert exists

# Generated at 2022-06-23 18:22:49.865951
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .contextutils import pushd
    from .osutils import remove

    with TemporaryDirectory() as temp_dir:
        with pushd(temp_dir):
            test_dir = Path(temp_dir + '/subdir')
            test_dir.mkdir()
            assert test_dir.is_dir()

            # Directory exists as a directory.
            assert directory_present(
                test_dir
                ).as_posix() == test_dir.as_posix()

            # Directory exists as a file.
            with open(test_dir.as_posix(), 'w') as test_file:
                test_file.write('Test file.')
            assert directory_present(test_dir).as_posix() != test_dir.as_posix()

# Generated at 2022-06-23 18:22:53.709752
# Unit test for function find_paths
def test_find_paths():
    expected = [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one')
    ]
    assert list(find_paths('/home/test_user/tmp/*')) == expected
    assert list(find_paths('/home/test_user/tmp/file_one')) == [expected[0]]



# Generated at 2022-06-23 18:22:54.539174
# Unit test for function chown
def test_chown():
    raise NotImplementedError()



# Generated at 2022-06-23 18:23:01.817043
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import exists_as, path_absent
    from flutils.pathutils import path_present_as_file
    from flutils.systemutils import get_temp_dir

    tmp_dir = get_temp_dir()

    path_present_as_file(
        '%s/test_file' % tmp_dir,
        content='content'
    )
    assert exists_as('%s/test_file' % tmp_dir) == 'file'

    path_absent('%s/test_file' % tmp_dir)
    assert exists_as('%s/test_file' % tmp_dir) == ''

    path_absent('%s/test_dir' % tmp_dir)
    assert exists_as('%s/test_dir' % tmp_dir) == ''


# Generated at 2022-06-23 18:23:07.813917
# Unit test for function directory_present
def test_directory_present():
    import os

    from flutils.pathutils import directory_present

    path = directory_present('/tmp/this_path')
    assert os.path.isdir(path)

    path = directory_present('~/tmp/this_path')
    assert path.is_dir() is True



# Generated at 2022-06-23 18:23:16.972974
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        files = [
            tmpdir / 'flutils.py',
            tmpdir / 'flutils.tests.__init__.py',
            tmpdir / 'flutils.tests.osutils.py',
            tmpdir / 'flutils.tests.osutils.txt',
        ]
        for file in files:
            Path(file).touch(mode=0o644, exist_ok=False)

        paths = list(find_paths(tmpdir / 'fl*.py'))
        assert paths == files[:2]

        paths = list(find_paths(tmpdir / 'fl*.py'))
        assert paths == files[:2]



# Generated at 2022-06-23 18:23:21.319924
# Unit test for function get_os_group
def test_get_os_group():
    expected = grp.struct_group(gr_name='test_group', gr_passwd='*',
                                gr_gid=2001, gr_mem=['test_user'])
    assert get_os_group('test_group') == expected
    assert get_os_group(2001) == expected



# Generated at 2022-06-23 18:23:31.117715
# Unit test for function find_paths
def test_find_paths():
    """Test the flutils.pathutils.find_paths() function."""
    dirc = '~/tmp'
    files = [
        'file_one',
        'file_two',
        'file_three'
    ]
    dirs = [
        'dir_one',
        'dir_two',
        'dir_three'
    ]

    with temporary_directory(dirc) as tmpdir:
        tmpdir = Path(tmpdir)
        for file_ in files:
            Path(os.path.join(tmpdir.as_posix(), file_)).touch()
        for dir_ in dirs:
            Path(os.path.join(tmpdir.as_posix(), dir_)).mkdir()


# Generated at 2022-06-23 18:23:35.637688
# Unit test for function normalize_path
def test_normalize_path():
    new_path = normalize_path('~/tmp/foo/../bar')
    assert new_path == Path(os.path.expanduser('~/tmp/bar'))

# Generated at 2022-06-23 18:23:46.209964
# Unit test for function chmod
def test_chmod():
    def _pre_test_cleanup():
        tmp_path = Path('~/tmp/flutils.tests.osutils').expanduser()
        if tmp_path.exists():
            tmp_path.unlink()
            tmp_path.rmdir()

    def _post_test_cleanup():
        tmp_path = Path('~/tmp/flutils.tests.osutils').expanduser()
        if tmp_path.exists():
            tmp_path.unlink()
            tmp_path.rmdir()

    def _init_test_dir():
        _pre_test_cleanup()
        tmp_path = Path('~/tmp/flutils.tests.osutils').expanduser()
        tmp_path.mkdir()
        return tmp_path

    # Tests for function chmod
    tmp_path

# Generated at 2022-06-23 18:23:57.670071
# Unit test for function exists_as
def test_exists_as():
    from flutils.testhelpers import random_string
    with tempfile.TemporaryDirectory() as td:
        with tempfile.NamedTemporaryFile(dir=td, delete=False) as f:
            f_name = f.name

        os.mkdir(os.path.join(td, random_string(10, 'ascii')))
        os.mkfifo(os.path.join(td, random_string(10, 'ascii')))

        assert exists_as(Path(td)) == 'directory'
        assert exists_as(Path(f_name)) == 'file'
        assert exists_as(Path(os.path.join(td, 'missing'))) == ''

# Generated at 2022-06-23 18:24:06.193337
# Unit test for function chown
def test_chown():
    """Unit test for function chown"""
    path = str(Path(__file__).parent.parent / 'tmp' / 'flutils.pathutils.txt')
    with open(path, 'w') as file_obj:
        file_obj.write('Hello world!')

    chown(path)

    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name
    assert '{}:{}'.format(user, group) == get_stat(path)['own']
    os.unlink(path)
    assert Path(path).exists() is False



# Generated at 2022-06-23 18:24:12.052937
# Unit test for function get_os_group
def test_get_os_group():
    key_err_msg = 'The given name: %r, is not a valid "group name"'
    value_error_msg = 'The given gid: %r, is not a valid gid for this operating system.'
    try:
        get_os_group()
    except OSError as err:
        _LOGGER.warning(err)
    try:
        # noinspection PyTypeChecker
        get_os_group('')
    except OSError as err:
        _LOGGER.warning(err)
    try:
        # noinspection PyTypeChecker
        get_os_group(b'')
    except OSError as err:
        _LOGGER.warning(err)
    try:
        get_os_group('bar')
    except OSError as err:
        _

# Generated at 2022-06-23 18:24:16.143925
# Unit test for function chown
def test_chown():
    assert chown('/tmp', 'root', 'root') is None
    assert chown('/tmp', '-1', 'root') is None
    assert chown('/tmp', 'root', '-1') is None
    assert chown('/tmp', '-1', '-1') is None


# Generated at 2022-06-23 18:24:26.495221
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/') == 'directory'
    assert exists_as('~/..') == 'directory'
    assert exists_as('~/../..') == 'directory'
    assert exists_as('~/../../..') == 'directory'
    assert exists_as('~/../../../..') == ''
    assert exists_as('~/../../../../..') == ''
    assert exists_as('~/../../../../../..') == ''
    assert exists_as('~/../../../../../../..') == ''
    assert exists_as('~/../../../../../../../..') == ''

    test_file = directory_present('~/tmp/flutils.pathutils.txt')

# Generated at 2022-06-23 18:24:37.759485
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path"""

    assert normalize_path('~/tmp/foo/../bar') == \
        PosixPath('/home/test_user/tmp/bar')

    if os.name == 'nt':
        assert normalize_path('~/tmp/foo/../bar') == \
            WindowsPath('C:/Users/test_user/tmp/bar')

    assert normalize_path(Path('~/tmp/foo/../bar')).as_posix() == \
        '/home/test_user/tmp/bar'

    assert normalize_path(b'~/tmp/foo/../bar') == \
        PosixPath('/home/test_user/tmp/bar')


# Generated at 2022-06-23 18:24:48.031746
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.testing.helpers import monkeypatch, skipif_ci
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()

    def get_cwd_listdir() -> Generator[str, None, None]:
        """Get the current working directory listdir."""
        yield from os.listdir(os.getcwd())

    @skipif_ci()
    @monkeypatch(target='flutils.pathutils.directory_present',
                 attribute='exists_as',
                 new=get_cwd_listdir)
    def test_directory_present_absent():
        """Test pathutils.directory_present() returns a Path object."""
        from flutils.pathutils import exists_as
        from flutils.testing.helpers import get_cwd_os

# Generated at 2022-06-23 18:24:59.597850
# Unit test for function directory_present
def test_directory_present():
    import os
    import tempfile
    from flutils.pathutils import directory_present
    from flutils.pathutils import normalize_path
    from getpass import getuser
    from random import randint

    # test_directory_present__invalid
    def test_directory_present__invalid():
        with tempfile.TemporaryDirectory() as tmpdir:
            path = directory_present(
                os.path.join(tmpdir, 'p1', 'p2', '.\\foo\\*'),
                mode=0o700,
                user=getuser(),
                group=None
            )
            assert path == normalize_path(os.path.join(tmpdir, 'p1', 'p2'))

    # test_directory_present__empty

# Generated at 2022-06-23 18:25:05.301171
# Unit test for function get_os_user
def test_get_os_user():
    try:
        pwd.getpwnam(getpass.getuser())
    except KeyError:
        raise OSError(
            'The given name: %r, is not a valid "login name" '
            'for this operating system.' % getpass.getuser()
        )


get_os_user(getpass.getuser())


# Generated at 2022-06-23 18:25:13.705597
# Unit test for function path_absent
def test_path_absent():
    import os
    with TemporaryDirectory() as tmpdir:
        tmpdir = os.path.join(tmpdir, 'test_dir')
        path1 = os.path.join(tmpdir, 'test_path')
        path2 = os.path.join(tmpdir, 'test_dir_two')
        path3 = os.path.join(path2, 'test_path')
        path4 = os.path.join(path2, 'test_link_path')
        os.mkdir(tmpdir)
        os.mkdir(path2)
        # Mode 0000 so we cannot change permissions to delete
        os.mkdir(path3, mode=0o0000)
        open(path1, 'w').close()
        open(path4, 'w').close()
        os.symlink(path3, path4)


# Generated at 2022-06-23 18:25:17.335528
# Unit test for function get_os_group
def test_get_os_group():
    test_group = get_os_group()
    assert isinstance(test_group, grp.struct_group)


# Generated at 2022-06-23 18:25:28.558850
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from flutils.testutils import make_tmp_directory_tree

    class AssertRaisesContext:
        exc_type = None
        exception = None

        def __init__(self, exc_type):
            self.exc_type = exc_type

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            if exc_type is not None:
                # Save exception data if any is raised.
                self.exception = exc_val

            if exc_type == self.exc_type:
                return True
            else:
                return False


# Generated at 2022-06-23 18:25:39.931094
# Unit test for function directory_present
def test_directory_present():
    directory_present(__file__)
    directory_present(__file__, mode=0o700,
                      user=getpass.getuser(),
                      group=grp.getgrgid(os.getgid()).gr_name)
    directory_present(__file__)
    # Test a non-existent path
    directory_present(Path(__file__).parent.joinpath('nope'))
    # Test a relative path
    directory_present(Path('flutils/pathutils.py'))
    # Test an already existing directory
    tmp_dir = directory_present(Path().cwd().joinpath('.tmp'))
    directory_present(tmp_dir)
    tmp_dir.rmdir()
    # Test a glob pattern
    directory_present('flutils*')
    # Test a file path
    directory

# Generated at 2022-06-23 18:25:45.478821
# Unit test for function get_os_group
def test_get_os_group():
    test_name = get_os_user().pw_name
    test_gid = get_os_user().pw_gid
    group = get_os_group(test_name)
    assert group.gr_name == test_name
    assert group.gr_gid == test_gid
    group = get_os_group(test_gid)
    assert group.gr_name == test_name
    assert group.gr_gid == test_gid
    # Test that OSError is raised.
    with pytest.raises(OSError):
        get_os_group('xyz123')



# Generated at 2022-06-23 18:25:46.483305
# Unit test for function chown
def test_chown():
    assert False



# Generated at 2022-06-23 18:25:51.615695
# Unit test for function directory_present
def test_directory_present():
    os_path = directory_present(
        '/tmp/flutils.tests.osutils',
        mode=0o700,
    )
    assert os_path.absolute() == Path('/tmp/flutils.tests.osutils').absolute()
    assert os_path.is_dir() == True

# Generated at 2022-06-23 18:26:02.955312
# Unit test for function chown
def test_chown():
    """Make sure we can change ownership of a file or directory."""
    from flutils.osutils import get_os_user
    from flutils.pathutils import chown
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir) / 'flutils' / 'tests' / 'osutils'
        tmpdir.mkdir(parents=True, exist_ok=False)
        tmpfile = tmpdir / 'flutils.tests.osutils.txt'
        tmpfile.touch()
        osUser = get_os_user()
        chown(tmpfile, user=osUser.pw_name)
        assert tmpfile.owner() == osUser.pw_name
        # The group should now be based on the user's group.
        assert tmpfile.group() == osUser.p

# Generated at 2022-06-23 18:26:04.031186
# Unit test for function chown
def test_chown():
    raise NotImplementedError



# Generated at 2022-06-23 18:26:12.440854
# Unit test for function chmod
def test_chmod():
    #
    # Relative path
    #
    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = Path(tmpdirname)
        tmpfile = tmpdirname / 'file.txt'
        test_dir = tmpdirname / 'testdir'
        test_dir.mkdir()
        tmpfile.write_bytes(b'test')

        # Only change the mode of files.
        chmod(str(tmpdirname / '*.txt'), mode_file=0o660)
        assert tmpfile.stat().st_mode & 0o777 == 0o660
        assert test_dir.stat().st_mode & 0o777 == 0o700

        # Only change the mode of directories.
        chmod(str(tmpdirname / '*'), mode_dir=0o770)

# Generated at 2022-06-23 18:26:18.582276
# Unit test for function normalize_path
def test_normalize_path():
    import pytest
    from flutils.pathutils import normalize_path, exists_as

    for path in ('~/tmp/foo/../bar', '~/tmp', '~', '../tmp/../foo'):
        assert normalize_path(path) == normalize_path(Path(path))
        assert normalize_path(path).as_posix() == normalize_path(
            path.encode('utf-8')
        ).as_posix()

    with pytest.raises(TypeError):
        normalize_path(5)



# Generated at 2022-06-23 18:26:29.539685
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    import time
    import unittest

    import flutils.pathutils
    import flutils.tests.helpers


    class TestChown(flutils.tests.helpers.TestBase):

        def test_update_group_name(self):
            root = Path(tempfile.mkdtemp())
            os.chown(root.as_posix(), self.uid, self.gid)
            uid = getpwuid(os.stat(root.as_posix()).st_uid).pw_name
            gid = getgrgid(os.stat(root.as_posix()).st_gid).gr_name
            self.assertEqual(uid, self.user)
            self.assertEqual(gid, self.group)

            flutils.path

# Generated at 2022-06-23 18:26:31.985702
# Unit test for function get_os_group
def test_get_os_group():
    assert isinstance(get_os_group(), grp.struct_group)
    assert isinstance(get_os_group('bar'), grp.struct_group)

