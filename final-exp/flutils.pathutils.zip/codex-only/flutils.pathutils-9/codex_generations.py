

# Generated at 2022-06-23 18:16:39.291511
# Unit test for function exists_as
def test_exists_as():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        td = Path(td)
        assert exists_as(td) == 'directory'
        assert exists_as(td / 'test') == ''
        assert exists_as(__file__) == 'file'
        assert exists_as(__file__ / 'test') == ''

# Generated at 2022-06-23 18:16:45.057073
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() is not None
    try:
        get_os_user('bad_user')
    except OSError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 18:16:52.021654
# Unit test for function get_os_group
def test_get_os_group():
    expected = 'bar'
    gid = 2001
    grp_struct = grp.struct_group(
        gr_name=expected,
        gr_passwd='*',
        gr_gid=gid,
        gr_mem=['foo'],
    )

    ret = get_os_group(grp_struct.gr_name)

    assert ret.gr_name == expected
    assert ret.gr_gid == gid
    assert ret.gr_mem == grp_struct.gr_mem



# Generated at 2022-06-23 18:16:58.070807
# Unit test for function exists_as
def test_exists_as():
    """Test exists_as().

    .. note::
        This test will not run on Windows because of the use of
        :obj:`os.mkfifo()` which is not supported.

    """
    import os
    import os.path
    import tempfile

    from flutils.pathutils import exists_as
    from flutils.tests.helpers import TestData

    test_data = TestData(__file__)
    if os.name != 'nt':
        with tempfile.TemporaryDirectory(prefix=test_data.test_prefix) as dirpath:
            dirpath = os.path.abspath(dirpath)
            dir_path = os.path.join(dirpath, 'test_dir')
            file_path = os.path.join(dirpath, 'test_file')

# Generated at 2022-06-23 18:17:08.913060
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for the function 'normalize_path'.
    """
    assert normalize_path('.').as_posix() == os.getcwd()
    assert normalize_path('..').as_posix() == os.path.dirname(os.getcwd())

    assert normalize_path('~').as_posix() == os.path.expanduser('~')

    test_path = normalize_path('~/tmp/foo/../bar')
    assert test_path == os.path.join(os.path.expanduser('~'), 'tmp/bar')

    assert normalize_path('~/tmp/foo/../bar').as_posix() == os.path.join(
        os.path.expanduser('~'), 'tmp/bar'
    )

# Generated at 2022-06-23 18:17:13.332307
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo'])



# Generated at 2022-06-23 18:17:17.765516
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name != ''
    assert get_os_user(1000).pw_name != ''
    assert get_os_user(str(1000)).pw_uid != 0
    assert get_os_user(1000).pw_name == get_os_user(str(1000)).pw_name
    

# Generated at 2022-06-23 18:17:21.456581
# Unit test for function path_absent
def test_path_absent():
    from .tools import TempDir
    tmp = TempDir()
    os.makedirs(os.path.join(tmp.name, 'sub/subsub'))
    path_absent(tmp.name)

    tmp = TempDir()
    os.makedirs(os.path.join(tmp.name, 'sub/subsub'))
    path = os.path.join(tmp.name, 'sub/subsub')
    path_absent(path)


# Generated at 2022-06-23 18:17:25.448267
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError):
        get_os_group('bogus_group_name')
    with pytest.raises(OSError):
        get_os_group(9999999999)
    assert isinstance(get_os_group(), grp.struct_group)



# Generated at 2022-06-23 18:17:31.467581
# Unit test for function chown
def test_chown():
    test_dir = '/tmp/flutils.tests.path.chown'
    test_file = test_dir + '/foo.txt'
    test_dir2 = test_dir + '/foo'
    test_dirs = [
        test_dir,
        test_dir2
    ]
    for d in test_dirs:
        os.makedirs(d, exist_ok=True)
        with open(test_file, 'w') as fd:
            fd.write('tmp')
    chown(test_dir, include_parent=True)



# Generated at 2022-06-23 18:17:42.576757
# Unit test for function directory_present
def test_directory_present():
    import pathlib
    from flutils.pathutils import directory_present
    from flutils.tests.tutils import TESTS_DIR

    # Make a temporary directory to be used for testing
    # because the tests are destructive.
    path = pathlib.Path(TESTS_DIR).joinpath('test_directory_present')
    directory_present(path, mode=0o770)

    path = path.joinpath('child')
    directory_present(path, mode=0o770)

    path = path.joinpath('another child')
    directory_present(path, mode=0o770)

    # No error should be raised by this call because all
    # the paths exist.
    directory_present(path, mode=0o770)

    # Remove the path so it can be tested that it is created.
    path.rmdir

# Generated at 2022-06-23 18:17:51.460311
# Unit test for function normalize_path
def test_normalize_path():
    # pylint: disable=C0116
    import pytest  # type: ignore
    # pylint: enable=C0116

    # pylint: disable=C0103
    path = normalize_path(Path('~/tmp'))
    assert path.as_posix() == os.path.join(os.path.expanduser('~'), 'tmp')
    # pylint: enable=C0103

    path = normalize_path('~/tmp')
    assert path.as_posix() == os.path.join(os.path.expanduser('~'), 'tmp')

    with pytest.raises(TypeError):
        normalize_path(None)



# Generated at 2022-06-23 18:17:54.618661
# Unit test for function get_os_group
def test_get_os_group():
    gid = get_os_group('foo').gr_gid
    get_os_group(gid)

# Generated at 2022-06-23 18:18:04.344787
# Unit test for function find_paths
def test_find_paths():
    with temporary_directory() as dir_path:
        dir_path = Path(dir_path)
        file_one = dir_path / 'file_one'
        file_one.touch()
        dir_one = dir_path / 'dir_one'
        dir_one.mkdir()
        paths = list(find_paths(str(file_one)))
        assert len(paths) == 1
        assert paths[0].is_file()
        paths = list(find_paths(str(dir_one)))
        assert len(paths) == 1
        assert paths[0].is_dir()
        paths = list(find_paths(str(dir_path / '*')))
        assert len(paths) == 2


# Generated at 2022-06-23 18:18:12.108695
# Unit test for function chmod
def test_chmod():
    """Test for chmod."""

    from flutils.osutils import Path
    import tempfile

    tempdir = Path(tempfile.mkdtemp())

    # Create the file
    flutils_path = tempdir / 'flutils.tests.osutils.txt'
    flutils_path.write_text('This is a test.')

    chmod(flutils_path, 0o660)

    assert flutils_path.stat().st_mode == 33152

    # Convert to a directory
    flutils_path.unlink()
    flutils_path.mkdir()

    chmod(flutils_path, mode_file=0o660, mode_dir=0o770)

    assert flutils_path.stat().st_mode == 40960

    # Test out a glob pattern

# Generated at 2022-06-23 18:18:13.877083
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.cwd()) == 'directory'
    assert exists_as(Path.cwd() / 'setup.py') == 'file'



# Generated at 2022-06-23 18:18:14.779297
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:18:19.068799
# Unit test for function get_os_group
def test_get_os_group():
    import grp
    # TODO: Add tests for mac, linux and windows.
    # Get the current user's group.
    assert get_os_group() == grp.getgrgid(os.getgid())

    # Get a group with the current user's gid.
    assert get_os_group(os.getgid()) == grp.getgrgid(os.getgid())

    # Get a group with the current user's group name.
    assert get_os_group(grp.getgrgid(os.getgid()).gr_name) == grp.getgrgid(os.getgid())

    # None of these should work.
    with pytest.raises(OSError):
        get_os_group(999)

# Generated at 2022-06-23 18:18:24.188307
# Unit test for function path_absent
def test_path_absent():
    # Test variable
    path = '/tmp/test_path'
    os.mkdir(path)
    assert os.path.exists(path) is True
    path_absent(path)
    assert os.path.exists(path) is False


# Generated at 2022-06-23 18:18:29.937811
# Unit test for function path_absent
def test_path_absent():
    from pathlib import Path
    import stat

    test_path_root = Path(__file__).parent
    test_path_root = test_path_root / 'tmp'
    test_path_root = test_path_root.as_posix()
    test_path_root = cast(str, test_path_root)

    test_path_one = Path(test_path_root) / 'test_path_one'
    test_path_one = test_path_one.as_posix()
    test_path_one = cast(str, test_path_one)

    test_path_two = Path(test_path_one) / 'test_path_two'
    test_path_two = test_path_two.as_posix()

# Generated at 2022-06-23 18:18:41.014264
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path function."""
    # Test for string
    # @todo: This test needs to be updated to use
    # os.path.normpath(os.path.expanduser(path)).
    # This will normalize the pathname by collapsing redundant separators and
    # up-level references so that A//B, A/B/, A/./B and A/foo/../B all become
    # A/B.
    path = Path(__file__).parent
    yield assert_equal, normalize_path(path), path.as_posix()


normalize_path.register(bytes, normalize_path)



# Generated at 2022-06-23 18:18:51.814752
# Unit test for function path_absent
def test_path_absent():
    path = Path('test_path')
    path.mkdir(parents=True)
    path.joinpath('test_path_file').write_text('test')
    path_absent(path.as_posix())
    assert path.is_dir() is False
    assert path.is_file() is False
    assert path.exists() is False

    path.mkdir(parents=True)
    path_absent(path.as_posix())
    assert path.is_dir() is False
    assert path.is_file() is False
    assert path.exists() is False

    path.mkdir(parents=True)
    path.joinpath('test_path_file').write_text('test')
    path_absent(path.as_posix())
    assert path.is_dir() is False
   

# Generated at 2022-06-23 18:18:57.930695
# Unit test for function normalize_path
def test_normalize_path():
    if os.name == 'nt':
        os.environ['FOO'] = 'C:\\Utils'
        assert normalize_path('%FOO%\\bin\\some_file.jpg') == \
            Path('C:/Utils/bin/some_file.jpg')
        assert normalize_path('..\\foo\\file.jpg') == \
            Path('../foo/file.jpg')
        assert normalize_path('..\\foo\\file.jpg') == \
            Path('../foo/file.jpg')
        assert normalize_path('..\\foo\\file.jpg') == \
            Path('../foo/file.jpg')
        assert normalize_path('..\\foo\\file.jpg') == \
            Path('../foo/file.jpg')

# Generated at 2022-06-23 18:19:09.542189
# Unit test for function chown
def test_chown():
    # create a temporary file to set permission on.
    with open('/tmp/flutils.tests.osutils.txt', 'w') as f:
        pass

    # Change ownership of the file using the current user
    chown('/tmp/flutils.tests.osutils.txt')

    # Change ownership of the file using only the group
    chown(
        '/tmp/flutils.tests.osutils.txt',
        user=-1,
        group=getpass.getuser()
    )

    # Change ownership of the file using only the user
    chown(
        '/tmp/flutils.tests.osutils.txt',
        user=getpass.getuser(),
        group=-1
    )

    # Change ownership of the file by user and group

# Generated at 2022-06-23 18:19:15.874911
# Unit test for function find_paths
def test_find_paths():
    from os import mkdir, remove
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        parent = Path(tmpdir)
        for path in ('~/tmp/*', '~/tmp/test_dir/**'):
            path = normalize_path(path)
            assert path == parent / path.as_posix()[len(path.anchor):]
            assert path.as_posix() == str(path)

        txt_path = parent / 'file_one.txt'
        txt_path.touch()
        assert txt_path.is_file() is True
        assert exists_as(txt_path) == 'file'
        assert txt_path.exists() is True

        dir_path = parent / 'outer_dir'
        assert dir_path.is_dir() is False

# Generated at 2022-06-23 18:19:19.168373
# Unit test for function directory_present
def test_directory_present():
    base_path = normalize_path('~/tmp/flutils.tests.osutils')
    path = base_path.joinpath('test_directory_present')
    try:
        assert path == directory_present(path)
        assert path.is_dir() is True
        assert path.exists() is True
        base_path.rmdir()
    finally:
        if path.exists() is True:
            path.rmdir()
            base_path.rmdir()



# Generated at 2022-06-23 18:19:25.908979
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/../bar') == Path(os.path.expanduser('~/bar'))
    assert normalize_path('~/tmp/./../bar') == Path(os.path.expanduser('~/bar'))
    assert normalize_path('~/tmp//../bar') == Path(os.path.expanduser('~/bar'))
    assert normalize_path('~/tmp//./../bar') == Path(os.path.expanduser('~/bar'))
    assert normalize_path('~/tmp//./../bar/') == Path(os.path.expanduser('~/bar'))
    assert normalize_path('~/tmp/foo/../bar') == Path(os.path.expanduser('~/tmp/bar'))
    assert normalize_

# Generated at 2022-06-23 18:19:33.846287
# Unit test for function find_paths
def test_find_paths():
    paths = ['~/tmp/file_one', '~/tmp/dir_one']
    paths_map = {}

    for path in paths:
        path = normalize_path(path)
        paths_map[path.name] = path

    # Mock Path.glob()
    glob_mock = MagicMock(side_effect=_glob)
    with patch('flutils.pathutils.Path.glob', new=glob_mock):
        # Test
        result = list(find_paths('~/tmp/*'))

    assert result[0] == paths_map['file_one']
    assert result[1] == paths_map['dir_one']
    glob_mock.assert_called_once_with('~/tmp/*')

# Generated at 2022-06-23 18:19:46.321145
# Unit test for function find_paths
def test_find_paths():
    """Unit test for: ``find_paths``"""
    with TemporaryDirectory(prefix='flutils_test_') as tmpdir:
        tmpdir = Path(tmpdir).resolve()
        tmpdir.mkdir(parents=True)
        # Make sure that the prefix works
        assert tmpdir.name.startswith('flutils_test_') is True
        paths = []
        for i in range(1, 3):
            p = tmpdir / f'file_{i}'
            p.touch()
            paths.append(p.as_posix())
        for i in range(1, 3):
            p = tmpdir / f'dir_{i}'
            p.mkdir()
            paths.append(p.as_posix())
        # Because the results are in a generator,
        # we must convert the results to

# Generated at 2022-06-23 18:19:50.176696
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('foo').pw_uid == 1001
    assert get_os_user(1001).pw_name == 'foo'



# Generated at 2022-06-23 18:19:59.136602
# Unit test for function chmod
def test_chmod():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory(prefix='flutils_test_') as tmpdir:
        tmpdir = Path(tmpdir)

        filepath = tmpdir / 'file'
        filepath.touch()

        dirpath = tmpdir / 'dir'
        dirpath.mkdir()

        linkpath = tmpdir / 'link'
        linkpath.symlink_to(filepath)


# Generated at 2022-06-23 18:20:05.920731
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert get_os_user().pw_name == getpass.getuser()
    assert isinstance(get_os_user(1000), pwd.struct_passwd)
    assert get_os_user(1000).pw_uid == 1000
    assert get_os_user(1000).pw_name == 'testuser'



# Generated at 2022-06-23 18:20:13.508280
# Unit test for function path_absent
def test_path_absent():
    shutil.rmtree('/tmp/p_a_test')

    test_dir = Path('/tmp/p_a_test')
    test_dir.mkdir(mode=0o700)

    open(test_dir / 'file_one', 'a+').close()
    open(test_dir / 'file_two', 'a+').close()
    test_dir / 'file_three'.symlink_to(test_dir / 'file_one')

    test_dir / 'dir_one'.mkdir(mode=0o700)
    test_dir / 'dir_two'.mkdir(mode=0o700)
    test_dir / 'dir_three'.symlink_to(test_dir / 'dir_two')

    test_dir / 'dir_one' / 'file_one'.touch()


# Generated at 2022-06-23 18:20:17.942337
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_user."""
    assert get_os_user()
    assert get_os_user('foo')
    assert get_os_user(1001)
    assert get_os_user(1001)



# Generated at 2022-06-23 18:20:26.141176
# Unit test for function chmod
def test_chmod():
    path = Path(__file__).with_suffix('.txt')
    d_mode = 0o700
    f_mode = 0o660
    try:
        chmod(path, f_mode)
        chmod(path.parent, d_mode)
        assert mode(str(path)) == f_mode
        assert mode(str(path.parent)) == d_mode
    finally:
        chmod(path.parent, 0o755)
        path.unlink()



# Generated at 2022-06-23 18:20:30.862445
# Unit test for function get_os_group
def test_get_os_group():
    try:
        grp_info = get_os_group('test')  # nosec
    except OSError:
        assert True
    else:
        assert grp_info.gr_name != 'test'
    group_info = get_os_group()
    assert group_info.gr_name is not None

    try:
        grp_info = get_os_group(-1)  # nosec
    except OSError:
        assert True
    else:
        assert grp_info.gr_gid != -1



# Generated at 2022-06-23 18:20:33.029182
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root')
    assert get_os_user(0)
    assert get_os_user()



# Generated at 2022-06-23 18:20:45.196520
# Unit test for function get_os_user
def test_get_os_user():
    """Test the `pathutils.get_os_user` function."""
    from flutils.pathutils import get_os_user
    try:
        get_os_user()
    except OSError as exc:
        assert str(exc) == 'The given name: %r, is not a valid "login name" '\
            'for this operating system.' % getpass.getuser()
    try:
        get_os_user(0)
    except OSError as exc:
        assert str(exc) == 'The given uid: %r, is not a valid uid for this '\
            'operating system.' % 0
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_name == 'root'



# Generated at 2022-06-23 18:20:56.890591
# Unit test for function chown
def test_chown():
    from os import geteuid, getegid
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    import time

    def assert_fn(exc_type, exc_msg, exc_info):
        assert type(exc_info[1]) is exc_type
        assert str(exc_info[1]) == exc_msg

    with TemporaryDirectory() as tmp:
        tmp_dir = Path(tmp)

        tmp_dir.mkdir()
        # tmp_dir.chown(0, 0)
        tmp_dir.touch()

        # Test chown(invalid)
        # * user
        # * group
        with assert_raises(OSError) as exc_info:
            chown(tmp_dir, user='i_am_not_a_user')
        assert_fn

# Generated at 2022-06-23 18:21:09.756884
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from . import run_test

    # Test if path does not exist
    run_test(
        'exists_as no exist',
        exists_as,
        '~/flutils_test.doesnotexist',
        ''
    )

    # Test if path is a directory
    run_test(
        'exists_as dir',
        exists_as,
        '~/tmp',
        'directory'
    )

    # Test if path is a file
    run_test(
        'exists_as file',
        exists_as,
        '~/tmp/flutils.tests.osutils.txt',
        'file'
    )

    # Test if path is a broken symbolic link

# Generated at 2022-06-23 18:21:14.760570
# Unit test for function normalize_path
def test_normalize_path():

    # Test the function with a Path object
    path = Path('~/tmp/foo/../bar')
    assert normalize_path(path) == Path(
        os.path.join(os.path.expanduser('~'), 'tmp/bar'))

    # Test the function with a str.
    path = '~/tmp/foo/../bar'
    assert normalize_path(path) == Path(
        os.path.join(os.path.expanduser('~'), 'tmp/bar'))

    # Test the function with bytes.
    path = Path('~/tmp/foo/../bar').as_posix().encode(
        getfilesystemencoding())

# Generated at 2022-06-23 18:21:22.621767
# Unit test for function find_paths
def test_find_paths():
    # Setup
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        dir_path = Path(tmpdir) / 'dir_one'
        dir_path.mkdir()
        file_path = Path(tmpdir) / 'file_one'
        file_path.touch()

        search_dir = dir_path.parent
        search_pattern = dir_path.name + '*'

        paths = list(find_paths(search_dir / search_pattern))

        assert dir_path in paths
        assert file_path in paths



# Generated at 2022-06-23 18:21:29.744430
# Unit test for function chmod
def test_chmod():
    # Read in the Bash script that runs the unit tests.
    with open(
            Path(__file__).parent.joinpath(
                'test_chmod.bash'
            ).as_posix(),
            'r') as f:
        bash_script = f.read()

    # Get the file and directory names from the Bash script.
    _, _, file_dir_list = bash_script.partition('# Script created test files')
    file_dir_list, _, _ = file_dir_list.partition('# Script removed test files')

    # Get the test files & directories.
    file_dir_list = file_dir_list.splitlines()

# Generated at 2022-06-23 18:21:42.518628
# Unit test for function get_os_group
def test_get_os_group():
    group_one = get_os_group('foo')
    assert group_one.gr_gid == 1000
    assert group_one.gr_name == 'foo'
    assert list(group_one.gr_mem) == ['bar']

    # Get current user's group
    group_two = get_os_group()
    assert group_two.gr_gid == 1000
    assert group_two.gr_name == 'foo'
    assert list(group_two.gr_mem) == ['bar']

    with pytest.raises(OSError) as exception_info:
        get_os_group('this group name will not exist')

# Generated at 2022-06-23 18:21:53.366150
# Unit test for function find_paths
def test_find_paths():
    import os
    import hashlib
    import tempfile
    import time
    import typing

    def _get_md5sum(path: os.PathLike) -> str:
        md5 = hashlib.md5()
        with open(path, 'rb') as data:
            for chunk in iter(lambda: data.read(4096), b''):
                md5.update(chunk)
        return md5.hexdigest()

    def create_temp_file(
            base_dir: os.PathLike,
            zipped: bool = False
    ) -> os.PathLike:
        t_file = tempfile.NamedTemporaryFile(mode='w+b', dir=base_dir,
                                             delete=False)
        t_file.seek(1024)
        t_file.write(b'\0')

# Generated at 2022-06-23 18:21:55.654452
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('testpath') == Path('testpath')
    assert directory_present('testpath1', mode=0o777) == Path('testpath1')
# Done



# Generated at 2022-06-23 18:22:08.889223
# Unit test for function chown
def test_chown():
    import flutils
    import os

    # Setup test env
    rootdir = '/tmp/flutils-test'
    if os.path.isdir(rootdir):
        import shutil
        shutil.rmtree(rootdir)
    os.makedirs(rootdir)

    os.chdir(rootdir)
    os.mkdir('test-dir')

    # Create test file
    with open('a.txt', 'w') as f:
        f.write('test file')

    # Make symlink
    os.symlink('a.txt', 'a.txt.link')

    # Make subdirs
    for d in ['b', 'c']:
        os.mkdir(d)
        os.chdir(d)
        with open('a', 'w') as f:
            f.write

# Generated at 2022-06-23 18:22:11.236746
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~') == Path.home()
    assert normalize_path('/tmp') == Path('/tmp')



# Generated at 2022-06-23 18:22:19.845266
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from pathlib import Path
    from shutil import copytree, rmtree

    test_path = Path('~/tmp/test_path')
    test_path_absent = Path('~/tmp/test_path_absent')

    if test_path_absent.exists():
        rmtree(test_path_absent.as_posix())

    if test_path.exists():
        rmtree(test_path.as_posix())

    copytree(test_path_absent.as_posix(), test_path.as_posix())

    path_absent(test_path)
    assert test_path.exists() is False



# Generated at 2022-06-23 18:22:29.953422
# Unit test for function get_os_user
def test_get_os_user():
    import multiprocessing.process
    import tempfile

    user_name = get_os_user().pw_name
    process: multiprocessing.process.Process = multiprocessing.process.Process(
        target=get_os_user,
        args=(user_name,)
    )
    with tempfile.TemporaryDirectory() as tmp_dir:
        with tempfile.NamedTemporaryFile() as tmp_file:
            process.start()
            process.join()

            assert isinstance(process.exitcode, int)
            assert process.exitcode == 0

            assert isinstance(process.pid, int)
            try:
                os.kill(process.pid, 0)
            except OSError as e:
                assert isinstance(e, OSError)
                assert e.errno == errno

# Generated at 2022-06-23 18:22:41.182142
# Unit test for function directory_present
def test_directory_present():
    # Test creating a new directory
    path = Path('/tmp/flutils/pathutils/directory_present/')
    assert directory_present(path) == Path('/tmp/flutils/pathutils/directory_present/')
    assert path.exists() is True

    # Test modifying a directory that already exists.
    path = Path('/tmp/flutils/pathutils/directory_present/')
    assert directory_present(path) == Path('/tmp/flutils/pathutils/directory_present/')

    # Test creating a new directory.
    path = Path('/tmp/flutils/pathutils/directory_present/test')
    assert directory_present(path) == Path('/tmp/flutils/pathutils/directory_present/test')
    assert path.exists() is True

    # Test modifying a directory that already exists.


# Generated at 2022-06-23 18:22:48.036271
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as fpath:
        gpath = Path(fpath)
        for num in range(1, 4):
            fname = f'file_{num}'
            dname = f'dir_{num}'
            gpath.joinpath(fname).touch()
            gpath.joinpath(dname).mkdir()
        # This is to test a pattern that is not found.
        assert list(find_paths(str(gpath.joinpath('*_four')))) == []

        result = list(find_paths(str(gpath.joinpath('*_1'))))
        result.sort(key=str)
        assert result == [gpath.joinpath('dir_1'), gpath.joinpath('file_1')]



# Generated at 2022-06-23 18:23:00.182425
# Unit test for function chown
def test_chown():
    _user = getpass.getuser()
    _group = grp.getgrgid(os.getgid()).gr_name
    test_file = Path(
        os.path.expanduser(
            os.path.join('~', 'tmp', 'flutils.tests.osutils.txt')
        )
    )
    test_file_pattern = Path(
        os.path.expanduser(
            os.path.join('~', 'tmp', 'flutils.tests.osutils.*')
        )
    )
    test_dir = Path(os.path.expanduser(os.path.join('~', 'tmp')))

    path_absent(test_file)


# Generated at 2022-06-23 18:23:06.558382
# Unit test for function find_paths
def test_find_paths():
    from os import walk
    from .osutils import makedirs

    root_path = Path('~/tmp/flutils-test-find-paths')
    path_1 = root_path / 'path_1.txt'
    path_2 = root_path / 'path_2.txt'
    path_3 = root_path / 'path_3.txt'
    path_4 = root_path / 'path_4.txt'

    makedirs(root_path)


# Generated at 2022-06-23 18:23:15.436402
# Unit test for function chmod
def test_chmod():
    """
    .. code-block:: none

        pytest tests/test_pathutils.py::test_chmod
    """
    try:
        user = getpass.getuser()
    except KeyError:
        # Most likely on Windows.
        user = 'USERNAME'

    path = Path(f'/etc/nsswitch.conf')
    dir_path = Path('~').expanduser().joinpath(
        'tmp',
        'flutils',
        'tests',
        'pathutils',
    )

    tmp_ame = 'tmp_file.txt'
    tmp_path = dir_path.joinpath(tmp_ame)

    # Cleanup
    if tmp_path.is_file() is True:
        tmp_path.unlink()

# Generated at 2022-06-23 18:23:23.601621
# Unit test for function find_paths
def test_find_paths():
    pattern = normalize_path('~/tmp/**')
    found_paths = []
    for path in find_paths(pattern):
        found_paths.append(path)
    assert len(found_paths) == 2
    assert found_paths == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one'),
    ]



# Generated at 2022-06-23 18:23:30.340896
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        foo = Path(tempdir) / 'foo'
        bar = foo / 'bar'
        baz = bar / 'baz'
        foo.mkdir()
        bar.mkdir()
        baz.mkdir()
        assert os.path.exists(foo.as_posix()) is True
        assert os.path.exists(bar.as_posix()) is True
        assert os.path.exists(baz.as_posix()) is True
        path_absent(bar)
        assert os.path.exists(foo.as_posix()) is True
        assert os.path.exists(bar.as_posix()) is False
        assert os.path.ex

# Generated at 2022-06-23 18:23:39.511767
# Unit test for function get_os_group
def test_get_os_group():
    # Test: Basic tests
    os_grp = get_os_group('bar')
    assert os_grp.gr_name == 'bar'
    assert os_grp.gr_passwd == '*'
    assert os_grp.gr_gid == 2001
    assert os_grp.gr_mem == ['foo']
    # Test: OSError tests
    with pytest.raises(OSError) as exc_info:
        get_os_group(2002)
    assert exc_info.type is OSError
    assert exc_info.value.args[0] == (
        'The given gid: 2002, is not a valid gid for this operating system.'
    )
    with pytest.raises(OSError) as exc_info:
        get_os_group('baz')


# Generated at 2022-06-23 18:23:49.834883
# Unit test for function normalize_path
def test_normalize_path():
    import os
    import sys

    from flutils.pathutils import normalize_path

    assert os.sep + 'home' + os.sep + 'foo' == normalize_path('~/foo')
    assert os.sep + 'home' + os.sep + 'foo' == normalize_path('$HOME/foo')
    assert os.sep + 'home' + os.sep + 'foo' == normalize_path('$HOME/../foo')

    cur_dir = os.getcwd()
    new_dir = os.path.split(cur_dir)[0]
    os.chdir(new_dir)
    try:
        assert cur_dir == normalize_path(os.path.split(cur_dir)[1])
    finally:
        os.chdir(cur_dir)

   

# Generated at 2022-06-23 18:23:57.479373
# Unit test for function directory_present
def test_directory_present():
    assert directory_present(__file__, mode=0o700).exists()
    assert directory_present(__file__, mode=0o700).is_dir()
    user = getpass.getuser()
    assert directory_present(__file__, user=user).exists()
    group = getpass.getuser()
    assert directory_present(__file__, group=group).exists()
    assert directory_present(__file__, mode=0o700, user=user, group=group)

# Generated at 2022-06-23 18:24:01.421327
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert user is not None



# Generated at 2022-06-23 18:24:03.915527
# Unit test for function chown
def test_chown():
    """
    This function is called by the flutils_tests module,
    and does not have a unit test itself.
    """
    pass



# Generated at 2022-06-23 18:24:04.840842
# Unit test for function path_absent
def test_path_absent():
    # TODO: Add unit tests
    assert False



# Generated at 2022-06-23 18:24:15.742892
# Unit test for function directory_present
def test_directory_present():
    import pytest
    from .osutils import (
        my_username,
        my_group,
    )
    from .files import (
        create_test_file,
    )

    try:
        my_uid = get_os_user().pw_uid
        my_gid = get_os_group().gr_gid
    except KeyError:
        pytest.skip('Unable to determine the UID and'
                    ' GID of the current user.')

    # On some systems like on Travis CI there is no HOME environment
    # variable set so we'll default to '/tmp'.
    my_home = os.environ.get('HOME', '/tmp')

    with create_test_file(parent=my_home) as _:
        assert exists_as(my_home) == 'directory'
        assert exists_as

# Generated at 2022-06-23 18:24:25.713336
# Unit test for function chmod
def test_chmod():
    import shutil
    import tempfile

    TEMP_DIR = Path(tempfile.mkdtemp())
    FILENAME = 'mode_file.txt'
    FILEPATH = TEMP_DIR / FILENAME
    FILEPATH.touch()
    CHANGE_MODE_DIR = 0o755
    CHANGE_MODE_FILE = 0o660
    NEW_MODE_DIR = CHANGE_MODE_DIR
    NEW_MODE_FILE = CHANGE_MODE_FILE

    TEMP_DIR.chmod(0o700)
    chmod(FILEPATH.as_posix(), CHANGE_MODE_FILE)
    chmod(TEMP_DIR.as_posix(), mode_dir=CHANGE_MODE_DIR)

# Generated at 2022-06-23 18:24:35.065587
# Unit test for function find_paths
def test_find_paths():
    with TempFileManager(directory='/tmp') as mgr:
        mgr.create_file('/tmp/file_one', 'File one')
        mgr.create_file('/tmp/file_two', 'File two')
        mgr.create_file('/tmp/file_three', 'File three')
        mgr.create_directory('/tmp/dir_one')
        mgr.create_directory('/tmp/dir_two')

        assert list(find_paths('/tmp/file_*')) == [
            Path('/tmp/file_one'),
            Path('/tmp/file_three'),
            Path('/tmp/file_two')
        ]



# Generated at 2022-06-23 18:24:41.296430
# Unit test for function get_os_group
def test_get_os_group():
    # Need to validate for different OS users
    # as groups can vary per OS user.
    # To validate, need to just know if valid
    # or not.
    user = cast(grp.struct_group, get_os_group('bar')).gr_name
    assert user == 'bar', 'get_os_group() should find a group named "bar"'



# Generated at 2022-06-23 18:24:49.947842
# Unit test for function path_absent
def test_path_absent():
    os.chdir('/tmp')
    path = 'test_path_absent'
    os.mkdir(path)
    with open(os.path.join(path, 'test_file'), 'w+') as f:
        f.write('Testing 1, 2, 3.')
    path_absent(path)
    assert not os.path.exists(path)
    path = Path('test_path_absent')
    path.mkdir()
    with open(os.path.join(path, 'test_file'), 'w+') as f:
        f.write('Testing 1, 2, 3.')
    path_absent(path)
    assert not os.path.exists(path)
    path = os.path.join(path, 'test_file')

# Generated at 2022-06-23 18:25:01.861928
# Unit test for function directory_present
def test_directory_present():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        new_dir = directory_present(
            Path(tmpdir) / 'new_dir'
        )
        assert new_dir.is_dir() is True
        assert new_dir.is_absolute() is True
        assert new_dir.exists() is True

        new_dir = directory_present(
            Path(tmpdir) / 'new_dir2',
            user='root'
        )
        assert new_dir.is_dir() is True
        assert new_dir.is_absolute() is True
        assert new_dir.exists() is True
        assert new_dir.owner() == 'root'


# Generated at 2022-06-23 18:25:04.571551
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    pwd_rec = get_os_user()
    assert pwd_rec.pw_name == getpass.getuser()
    assert isinstance(pwd_rec, pwd.struct_passwd)



# Generated at 2022-06-23 18:25:06.959279
# Unit test for function directory_present
def test_directory_present():
    assert repr(directory_present('~/tmp/foo')) == repr(Path('~/tmp/foo').expanduser())



# Generated at 2022-06-23 18:25:14.779055
# Unit test for function get_os_user
def test_get_os_user():
    # Test if it returns the current user
    if sys.platform == 'win32':
        assert get_os_user().pw_name == getpass.getuser().lower()
    else:
        assert get_os_user().pw_name == getpass.getuser()

    # Test if it returns a user based on name
    # This test could fail if the uid for root is not 0
    assert get_os_user('root').pw_uid == 0



# Generated at 2022-06-23 18:25:19.729890
# Unit test for function find_paths
def test_find_paths():
    with change_directory(Path(__file__).parent.anchor):
        assert list(find_paths('.')) == [
            Path(__file__).parent.anchor,
            Path(__file__).parent.anchor / '__pycache__'
        ]



# Generated at 2022-06-23 18:25:21.399095
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    assert True is True



# Generated at 2022-06-23 18:25:25.613064
# Unit test for function exists_as
def test_exists_as():
    path = Path(__file__).parent
    assert exists_as(path) == 'directory'
    assert exists_as(__file__) == 'file'
    assert exists_as(path / 'foobar') == ''



# Generated at 2022-06-23 18:25:38.065809
# Unit test for function chmod
def test_chmod():
    assert 'home' in os.environ
    home = os.environ['HOME']

    path = f'{home}/tmp/flutils.tests.osutils.txt'
    directory = f'{home}/tmp/flutils.tests.osutils.dir'

    if os.path.exists(path) is True:
        os.remove(path)
    if os.path.exists(directory) is True:
        os.rmdir(directory)

    Path(directory).mkdir()

    with open(path, 'w'):
        pass

    chmod(path, 0o660)
    chmod(directory, 0o770)

    assert os.stat(path)[0] == 0o100660
    assert os.stat(directory)[0] == 0o160755

    os.remove(path)


# Generated at 2022-06-23 18:25:46.950348
# Unit test for function chown
def test_chown():
    import mock
    import pytest

    chunk_size = 1024
    bytes_count = (5*1024**2) + (128*1024)

    test_file = '~/foo.txt'
    p = mock.patch('os.chown')
    m = p.start()
    try:
        chown(test_file)
        m.assert_called_once_with(
            expanduser(test_file),
            get_os_user().pw_uid,
            get_os_user().pw_gid
        )
    finally:
        p.stop()

    p = mock.patch('os.path.exists', return_value=True)
    m = p.start()
    e = mock.patch('os.chown')
    n = e.start()

# Generated at 2022-06-23 18:25:52.185948
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function :func:`~flutils.pathutils.get_os_user`.
    """
    user_foo = get_os_user('foo')
    assert isinstance(user_foo, pwd.struct_passwd)
    assert user_foo.pw_name == 'foo'



# Generated at 2022-06-23 18:26:03.562669
# Unit test for function exists_as
def test_exists_as():
    import flutils.pathutils

    model_path = Path(__file__).resolve().parent.joinpath('data', 'exists_as')
    model_path_str = model_path.as_posix()
    model_path_str = model_path_str.replace('__init__.py', '')
    model_path_bytes = model_path_str.encode()

    for file_path in model_path.glob('**/*'):
        for path in [file_path, str(file_path), model_path_str + str(file_path),
                model_path_bytes + file_path.as_posix().encode()]:
            assert flutils.pathutils.exists_as(path) == ''
            os.makedirs(path)
            assert flutils.pathutils.exists

# Generated at 2022-06-23 18:26:12.244171
# Unit test for function chown
def test_chown():
    # Setup the environment
    path = Path('~/tmp/foo.txt').expanduser().as_posix()
    os.makedirs(Path(path).parent.as_posix(), exist_ok=True)
    with open(path, 'w') as fd:
        fd.write('foo')
    # Test it
    try:
        chown(path, user='foo', group='bar')
    except OSError:
        pass
    else:
        # Cleanup the environment
        os.remove(path)
        os.removedirs(Path(path).parent.as_posix())
        raise AssertionError('OSError not raised')
    # Cleanup the environment
    os.remove(path)
    os.removedirs(Path(path).parent.as_posix())



# Generated at 2022-06-23 18:26:24.554166
# Unit test for function exists_as
def test_exists_as():
    # Test returns 'directory' for directories

    # Test returns 'file' for files

    # Test returns '' if path does not exist
    assert exists_as('/tmp/foo') == ''

    # Test returns 'FIFO' for FIFO pipes
    assert exists_as('/dev/null') == 'FIFO'

    # Test returns 'socket' for sockets
    assert exists_as('/var/run/syslog') == 'socket'

    # Test returns 'block device' for block devices
    assert exists_as('/dev/sda') == 'block device'

    # Test returns 'char device' for char devices
    assert exists_as('/dev/urandom') == 'char device'

    # Test returns '' if path is a broken symlink
    pytest.xfail()
    # assert exists_as('/tmp/

# Generated at 2022-06-23 18:26:34.072206
# Unit test for function get_os_group
def test_get_os_group():
    # Test the given name exists in the OS
    result = get_os_group()
    assert result.gr_name == 'nobody'
    assert result.gr_passwd == '*'
    assert result.gr_gid == -2
    assert result.gr_mem == []

    # Test given name does not exist
    with pytest.raises(OSError):
        get_os_group('foo')

    # Test given gid does exist in the OS
    result = get_os_group(result.gr_gid)
    assert result.gr_name == 'nobody'
    assert result.gr_passwd == '*'
    assert result.gr_gid == -2
    assert result.gr_mem == []

    # Test given gid does not exist in the OS