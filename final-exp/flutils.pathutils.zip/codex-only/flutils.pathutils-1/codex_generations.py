

# Generated at 2022-06-23 18:16:43.329726
# Unit test for function directory_present
def test_directory_present():
    """Test function directory_present."""
    path = Path('~/tmp/flutils.tests.pathutils.directory_present')

    if path.exists() is True:
        path.rmdir()

    path.mkdir(mode=0o770)
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_mode == 0o40700
    test_dir = directory_present(path, mode=0o444)
    assert test_dir.stat().st_mode == 0o40444
    assert path == test_dir

    path.rmdir()
    assert path.exists() is False
    test_dir = directory_present(path, mode=0o444)
    assert test_dir.stat().st_mode == 0o40444
    assert test

# Generated at 2022-06-23 18:16:44.734861
# Unit test for function find_paths
def test_find_paths():
    find_paths('~/tmp/**')



# Generated at 2022-06-23 18:16:54.220029
# Unit test for function path_absent
def test_path_absent():
    normalize_path = flutils.pathutils.normalize_path
    os.listdir = mock.Mock(return_value=())
    os.unlink = mock.Mock()
    os.rmdir = mock.Mock()
    os.path.isfile = mock.Mock(return_value=True)
    os.path.islink = mock.Mock(return_value=False)
    os.path.isdir = mock.Mock(return_value=False)
    os.path.exists = mock.Mock(return_value=True)
    path_absent = flutils.pathutils.path_absent
    path_absent(normalize_path('~/tmp/test_path'))

# Generated at 2022-06-23 18:16:57.709978
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('root') == pwd.getpwnam('root')



# Generated at 2022-06-23 18:16:58.932729
# Unit test for function chmod
def test_chmod():
    assert True == False


# Generated at 2022-06-23 18:17:03.029701
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == getpass.getuser()
    with pytest.raises(OSError):
        get_os_user('does_not_exist')



# Generated at 2022-06-23 18:17:11.914067
# Unit test for function directory_present

# Generated at 2022-06-23 18:17:12.560410
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-23 18:17:13.293888
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:17:14.651691
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.cwd()) == 'directory'



# Generated at 2022-06-23 18:17:26.138247
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / 'test_dir_one'
        path.mkdir(mode=0o700)
        path_absent(path)
        assert not path.exists(), 'path_absent failed to delete directory.'
        path = Path(td) / 'test_dir_two'
        path.mkdir(mode=0o700)
        path = path / 'test_file_one'
        path.touch()
        path_absent(path)
        assert not path.exists(), 'path_absent failed to delete file.'
        path = Path(td) / 'test_symlink_one'
        path.symlink_to('bar')
        path_absent(path)

# Generated at 2022-06-23 18:17:34.628364
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    try:
        test_path = Path(temp_dir, 'test_path')
        test_path.mkdir(mode=0o700)
        test_path.joinpath('test_file').write_text('test')
        assert test_path.is_dir()
        path_absent(test_path)
        assert test_path.exists() is False
    finally:
        shutil.rmtree(temp_dir)



# Generated at 2022-06-23 18:17:43.892216
# Unit test for function directory_present
def test_directory_present():
    # Mock objects.
    class MockPosixPath(PosixPath):

        def mkdir(self, mode=None):
            print('MockPosixPath.mkdir()')

    class MockWindowsPath(WindowsPath):

        def mkdir(self, mode=None):
            print('MockPosixPath.mkdir()')

    mock_paths = [
        functools.partial(MockPosixPath, '/root/foo/bar'),
        functools.partial(MockWindowsPath, 'C:\\root\\foo\\bar'),
    ]

    # Test the function itself.
    for mock_path in mock_paths:
        directory_present(mock_path())



# Generated at 2022-06-23 18:17:44.230425
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:17:55.592832
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present."""
    from os import (
        chmod,
        getuid,
        getgid,
        uname,
    )
    from os.path import (
        exists,
        isdir,
        join,
    )
    from shutil import (
        copyfile,
        rmtree,
    )
    from tempfile import (
        mkdtemp,
        NamedTemporaryFile,
    )
    from unittest import TestCase

    from flutils.pathutils import (
        directory_present,
        normalize_path,
    )

    class TestDirectoryPresent(TestCase):
        """Unit test for function directory_present."""

        def setUp(self):
            """Set up the tests."""
            self._temp_dir = mkdtemp()


# Generated at 2022-06-23 18:17:56.057032
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:18:03.069384
# Unit test for function chown
def test_chown():
    assert chown(__file__)
    assert chown(__file__, user='-1')
    assert chown(__file__, user=None)
    assert chown(__file__, user=getpass.getuser())
    assert chown(__file__, group='-1')
    assert chown(__file__, group=None)
    assert chown(__file__, group=grp.getgrgid(os.getgid()).gr_name)



# Generated at 2022-06-23 18:18:14.425459
# Unit test for function directory_present
def test_directory_present():
    path = Path(__file__).parent.joinpath('tests_directory_present')
    directory_present(path)
    assert path.exists()

    path = Path(__file__).parent.joinpath('tests_directory_present')
    directory_present(path)
    assert path.exists()

    path = Path(__file__).joinpath('tests_directory_present.txt')
    try:
        directory_present(path)
    except FileExistsError:
        pass
    else:
        assert False

    try:
        path = Path(__file__).parent.joinpath('tests_directory_present', '*')
        directory_present(path)
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 18:18:17.691704
# Unit test for function get_os_group
def test_get_os_group():
    """Test the get_os_group() function."""
    # By default get_os_group will use the current user's group.
    group = get_os_group()
    assert isinstance(group, grp.struct_group)
    assert group.gr_gid == get_os_user().pw_gid
    group = get_os_group(get_os_user().pw_gid)
    assert isinstance(group, grp.struct_group)
    assert group.gr_gid == get_os_user().pw_gid


# Generated at 2022-06-23 18:18:29.271710
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    # fmt: off

# Generated at 2022-06-23 18:18:29.718670
# Unit test for function chmod
def test_chmod():
    pass

# Generated at 2022-06-23 18:18:42.598836
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from flutils.pathutils import path_absent
    from tempfile import TemporaryDirectory
    from os import chmod as os_chmod


    # Chmod of a file
    with TemporaryDirectory() as tmpdir:
        tmpfile = Path(tmpdir) / 'flutils.tests.osutils.txt'
        tmpfile.touch()
        os_chmod(tmpfile.as_posix(), 0o644)
        assert os.stat(tmpfile.as_posix()).st_mode & 0o777 == 0o644
        chmod(tmpfile, 0o660)
        assert os.stat(tmpfile.as_posix()).st_mode & 0o777 == 0o660
        chmod(tmpfile.as_posix(), 0o700)
        assert os.stat

# Generated at 2022-06-23 18:18:52.964176
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    from flutils.testing import capture_stdout

    with TemporaryDirectory() as tmp_dir:
        path = Path(tmp_dir) / 'test_path'
        assert not path.exists()
        path_absent(path)
        assert not path.exists()
        path.write_text('foo')
        assert path.exists()
        path.symlink_to(path / 'link')
        assert (path / 'link').is_symlink()
        path_absent(path)
        assert not path.exists()
        assert not (path / 'link').is_symlink()

        path = Path(tmp_dir) / 'dir1' / 'dir2' / 'dir3' / 'dir4'
        assert not path.exists()

# Generated at 2022-06-23 18:18:58.730619
# Unit test for function normalize_path
def test_normalize_path():

    # pylint: disable=W0212
    # pylint: disable=W0612

    def side_effect(path):
        return '/home/test_user'

    #: :type: unittest.TestCase
    tc = unittest.TestCase()


# Generated at 2022-06-23 18:19:02.766121
# Unit test for function exists_as
def test_exists_as():
    path = Path('/Users/len')
    assert exists_as(path) == 'directory'
    path = Path('/Users/len/Library/Application Support/Google/Chrome/Default/History')
    assert exists_as(path) == 'file'



# Generated at 2022-06-23 18:19:08.207829
# Unit test for function get_os_user
def test_get_os_user():
    """Test for function get_os_user."""
    user_info = get_os_user('root')
    assert user_info.pw_name == 'root'
    assert user_info.pw_shell == '/usr/bin/bash'
    assert user_info.pw_gecos == 'root'



# Generated at 2022-06-23 18:19:14.052002
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from textwrap import dedent
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        other_tmpdir = tmpdir / 'other_tmpdir'
        other_tmpdir.mkdir()
        path = other_tmpdir / 'test_dir'

        directory_present(path)
        assert path.is_dir()

        path.mkdir()
        with path.open('w') as f:
            f.write(dedent('''\
                a
                b
                c
            '''))

# Generated at 2022-06-23 18:19:24.740914
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    def _cleanup():
        for p in Path().glob('~/tmp/flutils.tests.osutils.*'):
            # pylint: disable=broad-except
            try:
                p.unlink()

            except Exception:
                pass

    _cleanup()

    path0 = '~/tmp/flutils.tests.osutils.txt'
    path1 = '~/tmp/flutils.tests.osutils.dir'
    path2 = '~/tmp/flutils.tests.osutils.txt'

    Path(path0).touch()
    Path(path1).mkdir()
    Path(path1).chmod(0o700)
    Path(path2).symlink_to(path0)

    p0 = Path(path0)
   

# Generated at 2022-06-23 18:19:33.416206
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    from tempfile import TemporaryFile
    from flutils.pathutils import normalize_path
    import os

    tmp_path = Path(normalize_path('~/tmp/flutils.tests/exists_as'))
    tmp_path.mkdir(parents=True, exist_ok=True)

    # Test directory
    tmp_path = Path(normalize_path('~/tmp/flutils.tests/exists_as/dir'))
    if tmp_path.exists():
        tmp_path.rmdir()
    tmp_path.mkdir(parents=True, exist_ok=True)
    assert exists_as(tmp_path) == 'directory'

    # Test file

# Generated at 2022-06-23 18:19:43.470170
# Unit test for function chown
def test_chown():
    path = 'flutils.tests.osutils.txt'
    abspath = os.path.abspath(path)
    with open(path, 'w') as f:
        f.write('testing')
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        assert os.path.exists(abspath)
        assert os.path.isfile(abspath)
        chown(path, include_parent=True)
        fstat = os.stat(abspath)
        assert fstat.st_uid == os.getuid()
        assert fstat.st_gid == os.getgid()
        # test mode change
        chown(path, user='root', group='wheel')
        fstat = os.stat(abspath)
        assert fstat

# Generated at 2022-06-23 18:19:50.826492
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as(Path().cwd()) == 'directory'
    assert exists_as(Path() / 'tmp' / 'tmp' / 'tmp') == ''
    assert exists_as('/etc') == 'directory'
    assert exists_as('/non-existent') == ''



# Generated at 2022-06-23 18:19:58.733520
# Unit test for function exists_as
def test_exists_as():
    from flutils.systemutils import is_posix
    from flutils.pathutils import directory_present

    if is_posix() is True:
        tempdir = directory_present('/tmp/flutils.tests.pathutils')

        with tempdir.joinpath('link-to-file').open(mode='w') as f:
            f.write('testing')

        (tempdir / 'link-to-file').symlink_to('link-to-file')
        assert exists_as(tempdir / 'link-to-file') == 'file'
        assert exists_as(tempdir / 'link-to-file-link') == 'file'

        tempdir.rmdir()



# Generated at 2022-06-23 18:20:03.324946
# Unit test for function get_os_user
def test_get_os_user():
    if _IS_WINDOWS is False:
        assert get_os_user() == pwd.getpwuid(os.getuid())
    else:
        assert get_os_user(getpass.getuser()) == get_os_user()



# Generated at 2022-06-23 18:20:04.360111
# Unit test for function chown
def test_chown():
    assert False

# Generated at 2022-06-23 18:20:12.063139
# Unit test for function path_absent
def test_path_absent():
    HOME = normalize_path('~')
    TEST_DIR = HOME / 'tmp'
    TEST_FILE = TEST_DIR / 'file'
    TEST_DIR_ONE = TEST_DIR / 'dir_one'
    TEST_DIR_TWO = TEST_DIR / 'dir_two'

    path_present(
      path=TEST_DIR,
      mode_dir=0o700,
    )
    path_present(
      path=TEST_FILE,
      content='This is a test file',
      mode_file=0o600,
    )
    path_present(
      path=TEST_DIR_ONE,
      mode_dir=0o700,
    )
    path_present(
      path=TEST_DIR_TWO,
      mode_dir=0o700,
    )
    path

# Generated at 2022-06-23 18:20:14.126592
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group(os_user.pw_gid)
    assert isinstance(group, grp.struct_group)
    assert group.gr_name == os_user.pw_name



# Generated at 2022-06-23 18:20:27.550679
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        chmod(tmp_dir, mode_file=0o640, mode_dir=0o700, include_parent=True)
        file_path = chmod(
            os.path.join(tmp_dir, 'flutils.tests.osutils.txt'),
            mode_file=0o640,
            mode_dir=0o700,
            include_parent=True
        )

    # Test the file_path returned by chmod()
    assert isinstance(file_path, Path)
    assert file_path.exists() is True
    assert file_path.is_dir() is False
    assert file_path.is_file() is True
    # https://stackoverflow.com/a/

# Generated at 2022-06-23 18:20:38.180840
# Unit test for function directory_present
def test_directory_present():
    path = Path('/tmp/foo/')
    mode = 0o700
    user = 'foo'
    group = 'bar'

    def test_exception(exc, expected_exception):
        try:
            directory_present(path, mode, user, group)
        except exc as err:
            assert isinstance(err, expected_exception)

    # Test when path contains a glob pattern
    path = Path('/tmp/foo*/')
    test_exception(ValueError, ValueError)

    # Test when path is not an absolute path
    path = Path('foo')
    test_exception(ValueError, ValueError)

    # Test when path is not absolute and contains a glob pattern
    path = Path('foo*')
    test_exception(ValueError, ValueError)

    # Test when path exists and is not a

# Generated at 2022-06-23 18:20:48.040101
# Unit test for function directory_present
def test_directory_present():
    """Test for function directory_present()
    """
    import shutil
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        from pathlib import Path
        from .pathutils import directory_present, normalize_path

        tmp_path = Path(tmp_dir)

        tmp_dir_path = tmp_path.joinpath('tmp')
        assert not tmp_dir_path.exists()
        assert directory_present(tmp_dir_path) == tmp_dir_path
        assert tmp_dir_path.exists()

        # Testing with a glob pattern.
        tmp_dir_path = tmp_path.joinpath('tmp_dir_2*')
        assert not tmp_dir_path.exists()

# Generated at 2022-06-23 18:20:59.207613
# Unit test for function exists_as
def test_exists_as():
    # type: () -> None
    '''Unit test for function exists_as.'''
    # pylint: disable=no-self-use
    from flutils.pathutils import directory_present, exists_as
    import os

    with directory_present('/tmp/exists_as_test') as test_path:
        with test_path.joinpath('exists_file.txt').open('w+') as exists_file:
            exists_file.write('foo')

        assert exists_as('/tmp/exists_as_test') == 'directory'
        assert exists_as('/tmp/exists_as_test/exists_file.txt') == 'file'
        assert exists_as('/tmp/exists_as_test/exists_file.txt2') == ''

# Generated at 2022-06-23 18:21:09.872775
# Unit test for function exists_as
def test_exists_as():
    r"""Test exists_as function."""
    from flutils.testutils import unit_test_entry_point
    from flutils.testutils import TestBase, test_data_path

    class TestExistsAs(TestBase):
        """Test exists_as function."""

        def test_normal_use(self):
            """Test normal use."""
            expected = 'directory'
            test_path = test_data_path(self.__class__.__module__)
            actual = exists_as(test_path)
            self.assertEqual(actual, expected)

        def test_nonexistent_path(self):
            """Test with a nonexistent path."""
            expected = ''
            test_path = test_data_path(self.__class__.__module__) / 'foo'

# Generated at 2022-06-23 18:21:17.771726
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory
    from flutils import rootpath

    with TemporaryDirectory(prefix='tmp.test_find_paths') as tmp:
        for path in [
                Path(tmp).joinpath('file_one'),
                Path(tmp).joinpath('dir_one'),
                Path(tmp).joinpath('dir_two', 'file_one'),
                Path(tmp).joinpath('dir_one', 'file_one'),
        ]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch()


# Generated at 2022-06-23 18:21:18.459940
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:21:22.019518
# Unit test for function get_os_user
def test_get_os_user():
    test_list = [None, 0, 'root', 1001, 'foo', -1]
    # TODO: This should be a dict or tuple
    for test_value in test_list:
        get_os_user(test_value)



# Generated at 2022-06-23 18:21:22.987008
# Unit test for function chown
def test_chown():
    # setup
    assert True



# Generated at 2022-06-23 18:21:33.845407
# Unit test for function chown
def test_chown():
    import faker
    from tests.pathutils import get_random_path
    faker = faker.Faker()
    path = get_random_path()

    if path.exists():
        mode = os.stat(path, follow_symlinks=False).st_mode
        try:
            chown(path, user=faker.user_name(), group=faker.user_name())
        except (OSError, PermissionError):
            os.chmod(path, mode | 0o200)
            chown(path, user=faker.user_name(), group=faker.user_name())
        finally:
            os.chmod(path, mode)
            os.remove(path)



# Generated at 2022-06-23 18:21:45.072623
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/tmp') == ''
    assert exists_as('~/non-existing-path') == ''
    assert exists_as('/dev/full') == 'block device'
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
# Unit test: Apply the unit test to the function test_exists_as
try:
    test_exists_as()
except AssertionError:
    _LOG.exception('Unit test failed.')
    raise


# Generated at 2022-06-23 18:21:53.515826
# Unit test for function find_paths
def test_find_paths():
    """
    Unit test for function find_paths
    """
    search_path = Path(__file__).parent.parent/'tmp'
    file_one = search_path/'file_one'
    file_two = search_path/'file_two'

    file_one.touch()
    file_two.touch()

    try:
        assert len(list(find_paths(search_path/'*'))) == 2
    finally:
        file_one.unlink()
        file_two.unlink()



# Generated at 2022-06-23 18:22:03.467794
# Unit test for function exists_as
def test_exists_as():
    tpd = Path(tempfile.gettempdir())
    tpd = directory_present(
        tpd.joinpath(os.urandom(16).hex()), mode=0o770, user='-1', group='-1')
    path = tpd.joinpath('exists_as_file')
    path.write_text('foo')

    try:
        tpd_exists_as = exists_as(tpd)
        path_exists_as = exists_as(path)
    finally:
        rmtree(tpd)
    assert tpd_exists_as == 'directory'
    assert path_exists_as == 'file'



# Generated at 2022-06-23 18:22:14.723438
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function ``get_os_user``.
    """
    from .getpass import getuser
    from .osdata import TEST_UID_ONE, TEST_UNAME_ONE, TEST_UONE_GID
    from .osdata import TEST_UONE_GECOS, TEST_UONE_HOME, TEST_UONE_SHELL
    assert getuser() == get_os_user().pw_name
    assert get_os_user(TEST_UID_ONE).pw_uid == TEST_UID_ONE
    assert get_os_user(TEST_UID_ONE).pw_name == TEST_UNAME_ONE
    assert get_os_user(TEST_UID_ONE).pw_gid == TEST_UONE_GID
    assert get_os_user(TEST_UID_ONE).pw

# Generated at 2022-06-23 18:22:15.945017
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-23 18:22:26.122058
# Unit test for function chown
def test_chown():
    from subprocess import run
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        file_path = tmpdir / 'file.txt'
        file_path.touch()

        run(['chmod', '777', tmpdir], check=True)

        chown(file_path)

        assert (
            run([
                'ls',
                '-n',
                file_path,
                '|',
                'grep',
                getpass.getuser()
            ], check=True, shell=True).returncode == 0
        ) and (
            run([
                'ls',
                '-n',
                file_path,
                '|',
                'grep',
                getpass.getuser(),
            ]).returncode == 0
        )



# Generated at 2022-06-23 18:22:29.501519
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path.home()) == 'directory'
    assert exists_as(Path.home() / '.zprofile') == 'file'
    assert exists_as(Path.home() / '.NOTA_FILE') == ''



# Generated at 2022-06-23 18:22:40.105160
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from os import makedirs
    from os.path import dirname, join
    from shutil import rmtree
    from tempfile import TemporaryDirectory

    # Test a directory that does not exist.
    test_dir = join('/tmp', 'test')
    directory_present(test_dir)
    assert os.path.exists(test_dir) == True
    rmtree(test_dir)

    # Test a directory that exists but has the wrong mode.
    test_dir = join('/tmp', 'test')
    makedirs(test_dir, mode=0o777)
    directory_present(test_dir, mode=0o660)
    assert os.stat(test_dir).st_mode & 0o777 == 0o660

# Generated at 2022-06-23 18:22:47.064741
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

    path = Path('test_chmod.txt')
    if path.is_file():
        path.unlink()

    with path.open(mode='wt') as f:
        f.write('')

    path.chmod(0o777)

    assert path.is_file()

    chmod(path, 0o606)

    assert oct(path.stat().st_mode & 0o777) == '0o606'

    path.unlink()

    assert path.exists() is False



# Generated at 2022-06-23 18:22:59.366892
# Unit test for function chmod
def test_chmod():
    from shutil import copy2
    from os import pardir, path
    import tempfile
    from flutils.pathutils import chmod

    tmp_dir = Path(tempfile.mkdtemp())

# Generated at 2022-06-23 18:23:00.771310
# Unit test for function chown
def test_chown():
    import tempfile

    path = tempfile.mkdtemp()
    chown(path, '-1')



# Generated at 2022-06-23 18:23:06.957984
# Unit test for function path_absent
def test_path_absent():
    root = os.path.expanduser('~/tmp/pathutils.test/')
    if os.path.exists(root):
        shutil.rmtree(root)
    dir_one = os.path.join(root, 'dir_one')
    dir_two = os.path.join(root, 'dir_two')
    dir_three = os.path.join(root, 'dir_three')
    file_one = os.path.join(root, 'file_one')
    file_two = os.path.join(root, 'file_two')
    file_three = os.path.join(root, 'file_three')
    link_one = os.path.join(root, 'link_one')
    link_two = os.path.join(root, 'link_two')
    os

# Generated at 2022-06-23 18:23:20.809810
# Unit test for function get_os_group
def test_get_os_group():
    from testfixtures import compare
    from testfixtures import ShouldRaise
    from testfixtures import ShouldWarn
    from testfixtures import TempDirectory
    from testfixtures import validate_logging

    # If not name is given the group of the current user
    # should be returned.
    # Get the current user.
    cur_user = get_os_user()
    cur_group = get_os_group()
    compare(cur_group.gr_gid, cur_user.pw_gid)

    # The case with a name that does not exist.

# Generated at 2022-06-23 18:23:30.475943
# Unit test for function chmod
def test_chmod():
    import flutils.pathutils

    tmp_dir = Path('~/tmp/flutils.pathutils/chmod').expanduser()

    if tmp_dir.exists():
        tmp_dir.chmod(0o700)
        if tmp_dir.is_dir():
            tmp_dir.rmdir()
        elif tmp_dir.is_file():
            tmp_dir.unlink()

    flutils.pathutils.directory_present(tmp_dir, mode_dir=0o700)
    (tmp_dir / 'flutils.tests.pathutils.txt').touch()

    flutils.pathutils.chmod(
        '~/tmp/**',
        mode_file=0o600,
        mode_dir=0o700,
        include_parent=True
    )

# Generated at 2022-06-23 18:23:39.592003
# Unit test for function path_absent
def test_path_absent():
    tmp = normalize_path('~/tmp')
    tmp.rmdir()
    tmp.mkdir()
    assert exists_as(tmp) == 'directory'
    assert tmp.is_dir()
    test_dir = tmp / 'test_dir'

# Generated at 2022-06-23 18:23:41.475311
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo') == Path('/home/test_user/tmp/foo')



# Generated at 2022-06-23 18:23:42.186206
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:23:48.053439
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/flutils_test/test_path_absent')

    path_absent(path)
    assert exists_as(path) == ''

    path.touch()
    path_absent(path)
    assert exists_as(path) == ''

    path.mkdir()
    path_absent(path)
    assert exists_as(path) == ''

    path.mkdir(parents=True)
    path_absent(path)
    assert exists_as(path) == ''

    path_absent(path.as_posix())
    assert exists_as(path) == ''

    path.mkdir(parents=True)
    Path(path, 'file_one').touch()
    path_absent(path)
    assert exists_as(path) == ''

    path.mkdir

# Generated at 2022-06-23 18:23:51.597194
# Unit test for function chmod
def test_chmod():
    _test_case_chmod_01()
    _test_case_chmod_02()
    _test_case_chmod_03()
    _test_case_chmod_04()



# Generated at 2022-06-23 18:24:01.125403
# Unit test for function chown
def test_chown():
    def _test_chown(
            path: Union[str, bytes, Path],
            user: Optional[str] = None,
            group: Optional[str] = None,
            include_parent: bool = False
    ):
        chown(path, user, group, include_parent)
        if user is not None:
            if user == '-1':
                pass
            else:
                assert get_os_user(user).pw_name == os.stat(path).st_uid
        if group is not None:
            if group == '-1':
                pass
            else:
                assert get_os_group(group).gr_gid == os.stat(path).st_gid


# Generated at 2022-06-23 18:24:07.145007
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Supports a :term:`glob pattern`.  So to recursively change the mode
    # of a directory just do:
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # To change the mode of a directory's immediate contents:
    assert chmod('~/tmp/*')



# Generated at 2022-06-23 18:24:12.350586
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from tempfile import NamedTemporaryFile
    from tempfile import TemporaryDirectory

    # The tempfile.NamedTemporaryFile() function creates a temporary file
    # with the name passed through the 'dir' parameter.
    # tempfile.TemporaryDirectory() creates a temporary directory.
    with NamedTemporaryFile(dir='/tmp') as test_file:
        test_file_name = Path(test_file.name)
        assert test_file_name in find_paths('/tmp/test_file*')
        assert test_file_name not in find_paths('/var/tmp/test_file*')

    with TemporaryDirectory(dir='/tmp') as test_dir:
        test_dir_name = Path(test_dir)
        assert test_dir_name in find_

# Generated at 2022-06-23 18:24:16.575084
# Unit test for function normalize_path
def test_normalize_path():
    test_cases = (
        {
            'given': '~/tmp/foo',
            'expected': Path('/Users/len/tmp/foo'),
            'msg': 'normalizing a str path 1/2',
        },
        {
            'given': '~/tmp/foo/../bar',
            'expected': Path('/Users/len/tmp/bar'),
            'msg': 'normalizing a str path 2/2',
        },
        {
            'given': Path('~/tmp/foo'),
            'expected': Path('/Users/len/tmp/foo'),
            'msg': 'normalizing a Path object',
        },
    )
    for test in test_cases:
        assert normalize_path(test['given']) == test['expected'], test['msg']



# Generated at 2022-06-23 18:24:17.125091
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:24:18.238688
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp'
    assert normalize_path(path) == Path.home().joinpath('tmp')



# Generated at 2022-06-23 18:24:27.990933
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path()"""
    # Test path is a str.
    assert normalize_path('~/tmp/foo/../bar') == Path(os.path.expanduser(
        '~/tmp/foo/../bar'))
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('./tmp/foo/../bar') == Path('./tmp/bar')
    assert normalize_path('./././../tmp/foo/../bar') == Path('../tmp/bar')

    # Test path is a bytes.
    assert normalize_path(b'~/tmp/foo/../bar') == Path(os.path.expanduser(
        '~/tmp/foo/../bar'))

# Generated at 2022-06-23 18:24:34.945416
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function: path_absent"""
    with tempfile.TemporaryDirectory(dir='/tmp') as tmpdir:
        tmpdir = Path(tmpdir)
        test_dir = tmpdir / 'test_dir'
        test_dir.mkdir(mode=0o777)
        for i in range(3):
            if i < 2:
                test_file = test_dir / 'test_file_%s' % i
                with test_file.open('w+') as f:
                    f.write('Test file %s' % i)
            else:
                test_file = test_dir / 'test_file_%s' % i
                test_file.symlink_to(test_dir / 'test_file_0')

        subdir = test_dir / 'subdir'
        subdir

# Generated at 2022-06-23 18:24:35.571329
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:24:48.853523
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group
    import grp
    # This will raise an exception on BSD but all the tests should pass.
    assert get_os_group() == grp.getgrgid(grp.getgrgid(os.getgid()).gr_gid)
    assert get_os_group('-1') == grp.getgrgid(grp.getgrgid(os.getgid()).gr_gid)
    assert get_os_group(grp.getgrgid(os.getgid()).gr_gid) == grp.getgrgid(os.getgid())
    assert get_os_group('root') == grp.getgrnam('root')



# Generated at 2022-06-23 18:24:59.844812
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function :func:`get_os_user`."""
    from flutils.pathutils import get_os_user
    import pwd
    import getpass

    # Current user.
    assert get_os_user() == pwd.getpwnam(getpass.getuser())

    # Existing uid and name (should both raise OSError).
    try:
        get_os_user(3306)
    except OSError:
        pass
    else:
        raise AssertionError
    try:
        get_os_user('my_sqld')
    except OSError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 18:25:00.489012
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:25:10.286647
# Unit test for function chown
def test_chown():
    import os
    from tempfile import TemporaryDirectory
    from flutils.pathutils import (
        chown,
        chmod,
    )
    from flutils.osutils import get_os_user

    with TemporaryDirectory(prefix='flutils.test_') as tmpdir:
        tmpdir = Path(tmpdir)

        # test chown of non-existing file
        path = tmpdir / 'flutils.tests.osutils.txt'
        chown(path, user='foobar')
        assert path.exists() is False

        # test chown of existing file
        path = tmpdir / 'flutils.tests.osutils.txt'
        path.touch()
        assert path.exists() is True

        chown(path, user='foobar')

# Generated at 2022-06-23 18:25:20.195185
# Unit test for function chown
def test_chown():
    from flutils.testingutils import setup_test_paths, teardown_test_paths
    setup_test_paths()

# Generated at 2022-06-23 18:25:30.447299
# Unit test for function path_absent
def test_path_absent():
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        copy_tree('tests/sample_data/test_dir', tmpdir.joinpath('test_dir'))
        path = tmpdir.joinpath('test_dir/node_modules/@foo')
        path_absent(path)
        assert path.exists() is False
        path = tmpdir.joinpath('test_dir/node_modules/@foo')
        path.mkdir()
        copy_tree('tests/sample_data/test_dir/node_modules/@foo/bar',
                  path.joinpath('bar'))
        path_absent(path)
        assert path.exists() is False
        path = tmpdir.joinpath('test_dir/node_modules/@foo')
        path.mkdir()
        file

# Generated at 2022-06-23 18:25:36.570523
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.write_text('foobar')
    chmod(path, mode_file=0o660)

    g_info = path.stat().st_mode

    assert (g_info & 0o700) == 0o660

    path.unlink()



# Generated at 2022-06-23 18:25:46.033283
# Unit test for function exists_as
def test_exists_as():
    """Test the exists_as function.
    """
    from .test_data import BLOCK_DEV_PATH, CHAR_DEV_PATH, DIR_PATH, FIFO_PATH, FILE_PATH, SYMLINK_PATH, SOCKET_PATH, SYMLINK_TARGET, EXISTING_PATH, MISSING_PATH
    assert(exists_as(EXISTING_PATH) == '')
    assert(exists_as(MISSING_PATH) == '')
    assert(exists_as(DIR_PATH) == 'directory')
    assert(exists_as(FILE_PATH) == 'file')
    assert(exists_as(BLOCK_DEV_PATH) == 'block device')
    assert(exists_as(CHAR_DEV_PATH) == 'char device')

# Generated at 2022-06-23 18:25:49.014764
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user().pw_uid, int)
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-23 18:26:00.685819
# Unit test for function normalize_path
def test_normalize_path():  # pragma: no cover
    def test_path(path: _PATH) -> None:
        _path = normalize_path(path)
        print('{:<45s}  {!r:<30s}'.format(path, _path))

    print('\n--- str ---')
    test_path('/tmp/foo/../bar')
    test_path('/tmp/foo/../bar/baz')
    test_path('/tmp/foo/../bar/foo/./baz')
    test_path('/tmp/foo/../bar/../baz')
    test_path('~/foo/bar')
    test_path('~/foo/../bar')
    test_path('bar')
    test_path('foo/../bar')
    test_path('../bar')

# Generated at 2022-06-23 18:26:11.020497
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown
    from flutils.osutils import get_os_username
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    temp_file = Path(temp_dir.name).joinpath('test.txt')
    temp_file.write_text('')
    temp_file_path = Path(temp_file.as_posix())
    temp_file_path.touch()
    assert temp_file_path.exists()
    assert temp_file_path.is_file()
    assert get_os_username() == temp_file_path.owner()
    # All of the below should pass
    chown(temp_file_path)
    chown(temp_file_path, user=get_os_username())

# Generated at 2022-06-23 18:26:18.643961
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path."""
    assert normalize_path('/path/to/foo') == Path('/path/to/foo')
    assert normalize_path('/path//to/foo') == Path('/path/to/foo')
    assert normalize_path('/path/to//foo') == Path('/path/to/foo')
    assert normalize_path('/path/to/./foo') == Path('/path/to/foo')
    assert normalize_path('/path/to/../foo') == Path('/path/foo')
    assert normalize_path('/path/to/..') == Path('/path')
    assert normalize_path('/path/to/../../foo') == Path('/foo')
    assert normalize_path('../foo') == Path('../foo')

# Generated at 2022-06-23 18:26:29.584015
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group().gr_name == os.environ.get('USER')
    assert get_os_group('bar').gr_name == 'bar'
    assert get_os_group(2001).gr_name == 'bar'
    user: pwd.struct_passwd = get_os_user()
    group: grp.struct_group = get_os_group(user.pw_gid)
    assert group.gr_name == user.pw_name
    assert get_os_group(name=user.pw_gid).gr_name == user.pw_name
    assert get_os_group(user.pw_name).gr_name == user.pw_name

# Generated at 2022-06-23 18:26:38.634903
# Unit test for function find_paths
def test_find_paths():
    from ..osutils import makedirs
    import os
    import stat

    makedirs('/tmp/dir_1')
    makedirs('/tmp/dir_2/dir_3')
    with open('/tmp/file_1', 'w') as this_file:
        this_file.write('Test File 1')
    with open('/tmp/dir_1/file_2', 'w') as this_file:
        this_file.write('Test File 2')
    with open('/tmp/dir_2/file_3', 'w') as this_file:
        this_file.write('Test File 3')
    with open('/tmp/dir_2/dir_3/file_4', 'w') as this_file:
        this_file.write('Test File 4')

    # Ensure the file permission are