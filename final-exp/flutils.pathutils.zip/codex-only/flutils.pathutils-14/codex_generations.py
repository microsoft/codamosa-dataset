

# Generated at 2022-06-23 18:16:39.895515
# Unit test for function chmod
def test_chmod():
    from flutils.testutils import BaseTest
    from flutils.pathutils import (
        exists_as,
        path_absent,
    )

    from flutils.tests.pathutils import (
        _TEST_PATH,
        TEST_PATH2,
        TEST_PATH3,
        TEST_PATH4,
        TEST_PATH5,
        TEST_PATH6,
    )

    class Test_chmod(BaseTest):

        def test_a_file(self) -> None:
            chmod(_TEST_PATH)
            assert exists_as(_TEST_PATH, 2)

        def test_a_directory(self) -> None:
            chmod(TEST_PATH2)
            assert exists_as(TEST_PATH2, 3)


# Generated at 2022-06-23 18:16:44.169194
# Unit test for function exists_as
def test_exists_as():
    """Test the flutils.pathutils.exists_as function."""
    with tempfile.NamedTemporaryFile() as f:
        # Test directory
        directory = Path(f.name).parent
        assert exists_as(directory) == 'directory'
        # Test file
        assert exists_as(f.name) == 'file'
        # Test nonexistent path
        assert exists_as('/nonexistent_path') == ''



# Generated at 2022-06-23 18:16:53.916473
# Unit test for function chmod
def test_chmod():
    """
    Unit test for chmod
    """
    test_path = Path('/tmp/flutils.tests.chmod')
    test_path.mkdir(0o700, parents=True, exist_ok=True)
    test_file = Path(test_path.as_posix() + '/flutils.tests.chmod')
    test_file.write_text('flutils.tests.chmod', encoding='utf-8')

    test_dir = Path(test_path.as_posix() + '/dir1')
    test_dir.mkdir(0o700, parents=False, exist_ok=True)

    test_path.chmod(0o500)
    test_file.chmod(0o400)
    test_dir.chmod(0o700)


# Generated at 2022-06-23 18:17:03.316366
# Unit test for function exists_as
def test_exists_as(): # NOQA
    """Unit test for function exists_as."""
    test_path = Path('/tmp/flutils.tests.exists_as')
    test_path.touch()

    assert exists_as(test_path) == 'file'
    test_path.rmdir()
    assert exists_as(test_path) == ''

    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    test_path.rmdir()
    assert exists_as(test_path) == ''



# Generated at 2022-06-23 18:17:11.986129
# Unit test for function path_absent
def test_path_absent():
    from pathlib import (
        PosixPath as _PosixPath,
        WindowsPath as _WindowsPath,
    )
    from typing import (
        Generator as _Generator,
    )
    from unittest import TestCase
    from unittest.mock import patch, mock_open

    from flutils.pathutils import (
        path_absent as _path_absent,
        Path as _Path,
        _PATH,
    )

    class TempDir(TestCase):
        """Create a :term:`temporary directory` for testing."""

        @classmethod
        def setUpClass(cls):
            """Create the temporary directory."""
            # Patch os.path.abspath and os.getcwd to better control the
            # return value so we get a consistent test environment.
            cls.absp

# Generated at 2022-06-23 18:17:12.603724
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-23 18:17:22.154024
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    from unittest.mock import patch, Mock

    with patch('pwd.getpwnam') as mock_getpwnam:
        pwd_struct = Mock()
        pwd_struct.pw_uid = 1234
        mock_getpwnam.return_value = pwd_struct
        assert pwd_struct.pw_uid == get_os_user('foo').pw_uid

    with patch('pwd.getpwuid') as mock_getpwuid:
        pwd_struct = Mock()
        pwd_struct.pw_name = 'test_user'
        mock_getpwuid.return_value = pwd_struct
        assert pwd_struct.pw_name == get_os_user(1234).pw

# Generated at 2022-06-23 18:17:22.701784
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-23 18:17:23.173957
# Unit test for function chmod
def test_chmod():
    assert True



# Generated at 2022-06-23 18:17:26.446409
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    from flutils.pathutils import exists_as
    assert exists_as(Path('~/tmp')) == 'directory'
    assert exists_as('/dev/tty') == 'character device'



# Generated at 2022-06-23 18:17:28.406212
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('.gitignore') == 'file'
    assert exists_as('.') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/dev/null') == 'char device'


# Generated at 2022-06-23 18:17:40.736132
# Unit test for function normalize_path
def test_normalize_path():
    from shutil import copytree

    from flutils.pathutils import get_os_user

    _test_path = normalize_path('~/tmp/test_pathutils')
    if exists_as(_test_path):
        _test_path.rmtree()

    _test_path.mkdir(parents=True)

    _src_dir = normalize_path('~/tmp/test_pathutils/src_dir')
    _src_dir.mkdir(parents=True)
    _file_one = normalize_path('~/tmp/test_pathutils/file_one')
    _file_one.touch()
    _file_two = normalize_path('~/tmp/test_pathutils/file_two')
    _file_two.touch()

# Generated at 2022-06-23 18:17:45.824261
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    path_one = directory_present(TEST_DIR / 'path_one')
    path_one.joinpath('one.txt').touch()
    path_one.joinpath('two.txt').touch()

    path_two = directory_present(TEST_DIR / 'path_two')
    path_two.joinpath('one.txt').touch()
    path_two.joinpath('two.txt').touch()

    found = sorted(find_paths(TEST_DIR / 'path_*'))
    assert len(found) == 2
    assert str(found[0]) == str(path_one)
    assert str(found[1]) == str(path_two)


# Generated at 2022-06-23 18:17:58.327116
# Unit test for function get_os_group
def test_get_os_group():
    try:
        get_os_group('_nonexisting_')
    except OSError:
        pass
    else:
        raise AssertionError(
            'No OSError was thrown when a non existing "group name" was '
            'specified.'
        )
    try:
        get_os_group(10000)
    except OSError:
        pass
    else:
        raise AssertionError(
            'No OSError was thrown when a non existing "gid" was specified.'
        )

    try:
        get_os_group('root')
    except OSError:
        raise AssertionError(
            'An OSError was thrown when the "group name": root, was '
            'specified.'
        )


# Generated at 2022-06-23 18:17:58.898638
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:18:00.944902
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-23 18:18:11.925836
# Unit test for function chown
def test_chown():
    print("chown")
    try:
        assert os.getlogin == getpass.getuser
        assert getpass.getuser() == os.getlogin()
    except AttributeError:
        # This is raised on OpenBSD
        assert os.getlogin == pwd.getpwuid(os.geteuid()).pw_name
        assert pwd.getpwuid(os.geteuid()).pw_name == os.getlogin()
    else:
        assert getpass.getuser() == pwd.getpwuid(os.geteuid()).pw_name
        assert os.getlogin() == pwd.getpwuid(os.geteuid()).pw_name


# Generated at 2022-06-23 18:18:17.544455
# Unit test for function chown
def test_chown():
    test_path = '/tmp/flutils.tests.pathutils.osutils.txt'
    with open(test_path, 'w') as f:
        f.write("mock data\n")
    chown(test_path)
    os.unlink(test_path)
    assert(os.path.exists(test_path) is False)



# Generated at 2022-06-23 18:18:29.225655
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    path.write_text('x' * 1000)
    # first run - change ownership and check
    chown(path, user='alice', group='users')
    assert path.stat().st_uid == pwd.getpwnam('alice').pw_uid
    assert path.stat().st_gid == grp.getgrnam('users').gr_gid
    # second run - change ownership and check
    chown(path, user='bob', group='wheel')
    assert path.stat().st_uid == pwd.getpwnam('bob').pw_uid
    assert path.stat().st_gid == grp.getgrnam('wheel').gr_gid
    # clean up
    path.un

# Generated at 2022-06-23 18:18:34.868193
# Unit test for function path_absent
def test_path_absent():
    path = './tmp/test/bar'
    pathlib.Path(path).mkdir(parents=True, exist_ok=True)
    open(os.path.join(path, 'foo'), 'a').close()
    open(os.path.join(path, 'baz'), 'a').close()
    dir_path = pathlib.Path(path)
    assert dir_path.exists()
    path_absent(path)
    assert dir_path.exists() is False
    assert exists_as(dir_path) == ''



# Generated at 2022-06-23 18:18:35.328176
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:18:38.370793
# Unit test for function get_os_user
def test_get_os_user():
    """Test for flutils.pathutils.get_os_user"""
    if isinstance(get_os_user(), pwd.struct_passwd):
        return
    raise AssertionError



# Generated at 2022-06-23 18:18:49.509315
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.systemutils import get_os_name
    import tempfile
    import time

    path = directory_present(
        '~/test_directory_present/%s'
        % tempfile.gettempdir().split('/')[-1]
    )

    if get_os_name() != 'Windows':
        assert path == Path(path)
        assert path.parent == Path('~/test_directory_present')
        assert path.exists() is True
        assert path.is_dir() is True
        assert path.stat().st_mode == 0o40700
        assert path.stat().st_uid == os.getuid()
        assert path.stat().st_gid == os.getgid()
    else:
        assert type(path) == Pos

# Generated at 2022-06-23 18:18:55.530561
# Unit test for function exists_as
def test_exists_as():
    import os
    import sys
    if sys.platform.startswith('win'):
        path_type = 'file'
        import win32file
        import win32security
        import pywintypes
        current_file = __file__.replace('\\', '/').split('/')[-1]
        path = win32file.GetVolumePathName(__file__.replace('/', '\\')) + \
            '/' + current_file
    else:
        path_type = 'socket'
        path = '/tmp/dummy_sock'
        if not os.path.exists('/tmp/dummy_sock'):
            import socket
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.bind('/tmp/dummy_sock')
           

# Generated at 2022-06-23 18:19:02.007103
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown, group_exists
    chown('~/tmp/flutils.tests.osutils/', user='foo', group='bar')
    assert group_exists(user='foo', group='bar') is True
    for i in Path().glob('~/tmp/flutils.tests.osutils/**'):
        assert i.stat().st_uid == get_os_user('foo').pw_uid
        assert i.stat().st_gid == get_os_group('bar').gr_gid



# Generated at 2022-06-23 18:19:03.647078
# Unit test for function chown
def test_chown():
    pass


# Generated at 2022-06-23 18:19:11.508027
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_uid == os.geteuid()
    assert get_os_user(os.getlogin()).pw_uid == os.geteuid()
    if os.geteuid() == 0:
        with pytest.raises(OSError):
            get_os_user(500550550)
    else:
        with pytest.raises(OSError):
            get_os_user(0)
    with pytest.raises(OSError):
        get_os_user('i_am_not_a_real_user_12735123')


# Generated at 2022-06-23 18:19:15.775603
# Unit test for function get_os_group
def test_get_os_group():
    assert(get_os_group().gr_name == get_os_user().pw_name)
    #
    # By default this function returns the current user's group name.
    #

    #
    # If the given name is an integer, it is assumed to be a gid.
    #
    assert(get_os_group(0).gr_name == 'root')

    #
    # Assert that an invalid gid throws an OSError.
    #
    with pytest.raises(OSError):
        get_os_group(1000)



# Generated at 2022-06-23 18:19:21.209638
# Unit test for function get_os_user

# Generated at 2022-06-23 18:19:29.954036
# Unit test for function find_paths
def test_find_paths():
    """Unit test function find_paths."""
    with TempDirectory() as base_path:
        with TempDirectory(base_path=base_path):
            with TempDirectory(base_path=base_path):
                with TemporaryFile(base_path=base_path):
                    with TemporaryFile(base_path=base_path):
                        paths = list(find_paths(base_path.as_posix() + '/*'))
                        assert isinstance(paths, list)
                        assert len(paths) == 2
                        for path in paths:
                            assert isinstance(path, Path)
                            assert isinstance(path, PosixPath)
                            assert isinstance(path, WindowsPath)



# Generated at 2022-06-23 18:19:42.589976
# Unit test for function path_absent
def test_path_absent():
    # Setup test directory
    dir_path = normalize_path('~/tmp/test_path_absent')

    # Ensure directory does not exist
    path_absent(dir_path)

    # Create a temporary directory to populate
    os.makedirs(dir_path, exist_ok=True)

    # Create tmp files and directories to populate
    file_one = dir_path / 'file_one'
    file_one.touch()
    file_two = dir_path / 'file_two'
    file_two.touch()

    file_three = dir_path / 'file_three'
    file_three.touch()
    file_three.unlink()
    file_three.symlink_to(file_one)
    file_four = dir_path / 'file_four'
    file_four.touch

# Generated at 2022-06-23 18:19:55.803976
# Unit test for function path_absent
def test_path_absent():
    import os
    out_list = []
    user = getpass.getuser()
    path = '~/tmp/test_path'
    path = path_absent(path)
    assert path is None
    out = os.path.exists(path)
    assert out is False
    out_list.append(out)
    path = '~/tmp/test_path'
    # Create files
    for i in range(1, 3):
        path = os.path.join(path, 'file_%s' % i)
        with open(path, 'w') as f:
            f.write('%s' % i)
        out = os.path.exists(path)
        assert out is True
        out_list.append(out)
    # Create symlinks

# Generated at 2022-06-23 18:20:07.448916
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil
    import stat
    import pwd
    import grp
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.pathutils import get_os_group

    # Create a temporary directory to work in
    tmp_dir = tempfile.mkdtemp()
    this_dir = tmp_dir


# Generated at 2022-06-23 18:20:07.985185
# Unit test for function path_absent
def test_path_absent():
    return



# Generated at 2022-06-23 18:20:16.970196
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user(None).pw_name == get_os_user().pw_name
    assert get_os_user('root').pw_name == 'root'
    assert get_os_user(0).pw_uid == 0
    with pytest.raises(OSError) as err:
        get_os_user(999)
    assert 'is not a valid "login name" for this operating system.' in str(err)

# Generated at 2022-06-23 18:20:19.253604
# Unit test for function directory_present
def test_directory_present():
    print(directory_present('~/tmp/test_path'))
    return False



# Generated at 2022-06-23 18:20:32.269690
# Unit test for function chmod
def test_chmod():
    import shutil
    from tempfile import TemporaryDirectory

    try:
        # Old way of creating a TemporaryDirectory when
        # the function was just a context manager and
        # did not return a path.
        tmpdir = TemporaryDirectory(prefix='flutils.osutils.test_chmod_')
    except TypeError:
        tmpdir = TemporaryDirectory(prefix='flutils.osutils.test_chmod_',
                                    dir='.')
    finally:
        tmpdir.name = str(Path(tmpdir.name))

    dir_path = Path(tmpdir.name)
    file_path = dir_path / 'flutils.tests.osutils.txt'


# Generated at 2022-06-23 18:20:36.952837
# Unit test for function get_os_group
def test_get_os_group():
    name = get_os_group().gr_name
    assert is_valid_group_name(name) is True



# Generated at 2022-06-23 18:20:40.009750
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    chown('~/tmp/**')
    chown('~/tmp/*', user='foo', group='bar')


# Generated at 2022-06-23 18:20:51.774339
# Unit test for function exists_as
def test_exists_as():


    assert exists_as(__file__) == 'file'
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/usr/bin/python') == 'file'
    assert exists_as('/') == 'directory'
    assert exists_as('/dev/lunix') == 'block device'
    assert exists_as('/dev/urandom') == 'char device'
    assert exists_as('/tmp/osutils_fifo') == 'FIFO'
    assert exists_as('/tmp/osutils_socket') == 'socket'
    assert exists_as('/tmp/not_a_real_path') == ''
    assert exists_as('~/this/path/doesnt/exist') == ''



# Generated at 2022-06-23 18:20:52.402651
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:20:52.952159
# Unit test for function path_absent
def test_path_absent():
    pass


# Generated at 2022-06-23 18:21:01.773273
# Unit test for function chmod
def test_chmod():
    """ Unit tests for flutils.pathutils.chmod """
    from pathlib import Path
    from flutils.pathutils import chmod

    test_dir = Path(__file__).parent / 'data' / 'chmod'

    # Just chmod a path that does not exist
    chmod(test_dir, include_parent=True)

    # Create the directory and chmod the directory with
    # a glob pattern that would look for files within the
    # directory.
    test_dir.mkdir()
    chmod(str(test_dir) + '/**')

    # Create an empty file, then chmod it.
    test_file = test_dir / 'empty_file.txt'
    test_file.touch()
    chmod(str(test_dir) + '/**')

# Generated at 2022-06-23 18:21:11.343052
# Unit test for function find_paths
def test_find_paths():
    """Test ``find_paths()``."""
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()
        (tmp_dir / 'file_one').touch()
        (tmp_dir / 'file_two').touch()
        (tmp_dir / 'file_three').touch()
        list(find_paths('%s/*' % tmp_dir.as_posix()))

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_dir.mkdir()
        list(find_paths('%s/dummy' % tmp_dir.as_posix()))
        (tmp_dir / 'file_one').touch()

# Generated at 2022-06-23 18:21:16.286850
# Unit test for function normalize_path
def test_normalize_path():

    # Failures
    def test_bad_types():
        import pytest
        with pytest.raises(TypeError):
            normalize_path(None)

    # Successes
    def test_str():
        path = normalize_path('.')
        assert isinstance(path, Path)
        assert isinstance(path, BINARY_TYPE_MAP['path'])
        assert path.as_posix() == os.getcwd()

    def test_bytes():
        path = normalize_path(b'.')
        assert isinstance(path, Path)
        assert isinstance(path, BINARY_TYPE_MAP['path'])
        assert path.as_posix() == os.getcwd()


# Generated at 2022-06-23 18:21:26.097594
# Unit test for function directory_present
def test_directory_present():
    from . import pathutils

    path = pathutils.directory_present('~/tmp/test_path')
    assert path.as_posix() == '/Users/len/tmp/test_path'

    # Ensure that no parent paths are changed if they already exist.
    path = pathutils.directory_present('~/tmp/test_path/subdir')
    assert path.as_posix() == '/Users/len/tmp/test_path/subdir'

    # Create a group that the current user is not a member of.
    import grp
    group_name = 'pyflutils_group'
    for group in grp.getgrall():
        if group.gr_name == group_name:
            grp.delete(group);
    grp.create(group_name)

# Generated at 2022-06-23 18:21:39.179536
# Unit test for function get_os_group
def test_get_os_group():
    # Test KeyError exception
    with pytest.raises(OSError) as excinfo:
        get_os_group('foo')
    assert 'The given name: \'foo\', is not a valid "group name" for this ' \
        'operating system.' in str(excinfo.value)

    # Test KeyError exception
    with pytest.raises(OSError) as excinfo:
        get_os_group(9999)
    assert 'The given gid: 9999, is not a valid gid for this operating' \
        ' system.' in str(excinfo.value)

    # Test getting a groups object.

    # Test for Linux/POSIX
    if platform.system() != 'Windows':
        group = get_os_group()
        assert group.gr_gid == os.getgid()
        assert group

# Generated at 2022-06-23 18:21:49.023096
# Unit test for function chown
def test_chown():
    cwd = os.getcwd()
    for path in find_paths(cwd, r'^test_chown.*', prune_dirs=True):
        path.unlink()

    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        os.chdir(tmp_dir)
        work_paths = [
            Path('test_chown_file.txt'),
            Path('test_chown_dir'),
            Path('test_chown_dir/test_chown_file.txt'),
            Path('test_chown_dir/test_chown_file_link.txt')
        ]
        for path in work_paths:
            if path.is_dir():
                path.mkdir(parents=True, exist_ok=True)
            else:
                path.touch

# Generated at 2022-06-23 18:21:57.187283
# Unit test for function chown
def test_chown():

    def _chown_assert(*expected: _STR_OR_INT_OR_NONE) -> None:
        path = normalize_path('~/.flutils_test_pathutils.chown')
        if path.exists() is True:
            path.unlink()
        path.mkdir(parents=True, exist_ok=True)
        chown(path, *expected)
        path_stat = path.stat()
        path_uid = path_stat.st_uid
        path_gid = path_stat.st_gid

        if expected[0] is None:
            expected_uid = os.getuid()
        elif expected[0] == '-1':
            expected_uid = -1
        else:
            expected_uid = pwd.getpwnam(expected[0]).pw_uid


# Generated at 2022-06-23 18:22:10.972076
# Unit test for function chown
def test_chown():
    import tempfile
    tmpdir = tempfile.TemporaryDirectory()
    tmpfd = tempfile.NamedTemporaryFile(dir=tmpdir.name).file

    # test -1
    chown(tmpdir.name, user='-1', group='-1')

    # test normal case
    chown(tmpdir.name, user='root', group='root')

    # test not exist glob pattern
    one_glob = Path(tmpdir.name).joinpath('*')
    chown(one_glob, user='root', group='root')

    # test exist glob pattern
    two_glob = Path(tmpdir.name).joinpath('__*')
    open(two_glob, 'w').close()
    chown(two_glob, user='root', group='root')

    # test include_parent

# Generated at 2022-06-23 18:22:20.318426
# Unit test for function path_absent
def test_path_absent():
    import os
    import os.path
    import tempfile
    import unittest

    from flutils.pathutils import path_absent
    from flutils.pathutils import path_present


    class Test_path_absent(unittest.TestCase):

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = '%s/test_file' % self.test_dir
            self.test_link = '%s/test_link' % self.test_dir
            self.test_dir_1 = '%s/dir_one' % self.test_dir
            self.test_dir_2 = '%s/dir_two' % self.test_dir_1

# Generated at 2022-06-23 18:22:30.299594
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = Path(tempfile.mkdtemp())
    print('\nTest directory: %s' % tmp_dir)

    file_one = Path(tmp_dir / 'file_one')
    file_two = Path(tmp_dir / 'file_two')
    file_three = Path(tmp_dir / 'file_three')
    dir_one = Path(tmp_dir / 'dir_one')


# Generated at 2022-06-23 18:22:31.163738
# Unit test for function chown
def test_chown():
    assert True is True


# Generated at 2022-06-23 18:22:42.566337
# Unit test for function find_paths
def test_find_paths():
    """Test unit for function find_paths"""
    from flutils.pathutils import find_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import Generator

    with TemporaryDirectory(prefix='test_pathutils_') as tmp_dir:
        tmp_dir = Path(tmp_dir)

        sub_path = tmp_dir / 'sub_path'
        sub_path.mkdir()
        (sub_path / 'test_file.txt').open('a').close()
        (sub_path / 'test_dir').mkdir()

        (tmp_dir / 'test_file.txt').open('a').close()
        (tmp_dir / 'test_dir').mkdir()

        # Test pattern with wildcard (*)
        pattern: Path = tmp_dir / '*'

# Generated at 2022-06-23 18:22:49.163627
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user"""
    assert (get_os_user().pw_gecos == pwd.getpwuid(os.geteuid()).pw_gecos) == True

    assert (get_os_user(1001).pw_name == 'foo') == True



# Generated at 2022-06-23 18:22:53.319739
# Unit test for function get_os_user
def test_get_os_user():
    """ Test function get_os_user.
    """
    user = get_os_user()
    assert user.pw_name == "dwrobel"


# Generated at 2022-06-23 18:23:02.758859
# Unit test for function chown
def test_chown():
    # This function will not unit test an exception
    # The exception is a TypeError if the user
    # or group does not exist.
    from flutils.pathutils import chown
    from flutils.miscutils import Result
    ret = Result()

    # Temporary testing file
    fpath = Path('/tmp/flutils.tests.pathutils.chown.txt')

    if fpath.exists():
        fpath.unlink()

    fpath.touch()

    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name
    chown(fpath, user, group)

    stat_info = Path(fpath).stat()

    # Test the default user and group

# Generated at 2022-06-23 18:23:08.441019
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import subprocess

    # Test a single file.
    f = tempfile.NamedTemporaryFile(delete=False)
    fname = f.name
    f.close()
    assert os.path.exists(fname)
    assert os.path.isfile(fname)
    #
    path_absent(fname)
    assert not os.path.exists(fname)
    assert not os.path.isfile(fname)

    # Test a directory with a file.
    p = tempfile.mkdtemp()
    assert os.path.exists(p)
    assert os.path.isdir(p)
    f = tempfile.NamedTemporaryFile(dir=p, delete=False)
    fname = f.name
    f.close

# Generated at 2022-06-23 18:23:21.367837
# Unit test for function directory_present
def test_directory_present():
    user = getpass.getuser() # Get the login name of the current user.
    group = grp.getgrgid(os.getgid()).gr_name # Get the group name of the current user.

    path = Path(directory_present('~/tmp/flutils.tests.directory_present'))
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat().st_uid == pwd.getpwnam(user).pw_uid
    assert path.stat().st_gid == grp.getgrnam(group).gr_gid

    path = Path(directory_present('~/tmp/flutils.tests.directory_present/foo'))
    assert path.exists() is True
    assert path.is_dir() is True
    assert path.stat

# Generated at 2022-06-23 18:23:31.160172
# Unit test for function directory_present
def test_directory_present():
    """Test function directory_present."""
    p = '~/tmp/flutils.tests.pathutils.directory_present'
    path = directory_present(p)
    assert isinstance(path, Path) is True
    assert path.as_posix() == os.path.expanduser(
        '~/tmp/flutils.tests.pathutils.directory_present'
    )
    assert path.is_dir() is True
    os.unlink(path)
    assert path.is_dir() is False
    assert os.path.exists(path) is False
    directory_present(p, user='-1')
    assert os.getuid() == path.stat().st_uid
    directory_present(p, group='-1')
    assert os.getgid() == path.stat().st_gid



# Generated at 2022-06-23 18:23:43.623207
# Unit test for function chown
def test_chown():
    # pylint: disable=blacklisted-function
    from flutils.pathutils import chown, get_os_group, get_os_user
    from flutils.tests.pathutils import (
        create_file_tree,
        rm_rf,
    )

    # Test that chown doesn't change group of symlink target.
    #
    # Tests:
    # - chown of symlink
    # - chown does not change group of symlink target

    create_file_tree({
        'foo': {
            'd1': {
                'src_file.txt': 'Hello World!',
                'src_sym.txt': {'path': 'src_file.txt'},
            },
        },
    })

    # Set the mode of the source file so we can check if it
    # was

# Generated at 2022-06-23 18:23:55.371248
# Unit test for function exists_as
def test_exists_as(): # NOQA
    """Unit test for function exists_as."""
    returncode = 0
    errors = []
    path = Path('/tmp/flutils.tests.pathutils.testfile')
    exists_as_val = exists_as(path)
    if exists_as_val != '':
        errors.append(
            'The test file: %r does exists as a %s.' % (path, exists_as_val)
        )
        returncode = 1

    path.touch(exist_ok=True)
    exists_as_val = exists_as(path)
    if exists_as_val != 'file':
        errors.append(
            'The test file: %r does exists as a %s.' % (path, exists_as_val)
        )
        returncode = 1

    # Clean up the test file

# Generated at 2022-06-23 18:24:06.192404
# Unit test for function exists_as
def test_exists_as():
    """Coverage for exists_as function."""

    assert exists_as('/') == 'directory'
    assert exists_as('/etc') == 'directory'

    assert exists_as('/etc/hosts') == 'file'
    assert exists_as('/etc/hosts.allow') == 'file'
    assert exists_as('/etc/hosts.deny') == 'file'

    assert exists_as('/proc') == 'directory'
    assert exists_as('/sys') == 'directory'
    assert exists_as('/dev') == 'directory'
    assert exists_as('/var') == 'directory'
    assert exists_as('/var/empty') == 'directory'

    assert exists_as('/dev/null') == 'character device'

# Generated at 2022-06-23 18:24:09.462388
# Unit test for function chmod
def test_chmod():
    assert chmod(
        '~/tmp/**',
        mode_file=0o644,
        mode_dir=0o770,
    ) is None



# Generated at 2022-06-23 18:24:14.068673
# Unit test for function find_paths
def test_find_paths():
    # We can safely assume the parent of this file is the root
    # of a package and the test files will always exist in the
    # tests subdirectory of the flutils package.
    #
    # This will fail if the tests are being run outside of the
    # package.
    base_path = Path(__file__).parent.parent
    test_path = base_path / 'tests'
    paths = list(find_paths(test_path / 'data'))
    assert len(paths) == 2
    assert Path(test_path, 'data', 'file_one') in paths
    assert Path(test_path, 'data', 'dir_one') in paths




# Generated at 2022-06-23 18:24:23.633244
# Unit test for function find_paths
def test_find_paths():
    with TempDir() as tmpdir:
        file_one_path = Path(tmpdir.path).joinpath('file_one')
        file_one_path.touch()
        assert list(find_paths(Path(tmpdir.path).joinpath('*'))) \
            == [file_one_path]

        dir_one_path = Path(tmpdir.path).joinpath('dir_one')
        dir_one_path.mkdir()
        assert list(find_paths(Path(tmpdir.path).joinpath('*'))) \
            == [file_one_path, dir_one_path]

        file_two_path = dir_one_path.joinpath('file_two')
        file_two_path.touch()

# Generated at 2022-06-23 18:24:24.344323
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:24:28.009725
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('~/tmp/bar').expanduser()



# Generated at 2022-06-23 18:24:30.605589
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('~/does-not-exist') == ''
    assert exists_as('~/') == 'directory'
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-23 18:24:37.837392
# Unit test for function get_os_user
def test_get_os_user():
    import getpass
    from flutils.pathutils import get_os_user
    from passlib.utils import getrandbytes

    class TestUser():
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return other.pw_name == self.name

    for _ in range(100):
        try:
            user = get_os_user()
            assert user == TestUser(getpass.getuser())
        except OSError:
            pass  # Some systems will not allow looking up user by uid.
    # Assert OSError is raised when an invalid name is given.
    with pytest.raises(OSError):
        get_os_user(getrandbytes(length=10).decode('utf-8'))
    # Assert O

# Generated at 2022-06-23 18:24:46.518789
# Unit test for function find_paths
def test_find_paths():
    test_path = Path(__file__).parent
    test_filenames = ['test_file_one', 'test_file_two', 'test_dir_one']
    create_file(test_path / test_filenames[0])
    create_file(test_path / test_filenames[1])
    create_directory(test_path / test_filenames[2])

    try:
        assert Path('/') in find_paths('/')
        assert sorted(test_filenames) == sorted(
            [p.name for p in find_paths(test_path / '*')]
        )
    finally:
        for test_file in test_filenames:
            rm(test_file)



# Generated at 2022-06-23 18:24:52.619157
# Unit test for function normalize_path
def test_normalize_path():
    # When PosixPath is used.
    test_path = Path('foo')
    result = normalize_path(test_path)
    assert result == Path(os.getcwd()) / 'foo'

    # When WindowsPath is used.
    test_path = WindowsPath('foo')
    result = normalize_path(test_path)
    # On Windows paths are normalized to upper case.
    assert result == Path(os.getcwd()) / 'FOO'

    # When bytes is used.
    test_path = b'foo'
    result = normalize_path(test_path)
    assert result == Path(os.getcwd()) / 'foo'



# Generated at 2022-06-23 18:24:58.825633
# Unit test for function get_os_user
def test_get_os_user():
    import os
    from flutils.pathutils import get_os_user
    from flutils.typesutils import FakeObject

    if os.name != 'nt':
        assert isinstance(get_os_user(), FakeObject)
        assert isinstance(get_os_user(name='-1'), FakeObject)
        assert isinstance(get_os_user(name=1001), FakeObject)
        assert isinstance(get_os_user(name='foo'), FakeObject)
    else:
        assert True



# Generated at 2022-06-23 18:25:00.542922
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('~/tmp/test_path')
    path = directory_present(test_path)
    path.exists()



# Generated at 2022-06-23 18:25:01.214182
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:25:04.874544
# Unit test for function normalize_path
def test_normalize_path():
    import unittest.mock as mock
    with mock.patch('pathlib.Path'):
        assert normalize_path('~/tmp/foo/../bar') == '~/tmp/bar'



# Generated at 2022-06-23 18:25:13.526728
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        file_one = tmp_path / 'file_one'
        file_two = tmp_path / 'file_two'
        dir_one = tmp_path / 'dir_one'
        dir_two = tmp_path / 'dir_two'

        file_one.touch()
        file_two.touch()
        dir_one.mkdir()
        dir_two.mkdir()

        results = []
        for path in find_paths(f'{tmp_path}/*'):
            results.append(path.as_posix())

        assert f'{file_one.as_posix()}' in results
        assert f'{file_two.as_posix()}' in results

# Generated at 2022-06-23 18:25:21.677240
# Unit test for function exists_as
def test_exists_as():
    with TemporaryDirectory() as tempdirname:
        path = Path(tempdirname)
        path.mkdir()
        test_dir = path / 'test_dir'
        test_dir.mkdir()
        test_file = path / 'test_file.txt'
        test_file.touch()
        result = exists_as(test_file)
        assert result == 'file'
        result = exists_as(test_dir)
        assert result == 'directory'


# Generated at 2022-06-23 18:25:27.998643
# Unit test for function get_os_user
def test_get_os_user():
    expected = pwd.struct_passwd(
        pw_name='len',
        pw_passwd='********',
        pw_uid=1001,
        pw_gid=1001,
        pw_gecos='Lenovo-PC',
        pw_dir='/home/len',
        pw_shell='/bin/bash',
    )
    actual = get_os_user()
    assert actual == expected


# Generated at 2022-06-23 18:25:39.417405
# Unit test for function chown
def test_chown():
    path = Path(__file__).parent / 'test_pathutils.file'
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name
    chown(path, user, group)
    stat = path.stat()
    assert stat.st_uid == getpwuid(user).pw_uid
    assert stat.st_gid == getgrgid(group).gr_gid
    chown(path, None, None)
    stat = path.stat()
    assert stat.st_uid == getpwuid(user).pw_uid
    assert stat.st_gid == getgrgid(group).gr_gid
    chown(path, '-1', '-1')
    stat = path.stat()

# Generated at 2022-06-23 18:25:46.151432
# Unit test for function chmod
def test_chmod():
    test_dir = Path(__file__).parent.parent / 'tmp'
    if not test_dir.exists():
        test_dir.mkdir(parents=True)

    test_file = test_dir / 'flutils.tests.osutils.txt'
    with open(test_file, 'w') as fd:
        fd.write('File created by chmod unit test')

    chmod(test_file, mode_file=0o660)
    assert oct(test_file.stat().st_mode & 0o777) == '0o660'

    test_dir = test_dir / 'flutils.osutils.tests'
    if not test_dir.exists():
        test_dir.mkdir()

    chmod(test_dir, mode_dir=0o770)

# Generated at 2022-06-23 18:25:47.777034
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)



# Generated at 2022-06-23 18:25:50.571489
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)

# Generated at 2022-06-23 18:26:01.245192
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile
    import pytest

    dirname = tempfile.mkdtemp()
    filename = os.path.join(dirname, 'test_file.txt')
    with open(filename, 'w') as fp:
        fp.write('Hello World!')

    dirmode = os.stat(dirname).st_mode
    filemode = os.stat(filename).st_mode

    if os.name == 'nt':
        mask = 0o777
    else:
        mask = 0o7777

    dirmode = (dirmode & mask) | 0o700
    filemode = (filemode & mask) | 0o666

    chmod(filename)

    assert (os.stat(dirname).st_mode & mask) == dirmode

# Generated at 2022-06-23 18:26:02.278386
# Unit test for function chmod
def test_chmod():
    assert callable(chmod)



# Generated at 2022-06-23 18:26:11.525616
# Unit test for function chmod
def test_chmod():
    # Create path to test with
    tmp_dir = Path(__file__).parent / 'tmp' / 'osutils'
    path_to_test = tmp_dir / 'foo.txt'
    path_to_test.parent.mkdir(parents=True, exist_ok=True)
    path_to_test.open('w').close()

    # Test that file was created with default mode
    with pytest.raises(PermissionError):
        with path_to_test.open('a'):
            pass

    # Test that changing file mode works
    chmod(path=path_to_test, mode_file=0o660)

    # Test that file was changed
    with path_to_test.open('a'):
        pass

    # Test that changing directory mode works

# Generated at 2022-06-23 18:26:16.265176
# Unit test for function get_os_group
def test_get_os_group():
    """Unit test for function get_os_group"""
    assert get_os_group()
    if IS_LINUX:
        assert get_os_group(1000)
    else:
        assert get_os_group('Administrators')



# Generated at 2022-06-23 18:26:24.884207
# Unit test for function exists_as
def test_exists_as():
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_path = tmp_dir / 'tmp_path'
        tmp_path.touch()
        assert exists_as(tmp_path) == 'file'

        tmp_dir.mkdir('tmp_dir')
        assert exists_as(tmp_dir / 'tmp_path') == ''

        tmp_dir.mkfifo('tmp_fifo')
        assert exists_as(tmp_dir / 'tmp_fifo') == 'FIFO'
# unit test end



# Generated at 2022-06-23 18:26:25.519094
# Unit test for function chmod
def test_chmod():
    return



# Generated at 2022-06-23 18:26:34.649766
# Unit test for function chown
def test_chown():

    from os import (
        chmod,
        chown,
        makedirs,
        remove,
    )

    from os.path import (
        join,
    )

    from flutils.pathutils import (
        directory_present,
        get_os_user,
        normalize_path,
    )

    from flutils.tests.helpers import (
        create_file,
    )
