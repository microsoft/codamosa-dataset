

# Generated at 2022-06-23 18:16:35.781468
# Unit test for function exists_as
def test_exists_as():
    from pathlib import Path
    
    assert exists_as(Path('test_data/test.txt')) == 'file'
    assert exists_as(Path('test_data/test')) == ''
    assert exists_as(Path('test_data/test/')) == ''
    
test_exists_as()



# Generated at 2022-06-23 18:16:47.635243
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user."""
    from . import get_os_user
    import pwd
    import getpass
    if sys.platform == 'darwin':
        user = get_os_user()
        assert(isinstance(user, pwd.struct_passwd))
        assert(user.pw_name == getpass.getuser())
        assert(os.getuid() == user.pw_uid)
        assert(os.getgid() == user.pw_gid)
    elif sys.platform == 'linux':
        user = get_os_user()
        assert(isinstance(user, pwd.struct_passwd))
        assert(user.pw_name == getpass.getuser())
        # Linux seems to return the real UID not the effective UID

# Generated at 2022-06-23 18:16:49.334589
# Unit test for function get_os_user
def test_get_os_user():
    """Test Function get_os_user()"""
    assert get_os_user('root')

# Generated at 2022-06-23 18:16:56.806049
# Unit test for function chown
def test_chown():
    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name

# Generated at 2022-06-23 18:17:01.132043
# Unit test for function find_paths
def test_find_paths():
    p = Path('~/')
    g = find_paths(p)
    assert isinstance(g, Generator)
    assert isinstance(next(g), Path)
    assert isinstance(find_paths('~/tmp/*')[0], PosixPath)



# Generated at 2022-06-23 18:17:10.702048
# Unit test for function normalize_path
def test_normalize_path():
    # Create the full path to the test file.
    path = os.path.abspath(__file__)
    # Create the path to the test directory.
    path_dir = os.path.dirname(path)
    # Set the current working directory to the test directory.
    os.chdir(path_dir)
    # Create a list of test cases
    # Each test case should have an expected value and a callable
    # that when called should return a value that is the same as expected
    # value.

# Generated at 2022-06-23 18:17:18.951913
# Unit test for function find_paths
def test_find_paths():
    """Tests the functionality of the :obj:`find_paths` function."""
    import pandas as pd

    # Create a dataframe to store the paths that we want to find.

# Generated at 2022-06-23 18:17:26.376786
# Unit test for function chmod
def test_chmod():
    tmpdir = Path(os.getenv('TMPDIR', '/tmp'))
    # Dirs
    _dir = tmpdir.joinpath('flutils.tests.osutils.dir')
    if _dir.exists():
        _dir.rmdir()

    _dir.mkdir()

    # File
    _file = _dir.joinpath('flutils.tests.osutils.txt')
    _file.touch()

    # Test modes
    chmod('~/tmp/flutils.tests.osutils.dir')
    assert _dir.stat().st_mode == 0o700

    chmod('~/tmp/flutils.tests.osutils.dir/flutils.tests.osutils.txt')
    assert _file.stat().st_mode == 0o600


# Generated at 2022-06-23 18:17:37.725249
# Unit test for function chown
def test_chown():
    from .generic import drop_privileges
    from .osutils import get_os_user

    drop_privileges()

    with Path.cwd().joinpath('tmp').joinpath('flutils.tests.osutils.txt') as path:
        Path(path).touch()

    with Path.cwd().joinpath('tmp').joinpath('flutils').joinpath('tests').joinpath('osutils').joinpath('txt') as path:
        try:
            chown(path, group='vip')
        except OSError:
            assert get_os_user().pw_name == 'root'
        else:
            assert get_os_user().pw_name != 'root'



# Generated at 2022-06-23 18:17:45.889157
# Unit test for function normalize_path
def test_normalize_path():
    """Test for function normalize_path."""
    # Note the space in between the directory and file separator.
    # This space is removed.
    path = normalize_path('/foo/bar /baz/')

    assert path == Path('/foo/bar/baz/')

    path = normalize_path('/foo/bar/baz/')

    assert path == Path('/foo/bar/baz/')

    path = normalize_path('~/tmp/foo/../bar')

    assert path == Path(os.path.expanduser('~/tmp/bar'))
normalize_path.register(bytes, functools.partial(normalize_path, path=bytes))



# Generated at 2022-06-23 18:17:48.699411
# Unit test for function directory_present
def test_directory_present():
    path = Path('/Users/len').user_home() / 'tmp/flutils-test.osutils'
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True
    path.rmdir()
    assert path.exists() is False



# Generated at 2022-06-23 18:17:55.109545
# Unit test for function get_os_group
def test_get_os_group():
    user = get_os_user().pw_name
    group = get_os_group(user).gr_name
    group_obj = get_os_group(group)
    assert isinstance(group_obj, grp.struct_group)
    assert group_obj.gr_name == group



# Generated at 2022-06-23 18:18:03.109616
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert isinstance(user.pw_name, str)
    assert isinstance(user.pw_passwd, str)
    assert isinstance(user.pw_uid, int)
    assert isinstance(user.pw_gid, int)
    assert isinstance(user.pw_gecos, str)
    assert isinstance(user.pw_dir, str)
    assert isinstance(user.pw_shell, str)



# Generated at 2022-06-23 18:18:14.425454
# Unit test for function normalize_path
def test_normalize_path():
    # Test normalize_path(path)
    # Happy path
    assert normalize_path('/tmp/foo') == Path('/tmp/foo')
    assert normalize_path('/tmp/foo/bar') == Path('/tmp/foo/bar')
    assert normalize_path('/tmp/foo/..') == Path('/tmp')
    assert normalize_path('~/tmp/foo') == Path(os.path.expanduser('~/tmp/foo'))
    assert normalize_path('~/.ssh') == Path(os.path.expanduser('~/.ssh'))
    assert normalize_path('~/.ssh/id_rsa.pub') == \
        Path(os.path.expanduser('~/.ssh/id_rsa.pub'))

# Generated at 2022-06-23 18:18:26.717715
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod."""
    import shutil
    from flutils.pathutils import (
        chmod,
        path_absent,
    )

    tmp_root = Path('~/tmp/flutils.tests.pathutils').expanduser()

    tmp_root.mkdir(parents=True, exist_ok=True)

    tmp_dir = Path('~/tmp/flutils.tests.pathutils').expanduser() / 'chmod_test'
    tmp_dir_2 = Path('~/tmp/flutils.tests.pathutils').expanduser() / 'chmod_test_2'
    tmp_dir_3 = Path('~/tmp/flutils.tests.pathutils').expanduser() / 'chmod_test_3'

    tmp_dir.mkdir(exist_ok=True)

# Generated at 2022-06-23 18:18:35.144423
# Unit test for function normalize_path
def test_normalize_path(): # noqa
    """Unit test for function normalize_path."""

    # Unicode literals are not allowed.
    # Testing for the bytes type.
    path = b'/foo/bar/baz'
    path = normalize_path(path)
    assert isinstance(path, Path)
    if os.path.altsep is None:
        assert path.as_posix() == '/foo/bar/baz'
    else:
        assert path.as_posix() == '/foo\\bar/baz'

    # Testing for the PosixPath type.
    path = Path('~/tmp')
    path = normalize_path(path)
    assert isinstance(path, Path)
    assert path.as_posix() == '/home/test_user/tmp'

    # Testing for the WindowsPath type.

# Generated at 2022-06-23 18:18:46.130916
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent.
    """
    from flutils.pathutils import path_absent
    from shutil import rmtree

    dir_path = Path('~/tmp/flutils/pathutils/test_path_absent')
    dir_path = dir_path.expanduser()
    dir_path.mkdir(parents=True, exist_ok=True)
    assert dir_path.exists()

    file_path = dir_path.joinpath('test_file.txt')
    file_path.touch()
    assert file_path.exists()

    sub_dir_path = dir_path.joinpath('test_dir')
    sub_dir_path.mkdir(parents=True, exist_ok=True)
    assert sub_dir_path.exists()

    path_absent

# Generated at 2022-06-23 18:18:54.575577
# Unit test for function find_paths
def test_find_paths():
    cwd = Path().cwd()
    paths = ['test_file.txt', 'test_dir', 'test_dir/test_file_in_test_dir.txt']
    for path in paths:
        path = cwd / path
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_dir() is False:
            with path.open('w') as o:
                o.write('test')

    # Test with a glob pattern w/o a path.  Should find the files
    # in the current working directory.
    paths = list(find_paths('test*'))
    actual = [path.as_posix() for path in paths]
    expected = [cwd / 'test_file.txt', cwd / 'test_dir']

# Generated at 2022-06-23 18:19:03.677963
# Unit test for function directory_present
def test_directory_present():  # pylint: disable=missing-function-docstring
    from flutils.pathutils import directory_present
    import shutil
    import pytest

    test_path = (
        Path('~')
        .expanduser()
        .joinpath('tmp', 'test_path')
    )

    test_path.mkdir(parents=True, mode=0o755, exist_ok=True)
    test_path.chmod(0o700)

    with pytest.raises(ValueError):
        directory_present('~/*')

    with pytest.raises(FileExistsError):
        directory_present(test_path)

    msg = (
        'The path: %r can NOT be created as a directory because it '
        'already exists as a ' % test_path.as_posix()
    )

# Generated at 2022-06-23 18:19:06.350101
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as temp_dir:
        Path(temp_dir).joinpath('file_one').open('x').close()
        Path(temp_dir).joinpath('dir_one').mkdir()
        results = list(find_paths(Path(temp_dir).joinpath('*')))
        assert len(results) == 2
        assert Path(temp_dir).joinpath('file_one') in results
        assert Path(temp_dir).joinpath('dir_one') in results



# Generated at 2022-06-23 18:19:08.079789
# Unit test for function chown
def test_chown():
    chown('/home/danelle/tmp/flutils.tests.osutils.txt')

# Generated at 2022-06-23 18:19:19.577951
# Unit test for function chown
def test_chown():
    """Test the chown function."""
    import os
    import pytest
    import tempfile
    from flutils.pathutils import chown, get_os_user, get_os_group
    from flutils.pyutils import get_random_str

    non_exist_str = get_random_str()
    non_exist_user = '{}_user'.format(non_exist_str)
    non_exist_group = '{}_group'.format(non_exist_str)

    with tempfile.TemporaryDirectory() as test_dir:
        tmp_file = os.path.join(test_dir, 'test_file')
        with open(tmp_file, 'w') as tmp_file_obj:
            tmp_file_obj.write('test_file')


# Generated at 2022-06-23 18:19:24.878275
# Unit test for function chmod
def test_chmod():
    # Test the following cases:
    #     - glob pattern and exists ==> chmod parent dir
    #     - glob pattern and not exists ==> nothing
    #     - file and exists ==> chmod file
    #     - file and not exists ==> nothing
    #     - directory and exist ==> chmod directory
    #     - directory and not exist ==> nothing
    pass



# Generated at 2022-06-23 18:19:32.015677
# Unit test for function path_absent
def test_path_absent():
    test_path = './test_tmp/file_foo.txt'
    os.makedirs(os.path.dirname(test_path), exist_ok=True)
    with open(test_path, mode='wt') as f:
        f.write('bar')
    assert os.path.exists(test_path) is True
    path_absent(test_path)
    assert os.path.exists(test_path) is False



# Generated at 2022-06-23 18:19:34.227973
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'



# Generated at 2022-06-23 18:19:44.081113
# Unit test for function path_absent
def test_path_absent():
    """Test the :func:`path_absent` function.

    """
    path = Path('~/tmp/path_absent_test')
    path.mkdir(mode=0o700, parents=True)
    path = normalize_path(path)

    if path.is_dir() is False:
        raise AssertionError(
            'The path: %r does NOT exist. '
            'The :func:`path_absent` '
            'function **MUST** be tested with a path that exists '
            'as a directory.' % path.as_posix()
        )

    path_absent(path)


# Generated at 2022-06-23 18:19:55.975744
# Unit test for function chmod
def test_chmod():
    from os import (
        listdir,
        mkdir,
        unlink,
    )
    from os.path import join
    import shutil
    from tempfile import mkdtemp
    from flutils.pathutils import (
        chmod,
        directory_present,
        path_absent,
    )

    path = join(mkdtemp(), 'test.txt')

# Generated at 2022-06-23 18:20:02.064467
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import exists_as
    from flutils.tests.pathutils.constants import (
        DIR_PATH,
        DIR_PATH2,
        DIR_PATH3,
        FILE_PATH,
        FILE_PATH2,
        TEST_FILE3
    )

    assert exists_as(FILE_PATH) == 'file'
    assert exists_as(FILE_PATH2) == 'file'
    assert exists_as(TEST_FILE3) == ''
    assert exists_as(DIR_PATH) == 'directory'
    assert exists_as(DIR_PATH2) == 'directory'
    assert exists_as(DIR_PATH3) == ''



# Generated at 2022-06-23 18:20:10.701065
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    import os
    from flutils.pathutils import path_absent
    with tempfile.TemporaryDirectory(prefix='flutils_test_path_absent_') as tmpdirname:
        # Build a temp directory structure
        tmpdirname = Path(tmpdirname)
        dir_one = tmpdirname.joinpath('dir_one')
        dir_one.mkdir()
        dir_two = dir_one.joinpath('dir_two')
        dir_two.mkdir()
        file_one = dir_one.joinpath('file_one')
        file_one.touch()
        file_two = dir_two.joinpath('file_two')
        file_two.touch()
        path_absent(tmpdirname)

# Generated at 2022-06-23 18:20:21.269239
# Unit test for function find_paths
def test_find_paths():
    import tempfile
    tempdir = None

# Generated at 2022-06-23 18:20:33.540262
# Unit test for function directory_present
def test_directory_present():

    # Test changing mode only
    directory_present(
        './tmp/unittests_directory_present_test',
        mode=0o755
    )
    test_dir = Path('./tmp/unittests_directory_present_test')
    assert test_dir.exists()
    assert test_dir.is_dir()
    assert test_dir.stat().st_mode == 0o40755
    test_dir.rmdir()

    # Test changing user and group only
    directory_present(
        './tmp/unittests_directory_present_test',
        user='www-data',
        group='www-data'
    )
    test_dir = Path('./tmp/unittests_directory_present_test')
    assert test_dir.exists()
    assert test_dir.is_

# Generated at 2022-06-23 18:20:45.195961
# Unit test for function directory_present
def test_directory_present():
    import pytest
    from flutils.pathutils import directory_present, path_absent


    user = getpass.getuser()
    home = Path.home()

    test_dir = '~/tmp/test_path'
    test_dir = normalize_path(test_dir)
    assert test_dir.as_posix().startswith(home.as_posix())

    assert path_absent(test_dir) is True

    test_dir = directory_present(test_dir)
    assert test_dir.is_dir() is True
    assert test_dir.owner() == user
    assert test_dir.group() == user

    test_dir = directory_present(test_dir)
    assert test_dir.is_dir() is True
    assert test_dir.owner() == user
    assert test_

# Generated at 2022-06-23 18:20:56.897681
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from tempfile import TemporaryFile

    from flutils.pathutils import directory_present

    with TemporaryDirectory() as tmpdir:
        base_path = Path(tmpdir)
        test_path = base_path.joinpath('foo/bar/baz')

        assert directory_present(test_path) == Path('%s/foo/bar/baz' % tmpdir)
        assert directory_present(test_path) == Path('%s/foo/bar/baz' % tmpdir)

        # Test one of the parent dirs not being a directory.
        with TemporaryFile(dir=tmpdir) as tmpfile:
            test_path = Path('%s/foo/%s' % (tmpdir, tmpfile.name))


# Generated at 2022-06-23 18:21:05.148552
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(get_os_user().pw_uid).pw_uid == get_os_user().pw_uid
    try:
        get_os_user(999999)
    except OSError:
        pass
    else:
        raise AssertionError('OSError NOT raised.')



# Generated at 2022-06-23 18:21:09.680826
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path
    from pathlib import Path, PurePosixPath, PureWindowsPath
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path(PurePosixPath('/tmp/foo/../bar')) == Path('/tmp/bar')
    assert normalize_path('c:\\tmp\\foo\\..\\bar') == Path('c:/tmp/bar')
    assert normalize_path(PureWindowsPath('c:\\tmp\\foo\\..\\bar')) == Path('c:/tmp/bar')
normalize_path.register(bytes, lambda path: Path(bytes.decode(path, sys.getfilesystemencoding())))

# Generated at 2022-06-23 18:21:17.619384
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user(9999)
    except OSError:
        pass
    else:
        raise Exception(
            'The function get_os_user did NOT raise OSError given an invalid '
            'uid.'
        )
    try:
        get_os_user('invalid_name')
    except OSError:
        pass
    else:
        raise Exception(
            'The function get_os_user did NOT raise OSError given an invalid '
            'name.'
        )
    try:
        get_os_user()
    except Exception:
        raise
    else:
        pass

# Generated at 2022-06-23 18:21:23.119431
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user, normalize_path
    assert get_os_user() == get_os_user(os.environ.get('USER'))
    assert get_os_user() == get_os_user(os.environ.get('LOGNAME'))
    assert get_os_user() == get_os_user(os.getuid())



# Generated at 2022-06-23 18:21:30.017573
# Unit test for function exists_as
def test_exists_as():
    tmp = None

# Generated at 2022-06-23 18:21:42.332188
# Unit test for function chmod
def test_chmod():
    tmp = Path('~/tmp') / 'flutils.tests.osutils'
    tmp = normalize_path(tmp)
    tmp.mkdir(parents=True, exist_ok=True)
    file = tmp / 'test_chmod.txt'
    file.write_text('TEST')
    assert file.exists() is True
    assert file.is_file() is True
    assert file.stat().st_mode == 0o100644
    chmod(file.as_posix(), 0o600)
    assert file.stat().st_mode == 0o100600
    chmod(file.as_posix(), 0o660)
    assert file.stat().st_mode == 0o100660
    chmod(file.as_posix(), 0o660)



# Generated at 2022-06-23 18:21:43.789369
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user."""
    assert get_os_user()
    assert get_os_user(1001)
    assert get_os_user('foo')
    assert get_os_user('-1')



# Generated at 2022-06-23 18:21:51.060318
# Unit test for function directory_present
def test_directory_present():
    tmp_dir = normalize_path('~/tmp')
    directory_present(tmp_dir, user='root', group='wheel')
    assert exists_as(tmp_dir) == 'directory'
    assert get_os_user(tmp_dir.owner()).pw_name == 'root'
    assert get_os_group(tmp_dir.group()).gr_name == 'wheel'

    test_path = normalize_path('~/tmp/test_path')
    directory_present(test_path)
    assert exists_as(test_path) == 'directory'
    assert get_os_user(test_path.owner()).pw_name == getpass.getuser()
    assert get_os_group(test_path.group()).gr_name == getpass.getuser()
    test_path.rmd

# Generated at 2022-06-23 18:21:58.709298
# Unit test for function directory_present
def test_directory_present():
    path = normalize_path('~/tmp')
    path.mkdir(mode=0o755)

    dir_path = directory_present(
        path=path / 'test_path',
        mode=0o750,
        user='-1',
        group='-1',
    )
    assert dir_path.is_dir() is True, 'The given path: %r must be a directory.' % dir_path.as_posix()
    assert dir_path.stat().st_mode & 0o7777 == 0o750
    assert dir_path.stat().st_uid == os.getuid()
    assert dir_path.stat().st_gid == os.getgid()

    # This should NOT create a new path.

# Generated at 2022-06-23 18:22:10.535816
# Unit test for function chown
def test_chown():
    with TempDir() as tmpdir:
        new_path = Path(tmpdir) / 'foo.txt'
        new_path.touch()

        # This requires root to succeed.  But we will skip if it
        # fails.
        try:
            chown(new_path, user='root')
        except PermissionError:
            pass
        else:
            assert get_os_user().pw_uid == os.stat(new_path).st_uid

        try:
            chown(new_path, group='root')
        except PermissionError:
            pass
        else:
            assert get_os_group().gr_gid == os.stat(new_path).st_gid



# Generated at 2022-06-23 18:22:19.891366
# Unit test for function exists_as
def test_exists_as():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        assert exists_as(tmpdir) == 'directory'
        assert exists_as(tmpdir.joinpath('foo')) == ''
        assert exists_as(tmpdir.joinpath('bar.txt')) == ''
        assert exists_as(tmpdir.joinpath('foo/bar.txt')) == ''
        assert exists_as(tmpdir.joinpath('drop/boom.txt')) == ''

        foo_dir = tmpdir.joinpath('foo')
        foo_dir.mkdir()
        assert exists_as(foo_dir) == 'directory'
        assert exists_as(foo_dir.joinpath('bar.txt')) == ''

# Generated at 2022-06-23 18:22:29.952661
# Unit test for function chmod
def test_chmod():
    from tests.data.common import tmp_dir
    from tests.data import common

    tmp_dir = tmp_dir(__file__)

    # chmod the tmp_dir
    mode = 0o770
    test_file = tmp_dir / 'flutils.tests.osutils.txt'
    test_dir = tmp_dir / 'flutils.tests.osutils'
    test_dir.mkdir()
    test_file.touch()

    # test chmod the tmp dir
    chmod(tmp_dir, mode_dir=mode)

    # test chmod files
    chmod(test_file, mode_file=mode)
    assert os.stat(test_file.as_posix()).st_mode & 0o700 == mode

    # test chmod dirs

# Generated at 2022-06-23 18:22:40.628355
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('./foo') == os.path.join(os.getcwd(), 'foo')
    assert normalize_path('./foo/./bar/../baz') == Path(os.getcwd()).joinpath('foo', 'baz')
    assert normalize_path('~') != os.path.expanduser('~')
    assert normalize_path('~') == Path(os.path.expanduser('~')).as_posix()
    assert normalize_path('~/foo') != os.path.expanduser('~/foo')
    assert normalize_path('~/foo') == Path(os.path.expanduser('~/foo')).as_posix()

# Generated at 2022-06-23 18:22:45.847801
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/bar'
    npath = normalize_path(path)
    if not npath.endswith(path[1:]):
        raise AssertionError('Expected: %r, Got: %r' % (path, npath))

    path = '$USER/$USERNAME'
    npath = normalize_path(path)
    if not npath.endswith(path[1:]):
        raise AssertionError('Expected: %r, Got: %r' % (path, npath))



# Generated at 2022-06-23 18:22:47.137228
# Unit test for function chown
def test_chown():
    # TODO: namespace test_chown
    pass



# Generated at 2022-06-23 18:22:59.435205
# Unit test for function get_os_user
def test_get_os_user():
    pass
    from unittest import TestCase
if sys.version_info[0] >= 3:
    from unittest.mock import patch
    # TODO: Can't get patch to work for classmethods.
    # May need to use unittest.mock from PyPI.
    # @patch('flutils.pathutils.pwd.getpwnam', side_effect=KeyError)
    # @patch('flutils.pathutils.getpass.getuser', return_value='test_user')
    # def test_get_os_user(self):
    #     self.assertRaises(
    #         KeyError,
    #         get_os_user
    #     )
    #
    # @patch('flutils.pathutils.pwd.getpwuid', side_effect=KeyError)
   

# Generated at 2022-06-23 18:23:07.757794
# Unit test for function directory_present
def test_directory_present():
    """Unit test."""
    assert directory_present('~/tmp/flutils.tests.pathutils/target1/')
    # Clear it out for the next test.
    # refresh the path so it is a new Path object.
    path = normalize_path('~/tmp/flutils.tests.pathutils/target1/')
    path.rmdir()
    assert directory_present(
        '~/tmp/flutils.tests.pathutils/target2/',
        mode=0o770
    )
    path = normalize_path('~/tmp/flutils.tests.pathutils/target2/')
    assert oct(path.stat().st_mode)[-3:] == '770'
    # Clear it out for the next test.
    # refresh the path so it is a new Path object.
    path.rmd

# Generated at 2022-06-23 18:23:13.528681
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == grp.struct_group(gr_name='bar',
                                                   gr_passwd='x', gr_gid=2001,
                                                   gr_mem=['foo'])



# Generated at 2022-06-23 18:23:14.175141
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:23:15.887901
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('bar') == get_os_group(2001)



# Generated at 2022-06-23 18:23:17.920385
# Unit test for function get_os_group
def test_get_os_group():
    """Test function get_os_group."""
    assert get_os_group()

# Generated at 2022-06-23 18:23:25.994254
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pyutils import rm_rf

    test_dir = directory_present('~/tmp/flutils.tests.pathutils.dir')
    assert test_dir.as_posix() == '~/tmp/flutils.tests.pathutils.dir'

    other_dir = directory_present(
        '~/tmp/flutils.tests.pathutils.dir/other_dir'
    )
    assert other_dir.as_posix() == '~/tmp/flutils.tests.pathutils.dir/other_dir'

    rm_rf(test_dir.as_posix())



# Generated at 2022-06-23 18:23:31.696295
# Unit test for function path_absent
def test_path_absent():
    import os
    import tempfile
    import shutil
    import pytest

    @pytest.fixture(autouse=True)
    def root_dir_setup(root_dir: str) -> None:
        child = os.path.join('a', 'b')
        child_dir = os.path.join(root_dir, child)
        os.makedirs(child_dir, exist_ok=True)
        os.chdir(root_dir)
        test_dir = 'test_dir'
        test_file = 'test_file'
        os.makedirs(test_dir, exist_ok=True)
        with open(test_file, 'w', encoding='utf-8') as f:
            f.write('test')

# Generated at 2022-06-23 18:23:32.335105
# Unit test for function get_os_group
def test_get_os_group():
    pass



# Generated at 2022-06-23 18:23:41.385211
# Unit test for function normalize_path
def test_normalize_path():
    assert ((normalize_path('~/tmp/foo/../bar') ==
             Path(os.path.expanduser('~/tmp/foo/../bar'))) is True)
    assert ((normalize_path('~/tmp/foo/../bar') ==
             Path(os.path.expanduser('~/tmp//bar/.'))) is True)
    assert ((normalize_path('tmp/foo/../bar') ==
             Path(os.path.join(os.getcwd(), 'tmp/bar'))) is True)



# Generated at 2022-06-23 18:23:47.554510
# Unit test for function path_absent
def test_path_absent():
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:23:51.831441
# Unit test for function path_absent
def test_path_absent():
    cwd = os.getcwd()
    path = Path(cwd, 'tmp', 'test_file.txt')
    path.touch()
    path_absent(path=path)
    assert path.exists() is False
    path = Path(cwd, 'tmp', 'test_dir')
    path.mkdir()
    path_absent(path=path)
    assert path.exists() is False
    path = Path(cwd, 'tmp', 'test_link.txt')
    linked_path = Path(cwd, 'tmp', 'test_file.txt')
    linked_path.touch()
    path.symlink_to(linked_path)
    path_absent(path=path)
    assert path.exists() is False

# Generated at 2022-06-23 18:24:01.719944
# Unit test for function find_paths
def test_find_paths():
    """Test ``find_paths()``"""
    # Create example directory structure
    tmp_path = normalize_path('~/tmp')
    os.makedirs(tmp_path.as_posix())
    with io.open(
            '%s/abcdef.txt' % tmp_path.as_posix(), 'w', encoding='UTF-8'
    ) as file_handler:
        file_handler.write('abcdef')

    with io.open(
            '%s/012345.txt' % tmp_path.as_posix(), 'w', encoding='UTF-8'
    ) as file_handler:
        file_handler.write('012345')


# Generated at 2022-06-23 18:24:12.820536
# Unit test for function chmod
def test_chmod():
    from os import PathLike
    from tempfile import TemporaryDirectory
    from testfixtures import (
        compare,
        ShouldRaise,
        tempdir,
        TestCase,
        test_datetime
    )
    from unittest.mock import (
        Mock,
        mock_open,
        patch,
    )
    from pathlib import Path
    from flutils.pathutils import (
        chmod,
        normalize_path
    )

    with patch('pathlib.Path.exists', Mock(return_value=True)):
        with ShouldRaise(NotImplementedError):
            with patch('pathlib.Path.glob', Mock(return_value=[])):
                chmod('/tmp/*', 0o777, 0o777)

        # Test single file

# Generated at 2022-06-23 18:24:21.632658
# Unit test for function chmod
def test_chmod():
    print('Testing function chmod()...', end='')
    with tempfile.TemporaryDirectory() as tmp_path:
        sample_file = os.path.join(tmp_path, 'sample.txt')
        sample_dir = os.path.join(tmp_path, 'sample')
        sample_sub_dir = os.path.join(sample_dir, 'sub')
        sample_subsub_dir = os.path.join(sample_sub_dir, 'subsub')
        sample_subsubsubsub_dir = os.path.join(sample_subsub_dir, 'subsubsub')
        sample_subsubsubsubsub_dir = os.path.join(sample_subsubsubsub_dir, 'subsubsubsub')
        os.makedirs(sample_subsubsubsubsub_dir)

# Generated at 2022-06-23 18:24:26.225815
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test `get_os_user`."""
    import getpass
    with pytest.raises(OSError):
        get_os_user('something')
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-23 18:24:34.566578
# Unit test for function path_absent
def test_path_absent():
    testdir = '~/tmp/test_path_absent'
    path_absent(testdir)
    with open(normalize_path(testdir), 'w') as f:
        f.write('/home/testuser/tmp/test_path_absent')
    path_present(testdir)
    path_absent(testdir)
    try:
        with open(normalize_path(testdir), 'r') as f:
            f.read()
    except FileNotFoundError:
        pass
    else:
        assert False
test_path_absent.__test__ = False



# Generated at 2022-06-23 18:24:45.909562
# Unit test for function exists_as
def test_exists_as():
    path = normalize_path('~/tmp/flutils.tests.osutils.txt')
    try:
        with path.open('a'):
            assert exists_as(path) == 'file'
    except FileNotFoundError:
        with path.open('w'):
            assert exists_as(path) == 'file'
    finally:
        path.unlink()
    assert exists_as(path) == ''

    path = normalize_path('~/tmp/flutils.tests')
    try:
        path.mkdir()
        assert exists_as(path) == 'directory'
    except FileExistsError:
        assert exists_as(path) == 'directory'
    finally:
        path.rmdir()
    assert exists_as(path) == ''


# Generated at 2022-06-23 18:24:47.386716
# Unit test for function chown
def test_chown():
    chown('~/tmp/flutils.tests.osutils.txt')
    assert True



# Generated at 2022-06-23 18:24:53.563130
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from tempfile import mkdtemp
    from shutil import rmtree
    from typing import Iterable

    def _find_paths(path: str) -> Iterable[str]:
        paths = list(find_paths(path))
        for index, path in enumerate(paths):
            paths[index] = path.resolve().as_posix()
        return paths

    def _make_tmp_dir(tmp_dir: str, dir_name: str) -> None:
        tmp_dir = Path(tmp_dir)
        dir_name = tmp_dir.joinpath(dir_name)
        dir_name.mkdir()


# Generated at 2022-06-23 18:25:02.438834
# Unit test for function directory_present
def test_directory_present():
    '''

    :return:
    '''
    assert directory_present('/tmp/test_path').as_posix() == '/tmp/test_path'
    assert directory_present('/tmp/test_path/test_2').as_posix() == '/tmp/test_path/test_2'
    assert directory_present('/tmp/test_path', user=os.getuid()).as_posix() == '/tmp/test_path'
    assert directory_present('/tmp/test_path/test_2', user=os.getuid()).as_posix() == '/tmp/test_path/test_2'
    assert directory_present('/tmp/test_path', group=os.getgid()).as_posix() == '/tmp/test_path'

# Generated at 2022-06-23 18:25:07.704460
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    tmp_path = Path().home() / 'tmp'
    test_path = tmp_path / 'test_path_absent_file'
    test_path2 = tmp_path / 'test_path_absent_dir'
    test_path3 = test_path2 / 'test_path_absent_file3'
    os.mkdir(test_path2)
    test_path.touch()
    test_path3.touch()
    path_absent(test_path)
    path_absent(test_path2)
    assert exists_as(test_path) == ''
    assert exists_as(test_path2) == ''
    assert exists_as(test_path3) == ''



# Generated at 2022-06-23 18:25:19.239903
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod

    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)
    assert os.access('~/tmp/flutils.tests.osutils.txt', os.R_OK) is True
    assert os.access('~/tmp/flutils.tests.osutils.txt', os.W_OK) is True

    chmod('~/tmp/*', 0o770)
    assert os.access('~/tmp/flutils.tests.osutils.txt', os.R_OK) is True
    assert os.access('~/tmp/flutils.tests.osutils.txt', os.W_OK) is True
    assert os.access('~/tmp/flutils.tests.osutils.txt', os.X_OK) is True


# Generated at 2022-06-23 18:25:29.909328
# Unit test for function normalize_path
def test_normalize_path():
    _os_cwd = os.getcwd()
    os.chdir(str(Path(__file__).parent))
    path = Path('~/tmp/foo/../bar')
    exp_path_str = '%s/tmp/bar' % os.getenv('HOME')
    exp_path = Path(exp_path_str)
    ret_path = normalize_path(path)
    _test_path = Path.cwd() / 'tests'
    _test_path = normalize_path(_test_path)
    os.chdir(_os_cwd)
    assert ret_path.as_posix() == exp_path.as_posix()
    assert ret_path == exp_path
    assert ret_path.parent == exp_path.parent
    assert ret_path.parent == _test_path

# Generated at 2022-06-23 18:25:34.969083
# Unit test for function get_os_group
def test_get_os_group():
    """Test that the get_os_group returns the same result as the
    `grp.getgrnam` method.

    """
    import grp
    foo = grp.getgrnam('foo')
    bar = get_os_group('foo')
    assert foo == bar



# Generated at 2022-06-23 18:25:45.636496
# Unit test for function exists_as
def test_exists_as():
    from .unittest_helpers import flutils_test_case, TEST_DATA_PATH
    from .unittest_helpers import TEST_TEMP_PATH
    from unittest import TestCase
    import tempfile

    class TestExistsAs(TestCase):

        def test_exists_as(self):

            test_exists_as_dir_path = TEST_DATA_PATH / 'test_exists_as'
            self.assertEqual(exists_as(test_exists_as_dir_path), 'directory')

            test_exists_as_dirs_and_files = (
                'test_exists_as_dirs_and_files.txt',
                'test_exists_as_dirs_and_files_dir',
            )


# Generated at 2022-06-23 18:25:51.349681
# Unit test for function get_os_group
def test_get_os_group():
    os_group = get_os_group('wheel')
    gr_gid = getattr(os_group, 'gr_gid')
    gr_name = getattr(os_group, 'gr_name')
    assert isinstance(gr_gid, int)
    assert isinstance(gr_name, str)



# Generated at 2022-06-23 18:25:55.624950
# Unit test for function normalize_path
def test_normalize_path():
    path = inspect.getfile(test_normalize_path)
    normalized_path = normalize_path(path)
    assert normalized_path.as_posix() == path
    assert normalized_path.as_posix() == os.path.realpath(path)



# Generated at 2022-06-23 18:26:03.485367
# Unit test for function directory_present
def test_directory_present():
    from os import path
    from tempfile import mkdtemp
    from shutil import rmtree

    tmp_dir = mkdtemp()

# Generated at 2022-06-23 18:26:11.974559
# Unit test for function get_os_group
def test_get_os_group():
    # A name that exists as a group name.
    get_os_group('adm')

    # A name that does not exists as a group name.
    try:
        get_os_group('foo')
    except OSError:
        pass
    else:
        raise AssertionError('The given name: foo, must not exist.')

    # A valid gid.
    get_os_group(2000)

    # A gid that does not exist.
    try:
        get_os_group(1000000)
    except OSError:
        pass
    else:
        raise AssertionError('The given gid: 1000000, must not exist.')

    # Leave group as the current user's group.
    get_os_group(None)



# Generated at 2022-06-23 18:26:15.758043
# Unit test for function normalize_path
def test_normalize_path():
    """Test function normalize_path

    """
    # pylint: disable=missing-function-docstring
    # pylint: disable=invalid-name
    try:
        return _test_normalize_path()
    except Exception as error:  # pragma: no cover
        print(error.__class__.__name__)
        print(error)
        return 1



# Generated at 2022-06-23 18:26:20.513118
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/foo/../bar'
    assert normalize_path(path).as_posix() == '/home/test_user/tmp/bar'
    path = r'C:\test\foo\..\bar'
    assert normalize_path(path).as_posix() == 'C:/test/tmp/bar'



# Generated at 2022-06-23 18:26:22.545873
# Unit test for function get_os_user
def test_get_os_user():
    try:
        assert get_os_user(os.getuid()) == get_os_user()
    except AssertionError:
        print("get_os_user() failed to return itself.")


# Generated at 2022-06-23 18:26:32.778495
# Unit test for function path_absent
def test_path_absent():
    def _test():
        path_test = Path('test_flutils_pathutils_path_absent')

        if path_test.is_dir():
            rmtree(path_test)
        path_test.mkdir(mode=0o700)

        Path('foo').touch()
        path_absent(path_test)
        assert path_test.is_dir() is False
        path_test.mkdir(mode=0o700)

        Path(path_test, 'foo').touch()
        path_absent(path_test)
        assert path_test.is_dir() is False
        path_test.mkdir(mode=0o700)

        Path(path_test, 'foo').touch()
        xtra_dir = Path(path_test, 'xtra_dir')
        xtra