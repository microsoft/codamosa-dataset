

# Generated at 2022-06-23 18:16:43.456284
# Unit test for function find_paths
def test_find_paths():

    # Create a directory test path
    test_path = Path('/tmp/tmp_file')
    if test_path.exists():
        test_path.unlink()
    else:
        test_path.mkdir()

    # Check for a single directory
    files = tuple(find_paths(test_path))
    assert len(files) == 1
    assert files[0].as_posix() == test_path.as_posix()

    # Create a test file
    test_file = test_path / 'test_file_one'
    test_file.touch()
    test_files = tuple(find_paths(test_path))
    assert len(test_files) == 2
    assert test_files[0].as_posix() == test_path.as_posix()

# Generated at 2022-06-23 18:16:47.495305
# Unit test for function find_paths
def test_find_paths():
    expected = [Path('test_paths/dir_one'), Path('test_paths/file_one')]
    actual = list(find_paths(Path('test_paths/*')))
    assert set(expected) == set(actual)



# Generated at 2022-06-23 18:16:55.773951
# Unit test for function path_absent
def test_path_absent():
    os.chdir('tests')

# Generated at 2022-06-23 18:17:06.943782
# Unit test for function exists_as
def test_exists_as():
    from . import POSIX_TEST_FILE
    from . import POSIX_TEST_DIR
    from . import POSIX_TEST_SOCKET
    from . import POSIX_TEST_FIFO
    from . import POSIX_TEST_BROKEN_SYMLINK
    from . import POSIX_TEST_SYMLINK_TO_DIR
    from . import POSIX_TEST_SYMLINK_TO_FILE

    assert exists_as(POSIX_TEST_FILE) == 'file'
    assert exists_as(POSIX_TEST_DIR) == 'directory'
    assert exists_as(POSIX_TEST_SOCKET) == 'socket'
    assert exists_as(POSIX_TEST_FIFO) == 'FIFO'

# Generated at 2022-06-23 18:17:13.121675
# Unit test for function chmod
def test_chmod():
    from ..osutils import tmp_dir_ctx
    from flutils.pathutils import path_absent
    from flutils.fileutils import touch

    with tmp_dir_ctx(prefix='test_chmod_', suffix='_tmp') as tmp_dir:
        normalized_path = str(tmp_dir)

        assert path_absent(normalized_path) is True

        os.mkdir(normalized_path)

        assert os.path.isdir(normalized_path)

        #
        # Set the mode to 0o777 so that we can see if the mode was changed
        # later
        #
        os.chmod(normalized_path, 0o777)

        assert os.stat(normalized_path).st_mode & 0o777 == 0o777

        touch(normalized_path + '/file.txt')



# Generated at 2022-06-23 18:17:22.503636
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from pathlib import Path
    from os import remove

    p = Path('~/tmp/dir_one/dir_two').expanduser()
    p.mkdir(parents=True, exist_ok=True)
    Path('~/tmp/dir_one/dir_two/file_one.py').touch()
    Path('~/tmp/dir_one/dir_two/file_two.py').touch()
    pth = p.joinpath('file_three.py')
    pth.touch()
    pth.write_text('print(1)')
    pth.unlink()

    paths = sorted([path.as_posix() for path in find_paths('~/tmp/dir_one/*')])

# Generated at 2022-06-23 18:17:25.109000
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp')
    assert path == Path(os.environ['HOME'], 'tmp')



# Generated at 2022-06-23 18:17:31.770457
# Unit test for function get_os_user
def test_get_os_user():
    """Test cases for function get_os_user."""
    try:
        # Test for non-existing uid.
        get_os_user(0)
    except OSError:
        pass
    else:
        raise AssertionError('Expected OSError.')
    try:
        # Test for non-existing "login name".
        get_os_user('non-existing-user')
    except OSError:
        pass
    else:
        raise AssertionError('Expected OSError.')
    # Test for current user.
    assert isinstance(get_os_user(), pwd.struct_passwd)



# Generated at 2022-06-23 18:17:40.622203
# Unit test for function path_absent
def test_path_absent():
    # Create a directory for testing path_absent
    test_dir = '~/tmp/test_path_absent'

    # Ensure the test directory is deleted if it exists
    path_absent(test_dir)

    # Create the test directory
    make_dir(test_dir)

    # Create a test file
    test_file = Path(test_dir).joinpath('test_file')
    with test_file.open(mode='w') as fh:
        fh.write('test')

    # Create a test link
    test_link = Path(test_dir).joinpath('test_link')
    test_link.symlink_to(test_file, target_is_directory=False)

    assert test_file.is_file()
    assert test_link.is_symlink()

    # Ensure

# Generated at 2022-06-23 18:17:51.820440
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""

    current_dir = os.getcwd()

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_parent = Path(tmp_dir.name)
    tmp_link = tmp_parent / 'link_one'
    tmp_path = tmp_parent / 'test_parent'
    tmp_file = tmp_path / 'file_one'

    tmp_link.symlink_to(tmp_file)


# Generated at 2022-06-23 18:17:58.813450
# Unit test for function normalize_path
def test_normalize_path():
    with pytest.raises(TypeError) as exc_info:
        normalize_path(0)
    # print(exc_info.value)
    assert 'The given path: 0 must be one of the following types:' in (
        str(exc_info.value)
    )
    assert 'str' in str(exc_info.value)
    assert 'bytes' in str(exc_info.value)
    assert 'pathlib' in str(exc_info.value)
    if 'str' not in str(exc_info.value):
        raise exc_info
    if 'bytes' not in str(exc_info.value):
        raise exc_info
    if 'pathlib' not in str(exc_info.value):
        raise exc_info
    assert exc_info.type == TypeError

# Generated at 2022-06-23 18:18:07.123266
# Unit test for function chown
def test_chown():
    import unittest.mock
    from flutils.pathutils import chown
    with unittest.mock.patch('os.chown') as mock_chown:
        chown('/tmp/foo')
        mock_chown.assert_called_once_with(
            '/tmp/foo',
            unittest.mock.ANY,
            unittest.mock.ANY
        )



# Generated at 2022-06-23 18:18:18.415027
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function."""
    import tempfile
    import shutil
    from os.path import join, dirname, exists
    from flutils.pathutils import find_paths
    with tempfile.TemporaryDirectory('flutils_test_') as tmpdir:
        # Create a directory and file
        (Path(tmpdir) / 'sub_dir_one').mkdir()
        (Path(tmpdir) / 'sub_dir_one' / 'sub_sub_dir_one').mkdir()
        (Path(tmpdir) / 'sub_dir_one' / 'sub_sub_dir_one' / 'file_one.txt').touch()
        (Path(tmpdir) / 'sub_dir_one' / 'sub_sub_dir_one' / 'file_two.txt').touch()

# Generated at 2022-06-23 18:18:29.908579
# Unit test for function path_absent
def test_path_absent():
    # Setup
    pattern = normalize_path('~/tmp/*')
    for path in find_paths(pattern):
        path_absent(path)
    p1 = normalize_path('~/tmp/file_one')
    p2 = normalize_path('~/tmp/file_two')
    p3 = normalize_path('~/tmp/dir_one')
    p4 = normalize_path('~/tmp/dir_one/file_three')
    p5 = normalize_path('~/tmp/dir_two')
    p6 = normalize_path('~/tmp/dir_two/file_three')
    p7 = normalize_path('~/tmp/dir_two/file_four')
    p8 = normalize_path('~/tmp/dir_two/dir_three')


# Generated at 2022-06-23 18:18:36.435898
# Unit test for function directory_present
def test_directory_present():
    assert directory_present('/tmp/flutils.test_directory_present') == (
        Path('/tmp/flutils.test_directory_present')
    )
    assert directory_present('/tmp/flutils.test_directory_present') == (
        Path('/tmp/flutils.test_directory_present')
    )



# Generated at 2022-06-23 18:18:44.448591
# Unit test for function chmod
def test_chmod():
    from os import path

    from flutils.pathutils import PathLike

    path_orig = path.abspath('~/tmp/flutils.tests.osutils.txt')
    path = PathLike(path_orig)
    mode_file = 0o660

    # Ensure file exists
    open(path, 'w').close()

    chmod(path, mode_file=mode_file)
    assert path.stat().st_mode & 0o777 == mode_file

    # Cleanup
    path.unlink()
    assert path.exists() is False
test_chmod()



# Generated at 2022-06-23 18:18:49.842733
# Unit test for function path_absent
def test_path_absent():
    """Tests for the function path_absent."""
    # Import the function to test
    import flutils.pathutils as putils
    path = Path('/tmp/foo/bar')
    path.mkdir(parents=True, exist_ok=True)
    path = path / 'file.txt'
    path.touch()
    putils.path_absent(path)



# Generated at 2022-06-23 18:18:51.748940
# Unit test for function get_os_group
def test_get_os_group():
    try:
        assert grp.getgrnam('bar') == get_os_group('bar')
    except KeyError:
        pytest.skip("This test won't pass if the group 'bar' is not present.")



# Generated at 2022-06-23 18:18:57.847913
# Unit test for function chmod
def test_chmod():
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    file_a = os.path.join(tmp_dir, 'a')
    file_b = os.path.join(tmp_dir, 'b')
    file_c = os.path.join(tmp_dir, 'c')
    dir_a = os.path.join(tmp_dir, 'dir_a')
    dir_b = os.path.join(tmp_dir, 'dir_b')
    dir_c = os.path.join(tmp_dir, 'dir_c')

    # Test None input
    try:
        chmod(None)
    except TypeError:
        pass
    else:
        raise AssertionError('None path should have raised TypeError.')

    # Test empty input

# Generated at 2022-06-23 18:19:04.710934
# Unit test for function exists_as
def test_exists_as():
    def test(path, expected):
        actual = exists_as(path)
        assert actual == expected

    test(__file__, 'file')
    test(__file__ + 'foo', '')
    test(__file__ + 'foo.py', '')
    test(__file__ + '/foo.py', '')
    test(__file__ + '/foo', '')
    test(Path(__file__).parent, 'directory')
    test(Path(__file__).parent + '/foo.py', '')



# Generated at 2022-06-23 18:19:15.686384
# Unit test for function chmod
def test_chmod():
    tmpdir = Path(Path(__file__).absolute().parent, 'tmp')
    tmpdir.mkdir(exist_ok=True)
    tmpfile = Path(tmpdir, 'tmpfile1')
    tmpfile.touch()
    assert tmpfile.stat().st_mode - 0o100 == 0o600
    assert tmpfile.is_symlink() == False
    # Create a symlink with a target that is a file
    # and make sure that the symlink target is changed
    # but not the symlink itself
    tmpfile2 = Path(tmpdir, 'tmpfile2')
    tmpfile2.touch()
    Path(tmpdir, 'tmpfile2_symlink').symlink_to(tmpfile2)

# Generated at 2022-06-23 18:19:26.301095
# Unit test for function find_paths
def test_find_paths():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import isdir, join


# Generated at 2022-06-23 18:19:34.761923
# Unit test for function normalize_path
def test_normalize_path():
    from .schemas import Paths
    from .schemas import PosixPaths
    from .schemas import WindowsPaths

    paths = Paths()
    posix_paths = PosixPaths()
    windows_paths = WindowsPaths()

    assert normalize_path(paths.posix.absolute) == posix_paths.absolute
    assert normalize_path(paths.posix.home) == posix_paths.home
    assert normalize_path(paths.posix.parent) == posix_paths.parent
    assert normalize_path(paths.posix.relative) == posix_paths.relative
    assert normalize_path(paths.posix.relative_with_parent) == \
        posix_paths.relative_with_parent
    assert normalize

# Generated at 2022-06-23 18:19:46.968141
# Unit test for function find_paths
def test_find_paths():
    # Create test files and directories
    data_dir = os.path.abspath(
        os.path.join(os.path.dirname(__file__), 'data')
    )
    started_dir = os.path.abspath(os.path.curdir)
    os.chdir(data_dir)
    shutil.copytree(
        'deep_kevin',
        os.path.join('find_paths', 'deep_kevin')
    )
    shutil.copytree(
        'no_dot',
        os.path.join('find_paths', 'no_dot')
    )
    for _ in range(4):
        os.makedirs(os.path.join('find_paths', 'mkdirs' + str(_)))

# Generated at 2022-06-23 18:19:57.654136
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    from flutils.pathutils import normalize_path
    from flutils.commonutils import get_new_temp_dir

    temp_dir = get_new_temp_dir()

# Generated at 2022-06-23 18:20:05.475000
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path."""
    path = normalize_path('~/foo/../bar')
    assert path.as_posix() == os.path.join(os.getcwd(), '/home/test_user/bar')

    path = normalize_path('~/foo/../bar/')
    assert path.as_posix() == os.path.join(os.getcwd(), '/home/test_user/bar')

    path = normalize_path('~/foo/./bar')
    assert path.as_posix() == os.path.join(os.getcwd(), '/home/test_user/foo/bar')

    path = normalize_path('~/foo/./bar/')

# Generated at 2022-06-23 18:20:13.106717
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/test') == (
        '/home/test_user/tmp/test'
        if os.name == 'posix' else
        'C:\\Users\\test_user\\tmp\\test'
    )
    assert normalize_path('E:/test') == os.path.normcase('E:/test')
    assert normalize_path('E:\\test') == os.path.normcase('E:\\test')
    assert normalize_path('test') == os.path.normcase(
        'C:\\Users\\test_user\\tmp\\test'
        if os.name == 'nt' else
        '/home/test_user/tmp/test'
    )
normalize_path.register(bytes, normalize_path)

# Generated at 2022-06-23 18:20:19.722327
# Unit test for function chmod
def test_chmod():
    import os

    import pytest

    from flutils.pathutils import chmod

    # Normalize the current working directory into a path object.
    cwd = Path().cwd().absolute()

    # Create some test paths.
    test_paths = [
        Path(cwd, Path(__file__)).parent.parent,
        Path(cwd, Path(__file__)).parent,
        Path(cwd, Path(__file__)),
    ]

    # The expected modes for the test paths.
    test_modes = [
        0o750,
        0o750,
        0o640,
    ]

    # The expected file modes for the test paths.
    test_file_modes = [
        0o750,
        0o750,
        0o640,
    ]

    # The expected directory modes

# Generated at 2022-06-23 18:20:32.583045
# Unit test for function normalize_path
def test_normalize_path():
    """Test the normalize_path function."""
    assert normalize_path(Path(f'{os.path.expanduser("~/tmp")}/../bar')).as_posix() == '/home/test_user/tmp/../bar'
    assert normalize_path('~/../bar') == Path('~/../bar')

    assert normalize_path('~/tmp/foo/../bar').as_posix() == '/home/test_user/tmp/bar'
    assert normalize_path('~/tmp/foo/./bar').as_posix() == '/home/test_user/tmp/foo/bar'
    assert normalize_path('~/tmp/foo/../bar').as_posix() == '/home/test_user/tmp/bar'


# Generated at 2022-06-23 18:20:44.752956
# Unit test for function normalize_path
def test_normalize_path():
    """Test normalize_path function"""

    import os
    from pathlib import Path
    from flutils.pathutils import normalize_path

    fsenc = os.getfilesystemencoding()
    path = Path('~/tmp/foo/../bar')
    assert normalize_path(path) == Path(path.as_posix())
    assert normalize_path(path.as_posix()) == Path(path.as_posix())
    assert normalize_path(path.as_posix().encode(fsenc)) == Path(path.as_posix())
    assert normalize_path(path.as_posix().encode(fsenc).decode(fsenc)) == Path(path.as_posix())



# Generated at 2022-06-23 18:20:48.997232
# Unit test for function find_paths
def test_find_paths():
    """Test the find_paths function."""
    tmp_path = Path('~/tmp').expanduser()
    file_one = tmp_path / 'file_one'
    file_two = tmp_path / 'file_two'
    dir_one = tmp_path / 'dir_one'
    dir_two = tmp_path / 'dir_two'
    os.makedirs(dir_two, mode=0o700, exist_ok=True)
    with file_one.open('wt') as out:
        out.write('My first file.')
    with file_two.open('wt') as out:
        out.write('My second file.')
    dir_one.mkdir(mode=0o700, parents=True)
    dir_two.mkdir(mode=0o700, parents=True)

# Generated at 2022-06-23 18:20:59.419325
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        p0 = Path(tmpdir)
        p1 = normalize_path(p0)
        p2 = p0 / 'dir_one'
        p3 = p0 / 'file_one'
        p4 = p2 / 'file_two'
        p5 = p2 / 'file_three'
        p6 = p2 / 'dir_two'
        p7 = p6 / 'file_four'

        path_absent(p0)
        assert exists_as(p0) == ''

        p1.mkdir(mode=0o700)
        assert exists_as(p1) == 'directory'

        p2.mkdir(mode=0o700)
        p3.touch(mode=0o600)

# Generated at 2022-06-23 18:21:01.131203
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(__file__).as_posix() == \
        os.path.abspath(__file__).as_posix()


# Generated at 2022-06-23 18:21:10.932496
# Unit test for function get_os_user
def test_get_os_user():
    """Test the function get_os_group()."""
    # Get the current user.
    current_user = getpass.getuser()
    current_os_user = get_os_user(current_user)
    assert current_os_user.pw_name == current_user
    assert current_os_user.pw_passwd.startswith("*")
    assert current_os_user.pw_uid > 0
    assert current_os_user.pw_gid > 0
    assert current_os_user.pw_shell.endswith("bash")
    # Get the current user by uid.
    current_os_user = get_os_user(current_os_user.pw_uid)
    assert current_os_user.pw_name == current_user
    assert current_os

# Generated at 2022-06-23 18:21:15.878976
# Unit test for function normalize_path

# Generated at 2022-06-23 18:21:22.164885
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths in the pathutils module."""
    import subprocess as sp
    tmp_user = get_os_user().pw_name
    cmd = (
        'mkdir -p '
        '/tmp/flutils.tests.settings.test_find_paths/sub_dir_one '
        '/tmp/flutils.tests.settings.test_find_paths/sub_dir_one/sub_sub_dir'
        '; touch '
        '/tmp/flutils.tests.settings.test_find_paths/sub_dir_one/sub_sub_dir/sub_sub_sub_file_one'
    )
    sp.check_call(cmd, shell=True)

# Generated at 2022-06-23 18:21:29.273702
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(getpass.getuser()) == pwd.getpwuid(os.getuid())
    with pytest.raises(OSError):
        get_os_user(1234567890)
    with pytest.raises(OSError):
        get_os_user('example_user')


# Generated at 2022-06-23 18:21:42.047798
# Unit test for function chown
def test_chown():
    with TemporaryDirectory() as tmpdir:
        p = Path(tmpdir) / 'test.txt'
        p.touch()

        chown(p, user=None, group=None)
        stat = os.stat(p)
        assert stat.st_uid == os.getuid()
        assert stat.st_gid == os.getgid()

        chown(p, user='-1', group='-1')
        stat = os.stat(p)
        assert stat.st_uid == os.getuid()
        assert stat.st_gid == os.getgid()

        # Create a non-existent user and group to make sure it fails
        chown(p, user='this_is_not_a_user', group='this_is_not_a_group')
        stat = os.stat(p)

# Generated at 2022-06-23 18:21:48.199741
# Unit test for function find_paths
def test_find_paths():
    assert set(find_paths('/tmp/**')) == {
        Path('/tmp/bar'),
        Path('/tmp/foo'),
        Path('/tmp/spam'),
        Path('/tmp/eggs')
    }



# Generated at 2022-06-23 18:21:52.168366
# Unit test for function normalize_path
def test_normalize_path():
    """Test flutils.pathutils.normalize_path"""
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')

normalize_path.register(Path, lambda path: path)



# Generated at 2022-06-23 18:21:59.483347
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/flutils/test_path')
    assert path == Path('/Users/len/tmp/flutils/test_path')

    path = directory_present('~/tmp/flutils/test_path2')
    assert path == Path('/Users/len/tmp/flutils/test_path2')

    path = Path('~/tmp/flutils/test_path')
    path_exists_as = exists_as(path)
    assert path_exists_as == 'directory'

    path = Path('~/tmp/flutils/test_path2')
    path_exists_as = exists_as(path)
    assert path_exists_as == 'directory'


# Generated at 2022-06-23 18:22:12.098332
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('.') == Path.cwd()
    assert normalize_path(b'.') == Path.cwd()
    assert normalize_path('./') == Path.cwd()
    assert normalize_path(b'./') == Path.cwd()
    assert normalize_path('.///') == Path.cwd()
    assert normalize_path(b'.///') == Path.cwd()
    assert normalize_path('.///.///.//') == Path.cwd()
    assert normalize_path(b'.///.///.//') == Path.cwd()
    assert normalize_path('./tmp') == Path.cwd().joinpath('tmp')
    assert normalize_path(b'./tmp') == Path.cwd().joinpath('tmp')
    assert normalize_

# Generated at 2022-06-23 18:22:21.481417
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.systemutils import get_current_user_id
    from flutils.systemutils import is_current_user_a_root_account
    from flutils.systemutils import is_posix

    group = get_os_group()
    if is_posix() is True:
        assert group.gr_gid == os.getgid()
    assert group.gr_name == os.getgroups()[0]

    if is_posix() is True:
        if is_current_user_a_root_account() is False:
            gid = os.getgroups()[-1]
            assert get_os_group(gid).gr_name == os.getgroups()[-1]

    for name in ('2', 'nogroup', 'nobody', 'root'):
        assert get_os_group

# Generated at 2022-06-23 18:22:31.131223
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as dir_path:
        dir_path = Path(dir_path).expanduser()
        Path(f'{dir_path}/file.txt').touch()
        sub_dir = Path(f'{dir_path}/sub_dir')
        sub_dir.mkdir()
        Path(f'{sub_dir}/file_txt').touch()
        results = list(find_paths(f'{dir_path}/**'))
        assert sorted([
            f'{dir_path}/file.txt',
            f'{dir_path}/sub_dir/file_txt',
            f'{dir_path}/sub_dir'
        ]) == sorted([result.as_posix() for result in results])



# Generated at 2022-06-23 18:22:42.521129
# Unit test for function get_os_user
def test_get_os_user():
    assert (
        'testuser2:testpass2:1001:2001:Test User 2:/Users/testuser2:/bin/false'
        .split(':') == list(get_os_user('testuser2'))
    )
    assert (
        'testuser3:testpass3:1002:2001:Test User 3:/Users/testuser3:/bin/false'
        .split(':') == list(get_os_user('testuser3'))
    )
    assert (
        'testuser2:testpass2:1001:2001:Test User 2:/Users/testuser2:/bin/false'
        .split(':') == list(get_os_user('testuser2'))
    )

# Generated at 2022-06-23 18:22:43.884003
# Unit test for function get_os_group
def test_get_os_group():
    assert type(get_os_group()) == grp.struct_group

# Generated at 2022-06-23 18:22:48.963376
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path"""

    path = normalize_path('~/tmp/foo/../bar')
    assert path.as_posix() == '/home/test_user/tmp/bar'


normalize_path.register(Path, cast)



# Generated at 2022-06-23 18:23:00.339761
# Unit test for function directory_present
def test_directory_present():
    # Test that a new directory is created.
    from tempfile import TemporaryFile
    from time import process_time

    temp_file = TemporaryFile()

    # The directory created will be unique and hopefully
    # not exist as a directory on the system.
    test_path = Path('.').joinpath(
        'tmp.%s.test_directory_present' % process_time()
    )
    assert not test_path.exists(), 'The test path already exist.'

    try:
        ret = directory_present(test_path)
        assert isinstance(ret, (PosixPath, WindowsPath))
        assert ret.as_posix() == test_path.as_posix()
        assert test_path.exists()
        assert test_path.is_dir()
    finally:
        ret.rmdir()
    #

# Generated at 2022-06-23 18:23:07.687058
# Unit test for function chown
def test_chown():
    path='/tmp/foo'
    if os.path.lexists(path) is False:
        os.makedirs(path)
    user=os.getlogin()
    chown(path)
    result=os.stat(path)
    assert result.st_uid==os.getuid()
    assert result.st_gid==os.getgid()

# Generated at 2022-06-23 18:23:09.616302
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-23 18:23:22.162149
# Unit test for function chown
def test_chown():
    # Basic use case
    os.mkdir('/tmp/foo')
    assert chown('/tmp/foo', group='foo') is None
    assert os.stat('/tmp/foo').st_gid == grp.getgrnam('foo').gr_gid
    assert chown('/tmp/foo', group='-1') is None
    assert os.stat('/tmp/foo').st_gid != grp.getgrnam('foo').gr_gid
    assert os.stat('/tmp/foo').st_gid == os.getgid()
    assert chown('/tmp/foo', user=getpass.getuser()) is None
    assert os.stat('/tmp/foo').st_uid == pwd.getpwnam(getpass.getuser()).pw_uid

# Generated at 2022-06-23 18:23:32.306729
# Unit test for function directory_present
def test_directory_present():

    path = normalize_path('~/tmp/pathutils_tests')

# Generated at 2022-06-23 18:23:35.481848
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None



# Generated at 2022-06-23 18:23:39.455547
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group('bar')
    assert group.gr_name == 'bar'
    assert group.gr_gid == 2001

    group = get_os_group(2001)
    assert group.gr_name == 'bar'
    assert group.gr_gid == 2001



# Generated at 2022-06-23 18:23:46.095773
# Unit test for function path_absent
def test_path_absent():
    base_path = Path(__file__).parent
    assert base_path.is_dir()
    path: Path = base_path / 'data' / 'path_absent'
    if path.is_dir():
        path_absent(path)
    assert path.is_dir() is False
    assert path.parent.is_dir()
    path_absent(path)
    assert path.is_dir() is False
    path.mkdir(mode=0o700)
    assert path.is_dir()
    path_absent(path)
    assert path.is_dir() is False
    path.mkdir(parents=True, mode=0o700)
    assert path.is_dir()
    file_path = path / 'test_file'
    assert file_path.exists() is False
    file

# Generated at 2022-06-23 18:23:51.377396
# Unit test for function directory_present
def test_directory_present():
    test_path = Path('~/tmp/flutils.tests.test_directory_present')
    if test_path.is_dir():
        shutil.rmtree(test_path)
    directory_present(test_path)
    assert test_path.is_dir()
    assert test_path.exists()



# Generated at 2022-06-23 18:24:01.406691
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError):
        get_os_group(12345)
    try:
        gr = get_os_group()
        assert isinstance(gr, grp.struct_group)
        assert gr.gr_name == 'ftp'
    except NotImplementedError:
        # The unit test user doesn't have a valid
        # default group.  So will have to skip
        # the test.
        pass
    gr = get_os_group('root')
    assert isinstance(gr, grp.struct_group)
    assert gr.gr_name == 'root'
    gr = get_os_group(0)
    assert isinstance(gr, grp.struct_group)
    assert gr.gr_gid == 0


# Generated at 2022-06-23 18:24:02.974934
# Unit test for function directory_present
def test_directory_present():
    return directory_present('/tmp/flutils')




# Generated at 2022-06-23 18:24:06.197315
# Unit test for function chown
def test_chown():
    from tempfile import NamedTemporaryFile
    from flutils.osutils import chown
    _file = NamedTemporaryFile(delete=False)
    assert chown(_file.name) is None



# Generated at 2022-06-23 18:24:11.679070
# Unit test for function exists_as
def test_exists_as():
    from flutils.process import chdir
    from flutils.pathutils import relative_to
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from os import LinkError, utime

    # Test directory
    with TemporaryDirectory() as tmp_d:
        tmp_d = Path(tmp_d)
        chdir(str(tmp_d))
        assert exists_as('') == ''
        assert exists_as('.') == 'directory'
        assert exists_as('./directory') == ''
        assert exists_as('./foo') == ''
        tmp_d.joinpath('directory').mkdir()
        assert exists_as('./directory') == 'directory'
        assert exists_as('./foo') == ''
        tmp_d.joinpath('directory/file').touch()

# Generated at 2022-06-23 18:24:20.789139
# Unit test for function directory_present
def test_directory_present():
    from pathlib import Path
    from tempfile import mkdtemp
    from os import chmod, getuid, stat, unlink
    from stat import S_ISDIR

    # Test chown
    tmp_dir = mkdtemp()
    tmp_path = '%s/flutils.tests.osutils.txt' % tmp_dir
    test_path = directory_present(tmp_path)
    file_stat = stat(tmp_path)
    if getuid() != file_stat.st_uid:
        raise AssertionError(
            'The path: %r did NOT have the expected uid: %r. Instead it had '
            'the uid: %r'
            % (test_path.as_posix(), getuid(), file_stat.st_uid)
        )

# Generated at 2022-06-23 18:24:22.106509
# Unit test for function chown
def test_chown():
    assert False



# Generated at 2022-06-23 18:24:33.553728
# Unit test for function chmod
def test_chmod():
    """Test function :func:`~flutils.pathutils.chmod`"""

    tmp = Path('tests/tmp')
    tmp.mkdir(mode=0o755, parents=True, exist_ok=True)

    fp = tmp / 'test.txt'
    with fp.open('w') as fh:
        fh.write('abc')

    assert fp.exists() is True
    assert oct(fp.stat().st_mode)[-3:] == '600'

    fp2 = tmp / 'test2.txt'
    fp2.write_text('def')
    assert fp2.exists() is True
    assert oct(fp2.stat().st_mode)[-3:] == '600'

    chmod(tmp / '*.txt', mode_file=0o660)

# Generated at 2022-06-23 18:24:44.689905
# Unit test for function path_absent
def test_path_absent():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        os.mkdir('test_dir')
        with open('test_file', 'w') as f:
            f.write('test')
        os.symlink('test_file', 'test_sym')
        os.mkfifo('test_fifo')
        path_absent('test_dir')
        path_absent('test_file')
        assert os.listdir() == ['test_sym', 'test_fifo']
        path_absent('test_sym')
        assert os.listdir() == ['test_fifo']
        path_absent('test_fifo')
        assert os.listdir() == []



# Generated at 2022-06-23 18:24:53.100967
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from typing import Callable
    from unittest import TestCase

    from flutils.pathutils import directory_present

    def _is_directory(path: str) -> bool:
        from pathlib import Path

        path = Path(path).resolve()
        return path.exists() and path.is_dir()

    def _is_readable(path: str) -> bool:
        from pathlib import Path

        path = Path(path).resolve()
        return path.exists() and os.access(path, os.R_OK)

    def _is_writable(path: str) -> bool:
        from pathlib import Path

        path = Path(path).resolve()
        return path.exists() and os.access(path, os.W_OK)


# Generated at 2022-06-23 18:25:02.189674
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        file_one = tmp_path / 'file_one'
        file_one.touch(mode=0o644)
        dir_one = tmp_path / 'dir_one'
        dir_one.mkdir(mode=0o755)
        dir_one_file_one = dir_one / 'file_one'
        dir_one_file_one.touch(mode=0o644)
        dir_one_file_two = dir_one / 'file_two'
        dir_one_file_two.touch(mode=0o644)
        dir_one_dir_one = dir_one / 'dir_one'
        dir_one_dir_one.mkdir(mode=0o755)


# Generated at 2022-06-23 18:25:06.015251
# Unit test for function directory_present
def test_directory_present():
    path = pathlib.Path('/tmp/test_directory_present')
    if not path.exists():
        path.mkdir()
    assert directory_present(path) == '/tmp/test_directory_present'



# Generated at 2022-06-23 18:25:07.383952
# Unit test for function directory_present
def test_directory_present():
    import doctest

    assert doctest.testmod()[0] == 0



# Generated at 2022-06-23 18:25:19.025019
# Unit test for function path_absent

# Generated at 2022-06-23 18:25:26.369112
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    from tempfile import mkdtemp

    test_path = mkdtemp()
    path = Path(test_path) / 'foo' / 'bar'
    path.mkdir(parents=True)
    try:
        assert path.exists()
        path_absent(path)
        assert path.exists() is False
    finally:
        path_absent(test_path)
# Testing: path_absent



# Generated at 2022-06-23 18:25:38.197902
# Unit test for function path_absent
def test_path_absent():
    from shutil import rmtree

    from flutils.testing import data_dir

    with data_dir('path_absent') as tmp_dir:
        # Test removal of a dir with files and subdirs.
        dir_path = os.path.join(tmp_dir, 'dir')
        os.mkdir(dir_path)
        file_path = os.path.join(dir_path, 'file')
        with open(file_path, 'w') as f:
            f.write('test file')
        subdir_path = os.path.join(dir_path, 'subdir')
        os.mkdir(subdir_path)
        path_absent(dir_path)
        assert not os.path.exists(dir_path)

        # Test removal of a file.
        file_path = os

# Generated at 2022-06-23 18:25:45.533485
# Unit test for function find_paths
def test_find_paths():

    def test_glob_patterns():
        """
        Test cases for glob patterns

        Note:
            This test case is expecting the file and directories
            to be created by the test suite for the unit test to work
            properly.
        """
        the_dir = Path('~/tmp/find-paths-tests').expanduser()
        the_dir.mkdir(mode=0o700, parents=True)


# Generated at 2022-06-23 18:25:55.910706
# Unit test for function get_os_user
def test_get_os_user():
    """Test get_os_user(name)."""
    name = get_os_user()
    expected = pwd.getpwuid(os.getuid())
    assert name.pw_name == expected.pw_name
    assert name.pw_passwd == expected.pw_passwd
    assert name.pw_uid == expected.pw_uid
    assert name.pw_gid == expected.pw_gid
    assert name.pw_gecos == expected.pw_gecos
    assert name.pw_dir == expected.pw_dir
    assert name.pw_shell == expected.pw_shell



# Generated at 2022-06-23 18:26:06.637003
# Unit test for function normalize_path
def test_normalize_path():
    """Unit testing for function normalize_path."""
    def _test(
            path_in: _PATH,
            expected: str
    ) -> None:
        """Test the normalize_path function."""
        actual = normalize_path(path_in)
        assert expected == actual.as_posix()

    class _BytesRaw:
        def __init__(self, value: bytes):
            self.value = value

        def __bytes__(self) -> bytes:
            return self.value

    _test('', '')
    _test('.', '/')
    _test('..', '/')
    _test(Path(), '/')
    _test('/', '/')
    _test('/tmp', '/tmp')
    _test('~/tmp', '/home/test_user/tmp')

# Generated at 2022-06-23 18:26:08.908375
# Unit test for function chown
def test_chown():
    assert True



# Generated at 2022-06-23 18:26:15.723746
# Unit test for function normalize_path
def test_normalize_path():
    cwd = os.getcwd()
    os.chdir('/tmp')


# Generated at 2022-06-23 18:26:23.846590
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group('bar')
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_gid == 2001
    assert group.gr_mem == ['foo']
    group = get_os_group(2001)
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_gid == 2001
    assert group.gr_mem == ['foo']
test_get_os_group()



# Generated at 2022-06-23 18:26:24.487875
# Unit test for function chmod
def test_chmod():
    pass


# Generated at 2022-06-23 18:26:25.167737
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:26:32.695955
# Unit test for function path_absent
def test_path_absent():
    path = normalize_path('/tmp/utest_flutils/path_absent')
    path_absent(path)
    assert not path.exists()

    path.mkdir(parents=True)
    assert path.is_dir()
    path_absent(path)
    assert not path.exists()

    path.mkdir(parents=True)
    filep = path / 'file_one'
    filep.write_text('Hello World!')
    assert filep.is_file()
    path_absent(path)
    assert not path.exists()

