

# Generated at 2022-06-23 18:16:43.576415
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import (
        normalize_path,
        get_os_group,
    )
    # Test "group name" exists.
    group = get_os_group(name='bar')
    assert group.gr_name == 'bar'
    assert group.gr_passwd == '*'
    assert group.gr_gid == 2001
    assert group.gr_mem == ['foo']
    # Test "group name" does NOT exist.
    with pytest.raises(OSError) as err:
        get_os_group(name='baz')
    assert str(err.value) == (
        'The given name: \'baz\', is not a valid "group name" for this '
        'operating system.'
    )
    # Test gid exists.
    group = get_os_

# Generated at 2022-06-23 18:16:53.821129
# Unit test for function exists_as
def test_exists_as():
    _PATH = Path.home() / 'tmp'
    _TEST_FILE = _PATH / 'exists_as_test'
    _TEST_LINK = _PATH / 'exists_as_link'
    assert exists_as(_PATH) == 'directory'
    assert exists_as(_PATH / 'not_a_path') == ''
    try:
        with _TEST_FILE.open(mode='w'):
            assert exists_as(_TEST_FILE) == 'file'
        Path(_TEST_LINK).symlink_to(_TEST_FILE)
        assert exists_as(_TEST_LINK) == 'file'
        Path(_TEST_LINK).unlink()
        assert exists_as(_TEST_LINK) == ''
    finally:
        _TEST_FILE.unlink()

# Generated at 2022-06-23 18:17:05.575415
# Unit test for function get_os_user
def test_get_os_user():
    """Test the get_os_user function."""
    with pytest.raises(OSError):
        get_os_user('not_a_real_user')
    with pytest.raises(OSError):
        get_os_user(1234)
    # On the Travis Ubuntu 18.04 LTS environment, the
    # 'root' user is NOT locked.
    if sys.platform.startswith('linux'):
        os_user = get_os_user('root')
        if os_user.pw_uid == 0:
            assert os_user.pw_gecos == 'root'
    os_user = get_os_user()
    assert isinstance(os_user, pwd.struct_passwd)



# Generated at 2022-06-23 18:17:16.864601
# Unit test for function find_paths
def test_find_paths():
    # Setup test
    path = Path()
    path = path.joinpath('tmp', 'test_find_paths')
    path.mkdir(parents=True, exist_ok=True)

    path.joinpath('find_paths.txt').touch()
    path.joinpath('find_paths.yml').touch()

    path.joinpath('find_paths').mkdir()

    # Test

# Generated at 2022-06-23 18:17:25.279062
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import (
        chmod,
        find_paths,
        path_absent,
    )

    def teardown_function(function):
        path_absent('~/.flutils.tests.chmod.txt')
        path_absent('~/.flutils.tests.chmod.dir')

    def test_normalize_path(function):
        chmod('~/.flutils.tests.chmod.txt', 0o660)
        assert Path('~/.flutils.tests.chmod.txt').stat().st_mode & 0o700 == 0o660

    def test_chmod_glob(function):
        chmod('~/.flutils.tests.chmod*')

# Generated at 2022-06-23 18:17:27.794309
# Unit test for function get_os_group
def test_get_os_group():
    assert_equal(
        get_os_group('bar'),
        grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2001,
                         gr_mem=['foo'])
    )
    with pytest.raises(OSError):
        get_os_group('baz')



# Generated at 2022-06-23 18:17:28.955501
# Unit test for function get_os_user
def test_get_os_user():
    """Test function ``get_os_user``"""
    print(get_os_user())


# Generated at 2022-06-23 18:17:38.432445
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/dev') == ''
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/stdin') == 'FIFO'
    assert exists_as('/var/run/systemd/journal/stdout') == 'socket'
    assert exists_as('/does/not/exist/tmp') == ''


# Generated at 2022-06-23 18:17:47.146067
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path('~/tmp/foo\\..\\bar') == Path('/home/test_user/tmp/bar')
    assert normalize_path(
        '${HOME}/tmp/foo\\..\\bar'
    ) == Path('/home/test_user/tmp/bar')
    assert normalize_path('/tmp/foo/../bar') == Path('/tmp/bar')
    assert normalize_path('/tmp/foo\\..\\bar') == Path('/tmp/bar')
    assert normalize_path('tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
    assert normalize_

# Generated at 2022-06-23 18:18:00.191190
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from pathlib import PosixPath
    from shutil import copy2

    mode = 0o777
    with TemporaryDirectory() as tmp_dir:
        tmp_dir = PosixPath(tmp_dir)
        with open(tmp_dir / 'spam.txt', 'w') as tmp_file:
            tmp_file.write('spam')

        test_dir = tmp_dir / 'test_dir'
        test_dir.mkdir()
        test_dir = tmp_dir / 'test_dir'
        test_dir_2 = tmp_dir / 'test_dir/test_dir_2'
        test_dir_3 = tmp_dir / 'test_dir/test_dir_2/test_dir_3'

# Generated at 2022-06-23 18:18:11.681095
# Unit test for function path_absent
def test_path_absent():
    """Test the ``path_absent`` function."""
    results = []

    # Create the directory to be used for testing.
    test_dir = normalize_path('~/tmp/flutils_test/path_absent')
    path_present(test_dir)

    test_path = normalize_path(test_dir / 'foo')
    path_present(test_path)
    results.append(os.path.exists(test_path.as_posix()))

    os.chmod(test_path.as_posix(), stat.S_ISVTX | stat.S_ISUID)
    path_absent(test_path)
    results.append(os.path.exists(test_path.as_posix()))

    test_path = normalize_path(test_dir / 'bar')

# Generated at 2022-06-23 18:18:18.173824
# Unit test for function path_absent
def test_path_absent():
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        dname = os.path.join(tmpdirname, 'foo')
        os.mkdir(dname)
        fname = os.path.join(dname, 'bar')
        open(fname, 'w', encoding='utf-8').write('baz')
        pname = os.path.join(tmpdirname, 'foo2')
        os.symlink(dname, pname)
        # Make sure the "path absent" is idempotent
        path_absent(tmpdirname)
        path_absent(tmpdirname)
        path_absent(fname)
        path_absent(fname)
        path_absent(dname)

# Generated at 2022-06-23 18:18:29.692365
# Unit test for function directory_present
def test_directory_present():
    from shutil import rmtree

    from os import mkdir, stat, unlink
    from os.path import exists, isdir, join
    from tempfile import mkdtemp

    from flutils.pathutils import directory_present

    from tests.test_utils import random_file_name, random_string

    from .mock_getpass import MockGetpass

    with MockGetpass() as mg:
        tmp_dir = mkdtemp()

        # Test simple scenario of creating a new directory.
        path = directory_present(join(tmp_dir, random_string()))
        assert exists(path.as_posix()) is True
        assert isdir(path.as_posix()) is True
        assert stat(path.as_posix()).st_mode == 0o700
        assert stat(path.as_posix()).st

# Generated at 2022-06-23 18:18:31.250442
# Unit test for function path_absent
def test_path_absent():  # noqa: D103
    path_absent(__file__ + '.bak')

# Generated at 2022-06-23 18:18:43.268782
# Unit test for function normalize_path
def test_normalize_path():
    # Test normalize_path(path: str) -> Path
    assert normalize_path('~/tmp/foo/../bar') == Path(
        '/home/test_user/tmp/bar'
    )
    assert normalize_path('~/tmp/foo/../bar') != \
        os.path.expanduser('~/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') != \
        os.path.expandvars('~/tmp/foo/../bar')
    assert normalize_path('~/tmp/foo/../bar') != \
        os.path.normpath(os.path.expanduser('~/tmp/foo/../bar'))
    assert normalize_path('~/tmp/foo/../bar') != \
        os.path.norm

# Generated at 2022-06-23 18:18:47.772015
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    assert list(find_paths('~/tmp/*')) == [
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one'),
    ]



# Generated at 2022-06-23 18:18:53.224589
# Unit test for function normalize_path
def test_normalize_path():
    """Test :obj:`~flutils.pathutils.normalize_path`."""
    curr_path = os.path.join(os.getcwd(), 'flutils')
    exp_path = os.path.normpath(curr_path)
    exp_path = os.path.normcase(exp_path)
    test_path = normalize_path('./flutils')
    assert test_path == Path(exp_path)



# Generated at 2022-06-23 18:18:58.904305
# Unit test for function get_os_group
def test_get_os_group():
    """Test function get_os_group."""
    # The following test is only valid for the user 'len' which
    # has the following entry in it's /etc/passwd file:
    # len:x:501:501::/Users/len:/bin/bash

# Generated at 2022-06-23 18:19:04.335976
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""

    # Setup
    test_path = Path(__file__).parent / 'test_exists_as.txt'
    test_path.touch()

    # Test
    actual = exists_as(test_path)

    # Teardown
    test_path.unlink()

    # Assert test
    assert actual == 'file'



# Generated at 2022-06-23 18:19:13.321098
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path"""

    if sys.platform.startswith(('linux', 'darwin')):
        is_posix: bool = True
    else:
        is_posix: bool = False

    def test_path(path: _PATH, valid_path: _PATH):
        """Helper function for the unit test"""
        path = normalize_path(path)
        assert path.as_posix() == valid_path
        if is_posix:
            assert isinstance(path, PosixPath)
        else:
            assert isinstance(path, WindowsPath)
        path = normalize_path(path)
        assert path.as_posix() == valid_path
        path = str(path)
        path = normalize_path(path)
        assert path.as_posix() == valid

# Generated at 2022-06-23 18:19:18.780576
# Unit test for function find_paths
def test_find_paths():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        file_one = temp_dir / 'file_one'
        file_two = temp_dir / 'file_two'
        file_one.touch()
        file_two.touch()
        dir_one = temp_dir / 'dir_one'
        dir_one.mkdir()
        dir_two = temp_dir / 'dir_one/dir_two'
        dir_two.mkdir()
        file_three = dir_two / 'file_three'
        file_three.touch()

        test_paths = find_paths(temp_dir / '*')
        assert set(test_paths) == {
            file_one, file_two, dir_one
        }



# Generated at 2022-06-23 18:19:24.484469
# Unit test for function directory_present
def test_directory_present():
    assert isinstance(directory_present('/tmp'), PosixPath)
    assert isinstance(directory_present(Path('/tmp')), PosixPath)
    assert isinstance(directory_present('c:\\tmp'), WindowsPath)
    assert isinstance(directory_present(Path('c:\\tmp')), WindowsPath)



# Generated at 2022-06-23 18:19:32.439554
# Unit test for function chown
def test_chown():
    get_os_group = functools.partial(
        get_os_group,
        raise_on_error=True
    )

    get_os_user = functools.partial(
        get_os_user,
        raise_on_error=True
    )

    current_gid = os.getgid()
    current_uid = os.getuid()
    current_user = get_os_user(current_uid).pw_name
    current_group = get_os_group(current_gid).gr_name
    path = Path('/tmp/foo')

    path.touch()
    chown(path, current_user, current_group)
    assert path.stat().st_uid == current_uid
    assert path.stat().st_gid == current_gid


# Generated at 2022-06-23 18:19:44.297758
# Unit test for function directory_present
def test_directory_present():
    from flutils.tests.pathutils import TemporaryTestCase

    class TestDirectoryPresent(TemporaryTestCase):

        def test_file_already_exists(self):
            tmp_file = self.tmp_path / 'file.txt'

            with open(tmp_file, 'w') as f:
                f.write('Some text.')

            with self.assertRaises(FileExistsError):
                directory_present(tmp_file)

        def test_symlink_already_exists(self):
            tmp_symlink = self.tmp_path / 'symlink'
            tmp_symlink_target = self.tmp_path / 'symlink_target'

            with open(tmp_symlink_target, 'w') as f:
                f.write('Some text.')

            tmp_sy

# Generated at 2022-06-23 18:19:51.170494
# Unit test for function path_absent
def test_path_absent():
    t_path = '~/tmp/test_path_absent'
    path_present(t_path)
    assert exists_as(t_path) == 'directory'
    path_absent(t_path)
    assert not os.path.exists(t_path)
    path_present(t_path)
    path_present(t_path + '/foo')
    path_present(t_path + '/foo/bar')
    path_present(t_path + '/foo/bar/baz')
    path_absent(t_path)
    assert not os.path.exists(t_path)



# Generated at 2022-06-23 18:19:53.241496
# Unit test for function get_os_user
def test_get_os_user():
    uid = get_os_user().pw_uid
    assert get_os_user(uid).pw_uid == uid



# Generated at 2022-06-23 18:20:01.195797
# Unit test for function directory_present
def test_directory_present():
    from .testingutils import (
        create_tempdir,
        remove_tempdir,
    )

    tmpdir = create_tempdir()


# Generated at 2022-06-23 18:20:05.022624
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user(get_os_user().pw_uid), pwd.struct_passwd)
    assert get_os_user().pw_name == getpass.getuser()



# Generated at 2022-06-23 18:20:08.553217
# Unit test for function path_absent
def test_path_absent():
    p = Path(__file__).parent
    p = p / 'test' / 'test_path'
    if p.exists():
        path_absent(p)
    assert not p.exists(), 'the path was not absent: %r' % p



# Generated at 2022-06-23 18:20:15.494959
# Unit test for function directory_present
def test_directory_present():
    # Test a new directory
    path = directory_present(
        '~/tmp/flutils.tests.pathutils.directory_present.txt'
    )
    assert path.is_dir() is True
    assert path.name == 'directory_present.txt'
    assert path.parent.name == 'pathutils'

    # Test an existing directory
    directory_present(
        '~/tmp/flutils.tests.pathutils.directory_present.txt'
    )
    assert path.is_dir() is True
    assert path.name == 'directory_present.txt'
    assert path.parent.name == 'pathutils'
    path.parent.rmdir()



# Generated at 2022-06-23 18:20:19.844717
# Unit test for function path_absent
def test_path_absent():
    TEST_DIR = Path(os.getcwd())
    TEST_DIR.mkdir(exist_ok=True)
    tmp_dir = TEST_DIR / 'tmp'
    tmp_dir.mkdir(exist_ok=True)
    DIRS = [
        'one',
        'two',
        'three',
        'four',
        'five',
        'six',
        'seven',
        'eight',
        'nine',
        'ten'
    ]
    for dir in DIRS:
        dir = tmp_dir / dir
        dir.mkdir(exist_ok=True)

# Generated at 2022-06-23 18:20:27.409712
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(
        Path().joinpath('tests', 'data', 'pathutils', 'exists_as')
    ) == 'directory'
    assert exists_as(
        Path().joinpath('tests', 'data', 'pathutils', 'exists_as.txt')
    ) == 'file'
    assert exists_as(
        Path().joinpath('tests', 'data', 'pathutils', 'does_NOT_exist')
    ) == ''



# Generated at 2022-06-23 18:20:28.993810
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/.ssh/config.d/id_rsa.pub')
    if path.exists():
        path.chmod(0o600)

# Generated at 2022-06-23 18:20:36.122934
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    test_dir = Path().cwd() / 'tests' / 'pathutils'
    assert len(list(find_paths(test_dir))) == 3
    assert set(find_paths(test_dir)) == {
        (test_dir / 'test_file.txt').resolve(),
        (test_dir / 'test_file_2.txt').resolve(),
        (test_dir / 'test_folder').resolve()
    }



# Generated at 2022-06-23 18:20:44.667005
# Unit test for function chown
def test_chown():
    from tempfile import TemporaryDirectory
    from shutil import copy

    with TemporaryDirectory() as tmpdir:
        path = Path(tmpdir, 'mydir', 'mydir')
        path.mkdir(parents=True)

        txt_src = Path('test_data/test_pathutils/chown.txt')
        txt_dst = Path(tmpdir, 'mydir', 'chown.txt')
        chown(txt_dst, 'root', 'root')

        copy(txt_src, txt_dst)

        os_txt = Path(tmpdir, 'mydir', 'os.txt')
        os_txt.touch()



# Generated at 2022-06-23 18:20:46.613775
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_name == 'root'



# Generated at 2022-06-23 18:20:53.037281
# Unit test for function normalize_path
def test_normalize_path():
    cwd = os.getcwd()
    try:
        os.chdir('/home')
        assert normalize_path('~/tmp/foo') == normalize_path('/home/tmp/foo')
        os.chdir('/tmp')
        assert normalize_path('~/tmp') == normalize_path('/home/tmp')
    finally:
        os.chdir(cwd)



# Generated at 2022-06-23 18:20:56.049937
# Unit test for function get_os_group
def test_get_os_group():
    """Test to verify function get_os_group returns the correct OS group."""
    os_group = get_os_group()
    assert isinstance(os_group, grp.struct_group)



# Generated at 2022-06-23 18:21:08.850502
# Unit test for function chmod
def test_chmod():
    from os import stat, utime
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp

    tmp_dir = mkdtemp()

    # Create a file and test that it is created as 600
    # and has the correct mode.
    path1 = Path(tmp_dir) / 'pathutils.txt'
    path1.touch()
    path1_stat = stat(str(path1))
    assert path1_stat.st_mode == 33188, 'Created file is NOT 0600!'
    assert path1_stat.st_uid == getpass.getuser(), 'Created file is not owned by {}!'.format(getpass.getuser())

# Generated at 2022-06-23 18:21:09.344628
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-23 18:21:16.945861
# Unit test for function chown
def test_chown():
    path = normalize_path('tmp/flutils.tests.osutils.txt')
    with path.open('w'):
        pass
    chown(path)
    assert path.is_file()
    assert get_os_user().pw_uid == path.stat().st_uid
    assert get_os_group().gr_gid == path.stat().st_gid
    chown(path, group=-1)
    assert path.is_file()
    assert get_os_user().pw_uid == path.stat().st_uid
    assert get_os_group().gr_gid == path.stat().st_gid
    chown(path, include_parent=True)
    assert path.is_file()
    assert get_os_user().pw_uid == path.stat().st_uid


# Generated at 2022-06-23 18:21:20.212929
# Unit test for function get_os_user
def test_get_os_user():
    assert (
            get_os_user('root').pw_gid == 0
    )
    assert (
            get_os_user('root').pw_uid == 0
    )



# Generated at 2022-06-23 18:21:23.613925
# Unit test for function path_absent
def test_path_absent():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_path:
        tmp_path = Path(tmp_path)
        tmp_path.joinpath('test_file').touch()
        path_absent(str(tmp_path))
        assert tmp_path.exists() is False



# Generated at 2022-06-23 18:21:24.232024
# Unit test for function exists_as
def test_exists_as():
    pass



# Generated at 2022-06-23 18:21:37.486579
# Unit test for function path_absent
def test_path_absent():
    import pytest
    import tempfile
    import uuid
    __tracebackhide__ = True
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Path Present
        path = os.path.join(tmpdirname, 'test_path')
        os.mkdir(path)
        assert os.path.exists(path) is True

        # Path Absent
        errmsg = (
            'The path: %r can NOT be removed because it does NOT '
            'exist.' % path
        )
        with pytest.raises(FileNotFoundError, match=re.escape(errmsg)):
            path_absent(path)

        # Path Absent
        try:
            path_absent(path)
        except FileNotFoundError:
            assert False is True

        # Path Absent

# Generated at 2022-06-23 18:21:38.143241
# Unit test for function find_paths
def test_find_paths():
    return

# Generated at 2022-06-23 18:21:48.346294
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir)
        p_file = p / 'file_one'
        p_dir = p / 'dir_one'
        p_file.touch()
        p_dir.mkdir()
        (p_dir / 'file_one').touch()
        assert {path.name for path in find_paths(p / '*')} == {
            p_file.name, p_dir.name}
        assert {path.name for path in find_paths(p_dir / '*')} == {
            p_file.name}
        assert {path.name for path in find_paths(p_file)} == {
            p_file.name}

# Generated at 2022-06-23 18:21:56.812705
# Unit test for function directory_present
def test_directory_present():
    # Define parameters to be tested
    path = os.path.expanduser('~/flutils/tmp/directory_present')
    path_parent = os.path.expanduser('~/flutils/tmp')
    path_grandparent = os.path.expanduser('~/flutils')
    # Setup the path using function directory_present
    directory_present(path)
    # Assert path and parent exists as directories
    assert os.path.exists(path_parent) and \
        os.path.exists(path) and \
        os.path.exists(path_grandparent)
    # Assert path exists as a directory
    assert os.path.isdir(path)



# Generated at 2022-06-23 18:22:00.646662
# Unit test for function find_paths
def test_find_paths():
    paths = list(find_paths('~/tmp/**'))
    for path in paths:
        assert isinstance(path, Path)
    assert paths



# Generated at 2022-06-23 18:22:12.909178
# Unit test for function exists_as
def test_exists_as():
    # Does not exist.
    test_path = Path(__file__).parent / 'test_path.txt'
    assert exists_as(test_path) == ''
    # A file.
    test_path.touch()
    assert exists_as(test_path) == 'file'
    # A directory.
    test_path.unlink()
    test_path.mkdir()
    assert exists_as(test_path) == 'directory'
    # A block device.
    block_device = '/dev/null'
    assert exists_as(block_device) == 'block device'
    # A FIFO.
    fifo = '/dev/log'
    assert exists_as(fifo) == 'FIFO'
    # A socket.
    socket = '/var/run/syslog'
    assert exists_

# Generated at 2022-06-23 18:22:24.655084
# Unit test for function chmod
def test_chmod():
    """Test the flutils.pathutils.chmod() function."""

    from flutils.pathutils import chmod

    from .osutils import make_temp_file, make_temp_dir

    TEMP_FILE = make_temp_file()
    TEMP_DIR = make_temp_dir()


# Generated at 2022-06-23 18:22:34.215615
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group()
    ok_(
        isinstance(group, grp.struct_group),
        msg='TEST: %r does NOT exist on this operating system' % group
    )
    group = get_os_group(0)
    ok_(
        isinstance(group, grp.struct_group),
        msg='TEST: %r does NOT exist on this operating system' % group
    )
    group = get_os_group('root')
    ok_(
        isinstance(group, grp.struct_group),
        msg='TEST: %r does NOT exist on this operating system' % group
    )
# End unit test for function get_os_group


# Generated at 2022-06-23 18:22:37.580037
# Unit test for function chown
def test_chown():
    """
    function to test chown function
    """
    chown("./README.rst", user="-1", group="-1")



# Generated at 2022-06-23 18:22:47.275449
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    from flutils.tests.osutils import create_tree

    with create_tree() as tmp_path:
        # This should return nothing
        assert list(find_paths(tmp_path / 'foo/bar/*')) == []

        # This should return four results
        result = list(find_paths(tmp_path / '*'))
        assert len(result) == 4
        assert {p.name for p in result} == {
            Path(tmp_path / 'a').name,
            Path(tmp_path / 'b').name,
            Path(tmp_path / 'c.txt').name,
            Path(tmp_path / 'd').name,
        }

        # This should return just one results

# Generated at 2022-06-23 18:22:54.541416
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user('len')
    assert isinstance(get_os_user('len'), pwd.struct_passwd)
    assert get_os_user() == get_os_user(getpass.getuser())
    assert len(get_os_user()) == 7
    with pytest.raises(OSError):
        get_os_user('!')



# Generated at 2022-06-23 18:22:57.335451
# Unit test for function find_paths
def test_find_paths():
    from tests.pathutils import find_paths as test_find_paths

    test_paths = (
        test_find_paths(os.path.abspath(__file__)) == [os.path.abspath(__file__)] and
        test_find_paths('~/tmp/*') == [
            Path('~/tmp/file_one'),
            Path('~/tmp/dir_one')
        ]
    )
    assert test_paths



# Generated at 2022-06-23 18:23:01.544509
# Unit test for function exists_as
def test_exists_as():
    import tempfile
    tmp_dir = tempfile.mkdtemp(prefix='tmp_flutils_test_')
    tmp_file = tempfile.mkstemp(prefix='tmp_file_', dir=tmp_dir)[1]
    tmp_fifo = tempfile.mkstemp(prefix='tmp_fifo_', dir=tmp_dir)[1]
    os.remove(tmp_file)  # mkstemp() creates a temp file.
    os.mkfifo(tmp_fifo)  # mkstemp() does NOT create a FIFO.


# Generated at 2022-06-23 18:23:09.067082
# Unit test for function chmod
def test_chmod():
    import os
    
    path = Path('~/.bashrc').expanduser().as_posix()
    
    chmod(path, mode_file=0o755)
    
    mode = os.stat(path).st_mode & 0o777
    
    assert(mode == 0o755)
    
    assert(chmod('/some/fake/path/that/does/not/exist') == None)
    
    
    

# Generated at 2022-06-23 18:23:17.782328
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user('foo')
    assert user.pw_name == 'foo'
    assert user.pw_passwd == '********'
    assert user.pw_uid == 1001
    assert user.pw_gid == 2001
    assert user.pw_gecos == 'Foo Bar'
    assert user.pw_dir == '/home/foo'
    assert user.pw_shell == '/usr/local/bin/bash'



# Generated at 2022-06-23 18:23:27.841162
# Unit test for function chmod
def test_chmod():
    from os import (
        getenv,
        mkdir,
        rmdir,
        stat,
    )
    from os.path import (
        isdir,
        isfile,
        join,
    )
    from sys import (
        argv,
        executable,
    )
    from tempfile import (
        gettempdir,
    )
    from unittest.mock import (
        create_autospec,
        patch,
        Mock,
        sentinel,
    )

    from flutils.pathutils import (
        chmod,
        normalize_path,
    )

    _TEST_DIR = join(gettempdir(), f'{getenv("USER")}.flutils.tests')

# Generated at 2022-06-23 18:23:39.445685
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import exists_as, normalize_path, path_absent
    tmp_dir = os.path.join(os.path.dirname(__file__), 'tmp')
    if os.path.isdir(tmp_dir):
        shutil.rmtree(tmp_dir)
    os.mkdir(tmp_dir)
    assert exists_as(tmp_dir) == 'directory'
    tmp_sub_dir = os.path.join(tmp_dir, 'sub_dir')
    tmp_sub_sub_dir = os.path.join(tmp_sub_dir, 'sub_sub_dir')
    tmp_sub_sub_sub_dir = os.path.join(tmp_sub_sub_dir, 'sub_sub_sub_dir')
    tmp_sub_sub_sub_sub_

# Generated at 2022-06-23 18:23:49.844802
# Unit test for function chmod
def test_chmod():
    import tempfile
    from flutils.pathutils import chmod
    from shutil import rmtree
    from os import makedirs

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:23:54.828954
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/flutils/tests/test_directory_present')
    correct_path = '~/tmp/flutils/tests/test_directory_present'

    assert path.as_posix() == correct_path

# Generated at 2022-06-23 18:24:05.515121
# Unit test for function exists_as
def test_exists_as():
    path_file = Path().home() / 'tmp' / 'flutils.tests.osutils.txt'
    path_dir = Path().home() / 'tmp' / 'flutils.tests.osutils'
    posix = 'posix'
    nt = 'nt'
    expected = 'directory'
    actual = exists_as(path_dir)
    if os.name == posix:
        assert actual == expected
    elif os.name == nt:
        expected = ''
        assert actual == expected

    path_dir.mkdir(mode=0o770, parents=True)

    expected = 'file'
    actual = exists_as(path_file)
    if os.name == posix:
        assert actual == expected
    elif os.name == nt:
        expected = ''
        assert actual == expected

# Generated at 2022-06-23 18:24:11.387364
# Unit test for function path_absent
def test_path_absent():
    for _ in range(2):
        _tmp_dir = tempfile.mkdtemp(prefix='test_')
        chown(_tmp_dir, user='test_user', group='test_group')
        _tmp_file = os.path.join(_tmp_dir, 'test_file')
        with open(_tmp_file, 'w') as fp: pass
        chown(_tmp_file, user='test_user', group='test_group')
        path_absent(_tmp_file)
        assert os.path.exists(_tmp_file) is False
        path_absent(_tmp_dir)
        assert os.path.exists(_tmp_dir) is False
        assert os.path.exists(_tmp_file) is False



# Generated at 2022-06-23 18:24:12.596580
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group("bar").gr_gid == 2001



# Generated at 2022-06-23 18:24:17.825953
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(normalize_path('~/tmp')) == 'directory'
    assert exists_as(normalize_path('~/tmp/osutils.txt')) == 'file'
    # assert exists_as(normalize_path('~/tmp/osutils.lnk')) == ''
    # assert exists_as(normalize_path('~/tmp/non_file')) == ''



# Generated at 2022-06-23 18:24:27.909615
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/etc') == 'directory'
    assert exists_as('/etc/passwd') == 'file'
    assert exists_as('/dev/null') == 'block device'
    assert exists_as('/dev/console') == 'char device'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/dev/log') == 'socket'

    # Non-existing cases
    assert exists_as('/nonexisting') == ''
    assert exists_as('/nonexisting/nonexisting') == ''
    assert exists_as('/etc/nonexisting') == ''
    assert exists_as('/nonexisting/passwd') == ''

    # Broken link cases
    with NamedTemporaryFile() as f:
        fname = f.name

# Generated at 2022-06-23 18:24:30.515976
# Unit test for function find_paths
def test_find_paths():
    assert set(find_paths('~/tmp/*')) == {
        Path('/home/test_user/tmp/file_one'),
        Path('/home/test_user/tmp/dir_one'),
    }



# Generated at 2022-06-23 18:24:30.980930
# Unit test for function get_os_user
def test_get_os_user():
    pass

# Generated at 2022-06-23 18:24:42.479133
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent

    # Test an existing directory gets removed.
    test_path = Path('~/tmp/test_path/pathutils').expanduser()
    test_path.mkdir(parents=True)
    path_absent(test_path)
    assert not test_path.exists()

    # Test an existing symlink to a directory gets removed.
    test_path = Path('~/tmp/test_path/pathutils').expanduser()
    test_path_link = Path('~/tmp/test_path_link/pathutils').expanduser()
    test_path.mkdir(parents=True)
    test_path_link.parent.mkdir(parents=True)
    test_path_link.symlink_to(test_path)
    path_absent

# Generated at 2022-06-23 18:24:50.588404
# Unit test for function chmod
def test_chmod():

    from flutils.pathutils import chmod
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tempdir:

        path_dir = Path(tempdir) / 'dir'
        path_file = path_dir / 'flutils.tests.osutils.txt'

        path_dir.mkdir()
        path_file.touch()

        assert path_dir.is_dir() is True
        assert path_dir.stat().st_mode & 0o7777 == 0o700
        assert path_file.is_dir() is False
        assert path_file.stat().st_mode & 0o7777 == 0o600

        chmod(path_dir.as_posix(), mode_file=0o664, mode_dir=0o775)

        assert path_dir.is_dir() is True
        assert path_dir

# Generated at 2022-06-23 18:24:53.418791
# Unit test for function get_os_user
def test_get_os_user():
    """Test :func:`get_os_user <flutils.pathutils.get_os_user>`."""
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user('root').pw_name == 'root'
    with pytest.raises(OSError):
        get_os_user(-1)



# Generated at 2022-06-23 18:25:00.290284
# Unit test for function chmod
def test_chmod():
    path = normalize_path('~/tmp')
    chmod(path, mode_file=0o444, mode_dir=0o555)
    assert path.stat().st_mode & 0o777 == 0o555
    # Remove the test files used for this test
    for f in path.glob('flutils.tests.osutils.*'):
        if f.is_file():
            f.unlink()
    if os.path.exists(path.as_posix()):
        os.rmdir(path.as_posix())



# Generated at 2022-06-23 18:25:01.017580
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:25:07.955672
# Unit test for function get_os_group
def test_get_os_group():
    expected = grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2001,
        gr_mem=['foo'])
    result = get_os_group('bar')
    assert expected == result
    expected = grp.struct_group(gr_name='bar', gr_passwd='*', gr_gid=2001,
        gr_mem=['foo'])
    result = get_os_group(2001)
    assert expected == result



# Generated at 2022-06-23 18:25:19.357258
# Unit test for function chown
def test_chown():
    path = normalize_path('~/tmp/flutils.tests.osutils.1.txt')
    assert os.stat(path.as_posix()).st_uid == getpass.getuser()
    assert os.stat(path.as_posix()).st_gid == grp.getgrgid(os.getgid()).gr_gid
    assert os.stat(path.parent.as_posix()).st_uid == getpass.getuser()
    assert os.stat(path.parent.as_posix()).st_gid == grp.getgrgid(os.getgid()).gr_gid

    chown('~/tmp/flutils.tests.osutils.*.txt', user='-1', group='-1')

# Generated at 2022-06-23 18:25:30.002848
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory to hold test paths.
    test_path = cast(Path, Path(tempfile.mkdtemp()))

# Generated at 2022-06-23 18:25:38.110833
# Unit test for function path_absent
def test_path_absent():
    with TemporaryDirectory() as tmpdir:
        test_dir = tmpdir / 'test_path'
        test_dir.mkdir(mode=0o700)
        with open('/home/test_user/tmp/test_path/test_file', 'w') as out_obj:
            out_obj.write('test content')
        path_absent('/home/test_user/tmp/test_path')
        assert os.path.isdir('/home/test_user/tmp/test_path') is False



# Generated at 2022-06-23 18:25:45.478863
# Unit test for function get_os_group
def test_get_os_group():
    gr_name = 'gr_name'
    gr_passwd = 'gr_passwd'
    gr_gid = 1
    gr_mem = ['gr_mem']
    group = grp.struct_group(gr_name,  gr_passwd, gr_gid, gr_mem)

    def side_effect(name: Union[str, int]) -> grp.struct_group:
        if isinstance(name, str):
            return group
        else:
            raise KeyError

    with mock.patch.object(grp, 'getgrnam') as mock_getgrnam:
        mock_getgrnam.side_effect = side_effect

        with mock.patch.object(grp, 'getgrgid') as mock_getgrgid:
            mock_getgrgid.side_effect = side_effect

# Generated at 2022-06-23 18:25:46.486300
# Unit test for function exists_as
def test_exists_as():
    return

# Generated at 2022-06-23 18:25:55.624890
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/../foo/bar') == Path('/foo/bar')
    assert normalize_path('~/foo') == Path('/home/test_user/foo')
    assert normalize_path('/tmp/foo') == Path('/tmp/foo')
    assert normalize_path('/tmp/foo') == Path('/tmp/foo')
    assert normalize_path('tmp/') == Path('/home/test_user/tmp')
    assert normalize_path('tmp') == Path('/home/test_user/tmp')



# Generated at 2022-06-23 18:26:06.494957
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from pathlib import Path

    # Test single file.
    Path('/tmp/flutils-tests/chmod/txt').touch()
    assert Path('/tmp/flutils-tests/chmod/txt').stat().st_mode & 0o777 == 0o600
    chmod('/tmp/flutils-tests/chmod/txt', 0o660)
    assert Path('/tmp/flutils-tests/chmod/txt').stat().st_mode & 0o777 == 0o660
    chmod('/tmp/flutils-tests/chmod/txt', 0o660, 0o770, include_parent=True)
    assert Path('/tmp/flutils-tests/chmod').stat().st_mode & 0o777 == 0o770

    # Test directory.

# Generated at 2022-06-23 18:26:15.193136
# Unit test for function chmod
def test_chmod():
    import os
    import tempfile

    from flutils.pathutils import chmod
    from flutils.pathutils import directory_present
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_exists_as

    os.environ['HOME'] = '/home/test'

    tmp = Path(tempfile.gettempdir())
    tmp_dir = tmp / 'tmp_test_chmod'
    tmp_path = tmp_dir / 'test_chmod.txt'

    with path_absent(tmp_path):
        with directory_present(tmp_dir):
            chmod(tmp_path)
            assert path_exists_as(tmp_path, 'file') is True

    with path_absent(tmp_path):
        with directory_present(tmp_dir):
            chmod

# Generated at 2022-06-23 18:26:20.929412
# Unit test for function exists_as
def test_exists_as():
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.bind('/tmp/test_exists_as.sock')
        assert exists_as('/tmp/test_exists_as.sock') == 'socket'
    assert exists_as('/tmp/test_exists_as.sock') == ''



# Generated at 2022-06-23 18:26:30.570731
# Unit test for function normalize_path
def test_normalize_path():
    """Unit tests for the normalize_path function."""
    # NOTE: This test is only being runn in a Linux environment.
    # It is not part of the unit test suite on a Windows environment.
    if sys.platform.startswith('linux'):
        normalize_path_posix = \
            functools.partial(normalize_path,
                              encoding=sys.getfilesystemencoding())
        normalize_path_posix('~/tmp/foo')
        normalize_path_posix('/home/testuser/tmp/foo')
        normalize_path_posix('/home/testuser/tmp/foo/../bar')
        normalize_path_posix('/./home/testuser/tmp/foo')
        normalize_path_posix('/../home/testuser/tmp/foo')

# Generated at 2022-06-23 18:26:37.557772
# Unit test for function directory_present
def test_directory_present():
    # os.path.join() does not like PosixPath objects.
    path = str(Path('~/tmp/flutils_test_directory').expanduser())
    try:
        import shutil
        shutil.rmtree(path, ignore_errors=True)
    except NotADirectoryError:
        Path(path).unlink()

    directory_present(path, mode=0o666, user='root', group='wheel')
    assert os.path.isdir(path) is True

    uid = pwd.getpwnam('root').pw_uid
    gid = grp.getgrnam('wheel').gr_gid
    stat = os.stat(path)
    assert stat.st_uid == uid
    assert stat.st_gid == gid
    assert stat.st_mode & 0