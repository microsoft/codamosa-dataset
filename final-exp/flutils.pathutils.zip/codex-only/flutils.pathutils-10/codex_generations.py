

# Generated at 2022-06-23 18:16:43.394931
# Unit test for function chown
def test_chown():
    import os
    import shlex
    from subprocess import run
    from tempfile import TemporaryDirectory

    from flutils.pathutils import chown

    with TemporaryDirectory() as tmpdir:
        parent_owner = getattr(os, 'geteuid', getpass.getuser)()
        parent_group = getattr(os, 'getegid', getpass.getuser)()

        # Test the function
        run(shlex.split("mkdir -p " + tmpdir + "/testdir/testdir"))
        run(shlex.split("touch " + tmpdir + "/testdir/testdir/testfile"))
        chown(tmpdir + "/testdir/testdir/testfile", user=0, group=0)

        # Check the results

# Generated at 2022-06-23 18:16:53.624865
# Unit test for function chmod
def test_chmod():
    import shutil
    import tempfile

    import pytest
    from _pytest.pathlib import copy_missing_parents

    try:
        with tempfile.TemporaryDirectory(dir='.') as tmpdir:
            tmpdir_path = Path(tmpdir)
            file_path = tmpdir_path / 'file.txt'

            with file_path.open('w') as f:
                f.write("test")

            # test that file_path exists
            if file_path.exists() is False:
                copy_missing_parents('file.txt')

            # test that chmod does not exist
            chmod('file.txt', 0o600)
            assert file_path.stat().st_mode & 0o777 == 0o600
    finally:
        if file_path.exists() is True:
            file_

# Generated at 2022-06-23 18:17:03.163556
# Unit test for function chown
def test_chown():
    from .osutils import (
        create_file,
        create_dir,
    )
    tmpdir = create_dir('~/tmp')
    create_file(tmpdir)
    chown(tmpdir.as_posix(), user=getpass.getuser())
    assert getpass.getuser() == tmpdir.owner()
    chown(tmpdir.as_posix(), group=grp.getgrgid(os.getgid()).gr_name)
    assert getpass.getuser() == tmpdir.owner()



# Generated at 2022-06-23 18:17:04.610453
# Unit test for function chmod
def test_chmod():
    # FIXME: create unit test for chmod
    pass



# Generated at 2022-06-23 18:17:13.429858
# Unit test for function get_os_group
def test_get_os_group():
    name = 'foo'
    try:
        _ = get_os_group(name)
    except OSError as e:
        assert str(e) == \
               'The given name: \'foo\', is not a valid "group name" for this ' \
               'operating system.'
    name = 0
    try:
        _ = get_os_group(name)
    except OSError as e:
        assert str(e) == \
               'The given gid: 0, is not a valid gid for this operating system.'



# Generated at 2022-06-23 18:17:17.540590
# Unit test for function get_os_user
def test_get_os_user():
    # Get user no args
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    # Get user no args
    user = get_os_user(getpass.getuser())
    assert isinstance(user, pwd.struct_passwd)



# Generated at 2022-06-23 18:17:24.350842
# Unit test for function normalize_path
def test_normalize_path():
    path = normalize_path('~/tmp/foo/../bar')
    assert path == Path('/home/test_user/tmp/bar')
    path = normalize_path(Path('~/tmp/foo/../bar'))
    assert path == Path('/home/test_user/tmp/bar')
    path = normalize_path(b'~/tmp/foo/../bar')
    assert path == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-23 18:17:29.582619
# Unit test for function find_paths
def test_find_paths():
    from . import osutils
    from .osutils import remove_all
    with osutils.temp_directory() as temp_directory:
        sub_path_one = temp_directory / 'sub_path_one'
        file_one = sub_path_one / 'file_one'
        sub_path_two = temp_directory / 'sub_path_two'
        file_two = sub_path_two / 'file_two'
        file_one.touch()
        file_two.touch()
        assert set(find_paths(temp_directory)) == {
            sub_path_one, sub_path_two, file_one, file_two
        }
        tmp_anchor = Path(tempfile.gettempdir())

# Generated at 2022-06-23 18:17:32.348584
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert user.pw_name == getpass.getuser()



# Generated at 2022-06-23 18:17:33.482949
# Unit test for function directory_present
def test_directory_present():
    """
    """
    pass


# Generated at 2022-06-23 18:17:37.935986
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group()
    assert get_os_group(grp.getgrgid(os.getgid()).gr_name)
    assert get_os_group(os.getgid())
    assert get_os_group(2035)



# Generated at 2022-06-23 18:17:46.887012
# Unit test for function path_absent
def test_path_absent():
    """Unit test for function path_absent."""
    import unittest
    import tempfile

    class TestPathAbsent(unittest.TestCase):
        """TestCase class for path_absent."""

        def setUp(self):
            """
            Create a temporary directory and save a reference to it.

            The temporary directory will be removed when the test is finished.
            """
            self.tmpdir = tempfile.TemporaryDirectory()
            self.dir = Path(self.tmpdir.name)
            self.dir.mkdir()

        def tearDown(self):
            """Remove the temporary directory and its contents."""
            self.tmpdir.cleanup()

        def test_absent(self):
            self.assertTrue(self.dir.is_dir())
            path_absent(self.dir)

# Generated at 2022-06-23 18:17:53.270582
# Unit test for function exists_as
def test_exists_as():
    """Test for function exists_as."""
    assert exists_as('.') == 'directory'
    assert exists_as(__file__) == 'file'
    assert exists_as('') == ''
    assert exists_as(__package__) == ''
    assert exists_as(__loader__) == ''



# Generated at 2022-06-23 18:17:56.930990
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for normalize_path."""
    assert normalize_path('~/tmp/foo') == Path('/home/test_user/tmp/foo')
    assert normalize_path(Path('/tmp/foo')) == Path('/tmp/foo')
    assert normalize_path('/tmp/foo') == Path('/tmp/foo')



# Generated at 2022-06-23 18:18:01.383710
# Unit test for function chmod
def test_chmod():
    test_path = Path('~/tmp/flutils.tests.osutils.txt').expanduser()
    test_path.touch()
    chmod(test_path, 0o660)
    assert test_path.stat().st_mode == 0o100660



# Generated at 2022-06-23 18:18:10.587015
# Unit test for function normalize_path
def test_normalize_path():
    # path = str
    assert normalize_path('~/tmp') == Path.home() / 'tmp'
    # path = bytes
    assert normalize_path(b'~/tmp') == Path.home() / 'tmp'
    # path = Path
    assert normalize_path(Path()) == Path.cwd()
    # path = PosixPath
    assert normalize_path(PosixPath()) == Path.cwd()
    # path = WindowsPath
    assert normalize_path(WindowsPath()) == Path.cwd()



# Generated at 2022-06-23 18:18:21.037213
# Unit test for function directory_present
def test_directory_present():
    import shlex
    import shutil
    import subprocess
    import tempfile

    from flutils.pathutils import directory_present

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        # Test regular operation.
        dir_path = directory_present(tmp_dir / 'test_path')
        assert dir_path.is_dir() is True
        assert shlex.split('ls -ld %s' % dir_path.as_posix())[0:4] == [
            'drwx------', '1', getpass.getuser(), getpass.getuser()
        ]

        # Test the given path already exists.
        dir_path = directory_present(tmp_dir / 'test_path')
        assert dir_path.is_dir() is True
        assert sh

# Generated at 2022-06-23 18:18:22.890800
# Unit test for function chown
def test_chown():
    assert True
# End unit test for function chown



# Generated at 2022-06-23 18:18:32.518253
# Unit test for function directory_present
def test_directory_present():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        mode = 0o666
        user = getpass.getuser()
        group = grp.getgrgid(os.getgid()).gr_name
        expected_path = tmp_path.joinpath('test_path')

        # Check directory does not exist.
        assert expected_path.exists() is False

        actual_path = directory_present(
            expected_path,
            mode=mode,
            user=user,
            group=group
        )

        # Check created directory.
        assert actual_path == expected_path
        assert actual_path.exists() is True
        assert actual_path.is_dir() is True
        assert expected_path.stat().st_mode & 0o777 == mode
       

# Generated at 2022-06-23 18:18:34.214676
# Unit test for function get_os_user
def test_get_os_user():
    # Need to write unit test
    pass



# Generated at 2022-06-23 18:18:35.623167
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user()
    get_os_user(1001)



# Generated at 2022-06-23 18:18:45.523269
# Unit test for function find_paths
def test_find_paths():
    tmp_dir = directory_present(Path().home() / 'tmp' / 'flutils.tests')
    tmp_sub_dir = directory_present(tmp_dir / 'sub')
    (tmp_sub_dir / 'subsub').mkdir(0o700)
    (tmp_sub_dir / 'subsub2').mkdir(0o700)
    (tmp_sub_dir / 'subsub' / 'subsub3').mkdir(0o700)
    (tmp_sub_dir / 'subsub' / 'subsub3' / 'subsub4').mkdir(0o700)
    (tmp_sub_dir / 'subsub' / 'subsub3' / 'subsub4' / 'subsub5')\
        .mkdir(0o700)


# Generated at 2022-06-23 18:18:49.371188
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user()
    get_os_user(pwd.getpwuid(os.getuid()).pw_name)
    get_os_user(pwd.getpwuid(os.getuid()).pw_uid)



# Generated at 2022-06-23 18:18:56.194338
# Unit test for function chmod
def test_chmod():
    import textwrap
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_user
    from flutils.tests.datautils import make_temp_file

    base_path = '~/tmp/flutils.tests.osutils'

# Generated at 2022-06-23 18:19:06.598301
# Unit test for function get_os_user
def test_get_os_user():
    from flutils.pathutils import get_os_user
    import pwd
    from unittest.mock import Mock
    from unittest.mock import patch

    foo_pw_struct = pwd.struct_passwd(
        pw_name='foo', pw_passwd='********', pw_uid=1001, pw_gid=2001,
        pw_gecos='Foo Bar', pw_dir='/home/foo',
        pw_shell='/usr/local/bin/bash'
    )

    with patch('pwd.getpwnam') as mock_getpwnam:
        mock_getpwnam.return_value = foo_pw_struct
        assert get_os_user('foo') == foo_pw_struct
        mock_getpwnam.assert_

# Generated at 2022-06-23 18:19:12.748086
# Unit test for function find_paths
def test_find_paths():
    path = '/tmp'
    # Get a random directory name
    dname = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    pattern = '/tmp/*'
    path = os.path.join(path, dname)
    os.mkdir(path)
    try:
        assert os.path.exists(path)
        paths = list(find_paths(pattern))
        assert path in paths
    finally:
        os.rmdir(path)
test_find_paths()



# Generated at 2022-06-23 18:19:15.569389
# Unit test for function exists_as
def test_exists_as():
    # The current user should exist on practically any operating system.
    assert exists_as(get_os_user().pw_dir) == 'directory'
    # The below paths should not exist.
    assert exists_as('/this/path/does/not/exist') == ''
    assert exists_as('~/this/path/does/not/exist') == ''



# Generated at 2022-06-23 18:19:26.214395
# Unit test for function directory_present
def test_directory_present():
    tdir = Path(os.environ['TEST_DIR'])
    path = tdir / 'test_directory_present'
    if path.exists():
        path.rmdir()
    result = directory_present(path)
    assert isinstance(result, path.__class__)
    assert result.as_posix() == path.as_posix()
    assert result.exists() is True
    assert result.is_dir() is True
    assert os.stat(result.as_posix()).st_mode & 0o700 == 0o700

    result = directory_present(path)
    assert isinstance(result, path.__class__)
    assert result.as_posix() == path.as_posix()
    assert result.exists() is True
    assert result.is_dir() is True

# Generated at 2022-06-23 18:19:34.739119
# Unit test for function exists_as
def test_exists_as():
    """Test exists_as function."""
    from flutils.pathutils import exists_as

    assert exists_as('~/tmp') == 'directory'
    assert exists_as('/foo/bar') == ''
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'

    # Good test for a 'broken' symlink.
    if not is_windows():
        child_path = os.path.join(
            sys.prefix, 'lib', 'python%s' % sys.version[:3], 'os.py'
        )
        os.symlink(child_path, '/tmp/os.py')
        assert exists_as('/tmp/os.py') == ''
        os.unlink('/tmp/os.py')



# Generated at 2022-06-23 18:19:44.224482
# Unit test for function path_absent
def test_path_absent():
    base = Path(__file__).parent
    tmp = base.joinpath('flutils_pathutils_test_path_absent')
    tmp.mkdir(exist_ok=True)
    tmp_dir = tmp.joinpath('dir')
    tmp_dir.mkdir(exist_ok=True)
    tmp_dir_file = tmp_dir.joinpath('file')
    tmp_dir_file.touch(exist_ok=True)
    tmp_file = tmp.joinpath('file')
    tmp_file.touch(exist_ok=True)

# Generated at 2022-06-23 18:19:46.747862
# Unit test for function directory_present
def test_directory_present():
    directory_present('/Users/foo', mode=0o777, user=1000, group=1000)



# Generated at 2022-06-23 18:19:55.888453
# Unit test for function path_absent
def test_path_absent():
    test_dir = Path('/tmp/unit_tests/')
    test_dir.mkdir(parents=True, exist_ok=True)
    file1_path = test_dir / 'file_one'
    if file1_path.is_file():
        file1_path.unlink()
    file1_path.write_text('This is a test.')
    assert file1_path.is_file()
    path_absent(file1_path.as_posix())
    assert not file1_path.is_file()
    test_dir.rmdir()
test_path_absent()



# Generated at 2022-06-23 18:20:03.429922
# Unit test for function get_os_group
def test_get_os_group():
    import string
    import random
    import os
    group_name = ''.join(
        random.SystemRandom().choice(string.ascii_uppercase + string.digits)
        for _ in range(10)
    )
    user_name = ''.join(
        random.SystemRandom().choice(string.ascii_uppercase + string.digits)
        for _ in range(10)
    )
    with create_test_user(user_name=user_name, group_name=group_name) as user:
        # get the os user using the current user
        os_user = get_os_user()
        assert os_user.pw_name == user_name

        os_group = get_os_group(os_user.pw_gid)
        assert os_group.gr

# Generated at 2022-06-23 18:20:11.765999
# Unit test for function exists_as
def test_exists_as():
    """Unit test for the pathutils.exists_as function."""
    import pytest
    from flutils.pathutils import exists_as, directory_present

    tmp_dir = '~/tmp/flutils.tests.pathutils.exists_as'


# Generated at 2022-06-23 18:20:16.127894
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_name == getpass.getuser()
    user = get_os_user(1000)
    assert isinstance(user, pwd.struct_passwd)
    assert user.pw_uid == 1000



# Generated at 2022-06-23 18:20:21.493301
# Unit test for function normalize_path
def test_normalize_path(): # noqa: D103
    path = Path('/home/test_user/tmp/foo')
    assert normalize_path(path) == path
    assert normalize_path(path.as_posix()) == path
    assert normalize_path(path.as_posix().encode()) == path

# Generated at 2022-06-23 18:20:27.804269
# Unit test for function path_absent
def test_path_absent():
    path = Path('test_tmp/does_not_exist')
    assert path_absent(path) == None

    path = Path('test_tmp/file_one')
    assert path_absent(path) == None

    path = Path('test_tmp/dir_one')
    assert path_absent(path) == None



# Generated at 2022-06-23 18:20:38.339354
# Unit test for function chown
def test_chown():
    from shutil import (
        rmtree,
    )

    from tempfile import (
        mkdtemp,
    )

    from pathlib import Path
    from pathlib import PosixPath
    from pathlib import WindowsPath

    tmp_test_dir = Path(mkdtemp(prefix='test_pathutils_'))
    tmp_test_file = tmp_test_dir / 'flutils.tests.osutils.txt'
    tmp_test_file.touch()
    tmp_test_file_owner = os.stat(tmp_test_file).st_uid
    tmp_test_file_group = os.stat(tmp_test_file).st_gid

    tmp_test_str = str(tmp_test_file)

    # Test a Path

# Generated at 2022-06-23 18:20:39.785404
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)



# Generated at 2022-06-23 18:20:49.935519
# Unit test for function normalize_path
def test_normalize_path():
    # str paths
    assert normalize_path('/foo/bar') == Path('/foo/bar')
    assert normalize_path('/foo//bar') == Path('/foo/bar')
    assert normalize_path('/foo/./bar') == Path('/foo/bar')
    assert normalize_path('/foo/../bar') == Path('/bar')
    # bytes paths
    assert normalize_path(b'/foo/bar') == Path('/foo/bar')
    assert normalize_path(b'/foo//bar') == Path('/foo/bar')
    assert normalize_path(b'/foo/./bar') == Path('/foo/bar')
    assert normalize_path(b'/foo/../bar') == Path('/bar')
    # PosixPath paths

# Generated at 2022-06-23 18:20:59.662248
# Unit test for function chown
def test_chown():
    from os import mkdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import time

    from .test_functions import (
        has_permissions,
        has_user_and_group,
        is_owned
    )

    args = (
        None,
        'foo',
        'bar'
    )
    kwargs = {
        'user': None,
        'group': None
    }

    tmpdir = mkdtemp(prefix=f'flutils_{time()}_')

    file1 = Path(tmpdir) / 'flutils.tests.osutils.txt'
    file1.touch()

    dir1 = Path(tmpdir) / 'flutils.tests.osutils.dir'
    mkdir(dir1.as_posix())

    dir2

# Generated at 2022-06-23 18:21:09.985863
# Unit test for function chown
def test_chown():
    import os
    import sys
    import tempfile
    import unittest

    class TestChown(unittest.TestCase):
        def setUp(self):
            self.temp_path = Path(tempfile.gettempdir())
            self.test_path = self.temp_path / 'flutils.tests.osutils'

            self.test_path.mkdir(
                parents=True,
                exist_ok=True,
            )

            if sys.platform != 'win32':
                self.mode_file = 0o600
                self.mode_dir = 0o700
            else:
                self.mode_file = 0o666  # noqa
                self.mode_dir = 0o777  # noqa

            self.test_file_path = self.test_path / 'file.txt'

            self

# Generated at 2022-06-23 18:21:13.300385
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError):
        get_os_group()
    assert get_os_group(1000) == grp.getgrgid(1000)
    assert get_os_group('bar') == grp.getgrnam('bar')



# Generated at 2022-06-23 18:21:15.195104
# Unit test for function chown
def test_chown():
    assert True, 'TODO: Write unit test for chown'
    return True



# Generated at 2022-06-23 18:21:20.263368
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('.').as_posix() == os.getcwd()
    assert normalize_path('./tmp').as_posix() == os.path.join(os.getcwd(), 'tmp')
    if platform.system() == 'Windows':
        assert normalize_path('foo\\bar').as_posix() == 'foo/bar'
        assert normalize_path('\\temp\\foo').as_posix() == '/temp/foo'
    else:
        assert normalize_path('/tmp/foo').as_posix() == '/tmp/foo'

normalize_path.register(Path, lambda path: path)
normalize_path.register(bytes, lambda path: Path(path.decode(sys.getfilesystemencoding())))



# Generated at 2022-06-23 18:21:30.021286
# Unit test for function normalize_path
def test_normalize_path():
    paths = (
        ('~/tmp', '/home/test_user/tmp'),
        ('~/tmp/foo/../bar', '/home/test_user/tmp/bar'),
        ('/tmp/$FOO/bar/..', '/tmp/foo/'),
        ('~test_user/tmp/$FOO', '/home/test_user/tmp/foo')
    )
    with contextlib.ExitStack() as stack:
        stack.enter_context(environment_variable('FOO', 'foo'))
        stack.enter_context(working_directory('/tmp'))
        for path, expected in paths:
            assert (
                normalize_path(path).as_posix() == expected
            ), 'The path: {0!r} was not normalized properly.'.format(path)

# Generated at 2022-06-23 18:21:42.977271
# Unit test for function normalize_path
def test_normalize_path():
    # test normalize_path on str
    path = '~/tmp/foo/../bar'
    path_out = normalize_path(path)
    assert path_out.as_posix() == '/home/test_user/tmp/bar'

    # test normalize_path on bytes
    path = b'~/tmp/foo/../bar'
    path_out = normalize_path(path)
    assert path_out.as_posix() == '/home/test_user/tmp/bar'

    # test normalize_path on PosixPath
    path = Path('~/tmp/foo/../bar')
    path_out = normalize_path(path)
    assert path_out.as_posix() == '/home/test_user/tmp/bar'

    # test normalize_path on WindowsPath
   

# Generated at 2022-06-23 18:21:54.168762
# Unit test for function find_paths
def test_find_paths():
    def create_tmp_paths():
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            temp_dir = Path(temp_dir)
            tmp_files = (
                temp_dir / 'file_one',
                temp_dir / 'file_two',
                temp_dir / 'file_three',
            )
            tmp_dirs = (
                temp_dir / 'dir_one',
                temp_dir / 'dir_two',
                temp_dir / 'dir_three',
            )
            for item in tmp_files + tmp_dirs:
                i_type = 'dir' if item in tmp_dirs else 'file'
                os.makedirs(item.as_posix(), exist_ok=True) \
                    if i_type == 'dir' else item.touch()


# Generated at 2022-06-23 18:22:00.194433
# Unit test for function directory_present
def test_directory_present():
    kwargs = {
        'user': getpass.getuser(),
    }

    for path in [
            '~/tmp/flutils.pathutils',
            '~/tmp/flutils.pathutils/foo',
            '~/tmp/flutils.pathutils/foo/bar',
    ]:
        kwargs['path'] = path
        directory_present(**kwargs)



# Generated at 2022-06-23 18:22:12.606105
# Unit test for function chmod
def test_chmod():
    import os
    dir_path = os.path.join(os.path.expanduser('~'), 'tmp')
    test_file_1 = os.path.join(dir_path, 'flutils.tests.osutils.txt')
    test_file_2 = os.path.join(dir_path, 'flutils.tests.osutils.py')
    if not os.path.isdir(dir_path):
        os.mkdir(dir_path)
    if not os.path.isfile(test_file_1):
        open(test_file_1, 'a').close()
    if not os.path.isfile(test_file_2):
        open(test_file_2, 'a').close()
    chmod(test_file_1, 0o666)

# Generated at 2022-06-23 18:22:17.582077
# Unit test for function get_os_group
def test_get_os_group():
    """
    Unit test for function get_os_group

    """
    from flutils.pathutils import get_os_group
    get_os_group()
    get_os_group(None)
    assert get_os_group('root').gr_gid == 0
    assert get_os_group(0).gr_name == 'root'
    assert get_os_group('bar').gr_name == 'bar'



# Generated at 2022-06-23 18:22:20.785585
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/doesnotexist') == ''
    assert exists_as('~/tmp/myconfig.ini') == 'file'



# Generated at 2022-06-23 18:22:27.860356
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for function get_os_user."""
    from flutils.pathutils import get_os_user
    import getpass

    user = None
    if os.name == 'posix':
        user = pwd.getpwnam(getpass.getuser())
    elif os.name == 'nt':
        user = get_os_user(getpass.getuser())

    if user is not None:
        assert user == get_os_user(user.pw_uid)



# Generated at 2022-06-23 18:22:29.628673
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group() == get_os_user().pw_gid



# Generated at 2022-06-23 18:22:40.728083
# Unit test for function directory_present
def test_directory_present():
    from shutil import rmtree

    path = PosixPath('~/tmp/test_directory_present/test_directory').expanduser()
    try:
        directory_present(path)  # pylint: disable=no-value-for-parameter

    finally:
        rmtree(path.parent.as_posix())

    path = PosixPath('~/tmp/test_directory_present').expanduser()
    try:
        directory_present(path, mode=0o700)  # pylint: disable=no-value-for-parameter

    finally:
        rmtree(path.as_posix())

    path = PosixPath('~/tmp/test_directory_present').expanduser()

# Generated at 2022-06-23 18:22:49.129615
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'test_path_absent')

        # If path already exists, delete it.
        path_absent(path)

        # Create a file that will be deleted by the path_absent function.
        open(path, 'a').close()
        with open(path, mode='w') as fd:
            fd.write('test')
        assert os.path.exists(path)

        # Delete path.
        path_absent(path)
        assert not os.path.exists(path)

        # Create a directory one level deep.
        os.mkdir(path)
        path2 = os.path.join(path, 'test_path_absent2')

# Generated at 2022-06-23 18:22:54.378296
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(__file__) == Path(__file__)
    assert normalize_path('~foo/tmp/bar') == Path('/home/foo/tmp/bar')
    assert normalize_path('~foo/tmp/bar/baz') == Path('/home/foo/tmp/bar/baz')
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')
normalize_path.register(bytes, functools.partial(normalize_path, Path))



# Generated at 2022-06-23 18:22:57.504357
# Unit test for function directory_present
def test_directory_present():
    _test_path = Path('test_path')
    parent_path = directory_present(_test_path)
    assert parent_path.exists() is True
    assert parent_path.is_dir() is True
    assert parent_path.name == 'test_path'

    parent_path.rmdir()



# Generated at 2022-06-23 18:23:01.585642
# Unit test for function find_paths
def test_find_paths():
    filename = Path(__file__)
    cwd = Path.cwd()

    # Get this module's __file__ path.
    os_find_paths_output = set([filename])
    assert set(find_paths(cwd.as_posix() + '/*.py')) == os_find_paths_output

    os_find_paths_output = set([
        cwd.joinpath('flutils'),
        cwd.joinpath('flutils.tests'),
        cwd.joinpath('flutils.tests.osutils'),
        cwd.joinpath('flutils.utils')])
    assert set(find_paths(cwd.as_posix() + '/*/')) == os_find_paths_output


# Generated at 2022-06-23 18:23:08.114274
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)

    # Supports a glob pattern
    chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770)

    # To change the mode of a directory's immediate contents
    chmod('~/tmp/*')



# Generated at 2022-06-23 18:23:18.967631
# Unit test for function find_paths
def test_find_paths():
    from flutils.osutils import cd_tempdir
    from flutils.pathutils.pathutils import find_paths
    from flutils.systemutils import get_tempdir
    with cd_tempdir():
        file_pattern = get_tempdir() / 'test_file_*'
        dir_pattern = get_tempdir() / 'test_dir_*'
        assert file_pattern not in find_paths(file_pattern)
        assert dir_pattern not in find_paths(dir_pattern)
        open(file_pattern.as_posix(), 'w').close()
        os.mkdir(dir_pattern.as_posix())
        assert file_pattern in find_paths(file_pattern)
        assert dir_pattern in find_paths(dir_pattern)



# Generated at 2022-06-23 18:23:27.281839
# Unit test for function get_os_user
def test_get_os_user():
    os.environ['HOME'] = '/home/test_user'
    res = get_os_user()
    assert isinstance(res, pwd.struct_passwd)
    assert res.pw_name == 'test_user'
    assert res.pw_dir == '/home/test_user'
    assert int(res.pw_uid) > 0
    assert int(res.pw_gid) > 0
    assert res.pw_shell.endswith('/bash')
    assert res.pw_gecos == ''
    assert res.pw_passwd == '********'
    assert isinstance(res.pw_gecos, str)



# Generated at 2022-06-23 18:23:34.929583
# Unit test for function get_os_user
def test_get_os_user():
    try:
        get_os_user()
        get_os_user('')
        get_os_user('0')
        get_os_user(0)
        get_os_user(os.getuid())
        get_os_user(os.getlogin())
    except OSError:
        # OSError is an expected result on some systems.
        pass
    except KeyError:
        # KeyError is an expected result on some systems.
        pass



# Generated at 2022-06-23 18:23:36.098594
# Unit test for function chmod
def test_chmod():
    assert callable(chmod) is True



# Generated at 2022-06-23 18:23:43.776184
# Unit test for function path_absent
def test_path_absent():
    # pylint: disable=missing-function-docstring
    # pylint: disable=unused-variable
    import os
    import re
    import shutil
    import tempfile

    from pathlib import Path
    from unittest import TestCase
    from unittest.mock import patch, sentinel

    from flutils.pathutils import path_absent

    with tempfile.TemporaryDirectory() as tmpdir:
        # Setup paths and files
        tmpdir = Path(tmpdir)
        tmpdir_path = tmpdir / 'dir'
        file_one = tmpdir_path / 'file_one'
        file_two = tmpdir / 'file_two'
        link_one = tmpdir / 'link_one'
        link_two = tmpdir / 'link_two'

# Generated at 2022-06-23 18:23:45.437742
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp')
    assert Path('~/tmp').is_dir()



# Generated at 2022-06-23 18:23:49.562038
# Unit test for function directory_present
def test_directory_present():
    path = directory_present('~/tmp/flutils.test_pathutils.test_directory_present.txt')
    assert path.as_posix() == '/Users/len/tmp/flutils.test_pathutils.test_directory_present.txt'


# Generated at 2022-06-23 18:23:52.600971
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')

# Generated at 2022-06-23 18:24:02.042841
# Unit test for function directory_present
def test_directory_present():
    """Verify :func:`directory_present` behavior."""

    with pytest.raises(ValueError) as excinfo:
        directory_present('~/tmp/*')

    assert excinfo.value.args[0] == (
        'The path: \'~/tmp/*\' must NOT contain any glob patterns.'
    )

    with pytest.raises(ValueError) as excinfo:
        directory_present('relative/path')

    assert excinfo.value.args[0] == (
        'The path: \'relative/path\' must be an absolute path.  A path is '
        'considered absolute if it has both a root and (if the flavour '
        'allows) a drive.'
    )


# Generated at 2022-06-23 18:24:13.200665
# Unit test for function chown
def test_chown():
    import inspect
    import pytest
    from flutils.pathutils import chown
    from flutils.pathutils import path_absent

    def test_bad_user_input(user: str = "", group: str = "") -> None:
        if user != "" and group != "":
            with pytest.raises((OSError, KeyError)):
                chown("~/tmp/test_chown_path_absent", user, group)
        elif user == "" and group != "":
            with pytest.raises(KeyError):
                chown("~/tmp/test_chown_path_absent", group=group)

# Generated at 2022-06-23 18:24:14.579222
# Unit test for function chown
def test_chown():
    assert chown('~/tmp/flutils.tests.osutils.txt')



# Generated at 2022-06-23 18:24:15.213121
# Unit test for function find_paths
def test_find_paths():
    pass



# Generated at 2022-06-23 18:24:25.104518
# Unit test for function directory_present
def test_directory_present():
    from tests.pathutils import test_path

    if isinstance(test_path, WindowsPath):
        raise NotImplementedError(
            'Unit test not implemented for operating system: %r'
            % sys.platform
        )

    new_path = test_path / 'non_existant_directory'
    returned = directory_present(new_path)
    assert returned.exists() is True
    assert returned.is_dir() is True
    assert returned.owner() == getpass.getuser()
    assert returned.group() == grp.getgrgid(os.getgid()).gr_name

    returned = directory_present(new_path)
    assert returned.exists() is True
    assert returned.is_dir() is True
    assert returned.owner() == getpass.getuser()
    assert returned.group

# Generated at 2022-06-23 18:24:29.812846
# Unit test for function normalize_path
def test_normalize_path():
    """Tests for function normalize_path."""

    file_name = 'tmp_12345.txt'
    test_path = Path(__file__).parent.joinpath('tmp')

    # Test the bytes path.
    path = test_path.joinpath(file_name).as_bytes()
    path = normalize_path(path)



# Generated at 2022-06-23 18:24:36.953745
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(__file__) == 'file'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('no_such_path') == ''
    assert exists_as('/dev/null') == 'char device'
    assert exists_as('/dev/zero') == 'char device'
    assert exists_as('/dev/tty') == 'char device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/urandom') == 'char device'



# Generated at 2022-06-23 18:24:42.915535
# Unit test for function chown
def test_chown():
    """Tests for the ``chown`` function."""

    assert __func_test_chown_OSError() is True
    assert __func_test_chown_TypeError() is True
    assert __func_test_chown_ValueError() is True



# Generated at 2022-06-23 18:24:50.757750
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import (
        chmod,
        path_absent,
    )
    from flutils.osutils import (
        create_tmp_file,
        create_tmp_dir,
    )
    from os.path import (
        isdir,
        isfile,
    )

    # All of these use the same mode
    # so save the call to create_tmp_file()
    temp_file = create_tmp_file(mode=0o600)
    assert isfile(temp_file)

    ###########
    # Test 1 #
    ###########
    # - chmod abs path
    # - Default mode
    chmod(temp_file)
    assert isfile(temp_file)
    assert os.stat(temp_file).st_mode == 33152

    ###########
   

# Generated at 2022-06-23 18:25:00.685567
# Unit test for function find_paths
def test_find_paths():
    with TemporaryDirectory() as rootdir:
        file_one = Path(rootdir, 'file_one')
        dir_one = Path(rootdir, 'dir_one')
        dir_one_one = Path(dir_one, 'dir_one_one')
        file_one.touch()
        dir_one.mkdir()
        dir_one_one.mkdir()
        assert set(find_paths(f'{rootdir}/*')) == {file_one, dir_one}
        assert set(find_paths(f'{rootdir}/*/')) == {dir_one}
        assert set(find_paths(f'{rootdir}/*/*')) == {dir_one_one}



# Generated at 2022-06-23 18:25:06.649947
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths."""
    pattern = '/tmp/**'
    search = pattern[len('/tmp'):]
    expected = ['/tmp/file_one', '/tmp/dir_one', '/tmp/dir_one/file_one']
    result = list(find_paths(pattern))
    assert result == expected
    result = list(Path().glob(search))
    assert result == expected



# Generated at 2022-06-23 18:25:15.689651
# Unit test for function find_paths
def test_find_paths():
    from unittest.mock import create_autospec
    from flutils.pathutils import find_paths
    import pathlib
    pattern = pathlib.Path('~').expanduser() / 'tmp' / '*'
    gen = find_paths(pattern)
    posix_path = create_autospec(pathlib.PosixPath)
    windows_path = create_autospec(pathlib.WindowsPath)
    assert gen.send(next(gen)) == posix_path
    assert gen.send(next(gen)) == windows_path



# Generated at 2022-06-23 18:25:19.261267
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('~') == 'directory'
    assert exists_as('~/tmp') == 'directory'



# Generated at 2022-06-23 18:25:25.588765
# Unit test for function exists_as
def test_exists_as():
    try:
        with open(os.path.join(os.getcwd(), '.temp_file.txt'), 'w') as fd:
            fd.write('This is a test file.')
            fd.close()
        assert exists_as(Path('.temp_file.txt')) == 'file'
    except Exception:
        raise
    finally:
        os.remove('.temp_file.txt')
    assert exists_as(Path(os.getcwd())) == 'directory'
    assert exists_as(os.path.join('this', 'path', 'does', 'not', 'exist')) == ''



# Generated at 2022-06-23 18:25:31.618173
# Unit test for function get_os_group
def test_get_os_group():
    os_group = get_os_group('foo')
    assert os_group.gr_name == 'foo'
    assert os_group.gr_passwd == '*'
    assert os_group.gr_gid == 2000
    assert os_group.gr_mem == ['bar']



# Generated at 2022-06-23 18:25:36.993554
# Unit test for function get_os_user
def test_get_os_user():
    actual = get_os_user('foo')
    expected = pwd.struct_passwd(pw_name='foo', pw_passwd='********',
                                 pw_uid=1001, pw_gid=2001, pw_gecos='Foo Bar',
                                 pw_dir='/home/foo',
                                 pw_shell='/usr/local/bin/bash')
    assert actual == expected

# Generated at 2022-06-23 18:25:46.576099
# Unit test for function find_paths
def test_find_paths():
    # Ensure the unit test is running from the current working directory
    # and not from the directory where the unit test was invoked from.
    os.chdir(os.getcwd())
    non_existing_path = normalize_path('~/tmp/find_paths')
    if non_existing_path.exists() is True:
        shutil.rmtree(non_existing_path.as_posix())

    non_existing_path.mkdir()

    (non_existing_path / 'file_one').touch()
    (non_existing_path / 'dir_one').mkdir()

    found_paths = find_paths('~/tmp/find_paths/*')
    assert found_paths is not None
    assert type(found_paths) is GeneratorType

# Generated at 2022-06-23 18:25:53.179084
# Unit test for function get_os_user
def test_get_os_user():  
    expected = pwd.struct_passwd(pw_name='flutils', pw_passwd='********', pw_uid=1001, pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo', pw_shell='/usr/local/bin/bash')
    returned = get_os_user('flutils')
    assert returned == expected



# Generated at 2022-06-23 18:25:54.709033
# Unit test for function directory_present
def test_directory_present():
    directory_present('~/tmp/flutils.test_directory_present')



# Generated at 2022-06-23 18:26:05.729548
# Unit test for function exists_as
def test_exists_as():
    from tests.pathutils import (
        _mock_path_isfile_false,
        _mock_path_isfile_true,
        _mock_path_isdir_false,
        _mock_path_isdir_true,
        _mock_path_isblock_false,
        _mock_path_isblock_true,
        _mock_path_ischar_false,
        _mock_path_ischar_true,
        _mock_path_isfifo_false,
        _mock_path_isfifo_true,
        _mock_path_issocket_false,
        _mock_path_issocket_true
    )

    # Does not exist.
    path = Path('/fake/path')

# Generated at 2022-06-23 18:26:13.240720
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    import shutil

    with TemporaryDirectory(prefix='flutils.tests.pathutils') as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'test_path.txt'

        with tmpfile.open('wb') as tfile:
            tfile.write(b'\0' * 1024)

        build_path = tmpdir / 'test_path'

        # Test the path does not exist.
        directory_present(build_path)

        assert build_path.is_dir() is True

        # Test the path already exists as a directory.
        directory_present(build_path)

        assert build_path.is_dir() is True

        # Test the path exists as a file.

# Generated at 2022-06-23 18:26:21.323400
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(b'/foo/bar') == '/foo/bar'
    assert normalize_path('/foo/bar') == '/foo/bar'
    assert normalize_path('~/foo/bar') == '/home/test_user/foo/bar'
    assert normalize_path('$HOME/foo/bar') == '/home/test_user/foo/bar'
    assert normalize_path('/foo//bar/') == '/foo/bar'
    assert normalize_path('/foo/./bar') == '/foo/bar'
    assert normalize_path('/foo/bar/.') == '/foo/bar'
    assert normalize_path('./foo') == os.getcwd() + '/foo'
    assert normalize_path('/foo/../bar') == '/bar'
    assert normalize_

# Generated at 2022-06-23 18:26:25.920482
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770) is None
    assert chmod('~/tmp/*') is None



# Generated at 2022-06-23 18:26:26.549773
# Unit test for function path_absent
def test_path_absent():
    pass



# Generated at 2022-06-23 18:26:32.615460
# Unit test for function normalize_path
def test_normalize_path():
    # Test with PosixPath
    posix_path = Path('~/tmp/foo/../bar')
    posix_path = posix_path.expanduser()
    posix_path = posix_path.resolve()
    posix_path = posix_path.as_posix()
    assert normalize_path('~/tmp/foo/../bar').as_posix() == posix_path
    # Test with PosixPath
    windows_path = Path('~/tmp/foo/../bar')
    windows_path = windows_path.expanduser()
    windows_path = windows_path.resolve()
    windows_path = windows_path.as_posix()
    assert normalize_path('~/tmp/foo/../bar').as_posix() == windows_path
    # Test with bytes