

# Generated at 2022-06-23 18:16:40.057494
# Unit test for function get_os_user
def test_get_os_user():
    assert_equals(
        get_os_user('root'),
        pwd.struct_passwd(
            pw_name='root',
            pw_passwd='********',
            pw_uid=0,
            pw_gid=0,
            pw_gecos='System Administrator',
            pw_dir='/var/root',
            pw_shell='/usr/bin/false',
        )
    )
#==============================================================================
#                                   TESTS
#==============================================================================
from flutils.testutils import TestCase


# Generated at 2022-06-23 18:16:47.633734
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as dir:
        tmp_path = Path(dir)
        assert list(find_paths(tmp_path)) == []
        tmp_path = tmp_path / 'test'
        tmp_path.touch()
        assert list(find_paths(tmp_path)) == [tmp_path]



# Generated at 2022-06-23 18:16:48.503037
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group() == _EXAMPLE_GROUP



# Generated at 2022-06-23 18:16:56.315253
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = normalize_path(tmpdir)
        file_one = tmpdir.joinpath('file_one')
        file_one.write_text('One')
        dir_one = tmpdir.joinpath('dir_one')
        dir_one.mkdir()
        dir_one_file_one = dir_one.joinpath('file_two')
        dir_one_file_one.write_text('Two')
        broken_link_one = tmpdir.joinpath('broken_link_one')
        os.symlink('I_do_not_exist_on_this_file_system', broken_link_one)
        broken_link_two = dir_one.joinpath('broken_link_two')

# Generated at 2022-06-23 18:17:07.164672
# Unit test for function chown
def test_chown():
    """Test function chown."""
    from flutils.pathutils import tempdir
    if os.name == 'nt':
        return

    with tempdir() as tmpdir:
        Path(tmpdir / 'foo').touch()

        foo_pw = pwd.getpwuid(os.stat(tmpdir / 'foo').st_uid)
        foo_gr = grp.getgrgid(os.stat(tmpdir / 'foo').st_gid)

        chown(tmpdir / 'foo', getpass.getuser(), foo_gr.gr_name)

        foo_pw = pwd.getpwuid(os.stat(tmpdir / 'foo').st_uid)
        foo_gr = grp.getgrgid(os.stat(tmpdir / 'foo').st_gid)

        assert foo

# Generated at 2022-06-23 18:17:12.855165
# Unit test for function get_os_group
def test_get_os_group():
    user1 = get_os_user('foo')
    user2 = get_os_user(user1.pw_gid)
    assert user1.pw_gid == user2.pw_gid
    assert user1.pw_name == user2.pw_name

# Generated at 2022-06-23 18:17:23.455858
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function `normalize_path`."""
    tmp_path = Path(tempfile.gettempdir())
    test_path = tmp_path / 'test_path'

    def test_path_exists():
        """Check that the test path exists."""
        assert exists_as(test_path) == 'file'

    def test_norm_path_is_path_obj():
        """
        Check that the given path is converted to a `Path <pathlib.Path>`
        object.
        """
        if sys.platform.startswith('win'):
            assert isinstance(normalize_path(test_path), WindowsPath)
        else:
            assert isinstance(normalize_path(test_path), PosixPath)


# Generated at 2022-06-23 18:17:35.339382
# Unit test for function chmod
def test_chmod():

    from textwrap import dedent
    from tempfile import (
        TemporaryDirectory,
        TemporaryFile,
    )

    from flutils.pathutils import chmod as _chmod


    # Test a single file
    with TemporaryFile('w') as tmp:
        tmp.write('test')
        tmp.close()
        _chmod(tmp.name, 0o640)
        assert oct(os.stat(tmp.name).st_mode)[-3:] == '640'

    # Test a directory
    with TemporaryDirectory() as tmp:
        with open(os.path.join(tmp, 'testfile'), 'w') as f:
            f.write('test')

        _chmod(tmp, 0o750)
        assert oct(os.stat(tmp).st_mode)[-3:] == '750'

# Generated at 2022-06-23 18:17:41.331727
# Unit test for function path_absent
def test_path_absent():
    test_path = Path(os.getcwd()) / 'tmp' / 'test_utilities' / 'flutils' / 'pathutils'
    test_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    test_file = test_path / 'test_file'
    test_file.touch()
    path_absent(test_file)



# Generated at 2022-06-23 18:17:51.916100
# Unit test for function chmod
def test_chmod():
    def call_chmod(path: str, mode_file: int = 0o660, mode_dir: int = 0o770) -> int:
        with tempfile.TemporaryDirectory() as tempdir:
            path = os.path.join(tempdir, path)
            chmod(path, mode_file, mode_dir)
            return os.stat(path).st_mode

    with tempfile.TemporaryDirectory() as tempdir:
        # Create a non-recursive file
        path = os.path.join(tempdir, 'test_chmod.txt')
        open(path, mode='a').close()
        assert oct(call_chmod(path, mode_file=0o660, mode_dir=0o770)) == '0o660'
        # Create a non-recursive directory

# Generated at 2022-06-23 18:17:58.927915
# Unit test for function normalize_path
def test_normalize_path():
    # pylint: disable=line-too-long
    """
    Test for normalize_path.
    """
    path = normalize_path('~/tmp/foo/../bar')
    assert path == Path(os.path.join(os.environ['HOME'], 'tmp', 'bar'))

    path2 = Path(os.path.join(os.environ['HOME'], 'tmp', 'bar'))
    path = normalize_path(path2)
    assert path == path2

    path = normalize_path('~/$USER/tmp/foo/../bar')
    assert path == Path(
        os.path.join(os.environ['HOME'], os.environ['USER'], 'tmp', 'bar')
    )


# Generated at 2022-06-23 18:18:06.860256
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == pwd.getpwuid(os.getuid())
    assert get_os_user(name=os.getuid()) == pwd.getpwuid(os.getuid())
    assert get_os_user(name=get_os_user().pw_name) == pwd.getpwuid(os.getuid())



# Generated at 2022-06-23 18:18:14.061511
# Unit test for function chown
def test_chown():
    import os
    from os.path import abspath, exists, isdir, join

    from flutils.pathutils import chown
    from flutils.osutils import get_os_user

    if not isdir('/tmp'):
        assert False, 'This system does not support /tmp.'

    d = '/tmp/foo'
    if exists(d):
        os.chdir('/tmp')
        os.rmdir('foo')

    os.mkdir(d)
    user = get_os_user()
    chown(d)

    assert abspath(d) == abspath(os.getcwd())
    assert isdir(d), f'{d} should exist!'
    assert user.pw_uid == os.stat(d).st_uid, 'UID should be the same!'
    assert user.pw

# Generated at 2022-06-23 18:18:26.479159
# Unit test for function find_paths
def test_find_paths():
    """Test the function: find_paths."""

    tmp_dir = str(tmp_path)
    Path(tmp_dir).mkdir(mode=0o700, parents=True)

    Path(os.path.join(tmp_dir, 'file_one')).touch()
    Path(os.path.join(tmp_dir, 'file_two')).touch()
    Path(os.path.join(tmp_dir, 'file_three')).touch()

    open(os.path.join(tmp_dir, 'file_four.py'), 'a').close()
    open(os.path.join(tmp_dir, 'file_five.json'), 'a').close()

    Path(os.path.join(tmp_dir, 'file_six.pyc')).touch()

# Generated at 2022-06-23 18:18:35.019402
# Unit test for function path_absent
def test_path_absent():
    from unittest.mock import patch
    from flutils.pathutils import path_absent

    test_dir = '/tmp/test_path'
    test_file = os.path.join(test_dir, 'test_file')

    os.makedirs(test_dir)
    with open(test_file, 'wt') as f:
        f.write('Test')
    os.chmod(test_dir, 0o700)

    with patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        with patch('os.path.islink') as mock_islink:
            mock_islink.return_value = True
            with patch('os.unlink') as mock_unlink:
                path_absent(test_dir)
                assert mock_

# Generated at 2022-06-23 18:18:45.926231
# Unit test for function directory_present
def test_directory_present():
    from tempfile import TemporaryDirectory
    from os import chmod
    from random import randrange
    from random import choice
    from string import ascii_lowercase

    choice_list = [
        0,
        1,
        2,
        3,
        4,
        5,
        6,
    ]
    a_path = '~/tmp/%s' % ''.join(choice(ascii_lowercase) for _ in range(20))
    a_path = Path(a_path).expanduser()
    with TemporaryDirectory() as tmp_path:
        tmp_path = Path(tmp_path)
        file_path = tmp_path / 'file'
        dir_path = tmp_path / 'dir'
        file_path.touch()
        if randrange(6) != 4:
            dir_

# Generated at 2022-06-23 18:18:48.479158
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()
    assert get_os_user(1001)
    assert get_os_user('foo')



# Generated at 2022-06-23 18:18:49.051006
# Unit test for function chmod
def test_chmod():
    pass


# Generated at 2022-06-23 18:18:49.596751
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:18:53.224274
# Unit test for function get_os_user
def test_get_os_user():
    os_user = get_os_user('root')
    assert type(os_user) is pwd.struct_passwd

    with pytest.raises(OSError):
        get_os_user(-1)

    with pytest.raises(OSError):
        get_os_user('this_name_does_not_exist')



# Generated at 2022-06-23 18:18:57.772259
# Unit test for function normalize_path
def test_normalize_path():
    actual_bytes = normalize_path(b'/home/foo/bar')
    expected = Path('/home/foo/bar')
    assert actual_bytes == expected
    assert type(actual_bytes) == type(expected)

    actual_str = normalize_path('/home/foo/bar')
    assert actual_str == expected
    assert type(actual_str) == type(expected)

    actual_posix = normalize_path(Path('/home/foo/bar'))
    assert actual_posix == expected
    assert type(actual_posix) == type(expected)


# Generated at 2022-06-23 18:19:01.373692
# Unit test for function get_os_group
def test_get_os_group():
    from flutils.pathutils import get_os_group #To get the current log name
    g = get_os_group()
    print(g.gr_gid)
    print(g.gr_name)
    print(g.gr_passwd)
    print(g.gr_mem)
    
    

# Generated at 2022-06-23 18:19:12.592233
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir_obj = Path(tmp_dir)
        file_one = tmp_dir_obj / 'file_one'
        file_two = tmp_dir_obj / 'file_two'

        dir_one = tmp_dir_obj / 'dir_one'
        dir_two = tmp_dir_obj / 'dir_two'
        dir_three = tmp_dir_obj / 'dir_three'

        file_one.touch()
        file_two.touch()

        dir_one.mkdir()
        dir_two.mkdir()
        dir_three.mkdir()

        search_paths = list(find_paths(tmp_dir_obj))
        search_paths.sort()


# Generated at 2022-06-23 18:19:23.217015
# Unit test for function chown

# Generated at 2022-06-23 18:19:32.243532
# Unit test for function exists_as
def test_exists_as():
    # pylint: disable=too-many-branches
    if os.name == 'nt':
        test_path = WindowsPath('C:\\Windows')
    else:
        test_path = Path('/tmp')

    # Create a Path object that is a directory that exists.
    assert exists_as(test_path.as_posix()) == 'directory'

    # Create a Path object that is a directory that exists.
    test_path = Path(tempfile.mkdtemp())
    assert exists_as(test_path.as_posix()) == 'directory'
    shutil.rmtree(test_path.as_posix())

    # Create a Path object that is a file that exists.
    test_path = Path(tempfile.mktemp())

# Generated at 2022-06-23 18:19:37.069420
# Unit test for function get_os_group
def test_get_os_group():
    assert 'bar' == get_os_group('bar').gr_name
    assert '*' == get_os_group('bar').gr_passwd
    assert 2001 == get_os_group('bar').gr_gid
    assert ['foo'] == get_os_group('bar').gr_mem



# Generated at 2022-06-23 18:19:49.213511
# Unit test for function normalize_path
def test_normalize_path():
    from flutils.pathutils import normalize_path
    assert normalize_path(b'/usr/tmp/foo/../bar').as_posix() == '/usr/tmp/bar'
    assert normalize_path('/usr/tmp/foo/../bar').as_posix() == '/usr/tmp/bar'
    assert normalize_path('usr/tmp/foo/../bar').as_posix() == 'usr/tmp/bar'
    assert normalize_path('foo/../bar').as_posix() == 'bar'
    assert normalize_path('..').as_posix() == '..'
    assert normalize_path('../..').as_posix() == '../..'
    assert normalize_path('../../foo').as_posix() == '../../foo'

# Generated at 2022-06-23 18:19:50.365024
# Unit test for function chown
def test_chown():
    assert callable(chown)



# Generated at 2022-06-23 18:19:59.266919
# Unit test for function normalize_path
def test_normalize_path():
    """Unit test for function normalize_path."""
    from flutils.pathutils import normalize_path
    cwd = os.getcwd()
    assert normalize_path('.').as_posix() == cwd
    assert normalize_path('/.').as_posix() == '/'
    assert normalize_path('/./').as_posix() == '/'
    assert normalize_path('/./..').as_posix() == '/'
    assert normalize_path('/./../').as_posix() == '/'
    assert normalize_path('./..').as_posix() == cwd.split(os.path.sep)[0]
    assert normalize_path('./../').as_posix() == cwd.split(os.path.sep)[0]

# Generated at 2022-06-23 18:20:07.524252
# Unit test for function find_paths
def test_find_paths():
    with tempfile.TemporaryDirectory() as tmpdir:
        abspath = Path(tmpdir)

        subdir = abspath / 'subdir'
        subdir.mkdir()

        file_one = abspath / 'file_one'
        file_one.touch()

        file_two = abspath / 'file_two.txt'
        file_two.touch()

        file_three = subdir / 'file_three.txt'
        file_three.touch()

        # Easy case
        assert list(find_paths(abspath.as_posix())) == [abspath]
        # Test absolute path
        assert list(find_paths(abspath.as_posix() + '/*')) == \
            [file_one, file_two, subdir]
        # Test relative path

# Generated at 2022-06-23 18:20:15.412355
# Unit test for function chmod
def test_chmod():
    import tempfile
    import os
    import shutil
    import stat

    # Setup
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 18:20:20.743613
# Unit test for function get_os_group
def test_get_os_group():
    # Non-existant gid.
    with pytest.raises(OSError):
        assert get_os_group(123)

    group = get_os_group()
    assert group.gr_gid == get_os_user().pw_gid



# Generated at 2022-06-23 18:20:32.069893
# Unit test for function chown
def test_chown():
    filename = '/tmp/flutils.tests.osutils.txt'
    with open(filename, 'w') as f:
        f.write('chown test')
    try:
        assert os.getuid() == chown(filename).st_uid
        assert os.getgid() == chown(filename).st_gid
        with pytest.raises(OSError):
            chown(filename, user='doesnotexist')
        with pytest.raises(OSError):
            chown(filename, group='doesnotexist')
        chown(filename, user=os.getuid())
        chown(filename, group=os.getgid())
    finally:
        os.remove(filename)



# Generated at 2022-06-23 18:20:44.793796
# Unit test for function chmod
def test_chmod():
    test_dir = '/tmp/flutils.tests.pathutils'
    test_file = '/tmp/flutils.tests.pathutils/flutils.tests.pathutils.txt'
    os.makedirs(test_dir, mode=0o700, exist_ok=True)
    with open(test_file, 'w') as f:
        f.write('')

    for p in [test_dir, test_file]:
        print(p, oct(os.stat(p).st_mode))
        chmod(p, mode_file=0o644, mode_dir=0o755)
        print(p, oct(os.stat(p).st_mode))

    chmod('/tmp/flutils.tests.pathutils/**', mode_file=0o664, mode_dir=0o775)
   

# Generated at 2022-06-23 18:20:46.406464
# Unit test for function get_os_user
def test_get_os_user():
    get_os_user('foo')



# Generated at 2022-06-23 18:20:56.819776
# Unit test for function exists_as
def test_exists_as():
    """Unit test for function exists_as."""
    from flutils.pathutils import exists_as, get_tmp_dir
    from flutils.systemutils import get_home_dir

    tmpdir = get_tmp_dir()
    existent_dir = get_home_dir()
    existent_file = existent_dir / 'Readme.md'
    existent_symlink = existent_dir / 'symlink.txt'
    nonexistent_path = existent_dir / 'missing.txt'

    assert (
        exists_as(existent_dir) == 'directory'
    ), 'Should return "directory" if "path" is a directory.'
    assert (
        exists_as(existent_file) == 'file'
    ), 'Should return "file" if "path" is a file.'

# Generated at 2022-06-23 18:21:00.740202
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == []



# Generated at 2022-06-23 18:21:06.050710
# Unit test for function get_os_group
def test_get_os_group():
    # NOTE: The login name and group name returned by this function
    #       depends on the operating system.
    print(get_os_group())
    assert get_os_group()
    assert get_os_group('-1')
    assert get_os_group(0)
    assert get_os_group('foo')
    assert get_os_group(2000)

# Generated at 2022-06-23 18:21:09.915465
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    import shutil
    path = Path(tempfile.mkdtemp())
    path = path / 'test_dir'
    path.mkdir()
    path = path / 'test_symlink'
    path.symlink_to('~test_dir', target_is_directory=True)
    path = path / 'test_tempfile'
    path.touch()
    path_absent(path.parent)
    assert path_absent(path.parent) is None
    assert path.parent.exists() is False
    assert path.exists() is False
    shutil.rmtree(path.parent.parent)



# Generated at 2022-06-23 18:21:10.483233
# Unit test for function directory_present
def test_directory_present():
    pass



# Generated at 2022-06-23 18:21:11.289745
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:21:16.421707
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~') == 'directory'
    assert exists_as('~/no_exist') == ''
    assert exists_as('~/.') == 'directory'
    assert exists_as('~/..') == 'directory'
    assert exists_as('/dev/null') == 'char device'

# Generated at 2022-06-23 18:21:18.506509
# Unit test for function path_absent
def test_path_absent():
    # Set up data for testing
    _path = Path('~') / 'tmp' / 'test_path'
    _path.mkdir(parents=True, exist_ok=True)
    assert _path.exists()
    # Run function
    path_absent(_path)
    # Evaluate results
    assert not _path.exists()



# Generated at 2022-06-23 18:21:25.778343
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(b'~/tmp/foo/../bar') == Path('~/tmp/bar')
    assert normalize_path(PosixPath('~/tmp/foo/../bar')) == Path('~/tmp/bar')
    assert normalize_path(WindowsPath('~/tmp/foo/../bar')) == Path('~/tmp/bar')
    assert normalize_path('~/tmp/foo/../bar') == Path('~/tmp/bar')

    os.environ['TEST_ENV'] = 'foobar'
    assert normalize_path('~/tmp/foo/$TEST_ENV/../bar') == Path('~/tmp/foo/foobar/../bar')
    del os.environ['TEST_ENV']


# Generated at 2022-06-23 18:21:33.120729
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group() is not None
    assert get_os_group('bar') is not None
    assert get_os_group(2001) is not None
    with pytest.raises(OSError):
        get_os_group('foo')
    with pytest.raises(OSError):
        get_os_group(1000)



# Generated at 2022-06-23 18:21:39.431993
# Unit test for function chmod
def test_chmod():
    from tempfile import gettempdir
    from flutils.pathutils import Path
    from flutils.pathutils import chmod

    tempdir = Path(gettempdir()).as_posix()
    path = Path(tempdir, 'flutils.tests.pathutils.txt').as_posix()
    mode = 0o400
    chmod(path, mode)
    assert Path(path).stat().st_mode & 0o777 == mode



# Generated at 2022-06-23 18:21:45.457823
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('~/flutils.tests') == 'directory'
    assert exists_as('~/flutils.tests/foo') == ''
    assert exists_as('~/flutils.tests/foo.txt') == ''
    assert exists_as('~/flutils.tests/osutils/test_exists_as.py') == 'file'
# /Unit test for function exists_as



# Generated at 2022-06-23 18:21:46.806293
# Unit test for function chmod
def test_chmod():
    chmod('/tmp/flutils.tests.pathutils.test_chmod.txt', 0o660)

# Generated at 2022-06-23 18:21:54.205568
# Unit test for function exists_as
def test_exists_as():
    """Test function exists_as()."""
    tmpdir = mkdtemp(prefix='flutils_')
    tmpdir_path = Path(tmpdir)
    # Make the temporary directory a symbolic link.
    os.rmdir(tmpdir)
    os.symlink('/bin', tmpdir)
    try:
        assert exists_as(tmpdir_path) == 'directory'
    finally:
        tmpdir_path.unlink()



# Generated at 2022-06-23 18:22:06.951601
# Unit test for function get_os_user

# Generated at 2022-06-23 18:22:16.757274
# Unit test for function find_paths
def test_find_paths():
    import pytest

    from tempfile import mkdtemp

    from flutils.pathutils import find_paths, walk_paths

    from tests.osutils import cd
    from tests.tempdir import TempDir

    # Create a temporary directory for testing.
    tmp_dir = mkdtemp()

    # Create a series of test paths.
    path_list = [
        '{0}/pytest.txt'.format(tmp_dir),
        '{0}/pytest.d'.format(tmp_dir),
        '{0}/pytest.d/pytest.txt'.format(tmp_dir),
        '{0}/pytest.d/pytest_2.txt'.format(tmp_dir),
        '{0}/.hidden/pytest.txt'.format(tmp_dir),
    ]

    # Create our

# Generated at 2022-06-23 18:22:20.235048
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('~/tmp/*')) == [
        Path('/Users/len/tmp/file_one.txt'),
        Path('/Users/len/tmp/dir_one')
    ]



# Generated at 2022-06-23 18:22:30.269515
# Unit test for function path_absent
def test_path_absent():
    assert exists_as('/tmp/test_path') == ''
    path_absent('/tmp/test_path')
    assert exists_as('/tmp/test_path') == ''

    os.makedirs('/tmp/test_path')
    try:
        assert exists_as('/tmp/test_path') == 'directory'
        path_absent('/tmp/test_path')
        assert exists_as('/tmp/test_path') == ''
    finally:
        shutil.rmtree('/tmp/test_path')

    with open('/tmp/test_path', 'w'):
        pass

# Generated at 2022-06-23 18:22:40.834339
# Unit test for function normalize_path
def test_normalize_path():
    # Test normalize_path simple string
    assert normalize_path('/usr/bin') == Path('/usr/bin')
    # Test normalize_path bytes
    assert normalize_path(b'/usr/bin') == Path('/usr/bin')
    # Test normalize_path Posix Path
    assert normalize_path(Path('/usr/bin')) == Path('/usr/bin')
    # Test normalize_path Windows Path
    assert normalize_path(WindowsPath('C:/Windows/System32')) == WindowsPath('C:/Windows/System32')
    # Test normalize_path with a ~
    assert normalize_path('~/tmp') == Path('/home/test_user/tmp')
    # Test normalize_path with an env variable

# Generated at 2022-06-23 18:22:45.237648
# Unit test for function path_absent
def test_path_absent():

    test_path = '/tmp/test_path'
    try:
        os.mkdir('/tmp/test_path')
    except FileExistsError:
        pass
    path_absent('/tmp/test_path')
    assert path_absent('/tmp/test_path') == None
    assert os.path.exists(test_path) != True
    assert os.path.exists('/tmp/test_path') != True


# Generated at 2022-06-23 18:22:50.031160
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path(Path.cwd()) == normalize_path(os.getcwd())
    assert normalize_path(b'.') == normalize_path(os.getcwd())
normalize_path.register(bytes, normalize_path)
normalize_path.register(PosixPath, normalize_path)
normalize_path.register(WindowsPath, normalize_path)



# Generated at 2022-06-23 18:22:56.962550
# Unit test for function path_absent
def test_path_absent():
    import tempfile
    test_path = Path(tempfile.mkdtemp())
    tp1 = test_path / 'foo1'
    tp1.mkdir()
    tp2 = tp1 / 'bar2'
    tp2.mkdir()
    tp3 = tp2 / 'blah3'
    tp3.mkdir()
    tp4 = tp2 / 'blah4'
    tp4.mkdir()
    tp5 = tp1 / 'bar5'
    tp5.mkdir()
    tp6 = tp2 / 'blah6'
    tp6.touch()
    path_absent(test_path)
    assert test_path.exists() is False

# Generated at 2022-06-23 18:22:57.494781
# Unit test for function get_os_group
def test_get_os_group():
    assert(get_os_group())



# Generated at 2022-06-23 18:22:57.940256
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:23:04.769820
# Unit test for function chown
def test_chown():
    # Poorman's mocking.  Used for testing.
    # If you need to change these for testing,
    # change the values here and run this test
    # along with the other tests.
    # Be sure to change them back!
    pwd.getpwnam = lambda u: pwd.struct_passwd([
        'root',
        '****',
        0,
        0,
        'root',
        '/root',
        '/bin/bash',
    ])
    grp.getgrnam = lambda g: grp.struct_group([
        'root',
        '****',
        0,
        ['root'],
    ])

    user = getpass.getuser()
    group = grp.getgrgid(pwd.getpwnam(user).pw_gid).gr_name
    ch

# Generated at 2022-06-23 18:23:13.540905
# Unit test for function exists_as
def test_exists_as():
    from tempfile import TemporaryDirectory
    from flutils.pathutils import exists_as

    with TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        tmp_file = tmp_dir / 'tmpfile.txt'
        tmp_file.touch()
        tmp_dir = directory_present(tmp_dir)
        assert exists_as(tmp_file) == 'file'
        assert exists_as(tmp_dir) == 'directory'

        tmp_symlink = tmp_dir / 'symlink'
        tmp_symlink.symlink_to(tmp_file)
        assert exists_as(tmp_symlink) == 'file'
        assert exists_as(tmp_dir) == 'directory'



# Generated at 2022-06-23 18:23:24.171996
# Unit test for function chmod
def test_chmod():
    """
    Unit test for function chmod
    """
    import pytest
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree

    path = Path(mkdtemp())
    _path = path / '___flutils.tests.osutils.txt'
    _path.touch()

    assert _path.exists() is True
    assert _path.is_file() is True
    assert _path.stat().st_mode & 0o777 == 0o600
    assert path.stat().st_mode & 0o777 == 0o700

    with pytest.raises(TypeError):
        chmod(_path, mode_file=1.1, mode_dir=1.1)

    chmod(_path, 0o660)
    _path.resolve()

# Generated at 2022-06-23 18:23:34.734181
# Unit test for function exists_as
def test_exists_as():
    from flutils.pathutils import directory_present
    from flutils.pathutils import exists_as

    tmp_dir = str(directory_present('~/tmp/flutils/osutils'))
    os.makedirs(os.path.join(tmp_dir, 'dir'), mode=0o755)
    os.makedirs(os.path.join(tmp_dir, 'fifo'), mode=0o755)
    os.makedirs(os.path.join(tmp_dir, 'char'), mode=0o755)
    os.makedirs(os.path.join(tmp_dir, 'block'), mode=0o755)
    os.makedirs(os.path.join(tmp_dir, 'socket'), mode=0o755)

# Generated at 2022-06-23 18:23:41.456589
# Unit test for function path_absent
def test_path_absent():
    with tempfile.TemporaryDirectory(prefix='flutils_test_') as workdir:
        tmpdir = Path(workdir)
        path = tmpdir / 'foo'
        path.mkdir()
        (path / 'tmp').mkdir()
        (path / 'tmp/foo').mkdir()
        (path / 'tmp/foo/tmp').mkdir()
        (path / 'tmp/foo/tmp/foo').mkdir()
        (path / 'tmp/foo/tmp/foo/tmp').mkdir()
        path_absent(path)
        assert not path.exists()


# Generated at 2022-06-23 18:23:52.653312
# Unit test for function directory_present
def test_directory_present():
    """Unit test for function directory_present."""
    try:
        import pytest
    except ImportError:
        pass   # Unit test should be run with pytest
    else:
        try:
            from pathlib import Path
        except ImportError:
            pass

# Generated at 2022-06-23 18:23:59.554377
# Unit test for function chown
def test_chown():
    directory_present('/tmp/flutils/pathutils.tests', mode=0o755)
    path = Path('/tmp/flutils/pathutils.tests/chown.txt')
    path.touch()
    chown(
        path.as_posix(),
        'root',
        group=427,
        include_parent=True
    )
    assert path.stat().st_uid == 0
    assert path.stat().st_gid == 427



# Generated at 2022-06-23 18:24:03.088039
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user('foo'), pwd.struct_passwd)
    assert isinstance(get_os_user(1001), pwd.struct_passwd)
    assert isinstance(get_os_user(), pwd.struct_passwd)


# Generated at 2022-06-23 18:24:05.153860
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user('foo')
    assert user.pw_uid == 1001



# Generated at 2022-06-23 18:24:06.567015
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user().pw_uid == os.geteuid()



# Generated at 2022-06-23 18:24:17.325872
# Unit test for function chmod
def test_chmod():
    import shutil
    from os.path import expanduser
    from tempfile import mkdtemp
    from flutils.pathutils import chmod

    temp_path = Path(mkdtemp())
    tmp_file = Path(expanduser('~/tmp/flutils.tests.osutils.txt'))
    path_to_file = Path(expanduser('~/tmp/flutils.tests.osutils'))

    # Make the temp directory and file
    temp_path.mkdir(parents=True, exist_ok=True)
    tmp_file.parent.mkdir(parents=True, exist_ok=True)
    tmp_file.touch()

# Generated at 2022-06-23 18:24:27.120270
# Unit test for function get_os_user
def test_get_os_user():
    if os.name == 'posix':
        assert get_os_user(-1).pw_name == 'nobody'
        assert get_os_user().pw_name == getpass.getuser()
        assert get_os_user('root').pw_uid == 0
        assert get_os_user(0).pw_name == 'root'
    elif os.name == 'nt':
        assert get_os_user(-1).pw_name == 'guest'
        assert get_os_user().pw_name == getpass.getuser()
        assert get_os_user('Administrator').pw_uid == 500
        assert get_os_user(500).pw_name == 'Administrator'



# Generated at 2022-06-23 18:24:32.067070
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(Path().cwd()) == 'directory'
    assert exists_as(Path(__file__)) == 'file'
    if os_name == WIN:
        assert exists_as(Path('C:\\')) == 'directory'
    else:
        assert exists_as(Path('/')) == 'directory'



# Generated at 2022-06-23 18:24:37.758064
# Unit test for function chown
def test_chown():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        p = Path(tmpdir, 'foo')
        p.touch()
        user_name = getpass.getuser()
        chown(p, user=user_name, include_parent=True)
        assert getpass.getuser() == user_name
        assert p.owner() == user_name

# Generated at 2022-06-23 18:24:48.029076
# Unit test for function directory_present
def test_directory_present():
    from tempfile import NamedTemporaryFile
    from unittest import mock
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    import sys
    import os

    # Posix
    # Test: Path already exists as a directory
    path = '/tmp/test_directory_present.txt'
    _open = mock_open(read_data='This is a test.')

# Generated at 2022-06-23 18:24:59.597352
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'

    if os.path.exists(path) is True:
        os.remove(path)
    if os.path.exists(path) is True:
        raise IOError('Could not remove {!r}'.format(path))
    if os.path.exists(path) is True:
        raise IOError('{!r} still exists.'.format(path))

    open(path, 'w').close()
    if os.path.exists(path) is False:
        raise IOError('{!r} was not created.'.format(path))

    # Test invalid mode_file and mode_dir
    err_msg = 'File mode must be a valid octal value'

# Generated at 2022-06-23 18:25:06.165904
# Unit test for function directory_present
def test_directory_present():
    import contextlib
    import os

    from pyfakefs.fake_filesystem_unittest import TestCase

    from flutils.pathutils import directory_present

    @contextlib.contextmanager
    def ChangeDir(path: str) -> Generator[None, None, None]:
        old_dir = os.getcwd()
        os.chdir(path)
        try:
            yield
        finally:
            os.chdir(old_dir)

    class DirectoryPresentTests(TestCase):
        """Tests for the directory_present function."""

        def setUp(self) -> None:
            super(DirectoryPresentTests, self).setUp()
            self.setUpPyfakefs()

        def test_directory_present(self) -> None:
            """Test creating a single directory."""

# Generated at 2022-06-23 18:25:09.863301
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user("root").pw_uid == pwd.getpwnam("root").pw_uid



# Generated at 2022-06-23 18:25:16.339793
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('root') == grp.struct_group(gr_name='root',
                                                    gr_passwd='*',
                                                    gr_gid=0,
                                                    gr_mem=[])
    assert get_os_group('bar') == grp.struct_group(gr_name='bar',
                                                   gr_passwd='*',
                                                   gr_gid=2001,
                                                   gr_mem=['foo'])



# Generated at 2022-06-23 18:25:17.678404
# Unit test for function chown
def test_chown():
    pass



# Generated at 2022-06-23 18:25:19.261904
# Unit test for function get_os_user
def test_get_os_user():
    from unittest.mock import patch

    assert get_os_user()



# Generated at 2022-06-23 18:25:21.442955
# Unit test for function get_os_user
def test_get_os_user():
    name = getpass.getuser()
    user_obj = get_os_user()
    assert isinstance(user_obj, tuple)
    assert user_obj.pw_name == name



# Generated at 2022-06-23 18:25:22.107725
# Unit test for function get_os_user
def test_get_os_user():
    r = get_os_user()
    print(r)


# Generated at 2022-06-23 18:25:31.194089
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from pathlib import Path
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as test_path:
        path = directory_present(os.path.join(test_path, 'lorem', 'ipsum'))
        assert isinstance(path, Path)
        assert path.exists() is True
        # Test recursive creation
        child = directory_present(
            os.path.join(path.as_posix(), 'dolor', 'sit')
        )
        assert child.exists() is True
        assert child.is_dir() is True
        # Test directory exists
        pth = directory_present(child)
        assert pth.exists() is True
        assert pth.is_dir() is True
        # Test build from path
        p

# Generated at 2022-06-23 18:25:34.426889
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('root')
    assert get_os_group(0)
    assert get_os_group(get_os_user().pw_gid)



# Generated at 2022-06-23 18:25:39.473391
# Unit test for function get_os_group
def test_get_os_group():
    assert get_os_group('foo') == grp.struct_group(
        gr_name='foo',
        gr_passwd='*',
        gr_gid=2000,
        gr_mem=['bar'],
    )



# Generated at 2022-06-23 18:25:46.171101
# Unit test for function chown
def test_chown():
    import shutil
    from tempfile import mkdtemp
    from flutils.pathutils import chown, normalize_path
    from flutils.osutils import get_os_user, get_os_group
    import os
    import stat

    user = get_os_user(os.getuid()).pw_name
    group = get_os_group(os.getgid()).gr_name

    tmp_path = Path(mkdtemp())

# Generated at 2022-06-23 18:25:57.896143
# Unit test for function chmod
def test_chmod():
    # You can set a variable to the return of a function...
    iam = os.system(
        'sh -c "chmod -v -R ugo+rX ~/tmp/flutils.tests.pathutils"')
    assert iam == 0
    iam = os.system('sh -c "chmod -v -R ugo-rwx ~/tmp/flutils.tests.pathutils"')
    assert iam == 0
    iam = os.system(
        'sh -c "chmod -v -R ugo+rw ~/tmp/flutils.tests.pathutils"')
    assert iam == 0
    # ...but you can still enter a command directly
    os.system('sh -c "chmod -v -R ugo-rwx ~/tmp/flutils.tests.pathutils"')
    # You can also

# Generated at 2022-06-23 18:26:08.435427
# Unit test for function directory_present
def test_directory_present():
    """Test the :obj:`~flutils.pathutils.directory_present`
    function.
    """
    path = str(Path(__file__).parent)
    test_path = Path(path, 'flutils', 'pathutils')

    test_root_path = Path(path, 'root')
    if test_root_path.exists():
        shutil.rmtree(str(test_root_path))
    test_root_path.mkdir()

    # Test present and set mode, user, and group.
    assert directory_present(
        test_path, mode=0o755, user='root', group='root'
    ) == test_path
    assert (
        PosixPath(__file__).stat().st_mode & 0o777 == 0o755
    )

# Generated at 2022-06-23 18:26:21.322539
# Unit test for function chmod
def test_chmod():
    _path = Path('./tmp/flutils.tests.osutils.txt')
    _cont_dir = Path('./tmp/flutils.tests.osutils.dir')
    _path.parent.mkdir(parents=True, exist_ok=True)
    _cont_dir.mkdir(parents=True, exist_ok=True)
    with open(_path, 'w') as f:
        f.write('')
    _cont_dir.joinpath('a').touch()
    _cont_dir.joinpath('b').touch()
    _cont_dir.joinpath('c').touch()
    _cont_dir.joinpath('d').touch()

    _mode = 0o666
    _dir_mode = 0o777

    chmod(_path, _mode, _dir_mode)

# Generated at 2022-06-23 18:26:22.337412
# Unit test for function chmod
def test_chmod():
    pass



# Generated at 2022-06-23 18:26:23.477747
# Unit test for function chown
def test_chown():
    assert True

# Generated at 2022-06-23 18:26:33.097049
# Unit test for function normalize_path
def test_normalize_path():
    """Unit testing for function normalize_path."""
    cur_path = os.getcwd()

    assert isinstance(normalize_path('~/foo'), Path)
    assert isinstance(normalize_path('foo/bar'), Path)
    assert isinstance(normalize_path('foo/../bar'), Path)
    assert isinstance(normalize_path('foo//bar'), Path)
    assert isinstance(normalize_path('foo/./bar'), Path)
    assert isinstance(normalize_path('foo/bar/').as_posix(), str)
    assert isinstance(normalize_path('/foo/bar').as_posix(), str)
    assert isinstance(normalize_path('/foo/bar/'), Path)
    assert isinstance(normalize_path('/foo/bar/.'), Path)