

# Generated at 2022-06-23 18:16:40.056530
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from os import PathLike
    from pathlib import Path
    import pwd
    import tempfile
    import textwrap

    # Create a temporary directory to be used for the tests
    tmp_dir = Path(tempfile.gettempdir(), 'test_directory_present')
    tmp_dir.mkdir(mode=0o700, exist_ok=True)

    # Create a temporary file to use in the tests
    tmp_file = Path(tempfile.gettempdir(), 'test_directory_present.txt')
    with tmp_file.open(mode='w', encoding='utf-8') as tmp_fh:
        tmp_fh.write('foo\n')
    os.chmod(tmp_file.as_posix(), 0o644)


# Generated at 2022-06-23 18:16:51.136641
# Unit test for function normalize_path
def test_normalize_path():
    assert callable(normalize_path)
    path = normalize_path('~/tmp/foo/../bar')
    assert path.as_posix() == os.path.join(os.path.expanduser('~'), 'tmp', 'bar')
normalize_path.register(bytes, lambda b: normalize_path(b.decode(sys.getfilesystemencoding())))
normalize_path.register(PosixPath, lambda p: normalize_path(p.as_posix()))
normalize_path.register(WindowsPath, lambda wp: normalize_path(wp.as_posix()))

# Generated at 2022-06-23 18:16:58.229721
# Unit test for function get_os_group
def test_get_os_group():
    with pytest.raises(OSError):
        get_os_group(name='foo2')
    with pytest.raises(OSError):
        get_os_group(name=202)
    assert get_os_group(name='bar') == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )
    assert get_os_group(name=2001) == grp.struct_group(
        gr_name='bar', gr_passwd='*', gr_gid=2001, gr_mem=['foo']
    )

# Generated at 2022-06-23 18:17:09.129117
# Unit test for function path_absent
def test_path_absent():
    from flutils.pathutils import path_absent
    path_absent('~/tmp/folder_one')
    with TemporaryDirectory(dir='~/tmp') as folder:
        os.mkdir(os.path.join(folder, 'folder_one'))
        os.mkdir(os.path.join(folder, 'folder_one', 'folder_two'))
        os.mkdir(os.path.join(folder, 'folder_one', 'folder_three'))
        with open(os.path.join(folder, 'folder_one', 'foo'), 'wt') as fp:
            fp.write('test')
        with open(os.path.join(folder, 'folder_one', 'folder_two', 'bar'), 'wt') as fp:
            fp.write('test')

# Generated at 2022-06-23 18:17:16.777566
# Unit test for function find_paths
def test_find_paths():
    with TempDir() as tmp_path:
        for path in tmp_path.glob('**'):
            path.unlink()

        tmp_path.joinpath('file_one').touch()
        tmp_path.joinpath('dir_one').mkdir()

        result = list(find_paths(str(tmp_path / '*')))

        assert tmp_path.joinpath('file_one') in result
        assert tmp_path.joinpath('dir_one') in result



# Generated at 2022-06-23 18:17:27.615856
# Unit test for function normalize_path

# Generated at 2022-06-23 18:17:33.259086
# Unit test for function directory_present
def test_directory_present():
    from flutils.pathutils import directory_present
    from flutils.pathutils import tmp_directory_present

    tmp_dir = tmp_directory_present()
    path = directory_present(tmp_dir / 'test_foo', mode=0o775)
    assert path == (tmp_dir / 'test_foo')



# Generated at 2022-06-23 18:17:39.067899
# Unit test for function get_os_user
def test_get_os_user():
    with pytest.raises(OSError):
        get_os_user(name='foo')
    try:
        pwd.getpwnam(name=getpass.getuser())
    except KeyError:
        pass
    else:
        result = get_os_user(name=None)
        assert isinstance(result, pwd.struct_passwd)


# Generated at 2022-06-23 18:17:41.498154
# Unit test for function exists_as
def test_exists_as():
    directory_present(TEST_DIR)
    assert exists_as(TEST_DIR) == 'directory'
    regular_file(TEST_FILE)
    assert exists_as(TEST_FILE) == 'file'
    delete_file(TEST_FILE)
    assert exists_as(TEST_FILE) == ''
    delete_directory(TEST_DIR, exclude_root=True)  # pragma: no cover



# Generated at 2022-06-23 18:17:42.877829
# Unit test for function get_os_group
def test_get_os_group():
    try:
        assert get_os_group('wheel').gr_name == 'wheel'
    except OSError:
        assert get_os_group(-1).gr_gid == -1



# Generated at 2022-06-23 18:17:51.688082
# Unit test for function chown
def test_chown():
    from textwrap import dedent
    from shutil import rmtree
    from flutils.pathutils import chown, normalize_path
    from flutils.tests.helpers import (
        assert_contents_equal,
        create_test_file,
        get_test_dir
    )

    path = normalize_path(os.path.join(
        get_test_dir(),
        'flutils',
        'tests',
        'pathutils',
        'chown'
    ))
    os.makedirs(path.as_posix())
    create_test_file(path)
    chown(path, user='foo', group='bar')

    # Make sure that chown() preserves the original mode.

# Generated at 2022-06-23 18:17:59.189795
# Unit test for function chmod
def test_chmod():
    path = '~/tmp/flutils.tests.osutils.txt'
    mode = 0o660
    chmod(path, mode)
    path = Path(path).expanduser()
    mode_oct = oct(mode)
    assert path.exists() is True
    assert path.is_file() is True
    assert path.stat().st_size == 0
    assert oct(path.stat().st_mode)[-3:] == mode_oct[-3:]



# Generated at 2022-06-23 18:18:12.648687
# Unit test for function path_absent
def test_path_absent():
    from contextlib import contextmanager
    from os import mkdir, remove
    from os.path import basename, dirname, join
    from pathlib import Path
    from shutil import copytree
    from tempfile import mkdtemp

    @contextmanager
    def determine_cwd():
        cwd = os.getcwd()

        try:
            yield
        finally:
            os.chdir(cwd)

    def tmpdir() -> str:
        """Return a name of a non-existent directory in the current
        directory.

        Raises:
            FileExistsError: If a unique temporary directory name could
                not be found.
        """
        counter = 0
        while True:
            tmp_dir = mkdtemp(prefix='flutils_test_')
            name = basename(tmp_dir)

# Generated at 2022-06-23 18:18:24.400331
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar').as_posix() \
        == os.path.join(os.path.expanduser('~'), 'tmp/bar')
    assert normalize_path(b'~/tmp/foo/../bar').as_posix() \
        == os.path.join(os.path.expanduser('~'), 'tmp/bar')
    assert normalize_path(
        Path(os.path.expanduser('~')) / 'tmp/foo/../bar'
    ).as_posix() == os.path.join(os.path.expanduser('~'), 'tmp/bar')
    assert normalize_path('~/tmp/foo/../bar').as_posix() is not '/tmp/bar'



# Generated at 2022-06-23 18:18:30.740822
# Unit test for function path_absent
def test_path_absent():
    path_to_del = Path(tempfile.mkdtemp(), 'to_del')
    path_to_del.mkdir()
    path_to_del.joinpath('sub').mkdir()
    path_to_del.joinpath('sub', 'subsub').mkdir()
    path_to_del.joinpath('subsubsub').mkdir()
    path_to_del.joinpath('subsubsubsub').mkdir()
    path_to_del.joinpath('subsubsubsub', 'subsubsubsubsub').mkdir()
    path_to_del.joinpath('subsubsubsubsubsub').mkdir()
    path_to_del.joinpath('subsubsubsubsubsubsub').mkdir()
    path_to_del.joinpath('subsubsubsubsubsubsubsub').mkdir()
   

# Generated at 2022-06-23 18:18:35.387213
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chown, exists_as
    path = normalize_path('~/tmp/flutils.tests.pathutils.txt')
    chown(path)
    assert exists_as(path)



# Generated at 2022-06-23 18:18:39.228097
# Unit test for function directory_present
def test_directory_present():
    directory_present('./tmp_dir')
    assert Path('./tmp_dir').exists()
    Path('./tmp_dir').rmdir()



# Generated at 2022-06-23 18:18:41.783091
# Unit test for function get_os_user
def test_get_os_user():
    # get_os_user(name: Optional[str] = None)
    get_os_user()
    get_os_user(0)
    get_os_user('foo')



# Generated at 2022-06-23 18:18:48.598931
# Unit test for function get_os_group
def test_get_os_group():
    test = get_os_group('foo')
    assert test.gr_name == 'foo'
    assert test.gr_passwd == '*'
    assert test.gr_gid == 1000
    assert test.gr_mem == ['bar']
    assert get_os_group().gr_name == 'root'
    assert get_os_group(1001).gr_name == 'bar'

# Generated at 2022-06-23 18:18:50.102902
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    playbook_teardown('test_chmod')



# Generated at 2022-06-23 18:18:56.644091
# Unit test for function find_paths
def test_find_paths():
    assert list(find_paths('/home/test_user/tmp')) == [
        PosixPath('/home/test_user/tmp')
    ]
    assert list(find_paths('/home/test_user/tmp/*')) == [
        PosixPath('/home/test_user/tmp/file_one'),
        PosixPath('/home/test_user/tmp/dir_one')
    ]

# Generated at 2022-06-23 18:19:07.199104
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/dev/null') == 'character device'
    assert exists_as('/dev/random') == 'character device'
    assert exists_as('/dev/zero') == 'character device'
    assert exists_as('/etc') == 'directory'
    assert exists_as('/tmp') == 'directory'
    assert exists_as('/bin/bash') == 'file'
    assert exists_as('/bin/cat') == 'file'
    assert exists_as('/bin/sh') == 'file'
    assert exists_as('/dev/console') == 'file'
    assert exists_as('/dev/tty') == 'file'
    assert exists_as('/dev/tty0') == 'file'
    assert exists_as('/dev/tty1') == 'file'

# Generated at 2022-06-23 18:19:15.101800
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('/proc/cpuinfo') == 'file'
    assert exists_as('/proc/1') == 'directory'
    assert exists_as('/dev/sda') == 'block device'
    assert exists_as('/dev/random') == 'char device'
    assert exists_as('/dev/pts/0') == 'FIFO'
    assert exists_as('/var/run/dbus/system_bus_socket') == 'socket'
    assert exists_as('/foo/bar/baz') == ''



# Generated at 2022-06-23 18:19:17.125196
# Unit test for function chmod
def test_chmod():
    chmod('~/tmp/flutils.tests.osutils.txt', 0o660)


# Generated at 2022-06-23 18:19:18.649192
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group()
    assert isinstance(group, grp.struct_group)
    assert group.gr_name is not None



# Generated at 2022-06-23 18:19:21.008218
# Unit test for function chown
def test_chown():
    return True


# Generated at 2022-06-23 18:19:23.170290
# Unit test for function normalize_path
def test_normalize_path():
    assert normalize_path('~/tmp/foo/../bar') == Path('/home/test_user/tmp/bar')



# Generated at 2022-06-23 18:19:31.885107
# Unit test for function directory_present
def test_directory_present():
    import shutil
    from tempfile import gettempdir
    from flutils.pathutils import directory_present as dp

    test_dir_temp = gettempdir()
    test_dir = os.path.join(test_dir_temp, 'test_dir_present')
    test_dir2 = os.path.join(test_dir_temp, 'test_dir_present2')

    if not os.path.exists(test_dir):
        os.mkdir(test_dir)

    assert dp(test_dir).as_posix() == test_dir

    assert dp(test_dir2).as_posix() == test_dir2

    shutil.rmtree(test_dir)
    shutil.rmtree(test_dir2)



# Generated at 2022-06-23 18:19:37.154544
# Unit test for function exists_as
def test_exists_as():
    assert exists_as('') == ''
    assert exists_as('blah') == ''
    assert exists_as('~/tmp') == 'directory'
    assert exists_as('~/tmp/flutils.tests.osutils.txt') == 'file'
    assert exists_as('~/flutils.tests.osutils.txt') == 'file'
    assert exists_as('/dev/null') == 'char device'



# Generated at 2022-06-23 18:19:43.018167
# Unit test for function path_absent
def test_path_absent():
    m = mock_open()
    with patch('builtins.open', m, create=True):
        path_absent('~/tmp/test_path')
        m.assert_called_with(
            os.path.normpath(
                os.path.expandvars(
                    os.path.expanduser(
                        os.path.join('~', 'tmp', 'test_path')
                    )
                )
            ),
            'w'
        )



# Generated at 2022-06-23 18:19:55.846051
# Unit test for function get_os_user
def test_get_os_user():
    user = get_os_user()

    if os.name == 'posix':
        assert isinstance(user, pwd.struct_passwd)
        assert isinstance(user.pw_name, str)
        assert isinstance(user.pw_passwd, str)
        assert isinstance(user.pw_uid, int)
        assert isinstance(user.pw_gid, int)
        assert isinstance(user.pw_gecos, str)
        assert isinstance(user.pw_dir, str)
        assert isinstance(user.pw_shell, str)

    try:
        user = get_os_user(name='a_bogus_user')
    except OSError:
        pass
    else:
        fail('OSError should have been raised.')


# Generated at 2022-06-23 18:20:07.544166
# Unit test for function chown
def test_chown():
    from io import StringIO
    from flutils.pathutils import chown
    from flutils.osutils import (
        capture_stdout,
        capture_stderr,
    )
    from flutils.tests.helpers import (
        TempDir,
        TempFile,
    )

    with TempDir() as tmp_dir:
        with TempFile(tmp_dir) as tmp_file:
            # Do nothing
            chown(tmp_file)

            # No globbing support
            with capture_stdout() as stdout:
                with capture_stderr() as stderr:
                    chown('foo')
            assert stdout.getvalue() == ''
            assert stderr.getvalue() != ''

            # With globbing

# Generated at 2022-06-23 18:20:11.764121
# Unit test for function path_absent
def test_path_absent():
    path = Path('/tmp/test_path')
    path.mkdir(mode=0o770, parents=True, exist_ok=True)
    path_absent(path)
    assert not path.exists()
    path = Path('/tmp/test_path')
    path.mkdir(mode=0o770, parents=True, exist_ok=True)
    path_absent(path)
    assert not path.exists()



# Generated at 2022-06-23 18:20:15.770833
# Unit test for function chmod
def test_chmod():
    assert chmod('~/tmp/flutils.tests.osutils.txt', 0o660) is None
    assert chmod('~/tmp/**', mode_file=0o644, mode_dir=0o770) is None
    assert chmod('~/tmp/*') is None

# Generated at 2022-06-23 18:20:18.216988
# Unit test for function get_os_group
def test_get_os_group():
    expected_name = 'bar'
    expected_passwd = '*'
    expected_gid = 2001
    expected_mem = ['foo']
    assert_equal(get_os_group(expected_name),
        grp.struct_group(gr_name=expected_name, gr_passwd=expected_passwd,
            gr_gid=expected_gid, gr_mem=expected_mem))



# Generated at 2022-06-23 18:20:31.802733
# Unit test for function path_absent
def test_path_absent():
    """ Unit tests for the function :mod:`pathutils.path_absent`. """

    class TestFunc(TestCase):
        """ Unit test class for :mod:`pathutils.path_absent`. """

        def test_path_absent(self):
            """ Test: :mod:`pathutils.path_absent`. """
            tmp_dir = Path(__file__).parent.joinpath('tmp')
            tmp_dir.mkdir(parents=True, exist_ok=True)
            test_dir = tmp_dir.joinpath('test_dir')
            test_dir.mkdir(exist_ok=True)
            test_file = tmp_dir.joinpath('test_file')
            test_file.touch()
            test_link = tmp_dir.joinpath('test_link')
            test_link.sy

# Generated at 2022-06-23 18:20:39.875676
# Unit test for function normalize_path
def test_normalize_path():
    """Functional test for function normalize_path()."""
    path = '~/tmp'
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = '~/tmp/../foo'
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = '~/tmp/foo/../bar'
    assert normalize_path(path).as_posix() == os.path.expanduser(path)
    path = '//tmp/../foo'

# Generated at 2022-06-23 18:20:41.076899
# Unit test for function find_paths
def test_find_paths():
    pass

# Generated at 2022-06-23 18:20:52.048059
# Unit test for function path_absent
def test_path_absent():
    """
    Unit test for function path_absent
    """

    from flutils.pathutils import path_absent
    from flutils.testutils import TempPath

    # Test with a missing path
    path = '/tmp/test_path'
    path_absent(path)

    # Test with a file path
    with TempPath() as tmp_pth:
        path = tmp_pth / 'tmp'
        path.write_text('*')
        assert path.exists()
        path_absent(path)
        assert not path.exists()

    # Test with a directory path
    with TempPath() as tmp_pth:
        path = tmp_pth / 'tmp'
        path.write_text('*')
        assert path.exists()
        assert path.is_file()
        path_abs

# Generated at 2022-06-23 18:21:01.121678
# Unit test for function find_paths
def test_find_paths():
    from . import TEST_PARENT_DIR
    from .pathutils import clean_dir

    TEST_DATA_DIR = Path(TEST_PARENT_DIR) / 'data'
    clean_dir(TEST_DATA_DIR)
    TEST_DATA_DIR.mkdir(parents=True, exist_ok=True)

    TEST_FILE_ONE = TEST_DATA_DIR / 'file_one'
    TEST_FILE_ONE.touch()

    TEST_DIR_ONE = TEST_DATA_DIR / 'dir_one'
    TEST_DIR_ONE.mkdir()

    assert set(find_paths(TEST_DATA_DIR / '*')) == \
           set(TEST_DIR_ONE.iterdir())

# Generated at 2022-06-23 18:21:04.837478
# Unit test for function get_os_user
def test_get_os_user():
    """Unit test for :obj:`get_os_user <flutils.pathutils.get_os_user>`."""
    with pytest.raises(OSError):
        get_os_user('foo')
    with pytest.raises(OSError):
        get_os_user(-1)



# Generated at 2022-06-23 18:21:06.718067
# Unit test for function exists_as
def test_exists_as():
    assert exists_as(os.path.expanduser('~')) == 'directory'



# Generated at 2022-06-23 18:21:08.274283
# Unit test for function directory_present
def test_directory_present():
    directory_present('test_dir_present')
    os.rmdir('test_dir_present')



# Generated at 2022-06-23 18:21:15.781900
# Unit test for function chown
def test_chown():
    from flutils.tests import run_test

    bad_group = 'does_not_exist'
    bad_user = 'does_not_exist'

    def test_func():
        try:
            chown('/does/not/exist', user=bad_user, group=bad_group)
        except OSError as ex:
            assert ex.filename == '/does/not/exist'

    def test_func_is_dir():
        chown('/', user=bad_user, group=bad_group)

    try:
        run_test(test_func)
    except OSError:
        pass

    # Changing ownership of / would cause an error
    # on startup for the unit test so we will
    # let this pass without asserting anything.
    run_test(test_func_is_dir)




# Generated at 2022-06-23 18:21:22.893947
# Unit test for function get_os_user
def test_get_os_user():
    try:
        pwd.getpwnam(getpass.getuser())
    except KeyError:
        pass
    else:
        assert get_os_user() == pwd.getpwnam(getpass.getuser())
    assert get_os_user(0) == pwd.getpwuid(0)
    assert get_os_user(1) == pwd.getpwuid(1)
    assert get_os_user(2) == pwd.getpwuid(2)



# Generated at 2022-06-23 18:21:26.705632
# Unit test for function chmod
def test_chmod():
    path = Path('/tmp/flutils.tests.osutils.txt')
    path.touch()
    mode = path.stat().st_mode
    chmod(path, 0o660)
    assert path.stat().st_mode & 0o777 == 0o660
    path.unlink()
    assert path.exists() is False



# Generated at 2022-06-23 18:21:39.433027
# Unit test for function directory_present
def test_directory_present():
    """Test the function directory_present.

    """
    path = normalize_path('~/tmp/test_path')
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True

    path = normalize_path('~/tmp/test_path/test_child_directory')
    directory_present(path)
    assert path.exists() is True
    assert path.is_dir() is True

    mode = 0o755
    path = normalize_path('~/tmp/test_path')
    directory_present(path, mode=mode)
    assert path.stat().st_mode == mode

    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name

# Generated at 2022-06-23 18:21:45.243511
# Unit test for function exists_as
def test_exists_as():
    from flutils.randomutils import random_string
    from flutils.pathutils import directory_present
    with TempDir() as tmp:
        # Test for when the path does NOT exist.
        _path = tmp.path.joinpath(random_string())
        _type = exists_as(_path)
        assert _type == ''

        # Test for when the path is a directory.
        _path = directory_present(tmp.path.joinpath(random_string()))
        _type = exists_as(_path)
        assert _type == 'directory'

        # Test for when the path is a file.
        _path = tmp.path.joinpath(random_string())
        _path.touch()
        _type = exists_as(_path)
        assert _type == 'file'

        # Test for when the path is a block device.

# Generated at 2022-06-23 18:21:51.925973
# Unit test for function get_os_group
def test_get_os_group():
    for path in find_paths('~/tmp/*'):
        if path.is_dir():
            if path.name == 'dir_one':
                assert get_os_group(path.stat().st_gid).gr_name == 'foo'
                assert get_os_group(path.stat().st_gid).gr_gid == 2001
            elif path.name == 'dir_two':
                assert get_os_group(path.stat().st_gid).gr_name == 'bar'
                assert get_os_group(path.stat().st_gid).gr_gid == 2000
            else:
                assert get_os_group(path.stat().st_gid).gr_name == 'foobar'
                assert get_os_group(path.stat().st_gid).gr_gid

# Generated at 2022-06-23 18:21:59.353788
# Unit test for function find_paths
def test_find_paths():
    import os
    import stat
    import tempfile

    from typing import Generator

    from flutils.pathutils import find_paths  # noqa W0611

    tmp_dir = os.path.join(tempfile.gettempdir(), 'test_find_path')
    mkdir_f(tmp_dir)

    # Create a file and a directory.
    org_scope = os.getcwd()
    file_path = os.path.join(tmp_dir, 'file_path')
    file_handle = open(file_path, mode='w')
    file_handle.close()
    dir_path = os.path.join(tmp_dir, 'dir_path')
    os.mkdir(dir_path)
    os.chmod(dir_path, mode=stat.S_IRWXU)
    os

# Generated at 2022-06-23 18:22:12.009273
# Unit test for function chown
def test_chown():
    from flutils.pathutils import chmod, chown, get_os_group, get_os_user

    user = getpass.getuser()
    group = grp.getgrgid(os.getgid()).gr_name

    test_filename = 'flutils.tests.osutils_test_chown.txt'
    test_file_path = normalize_path(f'/tmp/{test_filename}')

    # Test a single path that is a file
    with test_file_path:
        chmod(test_file_path.as_posix(), mode_file=0o644, mode_dir=0o770)
        chown(test_file_path.as_posix())

        assert test_file_path.exists() is True

# Generated at 2022-06-23 18:22:15.734463
# Unit test for function find_paths
def test_find_paths():
    from flutils.pathutils import find_paths
    pattern = './tests/*'

    expected = ['./tests/test_pathutils.py', './tests/__init__.py']
    results = [r.as_posix() for r in find_paths(pattern)]
    assert results == expected



# Generated at 2022-06-23 18:22:26.033776
# Unit test for function get_os_user
def test_get_os_user():
    import pwd
    assert pwd.struct_passwd(pw_name='foo', pw_passwd='********', pw_uid=1001,
         pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo',
         pw_shell='/usr/local/bin/bash') == get_os_user('foo')
    assert pwd.struct_passwd(pw_name='foo', pw_passwd='********', pw_uid=1001,
         pw_gid=2001, pw_gecos='Foo Bar', pw_dir='/home/foo',
         pw_shell='/usr/local/bin/bash') == get_os_user(1001)

# Generated at 2022-06-23 18:22:35.540390
# Unit test for function chmod
def test_chmod():
    from flutils.pathutils import chmod
    from textwrap import dedent

    # Create a temporary directory for testing.
    with tempfile.TemporaryDirectory() as tdir:

        # Create a symlink to a temporary file.
        tfile = Path(tdir) / 'tmpfile.txt'
        with tfile.open('w') as fh:
            fh.write('Hello World!')
        link = Path(tdir) / 'tmpfile_link'
        link.symlink_to(tfile)

        # Create a temporary directory.
        subdir = Path(tdir) / 'subdir'
        subdir.mkdir()

        # Create a temporary file.
        subfile = Path(tdir) / 'subdir/file.txt'

# Generated at 2022-06-23 18:22:46.217995
# Unit test for function find_paths
def test_find_paths():
    """Unit test for function find_paths."""
    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        test_dir = tmpdir.joinpath('test')
        test_dir.touch()
        test_dir.mkdir(exist_ok=True)
        test_dir = test_dir.resolve()
        test_dir.mkdir()
        file_one = test_dir.joinpath('file_one')
        file_one.touch()
        dir_one = test_dir.joinpath('dir_one')
        dir_one.mkdir()
        dir_two = test_dir.joinpath('dir_two')
        dir_two.mkdir()
        file_two = dir_two.joinpath('file_two')
        file_two.touch()


# Generated at 2022-06-23 18:22:49.793107
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user()
    assert get_os_user('')
    assert get_os_user([]).pw_name
    assert get_os_user(get_os_user().pw_name).pw_name
    assert get_os_user(get_os_user().pw_uid).pw_name


# Generated at 2022-06-23 18:23:01.138324
# Unit test for function exists_as
def test_exists_as():
    # Test for a directory.
    path = Path('/tmp')
    assert exists_as(path) == 'directory'

    # Test for a file.
    path = Path('/etc/passwd')
    assert exists_as(path) == 'file'

    # Test for a block device.
    path = Path('/dev/sda')
    assert exists_as(path) == 'block device'

    # Test for a character device.
    path = Path('/dev/console')
    assert exists_as(path) == 'char device'

    # Test for a fifo.
    path = Path('/dev/fd/0')
    assert exists_as(path) == 'FIFO'

    # Test for a symbolic link pointing to a directory.
    path = Path('/var/tmp')

# Generated at 2022-06-23 18:23:09.956633
# Unit test for function chown
def test_chown():
    if getpass.getuser() == 'root':
        import shutil
        tmpdir = Path(os.environ['TMPDIR'])
        user = getpass.getuser()
        group = grp.getgrnam(user).gr_name
        dir_path = tmpdir / 'ut_chown'

        dir_path.mkdir(mode=0o777, parents=True, exist_ok=True)
        dir_path_2 = dir_path / '2'
        dir_path_2.mkdir(mode=0o777, exist_ok=True)
        assert os.stat(dir_path.as_posix()).st_uid == 0
        assert os.stat(dir_path.as_posix()).st_gid == 0

# Generated at 2022-06-23 18:23:22.384757
# Unit test for function directory_present
def test_directory_present():
    import shutil
    import tempfile
    from flutils.pathutils import exists_as
    from pathlib import Path

    def test_path(
            path: Path,
            mode_dir: Optional[int] = None,
            mode_file: Optional[int] = None,
    ) -> None:
        assert path.exists() is True
        assert path.is_dir() is True

        if mode_dir is not None:
            assert path.stat().st_mode & 0o777 == mode_dir
        else:
            assert path.stat().st_mode & 0o777 == 0o700

        if mode_file is not None:
            assert exists_as(path / 'test_file.txt') == 'file'
            assert path.joinpath('test_file.txt').stat().st_mode & 0o777 == mode

# Generated at 2022-06-23 18:23:29.790182
# Unit test for function get_os_group
def test_get_os_group():
    from os import getuid
    from os import setuid
    from os import getgroups

    test_user = 'test_user'
    test_group = 'test_group'
    test_groupid = 2001

    if isinstance(getgroups()[0], int) is True:
        get_os_group_expected = grp.struct_group(
            gr_name=test_group,
            gr_passwd='*',
            gr_gid=test_groupid,
            gr_mem=['test_user'],
        )
    else:
        get_os_group_expected = grp.struct_group(
            gr_name=test_group,
            gr_passwd='*',
            gr_gid=test_groupid,
            gr_mem=[b'test_user'],
        )



# Generated at 2022-06-23 18:23:31.819220
# Unit test for function get_os_user
def test_get_os_user():
    assert get_os_user() == get_os_user(get_os_user().pw_name)


# Generated at 2022-06-23 18:23:44.015557
# Unit test for function normalize_path
def test_normalize_path():
    with pytest.raises(TypeError):
        normalize_path(False)
    with pytest.raises(TypeError):
        normalize_path(1)
    with pytest.raises(TypeError):
        normalize_path(None)
    assert normalize_path('/foo/bar') == Path('/foo/bar')
    assert normalize_path('/foo/bar').is_absolute() is True
    assert normalize_path('Foo/Bar') == Path('Foo/Bar')
    assert normalize_path('Foo/Bar').is_absolute() is False
    assert normalize_path('~') == os.path.expanduser('~')
    assert normalize_path('~foo') == os.path.expanduser('~foo')
    assert normalize_path('~foo/bar')

# Generated at 2022-06-23 18:23:52.883093
# Unit test for function find_paths
def test_find_paths():
    """Test function find_paths"""
    with TemporaryDirectory() as tmp_dir:
        tmp_dir_path = Path(tmp_dir)
        file_one_path = tmp_dir_path / 'file_one'
        file_one_path.touch()
        dir_one_path = tmp_dir_path / 'dir_one'
        dir_one_path.mkdir()
        pattern = Path(tmp_dir) / '*'
        paths = list(find_paths(pattern))
        assert file_one_path in paths
        assert dir_one_path in paths



# Generated at 2022-06-23 18:24:01.724138
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as path:
        expected = Path(path).joinpath('test')
        expected.touch()

        chmod(expected, 0o660)
        assert expected.stat().st_mode == 33152

        chmod(Path(path).joinpath('*'), 0o755, include_parent=True)
        assert expected.stat().st_mode == 33024

        expected.mkdir(parents=True)
        expected.joinpath('test.txt').touch()
        assert expected.stat().st_mode == 16832

        chmod(expected.joinpath('**'), 0o777)
        assert expected.stat().st_mode == 16832

        assert expected.joinpath('test.txt').stat().st_mode == 33279



# Generated at 2022-06-23 18:24:08.867979
# Unit test for function chown
def test_chown():
    import tempfile
    import shutil

    test_dir = Path(tempfile.mkdtemp(), 'recursive')
    dir_owner = getpass.getuser()
    dir_group = grp.getgrgid(pwd.getpwnam(dir_owner).pw_gid).gr_name


# Generated at 2022-06-23 18:24:13.868677
# Unit test for function find_paths
def test_find_paths():
    # In order to provide a reproducible test, we need to use fixed
    # directory and files.
    tmpdir = tmpdir_factory.mktemp('test-pathutils')
    os.chdir(tmpdir.strpath)

    # Create a test directory.
    path = Path().home() / 'tmp' / 'test_path'
    path.mkdir(parents=True, exist_ok=True)

    # Create two files in the test directory.
    with path.joinpath('file_one').open('w') as f:
        f.write('File One')
    path.joinpath('file_two').touch()

    # Create two directories in the test directory.
    path.joinpath('dir_one').mkdir()
    path.joinpath('dir_two').mkdir()

    # Find all the files and directories in

# Generated at 2022-06-23 18:24:22.805490
# Unit test for function chmod
def test_chmod():
    from flutils.tests import get_test_file_path
    from flutils.pathutils import chmod
    from shutil import rmtree
    from tempfile import mkdtemp
    tmp_dir = Path(mkdtemp())
    tmp_file = tmp_dir / 'test.txt'
    with tmp_file.open('wt') as out_file:
        out_file.write('hello world')
    chmod(tmp_file, mode_file=0o600)
    saved_path = Path(get_test_file_path('test_chmod.txt'))
    try:
        assert tmp_file.stat().st_mode == saved_path.stat().st_mode
    finally:
        rmtree(str(tmp_dir))



# Generated at 2022-06-23 18:24:26.749138
# Unit test for function get_os_user
def test_get_os_user():
    assert isinstance(get_os_user(), pwd.struct_passwd)
    assert isinstance(get_os_user(1000), pwd.struct_passwd)
    assert isinstance(get_os_user('root'), pwd.struct_passwd)



# Generated at 2022-06-23 18:24:32.019004
# Unit test for function normalize_path
def test_normalize_path():
    path = '~/tmp/foo/../bar'
    value = normalize_path(path)
    assert value == Path('/home/test_user/tmp/bar')
    assert isinstance(value, Path)


normalize_path.register(Path, normalize_path)



# Generated at 2022-06-23 18:24:43.432109
# Unit test for function get_os_user
def test_get_os_user():
    """Test function get_os_user

    Expected results:

    1. If given no arguments, the return value is a
       :obj:`struct_passwd <pwd>` for the current user.
    2. If given a valid "login name" return value is a
       :obj:`struct_passwd <pwd>`.
    3. If given a valid ``uid``, return value is a
       :obj:`struct_passwd <pwd>`.
    4. If given an invalid "login name", raise an OSError.
    5. If given an invalid ``uid``, raise an OSError.

    """
    assert get_os_user() == get_os_user(getpass.getuser())
    user = get_os_user(getpass.getuser())

# Generated at 2022-06-23 18:24:52.058908
# Unit test for function chmod
def test_chmod():
    """Unit test for function chmod.
    """

    # Test with a directory with a glob pattern
    original_mode = 0o700
    path = '~/tmp/**'
    mode_dir = 0o600
    chmod(path, mode_dir=mode_dir)
    for sub_path in Path().glob(path.as_posix()):
        assert sub_path.stat().st_mode == original_mode

    # Test with a file with a glob pattern
    original_mode = 0o600
    path = '~/tmp/flutils.tests.osutils.txt'
    mode_file = 0o660
    chmod(path, mode_file=mode_file)
    for sub_path in Path().glob(path.as_posix()):
        assert sub_path.stat().st_mode == original

# Generated at 2022-06-23 18:25:01.924322
# Unit test for function chmod
def test_chmod():
    import tempfile

    path = Path(tempfile.mkdtemp(prefix='flutils.tests.osutils.chmod.'))

    # Create a file and a directory for testing purposes.
    path_file = path / 'file.txt'
    path_file.write_text('This is a file!')

    path_dir = path / 'directory'
    path_dir.mkdir()

    # Test normally.
    chmod(path_file, 0o755)
    chmod(path_dir, 0o755)
    assert path_file.stat().st_mode == 0o100755
    assert path_dir.stat().st_mode == 0o40755
    chmod(path_file, 0o644)
    chmod(path_dir, 0o755)
    assert path_file.stat().st_mode == 0

# Generated at 2022-06-23 18:25:03.639731
# Unit test for function directory_present
def test_directory_present():
    directory_present('/tmp/directory_present_test')



# Generated at 2022-06-23 18:25:11.237323
# Unit test for function chmod
def test_chmod():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpfile = tmpdir / 'flutils.tests.osutils.txt'
        tmpfile.touch()
        chmod(tmpfile, stat.S_IRGRP | stat.S_IWUSR | stat.S_IRUSR)
        mode = tmpfile.stat().st_mode
        assert stat.S_IRGRP | stat.S_IWUSR | stat.S_IRUSR == mode



# Generated at 2022-06-23 18:25:20.579821
# Unit test for function path_absent
def test_path_absent():
    from flutils.testutils import TempDir
    from flutils.pathutils import path_absent
    from flutils.pathutils import path_directory
    from flutils.pathutils import path_file
    from flutils.pathutils import full_path_s
    from pathlib import Path
    import os
    import tempfile
    import unittest

    class TestPathAbsent(unittest.TestCase):

        def setUp(self) -> None:
            self.addCleanup(self.tempdir.cleanup)
            self.tempdir = TempDir()

        def test_file(self) -> None:
            path = Path(self.tempdir.directory, 'tmpfile.txt')
            path_absent(path=path)
            path_file(path=path)

# Generated at 2022-06-23 18:25:30.213180
# Unit test for function find_paths
def test_find_paths():
    assert [str(p) for p in find_paths('~/tmp/*')] == ['~/tmp/file_one', '~/tmp/dir_one']
    assert [str(p) for p in find_paths('~/tmp/**')] == ['~/tmp/file_one', '~/tmp/dir_one', '~/tmp/dir_one/testfile3.txt', '~/tmp/dir_one/testfile2.txt', '~/tmp/dir_one/testfile1.txt']
    assert [str(p) for p in find_paths('~/tmp/dir_one/testfile2.txt')] == ['~/tmp/dir_one/testfile2.txt']



# Generated at 2022-06-23 18:25:41.261690
# Unit test for function chmod
def test_chmod():
    import stat
    import tempfile

    fd, tmp_path = tempfile.mkstemp()
    tmp_dir = Path(tmp_path).parent
    tmp_parent = tmp_dir.parent

    # Test that non-existent path will not raise exception
    chmod(tmp_dir / 'fake')

    # Test that a single file is correctly changed
    chmod(tmp_path, 0o644)
    assert stat.S_IMODE(os.lstat(tmp_path).st_mode) == 0o644

    # Test that a single directory is correctly changed
    chmod(tmp_dir, 0o755)
    assert stat.S_IMODE(os.lstat(tmp_dir).st_mode) == 0o755

    # Test that glob pattern works (recursively)

# Generated at 2022-06-23 18:25:43.957155
# Unit test for function get_os_group
def test_get_os_group():
    group = get_os_group()
    assert isinstance(group, grp.struct_group)
    assert get_os_group() == grp.getgrgid(os.getuid())
    assert get_os_group(os.getuid()) == get_os_group()



# Generated at 2022-06-23 18:25:44.759258
# Unit test for function get_os_user
def test_get_os_user():
  return get_os_user('foo')


# Generated at 2022-06-23 18:25:57.468037
# Unit test for function find_paths
def test_find_paths():
    with changes_dir('/tmp'):
        paths = (
            Path('find_paths/tmp_dir_one'),
            Path('find_paths/tmp_dir_two'),
            Path('find_paths/tmp_file_one'),
            Path('find_paths/tmp_file_two'),
            Path('find_paths/tmp_file_three')
        )
        for path in paths:
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if path.is_file() is False:
                path.mkdir(mode=0o700, parents=True, exist_ok=True)
            else:
                path.touch(mode=0o600, exist_ok=True)
        patt = '/tmp/find_paths/*'
        res

# Generated at 2022-06-23 18:26:08.029034
# Unit test for function path_absent
def test_path_absent():
    # Create a temporary directory to hold the test data.
    with tempfile.TemporaryDirectory() as temp_dir:
        path = Path(temp_dir)
        # Create a file and a directory to test with.
        file_one = path.joinpath('file_one')
        file_one.write_text('')
        dir_one = path.joinpath('dir_one')
        dir_one.mkdir(mode=0o644)
        file_two = dir_one.joinpath('file_two')
        file_two.write_text('')

        # The 'file_one' path should exist.
        assert exists_as(file_one) == 'file'

        # The directory 'dir_one' should exist.
        assert exists_as(dir_one) == 'directory'

        # The 'file_

# Generated at 2022-06-23 18:26:15.502406
# Unit test for function get_os_user
def test_get_os_user():
    """Unit tests for function :obj:`get_os_user`."""
    assert get_os_user().pw_name == getpass.getuser()
    assert get_os_user(os.getuid()).pw_name == getpass.getuser()
    assert get_os_user(os.getuid()).pw_uid == os.getuid()



# Generated at 2022-06-23 18:26:22.983241
# Unit test for function normalize_path
def test_normalize_path():
    """Test to make sure all the code paths are tested."""
    from_home = '~/tmp'

    # Test the PathLike cases.
    assert normalize_path(os.fsencode(from_home)) == Path(
        os.path.expanduser(from_home)
    )
    assert normalize_path(Path(from_home)) == Path(
        os.path.expanduser(from_home)
    )

    # Test the str cases.
    assert isinstance(normalize_path(from_home), Path)

    tmp_dir = '%s' % tempfile.TemporaryDirectory(  # type: ignore
        prefix='test_normalize_path_'
    )
    os.chdir(tmp_dir)

# Generated at 2022-06-23 18:26:33.055339
# Unit test for function chown
def test_chown():
    import os
    import tempfile
    from flutils.pathutils import Path
    from flutils.pathutils import chmod
    from flutils.pathutils import chown
    from flutils.pathutils import get_os_group

    group = get_os_group()
    username = getpass.getuser()

    with tempfile.TemporaryDirectory() as path:
        path = Path(path)
        file_path = path / 'flutils.tests.pathutils.txt'
        file_path.touch()

        # Test chown a single file
        chown(file_path, user=username, group=group.gr_name)

        assert os.stat(file_path).st_uid == os.getuid()
        assert os.stat(file_path).st_gid == group.gr_gid

        # Test ch