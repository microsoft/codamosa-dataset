

# Generated at 2022-06-24 17:08:50.462757
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=123456, minutes=24, seconds=59, microseconds=123456
    )) == '123456:24:59.123456'


# Generated at 2022-06-24 17:09:00.134752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('05:09:19.263928') == datetime_module.timedelta(hours=5, minutes=9, seconds=19, microseconds=263928)
    assert timedelta_parse('-05:09:19.263928') == datetime_module.timedelta(hours=-5, minutes=-9, seconds=-19, microseconds=-263928)
    assert timedelta_parse('0:1:2.1') == datetime_module.timedelta(seconds=62, microseconds=100000)


# Generated at 2022-06-24 17:09:09.958579
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=12)))) == '00:00:12.000000'
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=12, microseconds=5)))) == '00:00:12.000005'
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(minutes=2, seconds=12, microseconds=5)))) == '00:02:12.000005'
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=12, minutes=2, seconds=12, microseconds=5))))

# Generated at 2022-06-24 17:09:12.991387
# Unit test for function timedelta_format
def test_timedelta_format():
    set_1 = datetime_module.timedelta(1)
    var_1 = timedelta_format(set_1)
    assert var_1 == '00:00:00.000000'
    set_2 = {'hours': 0, 'microseconds': 0, 'seconds': 0, 'days': 0, 'minutes': 0}
    var_2 = timedelta_format(set_2)


# Generated at 2022-06-24 17:09:16.618225
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:34:56.789012') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789012
    )

# Generated at 2022-06-24 17:09:20.133861
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:25:45.000000') == datetime_module.timedelta(hours=3, minutes=25, seconds=45)

# Generated at 2022-06-24 17:09:27.041431
# Unit test for function timedelta_format
def test_timedelta_format():
    expected = '00:00:00.000000'
    computed = timedelta_format(datetime_module.timedelta(microseconds=0))
    assert computed is not expected
    assert computed == expected, (expected, computed)
    expected = '00:00:01.100100'
    computed = timedelta_format(datetime_module.timedelta(microseconds=1100100))
    assert computed is not expected
    assert computed == expected, (expected, computed)


# Generated at 2022-06-24 17:09:37.705395
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse("00:00:00.100000") == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse("00:00:01.100000") == datetime_module.timedelta(0, 1, 100000)
    assert timedelta_parse("00:01:01.100000") == datetime_module.timedelta(0, 61, 100000)

# Generated at 2022-06-24 17:09:50.194797
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == '00:00:00.999999'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=59, microseconds=1)) == '00:00:59.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=59, microseconds=1)) == '00:01:59.000001'

# Generated at 2022-06-24 17:09:54.908489
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Make sure a timedelta can be parsed that way."""
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:10:08.633542
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Example Nr. 0
#    print('Running test #0')
    var_0 = timedelta_parse('00:00:00.000000')
    assert isinstance(var_0, datetime_module.timedelta)
    assert var_0 == datetime_module.timedelta(seconds=0)

    # Example Nr. 1
#    print('Running test #1')
    var_0 = timedelta_parse('00:00:00.000001')
    assert isinstance(var_0, datetime_module.timedelta)
    assert var_0 == datetime_module.timedelta(microseconds=1)

    # Example Nr. 2
#    print('Running test #2')
    var_0 = timedelta_parse('00:00:01.000000')

# Generated at 2022-06-24 17:10:16.965062
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Raise exception when not enough arguments are passed
    with pytest.raises(TypeError):
        timedelta_parse()
    # Raise exception for invalid types for argument s
    with pytest.raises(TypeError):
        timedelta_parse(null)
    # Raise exception for invalid types for argument s
    with pytest.raises(TypeError):
        timedelta_parse(null, null, null)
    # Raise exception for invalid types for argument s
    with pytest.raises(TypeError):
        timedelta_parse(null, null)
    # Raise exception for invalid types for argument s
    with pytest.raises(TypeError):
        timedelta_parse(null)
    # Raise exception for invalid types for argument s
    with pytest.raises(TypeError):
        timedelta_parse(None)
# test_

# Generated at 2022-06-24 17:10:25.200752
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(2) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=33333)) == \
                                                           '01:00:00.03333'
    assert timedelta_format(datetime_module.timedelta(days=2,
                                                      minutes=333,
                                                      seconds=3,
                                                      microseconds=555)) == \
                                                           '48:06:03.000555'


# Generated at 2022-06-24 17:10:38.269253
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test when s == '':
    assert timedelta_parse('') == datetime_module.timedelta()
    # Test when s == '0:00:00.000000':
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    # Test when s == '00:00:00.000000':
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    # Test when s == '0:0:0.0':
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    # Test when s == '00:00:00':
    assert timedelta_parse('00:00:00') == datetime_module.timedelta()

# Generated at 2022-06-24 17:10:39.411754
# Unit test for function timedelta_parse
def test_timedelta_parse():
    set_0 = set()
    assert timedelta_parse(set_0) == set_0

# Generated at 2022-06-24 17:10:52.209216
# Unit test for function timedelta_format
def test_timedelta_format():
    #
    # Happy path test
    #
    # Case where parameters are valid
    #
    case_0_expected_result = '00:00:00.000000'
    case_0_actual_result = timedelta_format(datetime_module.timedelta(0))
    assert case_0_actual_result == case_0_expected_result
    #
    # Sad path test
    #
    # Case where parameters are invalid
    #
    case_1_expected_result = NotImplementedError
    case_1_actual_result = timedelta_format(None, 'not_microseconds')
    try:
        assert case_1_actual_result == case_1_expected_result
    except AssertionError:
        print('Expected: ', case_1_expected_result)

# Generated at 2022-06-24 17:11:03.387130
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1, microseconds=300000))) == datetime_module.timedelta(seconds=1, microseconds=300000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1, seconds=1, microseconds=5))) == datetime_module.timedelta(minutes=1, seconds=1, microseconds=5)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=5))) == datetime_module

# Generated at 2022-06-24 17:11:08.346231
# Unit test for function timedelta_parse
def test_timedelta_parse():
    set_0 = set()
    var_0 = timedelta_parse(set_0)

# Generated at 2022-06-24 17:11:10.227107
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(seconds=0, microseconds=0)




# Generated at 2022-06-24 17:11:21.029400
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('1.1')) == '00:00:01.100000'
    assert timedelta_format(timedelta_parse('1.11')) == '00:00:01.110000'
    assert timedelta_format(timedelta_parse('1.111')) == '00:00:01.111000'
    assert timedelta_format(timedelta_parse('1:1')) == '01:00:01.000000'

# Generated at 2022-06-24 17:11:34.554220
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = timedelta_parse('0:0:0.060000')


# Generated at 2022-06-24 17:11:36.640631
# Unit test for function timedelta_format
def test_timedelta_format():
    # Make sure it doesn't raise any exception
    set_0 = set()
    timedelta_format(set_0)


# Generated at 2022-06-24 17:11:38.523299
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = timedelta_parse(set_0)




# Generated at 2022-06-24 17:11:41.252756
# Unit test for function timedelta_format
def test_timedelta_format():
    set_60 = set()
    assert timedelta_format(set_60) == '00:00:00.000000'



# Generated at 2022-06-24 17:11:52.081548
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000999') == datetime_module.timedelta(microseconds=999)
    assert timedelta_parse('00:00:00.000999') == datetime_module.timedelta(microseconds=999)
    assert timedelta_parse('00:00:00.000999') == datetime_module.timedelta(microseconds=999)
    assert timedelta_parse('00:00:00.000999') == datetime_module.timedelta(microseconds=999)

# Generated at 2022-06-24 17:12:01.105900
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=-3,
                                                      microseconds=-4)) == \
           '01:02:57.999996'


# Generated at 2022-06-24 17:12:09.378563
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # test 1
    expected_value = datetime_module.timedelta(days=30, hours=0, minutes=0, seconds=0, microseconds=0)
    actual_value   = timedelta_parse('720:00:00:00.000000')
    assert expected_value == actual_value, 'Expected: {!r}, Actual: {!r}'.format(expected_value, actual_value)
    # test 2
    expected_value = datetime_module.timedelta(days=0, hours=0, minutes=10, seconds=0, microseconds=0)
    actual_value   = timedelta_parse('00:10:00:00.000000')
    assert expected_value == actual_value, 'Expected: {!r}, Actual: {!r}'.format(expected_value, actual_value)
   

# Generated at 2022-06-24 17:12:18.074912
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-24 17:12:20.469290
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse(str_0)
    timedelta_parse(str_1)


# Generated at 2022-06-24 17:12:27.719986
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_set = [
        ('00:00:00.0', 0),
        ('00:00:00.1', 1),
        ('00:10:00.0', 600000),
        ('01:00:00.0', 3600000),
        ('01:01:01.010101', 3666101),
        ('23:59:59.999999', 86399999),
    ]
    for string, expected in test_set:
        actual = timedelta_parse(string)
        assert actual == datetime_module.timedelta(microseconds=expected)



# Generated at 2022-06-24 17:12:48.239178
# Unit test for function timedelta_format
def test_timedelta_format():
    set_0 = set()
    var_0 = timedelta_format(set_0)
    assert var_0 == '00:00:00.000000'
    import datetime
    set_1 = datetime.timedelta(seconds=576)
    var_1 = timedelta_format(set_1)
    assert var_1 == '00:09:36.000000'
    set_2 = datetime.timedelta(hours=1, minutes=2, seconds=3,
                             microseconds=400000)
    var_2 = timedelta_format(set_2)
    assert var_2 == '01:02:03.400000'



# Generated at 2022-06-24 17:12:51.207457
# Unit test for function timedelta_parse
def test_timedelta_parse():
    set_0 = set()
    var_0 = timedelta_parse(set_0)

# Generated at 2022-06-24 17:13:04.294069
# Unit test for function timedelta_format
def test_timedelta_format():
    # A tuple of Python objects representing the positional arguments to
    # timedelta_format.
    args = ()
    # A tuple of strings representing the expected type of the positional
    # arguments to timedelta_format after conversion.
    arg_types = ()
    # A mapping from argument names to their values.
    kwargs = {}
    # The expected return value from the call to timedelta_format.
    expected = None
    # Call timedelta_format:
    result = timedelta_format(*args, **kwargs)
    # Check the result against expected:
    assert result == expected, ('timedelta_format gave ' + repr(result) +
                                ', expected ' + repr(expected))
    # Check the type of each positional argument after conversion against
    # the expected type:

# Generated at 2022-06-24 17:13:06.224912
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == set()

# Generated at 2022-06-24 17:13:10.324254
# Unit test for function timedelta_format
def test_timedelta_format():
    from datetime import timedelta
    
    timedelta_0 = timedelta(minutes=30, hours=1, seconds=30)
    var_0 = timedelta_format(timedelta_0)
    var_1 = '01:30:30.000000'
    assert (var_0 == var_1)


# Generated at 2022-06-24 17:13:16.804754
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)

# Generated at 2022-06-24 17:13:26.010619
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Test for exception raised for type-mismatch
    try:
        timedelta_parse(0)
        raise AssertionError()
    except AssertionError:
        AssertionError("Exception not raised for invalid \"s\" type")

    # Test for exception raised for invalid negative numbers
    try:
        timedelta_parse(-1)
        raise AssertionError()
    except ValueError:
        pass

    # Test for exception raised for invalid string with dots and colons
    try:
        timedelta_parse(':.:')
        raise AssertionError()
    except ValueError:
        pass

    # Test for exception raised for invalid string with too few elements
    try:
        timedelta_parse('1:1')
        raise AssertionError()
    except ValueError:
        pass

    # Test for exception raised for

# Generated at 2022-06-24 17:13:26.990066
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert '00:00:00.000000' == timedelta_parse('00:00:00.000000')


# Generated at 2022-06-24 17:13:36.102185
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=0, seconds=0, microseconds=0)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=2, seconds=0, microseconds=0)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=1, microseconds=0)) == '00:00:01.000000'

# Generated at 2022-06-24 17:13:39.303163
# Unit test for function timedelta_format
def test_timedelta_format():
    set_0 = timedelta_format(timedelta_parse("00:00:01.000001"))
    assert set_0 is not None


# Generated at 2022-06-24 17:13:54.564134
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)

# Generated at 2022-06-24 17:14:08.196989
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                                      microseconds=5)) == '26:03:04.000005'
    assert timedelta_format(datetime_module.timedelta(hours=5)) == '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=999)) == '00:00:00.000999'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-24 17:14:09.963211
# Unit test for function timedelta_parse
def test_timedelta_parse():
    set_0 = timedelta_parse(const_0)

    assert set_0 == const_1

# Generated at 2022-06-24 17:14:20.917605
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1, microseconds=1)) == '01:01:01.000001'

# Generated at 2022-06-24 17:14:22.277666
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()



# Generated at 2022-06-24 17:14:24.967767
# Unit test for function timedelta_parse
def test_timedelta_parse():
    pass
    #print ""
    #print '---'
    #print 'timedelta_parse'
    #print timedelta_parse()


# Generated at 2022-06-24 17:14:36.242979
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        (
            datetime_module.timedelta(),
            '00:00:00.000000'
        ),
        (
            datetime_module.timedelta(days=2),
            '48:00:00.000000'
        ),
        (
            datetime_module.timedelta(days=2, hours=3, minutes=4, seconds=5,
                                      microseconds=6),
            '51:04:05.000006'
        ),
    ]
    for case in cases:
        assert timedelta_parse(timedelta_format(case[0])) == case[0]
        assert timedelta_parse(timedelta_format(case[0]).replace('.', ':')) == case[0]


if __name__ == '__main__':
    test_timed

# Generated at 2022-06-24 17:14:42.556012
# Unit test for function timedelta_format
def test_timedelta_format():
    # Check if set_0 is a set.
    assert isinstance(set_0, set)
    # Check if var_0 is a string.
    assert isinstance(var_0, str)
    # Check if var_0 is equal to string_0.
    assert var_0 == '00:00:00.000000'



# Generated at 2022-06-24 17:14:47.254312
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        datetime_module.timedelta(0, 0, 0)
        test_case_0()
    except TypeError:
        print("1. Test Timedelta format function. TypeError: missing or un-named arguments.")
        return False
    except Exception:
        print("1. Test Timedelta format function. Exception: other errors.")
        return False
    print("1. Test Timedelta format function. type is correct")
    return True


# Generated at 2022-06-24 17:14:53.612971
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('34:54:23.123421') == datetime_module.timedelta(
        hours=34, minutes=54, seconds=23,
        microseconds=123421
    )


if __name__ == '__main__':

    if sys.version_info >= (3, 6):
        assert time_isoformat(datetime_module.time(12, 2, 3, 456)) == (
            '12:02:03.004560'
        )
    else:
        assert time_isoformat(datetime_module.time(12, 2, 3, 456)) == (
            '12:02:03.000456'
        )


# Generated at 2022-06-24 17:15:20.100236
# Unit test for function timedelta_format
def test_timedelta_format():
    if 5:
        set_0 = set()
        var_0 = timedelta_format(set_0)
        assert var_0 == '00:00:00.000000', 'actual {}'.format(var_0)
    if 9:
        set_0 = datetime_module.timedelta(hours=5, minutes=9, seconds=9, microseconds=9)
        var_0 = timedelta_format(set_0)
        assert var_0 == '05:09:09.000009', 'actual {}'.format(var_0)
    if 8.0:
        set_0 = datetime_module.timedelta(hours=8.0, minutes=0.0, seconds=0.0, microseconds=0.0)
        var_0 = timedelta_format(set_0)
        assert var_

# Generated at 2022-06-24 17:15:26.087230
# Unit test for function timedelta_format
def test_timedelta_format():
    example_0 = datetime_module.timedelta(0, 13612, 87655)
    expected_result_0 = '00:03:56.087655'
    actual_result_0 = timedelta_format(example_0)
    assert actual_result_0 == expected_result_0
    assert True


# Generated at 2022-06-24 17:15:30.415507
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        test_case_0()
    except AssertionError as e:
        msg = 'Got AssertionError, expected None\nGot: AssertionError'
        assert False, msg + '\n' + str(e)

# vim: et sw=4 sts=4

# Generated at 2022-06-24 17:15:33.854284
# Unit test for function timedelta_parse
def test_timedelta_parse():
    set_0 = set()
    var_0 = timedelta_parse(set_0)
    assert set_0 == var_0



# Generated at 2022-06-24 17:15:42.624099
# Unit test for function timedelta_parse
def test_timedelta_parse():
    string = '00:00:00.000000'
    assert timedelta_parse(string) == datetime_module.timedelta(0)
    string = '01:01:01.010000'
    assert timedelta_parse(string) == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10000)

# Generated at 2022-06-24 17:15:51.910692
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'


# Generated at 2022-06-24 17:15:57.678304
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1, 0)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60, 0)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600, 0, 0)

# Generated at 2022-06-24 17:16:04.796720
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test if the iso format parses back correctly to the original time
    t = datetime_module.datetime.now()
    str_0 = timedelta_format(t.time())
    t_0 = datetime_module.datetime.strptime(str_0,'%H:%M:%S.%f')
    assert t_0.time() == t.time()


# Generated at 2022-06-24 17:16:06.833076
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()

# Generated at 2022-06-24 17:16:15.629857
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    timedelta object format
    '''
    a_set = datetime_module.timedelta()
    a_str = timedelta_format(a_set)
    assert a_str == '00:00:00.000000'
    a_set = datetime_module.timedelta(seconds=1, microseconds=1)
    a_str = timedelta_format(a_set)
    assert a_str == '00:00:01.000001'
    a_set = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    a_str = timedelta_format(a_set)
    assert a_str == '24:00:01.000001'



# Generated at 2022-06-24 17:16:49.708175
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test with no time
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                          '00:00:00.000000'

    # Test with only one field
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                          '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=12, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                          '12:00:00.000000'

# Generated at 2022-06-24 17:16:51.328806
# Unit test for function timedelta_format
def test_timedelta_format():
    expected = '00:00:00.000000'
    set_0 = set()
    var_0 = timedelta_format(set_0)
    assert var_0 == expected


# Generated at 2022-06-24 17:16:54.562443
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(9, 12, 45)) == '00:00:09.000012'



# Generated at 2022-06-24 17:16:58.661981
# Unit test for function timedelta_parse
def test_timedelta_parse():
    input_1 = "0:00:00.000000"
    expected_output = datetime_module.timedelta(0, 0)
    actual_output = timedelta_parse(input_1)
    assert actual_output == expected_output


# Generated at 2022-06-24 17:17:06.979852
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test if function timedelta_format is callable (if needed)
    try:
        timedelta_format
    except NameError:
        return
    
    # Test if function timedelta_format raises errors or fails when arguments
    # have incorrect types (if needed)
    #var_0 = timedelta_format(lambda str: None) # TypeError
    #var_1 = timedelta_format(datetime_module.datetime.now()) # TypeError
    
    # Test if function timedelta_format raises errors or fails when arguments
    # number is incorrect (if needed)
    #var_2 = timedelta_format(datetime_module.timedelta(0)) # TypeError
    #var_3 = timedelta_format(datetime_module.timedelta(0), timespec='milliseconds', timespec='microseconds') #

# Generated at 2022-06-24 17:17:12.992761
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:59:59.999999') == datetime_module.timedelta(minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999)

# Generated at 2022-06-24 17:17:18.266259
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:02:03.004005') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4005
    )

# Generated at 2022-06-24 17:17:26.813237
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 0, 1)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(0, 0, 0, 999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(0, 1, 999999)

# Generated at 2022-06-24 17:17:33.146243
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('12:34:56.654321')) == '12:34:56.654321'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == '23:59:59.999999'


# Generated at 2022-06-24 17:17:36.395899
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    from . import expect
    
    answer = timedelta_format(1)
    expect(answer, '00:00:00.000001')
