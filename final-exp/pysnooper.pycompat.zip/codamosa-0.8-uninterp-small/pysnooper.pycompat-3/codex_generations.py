

# Generated at 2022-06-24 17:08:54.661921
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1)) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'

# Generated at 2022-06-24 17:08:57.218143
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    :type str_0: timedelta
    :rtype: bool
    '''

    str_0 = 'IL5'
    var_0 = timedelta_parse(str_0)
    var_1 = str_0 == var_0
    return var_1

# Generated at 2022-06-24 17:08:58.794931
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = 'IL5'
    var_0 = timedelta_parse(str_0)
    assert isinstance(var_0, datetime_module.timedelta)



# Generated at 2022-06-24 17:09:08.258790
# Unit test for function timedelta_format
def test_timedelta_format():
    s = datetime_module.timedelta(days=1, hours=23, minutes=59, seconds=58,
                                  microseconds=123456)
    assert timedelta_format(s) == '23:59:58.123456'
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-24 17:09:12.365505
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .compatibility import timedelta_parse
    from .compatibility import timedelta_format
    for n in range(-10000,10000):
        seconds = n * 0.01
        timedelta = datetime_module.timedelta(seconds=seconds)
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta


# Generated at 2022-06-24 17:09:15.832064
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Arrange
    str_0 = '0:00:00.000000'
    var_0 = timedelta_parse(str_0)

    # Assert
    assert var_0 == datetime_module.timedelta()

# Generated at 2022-06-24 17:09:25.563474
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
           '02:03:04.000005'
    assert timedelta_format(datetime_module.timedelta(seconds=4,
                                                      microseconds=5)) == \
           '00:00:04.000005'
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=5)) == \
           '00:00:00.000005'
test_timedelta_format()


# Generated at 2022-06-24 17:09:37.883907
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:21:31.387000') == datetime_module.timedelta(days=2, hours=21, minutes=31, seconds=31, microseconds=387000)
    assert timedelta_parse('3:3:3.3') == datetime_module.timedelta(hours=3, minutes=3, seconds=3, microseconds=300000)
    assert timedelta_parse('0:0:0:0.00') == datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('0:0:0:0.01') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:0:0:0.1') == datetime_module.timedelta(microseconds=100)

# Generated at 2022-06-24 17:09:50.316204
# Unit test for function timedelta_format
def test_timedelta_format():
    assert  timedelta_format(timedelta_parse("1:01:01.010101")) == "01:01:01.010101"
    assert  timedelta_format(timedelta_parse("0:0:0.123456")) == "00:00:00.123456"
    assert  timedelta_format(timedelta_parse("10:29:59.999999")) == "10:29:59.999999"
    assert  timedelta_format(timedelta_parse("2:2:2.02")) == "02:02:02.020000"
    assert  timedelta_format(timedelta_parse("0:1:1.01")) == "00:01:01.010000"

# Generated at 2022-06-24 17:09:57.940096
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
                            datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00:000001') == \
                            datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000000') == \
                            datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01:000000') == \
                            datetime_module.timedelta(seconds=1)
    assert timed

# Generated at 2022-06-24 17:10:11.012610
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4000)) == \
           '01:02:03.004000'

# Generated at 2022-06-24 17:10:19.370068
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(0, 0, 123456)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:00:59.999999') == datetime_module.timedelta(0, 59, 999999)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)

# Generated at 2022-06-24 17:10:26.848780
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(
        datetime_module.time(hour=2, minute=45, second=33, microsecond=678912),
        timespec='microseconds'
    )
    if sys.version_info[:2] >= (3, 6):
        # This is weird. It will give the same result, but Python 3.6's will
        # not have the leading zeros. The leading zeros are necessary for
        # parsing (`timedelta_parse`).
        assert time == '02:45:33.678912' or time == '2:45:33.678912'
    else:
        assert time == '02:45:33.678912'


# Generated at 2022-06-24 17:10:33.603080
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=13)) == '00:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=13.37)) == '00:00:13.370000'
    assert timedelta_format(datetime_module.timedelta(seconds=3613)) == '01:00:13.000000'


# Generated at 2022-06-24 17:10:42.057790
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=10)) == \
           '00:00:01.000010'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1,
                                                      seconds=1,
                                                      microseconds=10)) == \
           '00:01:01.000010'

# Generated at 2022-06-24 17:10:55.875123
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    if __name__ == '__main__':
        test_timedelta_parse()
    """
    timedelta_0 = timedelta_parse('00:00:00.000010')
    assert timedelta_0.microseconds == 10
    timedelta_0 = timedelta_parse('00:00:00.000100')
    assert timedelta_0.microseconds == 100
    timedelta_0 = timedelta_parse('00:00:00.001000')
    assert timedelta_0.microseconds == 1000
    timedelta_0 = timedelta_parse('00:00:00.010000')
    assert timedelta_0.microseconds == 10000
    timedelta_0 = timedelta_parse('00:00:00.100000')
    assert timedelta_0.microseconds == 100000
    timedelta_0

# Generated at 2022-06-24 17:11:04.748985
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(seconds=0.25, microseconds=750000)
    ) == '00:00:00.257500'
    assert timedelta_format(
        datetime_module.timedelta(seconds=0.25, microseconds=1)
    ) == '00:00:00.000001'
    assert timedelta_format(
        datetime_module.timedelta(seconds=0, microseconds=99)
    ) == '00:00:00.000099'

# Generated at 2022-06-24 17:11:08.797586
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=30,
                                                      seconds=20,
                                                      microseconds=45000)) == \
           '02:30:20.045000'
    
    

# Generated at 2022-06-24 17:11:18.423253
# Unit test for function timedelta_format
def test_timedelta_format():
    # assert timedelta_format(datetime_module.timedelta(hours=1)) ==
    # '01:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=10)
    ) == '01:10:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=10, seconds=29)
    ) == '01:10:29.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=10, seconds=29,
                                  microseconds=234)
    ) == '01:10:29.000234'

# Generated at 2022-06-24 17:11:26.654370
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.0100000000000') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1, 0)
    assert timedelta_parse('00:00:01.001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta

# Generated at 2022-06-24 17:11:51.488076
# Unit test for function timedelta_format
def test_timedelta_format():
    test_cases = [
        timedelta_parse('0:0:0.000000'),
        timedelta_parse('0:0:0.000001'),
        timedelta_parse('0:0:0.222222'),
        timedelta_parse('0:0:1.333333'),
        timedelta_parse('0:1:2.444444'),
        timedelta_parse('1:2:3.555555'),
        timedelta_parse('23:59:59.999999'),
        timedelta_parse('23:59:60.000000'), # Allow for leap seconds
    ]
    for timedelta in test_cases:
        assert timedelta_format(timedelta) == timedelta_format(timedelta)



# Generated at 2022-06-24 17:11:59.274083
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1, 0)) == '24:00:01.000000'


# Generated at 2022-06-24 17:12:08.643519
# Unit test for function timedelta_parse

# Generated at 2022-06-24 17:12:14.129064
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-24 17:12:21.497528
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'



# Generated at 2022-06-24 17:12:36.330208
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:0:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.00001') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.0001') == datetime_module.timedelta(microseconds=100)

# Generated at 2022-06-24 17:12:47.330752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:00.01') == dat

# Generated at 2022-06-24 17:12:55.373081
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(seconds=0.01)
    assert timedelta_format(timedelta_0) == time_isoformat(
        (datetime_module.datetime.min + timedelta_0).time(),
        timespec='microseconds'
    )
    timedelta_1 = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta_1) == time_isoformat(
        (datetime_module.datetime.min + timedelta_1).time(),
        timespec='microseconds'
    )

# Generated at 2022-06-24 17:13:00.600404
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    ) == '01:02:03.000004'


# Generated at 2022-06-24 17:13:03.718874
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('01:04:17.123456')) == \
           '01:04:17.123456'




# Generated at 2022-06-24 17:13:52.705302
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_roundtrip(timedelta):
        s = timedelta_format(timedelta)
        r = timedelta_parse(s)
        assert r == timedelta
    assert_roundtrip(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                               microseconds=0))
    assert_roundtrip(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                               microseconds=1))
    assert_roundtrip(datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                               microseconds=0))
    assert_roundtrip(datetime_module.timedelta(hours=0, minutes=1, seconds=0,
                                               microseconds=0))

# Generated at 2022-06-24 17:13:56.963415
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5.5)) == '00:00:05.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'


# Generated at 2022-06-24 17:14:10.134172
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(microseconds=1000000)
    assert timedelta_parse

# Generated at 2022-06-24 17:14:21.084115
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(
        milliseconds=100
    )
    assert timedelta_parse('00:00:01.000') == datetime_module.tim

# Generated at 2022-06-24 17:14:25.198935
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse("00:00:00.000001")

    milliseconds = timedelta.seconds * 1000 + timedelta.microseconds / 1000
    assert milliseconds == 1


if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-24 17:14:34.434137
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00:000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00:000001') == datetime_module.timedelta(microseconds=1)


# Generated at 2022-06-24 17:14:46.099791
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=19, minutes=28,
                                                      seconds=36,
                                                      microseconds=524)) == \
           '19:28:36.000524'
    assert timedelta_format(datetime_module.timedelta(hours=19, minutes=28,
                                                      seconds=36,
                                                      microseconds=0)) == \
           '19:28:36.000000'
    assert timedelta_format(datetime_module.timedelta(hours=19, minutes=28,
                                                      seconds=36)) == \
           '19:28:36.000000'

# Generated at 2022-06-24 17:14:58.686874
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('0:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('0:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-24 17:15:04.625068
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      microseconds=7)) == '04:05:06.000007'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      milliseconds=7)) == '04:05:06.007000'

# Generated at 2022-06-24 17:15:17.959606
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('0:01:01.000001') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=1
    )
    assert timedelta_parse('1:01:01.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )


# Generated at 2022-06-24 17:16:41.442130
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('0:0:0.000001')
    assert timedelta.microseconds == 1



# Generated at 2022-06-24 17:16:47.500460
# Unit test for function timedelta_format
def test_timedelta_format():
    from .time import time_module
    test_timedelta = datetime_module.timedelta(seconds=1,
                                               microseconds=100)
    assert timedelta_format(test_timedelta) == '00:00:01.000100'

    assert timedelta_format(time_module.time_to_timedelta(0.01)) == \
           '00:00:00.010000'


# Generated at 2022-06-24 17:16:53.875188
# Unit test for function timedelta_parse
def test_timedelta_parse():
    equal = datetime_module.timedelta(hours=1, minutes=3, seconds=2, microseconds=4)
    abc_equal = timedelta_parse(timedelta_format(equal))
    abc_equal_str = timedelta_format(abc_equal)
    assert abc_equal_str == "01:03:02.000004"

# Generated at 2022-06-24 17:17:00.100979
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(microseconds=100001)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:01.000000') == \
           datetime_module.timedelta(hours=1, seconds=1)


# Generated at 2022-06-24 17:17:11.160812
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_parse_works(s, expected):
        assert timedelta_parse(s) == expected
        time = timedelta_parse(s).total_seconds()
        assert time_isoformat(datetime_module.time(time=time),
                              timespec='microseconds') == s
        assert timedelta_format(timedelta_parse(s)) == s

    assert_timedelta_parse_works('00:00:00.000000',
                                 datetime_module.timedelta(seconds=0,
                                                           microseconds=0))
    assert_timedelta_parse_works('00:00:00.000001',
                                 datetime_module.timedelta(seconds=0,
                                                           microseconds=1))

# Generated at 2022-06-24 17:17:23.399459
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = timedelta_parse('00:00:00.000000')
    assert isinstance(timedelta_0, datetime_module.timedelta)
    assert timedelta_0 == datetime_module.timedelta(0)
    if PY3:
        timedelta_1 = timedelta_parse(b'00:00:00.000000')
        assert isinstance(timedelta_1, datetime_module.timedelta)
        assert timedelta_1 == datetime_module.timedelta(0)
    timedelta_2 = timedelta_parse('01:02:03.004005')
    assert isinstance(timedelta_2, datetime_module.timedelta)

# Generated at 2022-06-24 17:17:35.350408
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('0:0:0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:1:0.000001') == datetime_module.timedelta(0, 60, 1)
    assert timedelta_parse('0:0:1.000001')

# Generated at 2022-06-24 17:17:38.114606
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=4)) == '01:02:03.000004'


# Generated at 2022-06-24 17:17:40.564530
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.001000') == datetime_module.timedelta(
    hours=1, minutes=0, seconds=0, microseconds=1000)


# Generated at 2022-06-24 17:17:44.144583
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(0, 0, 165000)
    s = timedelta_format(timedelta_0)
    assert s == '00:00:00.165000'
