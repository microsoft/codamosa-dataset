

# Generated at 2022-06-24 17:08:49.303437
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('23:45:21.012345')


# Generated at 2022-06-24 17:08:50.719854
# Unit test for function timedelta_format

# Generated at 2022-06-24 17:08:53.922838
# Unit test for function timedelta_parse
def test_timedelta_parse():
    ret_1 = timedelta_parse('-08:53:50:297561')
    assert(ret_1 == -315.69025)

# Generated at 2022-06-24 17:08:57.161205
# Unit test for function timedelta_parse
def test_timedelta_parse():
    success = True
    for n in range(10):
        try:
            float_1 = 3.2
            var_1 = timedelta_parse(float_1)
        except TypeError:
            success = False
        except ValueError:
            success = False
        except Exception:
            raise
    assert success

# Generated at 2022-06-24 17:09:07.593392
# Unit test for function timedelta_parse
def test_timedelta_parse():
    float_0 = '34:19:34.773463'
    int_0 = timedelta_parse(float_0)
    float_2 = '34:19:34.773463'
    int_1 = timedelta_parse(float_2)
    float_3 = '34:19:34.773463'
    int_2 = timedelta_parse(float_3)
    float_4 = '34:19:34.773463'
    int_3 = timedelta_parse(float_4)
    float_5 = '34:19:34.773463'
    int_4 = timedelta_parse(float_5)
    float_6 = '34:19:34.773463'
    int_5 = timedelta_parse(float_6)

# Generated at 2022-06-24 17:09:09.511090
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('20:21:22.123456') == datetime_module.timedelta(
        hours=20, minutes=21, seconds=22, microseconds=123456)



# Generated at 2022-06-24 17:09:14.203608
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test 1
    result = timedelta_parse('-00:05:15.69025')
    assert isinstance(result, datetime_module.timedelta)
    assert result.days == -1
    assert result.seconds == 90025
    assert result.microseconds == 0

    # Test 2
    result = timedelta_parse('-00:05:15.69025000')
    assert isinstance(result, datetime_module.timedelta)
    assert result.days == -1
    assert result.seconds == 90025
    assert result.microseconds == 0

    # Test 3
    result = timedelta_parse('-00:05:15.690250000')
    assert isinstance(result, datetime_module.timedelta)
    assert result.days == -1
    assert result.seconds == 90025

# Generated at 2022-06-24 17:09:23.547811
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(0)) == 0
    assert timedelta_parse(timedelta_format(1234.567)) == 1234.567
    assert timedelta_parse(timedelta_format(-1234.567)) == -1234.567
    assert timedelta_parse(timedelta_format(1234.567)) > -4000
    assert timedelta_parse(timedelta_format(1234.567)) < 4000
    assert timedelta_parse(timedelta_format(1234.567)) % 10 == 4
    assert timedelta_parse(timedelta_format(1234.567)) / 10 == 123.4567
    assert timedelta_parse(timedelta_format(1234.567)) / 1000 == 1.234567
    assert timedelta

# Generated at 2022-06-24 17:09:33.542682
# Unit test for function timedelta_parse
def test_timedelta_parse():
    float_0 = -126.76698
    float_1 = 0.0
    float_2 = 821.6788
    float_3 = -455.54109
    float_4 = 592.50175
    float_5 = 735.21065
    float_6 = -154.69481
    var_0 = timedelta_parse(float_0)
    var_1 = timedelta_parse(float_1)
    var_2 = timedelta_parse(float_2)
    var_3 = timedelta_parse(float_3)
    var_4 = timedelta_parse(float_4)
    var_5 = timedelta_parse(float_5)
    var_6 = timedelta_parse(float_6)
    assert var_0 == -126.76698
    assert var_1

# Generated at 2022-06-24 17:09:47.111067
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Assigning float_0 the float value -315.69025
    float_0 = -315.69025
    # Getting var_0's value from function timedelta_parse
    var_0 = timedelta_parse(timedelta_format(float_0))
    assert var_0 == float_0
    # Getting var_1's value from function timedelta_parse
    float_1 = -23.826
    var_1 = timedelta_parse(timedelta_format(float_1))
    assert var_1 == float_1
    # Getting var_2's value from function timedelta_parse
    float_2 = -13.438
    var_2 = timedelta_parse(timedelta_format(float_2))
    assert var_2 == float_2
    # Getting var_3's value from function timedelta_

# Generated at 2022-06-24 17:10:02.671107
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        test_case_0()
    except Exception as exc:
        assert False, 'Exception raised: {}'.format(exc)
    else:
        assert True



# Generated at 2022-06-24 17:10:09.414075
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        # Looks like Python 3
        if sys.version_info[0] == 3:
            assert '-315.690249:00:00' == timedelta_format(-315.69025)
        # Looks like Python 2
        else:
            assert u'-315.690249:00:00' == timedelta_format(-315.69025)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 17:10:16.188096
# Unit test for function timedelta_format
def test_timedelta_format():
    print("\n***\n***  timedelta_format\n***\n\n")
    case_0 = -315.69025
    var_0 = timedelta_format(case_0)
    assert isinstance(var_0, str)
    assert var_0 == '-05:29:26.690248'

    return



# Generated at 2022-06-24 17:10:19.755173
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("001:15:31.690254") == timedelta(hours=1, minutes=15, seconds=31, microseconds=690254)
    assert timedelta_parse("-001:15:31.690254") == timedelta(hours=-1, minutes=-15, seconds=-31, microseconds=-690254)

# Generated at 2022-06-24 17:10:32.439527
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("-00:00:00.000000") == datetime_module.timedelta(
        0, 0, 0)
    assert timedelta_parse("-00:00:00.000001") == datetime_module.timedelta(
        0, 0, -1)
    assert timedelta_parse("-00:00:00.001001") == datetime_module.timedelta(
        0, 0, -1001)
    assert timedelta_parse("-00:00:00.010001") == datetime_module.timedelta(
        0, 0, -10001)
    assert timedelta_parse("-00:00:00.100001") == datetime_module.timedelta(
        0, 0, -100001)

# Generated at 2022-06-24 17:10:43.545711
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
           '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=1)) == \
           '23:59:59.000001'

# Generated at 2022-06-24 17:10:56.517628
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=9)) == '00:00:09.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=9, microseconds=1)) == '00:00:09.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=5, seconds=5, microseconds=10)).startswith('29:05:05')
    assert timedelta_format(datetime_module.timedelta(days=100, hours=5, seconds=5, microseconds=10)).startswith('99:05:05')



# Generated at 2022-06-24 17:10:58.496612
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-315.69025') == datetime_module.timedelta(
        hours=-315, minutes=41, seconds=37, microseconds=200000
    )

# Generated at 2022-06-24 17:11:06.973105
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('-00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('-1:00:00.000000') == datetime_module.timedelta(-1)
    assert timedelta_parse('-00001:00:00.000000') == datetime_module.timedelta(-1)
    assert timedelta_parse('-00000001:00:00.000000') == datetime_module.timedelta(-1)
    assert timedelta_parse('-0000000001:00:00.000000') == datetime_module.timedelta(-1)

# Generated at 2022-06-24 17:11:09.391439
# Unit test for function timedelta_format
def test_timedelta_format():
    assert(timedelta_format(timedelta_parse("-315.69025"))=="-08:44:44.69025")


# Generated at 2022-06-24 17:11:38.058386
# Unit test for function timedelta_format
def test_timedelta_format():

    float_0 = -38.3646
    var_0 = timedelta_format(float_0)
    
    assert var_0 == '03:32:27.286217'
    float_1 = 1.323
    var_1 = timedelta_format(float_1)
    
    assert var_1 == '00:00:01.323000'



# Generated at 2022-06-24 17:11:46.845390
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert ( timedelta_parse( '' ) == None )
    assert ( timedelta_parse( '-00:35:18.477551' ) == -35.18477551 )
    assert ( timedelta_parse( '-00:35:18.477551' ) == -35.184775510000006 )
    assert ( timedelta_parse( '00:35:18.477551' ) == 35.18477551 )
    assert ( timedelta_parse( '00:35:18.477551' ) == 35.184775510000006 )
    assert ( timedelta_parse( '-00:35:18.477550' ) == -35.1847755 )
    assert ( timedelta_parse( '00:35:18.477550' ) == 35.1847755 )

# Generated at 2022-06-24 17:11:52.199223
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=6000)) == '00:00:00.006000'
    assert timedelta_format(datetime_module.timedelta(microseconds=6010)) == '00:00:00.006010'
    assert timedelta_format(datetime_module.timedelta(microseconds=-6000)) == '-1 day, 23:59:59.994000'


# Generated at 2022-06-24 17:12:03.471421
# Unit test for function timedelta_parse
def test_timedelta_parse():
    float_0 = -879.11905
    float_1 = -879.11905
    float_2 = -879.11905
    float_3 = -879.11905
    var_0 = timedelta_format(float_0)
    var_1 = timedelta_format(float_1)
    var_2 = timedelta_format(float_2)
    var_3 = timedelta_format(float_3)
    var_4 = timedelta_parse(var_0)
    var_5 = timedelta_parse(var_1)
    var_6 = timedelta_parse(var_2)
    var_7 = timedelta_parse(var_3)
    var_8 = timedelta_format(float_0)
    var_9 = timedelta_format(float_1)
   

# Generated at 2022-06-24 17:12:11.972188
# Unit test for function timedelta_parse
def test_timedelta_parse():
    float_0 = 327.98979
    var_0 = timedelta_format(float_0)
    var_1 = timedelta_parse(var_0)
    assert abs(((var_0 - float_0) / var_0) - 0.0) < 0.001

# Generated at 2022-06-24 17:12:14.309265
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse(test_case_0()), datetime_module.timedelta)

# Generated at 2022-06-24 17:12:24.987206
# Unit test for function timedelta_format
def test_timedelta_format():
    test_0 = timedelta_format(-315.69025)
    assert test_0 == "-08:39:23.69025"
    test_1 = timedelta_format(157.79495)
    assert test_1 == "04:19:19.794950"
    test_2 = timedelta_format(-31.296001)
    assert test_2 == "-00:31:17.296001"
    test_3 = timedelta_format(69.6696)
    assert test_3 == "01:09:26.669600"
    test_4 = timedelta_format(100.8585)
    assert test_4 == "02:47:08.585000"
    test_5 = timedelta_format(0.789799)

# Generated at 2022-06-24 17:12:28.532898
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('Test function timedelta_parse')
    assert isinstance(timedelta_parse(timedelta_format(-1)),
                      datetime_module.timedelta)
    assert timedelta_parse(timedelta_format(-1)) == datetime_module.timedelta(
        hours=-1
    )


# Generated at 2022-06-24 17:12:33.160599
# Unit test for function timedelta_format
def test_timedelta_format():
    import time
    import datetime as datetime_module
    import pytest
    from combi._lib._python_compatibility import timedelta_format

    dt = datetime_module.timedelta(
        hours=3,
        minutes=45,
        seconds=6,
        microseconds=8351
    )

    assert timedelta_format(dt) == '03:45:06.008351'



# Generated at 2022-06-24 17:12:36.514583
# Unit test for function timedelta_format
def test_timedelta_format():

    float_0 = -315.69025
    var_0 = timedelta_format(float_0)


# Generated at 2022-06-24 17:13:03.599392
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        assert test_case_0() # Run test case 0
    except AssertionError:
        raise AssertionError("Test case 0 failed")

test_cases = [
    test_case_0,
]

if __name__ == '__main__':
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-24 17:13:06.028745
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-315.69025') == -315.69025


# Generated at 2022-06-24 17:13:08.365654
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse(timedelta_format(float_0))) == float_0

# Generated at 2022-06-24 17:13:14.602992
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = timedelta_parse('-11.00:00:26.290000')
    assert var_0 == datetime_module.timedelta(days=-11, seconds=26,
                                              microseconds=290000)
    var_1 = timedelta_parse('-11:00:26.290000')
    assert var_1 == datetime_module.timedelta(days=-11, seconds=26,
                                              microseconds=290000)
    var_2 = timedelta_parse('26.290000')
    assert var_2 == datetime_module.timedelta(seconds=26,
                                              microseconds=290000)
    var_3 = timedelta_parse('26.29')
    assert var_3 == datetime_module.timedelta(seconds=26, microseconds=290000)


# Generated at 2022-06-24 17:13:19.362348
# Unit test for function timedelta_parse
def test_timedelta_parse():
    float_0 = datetime_module.timedelta(seconds=-524320,
                                        microseconds=217847)
    float_1 = timedelta_format(-263.873313)
    float_2 = timedelta_parse(float_1)
    assert float_0 == float_2



# Generated at 2022-06-24 17:13:22.393680
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = timedelta_parse(-315.69025)
    assert var_0 == -315.69025
    var_1 = timedelta_parse(-315.69025)
    assert var_1 == -315.69025

# Generated at 2022-06-24 17:13:24.706199
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)


# Generated at 2022-06-24 17:13:31.514551
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test 1
    var_1 = timedelta_parse('-04:00:00.000000')
    assert var_1 == datetime_module.timedelta(0, 0, 0)

    # Test 2
    var_2 = timedelta_parse('-04:00:00.000001')
    assert var_2 == datetime_module.timedelta(0, 0, 0, 1)

    # Test 3
    var_3 = timedelta_parse('-04:00:00.999999')
    assert var_3 == datetime_module.timedelta(0, 0, 0, 999999)

    # Test 4
    var_4 = timedelta_parse('-04:00:00.1000000')
    assert var_4 == datetime_module.timedelta(0, 0, 0, 1000000)



# Generated at 2022-06-24 17:13:39.604836
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=5,
                                                      seconds=5,
                                                      microseconds=5)) == \
                                                      '05:05:05.000005'
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=5,
                                                      seconds=5,
                                                      microseconds=50000)) == \
                                                      '05:05:05.050000'
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=5,
                                                      seconds=5,
                                                      microseconds=500000)) == \
                                                      '05:05:05.500000'

# Generated at 2022-06-24 17:13:44.400937
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-315:41:24.69025') == -315.69025

# Generated at 2022-06-24 17:14:16.952928
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('03:14:15.000000') == datetime_module.timedelta(
        hours=3, minutes=14, seconds=15
    )
    assert timedelta_parse('03:14:15.900000') == datetime_module.timedelta(
        hours=3, minutes=14, seconds=15, milliseconds=900
    )
    assert timedelta_parse('03:14:15.900000') == datetime_module.timedelta(
        hours=3, minutes=14, seconds=15, milliseconds=900
    )



# Generated at 2022-06-24 17:14:21.606056
# Unit test for function timedelta_format
def test_timedelta_format():
    # Raises error if float_0 is different from float_1
    assert timedelta_format(-315.69025) == '11:20:15.690251'
    # Raises error if float_0 is different from float_1
    assert timedelta_format(200.0) == '07:06:40.000000'


# Generated at 2022-06-24 17:14:25.123069
# Unit test for function timedelta_format
def test_timedelta_format():
    t1 = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456)
    assert timedelta_format(t1) == '01:02:03.000456'


# Generated at 2022-06-24 17:14:29.781537
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)
    assert var_0 == "-17:42:46.69025"



# Generated at 2022-06-24 17:14:34.163574
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_module.timedelta(
        days=2, hours=23, minutes=54, seconds=32, microseconds=12345
    )) == '02:23:54.012345'



# Generated at 2022-06-24 17:14:37.557032
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-0:05:15.69025') == datetime_module.timedelta(
        seconds=-315.69025,
        microseconds=-69025
    )


# Generated at 2022-06-24 17:14:38.691442
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()

# Generated at 2022-06-24 17:14:48.309243
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-22:11:04.308826') == datetime_module.timedelta(2, 18264, 308826)
    assert timedelta_parse('-04:14:24.638187') == datetime_module.timedelta(4, 9084, 638187)
    assert timedelta_parse('-09:23:10.860170') == datetime_module.timedelta(9, 33790, 860170)
    assert timedelta_parse('-15:53:21.927330') == datetime_module.timedelta(15, 55601, 927330)
    assert timedelta_parse('-18:22:37.375672') == datetime_module.timedelta(18, 67557, 375672)

# Generated at 2022-06-24 17:14:50.586430
# Unit test for function timedelta_format
def test_timedelta_format():
    # Setup
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)

    # Testing function...
    assert var_0 == '-05:30:37.690251'

    # Teardown

# Generated at 2022-06-24 17:14:52.201426
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in range(100):
        try:
            test_case_0()
        except:
            print("An exception occurred!")
            raise


# Generated at 2022-06-24 17:15:20.343928
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(1.0) == "08:20:01.000000"
    assert timedelta_format(0.0) == "08:00:00.000000"
    assert timedelta_format(-0.5) == "07:59:59.500000"


# Generated at 2022-06-24 17:15:31.542848
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.00") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse("00:00:00.010000") == datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse("00:00:00.100000") == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse("00:00:00.1") == datetime

# Generated at 2022-06-24 17:15:43.493600
# Unit test for function timedelta_format
def test_timedelta_format():
    with open('/tmp/python_test_log.txt', 'w') as python_test_log:
        with open('/tmp/python_test_log.txt', 'a') as python_test_log:
            python_test_log.write(
                'test_timedelta_format:timedelta_format:%s\n' %
                (timedelta_format(datetime_module.timedelta(
                    hours=21, minutes=4, seconds=49, microseconds=757719
                )))
            )


# Generated at 2022-06-24 17:15:48.544307
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(-315.69025) == '-08:51:07.69025'
    assert timedelta_format(0.123) == '00:00:00.123000'
    assert timedelta_format(0.1) == '00:00:00.100000'


# Generated at 2022-06-24 17:15:55.974128
# Unit test for function timedelta_format
def test_timedelta_format():
    n_tests = 0
    n_passed = 0
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()


# Generated at 2022-06-24 17:16:07.376550
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(0.0) == '00:00:00.000000'
    assert timedelta_format(1.0) == '00:00:01.000000'
    assert timedelta_format(1.1) == '00:00:01.100000'
    assert timedelta_format(1.11) == '00:00:01.110000'
    assert timedelta_format(1.111) == '00:00:01.111000'
    assert timedelta_format(1.1111) == '00:00:01.111100'
    assert timedelta_format(1.11111) == '00:00:01.111110'
    assert timedelta_format(1.111111) == '00:00:01.111111'

# Generated at 2022-06-24 17:16:12.363384
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Initialization
    var_0 = 0
    expected__var_0 = 0
    # Call the tested method
    var_0 = timedelta_parse(var_0)
    # Check the result
    assert var_0 == expected__var_0

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 17:16:15.108628
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)
    assert isinstance(var_0, str)
    assert var_0 == '-0:05:15.690250'



# Generated at 2022-06-24 17:16:26.396305
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(float(0)) == datetime_module.timedelta(0)
    assert timedelta_parse(float(1)) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(-float(1)) == datetime_module.timedelta(microseconds=-1)
    assert timedelta_parse(float(1.1)) == datetime_module.timedelta(microseconds=1100)
    assert timedelta_parse(-float(1.1)) == datetime_module.timedelta(microseconds=-1100)
    assert timedelta_parse(float('1.1')) == datetime_module.timedelta(microseconds=1100)
    assert timedelta_parse(-float('1.1')) == datetime_module.timedelta(microseconds=-1100)
    assert timed

# Generated at 2022-06-24 17:16:29.438073
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(float('-315.69025')) == '-00:05:15.69025'

# Generated at 2022-06-24 17:16:54.654456
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)


# Generated at 2022-06-24 17:16:55.669101
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_format()


# Generated at 2022-06-24 17:16:56.800533
# Unit test for function timedelta_format
def test_timedelta_format():
    assert True == True


# Generated at 2022-06-24 17:16:59.084204
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '-05:49:25.690257'
    assert timedelta_parse(s) == -315.690257



# Generated at 2022-06-24 17:17:00.933617
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)
    assert var_0 == '-05:25:13.69025'



# Generated at 2022-06-24 17:17:04.439106
# Unit test for function timedelta_format
def test_timedelta_format():
    float_0 = -315.69025
    var_0 = timedelta_format(float_0)

if __name__ == "__main__":
    test_timedelta_format()

# Generated at 2022-06-24 17:17:06.981115
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test for functions timedelta_parse
    # Test for function timedelta_parse
    # Case for function timedelta_parse - S1
    float_0 = -315.69025
    var_0 = timedelta_parse(float_0)



# Generated at 2022-06-24 17:17:08.941036
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


if __name__ == '__main__':
    test_timedelta_format()

# Generated at 2022-06-24 17:17:22.171815
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Example 1.
    # var_0 = timedelta_parse('')
    assert timedelta_parse('-00:05:15.690250') == datetime_module.timedelta(seconds=-315.69025)
    # Example 2.
    # var_0 = timedelta_parse('')
    assert timedelta_parse('-00:00:02.000600') == datetime_module.timedelta(microseconds=-2000)
    # Example 3.
    # var_0 = timedelta_parse('')
    assert timedelta_parse('-00:00:02') == datetime_module.timedelta(seconds=-2)
    # Example 4.
    # var_0 = timedelta_parse('')
    assert timedelta_parse('-00:02:00') == datetime_module.tim

# Generated at 2022-06-24 17:17:26.381647
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('-00:05:15.690251') == -315.690251)
test_timedelta_parse()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:18:01.163411
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        assert timedelta_format(18118500.864323) == '05:01:58.500864'
        assert timedelta_format(-315.69025) == '-00:00:00.000315'
    except AssertionError as e:
        print('Function timedelta_format has failed:', e)
        sys.exit(1)


# Generated at 2022-06-24 17:18:12.048144
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(0.0) == '00:00:00.000000'
    assert timedelta_format(1) == '00:00:01.000000'
    assert timedelta_format(21) == '00:00:21.000000'
    assert timedelta_format(321) == '00:05:21.000000'
    assert timedelta_format(4321) == '01:12:01.000000'
    assert timedelta_format(54321) == '15:05:21.000000'
    assert timedelta_format(654321) == '181:12:01.000000'
    assert timedelta_format(7654321) == '2191:12:01.000000'
    assert timedelta_format(87654321) == '26281:12:01.000000'
    assert timedelta_

# Generated at 2022-06-24 17:18:21.471072
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test 0
    var_0 = timetest_case_0()
    assert var_0 == '-09:15:58.69025'
    assert type(var_0) is str
    # Test 1
    float_0 = -940.17593
    var_0 = timedelta_format(float_0)
    assert var_0 == '-02:40:05.175930'
    assert type(var_0) is str
    # Test 2
    float_0 = 986.98219
    var_0 = timedelta_format(float_0)
    assert var_0 == '02:47:06.982190'
    assert type(var_0) is str
    # Test 3
    float_0 = -958.80249
    var_0 = timedelta_format(float_0)

# Generated at 2022-06-24 17:18:26.163523
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("48:56:23.354200") == datetime_module.timedelta(48, 56, 23.354200)


# Generated at 2022-06-24 17:18:34.016017
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-' + timedelta_format(145.65)) == -145.65
    for _ in range(10):
        dt = datetime_module.timedelta(
            seconds=random.randrange(0, 3600 * 24 * 365 * 2),
            microseconds=random.randrange(0, 10 ** 6)
        )
        assert timedelta_parse(timedelta_format(dt)) == dt

# Generated at 2022-06-24 17:18:35.124756
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(float_0) == var_0


# Generated at 2022-06-24 17:18:45.080388
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-315:41:24.690000') == datetime_module.timedelta(315, -24, -690000)
    assert timedelta_parse('-2:52:46.470000') == datetime_module.timedelta(3, -17914, -530000)
    assert timedelta_parse('-2:23:21.440000') == datetime_module.timedelta(3, -15041, -560000)
    assert timedelta_parse('-3:57:46.180000') == datetime_module.timedelta(4, -21966, -820000)
    assert timedelta_parse('-2:51:29.700000') == datetime_module.timedelta(3, -17769, -300000)