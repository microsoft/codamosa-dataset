

# Generated at 2022-06-24 17:08:49.864865
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test str_0
    str_0 = 'vQ"'
    var_0 = timedelta_parse(str_0)
    # Test str_1
    str_1 = 'vQ"'
    var_1 = timedelta_parse(str_1)
    # Test str_2
    str_2 = 'vQ"'
    var_2 = timedelta_parse(str_2)
    # Test str_3
    str_3 = 'vQ"'
    var_3 = timedelta_parse(str_3)
    # Test str_4
    str_4 = 'vQ"'
    var_4 = timedelta_parse(str_4)


# Generated at 2022-06-24 17:08:55.790770
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)


# Generated at 2022-06-24 17:09:05.221074
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=999999)) == '00:00:01.999999'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'

    test_case_0()

# Generated at 2022-06-24 17:09:13.696650
# Unit test for function timedelta_format
def test_timedelta_format():
    ###########################################################################
    # No Assertions Provided
    ###########################################################################
    str_0 = 0
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)
    str_0 = timedelta_format(str_0)

# Generated at 2022-06-24 17:09:23.309209
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.00") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:01.00") == datetime_module.timedelta(seconds=1)
    assert timedelta_parse("00:01:00.00") == datetime_module.timedelta(minutes=1)
    assert timedelta_parse("01:00:00.00") == datetime_module.timedelta(hours=1)
    assert timedelta_parse("00:02:00.00") == datetime_module.timedelta(minutes=2)
    assert timedelta_parse("00:05:00.00") == datetime_module.timedelta(minutes=5)
    assert timedelta_parse("00:13:00.00") == datetime

# Generated at 2022-06-24 17:09:27.941850
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse()
    assert timedelta_parse != None
    assert timedelta_parse('') != None
    assert timedelta_parse(0) != None
    assert timedelta_parse(None) != None
    assert timedelta_parse('str') != None
    assert timedelta_parse(timedelta) != None
    assert timedelta_parse(int) != None
    assert timedelta_parse(timedelta()) != None
    assert timedelta_parse(timedelta_parse(timedelta)) != None



# Generated at 2022-06-24 17:09:30.175162
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = 'vQ"'
    var_0 = timedelta_format(str_0)



# Generated at 2022-06-24 17:09:32.866773
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(str_0)
    assert var_0 == '00:00:00.000000'
test_timedelta_format()

# Generated at 2022-06-24 17:09:37.389457
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:09:41.030246
# Unit test for function timedelta_format
def test_timedelta_format():
    pass


# Generated at 2022-06-24 17:09:57.178541
# Unit test for function timedelta_format
def test_timedelta_format():
    assert test_case_0() == timedelta_parse(timedelta_format(str_0))


if not PY3:
    z =  str_0
    try:
        z =  var_0
    except NameError:
        exec('var_0 = ' + str(var_0))
    d =  z

# Generated at 2022-06-24 17:09:59.377565
# Unit test for function timedelta_format
def test_timedelta_format():
    print('Test timedelta_format')
    test_case_0()


# Generated at 2022-06-24 17:10:09.645075
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 0, 0)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == '24:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1000)) == '24:00:01.001000'

# Generated at 2022-06-24 17:10:21.438003
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(None)
    if isinstance(timedelta, str):
        assert False, "timedelta should not be str"
    elif isinstance(timedelta, str):
        try:
            assert False, "timedelta should be str"
        except str:
            pass
    _start_time = datetime_module.datetime.now()
    test_case_0()
    _end_time = datetime_module.datetime.now()
    if not ((_end_time - _start_time).total_seconds() <= 0.00001):
        assert False, "timedelta_format function takes < 0.00001 seconds"
    assert True, "timedelta_format function ok"


# Generated at 2022-06-24 17:10:26.559008
# Unit test for function timedelta_format
def test_timedelta_format():
    from random import seed, randint, random
    from copy import copy
    from pytest import raises
    class Test:
        def __init__(self):
            seed(0)
            self.ranges = {}
            for i in range(10):
                self.ranges[i] = (randint(-100, 100), randint(-100, 100))
            self.values = [0, 1, -1, 1.1, -1.1, 1.0, -1.0, 1.9, -1.9, 1e10, -1e10, 1e20, -1e20, 1e100, -1e100, float("inf"), float("-inf"), float("nan")]
            self.input_values = [-1, -0.8, -0]

# Generated at 2022-06-24 17:10:38.884255
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('0:0:0.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-24 17:10:51.816408
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.00001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.00001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0)

# Generated at 2022-06-24 17:11:03.231175
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('1:1:1.000001')) == '01:01:01.000001'
    assert timedelta_format(timedelta_parse('2:2:2.000002')) == '02:02:02.000002'
    assert timedelta_format(timedelta_parse('3:3:3.000003')) == '03:03:03.000003'
    assert timedelta_format(timedelta_parse('4:4:4.000004')) == '04:04:04.000004'
    assert timedelta_format(timedelta_parse('5:5:5.000005')) == '05:05:05.000005'

# Generated at 2022-06-24 17:11:12.714510
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test cases
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.1') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('0:00:00.01') == datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse('0:00:00.001') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('0:00:00.0001') == datetime_module.timedelta(microseconds=100)

# Generated at 2022-06-24 17:11:24.586294
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.001001') == datetime_module.timedelta(0, 1, 1001)
    assert timedelta_parse('00:01:02.003003') == datetime_module.timedelta(0, 62, 3003)
    assert timedelta_parse('01:02:03.006006') == datetime_module.timedelta(1, 7263, 6006)
    assert timedelta_parse('01:02:03.006006') == datetime_module.timedelta(1, 7263, 6006)


    # assert timedelta_parse('00:00:01.001001') == datetime_module.timedelta(0, 1, 1001)
    # assert timedelta_parse('00:01:02.003003') == datetime_

# Generated at 2022-06-24 17:11:53.175444
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(0) == '00:00:00.000000'

    assert timedelta_format(1) == '00:00:00.000001'
    assert timedelta_format(2) == '00:00:00.000002'
    assert timedelta_format(3) == '00:00:00.000003'
    assert timedelta_format(4) == '00:00:00.000004'
    assert timedelta_format(5) == '00:00:00.000005'
    assert timedelta_format(6) == '00:00:00.000006'
    assert timedelta_format(7) == '00:00:00.000007'
    assert timedelta_format(8) == '00:00:00.000008'

# Generated at 2022-06-24 17:12:04.465252
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)


# Generated at 2022-06-24 17:12:06.501871
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = 'vQ"'
    var_0 = timedelta_parse(str_0)

# Generated at 2022-06-24 17:12:13.982424
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0))
    assert (timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1))
    assert (timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10))
    assert (timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100))
    assert (timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000))

# Generated at 2022-06-24 17:12:23.190639
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.time(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.time(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.time(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.datetime(1, 1, 1, 0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.datetime(1, 1, 1, 0)

# Generated at 2022-06-24 17:12:28.103207
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = 'yGq'
    assert timedelta_format(str_0) == '00:00:00.000000'


# Generated at 2022-06-24 17:12:38.462557
# Unit test for function timedelta_parse

# Generated at 2022-06-24 17:12:52.121984
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0)) == \
    '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, microseconds=0)) \
    == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
    '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
    '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
    '00:00:01.000000'

# Generated at 2022-06-24 17:13:00.880298
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'

# Generated at 2022-06-24 17:13:11.018239
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 50, 42)) == '00:00:50.000042'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 512)) == '00:00:00.000512'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, -1, -2)) == '-00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(0, -15, -100)) == '-00:00:15.000100'

# Generated at 2022-06-24 17:13:54.235260
# Unit test for function timedelta_parse
def test_timedelta_parse():
    string_0 = 'blah'
    var_0 = timedelta_parse(string_0)
    assert isinstance(var_0, datetime_module.timedelta)

    string_0 = 'blah'
    var_0 = timedelta_parse(string_0)
    assert isinstance(var_0, datetime_module.timedelta)




# Generated at 2022-06-24 17:14:06.557411
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=14, minutes=15,
                                                      seconds=16,
                                                      microseconds=17)) == \
                                                      "14:15:16.000017"
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      "01:02:03.000004"
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=16,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      "03:16:00.000000"


# Generated at 2022-06-24 17:14:10.365178
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse(timedelta_format(timedelta_module.timedelta(days=1, hours=15, minutes=3, seconds=8, microseconds=15)))) == "15:03:08.000015"



# Generated at 2022-06-24 17:14:13.216867
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = 'vQ"'
    var_0 = timedelta_format(str_0)
    assert var_0 == '00:00:00.001000'


# Generated at 2022-06-24 17:14:17.347109
# Unit test for function timedelta_format
def test_timedelta_format():
#    """Test for correct output for the datetime functions"""
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000', 'Wrong output for timedelta_format'

test_timedelta_format()

# Generated at 2022-06-24 17:14:25.250251
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Test case #0
    string = '00:00:00.000000'
    expected_output = datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=0,
    )
    actual_output = timedelta_parse(string)

    assert actual_output == expected_output

    # Test case #1
    string = '23:59:59.999999'
    expected_output = datetime_module.timedelta(
        hours=23,
        minutes=59,
        seconds=59,
        microseconds=999999,
    )
    actual_output = timedelta_parse(string)

    assert actual_output == expected_output

    # Test case #2
    string = '00:00:00.999999'
    expected_output

# Generated at 2022-06-24 17:14:27.267221
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Make sure the test suite runs properly
    '''
    pass

# Generated at 2022-06-24 17:14:33.542960
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # __doc__ (as of 2008-08-02) for os.path.islink:
    #
    # Test for symbolic link.
    #
    # Returns a boolean indicating whether the pathname refers to a symbolic
    # link.
    # Always False if symbolic links are not supported by the Python
    # installation.
    pass


# Generated at 2022-06-24 17:14:45.687362
# Unit test for function timedelta_format
def test_timedelta_format():
    input_0 = datetime_module.timedelta(days=4)
    actual_output_0 = timedelta_format(input_0)
    expected_output_0 = '96:00:00.000000'
    assert actual_output_0 == expected_output_0

    input_1 = datetime_module.timedelta()
    actual_output_1 = timedelta_format(input_1)
    expected_output_1 = '00:00:00.000000'
    assert actual_output_1 == expected_output_1

    input_2 = datetime_module.timedelta(milliseconds=1)
    actual_output_2 = timedelta_format(input_2)
    expected_output_2 = '00:00:00.001000'
    assert actual_output_2 == expected_output_2

# Generated at 2022-06-24 17:14:47.084494
# Unit test for function timedelta_format
def test_timedelta_format():
    assert test_case_0() == "00:00:00.000000", 'uncaught exception'



# Generated at 2022-06-24 17:16:05.505669
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # variables
    timedelta_parse_timedelta = "test"
    timedelta_parse_expected_result = "test"
    # check results
    assert timedelta_parse(timedelta_parse_timedelta) == timedelta_parse_expected_result


# Generated at 2022-06-24 17:16:15.195137
# Unit test for function timedelta_parse
def test_timedelta_parse():
#    assert timedelta_parse('01:23:45.678000') == datetime_module.timedelta(0, 45, 678000)
    assert timedelta_parse('01:23:45.678000') == datetime_module.timedelta(0, 45, 678000)
    res = timedelta_parse('01:23:45.678000')
#    print("res1", res)
    assert timedelta_parse('01:23:45.678') == datetime_module.timedelta(0, 45, 678000)
    res = timedelta_parse('01:23:45.678')
#    print("res2", res)
    test = datetime_module.timedelta(0, 45, 678000)

# Generated at 2022-06-24 17:16:19.906592
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '00:00:00.000000'
    var_0 = timedelta_parse(str_0)
    assert var_0.microseconds == 0
    assert var_0.seconds == 0
    assert var_0.minutes == 0
    assert var_0.hours == 0


# Generated at 2022-06-24 17:16:29.256491
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.timedelta(hours=17, minutes=13, seconds=59,
                                     microseconds=999999)
    assert '17:13:59.999999' == timedelta_format(time)
    output = timedelta_format(datetime_module.timedelta(seconds=99999,
                                                        microseconds=999999))
    assert output == '27:46:39.999999'
    output = timedelta_format(datetime_module.timedelta(seconds=3662,
                                                        microseconds=999999))
    assert output == '01:01:02.999999'
    output = timedelta_format(datetime_module.timedelta(seconds=49999,
                                                        microseconds=999999))
    assert output == '13:46:39.999999'


# Generated at 2022-06-24 17:16:39.580453
# Unit test for function timedelta_parse
def test_timedelta_parse():
    correct_answer_0 = '00:00:00.000000'
    var_0 = timedelta_parse('00:00:00.000000')
    assert var_0 == correct_answer_0
    correct_answer_1 = '03:46:40.000000'
    var_0 = timedelta_parse('03:46:40.000000')
    assert var_0 == correct_answer_1
    correct_answer_2 = '00:00:00.000001'
    var_0 = timedelta_parse('00:00:00.000001')
    assert var_0 == correct_answer_2
    correct_answer_3 = '18:00:00.000000'
    var_0 = timedelta_parse('18:00:00.000000')
    assert var_0 == correct_answer_3
    correct_answer_

# Generated at 2022-06-24 17:16:45.282077
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Unit test for timedelta_format()
    '''
    assert timedelta_format(datetime_module.timedelta(microseconds=6854)) == "00:00:00.006854"
    assert timedelta_format(datetime_module.timedelta(microseconds=6854)) == "00:00:00.006854"


# Generated at 2022-06-24 17:16:52.116421
# Unit test for function timedelta_format
def test_timedelta_format():

    # Test with a good timedelta number
    result = timedelta_format(datetime_module.timedelta(hours=2,
                                                        minutes=10,
                                                        seconds=1,
                                                        microseconds=5))
    expected = '02:10:01.000005'
    assert result == expected

# Generated at 2022-06-24 17:16:54.399188
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = 'vQ"'
    var_0 = timedelta_format(str_0)


# Generated at 2022-06-24 17:17:06.097230
# Unit test for function timedelta_format
def test_timedelta_format():
    var_0 = datetime_module.timedelta(microseconds=-1)
    var_1 = timedelta_format(var_0)
    assert var_1 == '0:00:00.999999'
    var_2 = datetime_module.timedelta(weeks=-2, hours=-72)
    var_3 = timedelta_format(var_2)
    assert var_3 == '0:00:00.000000'
    var_4 = datetime_module.timedelta(days=10)
    var_5 = timedelta_format(var_4)
    assert var_5 == '240:00:00.000000'
    var_6 = datetime_module.timedelta(hours=0)
    var_7 = timedelta_format(var_6)

# Generated at 2022-06-24 17:17:13.099230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert(timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0))
    assert(timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1))
    assert(timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10))
    assert(timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100))
    assert(timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000))