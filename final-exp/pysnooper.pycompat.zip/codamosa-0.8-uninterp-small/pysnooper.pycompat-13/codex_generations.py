

# Generated at 2022-06-24 17:08:52.211779
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import py_compat

    assert py_compat.timedelta_parse(py_compat.timedelta_format(
            datetime_module.timedelta(days=100, hours=12,
                                      seconds=45.678,
                                      microseconds=123456)
    )) == datetime_module.timedelta(days=100, hours=12,
                                    seconds=45.678,
                                    microseconds=123456)

# Generated at 2022-06-24 17:08:55.030592
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0)
    
    

# Generated at 2022-06-24 17:09:05.652618
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == '00:00:00.010000'

# Generated at 2022-06-24 17:09:13.247979
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        assert_equal(timedelta_format(0), '00:00:00.000000')
        assert_equal(timedelta_format(1), '00:00:00.000001')
        assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
                     '00:00:01.000000')
        assert_equal(timedelta_format(datetime_module.timedelta(days=1)),
                     '24:00:00.000000')
    except:
        traceback.print_exc()


# Generated at 2022-06-24 17:09:14.715598
# Unit test for function timedelta_format
def test_timedelta_format():
    case_0 = test_case_0()
    assert case_0 == b''

# Generated at 2022-06-24 17:09:16.381965
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:09:21.610655
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse("00:00:00:00:0") # Boundary case
    timedelta_parse("2:17:56:39:999") # Boundary case
    timedelta_parse("1:1:1:1:1") # Random case

# Generated at 2022-06-24 17:09:29.441236
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
                                                                microseconds=1)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
                                                              microseconds=100)
    assert timedelta_parse('00:00:00.120000') == datetime_module.timedelta(
                                                              microseconds=120)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
                                                            microseconds=123456)

# Generated at 2022-06-24 17:09:31.711045
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_python_toolbox import toolbox
    arg = datetime_module.timedelta()
    expected = '00:00:00.000000'
    actual = timedelta_format(arg)
    toolbox.assert_equal(actual, expected)


# Generated at 2022-06-24 17:09:35.283158
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10)) == '10:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=21,
                                                      seconds=36)) == '10:21:36.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=21,
                                                      seconds=36,
                                                      microseconds=1000)) == '10:21:36.001000'


# Generated at 2022-06-24 17:09:55.501175
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("01:00:00.000000") == datetime_module.timedelta(1, 0)
    assert timedelta_parse("00:01:00.000000") == datetime_module.timedelta(0, 60)
    assert timedelta_parse("00:00:01.000000") == datetime_module.timedelta(0, 1)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse("01:02:03.000456") == datetime_module.timedelta(1, 7373, 456)

# Generated at 2022-06-24 17:10:07.259793
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_0 = b''
    var_0 = timedelta_format(bytes_0)
    assert var_0 == b'00:00:00:000000'
    var_0 = timedelta_format(timedelta_parse(b'00:00:00.999999'))
    assert var_0 == b'00:00:00.999999'
    var_0 = timedelta_format(timedelta_parse(b'00:00:00.99'))
    assert var_0 == b'00:00:00.990000'
    var_0 = timedelta_format(timedelta_parse(b'00:00:00.9'))
    assert var_0 == b'00:00:00.900000'

# Generated at 2022-06-24 17:10:13.339238
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'



# Generated at 2022-06-24 17:10:23.081593
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.00') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.0000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.00000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('12.000000') == datetime_module.timed

# Generated at 2022-06-24 17:10:24.168028
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()

# Generated at 2022-06-24 17:10:31.053404
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        time_0 = (datetime_module.datetime.min + timedelta_parse('')).time()
        assert time_0 == datetime_module.time(0, 0, 0)
    except AssertionError:
        print('AssertionError: ', datetime_module.time(0, 0, 0), '!=', time_0)


# Generated at 2022-06-24 17:10:35.891223
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1,
                                                      minutes=1, seconds=1,
                                                      microseconds=1)) == \
        '25:01:01.000001'


# Generated at 2022-06-24 17:10:51.069911
# Unit test for function timedelta_format
def test_timedelta_format():
    import re
    import datetime as datetime_module
    assert re.match(r'^\d{2}:\d{2}:\d{2}\.\d{6}$',
                    timedelta_format(datetime_module.timedelta(hours=1,
                                                               minutes=23,
                                                               seconds=45,
                                                               microseconds=
                                                               54321)))
    assert not re.match(r'^\d{2}:\d{2}:\d{2}\.\d{6}$',
                       timedelta_format(datetime_module.timedelta(hours=1,
                                                                  minutes=23,
                                                                  seconds=45,
                                                                  microseconds=
                                                                  5321)))

# Generated at 2022-06-24 17:10:54.350283
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse(b'23:59:59.999999')
    timedelta_parse('23:59:59.999999')

# Generated at 2022-06-24 17:11:00.901361
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) \
           == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=6)) \
           == '01:00:00.000006'


# Generated at 2022-06-24 17:11:30.090276
# Unit test for function timedelta_format
def test_timedelta_format():
    expected = '00:00:00.000000'
    actual = timedelta_format(datetime_module.timedelta(0))
    assert actual == expected
    expected = '00:00:00.000001'
    actual = timedelta_format(datetime_module.timedelta(0, 0, 1))
    assert actual == expected
    expected = '00:00:01.000000'
    actual = timedelta_format(datetime_module.timedelta(0, 1))
    assert actual == expected
    expected = '12:34:56.789000'
    actual = timedelta_format(datetime_module.timedelta(0, 43796, 789000))
    assert actual == expected
    expected = '12:34:56.789012'

# Generated at 2022-06-24 17:11:31.604478
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 17:11:37.787917
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from hypothesis import given
    from hypothesis.strategies import timedeltas

    @given(timedeltas())
    def test_timedelta_parse(x):
        try:
            assert timedelta_parse(timedelta_format(x)) == x
        except AssertionError as e:
            raise AssertionError('timedelta_parse(timedelta_format(x)) != x')


# Generated at 2022-06-24 17:11:44.909773
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = b''
    var_0 = timedelta_parse(bytes_0)
    assert var_0 == datetime_module.timedelta(0)

    arg_0 = b'10'
    var_0 = timedelta_parse(arg_0)
    assert var_0 == datetime_module.timedelta(seconds=10)

    arg_0 = b'10:21'
    var_0 = timedelta_parse(arg_0)
    assert var_0 == datetime_module.timedelta(minutes=10, seconds=21)

    arg_0 = b'10:21:13'
    var_0 = timedelta_parse(arg_0)
    assert var_0 == datetime_module.timedelta(hours=10, minutes=21,
                                              seconds=13)



# Generated at 2022-06-24 17:11:49.107781
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = b''
    var_0 = timedelta_parse(bytes_0)
    var_1 = type(var_0)
    var_2 = var_1.__name__



# Generated at 2022-06-24 17:12:02.797921
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''First sample test for timedelta_parse'''
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse("00:00:00.500000") == datetime_module.timedelta(0, 0, 500000)
    assert timedelta_parse("00:00:01.000000") == datetime_module.timedelta(0, 1, 0)
    assert timedelta_parse("00:00:01.000001") == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse("00:00:01.500000") == datetime_module

# Generated at 2022-06-24 17:12:16.180151
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=4,
                                                      minutes=45, seconds=30,
                                                      microseconds=5)) == \
           '04:45:30.000005'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=4,
                                                      minutes=45, seconds=30,
                                                      microseconds=5)) == \
        '04:45:30.000005'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                      minutes=0, seconds=0,
                                                      microseconds=0)) == \
        '00:00:00.000000'


# Generated at 2022-06-24 17:12:21.220049
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'

    print("All tests passed")


# Generated at 2022-06-24 17:12:28.743333
# Unit test for function timedelta_parse
def test_timedelta_parse():
    ans = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse('1:2:3.000004') == ans


# Generated at 2022-06-24 17:12:35.336352
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        0
    )
    assert timedelta_parse('00:09:10.050000') == datetime_module.timedelta(
        0, 34610, 50000
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        1, -1
    )




# Generated at 2022-06-24 17:13:29.400524
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Test with string
    b = "00:00:00.000000"
    assert timedelta_parse(b) == datetime_module.timedelta(0, 0, 0)

    # Test with bytes
    b = b"00:00:00.000000"
    assert timedelta_parse(b) == datetime_module.timedelta(0, 0, 0)


# Generated at 2022-06-24 17:13:40.733761
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(1) == '00:00:00.000001'
    assert timedelta_format(10) == '00:00:00.000010'
    assert timedelta_format(100) == '00:00:00.000100'
    assert timedelta_format(1000) == '00:00:00.001000'
    assert timedelta_format(10 * 1000) == '00:00:00.010000'
    assert timedelta_format(10 * 1000 * 1000) == '00:00:01.000000'
    assert timedelta_format(10 * 1000 * 1000 * 60) == '00:01:00.000000'
    assert timedelta_format(10 * 1000 * 1000 * 60 * 60) == '00:01:00.000000'

# Generated at 2022-06-24 17:13:48.189700
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-24 17:13:59.968585
# Unit test for function timedelta_format
def test_timedelta_format():
    b''
    assert timedelta_format(b'') == '00:00:00.000000'
    b'y'
    assert timedelta_format(b'y') == '00:00:00.000000'
    b'YA'
    assert timedelta_format(b'YA') == '00:00:00.000000'
    b'YAK'
    assert timedelta_format(b'YAK') == '00:00:00.000000'
    b'YAKS'
    assert timedelta_format(b'YAKS') == '00:00:00.000000'
    b'YAKSH'
    assert timedelta_format(b'YAKSH') == '00:00:00.000000'


# Generated at 2022-06-24 17:14:10.007674
# Unit test for function timedelta_format
def test_timedelta_format():
    import hypothesis
    from hypothesis import strategies as st
    from hypothesis import given
    from hypothesis.extra.datetime import datetimes
    from hypothesis.strategies import integers
    from hypothesis.strategies import one_of
    from hypothesis.strategies import recursive
    import datetime


# Generated at 2022-06-24 17:14:20.958875
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert '00:00:00.000000' == timedelta_format(timedelta_parse('0'))
    assert '00:00:00.000001' == timedelta_format(timedelta_parse('0.000001'))
    assert '00:00:00.000001' == timedelta_format(timedelta_parse('0.0000010'))
    assert '23:59:59.999999' == timedelta_format(timedelta_parse('86399.999999'))
    assert '23:59:59.999999' == timedelta_format(timedelta_parse('86399.9999990'))
    assert '23:59:59.999999' == timedelta_format(timedelta_parse('86399.99999900'))

# Generated at 2022-06-24 17:14:22.265886
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:14:30.784061
# Unit test for function timedelta_format
def test_timedelta_format():
    test_code = '''
from datetime import timedelta
var_0 = timedelta(seconds=3, microseconds=5)
'''
    test_ast = ast.parse(test_code)
    module = ast_compiler(test_ast)

    result = module.var_0
    assert (datetime_module.datetime.min + result).time() == result.time()
    assert isinstance(result, datetime_module.timedelta)
    assert timedelta_format(result) == timedelta_format(result)
    assert timedelta_format(result) == timedelta_format(result)
    assert timedelta_format(result) == timedelta_format(result)
    assert timedelta_format(result) == timedelta_format(result)


# Generated at 2022-06-24 17:14:34.109149
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:14:46.007196
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test unit for timedelta_parse
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('05:43:28.181736') == datetime_module.timedelta(
        hours=5, minutes=43, seconds=28, microseconds=181736
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-24 17:15:51.126755
# Unit test for function timedelta_format
def test_timedelta_format():
    # Make sure it raises an exception for invalid input
    # Make sure it raises an exception for invalid input
    try:
        assert not True
    except:
        assert True
    try:
        assert not True
    except:
        assert True
    # Make sure it gives correct output for correct input
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    # Make sure it gives correct output for correct input
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'
    # Make sure it gives correct output for correct input
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, minutes=1)) == '01:01:00.000000'


# Generated at 2022-06-24 17:15:52.749914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = b''
    assert timedelta_parse(var_0) == b''


# Generated at 2022-06-24 17:15:58.647204
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_value = timedelta_parse("00:00:00.000000")
    assert isinstance(test_value, datetime_module.timedelta)
    assert bytes(test_value) == b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert repr(test_value) == "datetime.timedelta(0)"

    test_value = timedelta_parse("01:00:00.000000")
    assert isinstance(test_value, datetime_module.timedelta)
    assert bytes(test_value) == b'\x00\x00\x00\x00\x00\x00\x00)\x18'
    assert repr(test_value) == "datetime.timedelta(1)"

    test_value = timedelta_parse

# Generated at 2022-06-24 17:16:08.855588
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=4, seconds=3, microseconds=2)) == '05:04:03.000002'
    assert timedelta_format(datetime_module.timedelta(hours=12, minutes=11, seconds=10, microseconds=9)) == '12:11:10.000009'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=22, seconds=21, microseconds=20)) == '23:22:21.000020'


# Generated at 2022-06-24 17:16:17.497807
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Function that changes a string to a list of words
    from datetime import timedelta
    assert timedelta_parse('00:00:00.000000') == timedelta(0)
    assert timedelta_parse('23:59:59.999999') == timedelta(days=1, microseconds=-1)

    assert type(timedelta_parse('00:00:00.000000')) == timedelta
    assert type(timedelta_parse('23:59:59.999999')) == timedelta

    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == '23:59:59.999999'

# Generated at 2022-06-24 17:16:21.682909
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)))) == \
                                  '01:02:03.123456'



# Generated at 2022-06-24 17:16:24.734585
# Unit test for function timedelta_format
def test_timedelta_format():
    my_input = b''
    my_output = 0
    assert my_input == my_output, 'Error in test_timedelta_format'


# Generated at 2022-06-24 17:16:32.619182
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = '00:00:00.000000'
    var_0 = timedelta_parse(bytes_0)
    assert var_0 == datetime_module.timedelta(0)

    bytes_0 = '00:00:01.000000'
    var_0 = timedelta_parse(bytes_0)
    assert var_0 == datetime_module.timedelta(seconds=1)

    bytes_0 = '00:01:00.000000'
    var_0 = timedelta_parse(bytes_0)
    assert var_0 == datetime_module.timedelta(minutes=1)

    bytes_0 = '01:00:00.000000'
    var_0 = timedelta_parse(bytes_0)
    assert var_0 == datetime_module.timedelta(hours=1)



# Generated at 2022-06-24 17:16:40.967348
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-24 17:16:50.021278
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''timedelta_parse should return datetime.timedelta object from string.'''
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:59:59.999999') == datetime_module.timedelta(minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('00:00:00.002500') == datetime_module.timedelta(microseconds=2500)
    if sys.version_info[:2] >= (3, 6):
        assert timedelta_parse('00:00:00.0025') == datetime_module.timedelta(microseconds=25)
        assert timedelta_parse('00:00:00.002') == datetime_module.timed