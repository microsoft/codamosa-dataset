

# Generated at 2022-06-24 17:08:53.794705
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # just test the expected case, I don't care much about edge cases
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901)
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901)



# Generated at 2022-06-24 17:08:57.547984
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Call the function
    try:
        test_case_0()
    except:
        return False

    return True

if __name__ == '__main__':
    if not test_timedelta_parse():
        print('Test failed')
        sys.exit(1)
    else:
        print('Test passed')
        sys.exit(0)

# Generated at 2022-06-24 17:08:59.812477
# Unit test for function timedelta_format
def test_timedelta_format():
    test_timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4, microseconds=5)
    assert timedelta_format(test_timedelta) == '02:03:04.000005'


# Generated at 2022-06-24 17:09:03.800366
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)) == '01:02:03.123456'


# Generated at 2022-06-24 17:09:11.275380
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse("00:00:00.000000")) == "00:00:00.000000"
    assert timedelta_format(timedelta_parse("00:00:00.000001")) == "00:00:00.000001"
    assert timedelta_format(timedelta_parse("00:00:00.000010")) == "00:00:00.000010"
    assert timedelta_format(timedelta_parse("00:00:00.000100")) == "00:00:00.000100"
    assert timedelta_format(timedelta_parse("00:00:00.001000")) == "00:00:00.001000"

# Generated at 2022-06-24 17:09:22.432487
# Unit test for function timedelta_format
def test_timedelta_format():
    # Asserts that the reversed string for 'test' is 'tset'.
    assert '00:00:00.000000' == timedelta_format(datetime_module.timedelta(0))
    assert '01:02:03.000000' == timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3))
    assert '00:02:00.000000' == timedelta_format(datetime_module.timedelta(minutes=2))
    assert '00:00:02.000000' == timedelta_format(datetime_module.timedelta(seconds=2))
    assert '00:00:00.100000' == timedelta_format(datetime_module.timedelta(microseconds=100000))
    assert '00:00:00.200001' == timedelta

# Generated at 2022-06-24 17:09:28.673106
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-24 17:09:35.206346
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-24 17:09:37.610898
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()
    test_case_0()
# vim: tabstop=4 shiftwidth=4 expandtab softtabstop=4

# Generated at 2022-06-24 17:09:44.978691
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Test 0: single return point
    test_case_0()

    # Test 1: normal input
    var_1 = timedelta_parse('00:00:00.000000')
    assert isinstance(var_1, datetime_module.timedelta)
    assert var_1 == datetime_module.timedelta(0)

    # Test 2: normal input
    var_2 = timedelta_parse('00:00:00.112345')
    assert isinstance(var_2, datetime_module.timedelta)
    assert var_2 == datetime_module.timedelta(0, 0, microseconds=112345)

# Generated at 2022-06-24 17:10:00.327623
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0_expected = datetime_module.timedelta(microseconds=69, seconds=42, hours=0, weeks=0, days=0, minutes=0)
    timedelta_0 = timedelta_parse('00:00:42.000069')
    assert timedelta_0 == timedelta_0_expected


# Generated at 2022-06-24 17:10:04.169116
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('23:59:59:999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )



# Generated at 2022-06-24 17:10:08.469071
# Unit test for function timedelta_format
def test_timedelta_format():
    time_string = timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    ))
    assert time_string == '01:02:03.456789'



# Generated at 2022-06-24 17:10:20.704174
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = timedelta_parse('01:00:00.000000')
    assert timedelta_0.seconds == 3600
    assert timedelta_0.microseconds == 0
    timedelta_1 = timedelta_parse('00:00:00.000001')
    assert timedelta_1.seconds == 0
    assert timedelta_1.microseconds == 1
    timedelta_2 = timedelta_parse('00:00:00.999999')
    assert timedelta_2.seconds == 0
    assert timedelta_2.microseconds == 999999
    timedelta_3 = timedelta_parse('00:00:01.000000')
    assert timedelta_3.seconds == 1
    assert timedelta_3.microseconds == 0
    timedelta_4 = timedelta_parse('00:01:00.000000')
    assert timed

# Generated at 2022-06-24 17:10:27.332740
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-24 17:10:42.096170
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:1:2.123') == \
           datetime_module.timedelta(minutes=1, seconds=2, microseconds=123)
    assert timedelta_parse('0:01:02.012345') == \
           datetime_module.timedelta(minutes=1, seconds=2, microseconds=12345)
    assert timedelta_parse('00:01:02.000001') == \
           datetime_module.timedelta(minutes=1, seconds=2, microseconds=1)
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)




# Generated at 2022-06-24 17:10:55.877080
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8)) =='00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) =='00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8, seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8, microseconds=2)) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=1)) == '00:01:00.000000'
    assert timed

# Generated at 2022-06-24 17:11:00.208641
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-24 17:11:02.894542
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == (
        '00:01:00.000000'
    )



# Generated at 2022-06-24 17:11:06.483183
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:04:05.000006') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=6
    )



# Generated at 2022-06-24 17:11:33.449013
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse(
        '11:22:33.123456'
    )) == '11:22:33.123456'
    assert timedelta_parse('11:22:33.123456') == datetime_module.timedelta(11,
                                                                           8353,
                                                                           123456)
    assert timedelta_format(timedelta_parse('11:22:33')) == '11:22:33.000000'
    assert timedelta_format(timedelta_parse('11:22')) == '11:22:00.000000'
    assert timedelta_format(timedelta_parse('11')) == '11:00:00.000000'

# Generated at 2022-06-24 17:11:38.881750
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = datetime_module.timedelta(microseconds=1)
    a = timedelta_parse(timedelta_format(timedelta_0))
    b = timedelta_0
    assert a == b

if __name__ == '__main__':
    test_case_0()
    test_timedelta_parse()
    print('Done!')

# Generated at 2022-06-24 17:11:43.423164
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(12, 34, 56, 789),
        datetime_module.timedelta(-12, -34, -56, -789),
    ):
        assert (timedelta_parse(timedelta_format(timedelta)) == timedelta)

# Generated at 2022-06-24 17:11:49.428648
# Unit test for function timedelta_format
def test_timedelta_format():
    time_delta_0 = datetime_module.timedelta(days=1, seconds=1, microseconds=1,
                                             milliseconds=1, minutes=1,
                                             hours=1, weeks=1)
    assert timedelta_format(time_delta_0) == '25:01:01.001001'


# Generated at 2022-06-24 17:12:00.767863
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('03:02:01.123456')) == \
                                                     '03:02:01.123456'
    assert timedelta_format(timedelta_parse('14:28:15.001002')) == \
                                                     '14:28:15.001002'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                     '00:00:00.000000'



# Generated at 2022-06-24 17:12:09.304104
# Unit test for function timedelta_format
def test_timedelta_format():
    def test_case_0():
        assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'

    def test_case_1():
        assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

    def test_case_2():
        assert timedelta_format(datetime_module.timedelta(microseconds=99)) == '00:00:00.000099'

    def test_case_3():
        assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'


# Generated at 2022-06-24 17:12:18.050879
# Unit test for function timedelta_format
def test_timedelta_format():

    def check(timedelta, expected_string):
        assert timedelta_format(timedelta) == expected_string

    timedelta = datetime_module.timedelta(hours=5,
                                          minutes=5,
                                          seconds=5,
                                          microseconds=10)
    check(timedelta, '05:05:05.000010')
    timedelta = datetime_module.timedelta(hours=1,
                                          minutes=2,
                                          seconds=3,
                                          microseconds=4100000)
    check(timedelta, '01:02:03.410000')
    timedelta = datetime_module.timedelta(hours=-1,
                                          minutes=-2,
                                          seconds=-3,
                                          microseconds=-4100000)
   

# Generated at 2022-06-24 17:12:21.355731
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(1, 2, 3, 123456))
    assert time == '01:02:03.123456'



# Generated at 2022-06-24 17:12:29.076560
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_object = timedelta_parse('0:20:07.345')
    assert timedelta_object == datetime_module.timedelta(minutes=20,
                                                         seconds=7,
                                                         microseconds=343000)

# Generated at 2022-06-24 17:12:36.520009
# Unit test for function timedelta_format
def test_timedelta_format():

    timedelta_0 = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                            seconds=4, microseconds=5)
    s_0 = timedelta_format(timedelta_0)
    assert s_0 == '02:03:04.000005'

    timedelta_1 = datetime_module.timedelta(seconds=1)
    s_1 = timedelta_format(timedelta_1)
    assert s_1 == '00:00:01.000000'


# Generated at 2022-06-24 17:13:20.759312
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:59.999999') == \
           datetime_module.timedelta(0, 59, 999990)
    assert timedelta_parse('00:59:59.999999') == \
           datetime_module.timedelta(0, 3600 * 1 - 1, 999999)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(0, 3600 * 1)

# Generated at 2022-06-24 17:13:28.673701
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Make sure you can parse an ordinary timedelta correctly
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=1)
    assert timedelta_parse('0:00:00.234567') == datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=234567)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(hours=0, minutes=0, seconds=1, microseconds=0)

# Generated at 2022-06-24 17:13:36.267045
# Unit test for function timedelta_format
def test_timedelta_format():
    def tester(timedelta, answer):
        if timedelta_format(timedelta) != answer:
            raise ValueError

    tester(datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4),
           '01:02:03.000004')

    tester(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=0),
           '00:00:00.000000')

    tester(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=1),
           '00:00:00.000001')


# Generated at 2022-06-24 17:13:46.167304
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:1.000000')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:0:1.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('0:0:1.000010')) == '00:00:01.000010'
    assert timedelta_format(timedelta_parse('0:0:1.000100')) == '00:00:01.000100'
    assert timedelta_format(timedelta_parse('0:0:1.001000')) == '00:00:01.001000'

# Generated at 2022-06-24 17:13:53.177625
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=1,
                                                      minutes=1)) == (
        '01:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=1,
                                                      minutes=1,
                                                      seconds=1)) == (
        '01:01:01.000000'
    )
    assert timed

# Generated at 2022-06-24 17:13:57.545472
# Unit test for function timedelta_format
def test_timedelta_format():
    if PY3:
        td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                       microseconds=4)
        assert timedelta_format(td) == '01:02:03.000004'



# Generated at 2022-06-24 17:14:04.273364
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(0, 1, 723171))
    assert result == '00:00:01.723171'

    result = timedelta_format(datetime_module.timedelta(10, 723171))
    assert result == '10:00:01.723171'



# Generated at 2022-06-24 17:14:14.525075
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_timedelta_format(timedelta, expected_result):
        time = (datetime_module.datetime.min + timedelta).time()
        result = time_isoformat(time, timespec='microseconds')
        assert result == expected_result
    assert_timedelta_format(
        datetime_module.timedelta(hours=13, minutes=40, seconds=1, microseconds=0),
        '13:40:01.000000'
    )
    assert_timedelta_format(
        datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=123456),
        '23:59:59.123456'
    )

# Generated at 2022-06-24 17:14:21.446469
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    with pytest.raises(ValueError):
        timedelta_parse('00:00:00.123456.123')



# Generated at 2022-06-24 17:14:29.805685
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-24 17:15:52.263509
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(microseconds=999999)
    assert timedelta_format(timedelta_0) == '00:00:00.999999'
    timedelta_0 = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta_0) == '00:00:01.000000'
    timedelta_0 = datetime_module.timedelta(minutes=1)
    assert timedelta_format(timedelta_0) == '00:01:00.000000'
    timedelta_0 = datetime_module.timedelta(hours=1)
    assert timedelta_format(timedelta_0) == '01:00:00.000000'
    timedelta_0 = datetime_module.timedelta(days=1)

# Generated at 2022-06-24 17:15:58.507664
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:00:00.000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('01:01:00.000000')) == '01:01:00.000000'
    assert timedelta_format(timedelta_parse('01:01:01.000000')) == '01:01:01.000000'
    assert timedelta_format(timedelta_parse('01:01:01.000001')) == '01:01:01.000001'

# Generated at 2022-06-24 17:16:03.882944
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(hours=1,
                                                        minutes=2,
                                                        seconds=3,
                                                        microseconds=456789))
    assert result == '01:02:03.456789'


# Generated at 2022-06-24 17:16:14.490611
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1))) == datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 60*60*24*1000))) == \
           datetime_module.timedelta(0, 60*60*24*1000)



# Generated at 2022-06-24 17:16:19.229518
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Case 0:
    td_0 = timedelta_parse('01:02:03.000001')
    assert td_0 == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                             microseconds=1)

    # Case 1:
    td_1 = timedelta_parse('01:02:03.002001')
    assert td_1 == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                             microseconds=2001)



# Generated at 2022-06-24 17:16:24.615689
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = timedelta_parse('17:34:51.123456')
    assert isinstance(timedelta_0, datetime_module.timedelta)
    assert timedelta_0 == datetime_module.timedelta(
        hours=17, minutes=34, seconds=51, milliseconds=123,
        microseconds=456
    )


# Generated at 2022-06-24 17:16:32.592661
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(timedelta_parse('0:0:0.0'))) == \
            timedelta_parse('0:0:0.0')
    assert timedelta_parse(timedelta_format(timedelta_parse('0:0:0.000000'))) == \
            timedelta_parse('0:0:0.000000')
    assert timedelta_parse(timedelta_format(timedelta_parse('0:0:0.123456'))) == \
            timedelta_parse('0:0:0.123456')
    assert timedelta_parse(timedelta_format(timedelta_parse('0:0:57.123456'))) == \
            timedelta_parse('0:0:57.123456')

# Generated at 2022-06-24 17:16:36.357704
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456)
    assert timedelta_format(td) == '01:02:03.123456'


# Generated at 2022-06-24 17:16:47.995843
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == ('00:00:00.000000')
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == ('00:00:01.000000')
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == ('00:01:00.000000')

    assert timedelta_format(datetime_module.timedelta(seconds=3400)) == ('00:56:40.000000')
    assert timedelta_format(datetime_module.timedelta(seconds=3599)) == ('00:59:59.000000')

    assert timedelta_format(datetime_module.timedelta(seconds=3600)) == ('01:00:00.000000')

# Generated at 2022-06-24 17:16:51.845766
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                          microseconds=6)
    assert timedelta_format(timedelta) == '01:23:45.000006'

