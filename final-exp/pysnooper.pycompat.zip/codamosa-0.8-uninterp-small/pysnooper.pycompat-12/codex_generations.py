

# Generated at 2022-06-24 17:08:56.313304
# Unit test for function timedelta_format
def test_timedelta_format():
    v0 = timedelta_format('')
    assert v0 == '00:00:00.000000'
    v0 = timedelta_format('')
    assert v0 == '00:00:00.000000'


# Generated at 2022-06-24 17:09:07.086089
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert type(timedelta_parse('write')) == type(datetime_module.timedelta(hours=write, minutes=-360, seconds=-7920))
    assert timedelta_parse('write') == datetime_module.timedelta(hours=write, minutes=-360, seconds=-7920)
    assert timedelta_parse('write') == datetime_module.timedelta(hours=write, minutes=-360, seconds=-7920)
    assert timedelta_parse('write') != datetime_module.timedelta(hours=1, minutes=1, seconds=0, microseconds=0)
    assert timedelta_parse('write') != 'write'
    assert timedelta_parse('write') != datetime_module.timedelta(hours=write, minutes=-360, seconds=-7920)

# Generated at 2022-06-24 17:09:11.878922
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        assert timedelta_parse('00:00:01.234567') - datetime_module.timedelta(seconds=1.234567) < datetime_module.timedelta(microseconds=1)
    except Exception as ex:
        raise Exception(str(ex))



# Generated at 2022-06-24 17:09:20.452595
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''Test function timedelta_parse'''
    # Passed parameters and expected results:
    test_case_0.__dict__.update(locals())
    timedelta_parse_test_cases = [
        # TODO: Add test cases
    ]

    # Populate the globals dict with variables from the test case dicts
    for test_case in timedelta_parse_test_cases:
        for key, value in test_case.items():
            globals()[key] = value
        yield test_timedelta_parse, test_case



# Generated at 2022-06-24 17:09:28.456575
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-24 17:09:38.356206
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == '00:00:00.001000'

# Generated at 2022-06-24 17:09:42.058675
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = timedelta_parse('read')
    assert var_0 == datetime_module.timedelta()



# Generated at 2022-06-24 17:09:52.327308
# Unit test for function timedelta_parse

# Generated at 2022-06-24 17:10:02.752093
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4,
                                                      milliseconds=5,
                                                      days=6, weeks=7)) == '01:02:03.000004'
    test_case_0()

# Generated at 2022-06-24 17:10:06.405175
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()


# Generated at 2022-06-24 17:10:15.951901
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.time(12, 15, 43, 567_890)
    assert timedelta_format(t) == '12:15:43.056789'



# Generated at 2022-06-24 17:10:23.084610
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Tries to test an unrecognizable string.
    # Workaround for a bug:
    # timedelta_parse() raises ValueError instead of TypeError
    try:
        timedelta_parse('abc')
    except TypeError:
        pass

    # Tests with a list of strings and the numbers they should convert to
    list_0 = ['0:00:00.01', timedelta_parse('0:00:00.01')]
    list_1 = ['0:00:00.010', timedelta_parse('0:00:00.010')]
    list_2 = ['0:00:00.000001', timedelta_parse('0:00:00.000001')]
    list_3 = ['0:00:00.0000010', timedelta_parse('0:00:00.0000010')]

# Generated at 2022-06-24 17:10:31.805374
# Unit test for function timedelta_format
def test_timedelta_format():
    # Basic test
    assert timedelta_format(datetime_module.timedelta(microseconds=6)) == \
           "00:00:00.000006"
    # Test time boundaries
    assert timedelta_format(datetime_module.timedelta(seconds=59,
                                                      microseconds=999999)) == \
           "00:00:59.999999"
    assert timedelta_format(datetime_module.timedelta(minutes=59,
                                                      microseconds=999999)) == \
           "00:59:59.999999"
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      microseconds=999999)) == \
           "23:59:59.999999"
    # Test lots of zeros (this was a bug)

# Generated at 2022-06-24 17:10:41.258957
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(0, 10)
    assert timedelta_parse('00:20:10.000000') == datetime_module.timedelta(0, 20*60 + 10)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(hours=1, seconds=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-24 17:10:55.505423
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Assert that `00:00:00.00` parses to `00:00:00`:
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    # Assert that `12:23:45.678` parses to `12:23:45.678`:
    assert timedelta_parse('12:23:45.678') == datetime_module.timedelta(
        hours=12, minutes=23, seconds=45, microseconds=678,
    )
    # Assert that `123:45:67.8` parses to `123:45:67.8`:

# Generated at 2022-06-24 17:11:04.574397
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert(timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0))
    assert(timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1))
    assert(timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000))
    assert(timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000))
    assert(timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000))

# Generated at 2022-06-24 17:11:10.737057
# Unit test for function timedelta_format
def test_timedelta_format():
    # No input
    # No output
    if timedelta_format(timedelta_format) != timedelta_format(timedelta_format):
        raise AssertionError("""Function timedelta_format failed on input:
            timedelta_format"""
            )

    # No input
    # No output
    if timedelta_format(test_case_0) != timedelta_format(test_case_0):
        raise AssertionError("""Function timedelta_format failed on input:
            test_case_0"""
            )



# Generated at 2022-06-24 17:11:21.610234
# Unit test for function timedelta_format
def test_timedelta_format():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', ['input', 'output'])

# Generated at 2022-06-24 17:11:25.521354
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=12, minute=0, second=0, microsecond=1234)
    time_isoformat(time, timespec='microseconds') == '12:00:00.001234'



# Generated at 2022-06-24 17:11:27.888209
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == "01:00:00.000000"


# Generated at 2022-06-24 17:11:50.057804
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == (
                                                          '02:03:04.000005')


# Generated at 2022-06-24 17:11:54.784122
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = 'write'
    var_0 = timedelta_parse(str_0)
    var_1 = timedelta_format(var_0)
    assert var_1 == '00:00:00.000000 write'

# Generated at 2022-06-24 17:12:07.016832
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Test the function timedelta_format
    '''
    timedelta_0 = datetime_module.timedelta(days=1)
    str_0 = timedelta_format(timedelta_0)
    assert isinstance(str_0, str)
    assert str_0 == '00:00:00.000000'
    timedelta_0 = datetime_module.timedelta(days=0, hours=1)
    str_0 = timedelta_format(timedelta_0)
    assert str_0 == '01:00:00.000000'
    timedelta_0 = datetime_module.timedelta(days=0, hours=0, minutes=1)
    str_0 = timedelta_format(timedelta_0)
    assert str_0 == '00:01:00.000000'

# Generated at 2022-06-24 17:12:17.267983
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format_0 = datetime_module.timedelta(microseconds=1)
    timedelta_format_1 = datetime_module.timedelta(seconds=1)
    timedelta_format_2 = datetime_module.timedelta(minutes=1)
    timedelta_format_3 = datetime_module.timedelta(hours=1)
    timedelta_format_4 = datetime_module.timedelta(days=1)
    timedelta_format_5 = datetime_module.timedelta(days=1, hours=1)
    timedelta_format_6 = datetime_module.timedelta(days=1, minutes=1)
    timedelta_format_7 = datetime_module.timedelta(days=1, seconds=1)
    timedelta_format_8 = dat

# Generated at 2022-06-24 17:12:25.174797
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_cases = [
        # Test case 0
        (
            {
                'str_0': 'write',
            },
            None
        ),
    ]

    for kwargs, assertion in test_cases:
        try:
            timedelta_parse(**kwargs)
        except AssertionError:
            raise AssertionError('Test case failed: %s' % kwargs)
        if assertion is not None:
            raise AssertionError('Test case failed: %s' % kwargs)


# Generated at 2022-06-24 17:12:28.907692
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('write') == datetime_module.timedelta(0)
    assert timedelta_parse('read') == datetime_module.timedelta(1)
    assert timedelta_parse('trace') == datetime_module.timedelta(2)
    assert timedelta_parse('take') == datetime_module.timedelta(3)



# Generated at 2022-06-24 17:12:31.995308
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = datetime_module.timedelta(seconds = -1)

    assert timedelta_parse(timedelta_format(var_0)) == var_0
    assert timedelta_format(var_0) == '23:59:59.999994'



# Generated at 2022-06-24 17:12:37.143160
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=5, seconds=5)) == "00:05:05.000000"
    assert timedelta_format(datetime_module.timedelta(hours=120)) == "120:00:00.000000"


# Generated at 2022-06-24 17:12:46.033138
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('3:33:55.555555')) == '03:33:55.555555'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:05:00.123400')) == '00:05:00.123400'
    assert timedelta_format(timedelta_parse('00:00:59.999999')) == '00:00:59.999999'



# Generated at 2022-06-24 17:12:48.058869
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = 'write'
    var_0 = timedelta_parse(str_0)

# Generated at 2022-06-24 17:13:13.871756
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('write')  == datetime_module.timedelta(microseconds=71582788)




# Generated at 2022-06-24 17:13:16.105980
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Assert that the time delta received in the string is equal to the time
    # delta produced from the string
    assert test_case_0() == datetime_module.timedelta(0)

# Generated at 2022-06-24 17:13:25.705259
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:00:00.000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('00:01:00.000000')) == '00:01:00.000000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'

# Generated at 2022-06-24 17:13:26.953315
# Unit test for function timedelta_format
def test_timedelta_format():

    expected = '00:00:00.000000'
    actual = timedelta_format(test_case_0())
    assert actual == expected



# Generated at 2022-06-24 17:13:33.064689
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    Tests whether the time format returned is correct
    """
    assert timedelta_format(datetime_module.timedelta(hours=1,minutes=2,seconds=3,microseconds=4)) == "01:02:03.000004"


# Generated at 2022-06-24 17:13:44.734483
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_1 = timedelta_parse("00:00:00.000000")
    var_2 = timedelta_parse("00:00:00.000002")
    var_3 = timedelta_parse("00:00:00.000003")
    var_4 = timedelta_parse("00:00:00.000004")
    var_5 = timedelta_parse("00:00:00.000005")
    var_6 = timedelta_parse("00:00:00.000006")
    var_7 = timedelta_parse("00:00:00.000007")
    var_8 = timedelta_parse("00:00:00.000008")
    var_9 = timedelta_parse("00:00:00.000009")
    var_10 = timedelta_parse("00:00:00.000010")


# Generated at 2022-06-24 17:13:52.913234
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3600)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3660)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3661)) == '01:01:01.000000'

# Generated at 2022-06-24 17:14:06.223993
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0.000001)) == '00:00:00:000001'
    assert timedelta_format(datetime_module.timedelta(seconds=0.0001)) == '00:00:00:001000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=50)) == '00:00:00:050000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01:000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=0)) == '00:00:01:000000'

# Generated at 2022-06-24 17:14:13.333988
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        microseconds=0
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1, microseconds=0
    )
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(
        seconds=1, microseconds=999999
    )
    assert timedelta_parse('00:00:59.999999') == datetime_module.timedelta(
        seconds=59, microseconds=999999
    )
    assert timedelta_parse

# Generated at 2022-06-24 17:14:23.154881
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0,0,999)) == '00:00:00.000999'
    assert timedelta_format(datetime_module.timedelta(0,0,999,1000)) == '00:00:01.001999'
    assert timedelta_format(datetime_module.timedelta(0,0,999,1000,1000)) == '00:01:01.002999'
    assert timedelta_format(datetime_module.timedelta(0,0,999,1000,1000,1000)) == '01:01:01.003999'
    assert timedelta_format(datetime_module.timedelta(3,2,1,0)) == '72:02:01.000000'

# Generated at 2022-06-24 17:14:51.276210
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                               microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=11,
                                                      seconds=12,
                                               microseconds=13)) == '10:11:12.000013'


# Generated at 2022-06-24 17:14:52.433739
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(str_0) == datetime_module.timedelta(0)


# Generated at 2022-06-24 17:14:58.017858
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test case 0
    timedelta_0 = datetime_module.timedelta(0)
    str_0 = timedelta_format(timedelta_0)
    assert str_0 == '00:00:00.000000', str_0

    # Test case 1
    timedelta_1 = datetime_module.timedelta(seconds=10)
    str_1 = timedelta_format(timedelta_1)
    assert str_1 == '00:00:10.000000', str_1

    # Test case 2
    timedelta_2 = datetime_module.timedelta(minutes=10)
    str_2 = timedelta_format(timedelta_2)
    assert str_2 == '00:10:00.000000', str_2

    # Test case 3
    timedelta_3 = datetime

# Generated at 2022-06-24 17:15:04.583125
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('10:45:34.000000') == datetime_module.timedelta(
        hours=10, minutes=45, seconds=34)
    assert timedelta_parse('10:45:34.123456') == datetime_module.timedelta(
        hours=10, minutes=45, seconds=34, microseconds=123456
    )



# Generated at 2022-06-24 17:15:08.229660
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()

if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-24 17:15:11.855075
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=23,
                                                      microseconds=500000)) == str_0


# Generated at 2022-06-24 17:15:21.692805
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # If s is type "str", then success is type "bool"
    success = False

    # If s is type "str", then result is type "datetime.timedelta"
    result = timedelta_parse('00:00:00.000000')

    # If s is type "str", then result is type "datetime.timedelta"
    # If s is type "str", then result is type "datetime.timedelta"
    # If s is type "str", then result is type "datetime.timedelta"
    # If s is type "str", then result is type "datetime.timedelta"
    result = timedelta_parse('00:00:00.000000')
    result = timedelta_parse('00:00:00.000100')

# Generated at 2022-06-24 17:15:23.896780
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse(str_0)) == str_0


# Generated at 2022-06-24 17:15:29.861271
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(str_0) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(str_1) == datetime_module.timedelta(seconds=1)


# Generated at 2022-06-24 17:15:45.797124
# Unit test for function timedelta_format
def test_timedelta_format():
    time_0 = datetime_module.timedelta()
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'
    assert timedelta_format(time_0) == '00:00:00.000000'

# Generated at 2022-06-24 17:16:41.277746
# Unit test for function timedelta_parse
def test_timedelta_parse():
    case_0 = timedelta_parse(timedelta_format(datetime_module.timedelta()))
    assert str(case_0) == '0:00:00'
    assert case_0.total_seconds() == 0
    assert not case_0.days

    case_1 = timedelta_parse(timedelta_format(datetime_module.timedelta(days=1)))
    assert str(case_1) == '0:00:00'
    assert case_1.total_seconds() == 0
    assert case_1.days == 1

    case_2 = timedelta_parse(timedelta_format(datetime_module.timedelta(days=2, microseconds=1)))
    assert str(case_2) == '0:00:00.000001'
    assert case_2.total_

# Generated at 2022-06-24 17:16:56.156005
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
           '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == \
           '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == \
           '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == \
           '00:00:00.001000'

# Generated at 2022-06-24 17:17:07.444563
# Unit test for function timedelta_format
def test_timedelta_format():

    # Tests for edge cases
    if timedelta_format(datetime_module.timedelta(seconds=0)) != '00:00:00.000000':
        raise AssertionError
    if timedelta_format(datetime_module.timedelta(seconds=1)) != '00:00:01.000000':
        raise AssertionError
    if timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) != '00:00:01.000001':
        raise AssertionError
    if timedelta_format(datetime_module.timedelta(days=1, seconds=2, microseconds=3)) != \
       '48:00:02.000003':
        raise AssertionError

    # Test for a random value

# Generated at 2022-06-24 17:17:12.206380
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == str_0
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=100,
    )) == '02:03:04.000100'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=100000,
    )) == '00:00:00.100000'
    # Unit test for function timedelta_parse

# Generated at 2022-06-24 17:17:18.667126
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
                                                                  '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                  '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=-1)) == \
                                                                 '23:59:59.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )) == '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999998
    ))

# Generated at 2022-06-24 17:17:25.170180
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-24 17:17:35.988672
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == str_0
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1)) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-24 17:17:46.151670
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test for cases of timedelta_format
    for i in range(100):
        delta_0 = datetime_module.timedelta(hours=i,
                                            minutes=i,
                                            seconds=i,
                                            microseconds=i)
        str_0 = timedelta_format(delta_0)
        delta_1 = timedelta_parse(str_0)
        assert delta_0 == delta_1, "str_0 " + str_0 + ' ' + str(delta_0) + ' ' + str(delta_1)
test_case_0()
test_timedelta_format()

# Generated at 2022-06-24 17:17:49.326981
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(0, 0, 0)
    assert timedelta_format(timedelta) == '00:00:00.000000'



# Generated at 2022-06-24 17:18:00.718709
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = datetime_module.timedelta(microseconds=0)
    timedelta_0_str = timedelta_format(timedelta_0)
    assert timedelta_format(timedelta_parse(timedelta_0_str)) == timedelta_0_str

    timedelta_1 = datetime_module.timedelta(hours=-1)
    timedelta_1_str = timedelta_format(timedelta_1)
    assert timedelta_format(timedelta_parse(timedelta_1_str)) == timedelta_1_str

    timedelta_2 = datetime_module.timedelta(minutes=-1)
    timedelta_2_str = timedelta_format(timedelta_2)