

# Generated at 2022-06-24 17:08:54.293981
# Unit test for function timedelta_format
def test_timedelta_format():

    # Test 1:
    int_0 = 312
    str_0 = timedelta_format(int_0)
    assert str_0 == '00:05:12.000000'

    # Test 2:
    int_0 = 12
    str_0 = timedelta_format(int_0)
    assert str_0 == '00:00:12.000000'

    # Test 3:
    int_0 = 31222
    str_0 = timedelta_format(int_0)
    assert str_0 == '00:05:12.220000'

    # Test 4:
    int_0 = -21
    str_0 = timedelta_format(int_0)
    assert str_0 == '-00:00:21.000000'


# Generated at 2022-06-24 17:09:02.804548
# Unit test for function timedelta_parse

# Generated at 2022-06-24 17:09:10.806263
# Unit test for function timedelta_parse
def test_timedelta_parse():

    import sys
    from pytest import raises
    def test_case_1():
        timedelta_a = '00:00:06.'
        timedelta_b = '00:00:06.11'
        timedelta_c = '00:00:06.111111'
        timedelta_d = '00:00:6'
        timedelta_e = '00:00:06.1111111'

        with raises(ValueError) as e:
            timedelta_parse(timedelta_a)
        with raises(ValueError) as e:
            timedelta_parse(timedelta_b)
        with raises(ValueError) as e:
            timedelta_parse(timedelta_c)
        with raises(ValueError) as e:
            timedelta_parse(timedelta_d)

# Generated at 2022-06-24 17:09:22.314130
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-24 17:09:25.438195
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (
        datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                  milliseconds=5, microseconds=6),
    ):
        assert timedelta_format(timedelta) == str(timedelta)

# Generated at 2022-06-24 17:09:28.275959
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'

# Generated at 2022-06-24 17:09:33.412223
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('07:07:07.000007')) == '07:07:07.000007'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'


# Generated at 2022-06-24 17:09:47.062516
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ) == '01:02:03.456789'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=0)
    ) == '01:02:03.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=1)
    ) == '01:02:03.000001'

# Generated at 2022-06-24 17:09:54.759672
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(seconds=3))
    assert result == '00:00:03'
    result = timedelta_format(datetime_module.timedelta(minutes=3))
    assert result == '00:03:00'
    result = timedelta_format(datetime_module.timedelta(minutes=3,
                                                        seconds=5))
    assert result == '00:03:05'
    result = timedelta_format(datetime_module.timedelta(minutes=3,
                                                        seconds=5,
                                                        microseconds=500))
    assert result == '00:03:05.000500'

# Generated at 2022-06-24 17:10:01.319305
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Test the timedelta_format function with datetime.timedelta
    '''
    var_1 = 5
    var_2 = datetime_module.timedelta(minutes=var_1)
    var_3 = timedelta_format(var_2)
    test.equal(var_3, "00:05:00.000000")


# Generated at 2022-06-24 17:10:22.162544
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=333333)) == \
           '23:59:59.333333'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == \
           '00:00:01.100000'

# Generated at 2022-06-24 17:10:27.589206
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] >= (3, 6):
        assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1)) == '00:00:00.000001'
        assert timedelta_format(datetime_module.timedelta(0, 0, 0, 10)) == '00:00:00.000010'
        assert timedelta_format(datetime_module.timedelta(0, 0, 0, 100)) == '00:00:00.000100'
        assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1000)) == '00:00:00.001000'
        assert timedelta_format(datetime_module.timedelta(0, 0, 0, 10000)) == '00:00:00.010000'
       

# Generated at 2022-06-24 17:10:42.389033
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=312)) == '05:12:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=1)) == '04:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=675)) == '00:00:00.675000'

    assert timedelta_format(datetime_module.timedelta(seconds=312)) == '00:05:12.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=4, seconds=1)) == '00:04:01.000000'

# Generated at 2022-06-24 17:10:48.360366
# Unit test for function timedelta_format
def test_timedelta_format():
    int_0 = 312
    timedelta_0 = timedelta_parse(int_0)
    result_0 = timedelta_format(timedelta_0)
    assert result_0 == '00:05:12.000000'

# Generated at 2022-06-24 17:10:56.591172
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('0:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('0:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-24 17:11:05.042791
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.040000')) == '00:00:00.040000'
    assert timedelta_format(timedelta_parse('00:01:23.456789')) == '00:01:23.456789'
    assert timedelta_format(timedelta_parse('01:02:03.456789')) == '01:02:03.456789'
    assert timedelta_format(timedelta_parse('12:34:56.789012')) == '12:34:56.789012'
    # Test the test:

# Generated at 2022-06-24 17:11:13.182988
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    Make sure that `timedelta_format` produces the expected output.
    """
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      milliseconds=3,
                                                      microseconds=4)) == \
           '00:00:02.003004'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      milliseconds=5,
                                                      microseconds=6)) == \
           '26:03:04.005006'


# Generated at 2022-06-24 17:11:18.612377
# Unit test for function timedelta_parse
def test_timedelta_parse():
    int_0 = 312
    var_2 = timedelta_parse(int_0)
    int_1 = 0
    # Call subroutine 'assert_equal'
    assert_equal(var_2, int_1)

# Generated at 2022-06-24 17:11:26.730891
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Test if the string representation of the timedelta could be parsed
    """
    assert timedelta_parse('10:10:10.123456') == datetime_module.timedelta(10, 3710, 123456)
    assert timedelta_parse('10:10:10.12345') == datetime_module.timedelta(10, 3710, 12345)
    assert timedelta_parse('10:10:10.1234') == datetime_module.timedelta(10, 3710, 1234)
    assert timedelta_parse('10:10:10.123') == datetime_module.timedelta(10, 3710, 123)
    assert timedelta_parse('10:10:10.12') == datetime_module.timedelta(10, 3710, 12)

# Generated at 2022-06-24 17:11:29.516276
# Unit test for function timedelta_parse
def test_timedelta_parse():

    test_case_0()

    # var_0 = timedelta_parse('00:00:00.000000')
    # assert var_0 == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:12:03.245530
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.datetime.min
    result_0 = '00:00:00.000000'
    assert timedelta_format(timedelta_0) == result_0
    timedelta_0 = datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0
    )
    result_0 = '01:00:00.000000'
    assert timedelta_format(timedelta_0) == result_0
    timedelta_0 = datetime_module.timedelta(
        hours=2, minutes=0, seconds=0, microseconds=0
    )
    result_0 = '02:00:00.000000'
    assert timedelta_format(timedelta_0) == result_0
    timedelta_0 = datetime_module

# Generated at 2022-06-24 17:12:06.221113
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test that the time delta is represented as a string with 15 characters.
    assert len(timedelta_format(datetime_module.timedelta(hours=10, minutes=11, seconds=12, microseconds=13))) == 15


# Generated at 2022-06-24 17:12:12.074261
# Unit test for function timedelta_format
def test_timedelta_format():
    # 1
    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=3))\
           == '00:02:03.000000'

if __name__ == '__main__':
    test_timedelta_format()

# Generated at 2022-06-24 17:12:23.294086
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from python_toolbox.nifty_collections import OrderedDict
    from python_toolbox.nifty_collections import LazyTuple
    from python_toolbox import nifty_functions
    from python_toolbox import date_time_tools
    from python_toolbox import math_tools
    from python_toolbox import system_tools
    from python_toolbox import dict_tools
    from python_toolbox import sequencing
    from python_toolbox import import_tools
    from python_toolbox import caching
    from python_toolbox import memoize
    from python_toolbox import persistence
    from python_toolbox import weak_ref
    from python_toolbox import lazy_object
    from python_toolbox import pretty_printing
    from python_toolbox import emulation
    from python_toolbox import decorator_tools

# Generated at 2022-06-24 17:12:28.999998
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('Running test_timedelta_parse')
    test_case_0()

if PY3:
    import io
    import _pyio as pyio
    _PyIOBase = pyio.TextIOBase
else:
    import StringIO as io
    import _pyio as pyio
    _PyIOBase = pyio.StringIO

_PY2_PYIO_ENCODING_ATTRIBUTE_NAME = '_encoding'
_PY3_PYIO_ENCODING_ATTRIBUTE_NAME = 'encoding'


# Generated at 2022-06-24 17:12:37.324967
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=3, minutes=3, seconds=3, microseconds=300000
    )) == '03:03:03.300000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=1, seconds=0, microseconds=50000
    )) == '00:01:00.050000'


# Generated at 2022-06-24 17:12:44.555138
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('312') == datetime_module.timedelta(seconds=312))
    assert (timedelta_parse('312.345') == datetime_module.timedelta(seconds=312, microseconds=345000))
    assert (timedelta_parse('00:05:12') == datetime_module.timedelta(seconds=312))
    assert (timedelta_parse('00:05:12.345') == datetime_module.timedelta(seconds=312, microseconds=345000))



# Generated at 2022-06-24 17:12:53.775519
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Try with int
    int_0 = 312
    assert timedelta_parse(int_0) == datetime_module.timedelta(312)
    # Try with string
    str_0 = '03:30:12'
    assert timedelta_parse(str_0) == datetime_module.timedelta(hours=3, minutes=30, seconds=12)
    # Try with float
    # float_0 = 312.3
    # assert timedelta_parse(float_0) == datetime_module.timedelta(312, 300000000)
    # Try with negative datetime
    datetime_0 = -datetime_module.datetime(year=2020, month=5, day=12, hour=2, minute=30)
    assert timedelta_parse(datetime_0) == datetime_module.timedelta

# Generated at 2022-06-24 17:13:04.447922
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(0, 0, 1e-6)
    assert timedelta_parse('00:00:00.001') == datetime_module.timedelta(0, 0, 1e-6)
    assert timedelta_parse('00:00:00.0001') == datetime_module.timedelta(0, 0, 1e-7)
    assert timedelta_parse('00:00:00.00001') == datetime_module.timedelta(0, 0, 1e-7)

# Generated at 2022-06-24 17:13:11.208704
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test default case.
    v = timedelta_format(datetime_module.timedelta(seconds=8))
    assert v == '00:00:08.000000'

    # Test default case.
    v = timedelta_format(datetime_module.timedelta(seconds=8))
    assert v == '00:00:08.000000'



# Generated at 2022-06-24 17:13:42.324122
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("0:0:0.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("0:0:15.000000") == datetime_module.timedelta(seconds=15)
    assert timedelta_parse("0:15:0.000000") == datetime_module.timedelta(minutes=15)
    assert timedelta_parse("15:0:0.000000") == datetime_module.timedelta(hours=15)
    assert timedelta_parse("0:0:0.000001") == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse("0:0:0.000010") == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse("0:0:0.000100")

# Generated at 2022-06-24 17:13:52.656137
# Unit test for function timedelta_format
def test_timedelta_format():
    assert False == (datetime_module.datetime.min + datetime_module.timedelta(hours=1, minutes=1,
                                                                              seconds=1,
                                                                              microseconds=1)).time().isoformat()
    assert '01:01:01.000001' == (datetime_module.datetime.min + datetime_module.timedelta(hours=1, minutes=1,
                                                                                         seconds=1,
                                                                                         microseconds=1)).time().isoformat(timespec='microseconds')
    assert '01:01:01.000001' == timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                                          seconds=1,
                                                                          microseconds=1))
    assert '0:01:01'

# Generated at 2022-06-24 17:14:05.987631
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse("00:00:00.000010") == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse("00:00:00.000100") == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse("00:00:00.001000") == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse("00:00:00.010000") == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-24 17:14:11.304340
# Unit test for function timedelta_parse
def test_timedelta_parse():
    f_0 = True
    f_1 = False
    f_2 = True
    r_0 = timedelta_parse(f_0)
    r_1 = timedelta_parse(f_1)
    r_2 = timedelta_parse(f_2)

    # Verify if the variables match
    assert r_0 == True
    assert r_1 == False
    assert r_2 == True


# Generated at 2022-06-24 17:14:14.471765
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_1 = '00:00:00.000000'
    var_2 = timedelta_parse(var_1)
    assert var_2 == datetime_module.timedelta(0)

# Generated at 2022-06-24 17:14:22.005590
# Unit test for function timedelta_format
def test_timedelta_format():
    assert(timedelta_format(datetime_module.timedelta(0, 1)) == "00:00:01.000000")
    assert(timedelta_format(datetime_module.timedelta(0, 60)) == "00:01:00.000000")
    assert(timedelta_format(datetime_module.timedelta(0, 3600)) == "01:00:00.000000")
    assert(timedelta_format(datetime_module.timedelta(0, 3600*60)) == "60:00:00.000000")


# Generated at 2022-06-24 17:14:30.872740
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(hours=0,
                                                              minutes=0,
                                                              seconds=0,
                                                              microseconds=0)
    assert timedelta_parse('0:00:00.010000') == datetime_module.timedelta(hours=0,
                                                              minutes=0,
                                                              seconds=0,
                                                              microseconds=1000)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(hours=0,
                                                              minutes=0,
                                                              seconds=0,
                                                              microseconds=1)
    assert timedelta_parse('0:00:00.100000') == datetime_module.tim

# Generated at 2022-06-24 17:14:35.500927
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse("0:00:00.000000"), datetime_module.timedelta)


# Generated at 2022-06-24 17:14:42.862604
# Unit test for function timedelta_parse
def test_timedelta_parse():
    a = datetime_module.timedelta(days=1, hours=12, minutes=0, seconds=0)
    assert timedelta_parse("12:00:00.000000") == a
    # print(timedelta_parse("12:00:00.000000"))


if __name__ == '__main__':
    test_case_0()
    test_timedelta_parse()

# Generated at 2022-06-24 17:14:50.226811
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)

# Generated at 2022-06-24 17:15:46.709084
# Unit test for function timedelta_format
def test_timedelta_format():
    # Get actual result.
    func = timedelta_format
    print(func.__name__)
    for cls in [timedelta_format]:
        for subcls in cls.__subclasses__():
            subcls.test_case_0(func)
            break


# Generated at 2022-06-24 17:15:55.381459
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('0:0:1.999999') == datetime_module.timedelta(seconds=1, microseconds=999999)
    assert timed

# Generated at 2022-06-24 17:15:59.552393
# Unit test for function timedelta_format
def test_timedelta_format():
    import random

    for _ in range(1000):
        timedelta = datetime_module.timedelta(
            microseconds=random.randint(-1000000000, 1000000000)
        )
        assert timedelta == timedelta_parse(timedelta_format(timedelta))


if __name__ == '__main__':
    test_case_0()
    test_timedelta_format()

# Generated at 2022-06-24 17:16:10.502425
# Unit test for function timedelta_format
def test_timedelta_format():
    bool_0 = False
    var_0 = timedelta_format(bool_0)
    assert var_0 == '00:00:00.000000'
    bool_1 = False
    var_1 = timedelta_format(bool_1)
    assert var_1 == '00:00:00.000000'
    bool_2 = True
    var_2 = timedelta_format(bool_2)
    assert var_2 == '00:00:00.000000'
    bool_3 = False
    var_3 = timedelta_format(bool_3)
    assert var_3 == '00:00:00.000000'
    bool_4 = False
    var_4 = timedelta_format(bool_4)
    assert var_4 == '00:00:00.000000'
    bool_5 = False
    var

# Generated at 2022-06-24 17:16:17.363043
# Unit test for function timedelta_format
def test_timedelta_format():
    bool_0 = False
    var_0 = timedelta_format(bool_0)
    assert var_0 == '00:00:00.000000'
    bool_0 = True
    var_0 = timedelta_format(bool_0)
    assert var_0 == '00:00:00.000001'
    bool_0 = False
    var_0 = timedelta_format(bool_0)
    assert var_0 == '00:00:00.000000'
    bool_0 = True
    var_0 = timedelta_format(bool_0)
    assert var_0 == '00:00:00.000001'



# Generated at 2022-06-24 17:16:19.301488
# Unit test for function timedelta_format
def test_timedelta_format():
    # test case 0:
    test_case_0()


# Generated at 2022-06-24 17:16:20.808739
# Unit test for function timedelta_format
def test_timedelta_format():
    print('\nRunning test of function timedelta_format...')
    test_case_0()

test_timedelta_format()

# Generated at 2022-06-24 17:16:26.515131
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Ensure that function timedelta_parse generates correct output.
    '''
    # Test data
    var_0 = '0:00:00:000000'
    expected_result = datetime_module.timedelta(0)
    actual_result = timedelta_parse(var_0)

    assert actual_result == expected_result


# Generated at 2022-06-24 17:16:38.355687
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Testing function timedelta_parse
    """
    print("In function " + __name__ + ": " + test_timedelta_parse.__doc__)

    # Set up test values
    str_0 = "12:30:00.000000"
    timedelta_0 = datetime_module.timedelta(seconds=45000, minutes=30, hours=12)
    timedelta_1 = datetime_module.timedelta(seconds=5)
    timedelta_2 = datetime_module.timedelta(seconds=4)
    timedelta_3 = datetime_module.timedelta(seconds=5)
    # Test compare
    assert(timedelta_parse(str_0) == timedelta_0)
    # Test with no args
    # Test with one arg

# Generated at 2022-06-24 17:16:49.156131
# Unit test for function timedelta_parse