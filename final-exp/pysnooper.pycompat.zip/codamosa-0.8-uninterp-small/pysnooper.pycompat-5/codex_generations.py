

# Generated at 2022-06-24 17:08:54.818428
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Expected : 0:00:00.000100
    # Passed   : 0:00:00.000000
    assert timedelta_parse('.') == datetime_module.timedelta(0, microseconds=100)
    # Expected : 0:00:01.000000
    # Passed   : 0:00:00.000000
    assert timedelta_parse(':') == datetime_module.timedelta(0, seconds=1)
    # Expected : 0:01:01.000000
    # Passed   : 0:00:00.000000
    assert timedelta_parse('::') == datetime_module.timedelta(0, minutes=1, seconds=1)
    # Expected : 1:01:01.000000
    # Passed   : 0:00:00.000000
    assert timedelta_parse(':::')

# Generated at 2022-06-24 17:09:05.503549
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )

# Generated at 2022-06-24 17:09:11.598987
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(seconds = 1, microseconds = 33)
    str_0 = '00:00:01.000033'
    assert timedelta_format(timedelta_0) == str_0


# Generated at 2022-06-24 17:09:22.571902
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.') == datetime_module.timedelta(0, 0, 0, 1000)
    assert timedelta_parse('0.1') == datetime_module.timedelta(0, 0, 0, 100000)
    assert timedelta_parse('1.1') == datetime_module.timedelta(0, 0, 1, 100000)
    assert timedelta_parse('1:1') == datetime_module.timedelta(0, 60, 1)
    assert timedelta_parse('1:1.1') == datetime_module.timedelta(0, 60, 1, 100000)
    assert timedelta_parse('1:1:1') == datetime_module.timedelta(0, 3660, 1)
    assert timedelta_parse('1:1:1.1') == dat

# Generated at 2022-06-24 17:09:25.306913
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_compatibility
    assert test_compatibility.timedelta_format(
        datetime_module.timedelta(seconds=2, microseconds=1)
    ) == '00:00:02.000001'



# Generated at 2022-06-24 17:09:37.115924
# Unit test for function timedelta_format
def test_timedelta_format():
    # pick a couple of times
    times = [datetime_module.timedelta(microseconds=1),
             datetime_module.timedelta(0, 1, 2, 3),
             datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                       microseconds=999999),
             datetime_module.timedelta(days=1),
             datetime_module.timedelta(hours=1, seconds=1, microseconds=1),
             datetime_module.timedelta(minutes=1, seconds=1, microseconds=1),
             datetime_module.timedelta(days=999999, hours=23, minutes=59,
                                       seconds=59, microseconds=999999),
             ]
    for t in times:
        s = timedelta_format(t)

# Generated at 2022-06-24 17:09:46.032974
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # These are the expected results of the test
    expected_value = type(0)

    test_case_number = 0
    if test_case_number == 0:
        # The first test case
        test_case_input_0 = '0:00:00.040000'
        test_case_input_1 = '0:00:19.0'
        test_case_input_2 = '0:00:19.00'
        test_case_input_3 = '0:00:19.000'
        test_case_input_4 = '0:00:19.0000'
        test_case_input_5 = '0:00:19.00000'
        test_case_input_6 = '0:00:19.000000'

# Generated at 2022-06-24 17:09:51.760043
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(
        microseconds=123456)
    assert timedelta_parse('0:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456)
    assert timedelta_parse('0:01:01.123456') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=123456)
    assert timedelta_parse('1:01:01.123456') == datetime_

# Generated at 2022-06-24 17:09:59.074678
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == '24:00:00.000000'


# Generated at 2022-06-24 17:10:07.191229
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Assert that times can be parsed from string
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=0)
    # Assert that times can be parsed from string
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=1)
    # Assert that times can be parsed from string
    assert timedelta_parse('00:00:00.999999') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=999999)
    # Assert that times can be parsed from string
   

# Generated at 2022-06-24 17:10:23.828871
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
           '00:02:00.000000'


# Generated at 2022-06-24 17:10:37.837609
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=5)) == \
                                                                      '02:03:04.000005'

    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=5)) == \
                                                                      '02:03:04.000005'

    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=4,
                                                      microseconds=5)) == \
                                                                      '00:03:04.000005'

    assert timedelta_format(datetime_module.timedelta(seconds=4, microseconds=5))

# Generated at 2022-06-24 17:10:49.064222
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '0:0:0.1'
    var_0 = timedelta_parse(str_0)
    assert isinstance(var_0, datetime_module.timedelta)
    assert var_0.total_seconds() == 0.1
    
    str_1 = '0:0:0.0'
    var_1 = timedelta_parse(str_1)
    assert isinstance(var_1, datetime_module.timedelta)
    assert var_1.total_seconds() == 0.0
    
    str_2 = '0:0:0.01'
    var_2 = timedelta_parse(str_2)
    assert isinstance(var_2, datetime_module.timedelta)
    assert var_2.total_seconds() == 0.01
    
   

# Generated at 2022-06-24 17:10:56.898252
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '.'
    # assert timedelta_parse(str_0) is timedelta_parse(str_0)
    str_1 = '0.'
    # assert timedelta_parse(str_1) is timedelta_parse(str_1)
    str_2 = '00.'
    # assert timedelta_parse(str_2) is timedelta_parse(str_2)
    str_3 = '0.1'
    # assert timedelta_parse(str_3) is timedelta_parse(str_3)
    str_4 = '0.10'
    # assert timedelta_parse(str_4) is timedelta_parse(str_4)
    str_5 = '0.100'
    # assert timedelta_parse(str_5) is timedelta_parse(str_5)
    str

# Generated at 2022-06-24 17:11:05.155428
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=61, microseconds=1)) == '00:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1, microseconds=1)) == '00:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=61, seconds=1, microseconds=1)) == '01:01:01.000001'

# Generated at 2022-06-24 17:11:06.629473
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == str_0

# Generated at 2022-06-24 17:11:09.617628
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Unit test for function timedelta_parse

    Make sure the function performs as expected.
    """
    input_0 = "00:00:00.000000"
    output_0 = test_case_0()
    assert output_0 == input_0



# Generated at 2022-06-24 17:11:18.924886
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == '00:00:00.001000'

# Generated at 2022-06-24 17:11:26.816083
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'

    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'

    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == \
           '00:00:00.010000'


# Generated at 2022-06-24 17:11:35.899603
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) \
            == '02:03:04.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) \
            == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) \
            == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=12)) \
            == '00:00:00.000012'

# Generated at 2022-06-24 17:11:54.810928
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Assert that timedelta_parse raises a TypeError
    # when called with 'str' arg
    try:
        timedelta_parse('str')
    except TypeError:
        pass
    else:
        raise AssertionError

    # Assert that timedelta_parse on '.' equals expected result
    assert timedelta_parse('.') == datetime_module.timedelta(microseconds=1)

    # Assert that timedelta_parse on '.3' equals expected result
    assert timedelta_parse('.3') == datetime_module.timedelta(microseconds=300)

    # Assert that timedelta_parse on '.25' equals expected result
    assert timedelta_parse('.25') == datetime_module.timedelta(microseconds=250)

    # Assert that timedelta_parse on '.:' equals expected

# Generated at 2022-06-24 17:12:00.354600
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=58,
                                                      microseconds=123456)) == \
                                                      '23:59:58.123456'


# Generated at 2022-06-24 17:12:09.173484
# Unit test for function timedelta_format
def test_timedelta_format():
    #
    # Test cases
    #
    result = timedelta_format(datetime_module.time(0, 0, 0))
    expected = '00:00:00.000000'
    assert result == expected, 'Test case 0 failed'


    result = timedelta_format(datetime_module.time(0, 0, 0, 1))
    expected = '00:00:00.000001'
    assert result == expected, 'Test case 1 failed'


    result = timedelta_format(datetime_module.time(0, 1, 0))
    expected = '00:01:00.000000'
    assert result == expected, 'Test case 2 failed'


    result = timedelta_format(datetime_module.time(0, 1, 0, 1))
    expected = '00:01:00.000001'


# Generated at 2022-06-24 17:12:14.971864
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Testing that timedelta_parse(['.']) raises TypeError
    try:
        timedelta_parse(['.'])
    except TypeError:
        pass
    else:
        raise AssertionError
    # Testing that timedelta_parse('.') == datetime.timedelta(0)
    timedelta_parse('.') == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:12:25.556195
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(0, 1, 1)) == '00:00:01.000001'

    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(0, 10, 10)) == '00:00:10.000010'


# Generated at 2022-06-24 17:12:36.515769
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_5 = timedelta_parse('00:00:00.000000')
    assert var_5 == datetime_module.timedelta(seconds=0, microseconds=0)
    var_6 = timedelta_parse('00:00:01.000000')
    assert var_6 == datetime_module.timedelta(seconds=1, microseconds=0)
    var_7 = timedelta_parse('00:00:01.719000')
    assert var_7 == datetime_module.timedelta(seconds=1, microseconds=719000)
    var_8 = timedelta_parse('00:02:01.719000')
    assert var_8 == datetime_module.timedelta(seconds=121, microseconds=719000)

# Generated at 2022-06-24 17:12:40.429533
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(microseconds = 1)
    assert timedelta_format(timedelta_0) == '00:00:00.000001'


# Generated at 2022-06-24 17:12:52.220536
# Unit test for function timedelta_format

# Generated at 2022-06-24 17:13:01.566990
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.') == datetime_module.timedelta()
    assert timedelta_parse('.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('..123456') == datetime_module.timedelta(
        seconds=123456
    )
    assert timedelta_parse('1.23456') == datetime_module.timedelta(
        minutes=1, microseconds=23456
    )




# Generated at 2022-06-24 17:13:05.254213
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-24 17:13:33.655068
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test that timedelta_format formats `timedelta_0` as string "00:00:00.999999"
    timedelta_0 = datetime_module.timedelta(microseconds=999999)
    assert timedelta_format(timedelta_0) == "00:00:00.999999"
    # Test that timedelta_format formats `timedelta_1` as string "01:02:03.123456"
    timedelta_1 = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_format(timedelta_1) == "01:02:03.123456"


# Generated at 2022-06-24 17:13:45.035114
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.000000') == datetime_module.timedelta()
    assert timedelta_parse('.000500') == datetime_module.timedelta(
        microseconds=500
    )
    assert timedelta_parse('.999500') == datetime_module.timedelta(
        microseconds=999500
    )
    assert timedelta_parse('.000500') > datetime_module.timedelta()
    assert timedelta_parse('.001500') > datetime_module.timedelta(
        microseconds=500
    )
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()

# Generated at 2022-06-24 17:13:52.987565
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # No argument raises TypeError
    with pytest.raises(TypeError):
        timedelta_parse()
    # Argument must be a string
    with pytest.raises(TypeError):
        timedelta_parse(0)
    # String must have format 00:00:00.000000
    with pytest.raises(ValueError):
        timedelta_parse('hello world')
    with pytest.raises(ValueError):
        timedelta_parse('001:00:00.000000')
    with pytest.raises(ValueError):
        timedelta_parse('00:01:00.000000')
    with pytest.raises(ValueError):
        timedelta_parse('00:00:01.000000')

# Generated at 2022-06-24 17:14:06.275891
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('.000001') == datetime_module.timedelta(0, 1e-6)
    assert timedelta_parse('.000111') == datetime_module.timedelta(0, 111e-6)
    assert timedelta_parse('.011111') == datetime_module.timedelta(0, 11111e-6)
    assert timedelta_parse('.100000') == datetime_module.timedelta(0, 10e-3)
    assert timedelta_parse('.101111') == datetime_module.timedelta(0, 10111e-6)
    assert timedelta_parse('.111111') == datetime_module.timedelta(0, 11111e-3)

# Generated at 2022-06-24 17:14:16.770230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Here we create a random timedelta and convert it to string and then
    # back to timedelta (via the formatted string).
    #
    # Then we check that the roundtrip is lossless and that the string is
    # formatted correctly.
    import random
    random_timedelta = datetime_module.timedelta(
        microseconds=1 + int(999999 * random.random()),
        seconds=1 + int(999 * random.random()),
        minutes=1 + int(59 * random.random()),
        hours=1 + int(23 * random.random()),
        days=1 + int(999 * random.random()),
    )
    random_timedelta_str = timedelta_format(random_timedelta)

# Generated at 2022-06-24 17:14:21.166325
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '.'
    var_0 = timedelta_parse(str_0)
    assert str_0 == '.'
    var_1 = timedelta_parse('2:2:2.2')
    assert str(var_1) == '1 day, 2:02:02.000002'


# Generated at 2022-06-24 17:14:29.744510
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=10)) == '01:01:10.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=10, microseconds=10)) == '01:01:10.000010'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=10, microseconds=100)) == '01:01:10.000100'
    assert timedelta

# Generated at 2022-06-24 17:14:31.981569
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == '00:00:00.000000'



# Generated at 2022-06-24 17:14:45.201681
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == dat

# Generated at 2022-06-24 17:14:51.634344
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(
        microseconds=0)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        microseconds=1000000)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        seconds=60)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('0:00:00.000001') == datetime_module

# Generated at 2022-06-24 17:15:42.255869
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()

# Generated at 2022-06-24 17:15:45.401920
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        assert isinstance(test_case_0(), datetime_module.timedelta)
        return True
    except:
        return False


# Generated at 2022-06-24 17:15:54.481616
# Unit test for function timedelta_format
def test_timedelta_format():
    from garlicsim.general_misc.nifty_collections import OrderedDict

# Generated at 2022-06-24 17:15:59.091757
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 1, 200000)) == '00:00:01.200000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 2)) == '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'


# Generated at 2022-06-24 17:16:04.955730
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse(''), datetime_module.timedelta)
    assert timedelta_parse('') == datetime_module.timedelta()
    assert timedelta_parse('.') == datetime_module.timedelta()
    assert timedelta_parse('..') == datetime_module.timedelta()



# Generated at 2022-06-24 17:16:14.697273
# Unit test for function timedelta_format
def test_timedelta_format():
    class Test(object):
        def test(self):
            assert timedelta_format(timedelta_parse('2:43:12.123456')) == '2:43:12.123456'
            assert timedelta_format(timedelta_parse('1:28:59.000000')) == '1:28:59.000000'
            assert timedelta_format(timedelta_parse('0:00:12.000000')) == '0:00:12.000000'
            assert timedelta_format(timedelta_parse('0:00:00.000012')) == '0:00:00.000012'
            assert timedelta_format(timedelta_parse('0:00:00.123456')) == '0:00:00.123456'

# Generated at 2022-06-24 17:16:17.405970
# Unit test for function timedelta_format
def test_timedelta_format():
    test_time_delta = datetime_module.timedelta(hours=1, minutes=1,
                                                seconds=1, microseconds=1)
    assert timedelta_format(test_time_delta) == '01:01:01.000001'


# Generated at 2022-06-24 17:16:21.586876
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '.'
    str_1 = timedelta_format(datetime_module.timedelta(seconds=1))
    assert str_0 == str_1, "expected " + str_1 + " but got " + str_0


# Generated at 2022-06-24 17:16:27.350663
# Unit test for function timedelta_format
def test_timedelta_format():
    assert time_isoformat(datetime_module.time(hour=22, minute=10, second=9,
                                               microsecond=123)) == '22:10:09.000123'
    assert timedelta_format(datetime_module.timedelta(hours=22, minutes=10, seconds=9,
                                                      microseconds=123)) == '22:10:09.000123'



# Generated at 2022-06-24 17:16:33.474482
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime as datetime_module
    string = timedelta_format(
        datetime_module.timedelta(hours=3, minutes=10, seconds=25,
                                  microseconds=784512)
    )
    assert string == '03:10:25.784512'



# Generated at 2022-06-24 17:17:33.341844
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    timedelta_format(timedelta) -> string

    Convert a time to a string in ISO 8601 format.  The format is
    'HH:MM:SS.mmmmmm' where HH, MM, SS and mmmmmm are the hours,
    minutes, seconds and microseconds respectively.  If
    microseconds is 0, then it is omitted altogether.  If
    microseconds is 0 and seconds is 0, then seconds are omitted
    altogether.  If microseconds is 0 and seconds is 0 and minutes
    is 0, then minutes are omitted altogether.  Hours are always
    present.
    """
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'

# Generated at 2022-06-24 17:17:42.237455
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.00") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.00") == timedelta_parse("00:00:00.000000")
    assert timedelta_parse("00:00:00.01") == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse("00:00:00.01") == timedelta_parse("00:00:00.000001")
    assert timedelta_parse("00:00:00.1") == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse("00:00:00.1") == timedelta_parse("00:00:00.000100")

# Generated at 2022-06-24 17:17:44.056384
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )



# Generated at 2022-06-24 17:17:54.420051
# Unit test for function timedelta_parse
def test_timedelta_parse():
    value = timedelta_parse('0:00:00.000000')
    assert value == datetime_module.timedelta(0)
    value = timedelta_parse('1:02:03.000000')
    assert value == datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    value = timedelta_parse('0:00:00.000001')
    assert value == datetime_module.timedelta(microseconds=1)
    value = timedelta_parse('22:33:44.555555')
    assert value == datetime_module.timedelta(hours=22, minutes=33, seconds=44,
                                              microseconds=555555)

# Generated at 2022-06-24 17:17:58.715161
# Unit test for function timedelta_parse
def test_timedelta_parse():
    r = timedelta_parse('32:17:00.000000')
    assert isinstance(r, datetime_module.timedelta)
    assert r == datetime_module.timedelta(hours=32, minutes=17)



# Generated at 2022-06-24 17:18:01.071272
# Unit test for function timedelta_parse
def test_timedelta_parse():
    #assert False # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:18:05.622309
# Unit test for function timedelta_format
def test_timedelta_format():
    function_name = 'timedelta_format'

    # Call the function with all expected/valid parameter values.
    bytes_0 = b'\x80z\xa7\x94J1<\xa5Ak'
    var_0 = timedelta_format(bytes_0)



# Generated at 2022-06-24 17:18:10.649890
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_1 = b'L\x99\xe0\x05\xe6_\xd6\x9f'
    temp_1 = timedelta_format(bytes_1)
    assert temp_1 == '00:00:00.227517'


# Generated at 2022-06-24 17:18:21.004193
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test with correct input
    assert isinstance(timedelta_parse(timedelta_format(b'\x80z\xa7\x94J1<\xa5Ak')), datetime_module.timedelta)
    assert timedelta_parse(timedelta_format(b'\x80z\xa7\x94J1<\xa5Ak')) == b'\x80z\xa7\x94J1<\xa5Ak'
    # Test with wrong input
    # The following line causes SyntaxError in Python 2.7, which is correct
    # assert timedelta_parse(timedelta_format(b'\x80z\xa7\x94J1<\xa5Ak')) == b'\x80z\xa7\x94J1<\xa5Ak'


# Generated at 2022-06-24 17:18:35.131402
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('00:00:00.250000') == dat