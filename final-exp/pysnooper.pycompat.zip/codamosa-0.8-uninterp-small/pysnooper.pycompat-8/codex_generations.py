

# Generated at 2022-06-24 17:09:01.337035
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1
    )) == '25:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=100000
    )) == '25:01:01.100000'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1000000
    )) == '25:01:01.000000'

# Generated at 2022-06-24 17:09:04.598082
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:54:20.494335') == datetime_module.timedelta(0, 39260, 494335)


# Generated at 2022-06-24 17:09:13.696229
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Test function timedelta_parse."""
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        0, 0, 1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        0, 1, 0
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        0, 60, 0
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        3600
    )
    assert timedelta_parse('01:01:01.000001') == dat

# Generated at 2022-06-24 17:09:23.308263
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, seconds=2,
                                                        microseconds=345678)) == '01:00:02.345678'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=2, microseconds=3)) == '01:00:02.000003'
    assert timedelta_format(datetime_module.timedelta(seconds=60, microseconds=1)) == '00:01:00.000001'

# Generated at 2022-06-24 17:09:27.667264
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_parse('00:00:00.000050').microseconds == 50

# Generated at 2022-06-24 17:09:38.030804
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=0, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=1, microseconds=0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=1, seconds=0, microseconds=0)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=1, minutes=0, seconds=0, microseconds=0)) == '01:00:00.000000'
    assert timedelta_format

# Generated at 2022-06-24 17:09:50.395244
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('Starting test_case_0')
    test_case_0()
    print('Finished test_case_0')
    print('Starting test_case_1')
    test_case_1()
    print('Finished test_case_1')
    print('Starting test_case_2')
    test_case_2()
    print('Finished test_case_2')
    print('Starting test_case_3')
    test_case_3()
    print('Finished test_case_3')
    print('Starting test_case_4')
    test_case_4()
    print('Finished test_case_4')
    print('Starting test_case_5')
    test_case_5()
    print('Finished test_case_5')
    print('Starting test_case_6')
    test

# Generated at 2022-06-24 17:09:57.927320
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=13)) == '00:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=60)) == '01:00:00.000000'

# Generated at 2022-06-24 17:10:09.113537
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-24 17:10:16.812475
# Unit test for function timedelta_parse
def test_timedelta_parse():
    x = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    x_s = timedelta_format(x)
    x_again = timedelta_parse(x_s)
    assert x == x_again


if __name__ == '__main__':
    test_case_0()
    test_timedelta_parse()

# Generated at 2022-06-24 17:10:38.208553
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001200') == datetime_module.timedelta(microseconds=120)
    assert timedelta_parse('00:00:00.120000') == datetime_module.timedelta(microseconds=120000)
    assert timedelta_parse('00:00:12.000000') == datetime_module.timedelta(seconds=12)
    assert timedelta_parse('00:12:00.000000') == datetime_module.timedelta(minutes=12)
    assert timedelta_parse('12:00:00.000000')

# Generated at 2022-06-24 17:10:43.967432
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0, 0, 0) , "timedelta_parse('00:00:00.000000') != datetime.timedelta(0, 0, 0)"
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(0, 0, 0, 1) , "timedelta_parse('00:00:00.000001') != datetime.timedelta(0, 0, 0, 1)"
    assert timedelta_parse("00:00:00.123456") == datetime_module.timedelta(0, 0, 0, 123456) , "timedelta_parse('00:00:00.123456') != datetime.timedelta(0, 0, 0, 123456)"

# Generated at 2022-06-24 17:10:46.843047
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()

# Generated at 2022-06-24 17:10:55.969041
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse("0") == datetime_module.timedelta(0)), "Expected: <timedelta(0)> Actual: {}".format(timedelta_parse("0"))
    assert (timedelta_parse("1") == datetime_module.timedelta(seconds=1)), "Expected: <timedelta(seconds=1)> Actual: {}".format(timedelta_parse("1"))
    assert (timedelta_parse("1.1") == datetime_module.timedelta(microseconds=1000000+100000)), "Expected: <timedelta(microseconds=1000000+100000)> Actual: {}".format(timedelta_parse("1.1"))

# Generated at 2022-06-24 17:11:02.876355
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test with Example #0
    complex_0 = datetime_module.timedelta(days=369)
    var_0 = timedelta_format(complex_0)
    assert var_0 == '00:00:00.000000'
    # Test with Example #1
    complex_1 = datetime_module.timedelta(days=369, seconds=86398,
                                          microseconds=123456)
    var_1 = timedelta_format(complex_1)
    assert var_1 == '23:59:58.123456'

# Generated at 2022-06-24 17:11:12.585361
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0:0') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()

    assert timedelta_parse('0:0:1.1') == datetime_module.timedelta(
        seconds=1, microseconds=100000
    )

# Generated at 2022-06-24 17:11:24.586207
# Unit test for function timedelta_format
def test_timedelta_format():
    # Check that timedelta_format(timedelta_parse(s)) == s for all s
    # that are valid timedelta strings:
    for hours in range(3):
        for minutes in range(60):
            for seconds in range(60):
                for microseconds in range(1000000):
                    s = '{}:{}:{}.{}'.format(
                        hours,
                        minutes,
                        seconds,
                        microseconds
                    )
                    assert timedelta_format(timedelta_parse(s)) == s
    # Check against known values:
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=35)) == '00:35:00.000000'
    assert timedelta

# Generated at 2022-06-24 17:11:34.343580
# Unit test for function timedelta_format
def test_timedelta_format():
    
    # Call function with arguments:
    #   obj1 = datetime.timedelta(hours=0, minutes=0, seconds=0, microseconds=0, milliseconds=0,
    #                             days=0)
    obj1 = datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=0, milliseconds=0,
                                     days=0)
    assert timedelta_format(obj1) == "00:00:00.000000"
    #   obj1 = datetime.timedelta(days=-1, seconds=86400, microseconds=0, milliseconds=0,
    #                             minutes=0, hours=0, weeks=0)

# Generated at 2022-06-24 17:11:44.735987
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=4, microseconds=987))) == datetime_module.timedelta(seconds=4, microseconds=987)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=4, microseconds=987000))) == datetime_module.timedelta(seconds=4, microseconds=987000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=4, microseconds=987000000))) == datetime_module.timedelta(seconds=4, microseconds=987000000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=4, microseconds=987000000000))) == datetime_module.timedelta

# Generated at 2022-06-24 17:11:49.979346
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3.14159,
                                                      microseconds=123456)) == (
                                                          '01:02:03.134561')



# Generated at 2022-06-24 17:12:08.127390
# Unit test for function timedelta_parse
def test_timedelta_parse():
    source_0 = '00:00:00.000000'
    actual_0 = timedelta_parse(source_0)
    assert actual_0 == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:12:15.680356
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('TESTING timedelta_parse')
    try:
        test_case_0()
    except Exception as exception:
        print('Uncaught exception in test case:', exception)
    else:
        print('No exception.')


# Generated at 2022-06-24 17:12:16.782193
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:12:27.376342
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:00:00.000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('10:00:00.000000')) == '10:00:00.000000'
    assert timedelta_format(timedelta_parse('00:01:00.000000')) == '00:01:00.000000'
    assert timedelta_format(timedelta_parse('00:10:00.000000')) == '00:10:00.000000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == '00:00:01.000000'
   

# Generated at 2022-06-24 17:12:28.797299
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == None

# Generated at 2022-06-24 17:12:30.252579
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        test_case_0()
    except:
        print('ERROR: test_case_0()')

# Generated at 2022-06-24 17:12:31.414341
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('Function timedelta_parse passed all tests!')


# Generated at 2022-06-24 17:12:41.009452
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (
        timedelta_format(timedelta_parse('0:01:11.073000')) ==
        '00:01:11.073000'
    )
    assert (
        timedelta_format(timedelta_parse('18:00:15.123456')) ==
        '18:00:15.123456'
    )
    assert (
        timedelta_format(timedelta_parse('16:51:34.172765')) ==
        '16:51:34.172765'
    )
    assert (
        timedelta_format(timedelta_parse('8:38:31.915081')) ==
        '08:38:31.915081'
    )

# Generated at 2022-06-24 17:12:51.357362
# Unit test for function timedelta_format
def test_timedelta_format():

    test_case = [
        [
            None, # timedelta
            timedelta_format(None),
        ]
    ]
    for sub_case in test_case:
        var_0 = sub_case[0]
        var_1 = sub_case[1]
        var_2 = timedelta_format(var_0)
        if (var_1 != var_2):
            var_3 = "assert timedelta_format(%s) == %s" % (var_0, var_1)
            raise Exception(var_3)
    return "Test passed"

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-24 17:13:04.296045
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(hours=23, minutes=59, seconds=58, microseconds=123456)
    r = time_isoformat(datetime_module.datetime.min + t)
    assert r == '23:59:58.123456'

if PY2:
    from past.builtins import execfile as execfile
else:
    # execfile is already gone in Python 3.
    execfile = None


# Generated at 2022-06-24 17:13:27.000965
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test 1
    var_1 = timedelta_parse('0:00:01.000000')
    assert (var_1 == datetime_module.timedelta(0, 1))
    # Test 2
    var_2 = timedelta_parse('0:00:02.000001')
    assert (var_2 == datetime_module.timedelta(0, 2, 1))
    # Test 3
    var_3 = timedelta_parse('0:00:03.000002')
    assert (var_3 == datetime_module.timedelta(0, 3, 2))
    # Test 4
    var_4 = timedelta_parse('0:00:04.000003')
    assert (var_4 == datetime_module.timedelta(0, 4, 3))
    # Test 5

# Generated at 2022-06-24 17:13:33.343925
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=123456)) == '00:00:02.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=3,
                                                      microseconds=123456)) == '00:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4, microseconds=123456)) == '02:03:04.123456'

# Generated at 2022-06-24 17:13:36.948019
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
           '00:00:00.000000'


# Generated at 2022-06-24 17:13:46.459238
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def test_case_0():
        expected_0 = ''
        actual_0 = timedelta_parse(expected_0, 1)
        assert actual_0 == expected_0
        assert type(actual_0) == type(expected_0)

        expected_1 = ''
        actual_1 = timedelta_parse(expected_1, 1)
        assert actual_1 == expected_1
        assert type(actual_1) == type(expected_1)

        expected_2 = ''
        actual_2 = timedelta_parse(expected_2, 1)
        assert actual_2 == expected_2
        assert type(actual_2) == type(expected_2)

    def test_case_1():
        expected_0 = ''
        actual_0 = timedelta_parse(expected_0, 1)
        assert actual_0 == expected

# Generated at 2022-06-24 17:13:51.910160
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse("00:00:00.000000")) == "00:00:00.000000"
    assert timedelta_format(timedelta_parse("00:00:00.123456")) == "00:00:00.123456"
    assert timedelta_format(timedelta_parse("01:02:03.123456")) == "01:02:03.123456"
    assert timedelta_format(timedelta_parse("01:02:03.456789")) == "01:02:03.456789"

# Generated at 2022-06-24 17:14:05.281621
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:00:00.000000'
    timedelta_0 = timedelta_parse(s)
    assert timedelta_0 == datetime_module.timedelta(0, 0, 0)
    s = '00:00:00.000001'
    timedelta_0 = timedelta_parse(s)
    assert timedelta_0 == datetime_module.timedelta(0, 0, 0, 1)
    s = '00:00:01.002000'
    timedelta_0 = timedelta_parse(s)
    assert timedelta_0 == datetime_module.timedelta(0, 1, 2)
    s = '00:01:00.300000'
    timedelta_0 = timedelta_parse(s)

# Generated at 2022-06-24 17:14:15.843331
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('12:34:56.789012')) == '12:34:56.789012'
    assert timedelta_format(timedelta_parse('12:34:56.012345')) == '12:34:56.012345'
    assert timedelta_format(timedelta_parse('01:02:03.123456')) == '01:02:03.123456'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('--1:23:45.999999'))

# Generated at 2022-06-24 17:14:20.326988
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=3, hours=12, minutes=42,
                                          seconds=2, microseconds=253963)
    time = time_isoformat(timedelta)
    assert time == '12:42:02.253963'



# Generated at 2022-06-24 17:14:29.371483
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0:1.000000')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:0:0.999999')) == '00:00:00.999999'
    assert timedelta_format(timedelta_parse('0:1:0.000000')) == '00:01:00.000000'

# Generated at 2022-06-24 17:14:37.720710
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Test for function timedelta_format:
    '''
    # Test arguments:
    test_timedelta_format_arg_0 = datetime_module.timedelta(days=4, seconds=4,
                                                            microseconds=4,
                                                            milliseconds=4,
                                                            minutes=4,
                                                            hours=4,
                                                            weeks=4)

    # Actual outcome:
    test_timedelta_format_act_0 = timedelta_format(
        test_timedelta_format_arg_0
    )

    # Test arguments:

# Generated at 2022-06-24 17:15:01.429739
# Unit test for function timedelta_format
def test_timedelta_format():
    complex_0 = None
    var_0 = timedelta_format(complex_0)


# Generated at 2022-06-24 17:15:05.485631
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test 0:
    time = datetime_module.time(12, 12, 12, 1234)
    assert timedelta_format(time.replace(microsecond=0) - datetime_module.time(0, 0, 0, 0)) == '12:12:12.000000'


# Generated at 2022-06-24 17:15:19.630643
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import sys
    import datetime
    # Test for valid answer
    assert timedelta_parse('1:1:1.000001') == datetime.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)
    assert timedelta_parse('0:0:0.000000') == datetime.timedelta(seconds=0)
    assert timedelta_parse('0:0:59.990000') == datetime.timedelta(seconds=59, microseconds=990000)
    assert timedelta_parse('0:0:59.999999') == datetime.timedelta(seconds=59, microseconds=999999)
    assert timedelta_parse('1:2:59.999999') == datetime.timedelta(hours=1, minutes=2, seconds=59, microseconds=999999)


# Generated at 2022-06-24 17:15:21.887147
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


if __name__ == '__main__':
    test_timedelta_format()

# Generated at 2022-06-24 17:15:23.102323
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert True
    assert True


# Generated at 2022-06-24 17:15:27.178350
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        test_case_0()
    except AssertionError:
        assert False
    except NotImplementedError:
        assert False


# Generated at 2022-06-24 17:15:31.295580
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '24:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1, microseconds=1)) == '24:00:01.000001'


# Generated at 2022-06-24 17:15:42.696632
# Unit test for function timedelta_format
def test_timedelta_format():
    output_0 = timedelta_format(test_timedelta_format.complex_0)
    assert output_0 == test_timedelta_format.var_0

test_timedelta_format.complex_0 = datetime_module.timedelta(days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0, weeks=0)
test_timedelta_format.var_0 = '00:00:00.000000'


# Generated at 2022-06-24 17:15:53.016901
# Unit test for function timedelta_format
def test_timedelta_format():
    # pylint: disable=undefined-variable
    assert timedelta_format(timedelta_parse('11:22:33.123456')) == \
           '11:22:33.123456'
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == \
           '01:02:03.123456'
    assert timedelta_format(timedelta_parse('1:2:3.12')) == \
                                                   '01:02:03.120000'
    assert timedelta_format(timedelta_parse('1:2:3.1')) == \
                                                   '01:02:03.100000'

# Generated at 2022-06-24 17:15:54.798739
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()
    test_case_0()


if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-24 17:16:25.916376
# Unit test for function timedelta_parse
def test_timedelta_parse():

    if isinstance(StringIO, object):
        # Python 3.2.3 compatibility
        # Can't use `from io import StringIO` because that's not available
        # in Python 2.
        from cStringIO import StringIO
    from garlicsim.general_misc import cute_testing
    this_file = os.path.join(os.path.dirname(__file__), 'test_compatibility.py')
    with open(this_file) as file_object:
        source = file_object.read()
    assert 'def test_case_0():\n    bytes_0 = None\n    var_0 = timedelta_format(bytes_0)\n' in source
    test_case_0()
    assert cute_testing.get_stdout() == '00:00:00.000000\n' # todo: fix assert

# Generated at 2022-06-24 17:16:29.377875
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in range(100):
        sys.stdout.write('.')
        sys.stdout.flush()
        test_case_0()
    print()



# Generated at 2022-06-24 17:16:30.880838
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()

# Generated at 2022-06-24 17:16:40.172440
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from time import time
    from time import sleep
    from random import randrange


    def timedelta_format(timedelta):
        time = (datetime_module.datetime.min + timedelta).time()
        return time_isoformat(time, timespec='microseconds')

    def timedelta_parse(s):
        hours, minutes, seconds, microseconds = map(
            int,
            s.replace('.', ':').split(':')
        )
        return datetime_module.timedelta(hours=hours, minutes=minutes,
                                         seconds=seconds,
                                         microseconds=microseconds)



    # Test 1
    time1 = datetime_module.timedelta(microseconds=randrange(10000000))
    assert time1 == timedelta_parse(timedelta_format(time1))



# Generated at 2022-06-24 17:16:42.917914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = None
    var_0 = None
    # Call the function
    var_0 = timedelta_parse(bytes_0)

# Generated at 2022-06-24 17:16:55.460189
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                  microseconds=67890)
    )) == datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                    microseconds=67890)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=-7, hours=3, minutes=4, seconds=5,
                                  microseconds=67890)
    )) == datetime_module.timedelta(days=-7, hours=3, minutes=4, seconds=5,
                                    microseconds=67890)

# Generated at 2022-06-24 17:17:04.680277
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    ) == '01:02:03.123456'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    ) != '01:02:03.123456 '
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=12345)
    ) != '01:02:03.123456'


# Generated at 2022-06-24 17:17:19.419481
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        # Test raise exception when we pass an invalid value to a function
        #var_0 = timedelta_parse('test')
        #del var_0
        pass # You can leave this empty if you don't need it
    except TypeError:
        pass # You can leave this empty if you don't need it
    except ValueError:
        pass # You can leave this empty if you don't need it

    try:
        # Test raise exception when we pass an invalid value to a function
        #var_0 = timedelta_parse(None)
        #del var_0
        pass # You can leave this empty if you don't need it
    except TypeError:
        pass # You can leave this empty if you don't need it
    except ValueError:
        pass # You can leave this empty if you don't need it


# Generated at 2022-06-24 17:17:25.194915
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(3600, 1)
    assert timedelta_parse('10:20:30.400000') == datetime_module.timedelta(37230, 30, 400000)
    assert timedelta_parse('20:40:50.600000')

# Generated at 2022-06-24 17:17:26.672208
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = None
    var_0 = timedelta_parse(bytes_0)

test_case_0()
test_timedelta_parse()

# Generated at 2022-06-24 17:18:43.118875
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(None) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=70)) == '01:10:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=70)) == '00:01:10.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=700000)) == '00:00:00.700000'
