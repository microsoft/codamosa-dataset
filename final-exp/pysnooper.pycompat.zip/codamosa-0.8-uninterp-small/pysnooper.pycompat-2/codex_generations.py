

# Generated at 2022-06-24 17:08:46.592521
# Unit test for function timedelta_format
def test_timedelta_format():
    int_0 = 1
    var_0 = timedelta_format(int_0)

# Generated at 2022-06-24 17:08:53.476739
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    timedelta_parse should return a timedelta object.
    """
    assert timedelta_parse('00:00:00.000000') == datetime.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000100') == datetime.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime.timedelta(microseconds=10000)

# Generated at 2022-06-24 17:08:55.663699
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'


# Generated at 2022-06-24 17:09:05.504819
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import assert_equal
    timedelta_0 = datetime_module.timedelta(days=1, minutes=1, seconds=1, microseconds=1)
    str_0 = timedelta_format(timedelta_0)
    timedelta_1 = timedelta_parse(str_0)
    assert_equal(timedelta_0, timedelta_1)
    timedelta_0 = datetime_module.timedelta(days=-1, minutes=1, seconds=1, microseconds=1)
    str_0 = timedelta_format(timedelta_0)
    timedelta_1 = timedelta_parse(str_0)
    assert_equal(timedelta_0, timedelta_1)


# Generated at 2022-06-24 17:09:10.930655
# Unit test for function timedelta_format
def test_timedelta_format():
    if timedelta_format(1) != '00:00:00.000001':
        print('function timedelta_format failed!')
        return 1
    return 0


# Generated at 2022-06-24 17:09:22.377386
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == '01:00:01.000000'

# Generated at 2022-06-24 17:09:24.431666
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0)



# Generated at 2022-06-24 17:09:29.865719
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse('01:02:03.000000'), datetime_module.timedelta)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)


# Generated at 2022-06-24 17:09:46.239683
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(milliseconds=10)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-24 17:09:51.918589
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    ) == '00:00:01.000001'
    assert timedelta_format(
        datetime_module.timedelta(days=1, seconds=1)
    ) == '00:00:01.000000'
    assert timedelta_format(
        datetime_module.timedelta(seconds=1)
    ) == '00:00:01.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=1)
    ) == '00:00:00.000001'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=100)
    ) == '00:00:00.000100'
   

# Generated at 2022-06-24 17:10:06.477208
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:10:08.085390
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'


# Generated at 2022-06-24 17:10:20.702949
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-24 17:10:22.169089
# Unit test for function timedelta_format
def test_timedelta_format():
    print(timedelta_format(3600.0))


# Generated at 2022-06-24 17:10:26.858916
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(1) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == (
        '01:02:03.000004'
    )
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400005
    )) == '01:02:03.040005'

# Generated at 2022-06-24 17:10:28.667200
# Unit test for function timedelta_format
def test_timedelta_format():
    int_0 = 1
    var_0 = timedelta_format(int_0)
    assert var_0 == '01:00:00.000001'


# Generated at 2022-06-24 17:10:42.387468
# Unit test for function timedelta_parse
def test_timedelta_parse():
    int_0 = datetime_module.timedelta(hours=0, minutes=0, seconds=5, microseconds=0)
    var_0 = timedelta_parse("00:00:05.000000")
    assert var_0 == int_0
    int_0 = datetime_module.timedelta(hours=0, minutes=1, seconds=0, microseconds=0)
    var_0 = timedelta_parse("00:01:00.000000")
    assert var_0 == int_0
    int_0 = datetime_module.timedelta(hours=0, minutes=1, seconds=1, microseconds=0)
    var_0 = timedelta_parse("00:01:01.000000")
    assert var_0 == int_0

# Generated at 2022-06-24 17:10:56.009391
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(0) == '00:00:00.000000'
    assert timedelta_format(1) == '00:00:00.000001'
    assert timedelta_format(-1) == '-1 day, 23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                               '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=-1)) == \
                               '-1 day, 23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '1 day, 00:00:00'

# Generated at 2022-06-24 17:11:04.828975
# Unit test for function timedelta_format
def test_timedelta_format():
    output = timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                        seconds=0,
                                                        microseconds=1))
    assert output == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1,
                                                      seconds=0,
                                                      microseconds=1)) == '00:01:00.000001'

    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=0,
                                                      seconds=0,
                                                      microseconds=1)) == '01:00:00.000001'


# Generated at 2022-06-24 17:11:13.074723
# Unit test for function timedelta_format
def test_timedelta_format():
    assert(timedelta_format((0)) == "00:00:00.000000")
    assert(timedelta_format((10 ** 3)) == "00:00:01.000000")
    assert(timedelta_format(((10 ** 3) * 60)) == "00:01:00.000000")
    assert(timedelta_format(((10 ** 3) * 60 * 60)) == "01:00:00.000000")
    assert(timedelta_format(((10 ** 3) * 60 * 60 * 24)) == "24:00:00.000000")
    assert(timedelta_format(((10 ** 3) * 60 * 60 * 24 * 7)) == "168:00:00.000000")

# Generated at 2022-06-24 17:11:27.289118
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'


# Generated at 2022-06-24 17:11:29.745278
# Unit test for function timedelta_parse
def test_timedelta_parse():
    int_0 = 1
    var_0 = timedelta_parse(int_0)
    assert isinstance(var_0, datetime_module.timedelta)



# Generated at 2022-06-24 17:11:31.999203
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse('01:00:00.000000'), datetime_module.timedelta)


# Generated at 2022-06-24 17:11:43.384960
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60))=="00:01:00.000000"
    assert timedelta_format(datetime_module.timedelta(seconds=70))=="00:01:10.000000"
    assert timedelta_format(datetime_module.timedelta(seconds=3661))=="01:01:01.000000"
    assert timedelta_format(datetime_module.timedelta(seconds=3661,microseconds=1))=="01:01:01.000001"
    assert timedelta_format(datetime_module.timedelta(seconds=3661,microseconds=10))=="01:01:01.000010"

# Generated at 2022-06-24 17:11:49.979040
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'


# Generated at 2022-06-24 17:12:04.422901
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(
        hours=1, microseconds=1)

    assert timedelta_parse('01:00:01.000001') == datetime_module.timedelta(
        hours=1, seconds=1, microseconds=1)

# Generated at 2022-06-24 17:12:06.458762
# Unit test for function timedelta_parse
def test_timedelta_parse():
    int_0 = 1
    var_0 = timedelta_parse(int_0)

# Generated at 2022-06-24 17:12:17.045843
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('1:00:00.000001') == datetime_module.timedelta(0, 3600, 1)
    assert timedelta_parse('1:00:00.000010') == datetime_module.timedelta(0, 3600, 10)
    assert timedelta_parse('1:00:00.000100') == datetime_module.timedelta(0, 3600, 100)
    assert timedelta_parse('1:00:00.001000') == datetime_module.timedelta(0, 3600, 1000)

# Generated at 2022-06-24 17:12:19.944954
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:01.000000") == datetime_module.timedelta(seconds=1)


# Generated at 2022-06-24 17:12:28.999923
# Unit test for function timedelta_format
def test_timedelta_format():
    int_0 = 1
    var_0 = timedelta_format(int_0)
    assert var_0 == '00:00:00.000001'
    int_0 = 60
    var_0 = timedelta_format(int_0)
    assert var_0 == '00:00:01.000000'
    int_0 = 3600
    var_0 = timedelta_format(int_0)
    assert var_0 == '00:01:00.000000'
    int_0 = 86400
    var_0 = timedelta_format(int_0)
    assert var_0 == '01:00:00.000000'
    int_0 = 1
    var_0 = timedelta_format(int_0)
    assert var_0 == '00:00:00.000001'

# Unit test

# Generated at 2022-06-24 17:12:51.669145
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1, 2, 3)) == '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(hours=12, minutes=34,
                                                      seconds=56,
                                                      microseconds=789)) == \
        '12:34:56.000789'
    assert timedelta_format(datetime_module.timedelta(microseconds=1_000_000)) == \
        '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(days=-1, seconds=1)) == \
        '-23:59:59.000000'

# Generated at 2022-06-24 17:13:04.327000
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00') == datetime_module.timedelta(minutes=60)
    assert timedelta_parse('1:00:00:00') == datetime_module.timedelta(minutes=60)
    assert timedelta_parse('1:00:00:00:00') == datetime_module.timedelta(minutes=60)
    assert timedelta_parse('1:00:00:00.00') == datetime_module.timedelta(minutes=60)
    assert timedelta_parse('1:00:00:00.000000') == datetime_module.timedelta(minutes=60)
    assert timedelta_parse('01:00:00') == datetime_module.timedelta(minutes=60)

# Generated at 2022-06-24 17:13:16.147183
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(0, 3600, 1)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(0, 3601)
    assert timedelta_parse('01:01:00.000000')

# Generated at 2022-06-24 17:13:25.740666
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000012') == datetime_module.timedelta(microseconds=12)
    assert timedelta_parse('00:00:00.000123') == dat

# Generated at 2022-06-24 17:13:26.832588
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    Testing for timedelta_format
    """
    test_case_0()
    

# Generated at 2022-06-24 17:13:32.015673
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("0:00:01.000000") == datetime_module.timedelta(0, 1)



# Generated at 2022-06-24 17:13:36.913012
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:22:40.000000') == datetime_module.timedelta(hours=2, minutes=22, seconds=40)
    assert timedelta_parse('16:52:12.990000') == datetime_module.timedelta(hours=16, minutes=52, seconds=12, microseconds=990000)
    assert timedelta_parse('19:49:59.999999') == datetime_module.timedelta(days=1, microseconds=1)

# Generated at 2022-06-24 17:13:46.434394
# Unit test for function timedelta_format
def test_timedelta_format():
    # Make sure it accepts timedelta with the same output as `datetime`
    delta_0 = datetime_module.timedelta(seconds=1.5)
    delta_1 = datetime_module.timedelta(seconds=0.5)
    delta_2 = datetime_module.timedelta(hours=1, seconds=0.5)
    delta_3 = datetime_module.timedelta(microseconds=12)
    assert datetime_module.datetime.min + delta_0 == datetime_module.datetime(1900, 1, 1, 0, 0, 1, 500000)
    assert timedelta_format(delta_0) == '00:00:01.500000'
    assert timedelta_format(delta_1) == '00:00:00.500000'
    assert timedelta_format

# Generated at 2022-06-24 17:13:47.781335
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime
    test_case_0()


# Generated at 2022-06-24 17:13:52.529132
# Unit test for function timedelta_format
def test_timedelta_format():
    assert callable(timedelta_format), f'timedelta_format is not callable'
    assert timedelta_format(1) == '00:00:00.000001', f'timedelta_format(1)'


# Generated at 2022-06-24 17:14:15.789115
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-24 17:14:19.928969
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.min) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta.max) == \
           '23:59:59.999999'



# Generated at 2022-06-24 17:14:29.135088
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.0000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00000000') == datetime_module.timedelta(0)

    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(0, 0,
                                                                       10000)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(0,
                                                                           0,
                                                                           999999)
    assert timedelta

# Generated at 2022-06-24 17:14:37.632341
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(milliseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-24 17:14:42.838886
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Returns True if timedelta_parse(timedelta_format(delta)) == delta"""
    for x in range(1000):
        for y in range(1000):
            for z in range(1000):
                for w in range(1000):
                    delta = datetime_module.timedelta(hours=x, minutes=y,
                                             seconds=z, microseconds=w)
                    s = timedelta_format(delta)
                    s_parsed = timedelta_parse(s)
                    assert s_parsed == delta, (x, y, z, w)

# Generated at 2022-06-24 17:14:50.184544
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timestamp_0 = timedelta_parse("00:00:00.000000")
    assert timestamp_0 == datetime_module.timedelta(0)
    timestamp_1 = timedelta_parse("00:03:02.100000")
    assert timestamp_1 == datetime_module.timedelta(0, 182, 100000)
    timestamp_2 = timedelta_parse("00:03:02.000000")
    assert timestamp_2 == datetime_module.timedelta(0, 182)
    timestamp_3 = timedelta_parse("00:03:02")
    assert timestamp_3 == datetime_module.timedelta(0, 182)
    timestamp_4 = timedelta_parse("00:00:00.999999")
    assert timestamp_4 == datetime_module.timedelta(0, 0, 999999)


# Generated at 2022-06-24 17:14:55.068801
# Unit test for function timedelta_format
def test_timedelta_format():
    result = str(timedelta_format(datetime_module.timedelta(hours=1)))
    expected = "01:00:00.000000"
    print('expected = {}\nresult = {}\nassertion = {}\n'.format(
        expected, result, expected == result))


# Generated at 2022-06-24 17:14:58.913995
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '\n    Testing for timedelta_format\n    '
    td = datetime_module.timedelta(days=3, hours=12, minutes=6, seconds=13,
                                   microseconds=22)
    assert timedelta_format(td) == '12:06:13.000022', str_0


# Generated at 2022-06-24 17:15:03.329958
# Unit test for function timedelta_parse
def test_timedelta_parse():

    parsed_timedelta = timedelta_parse('01:02:03:400000')

    assert parsed_timedelta == datetime_module.timedelta(hours=1,
                                                         minutes=2,
                                                         seconds=3,
                                                         microseconds=400000)



# Generated at 2022-06-24 17:15:12.032693
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=4, minutes=3, seconds=2,
                                  microseconds=1000)
    ) == '04:03:02.001000'
    assert timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                  microseconds=10000)
    ) == '03:02:01.010000'
    assert timedelta_format(
        datetime_module.timedelta(hours=2, minutes=1, seconds=0,
                                  microseconds=100000)
    ) == '02:01:00.100000'

# Generated at 2022-06-24 17:15:33.009309
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:03.123456') == datetime_module.timedelta(seconds=3, microseconds=123456)
    assert timedelta_parse('03:00:00.000000') == datetime_module.timedelta(hours=3)
    assert timedelta_parse('03:00:00.123456') == datetime_module.timedelta(hours=3, microseconds=123456)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)


# Generated at 2022-06-24 17:15:45.621556
# Unit test for function timedelta_format
def test_timedelta_format():
    microseconds = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(microseconds) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=23,
                                                      seconds=45,
                                                      microseconds=67)) == \
           '01:23:45.000067'
    assert timedelta_format(datetime_module.timedelta(days=8)) == '192:00:00.000000'


(test_case_0, )


# Generated at 2022-06-24 17:15:53.527271
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=2,
                                                      seconds=3,
                                                      microseconds=10)) == '10:02:03.000010'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=10)) == '01:01:01.000010'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=10)) == '00:00:00.000010'



# Generated at 2022-06-24 17:16:01.078926
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=6,
                                                      minutes=6,
                                                      seconds=6,
                                                      microseconds=6)) ==\
                                                      '06:06:06.000006'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=6,
                                                      seconds=6)) ==\
                                                      '06:06:06.000000'
    assert timedelta_format(datetime_module.timedelta(hours=6,
                                                      minutes=6)) ==\
                                                      '06:06:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=6)) ==\
                                                      '06:00:00.000000'

# Generated at 2022-06-24 17:16:11.364829
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=30,
                                                      seconds=30,
                                                      microseconds=3000)) \
        == '08:30:30.003000'
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=30,
                                                      milliseconds=30)) \
        == '08:30:00.030000'
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=30,
                                                      microseconds=30)) \
        == '08:30:00.000030'
    assert timedelta_format(datetime_module.timedelta(minutes=30,
                                                      milliseconds=30)) \
        == '00:30:00.030000'
    assert timedelta

# Generated at 2022-06-24 17:16:14.323131
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=3, minutes=43, seconds=2,
                                  microseconds=123456)
    ) == '03:43:02.123456'



# Generated at 2022-06-24 17:16:21.105914
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(0, 0, 0, 1))
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == time
    time = time_isoformat(datetime_module.time(0, 0, 0))
    assert timedelta_format(datetime_module.timedelta(0)) == time
    time = time_isoformat(datetime_module.time(0, 0, 1))
    assert timedelta_format(datetime_module.timedelta(0, 1)) == time
    time = time_isoformat(datetime_module.time(0, 0, 60))
    assert timedelta_format(datetime_module.timedelta(0, 60)) == time

# Generated at 2022-06-24 17:16:23.358663
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '\n    Testing for timedelta_parse\n    '


# Generated at 2022-06-24 17:16:25.367281
# Unit test for function timedelta_format
def test_timedelta_format():

    # Testing for timedelta_format
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-24 17:16:37.609151
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '30 days, 0:00:00'
    assert timedelta_format(datetime_module.timedelta(days=30)) == str_0
    str_0 = '12:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=12)) == str_0
    str_0 = '5:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=5)) == str_0
    str_0 = '0:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == str_0
    str_0 = '0:00:00.000010'

# Generated at 2022-06-24 17:16:56.470649
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        minutes=60)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(
        minutes=60, microseconds=1)
    assert timedelta_parse('24:00:00.000000') == datetime_module.timedelta(
        days=1)
    assert timed

# Generated at 2022-06-24 17:17:07.586033
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = datetime_module.timedelta()
    assert timedelta_0 == timedelta_parse(timedelta_format(timedelta_0))
    timedelta_1 = datetime_module.timedelta(hours=5)
    assert timedelta_1 == timedelta_parse(timedelta_format(timedelta_1))
    timedelta_2 = datetime_module.timedelta(hours=5, minutes=51, seconds=12)
    assert timedelta_2 == timedelta_parse(timedelta_format(timedelta_2))
    timedelta_3 = datetime_module.timedelta(hours=5, minutes=51, seconds=12,
                                            microseconds=121351)

# Generated at 2022-06-24 17:17:18.948896
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = datetime_module.timedelta(hours=2, minutes=2, seconds=2,
                                            microseconds=2)
    assert timedelta_format(timedelta_0) == '02:02:02.000002'
    assert timedelta_parse(timedelta_format(timedelta_0)) == timedelta_0
    timedelta_1 = datetime_module.timedelta(hours=28, minutes=2, seconds=0,
                                            microseconds=0)
    assert timedelta_format(timedelta_1) == '28:02:00.000000'
    assert timedelta_parse(timedelta_format(timedelta_1)) == timedelta_1

# Generated at 2022-06-24 17:17:25.554785
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('0:0:1.1') == datetime_module.timedelta(
        seconds=1, microseconds=100000
    )
    assert timedelta_parse('0:1:1.1') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=100000
    )
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )
    assert timed

# Generated at 2022-06-24 17:17:37.147636
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test case 0
    str_0 = '\n    Testing for timedelta_format\n    '
    # Test case 1
    str_1 = timedelta_format(datetime_module.timedelta(seconds=69))
    assert str_1 == '00:01:09', str_1
    
    # Test case 2
    str_1 = timedelta_format(datetime_module.timedelta(seconds=72))
    assert str_1 == '00:01:12', str_1
    
    # Test case 3
    str_1 = timedelta_format(datetime_module.timedelta(seconds=0))
    assert str_1 == '00:00:00', str_1
    
    # Test case 4

# Generated at 2022-06-24 17:17:47.441091
# Unit test for function timedelta_format
def test_timedelta_format():
    time_0 = time_isoformat(datetime_module.time(0, 0, 0, 123456))
    assert time_0 == '00:00:00.123456'
    time_1 = time_isoformat(datetime_module.time(1, 2, 3, 4))
    assert time_1 == '01:02:03.000004'
    time_2 = time_isoformat(datetime_module.time(1, 23, 59, 999999))
    assert time_2 == '01:23:59.999999'
    assert time_isoformat(datetime_module.time(0, 0, 0, 0, 'UTC')) == \
                                         '00:00:00.000000+00:00'

# Generated at 2022-06-24 17:17:55.693209
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def do_test(timedelta, str_expected):
        timedelta2 = timedelta_parse(str_expected)
        assert timedelta == timedelta2
    do_test(datetime_module.timedelta(seconds=1), '00:00:01.000000')
    do_test(datetime_module.timedelta(hours=1), '01:00:00.000000')
    do_test(datetime_module.timedelta(hours=25), '01:00:00.000000')



# Generated at 2022-06-24 17:18:03.646557
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1,
                                                      microseconds=1,
                                                      milliseconds=1)) == \
           '25:00:00.001001'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == \
           '25:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=1,
                                                      milliseconds=1)) == \
           '24:00:00.001001'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'

# Generated at 2022-06-24 17:18:05.184081
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()


# Generated at 2022-06-24 17:18:10.055836
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import nose

    nosetests = nose.loader.defaultTestLoader.loadTestsFromName
    results = nosetests('my_module.my_function')
    results.run(nose.core.TextTestRunner(verbosity=2).run(results))