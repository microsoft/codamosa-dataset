

# Generated at 2022-06-24 17:08:56.902965
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_0 = timedelta_parse(bytes_0)
    str_0 = timedelta_format(var_0)
    assert str_0 == b'00:15:34.058861'

# Generated at 2022-06-24 17:08:59.678293
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(b'14:15:02:234567') == datetime_module.timedelta(hours=14, minutes=15, seconds=2, microseconds=234567)



# Generated at 2022-06-24 17:09:02.197273
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(var_0, datetime_module.timedelta)

test_case_0()

# Generated at 2022-06-24 17:09:10.910485
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Check that it can sum a list of integers."""
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(0, 0, 123456)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)

# Generated at 2022-06-24 17:09:22.376532
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'), datetime_module.timedelta)
    assert timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee') == datetime_module.timedelta(17, 23138, 539511, 87533)

    assert isinstance(timedelta_parse(b'\x15\x8d\xa2\xfb\xfb\xbb\xb8\x9c\x9e\xda'), datetime_module.timedelta)

# Generated at 2022-06-24 17:09:26.178937
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3,
                                                      microseconds=14159)) == '00:00:03.0014159'
    assert timedelta_format(datetime_module.timedelta(minutes=30,
                                                      seconds=30)) == '00:30:30.000000'



# Generated at 2022-06-24 17:09:28.553594
# Unit test for function timedelta_format
def test_timedelta_format():
    time_0 = datetime_module.timedelta(days=3, seconds=123, microseconds=45678)
    str_0 = timedelta_format(time_0)
    assert str_0 == b'72:00:00.123456'



# Generated at 2022-06-24 17:09:38.381225
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert isinstance(timedelta_parse(''), datetime_module.timedelta)
    assert timedelta_parse('') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-24 17:09:44.276348
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(
        hours=1, minutes=39, seconds=41, microseconds=344892
    )
    assert timedelta_format(timedelta_0) == b'01:39:41.034822'


# Generated at 2022-06-24 17:09:53.424998
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(0, 1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(0, 10000)) == '00:00:00.010000'

# Generated at 2022-06-24 17:10:18.153922
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:20:30.123456') == datetime_module.timedelta(
        days=0, seconds=36630, microseconds=123456)
    assert timedelta_parse('-10:20:30.123456') == datetime_module.timedelta(
        days=-1, seconds=36630, microseconds=123456)
    assert timedelta_parse('10:20:30.123456') == timedelta_parse('10:20:30.1234560')
    assert timedelta_parse('10:20:30.123456') == timedelta_parse('10:20:30.12345600')
    assert timedelta_parse('10:20:30.123456') == timedelta_parse('10:20:30.123456000')

# Generated at 2022-06-24 17:10:24.985748
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_1 = timedelta_parse(bytes_0)
    var_2 = timedelta_format(var_1)
    assert var_2 == bytes_0


# Generated at 2022-06-24 17:10:29.501988
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-24 17:10:36.075158
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_ = datetime_module.timedelta(0, 5, 0)
    expected_0 = '00:00:05.000000'
    try:
        assert expected_0 == timedelta_format(timedelta_)
    except AssertionError as e:
        raise AssertionError(e.args + (timedelta_, expected_0))


# Generated at 2022-06-24 17:10:42.983239
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_0 = timedelta_parse(bytes_0)
    assert(var_0 == datetime_module.timedelta(hours=-20, minutes=-20,
                                              seconds=-20,
                                              microseconds=-20))
    bytes_0 = b'\xbf\xbf\xbf\xbf\xbf\xbf\xbf\xbf\xbf\xbf'
    var_0 = timedelta_parse(bytes_0)
    assert(var_0 == datetime_module.timedelta(hours=-1, minutes=-1,
                                              seconds=-1,
                                              microseconds=-1))

# Generated at 2022-06-24 17:10:56.275792
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_2 = b'\xfe\xa5\xb0\xfe\x95\xcc\xa8'
    var_1 = timedelta_parse(bytes_2)
    assert var_1 == datetime_module.timedelta(
        hours=67, minutes=170, seconds=204, microseconds=168
    )
    bytes_3 = b'\xb2\x99\xa6\xbd\xea\xed\xddX\x11\xae\xa0\x16\x8f\x1a\xb6'
    var_3 = timedelta_parse(bytes_3)
    assert var_3 == datetime_module.timedelta(
        hours=178, minutes=155, seconds=206, microseconds=222, microseconds=88
    )
    bytes_4 = b

# Generated at 2022-06-24 17:10:59.251371
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test cases
    foo = timedelta_format(datetime_module.timedelta(days=30))
    assert foo == '00:00:00.000000'

# Generated at 2022-06-24 17:11:07.308362
# Unit test for function timedelta_format

# Generated at 2022-06-24 17:11:09.983307
# Unit test for function timedelta_format
def test_timedelta_format():
    test_object = datetime_module.timedelta(0, 9000.124531)

    assert timedelta_format(test_object) == "00:01:30.124531"


# Generated at 2022-06-24 17:11:11.342791
# Unit test for function timedelta_format
def test_timedelta_format():
    # Unit: timedelta_format
    # Case 0
    test_case_0()


# Generated at 2022-06-24 17:11:33.334756
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee') == datetime_module.timedelta(days=7, hours=3, minutes=7, seconds=38, microseconds=60000)
    assert timedelta_parse(b'\x82\x85\x89\x93C\xae\x08\xbeN\x9b\x9c') == datetime_module.timedelta(days=6, hours=0, minutes=50, seconds=30, microseconds=465000)
    assert timedelta_parse(b'\xbd\x89\x82\xac\xa0\xaa\xf1\x9e\x9f\x90[') == datetime_module.timedelta

# Generated at 2022-06-24 17:11:35.774587
# Unit test for function timedelta_format
def test_timedelta_format():
    result_0 = timedelta_format(timedelta_parse('03:02:01:000300'))
    assert result_0 == '03:02:01.000300'

# Generated at 2022-06-24 17:11:45.788691
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    timedelta_format()
    '''
    from datetime import timedelta
    assert timedelta_format(timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(timedelta(0, 0, 123456)) == '00:00:00.123456'
    assert timedelta_format(timedelta(0, 1, 0)) == '00:00:01.000000'
    assert timedelta_format(timedelta(0, 10, 0)) == '00:00:10.000000'
    assert timedelta_format(timedelta(1, 0, 0)) == '24:00:00.000000'
    assert timedelta_

# Generated at 2022-06-24 17:11:54.246041
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_0 = b'\x9b\xbc\x8bc\xa7\xcdd\xdb\x93\x8b\xba\x9d\x97'
    var_0 = timedelta_format(bytes_0)
    bytes_1 = b'\x9b\xbc\x8bc\xa7\xcdd\xdb\x93\x8b\xba\x9d\x97'
    var_1 = timedelta_format(bytes_1)
    bytes_2 = b'\x9b\xbc\x8bc\xa7\xcdd\xdb\x93\x8b\xba\x9d\x97'
    var_2 = timedelta_format(bytes_2)

# Generated at 2022-06-24 17:11:57.080927
# Unit test for function timedelta_format
def test_timedelta_format():
    expected = '-1 days, 23:48:50.987654'
    value = datetime_module.timedelta(days=-1, hours=23, minutes=48,
                                      seconds=50, microseconds=987654)
    assert timedelta_format(value) == expected
    assert timedelta_parse(timedelta_format(value)) == value

# Generated at 2022-06-24 17:12:07.347800
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 0))) == datetime_module.timedelta(1, 0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1))) == datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 1))) == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1, 1))) == datetime_module.timedelta(1, 1, 1)

# Generated at 2022-06-24 17:12:09.432681
# Unit test for function timedelta_format
def test_timedelta_format():
    # Check if string of expected length
    assert len(timedelta_format(datetime_module.timedelta(seconds=1))) == 15


# Generated at 2022-06-24 17:12:13.542164
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_0 = timedelta_parse(bytes_0)


# Generated at 2022-06-24 17:12:23.190658
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789, milliseconds=987,
    )) == '01:02:03.456999'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789, milliseconds=986,
    )) == '01:02:03.456998'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789, milliseconds=985,
    )) == '01:02:03.456997'

# Generated at 2022-06-24 17:12:27.336644
# Unit test for function timedelta_format
def test_timedelta_format():
    timedeltas = [
        datetime_module.timedelta(hours=1),
        datetime_module.timedelta(hours=23, minutes=42, seconds=13,
                                  microseconds=719238),
    ]
    for timedelta in timedeltas:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-24 17:12:49.191097
# Unit test for function timedelta_parse
def test_timedelta_parse():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_0 = timedelta_parse(bytes_0)
    assert isinstance(var_0, datetime_module.timedelta), \
        "unexpected type from timedelta_parse"
    bytes_0 = b'\xb9J\x9d\x11\x8a\xd6\xa5\xee\x14\xc8\x7f'
    var_0 = timedelta_parse(bytes_0)
    assert isinstance(var_0, datetime_module.timedelta), \
        "unexpected type from timedelta_parse"

# Generated at 2022-06-24 17:12:59.428803
# Unit test for function timedelta_format
def test_timedelta_format():
    var_0 = timedelta_format(datetime_module.timedelta(0, 41, 696013))
    var_1 = timedelta_format(datetime_module.timedelta(0, 23, 546826))
    var_2 = timedelta_format(datetime_module.timedelta(0, 17, 245298))
    var_3 = timedelta_format(datetime_module.timedelta(0, 3, 787266))
    var_4 = timedelta_format(datetime_module.timedelta(0, 1, 605006))
    var_5 = timedelta_format(datetime_module.timedelta(0, 24, 79862))
    var_6 = timedelta_format(datetime_module.timedelta(0, 0, 675217))
    var_7

# Generated at 2022-06-24 17:13:04.501129
# Unit test for function timedelta_format
def test_timedelta_format():
    # Check that `timedelta_format` creates a string representing a
    # `timedelta` object
    timedelta_1 = datetime_module.timedelta(days=7, hours=6, minutes=5,
                                            seconds=4, microseconds=3)
    string_1 = timedelta_format(timedelta_1)
    assert isinstance(string_1, str)
    assert string_1 == '170:05:04.000003'


# Generated at 2022-06-24 17:13:10.567632
# Unit test for function timedelta_format
def test_timedelta_format():
    bytes_0 = b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee'
    var_0 = timedelta_parse(bytes_0)
    bytes_1 = timedelta_format(var_0)


# Generated at 2022-06-24 17:13:16.586342
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Check that timedelta_format and timedelta_parse are reciprocals.
    '''
    for seconds in range(-1000000000, 1000000000):
        timedelta = datetime_module.timedelta(seconds=seconds)
        s = timedelta_format(timedelta)
        assert isinstance(s, str)
        result_timedelta = timedelta_parse(s)
        assert timedelta == result_timedelta



# Generated at 2022-06-24 17:13:24.044611
# Unit test for function timedelta_parse
def test_timedelta_parse():
    var_0 = timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee')
    var_1 = timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Ga\xee')
    var_2 = timedelta_parse(b'\xbf\xbe\xa7\xad\x98g\xbb\x9c\xb3Gb\xee')
    assert var_0 == var_1 and var_0 != var_2

# Generated at 2022-06-24 17:13:24.923797
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse


# Generated at 2022-06-24 17:13:33.581650
# Unit test for function timedelta_format
def test_timedelta_format():
    import nose
    from garlicsim.general_misc import cute_testing
    from . import test_cute_timedelta

    # "longest"
    for timedelta in test_cute_timedelta.time_spans:

        assert cute_testing.tolerant_eq(
            timedelta_format(timedelta),
            str(timedelta)
        )


    # "shortest"
    for timedelta in test_cute_timedelta.time_spans:

        assert cute_testing.tolerant_eq(
            timedelta_format(timedelta),
            str(timedelta)
        )



# Generated at 2022-06-24 17:13:34.860657
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert(test_case_0())

# Generated at 2022-06-24 17:13:45.645075
# Unit test for function timedelta_format
def test_timedelta_format():
    time_0 = datetime_module.datetime.now()
    time_1 = time_0 - datetime_module.timedelta(microseconds=4)
    time_2 = time_0 + datetime_module.timedelta(microseconds=4)
    assert timedelta_format(time_1 - time_0) == timedelta_format(time_0 - time_1)
    assert timedelta_format(time_2 - time_0) == timedelta_format(time_0 - time_2)
    assert timedelta_format(time_1 - time_1) == timedelta_format(time_2 - time_2)
    assert timedelta_format(time_1 - time_2) == timedelta_format(time_2 - time_1)
    time_3 = time_0 + datetime_module.tim

# Generated at 2022-06-24 17:14:10.073555
# Unit test for function timedelta_format
def test_timedelta_format():
    a_0 = timedelta_format(datetime_module.timedelta(microseconds=1))
    assert a_0 == '00:00:00.000001'
    b_0 = timedelta_format(datetime_module.timedelta(seconds=1))
    assert b_0 == '00:00:01.000000'
    c_0 = timedelta_format(datetime_module.timedelta(minutes=1))
    assert c_0 == '00:01:00.000000'
    d_0 = timedelta_format(datetime_module.timedelta(hours=1))
    assert d_0 == '01:00:00.000000'


a_0 = 0


# Generated at 2022-06-24 17:14:13.270429
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:00:01.000000'
    expected = datetime_module.timedelta(seconds=1)
    actual = timedelta_parse(s)
    assert expected == actual


# Generated at 2022-06-24 17:14:21.703683
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5,
                                                       microseconds=76432)) ==  '00:00:05.076432'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                       minutes=2,
                                                       seconds=4,
                                                       microseconds=346)) ==  '01:02:04.000346'
    assert timedelta_format(datetime_module.timedelta(days=5,
                                                       hours=3)) ==  '120:00:00.000000'


# Generated at 2022-06-24 17:14:29.205227
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '\n    Check that timedelta_format and timedelta_parse are reciprocals.\n    '
    timedeltas = [
        datetime_module.timedelta(0),
        datetime_module.timedelta(1),
        datetime_module.timedelta(1, 10),
        datetime_module.timedelta(1, 10, 100),
        datetime_module.timedelta(1, 10, 100, 1000),
        datetime_module.timedelta(1, 10, 100, 1000, 111),
    ]
    for timedelta in timedeltas:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))


# Generated at 2022-06-24 17:14:37.655257
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time_delta_0 = datetime_module.timedelta(0, 0, 0)
    time_delta_1 = datetime_module.timedelta(0, 0, 1)
    time_delta_2 = datetime_module.timedelta(0, 1, 0)
    time_delta_3 = datetime_module.timedelta(1, 0, 0)
    time_delta_4 = datetime_module.timedelta(14, 54, 27)
    time_delta_5 = datetime_module.timedelta(14, 54, 28)
    str_0 = '00:00:00.000000'
    str_1 = '00:00:00.000001'
    str_2 = '00:00:01.000000'

# Generated at 2022-06-24 17:14:41.315632
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.789012') == datetime_module.timedelta(hours=12, minutes=34, seconds=56, microseconds=789012)

# Generated at 2022-06-24 17:14:45.905883
# Unit test for function timedelta_format
def test_timedelta_format():
    str_1 = '\n        Check that timedelta_format and timedelta_parse are reciprocals.\n        '
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1))) == datetime_module.timedelta(seconds=1, microseconds=1)


# Generated at 2022-06-24 17:14:58.586706
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] >= (3, 6):
        expected_result_00 = '00:00:00.000000'
        expected_result_01 = '00:00:00.000001'
        expected_result_10 = '00:00:00.100000'
        expected_result_60 = '00:00:00.600000'
        expected_result_61 = '00:00:00.610000'
        expected_result_62 = '00:00:00.620000'
        expected_result_63 = '00:00:00.630000'
        expected_result_64 = '00:00:00.640000'
        expected_result_65 = '00:00:00.650000'


# Generated at 2022-06-24 17:15:08.396763
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Check that timedelta_format and timedelta_parse are reciprocals.
    '''
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1))) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-24 17:15:13.079450
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'



# Generated at 2022-06-24 17:15:41.863166
# Unit test for function timedelta_format
def test_timedelta_format():
    for seconds in range(1000):
        for microseconds in range(1000000):
            td = datetime_module.timedelta(seconds=seconds,
                                           microseconds=microseconds)
            assert timedelta_parse(timedelta_format(td)) == td



# Generated at 2022-06-24 17:15:47.265107
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=456789)
    str_0 = timedelta_format(timedelta)
    datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=456789) == timedelta_parse(str_0)

    return



# Generated at 2022-06-24 17:15:55.320424
# Unit test for function timedelta_format
def test_timedelta_format():
    """Check that timedelta_format and timedelta_parse are reciprocals."""
    timedelta_0 = datetime_module.timedelta(seconds=1.1)
    timedelta_1 = timedelta_parse(timedelta_format(timedelta_0))
    assert timedelta_0 == timedelta_1

test_case_0()

# Generated at 2022-06-24 17:16:02.626414
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 9)) == '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 99)) == '00:00:00.000099'

# Generated at 2022-06-24 17:16:11.723860
# Unit test for function timedelta_parse
def test_timedelta_parse():
    x = timedelta_parse('08:14:04.321156')
    y = datetime_module.timedelta(hours=8, minutes=14, seconds=4,
                                  microseconds=321156)
    assert x == y
    x = timedelta_parse('0:0:0.0')
    y = datetime_module.timedelta(0)
    assert x == y
    x = timedelta_parse('3:12:34.345678')
    y = datetime_module.timedelta(hours=3, minutes=12, seconds=34,
                                  microseconds=345678)
    assert x == y



# Generated at 2022-06-24 17:16:17.501429
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = timedelta_parse('00:00:00.000000')
    assert (str_0 == datetime_module.timedelta(0, 0, 0))

    str_0 = timedelta_parse('01:02:03.000004')
    assert (str_0 == datetime_module.timedelta(1, 7373, 4))

    str_0 = timedelta_parse('12:11:10.123456')
    assert (str_0 == datetime_module.timedelta(12, 40470, 123456))


# Generated at 2022-06-24 17:16:27.002448
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(3, 0, 14, 57)
    formatted_time = time_isoformat(time)
    assert formatted_time == '03:00:14.000057'
    for i in range(4):
        td = datetime_module.timedelta(hours=i, minutes=i, seconds=i,
                                       microseconds=i)
        formatted_td = timedelta_format(td)
        assert formatted_td == '{:02d}:{:02d}:{:02d}.{:06d}'.format(i, i, i, i)
        parsed_td = timedelta_parse(formatted_td)
        assert parsed_td == td

# Generated at 2022-06-24 17:16:38.646164
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=23))) == datetime_module.timedelta(hours=23)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=24))) == datetime_module.timedelta(hours=24)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999))) == datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999)

# Generated at 2022-06-24 17:16:49.312420
# Unit test for function timedelta_parse
def test_timedelta_parse():
    try:
        assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=77))) == datetime_module.timedelta(seconds=77)
    except AssertionError:
        raise AssertionError(str_0)
    try:
        assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=77, microseconds=500))) == datetime_module.timedelta(seconds=77, microseconds=500)
    except AssertionError:
        raise AssertionError(str_0)

# Generated at 2022-06-24 17:16:55.393578
# Unit test for function timedelta_format
def test_timedelta_format():
    for time_delta in range(0, 1000000, 10000):
        time_delta = datetime_module.timedelta(microseconds=time_delta)
        str_0 = timedelta_format(time_delta)
        time_delta_1 = timedelta_parse(str_0)
        assert time_delta == time_delta_1


# Generated at 2022-06-24 17:17:55.041125
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(seconds=3, milliseconds=122)
    time_0 = time_isoformat(datetime_module.time(0, 0, 3, 122000))
    assert timedelta_format(timedelta_0) == time_0



# Generated at 2022-06-24 17:18:03.352891
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == '23:59:59.999999'
    assert timedelta_format(timedelta_parse('00:00:00.100000')) == '00:00:00.100000'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'

# Generated at 2022-06-24 17:18:12.913785
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=10)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=100)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        days=1000)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        days=10000)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1)) == '00:00:01.000000'

# Generated at 2022-06-24 17:18:19.526774
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '\n    Check that timedelta_format and timedelta_parse are reciprocals.\n    '
    for seconds in range(-10000, 10000, 3):
        for microseconds in range(0, 1000000, 200000):
            timedelta = datetime_module.timedelta(seconds=seconds,
                                              microseconds=microseconds)
            assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-24 17:18:24.610005
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3))) == datetime_module.timedelta(1, 2, 3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(-1, -2, -3))) == datetime_module.timedelta(-1, -2, -3)



# Generated at 2022-06-24 17:18:35.132220
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(hours=3, minutes=3, seconds=3, microseconds=3)
    assert timedelta_format(timedelta_0) == '03:03:03.000003'
    timedelta_0 = datetime_module.timedelta(days=-3)
    assert timedelta_format(timedelta_0) == '-3 days, 0:00:00'
    try:
        timedelta_format(timedelta_0, 'bla')
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 17:18:45.080256
# Unit test for function timedelta_parse
def test_timedelta_parse():
    expected = datetime_module.timedelta(days=1, seconds=2,
                                         milliseconds=3, microseconds=4)
    got = timedelta_parse('1:00:00:00.0030004')
    assert got == expected, '''
Wrong result of timedelta_parse: expected {expected!r}, got {got!r}.
    '''.format(expected=expected, got=got)
    got = timedelta_parse('1:00:02.0030004')
    assert got == expected, '''
Wrong result of timedelta_parse: expected {expected!r}, got {got!r}.
    '''.format(expected=expected, got=got)
    got = timedelta_parse('2:03:00.0004')