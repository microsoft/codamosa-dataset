

# Generated at 2022-06-24 17:08:49.610936
# Unit test for function timedelta_format
def test_timedelta_format():
    args = ["00:00:00.000000"]
    assert timedelta_format(args) == expected_result




# Generated at 2022-06-24 17:09:01.442971
# Unit test for function timedelta_format

# Generated at 2022-06-24 17:09:09.731917
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:12.000000") == datetime_module.timedelta(0, 12)
    assert timedelta_parse("00:01:00.000000") == datetime_module.timedelta(0, 60)
    assert timedelta_parse("01:00:00.000000") == datetime_module.timedelta(0, 3600)
    assert timedelta_parse("01:00:00.123456") == datetime_module.timedelta(0, 3600, 123456)


# Generated at 2022-06-24 17:09:14.498282
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(0.0) == '00:00:00.000000'
    assert timedelta_format(1e-06) == '00:00:00.000001'
    assert timedelta_format(0.00002) == '00:00:00.000002'
    assert timedelta_format(0.0003) == '00:00:00.000003'
    assert timedelta_format(0.0004) == '00:00:00.000004'
    assert timedelta_format(0.0005) == '00:00:00.000005'
    assert timedelta_format(0.0006) == '00:00:00.000006'
    assert timedelta_format(0.0007) == '00:00:00.000007'

# Generated at 2022-06-24 17:09:23.709398
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10.01)) == '00:00:10.010000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.3)) == '00:00:00.300000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1.5)) == '01:30:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=-1)) == '-00:01:00.000000'

# Generated at 2022-06-24 17:09:29.061733
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)))) == '01:02:03.123456'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=0))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=0)
    assert timedelta_

# Generated at 2022-06-24 17:09:32.746417
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Tested function/method is run once...
    timedelta_parse_run_count = 0

    # Tested function/method is run at least once...
    assert timedelta_parse_run_count > 0



# Generated at 2022-06-24 17:09:45.513778
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    from datetime import timedelta
    assert timedelta_parse('00:00:00.000000') == timedelta()
    assert timedelta_parse('00:00:00.000001') == timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.100000') == timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == timedelta(hours=1)
    assert timedelta_parse('-01:00:00.000000') == timedelta(hours=-1)

    with pytest.raises(ValueError):
        timedelta

# Generated at 2022-06-24 17:09:47.037576
# Unit test for function timedelta_parse
def test_timedelta_parse():
    typed_var_0 = False
    assert isinstance(timedelta_parse(typed_var_0), datetime_module.timedelta)



# Generated at 2022-06-24 17:09:54.731436
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(False) == '00:00:00.000000'
    assert timedelta_format(True) == '00:00:00.000001'
    assert timedelta_format(5) == '00:00:00.000005'
    assert timedelta_format(0.00005) == '00:00:00.000005'
    assert timedelta_format(0.05) == '00:00:00.050000'
    assert timedelta_format(0.5) == '00:00:00.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=2.5,
                                                      microseconds=22)) == \
           '00:00:02.005022'

# Generated at 2022-06-24 17:10:11.507749
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000050') == datetime_module.timedelta(
        microseconds=50
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:0:1.000050') == datetime_module.timedelta(
        seconds=1, microseconds=50
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-24 17:10:22.253534
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=100
    )

# Generated at 2022-06-24 17:10:26.889602
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('1:00:01.000000') == datetime_module.timedelta(3600) + datetime_module.timedelta(seconds=1)
    assert timedelta_parse

# Generated at 2022-06-24 17:10:33.214846
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3)) == '72:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=3)) == '00:00:00.003000'

# Generated at 2022-06-24 17:10:36.036995
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-24 17:10:42.963114
# Unit test for function timedelta_parse
def test_timedelta_parse():
    parsed_timedelta = timedelta_parse('1:2:3.004000')
    assert parsed_timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                         seconds=3,
                                                         microseconds=4000)
    parsed_timedelta = timedelta_parse('0:0:0.231415')
    assert parsed_timedelta == datetime_module.timedelta(0, 0, 0, 231415)
    parsed_timedelta = timedelta_parse('0:0:3.')
    assert parsed_timedelta == datetime_module.timedelta(0, 3)
    parsed_timedelta = timedelta_parse('0:0:3')
    assert parsed_timedelta == datetime_module.timedelta(0, 3)


# Generated at 2022-06-24 17:10:56.275835
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:03.000000') == datetime_module.timedelta(
        seconds=3
    )
    assert timedelta_parse('00:04:55.000000') == datetime_module.timedelta(
        minutes=4, seconds=55
    )
    assert timedelta_parse('03:04:55.000000') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=55
    )
    assert timedelta_parse('03:04:55.000001') == datetime_module

# Generated at 2022-06-24 17:11:02.173785
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) == \
           '01:02:03.000000'


# Generated at 2022-06-24 17:11:07.801732
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta()
    assert timedelta_format(timedelta_0) == '00:00:00.000000'


# Generated at 2022-06-24 17:11:13.734597
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        0
    )
    print('passed test 1')
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    print('passed test 2')
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        milliseconds=100
    )
    print('passed test 3')
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        milliseconds=999, microseconds=999
    )
    print('passed test 4')
    assert timedelta_parse('00:00:01.000000') == datetime_module

# Generated at 2022-06-24 17:11:38.460007
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(36.3))) == datetime_module.timedelta(36, 18000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(36.3, 1000))) == datetime_module.timedelta(36, 19000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(365, 1000))) == datetime_module.timedelta(365, 1000)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(365, 100000))) == datetime_module.timed

# Generated at 2022-06-24 17:11:47.014234
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from garlicsim.general_misc import compat
    f = compat.timedelta_parse
    assert f('00:00:00.000000').total_seconds() == 0
    assert f('00:00:01.000000').total_seconds() == 1
    assert f('00:01:00.000000').total_seconds() == 60
    assert f('01:00:00.000000').total_seconds() == 3600
    assert f('00:00:00.000001').microseconds == 1
    assert f('00:00:00.000010').microseconds == 10
    assert f('00:00:00.000100').microseconds == 100
    assert f('00:00:00.001000').microseconds == 1000
    assert f('00:00:00.010000').microseconds == 10000

# Generated at 2022-06-24 17:12:04.265697
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1, 0)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60, 0)
    assert timedelta_

# Generated at 2022-06-24 17:12:12.988760
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_0 = timedelta_parse(timedelta_format(datetime_module.timedelta()))
    int_0 = 0
    assert timedelta_0 == datetime_module.timedelta(hours=int_0, minutes=int_0,
                                                    seconds=int_0,
                                                    microseconds=int_0)
    timedelta_1 = timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1,
    )))
    int_1 = 1
    assert timedelta_1 == datetime_module.timedelta(hours=int_1, minutes=int_0,
                                                    seconds=int_0,
                                                    microseconds=int_0)

# Generated at 2022-06-24 17:12:24.095598
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:00:00.000011') == datetime_module.timedelta(0, 0, 11)
    assert timedelta_parse('0:00:00.000111') == datetime_module.timedelta(0, 0, 111)
    assert timedelta_parse('0:00:00.001111') == datetime_module.timedelta(0, 0, 1111)
    assert timedelta_parse('0:00:00.011111') == datetime_module.timedelta(0, 0, 11111)
    assert timedelta

# Generated at 2022-06-24 17:12:31.402022
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
          '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
          '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == \
          '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == \
          '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == \
          '00:00:00.001000'

# Generated at 2022-06-24 17:12:40.983176
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
                             '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == \
                             '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(microseconds=31)) == \
                             '00:00:00.000031'
    assert timedelta_format(datetime_module.timedelta(microseconds=3135)) == \
                             '00:00:00.003135'
    assert timedelta_format(datetime_module.timedelta(microseconds=313513)) == \
                             '00:00:00.313513'

# Generated at 2022-06-24 17:12:52.495625
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:01.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('00:01:00.000001')) == '00:01:00.000001'
    assert timedelta_format(timedelta_parse('01:00:00.000001')) == '01:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:10.000001')) == '00:00:10.000001'

# Generated at 2022-06-24 17:13:00.171807
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:00:01.001000') == datetime_module.timedelta(
        seconds=1, microseconds=1000)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)

# Generated at 2022-06-24 17:13:10.001974
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
                                            datetime_module.timedelta(0, 0,
                                                                      1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0,
                                                                           3600)



# Generated at 2022-06-24 17:13:45.279394
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:00:10.0000000')
    assert timedelta == datetime_module.timedelta(seconds=10)



# Generated at 2022-06-24 17:13:47.820630
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('0:00:00.000000')
    assert td == datetime_module.timedelta(0)


# Generated at 2022-06-24 17:13:55.450521
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=7, seconds=1)) == \
                                                           '07:00:01.000000'


# Generated at 2022-06-24 17:14:09.391579
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.00')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.0000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.00000')) == '00:00:00.000000'

# Generated at 2022-06-24 17:14:16.242040
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-24 17:14:21.891057
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)



# Generated at 2022-06-24 17:14:30.813997
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=10))) == datetime_module.timedelta(days=10)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=10, hours=15))) == datetime_module.timedelta(days=10, hours=15)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    t1 = datetime_module.timedelta(days=10, hours=15, seconds=40,
                                   microseconds=7)


# Generated at 2022-06-24 17:14:41.814397
# Unit test for function timedelta_format
def test_timedelta_format():
    # Check the couple of obvious ones from the wikipedia example:
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=6,
                                                      seconds=6,
                                                      microseconds=123456)) == \
                            '06:06:06.123456'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=6,
                                                      seconds=36,
                                                      microseconds=123456)) == \
                            '06:06:36.123456'

    # Check all the variations of 1 second:

# Generated at 2022-06-24 17:14:47.861145
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:01:01.000000') == datetime_module.timedelta(hours=1, minutes=1, seconds=1)

# Generated at 2022-06-24 17:14:58.788020
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == \
           datetime_module.timedelta(0)
    assert timedelta_parse('0:00:01.000000') == \
           datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.000000') == \
           datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:00:00.000000') == \
           datetime_module.timedelta(1)
    assert timedelta_parse('0:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
   

# Generated at 2022-06-24 17:16:02.003743
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == '00:00:00.000000'


# Generated at 2022-06-24 17:16:11.940322
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == timedelta_module.timedelta(0)
    assert timedelta_parse('0:0:0.000000') == timedelta_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == \
        timedelta_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0:0.000001') == \
        timedelta_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.00001') == \
        timedelta_module.timedelta(microseconds=10)
    assert timedelta_parse('1:0:0.0') == timedelta_module.timedelta(hours=1)
    assert timedelta_parse

# Generated at 2022-06-24 17:16:19.170954
# Unit test for function timedelta_format
def test_timedelta_format():
    from collections import OrderedDict
    from .test_tools import assert_equal

    time_a_by_timedelta = OrderedDict()
    for hours in (0, 2, 5, 9, 23):
        for minutes in (0, 2, 5, 9, 24, 59):
            for seconds in (0, 2, 5, 9, 24, 59):
                for microseconds in (0, 2, 5, 600_000, 999_999):
                    timedelta = datetime_module.timedelta(
                        hours=hours,
                        minutes=minutes,
                        seconds=seconds,
                        microseconds=microseconds
                    )
                    time_a = datetime_module.datetime.min + timedelta
                    time_a_by_timedelta[timedelta] = time_a


# Generated at 2022-06-24 17:16:21.683129
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:01:02.123456')
    assert timedelta.seconds == 62
    assert timedelta.microseconds == 123456


# Generated at 2022-06-24 17:16:31.039063
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(seconds=1, microseconds=123456)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(seconds=1, microseconds=999999)
    assert timedelta_parse('00:01:00') == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-24 17:16:40.209446
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (
        test_case_0.__code__.co_firstlineno + 2 ==
        inspect.getlineno(timedelta_parse(''))
    )
    timedelta_parse('')
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('01:02:03.000004') == timedelta_parse('01:02:03.04')
    assert timedelta_parse('01:02:03.000004').total_seconds() == 3723.000004
    assert timedelta_parse('35:02:03.000004').total_seconds() == 127323.000004

# Generated at 2022-06-24 17:16:49.735533
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def check(timedelta, s):
        assert timedelta_parse(s) == timedelta

    check(datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                    microseconds=123456),
          '03:02:01.123456')
    check(datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                    microseconds=123000),
          '03:02:01.123')
    check(datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                    microseconds=123000),
          '03:02:01.123000')

# Generated at 2022-06-24 17:16:56.442829
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.0000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == '00:00:10.0000'
    assert timedelta_format(datetime_module.timedelta(seconds=3600)) == '01:00:00.0000'
    assert timedelta_format(datetime_module.timedelta(seconds=86399)) == '23:59:59.0000'
    assert timedelta_format(datetime_module.timedelta(seconds=86400)) == '00:00:00.0000'
    assert timedelta_format(datetime_module.timedelta(seconds=1000000)) == '01:06:40.0000'


# Generated at 2022-06-24 17:17:07.575508
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
                            '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == \
                            '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == \
                            '00:00:00.001234'

# Generated at 2022-06-24 17:17:10.020225
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in range(100_000):
        timedelta = datetime_module.timedelta(days=i)
        assert timedelta_format(timedelta) == timedelta_format(timedelta)
