

# Generated at 2022-06-24 17:08:53.251068
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=8, hours=9, minutes=10, seconds=11,
                                  microseconds=120000))) == datetime_module.timedelta(days=8, hours=9, minutes=10, seconds=11, microseconds=120000)

# Generated at 2022-06-24 17:09:01.615204
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:31:25.123456') == datetime_module.timedelta(0, 5485, 123456)
    assert timedelta_parse('2:9:12.256893') == datetime_module.timedelta(0, 7632, 256893)
    assert timedelta_parse('4:39:19.183423') == datetime_module.timedelta(0, 16559, 183423)
    assert timedelta_parse('5:15:22.296106') == datetime_module.timedelta(0, 18722, 296106)

# Generated at 2022-06-24 17:09:10.849608
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59, seconds=1, microseconds=1)) == '23:59:01.000001'

# Generated at 2022-06-24 17:09:12.491744
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case_0()




# Generated at 2022-06-24 17:09:22.219002
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:09.000090') == datetime_module.timedelta(seconds=9, microseconds=90)
    assert timedelta_parse('00:01:09.000090') == datetime_module.timedelta(minutes=1, seconds=9, microseconds=90)
    assert timedelta_parse('01:01:09.000090') == datetime_module.timedelta(hours=1, minutes=1, seconds=9, microseconds=90)
    assert timedelta_parse('001:01:09.000090') == datetime_module.timedelta(hours=1, minutes=1, seconds=9, microseconds=90)



# Generated at 2022-06-24 17:09:28.601230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)

# Generated at 2022-06-24 17:09:34.423070
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '9=;nZ|ZT`tz%0\x0bB&'
    var_0 = timedelta_parse(str_0)
    assert isinstance(var_0, datetime_module.timedelta)
    str_0 = '\x0e\x17\r\x7f\x0f\x7fQ\x1d\t\x1d\x14\x13]\x06\t\x06'
    var_0 = timedelta_parse(str_0)
    assert isinstance(var_0, datetime_module.timedelta)

# Generated at 2022-06-24 17:09:47.405604
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(days=1, hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=5))
    timedelta_format(datetime_module.timedelta(days=1, hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=999999))
    timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0,
                                               seconds=0,
                                               microseconds=0))
    timedelta_format(datetime_module.timedelta(days=1, hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=0))

# Generated at 2022-06-24 17:09:50.631177
# Unit test for function timedelta_format
def test_timedelta_format():
    case_0 = timedelta_format(test_case_0()) # In case timedelta_parse didn't run
    if timedelta_format(test_case_0()) != case_0:
        print("FAIL")
        return
    print("PASS")



# Generated at 2022-06-24 17:09:57.926872
# Unit test for function timedelta_parse
def test_timedelta_parse():
    t1 = datetime_module.timedelta(hours=1) # 1:00:00
    t2 = datetime_module.timedelta(minutes=1) # 0:01:00
    t3 = datetime_module.timedelta(seconds=1) # 0:00:01
    t4 = datetime_module.timedelta(microseconds=1) # 0:00:00.000001
    t5 = t1 + t2 + t3 + t4
    t6 = timedelta_parse(timedelta_format(t5))
    assert abs(t6 - t5) < t4, "timedelta_format and timedelta_parse are failing"
    assert t6 == t5, "timedelta_format and timedelta_parse are failing"


# Generated at 2022-06-24 17:10:11.645352
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_0 = datetime_module.timedelta(1, 1, 1)
    string_0 = timedelta_format(timedelta_0)
    assert string_0 == '23:59:59.000001'
    timedelta_1 = datetime_module.timedelta(1, 1, 1, 1)
    string_1 = timedelta_format(timedelta_1)
    assert string_1 == '23:59:59.000001'
    timedelta_2 = datetime_module.timedelta(1, 1, 1, 1, 1)
    string_2 = timedelta_format(timedelta_2)
    assert string_2 == '23:59:59.000001'

# Generated at 2022-06-24 17:10:16.059836
# Unit test for function timedelta_format
def test_timedelta_format():
    # pylint: disable=redefined-outer-name
    timedelta_0 = datetime_module.timedelta(hours=22, minutes=5)
    str_0 = timedelta_format(timedelta_0)
    assert str_0 == '22:05:00.000000'


# Generated at 2022-06-24 17:10:22.684165
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:03.123456') == datetime_module.timedelta(0, 3, 123456)
    assert timedelta_parse('00:00:03.123') == datetime_module.timedelta(0, 3, 123000)
    assert timedelta_parse('00:01:10.013000') == datetime_module.timedelta(0, 70, 130000)
    assert timedelta_parse('01:02:31.123456') == datetime_module.timedelta(1, 8551, 123456)

# Generated at 2022-06-24 17:10:27.041654
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:02:03.123456')) == '01:02:03.123456'
    assert timedelta_format(timedelta_parse('10:20:30.123456')) == '10:20:30.123456'

if __name__ == '__main__':

    from python_toolbox import cute_testing
    cute_testing.reload_owned_modules(test_case_0)
    cute_testing.run_all_tests()

# Generated at 2022-06-24 17:10:32.742771
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str = '9=;nZ|ZT`tz%0\x0bB&'
    res = timedelta_parse(str)
    assert res == datetime_module.timedelta(days=11252, seconds=59630, microseconds=22978, milliseconds=50, minutes=86, hours=18, weeks=1617)

# Generated at 2022-06-24 17:10:41.437609
# Unit test for function timedelta_format
def test_timedelta_format():
    str_1 = '00:01:02.000000'
    timedelta_1 = datetime_module.timedelta(seconds=62)
    str_2 = '12:34:56.789012'
    timedelta_2 = datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                            microseconds=789012)

    assert timedelta_format(timedelta_1) == str_1
    assert timedelta_format(timedelta_2) == str_2


# Generated at 2022-06-24 17:10:49.097049
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '9=;nZ|ZT`tz%0\x0bB&'
    var_0 = timedelta_parse(str_0)
    var_1 = datetime_module.timedelta(hours=9, minutes=0, seconds=21, milliseconds=425, microseconds=33)
    assert var_0 == var_1


# Generated at 2022-06-24 17:10:53.076436
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
                                                             '00:00:02.000000'

# Test for function timedelta_parse

# Generated at 2022-06-24 17:11:00.580510
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9)) == '09:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=9, seconds=15, microseconds=5)) == '09:00:15.000005'
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=15, seconds=5)) == '09:15:05.000000'


# Generated at 2022-06-24 17:11:07.747329
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('timedelta_parse("01:02:03.040506") == (1, 2, 3, 40506)')
    print(timedelta_parse("01:02:03.040506") == (1, 2, 3, 40506))
    print("timedelta_parse(\"02:03:04.050607\") == (2, 3, 4, 50607)")
    print(timedelta_parse("02:03:04.050607") == (2, 3, 4, 50607))
    print("timedelta_parse(\"03:04:05.060708\") == (3, 4, 5, 60708)")
    print(timedelta_parse("03:04:05.060708") == (3, 4, 5, 60708))

# Generated at 2022-06-24 17:11:22.937287
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:03.000012') == (
        datetime_module.timedelta(seconds=3, microseconds=12)
    )
    assert timedelta_parse('00:00:03.000012') == (
        datetime_module.timedelta(seconds=3, microseconds=12)
    )



# Generated at 2022-06-24 17:11:33.180244
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=20)) == '00:00:20.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=30)) == '00:00:30.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=40)) == '00:00:40.000000'

# Generated at 2022-06-24 17:11:43.979503
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:00:00:000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00:000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00:000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:00:00:999999')) == '00:00:00.999999'
    assert timedelta_format(timedelta_parse('0:00:01:000000')) == '00:00:01.000000'

# Generated at 2022-06-24 17:11:53.697425
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1)) == '01:01:01.000000'

# Generated at 2022-06-24 17:12:01.682505
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00:000000') == datetime_module.timedelta(
        hours=1
    )

    assert timedelta_parse('0:59:59:999999') == datetime_module.timedelta(
        minutes=59, seconds=59, microseconds=999999
    )

    assert timedelta_parse('0:00:00:000001') == datetime_module.timedelta(
        microseconds=1
    )

# Generated at 2022-06-24 17:12:09.544111
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(hours=23, minutes=59, seconds=58,
                                   microseconds=123456)
    assert timedelta_format(td) == timedelta_parse(timedelta_format(td))
    assert timedelta_format(td) == '23:59:58.123456'



# Generated at 2022-06-24 17:12:18.146538
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('01:00:00.000001')) == \
                                                        '01:00:00.000001'
    assert timedelta_format(timedelta_parse('01:00:00.100100')) == \
                                                        '01:00:00.100100'
    assert timedelta_format(timedelta_parse('01:00:00.100100')) == \
                                                        '01:00:00.100100'
    assert timedelta_format(timedelta_parse('01:00:01.100100')) == \
                                                        '01:00:01.100100'
    assert timedelta_format(timedelta_parse('01:02:01.100100')) == \
                                                        '01:02:01.100100'

# Generated at 2022-06-24 17:12:28.185069
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.1') == datetime_module.timedelta(
        seconds=1, microseconds=100000)
    assert timedelta_parse('00:00:01.01') == datetime_module.timedelta(
        seconds=1, microseconds=10000)
    assert timedelta_parse('00:00:01.001') == datetime_module.timedelta(
        seconds=1, microseconds=1000)
    assert timedelta_parse('00:00:01.0001') == datetime_module.timedelta(
        seconds=1, microseconds=100)
    assert timedelta_parse('00:00:01.00001') == datetime_module.timedelta(
        seconds=1, microseconds=10)

# Generated at 2022-06-24 17:12:39.537165
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) == '01:02:03.456000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == '01:02:03.456789'

# Generated at 2022-06-24 17:12:43.527039
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, minutes=4, seconds=2, microseconds=30000
    ))) == datetime_module.timedelta(
        hours=3, minutes=4, seconds=2, microseconds=30000
    )


# Generated at 2022-06-24 17:13:01.069426
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('01:02:03.123456')
    assert td.total_seconds() == 3723.123456


# Generated at 2022-06-24 17:13:09.598590
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=2,
                                                seconds=1, microseconds=10)) == '03:02:01.000010'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=2,
                                                seconds=1, microseconds=10)) == '03:02:01.000010'
    assert timedelta_format(timedelta_parse('03:02:01.000010')) == '03:02:01.000010'


# Generated at 2022-06-24 17:13:15.261101
# Unit test for function timedelta_format
def test_timedelta_format():
    s = timedelta_format(datetime_module.timedelta(days=1))
    assert s == '00:00:00.000000'
    s = timedelta_format(datetime_module.timedelta(hours=11, minutes=51,
                                                   seconds=45,
                                                   microseconds=123456))
    assert s == '11:51:45.123456'


# Generated at 2022-06-24 17:13:22.746374
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Check the ability of timedelta_parse to parse the output of timedelta_format."""
    import random
    import time
    random.seed(time.time())
    for i in range(10_000):
        result = timedelta_format(datetime_module.timedelta(
            seconds=random.randrange(60, 1e8)
        ))
        assert timedelta_parse(result) == datetime_module.timedelta(seconds=random.randrange(60, 1e8)),\
            "Failed to parse `datetime.timedelta`."

# Generated at 2022-06-24 17:13:30.314040
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for _ in range(100):
        for days in range(100):
            for hours in range(100):
                for minutes in range(100):
                    for seconds in range(100):
                        for microseconds in range(1000000):
                            delta = datetime_module.timedelta(
                                days=days, hours=hours, minutes=minutes,
                                seconds=seconds, microseconds=microseconds
                            )
                            string = timedelta_format(delta)
                            assert delta == timedelta_parse(string)

# Generated at 2022-06-24 17:13:35.512243
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.000123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )



# Generated at 2022-06-24 17:13:37.739728
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:00:00.000001')
    assert timedelta.microseconds == 1

# Generated at 2022-06-24 17:13:40.453450
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert test_case_0() == 1
    def test_case_0():
        int_0 = 1
        return test_timedelta_parse()



# Generated at 2022-06-24 17:13:46.084833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Test if timedelta_parse works properly.
    
    Here, we test if it can parse a full model timedelta string.
    '''
    # Arrange
    timedelta_string = '1:00:00.000000'
    
    # Act
    timedelta_object = timedelta_parse(timedelta_string)
    
    # Assert
    assert timedelta_object == datetime_module.timedelta(minutes=60)
    

# Generated at 2022-06-24 17:13:49.985578
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                          microseconds=56789)
    assert timedelta_format(timedelta) == '50:03:04.056789'

test_timedelta_format()


# Generated at 2022-06-24 17:14:23.357646
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(test_case_0)) == test_case_0


# Generated at 2022-06-24 17:14:34.118024
# Unit test for function timedelta_parse

# Generated at 2022-06-24 17:14:41.774266
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3')) == '1:02:03.000000'
    assert timedelta_format(timedelta_parse('1:2:3.0')) == '1:02:03.000000'
    assert timedelta_format(timedelta_parse('1:2:3.a6')) == '1:02:03.000001'


# Generated at 2022-06-24 17:14:43.600598
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:00.999999') == datetime_module.timedelta(minutes=1, seconds=0, microseconds=999999)

# Generated at 2022-06-24 17:14:50.828824
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                     microseconds=3)) == '00:00:02.000003'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                     milliseconds=3)) == '00:00:02.003000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                     milliseconds=3,
                                                     microseconds=4)) == '00:00:02.003004'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                     milliseconds=3,
                                                     microseconds=40)) == '00:00:02.003040'

# Generated at 2022-06-24 17:15:00.225789
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4))) == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3))) == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2))) == \
           datetime_module.timedelta(hours=1, minutes=2)

# Generated at 2022-06-24 17:15:09.539817
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )
    assert timedelta_parse('1:21:23.000100') == datetime_module.timedelta(
        hours=1, minutes=21, seconds=23, microseconds=100
    )
    assert timedelta_parse('1:21:23.005912') == datetime_module.timedelta(
        hours=1, minutes=21, seconds=23, microseconds=5912
    )
    assert timedelta_parse('1:21:23.5') == datetime_module.timedelta(
        hours=1, minutes=21, seconds=23, microseconds=500_000
    )
    assert timedelta_

# Generated at 2022-06-24 17:15:20.824619
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('00:00:03.001001') == \
                                 datetime_module.timedelta(seconds=3,
                                                           microseconds=1001)

    assert timedelta_parse('00:01:03.001001') == \
                                 datetime_module.timedelta(minutes=1,
                                                           seconds=3,
                                                           microseconds=1001)

    assert timedelta_parse('01:01:03.001001') == \
                                 datetime_module.timedelta(hours=1,
                                                           minutes=1,
                                                           seconds=3,
                                                           microseconds=1001)

    assert timedelta_parse('00:00:00.001001') == \
                                 datetime_module.timedelta(microseconds=1001)


# Generated at 2022-06-24 17:15:25.961231
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=9, minutes=8, seconds=7,
                                   microseconds=600090)
    expected_result = '09:08:07.060090'
    assert timedelta_format(td) == expected_result



# Generated at 2022-06-24 17:15:33.989271
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Bottom line:
    def assert_parse_equals_format(td):
        assert td == timedelta_parse(timedelta_format(td))
    assert_parse_equals_format(datetime_module.timedelta(seconds=1))
    assert_parse_equals_format(datetime_module.timedelta(seconds=0.5))
    assert_parse_equals_format(datetime_module.timedelta(seconds=0.01))
    assert_parse_equals_format(datetime_module.timedelta(seconds=0.005))
    assert_parse_equals_format(datetime_module.timedelta(seconds=0.0005))
    assert_parse_equals_format(datetime_module.timedelta(seconds=0.00005))
    assert_parse_

# Generated at 2022-06-24 17:16:38.157537
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 2, 30000)) == '00:00:02.030000'



# Generated at 2022-06-24 17:16:49.060410
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=10000
    )

    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=100000
    )

    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=1000000
    )

    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )

    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )


# Generated at 2022-06-24 17:16:58.028672
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # A case which is a simple success
    assert(timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=1)))) == timedelta_format(
            datetime_module.timedelta(microseconds=1)))

    # Test when we have more than 6 digits
    assert(timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=1000000)))) == timedelta_format(
            datetime_module.timedelta(microseconds=1000000)))

    # Test when we have less than 6 digits

# Generated at 2022-06-24 17:16:59.888956
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01:000000') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-24 17:17:11.045084
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0)) == \
                                                              '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      seconds=3)) == \
                                                           '02:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=3,
                                                      microseconds=4)) == \
                                                         '02:00:03.000004'

# Generated at 2022-06-24 17:17:17.556266
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == \
           '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=-1, seconds=-1)) == '-01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=-1, seconds=-1)) == '-01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=-1)) == '-01:00:00.000000'



# Generated at 2022-06-24 17:17:24.600556
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                          milliseconds=5,
                                          microseconds=6)
    assert timedelta_format(timedelta) == '50:03:04.005006'
    timedelta = datetime_module.timedelta(seconds=1, microseconds=2)
    assert timedelta_format(timedelta) == '00:00:01.000002'



# Generated at 2022-06-24 17:17:29.857599
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4))\
                                                      == '01:02:03.000004'


# Generated at 2022-06-24 17:17:37.107037
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=100)) == '00:01:40.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=100)) == '00:00:00.100000'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'


# Generated at 2022-06-24 17:17:47.442111
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.2)) == '00:00:01.200000'
    assert timedelta_format(datetime_module.timedelta(seconds=23.45)) == '00:00:23.450000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23)) == '23:00:00.000000'
    assert timedelta_format