

# Generated at 2022-06-24 17:08:59.142539
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import unittest

    class TestTimedeltaParse(unittest.TestCase):
        def test_0(self):
            str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
            var_0 = timedelta_parse(str_0)

            self.assertEqual(
                var_0, datetime_module.timedelta(hours=7, minutes=12,
                                                 seconds=45,
                                                 microseconds=705692)
            )



    unittest.main()

# Generated at 2022-06-24 17:09:04.597054
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)

    var_1 = timedelta_format(var_0)
    assert var_1 == str_0


# Generated at 2022-06-24 17:09:10.957863
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    var_1 = timedelta_format(var_0)
    assert var_1 == str_0

# Generated at 2022-06-24 17:09:22.378156
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def test_simple():
        # `timedelta_parse` accepts string: 'HH:MM:SS.microseconds'.
        assert timedelta_parse('1:10:00.33333') == \
               datetime_module.timedelta(hours=1, minutes=10, seconds=0,
                                         microseconds=33333)

    def test_padding():
        # `timedelta_parse` does not require zero-padding on hours/minutes.
        assert timedelta_parse('1:10:0.33333') == \
               datetime_module.timedelta(hours=1, minutes=10, microseconds=33333)

        assert timedelta_parse('1:10:0') == \
               datetime_module.timedelta(hours=1, minutes=10)
        

# Generated at 2022-06-24 17:09:27.885893
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import random
    random_generator = random.Random()
    random_generator.seed(542)
    str_0 = '{:+d}:{:02d}:{:02d}:{:02d}.{:06d}'.format(
        random_generator.randint(-9999999, 9999999),
        random_generator.randint(0, 59),
        random_generator.randint(0, 59),
        random_generator.randint(0, 59),
        random_generator.randint(0, 99999)
    )
    var_0 = timedelta_parse(str_0)


# Generated at 2022-06-24 17:09:34.488658
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    assert var_0 == datetime_module.timedelta(days=40348, seconds=56971, microseconds=141727)

if __name__ == "__main__":
    print(test_case_0())

# Generated at 2022-06-24 17:09:43.462786
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    expected_0 = datetime_module.timedelta(days=238714, hours=18, minutes=27, seconds=11, milliseconds=171, microseconds=65698)
    assert var_0 == expected_0



# Generated at 2022-06-24 17:09:53.002851
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('+r.o7>MA+y*\x0c5v;5BW&')) == '+r.o7>MA+y*\x0c5v;5BW&'
    assert timedelta_format(timedelta_parse('#m:ZMzm\x13\x11\x10|<')) == '#m:ZMzm\x13\x11\x10|<'
    assert timedelta_format(timedelta_parse('*4]`\x08s,o\x12)K\x0co')) == '*4]`\x08s,o\x12)K\x0co'

# Generated at 2022-06-24 17:09:55.194729
# Unit test for function timedelta_format
def test_timedelta_format():
    var_0 = datetime_module.timedelta(hours=41, minutes=29, seconds=24, microseconds=627223)
    assert timedelta_format(var_0) == '41:29:24.627223'


# Generated at 2022-06-24 17:10:07.081298
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Tests for function `_timedelta_parse`.
    """

    # Test cases:
    TEST_CASES = [
        (datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                   microseconds=5),
         '02:03:04.000005'),
        (datetime_module.timedelta(microseconds=123456),
         '00:00:00.123456'),
    ]
    for expected_result, input_str in TEST_CASES:
        for add_plus_sign in (True, False):
            if add_plus_sign:
                input_str = '+' + input_str
            actual_result = timedelta_parse(input_str)

# Generated at 2022-06-24 17:10:21.181087
# Unit test for function timedelta_format
def test_timedelta_format():
    assert(timedelta_format(datetime_module.timedelta(seconds=1)) == "00:00:01.000000")
    assert(timedelta_format(datetime_module.timedelta(days=3, hours=22,
        minutes=14, seconds=54, milliseconds=231,
        microseconds=123456)) == "22:14:54.359856")


# Generated at 2022-06-24 17:10:25.076949
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    str_1 = timedelta_format(var_0)
    assert type(str_1) is str
    assert str_1 == str_0


# Generated at 2022-06-24 17:10:38.208249
# Unit test for function timedelta_format
def test_timedelta_format():
    var_0 = datetime_module.timedelta(days=19, seconds=93330,
                                      microseconds=582112)
    var_1 = timedelta_format(var_0)
    assert var_1 == '05:02:13.582112'
    var_0 = datetime_module.timedelta(days=27, seconds=45061,
                                      microseconds=383914)
    var_1 = timedelta_format(var_0)
    assert var_1 == '07:05:01.383914'
    var_0 = datetime_module.timedelta(days=21, seconds=75853,
                                      microseconds=783768)
    var_1 = timedelta_format(var_0)

# Generated at 2022-06-24 17:10:51.446116
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=25)) == '25:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=24)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=24, microseconds=1)) == '24:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=-24)) == '-24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-24, microseconds=-1)) == '-24:00:00.000001'

if __name__ == '__main__':
    test_case_0()
    test_timedelta_format()

# Generated at 2022-06-24 17:11:03.042243
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.55)) == '00:00:01.550000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.555)) == '00:00:01.555000'
    assert timedelta

# Generated at 2022-06-24 17:11:13.370532
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                      microseconds=0)
    assert timedelta_format(delta) == '00:00:00.000000'
    delta = datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                      microseconds=0)
    assert timedelta_format(delta) == '00:00:01.000000'
    delta = datetime_module.timedelta(hours=0, minutes=0, seconds=59,
                                      microseconds=0)
    assert timedelta_format(delta) == '00:00:59.000000'
    delta = datetime_module.timedelta(hours=0, minutes=1, seconds=0,
                                      microseconds=0)
    assert timedelta

# Generated at 2022-06-24 17:11:23.583272
# Unit test for function timedelta_format
def test_timedelta_format():
    # Testing code for function timedelta_format
    timedelta_object_0 = datetime_module.timedelta(seconds=(-0.18426))
    str_0 = '-00:00:00.184260'
    assert timedelta_format(timedelta_object_0) == str_0

    timedelta_object_0 = datetime_module.timedelta(seconds=(-0.67672))
    str_0 = '-00:00:00.676720'
    assert timedelta_format(timedelta_object_0) == str_0

    timedelta_object_0 = datetime_module.timedelta(seconds=(1.86738))
    str_0 = '00:00:01.867380'
    assert timedelta_format(timedelta_object_0) == str

# Generated at 2022-06-24 17:11:24.908971
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # str_0
    test_case_0()


# Generated at 2022-06-24 17:11:33.703742
# Unit test for function timedelta_format
def test_timedelta_format():
    "Function timedelta_format"
    # Read tests for function timedelta_format from file test_timedelta_format.tests
    # (each test is on a line starting with '#')
    tests = open('test_timedelta_format.tests').read().split('\n')[1:]
    tests = [test.split('#')[-1].strip() for test in tests if test]
    for test in tests:
        if test.startswith('>>>'):
            exec(test)
            continue
        if test.startswith('assert '):
            assert eval(test[7:])
            continue
        raise ValueError("Couldn't parse test: " + test)


# Generated at 2022-06-24 17:11:44.262387
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(3600, 1)

# Generated at 2022-06-24 17:12:09.470588
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    assert var_0 == datetime_module.timedelta(seconds=2212954.998473018)


# Generated at 2022-06-24 17:12:12.522833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert str_0 == timedelta_format(var_0)
    
    
    
    
    
    
    

# Generated at 2022-06-24 17:12:23.032140
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:01:45.000000') == datetime_module.timedelta(0, 36105)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000011') == datetime_module.timedelta(0, 0, 11)
    assert timedelta_parse('00:00:00.000012') == datetime_module.timedelta(0, 0, 12)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(0, 0, 100000)

# Generated at 2022-06-24 17:12:32.342638
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4)) == '02:03:04'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
           '02:03:04.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
           '00:00:00.000005'



# Generated at 2022-06-24 17:12:35.078323
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == str_0

# Generated at 2022-06-24 17:12:44.416257
# Unit test for function timedelta_format
def test_timedelta_format():

    # ----- Case 0 -----
    var_0 = datetime_module.timedelta(seconds=-3, days=0, microseconds=-43000,
                                      milliseconds=0, minutes=0, hours=0,
                                      weeks=0)
    str_0 = timedelta_format(var_0)

    # ----- Case 1 -----
    var_1 = datetime_module.timedelta(seconds=-3, days=0, microseconds=-43000,
                                      milliseconds=0, minutes=0, hours=0,
                                      weeks=0)
    str_1 = timedelta_parse(str_0).__str__()
    assert str_1 == (
        '-1 day, 23:59:56.957000'
    )



# Generated at 2022-06-24 17:12:50.186414
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Test that timedelta_format returns a string with a time format that
    timedelta_parse can parse.
    '''
    for i in range(10000):
        timedelta = datetime_module.timedelta(
            hours=i,
            microseconds=i
        )
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-24 17:12:56.072704
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # initialize test data, test data are stored in the file
    # ..\tests\test_data\test_python_compatibility.test_timedelta_parse.yaml
    from .test_data.test_python_compatibility import test_timedelta_parse
    for i_0 in range(len(test_timedelta_parse.in_0)):
        str_0 = test_timedelta_parse.in_0[i_0]
        var_0 = timedelta_parse(str_0)
        var_1 = test_timedelta_parse.out_0[i_0]
        assert var_0.hours == var_1.hours
        assert var_0.minutes == var_1.minutes
        assert var_0.seconds == var_1.seconds
        assert var_0.microseconds

# Generated at 2022-06-24 17:13:00.326981
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    str_1 = timedelta_format(var_0)
    assert str_1 == '13:19:04.573375'
    assert isinstance(str_1, str)


# Generated at 2022-06-24 17:13:05.503587
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = timedelta_format(timedelta_parse('+r.o7>MA+y*\x0c5v;5BW&'))
    assert str_0 == '+r.o7>MA+y*\x0c5v;5BW&'


# Generated at 2022-06-24 17:13:30.257347
# Unit test for function timedelta_format
def test_timedelta_format():
    prev_var_0 = var_0
    test_case_0()
    global var_0
    assert var_0 == prev_var_0
    assert timedelta_format(var_0) == str_0

# Generated at 2022-06-24 17:13:33.096059
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    assert timedelta_format(var_0) == str_0



# Generated at 2022-06-24 17:13:44.731339
# Unit test for function timedelta_format
def test_timedelta_format():
    str_1 = '-1 day, 10:06:34.454545'
    tmp_1 = datetime_module.timedelta(days=-1, hours=10, minutes=6,
                                      seconds=34, microseconds=454545)
    assert timedelta_format(tmp_1) == str_1
    str_2 = '-1 day, 10:06:34.454545'
    tmp_2 = datetime_module.timedelta(days=-1, hours=10, minutes=6,
                                      seconds=34, microseconds=454545)
    assert timedelta_format(tmp_2) == str_2
    str_3 = '-6 days, 17:14:28.123456'

# Generated at 2022-06-24 17:13:48.249950
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=3, microseconds=26000)) == '00:00:03.026000'

# Generated at 2022-06-24 17:13:51.493829
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('11:22:33.123456')) == \
                                                        '11:22:33.123456'

# Generated at 2022-06-24 17:14:05.034583
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        timedelta_parse('00:00:00.000001')
    ) == '00:00:00.000001'
    assert timedelta_format(
        timedelta_parse('-00:00:00.000001')
    ) == '-00:00:00.000001'
    assert timedelta_format(
        timedelta_parse('00:00:00.123456')
    ) == '00:00:00.123456'
    assert timedelta_format(
        timedelta_parse('-00:00:00.123456')
    ) == '-00:00:00.123456'
    assert timedelta_format(
        timedelta_parse('01:02:03.123456')
    ) == '01:02:03.123456'
    assert timedelta_

# Generated at 2022-06-24 17:14:15.578180
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Timedelta(hours=1, minutes=1, seconds=1, microseconds=1)
    var_0 = b'\x00\x01\x00\x01\x00\x01\x00\x01'
    var_1 = timedelta_parse(var_0)
    # Timedelta(hours=1, minutes=1, seconds=1, microseconds=1)
    var_2 = '\x00\x01\x00\x01\x00\x01\x00\x01'
    var_3 = timedelta_parse(var_2)
    # Timedelta(days=1, hours=1, minutes=1, seconds=1, microseconds=1)

# Generated at 2022-06-24 17:14:24.134980
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    assert type(var_0) == datetime_module.timedelta
    assert var_0.days == 0
    assert var_0.seconds == 13064
    assert var_0.microseconds == 662347
    # test that timedelta_parse raises a ValueError when given a wrong string
    str_1 = '=bGjnsO>l\\H0>y8Bg%c9q'
    try:
        timedelta_parse(str_1)
    except ValueError:
        pass
    else:
        raise Exception('ValueError should have been raised.')




# Generated at 2022-06-24 17:14:35.958327
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse("01:00:00.000000")) == "01:00:00.000000"
    assert timedelta_format(timedelta_parse("00:00:00.000000")) == "00:00:00.000000"
    assert timedelta_format(timedelta_parse("01:01:01.111111")) == "01:01:01.111111"
    assert timedelta_format(timedelta_parse("02:02:02.222222")) == "02:02:02.222222"
    assert timedelta_format(timedelta_parse("03:03:03.333333")) == "03:03:03.333333"

# Generated at 2022-06-24 17:14:38.577488
# Unit test for function timedelta_format
def test_timedelta_format():
    from datetime import timedelta
    assert timedelta_format(timedelta(days=2, minutes=5, seconds=5.54321)) == '48:05:05.543210'


# Generated at 2022-06-24 17:15:07.462416
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    var_1 = timedelta_format(var_0)
    assert var_1 == str_0, '{} is not equal {}'.format(var_1, str_0)

# Generated at 2022-06-24 17:15:20.132202
# Unit test for function timedelta_parse
def test_timedelta_parse():
    arg_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    ret_0 = timedelta_parse(arg_0)
    assert ret_0 == timedelta_parse('+r.o7>MA+y*\x0c5v;5BW&')
    arg_1 = 'H\xb4y\xdf\x0b\xef\xf6_\xbb\x0bz\xa8\xaaq^'
    ret_1 = timedelta_parse(arg_1)
    assert ret_1 == timedelta_parse('H\xb4y\xdf\x0b\xef\xf6_\xbb\x0bz\xa8\xaaq^')

# Generated at 2022-06-24 17:15:31.384268
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '48:00:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=20,
                                                      minutes=40,
                                                      seconds=50,
                                                      microseconds=60)) == \
                                                      '20:40:50.000060'
    assert timedelta_format(datetime_module.timedelta(hours=20,
                                                      minutes=40,
                                                      seconds=50,
                                                      microseconds=60)) == \
                                                      '20:40:50.000060'

# Generated at 2022-06-24 17:15:46.367570
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999
    )
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(
        microseconds=100)
    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(
        microseconds=10)
    assert timedelta_parse('00:00:00.001') == datetime_module.timedelta(
        microseconds=1)


# Generated at 2022-06-24 17:15:55.139990
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123000)
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02.123') == datetime_module.timedelta(hours=1, minutes=2, seconds=0, microseconds=123000)
    assert timedelta_parse('01:02.000123') == datetime_module.timedelta(hours=1, minutes=2, seconds=0, microseconds=123)

# Generated at 2022-06-24 17:16:01.434690
# Unit test for function timedelta_parse
def test_timedelta_parse():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    print((var_0))
    var_1 = timedelta_parse('%c]@%)\x0fTZ}Cwd\x14')
    print((var_1))
    str_1 = '-spM2;c%\x1b\x1eS"\x1ePv3iW:2@\x0eP-;6*p'
    var_2 = timedelta_parse(str_1)
    print((var_2))


# Generated at 2022-06-24 17:16:11.615930
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test 1: Empty string (failure)
    try:
        timedelta_parse('')
        raise Exception
    except Exception:
        pass

    # Test 2: String that does not conform to expectation (failure)
    try:
        timedelta_parse('1')
        raise Exception
    except Exception:
        pass

    # Test 3: Successful conversion
    timedelta_parse('01:02:03.123456')

    # Test 4: Negative numbers are OK
    timedelta_parse('-01:02:03.123456')

    # Test 5: Less than 4 digits after decimal point
    timedelta_parse('01:02:03.123')

    # Test 6: More than 6 digits after decimal point (failure)

# Generated at 2022-06-24 17:16:14.883846
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    time_0 = timedelta_parse(str_0)
    out_0 = timedelta_format(time_0)
    assert out_0 == str_0

# Generated at 2022-06-24 17:16:20.409514
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'


# Generated at 2022-06-24 17:16:23.111202
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == str_0
    print('timedelta_format passed!')


# Generated at 2022-06-24 17:16:58.841854
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('42:42:42.424242') == datetime_module.timedelta(hours=42, minutes=42, seconds=42, microseconds=424242)
    assert timedelta_parse('12:34:56.789') == datetime_module.timedelta(hours=12, minutes=34, seconds=56, microseconds=789000)

# Generated at 2022-06-24 17:17:07.124145
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse('00:20:00.000000') == datetime_module.timedelta(0, 1200, 0)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 3600, 0)
    assert timedelta_parse('01:00:00.000100') == datetime_module.timedelta(0, 3600, 100)
    assert timedelta_parse('02:00:00.000000') == datetime_module.timedelta(1, 7200, 0)
    assert timedelta_parse('03:25:45.000000') == datetime_module.timedelta(1, 12145, 0)

# Generated at 2022-06-24 17:17:12.360677
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'


# Generated at 2022-06-24 17:17:15.046153
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_case_0()

_module_name = 'test.test_2_to_3_compatibility'
_name = 'test.test_2_to_3_compatibility'
_filename = 'test/test_2_to_3_compatibility.py'

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 17:17:25.529598
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .my_testing import assert_equal
    assert_equal(timedelta_parse('00:00:00.000000'), datetime_module.timedelta(0))
    assert_equal(timedelta_parse('00:00:00.000001'), datetime_module.timedelta(microseconds=1))
    assert_equal(timedelta_parse('00:00:00.123456'), datetime_module.timedelta(microseconds=123456))
    assert_equal(timedelta_parse('00:00:01.123456'), datetime_module.timedelta(seconds=1, microseconds=123456))
    assert_equal(timedelta_parse('00:01:01.123456'), datetime_module.timedelta(minutes=1, seconds=1, microseconds=123456))
   

# Generated at 2022-06-24 17:17:30.694891
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    var_0 = timedelta_parse(str_0)
    assert timedelta_format(var_0) == str_0


# Generated at 2022-06-24 17:17:39.628256
# Unit test for function timedelta_format
def test_timedelta_format():
    str_0 = '+r.o7>MA+y*\x0c5v;5BW&'
    f_1 = timedelta_format((datetime_module.datetime.min + timedelta_parse(str_0)).time())
    f_2 = time_isoformat((datetime_module.datetime.min + timedelta_parse(str_0)).time(), timespec='microseconds')
    f_3 = timedelta_format(timedelta_parse(str_0))
    f_4 = timedelta_format(timedelta_parse(str_0))
    f_5 = timedelta_format(timedelta_parse(str_0))
    assert f_1 == f_2
    assert f_3 == f_4
    assert f_5 == f_2

# Generated at 2022-06-24 17:17:47.484441
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.1') == timedelta_parse('0:00:00.000001')
    assert timedelta_parse('.123') == timedelta_parse('0:00:00.000123')
    assert timedelta_parse('0.123') == timedelta_parse('0:00:00.000123')
    assert timedelta_parse('0.000001') == timedelta_parse('0:00:00.000001')
    assert timedelta_parse('0.000000') == timedelta_parse('0:00:00.000000')
    assert timedelta_parse('0.000010') == timedelta_parse('0:00:00.000010')
    assert timedelta_parse('0.000010.123') == timedelta_parse('0.000010:00:00.000123')


# Generated at 2022-06-24 17:17:49.264097
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(test_case_0()) == str_0


# Generated at 2022-06-24 17:17:53.922450
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('+r.o7>MA+y*\x0c5v;5BW&') == datetime_module.timedelta(microseconds=1, days=1, hours=1, minutes=1, seconds=1)