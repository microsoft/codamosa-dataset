

# Generated at 2022-06-20 12:25:25.937605
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(
        microseconds=100000)
    assert timedelta_parse('0:0:1') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-20 12:25:31.728311
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.023456') == \
           datetime_module.timedelta(minutes=1, seconds=2,
                                     microseconds=23456)
    assert timedelta_parse('11:21:32.987654') == \
           datetime_module.timedelta(hours=11, minutes=21, seconds=32,
                                     microseconds=987654)

    for bad_string in ('', 'a', '0:01:02.023456', '00:1:02.023456',
                       '00:01:2.023456', '00:01:02.1234567',
                       '00:01:02.02345'):
        with pytest.raises(ValueError):
            timedelta_parse(bad_string)

# Generated at 2022-06-20 12:25:42.485854
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime as datetime_module
    cases = [
        datetime_module.timedelta(seconds=0.1),
        datetime_module.timedelta(seconds=10),
        datetime_module.timedelta(minutes=10),
        datetime_module.timedelta(hours=10),
        datetime_module.timedelta(days=10),
        datetime_module.timedelta(days=1, seconds=1),
        datetime_module.timedelta(days=1),
    ]
    for case in cases:
        assert timedelta_parse(timedelta_format(case)) == case



# Generated at 2022-06-20 12:25:46.595049
# Unit test for function timedelta_parse
def test_timedelta_parse():
    the_delta = datetime_module.timedelta(hours=2, minutes=3,
                                          seconds=4, microseconds=567)
    assert timedelta_parse('h:m:s.us', the_delta) == the_delta
    assert timedelta_parse('2:3:4.567') == the_delta

# Generated at 2022-06-20 12:25:58.366352
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=6
    ))) == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=6
    )
    assert timedelta_parse('3:04:05.000006') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=6
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        minutes=3, seconds=4, microseconds=5
    ))) == datetime_module.timedelta(
        minutes=3, seconds=4, microseconds=5
    )

# Generated at 2022-06-20 12:26:06.815562
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=20)) == '02:20:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=20, seconds=3)) == '02:20:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=20, seconds=3, microseconds=4)) == '02:20:03.000004'



# Generated at 2022-06-20 12:26:18.906455
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == \
           datetime_module.timedelta(seconds=0, microseconds=0)
    assert timedelta_parse('0:0:0.000001') == \
           datetime_module.timedelta(seconds=0, microseconds=1)
    assert timedelta_parse('0:0:0.000010') == \
           datetime_module.timedelta(seconds=0, microseconds=10)
    assert timedelta_parse('0:0:0.000100') == \
           datetime_module.timedelta(seconds=0, microseconds=100)
    assert timedelta_parse('0:0:0.001000') == \
           datetime_module.timedelta(seconds=0, microseconds=1000)
    assert timedelta_

# Generated at 2022-06-20 12:26:29.436906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.999999')) == '00:00:00.999999'
    assert timedelta_format(timedelta_parse('0:00:01.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('0:00:01.0')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:00:01')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:01:01')) == '00:01:01.000000'
    assert timedelta_format(timedelta_parse('1:01:01')) == '01:01:01.000000'

# Generated at 2022-06-20 12:26:34.350490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == (
        datetime_module.timedelta(1))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2))) == (
        datetime_module.timedelta(1, 2))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3))) == (
        datetime_module.timedelta(1, 2, 3))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3, 4))) == (
        datetime_module.timedelta(1, 2, 3, 4))

# Generated at 2022-06-20 12:26:43.078100
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3))) == datetime_module.timedelta(1, 2, 3)
    for i in range(10):
        for j in range(10):
            for k in range(10):
                for l in range(10):
                    assert timedelta_parse(timedelta_format(
                        datetime_module.timedelta(i, j, k, l)
                    )) == datetime_module.timedelta(i, j, k, l)

# Generated at 2022-06-20 12:26:59.677720
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2)
    assert timedelta_format(timedelta) == '48:00:00.000000'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123000)
    assert timedelta_format(timedelta) == '01:02:03.123000'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:27:08.142399
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:42:02.444444')) == \
           '01:42:02.444444'
    assert timedelta_format(timedelta_parse('1:42:02.444444')) == \
           '01:42:02.444444'
    assert timedelta_format(timedelta_parse('-1:42:02.444444')) == \
           '-01:42:02.444444'
    assert timedelta_format(timedelta_parse('1:42:02:444444')) == \
           '01:42:02.444444'

# Generated at 2022-06-20 12:27:17.224664
# Unit test for function timedelta_parse
def test_timedelta_parse():
    long_timedelta = datetime_module.timedelta(days=10000, hours=13,
                                               minutes=37, seconds=12,
                                               microseconds=4540000)
    assert timedelta_format(long_timedelta) == '13:37:12.454000'
    assert timedelta_parse(timedelta_format(long_timedelta)) == long_timedelta
    
    
    
    
    


if PY3:
    integer_types = (int,)
    natural_types = integer_types
    code_types = (bytes, type(None))
    float_types = (float,)
    numeric_types = (int, float)
else:
    integer_types = (int, long)
    natural_types = integer_types

# Generated at 2022-06-20 12:27:27.583865
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:0:59.999999') == datetime_module.timedelta(
        seconds=59, microseconds=999999
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timed

# Generated at 2022-06-20 12:27:31.985033
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)
    assert timedelta_parse('01:02:03.004405') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40405)

# Generated at 2022-06-20 12:27:38.870734
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:0:0:0') == timedelta_parse('1:00:00:00')
    assert timedelta_parse('1:0:0:0') != timedelta_parse('1:0:0:1')
    assert timedelta_parse('1:0:0:0') == timedelta_parse('01:00:00:00')
    assert timedelta_parse('1:0:0:0') == timedelta_parse('001:00:00:00')

# Generated at 2022-06-20 12:27:49.544681
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:27:54.847264
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))


if PY3:
    import builtins
else:
    import __builtin__ as builtins

# Generated at 2022-06-20 12:28:02.789487
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == \
        '01:02:03.456789'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '0:0:0.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '0:01:0.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '0:0:01.000000'

# Generated at 2022-06-20 12:28:14.686548
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == (
        datetime_module.timedelta()
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1
    ))) == (datetime_module.timedelta(hours=1))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2
    ))) == (datetime_module.timedelta(hours=1, minutes=2))

# Generated at 2022-06-20 12:28:47.818174
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-20 12:28:57.703776
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hours=10, minutes=20, seconds=30,
                                microseconds=405060)
    assert time_isoformat(time, timespec='microseconds') == \
                                     '10:20:30.405060'
    
    timedelta = datetime_module.datetime.min + datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060,
        ) - datetime_module.datetime.min
    assert timedelta_format(timedelta) == '10:20:30.405060'
    
    

# Generated at 2022-06-20 12:28:59.744280
# Unit test for function timedelta_format
def test_timedelta_format():
    datetime_module.timedelta(days=1, hours=8, minutes=30, seconds=50,
                              microseconds=30000)

# Generated at 2022-06-20 12:29:08.330486
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.123456') == \
           datetime_module.timedelta(seconds=0, microseconds=123456)
    assert timedelta_parse('1:02:03.004000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4000)
    assert timedelta_parse('1:02:03.040000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40000)
    assert timedelta_parse('1:02:03.004') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=400)

# Generated at 2022-06-20 12:29:19.265291
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=456789)
    result = timedelta_format(timedelta)
    assert result == '01:02:03.456789'
    assert timedelta_parse(result) == timedelta


if PY3:
    def int_to_bytes(integer):
        yield integer.to_bytes(1, byteorder='big')
else:
    def int_to_bytes(integer):
        if integer < 128:
            yield chr(integer)
        else:
            yield bytearray(reversed(divmod(integer, 128)))

    # Unit test for function int_to_bytes

# Generated at 2022-06-20 12:29:27.493579
# Unit test for function timedelta_format
def test_timedelta_format():
    assert (timedelta_format(datetime_module.timedelta(hours=2))
                                            == '02:00:00.000000')
    assert (timedelta_format(datetime_module.timedelta(minutes=10))
                                            == '00:10:00.000000')
    assert (timedelta_format(datetime_module.timedelta(seconds=1))
                                            == '00:00:01.000000')
    assert (timedelta_format(datetime_module.timedelta(microseconds=1))
                                            == '00:00:00.000001')

# Generated at 2022-06-20 12:29:29.571896
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10)) == \
           '10:00:00.000000'



# Generated at 2022-06-20 12:29:36.906918
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.999999') == \
           datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('0:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:59.999999') == \
           datetime_module.timedelta(seconds=59, microseconds=999999)

# Generated at 2022-06-20 12:29:41.529554
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == (
        '01:02:03.456789'
    )



# Generated at 2022-06-20 12:29:49.314039
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == \
           '23:59:59.999999'
    assert timedelta_format(timedelta_parse('23:59:59.000001')) == \
           '23:59:59.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
           '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'

# Generated at 2022-06-20 12:30:46.798516
# Unit test for function timedelta_format
def test_timedelta_format():
    assert '00:00:00.000000' == timedelta_format(datetime_module.timedelta(0))
    assert '00:00:01.000000' == timedelta_format(datetime_module.timedelta(0, 1))
    assert '00:00:01.000001' == timedelta_format(datetime_module.timedelta(0, 1, 1))
    assert '00:00:01.000300' == timedelta_format(datetime_module.timedelta(0, 1, 300))
    assert '00:00:01.003000' == timedelta_format(datetime_module.timedelta(0, 1, 3000))
    assert '00:00:01.030000' == timedelta_format(datetime_module.timedelta(0, 1, 30000))

# Generated at 2022-06-20 12:30:56.906403
# Unit test for function timedelta_format
def test_timedelta_format():
    times = [
        (-10, 0, 0, 0),
        (0, -30, 0, 0),
        (0, 0, 0, -30),
        (-10, -30, 0, 0),
        (0, -30, -30, 0),
        (0, -30, 0, -30),
        (-10, -30, -30, 0),
        (-10, -30, 0, -30),
        (0, -30, -30, -30),
        (-10, -30, -30, -30),
    ]

    for hours, minutes, seconds, microseconds in times:
        my_timedelta = datetime_module.timedelta(hours=hours, minutes=minutes,
                                                 seconds=seconds,
                                                 microseconds=microseconds)
        assert timedelta_parse

# Generated at 2022-06-20 12:31:00.644580
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.050006') == \
           datetime_module.timedelta(hours=2,
                                     minutes=3,
                                     seconds=4,
                                     microseconds=50006)

# Generated at 2022-06-20 12:31:06.046562
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.400500') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400500)
    assert timedelta_parse('1:2:3.456789') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)

# Generated at 2022-06-20 12:31:11.623683
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.034567') == timedelta_module.timedelta(
        minutes=1, seconds=2, microseconds=34567
    )
    assert timedelta_parse('01:02:03.456789') == timedelta_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )

# Generated at 2022-06-20 12:31:17.385016
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                                 '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=12)) == \
                                                                 '12:00:00'



# Generated at 2022-06-20 12:31:21.425942
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=23,
                                          seconds=14, microseconds=900000)
    assert timedelta_format(timedelta) == '05:23:14.900000'



# Generated at 2022-06-20 12:31:27.312182
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == (
        '01:02:03.000004'
    )
    assert timedelta_format(datetime_module.timedelta(days=49, hours=1,
                                                      minutes=2, seconds=3,
                                                      microseconds=4)) == (
        '01:02:03.000004'
    )


# Generated at 2022-06-20 12:31:34.482811
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000002') == datetime_module.timedelta(
        microseconds=2
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )

# Generated at 2022-06-20 12:31:37.778843
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=100
    )



# Generated at 2022-06-20 12:33:43.284501
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        seconds=1, microseconds=1000)) == '00:00:01.001000'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1.0001)) == '00:00:01.000100'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1.00001)) == '00:00:01.000010'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1.000001)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1.0000001)) == '00:00:01.000000'

# Generated at 2022-06-20 12:33:52.032992
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_parse('01:02:03.000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )
    assert timedelta_parse('01:02:03.0') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )

# Generated at 2022-06-20 12:33:56.420424
# Unit test for function timedelta_format
def test_timedelta_format():
    for s in '00:00:00.000000', '00:00:10.123456', '01:00:00.000000', '12:34:56.987654':
        assert timedelta_parse(timedelta_format(timedelta_parse(s))) == \
               timedelta_parse(s)

test_timedelta_format()

# Generated at 2022-06-20 12:34:05.062375
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0.5)) == '00:00:01.000050'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1, 1)) == '00:00:00.000101'

# Generated at 2022-06-20 12:34:07.527262
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=120, seconds=1, microseconds=2)
    assert timedelta_format(timedelta) == '00:00:01.000002'



# Generated at 2022-06-20 12:34:16.049439
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004999') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4999)
    assert timedelta_parse('00:02:03.004999') == \
           datetime_module.timedelta(minutes=2, seconds=3,
                                     microseconds=4999)
    assert timedelta_parse('02:03.004999') == \
           datetime_module.timedelta(minutes=2, seconds=3,
                                     microseconds=4999)
    assert timedelta_parse('03.004999') == \
           datetime_module.timedelta(seconds=3, microseconds=4999)

# Generated at 2022-06-20 12:34:25.266336
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:10') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('0:10:0') == datetime_module.timedelta(minutes=10)
    assert timedelta_parse('10:0:0') == datetime_module.timedelta(hours=10)
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )
    assert timedelta_parse('1:1:1.1:1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100100
    )

test_timedelta_parse()

# Generated at 2022-06-20 12:34:33.388544
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.0') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('0:0:0.000000') == dat

# Generated at 2022-06-20 12:34:42.524962
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:01.999999') == datetime_module.timedelta(seconds=1, microseconds=999999)
    assert timedelta_parse('0:00:59.999999') == datetime_module.timedelta(seconds=59, microseconds=999999)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_

# Generated at 2022-06-20 12:34:50.940384
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456))
    assert timedelta_parse('1:2:3.123456') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456))
    assert timedelta_parse('01:02:03.123000') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123000))
    assert timedelta_parse('01:02:03.000000') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3))
    assert timedelta_