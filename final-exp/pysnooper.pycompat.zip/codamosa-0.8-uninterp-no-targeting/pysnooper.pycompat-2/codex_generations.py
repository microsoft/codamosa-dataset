

# Generated at 2022-06-20 12:25:23.085130
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:25:27.893058
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.123456') == \
           datetime_module.timedelta(seconds=1, minutes=23, hours=45,
                                     microseconds=123456)
    assert timedelta_parse('-1:23:45.123456') == \
           datetime_module.timedelta(seconds=-1, minutes=23, hours=45,
                                     microseconds=123456)

# Generated at 2022-06-20 12:25:30.051804
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for delta in (datetime_module.timedelta.min, datetime_module.timedelta.max):
        assert timedelta_parse(timedelta_format(delta)) == delta

# Generated at 2022-06-20 12:25:34.551156
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)

# Generated at 2022-06-20 12:25:44.677326
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0)) == \
                             '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == \
                             '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4)) == \
                             '04:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4, microseconds=1)) == \
                             '04:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=24)) == \
                             '00:00:00.000000'

# Generated at 2022-06-20 12:25:56.370458
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.10') == datetime_module.timedelta(
        0, 0, 10*1e-6)
    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(
        0, 0, 1*1e-6)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        0, 0, 1e-6)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        0, 0, 0)
    assert timedelta_parse('00:00:00.100000') == datetime_module

# Generated at 2022-06-20 12:26:03.957144
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
                                                           '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                           '24:00:00.000000'



# Generated at 2022-06-20 12:26:06.439772
# Unit test for function timedelta_parse
def test_timedelta_parse(): assert timedelta_parse('00:00:01.002000') == datetime_module.timedelta(seconds=1, microseconds=2000)
test_timedelta_parse()

# Generated at 2022-06-20 12:26:11.568793
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=15)) == '02:00:15.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=15, microseconds=10)) == '02:00:15.000010'


# Generated at 2022-06-20 12:26:14.649123
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=3, minutes=2, seconds=1)
    assert timedelta_format(delta) == '03:02:01.000000'
    assert timedelta_parse(timedelta_format(delta)) == delta


if sys.version_info[:2] >= (3, 4):
    from collections.abc import Iterable
else:
    from collections import Iterable



# Generated at 2022-06-20 12:26:30.590796
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(17, 17, 17)) == '00:00:17.000017'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3, microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '24:00:01.000000'

# Generated at 2022-06-20 12:26:41.944846
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                          '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
                                                          '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=10)) == \
                                                          '01:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(minutes=1,
                                                      microseconds=10)) == \
                                                          '00:01:00.000010'

# Generated at 2022-06-20 12:26:52.832609
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1, 2, 3)) == \
           '00:00:01.000003'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 123456)) == \
           '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(10, 10, 123456)) == \
           '00:10:10.123456'
    assert timedelta_format(datetime_module.timedelta(0, 60, 123456)) == \
           '00:01:00.123456'

# Generated at 2022-06-20 12:27:02.901076
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_python_toolbox import TestCase
    assert timedelta_format(datetime_module.timedelta(0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(-1, 86399, 999999)) == \
           '-00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=-1, hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
           '-00:00:00.000001'

# Generated at 2022-06-20 12:27:10.540387
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )

# Generated at 2022-06-20 12:27:18.173668
# Unit test for function timedelta_format
def test_timedelta_format():
    seconds_per_microsecond = 1 / (1e6)
    timedelta = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta) == '00:00:01.000000'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    
    timedelta = datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '00:00:01.000001'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    
    timedelta = datetime_module.timedelta(minutes=1)
    assert timedelta_format(timedelta) == '00:01:00.000000'

# Generated at 2022-06-20 12:27:24.275943
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from python_toolbox import fancy_repr
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    ))) == timedelta_format(
        datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    )

# Generated at 2022-06-20 12:27:28.644977
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(11, 12, 13, 141516)
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=12,
                                                      seconds=13,
                                                      microseconds=141516)) ==\
        time_isoformat(time)

# Generated at 2022-06-20 12:27:33.629786
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=5)) == \
           '09:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=27,
                                                      microseconds=35)) == \
           '00:00:27.000035'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1234,
                                                      microseconds=5)) == \
           '00:00:01.234005'


# Generated at 2022-06-20 12:27:38.307115
# Unit test for function timedelta_parse
def test_timedelta_parse():
    pairs = [
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('1:13:32.000000', datetime_module.timedelta(hours=1, minutes=13,
                                                     seconds=32)),
        ('11:13:32.000000', datetime_module.timedelta(hours=11,
                                                      minutes=13,
                                                      seconds=32)),
        ('11:13:32.444444', datetime_module.timedelta(hours=11,
                                                      minutes=13,
                                                      seconds=32,
                                                      microseconds=444444)),
        ('11:13:32.444444', timedelta_parse('11:13:32.444444')),
    ]

# Generated at 2022-06-20 12:28:13.644797
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0') == datetime_module.timedelta()
    assert timedelta_parse('0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0:0') == datetime_module.timedelta()

    assert timedelta_parse('1') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:28:19.543070
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import datetime
    for dt in (
        datetime.timedelta(days=1, hours=2, minutes=3, seconds=4,
                           microseconds=5),
        datetime.timedelta(),
        datetime.timedelta(seconds=0),
        datetime.timedelta(seconds=1),
        datetime.timedelta(microseconds=1),
        datetime.timedelta(microseconds=1000000),
    ):
        assert timedelta_parse(timedelta_format(dt)) == dt



# Generated at 2022-06-20 12:28:25.151875
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
           datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
           datetime_module.timedelta(1)

# Generated at 2022-06-20 12:28:34.176081
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('50:20:02.123456') == datetime_module.timedelta(
        days=2, hours=2, minutes=20, seconds=2, microseconds=123456
    )
    assert timedelta_parse('02:20:02.123456') == datetime_module.timedelta(
        hours=2, minutes=20, seconds=2, microseconds=123456
    )
    assert timedelta_parse('00:00:02.123456') == datetime_module.timedelta(
        seconds=2, microseconds=123456
    )
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:00.000000') == datetime_

# Generated at 2022-06-20 12:28:43.436207
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )
    assert timedelta_parse('1:1:1.1234') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123400
    )
    assert timedelta_parse('1:1:1.123456') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123456
    )

# Generated at 2022-06-20 12:28:46.757312
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03:04.0005') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     milliseconds=4,
                                     microseconds=5)

# Generated at 2022-06-20 12:28:51.799433
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004010') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40010)




# Generated at 2022-06-20 12:29:00.774740
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=5)) == \
                                                            '26:03:04.000005'

# Generated at 2022-06-20 12:29:08.989848
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
           '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=3601)) == \
           '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
           '24:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-20 12:29:20.014078
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1,
                                                      seconds=0,
                                                      microseconds=0)) == \
           '00:01:00.000000'

# Generated at 2022-06-20 12:29:55.687072
# Unit test for function timedelta_format
def test_timedelta_format():
    """Test the `timedelta_format` function."""
    # Positive durations
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    # Negative durations

# Generated at 2022-06-20 12:30:00.593495
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.000000') == datetime_module.timedelta(hours=2,
                                                                           minutes=3,
                                                                           seconds=4)
    assert timedelta_parse('02:00:00.250000') == datetime_module.timedelta(hours=2,
                                                                           microseconds=250000)

# Generated at 2022-06-20 12:30:02.626489
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:20:00.000000') == datetime_module.timedelta(
        minutes=20
    )

# Generated at 2022-06-20 12:30:14.164006
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'

# Generated at 2022-06-20 12:30:21.486369
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=23, minutes=10, seconds=55, microseconds=667788
    )) == '23:10:55.667788'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=10, seconds=55, microseconds=667788
    )) == '23:10:55.667788'
    assert timedelta_format(datetime_module.timedelta(
        minutes=10, seconds=55, microseconds=667788
    )) == '00:10:55.667788'
    assert timedelta_format(datetime_module.timedelta(
        seconds=55, microseconds=667788
    )) == '00:00:55.667788'

# Generated at 2022-06-20 12:30:26.234517
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time_string = '01:03:04.567891'
    assert timedelta_parse(time_string) == \
           (datetime_module.datetime.min +
            datetime_module.timedelta(hours=1, minutes=3, seconds=4,
                                      microseconds=567891)).time()

# Generated at 2022-06-20 12:30:29.652481
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, minutes=4,
                                          seconds=5, milliseconds=6)
    assert timedelta_format(timedelta) == '03:04:05.006000'



# Generated at 2022-06-20 12:30:36.475095
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=5,
                                                      seconds=7,
                                                      microseconds=8)) \
           == '03:05:07.000008'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=5,
                                                      microseconds=7)) \
           == '02:03:05.000007'



# Generated at 2022-06-20 12:30:45.924568
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = (
        ('01:00:00.000000', datetime_module.timedelta(hours=1)),
        ('01:00:00.000001', datetime_module.timedelta(hours=1, microseconds=1)),
        ('00:01:00.000001', datetime_module.timedelta(minutes=1, microseconds=1)),
        ('00:00:01.000001', datetime_module.timedelta(seconds=1, microseconds=1)),
    )
    for case in cases:
        assert timedelta_parse(case[0]) == case[1]


    assert timedelta_parse('1') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:30:56.027448
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:0:0.000100') == dat

# Generated at 2022-06-20 12:31:54.809741
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''Make sure `timedelta_parse` gives the same results as `timedelta_format`
    and the `timedelta.isoformat` method.'''
    import doctest
    doctest.testmod(verbose=True)
    for _ in range(1000):
        assert timedelta_format(timedelta_parse(timedelta_format(
            datetime_module.timedelta(seconds=0)
        ))) == '00:00:00.000000'
        assert timedelta_format(timedelta_parse(timedelta_format(
            datetime_module.timedelta(seconds=1)
        ))) == '00:00:01.000000'

# Generated at 2022-06-20 12:32:01.061757
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0,1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0,60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0,3600)

if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-20 12:32:11.124717
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=0)
    ) == '00:00:00.000000'

    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=0, seconds=0,
                                  microseconds=0)
    ) == '01:00:00.000000'

    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=2, seconds=0,
                                  microseconds=0)
    ) == '00:02:00.000000'


# Generated at 2022-06-20 12:32:17.909606
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000)
    ) == '01:02:03.400000'



# Generated at 2022-06-20 12:32:21.508032
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.056789') == datetime_module.timedelta(hours=2,
                                                                           minutes=3,
                                                                           seconds=4,
                                                                           microseconds=56789)
    assert timedelta_parse('02:03:04.000000') == datetime_module.timedelta(hours=2,
                                                                           minutes=3,
                                                                           seconds=4)

# Generated at 2022-06-20 12:32:28.895106
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=4,
                                                      microseconds=0)) == (
        '00:00:04.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=4,
                                                      microseconds=6)) == (
        '00:00:04.000006'
    )

# Generated at 2022-06-20 12:32:33.242199
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
           == '01:02:03.123456'


# Generated at 2022-06-20 12:32:41.441268
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, seconds=4,
                                                      microseconds=4)) == '04:00:04.000004'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1,
                                                      microseconds=1)) == '00:00:01.000001'

# Generated at 2022-06-20 12:32:50.196095
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == \
           datetime_module.timed

# Generated at 2022-06-20 12:32:59.304586
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:05:00.000000') == datetime_module.timedelta(
        hours=1, minutes=5)
    assert timedelta_parse('01:05:05.000000') == datetime_module.timedelta(
        hours=1, minutes=5, seconds=5)
    assert timedelta_parse('01:05:05.000001') == datetime_module.timedelta(
        hours=1, minutes=5, seconds=5, microseconds=1)
    assert timedelta_parse('01:05:05.123000') == datetime