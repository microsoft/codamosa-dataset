

# Generated at 2022-06-20 12:25:23.576806
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                             '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                             '00:00:01.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=1)
    ) == '00:00:00.000001'


# Generated at 2022-06-20 12:25:31.351041
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-20 12:25:41.078625
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4,
                                                      days=5)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == '00:00:00.000004'



# Generated at 2022-06-20 12:25:44.004114
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=3, minutes=30, seconds=20,
                                  microseconds=123456)
    ) == '03:30:20.123456'

# Generated at 2022-06-20 12:25:54.721053
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.005678') == \
           datetime_module.timedelta(2, 3 * 60 + 4, 5678)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-20 12:26:02.901152
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        microseconds=6000000
    )) == '00:00:06.000000'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=6000001
    )) == '00:00:06.000001'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=6000009
    )) == '00:00:06.000009'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=6000109
    )) == '00:00:06.000109'
    assert timedelta_format(datetime_module.timedelta(
        minutes=61, microseconds=109
    )) == '01:01:01.000109'
    assert timedelta

# Generated at 2022-06-20 12:26:11.039108
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01'
    assert timedelta_format(datetime_module.timedelta(seconds=-1)) == '-1 day, 23:59:59'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    ) == '01:02:03'

# Generated at 2022-06-20 12:26:15.055717
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == (
        '01:02:03.000004')



# Generated at 2022-06-20 12:26:25.597448
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.123456') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=123456)
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('01:02:03.123456') == timedelta_parse(
        '1:2:3.123456')
    assert timedelta_parse('01:02:03.123456') == timedelta_parse(
        '01:02:03.123456000')




# Generated at 2022-06-20 12:26:31.998150
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=5, seconds=5, microseconds=123456
    )) == '05:05:05.123456'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=5, seconds=5, microseconds=120000
    )) == '05:05:05.120000'
    assert timedelta_format(datetime_module.timedelta(
        minutes=5, seconds=5, microseconds=123456
    )) == '05:05:05.123456'
    assert timedelta_format(datetime_module.timedelta(
        seconds=5, microseconds=123456
    )) == '05:05:05.123456'

# Generated at 2022-06-20 12:26:45.601886
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, minutes=12, seconds=4,
                                          microseconds=100000)
    assert timedelta_format(timedelta) == '03:12:04.100000'


# Generated at 2022-06-20 12:26:55.552120
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(days=365, hours=23, minutes=54,
                                  seconds=32, microseconds=123456)
    assert timedelta_format(t) == '23:54:32.123456'
    t = datetime_module.timedelta(days=-365, hours=23, minutes=54,
                                  seconds=32, microseconds=123456)
    assert timedelta_format(t) == '-23:54:32.123456'
    t = datetime_module.timedelta(days=0, hours=0, minutes=0,
                                  seconds=0, microseconds=0)
    assert timedelta_format(t) == '00:00:00.000000'



# Generated at 2022-06-20 12:27:03.081328
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('14:20:32.000') == datetime_module.timedelta(
        0, 0, 0, 0, 0, 14, 20, 32)
    assert timedelta_parse('14:20:32.888') == datetime_module.timedelta(
        0, 0, 0, 0, 888, 14, 20, 32)
    assert timedelta_parse('14:20:32.999999') == datetime_module.timedelta(
        0, 0, 0, 999999, 0, 14, 20, 32)



# Generated at 2022-06-20 12:27:10.624756
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.2') == timedelta_parse('00:00:00.200000')


if sys.version_info[:2] >= (3, 7):
    from contextlib import nullcontext
else:
    class nullcontext(object):
        def __init__(self, enter_result=None):
            self.enter_result = enter_result
        def __enter__(self):
            return self.enter_result
        def __exit__(self, *excinfo):
            pass


if PY3:
    from io import StringIO, BytesIO
    from queue import Empty
    from configparser import ConfigParser
    from urllib.request import urlopen
else:
    from StringIO import StringIO
    from io import BytesIO
    from Queue import Empty
    from ConfigParser import ConfigParser
   

# Generated at 2022-06-20 12:27:17.498904
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000000') == timedelta_parse('61:1.000000') == \
                                             datetime_module.timedelta(
                                                 hours=1, minutes=1, seconds=1,
                                                 microseconds=0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
                                                 microseconds=1)
    assert timedelta_parse('0:0:0.100000') == datetime_module.timedelta(
                                                 microseconds=100000)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)

# Generated at 2022-06-20 12:27:24.202907
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '01:12:13.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(minutes=72,
                                                           seconds=13)
    s = '01:12:13.456789'
    assert timedelta_parse(s) == datetime_module.timedelta(minutes=72,
                                                           seconds=13,
                                                           microseconds=456789)

# Generated at 2022-06-20 12:27:28.208712
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                          microseconds=5)
    assert timedelta_format(timedelta) == '02:03:04.000005'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:27:35.904620
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, microseconds=1)) == '01:00:00.000001'
    assert timedelta

# Generated at 2022-06-20 12:27:40.785197
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000004') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)


try:
    from typing import Union, AnyStr, Optional
except ImportError:
    Union = AnyStr = Optional = object



# Generated at 2022-06-20 12:27:51.505085
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00.00') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0)
    assert timedelta_parse('01:00:00.00') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0)
    assert timedelta_parse('1:00:00.1') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=100000)
    assert timedelta_parse('1:00:00.01') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=10000)
    assert timedelta_parse('1:00:00.001') == datetime

# Generated at 2022-06-20 12:28:17.386563
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_timedelta import test_timedelta__format
    assert test_timedelta__format(timedelta_format)



# Generated at 2022-06-20 12:28:21.817018
# Unit test for function timedelta_parse
def test_timedelta_parse():
    x = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456000)
    assert timedelta_format(x) == '01:02:03.456000'
    assert timedelta_parse(timedelta_format(x)) == x
    assert timedelta_parse('01:02:03.456000') == x
    assert timedelta_parse('1:2:3.4') == x

# Generated at 2022-06-20 12:28:32.352272
# Unit test for function timedelta_parse
def test_timedelta_parse():
    zero = datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(zero)) == zero

    assert timedelta_parse('00:01:02.300004') == datetime_module.timedelta(
                                                        minutes=1,
                                                        seconds=2,
                                                        microseconds=300004)
    assert timedelta_parse('00:01:02.200000') == datetime_module.timedelta(
                                                        minutes=1,
                                                        seconds=2,
                                                        microseconds=200000)
    assert timedelta_parse('10:09:08.007') == datetime_module.timedelta(
                                                   hours=10,
                                                   minutes=9,
                                                   seconds=8,
                                                   microseconds=7000)


# Generated at 2022-06-20 12:28:39.748219
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45.123456')) == \
                                                        '01:23:45.123456'
    assert timedelta_format(timedelta_parse('123:45.123456')) == \
                                                          '123:45.123456'
    assert timedelta_format(timedelta_parse('45.123456')) == '00:45.123456'
    assert timedelta_format(timedelta_parse('.123456')) == '00:00.123456'

# Generated at 2022-06-20 12:28:49.142162
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456000)
    assert timedelta_format(t) == '01:02:03.456000'
    t = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=45000)
    assert timedelta_format(t) == '01:02:03.045000'
    t = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4500)
    assert timedelta_format(t) == '01:02:03.004500'
    t = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=450)


# Generated at 2022-06-20 12:28:56.150131
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        minutes=5, seconds=7, microseconds=98765,
    ))) == datetime_module.timedelta(minutes=5, seconds=7, microseconds=98765)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, seconds=9,
    ))) == datetime_module.timedelta(hours=3, seconds=9)



# Generated at 2022-06-20 12:29:02.523074
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:00:00.123456') == \
           datetime_module.timedelta(hours=2, seconds=123456 / 10**6)
    assert timedelta_parse('02:00:00.000000') == \
           datetime_module.timedelta(hours=2)
    assert timedelta_parse('02:59:59.123456') == \
           datetime_module.timedelta(hours=2, minutes=59, seconds=123456 / 10**6)

# Generated at 2022-06-20 12:29:05.845288
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) == \
                                                                  '01:02:03.123456'



# Generated at 2022-06-20 12:29:17.507458
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3,
                                                      microseconds=1)) == '00:00:03.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=7, seconds=9,
                                                      microseconds=4)) == '00:07:09.000004'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=2, seconds=1,
                                                      microseconds=3)) == '23:02:01.000003'

# Generated at 2022-06-20 12:29:28.432574
# Unit test for function timedelta_format
def test_timedelta_format():
    import sys
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == \
                            '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(2, 3, 4)) == \
                            '00:00:02.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                            minutes=2, seconds=3, microseconds=4)) == \
                            '01:02:03.000004'
    assert timedelta_format(sys.maxsize) == \
                            '00:00:10:03:11:29.544930'

# Generated at 2022-06-20 12:30:22.849529
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1,
                                          minutes=2,
                                          seconds=3,
                                          microseconds=4)

    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:30:34.230933
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                              '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
                                              '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == \
                                              '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == \
                                              '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == \
                                              '00:00:00.001000'
   

# Generated at 2022-06-20 12:30:44.007326
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        23, 59, 59, 999999
    )
    assert timedelta_parse('23:59:59.000000') == datetime_module.timedelta(
        23, 59, 59
    )
    assert timedelta_parse('23:59:59.010100') == datetime_module.timedelta(
        23, 59, 59, 10100
    )


try:
    from pathlib import Path
except ImportError: # Python < 3.6
    import pathlib2 as pathlib
    Path = pathlib.Path


try:
    from contextlib import asynccontextmanager
except ImportError:
    from contextlib2 import asynccontextmanager

# `exec` was removed from Python 3

# Generated at 2022-06-20 12:30:52.802608
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=12, minutes=1, seconds=3,
                                  microseconds=6)
    )) == datetime_module.timedelta(hours=12, minutes=1, seconds=3,
                                     microseconds=6)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=-12, minutes=-1, seconds=-3,
                                  microseconds=-6)
    )) == datetime_module.timedelta(hours=-12, minutes=-1, seconds=-3,
                                     microseconds=-6)



# Generated at 2022-06-20 12:31:02.828998
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        days=1,
        hours=2,
        minutes=3,
        seconds=4,
        microseconds=123456
    )
    assert timedelta_format(timedelta) == '02:03:04.123456'
    timedelta = datetime_module.timedelta(
        days=1,
        hours=2,
        minutes=3,
        seconds=4,
        microseconds=123
    )
    assert timedelta_format(timedelta) == '02:03:04.000123'
    timedelta = datetime_module.timedelta(
        days=1,
        hours=2,
        minutes=3,
        seconds=4,
        microseconds=12
    )
    assert timedelta_format(timedelta)

# Generated at 2022-06-20 12:31:10.175684
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:2:3.456789') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=456789)
    assert timedelta_parse('4:5:6.789') == \
           datetime_module.timedelta(hours=4, minutes=5, seconds=6, microseconds=789000)
    assert timedelta_parse('7:8:9') == \
           datetime_module.timedelta(hours=7, minutes=8, seconds=9)
    assert timedelta_parse('0:0:1') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse

# Generated at 2022-06-20 12:31:17.616025
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                          '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == \
                                                          '01:02:03.456789'



# Generated at 2022-06-20 12:31:21.599588
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    timedelta = datetime_module.timedelta(
        hours=44, minutes=44, seconds=9, microseconds=735000
    )
    assert timedelta_format(timedelta) == '44:44:09.735000'



# Generated at 2022-06-20 12:31:30.373630
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=5)) == \
                                                      '00:00:02.000005'
    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=3)) == \
                                                      '00:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3, seconds=4)) == \
                                                      '02:03:04.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      minutes=4, seconds=5)) == \
                                                      '51:03:04.000005'

# Generated at 2022-06-20 12:31:41.611368
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def equals(a, b):
        assert a.total_seconds() == b.total_seconds()
    equals(timedelta_parse('00:00:00.000000'),
           datetime_module.timedelta())
    equals(timedelta_parse('01:02:03.123456'),
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456))
    equals(timedelta_parse('1:2:3.123456'),
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456))

# Generated at 2022-06-20 12:33:43.336522
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:1.999999') == datetime_module.timedelta(seconds=1, microseconds=999999)
    assert timedelta_

# Generated at 2022-06-20 12:33:48.954313
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'

    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=400000)
    assert timedelta_format(timedelta) == '01:02:03.400000'



# Generated at 2022-06-20 12:33:57.897897
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1_000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10_000)) == '00:00:00.010000'

# Generated at 2022-06-20 12:34:06.725046
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert (timedelta_format(datetime_module.timedelta(days=0, hours=1)) ==
            '01:00:00.000000')
    assert (timedelta_format(datetime_module.timedelta(days=0, hours=1,
                                                       minutes=2)) ==
            '01:02:00.000000')
    assert (timedelta_format(datetime_module.timedelta(days=0, hours=1,
                                                       minutes=2,
                                                       seconds=3)) ==
            '01:02:03.000000')

# Generated at 2022-06-20 12:34:10.136318
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:34:18.570435
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                               '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
                                                               '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                               '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == \
                                                              '01:00:01.000000'

# Generated at 2022-06-20 12:34:27.401531
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:1:1.000000') == datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999)

# Generated at 2022-06-20 12:34:32.185499
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_parse('0:0:0.123') == datetime_module.timedelta(
        microseconds=123
    )
    assert timedelta_parse('0:0:1.0000000') == datetime_module.timedelta(
        seconds=1
    )

# Generated at 2022-06-20 12:34:41.338719
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=10, minutes=3, seconds=40,
                                          microseconds=500000000)
    assert timedelta_format(timedelta) == '10:03:40.50000000'
    timedelta = datetime_module.timedelta(days=10, seconds=20,
                                          microseconds=900000000)
    assert timedelta_format(timedelta) == '240:00:20.90000000'
    timedelta = datetime_module.timedelta(hours=10)
    assert timedelta_format(timedelta) == '10:00:00.000000'
    timedelta = datetime_module.timedelta()
    assert timedelta_format(timedelta) == '00:00:00.000000'


# Generated at 2022-06-20 12:34:49.724536
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.003000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=3000)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)