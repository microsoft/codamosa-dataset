

# Generated at 2022-06-20 12:25:09.110841
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )


timedelta_parse.pretty_name = 'timedelta_parse()'


if PY3:
    from functools import singledispatch
else:
    from singledispatch import singledispatch

# Generated at 2022-06-20 12:25:21.130876
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        0, microseconds=1
    )
    assert timedelta_parse('0:00:00.000010') == datetime_module.timedelta(
        0, microseconds=10
    )
    assert timedelta_parse('0:00:00.000100') == datetime_module.timedelta(
        0, microseconds=100
    )
    assert timedelta_parse('0:00:00.001000') == datetime_module.timedelta(
        0, microseconds=1000
    )
    assert timedelta_parse('0:00:00.010000') == datetime

# Generated at 2022-06-20 12:25:29.607027
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(milliseconds=1))) == datetime_module.timedelta(milliseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1))) == dat

# Generated at 2022-06-20 12:25:41.837498
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(
        seconds=10
    )
    assert timedelta_parse('00:10:00.000000') == datetime_module.timedelta(
        minutes=10
    )
    assert timedelta_parse('10:00:00.000000') == datetime_module.timedelta(
        hours=10
    )
    assert timedelta_parse('10:10:10.100010') == datetime_module.timedelta(
        hours=10, minutes=10, seconds=10, microseconds=100010
    )
    assert timedelta_parse('10:10:10.100010') == timedelta_

# Generated at 2022-06-20 12:25:46.224468
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (
        timedelta_format(
            timedelta_parse('02:03:04.005678')
        ) ==
        time_isoformat(
            datetime_module.time(2, 3, 4, 5678),
            timespec='microseconds'
        )
    )



# Generated at 2022-06-20 12:25:54.938062
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=3
    )) == '00:01:02.000003'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-20 12:25:57.088654
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:01:02.000001'
    assert timedelta_format(timedelta_parse(s)) == s

# Generated at 2022-06-20 12:26:07.772599
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:00:11.001001')
    assert timedelta.total_seconds() == 11.001001


try:
    from functools import singledispatch
except ImportError: # Python 2.7
    def singledispatch(func):
        dispatch_cache = {}
        def wrapper(*args, **kwargs):
            try:
                type_ = type(args[0])
            except:
                raise TypeError(
                    'singledispatch() expects a type as first argument.'
                )
            if type_ in dispatch_cache:
                return dispatch_cache[type_](*args, **kwargs)
            else:
                raise TypeError(
                    'Unsupported type {} for singledispatch.'.format(type_)
                )

# Generated at 2022-06-20 12:26:11.442147
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=12,
                                                      minutes=13,
                                                      seconds=14,
                                                      microseconds=15)) == \
                                                        '12:13:14.000015'



# Generated at 2022-06-20 12:26:15.561901
# Unit test for function timedelta_format
def test_timedelta_format():
    
    delta = datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                      microseconds=6)
    assert timedelta_format(delta) == '03:04:05.000006'

# Generated at 2022-06-20 12:26:32.263186
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:02:03.000000') == \
                                                datetime_module.timedelta(0,
                                                                          3600 +
                                                                          120 +
                                                                          3)
    assert timedelta_parse('01:02:03.456789') == \
                                                datetime_module.timedelta(0,
                                                                          3600 +
                                                                          120 +
                                                                          3,
                                                                          456789)



# Generated at 2022-06-20 12:26:44.265560
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.234)) == \
           '00:00:01.234000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=2345)) == \
           '00:00:00.002345'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345)) == \
           '00:00:00.012345'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-20 12:26:53.563723
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=3))) == datetime_module.timedelta(seconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=5))) == datetime_module.timedelta(seconds=5)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=100))) == datetime_module.timedelta(seconds=100)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=10, seconds=3))) == datetime_

# Generated at 2022-06-20 12:26:59.232517
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == '01:02:03.456789'
    assert timedelta_format(datetime_module.timedelta(seconds=123)) == '00:02:03.000000'



# Generated at 2022-06-20 12:27:09.424576
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(seconds=.123456)) == \
           '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=.123456)) == \
           '00:01:00.123456'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=.123456)) == \
           '01:01:00.123456'

    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(seconds=.123456), timespec='milliseconds')


# Generated at 2022-06-20 12:27:17.277704
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def t(input, expected):
        assert timedelta_parse(input) == expected

    t('00:00:00.000000', datetime_module.timedelta())
    t('00:01:00.050000', datetime_module.timedelta(seconds=60.05))
    t('00:01:00.0500', datetime_module.timedelta(seconds=60.05))
    t('00:01:00.050', datetime_module.timedelta(seconds=60.05))
    t('00:01:00.05', datetime_module.timedelta(seconds=60.05))
    t('00:01:00.5', datetime_module.timedelta(seconds=60.5))

# Generated at 2022-06-20 12:27:21.072483
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('22:03:04.123456') == \
           datetime_module.timedelta(
               hours=22, minutes=3, seconds=4, microseconds=123456)

# Generated at 2022-06-20 12:27:28.645504
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (
        datetime_module.timedelta(seconds=4),
        datetime_module.timedelta(microseconds=4),
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000),
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4),
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=0),
    ):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:27:30.623565
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('20:15:33.333111') == \
           datetime_module.timedelta(hours=20, minutes=15, seconds=33,
                                     microseconds=333111)

test_timedelta_parse()

# Generated at 2022-06-20 12:27:37.545156
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=43,
                                                      seconds=18,
                                                      microseconds=123456)) ==\
                                                      '09:43:18.123456'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) ==\
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) ==\
                                                      '23:59:59.999999'



# Generated at 2022-06-20 12:28:10.598481
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_timing import timedelta
    assert timedelta_format(timedelta(hours=23, minutes=59, seconds=59,
                                      microseconds=999999)) == '23:59:59.999999'
    assert timedelta_format(timedelta(hours=0, minutes=0, seconds=0,
                                      microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(timedelta(hours=0, minutes=0, seconds=1,
                                      microseconds=0)) == '00:00:01.000000'



# Generated at 2022-06-20 12:28:19.644740
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
           '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == \
           '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
           '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == \
           '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(
        hours=3, minutes=3, seconds=3, microseconds=1)) == '03:03:03.000001'

# Generated at 2022-06-20 12:28:23.366193
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=123456)
    assert time_isoformat(time) == '01:02:03.123456'

# Generated at 2022-06-20 12:28:32.640452
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''Unit test for `timedelta_parse`'''
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == \
                                                    '01:02:03.123456'
    assert timedelta_format(timedelta_parse('1:2:3:123456')) == \
                                                    '01:02:03.123456'
    assert timedelta_format(timedelta_parse('12:34:56.123456')) == \
                                                    '12:34:56.123456'
    assert timedelta_format(timedelta_parse('12:34:56:123456')) == \
                                                    '12:34:56.123456'

# Generated at 2022-06-20 12:28:38.446835
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('01:02:03.999999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=999999
    )



# Generated at 2022-06-20 12:28:48.380422
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=7,seconds=5)) == '00:07:05.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=12)) == '00:00:00.000012'

# Generated at 2022-06-20 12:28:59.560542
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '25:00:00.000000'



# Generated at 2022-06-20 12:29:02.431089
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:22:33.123456') == datetime_module.timedelta(
        hours=1, minutes=22, seconds=33, microseconds=123456
    )

# Generated at 2022-06-20 12:29:09.926902
# Unit test for function timedelta_parse
def test_timedelta_parse():

    for s in ('00:00:00:000000', '00:00:00.000000', '00:00:00,000000',
              '00:00:00_000000', '00:00:00 000000', '00:00:00'):
        assert timedelta_parse(s) == datetime_module.timedelta(seconds=0)

    for s in ('10:00:00:000000', '10:00:00.000000', '10:00:00,000000',
              '10:00:00_000000', '10:00:00 000000', '10:00:00'):
        assert timedelta_parse(s) == datetime_module.timedelta(hours=10)


# Generated at 2022-06-20 12:29:20.775781
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=123456
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-20 12:30:19.968296
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from nose.tools import assert_is_instance
    from .timer import clock_type
    for i in range(1000):
        delta = datetime_module.timedelta(seconds=i)
        string = timedelta_format(delta)
        delta2 = timedelta_parse(string)
        if clock_type is float:
            assert abs(delta - delta2) < datetime_module.timedelta(microseconds=1)
        else:
            assert delta == delta2
        assert_is_instance(string, str)


if PY3:
    def open_python(filename, *args, **kwargs):
        return open(filename, *args, **kwargs)
else:
    def open_python(filename, *args, **kwargs):
        return open(filename, *args, **kwargs)



# Generated at 2022-06-20 12:30:27.542159
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import nose.tools as tools
    for s, expected_result in (
        ('1:2:1.000200', datetime_module.timedelta(hours=1, minutes=2,
                                                    seconds=1,
                                                    microseconds=200)),
        ('11:22:33.445566', datetime_module.timedelta(hours=11, minutes=22,
                                                       seconds=33,
                                                       microseconds=44)),
    ):
        tools.assert_equal(timedelta_format(timedelta_parse(s)), s)

# Generated at 2022-06-20 12:30:38.251036
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=10, minutes=1, seconds=1, microseconds=1
    )) == '10:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=1, microseconds=1
    )) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=1, seconds=1, microseconds=1
    )) == '00:01:01.000001'
    assert timed

# Generated at 2022-06-20 12:30:47.012313
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456000)

    assert timedelta_parse('-1:02:03.456') == datetime_module.timedelta(
        hours=-1, minutes=-2, seconds=-3, microseconds=-456000)

    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)

    assert timedelta_parse('0:-0:0.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)


# Generated at 2022-06-20 12:30:57.116792
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:31:02.711954
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )


if sys.version_info[:2] >= (3, 3):
    from .abc import isasyncgen
else:
    def isasyncgen(value):
        return False # Lolz

# Generated at 2022-06-20 12:31:10.101839
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'

# Generated at 2022-06-20 12:31:18.012051
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(minutes=1) * n
                      for n in range(61)):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta
        assert timedelta_parse(timedelta_format(timedelta)) >= timedelta
        assert timedelta_parse(timedelta_format(timedelta)) <= timedelta
        assert timedelta_format(timedelta_parse(timedelta_format(timedelta))) == timedelta_format(timedelta)

# Generated at 2022-06-20 12:31:21.258074
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.003000') == (
        datetime_module.timedelta(minutes=1, seconds=2, microseconds=3000)
    )



# Generated at 2022-06-20 12:31:24.551589
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:00.000001') == datetime_module.timedelta(
        minutes=1, seconds=1e-6)


# Generated at 2022-06-20 12:32:26.613935
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=26, seconds=43, microseconds=123456
    )) == '05:26:43.123456'



# Generated at 2022-06-20 12:32:31.990147
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(milliseconds=123)
    assert timedelta_format(timedelta) == '00:00:00.001230'
    timedelta = datetime_module.timedelta(seconds=123.456)
    assert timedelta_format(timedelta) == '00:02:03.456000'
    timedelta = datetime_module.timedelta(minutes=5.5, seconds=6)
    assert timedelta_format(timedelta) == '00:05:30.600000'
    timedelta = datetime_module.timedelta(hours=4)
    assert timedelta_format(timedelta) == '04:00:00'
    timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4)


# Generated at 2022-06-20 12:32:40.283409
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        seconds=1,
        microseconds=1,
        minutes=1,
        hours=1
    )
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        seconds=1,
        microseconds=100000,
        minutes=1,
        hours=1
    )
    assert timedelta_parse('1:1:1') == datetime_module.timedelta(
        seconds=1,
        minutes=1,
        hours=1
    )
    assert timedelta_parse('1:1') == datetime_module.timed

# Generated at 2022-06-20 12:32:49.058315
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                       '00:00:00.000000'
    assert timedelta_format(timedelta_parse('10:00:00.000000')) == \
                                                       '10:00:00.000000'
    assert timedelta_format(timedelta_parse('00:11:00.000000')) == \
                                                       '00:11:00.000000'
    assert timedelta_format(timedelta_parse('00:00:12.000000')) == \
                                                       '00:00:12.000000'
    assert timedelta_format(timedelta_parse('00:00:00.123456')) == \
                                                       '00:00:00.123456'



# Generated at 2022-06-20 12:32:57.308523
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        days=1, seconds=2, microseconds=3
    )) == '82800.000003'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=3, minutes=4, seconds=5, microseconds=6
    )) == '108400.000006'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'

# Generated at 2022-06-20 12:33:01.653996
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=22,
                                                      minutes=12,
                                                      seconds=7,
                                                      microseconds=345678)) == \
                                                      '22:12:07.345678'



# Generated at 2022-06-20 12:33:04.292220
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3, seconds=1)) \
           == '00:00:00.000001'


# Generated at 2022-06-20 12:33:13.787799
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('0:0:0.1') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('0:0:0.01') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:0:0.001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.0') == \
           datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('0:0:0.000000000001')

# Generated at 2022-06-20 12:33:19.577864
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                       '00:00:00.000000'
    assert timedelta_format(timedelta_parse('23:00:00.000000')) == \
                                                       '23:00:00.000000'
    assert timedelta_format(timedelta_parse('19:37:34.234567')) == \
                                                   '19:37:34.234567'
    assert timedelta_format(timedelta_parse('00:00:00.123450')) == \
                                                   '00:00:00.123450'




# Generated at 2022-06-20 12:33:30.397317
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0') == timedelta_parse('00:00:00:000000')
    assert timedelta_parse('0.012345') == timedelta_parse('00:00:00:012345')
    assert timedelta_parse('0.12345') == timedelta_parse('00:00:00:12345')
    assert timedelta_parse('0.123456') == timedelta_parse('00:00:00:123456')
    assert timedelta_parse('0.123456') == timedelta_parse('00:00:00:001234.06')
    assert timedelta_parse('0.123456.78') == \
           timedelta_parse('00:00:00:123456.78')
    assert timedelta_parse('1') == timedelta_parse('00:00:01:000000')