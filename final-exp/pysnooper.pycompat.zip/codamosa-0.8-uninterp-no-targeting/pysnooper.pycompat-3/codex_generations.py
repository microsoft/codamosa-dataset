

# Generated at 2022-06-20 12:25:16.980558
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(seconds=1))
    ) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(seconds=-1))
    ) == datetime_module.timedelta(seconds=-1)

# Generated at 2022-06-20 12:25:26.715824
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:00:00.000000') == datetime_module.timedelta(
        12
    )
    assert timedelta_parse('12:00:00.000001') == datetime_module.timedelta(
        12, 1/1000000
    )
    assert timedelta_format(timedelta_parse('12:00:00.000001')) == \
        '12:00:00.000001'
    assert timedelta_parse('12:00:00.000010') == datetime_module.timedelta(
        12, 1/100000
    )

# Generated at 2022-06-20 12:25:29.760216
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=7, minutes=8, seconds=9,
                                          microseconds=10)
    assert timedelta_format(timedelta) == '07:08:09.000010'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:25:41.796445
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=102)) == \
           '00:00:00.000102'
    assert timedelta_format(datetime_module.timedelta(microseconds=102340)) == \
           '00:00:00.102340'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=62)) == \
           '00:01:02.000000'

# Generated at 2022-06-20 12:25:48.356761
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:00.000001') == \
           datetime_module.timedelta(seconds=60, microseconds=1)
    assert timedelta_parse('0:01:00.000010') == \
           datetime_module.timedelta(seconds=60, microseconds=10)
    assert timedelta_parse('1:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:00:01.123456') == \
           datetime_module.timedelta(seconds=1, microseconds=123456)

# Generated at 2022-06-20 12:25:59.543077
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=2, microseconds=394013)
    ) == '00:00:00.394013'

    assert timedelta_format(
        datetime_module.timedelta(seconds=2, microseconds=394013)
    ) == '00:00:02.394013'

    assert timedelta_format(
        datetime_module.timedelta(minutes=2, microseconds=394013)
    ) == '00:02:00.394013'

    assert timedelta_format(
        datetime_module.timedelta(hours=2, microseconds=394013)
    ) == '02:00:00.394013'



# Generated at 2022-06-20 12:26:05.247205
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(hours=4)),
                 '04:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=10, seconds=35, microseconds=555555)),
                 '00:10:35.555555')


# Generated at 2022-06-20 12:26:08.288679
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=456000)
    assert timedelta_format(timedelta) == '01:02:03.456000'



# Generated at 2022-06-20 12:26:20.774625
# Unit test for function timedelta_format
def test_timedelta_format():
    
    timedelta_minute = datetime_module.timedelta(minutes=1)
    timedelta_second = datetime_module.timedelta(seconds=1)
    timedelta_microsecond = datetime_module.timedelta(microseconds=1)
    
    
    assert timedelta_format(timedelta_minute) == '00:01:00.000000'
    assert timedelta_format(timedelta_second) == '00:00:01.000000'
    assert timedelta_format(timedelta_microsecond) == '00:00:00.000001'
    assert timedelta_format(timedelta_minute + timedelta_second) == \
                                                            '00:01:01.000000'

# Generated at 2022-06-20 12:26:31.108970
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.000004')) == \
           '01:02:03.000004'
    assert timedelta_format(timedelta_parse('10:20:30.040506')) == \
           '10:20:30.040506'
    assert timedelta_format(timedelta_parse('10:20:30.000999')) == \
           '10:20:30.000999'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('.1')) == \
           '00:00:00.100000'

# Generated at 2022-06-20 12:26:50.078221
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-20 12:27:00.074327
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == (
        '00:01:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(
        milliseconds=1000
    )) == ('00:00:01.000000')
    assert timedelta_format(datetime_module.timedelta(
        microseconds=1
    )) == ('00:00:00.000001')

# Generated at 2022-06-20 12:27:01.945147
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

# Generated at 2022-06-20 12:27:05.794040
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import random
    import timeit
    for _ in range(1000):
        timedelta = datetime_module.timedelta(
            seconds=random.randrange(36000000),
            microseconds=random.randrange(1000000)
        )
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:27:13.976185
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-20 12:27:19.532231
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0') == datetime_module.timedelta()
    assert timedelta_parse('1:02:03.04') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40000)



# Generated at 2022-06-20 12:27:29.111988
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                      minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) == \
                                                      '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                      minutes=1,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:01:00.000000'
    assert timedelta

# Generated at 2022-06-20 12:27:35.701997
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:04:06.123456') == \
                         datetime_module.timedelta(2, 4 * 60 + 6, 123456)
    assert timedelta_parse('02:04:06.123') == \
                         datetime_module.timedelta(2, 4 * 60 + 6, 123000)
    assert timedelta_parse('02:04:06') == \
                         datetime_module.timedelta(2, 4 * 60 + 6)
    assert timedelta_parse('02:04') == datetime_module.timedelta(0, 2 * 60 + 4)
    assert timedelta_parse('06') == datetime_module.timedelta(0, 6)
    assert timedelta_parse('00') == datetime_module.timedelta(0)

# Generated at 2022-06-20 12:27:46.639755
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000999') == datetime_module.timedelta(microseconds=999)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.001999') == datetime_module.timedelta(microseconds=1999)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(milliseconds=1)

# Generated at 2022-06-20 12:27:56.700819
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_python_toolbox.test_misc.test_shortcuts import assert_equal
    assert_equal(timedelta_parse('12:34:56.123456'),
                 datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                           microseconds=123456))
    assert_equal(timedelta_parse('00:00:00.000000'),
                 datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                           microseconds=0))
    assert_equal(timedelta_parse('-03:-02:-01.000100'),
                 datetime_module.timedelta(hours=-3, minutes=-2, seconds=-1,
                                           microseconds=-10000))



# Generated at 2022-06-20 12:28:10.749033
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3, minutes=4,
                           seconds=5, milliseconds=6, microseconds=7)) == \
                                                  '03:04:05.006007'
    
    

# Generated at 2022-06-20 12:28:17.511825
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0,
                                                                            1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0,
                                                                            60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)



# Generated at 2022-06-20 12:28:19.017687
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)

# Generated at 2022-06-20 12:28:30.350701
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:28:39.234727
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.123480') == \
           datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                     microseconds=123480)
    assert timedelta_parse('3:45.6789') == \
           datetime_module.timedelta(hours=3, minutes=45, seconds=0,
                                     microseconds=678900)
    assert timedelta_parse('4:56') == \
           datetime_module.timedelta(hours=4, minutes=56, seconds=0,
                                     microseconds=0)



# Generated at 2022-06-20 12:28:48.854643
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_parse('00:00:00.000000') == \
                                datetime_module.timedelta(hours=0, minutes=0,
                                                          seconds=0,
                                                          microseconds=0)
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) == \
                                                      '00:00:01.000000'
    assert timedelta_parse('00:00:01.000000') == \
                                datetime_module.timedelta

# Generated at 2022-06-20 12:28:57.075987
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:20:30.123456') == \
        datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                  microseconds=123456)
    assert timedelta_parse('0:1:2.345678') == \
        datetime_module.timedelta(minutes=1, seconds=2, microseconds=345678)
    assert timedelta_parse('3.456789') == \
        datetime_module.timedelta(seconds=3, microseconds=456789)



# Generated at 2022-06-20 12:29:05.565979
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'



# Generated at 2022-06-20 12:29:09.735518
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=456789
    )) == '01:02:03.456789'



# Generated at 2022-06-20 12:29:20.648853
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                 datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1)
    )) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1, microseconds=7)
    )) == datetime_module.timedelta(seconds=1, microseconds=7)

# Generated at 2022-06-20 12:29:55.377308
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.040000') == datetime_module.timedelta(
        1, 2 * 60 + 3, 40000
    )
    assert timedelta_parse('0:0:0.000456') == datetime_module.timedelta(
        0, 0, 456
    )
    assert timedelta_parse('0:0:0.0456') == datetime_module.timedelta(
        0, 0, 45600
    )
    assert timedelta_parse('0:0:0.456') == datetime_module.timedelta(
        0, 0, 456000
    )
    assert timedelta_parse('0:0:0.123000') == datetime_module.timedelta(
        0, 0, 123
    )
assert test_timed

# Generated at 2022-06-20 12:29:58.704557
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('-00:00:00.000000') == datetime_module.timedelta(0)

# Generated at 2022-06-20 12:30:09.780233
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, microseconds=2
    )) == '02:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, seconds=3, microseconds=5
    )) == '02:00:03.000005'

# Generated at 2022-06-20 12:30:19.232357
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000010') == \
           datetime_module.timedelta(seconds=1, microseconds=10)

    assert timedelta_parse('00:00:01.000011') == \
           datetime_module.timedelta(seconds=1, microseconds=11)

    assert timedelta_parse('00:00:01.000111') == \
           datetime_module.timedelta(seconds=1, microseconds=111)

    assert timedelta_parse('00:00:01.001111') == \
           datetime_module.timedelta(seconds=1, microseconds=1111)

    assert timedelta_parse('00:00:01.011111') == \
           datetime_module.timedelta(seconds=1, microseconds=11111)

    assert timed

# Generated at 2022-06-20 12:30:27.788498
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0,
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=8, minutes=4, seconds=2, microseconds=99999,
    )) == '08:04:02.099999'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999,
    )) == '23:59:59.999999'


# Generated at 2022-06-20 12:30:36.076465
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
    )
    assert timedelta_parse('01:02') == datetime_module.timedelta(
        hours=1, minutes=2
    )


"""
TODO: Make a unit test to make sure all string types are covered.
"""

# Generated at 2022-06-20 12:30:45.598840
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_equivalent(s1, s2):
        t1 = timedelta_parse(s1)
        t2 = timedelta_parse(s2)
        assert t1 == t2
        assert timedelta_format(t1) == s1
        assert timedelta_format(t2) == s2
    assert_equivalent('00:00:00.000000', '0.0')
    assert_equivalent('00:00:00.000001', '0.000001')
    assert_equivalent('00:00:00.000010', '0.00001')
    assert_equivalent('00:00:00.000100', '0.0001')
    assert_equivalent('00:00:00.001000', '0.001')

# Generated at 2022-06-20 12:30:55.673149
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'

# Generated at 2022-06-20 12:31:05.685896
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:05:00') == datetime_module.timedelta(minutes=65)
    assert timedelta_parse('1:05:10') == datetime_module.timedelta(minutes=65, seconds=10)
    assert timedelta_parse('1:05:10.000000') == datetime_module.timedelta(minutes=65, seconds=10)
    assert timedelta_parse('1:05:10.000001') == datetime_module.timedelta(minutes=65, seconds=10, microseconds=1)

# Generated at 2022-06-20 12:31:16.361945
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1))) == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)



# Generated at 2022-06-20 12:32:21.571045
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=5)) == '00:00:00.005000'

# Generated at 2022-06-20 12:32:28.218487
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1))) == datetime_module.timedelta(seconds=1, microseconds=1)

# Generated at 2022-06-20 12:32:37.655139
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=0
    ))) == datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=0
    )

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=999
    ))) == datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=999
    )

# Generated at 2022-06-20 12:32:41.442925
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                   seconds=3,
                                                   microseconds=456789))
    ) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456789)

# Generated at 2022-06-20 12:32:46.198579
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=18,
                                          seconds=18,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '02:18:18.123456'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


# Generated at 2022-06-20 12:32:54.224597
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=365)) == '00:00:00.000000'
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=365)
    )) == datetime_module.timedelta(days=365)
    assert timedelta_format(datetime_module.timedelta(days=365, microseconds=1)) == '00:00:00.000001'
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=365, microseconds=1)
    )) == datetime_module.timedelta(days=365, microseconds=1)

# Generated at 2022-06-20 12:33:02.522597
# Unit test for function timedelta_format
def test_timedelta_format():
    dt = datetime_module.timedelta(days=3000)
    assert timedelta_format(dt) == '00:00:00.000000'
    dt = datetime_module.timedelta(hours=10, minutes=1, seconds=2,
                                   microseconds=3)
    assert timedelta_format(dt) == '10:01:02.000003'
    dt = datetime_module.timedelta(minutes=1, seconds=2, microseconds=3)
    assert timedelta_format(dt) == '00:01:02.000003'
test_timedelta_format()


# Generated at 2022-06-20 12:33:12.175297
# Unit test for function timedelta_format
def test_timedelta_format():
    if timedelta_format(datetime_module.timedelta(days=9)) != '00:00:00.000000':
        raise Exception

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'


# Generated at 2022-06-20 12:33:19.487085
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1, seconds=1,
                                                      minutes=1, hours=1, days=1))

# Generated at 2022-06-20 12:33:22.900138
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456789)
    assert timedelta_format(td) == '01:02:03.456789'
