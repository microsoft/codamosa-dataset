

# Generated at 2022-06-20 12:25:21.844510
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('01:02:03:004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('01:02:03.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_parse('01:02:03:4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )

# Generated at 2022-06-20 12:25:30.114333
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1))
    ) == datetime_module.timedelta(hours=1)

    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1, minutes=10))
    ) == datetime_module.timedelta(hours=1, minutes=10)

    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1, seconds=10))
    ) == datetime_module.timedelta(hours=1, seconds=10)


# Generated at 2022-06-20 12:25:32.398682
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(
        timedelta_parse('02:03:04.123456')
    ) == '02:03:04.123456'

# Generated at 2022-06-20 12:25:37.437195
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59.999999') == \
           datetime_module.timedelta(days=1)



# Generated at 2022-06-20 12:25:41.713906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('01:15:00.130000') == datetime_module.timedelta(hours=1, minutes=15, seconds=0, microseconds=130000)
    with pytest.raises(ValueError):
        timedelta_parse('01:15:00.131')

# Generated at 2022-06-20 12:25:45.910302
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_python_toolbox import TestCase

    class TestTimedeltaParse(TestCase):
        def test(self):
            self.assertEqual(timedelta_parse('01:02:03.123456'),
                             datetime_module.timedelta(hours=1, minutes=2,
                                                       seconds=3,
                                                       microseconds=123456))

# Generated at 2022-06-20 12:25:57.568212
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('1:2:3.009999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=99
    )
    assert timedelta_parse('1:2:03.009999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=99
    )
    assert timedelta_parse('1:2:03.009999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=99
    )

# Generated at 2022-06-20 12:26:07.667402
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3))) == \
                                                           datetime_module.timedelta(days=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3.14))) == \
                                                           datetime_module.timedelta(days=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=33))) == \
                                                           datetime_module.timedelta(seconds=33)

# Generated at 2022-06-20 12:26:20.006887
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1,
                                                      microseconds=1)) == \
        '00:01:00.000001'

# Generated at 2022-06-20 12:26:30.444507
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=456)
    assert time_isoformat(time) == '01:02:03.00456'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1)
    ) == '01:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(minutes=1)
    ) == '00:01:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(seconds=1)
    ) == '00:00:01.000000'

# Generated at 2022-06-20 12:26:48.853460
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=0
    )) == '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=4
    )) == '01:02:03.000004'

    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=456789
    )) == '01:02:03.456789'



# Generated at 2022-06-20 12:26:56.808584
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4334
    )) == '01:02:03.004334'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=434334
    )) == '01:02:03.434334'


#

# Generated at 2022-06-20 12:27:03.593921
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                          '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                          '00:00:00.000001'
    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(microseconds=1), 'seconds')



# Generated at 2022-06-20 12:27:13.131385
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=100)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=100, minutes=1)) == '100:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=100, seconds=1)) == '01:40:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=100, microseconds=1)) == '00:01:40.000001'
    assert timedelta_format(datetime_module.timedelta(days=100, hours=1, minutes=2,
                                                      seconds=3, microseconds=4)) == '100:01:02.000003'

# Generated at 2022-06-20 12:27:23.800418
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(1, 2, 3, 4), timespec='microseconds')
    assert time == '01:02:03.000004'
    time = time_isoformat(datetime_module.time(1, 2, 3, 40), timespec='microseconds')
    assert time == '01:02:03.000040'
    time = time_isoformat(datetime_module.time(1, 2, 3, 400000), timespec='microseconds')
    assert time == '01:02:03.400000'
    time = time_isoformat(datetime_module.time(1, 2, 3, 4000000), timespec='microseconds')
    assert time == '01:02:03.400000'


# Generated at 2022-06-20 12:27:32.420394
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('1:02:03.000456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456)

    assert timedelta_parse('0:00:00.000000') == \
           datetime_module.timedelta()

    assert timedelta_parse('0:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)

    assert timedelta_parse('-1:02:03.000456') == \
           - datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                       microseconds=456)

    assert timedelta_parse('-0:00:00.000000') == \
           datetime_module.timedelta()

    assert timed

# Generated at 2022-06-20 12:27:37.226463
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.456789')) == \
                                                    '01:02:03.456789'


if PY3:
    def iteritems(d):
        return d.items()
else:
    def iteritems(d):
        return d.iteritems()

# Generated at 2022-06-20 12:27:41.320314
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=10, minutes=21, seconds=12, microseconds=155555
    ))) == datetime_module.timedelta(
        hours=10, minutes=21, seconds=12, microseconds=155555
    )

# Generated at 2022-06-20 12:27:52.010935
# Unit test for function timedelta_format
def test_timedelta_format():
    import numbers
    assert isinstance(timedelta_format(datetime_module.timedelta()),
                      text_type)
    assert timedelta_format(datetime_module.timedelta(-1, 86399, 999999)) == \
           '-01:00:00.999999'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
           '01:01:01.000001'
    for timedelta_ in timedelta_format, datetime_module.timedelta:
        assert timedelta_format(timedelta_(0)) == '00:00:00.000000'

# Generated at 2022-06-20 12:27:59.890095
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)

test_timedelta_parse()

# Generated at 2022-06-20 12:28:24.154908
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:59.999999') == \
           datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(seconds=60)
    assert timedelta_parse('00:59:59.999999') == \
           datetime_module.timedelta(minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(minutes=60)

# Generated at 2022-06-20 12:28:33.399876
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=72)) == \
           '72:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                            microseconds=2)) == '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(minutes=6,
                            microseconds=5)) == '00:06:00.000005'



# Generated at 2022-06-20 12:28:45.020115
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=40)) == \
           '00:00:00.000040'
    assert timedelta_format(datetime_module.timedelta(microseconds=400)) == \
           '00:00:00.000400'
    assert timedelta_format(datetime_module.timedelta(microseconds=4000)) == \
           '00:00:00.004000'
    assert timedelta_format(datetime_module.timedelta(microseconds=40000)) == \
           '00:00:00.040000'
    assert timedelta_format(datetime_module.timedelta(microseconds=400000)) == \
           '00:00:00.400000'

# Generated at 2022-06-20 12:28:51.441333
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('0:0:1.100000') == datetime_module.timedelta(seconds=1, microseconds=100000)
    assert timedelta_parse('0:0:1.123456') == datetime_module.timedelta(seconds=1, microseconds=123456)
    assert timedelta_parse('0:1:1.123456') == datetime_module.timedelta(minutes=1, seconds=1, microseconds=123456)

# Generated at 2022-06-20 12:29:01.542794
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-20 12:29:09.495791
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == \
           '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=20)) == \
           '00:00:01.000020'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=200)) == \
           '00:00:01.000200'
    assert timedelta_format

# Generated at 2022-06-20 12:29:13.845928
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
                                                                 == '01:02:03.123456'


# Generated at 2022-06-20 12:29:18.561941
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=1234)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=1234)

# Generated at 2022-06-20 12:29:29.335164
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1, microseconds=0
    )
    assert timedelta_parse('23:00:00.000000') == datetime_module.timedelta(
        hours=23, microseconds=0
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module

# Generated at 2022-06-20 12:29:36.745372
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                           '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1
    )) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'

# Generated at 2022-06-20 12:30:16.381442
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=10,
                                                      seconds=23,
                                                      microseconds=123456)) == \
                            '00:10:23.123456'
    assert timedelta_format(datetime_module.timedelta(hours=12, minutes=16,
                                                      seconds=57,
                                                      microseconds=654321)) == \
                            '12:16:57.654321'



# Generated at 2022-06-20 12:30:26.085788
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(days=2.5)) == \
           '48:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3.5)) == \
           '00:00:03.500000'

    timedelta = datetime_module.timedelta(seconds=3)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta(days=2.5)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:30:29.221011
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=4, seconds=3, microseconds=21
    )) == '05:04:03.000021'

# Generated at 2022-06-20 12:30:40.232724
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for time_string, expected_timedelta in (
        ('01:02:03.123456',
         datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456)),
        ('01:02:03.000006',
         datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=6)),
        ("00:59:59.999000",
         datetime_module.timedelta(minutes=59, seconds=59, microseconds=999000)),
        ('00:00:00.000000',
         datetime_module.timedelta(0)),
    ):
        assert timedelta_parse(time_string) == expected_timedelta
    assert timedelta_parse('0:00:00.000000')

# Generated at 2022-06-20 12:30:47.977162
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4567)
    assert timedelta_format(timedelta) == '01:02:03.004567'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


try:
    from importlib import resources as importlib_resources
except ImportError:
    try:
        from importlib_resources import open_text
    except ImportError:
        import pkg_resources

        def open_text(package_or_requirement, resource_name):
            return pkg_resources.resource_stream(
                package_or_requirement,
                resource_name
            )



# Generated at 2022-06-20 12:30:58.498635
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('01:02:03.000000')
    timedelta_parse('1:02:03.000000')
    timedelta_parse('01:2:03.000000')
    timedelta_parse('1:2:03.000000')
    timedelta_parse('01:02:3.000000')
    timedelta_parse('1:02:3.000000')
    timedelta_parse('01:02:03.000001')
    timedelta_parse('1:02:03.000001')
    timedelta_parse('01:02:03.123456')
    timedelta_parse('1:02:03.123456')
    timedelta_parse('1:02:03.123456')
    timedelta_parse('1:2:3.123456')

# Generated at 2022-06-20 12:31:07.645291
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.1234567') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.12345678') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timed

# Generated at 2022-06-20 12:31:19.241922
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                              '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'

# Generated at 2022-06-20 12:31:22.344079
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=0, seconds=1, microseconds=1)
    assert timedelta_format(td) == '00:00:01.000001'



# Generated at 2022-06-20 12:31:30.971841
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.456789') == \
                           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                     microseconds=456789)
    assert timedelta_parse('1:02:03.000000') == \
                           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                     microseconds=0)
    assert timedelta_parse('1:02:03.123400') == \
                           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                     microseconds=123400)

# Generated at 2022-06-20 12:32:54.187239
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = timedelta_format(datetime_module.timedelta(days=2, hours=1,
                                   minutes=23, seconds=5, microseconds=123456))
    assert timedelta_parse(s) == datetime_module.timedelta(days=2, hours=1,
                                                            minutes=23,
                                                            seconds=5,
                                                            microseconds=123456)

# Generated at 2022-06-20 12:32:56.872018
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.040506') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40506)



# Generated at 2022-06-20 12:33:03.983972
# Unit test for function timedelta_format
def test_timedelta_format():
    import wingdbstub
    x = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=10)
    assert timedelta_format(x) == '01:02:03.000010'
    x = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                  microseconds=51)
    assert timedelta_format(x) == '02:03:04.000005'


# Generated at 2022-06-20 12:33:08.825748
# Unit test for function timedelta_format
def test_timedelta_format():
    for s, timedelta in [
            ('00:00:00.000000', datetime_module.timedelta(0)),
            ('23:59:59.999999', datetime_module.timedelta(days=1) -
                                datetime_module.timedelta(microseconds=1)),
            ]:
        assert timedelta_format(timedelta) == s


# Generated at 2022-06-20 12:33:17.550249
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
                            '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3.5)) == \
                            '00:00:03.500000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == \
                            '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
                            '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=10)) == \
                            '240:00:00.000000'

# Generated at 2022-06-20 12:33:20.244271
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=12, minutes=36, seconds=57, microseconds=123456
    )) == '12:36:57.123456'


# Generated at 2022-06-20 12:33:31.129338
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45.678901')) == \
           '01:23:45.678901'
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('-1:23:45.678901')) == \
           '-01:23:45.678901'

try:
    from datetime import timezone
except ImportError: # Python 2.7
    class timezone(object):
        __slots__ = ('_offset', '_name')

        def __init__(self, offset, name=None):
            assert not isinstance(offset, timezone)
            self._offset = offset

# Generated at 2022-06-20 12:33:34.348856
# Unit test for function timedelta_format
def test_timedelta_format():
    for _ in range(10000):
        x = datetime_module.timedelta(days=-1, seconds=-1,
                                      microseconds=-1)
        str(x) == timedelta_format(x)



# Generated at 2022-06-20 12:33:42.218200
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1)
    assert timedelta_parse('1:1:1.111111') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=111111)
    assert timedelta_parse('1:1:1.999999') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=999999)
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(
        seconds=0, microseconds=0)
    assert timedelta_parse('0:0:1.0') == datetime_module.tim

# Generated at 2022-06-20 12:33:50.588553
# Unit test for function timedelta_format