

# Generated at 2022-06-20 12:25:21.722269
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta()
    assert timedelta_format(delta) == '00:00:00.000000'
    delta = datetime_module.timedelta(hours=1)
    assert timedelta_format(delta) == '01:00:00.000000'
    delta = datetime_module.timedelta(minutes=1)
    assert timedelta_format(delta) == '00:01:00.000000'
    delta = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_format(delta) == '24:00:01.000001'
    delta = datetime_module.timedelta(days=-10)
    assert timedelta_format(delta) == '-240:00:00.000000'
   

# Generated at 2022-06-20 12:25:30.030774
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('13:45:59.000000') == \
           datetime_module.timedelta(hours=13, minutes=45, seconds=59)

    assert timedelta_parse('13:45:59.123456') == \
           datetime_module.timedelta(hours=13, minutes=45, seconds=59,
                                     microseconds=123456)

    assert timedelta_parse('13:45:59.123456789') == \
           datetime_module.timedelta(hours=13, minutes=45, seconds=59,
                                     microseconds=123456)

    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)


# Generated at 2022-06-20 12:25:41.837743
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0))) == datetime_module.timedelta(0, 0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1))) == datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1))) == datetime_module.timedelta(1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1, 100))) == datetime_module.timedelta(0, 1, 100)

# Generated at 2022-06-20 12:25:53.470336
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def should_be_equal_by_time(a, b):
        if a > b:
            a, b = b, a
        if a.days > 0:
            raise NotImplementedError
        if b.days == 0:
            assert a == b
        else:
            # The difference is more than a day.
            assert a + datetime_module.timedelta(days=1) == b

    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)


# Generated at 2022-06-20 12:26:02.400466
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4)) == '04:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=4)) == '00:04:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(milliseconds=5)) == '00:00:00.005000'
    assert timedelta_format(datetime_module.timedelta(days=2, milliseconds=5)) == '48:00:00.005000'

# Generated at 2022-06-20 12:26:05.766642
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=3, seconds=46,
                                          microseconds=75900)
    assert timedelta_format(timedelta) == '03:00:46.075900'



# Generated at 2022-06-20 12:26:17.258044
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-20 12:26:27.561342
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(s='1:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse(s='01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse(s='1:2:3.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse(s='1:2:3.456789') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)

# Generated at 2022-06-20 12:26:33.279576
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                              '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == \
                                                             '00:00:00.000123'

# Generated at 2022-06-20 12:26:45.391825
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=23,
                                                      seconds=3,
                                                      microseconds=123456)) == (
                                                          '01:23:03.123456'
                                                      )

    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=23,
                                                      seconds=3)) == (
                                                          '01:23:03.000000'
                                                      )
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=23)) == (
                                                          '01:23:00.000000'
                                                      )
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timed

# Generated at 2022-06-20 12:26:55.202241
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)

# Generated at 2022-06-20 12:26:58.104281
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:20:30.123456') == datetime_module.timedelta(
        hours=1, minutes=20, seconds=30, microseconds=123456
    )

# Generated at 2022-06-20 12:27:07.584759
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('-1:00:00.000000') == datetime_module.timedelta(
        hours=-1)
    assert timedelta_parse('1:01:00.000000') == datetime_module.timedelta(
        hours=1, minutes=1)
    assert timedelta_parse('-1:01:00.000000') == datetime_module.timedelta(
        hours=-1, minutes=-1)

# Generated at 2022-06-20 12:27:11.830941
# Unit test for function timedelta_format
def test_timedelta_format():
    from random import randint
    for _ in range(100):
        hours = randint(0, 100)
        minutes = randint(0, 60)
        seconds = randint(0, 60)
        microseconds = randint(0, 1000000)
        timedelta = datetime_module.timedelta(hours=hours,
                                              minutes=minutes,
                                              seconds=seconds,
                                              microseconds=microseconds)
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:27:19.343804
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:27:28.942350
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(days=1, microseconds=-1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(1, 0, -1)



# Generated at 2022-06-20 12:27:31.807552
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040050') == \
                                          datetime_module.timedelta(hours=1,
                                                                    minutes=2,
                                                                    seconds=3,
                                                                    microseconds=40050)

# Generated at 2022-06-20 12:27:38.503066
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=5))) == datetime_module.timedelta(seconds=5)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=5.5))) == datetime_module.timedelta(seconds=5.5)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=5.125))) == datetime_module.timedelta(seconds=5.125)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=5.12345))) == datetime_module.timedelta(seconds=5.12345)

test_timedelta_parse()

# Generated at 2022-06-20 12:27:44.217334
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=4142)) == \
           '00:00:04.142000'
    assert timedelta_format(datetime_module.timedelta(hours=4,
                                                      minutes=14,
                                                      seconds=2)) == \
           '04:14:02.000000'


# Generated at 2022-06-20 12:27:46.683610
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, hours=2)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:28:06.625788
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
                                                hours=1, minutes=2, seconds=3,
                                                microseconds=456789)



# Generated at 2022-06-20 12:28:17.598001
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)


# Generated at 2022-06-20 12:28:29.765322
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:06:23.000000') == datetime_module.timedelta(
        hours=1, minutes=6, seconds=23
    )
    assert timedelta_parse('1:6:23.000000') == datetime_module.timedelta(
        hours=1, minutes=6, seconds=23
    )
    assert timedelta_parse('01:06:23.450000') == datetime_module.timedelta(
        hours=1, minutes=6, seconds=23, microseconds=450000
    )

# Generated at 2022-06-20 12:28:36.408190
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        '00:00:00.000000'
    ) == datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                   microseconds=0)
    assert timedelta_parse(
        '01:00:00.000000'
    ) == datetime_module.timedelta(hours=1, minutes=0, seconds=0,
                                   microseconds=0)
    assert timedelta_parse(
        '00:01:00.000000'
    ) == datetime_module.timedelta(hours=0, minutes=1, seconds=0,
                                   microseconds=0)

# Generated at 2022-06-20 12:28:46.756218
# Unit test for function timedelta_format
def test_timedelta_format():
    time_isoformat_result = time_isoformat(datetime_module.time(15, 31, 23, 478))
    assert time_isoformat_result == '15:31:23.000478'

    time_isoformat_result = time_isoformat(datetime_module.time(15, 31, 23, 478000))
    assert time_isoformat_result == '15:31:23.478000'

    timedelta = datetime_module.timedelta(days=1, hours=2,
                                          minutes=3, seconds=4,
                                          microseconds=567)

    assert timedelta_format(timedelta) == '50:03:04.00567'
    
    

# Generated at 2022-06-20 12:28:52.897620
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=2, minutes=3, seconds=5,
                                          microseconds=7)

    assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-20 12:29:02.881801
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:20:30.123456') == \
           datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                     microseconds=123456)
    assert timedelta_parse('10:20:30.123') == \
           datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                     microseconds=123000)
    assert timedelta_parse('10:20:30.1') == \
           datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                     microseconds=100000)
    assert timedelta_parse('10:20:30') == \
           datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                     microseconds=0)
   

# Generated at 2022-06-20 12:29:06.430972
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1, microseconds=-1)

test_timedelta_parse()

# Generated at 2022-06-20 12:29:15.570853
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        ('0:00:00.000000', 0),
        ('23:59:59.999999', (23 * 3600 + 59 * 60 + 59) * 1000000 + 99999),
        ('1:00:00.000000', 3600 * 1000000),
        ('1:01:00.000000', 3600 * 1000000 + 60 * 1000000),
        ('1:01:01.000000', 3600 * 1000000 + 60 * 1000000 + 1000000),
    ]
    for string, microseconds in cases:
        assert timedelta_parse(string).microseconds == microseconds

# Generated at 2022-06-20 12:29:26.168492
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    from . import history_database
    small_timedelta = datetime_module.timedelta(days=-1,
                                               microseconds=123456)
    assert timedelta_format(small_timedelta) == '-1 day, 23:59:59.123456'
    big_timedelta = datetime_module.timedelta(days=1,
                                               microseconds=987654)
    assert timedelta_format(big_timedelta) == '1 day, 00:00:00.987654'
    before_epoch = datetime_module.timedelta(days=-1,
                                              microseconds=-123456)
    assert timedelta_format(before_epoch) == '-1 day, 23:59:59.876544'

# Generated at 2022-06-20 12:30:21.282293
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # timedelta_parse() is used in `ice_cube.start_time_remapper` and the
    # test is meant to make sure it's working properly.
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('2:00:00.000000') == datetime_module.timedelta(hours=2)
    assert timedelta_parse('23:00:00.000000') == datetime_module.timedelta(hours=23)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:30:25.451274
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'


# Generated at 2022-06-20 12:30:36.433061
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                               '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                               '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                               '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                               '00:00:00.000001'

# Generated at 2022-06-20 12:30:40.144663
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for i in range(100):
        td = datetime_module.timedelta(seconds=20 * i)
        assert timedelta_parse(timedelta_format(td)) == td

test_timedelta_parse()

# Generated at 2022-06-20 12:30:45.449760
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.1)) == \
       '00:00:00.100000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
       '00:00:00.001000'



# Generated at 2022-06-20 12:30:54.277248
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=24, minutes=35, seconds=45, microseconds=98765))) == \
        datetime_module.timedelta(hours=24, minutes=35, seconds=45,
                                  microseconds=98765)


if sys.version_info[:2] >= (3, 6):
    def get_argspec(func):
        return inspect.getfullargspec(func)
else:
    def get_argspec(func):
        return inspect.getargspec(func)



# Generated at 2022-06-20 12:31:04.492918
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .asserts import assert_equality

    assert_equality(timedelta_parse('0:0:0.000000'),
                    datetime_module.timedelta(0))
    assert_equality(timedelta_parse('0:0:0.000001'),
                    datetime_module.timedelta(0, 1e-6))
    assert_equality(timedelta_parse('0:0:0.000010'),
                    datetime_module.timedelta(0, 1e-5))
    assert_equality(timedelta_parse('0:0:0.001000'),
                    datetime_module.timedelta(0, 1e-3))
    assert_equality(timedelta_parse('0:0:1.000000'),
                    datetime_module.timedelta(0, 1))
    assert_equality

# Generated at 2022-06-20 12:31:07.308755
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, seconds=3,
                                          microseconds=3)
    assert timedelta_format(timedelta) == '03:00:03.000003'



# Generated at 2022-06-20 12:31:18.739650
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('0:0:0.000000') ==
            datetime_module.timedelta(0, 0, 0))
    assert (timedelta_parse('0:0:0.001234') ==
            datetime_module.timedelta(0, 0, 1234))
    assert (timedelta_parse('0:0:0.123456') ==
            datetime_module.timedelta(0, 0, 123456))
    assert (timedelta_parse('0:0:0.123456789') ==
            datetime_module.timedelta(0, 0, 123456))
    assert (timedelta_parse('0:0:1.123456') ==
            datetime_module.timedelta(0, 1, 123456))

# Generated at 2022-06-20 12:31:22.194370
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=10, minutes=5, seconds=2,
                                  microseconds=34)
    ) == '10:05:02.000034'



# Generated at 2022-06-20 12:32:28.835694
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.040050') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40050)
    assert timedelta_parse('0:0:0.000000') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=0)
    assert timedelta_parse('0:0:1.000000') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                     microseconds=0)

if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-20 12:32:38.162829
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:5:5.5') == datetime_module.timedelta(minutes=5,
                                                                   seconds=5,
                                                                   microseconds=500000)

    assert timedelta_parse('0:5:05.50') == datetime_module.timedelta(minutes=5,
                                                                     seconds=5,
                                                                     microseconds=500000)

    assert timedelta_parse('0:5:05.5') == datetime_module.timedelta(minutes=5,
                                                                    seconds=5,
                                                                    microseconds=500000)


# Generated at 2022-06-20 12:32:47.236447
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
        '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(weeks=1)) == \
        '168:00:00.000000'

# Generated at 2022-06-20 12:32:55.143767
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.00') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.0000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.00') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.') == datetime_module.timedelta(0)
    assert timedelta

# Generated at 2022-06-20 12:33:05.627290
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:34.123456') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=34, microseconds=123456)
    assert timedelta_parse('1:23:34.999999') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=34, microseconds=999999)
    assert timedelta_parse('1:23:34.000000') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=34)
    assert timedelta_parse('1:23:34') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=34)

# Generated at 2022-06-20 12:33:08.672666
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'



# Generated at 2022-06-20 12:33:17.425878
# Unit test for function timedelta_format
def test_timedelta_format():
    dt1 = datetime_module.timedelta(days=0,
                                    hours=0,
                                    minutes=0,
                                    seconds=0,
                                    microseconds=0)
    assert timedelta_format(dt1) == '00:00:00.000000'

    dt2 = datetime_module.timedelta(days=1,
                                    hours=0,
                                    minutes=0,
                                    seconds=0,
                                    microseconds=0)
    assert timedelta_format(dt2) == '00:00:00.000000'

    dt3 = datetime_module.timedelta(days=1,
                                    hours=0,
                                    minutes=0,
                                    seconds=0,
                                    microseconds=1)

# Generated at 2022-06-20 12:33:20.474512
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=15,
                                                      seconds=30,
                                                      microseconds=123456)) \
           == '02:15:30.123456'



# Generated at 2022-06-20 12:33:31.253138
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=6)) == '06:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=7)) == '06:07:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=7, seconds=8)) == '06:07:08.000000'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=7, seconds=8, microseconds=99)) == '06:07:08.000099'
    assert timedelta_format(datetime_module.timedelta(hours=6, minutes=7, seconds=8, microseconds=123456)) == '06:07:08.123456'

# Unit

# Generated at 2022-06-20 12:33:40.045241
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:17:39.003000') == datetime_module.timedelta(
        minutes=17, seconds=39, microseconds=3
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module