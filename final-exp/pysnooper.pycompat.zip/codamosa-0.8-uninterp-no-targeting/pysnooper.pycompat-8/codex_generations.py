

# Generated at 2022-06-20 12:25:21.172233
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, microseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, seconds=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, seconds=1, microseconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, minutes=1)

# Generated at 2022-06-20 12:25:29.639172
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:25:36.062695
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=5, hours=14, minutes=3, seconds=11,
                                   microseconds=45)
    assert timedelta_format(td) == '334:03:11.000045'
    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-20 12:25:39.931351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:02:03.456789')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3,
                                                  microseconds=456789)



# Generated at 2022-06-20 12:25:46.184537
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def test(**kwargs):
        assert timedelta_parse(timedelta_format(
            datetime_module.timedelta(**kwargs)
        )) == datetime_module.timedelta(**kwargs)

    test(days=1)
    test(seconds=1)
    test(microseconds=1)
    test(minutes=14, seconds=2, microseconds=1)
    test(hours=14, seconds=2, microseconds=1)
    test(hours=1, minutes=1, seconds=1, microseconds=1)

# Generated at 2022-06-20 12:25:57.921094
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('01:02:03.004005') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4005
    )
    assert timedelta_parse('04:05:06.007008') == datetime_module.timedelta(
        hours=4, minutes=5, seconds=6, microseconds=7008
    )
    with pytest.raises(AssertionError):
        timedelta_parse('-1:02:03.004005')
    with pytest.raises(AssertionError):
        timedelta_parse('.004005')
    with pytest.raises(AssertionError):
        timedelta_parse('01:02:03.004005.')

# Generated at 2022-06-20 12:26:05.652442
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:51.100100') == datetime_module.timedelta(seconds=51, microseconds=100100)
    assert timedelta_parse('1:12:51.100100') == datetime_module.timedelta(hours=1, minutes=12, seconds=51, microseconds=100100)

# Generated at 2022-06-20 12:26:12.625146
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0, 0)
    assert timedelta_parse('1:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('2:03:04.234567') == \
           datetime_module.timedelta(hours=2, minutes=3, seconds=4, microseconds=234567)
    assert timedelta_parse('3:04:05.345678') == \
           datetime_module.timedelta(hours=3, minutes=4, seconds=5, microseconds=345678)
    assert timedelta_parse('4:05:06.456789') == \
           datetime

# Generated at 2022-06-20 12:26:17.969549
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                      seconds=4, microseconds=5)
    assert timedelta_format(timedelta) == '02:03:04.000005'


# Generated at 2022-06-20 12:26:20.251900
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060
    ))) == datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060
    )

# Generated at 2022-06-20 12:26:29.887414
# Unit test for function timedelta_parse
def test_timedelta_parse():
    t = timedelta_parse('23:04:44.124545')
    assert t > datetime_module.timedelta(days=1)
    assert t < datetime_module.timedelta(days=2)

# Generated at 2022-06-20 12:26:31.616740
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '25:00:01.000001'

# Generated at 2022-06-20 12:26:33.235667
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.123456') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=123456)



# Generated at 2022-06-20 12:26:45.394427
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:05.123456') == datetime_module.timedelta(
        seconds=5, microseconds=123456)
    assert timedelta_parse('00:00:05.123456') == datetime_module.timedelta(
        seconds=5, microseconds=123456)
    assert timedelta_parse('00:05:05.123456') == datetime_module.timedelta(
        minutes=5, seconds=5, microseconds=123456)
    assert timedelta_parse('05:05:05.123456') == datetime_module.timedelta(
        hours=5, minutes=5, seconds=5, microseconds=123456)

# Generated at 2022-06-20 12:26:55.472069
# Unit test for function timedelta_format
def test_timedelta_format():
    def assertEqual(a, b):
        assert a == b, '%s != %s' % (a, b)
    assertEqual(timedelta_format(datetime_module.timedelta(0)),
                '00:00:00.000000')
    assertEqual(timedelta_format(datetime_module.timedelta(seconds=1)),
                '00:00:01.000000')
    assertEqual(timedelta_format(datetime_module.timedelta(seconds=60)),
                '00:01:00.000000')
    assertEqual(timedelta_format(datetime_module.timedelta(hours=1)),
                '01:00:00.000000')



# Generated at 2022-06-20 12:27:05.348380
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=0)
    ) == '00:00:00.000000'

    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=0, seconds=0,
                                  microseconds=0)
    ) == '01:00:00.000000'

    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=1, seconds=0,
                                  microseconds=0)
    ) == '00:01:00.000000'


# Generated at 2022-06-20 12:27:08.329068
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2,
                                                      seconds=2030,
                                                      microseconds=123456)) == \
           '50:30:30.123456'


# Generated at 2022-06-20 12:27:13.552615
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

# Generated at 2022-06-20 12:27:24.633115
# Unit test for function timedelta_format
def test_timedelta_format():
    t1 = datetime_module.time(0, 0, 0, 0)
    t2 = datetime_module.time(1, 2, 3, 4)
    t3 = datetime_module.time(12, 34, 56, 789)
    t4 = datetime_module.time(23, 59, 59, 999999)

    assert time_isoformat(t1) == '00:00:00.000000'
    assert time_isoformat(t2) == '01:02:03.000004'
    assert time_isoformat(t3) == '12:34:56.000789'
    assert time_isoformat(t4) == '23:59:59.999999'

    timedelta1 = datetime_module.timedelta(days=1)
    timedelta2 = datetime_module.tim

# Generated at 2022-06-20 12:27:32.973038
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("1:1:1.000001") \
           == datetime_module.timedelta(0, 3661, 1)
    assert timedelta_parse("0:0:0.000001") \
           == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse("0:0:0.000010") \
           == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse("0:0:0.000100") \
           == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse("0:0:0.001000") \
           == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse("0:0:0.010000") \
           == datetime

# Generated at 2022-06-20 12:27:58.155783
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == timedelta_module.timedelta(0)

    assert timedelta_parse('00:00:00.000001') == timedelta_module.timedelta(
        microseconds=1
    )

    assert timedelta_parse('00:00:00.000010') == timedelta_module.timedelta(
        microseconds=10
    )

    assert timedelta_parse('00:00:00.000100') == timedelta_module.timedelta(
        microseconds=100
    )

    assert timedelta_parse('00:00:00.001000') == timedelta_module.timedelta(
        microseconds=1000
    )


# Generated at 2022-06-20 12:28:00.737722
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=12, minutes=23, seconds=34, microseconds=456789)) == \
           '12:23:34.0456789'



# Generated at 2022-06-20 12:28:04.747628
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5_678)
    assert timedelta_format(timedelta) == '02:03:04.005678'



# Generated at 2022-06-20 12:28:15.952346
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=28)) == \
           '00:00:00.000028'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=5)) == \
           '00:00:01.000005'

# Generated at 2022-06-20 12:28:22.773614
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = time_isoformat(datetime_module.time(1, 2, 3, 456))
    assert time.startswith('01:02:03.00')
    timedelta = timedelta_parse(time)
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                  microseconds=456)
    time = time_isoformat(datetime_module.time(1, 2, 3, 0))
    assert time.startswith('01:02:03.000000')
    timedelta = timedelta_parse(time)
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2, seconds=3)

# Generated at 2022-06-20 12:28:32.885259
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.max) == \
                                                              '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta.min) == \
                                                              '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5)) == \
                                                              '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5)) == \
                                                              '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == \
                                                              '00:00:05.000000'

# Generated at 2022-06-20 12:28:39.185673
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)) == \
        '01:02:03.000456'
    assert timedelta_format(datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060)) == \
        '10:20:30.405060'



# Generated at 2022-06-20 12:28:43.185500
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

test_timedelta_parse()

# Generated at 2022-06-20 12:28:47.427413
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1,
                                          minutes=23,
                                          seconds=45,
                                          microseconds=67890)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-20 12:28:55.134049
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(microseconds=1000000),
                      datetime_module.timedelta(seconds=1, microseconds=1),
                      datetime_module.timedelta(seconds=3, minutes=3,
                                                microseconds=1),
                      datetime_module.timedelta(days=1)):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-20 12:29:37.901722
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )


if PY3:
    from importlib import reload
else:
    from imp import reload



# Generated at 2022-06-20 12:29:48.472737
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=60)) == '01:00:00.000000'

# Generated at 2022-06-20 12:29:54.835624
# Unit test for function timedelta_format
def test_timedelta_format():
    x = timedelta_format(datetime_module.timedelta(microseconds=5))
    assert x == '00:00:00.000005'

    x = timedelta_format(datetime_module.timedelta(seconds=5, microseconds=5))
    assert x == '00:00:05.000005'

    x = timedelta_format(datetime_module.timedelta(minutes=5, seconds=5,
                                                   microseconds=5))
    assert x == '00:05:05.000005'

    x = timedelta_format(datetime_module.timedelta(hours=5, minutes=5,
                                                   seconds=5, microseconds=5))
    assert x == '05:05:05.000005'


# Generated at 2022-06-20 12:29:58.247547
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'

# Generated at 2022-06-20 12:30:03.825674
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(11, 35, 47))
    assert time == '11:35:47.000000'

    timedelta = datetime_module.timedelta(hours=37, minutes=32, seconds=28,
                                          microseconds=278329)
    result = timedelta_format(timedelta)
    assert result == '37:32:28.278329'



# Generated at 2022-06-20 12:30:10.807914
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in 0, 1, 9, 23:
        for j in 0, 1, 45, 59:
            for k in 0, 1, 30, 59:
                for l in 0, 1, 999997, 999999:
                    td = datetime_module.timedelta(hours=i, minutes=j,
                                                   seconds=k,
                                                   microseconds=l)
                    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-20 12:30:19.910651
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:30')) == '01:30:00.000000'
    assert timedelta_format(timedelta_parse('1:30.5')) == '01:30:00.500000'
    assert timedelta_format(timedelta_parse('1:30.500000')) == '01:30:00.500000'
    assert timedelta_format(timedelta_parse('1:30.500001')) == '01:30:00.500001'
    assert timedelta_format(timedelta_parse('1:30.512345')) == '01:30:00.512345'
    assert timedelta_format(timedelta_parse('1:30:1')) == '01:30:01.000000'
    assert timedelta

# Generated at 2022-06-20 12:30:30.165886
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('-1:0:0.000000') == datetime_module.timedelta(hours=-1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:-1:0.000000') == datetime_module.timedelta(minutes=-1)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:-1.000000') == datetime

# Generated at 2022-06-20 12:30:40.053647
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23)) == '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59)) == '23:59:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59)) == '23:59:59.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == '23:59:59.999999'



# Generated at 2022-06-20 12:30:46.522966
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_format_round_trip(td):
        assert timedelta_parse(timedelta_format(td)) == td
    assert_format_round_trip(datetime_module.timedelta(1))
    assert_format_round_trip(datetime_module.timedelta(1, 1))
    assert_format_round_trip(datetime_module.timedelta(1, 1, 1))
    assert_format_round_trip(datetime_module.timedelta(0, 1))
    assert_format_round_trip(datetime_module.timedelta(0, 0, 1))

# Generated at 2022-06-20 12:31:38.165879
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=5, hours=3, minutes=10,
                                          seconds=20, microseconds=123456)
    assert timedelta_format(timedelta) == '03:10:20.123456'



# Generated at 2022-06-20 12:31:48.157203
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=5))) == datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=5)

# Generated at 2022-06-20 12:31:56.570412
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('00:00:01.100000') == datetime_module.timedelta(0, 1, 100000)
    assert timedelta_parse('00:01:00.100000') == datetime_module.timedelta(0, 60, 100000)

# Generated at 2022-06-20 12:32:01.828180
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
                                                          '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=52,
                                                      seconds=12,
                                                      microseconds=907645)) == \
                                                          '23:52:12.907645'



# Generated at 2022-06-20 12:32:09.717797
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )
    assert timedelta_parse('123:59:59.999999') == datetime_module.timedelta(
        days=5,
        hours=3, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('123:59:59.999999') == timedelta_parse(
        '5:3:59:59.999999'
    )



# Generated at 2022-06-20 12:32:16.947822
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (datetime_module.timedelta(days=2),
                      datetime_module.timedelta(hours=2),
                      datetime_module.timedelta(seconds=3.14),
                      datetime_module.timedelta(microseconds=123),
                      datetime_module.timedelta(0, 3, 14)):
        result = timedelta_parse(timedelta_format(timedelta))
        assert timedelta == result


if PY3:
    class_types = (type,)
else:
    class_types = (type, types.ClassType)

# Generated at 2022-06-20 12:32:22.359611
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for days in range(1, 7):
        for hours in range(0, 24):
            for minutes in range(0, 60):
                for seconds in range(0, 60):
                    for microseconds in range(0, 1000000, 7):
                        timedelta = \
                            datetime_module.timedelta(days=days,
                                                      hours=hours,
                                                      minutes=minutes,
                                                      seconds=seconds,
                                                      microseconds=microseconds)

                        time = \
                            datetime_module.datetime(year=2000, month=1, day=1) + \
                            timedelta

                        s = time_isoformat(time, timespec='microseconds')
                        timedelta2 = timedelta_parse(s)
                        assert timedelta == timedelta2






# Generated at 2022-06-20 12:32:27.366648
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=2.5)) == '00:00:02.500000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1,
                                                      microseconds=1)) ==\
                                                      '01:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=-2.5)) == '-00:00:02.500000'



# Generated at 2022-06-20 12:32:32.408924
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=13, minutes=37, seconds=5, microseconds=6789
    ))) == datetime_module.timedelta(
        hours=13, minutes=37, seconds=5, microseconds=6789
    )


# Generated at 2022-06-20 12:32:35.314365
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        seconds=3662, microseconds=223432
    )) == '01:01:02.223432'

test_timedelta_format()



# Generated at 2022-06-20 12:34:46.414427
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
        microseconds=10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta

# Generated at 2022-06-20 12:34:54.036876
# Unit test for function timedelta_parse
def test_timedelta_parse():
    result = timedelta_parse('1:02:03.000456')
    assert result == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                               microseconds=456)

    assert timedelta_parse('0:00:00.1') == datetime_module.timedelta(0, 0, 0, 100)
    assert timedelta_parse('0:00:00.01') == datetime_module.timedelta(0, 0, 0, 10)
    assert timedelta_parse('0:00:00.001') == datetime_module.timedelta(0, 0, 0, 1)
    assert timedelta_parse('0:00:01') == datetime_module.timedelta(0, 0, 1)

# Generated at 2022-06-20 12:35:03.748287
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Test that `timedelta_parse` is the inverse of `timedelta_format`.
    '''
    for hours in range(100):
        for minutes in range(60):
            for seconds in range(60):
                for microseconds in range(10 ** 6):
                    timedelta = datetime_module.timedelta(
                        hours=hours, minutes=minutes,
                        seconds=seconds, microseconds=microseconds
                    )
                    if timedelta:
                        s = timedelta_format(timedelta)
                        assert s.startswith('0')
                    else:
                        s = '0:00:00.000000'
                    assert timedelta == timedelta_parse(s)