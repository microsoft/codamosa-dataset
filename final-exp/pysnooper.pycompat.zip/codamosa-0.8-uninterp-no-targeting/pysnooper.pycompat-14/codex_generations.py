

# Generated at 2022-06-20 12:25:08.963665
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                      microseconds=3)) == \
                            '24:00:02.000003'



# Generated at 2022-06-20 12:25:21.138273
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:11:11.111111') == datetime_module.timedelta(
        hours=1, minutes=11, seconds=11, microseconds=111111
    )
    assert timedelta_parse('1:11:11') == datetime_module.timedelta(
        hours=1, minutes=11, seconds=11
    )
    assert timedelta_parse('1:11') == datetime_module.timedelta(
        hours=1, minutes=11
    )
    assert timedelta_parse('1') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('0') == datetime_module.timedelta(
        hours=0
    )
    assert timedelta_parse('0:0') == datetime_module.timedelta

# Generated at 2022-06-20 12:25:25.460814
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=7, hours=6,
                                                      minutes=5, seconds=4,
                                                      microseconds=3)) == \
            "168:05:04.000003"
    assert timedelta_format(datetime_module.timedelta(days=7, hours=6,
                                                      minutes=5, seconds=4,
                                                      microseconds=3000)) == \
            "168:05:04.003000"
    assert timedelta_format(datetime_module.timedelta(days=7, hours=6,
                                                      minutes=5, seconds=4,
                                                      microseconds=3000000)) == \
            "168:05:04.300000"



# Generated at 2022-06-20 12:25:30.423243
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Note that `timedelta` (by itself) is a built-in type.
    assert timedelta_parse(
        timedelta_format(
            datetime_module.timedelta(hours=5, minutes=30, seconds=45)
        )
    ) == datetime_module.timedelta(hours=5, minutes=30, seconds=45)
    assert timedelta_parse(
        timedelta_format(
            datetime_module.timedelta(hours=5, minutes=30, microseconds=45)
        )
    ) == datetime_module.timedelta(hours=5, minutes=30, microseconds=45)



# Generated at 2022-06-20 12:25:37.764675
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hour=2, minute=3, second=5, microsecond=100100
    )) == '02:03:05.100100'
    assert timedelta_format(datetime_module.timedelta(-10)) == '-00:00:10.000000'


# Generated at 2022-06-20 12:25:46.654392
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:25:58.366490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.0') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.0') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.0') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.0') == datetime_module.timedelta(1)
    assert timedelta_parse('01:10:11.010203') == datetime_module.timedelta(
        1, 3661, 10203
    )


# Generated at 2022-06-20 12:26:02.664210
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=45, seconds=1,
                                          microseconds=1234)
    assert timedelta_format(timedelta) == '02:45:01.001234'



# Generated at 2022-06-20 12:26:08.233845
# Unit test for function timedelta_format
def test_timedelta_format():
    for td in (datetime_module.timedelta(hours=5),
               datetime_module.timedelta(hours=5, minutes=3, seconds=67,
                                         microseconds=8234),
               datetime_module.timedelta(days=6, hours=20, minutes=3, seconds=67,
                                         microseconds=8234),):
        assert timedelta_format(td) == timedelta_parse(timedelta_format(td))

# Generated at 2022-06-20 12:26:20.665210
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('01:02:03.001002') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=100)
    assert timedelta_parse('01:02:03.000001') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=1)
    assert timedelta_parse('01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse

# Generated at 2022-06-20 12:26:36.476720
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = [
        (
            datetime_module.timedelta(days=5, hours=4, minutes=3, seconds=2,
                                      microseconds=1),
            '05:04:03:02.000001'
        ),
        (
            datetime_module.timedelta(days=5, hours=4, minutes=3, seconds=2),
            '05:04:03:02.000000'
        ),
        (
            datetime_module.timedelta(seconds=1),
            '00:00:01:00.000000'
        ),
        (
            datetime_module.timedelta(microseconds=1),
            '00:00:00:00.000001'
        ),
    ]
    for input, result in cases:
        assert timedelta_format(input) == result

# Generated at 2022-06-20 12:26:48.198993
# Unit test for function timedelta_format
def test_timedelta_format():

    def check(timedelta, expected_string):
        assert timedelta_format(timedelta) == expected_string
        assert timedelta_parse(expected_string) == timedelta

    check(datetime_module.timedelta(seconds=1), '00:00:01.000000')
    check(datetime_module.timedelta(seconds=3, microseconds=7),
          '00:00:03.000007')
    check(datetime_module.timedelta(seconds=3, milliseconds=7),
          '00:00:03.007000')
    check(datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=5),
          '02:03:04.000005')

# Generated at 2022-06-20 12:26:56.330229
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:27:06.299825
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.040000') == \
       datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                 microseconds=40000)
    assert timedelta_parse('1:02:03.004001') == \
       datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                 microseconds=40001)
    assert timedelta_parse('1:02:03.004010') == \
       datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                 microseconds=40010)

# Generated at 2022-06-20 12:27:12.591895
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=54321)
    ) == '00:00:00.054321'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == \
           '00:03:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=2, microseconds=123456)
    ) == '02:00:00.123456'

# Generated at 2022-06-20 12:27:14.954618
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(hours=11, minutes=59, seconds=59,
                                   microseconds=999999)
    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-20 12:27:26.265197
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('03:04:05.678912')) == \
           '03:04:05.678912'

if hasattr(datetime_module, 'timezone'):
    timezone_string = 'timezone'
    UTC = datetime_module.timezone.utc
    def time_to_utc(time):
        return datetime_module.datetime(1, 1, 1, time.hour, time.minute,
                                        time.second, time.microsecond,
                                        UTC)
else:
    timezone_string = 'tzinfo'
    UTC = None

# Generated at 2022-06-20 12:27:33.926388
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8)) == \
           '08:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      minutes=10)) == \
           '08:10:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      seconds=10)) == \
           '08:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      microseconds=10)) == \
           '08:00:00.000010'

# Generated at 2022-06-20 12:27:45.559347
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.123') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123000)
    assert timedelta_parse('1:2:3') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)



# Generated at 2022-06-20 12:27:56.060090
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import testing

    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=1
    ))) == datetime_module.timedelta(microseconds=1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, microseconds=1
    ))) == datetime_module.timedelta(days=1, microseconds=1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=1, microseconds=1, minutes=1, seconds=1
    ))) == datetime_module.timedelta

# Generated at 2022-06-20 12:28:18.453613
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59.999999') == \
           datetime_module.timedelta(days=1) - datetime_module.timedelta(
               microseconds=1)
    assert timedelta_parse('24:00:00.000000') == \
           datetime_module.timedelta(days=1)
    assert timedelta_parse('111:59:59.999999') == \
           datetime_module.timedelta(days=5, hours=7) - datetime_module.timedelta(
               microseconds=1)

# Generated at 2022-06-20 12:28:25.199407
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=1234)) == \
              '01:02:03.001234'


# Generated at 2022-06-20 12:28:34.175571
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:02:03.04')) == '01:02:03.040000'
    assert timedelta_format(timedelta_parse('1:02:03')) == '01:02:03.000000'
    assert timedelta_format(timedelta_parse('1:02:03.04:56:07.89')) == '01:02:03.040000'
    assert timedelta_format(timedelta_parse('.1:02:03.04:56:07.89')) == '00:02:03.040000'
    assert timedelta_format(timedelta_parse('1:02:03.04:56:07.')) == '01:02:03.040000'

# Generated at 2022-06-20 12:28:36.979279
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('12:34:56.123456')) == \
           '12:34:56.123456'

# Generated at 2022-06-20 12:28:46.715342
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == '-01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=45)) == '01:02:03.000045'
    assert timedelta_format(datetime_module.timedelta(hours=-1, minutes=-2,
                                                      seconds=-3,
                                                      microseconds=-45)) == '-01:02:03.000045'



# Generated at 2022-06-20 12:28:59.012373
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0,
                                                                           0, 1)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(0,
                                                                           0, 999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0,
                                                                           1)
    assert timedelta_parse('00:00:59.999999') == datetime_module.timedelta(0,
                                                                           59, 99999)

# Generated at 2022-06-20 12:29:07.836236
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 0)) == \
                                                              '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1, 0)) == \
                                                             '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0, 0)) == \
                                                             '00:01:00.000000'

# Generated at 2022-06-20 12:29:18.120147
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'



# Generated at 2022-06-20 12:29:20.393596
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=5)) == \
           '00:00:00.000000'



# Generated at 2022-06-20 12:29:30.361919
# Unit test for function timedelta_parse
def test_timedelta_parse():
    f = timedelta_parse
    assert f('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert f('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert f('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert f('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert f('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert f('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:29:49.810262
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )

test_timedelta_parse()



# Generated at 2022-06-20 12:29:56.856298
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=2))) == datetime_module.timedelta(hours=2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=-3))) == datetime_module.timedelta(hours=-3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-20 12:30:07.506352
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == (
        '00:00:01.000001'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1,
                                                      microseconds=1)) == (
        '00:01:00.000001'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=1)) == (
        '01:00:00.000001'
    )

# Generated at 2022-06-20 12:30:11.113143
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.043000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=43000)

# Generated at 2022-06-20 12:30:19.593374
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                 '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                 '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                 '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                 '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                 '24:00:00.000000'


# Generated at 2022-06-20 12:30:21.982546
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )



# Generated at 2022-06-20 12:30:32.911144
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(0)
    )) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=5)
    )) == datetime_module.timedelta(hours=5)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=-5)
    )) == datetime_module.timedelta(hours=-5)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=9)
    )) == datetime_module.timedelta(microseconds=9)

# Generated at 2022-06-20 12:30:35.969155
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=123456)) == '07:08:09.123456'


# Generated at 2022-06-20 12:30:45.486887
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('1:02:00.000000') == datetime_module.timedelta(
        hours=1, minutes=2
    )
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:00.123456') == datetime_module

# Generated at 2022-06-20 12:30:55.584407
# Unit test for function timedelta_parse
def test_timedelta_parse():
    times = (
        (1, 1, 1, 1000), # Normal
        (1, 1, 1, 0), # No microseconds
        (1, 1, 0, 1000), # No seconds, just microseconds
        (1, 1, 0, 0), # No seconds or microseconds
        (0, 0, 0, 0), # No time at all
    )
    for hours, minutes, seconds, microseconds in times:
        timedelta = datetime_module.timedelta(hours=hours, minutes=minutes,
                                              seconds=seconds,
                                              microseconds=microseconds)
        assert timedelta_format(timedelta) == timedelta_parse(timedelta)


if sys.version_info[:2] >= (3, 7):
    def get_total_seconds(timedelta):
        return timedelta

# Generated at 2022-06-20 12:31:22.876984
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=22, minutes=33, seconds=44,
                                  microseconds=55555)
    ) == '22:33:44.055555'



# Generated at 2022-06-20 12:31:31.410103
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == (
        datetime_module.timedelta(microseconds=1)
    )
    assert timedelta_parse('00:00:00.000012') == (
        datetime_module.timedelta(microseconds=12)
    )
    assert timedelta_parse('00:00:00.000123') == (
        datetime_module.timedelta(microseconds=123)
    )
    assert timedelta_parse('00:00:00.001234') == (
        datetime_module.timedelta(microseconds=1234)
    )

# Generated at 2022-06-20 12:31:38.587907
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=None, minutes=44,
                                               seconds=21,
                                               microseconds=749492)) == \
        '00:44:21.074949'
    timedelta_format(datetime_module.timedelta(hours=11, minutes=22, seconds=1,
                                               microseconds=0)) == \
        '11:22:01.000000'



# Generated at 2022-06-20 12:31:48.405945
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''Test function `timedelta_parse`.'''
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901
    )
    assert timedelta_parse('1:23:45.678') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678000
    )
    assert timedelta_parse('1:23:45') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45
    )
    assert timedelta_parse('1:23') == datetime_module.timedelta(
        minutes=83
    )

# Generated at 2022-06-20 12:31:56.817651
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(12345))) == (
        datetime_module.timedelta(12345))
    assert timedelta_parse('-2345:45:58.204') == (
        datetime_module.timedelta(hours=-2345, minutes=-45, seconds=-58,
                                  microseconds=-204))
    assert timedelta_parse('-2345:45:58:204') == (
        datetime_module.timedelta(hours=-2345, minutes=-45, seconds=-58,
                                  microseconds=-204))
    assert timedelta_parse('-2345:45:58') == (
        datetime_module.timedelta(hours=-2345, minutes=-45, seconds=-58))

# Generated at 2022-06-20 12:32:00.521829
# Unit test for function timedelta_format
def test_timedelta_format():
    f = timedelta_format
    assert f(datetime_module.timedelta(hours=15, minutes=30, seconds=16,
                                       microseconds=321654)) == \
           '15:30:16.321654'



# Generated at 2022-06-20 12:32:03.007382
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:1:2.123456') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=123456
    )


# Generated at 2022-06-20 12:32:06.853929
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
                            hours=5,
                            minutes=6,
                            seconds=7,
                            microseconds=9000)) == '05:06:07.000090'



# Generated at 2022-06-20 12:32:16.494481
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == '00:00:00.010000'
    assert timedelta_

# Generated at 2022-06-20 12:32:21.709242
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                             datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=5, hours=6, minutes=7, seconds=8, microseconds=9
    ))) == datetime_module.timedelta(days=5, hours=6, minutes=7, seconds=8,
                                     microseconds=9)

# Generated at 2022-06-20 12:33:32.414732
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:33:38.995933
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse('1:2:3.00004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse('-1:2:3.4') == datetime_module.timedelta(
        hours=-1, minutes=2, seconds=3, microseconds=4)

# Generated at 2022-06-20 12:33:41.955500
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=56789)) == \
                                                          '02:03:04.00567'


# Generated at 2022-06-20 12:33:50.400052
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = [
        (datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456789),
         '01:02:03.456789'),
        (datetime_module.timedelta(hours=45, minutes=56, seconds=7,
                                   microseconds=89012),
         '45:56:07.890120'),
        (datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                   microseconds=0),
         '00:00:00.000000'),
        (datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                   microseconds=1),
         '00:00:00.000001'),
    ]

# Generated at 2022-06-20 12:33:54.291599
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_helpers import assert_equal

    assert_equal(timedelta_parse('0:00:00.000000'), datetime_module.timedelta(0))

# Generated at 2022-06-20 12:34:02.768789
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == \
                                                          '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(days=0, seconds=1,
                                                      microseconds=2)) == \
                                                          '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1,
                                                      microseconds=2)) == \
                                                          '24:00:01.000002'

# Generated at 2022-06-20 12:34:10.204321
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)

    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, 1, 1)

    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(3723, 4)

test_timedelta_parse()

# Generated at 2022-06-20 12:34:18.646402
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-20 12:34:21.360446
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import test_timedelta_format
    for timedelta in test_timedelta_format.timedeltas:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))


# Generated at 2022-06-20 12:34:27.937656
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        '001:00:00:000000'
    ) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(
        '000:00:00:000000'
    ) == datetime_module.timedelta(seconds=0)
    assert timedelta_parse(
        '000:00:59:000000'
    ) == datetime_module.timedelta(seconds=59)
    assert timedelta_parse(
        '000:01:00:000000'
    ) == datetime_module.timedelta(minutes=1)

