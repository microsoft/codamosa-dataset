

# Generated at 2022-06-20 12:25:22.573627
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == \
           '-01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'


# Generated at 2022-06-20 12:25:25.210663
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-20 12:25:32.454070
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=42, microseconds=12345)) == '42:00:00.012345'



# Generated at 2022-06-20 12:25:38.914645
# Unit test for function timedelta_format
def test_timedelta_format():
    # I'm the kind of person that has tests for tests.
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
                           '02:03:04.000005'



# Generated at 2022-06-20 12:25:47.040864
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3, seconds=11)) == \
           '00:00:11.000000'
    assert timedelta_format(datetime_module.timedelta(days=3,
                                                      microseconds=100100)) == \
           '00:00:00.100100'
    assert timedelta_format(datetime_module.timedelta(days=3, hours=5,
                                                      microseconds=100100)) == \
           '05:00:00.100100'

# Generated at 2022-06-20 12:25:51.787688
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=33,
                                                      seconds=22,
                                                      microseconds=478)) == \
           '02:33:22.000478'

# Generated at 2022-06-20 12:26:00.709440
# Unit test for function timedelta_format
def test_timedelta_format():
    for delta, expected_string in (
        (datetime_module.timedelta(hours=5), '05:00:00.000000'),
        (datetime_module.timedelta(minutes=5), '00:05:00.000000'),
        (datetime_module.timedelta(seconds=5), '00:00:05.000000'),
        (datetime_module.timedelta(microseconds=5), '00:00:00.000005'),
        (datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                   microseconds=5),
         '02:03:04.000005'),
    ):
        assert timedelta_format(delta) == expected_string



# Generated at 2022-06-20 12:26:08.973615
# Unit test for function timedelta_format
def test_timedelta_format():
    """Test the `timedelta_format` function."""
    tests = [
        (datetime_module.timedelta(days=1), '00:00:00.000000'),
        (datetime_module.timedelta(seconds=1, milliseconds=2,
                                   microseconds=3), '00:00:01.002003'),
        (datetime_module.timedelta(hours=10, seconds=1, milliseconds=2,
                                   microseconds=3), '10:00:01.002003'),
    ]
    for timedelta, expected in tests:
        assert timedelta_format(timedelta) == expected
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-20 12:26:15.513140
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=7,
                                                                      minutes=2,
                                                                      seconds=30,
                                                                      microseconds=9))) == datetime_module.timedelta(hours=7,
                                                                                                                   minutes=2,
                                                                                                                   seconds=30,
                                                                                                                   microseconds=9)

# Generated at 2022-06-20 12:26:27.517748
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    Test the `timedelta_format` function by checking that it returns a string
    which is the same thing as parsing.
    '''
    import pytest
    assert timedelta_format(datetime_module.timedelta(
        days=1,
        hours=23,
        minutes=59,
        seconds=58,
        microseconds=123456
    )) == '23:59:58.123456'
    assert timedelta_format(datetime_module.timedelta(
        hours=23,
        minutes=59,
        seconds=58,
        microseconds=123456
    )) == '23:59:58.123456'

# Generated at 2022-06-20 12:26:48.124876
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00.000000') == \
           datetime_module.timedelta(hours=1, minutes=0, seconds=0,
                                     microseconds=0)
    assert timedelta_parse('0:00:00.000000') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=0)
    assert timedelta_parse('0:00:00.000001') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                     microseconds=1)
    assert timedelta_parse('0:00:59.999999') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=59,
                                     microseconds=999_999)

# Generated at 2022-06-20 12:26:55.838453
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('06:07:08.090123') == datetime_module.timedelta(hours=6, minutes=7, seconds=8, microseconds=90123)
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('1:2') == datetime_module.timedelta(hours=1, minutes=2)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)

# Generated at 2022-06-20 12:27:05.681776
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:27:06.822025
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:03:04.123456') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=123456
    )



# Generated at 2022-06-20 12:27:11.167403
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=24)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=24 + 3,
                                                      minutes=12,
                                                      seconds=30,
                                                      microseconds=120000)) == \
           '03:12:30.120000'



# Generated at 2022-06-20 12:27:18.785829
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_conversion_is_correct(td):
        td_string = timedelta_format(td)
        assert td == timedelta_parse(td_string)
    assert_conversion_is_correct(datetime_module.timedelta(seconds=1))
    assert_conversion_is_correct(datetime_module.timedelta(microseconds=123))
    assert_conversion_is_correct(datetime_module.timedelta(days=1))
    assert_conversion_is_correct(datetime_module.timedelta(minutes=1,
                                                           microseconds=123))
    assert_conversion_is_correct(datetime_module.timedelta(hours=1,
                                                           microseconds=123))

# Generated at 2022-06-20 12:27:22.327253
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                                                                                                                                                                                       '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                                                                                                                                                                                       '01:02:03.000004'


# Generated at 2022-06-20 12:27:26.003450
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )


# Generated at 2022-06-20 12:27:29.193182
# Unit test for function timedelta_parse
def test_timedelta_parse():
    d = datetime_module.timedelta(days=37, hours=2, minutes=13,
                                  seconds=15, microseconds=123456)
    assert timedelta_parse(timedelta_format(d)) == d

# Generated at 2022-06-20 12:27:34.457683
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_parse('1:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_parse('01:02:03.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456000
    )

# Generated at 2022-06-20 12:28:02.391361
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.000004')) == \
                                                        '01:02:03.000004'
    assert timedelta_format(timedelta_parse('01:02:03.000004000')) == \
                                                        '01:02:03.000004'
    assert timedelta_format(timedelta_parse('01:02:03.0000040000')) == \
                                                        '01:02:03.000004'
    assert timedelta_format(timedelta_parse('01:02:03.000004000')) == \
                                                        '01:02:03.000004'

# Generated at 2022-06-20 12:28:14.354585
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse("00:00:00.000010") == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse("00:00:00.000100") == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse("00:00:00.001000") == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse("00:00:00.010000") == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-20 12:28:16.961752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:04:05.006000') == (
        datetime_module.timedelta(hours=3, minutes=4, seconds=5, microseconds=6)
    )

# Generated at 2022-06-20 12:28:24.238820
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_python_toolbox import _timedelta_format_test
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=1)) == \
           '00:00:01.000000'

# Generated at 2022-06-20 12:28:33.633120
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=0, microseconds=1))) == datetime_module.timedelta(seconds=0, microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, seconds=2, microseconds=3))) == datetime_module.timedelta(hours=1, seconds=2, microseconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=666, hours=1, seconds=2, microseconds=3))) == datetime_module.timedelta

# Generated at 2022-06-20 12:28:45.285829
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(
        seconds=1, microseconds=999999
    )
    assert timedelta_parse('00:01:00.000001') == datetime_module.timedelta(
        minutes=1, microseconds=1
    )
    assert timedelta_

# Generated at 2022-06-20 12:28:51.547209
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                          '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.800000')) == \
                                                          '00:00:00.800000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == \
                                                          '00:00:01.000000'
    assert timedelta_format(timedelta_parse('00:01:00.000000')) == \
                                                          '00:01:00.000000'
    assert timedelta_format(timedelta_parse('01:00:00.000000')) == \
                                                          '01:00:00.000000'


#

# Generated at 2022-06-20 12:29:01.630426
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-20 12:29:09.549103
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 2, 3, 4)) == \
           '24:00:02.000003'

    assert timedelta_format(
        datetime_module.timedelta(microseconds=1)
    ) == '00:00:00.000001'

    assert timedelta_format(
        datetime_module.timedelta(microseconds=999)
    ) == '00:00:00.000999'

    assert timedelta_format(
        datetime_module.timedelta(microseconds=1000)
    ) == '00:00:00.001000'


# Generated at 2022-06-20 12:29:15.349187
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(timedelta) == '00:00:00.000001'
    timedelta = datetime_module.timedelta(days=1, seconds=1)
    assert timedelta_format(timedelta) == '24:00:01.000000'



# Generated at 2022-06-20 12:30:16.530682
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == \
           '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=123)) == \
           '00:00:01.000123'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1, microseconds=123)) == \
           '01:00:01.000123'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1, microseconds=1)) == \
           '01:00:01.000001'

# Generated at 2022-06-20 12:30:21.702948
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(11, 22, 33, 434545)
    assert time_isoformat(time) == '11:22:33.043455'
    # test also timedelta
    assert timedelta_format(datetime_module.timedelta(hours=11, minutes=22,
                                             seconds=33, microseconds=434545)) \
           == '11:22:33.043455'



# Generated at 2022-06-20 12:30:32.639721
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=0)
    ) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'

# Generated at 2022-06-20 12:30:35.793289
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )) == '24:00:00.000000'



# Generated at 2022-06-20 12:30:45.372471
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789012
    )) == (
        '12:34:56.789012'
    )
    assert timedelta_format(datetime_module.timedelta(
        microseconds=789012
    )) == (
        '00:00:00.789012'
    )
    assert timedelta_format(datetime_module.timedelta(
        hours=12, microseconds=789012
    )) == (
        '12:00:00.789012'
    )
    assert timedelta_format(datetime_module.timedelta(
        seconds=56, microseconds=789012
    )) == (
        '00:00:56.789012'
    )


# Unit

# Generated at 2022-06-20 12:30:55.521091
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=1)) == \
                                                    '48:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                    '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                    '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=100)) == \
                                                    '00:00:01.000100'
    assert timedelta

# Generated at 2022-06-20 12:31:05.520347
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                             '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == \
                             '-00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
                             '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1, seconds=1)) == \
                             '-00:00:01.000000'

# Generated at 2022-06-20 12:31:16.161627
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_ok(td):
        s0 = timedelta_format(td)
        td1 = timedelta_parse(s0)
        s1 = timedelta_format(td1)
        assert s0 == s1
        assert td == td1
    assert_ok(datetime_module.timedelta())
    assert_ok(datetime_module.timedelta(seconds=1))
    assert_ok(datetime_module.timedelta(seconds=123))
    assert_ok(datetime_module.timedelta(microseconds=1))
    assert_ok(datetime_module.timedelta(microseconds=123))
    assert_ok(datetime_module.timedelta(microseconds=123456))

# Generated at 2022-06-20 12:31:20.055263
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
           '02:03:04.000005'



# Generated at 2022-06-20 12:31:24.551936
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=5, minutes=13, seconds=24, microseconds=50
    )
    assert timedelta_format(timedelta) == '05:13:24.000050'



# Generated at 2022-06-20 12:33:27.519456
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                  microseconds=123456)
    assert timedelta_format(t) == '11:22:33.123456'
    t = datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                  microseconds=123045)
    assert timedelta_format(t) == '11:22:33.123045'
    t = datetime_module.timedelta()
    assert timedelta_format(t) == '00:00:00.000000'



# Generated at 2022-06-20 12:33:34.887631
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(1)



# Generated at 2022-06-20 12:33:42.540886
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == (
        '00:00:00.001000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )

# Generated at 2022-06-20 12:33:48.462003
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-1,
                                                      microseconds=-1)) == \
                                                      '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                                                      '02:00:00.000000'

# Generated at 2022-06-20 12:33:57.366204
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0,
                                                                            0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0,
                                                                            0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0,
                                                                            0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0,
                                                                            0, 1000)

# Generated at 2022-06-20 12:34:05.379361
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-20 12:34:08.210821
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=11, hours=23, minutes=31,
                                          seconds=1, microseconds=2)
    assert timedelta_format(timedelta) == '551:31:01.000002'



# Generated at 2022-06-20 12:34:15.670054
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:24:00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == \
           '00:00:00:05:00:00'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
           '00:00:00:00:00:05'
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=5,
                                                      seconds=5,
                                                      microseconds=5)) == \
           '05:05:05:05:00:05'


# Generated at 2022-06-20 12:34:22.392751
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('24:00:00.000000')
    assert timedelta == datetime_module.timedelta(days=1)


if PY3:
    def dict_items_view(d):
        return d.items()
    def dict_keys_view(d):
        return d.keys()
    def dict_values_view(d):
        return d.values()
else:
    dict_items_view = dict.viewitems
    dict_keys_view = dict.viewkeys
    dict_values_view = dict.viewvalues

# Generated at 2022-06-20 12:34:30.968128
# Unit test for function timedelta_format
def test_timedelta_format():
    try:
        import nose
    except ImportError:
        return
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4))=='01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0))=='00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=1))=='00:00:01.000001'