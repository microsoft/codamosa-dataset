

# Generated at 2022-06-20 12:25:20.552201
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '1:02:03.001234'
    dt = timedelta_parse(s)
    assert dt.microseconds == 1234
    assert dt.seconds == 3 + 60 * 2 + 3600
    assert dt.days == 0

    s = '260:02:03.001234'
    dt = timedelta_parse(s)
    assert dt.microseconds == 1234
    assert dt.seconds == 3 + 60 * 2
    assert dt.days == 11



# Generated at 2022-06-20 12:25:23.436187
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=0, minutes=0,
                                          seconds=1, microseconds=2)
    assert timedelta_format(timedelta) == '00:00:01.000002'

# Generated at 2022-06-20 12:25:31.230906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('02:03:04.056789') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=56789
    )
    assert timedelta_parse('05:00:00.000001') == datetime_module.timedelta(
        hours=5, microseconds=1
    )
    assert timedelta_parse('00:05:00.000001') == datetime_module.timedelta(
        minutes=5, microseconds=1
    )
    assert timedelta_parse('00:00:05.000099') == datetime_module.timedelta(
        seconds=5, microseconds=99
    )


#

# Generated at 2022-06-20 12:25:40.055371
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=12,
                                                      minutes=3,
                                                      seconds=34,
                                                      microseconds=567890)) ==\
           '12:03:34.567890'
    timedelta = datetime_module.timedelta(days=365, hours=6,
                                          minutes=11,
                                          seconds=12, microseconds=131415)
    assert timedelta_format(timedelta) == '06:11:12.131415'



# Generated at 2022-06-20 12:25:47.437523
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:30:00.000000') == datetime_module.timedelta(minutes=30)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:10.000000') == datetime_module.timedelta(hours=1, seconds=10)
    assert timedelta_parse('01:00:30.000000') == datetime_module.timedelta(hours=1, minutes=1)
    assert timedelta_parse('01:10:00.000000') == datetime_module.timedelta(hours=1, minutes=10)

# Generated at 2022-06-20 12:25:59.111266
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.0001') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('0:0:0.001') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('0:0:0.01') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(0, 0, 10000)

# Generated at 2022-06-20 12:26:06.190484
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta, expected_output in (
            (datetime_module.timedelta(hours=3, minutes=4, seconds=2,
                                      microseconds=34),
             '03:04:02.000034'),
            (datetime_module.timedelta(hours=3, minutes=4, seconds=2,
                                      microseconds=34000),
             '03:04:02.034000'),
    ):
        actual_output = timedelta_format(timedelta)
        assert actual_output == expected_output



# Generated at 2022-06-20 12:26:17.871380
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:26:28.413789
# Unit test for function timedelta_parse
def test_timedelta_parse():
    q = timedelta_parse('0:0:0.123400')
    assert q == datetime_module.timedelta(microseconds=123400)

    q = timedelta_parse('0:0:0.123456')
    assert q == datetime_module.timedelta(microseconds=123456)

    q = timedelta_parse('0:02:03.123456')
    assert q == datetime_module.timedelta(hours=0, minutes=2, seconds=3,
                                          microseconds=123456)

    q = timedelta_parse('0:02:03.1234')
    assert q == datetime_module.timedelta(hours=0, minutes=2, seconds=3,
                                          microseconds=123400)


# Generated at 2022-06-20 12:26:35.909958
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=14, minutes=55,
                                                      seconds=32,
                                                      microseconds=200)) == '14:55:32.000200'
    assert timedelta_format(datetime_module.timedelta(hours=3, seconds=4,
                                                      microseconds=1)) == '03:00:04.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-20 12:26:53.747009
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-20 12:26:56.810303
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=-3,
                                                      microseconds=123000)) == \
           '-03:00:00:123000'



# Generated at 2022-06-20 12:27:03.593590
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(0, 0, 0, 1, 2, 3, 4)
    )) == datetime_module.timedelta(0, 0, 0, 1, 2, 3, 4)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(4, 2, 0, 0, 1)
    )) == datetime_module.timedelta(4, 2, 0, 0, 1)

# Generated at 2022-06-20 12:27:06.297734
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('00:04:00.000000') -
            datetime_module.timedelta(seconds=4)) < datetime_module.timedelta(
                microseconds=1)

# Generated at 2022-06-20 12:27:12.487068
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def _test():
        import pytest

        with pytest.raises(ValueError):
            timedelta_parse('1:1:1:1:1')
        with pytest.raises(ValueError):
            timedelta_parse('1:1:1.1:1')
        with pytest.raises(ValueError):
            timedelta_parse('1:1:1.1')
        assert timedelta_parse('1:1:1.1:1:1') == \
               timedelta_parse('01:01:01.000001')
        assert timedelta_parse('1') == timedelta_parse('00:00:00.000001')
        assert timedelta_parse('1.1') == timedelta_parse('00:00:01.100000')
        assert timedelta_parse('1.1:1')

# Generated at 2022-06-20 12:27:23.314640
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
        '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=5)) == \
        '00:00:01.000005'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=50)) == \
        '00:00:01.000050'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=500)) == \
        '00:00:01.000500'

# Generated at 2022-06-20 12:27:28.737073
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=30,
                                                      seconds=10)) \
           == '08:30:10.000000'
    assert timedelta_format(datetime_module.timedelta(hours=14, minutes=13,
                                                      seconds=30,
                                                      microseconds=123456)) \
           == '14:13:30.123456'



# Generated at 2022-06-20 12:27:34.599473
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test that even very large values are formatted correctly:
    one_year_timedelta = datetime_module.timedelta(days=365)
    formatted_timedelta = timedelta_format(one_year_timedelta)
    assert formatted_timedelta == '00:00:00:00:00:00:00:31536000.000000'

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == \
           '00:00:00.123456'

# Generated at 2022-06-20 12:27:37.929502
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(10, 987654321)) == \
                                                            '28:09:27.987654'



# Generated at 2022-06-20 12:27:48.689423
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.100001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:01:00.010001') == datetime_module.timedelta(seconds=60, microseconds=1)
    assert timedelta_parse('01:01:00.010001') == datetime_module.timedelta(minutes=61, seconds=1, microseconds=1)

# Generated at 2022-06-20 12:28:05.408655
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901
    )

# Generated at 2022-06-20 12:28:16.546459
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing_tools import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(days=1)),
                 '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(hours=1)),
                 '01:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=1)),
                 '00:01:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
                 '00:00:01.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(microseconds=1)),
                 '00:00:00.000001')

# Generated at 2022-06-20 12:28:20.568144
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(microseconds=1))
    ) == datetime_module.timedelta(microseconds=1)

    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(microseconds=2))
    ) == datetime_module.timedelta(microseconds=2)

# Generated at 2022-06-20 12:28:27.105325
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(hours=2, minutes=31, seconds=2,
                                  microseconds=750000),
        datetime_module.timedelta(hours=28, minutes=31, seconds=38,
                                  microseconds=758111)
    ):
        assert timedelta_parse(
            timedelta_format(timedelta)
        ) == timedelta

# Generated at 2022-06-20 12:28:35.290489
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                                      microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                                      microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                                      microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                                      microseconds=100)) == '00:00:00.000100'
    assert timedelta

# Generated at 2022-06-20 12:28:46.755524
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=12)) \
                                                      == '04:05:12.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=12,
                                                      microseconds=432000)) \
                                                      == '04:05:12.432000'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=12,
                                                      microseconds=432000)) \
                                                      == '04:05:12.432000'

# Generated at 2022-06-20 12:28:59.011883
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:05:15.500500') == \
           datetime_module.timedelta(hours=2, minutes=5, seconds=15,
                                     microseconds=500500)
    assert timedelta_parse('0:05:15.500500') == \
           datetime_module.timedelta(hours=0, minutes=5, seconds=15,
                                     microseconds=500500)
    assert timedelta_parse('2:01:15.500500') == \
           datetime_module.timedelta(hours=2, minutes=1, seconds=15,
                                     microseconds=500500)

# Generated at 2022-06-20 12:29:01.181816
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_timedelta import test_timedelta_format
    test_timedelta_format(timedelta_format)


# Generated at 2022-06-20 12:29:07.136957
# Unit test for function timedelta_format
def test_timedelta_format():
    import re
    format_regex = re.compile(r'\d{2}:\d{2}:\d{2}\.\d{6}')
    for i in range(999999):
        assert format_regex.match(
            timedelta_format(datetime_module.timedelta(microseconds=i))
        )
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == \
                                                    '00:00:00.000000'

test_timedelta_format()


# Generated at 2022-06-20 12:29:18.462973
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:10.123456') == datetime_module.timedelta(hours=1,
                                                         minutes=23,
                                                         seconds=10,
                                                         microseconds=123456)
    assert timedelta_parse('1:23:10') == datetime_module.timedelta(hours=1,
                                                         minutes=23,
                                                         seconds=10,
                                                         microseconds=0)
    assert timedelta_parse('1:23:10.123') == datetime_module.timedelta(hours=1,
                                                         minutes=23,
                                                         seconds=10,
                                                         microseconds=123000)
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()

    # Some more tests for fun

# Generated at 2022-06-20 12:29:54.553901
# Unit test for function timedelta_format
def test_timedelta_format():
    import bootstrap
    bootstrap.monkey_patching_runtime()
    import pytest
    from python_toolbox import cute_testing
    import python_toolbox.nifty_collections
    for timedelta in map(datetime_module.timedelta, python_toolbox.nifty_collections.cyclic(range(10000))):
        time = (datetime_module.datetime.min + timedelta).time()

        with cute_testing.RaiseAssertor(pytest.raises(NotImplementedError), times_to_try=2):
            time_isoformat(time, timespec='seconds')

        with cute_testing.RaiseAssertor(pytest.raises(NotImplementedError), times_to_try=2):
            time_isoformat(time, timespec='microseconds')


# Generated at 2022-06-20 12:30:04.383828
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(19, 51, 41, 456888)
    assert '19:51:41.456888' == time_isoformat(time, timespec='microseconds')

    timedelta = datetime_module.timedelta(days=365, hours=19, minutes=51,
                                          seconds=41, microseconds=456888)
    assert '19:51:41.456888' == timedelta_format(timedelta)

    assert datetime_module.timedelta() == timedelta_parse('00:00:00.000000')
    assert timedelta == timedelta_parse('19:51:41.456888')
    assert timedelta == timedelta_parse('19:51:41.456888000')



# Generated at 2022-06-20 12:30:15.785200
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1000)) == '00:00:00.001000'

# Generated at 2022-06-20 12:30:24.152508
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
        )
    assert timedelta_parse('0:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
        )
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
        )
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1
        )

# Generated at 2022-06-20 12:30:35.665600
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('2:34:56.000000') == datetime_module.timedelta(9296)
    assert timedelta_parse('12:34:56.000000') == datetime_module.timedelta(45296)
    assert timedelta_parse('23:59:59.000000') == datetime_module.timedelta

# Generated at 2022-06-20 12:30:41.573147
# Unit test for function timedelta_format
def test_timedelta_format():
    from random import random
    from time import sleep
    for _ in range(100):
        sleep(random() * .01)
        test_timedelta = datetime_module.timedelta(seconds=random())
        test_timedelta_str = timedelta_format(test_timedelta)
        assert (test_timedelta_str ==
                str(test_timedelta).split('.')[0])



# Generated at 2022-06-20 12:30:47.503821
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for x in (
        '00:00:00.000000',
        '01:02:03.100000',
        '1:2:3.1',
        '-01:02:03.100000',
        '-1:2:3.1',
    ):
        assert timedelta_parse(x) == datetime_module.timedelta(**{
            ('hours', 'minutes', 'seconds', 'microseconds')[y]: x
            for y, x in enumerate(map(int, x.replace('.', ':').split(':')))
        })
        



# Generated at 2022-06-20 12:30:57.644768
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) \
           == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) \
           == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) \
           == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) \
           == '00:00:10.000000'

# Generated at 2022-06-20 12:31:01.640720
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        days=62, hours=23, minutes=12, seconds=11, microseconds=10
    )
    result = timedelta_format(timedelta)
    assert result == '23:12:11.000010'

# Generated at 2022-06-20 12:31:09.568821
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.0') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

# Generated at 2022-06-20 12:32:14.250787
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.45678') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=45678
    )
    assert timedelta_parse('1:2:3.4567') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4567
    )

# Generated at 2022-06-20 12:32:22.624693
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, hours=1)) == '01:00:00.000000'

# Generated at 2022-06-20 12:32:29.726012
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=9)) == \
           '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(microseconds=99)) == \
           '00:00:00.000099'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=9)) == \
           '00:00:01.000009'

# Generated at 2022-06-20 12:32:38.962993
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from datetime import timedelta, time
    assert timedelta_parse('1:01:01.01') == timedelta(seconds=3661,
                                                       microseconds=10000)
    assert timedelta_parse('01:01:01.01') == timedelta(seconds=3661,
                                                       microseconds=10000)
    assert timedelta_parse('1:1:1.01') == timedelta(seconds=3661,
                                                     microseconds=10000)
    assert timedelta_parse('01:1:01.01') == timedelta(seconds=3661,
                                                       microseconds=10000)
    assert timedelta_parse('01:01:1.01') == timedelta(seconds=3661,
                                                       microseconds=10000)


# Generated at 2022-06-20 12:32:41.895905
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=4)
    assert timedelta_format(delta) == '01:02:03.000004'



# Generated at 2022-06-20 12:32:50.646682
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456000)
    ) == '01:02:03.456000'
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                  microseconds=567000)
    ) == '26:03:04.567000'

# Generated at 2022-06-20 12:32:58.453304
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'



# Generated at 2022-06-20 12:33:06.446578
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(seconds=1, microseconds=123456)
    assert timedelta_parse('00:01:00.123456') == datetime_module.timedelta(minutes=1, seconds=0, microseconds=123456)
    assert timedelta_parse('01:00:00.123456') == datetime_module.timedelta(hours=1, minutes=0, seconds=0, microseconds=123456)

# Generated at 2022-06-20 12:33:15.692427
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('12:15:43.234567')) == '12:15:43.234567'
    assert timedelta_format(timedelta_parse('12:15:43.234567')) == '12:15:43.234567'
    assert timedelta_format(timedelta_parse('00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('12:15.234567')) == '12:15:00.234567'

# Generated at 2022-06-20 12:33:17.933131
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('1:2:3.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

