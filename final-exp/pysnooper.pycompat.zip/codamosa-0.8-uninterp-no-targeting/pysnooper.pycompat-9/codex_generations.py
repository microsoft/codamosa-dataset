

# Generated at 2022-06-20 12:25:15.923564
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45') == timedelta_parse('00:01:23:45')
    assert timedelta_parse('1:23:45.123456') == timedelta_parse('00:01:23:45.123456')
    assert timedelta_parse('1:23:45.123456') == timedelta_parse('00:01:23:45.123456')

# Generated at 2022-06-20 12:25:18.767565
# Unit test for function timedelta_format
def test_timedelta_format():
    a = datetime_module.timedelta(minutes=10, seconds=12, microseconds=30000)
    assert timedelta_format(a) == '00:10:12.030000'



# Generated at 2022-06-20 12:25:25.072651
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0))) \
                 == datetime_module.timedelta(0, 0)

    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(0, (1 + 60 ** 2 + 24 ** 3)
                         * 10 ** 6))
    ) == datetime_module.timedelta(0, (1 + 60 ** 2 + 24 ** 3)
                                   * 10 ** 6)

# Generated at 2022-06-20 12:25:31.889522
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-20 12:25:44.198376
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.456789')) == \
                                                 '01:02:03.456789'


if PY3:
    def import_string(module_name, object_name):
        module = __import__(module_name, fromlist=[object_name])
        return getattr(module, object_name)
else:
    from importlib import import_module
    def import_string(module_name, object_name):
        module = import_module(module_name)
        return getattr(module, object_name)


try:
    from pathlib import Path as PathClass
except ImportError:
    try:
        from pathlib2 import Path as PathClass
    except ImportError:
        PathClass = None

# Generated at 2022-06-20 12:25:55.748961
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3)) == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-20 12:26:03.509101
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import nose
    import pytest

    assert timedelta_parse('1:2:3.000456') == \
                                  datetime_module.timedelta(hours=1, minutes=2,
                                                            seconds=3,
                                                            microseconds=456)
    assert timedelta_parse('00:02:03.000456') == \
                                  datetime_module.timedelta(hours=0, minutes=2,
                                                            seconds=3,
                                                            microseconds=456)
    assert timedelta_parse('00:00:03.000456') == \
                                  datetime_module.timedelta(hours=0, minutes=0,
                                                            seconds=3,
                                                            microseconds=456)
    assert timedelta_parse('00:00:00.000456')

# Generated at 2022-06-20 12:26:11.365933
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:26:15.054267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('4:05:06.789012') == datetime_module.timedelta(
        hours=4, minutes=5, seconds=6, microseconds=789012
    )



# Generated at 2022-06-20 12:26:27.104050
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'

# Generated at 2022-06-20 12:26:45.351179
# Unit test for function timedelta_format
def test_timedelta_format():
    timedeltas = [datetime_module.timedelta(hours=3, minutes=12, seconds=5,
                                            microseconds=123456)]
    if not PY2:
        timedeltas += [datetime_module.timedelta(days=100)]
    for timedelta in timedeltas:
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta


import inspect as inspect_module

# Generated at 2022-06-20 12:26:47.456916
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2)) == '00:00:172800.000000'



# Generated at 2022-06-20 12:26:55.796459
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)

# Generated at 2022-06-20 12:27:05.606392
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:30.000000') == datetime_module.timedelta(1, 30*60)
    assert timedelta_parse('01:00:30.123456') == datetime_module.timedelta(1, (30*60 + 30) * 1000 + 123)

# Generated at 2022-06-20 12:27:08.050959
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in ('00:00:00.000000', '12:34:56.789012'):
        assert timedelta_parse(s) == timedelta_parse(timedelta_format(timedelta_parse(s)))

# Generated at 2022-06-20 12:27:16.814114
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (
            datetime_module.timedelta(days=1, hours=3, microseconds=1),
            datetime_module.timedelta(days=7, hours=0, microseconds=1),
            datetime_module.timedelta(days=0, hours=23, microseconds=1),
            datetime_module.timedelta(days=0, hours=0, microseconds=1),
            datetime_module.timedelta(days=0, hours=0, microseconds=0),
        ):
        assert timedelta_format(timedelta) == time_isoformat(
            (datetime_module.datetime.min + timedelta).time(),
            timespec='microseconds'
        )
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-20 12:27:27.515521
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                            datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1)
    )) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2)
    )) == datetime_module.timedelta(hours=1, minutes=2)

# Generated at 2022-06-20 12:27:33.689686
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                microseconds=2)) == '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                minutes=20, seconds=30,
                                                microseconds=40)) == '10:20:30.000040'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                minutes=3, seconds=4,
                                                microseconds=5)) == '26:03:04.000005'



# Generated at 2022-06-20 12:27:45.424989
# Unit test for function timedelta_format
def test_timedelta_format():
    if datetime_module.time.isoformat != time_isoformat:
        assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
               datetime_module.time(0, 0, 0).isoformat()
        assert timedelta_format(datetime_module.timedelta(0, 0, 10**6 - 1)) == \
               datetime_module.time(0, 0, 1).isoformat(timespec='microseconds')
        assert timedelta_format(datetime_module.timedelta(0, 0, 10**6)) == \
               datetime_module.time(0, 0, 1).isoformat(timespec='microseconds')

# Generated at 2022-06-20 12:27:55.939497
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(0, 0, 123456)
    assert timedelta_parse('0:0:1.123456') == datetime_module.timedelta(0, 1, 123456)
    assert timedelta_parse('0:1:1.123456') == datetime_module.timedelta(0, 61, 123456)
    assert timedelta_parse('1:1:1.123456') == datetime_module.timedelta(1, 3661, 123456)
    assert timedelta_parse('2:59:59.123456') == datetime_module.timedelta(2, 86399, 123456)

# Generated at 2022-06-20 12:28:12.743603
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )) == '01:02:03.456789'



# Generated at 2022-06-20 12:28:20.858383
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_monkey_patching import TestCase
    class MyTestCase(TestCase):
        def test_timedelta_format(self):
            timedelta = datetime_module.timedelta(hours=3, minutes=2,
                                                  seconds=1,
                                                  microseconds=456)
            self.assertEqual(timedelta_format(timedelta),
                             '03:02:01.000456')

            timedelta = datetime_module.timedelta(hours=0, minutes=0,
                                                  seconds=0,
                                                  microseconds=0)
            self.assertEqual(timedelta_format(timedelta),
                             '00:00:00.000000')


# Unit tests for function timedelta_parse

# Generated at 2022-06-20 12:28:31.753258
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) \
           == '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.123456)) \
           == '00:00:01.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=-1.123456)) \
           == '-1 day, 23:59:58.876544'

    assert timedelta_parse('00:00:01.500000') \
           == datetime_module.timedelta(seconds=1.5)
    assert timedelta_parse('00:00:01.123456') \
           == datetime_module.timedelta(seconds=1.123456)

# Generated at 2022-06-20 12:28:43.036646
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-20 12:28:46.387217
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=456)
    assert timedelta_format(timedelta) == '01:02:03.000456'



# Generated at 2022-06-20 12:28:52.925408
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # noinspection PyUnresolvedReferences
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4567
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4567)

# Generated at 2022-06-20 12:28:55.874843
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=6,
                                                      microseconds=123456)) \
           == '00:00:06.123456'


# Generated at 2022-06-20 12:29:05.403586
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=8, minutes=9, seconds=10, microseconds=11)) == \
           '32:09:10.000011'

# Generated at 2022-06-20 12:29:09.895389
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=23, minutes=13, seconds=42,
                                   microseconds=123456)
    assert timedelta_format(td) == timedelta_parse(timedelta_format(td)) == td



_name_cache = {}

# Generated at 2022-06-20 12:29:18.364235
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 5)) == \
           '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 2)) == \
           '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(0, 0, 17, 123456)) == \
           '00:00:00.123456'


# Generated at 2022-06-20 12:29:47.526460
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=5, minutes=5,
                                               seconds=5, microseconds=5)) == \
                                               '05:05:05.000005'



# Generated at 2022-06-20 12:29:50.185305
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    ) == '01:02:03.000004'


# Generated at 2022-06-20 12:29:53.387803
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for string in ('00:01:02.003004', '1:2:3.4'):
        assert timedelta_parse(string) == datetime_module.timedelta(
            hours=1, minutes=2, seconds=3, microseconds=4004
        )

# Generated at 2022-06-20 12:30:02.625433
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2.5)) == '00:00:02.500000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '24:00:01.000000'
    assert timedelta_

# Generated at 2022-06-20 12:30:14.163517
# Unit test for function timedelta_format
def test_timedelta_format():
    from .compatibility import timedelta_format
    from .compatibility import timedelta_parse
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
        '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
        '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
        '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
        '00:00:00.000002'

# Generated at 2022-06-20 12:30:17.649140
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=2, minutes=23, seconds=56,
                                          microseconds=8000)
    formatted_timedelta = timedelta_format(timedelta)
    assert timedelta_parse(formatted_timedelta) == timedelta

# Generated at 2022-06-20 12:30:20.050956
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                          microseconds=789000)
    assert timedelta_format(timedelta) == '12:34:56.789000'



# Generated at 2022-06-20 12:30:26.331403
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:02:03.000000')) == \
                                           '01:02:03.000000'
    assert timedelta_format(timedelta_parse('00:00:00.002000')) == \
                                           '00:00:00.002000'
    assert timedelta_format(timedelta_parse('00:02:15.092000')) == \
                                           '00:02:15.092000'

# Generated at 2022-06-20 12:30:29.738270
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456)
    assert timedelta_format(td) == '01:02:03.123456'



# Generated at 2022-06-20 12:30:40.779150
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-20 12:31:34.332214
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, hours=1, minutes=1,
                                          seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '25:01:01.000001'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


if sys.version_info[:2] >= (3, 7):
    from datetime import timezone
    # already in 3.7+
else:
    class timezone(datetime_module.tzinfo):
        '''Fixed offset in minutes east from UTC.
        Implemented from the `datetime.timezone` class from Python 3.7,
        taken from https://docs.python.org/3/library/datetime.html
        '''

# Generated at 2022-06-20 12:31:44.214018
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:00:01.100000') == datetime_module.timedelta(0, 1, 100000)
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(0, 1, 123456)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('00:01:00.100000') == datetime_module.timedelta(0, 60, 100000)

# Generated at 2022-06-20 12:31:53.972544
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'

    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-20 12:31:56.352056
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=12, seconds=60)) == '12:01:00.000000'


# Generated at 2022-06-20 12:32:04.160517
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                  '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                  '00:00:00.000001'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                          days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                          microseconds=1))) == datetime_module.timedelta(
                                                          microseconds=1)

# Generated at 2022-06-20 12:32:07.513146
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789,
    )



# Generated at 2022-06-20 12:32:17.156910
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:00:01.001000')) == \
                                                        '00:00:01.001000'
    assert timedelta_format(timedelta_parse('0:01:01.001000')) == \
                                                        '00:01:01.001000'
    assert timedelta_format(timedelta_parse('1:01:01.001000')) == \
                                                        '01:01:01.001000'
    assert timedelta_format(timedelta_parse('1:01:01.111000')) == \
                                                        '01:01:01.111000'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == \
                                                        '23:59:59.999999'

# Generated at 2022-06-20 12:32:20.229988
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4,
                                                      microseconds=123456))\
                                                                  == '02:03:04.123456'



# Generated at 2022-06-20 12:32:22.510654
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=15, minutes=6, seconds=7, microseconds=8
    )) == '15:06:07.000008'

# Generated at 2022-06-20 12:32:29.623412
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:21:55.123456') \
           == datetime_module.timedelta(hours=12,
                                        minutes=21,
                                        seconds=55,
                                        microseconds=123456)
    assert timedelta_parse('12:21:55.123') \
           == datetime_module.timedelta(hours=12,
                                        minutes=21,
                                        seconds=55,
                                        microseconds=123000)
    assert timedelta_parse('1:2:3') \
           == datetime_module.timedelta(hours=1,
                                        minutes=2,
                                        seconds=3)
    assert timedelta_parse('2:3') \
           == datetime_module.timedelta(minutes=2,
                                        seconds=3)



# Generated at 2022-06-20 12:34:36.330534
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-20 12:34:45.552585
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=65)) == \
                                                              '00:01:05.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=70,
                                                      microseconds=500000)) == \
                                                              '00:01:10.500000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=30,
                                                      microseconds=100)) == \
                                                              '00:01:30.000100'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=10,
                                                      seconds=5,
                                                      microseconds=100)) == \
                                                             '01:10:05.000100'
    assert timed

# Generated at 2022-06-20 12:34:52.288504
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('0:00:00.000000') ==
            datetime_module.timedelta(hours=0, minutes=0,
                                      seconds=0, microseconds=0))
    assert (timedelta_parse('24:00:00.000000') ==
            datetime_module.timedelta(hours=24, minutes=0,
                                      seconds=0, microseconds=0))
    assert (timedelta_parse('1:01:01.010101') ==
            datetime_module.timedelta(hours=1, minutes=1,
                                      seconds=1, microseconds=10101))



# Generated at 2022-06-20 12:35:03.036769
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:10:00.000000') == datetime_module.timedelta(
        minutes=10
    )
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(
        seconds=10
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )