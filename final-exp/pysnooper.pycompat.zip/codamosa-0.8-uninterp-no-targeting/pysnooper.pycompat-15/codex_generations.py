

# Generated at 2022-06-20 12:25:23.124520
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:3.444444') == datetime_module.timedelta(
        seconds=3, microseconds=444444)
    assert timedelta_parse('1:0:0.123456') == datetime_module.timedelta(
        hours=1, microseconds=123456)
    assert timedelta_parse('10:54:03.123456') == datetime_module.timedelta(
        hours=10, minutes=54, seconds=3, microseconds=123456)
    assert timedelta_parse('2:33:25.123456') == datetime_module.timedelta(
        hours=2, minutes=33, seconds=25, microseconds=123456)

# Generated at 2022-06-20 12:25:30.979490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=456789)
    string = timedelta_format(timedelta)
    timedelta2 = timedelta_parse(string)
    assert timedelta == timedelta2


if sys.version_info[:2] >= (3, 3):

    def check_isinstance(object_, classes):
        """Return True if the object is an instance of any of ``classes``."""
        return isinstance(object_, classes)

else:

    def check_isinstance(object_, classes):
        """Return True if the object is an instance of any of ``classes``."""
        for class_ in classes:
            if isinstance(object_, class_):
                return True
        return False

# Generated at 2022-06-20 12:25:37.187013
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=123)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1234)) == '00:00:01.001234'


# Generated at 2022-06-20 12:25:40.304911
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, seconds=3, microseconds=3)
    assert timedelta_format(timedelta) == '03:00:03.000003'



# Generated at 2022-06-20 12:25:47.390874
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'


# Generated at 2022-06-20 12:25:56.501256
# Unit test for function timedelta_format
def test_timedelta_format():
    example_timedelta = datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_format(example_timedelta) == \
           '01:02:03.000456'
    example_timedelta = datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_format(example_timedelta) == \
           '01:02:03.456789'



# Generated at 2022-06-20 12:26:01.885502
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.datetime.min
    for hours in range(50):
        for minutes in range(60):
            for seconds in range(60):
                for microseconds in range(1000000):
                    assert timedelta_format(datetime_module.timedelta(
                        hours=hours, minutes=minutes, seconds=seconds,
                        microseconds=microseconds
                    )) == time.isoformat()
                    time += datetime_module.timedelta(
                        microseconds=1)



# Generated at 2022-06-20 12:26:10.328853
# Unit test for function timedelta_format
def test_timedelta_format():
    one_day_ago = datetime_module.datetime.now() - datetime_module.timedelta(
        days=1
    )
    one_day_ago_string = str(one_day_ago)
    assert one_day_ago_string.startswith('20')

    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                            '00:00:24:00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                             '00:00:00:01:00:00'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00:00:00:01'

    assert timedelta

# Generated at 2022-06-20 12:26:20.173899
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        ('01:02:03.004000', '01:02:03.004000'),
        ('1:2:3.4', '01:02:03.004000'),
        ('1:2:3', '01:02:03'),
        ('1:2', '00:01:02'),
    ]
    for s, s_expected in cases:
        timedelta = timedelta_parse(s)
        s_actual = timedelta_format(timedelta)
        assert s_actual == s_expected, (s_actual, s_expected)

# Generated at 2022-06-20 12:26:30.568130
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == '00:00:00.000004'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=3)) == '00:01:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=3)) == '01:00:03.000000'
   

# Generated at 2022-06-20 12:26:45.392609
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=4,
                                                      seconds=5,
                                                      milliseconds=1,
                                                      microseconds=3)) \
                           == '03:04:05.001003'



# Generated at 2022-06-20 12:26:52.831439
# Unit test for function timedelta_parse
def test_timedelta_parse():
    examples = [
        '00:00:00.000000',
        '23:59:59.999999',
        '01:23:45.678901',
        ]
    copies = []
    for s in examples:
        parsed = timedelta_parse(s)
        stringified = timedelta_format(parsed)
        copies.append(stringified)
    assert copies == examples

# Generated at 2022-06-20 12:26:57.239282
# Unit test for function timedelta_format
def test_timedelta_format():
    '''Unit test for function timedelta_format'''
    assert timedelta_format(datetime_module.timedelta(days=4, hours=5,
                                                      minutes=6, seconds=7,
                                                      microseconds=6543210)) \
           == '05:06:07.6543210'



# Generated at 2022-06-20 12:27:06.923483
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
                                                                microseconds=1)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
                                                                microseconds=100)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
                                                                microseconds=10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
                                                                microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.tim

# Generated at 2022-06-20 12:27:10.356023
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('00:00:01.123456') == \
           datetime_module.timedelta(seconds=1, microseconds=123456)

# Generated at 2022-06-20 12:27:14.838221
# Unit test for function timedelta_format
def test_timedelta_format():
    # This is a very loose test, just to make sure we didn't introduce
    # errors.
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert len(timedelta_format(timedelta)) == 15
    assert timedelta_format(timedelta) == '01:02:03.123456'



# Generated at 2022-06-20 12:27:26.085110
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=20)) == \
           '00:20:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=10)) == \
           '00:00:00.010000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'

# Generated at 2022-06-20 12:27:33.749801
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.1234567') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.12345678') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-20 12:27:45.469583
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('0:0:1.000010') == datetime_module.timedelta(0, 1, 10)
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(0, 1, 1)

# Generated at 2022-06-20 12:27:55.977099
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    for microseconds in (1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6):
        assert timedelta_format(datetime_module.timedelta(microseconds=microseconds)) == '00:00:00.{:06d}'.format(int(microseconds))
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'

# Generated at 2022-06-20 12:28:27.400530
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000400') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=400)
    assert timedelta_parse('26:59:59.999999') == \
           datetime_module.timedelta(days=1, microseconds=1)

# Generated at 2022-06-20 12:28:35.473817
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-20 12:28:38.740873
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=12))) == \
           datetime_module.timedelta(hours=12)

# Generated at 2022-06-20 12:28:48.562211
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:28:56.420943
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                     minutes=14,
                                                     seconds=56)) == \
           '23:14:56.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=14, seconds=56,
        microseconds=1234
    )) == '23:14:56.001234'



# Generated at 2022-06-20 12:29:03.057392
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                                                                '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-20 12:29:10.266765
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
                                                          '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
                                                          '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=123
    )) == '02:03:04.000123'

# Generated at 2022-06-20 12:29:21.063988
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours = 1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes = 1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds = 1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds = 1)) == \
                                                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
                                            microseconds = 12345678)) == \
                                                            '00:00:01.234567'


# Generated at 2022-06-20 12:29:31.484476
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )
    assert timedelta_parse('1:2:3.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('1:2:3.000004') == timedelta_parse('1:2:3.4')
    assert timedelta_parse('1:2:3.000004') == timedelta_parse('1:2:3.000004')


if PY3:
    from importlib import reload

# Generated at 2022-06-20 12:29:37.918645
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.010101') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=10
    )
    assert timedelta_parse('00:01:00.000001') == datetime_module.timedelta(
        minutes=1, microseconds=1
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('-00:00:00.000001') == datetime_module.timedelta(
        microseconds=-1
    )

# Generated at 2022-06-20 12:30:36.998411
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:01') == datetime_module.timedelta(
        seconds=1, minutes=1
    )
    assert timedelta_parse('01:00:01') == datetime_module.timedelta(
        seconds=1, minutes=0, hours=1
    )
    assert timedelta_parse('01:01:01') == datetime_module.timedelta(
        seconds=1, minutes=1, hours=1
    )
    assert timedelta_parse('01:01:01.000001') == datetime_module.timedelta(
        seconds=1, minutes=1, hours=1,
        microseconds=1
    )
    assert timedelta_

# Generated at 2022-06-20 12:30:46.291411
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=7, minutes=12, seconds=0, microseconds=123456
    )) == '07:12:00.123456'
    assert timedelta_format(datetime_module.timedelta(
        hours=7, minutes=12, seconds=0, microseconds=0
    )) == '07:12:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=1, microseconds=0
    )) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0
    )) == '01:00:00.000000'
    assert timedelta_

# Generated at 2022-06-20 12:30:49.265461
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                seconds=3,
                                                microseconds=123456)) == \
                                                '01:02:03.123456'



# Generated at 2022-06-20 12:30:56.698003
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-20 12:31:05.970826
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing import assert_equal
    from datetime import timedelta
    assert_equal(timedelta_parse('0:0:0.000000'), timedelta(seconds=0))
    assert_equal(timedelta_parse('0:0:1.000000'), timedelta(seconds=1))
    assert_equal(timedelta_parse('0:0:0.000001'), timedelta(microseconds=1))
    assert_equal(timedelta_parse('0:1:1.000001'), timedelta(seconds=61,
                                                             microseconds=1))
    assert_equal(timedelta_parse('1:1:1.000001'), timedelta(hours=1, seconds=61,
                                                             microseconds=1))

# Generated at 2022-06-20 12:31:16.647367
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.000000') == datetime_module.timedelta(
        seconds=60 * 60 * 1 + 60 * 23 + 45
    )
    assert timedelta_parse('0:23:45.000000') == datetime_module.timedelta(
        seconds=60 * 23 + 45
    )
    assert timedelta_parse('0:00:45.000000') == datetime_module.timedelta(
        seconds=45
    )
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('0:00:00.123450') == datetime_module.timedelta(
        microseconds=123450
    )

# Generated at 2022-06-20 12:31:21.383386
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=2, seconds=45, microseconds=50000
    ))) == datetime_module.timedelta(
        days=2, seconds=45, microseconds=50000
    )

test_timedelta_parse()

# Generated at 2022-06-20 12:31:30.188788
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.01') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=10
    )
    assert timedelta_parse('1:2:3.1') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100
    )

# Generated at 2022-06-20 12:31:41.428312
# Unit test for function timedelta_format
def test_timedelta_format():
    """Test function `timedelta_format`."""

    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )) == "01:02:03.400000"

    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == "01:02:03.000004"

    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )) == "01:02:03.040000"


# Generated at 2022-06-20 12:31:45.525121
# Unit test for function timedelta_parse
def test_timedelta_parse():
    d = timedelta_parse('00:10:11.123456')
    assert d.total_seconds() == (10*60 + 11) + 123456/10**6
    # Check that the function also works on a string that was created by
    # `.isoformat()`:
    assert timedelta_parse(d.isoformat()) == d

# Generated at 2022-06-20 12:32:51.711894
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = (datetime_module.datetime.min + datetime_module.timedelta(hours=10,
                                                                     minutes=20,
                                                                     seconds=30,
                                                                     microseconds=12345))
    assert timedelta_parse(timedelta_format(time)) == time
test_timedelta_parse()

# Generated at 2022-06-20 12:33:01.433158
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000002')) == \
           '00:00:00.000002'
    assert timedelta_format(timedelta_parse('01:00:00.000002')) == \
           '01:00:00.000002'
    assert timedelta_format(timedelta_parse('01:02:00.000002')) == \
           '01:02:00.000002'
    assert timedelta_format(timedelta_parse('01:02:03.000002')) == \
           '01:02:03.000002'
    assert timedelta_format(timedelta_parse('01:02:03.123456')) == \
           '01:02:03.123456'



# Generated at 2022-06-20 12:33:08.081595
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
                                            microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
                                            microseconds=1000001)) == \
                                            '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                            seconds=2, microseconds=3)) == \
                                            '01:00:02.000003'



# Generated at 2022-06-20 12:33:17.004855
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                                                         '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == \
                                                         '00:00:00.000001'
    assert timedelta_format(timedelta_parse('5:06:07.891011')) == \
                                                         '05:06:07.891011'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == \
                                                        '23:59:59.999999'

# Generated at 2022-06-20 12:33:27.809232
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:33:37.064093
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                  minutes=0, seconds=0,
                                                  microseconds=0)) == \
                                                  '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                  minutes=0, seconds=1,
                                                  microseconds=0)) == \
                                                  '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                  minutes=1, seconds=0,
                                                  microseconds=0)) == \
                                                  '00:01:00.000000'

# Generated at 2022-06-20 12:33:43.465293
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=1, microseconds=0
    )) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=1, seconds=0, microseconds=0
    )) == '00:01:00.000000'
    assert timedelta_format

# Generated at 2022-06-20 12:33:49.067386
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('1:2:3.000040') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40
    )
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()



# Generated at 2022-06-20 12:33:54.205221
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3,
                                                                     hours=5,
                                                                     minutes=34,
                                                                     seconds=54,
                                                                     microseconds=99))) == \
           datetime_module.timedelta(days=3, hours=5, minutes=34,
                                     seconds=54, microseconds=99)

# Generated at 2022-06-20 12:34:02.690151
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=12)) == '00:00:00.000012'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == '00:00:00.001234'