

# Generated at 2022-06-20 12:25:18.120321
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00:000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00:000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('0100:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('0100:00:00:000000') == datetime_module.timedelta(1)

# Generated at 2022-06-20 12:25:27.633568
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import six
    import pytest

# Generated at 2022-06-20 12:25:30.051422
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:34.123456') == datetime_module.timedelta(
        seconds=34, microseconds=123456
    )

# Generated at 2022-06-20 12:25:36.018051
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, minutes=23, seconds=1, microseconds=312322
    ))) == datetime_module.timedelta(hours=3, minutes=23, seconds=1,
                                     microseconds=312322)

# Generated at 2022-06-20 12:25:45.485490
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)

    assert timedelta_format(timedelta) == '01:02:03.123456'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

test_timedelta_format()


if PY3:
    def any_to_bytes(val, encoding='utf-8'):
        if isinstance(val, binary_type):
            return val
        if isinstance(val, text_type):
            return bytes(val, encoding=encoding)
        return binary_type(val)
else:
    def any_to_bytes(val, encoding='utf-8'):
        if isinstance(val, text_type):
            return

# Generated at 2022-06-20 12:25:57.088724
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = (
        (datetime_module.timedelta(hours=1), '01:00:00.000000'),
        (datetime_module.timedelta(minutes=10), '00:10:00.000000'),
        (datetime_module.timedelta(seconds=10), '00:00:10.000000'),
        (datetime_module.timedelta(microseconds=100), '00:00:00.000100'),
        (datetime_module.timedelta(microseconds=10), '00:00:00.000010'),
    )
    for timedelta, expected_result in cases:
        assert timedelta_format(timedelta) == expected_result
        parsed_timedelta = timedelta_parse(timedelta_format(timedelta))
        assert parsed_timedelta == timedelta

# Generated at 2022-06-20 12:26:07.175746
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:1:234567') == \
                 datetime_module.timedelta(seconds=1, microseconds=234567)
    assert timedelta_parse('9:8:7.654321') == \
                 datetime_module.timedelta(hours=9, minutes=8, seconds=7,
                                           microseconds=654321)


if sys.version_info[:2] >= (3, 6):
    datetime_isoformat = datetime_module.datetime.isoformat
else:
    def datetime_isoformat(datetime):
        assert isinstance(datetime, datetime_module.datetime)
        return '{}T{}Z'.format(
            datetime.date().isoformat(), timedelta_format(datetime.time())
        )

# Generated at 2022-06-20 12:26:10.020500
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=42, minutes=42, seconds=42, microseconds=42
    )) == '42:42:42.000042'


# Generated at 2022-06-20 12:26:22.663150
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )
    assert timedelta_parse('0:0:0.010000') == datetime_module.timedelta(
        milliseconds=10
    )
    assert timedelta_parse('0:0:0.100000') == datetime_module.timedelta(
        seconds=0.1
    )

# Generated at 2022-06-20 12:26:32.571546
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse(
        timedelta_format(datetime_module.timedelta(seconds=1))
    )) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse(
        timedelta_format(datetime_module.timedelta(minutes=1))
    )) == '00:01:00.000000'
    assert timedelta_format(timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1))
    )) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse(
        timedelta_format(datetime_module.timedelta(days=1))
    )) == '24:00:00.000000'

# Generated at 2022-06-20 12:26:48.279501
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:30:00.000000') == \
           datetime_module.timedelta(hours=2, minutes=30)
    assert timedelta_parse('1:25:01.000062') == \
           datetime_module.timedelta(hours=1, minutes=25, seconds=1,
                                     microseconds=62)



# Generated at 2022-06-20 12:26:56.391806
# Unit test for function timedelta_parse
def test_timedelta_parse():
    delta = datetime_module.timedelta(hours=-1)
    assert timedelta_parse(timedelta_format(delta)) == delta
    delta = datetime_module.timedelta(minutes=-1)
    assert timedelta_parse(timedelta_format(delta)) == delta
    delta = datetime_module.timedelta(seconds=-1)
    assert timedelta_parse(timedelta_format(delta)) == delta
    delta = datetime_module.timedelta(microseconds=-1)
    assert timedelta_parse(timedelta_format(delta)) == delta

    delta = datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                      microseconds=1)
    assert timedelta_parse(timedelta_format(delta)) == delta

   

# Generated at 2022-06-20 12:27:06.340142
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:01:01.000000') == datetime_module.timedelta(
        minutes=1, seconds=1)
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1)
    assert timedelta_parse('01:01:01.999999') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=999999)
    assert timedelta_parse('01:01:01.123456')

# Generated at 2022-06-20 12:27:14.437263
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:0:0.01') == datetime_module.timedelta(hours=1,
                                                            microseconds=10)
    assert timedelta_parse('1:2:3.45') == datetime_module.timedelta(hours=1,
                                                            minutes=2,
                                                            seconds=3,
                                                            microseconds=450)
    assert timedelta_parse('-1:2:3.45') == (datetime_module.timedelta(hours=-1,
                                                              minutes=-2,
                                                              seconds=-3,
                                                              microseconds=-450))



# Generated at 2022-06-20 12:27:21.167195
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_strs = (
        '00:00:00.000000',
        '02:04:06.789012',
        '02:04:06.789012',
        '-02:04:06.789012',
    )
    for timedelta_str in timedelta_strs:
        assert timedelta_format(timedelta_parse(timedelta_str)) == timedelta_str

# Generated at 2022-06-20 12:27:23.210542
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456000
    )) == '1:02:03.456000'



# Generated at 2022-06-20 12:27:31.914784
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:20.000000') == datetime_module.timedelta(
        seconds=80
    )
    assert timedelta_parse('0:01:20.000010') == datetime_module.timedelta(
        seconds=80, microseconds=10,
    )
    assert timedelta_parse('0:01:20.000100') == datetime_module.timedelta(
        seconds=80, microseconds=100,
    )
    assert timedelta_parse('0:01:20.001000') == datetime_module.timedelta(
        seconds=80, microseconds=1000,
    )
    assert timedelta_parse('0:01:20.010000') == datetime_module.timedelta(
        seconds=80, microseconds=10000,
    )
   

# Generated at 2022-06-20 12:27:37.061795
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'



# Generated at 2022-06-20 12:27:47.925265
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10, 1)) == \
           '00:00:00.000011'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1, 1)) == \
           '00:00:00.000101'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1, 1000000)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1, 0)) == \
           '00:00:01.000000'

# Generated at 2022-06-20 12:27:57.390943
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
        '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'



# Generated at 2022-06-20 12:28:20.965648
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2, hours=2, minutes=2,
                                          seconds=2, microseconds=2)
    assert timedelta_format(timedelta) == '48:02:02.000002'


# Generated at 2022-06-20 12:28:31.828150
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()).startswith('00:00:00')
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) \
                                                              .startswith('00:00:00')
    assert timedelta_format(datetime_module.timedelta(microseconds=0,
                                                      seconds=1)) \
                                                              .startswith('00:00:01')
    assert timedelta_format(datetime_module.timedelta(microseconds=0,
                                                      seconds=0,
                                                      minutes=1)) \
                                                              .startswith('00:01:00')

# Generated at 2022-06-20 12:28:35.025714
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('01:02:03.123456')
    time = (datetime_module.datetime.min + timedelta).time()
    assert time.isoformat(timespec='microseconds') == '01:02:03.123456'

# Generated at 2022-06-20 12:28:46.764752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-20 12:28:59.051995
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-20 12:29:07.834956
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(days=2, hours=3, minutes=4, seconds=5,
                                   microseconds=6)
    assert timedelta_parse('2:03:04:05.000006') == td
    assert timedelta_parse('02:03:04:05.000006') == td



# Generated at 2022-06-20 12:29:12.013098
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4,
                                                      microseconds=56789)) == '02:03:04.056789'

# Generated at 2022-06-20 12:29:22.380738
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.100000') == datetime_module.timedelta(microseconds=100000)

# Generated at 2022-06-20 12:29:26.310386
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_python_toolbox import assert_equal
    assert_equal(timedelta_parse('00:00:48.623948'),
                 datetime_module.timedelta(seconds=48, microseconds=623948))



# Generated at 2022-06-20 12:29:35.104911
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1') == datetime_module.timedelta(days=1)
    assert timedelta_parse('1.1') == datetime_module.timedelta(
        days=1, hours=2)
    assert timedelta_parse('1.1.1') == datetime_module.timedelta(
        days=1, hours=2, minutes=3)
    assert timedelta_parse('1.1.1.1') == datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4)
    assert timedelta_parse('1.1.1.1.1') == datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=5)

# Generated at 2022-06-20 12:30:20.710911
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('12:34:56.123456')) == \
           '12:34:56.123456'
    assert timedelta_format(timedelta_parse('99:59:59.999999')) == \
           '99:59:59.999999'

# Generated at 2022-06-20 12:30:28.303928
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import hypothesis
    import hypothesis.strategies as hst
    from combi._python_toolbox.third_party.time_string import (
        from_isoformat as from_isoformat_original
    )
    @hypothesis.given(hst.datetimes())
    def test(datetime):
        given_string = from_isoformat_original(datetime)
        parsed_timedelta = timedelta_parse(given_string)
        actual_string = timedelta_format(parsed_timedelta)
        assert given_string == actual_string
    test()

# Generated at 2022-06-20 12:30:39.162684
# Unit test for function timedelta_parse
def test_timedelta_parse():
    fmt = '{0:%H:%M:%S.%f}'
    dt_ = datetime_module.datetime(2019, 1, 1, 11, 22, 33, 444556)
    dt = dt_.timestamp()
    assert dt_ == datetime_module.datetime.fromtimestamp(dt)
    assert timedelta_parse(fmt.format(dt_)) == datetime_module.timedelta(
        11, 22*60 + 33, 444556
    )

if sys.version_info[:2] >= (3, 7):
    import datetime as _datetime
    def time_replace(time, **kwargs):
        return _datetime.time(time.hour, time.minute, time.second,
                              time.microsecond, **kwargs)

# Generated at 2022-06-20 12:30:47.476051
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=7,
                                                      seconds=13,
                                                      microseconds=5)) == \
        '03:07:13.000005'
    assert timedelta_format(datetime_module.timedelta(hours=24*10, minutes=7,
                                                      seconds=13,
                                                      microseconds=5)) == \
        '240:07:13.000005'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=7,
                                                      seconds=0,
                                                      microseconds=5)) == \
        '00:07:00.000005'

# Generated at 2022-06-20 12:30:57.567948
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
           '00:00:00.001000'

    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'


# Generated at 2022-06-20 12:31:05.518921
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=42)) == \
           '00:00:36:48:00.000000'
    assert timedelta_format(timedelta_parse('42:0:36:48:0.000000')) == \
           '00:00:36:48:00.000000'
    assert timedelta_parse('42:0:36:48:0.000000') == \
           datetime_module.timedelta(days=42)


if PY2:
    from .python_2 import *
else:
    from .python_3 import *

# Generated at 2022-06-20 12:31:16.167403
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(seconds=0,
                                          microseconds=0)
    assert timedelta_format(timedelta) == '00:00:00.000000'
    timedelta = datetime_module.timedelta(seconds=5,
                                          microseconds=0)
    assert timedelta_format(timedelta) == '00:00:05.000000'
    timedelta = datetime_module.timedelta(seconds=62,
                                          microseconds=0)
    assert timedelta_format(timedelta) == '00:01:02.000000'
    timedelta = datetime_module.timedelta(microseconds=50000)
    assert timedelta_format(timedelta) == '00:00:00.050000'

# Generated at 2022-06-20 12:31:25.883849
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == '00:00:00'

# Generated at 2022-06-20 12:31:32.750898
# Unit test for function timedelta_parse
def test_timedelta_parse():

    one_second = datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:00.000001') == one_second

    one_second_plus_one_microsecond = datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('00:00:01.000001') == one_second_plus_one_microsecond

    one_minute_plus_one_microsecond = datetime_module.timedelta(
        minutes=1, microseconds=1
    )
    assert timedelta_parse('00:01:00.000001') == one_minute_plus_one_microsecond

# Generated at 2022-06-20 12:31:43.021965
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == ''
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 2)) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(0, 3)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(0, 4)) == '00:00:00.000004'
    assert timedelta_format(datetime_module.timedelta(0, 5)) == '00:00:00.000005'

# Generated at 2022-06-20 12:33:33.115452
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=-1, hours=23, minutes=59, seconds=59, microseconds=999999)



# Generated at 2022-06-20 12:33:41.490380
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000123')) == \
                                                       '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:01.000123')) == \
                                                       '00:00:01.000001'
    assert timedelta_format(timedelta_parse('00:01:00.000123')) == \
                                                       '00:01:00.000001'
    assert timedelta_format(timedelta_parse('01:00:00.000123')) == \
                                                       '01:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.123456')) == \
                                                       '00:00:00.123456'

# Generated at 2022-06-20 12:33:50.214130
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:33:59.265073
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123)
    assert timedelta_parse('01:02:03.00123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123)
    assert timedelta_parse('01:02:03.0123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123)
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123)
    assert timedelta_parse('01:02:03.000001')

# Generated at 2022-06-20 12:34:07.862726
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5)) == \
        '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=12)) == \
        '00:12:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=13)) == \
        '00:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=14)) == \
        '00:00:00.000014'

# Generated at 2022-06-20 12:34:16.113304
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=9)) == \
           '00:00:09.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3601)) == \
           '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=90061)) == \
           '01:00:01.000000'

# Generated at 2022-06-20 12:34:25.332377
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) ==\
                                                                '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=123456)) == \
                                                                 '00:00:01.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == \
                                                                  '00:00:02.000000'

# Generated at 2022-06-20 12:34:29.705637
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000004') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)
    assert timedelta_parse('1:2:3.4') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)

# Generated at 2022-06-20 12:34:32.150614
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.000456') == \
           datetime_module.timedelta(hours=1, minutes=2,
                                     seconds=3, microseconds=456)

# Generated at 2022-06-20 12:34:41.304715
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                               '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                 '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                                 '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                                 '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
                                                                 '00:00:01.000000'
    assert timedelta_