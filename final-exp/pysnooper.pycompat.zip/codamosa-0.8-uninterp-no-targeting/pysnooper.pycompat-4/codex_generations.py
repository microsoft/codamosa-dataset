

# Generated at 2022-06-20 12:25:21.257139
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.max) == \
        '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta.min) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1)) == \
        '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'

# Generated at 2022-06-20 12:25:29.440215
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(0, 0, 123456)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:25:39.804141
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:02:03.004005')) == \
                                                   '01:02:03.004005'
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                                                   '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == \
                                                   '00:00:00.000001'
    assert timedelta_format(timedelta_parse('1:02:03.456789')) == \
                                                   '01:02:03.456789'

# Generated at 2022-06-20 12:25:47.483117
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 1e-6)
    assert timedelta_parse('0:0:1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )

# Generated at 2022-06-20 12:25:59.150865
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=42)) == '01:42:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1, minutes=-42)) == '-01:-42:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1, minutes=-42, seconds=1)) == '-01:-41:59.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=42, seconds=13, microseconds=999999)) == '01:42:13.999999'

# Generated at 2022-06-20 12:26:05.900242
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert datetime_module.timedelta(hours=1) == timedelta_parse('01:00:00.000000')
    assert datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4) == timedelta_parse('01:02:03.000004')
    assert datetime_module.timedelta(microseconds=123) == timedelta_parse('00:00:00.000123')

test_timedelta_parse()



# Generated at 2022-06-20 12:26:08.005435
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.001000') == datetime_module.timedelta(
        seconds=1, microseconds=1000,
    )


# Generated at 2022-06-20 12:26:20.396883
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:26:30.730248
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import json
    for timedelta in [
        datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                  microseconds=5),
        datetime_module.timedelta(days=5678, hours=12, minutes=34,
                                  seconds=56, microseconds=789),
        datetime_module.timedelta(days=-1, hours=-2, minutes=-3, seconds=-4,
                                  microseconds=-5),
        datetime_module.timedelta(days=-5678, hours=-12, minutes=-34,
                                  seconds=-56, microseconds=-789),
    ]:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))
    for _ in range(10000):
        timedelta = datetime_module.timedelta

# Generated at 2022-06-20 12:26:41.003237
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(days=1, hours=23))
    timedelta_format(datetime_module.timedelta(days=1, seconds=47222))
    timedelta_format(datetime_module.timedelta(days=1, microseconds=44444444))
    timedelta_format(datetime_module.timedelta())
    timedelta_format(datetime_module.timedelta(microseconds=1))
    timedelta_format(datetime_module.timedelta(microseconds=123456))
    timedelta_format(
        datetime_module.timedelta(days=1, seconds=47222, microseconds=123456)
    )



# Generated at 2022-06-20 12:26:55.829503
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        0, 1)
    assert timedelta_parse('00:00:01.100000') == datetime_module.timedelta(
        0, 1, 100000)
    assert timedelta_parse('00:00:01.100100') == datetime_module.timedelta(
        0, 1, 100100)
    assert timedelta_parse('00:01:00.100100') == datetime_module.timedelta(
        0, 60, 100100)

# Generated at 2022-06-20 12:27:05.644290
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3)) == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4000)) == '01:02:03.004000'
    assert timedelta_parse('01:02:00.000000') == datetime_module.timedelta(hours=1, minutes=2)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)

# Generated at 2022-06-20 12:27:07.964800
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(13, 37, 42, 123456))
    assert time == '13:37:42.123456'
    time = time_isoformat(datetime_module.time(0, 0, 0, 1))
    assert time == '00:00:00.000001'
    time = time_isoformat(datetime_module.time(23, 59, 59, 999999))
    assert time == '23:59:59.999999'



# Generated at 2022-06-20 12:27:13.527743
# Unit test for function timedelta_parse
def test_timedelta_parse():
    intervals = (
        '01:02:03.000004',
        '1:2:3.4',
        '0:0:0.4',
        '0:0:0.000004',
        '0:0:0.000000004',
        '0:0:0.00000000000004',
    )

# Generated at 2022-06-20 12:27:21.774429
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('13:14:15.161718') ==
            datetime_module.timedelta(hours=13, minutes=14, seconds=15,
                                      microseconds=161718))


if PY3:
    def get_function_name(function):
        return function.__qualname__.split('.<locals>', 1)[0]
else:
    def get_function_name(function):
        try:
            return function.__name__
        except AttributeError:
            return repr(function)

# Generated at 2022-06-20 12:27:30.825844
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=2))) == datetime_module.timedelta(seconds=2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)


if sys.version_info[:2] >= (3, 7):
    def datetime_format(date_time, timespec='milliseconds'):
        assert timespec == 'milliseconds'
        return date_time.isoformat

# Generated at 2022-06-20 12:27:33.064304
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:22:33.123456') == datetime_module.timedelta(
        hours=1, minutes=22, seconds=33, microseconds=123456
    )

# Generated at 2022-06-20 12:27:44.539797
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10000)) == '00:00:00.010000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:00.100000'
    assert timedelta_format

# Generated at 2022-06-20 12:27:55.054637
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45.678901')) == '01:23:45.678901'
    assert timedelta_format(timedelta_parse('.5')) == '00:00:00.500000'
    assert timedelta_format(timedelta_parse('.3')) == '00:00:00.300000'


if PY2:
    import functools

    class _cmp_helper(object):
        'Helper for rich comparison'
        __slots__ = ['obj']

        def __init__(self, obj):
            self.obj = obj

        def __eq__(self, other):
            return self.obj.__eq__(other.obj)

        def __ne__(self, other):
            return self.obj.__

# Generated at 2022-06-20 12:28:02.917231
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:28:26.900319
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'



# Generated at 2022-06-20 12:28:35.152243
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_td(timedelta, string):
        assert timedelta_format(timedelta) == string
        assert timedelta == timedelta_parse(string)
    assert_td(datetime_module.timedelta(seconds=0), '00:00:00.000000')
    assert_td(datetime_module.timedelta(seconds=0, microseconds=1),
              '00:00:00.000001')
    assert_td(datetime_module.timedelta(seconds=1), '00:00:01.000000')
    assert_td(datetime_module.timedelta(minutes=1), '00:01:00.000000')
    assert_td(datetime_module.timedelta(hours=1), '01:00:00.000000')

# Generated at 2022-06-20 12:28:46.090309
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000123') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123)
    assert timedelta_parse('03:01:02.012345') == \
           datetime_module.timedelta(hours=3, minutes=1, seconds=2,
                                     microseconds=12345)
    assert timedelta_parse('03:01:02.1234560') == \
           datetime_module.timedelta(hours=3, minutes=1, seconds=2,
                                     microseconds=123456)


try:
    from pathlib import Path
except ImportError:
    from pathlib2 import Path

# Generated at 2022-06-20 12:28:58.279800
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:15:30.000000') == datetime_module.timedelta(0, 15 * 60 + 30)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1e3)

# Generated at 2022-06-20 12:29:07.211190
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-20 12:29:18.463636
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=20,
                                                      seconds=30,
                                                      microseconds=123456)) == \
                                                      '10:20:30.123456'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=20,
                                                      seconds=30,
                                                      microseconds=125456)) == \
                                                      '10:20:30.125456'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=20,
                                                      seconds=30,
                                                      microseconds=12545)) == \
                                                      '10:20:30.012545'

# Generated at 2022-06-20 12:29:24.972058
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('08:23:57.846392', datetime_module.timedelta(8, 89837, 846392)),
        ('-13:47:20.000000', datetime_module.timedelta(-1, -83640)),
    ]
    for case in cases:
        assert timedelta_parse(case[0]) == case[1], case

# Generated at 2022-06-20 12:29:29.412601
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(seconds=1.23456)
    assert timedelta_format(delta) == '00:00:01.234560'
    assert timedelta_format(delta * 3) == '00:00:03.703680'


# Generated at 2022-06-20 12:29:36.800470
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-20 12:29:47.855023
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('0:00:00.000000') ==
            datetime_module.timedelta(seconds=0))
    assert (timedelta_parse('1:02:03.400000') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=400000))
    assert (timedelta_parse('1:02:03.000004') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=4))
    assert (timedelta_parse('1:02:03.400') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=400000))

# Generated at 2022-06-20 12:30:44.499965
# Unit test for function timedelta_format
def test_timedelta_format():
    s = '01:02:03.000000'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '01:02:03.123456'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '01:02:03.123456'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3.123456'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3.123456'
    assert timedelta_format(timedelta_parse(s)) == s

# Generated at 2022-06-20 12:30:54.883941
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:31:05.018840
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(
        timedelta_parse('1:02:03.004000')
    ) == '01:02:03.004000'
    assert timedelta_format(
        timedelta_parse('0:00:00.000001')
    ) == '00:00:00.000001'
    assert timedelta_format(
        timedelta_parse('0:00:00.000000')
    ) == '00:00:00.000000'
    assert timedelta_format(
        timedelta_parse('0:00:00.000010')
    ) == '00:00:00.000010'
    assert timedelta_format(
        timedelta_parse('0:00:00.007910')
    ) == '00:00:00.007910'

# Generated at 2022-06-20 12:31:15.718157
# Unit test for function timedelta_format

# Generated at 2022-06-20 12:31:18.911915
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, minutes=1,
                                          microseconds=1)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:31:23.978818
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(microseconds=1),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(minutes=1),
        datetime_module.timedelta(hours=1),
    ):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-20 12:31:29.797887
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        seconds=3, minutes=2, hours=1, microseconds=400000)
    assert timedelta_parse('10:20:30.405060') == datetime_module.timedelta(
        seconds=30, minutes=20, hours=10, microseconds=405060)



# Generated at 2022-06-20 12:31:40.970066
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1,
                                                      microseconds=1)) == \
           '01:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, seconds=1,
                                                      microseconds=1)) == \
           '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, seconds=0,
                                                      microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=3,
                                                      microseconds=4)) == \
           '02:00:03.000004'



# Generated at 2022-06-20 12:31:50.304670
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:10.123456') == (
        datetime_module.timedelta(hours=1, minutes=0, seconds=10,
                                  microseconds=123456))
    assert timedelta_parse('1000:00:10.123456') == (
        datetime_module.timedelta(hours=1000, minutes=0, seconds=10,
                                  microseconds=123456))
    assert timedelta_parse('1:1000:10.123456') == (
        datetime_module.timedelta(hours=1, minutes=1000, seconds=10,
                                  microseconds=123456))

# Generated at 2022-06-20 12:31:56.123089
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'


# Generated at 2022-06-20 12:34:02.919448
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )



# Generated at 2022-06-20 12:34:10.283593
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-20 12:34:18.753252
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_case
    test_case.assert_equal(timedelta_format(datetime_module.timedelta(0)),
                           '00:00:00.000000')
    test_case.assert_equal(timedelta_format(datetime_module.timedelta(
        milliseconds=1)), '00:00:00.001000')
    test_case.assert_equal(timedelta_format(datetime_module.timedelta(
        seconds=1)), '00:00:01.000000')
    test_case.assert_equal(timedelta_format(datetime_module.timedelta(
        minutes=1)), '00:01:00.000000')

# Generated at 2022-06-20 12:34:22.865939
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(seconds=1, microseconds=1),
        datetime_module.timedelta(microseconds=1),
    ):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:34:25.395917
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('9:12:15.234000') == (
        datetime_module.timedelta(hours=9, minutes=12, seconds=15,
                                  microseconds=234000))

# Generated at 2022-06-20 12:34:33.519657
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(hours=1,
                                                                        minutes=1,
                                                                        seconds=1,
                                                                        microseconds=1)
    assert timedelta_parse('1:1:1.000000') == datetime_module.timedelta(hours=1,
                                                                        minutes=1,
                                                                        seconds=1,
                                                                        microseconds=0)
    assert timedelta_parse('1:1:1.00') == datetime_module.timedelta(hours=1,
                                                                    minutes=1,
                                                                    seconds=1,
                                                                    microseconds=0)
    assert timedelta_parse('1:1:1.0') == datetime_module.timedelta

# Generated at 2022-06-20 12:34:39.999312
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 5, 1)) == '00:00:05.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'



# Generated at 2022-06-20 12:34:42.841789
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=2,
                                                      seconds=23,
                                                      microseconds=124124)) \
           == '04:02:23.124124'


# Generated at 2022-06-20 12:34:45.518009
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('16:03:31.527086') == (
        datetime_module.timedelta(hours=16, minutes=3, seconds=31,
                                  microseconds=527086)
    )



# Generated at 2022-06-20 12:34:52.256765
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                               '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                               '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                               '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                               '01:00:00.000000'

