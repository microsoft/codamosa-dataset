

# Generated at 2022-06-20 12:25:19.779714
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in [
        datetime_module.timedelta(0),
        datetime_module.timedelta(hours=1),
        datetime_module.timedelta(minutes=1),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(milliseconds=1),
        datetime_module.timedelta(microseconds=1),
    ]:
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-20 12:25:28.687825
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.100000') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:1.0') == datetime_module.timedelta(
        minutes=1, seconds=1
    )
    assert timedelta_parse('1:1:1.0') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1
    )
    assert timedelta_parse('1:1:1') == datetime

# Generated at 2022-06-20 12:25:38.200820
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:15:30.123') == datetime_module.timedelta(
        minutes=15, seconds=30, microseconds=123
    )
    assert timedelta_parse('0:15:30.123000') == datetime_module.timedelta(
        minutes=15, seconds=30, microseconds=123
    )
    assert timedelta_parse('0:15:30.0123') == datetime_module.timedelta(
        minutes=15, seconds=30, microseconds=123
    )
    assert timedelta_parse('0:15:30.00123') == datetime_module.timedelta(
        minutes=15, seconds=30, microseconds=123
    )
    assert timedelta_parse('0:15:30.000123') == datetime_module.timed

# Generated at 2022-06-20 12:25:46.870622
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('00:00:00.000000')
            == timedelta_parse('00:00:00.000000'))

    assert (timedelta_parse('00:00:00.000001')
            == timedelta_parse('00:00:00.000001'))

    assert (timedelta_parse('00:00:00.000010')
            == timedelta_parse('00:00:00.000010'))

    assert (timedelta_parse('01:02:03.000001')
            == timedelta_parse('1:2:3.1'))

    assert (timedelta_parse('01:02:03.000001')
            == timedelta_parse('1:2:3.1'))


# Generated at 2022-06-20 12:25:52.404479
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5)
    format_string = timedelta_format(timedelta)
    assert format_string == '02:03:04.000005'



# Generated at 2022-06-20 12:26:01.712905
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:05.400000') == datetime_module.timedelta(
        seconds=5, microseconds=400000
    )
    assert timedelta_parse('10:20:30.123456') == datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=123456
    )
    assert timedelta_parse('00:30:01.001001') == datetime_module.timedelta(
        minutes=30, seconds=1, microseconds=100
    )
    assert timedelta_parse('00:00:00.050000') == datetime_module.timedelta(
        microseconds=50
    )

# Generated at 2022-06-20 12:26:05.122500
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(milliseconds=124, microseconds=342,
                                          minutes=3, seconds=3)
    assert timedelta_format(timedelta) == '03:03:03.124342'


# Generated at 2022-06-20 12:26:12.296689
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(seconds=0, microseconds=100000)
    assert timedelta_parse('0:0:0.01') == datetime_module.timedelta(seconds=0, microseconds=10000)
    assert timedelta_parse('0:0:0.001') == datetime_module.timedelta(seconds=0, microseconds=1000)
    assert timedelta_parse('0:0:0.0001') == datetime_module.timedelta(seconds=0, microseconds=100)
    assert timedelta_parse('0:0:0.00001') == datetime_module.timedelta(seconds=0, microseconds=10)

# Generated at 2022-06-20 12:26:18.450793
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=5, hours=5, minutes=5, seconds=5,
                                   microseconds=5)
    assert timedelta_format(td) == '05:05:05.000005'
    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-20 12:26:28.754388
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=123456)

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta()
    )) == datetime_module.timedelta()

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3)


# Generated at 2022-06-20 12:26:43.550260
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('3:05:06.896565')
    assert timedelta.days == 0
    assert timedelta.seconds == 3 * 3600 + 5 * 60 + 6
    assert timedelta.microseconds == 896565

# Generated at 2022-06-20 12:26:52.969332
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:10.900000') == datetime_module.timedelta(
        seconds=10, microseconds=900000)
    assert timedelta_parse('01:30:00.000000') == datetime_module.timedelta(
        hours=1, minutes=30)
    assert timedelta_parse('01:30:10.000000') == datetime_module.timedelta(
        hours=1, minutes=30, seconds=10)
    assert timedelta_parse('01:30:10.900000') == datetime_module.timedelta(
        hours=1, minutes=30, seconds=10,
        microseconds=900000)

# Generated at 2022-06-20 12:26:56.111133
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=1)) == \
        '01:02:03.000001'

# Generated at 2022-06-20 12:27:06.218079
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                            '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
                                                            '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == \
                                                            '00:00:00.001000'
    assert timedelta_format(timedelta_parse('00:00:00.010000')) == \
                                                            '00:00:00.010000'

# Generated at 2022-06-20 12:27:14.367230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:00:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(0)
    s = '00:00:00.000001'
    assert timedelta_parse(s) == datetime_module.timedelta(microseconds=1)
    s = '00:00:00.999999'
    assert timedelta_parse(s) == datetime_module.timedelta(microseconds=999999)
    s = '00:00:01.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(seconds=1)
    s = '00:01:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-20 12:27:25.098889
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(seconds=1, microseconds=999999)
    assert timedelta_parse('00:01:01.999999') == datetime_module.timedelta(minutes=1, seconds=1, microseconds=999999)
    assert timedelta_parse('01:01:01.999999') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=999999)

test_timedelta_parse()

# Generated at 2022-06-20 12:27:33.275027
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(microseconds=100001)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(hours=1, microseconds=1)

# Generated at 2022-06-20 12:27:39.358441
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123000
    )
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123000
    )

# Generated at 2022-06-20 12:27:49.925390
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == \
           '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1.5)) == \
           '00:01:30.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1.5))

# Generated at 2022-06-20 12:27:56.556589
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-1:23:45.0011111') == \
           datetime_module.timedelta(hours=-1, minutes=23,
                                     seconds=45, microseconds=11111)


try:
    from contextlib import AsyncExitStack, asynccontextmanager
except ImportError:
    # Monkey patching `contextlib` with stubs
    AsyncExitStack = type(None)

    def asynccontextmanager(func):
        return func

# Generated at 2022-06-20 12:28:19.178374
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:05:13.113113') == datetime_module.timedelta(
        hours=1,
        minutes=5,
        seconds=13,
        microseconds=113113
    )
    assert timedelta_parse('1:05:13.113113') == datetime_module.timedelta(
        hours=1,
        minutes=5,
        seconds=13,
        microseconds=113113
    )
    assert timedelta_parse('2:05:33.113311') == timedelta_parse(
        '2:05:33.113311'
    )
    assert timedelta_parse('2:05:33.113311') == timedelta_

# Generated at 2022-06-20 12:28:29.178622
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
                                                 '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                 '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=1
    )) == '00:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'

# Generated at 2022-06-20 12:28:36.250006
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)

# Generated at 2022-06-20 12:28:45.638886
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3600)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 1000)) == '00:00:01.001000'


# Generated at 2022-06-20 12:28:51.660437
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789,
    )
    assert timedelta_parse('01:02:03.006789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=6789,
    )
    assert timedelta_parse('01:02:00.600789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=0, microseconds=600789,
    )
    assert timedelta_parse('01:02:00.600000') == dat

# Generated at 2022-06-20 12:28:57.350851
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(hours=1,
                                                minutes=2, seconds=3)
    assert timedelta_parse('1:2:3.456') == datetime_module.timedelta(
                                                    hours=1, minutes=2,
                                                    seconds=3,
                                                    microseconds=456000)

# Generated at 2022-06-20 12:29:06.430895
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.010101') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10101)

    assert timedelta_parse('1:01:01.0101011') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10101)

    assert timedelta_parse('1:01:01.010101001') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10101)


# Generated at 2022-06-20 12:29:09.637966
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import testing_tools
    sum(map(lambda: timedelta_format(testing_tools.random_timedelta()),
            range(10000)))

# Generated at 2022-06-20 12:29:20.519903
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime

    assert timedelta_format(datetime.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime.timedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(datetime.timedelta(seconds=15)) == '00:00:15.000000'
    assert timedelta_format(datetime.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime.timedelta(seconds=3600)) == '01:00:00.000000'
    assert timedelta_format(datetime.timedelta(seconds=3660)) == '01:01:00.000000'

# Generated at 2022-06-20 12:29:31.102564
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-20 12:29:54.152095
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == timedelta_format(datetime_module.timedelta(
        hours=25, minutes=2, seconds=3, microseconds=4
    )) == timedelta_format(datetime_module.timedelta(
        seconds=3723, microseconds=4
    )) == timedelta_format(datetime_module.timedelta(
        microseconds=3723004
    )) == '01:02:03.004004'

# Generated at 2022-06-20 12:30:03.825410
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('1:01:00.000000') == datetime_module.timedelta(
        hours=1, minutes=1
    )
    assert timedelta_parse('1:00:01.000000') == datetime_module.timedelta(
        hours=1, seconds=1
    )
    assert timedelta_parse('1:00:00.100000') == datetime_module.timedelta(
        hours=1, microseconds=100000
    )

# Generated at 2022-06-20 12:30:11.730706
# Unit test for function timedelta_parse
def test_timedelta_parse():

    """
    This function tests that `timedelta_parse` and `timedelta_format` are
    inverses.
    """
    #
    import random
    random = random._inst
    assert isinstance(random.random(), float)
    for _ in range(1000):

        seconds = random.random() * 1234567
        timedelta = datetime_module.timedelta(seconds=seconds)

        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-20 12:30:13.951341
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:02:03.004000') == \
           datetime_module.timedelta(seconds=123, microseconds=4000)

# Generated at 2022-06-20 12:30:17.149498
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('01:00:03.123456') ==
            datetime_module.timedelta(hours=1, minutes=0, seconds=3,
                                      microseconds=123456))



# Generated at 2022-06-20 12:30:24.695461
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                                                hours=1,
                                                minutes=2,
                                                seconds=3,
                                                microseconds=4))) == \
           datetime_module.timedelta(hours=1,
                                     minutes=2,
                                     seconds=3,
                                     microseconds=4)

# Generated at 2022-06-20 12:30:36.038818
# Unit test for function timedelta_format
def test_timedelta_format():
    zero = datetime_module.timedelta(seconds=0)
    one = datetime_module.timedelta(seconds=1)
    two = datetime_module.timedelta(seconds=2)
    three = datetime_module.timedelta(seconds=3)
    four = datetime_module.timedelta(seconds=4)
    five = datetime_module.timedelta(seconds=5)
    six = datetime_module.timedelta(seconds=6)
    seven = datetime_module.timedelta(seconds=7)
    eight = datetime_module.timedelta(seconds=8)
    nine = datetime_module.timedelta(seconds=9)


    assert timedelta_format(zero) == '00:00:00.000000'

# Generated at 2022-06-20 12:30:43.629279
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4,
    )
    assert timedelta_parse('02:03.004000') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=0, microseconds=4,
    )
    assert timedelta_parse('03.004000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=3, microseconds=4,
    )


# Generated at 2022-06-20 12:30:49.524874
# Unit test for function timedelta_parse
def test_timedelta_parse():
    microseconds = 123456
    assert timedelta_parse('0:0:0.{}'.format(microseconds)) == (
        datetime_module.timedelta(microseconds=microseconds))
    assert timedelta_parse('0:0:0.{}'.format(str(microseconds).zfill(6))) == (
        datetime_module.timedelta(microseconds=microseconds))
    assert timedelta_parse('0:0:0.{}'.format(str(microseconds))) == (
        datetime_module.timedelta(microseconds=microseconds))

    seconds = 123
    assert timedelta_parse('0:0:{}'.format(seconds)) == (
        datetime_module.timedelta(seconds=seconds))

# Generated at 2022-06-20 12:30:53.565824
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:01:02.000001'
    timedelta = timedelta_parse(s)
    assert (timedelta.seconds == 62 and timedelta.microseconds == 1)

test_timedelta_parse()

# Generated at 2022-06-20 12:31:11.623507
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=2,
        minutes=45,
        seconds=3,
        microseconds=123456
    )
    assert timedelta_format(timedelta).split('.')[0] == '02:45:03'
    assert timedelta_format(timedelta).split('.')[-1][:6] == '123456'



# Generated at 2022-06-20 12:31:22.383546
# Unit test for function timedelta_parse

# Generated at 2022-06-20 12:31:27.908516
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)

# Generated at 2022-06-20 12:31:30.342862
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=1,
                                                  seconds=2.3)) == \
           '03:01:02.300000'



# Generated at 2022-06-20 12:31:41.573531
# Unit test for function timedelta_format
def test_timedelta_format():
    """Unit test for function timedelta_format."""
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'


# Generated at 2022-06-20 12:31:46.995682
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      seconds=35,
                                                      microseconds=999999))\
           == '03:00:35.999999'



# Generated at 2022-06-20 12:31:56.155637
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-20 12:32:05.716821
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
    '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
    '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
    '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
    '00:00:00.000001'

# Generated at 2022-06-20 12:32:08.832323
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=11,
                                             seconds=12,
                                             microseconds=123456)) == \
           '10:11:12.123456'



# Generated at 2022-06-20 12:32:18.361618
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
           timedelta_format(datetime_module.timedelta(days=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_

# Generated at 2022-06-20 12:33:03.984779
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=2,
                                                      seconds=3,
                                                      microseconds=45678)) == \
                                                      '04:02:03.045678'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=5)) == \
                                                      '00:00:00.000005'

# Generated at 2022-06-20 12:33:13.494775
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('0:00:00.123400')
    assert timedelta.microseconds == 123400
    assert timedelta.seconds == 0
    assert timedelta.minutes == 0
    assert timedelta.hours == 0

    timedelta = timedelta_parse('0:23:00.123400')
    assert timedelta.microseconds == 123400
    assert timedelta.seconds == 0
    assert timedelta.minutes == 23
    assert timedelta.hours == 0

    timedelta = timedelta_parse('4:23:00.123400')
    assert timedelta.microseconds == 123400
    assert timedelta.seconds == 0
    assert timedelta.minutes == 23
    assert timedelta.hours == 4

    timedelta = timedelta_parse('4:23:15.123400')

# Generated at 2022-06-20 12:33:20.142054
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                                '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.111111)) == \
                                                              '00:00:01.111111'
    assert timedelta_format(datetime_module.timedelta(microseconds=111111)) \
                                                                == '00:00:00.111111'
    assert timedelta_format(datetime_module.timedelta(hours=4)) == \
                                                                    '04:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=30)) \
                                                                == '04:30:00.000000'

# Generated at 2022-06-20 12:33:31.019806
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.00011') == datetime_module.timedelta(
        microseconds=11)
    assert timedelta_parse('00:00:00.11') == datetime_module.timedelta(
        microseconds=110)
    assert timedelta_parse('00:00:01.11') == datetime_module.timedelta(
        seconds=1, microseconds=110)
    assert timedelta_parse('00:01:01.11') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=110)
    assert timedelta_parse('01:01:01.11') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=110)

# Generated at 2022-06-20 12:33:37.102355
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('02:03:04.056789')) == \
           '02:03:04.056789'


if not PY3:
    def open(filename, *args, **kwargs):
        '''Drop the `encoding` argument from Python 2.'''
        kwargs.pop('encoding', None)
        return __builtins__['open'](filename, *args, **kwargs)
else:
    open = __builtins__['open']

# Generated at 2022-06-20 12:33:45.203958
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) == \
                                                      '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=1,
                                                      microseconds=1)) == \
                                                      '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
                                                      '01:01:01.000001'

# Generated at 2022-06-20 12:33:48.537146
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=7, minutes=8, seconds=9,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '07:08:09.123456'



# Generated at 2022-06-20 12:33:55.285024
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000045') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=45
    )
    assert timedelta_parse('2:0:0.200000') == datetime_module.timedelta(
        hours=2, minutes=0, seconds=0, microseconds=200000
    )
    assert timedelta_parse('3:0:0') == datetime_module.timedelta(
        hours=3, minutes=0, seconds=0, microseconds=0
    )



# Generated at 2022-06-20 12:34:03.788935
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(hours=1, microseconds=1)
    assert timedelta_parse('01:00:00.999999') == datetime_module.timedelta(hours=1, microseconds=999999)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(hours=1, seconds=1)
    assert timedelta_parse('01:01:00.000000') == datetime_module.timedelta(hours=1, minutes=1)

# Generated at 2022-06-20 12:34:10.767766
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta()) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-20 12:34:49.209311
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_format(t) == '24:00:01.000001'

# Generated at 2022-06-20 12:34:53.861318
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:34:56.789012') == \
           datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                     microseconds=789012)

# Generated at 2022-06-20 12:34:57.973066
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2.5)) == '02:30:00.000000'


# Generated at 2022-06-20 12:35:05.158364
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in [datetime_module.timedelta(hours=0, minutes=0,
                                                seconds=0,
                                                microseconds=0),
                      datetime_module.timedelta(hours=1, minutes=2,
                                                seconds=3,
                                                microseconds=40000),
                      datetime_module.timedelta(hours=1, minutes=2,
                                                seconds=3,
                                                microseconds=99999),
    ]:
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta