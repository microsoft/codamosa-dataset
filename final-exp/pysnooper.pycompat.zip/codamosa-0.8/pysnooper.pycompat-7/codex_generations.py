

# Generated at 2022-06-10 21:32:50.887126
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_parse_true(a, b):
        assert timedelta_parse(a) == b

    assert_timedelta_parse_true('1:2:3.4', timedelta_parse('1:2:3.4'))
    assert_timedelta_parse_true('0:0:0.0', timedelta_parse('0:0:0.0'))
    assert_timedelta_parse_true('0:0:1.123', timedelta_parse('0:0:1.123'))
    assert_timedelta_parse_true('1:1:1.123', timedelta_parse('1:1:1.123'))

# Generated at 2022-06-10 21:32:59.441575
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        ('00:00:00.000000', datetime_module.timedelta(seconds=0)),
        ('00:01:00.000000', datetime_module.timedelta(seconds=60)),
        ('00:01:01.000000', datetime_module.timedelta(seconds=61)),
        ('-00:01:00.000000', datetime_module.timedelta(seconds=-60)),
        ('-00:01:01.000000', datetime_module.timedelta(seconds=-61)),
        ('00:00:00.000001', datetime_module.timedelta(microseconds=1)),
        ('-00:00:00.000001', datetime_module.timedelta(microseconds=-1)),
    ]
    for string, expected_timedelta in cases:
        assert timed

# Generated at 2022-06-10 21:33:09.056195
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0:0.123456')) == '00:00:00.123456'
    assert timedelta_format(timedelta_parse('0:0:5.000000')) == '00:00:05.000000'
    assert timedelta_format(timedelta_parse('0:0:60.000000')) == '00:01:00.000000'

# Generated at 2022-06-10 21:33:10.491266
# Unit test for function timedelta_format
def test_timedelta_format():
     assert timedelta_format(datetime_module.timedelta(
         hours=1, minutes=2, seconds=3, microseconds=456789
     )) == '01:02:03.456789'



# Generated at 2022-06-10 21:33:16.123382
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (
        datetime_module.timedelta(days=0, seconds=10,
                                  microseconds=123456),
        datetime_module.timedelta(days=365, seconds=60 * 60 * 24 * 365,
                                  microseconds=123456),
        datetime_module.timedelta(seconds=1, microseconds=100),
        datetime_module.timedelta(microseconds=100),
    ):
        td = timedelta_parse(timedelta_format(timedelta))
        assert timedelta == td


# Generated at 2022-06-10 21:33:22.529139
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )
    assert timedelta_parse('1:1:1.000001') == timedelta_parse('01:01:01.000001')
    assert timedelta_parse('1:1:1.000001') == timedelta_parse('1:01:01.000001')

# Generated at 2022-06-10 21:33:25.902834
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1,
                                                               hours=1,
                                                               minutes=2,
                                                               seconds=3,
                                                               microseconds=4567))) == datetime_module.timedelta(days=1,
                                                                                                         hours=1,
                                                                                                         minutes=2,
                                                                                                         seconds=3,
                                                                                                         microseconds=4567)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=4567))) == datetime_module.timedelta(microseconds=4567)

# Generated at 2022-06-10 21:33:34.413092
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('01:02:03.000100') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100
    )
    assert timedelta_parse('01:02:03.001000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1000
    )
    assert timedelta_parse('01:02:03.010000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=10000
    )

# Generated at 2022-06-10 21:33:45.283275
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1:0:0.000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('1:1:0.000000')) == '01:01:00.000000'
    assert timedelta_format(timedelta_parse('1:1:1.000000')) == '01:01:01.000000'
    assert timedelta_format(timedelta_parse('1:1:1.1')) == '01:01:01.100000'
    assert timedelta_format(timedelta_parse('11:1:1.1')) == '11:01:01.100000'

# Generated at 2022-06-10 21:33:54.374263
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == \
           '01:00:01.000000'

# Generated at 2022-06-10 21:34:06.356006
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                         '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                         '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                         '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                         '01:00:00.000000'



# Generated at 2022-06-10 21:34:09.247547
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=100000)


# Generated at 2022-06-10 21:34:20.795791
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=456)) == '01:02:03.004560'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=123456)) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=4567)) == '00:00:00.004567'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=123)) == '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=100)) == '00:00:00.000100'

# Generated at 2022-06-10 21:34:27.080653
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:34:38.257895
# Unit test for function timedelta_format
def test_timedelta_format():

    dt = timedelta_parse('00:00:00.000000')
    assert timedelta_format(dt) == '00:00:00.000000'

    dt = timedelta_parse('09:08:07.123456')
    assert timedelta_format(dt) == '09:08:07.123456'

    dt = timedelta_parse('23:55:59.999999')
    assert timedelta_format(dt) == '23:55:59.999999'

    dt = timedelta_parse('24:00:00.000000')
    assert timedelta_format(dt) == '00:00:00.000000'

    dt = timedelta_parse('25:00:00.000000')
    assert timedelta_format(dt) == '01:00:00.000000'

    dt = timed

# Generated at 2022-06-10 21:34:49.351455
# Unit test for function timedelta_parse
def test_timedelta_parse():
    input_output_pairs = (
        ('1:30:00.000000', datetime_module.timedelta(hours=1, minutes=30)),
        ('1:30:00.2000000', datetime_module.timedelta(hours=1, minutes=30,
                                                      milliseconds=200)),
        ('1:30:00.123456', datetime_module.timedelta(hours=1, minutes=30,
                                                     microseconds=123456)),
        ('00:01:30.1234567890', datetime_module.timedelta(minutes=1,
                                                          seconds=30,
                                                          microseconds=123456)),
    )
    for input, output in input_output_pairs:
        assert timedelta_parse(input) == output

# Generated at 2022-06-10 21:34:53.948727
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('15:42:37.123456') == datetime_module.timedelta(
        hours=15, minutes=42, seconds=37, microseconds=123456)



# Generated at 2022-06-10 21:35:07.709842
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=100)) == \
           '00:01:40.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1000)) == \
           '00:16:40.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10000)) == \
           '02:46:40.000000'

# Generated at 2022-06-10 21:35:11.271706
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=392,
                                                      seconds=17051,
                                                      minutes=36,
                                                      microseconds=250)) \
           == '10:36:51.00250'



# Generated at 2022-06-10 21:35:23.317077
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:35:56.353699
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('-00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('-00:00:00.000001') == datetime_module.timedelta(0, 0, -1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)

# Generated at 2022-06-10 21:36:08.117334
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                              '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1,
                                                      microseconds=1)) == \
                                                              '00:00:01.000001'



# Generated at 2022-06-10 21:36:16.875893
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.123456') == datetime_module.timedelta(
        hours=1,
        seconds=0,
        milliseconds=123,
        microseconds=456,
    )
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(
        seconds=0,
        milliseconds=123,
        microseconds=456,
    )
    assert timedelta_parse('0:00:00.012345') == datetime_module.timedelta(
        seconds=0,
        milliseconds=12,
        microseconds=345,
    )

# Generated at 2022-06-10 21:36:21.469322
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=23, minutes=28, seconds=44,
                                          microseconds=123123)
    assert timedelta_format(timedelta) == '23:28:44.123123'


# Generated at 2022-06-10 21:36:30.887422
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'



# Generated at 2022-06-10 21:36:39.860237
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:22:33.000000') == datetime_module.timedelta(
        hours=1, minutes=22, seconds=33
    )
    assert timedelta_parse('02:34:56.654654') == datetime_module.timedelta(
        hours=2, minutes=34, seconds=56, microseconds=654654
    )


import functools

if hasattr(functools, 'lru_cache'):
    lru_cache = functools.lru_cache

# Generated at 2022-06-10 21:36:52.094710
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45:678901')) == \
           '01:23:45.678901'
    assert timedelta_format(timedelta_parse('1:23:45:678901.2')) == \
           '01:23:45.678901'
    assert timedelta_format(timedelta_parse('1:23:45:678901.234567')) == \
           '01:23:45.678901'
    assert timedelta_format(timedelta_parse('1:23:45:678901.2345678')) == \
           '01:23:45.678901'
    assert timedelta_format(timedelta_parse('1:23:45:678901.23456789'))

# Generated at 2022-06-10 21:37:02.440701
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000,
    )
    assert timedelta_parse('1:1:1.123') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123000,
    )


# Generated at 2022-06-10 21:37:05.502488
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1.11:12:13.141516')) == \
           '01:11:12.141516'



# Generated at 2022-06-10 21:37:11.467050
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_ = timedelta_parse('12:30:22.123456')
    expected = datetime_module.timedelta(hours=12, minutes=30, seconds=22,
                                         microseconds=123456)
    assert timedelta_ == expected, timedelta_
    assert timedelta_format(timedelta_) == '12:30:22.123456'

test_timedelta_parse()

# Generated at 2022-06-10 21:38:11.162638
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.01') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('0:00:00.99') == datetime_module.timedelta(0, 0, 99000)
    assert timedelta_parse('0:00:01.00') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:00:09.99') == datetime_module.timedelta(0, 9, 990000)
    assert timedelta_parse('0:00:59.99') == datetime_module.timedelta(0, 59, 990000)


# Generated at 2022-06-10 21:38:23.780000
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:01.100000') == datetime_module.timedelta(
        milliseconds=100)

# Generated at 2022-06-10 21:38:31.411457
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing_tools import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(0)), '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(hours=6)), '06:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=38)), '00:38:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=23)), '00:00:23.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(milliseconds=160)), '00:00:00.160000')



# Generated at 2022-06-10 21:38:39.733653
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('05:34:21.123456') == (
        datetime_module.timedelta(hours=5, minutes=34, seconds=21,
                                  microseconds=123456))
    assert timedelta_parse('15:05:34:21.123456') == (
        datetime_module.timedelta(hours=15, minutes=5, seconds=34,
                                  microseconds=21123456))



# Generated at 2022-06-10 21:38:44.584583
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=12, seconds=3,
                                  microseconds=456789)
    ) == '01:12:03.045678'



# Generated at 2022-06-10 21:38:55.806106
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456)
    assert timedelta_parse(timedelta_format(td)) == td
    assert timedelta_parse('1:02:03.123456') == td


if PY3:
    long = int
    unicode = str
    basestring = str


if PY3:
    import urllib.parse
    urlencode = urllib.parse.urlencode
    quote = urllib.parse.quote
    unquote = urllib.parse.unquote
else:
    import urllib
    urlencode = urllib.urlencode
    quote = urllib.quote
    unquote = urllib.unquote



# Generated at 2022-06-10 21:39:06.590995
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    )
    assert timedelta_parse('00:00:00.000000') == (
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=0)
    )
    assert timedelta_parse('00:00:00.000001') == (
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=1)
    )

# Generated at 2022-06-10 21:39:13.100179
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901
    )
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )

    try:
        timedelta_parse('1:23:45.6789012')
    except ValueError:
        pass
    else:
        assert False, 'Should have raised ValueError'


# Generated at 2022-06-10 21:39:23.951379
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                 seconds=3,
                                                 microseconds=1234)) == \
                                                 '01:02:03.001234'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1,
                                                                  minutes=2,
                                                                  seconds=3,
                                                                  microseconds=1234
                                                                  ))) == \
                                                                  datetime_module.timedelta(hours=1,
                                                                                       minutes=2,
                                                                                       seconds=3,
                                                                                       microseconds=1234
                                                                                       )

# Generated at 2022-06-10 21:39:34.837080
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:41:21.658225
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-10 21:41:29.954157
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.456789') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)
    assert timedelta_parse('01:02:03.456789') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)
    assert timedelta_parse('01:02:03.4567') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456700)

# Generated at 2022-06-10 21:41:35.302471
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=10,
                                          minutes=11,
                                          seconds=12,
                                          microseconds=131415)
    assert timedelta_format(timedelta) == '10:11:12.131415'



# Generated at 2022-06-10 21:41:37.877043
# Unit test for function timedelta_format
def test_timedelta_format():
    print(timedelta_format(datetime_module.timedelta(seconds=60)))


# Generated at 2022-06-10 21:41:45.196100
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # If this unit test fails, there's a bug in timedelta_parse.
    # This test also makes sure that timedelta_parse is correct, because of
    # the round-trip.
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4))) == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)

# Generated at 2022-06-10 21:41:53.297255
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == '00:00:01.100000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3.3)) == '01:02:03.300000'


# Generated at 2022-06-10 21:42:02.410725
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)

# Generated at 2022-06-10 21:42:05.246966
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(hours=1,
                                                                           minutes=2,
                                                                           seconds=3,
                                                                           microseconds=1)

# Generated at 2022-06-10 21:42:12.078057
# Unit test for function timedelta_format
def test_timedelta_format():
    the_timedelta = datetime_module.timedelta(days=3, hours=14, minutes=37,
                                              seconds=50, microseconds=60000)
    assert timedelta_format(the_timedelta) == '14:37:50.060000'
    assert timedelta_parse(timedelta_format(the_timedelta)) == \
           the_timedelta


if PY3:
    from urllib.parse import urlparse
else:
    from urlparse import urlparse

# Generated at 2022-06-10 21:42:21.194568
# Unit test for function timedelta_format
def test_timedelta_format():
    def do(timedelta):
        time = (datetime_module.datetime.min + timedelta).time()
        return time.isoformat(timespec='microseconds')
    timedelta_format_truth = do # for putting in `assert`