

# Generated at 2022-06-10 21:32:49.136470
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:32:53.948337
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(12, 34, 56, 7890))
    assert time == '12:34:56.007890'
    assert time_isoformat(datetime_module.time(12, 34, 56, 7890),
                          timespec='microseconds') == '12:34:56.007890'
    try:
        time_isoformat(datetime_module.time(12, 34, 56, 7890),
                       timespec='blabla')
    except NotImplementedError:
        pass
    else:
        assert False

# Generated at 2022-06-10 21:32:58.585684
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # `timedelta_parse` should be the inverse of `timedelta_format`:
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5, minutes=3, seconds=2, microseconds=34
    ))) == datetime_module.timedelta(hours=5, minutes=3, seconds=2,
                                     microseconds=34)

# Generated at 2022-06-10 21:33:09.046214
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:33:12.067812
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3,
                                                                   microseconds=4)



# Generated at 2022-06-10 21:33:14.738357
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-10 21:33:18.641752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:01:02.034567')
    assert timedelta.total_seconds() == 62.034567
    timedelta = timedelta_parse('00:01:02')
    assert timedelta.total_seconds() == 62

# Generated at 2022-06-10 21:33:25.296178
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)



# Generated at 2022-06-10 21:33:34.058439
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) ==\
                                                               datetime_module.timedelta(0)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) ==\
                                                               datetime_module.timedelta(1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, -1))) ==\
                                                               datetime_module.timedelta(0, -1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, -1, -1))) ==\
                                                               datetime_module.timedelta(0, -1, -1)


# Generated at 2022-06-10 21:33:39.061261
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=56, seconds=5,
                                                      microseconds=69)) == \
           '05:56:05.000069'



# Generated at 2022-06-10 21:33:54.110428
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=23, minutes=13, seconds=57, microseconds=12345
    ))) == (datetime_module.timedelta(
        days=1, hours=23, minutes=13, seconds=57, microseconds=12345
    ))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=1
    ))) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=1000000
    ))) == datetime_module.timedelta(microseconds=1000000)

# Generated at 2022-06-10 21:34:05.104000
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )


if PY2:
    import io
    StringIO = io.BytesIO
    StringIO_LineWrapper = io.BytesIO
else:
    import io
    StringIO = io.StringIO
    StringIO_LineWrapper = io.BytesIO


if PY2:
    get_inf = float('inf')
else:
    get_inf = float('inf')


if PY2:
    def get_next(iterator):
        return iterator.next()

# Generated at 2022-06-10 21:34:09.808868
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '123:34:48.989898'
    assert timedelta_parse(s) == datetime_module.timedelta(days=123,
                                                            hours=34,
                                                            minutes=48,
                                                            seconds=48,
                                                            microseconds=989898)
test_timedelta_parse()




# Generated at 2022-06-10 21:34:21.399488
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_parse('1:2:3.40') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_parse('1:2:3.400000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)

# Generated at 2022-06-10 21:34:27.438919
# Unit test for function timedelta_format
def test_timedelta_format():
    from python_toolbox import math_tools

    for arg in math_tools.get_chunks(
        datetime_module.timedelta(0),
        datetime_module.timedelta(days=1),
        datetime_module.timedelta(minutes=1),
    ):
        assert timedelta_parse(timedelta_format(arg)) == arg

# Generated at 2022-06-10 21:34:35.228007
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=-1, minutes=-1, seconds=-1, microseconds=-1
    )) == '-01:-01:-01.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'



# Generated at 2022-06-10 21:34:42.406427
# Unit test for function timedelta_format
def test_timedelta_format():
    """Unit test for function `timedelta_format`."""

    from .test_timing import run_test_timing
    from .test_timing import TestCases

    def func(timedelta):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

    for argument, number in TestCases.items():
        run_test_timing(func, argument, number=number, name='timedelta_format')



# Generated at 2022-06-10 21:34:52.423610
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta_seconds in (1, 2, 3, 4, 5, 6, 10, 100, 1000, 1100, 100000,
                              1000000, 2000000, 10000000, 100000000, 1000000000,
                              10000000000, 100000000000, 1000000000000,
                              10000000000000, 1000000000000000):
        assert timedelta_format(
            datetime_module.timedelta(seconds=timedelta_seconds)
        ) == timedelta_format(
            (datetime_module.datetime.min +
             datetime_module.timedelta(seconds=timedelta_seconds)).time()
        )

# Generated at 2022-06-10 21:35:07.058267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == \
                                                          '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:1.000000')) == \
                                                          '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:1:1.000000')) == \
                                                          '00:01:01.000000'
    assert timedelta_format(timedelta_parse('1:1:1.000000')) == \
                                                          '01:01:01.000000'
    assert timedelta_format(timedelta_parse('0:0:0.000123')) == \
                                                          '00:00:00.000123'

# Generated at 2022-06-10 21:35:10.222468
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)



# Generated at 2022-06-10 21:35:32.818650
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == (
        '00:00:00.000010'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == (
        '00:00:00.000100'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == (
        '00:00:00.001000'
    )
    assert timedelta_format

# Generated at 2022-06-10 21:35:38.791179
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(0),
                      datetime_module.timedelta(milliseconds=1),
                      datetime_module.timedelta(microseconds=1),
                      datetime_module.timedelta(hours=1),
                      datetime_module.timedelta(hours=100, minutes=100,
                                                seconds=100,
                                                microseconds=100)):
        time = (datetime_module.datetime.min + timedelta).time()
        assert timedelta_format(timedelta) == time_isoformat(time,
                                                             timespec='microseconds')


# Generated at 2022-06-10 21:35:44.939764
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=30,
                                                      seconds=30)) == \
                                                time_isoformat(
        datetime_module.time(3, 30, 30), timespec='microseconds')



# Generated at 2022-06-10 21:35:53.444288
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-10 21:36:02.709243
# Unit test for function timedelta_format
def test_timedelta_format():
    data = [
        (1, '00:00:00.000001'),
        (60, '00:00:00.000100'),
        (13000, '00:00:00.013000'),
        (55000, '00:00:00.550000'),
        (24, '00:00:01.000000'),
        (40, '00:01:00.000000'),
    ]
    for timedelta, expected in data:
        assert timedelta_format(datetime_module.timedelta(microseconds=timedelta)) == expected


# Generated at 2022-06-10 21:36:08.729428
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in map(datetime_module.timedelta,
                         range(-10, 10),
                         range(-60, 60),
                         range(-3600, 3600, 20),
                         range(-10**6, 10**6, 10**4)):
        parsed_timedelta = timedelta_parse(timedelta_format(timedelta))
        assert parsed_timedelta == timedelta

test_timedelta_format()

# Generated at 2022-06-10 21:36:13.491233
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-10 21:36:16.505700
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                  microseconds=543210)
    ) == '03:02:01.054321'



# Generated at 2022-06-10 21:36:27.890679
# Unit test for function timedelta_format
def test_timedelta_format():
    before_microseconds = timedelta_format(datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=1234567
    ))
    assert before_microseconds == '00:00:00.123456'

    at_microseconds = timedelta_format(datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=1234567
    ))
    assert at_microseconds == '00:00:00.123456'

    after_microseconds = timedelta_format(datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=1234567
    ))

# Generated at 2022-06-10 21:36:38.296586
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=234567)
    assert timedelta_format(timedelta) == '01:02:03.234567'
    timedelta = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(timedelta) == '00:00:00.000001'
    timedelta = datetime_module.timedelta()
    assert timedelta_format(timedelta) == '00:00:00.000000'


#

# Generated at 2022-06-10 21:37:03.235541
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                '00:00:01'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=500)) == \
                                                                '00:00:01.000500'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=1)) == \
                                                                '00:00:00.000001'



# Generated at 2022-06-10 21:37:14.681256
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:37:17.299266
# Unit test for function timedelta_format
def test_timedelta_format():
    assert isinstance(timedelta_format(
        datetime_module.timedelta(seconds=1.23456789)
    ), str)



# Generated at 2022-06-10 21:37:26.579200
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'

# Generated at 2022-06-10 21:37:38.389675
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in ('00:00:00.000000',
              '12:34:56.123456',
              '23:59:59.999999'):
        assert timedelta_parse(s) == datetime_module.timedelta(
            *map(int, s.split('.')[0].split(':'))
        )
test_timedelta_parse()



# Generated at 2022-06-10 21:37:45.649565
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta_, s in {
        datetime_module.timedelta(hours=1, minutes=2,
                                  seconds=3, microseconds=400000):
            '01:02:03.400000',
        datetime_module.timedelta(hours=5, minutes=6,
                                  seconds=7):
            '05:06:07.000000',
        datetime_module.timedelta():
            '00:00:00.000000',
    }.items():
        assert timedelta_format(timedelta_) == s



# Generated at 2022-06-10 21:37:53.777394
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, microseconds=0
    ))) == datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, microseconds=0
    )

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, microseconds=1
    ))) == datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, microseconds=1
    )


# Generated at 2022-06-10 21:38:06.510188
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=3)) == \
           '00:01:03.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == \
           '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=2, microseconds=1)) == \
           '02:00:00.000001'

# Generated at 2022-06-10 21:38:20.556731
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.000099') == datetime_module.timedelta(
        microseconds=99
    )
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(
        microseconds=100
    )

# Generated at 2022-06-10 21:38:29.999417
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=4,
                                                                      minutes=53,
                                                                      seconds=2,
                                                                      microseconds=0))) == datetime_module.timedelta(hours=4,
                                                                                                                  minutes=53,
                                                                                                                  seconds=2,
                                                                                                                  microseconds=0)

# Generated at 2022-06-10 21:39:04.779414
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == \
                                                             '00:00:01.100000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.123456)) == \
                                                            '00:00:01.123456'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                           '00:00:01.000000'
    assert timedelta_format

# Generated at 2022-06-10 21:39:13.135863
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0:0.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('0:0:0.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('0:0:0.001000')) == '00:00:00.001000'

# Generated at 2022-06-10 21:39:22.648702
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                          datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == \
                          datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1,
                               microseconds=234567))) == \
                          datetime_module.timedelta(hours=1, microseconds=234567)

# Generated at 2022-06-10 21:39:31.926122
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_cases = [
        ('12:34:56.789000', 12, 34, 56, 789000),
        ('12:34:56.789', 12, 34, 56, 789000),
        ('12:34:56', 12, 34, 56, 0),
        ('34:56', 0, 34, 56, 0),
        ('56', 0, 0, 56, 0),
    ]
    for s, hours, minutes, seconds, microseconds in test_cases:
        assert timedelta_parse(s) == datetime_module.timedelta(
            hours=hours, minutes=minutes, seconds=seconds,
            microseconds=microseconds)

# Generated at 2022-06-10 21:39:36.128020
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5)
    s = timedelta_format(timedelta)
    assert s == '26:03:04.000005'
    assert timedelta == timedelta_parse(s)

# Generated at 2022-06-10 21:39:37.862801
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=11, minutes=12, seconds=13,
                                      microseconds=123456)
    assert timedelta_format(delta) == '11:12:13.123456'



# Generated at 2022-06-10 21:39:48.138699
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.003000') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=3
    )
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('01:02:03.99900') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=999
    )

# Generated at 2022-06-10 21:39:57.801083
# Unit test for function timedelta_format
def test_timedelta_format():
    for a in range(2):
        for b in range(60):
            for c in range(60):
                for d in range(1000000):
                    timedelta = datetime_module.timedelta(hours=a, minutes=b,
                                                          seconds=c,
                                                          microseconds=d)
                    s = timedelta_format(timedelta)
                    assert len(s) == 15
                    assert timedelta == timedelta_parse(s)



# Generated at 2022-06-10 21:40:04.685063
# Unit test for function timedelta_parse
def test_timedelta_parse():
    string = '01:02:03.123456'
    assert timedelta_parse(string) == datetime_module.timedelta(hours=1,
                                                                minutes=2,
                                                                seconds=3,
                                                                microseconds=123456)
    assert timedelta_format(timedelta_parse(string)) == string

# Generated at 2022-06-10 21:40:07.445166
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'


# Generated at 2022-06-10 21:41:04.025133
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:30:30.600000')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=30,
                                                  seconds=30,
                                                  microseconds=600000)
    print('timedelta_parse works')

# Generated at 2022-06-10 21:41:06.780832
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(531, 53001)) == \
           '05:31:00.053001'
    assert timedelta_format(datetime_module.timedelta(-1, -1)) == \
           '-00:00:01.999999'


# Generated at 2022-06-10 21:41:16.562294
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 9)) == \
           '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 99)) == \
           '00:00:00.000099'

# Generated at 2022-06-10 21:41:26.766028
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=2))) == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(milliseconds=1))) == datetime_module.timedelta(milliseconds=1)
test_timedelta_parse()


if PY3:
    def to_str(f):
        return f.__str__()

# Generated at 2022-06-10 21:41:32.784815
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=46)) == \
           '00:46:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=7)) == \
           '00:00:07.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=7.5)) == \
           '00:00:07.500000'

# Generated at 2022-06-10 21:41:38.319444
# Unit test for function timedelta_format
def test_timedelta_format():
    from datetime import timedelta
    assert timedelta_format(timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(timedelta(hours=0, minutes=0, seconds=0,
                                      microseconds=0)) == '00:00:00.000000'



# Generated at 2022-06-10 21:41:40.616453
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(
        timedelta_parse('01:02:03.123456')
    ) == '01:02:03.123456'

# Generated at 2022-06-10 21:41:53.919246
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:59.999999') == \
           datetime_module.timedelta(seconds=59, microseconds=999999)
    assert timedelta_parse('00:59:59.999999') == \
           datetime_module.timedelta(minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('23:59:59.999999') == \
           datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                     microseconds=999999)

    # Timedeltas with leading zeroes

# Generated at 2022-06-10 21:41:58.852436
# Unit test for function timedelta_format
def test_timedelta_format():

    for i in range(1000):
        dt = datetime_module.timedelta(days=1, seconds=i)
        assert timedelta_format(dt) == timedelta_parse(
            timedelta_format(dt)
        )
        assert timedelta_format(dt) == '24:00:00:000000.{:06d}'.format(i)



# Generated at 2022-06-10 21:42:05.019099
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=3,
                                                      seconds=3,
                                                      microseconds=3)) == (
                                                          '03:03:03.000003'
                                                      )
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=999999)) == (
                                                          '00:00:00.999999'
                                                      )
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == (
                                                          '23:59:59.999999'
                                                      )
