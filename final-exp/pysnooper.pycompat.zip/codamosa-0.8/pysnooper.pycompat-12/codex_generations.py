

# Generated at 2022-06-10 21:32:50.887343
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(0))
    ) == datetime_module.timedelta(0)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(1, 0))
    ) == datetime_module.timedelta(1, 0)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(1, 1))
    ) == datetime_module.timedelta(1, 1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(1, 1, 1))
    ) == datetime_module.timedelta(1, 1, 1)



# Generated at 2022-06-10 21:32:59.099714
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2.3)) == \
                                             '00:00:00.264000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3)) == \
                                             '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      seconds=4)) == \
                                             '03:00:04.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
                                             '03:00:04.000005'


# Generated at 2022-06-10 21:33:09.041777
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:1.245') == datetime_module.timedelta(
        seconds=1, microseconds=245
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(
        seconds=0
    )
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:1.000245') == datetime_module.timedelta(
        seconds=1, microseconds=245
    )
    assert timedelta_parse('0:0:01.000245') == datetime_module.timedelta(
        seconds=1, microseconds=245
    )

test_timedelta_parse()


# Generated at 2022-06-10 21:33:12.015442
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import inspect
    timedelta = datetime_module.timedelta(hours=23, minutes=47, seconds=28,
                                          microseconds=54321)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-10 21:33:18.390717
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('01:43:28.470000') == datetime_module.timedelta(
        hours=1, minutes=43, seconds=28, microseconds=470000
    )
    with pytest.raises(ValueError):
        timedelta_parse('1:43:28.470000')
    with pytest.raises(ValueError):
        timedelta_parse('01:25:28.47')
    with pytest.raises(ValueError):
        timedelta_parse('01:43:28')
    with pytest.raises(ValueError):
        timedelta_parse('01:43:28.4700000')
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        0
    )
    assert timedelta_

# Generated at 2022-06-10 21:33:24.330773
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=43)) == \
           '00:00:43.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=5,
                                                      minutes=8, seconds=12,
                                                      microseconds=33)) == \
           '53:08:12.000033'


# Generated at 2022-06-10 21:33:27.596818
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == \
           '00:00:01.000002'



# Generated at 2022-06-10 21:33:30.028567
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=13,
                                  microseconds=123456)
    ) == '01:02:13.123456'

# Generated at 2022-06-10 21:33:43.422396
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 60 * 60)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000)

# Generated at 2022-06-10 21:33:50.200747
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:20:30:400000')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=20,
                                                  seconds=30,
                                                  microseconds=400000)
    timedelta = timedelta_parse('1:20:30:4')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=20,
                                                  seconds=30,
                                                  microseconds=4)


# Generated at 2022-06-10 21:34:09.085683
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == '00:01:01.000000'

# Generated at 2022-06-10 21:34:20.532151
# Unit test for function timedelta_format
def test_timedelta_format():
    now = datetime_module.datetime.now()
    plus_one_sec = datetime_module.timedelta(seconds=1)
    def assert_different_by_one_sec(time1, time2):
        assert isinstance(time1, datetime_module.time)
        assert isinstance(time2, datetime_module.time)
        delta = datetime_module.datetime.combine(now.date(), time2) - \
                datetime_module.datetime.combine(now.date(), time1)
        assert delta == plus_one_sec
    assert_different_by_one_sec(
        time_isoformat(datetime_module.time(0, 0, 0)),
        time_isoformat(datetime_module.time(0, 0, 1))
    )
    assert_different

# Generated at 2022-06-10 21:34:26.254940
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_1000 = datetime_module.timedelta(milliseconds=1000)
    timedelta_1001 = datetime_module.timedelta(milliseconds=1001)
    timedelta_1 = datetime_module.timedelta(microseconds=1)

    assert timedelta_parse(timedelta_format(timedelta_1000)) == timedelta_1000
    assert timedelta_parse(timedelta_format(timedelta_1)) == timedelta_1

    assert timedelta_parse(timedelta_format(timedelta_1000)) \
        != timedelta_1001
    assert timedelta_parse(timedelta_format(timedelta_1)) != timedelta_1000

# Generated at 2022-06-10 21:34:34.536080
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                                            hours=12, minutes=0))) == \
                                            datetime_module.timedelta(hours=12,
                                                                      minutes=0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                                            hours=0, minutes=0,
                                            microseconds=130000))) == \
                                            datetime_module.timedelta(
                                            microseconds=130000)
test_timedelta_parse()

# Generated at 2022-06-10 21:34:45.563191
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:2:3.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('1:2:3.000004') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)
    assert timedelta_parse('0:0:0.000004') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000004') == \
           datetime_module.timedelta(microseconds=4)

# Generated at 2022-06-10 21:34:54.131674
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.000004')) ==\
           '01:02:03.000004'
    assert timedelta_format(timedelta_parse('-1:2:3.000004')) ==\
           '-02:57:56.999996'
    assert timedelta_format(timedelta_parse('-0:0:0.999999')) ==\
           '-00:00:00.999999'
    assert timedelta_format(timedelta_parse('0:0:0.000000')) ==\
           '00:00:00.000000'


# Patching `os.PathLike` as used in Python 3.6.2

# Generated at 2022-06-10 21:35:04.394162
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=-1)) == '-1 day, 23:59:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timed

# Generated at 2022-06-10 21:35:07.153138
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.004005') == datetime_module.timedelta(
        1,
        3723,
        4005
    )

# Generated at 2022-06-10 21:35:17.901548
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      microseconds=123456)) == \
                                                      '04:05:06.123456'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      microseconds=12)) == \
                                                      '04:05:06.000012'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      microseconds=1)) == \
                                                      '04:05:06.000001'

# Generated at 2022-06-10 21:35:21.853322
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("1:01:01.000001") == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)



# Generated at 2022-06-10 21:35:35.479832
# Unit test for function timedelta_format
def test_timedelta_format():
    timestamp = datetime_module.timedelta(
        hours=5, minutes=10, seconds=42, microseconds=987456
    )
    assert timedelta_format(timestamp) == '05:10:42.987456'


# Generated at 2022-06-10 21:35:48.932586
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == \
                                         datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3,
                                                                   microseconds=456789)
    assert timedelta_parse('1:02:03.456789') == \
                                         datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3,
                                                                   microseconds=456789)
    assert timedelta_parse('01:2:3.456789') == \
                                         datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3,
                                                                   microseconds=456789)
   

# Generated at 2022-06-10 21:35:59.262079
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=8, minutes=11, seconds=32,
                                          microseconds=43567)
    assert timedelta_format(timedelta) == '08:11:32.043567'
    timedelta = datetime_module.timedelta(days=3, hours=8, minutes=11,
                                          seconds=32, microseconds=43567)
    assert timedelta_format(timedelta) == '216:11:32.043567'
    timedelta = datetime_module.timedelta(days=3)
    assert timedelta_format(timedelta) == '72:00:00.000000'
    timedelta = datetime_module.timedelta(seconds=3567)

# Generated at 2022-06-10 21:36:09.036410
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                   seconds=4, microseconds=5)
    assert timedelta_format(td) == '26:03:04.000005'
    td = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                   seconds=4, microseconds=5000)
    assert timedelta_format(td) == '26:03:04.005000'


# Generated at 2022-06-10 21:36:14.905281
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=123)) == \
           '00:00:00.000000'
    
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      seconds=65)) == \
           '23:01:05.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=65,
                                                      microseconds=123456)) == \
           '00:01:05.123456'

# Generated at 2022-06-10 21:36:26.175990
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.0') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.0000') == datetime_module.timed

# Generated at 2022-06-10 21:36:33.708084
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-10 21:36:42.680642
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:36:50.433078
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        seconds=3600
    )
    assert timedelta_parse('1:00:00.000001') == datetime_module.timedelta(
        seconds=3600, microseconds=1
    )

# Generated at 2022-06-10 21:37:00.501454
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=14)) == '00:14:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-10 21:37:32.570431
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=23,
                                                      seconds=45,
                                                      microseconds=678901)) \
                                                              == '1:23:45.678901'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'



# Generated at 2022-06-10 21:37:35.928638
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(seconds=16, microseconds=10),
        datetime_module.timedelta(seconds=10, microseconds=16),
        datetime_module.timedelta(seconds=0, microseconds=16),
    ):
        s = timedelta_format(timedelta)
        assert timedelta == timedelta_parse(s)

# Generated at 2022-06-10 21:37:45.772005
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:00:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(seconds=0)

    s = '01:02:03.010203'
    assert timedelta_parse(s) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=10203
    )

    s = '01:02:03.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

    s = '01:02:03'
    assert timedelta_parse(s) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

# Generated at 2022-06-10 21:37:51.552601
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=13, minutes=35, seconds=15)
    ) == '13:35:15.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=18)) == \
                           '00:00:18.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=216)) == \
                           '00:00:00.000216'



# Generated at 2022-06-10 21:37:59.217884
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1)
    )) == datetime_module.timedelta(hours=1)

if __name__ == '__main__':
    test_timedelta_parse()

# Generated at 2022-06-10 21:38:10.396267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )



# Generated at 2022-06-10 21:38:23.548181
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:04:05.000000') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=0
    )
    assert timedelta_parse('03:04:05.123456') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=123456
    )
    assert timedelta_parse('03:04:05.123456789') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=123456
    )


# Adapted from six.py:
# Copyright (c) 2010-2017 Benjamin Peterson
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "

# Generated at 2022-06-10 21:38:31.497320
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, seconds=55)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=55)) == \
           '00:00:55.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=55)) == \
           '00:00:00.000055'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=37,
                                                      seconds=34,
                                                      microseconds=23)) == \
           '05:37:34.000023'



# Generated at 2022-06-10 21:38:33.869099
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('2:34:56.000001')) == (
        '02:34:56.000001'
    )

# Generated at 2022-06-10 21:38:46.989060
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Test `timedelta_parse` on a bunch of strings.
    '''

# Generated at 2022-06-10 21:39:18.103089
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=22, hours=16,
                                                      minutes=32,
                                                      seconds=7,
                                                      microseconds=99)) == \
                                                      '16:32:07.000099'


# Generated at 2022-06-10 21:39:22.867160
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) \
           == '01:02:03.456789'



# Generated at 2022-06-10 21:39:34.056543
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           "00:00:00.000000"
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           "00:00:01.000000"
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           "00:00:00.000001"
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
           "00:00:01.000001"

# Generated at 2022-06-10 21:39:42.777913
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-01:00:01.123456') == timedelta_parse(
        '-0001:00:01.123456'
    )
    assert timedelta_parse('-01:00:01.123456') == timedelta_parse(
        '-1:00:01.123456'
    )
    assert timedelta_parse('-01:00:01.123456') == timedelta_parse(
        '1:-1:-58.876544'
    )
    assert timedelta_parse('-01:00:01.123456') == timedelta_parse(
        '1:00:01.123456'
    )

test_timedelta_parse()
del test_timedelta_parse

# Generated at 2022-06-10 21:39:55.245354
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:40:05.108678
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from pithy.io import stdout
    from pytest import approx
    timedelta = timedelta_parse('01:02:03.004000')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3,
                                                  microseconds=4)

    timedelta = timedelta_parse('1:2:3.4')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3,
                                                  microseconds=400000)



# Generated at 2022-06-10 21:40:12.423117
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
            datetime_module.timedelta(0),
            datetime_module.timedelta(1, 2, 3, 4),
            datetime_module.timedelta(999, 999999)):
        round_trip = timedelta_parse(timedelta_format(timedelta))
        assert abs(round_trip - timedelta) < datetime_module.timedelta(0, 0, 1)

# Generated at 2022-06-10 21:40:22.304385
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.100000') == datetime_module.timedelta(seconds=1, microseconds=100000)

# Generated at 2022-06-10 21:40:28.136064
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=100)) == \
           '100:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=9876)) == \
           '00:00:00.009876'
    assert timedelta_format(datetime_module.timedelta(hours=50, minutes=15)) == \
           '50:15:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == \
           '-01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=-60))

# Generated at 2022-06-10 21:40:40.352855
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-10 21:41:35.345615
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=3, hours=2, microseconds=5)
    assert timedelta_format(timedelta) == '02:00:00.000005'



# Generated at 2022-06-10 21:41:37.225354
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.234)) == \
           '00:00:01.234000'

# Generated at 2022-06-10 21:41:48.948619
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:41:57.412314
# Unit test for function timedelta_format
def test_timedelta_format():
    timedeltas = [datetime_module.timedelta(hours=1),
                  datetime_module.timedelta(minutes=1),
                  datetime_module.timedelta(seconds=1)]
    assert all(
        timedelta_format(timedelta) ==
        time_isoformat(
            (datetime_module.datetime.min + timedelta).time(),
            timespec='microseconds'
        )
        for timedelta in timedeltas
    )



# Generated at 2022-06-10 21:42:07.726181
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) \
           == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) \
           == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) \
           == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) \
           == '00:00:00.000001'
    
    

# Generated at 2022-06-10 21:42:17.233786
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1))) == datetime_module.timedelta(microseconds=1)



# Generated at 2022-06-10 21:42:22.491594
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(weeks=123, days=1,
                                                      microseconds=6789)) == \
                                                      '168:00:00.006789'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=12,
                                                      microseconds=4321)) == \
                                                      '10:12:00.004321'

# Generated at 2022-06-10 21:42:29.056756
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('0:0:0.010000') == datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse('0:0:0.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse