

# Generated at 2022-06-10 21:32:47.419448
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=123456)
    assert timedelta_parse('00:12:34:56.123456') == datetime_module.timedelta(
        days=12, hours=34, seconds=56, microseconds=123456)



# Generated at 2022-06-10 21:32:50.696007
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(1, 3661, 100000)
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=100000)

# Generated at 2022-06-10 21:32:59.443267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (datetime_module.timedelta(hours=2, minutes=40, seconds=3,
                                      microseconds=123456) ==
            timedelta_parse('02:40:03.123456'))

    assert (datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                      microseconds=123456) ==
            timedelta_parse('1:01:01.123456'))

    assert (datetime_module.timedelta(hours=11, minutes=1, seconds=1,
                                      microseconds=123456) ==
            timedelta_parse('11:01:01.123456'))


# Generated at 2022-06-10 21:33:09.041361
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Test the function `timedelta_parse`.
    """
    from nose.tools import assert_equal
    test_timedelta_tuple = (2, 1, 0, 0)
    datetime = datetime_module.timedelta(*test_timedelta_tuple)
    string_input = "{}.{:03d}:{:02d}:{:02d}".format(
        test_timedelta_tuple[0],
        test_timedelta_tuple[1],
        test_timedelta_tuple[2],
        test_timedelta_tuple[3],
    )
    assert_equal(timedelta_parse(string_input), datetime)

# Generated at 2022-06-10 21:33:13.006250
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Unit test for the `timedelta_parse` function.

    Just make sure you didn't break anything since it's important to keep
    compatibility.
    """
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)

# Generated at 2022-06-10 21:33:17.877503
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=4, hours=4, minutes=4,
                                          seconds=4, microseconds=4)
    assert timedelta_format(timedelta) == '04:04:04.000004'
test_timedelta_format()


# Generated at 2022-06-10 21:33:28.771507
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:50:60.000001') == datetime_module.timedelta(
        hours=0, minutes=50, seconds=60, microseconds=1
    )
    assert timedelta_parse('00:50:60.000010') == datetime_module.timedelta(
        hours=0, minutes=50, seconds=60, microseconds=10
    )
    assert timedelta_parse('00:50:60.000100') == datetime_module.timedelta(
        hours=0, minutes=50, seconds=60, microseconds=100
    )
    assert timedelta_parse('00:50:60.001000') == datetime_module.timedelta(
        hours=0, minutes=50, seconds=60, microseconds=1000
    )

# Generated at 2022-06-10 21:33:31.062264
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('9:12:45.678123')) == (
        '09:12:45.678123')

# Generated at 2022-06-10 21:33:37.774214
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                               seconds=3,
                                               microseconds=4)
    assert timedelta_parse(timedelta_format(test_timedelta)) == test_timedelta



# Generated at 2022-06-10 21:33:46.816214
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(
        seconds=1, microseconds=999999)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)

# Generated at 2022-06-10 21:34:00.892975
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.datetime.max -
                            datetime_module.datetime.min) == \
           '23:59:59.999999'

# Generated at 2022-06-10 21:34:07.625622
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      minutes=15, seconds=16,
                                                      microseconds=987654)) == \
           '08:15:16.987654'
    assert timedelta_format(datetime_module.timedelta(hours=-3,
                                                      minutes=-15, seconds=-16,
                                                      microseconds=5)) == \
           '-03:-15:-16.000005'


# Generated at 2022-06-10 21:34:10.160721
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )



# Generated at 2022-06-10 21:34:13.246209
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789012
    )) == '12:34:56.789012'


# Generated at 2022-06-10 21:34:17.255210
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-10 21:34:28.723275
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)

# Generated at 2022-06-10 21:34:38.034164
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.datetime.now().time()
    microseconds = int(time_isoformat(time, timespec='microseconds').split('.')[1])
    assert microseconds == time.microsecond
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == '02:03:04.000005'
    assert timedelta_format(timedelta_parse('02:03:04.000005 ')) == '02:03:04.000005'

# Generated at 2022-06-10 21:34:43.870660
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59:999999') == datetime_module.timedelta(
        hours=23, minutes=59,
        seconds=59, milliseconds=999, microseconds=999
    )



# Generated at 2022-06-10 21:34:53.111982
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=8.5)) == '00:00:08.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=60.5)) == '00:01:00.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=61.5)) == '00:01:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=122.5)) == '00:02:02.500000'

# Generated at 2022-06-10 21:35:03.677535
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
                            seconds=123456)) == '00:00:03.123456'
    assert timedelta_format(datetime_module.timedelta(
                            seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
                            minutes=94, seconds=17,
                            microseconds=123456)) == '00:94:17.123456'
    assert timedelta_format(datetime_module.timedelta(
                            hours=2, minutes=94, seconds=17,
                            microseconds=123456)) == '02:94:17.123456'

# Generated at 2022-06-10 21:35:35.960014
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:0') == datetime_module.timedelta()
    assert timedelta_parse('0') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == \
                                            datetime_module.timedelta(hours=1)

# Generated at 2022-06-10 21:35:49.236657
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:02:00.000000') == datetime_module.timedelta(
        hours=1, minutes=2)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1)

# Generated at 2022-06-10 21:35:58.839970
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for delta in (
        datetime_module.timedelta(hours=23, minutes=12, seconds=59,
                                  microseconds=3456),
        datetime_module.timedelta(microseconds=314159),
        datetime_module.timedelta(microseconds=0),
    ):
        assert timedelta_parse(timedelta_format(delta)) == delta


if sys.version_info[:2] >= (3, 5):
    # In Python 3.6+ the `isconcurrent` attribute was removed from futures
    def isconcurrent(future):
        return future._state == 'PENDING'
else:
    def isconcurrent(future):
        return future.isconcurrent()

# Generated at 2022-06-10 21:36:04.501664
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=456789)
    assert timedelta_format(timedelta) == '01:02:03.456789'


# Generated at 2022-06-10 21:36:17.852475
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
        microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(
        minutes=4, seconds=5,
        microseconds=6)) == '00:04:05.000006'

# Generated at 2022-06-10 21:36:28.786236
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def f(s):
        return timedelta_parse(s)

    assert f('0:0:0.000000') == datetime_module.timedelta(0)
    assert f('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert f('0:0:0.000010') == datetime_module.timedelta(0, 0, 10)
    assert f('0:0:0.000100') == datetime_module.timedelta(0, 0, 100)
    assert f('0:0:0.001000') == datetime_module.timedelta(0, 0, 1000)
    assert f('0:0:0.010000') == datetime_module.timedelta(0, 0, 10000)

# Generated at 2022-06-10 21:36:36.416190
# Unit test for function timedelta_format
def test_timedelta_format():
    zero = datetime_module.timedelta(0)
    assert timedelta_format(zero) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 99999)) == \
        '00:00:00.099999'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
        '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(0, 60))

# Generated at 2022-06-10 21:36:45.610847
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:01.1') == datetime_module.timedelta(
        seconds=1, milliseconds=100
    )
    assert timedelta_parse('0:00:01.000123') == datetime_module.timedelta(
        microseconds=100123
    )



# Generated at 2022-06-10 21:36:48.470810
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=36)) == \
                                                              '10:00:00.000000'

# Generated at 2022-06-10 21:36:58.488533
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.056789') == \
                          datetime_module.timedelta(hours=2, minutes=3,
                                                    seconds=4,
                                                    microseconds=56789)

    assert timedelta_parse('02:03:04.056789') == \
                          datetime_module.timedelta(hours=2, minutes=3,
                                                    seconds=4,
                                                    microseconds=56789)



# Generated at 2022-06-10 21:37:49.451026
# Unit test for function timedelta_parse
def test_timedelta_parse():
    times = (
        '00:00:00.000000',
        '12:32:45.011234',
        '00:00:01.000000',
    )
    for time in times:
        assert timedelta_parse(time).total_seconds() == \
               timedelta_parse(time_isoformat(timedelta_to_time(
                   timedelta_parse(time)
               ))).total_seconds()

# Generated at 2022-06-10 21:37:53.639264
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=40, microseconds=1234
    ))) == datetime_module.timedelta(
        seconds=40, microseconds=1234
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=23, minutes=45, microseconds=1234
    ))) == datetime_module.timedelta(
        hours=23, minutes=45, microseconds=1234
    )

# Generated at 2022-06-10 21:38:04.715077
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(
        microseconds=1e5
    )
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )

# Generated at 2022-06-10 21:38:14.077501
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5)) == '5:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3)) == '5:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, seconds=3)) == '5:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, microseconds=1
    )) == '5:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=23)) == '00:00:00.000023'
test_timedelta_format()



# Generated at 2022-06-10 21:38:18.503000
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456)
    assert timedelta_format(td) == '01:02:03.123456'


# Generated at 2022-06-10 21:38:24.334944
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:01:11.012345') == \
           datetime_module.timedelta(minutes=12*60 + 1, seconds=11,
                                     microseconds=10**6*1 + 10**4*2 + 10**2*3 +
                                                  4*10**0 + 5)

# Generated at 2022-06-10 21:38:29.026112
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=3, minutes=12, seconds=44, microseconds=123000
    )) == '03:12:44.123000'


# Generated at 2022-06-10 21:38:43.762839
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:38:55.234512
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(
        hours=1, seconds=1)
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1)
   

# Generated at 2022-06-10 21:39:03.238835
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    ))) == timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                     seconds=1,
                                                     microseconds=1))


# See
# https://stackoverflow.com/questions/33754521/what-is-the-backported-version-of-collections-ordereddict-in-python-2

# Generated at 2022-06-10 21:40:49.406696
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(15, 3), timespec='microseconds')
    assert time == '15:03:00.000000'

    time = time_isoformat(datetime_module.time(15, 3, 2), timespec='microseconds')
    assert time == '15:03:02.000000'

    time = time_isoformat(datetime_module.time(15, 3, 2, 7), timespec='microseconds')
    assert time == '15:03:02.000007'



# Generated at 2022-06-10 21:40:52.406585
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:02:03.1300000') == (
        datetime_module.timedelta(minutes=2, seconds=3, microseconds=130000))

test_timedelta_parse()

# Generated at 2022-06-10 21:40:57.039066
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(weeks=12, days=2, hours=3,
                                             minutes=4, seconds=5,
                                             microseconds=6)
    assert timedelta_format(timedelta) == '903:04:05.000006'



# Generated at 2022-06-10 21:41:07.479523
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_roundtrip(timedelta):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))
    assert_roundtrip(datetime_module.timedelta(seconds=0))
    assert_roundtrip(datetime_module.timedelta(seconds=1))
    assert_roundtrip(datetime_module.timedelta(seconds=1.1))
    assert_roundtrip(datetime_module.timedelta(seconds=1.111))
    assert_roundtrip(datetime_module.timedelta(seconds=1, microseconds=1))
    assert_roundtrip(datetime_module.timedelta(seconds=1, microseconds=10))
    assert_roundtrip(datetime_module.timedelta(seconds=1, microseconds=100))

# Generated at 2022-06-10 21:41:13.183745
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:03:04.056789') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=56789
    )


try:
    from typing import Tuple as typing_Tuple
except ImportError:
    try:
        from typing import Tuple
        typing_Tuple = Tuple
    except ImportError:
        def typing_Tuple(*whatever):
            '''Dummy function for when we don't have typing.'''

# Generated at 2022-06-10 21:41:23.836764
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = datetime_module.time(2, 9, 32, 111111)
    s = time_isoformat(time, timespec='microseconds')
    assert timedelta_parse(s) == datetime_module.timedelta(hours=2, minutes=9,
                                                           seconds=32,
                                                           microseconds=111111)


if sys.version_info[:2] >= (3, 7):
    datetime_combine = datetime_module.datetime.combine
else:
    def datetime_combine(date, time):
        return datetime_module.datetime(date.year, date.month, date.day,
                                        time.hour, time.minute, time.second,
                                        time.microsecond, time.tzinfo)



# Generated at 2022-06-10 21:41:37.349182
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta
    assert timedelta_format(td(hours=2, minutes=3, seconds=4, microseconds=99)) == \
           '02:03:04.000099'
    assert timedelta_format(td(hours=10, minutes=23, seconds=14, microseconds=63)) == \
           '10:23:14.000063'
    assert timedelta_format(td(hours=24, minutes=59, seconds=59, microseconds=999999)) == \
           '24:59:59.999999'
    assert timedelta_format(td(hours=0, minutes=0, seconds=0, microseconds=0)) == \
           '00:00:00.000000'

# Generated at 2022-06-10 21:41:45.731624
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
           '03:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=3, seconds=43)) == \
           '03:00:43.000000'

    assert timedelta_format(datetime_module.timedelta(hours=3, seconds=43,
                                                      microseconds=55)) == \
           '03:00:43.000055'

test_timedelta_format()


# Generated at 2022-06-10 21:41:50.316678
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, seconds=6889,
                                          microseconds=54)
    assert timedelta_format(timedelta) == '01:01:01.006889'


# Generated at 2022-06-10 21:42:00.604422
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                    '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                    '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                    '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                    '24:00:00.000000'