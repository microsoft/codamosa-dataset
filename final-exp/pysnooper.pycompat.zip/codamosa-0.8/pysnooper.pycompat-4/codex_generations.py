

# Generated at 2022-06-10 21:32:49.363400
# Unit test for function timedelta_format
def test_timedelta_format():
    for seconds in range(0, 86400 * 366):
        for microseconds in range(0, 1000 * 1000):
            delta = datetime_module.timedelta(seconds=seconds,
                                              microseconds=microseconds)
            if microseconds == 0:
                microseconds = '000000'
            expected = ('{:0>2}:{:0>2}:{:0>2}.{}'.format(
                delta.seconds // 3600, (delta.seconds // 60) % 60,
                delta.seconds % 60, microseconds
            ))
            assert timedelta_format(delta) == expected


# Generated at 2022-06-10 21:32:51.883633
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('1:00:00.123456')
    assert td.hours == 1
    assert td.minutes == 0
    assert td.seconds == 0
    assert td.microseconds == 123456



# Generated at 2022-06-10 21:33:00.476706
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00:012345') == datetime_module.timedelta(
        0,
        microseconds=12345
    )
    assert timedelta_parse('00:00:00.012345') == datetime_module.timedelta(
        0,
        microseconds=12345
    )

# Generated at 2022-06-10 21:33:06.455542
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=1)) == \
                                                                      '01:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=0)) == '24:00:00.000000'

# Unit tests for function timedelta_parse:

# Generated at 2022-06-10 21:33:15.222286
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.1234567') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2') == datetime_module.timedelta(
        hours=1, minutes=2
    )

# Generated at 2022-06-10 21:33:17.667874
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == \
                            '00:00:01.100000'



# Generated at 2022-06-10 21:33:28.651531
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '24:00:01.000000'

# Generated at 2022-06-10 21:33:33.751941
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_ = timedelta_parse('1:23:34.567890')
    assert timedelta_ == datetime_module.timedelta(hours=1, minutes=23,
                                                   seconds=34,
                                                   microseconds=567_890)

# Generated at 2022-06-10 21:33:38.697023
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:15:03.456789') == datetime_module.timedelta(
        hours=2, minutes=15, seconds=3, microseconds=456789
    )



# Generated at 2022-06-10 21:33:48.105059
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=1, microseconds=2)
    )) == datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                    microseconds=2)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=23, microseconds=45)
    )) == datetime_module.timedelta(hours=0, minutes=0, seconds=23,
                                    microseconds=45)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=0, seconds=0, microseconds=0)
    )) == datetime_module

# Generated at 2022-06-10 21:34:08.545586
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('-1')) == '-00:01:00.000000'
    assert timedelta_format(timedelta_parse('0:12')) == '00:12:00.000000'
    assert timedelta_format(timedelta_parse('0:12:23')) == '00:12:23.000000'
    assert timedelta_format(timedelta_parse('0:12:23.123456')) \
                           == '00:12:23.123456'
    assert timedelta_format(timedelta_parse('-1:12:23.123456')) \
                           == '-01:12:23.123456'
    assert timed

# Generated at 2022-06-10 21:34:12.850807
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1:2:3.456789')) == '01:02:03.456789'

test_timedelta_parse()



# Generated at 2022-06-10 21:34:24.975981
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=65)) == \
           '00:01:05.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=65,
                                                      microseconds=5)) == \
           '00:01:05.000005'
    assert timedelta_format(datetime_module.timedelta(minutes=15,
                                                      seconds=5,
                                                      microseconds=5)) == \
           '00:15:05.000005'
    assert timedelta_format(datetime_module.timedelta(hours=5)) == \
           '05:00:00.000000'

# Generated at 2022-06-10 21:34:36.009329
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=3, hours=4, minutes=5,
                                          seconds=6, microseconds=123456)
    assert timedelta_format(timedelta) == '04:05:06.123456'
    timedelta = datetime_module.timedelta(seconds=60)
    assert timedelta_format(timedelta) == '00:01:00.000000'
    timedelta = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta) == '00:00:01.000000'
    timedelta = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(timedelta) == '00:00:00.000001'



# Generated at 2022-06-10 21:34:46.116196
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    This test is run automatically.
    """
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5, minutes=5, seconds=5, microseconds=655)))

# Generated at 2022-06-10 21:34:54.353399
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == (
        '00:00:00.000001'
    )
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(1, 0, 0)) == (
        '24:00:00.000000'
    )
    assert timedelta_format(
        datetime_module.timedelta(days=15, hours=1, minutes=13,
                                  seconds=42, microseconds=123456)
    )

# Generated at 2022-06-10 21:35:00.113811
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                          microseconds=234000)
    assert timedelta_format(timedelta) == '00:00:01.234000'



# Generated at 2022-06-10 21:35:05.421484
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'

# Generated at 2022-06-10 21:35:15.639942
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                 datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(2))) == \
                                                 datetime_module.timedelta(2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=2))) == \
                                                 datetime_module.timedelta(days=2)

# Generated at 2022-06-10 21:35:20.780032
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'


# Generated at 2022-06-10 21:35:53.226133
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=5))) == \
           datetime_module.timedelta(hours=5)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=5,
                                                                     microseconds=50))) == \
           datetime_module.timedelta(hours=5, microseconds=50)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=5,
                                                                     microseconds=50,
                                                                     seconds=3))) == \
           datetime_module.timedelta(hours=5, microseconds=50, seconds=3)

# Generated at 2022-06-10 21:36:01.529555
# Unit test for function timedelta_parse
def test_timedelta_parse():
    examples = [
        ('01:02:03', '01:02:03.000000'),
        ('1:2:3', '01:02:03.000000'),
        ('01:02:03.456789', '01:02:03.456789'),
        ('1:2:3.456789', '01:02:03.456789'),
    ]
    for user_format, expected in examples:
        assert timedelta_format(timedelta_parse(user_format)) == expected

# Generated at 2022-06-10 21:36:11.348342
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, seconds=1)) == \
                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=0,
                                                      microseconds=1)) == \
                            '00:00:00.000001'



# Generated at 2022-06-10 21:36:22.269419
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=40000)
    assert timedelta_parse('01:02:03.040000') == timedelta_parse('1:2:3.4')
    assert timedelta_parse('1:2:3.4') == timedelta_parse('1:02:3.4')
    assert timedelta_parse('1:2:3.4') == timedelta_parse('1:2:03.4')
    assert timedelta_parse('1:2:3.4') == timedelta_parse('1:2:3.4000')
    assert timedelta_parse('1:2:3.4') == timedelta_parse('1:2:3.0400')

# Generated at 2022-06-10 21:36:32.609032
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 2345)) == '00:00:00.002345'
    assert timedelta_format(datetime_module.timedelta(0, 0, 123456)) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1234567)) == '00:00:01.234567'

    assert timedelta_format(datetime_module.timedelta(0, 3, 2345)) == '00:00:03.002345'

    # One second before a minute

# Generated at 2022-06-10 21:36:42.132045
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(3, 90000)) == \
        '00:00:03.090000'
    assert timedelta_format(datetime_module.timedelta(5, 567000)) == \
        '00:00:05.567000'
    assert timedelta_format(datetime_module.timedelta(hours=6, seconds=5,
                                                      microseconds=765000)) == \
        '06:00:05.765000'
    assert timedelta_format(datetime_module.timedelta(days=2, seconds=1,
                                                      microseconds=20)) == \
        '48:00:01.000020'

# Generated at 2022-06-10 21:36:54.481982
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(timedelta_parse('1:1:1.1'))) == \
                                                            timedelta_parse('1:1:1.1')
    assert timedelta_parse(timedelta_format(timedelta_parse('1:1:1.11'))) == \
                                                            timedelta_parse('1:1:1.11')
    assert timedelta_parse(timedelta_format(timedelta_parse('1:1:1.111'))) == \
                                                            timedelta_parse('1:1:1.111')
    assert timedelta_parse(timedelta_format(timedelta_parse('1:1:1.1111'))) == \
                                                            timedelta_parse('1:1:1.1111')
    assert timed

# Generated at 2022-06-10 21:37:02.540462
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('01:00:00.000001') == \
           datetime_module.timedelta(hours=1, microseconds=1)
    assert timedelta_parse('01:02:00.000001') == \
           datetime_module.timedelta(hours=1, minutes=2,
                                     microseconds=1)
    assert timedelta_parse('01:02:03.000001') == \
           datetime_module.timedelta(hours=1, minutes=2,
                                     seconds=3, microseconds=1)
    assert timedelta_parse('01:02:03.400005') == \
           datetime_module.timedelta

# Generated at 2022-06-10 21:37:14.286579
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        seconds=123, microseconds=456789
    )) == '00:02:03.456789'


try:
    from importlib import resources
except ImportError:
    import pkg_resources  # pyflakes.ignore
    importlib_resources_not_found = True
else:
    importlib_resources_not_found = False


try:
    from typing import IO, cast
    if sys.version_info[:2] >= (3, 7):
        from typing import ContextManager
    else:
        from typing import TypeVar
        T = TypeVar('T')
        def ContextManager(tp): #pylint: disable=unused-argument
            return cast(IO[T], None)
except ImportError:
    pass

# Generated at 2022-06-10 21:37:24.241992
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('10:13:11.123456') == \
           datetime_module.timedelta(hours=10, minutes=13, seconds=11,
                                     microseconds=123456)

    assert timedelta_parse('10:13:11.12345') == \
           datetime_module.timedelta(hours=10, minutes=13, seconds=11,
                                     microseconds=12345)

    assert timedelta_parse('10:13:11.1234') == \
           datetime_module.timedelta(hours=10, minutes=13, seconds=11,
                                     microseconds=1234)


# Generated at 2022-06-10 21:38:16.591106
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=18,
                                                      minutes=10,
                                                      seconds=8,
                                                      microseconds=123456)) \
                          == '18:10:08.123456'



# Generated at 2022-06-10 21:38:21.863596
# Unit test for function timedelta_parse
def test_timedelta_parse():
    my_timedelta = datetime_module.timedelta(hours=3, minutes=2,
                                             seconds=1, microseconds=12345)
    s = timedelta_format(my_timedelta)
    assert timedelta_parse(s) == my_timedelta

# Generated at 2022-06-10 21:38:30.634284
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_cases = [
        (datetime_module.timedelta(seconds=2), '00:00:02.000000'),
        (datetime_module.timedelta(microseconds=2345), '00:00:00.002345'),
        (datetime_module.timedelta(seconds=5, microseconds=1234),
         '00:00:05.001234'),
        (datetime_module.timedelta(minutes=5, seconds=12, microseconds=1234),
         '00:05:12.001234'),
        (datetime_module.timedelta(days=5, hours=6, minutes=7, seconds=8,
                                   microseconds=1234),
         '125:07:08.001234')
    ]

# Generated at 2022-06-10 21:38:37.235574
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse(
        timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123456)
        )
    ) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123456))

# Generated at 2022-06-10 21:38:49.732317
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        days=0, hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )


if PY3:
    def byte_to_int(byte):
        return byte
else:
    byte_to_int = ord


if hasattr(datetime_module, 'fromisoformat'):
    fromisoformat = datetime_module.fromisoformat

# Generated at 2022-06-10 21:39:00.807318
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=3661,
    ))) == datetime_module.timedelta(seconds=3661)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=3661,
        microseconds=100000,
    ))) == datetime_module.timedelta(seconds=3661, microseconds=100000)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5,
        minutes=2,
        seconds=13,
    ))) == datetime_module.timedelta(hours=5, minutes=2, seconds=13)


# Generated at 2022-06-10 21:39:10.690583
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:39:22.279287
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
                                                    '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                    '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                    '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                    '00:01:00.000000'

# Generated at 2022-06-10 21:39:24.770307
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:02:03.000000')
    assert timedelta == datetime_module.timedelta(seconds=3723)

test_timedelta_parse()

# Generated at 2022-06-10 21:39:35.672687
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    s = timedelta_format(timedelta)
    new_timedelta = timedelta_parse(s)
    assert timedelta == new_timedelta


from contextlib import contextmanager
if PY2:
    from contextlib import closing
    import StringIO as io_module
    StringIO = io_module.StringIO
    def string_io_with_newline(string):
        return StringIO(string + u'\n')


# Generated at 2022-06-10 21:41:20.586657
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=7, minutes=22, seconds=16,
                                   microseconds=70000)
    assert timedelta_format(td) == '07:22:16.070000'


# Generated at 2022-06-10 21:41:29.340589
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4))) == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789))) == \
           datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                     microseconds=789)


try:
    from contextlib import redirect_stdout
    from contextlib import redirect_stderr
except ImportError: # Python 3.5+
    from contextlib import contextmanager


# Generated at 2022-06-10 21:41:40.533523
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(0, 16)) == \
           '00:00:16.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3600)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3600 - 1)) == \
           '00:59:59.000000'
    assert timedelta_format(datetime_module.timedelta(0, 3601)) == \
           '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'

# Generated at 2022-06-10 21:41:45.515754
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from garlicsim.general_misc.third_party.tictoc import RepeatedTimer
    rt = RepeatedTimer(0.02, 0.02, lambda: None)
    sample_timedelta = rt._interval
    assert timedelta_parse(timedelta_format(sample_timedelta)) == sample_timedelta

# Generated at 2022-06-10 21:41:50.133298
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:26:55.431234') == datetime_module.timedelta(
        hours=2, minutes=26, seconds=55, microseconds=431234
    )



# Generated at 2022-06-10 21:41:57.447241
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=456,
    )
    assert timedelta_parse('01:02:03.000123') == datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=123,
    )

# Generated at 2022-06-10 21:42:08.368239
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=31)) == \
                                                            '00:00:2678400.000000'
    assert timedelta_format(datetime_module.timedelta(hours=18,
                                                      minutes=47,
                                                      seconds=8,
                                                      microseconds=7044)) == \
                                                            '18:47:08.007044'
    assert timedelta_format(datetime_module.timedelta(hours=18,
                                                      minutes=47,
                                                      seconds=8,
                                                      microseconds=7045)) == \
                                                            '18:47:08.007045'

# Generated at 2022-06-10 21:42:11.472894
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=6, minutes=6, seconds=6, microseconds=6
    )) == '06:06:06.000006'



# Generated at 2022-06-10 21:42:18.555540
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=456789)
    time = (datetime_module.datetime.min + timedelta).time()
    utf8 = time_isoformat(time, timespec='microseconds')
    assert utf8 == b'01:02:03.456789'
    assert timedelta_format(timedelta) == b'01:02:03.456789'
    # Let's also check that it's reversible:
    assert timedelta_parse(utf8) == timedelta



# Generated at 2022-06-10 21:42:26.689038
# Unit test for function timedelta_format
def test_timedelta_format():
    for microseconds in range(1000):
        assert timedelta_format(datetime_module.timedelta(microseconds=microseconds)) == \
               '00:00:00.{:06d}'.format(microseconds)
    for seconds in range(60):
        assert timedelta_format(datetime_module.timedelta(seconds=seconds)) == \
               '00:00:{:02d}.000000'.format(seconds)
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'


