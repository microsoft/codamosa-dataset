

# Generated at 2022-06-10 21:32:49.947564
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:05.000000') == datetime_module.timedelta(
        seconds=5)
    assert timedelta_parse('00:00:05.000001') == datetime_module.timedelta(
        seconds=5, microseconds=1)
    assert timedelta_parse('00:00:05.999999') == datetime_module.timedelta(
        seconds=5, microseconds=999999)
    assert timedelta_parse('00:09:05.999999') == datetime_module.timedelta(
        minutes=9, seconds=5, microseconds=999999)
    assert timedelta_parse('20:09:05.999999') == datetime_module

# Generated at 2022-06-10 21:32:58.270205
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
                                  datetime_module.timedelta(seconds=0)
    assert timedelta_parse('00:00:36.990000') == \
                                  datetime_module.timedelta(seconds=36,
                                                            microseconds=990000)
    assert timedelta_parse('02:04:05.670000') == \
                                  datetime_module.timedelta(hours=2,
                                                            minutes=4,
                                                            seconds=5,
                                                            microseconds=670000)

if PY2:
    try:
        import pathlib as pathlib_module
    except ImportError: # Python 2.7
        import pathlib2 as pathlib_module
else:
    import pathlib as pathlib_module

# Generated at 2022-06-10 21:33:09.042684
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('00:01:00.000001') == datetime_module.timedelta(
        minutes=1, microseconds=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
   

# Generated at 2022-06-10 21:33:13.626104
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == \
        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=5
    )) == '26:03:04.000005'



# Generated at 2022-06-10 21:33:22.529573
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)
    
    
    
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=-1, minutes=-2, seconds=-3, microseconds=-4
    ))) == datetime_module.timedelta(hours=-1, minutes=-2, seconds=-3,
                                     microseconds=-4)

# Generated at 2022-06-10 21:33:32.421734
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0
    )
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        hours=0, minutes=1, seconds=0, microseconds=0
    )
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=1, microseconds=0
    )
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )

# Generated at 2022-06-10 21:33:36.939679
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('14:05:34.260282') == datetime_module.timedelta(
        hours=14, minutes=5, seconds=34, microseconds=260282
    )



# Generated at 2022-06-10 21:33:42.237884
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=12345,
                                                       microseconds=6)) ==\
           '00:00:12.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=12345)) ==\
           '00:00:12.123000'



# Generated at 2022-06-10 21:33:45.911437
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse(timedelta_format(datetime_module.timedelta(7, 8, 9)))
    assert td == datetime_module.timedelta(7, 8, 9)

# Generated at 2022-06-10 21:33:56.489739
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) == '01:02:03.456000'
    assert timedelta_parse('01:02:03.456000') == datetime_module.timedelta(hours=1,
                                                                           minutes=2,
                                                                           seconds=3,
                                                                           microseconds=456000)


if hasattr(os, 'scandir'):
    def scandir(path='.'):
        return os.scandir(path)
else:
    def scandir(path='.'):
        return os.listdir(path)



# Generated at 2022-06-10 21:34:07.815055
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=7, minutes=11,
                                                      seconds=19,
                                                      microseconds=287512)) == \
                     '07:11:19.287512'



# Generated at 2022-06-10 21:34:12.196329
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(0, 5, 10)) == '00:00:05.000010'

test_timedelta_format()

# Generated at 2022-06-10 21:34:24.047321
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=127)) == \
                                                               '00:00:01.027000'
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
                                                                '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                                '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
                                                                '00:00:00.000100'



# Generated at 2022-06-10 21:34:28.066393
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3, minutes=4, seconds=5, microseconds=6789)) == '51:04:05.006789'



# Generated at 2022-06-10 21:34:31.578349
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(0, 1, 2)
    assert timedelta_format(td) == '00:00:01.000002'
    td = datetime_module.timedelta(3, 4, 5)
    assert timedelta_format(td) == '72:00:04.000005'
    td = datetime_module.timedelta(5, 45, 0, 13779)
    assert timedelta_format(td) == '120:45:00.013779'


# Generated at 2022-06-10 21:34:43.931869
# Unit test for function timedelta_format
def test_timedelta_format():
    # `timedelta.max` doesn't exist in Python 2.
    timedelta_max = datetime_module.timedelta.max
    if PY2:
        timedelta_max = datetime_module.timedelta(minutes=9999999)
    assert timedelta_format(timedelta_max) == '23:59:59.999999'
    timedelta_min = datetime_module.timedelta.min
    if PY2:
        timedelta_min = -timedelta_max
    assert timedelta_format(timedelta_min) == '-23:59:59.999999'

    some_timedelta = datetime_module.timedelta(hours=1, minutes=1,
                                               seconds=1, microseconds=1)


# Generated at 2022-06-10 21:34:52.031361
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))


if sys.version_info[:2] >= (3, 6):
    datetime_isoformat = datetime_module.datetime.isoformat
else:
    def datetime_isoformat(datetime):
        assert isinstance(datetime, datetime_module.datetime)
        return datetime.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]



# Generated at 2022-06-10 21:35:01.840628
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) \
          == '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=123)) \
          == '01:01:01.000123'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=123456)) \
          == '01:01:01.123456'



# Generated at 2022-06-10 21:35:10.302614
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                               '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                               '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1)) == \
                                                               '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
                                                               '01:01:01.000001'

# Generated at 2022-06-10 21:35:22.212831
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001')==datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:01:00.000001')==datetime_module.timedelta(minutes=1, microseconds=1)
    assert timedelta_parse('0:01:01.000001')==datetime_module.timedelta(minutes=1, seconds=1, microseconds=1)
    assert timedelta_parse('0:01:01.000000')==datetime_module.timedelta(minutes=1, seconds=1)
    assert timedelta_parse('1:01:01.000001')==datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)

test_timedelta_parse()

# Generated at 2022-06-10 21:35:54.832643
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_round_trip(s):
        assert timedelta_parse(timedelta_format(timedelta_parse(s))) == s

    assert_round_trip('00:09:34.056000')
    assert_round_trip('00:00:34.056000')
    assert_round_trip('00:00:09.056000')
    assert_round_trip('00:00:00.056000')
    assert_round_trip('00:00:00.000001')
    assert_round_trip('00:00:00.000000')
    assert_round_trip('00:00:00.000010')
    assert_round_trip('00:00:00.000100')
    assert_round_trip('00:00:00.001000')

# Generated at 2022-06-10 21:35:59.631920
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=12,
                                                      seconds=4,
                                                      microseconds=823)) \
        == '09:12:04.000823'


# Generated at 2022-06-10 21:36:14.866941
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:00:01.999999') == datetime_module.timedelta(
        seconds=1, microseconds=999999
    )

# Generated at 2022-06-10 21:36:20.168273
# Unit test for function timedelta_format
def test_timedelta_format():
    sample_timedelta = datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=123
    )
    sample_result = timedelta_format(sample_timedelta)
    assert sample_result == '02:03:04.000123'
    assert timedelta_parse(sample_result) == sample_timedelta



# Generated at 2022-06-10 21:36:30.517097
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for delta in [
        datetime_module.timedelta(days=3),
        datetime_module.timedelta(seconds=3),
        datetime_module.timedelta(seconds=3, microseconds=5),
        datetime_module.timedelta(seconds=3, microseconds=5,
                                  milliseconds=1),
        datetime_module.timedelta(seconds=3, microseconds=5,
                                  milliseconds=1, minutes=1, hours=1)
    ]:
        assert timedelta_parse(timedelta_format(delta)) == delta


from . import contexts
from .contexts import contextmanager_type
from . import with_metaclass
from .with_metaclass import with_metaclass as with_metaclass_
from . import six_metaclass

# Generated at 2022-06-10 21:36:32.832353
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.123456') == \
        datetime_module.timedelta(hours=0, minutes=1, seconds=2,
                                  microseconds=123456)



# Generated at 2022-06-10 21:36:42.260591
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == \
           datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                     microseconds=123456)
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(seconds=1, microseconds=1)

# Generated at 2022-06-10 21:36:48.115798
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45.678901')) == \
                                                          '01:23:45.678901'
    assert timedelta_format(timedelta_parse('1.23.45.678901')) == \
                                                          '01:23:45.678901'

# Generated at 2022-06-10 21:37:02.796355
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_timedelta_format(value, expected):
        result = timedelta_format(value)
        assert result == expected, ((value, result), (value, expected))
    assert_timedelta_format(datetime_module.timedelta(days=0), '00:00:00.000000')
    assert_timedelta_format(datetime_module.timedelta(days=1), '24:00:00.000000')
    assert_timedelta_format(datetime_module.timedelta(days=1, seconds=1), '24:00:01.000000')
    assert_timedelta_format(datetime_module.timedelta(days=1, seconds=1, microseconds=1), '24:00:01.000001')



# Generated at 2022-06-10 21:37:14.432715
# Unit test for function timedelta_format
def test_timedelta_format():
    assert isinstance(timedelta_format(datetime_module.timedelta(0)), str)
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 9)) == '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 99)) == '00:00:00.000099'
   

# Generated at 2022-06-10 21:38:10.893140
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.010101') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10101)
    assert timedelta_parse('1:01:01.000001') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=1)
    assert timedelta_parse('1:01:01.000000') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_parse('1:01:01') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_parse('1:01') == \
           datetime

# Generated at 2022-06-10 21:38:22.615949
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    s = timedelta_format(timedelta)
    assert timedelta == timedelta_parse(s)


if sys.version_info[:2] >= (3, 7):
    def is_subclass_base_of(subclass, base):
        '''Check if subclass is a subclass of base.'''
        return issubclass(subclass, base)
else:
    def is_subclass_base_of(subclass, base):
        '''Check if subclass is a subclass of base.'''
        return base in getattr(subclass, '__mro__', [])

# Generated at 2022-06-10 21:38:26.872803
# Unit test for function timedelta_format
def test_timedelta_format():
    for x in range(0, 1000000):
        duration = x / 1000000
        m1 = timedelta_format(datetime_module.timedelta(seconds=duration))
        m2 = str(datetime_module.timedelta(seconds=duration))
        assert m1 == m2

test_timedelta_format()



# Generated at 2022-06-10 21:38:42.165794
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('1:0.000001')) == '01:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('0:0.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('0:0.001000')) == '00:00:00.001000'
    assert timedelta_format(timedelta_parse('0:0.010000')) == '00:00:00.010000'
   

# Generated at 2022-06-10 21:38:46.273257
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=7,
                                                      minutes=31,
                                                      seconds=46,
                                                      milliseconds=735)) == \
                                                            '07:31:46.735000'



# Generated at 2022-06-10 21:38:57.547892
# Unit test for function timedelta_format
def test_timedelta_format():
    td1 = timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1,
                                                                    minutes=2,
                                                                    seconds=3,
                                                                    microseconds=4567)))
    td2 = timedelta_parse(timedelta_format(datetime_module.timedelta(hours=23,
                                                                    minutes=59,
                                                                    seconds=59,
                                                                    microseconds=999999)))
    assert td1 == datetime_module.timedelta(hours=1,
                                            minutes=2,
                                            seconds=3,
                                            microseconds=4567)

# Generated at 2022-06-10 21:39:08.212693
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:39:16.546189
# Unit test for function timedelta_format
def test_timedelta_format():
    def test(timedelta, expected_string):
        assert timedelta_format(timedelta) == expected_string
    test(
        datetime_module.timedelta(hours=10, minutes=50, seconds=6,
                                  microseconds=1729),
        '10:50:06.001729'
    )
    test(
        datetime_module.timedelta(hours=0, minutes=0, seconds=6,
                                  microseconds=1729),
        '00:00:06.001729'
    )
    test(
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=1729),
        '00:00:00.001729'
    )



# Generated at 2022-06-10 21:39:26.492633
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('13:37:42.001010') == \
           datetime_module.timedelta(hours=13, minutes=37, seconds=42,
                                     microseconds=1010)


if PY2:

    if 'unicode' not in dir(__builtins__):
        unicode = text_type

    if 'xrange' not in dir(__builtins__):
        xrange = range

    def isidentifier(s):
        try:
            s = unicode(s)
        except TypeError:
            return False
        else:
            return s.isidentifier()

    def unit_test():

        def _test(s, expected_result):
            result = isidentifier(s)
            assert result == expected_result, result

        _test(u'abc', True)


# Generated at 2022-06-10 21:39:30.147607
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=7, minutes=34, seconds=7,
                                  microseconds=93658)
    ) == '07:34:07.093658'


# Generated at 2022-06-10 21:40:31.226063
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(12, 34, 56, 123456)

# Generated at 2022-06-10 21:40:39.923400
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(days=1, weeks=1, minutes=1, seconds=1,
                                  microseconds=1)
    s = timedelta_format(t)
    assert s == '156:31:01.000001'
    assert timedelta_parse(s) == t
    assert timedelta_parse(s) == datetime_module.timedelta(weeks=1,
                                                           seconds=1,
                                                           minutes=1,
                                                           microseconds=1)

test_timedelta_format()



# Generated at 2022-06-10 21:40:48.859135
# Unit test for function timedelta_parse
def test_timedelta_parse():
    t = timedelta_parse('0:00:00.000000')
    assert t == datetime_module.timedelta(0)
    t = timedelta_parse('1:00:00.000000')
    assert t == datetime_module.timedelta(hours=1)
    t = timedelta_parse('1:00:01.000000')
    assert t == datetime_module.timedelta(hours=1, seconds=1)
    t = timedelta_parse('1:00:01.000001')
    assert t == datetime_module.timedelta(hours=1, seconds=1,
                                          microseconds=1)
    t = timedelta_parse('1:00:01.100000')

# Generated at 2022-06-10 21:40:52.060857
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, seconds=2,
                                          microseconds=3)
    assert timedelta_format(timedelta) == '48:00:02.000003'


# Generated at 2022-06-10 21:41:02.338184
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=2)
    ) == '00:00:00.000002'
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    ) == '25:01:01.000001'
    
    

# Generated at 2022-06-10 21:41:05.398611
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == (
        datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                  microseconds=123456)
    )

# Generated at 2022-06-10 21:41:09.137500
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)

# Generated at 2022-06-10 21:41:12.071332
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=6, minutes=35, seconds=28, microseconds=1234
    )
    assert timedelta_format(timedelta) == '06:35:28.001234'

# Generated at 2022-06-10 21:41:18.104324
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta()), '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
             '00:00:01.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(hours=1)),
             '01:00:00.000000')



# Generated at 2022-06-10 21:41:22.880190
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('01:02:03.000045') == \
           datetime_module.timedelta(0, 3723, 45)
    assert timedelta_parse('01:02:03.000045') == \
           datetime_module.timedelta(seconds=3723, microseconds=45)