

# Generated at 2022-06-10 21:32:51.053777
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:05.000001') == datetime_module.timedelta(
        seconds=5,
        microseconds=1
    )
    assert timedelta_parse('00:00:05.000010') == datetime_module.timedelta(
        seconds=5,
        microseconds=10
    )
    assert timedelta_parse('00:00:05.000100') == datetime_module.timedelta(
        seconds=5,
        microseconds=100
    )
    assert timedelta_parse('00:00:05.001000') == datetime_module.timedelta(
        seconds=5,
        microseconds=1000
    )
    assert timedelta_

# Generated at 2022-06-10 21:32:54.279910
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=-1, hours=-23, minutes=-59,
                                          seconds=-59, microseconds=-999999)
    assert timedelta_format(timedelta) == '-47:59:59.999999'



# Generated at 2022-06-10 21:32:58.270462
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:02:03:000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )


# Generated at 2022-06-10 21:33:09.041733
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:33:12.028710
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-10 21:33:18.390287
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == \
           datetime_module.timedelta(microseconds=10000)
    assert timedelta_parse('00:00:00.100000') == \
           datetime_module.timedelta(microseconds=100000)

# Generated at 2022-06-10 21:33:29.086985
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=10)) == \
                                                      '00:00:00.000010'

# Generated at 2022-06-10 21:33:35.016080
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=13,
                                                      minutes=8, seconds=31,
                                                      microseconds=424242)) \
           == '13:08:31.424242'


# Generated at 2022-06-10 21:33:45.452184
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-100500)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-100500)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=-100500)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=-100500)) == '00:01:40.500000'

    assert timedelta_format(datetime_module.timedelta(hours=-3, minutes=-2, seconds=-1, microseconds=-2)) == '-03:02:01.000002'

# Generated at 2022-06-10 21:33:55.656490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
            '03:00:00.000000'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, minutes=6, seconds=7, microseconds=5
    ))) == datetime_module.timedelta(hours=3, minutes=6, seconds=7,
                                     microseconds=5)


try:
    from importlib.resources import path as pathlib_path
except ImportError:
    # This is probably Python 3.5, or Python 3.6+ with the importlib-resources
    # package not installed
    pathlib_path = None

# Workaround for https://bugs.python.org/issue29689:

# Generated at 2022-06-10 21:34:12.452258
# Unit test for function timedelta_format
def test_timedelta_format():
    timedeltas = [
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456),
        datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                  microseconds=0),
        datetime_module.timedelta(hours=0, minutes=0, seconds=1,
                                  microseconds=123456),
        datetime_module.timedelta(hours=0, minutes=1, seconds=0,
                                  microseconds=123456),
        datetime_module.timedelta(hours=1, minutes=0, seconds=0,
                                  microseconds=123456),
    ]
    for timedelta in timedeltas:
        time = (datetime_module.datetime.min + timedelta).time()


# Generated at 2022-06-10 21:34:24.416666
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('59:59:59.999999') == datetime_module.timedelta(
        hours=59, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('59:59:59.999998') == datetime_module.timedelta(
        hours=59, minutes=59, seconds=59, microseconds=999998
    )
    assert timedelta_parse('59:59:59.000123') == datetime_module.timedelta(
        hours=59, minutes=59, seconds=59, microseconds=123
    )
    assert timedelta_parse('01:23:45.123456') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=123456
    )
    assert timedelta

# Generated at 2022-06-10 21:34:27.577366
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        seconds=.123456789
    )) == '00:00:00.123456'


# Generated at 2022-06-10 21:34:29.411192
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=1,
                minutes=1, seconds=1, microseconds=1))



# Generated at 2022-06-10 21:34:41.197788
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.012345') \
                                 == datetime_module.timedelta(microseconds=12345)
    assert timedelta_parse('0:00:01.012345') \
                                 == datetime_module.timedelta(seconds=1,
                                                              microseconds=12345)
    assert timedelta_parse('0:01:01.012345') \
                        == datetime_module.timedelta(minutes=1, seconds=1,
                                                     microseconds=12345)
    assert timedelta_parse('1:01:01.012345') \
                        == datetime_module.timedelta(hours=1, minutes=1,
                                                     seconds=1,
                                                     microseconds=12345)



# Generated at 2022-06-10 21:34:51.778177
# Unit test for function timedelta_format
def test_timedelta_format():
    for first, second in ((datetime_module.timedelta(0), '00:00:00.000000'),
                          (datetime_module.timedelta(seconds=1),
                           '00:00:01.000000'),
                          (datetime_module.timedelta(minutes=1),
                           '00:01:00.000000'),
                          (datetime_module.timedelta(hours=1),
                           '01:00:00.000000'),
                          (datetime_module.timedelta(days=1),
                           '24:00:00.000000'),
                          (datetime_module.timedelta(microseconds=1),
                           '00:00:00.000001'),
                          ):
        assert timedelta_format(first) == second



# Generated at 2022-06-10 21:35:02.553752
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_equals(actual, expected):
        assert isinstance(actual, datetime_module.timedelta), actual
        assert isinstance(expected, datetime_module.timedelta), expected
        assert actual == expected

    assert_timedelta_equals(timedelta_parse('00:00:00.000000'),
                            datetime_module.timedelta(0))
    assert_timedelta_equals(timedelta_parse('00:00:00.000001'),
                            datetime_module.timedelta(microseconds=1))
    assert_timedelta_equals(timedelta_parse('00:00:00.100000'),
                            datetime_module.timedelta(microseconds=100000))

# Generated at 2022-06-10 21:35:11.110354
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=61)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-10 21:35:23.139066
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:0:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.0') == \
                                datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('0:00:00.1') == \
                                datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('0:00:00.12') == \
                                datetime_module.timedelta(microseconds=120)

# Generated at 2022-06-10 21:35:32.165721
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=5
    ))) == datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=5
    )

# Generated at 2022-06-10 21:35:53.303955
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=7, seconds=1, microseconds=1))) == (
            datetime_module.timedelta(days=7, seconds=1, microseconds=1)
        )

# Generated at 2022-06-10 21:35:58.646976
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


# Generated at 2022-06-10 21:36:03.755761
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:45:56.123456') == datetime_module.timedelta(
        hours=12,
        minutes=45,
        seconds=56,
        microseconds=123456,
    )



# Generated at 2022-06-10 21:36:07.309718
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
           datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(10))) == \
           datetime_module.timedelta(10)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 1))) == \
           datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 0, 1))) == \
           datetime_module.timedelta(0, 0, 0, 1)

# Generated at 2022-06-10 21:36:16.854582
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.999999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=999999
    )
    assert timedelta_parse('1:02:03.999999') == timedelta_parse(
        '1:02:03.999:999')
    assert timedelta_parse('1:02:03.999999') == timedelta_parse(
        '1:02:03.999999z')

# Generated at 2022-06-10 21:36:26.898606
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in [
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(seconds=123),
        datetime_module.timedelta(seconds=123, microseconds=456),
        datetime_module.timedelta(seconds=1, hours=2, minutes=3),
        datetime_module.timedelta(seconds=1, hours=2, minutes=3, microseconds=456),
    ]:
        s = timedelta_format(timedelta)
        assert isinstance(s, str)
        assert len(s) == 15
        assert timedelta == timedelta_parse(s)



# Generated at 2022-06-10 21:36:31.247126
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2))) == datetime_module.timedelta(1, 2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(3, 4, 5))) == datetime_module.timedelta(3, 4, 5)



# Generated at 2022-06-10 21:36:41.304869
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        0, 1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        0, 1, 1)
    assert timedelta_parse('00:01:02.000003') == datetime_module.timedelta(
        0, 62, 3)
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        3723, 3, 4)

# Generated at 2022-06-10 21:36:46.490819
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=21)) == \
           '03:21:00.000000'



# Generated at 2022-06-10 21:36:52.702129
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if PY2:
        return
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

test_timedelta_parse()

# Generated at 2022-06-10 21:37:43.236498
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                             '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                             '00:00:00.000001'
    
    

# Generated at 2022-06-10 21:37:49.948540
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s, expected_value in (
        ('00:02:37.601600', datetime_module.timedelta(minutes=2, seconds=37,
                                                      microseconds=601600)),
        ('00:00:00.000400', datetime_module.timedelta(microseconds=400)),
        ('00:00:00.000000', datetime_module.timedelta())
    ):
        assert timedelta_parse(s) == expected_value


_TIMEDELTA_TYPE = type(datetime_module.timedelta(0))


# Generated at 2022-06-10 21:37:57.454478
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import assert_equal
    assert_equal(timedelta_format(timedelta_parse('0:0:0.123456')),
                 '00:00:00.123456')
    assert_equal(timedelta_format(timedelta_parse('1:1:1.123456')),
                 '01:01:01.123456')
    assert_equal(timedelta_format(timedelta_parse('11:11:11.123456')),
                 '11:11:11.123456')
    assert_equal(timedelta_format(timedelta_parse('22:22:22.123456')),
                 '22:22:22.123456')

# Generated at 2022-06-10 21:38:09.943960
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:02:03.0000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('1:02:03.0000050') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=50
    )
    assert timedelta_parse('1:02:03.0000600') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=600
    )

# Generated at 2022-06-10 21:38:14.088251
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(seconds=1)
    ) == '00:00:01.000000'


# Generated at 2022-06-10 21:38:25.219525
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.01') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=10
    )
    assert timedelta_parse('01:01:01.01') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=10
    )
    assert timedelta_parse('1:01:01.01') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=10
    )
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=100
    )
    assert timedelta_parse('1:1:1') == dat

# Generated at 2022-06-10 21:38:32.445498
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.0001') == datetime_module.timedelta(
        microseconds=1,
    )
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )

# Generated at 2022-06-10 21:38:37.864138
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=123_456)
    assert timedelta_format(timedelta) == '02:03:04.123456'


# Generated at 2022-06-10 21:38:50.177296
# Unit test for function timedelta_parse
def test_timedelta_parse():
    result = (timedelta_parse('1:02:03.123456') ==
              datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                        microseconds=123456))
    if not result:
        raise AssertionError


if PY3:
    def open_as_text(file_path, encoding='utf-8'):
        return open(file_path, 'rt', encoding=encoding)
    def open_as_binary(file_path):
        return open(file_path, 'rb')
else:
    def open_as_text(file_path, encoding='utf-8'):
        return open(file_path, 'r')
    def open_as_binary(file_path):
        return open(file_path, 'rb')



# Generated at 2022-06-10 21:38:58.874689
# Unit test for function timedelta_format
def test_timedelta_format():
    from python_toolbox import cute_testing
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=4)
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == \
           '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           time_isoformat(time, timespec='microseconds')



# Generated at 2022-06-10 21:40:48.401166
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse('') == datetime_module.timedelta()
    assert timedelta_parse('1') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:2') == datetime_module.timedelta(hours=1, minutes=2)
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('1:2:3:4') == dat

# Generated at 2022-06-10 21:40:54.985933
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:34:56.7890') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789000
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )



# Generated at 2022-06-10 21:41:04.514557
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)

# Generated at 2022-06-10 21:41:08.027384
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1)

if PY3:
    def is_string(x):
        return isinstance(x, str)
else:
    def is_string(x):
        return isinstance(x, (str, unicode))

# Generated at 2022-06-10 21:41:10.655519
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'

# Generated at 2022-06-10 21:41:20.983320
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=30)) == (
        '00:00:30.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=45)) == (
        '00:00:45.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(days=1)) == (
        '24:00:00.000000'
    )

# Generated at 2022-06-10 21:41:22.762193
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)

# Generated at 2022-06-10 21:41:36.141810
# Unit test for function timedelta_parse
def test_timedelta_parse():
    tests = [
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('00:00:00.000001', datetime_module.timedelta(microseconds=1)),
        ('00:00:00.999999', datetime_module.timedelta(microseconds=999999)),
        ('00:00:01.000000', datetime_module.timedelta(seconds=1)),
        ('00:59:59.999999', datetime_module.timedelta(minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)),
        ('23:59:59.999999', datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)),
    ]
   

# Generated at 2022-06-10 21:41:40.529246
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:20:00.000012') == datetime_module.timedelta(
        hours=1, minutes=20, seconds=0, microseconds=12
    )



# Generated at 2022-06-10 21:41:52.475514
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(microseconds=3003)) == '00:00:03.003000'
    assert timedelta_format(datetime_module.timedelta(microseconds=333003)) == '00:03:33.003000'
    assert timed