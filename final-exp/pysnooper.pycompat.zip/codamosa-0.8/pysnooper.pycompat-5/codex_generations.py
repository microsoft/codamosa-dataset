

# Generated at 2022-06-10 21:32:44.520759
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.005678') == (
        datetime_module.timedelta(hours=2,
                                  minutes=3,
                                  seconds=4,
                                  microseconds=5678)
    )
    assert timedelta_parse('2:3:4.005678') == (
        datetime_module.timedelta(hours=2,
                                  minutes=3,
                                  seconds=4,
                                  microseconds=5678)
    )

# Generated at 2022-06-10 21:32:52.339478
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=7200)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=7200)) == '1439:59:59.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=3000)) == '00:00:00.003000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3123000)) == '00:52:03.123000'



# Generated at 2022-06-10 21:33:00.940513
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.123000') == datetime_module.timedelta(seconds=1, microseconds=123000)
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(seconds=1, microseconds=123456)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse

# Generated at 2022-06-10 21:33:11.313854
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )
    assert timedelta_parse('00:01:01.123456') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=123456
    )
    assert timedelta_parse('01:01:01.123456') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123456
    )

# Generated at 2022-06-10 21:33:18.092486
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('3:02:01') == datetime_module.timedelta(
        hours=3, minutes=2, seconds=1
    )
    assert timedelta_parse('3:02:01.102') == datetime_module.timedelta(
        hours=3, minutes=2, seconds=1, microseconds=102
    )
    assert timedelta_parse('3:02:01.012345') == datetime_module.timedelta(
        hours=3, minutes=2, seconds=1, microseconds=12345
    )
    assert timedelta_parse('3:02:01.012345678') == datetime_module.timedelta(
        hours=3, minutes=2, seconds=1, microseconds=123456
    )

# Generated at 2022-06-10 21:33:21.396256
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=4)
    assert time_isoformat(time) == '01:02:03.000004'


# Generated at 2022-06-10 21:33:29.971433
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.123456') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123456
    )
    # Make sure it's not affecting the results by rounding off microseconds:
    assert timedelta_parse('1:1:1.123457') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123457
    )
    assert timedelta_parse('1:1:1.123458') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=123458
    )

# Generated at 2022-06-10 21:33:36.146371
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=16, minutes=19, seconds=23,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '16:19:23.123456'



# Generated at 2022-06-10 21:33:39.768151
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.010101') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=10101
    )



# Generated at 2022-06-10 21:33:48.297971
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=6,
                                                      seconds=7,
                                                      microseconds=8)) == \
        '05:06:07.000008'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                     minutes=2,
                                                     seconds=60*60+5,
                                                     microseconds=1000)) == \
        '01:02:01.001000'
    assert timedelta_format(datetime_module.timedelta(days=-10,
                                                     minutes=-1,
                                                     seconds=-2)) == \
        '&10_00:59:58.000000'

# Generated at 2022-06-10 21:34:09.167471
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=5, minutes=2, seconds=1,
                                      microseconds=123456)
    assert timedelta_format(delta) == '05:02:01.123456'
    delta = datetime_module.timedelta(hours=5, minutes=2, seconds=1,
                                      microseconds=123)
    assert timedelta_format(delta) == '05:02:01.000123'
    delta = datetime_module.timedelta(hours=5, minutes=2, seconds=1,
                                      microseconds=1)
    assert timedelta_format(delta) == '05:02:01.000001'
    delta = datetime_module.timedelta(hours=5, minutes=2, seconds=1,
                                      microseconds=0)


# Generated at 2022-06-10 21:34:11.225400
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:34:17.358495
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()

if PY3:
    def get_qualname(thing):
        return thing.__qualname__
else:
    def get_qualname(thing):
        return '{}.{}'.format(
            thing.__module__,
            thing.__name__
        )

# Generated at 2022-06-10 21:34:28.809878
# Unit test for function timedelta_format
def test_timedelta_format():
    from garlicsim.general_misc import cute_testing
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ) == '01:02:03.456789'

    cute_testing.assert_nearly_equal(
        timedelta_format(
            datetime_module.timedelta(seconds=60 * 60 * 23 + 60 * 60 * 0.12345)
        ),
        '23:00:00.123000'
    )


if hasattr(datetime_module.date, 'fromisoformat'):
    date_fromisoformat = datetime_module.date.fromisoformat

# Generated at 2022-06-10 21:34:40.475285
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import assert_equivalent
    assert_equivalent(timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=86399, microseconds=999999)
    )), datetime_module.timedelta(seconds=86399, microseconds=999999))
    assert_equivalent(timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=0, microseconds=0)
    )), datetime_module.timedelta(seconds=0, microseconds=0))
    assert_equivalent(timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1, microseconds=1)
    )), datetime_module.timedelta(seconds=1, microseconds=1))


# Generated at 2022-06-10 21:34:51.291873
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:35:06.553628
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_from_string = timedelta_parse
    assert timedelta_from_string('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_from_string('0:00:00.012345') == datetime_module.timedelta(0, 0, 12345)
    assert timedelta_from_string('0:00:01.234000') == datetime_module.timedelta(0, 1, 234000)
    assert timedelta_from_string('0:23:00.000000') == datetime_module.timedelta(0, 1380)
    assert timedelta_from_string('23:00:00.000000') == datetime_module.timedelta(1, 82800)

# Generated at 2022-06-10 21:35:08.615258
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('13:37:42.137000')) == \
                                                        '13:37:42.137000'



# Generated at 2022-06-10 21:35:20.689597
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('3:04:05.000123') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=123
    )
    assert timedelta_parse('3:4:5.000123') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=123
    )
    assert timedelta_parse('03:04:05.000123') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=123
    )

# Generated at 2022-06-10 21:35:31.719998
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('1:02:03.123456')
    assert td.__class__ is datetime_module.timedelta
    assert td.seconds == (1*3600 + 2*60 + 3)
    assert td.microseconds == 123456

    td = timedelta_parse('1234:05:06.012345')
    assert td.__class__ is datetime_module.timedelta
    assert td.seconds == (1234*3600 + 5*60 + 6)
    assert td.microseconds == 12345

    td = timedelta_parse('12:03:04.012345')
    assert td.__class__ is datetime_module.timedelta
    assert td.seconds == (12*3600 + 3*60 + 4)
    assert td.microseconds == 12345


# Generated at 2022-06-10 21:35:48.700257
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
        datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1))) == \
        datetime_module.timedelta(1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1, 1))) == \
        datetime_module.timedelta(1, 1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1, 1, 1))) == \
        datetime_module.timedelta(1, 1, 1, 1)

# Generated at 2022-06-10 21:35:56.995556
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.1')) == '00:00:00.100000'
    assert timedelta_format(timedelta_parse('1:2:3.4')) == '01:02:03.400000'

test_timedelta_parse()

# Generated at 2022-06-10 21:36:00.574431
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.max) == \
           '23:59:59.999999'



# Generated at 2022-06-10 21:36:11.158389
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                                                           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == \
                                                           '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(minutes=3,
                                                      seconds=10,
                                                      microseconds=123456)) == \
                                                           '00:03:10.123456'

# Generated at 2022-06-10 21:36:22.227388
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(0, 0, 999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(0, 1, 999999)

# Generated at 2022-06-10 21:36:27.805193
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '20:06:13.249876'
    expected = (20 * 60 + 6) * 60 + 13
    parsed = timedelta_parse(s)
    seconds = parsed.days * 24 * 60 * 60 + parsed.seconds
    assert seconds == expected
    assert parsed.microseconds == 249876
    assert timedelta_format(parsed) == s

# Generated at 2022-06-10 21:36:38.214741
# Unit test for function timedelta_parse
def test_timedelta_parse():
    zero = datetime_module.timedelta()
    assert timedelta_format(zero) == '00:00:00.000000'
    assert timedelta_parse(timedelta_format(zero)) == zero
    one_minute = datetime_module.timedelta(minutes=1)
    assert timedelta_format(one_minute) == '00:01:00.000000'
    assert timedelta_parse(timedelta_format(one_minute)) == one_minute
    assert timedelta_parse('1:2:3.456000') == one_minute + \
                                              datetime_module.timedelta(
                                                   seconds=3,
                                                   microseconds=456000)

# Generated at 2022-06-10 21:36:42.495072
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.123456') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=123456)

    assert timedelta_parse('02:00:00.000000') == datetime_module.timedelta(
        hours=2)



# Generated at 2022-06-10 21:36:54.955114
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('0:0:0.000000').microseconds == 0
    timedelta_parse('0:0:0.000001').microseconds == 1
    timedelta_parse('0:0:0.999999').microseconds == 999999
    timedelta_parse('0:0:1.000000').microseconds == 0
    timedelta_parse('0:0:1.000001').microseconds == 1
    timedelta_parse('0:0:1.999999').microseconds == 999999
    timedelta_parse('0:1:0.000000').microseconds == 0
    timedelta_parse('0:1:0.000001').microseconds == 1
    timedelta_parse('0:1:0.999999').microseconds == 999999
    timedelta_parse('0:1:1.000000').microseconds == 0


# Generated at 2022-06-10 21:36:58.317262
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, seconds=2)
    ) == '01:00:02.000000'




# Generated at 2022-06-10 21:37:17.207589
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=120)) \
           == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) \
           == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) \
           == '00:00:00.001234'



# Generated at 2022-06-10 21:37:26.509300
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    compare = lambda x: x == timedelta_parse(timedelta_format(x))
    assert compare(datetime_module.timedelta(hours=1, minutes=2, seconds=3))
    assert compare(datetime_module.timedelta(minutes=2, seconds=3,
                                             microseconds=456))
    assert compare(datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                             microseconds=456))
    assert compare(
        datetime_module.timedelta(days=3, hours=1, minutes=2, seconds=3,
                                  microseconds=456)
    )

    assert compare(datetime_module.timedelta(0))
    assert compare(datetime_module.timedelta(microseconds=1))
   

# Generated at 2022-06-10 21:37:32.024821
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=567)) == \
                                                          '26:03:04.00567'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=567)) == \
                                                          '02:03:04.00567'
    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=4,
                                                      microseconds=567)) == \
                                                          '00:03:04.00567'

# Generated at 2022-06-10 21:37:41.558195
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-123)) == \
                                                               '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0,
                                                      hours=48,
                                                      minutes=2)) == \
                                                               '48:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=123,
                                                      hours=47,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
                                                               '47:59:59.999999'

test_timedelta_format()



# Generated at 2022-06-10 21:37:50.700652
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'
    timedelta = datetime_module.timedelta(days=1, hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '25:02:03.000004'
    timedelta = datetime_module.timedelta(days=2, hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '49:02:03.000004'


# Generated at 2022-06-10 21:37:53.082795
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '12:13.4000000'
    assert timedelta_parse(s) == datetime_module.timedelta(hours=12, minutes=13,
                                                            seconds=0,
                                                            microseconds=4000)



# Generated at 2022-06-10 21:37:58.020642
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=4)



# Generated at 2022-06-10 21:38:02.864315
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=10, minutes=50, seconds=20,
                                  microseconds=1001)
    ) == '10:50:20.001000'


# Generated at 2022-06-10 21:38:09.931339
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in (
        '0:0:0.000000',
        '3:4:5.023400',
        '12:43:59.99999',
    ):
        assert timedelta_parse(s) == datetime_module.timedelta(
            hours=int(s[:2]),
            minutes=int(s[3:5]),
            seconds=int(s[6:8]),
            microseconds=int(s[9:]),
        )

# Generated at 2022-06-10 21:38:23.223488
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.400000') == datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3,
                                                                   microseconds=400000)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(hours=0,
                                                                   minutes=0,
                                                                   seconds=0,
                                                                   microseconds=0)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(hours=0,
                                                                   minutes=0,
                                                                   seconds=1,
                                                                   microseconds=0)
    assert timedelta_parse('0:0:1.000001') == datetime_module.tim

# Generated at 2022-06-10 21:38:58.411210
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(0)
    assert timedelta_parse('02:00:00.000000') == \
           datetime_module.timedelta(hours=2)
    assert timedelta_parse('02:00:00.000001') == \
           datetime_module.timedelta(hours=2, microseconds=1)
    assert timedelta_parse('02:00:00.000010') == \
           datetime_module.timedelta(hours=2, microseconds=10)
    assert timedelta_parse('02:00:00.000100') == \
           datetime_module.timedelta(hours=2, microseconds=100)

# Generated at 2022-06-10 21:39:01.587320
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-10 21:39:05.545638
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('1:23:45.678901')
    assert td == datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                           microseconds=678901)



# Generated at 2022-06-10 21:39:09.908920
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

if PY3:
    range = range
    zip = zip
else:
    range = xrange
    zip = itertools.izip


# Generated at 2022-06-10 21:39:17.284271
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:35:22.123123') == (datetime_module.timedelta(
        hours=2, minutes=35, seconds=22, microseconds=123123))
    assert timedelta_parse('0:0:1.000000') == (datetime_module.timedelta(
        hours=0, minutes=0, seconds=1))
    assert timedelta_parse('0:0:0.100000') == (datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=100000))



# Generated at 2022-06-10 21:39:21.570865
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                          microseconds=1)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-10 21:39:26.203419
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=12, minutes=32, seconds=53, microseconds=675543
    ))) == datetime_module.timedelta(
        hours=12, minutes=32, seconds=53, microseconds=675543
    )


if PY3:
    import collections.abc as collections_abc
else:
    import collections as collections_abc

# Generated at 2022-06-10 21:39:29.925339
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                  microseconds=678901)
    ) == '01:23:45.678901'

# Generated at 2022-06-10 21:39:33.266951
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, milliseconds=678, microseconds=901
    )

# Generated at 2022-06-10 21:39:41.076199
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=1,
                                                      seconds=2,
                                                      minutes=3,
                                                      hours=4)) == '04:03:02.000002'



# Generated at 2022-06-10 21:40:41.581478
# Unit test for function timedelta_parse
def test_timedelta_parse():

    for dt in range(100):
        for t in range(100):
            for s in range(100):
                for m in range(100):
                    assert timedelta_parse(
                        timedelta_format(datetime_module.timedelta(
                            days=dt, hours=t, seconds=s, microseconds=m
                        ))
                    ) == datetime_module.timedelta(days=dt, hours=t,
                                                    seconds=s,
                                                    microseconds=m)
                                                    


# Generated at 2022-06-10 21:40:49.451799
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, microseconds=2)) == '00:01:00.000002'
    assert timedelta_format(datetime_module.timedelta(minutes=1, microseconds=20)) == '00:01:00.000020'
    assert timedelta_format(datetime_module.timedelta(minutes=1, microseconds=200)) == '00:01:00.000200'
    assert timedelta_format(datetime_module.timedelta(minutes=1, microseconds=2000)) == '00:01:00.002000'

# Generated at 2022-06-10 21:40:59.551705
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:59:58.070000') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=58, microseconds=70000
    )


if PY3:
    def string_to_type(string):
        assert isinstance(string, str)
        if not string:
            return None
        try:
            return eval(string)
        except SyntaxError:
            raise RuntimeError("Can't evaluate `{}`".format(string))
else:
    def string_to_type(string):
        if not isinstance(string, (str, unicode)):
            raise RuntimeError("`string` must be a string or unicode, not {}.".format(
                type(string)
            ))
        if not string:
            return None

# Generated at 2022-06-10 21:41:03.554933
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=29, minutes=59, seconds=59)
    )) == datetime_module.timedelta(hours=29, minutes=59, seconds=59)



# Generated at 2022-06-10 21:41:08.073211
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:11:11.111111')) == \
           '01:11:11.111111'
    assert timedelta_format(timedelta_parse('1:11:11.0000')) == \
           '01:11:11.000000'

# Generated at 2022-06-10 21:41:12.912644
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
        '01:02:03.000004'

    assert timedelta_parse('1:2:3.4') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000)

# Generated at 2022-06-10 21:41:19.468287
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, hours=1,
                                                      minutes=2, seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(days=5, hours=6,
                                                      minutes=7, seconds=8,
                                                      microseconds=9)) == \
           '182:07:08.000009'



# Generated at 2022-06-10 21:41:23.528118
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=5, hours=5, minutes=5, seconds=5,
                                  microseconds=5)
    ) == '05:05:05.000005'



# Generated at 2022-06-10 21:41:34.312621
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5)) == '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, seconds=3.2)) == '48:00:03.200000'
    assert timedelta_format(datetime_module.timedelta(days=2, seconds=3.123456)) == '48:00:03.123456'
    assert timedelta_format(datetime_module.timedelta(days=2, seconds=3.1234)) == '48:00:03.123400'



# Generated at 2022-06-10 21:41:43.227943
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1))
    ) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(minutes=1))
    ) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(seconds=1))
    ) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(microseconds=1))
    ) == datetime_module