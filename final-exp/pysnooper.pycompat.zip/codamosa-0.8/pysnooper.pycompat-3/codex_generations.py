

# Generated at 2022-06-10 21:32:48.299340
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Make sure that `timedelta_parse` with `timedelta_format` is the identity
    function."""
    from framework import test_utils
    from . import toolz
    for _ in toolz.times(10000):
        timedelta = datetime_module.timedelta(
            seconds=test_utils.random_float(),
            microseconds=test_utils.random_float()
        )
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    print('All tests passed.')



# Generated at 2022-06-10 21:32:52.939522
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )) == '01:02:03.123456'

    assert timedelta_format(datetime_module.timedelta(
        hours=20, minutes=30, seconds=40, microseconds=123456
    )) == '20:30:40.123456'

    assert timedelta_format(datetime_module.timedelta(
        hours=200, minutes=300, seconds=400, microseconds=123456
    )) == '200:300:400.123456'



# Generated at 2022-06-10 21:32:56.666704
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, minutes=1, microseconds=1)
    assert timedelta_format(timedelta) == '24:01:00.000001'


if PY2:
    import __builtin__ as builtins
else:
    import builtins



# Generated at 2022-06-10 21:33:00.142144
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=400000)
    assert timedelta_format(delta) == '01:02:03.400000'


# Generated at 2022-06-10 21:33:02.335175
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      seconds=14,
                                                      microseconds=53)) \
                                                      == '03:00:14.000003'

# Generated at 2022-06-10 21:33:05.941383
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=3,
                                                      seconds=3,
                                                      microseconds=3)) == \
                                                      '03:03:03.000003'



# Generated at 2022-06-10 21:33:14.806833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import assert_equal
    assert_equal(timedelta_parse('1:2:3.4'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))
    assert_equal(timedelta_parse('1:2:3.400000'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    ))
    assert_equal(timedelta_parse('1:2:3.003000'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=300
    ))

# Generated at 2022-06-10 21:33:25.492136
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    with pytest.raises(ValueError):
        timedelta_format(datetime_module.timedelta(hours=1, microseconds=1))
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'

# Generated at 2022-06-10 21:33:28.263899
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import doctest
    from garlicsim.general_misc import cute_testing
    assert cute_testing.run_doctest(timedelta_parse, doctest)

# Generated at 2022-06-10 21:33:33.581525
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('3:05:01.123456') == datetime_module.timedelta(
        hours=3, minutes=5, seconds=1, microseconds=123456
    )

# Generated at 2022-06-10 21:33:54.752359
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('.000000') == datetime_module.timedelta()
    assert timedelta_parse('0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('0:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )

# Generated at 2022-06-10 21:34:05.629465
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:34:13.305593
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('11:22:33.123456') == (
        datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                  microseconds=123456)
    )
    assert timedelta_parse('11:22:33.012345') == (
        datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                  microseconds=12345)
    )
    assert timedelta_parse('11:22:33.123') == (
        datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                  microseconds=123000)
    )

# Generated at 2022-06-10 21:34:25.682769
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1,
    )
    assert timedelta_parse('00:00:02.000000') == datetime_module.timedelta(
        seconds=2
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
    )

# Generated at 2022-06-10 21:34:29.540131
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = datetime_module.time(1, 2, 3, 56789)
    assert timedelta_parse(time_isoformat(time)) == datetime_module.timedelta(1, 2*60**2 + 3*60 + 56789*10**-6)

# Generated at 2022-06-10 21:34:33.473138
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=1337)) == \
        '01:02:03.001337'


# Generated at 2022-06-10 21:34:45.547324
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:34:51.042141
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:01:02.123456')) == '00:01:02.123456'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('15:27:42.123456')) == '15:27:42.123456'



# Generated at 2022-06-10 21:35:06.457209
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('23:59:59') == datetime_module.timedelta(
        days=1, seconds=-1
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1, seconds=-1, microseconds=-1
    )
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1, seconds=-1, microseconds=-1
    )
    assert timedelta_parse('23:59:59.999999') == datetime

# Generated at 2022-06-10 21:35:17.016881
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'

# Generated at 2022-06-10 21:35:56.211044
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'

# Generated at 2022-06-10 21:36:01.634786
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=45, minutes=30, seconds=15, microseconds=123456
    ))) == datetime_module.timedelta(hours=45, minutes=30, seconds=15,
                                     microseconds=123456)

# Generated at 2022-06-10 21:36:07.399266
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(0, 86399, 999999)
    assert timedelta_parse('1:02:03.040506') == datetime_module.timedelta(0, 3723, 40506)



# Generated at 2022-06-10 21:36:10.620248
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901
    )



# Generated at 2022-06-10 21:36:13.083090
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=2, hours=3,
                                          minutes=4, seconds=5,
                                          microseconds=6)
    s = timedelta_format(timedelta)
    assert timedelta_parse(s) == timedelta

# Generated at 2022-06-10 21:36:16.204729
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=4, minutes=7, seconds=8,
                                          microseconds=9)
    assert timedelta_format(timedelta) == '04:07:08.000009'


# Generated at 2022-06-10 21:36:19.815473
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

# Generated at 2022-06-10 21:36:30.203018
# Unit test for function timedelta_parse
def test_timedelta_parse():

    # Testing with a whole-number number of microseconds:
    assert timedelta_parse('1:23:45.0') == datetime_module.timedelta(hours=1, minutes=23,
                                                                     seconds=45,
                                                                     microseconds=0)

    # Testing with a fractional number of microseconds:
    assert timedelta_parse('1:23:45.123') == datetime_module.timedelta(hours=1, minutes=23,
                                                                       seconds=45,
                                                                       microseconds=123)

    # Testing with a whole-number number of seconds and microseconds:

# Generated at 2022-06-10 21:36:32.830655
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                 microseconds=4)
    ) == '1:02:03.000004'



# Generated at 2022-06-10 21:36:42.262610
# Unit test for function timedelta_parse
def test_timedelta_parse():
    delta = timedelta_parse('1:2:3.35')
    assert delta.seconds == 3 * 3600 + 2 * 60 + 3
    assert delta.microseconds == 350000
    #
    delta = timedelta_parse('1:2:3.0')
    assert delta.seconds == 3 * 3600 + 2 * 60 + 1
    assert delta.microseconds == 0
    #
    delta = timedelta_parse('0:0:3.000000')
    assert delta.seconds == 3
    assert delta.microseconds == 0
    #
    delta = timedelta_parse('0:0:3.000001')
    assert delta.seconds == 3
    assert delta.microseconds == 1
    #
    delta = timedelta_parse('0:0:3.999999')
    assert delta.seconds == 3
    assert delta.micro

# Generated at 2022-06-10 21:37:39.055922
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                          '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                          '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=2,
                                                      microseconds=4)) == \
                                                     '01:00:02.000004'



# Generated at 2022-06-10 21:37:49.029218
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=30)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

# Generated at 2022-06-10 21:37:54.147188
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(microseconds=123456)
    assert timedelta_format(timedelta) == '00:00:00.123456'

    timedelta = datetime_module.timedelta(seconds=1234567890)
    assert timedelta_format(timedelta) == '34:17:36.7890'

    timedelta = datetime_module.timedelta(seconds=3600, microseconds=123456)
    assert timedelta_format(timedelta) == '01:00:00.123456'



# Generated at 2022-06-10 21:37:57.630728
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    assert timedelta_format(delta) == '25:00:01.000001'


# Generated at 2022-06-10 21:38:06.324265
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5)) == \
                                                                   '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5)) == \
                                                                       '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5,
                                                      seconds=15)) == \
        '00:05:15.000000'



# Generated at 2022-06-10 21:38:16.989133
# Unit test for function timedelta_format
def test_timedelta_format():
    import random
    import itertools
    for hour, minute, second, microsecond in itertools.product(
                                            range(25), range(60), range(60),
                                            range(1000000)):
        timedelta = datetime_module.timedelta(hours=hour,
                                              minutes=minute,
                                              seconds=second,
                                              microseconds=microsecond)
        formatted = timedelta_format(timedelta)
        parsed = timedelta_parse(formatted)
        assert parsed == timedelta

test_timedelta_format()

# Generated at 2022-06-10 21:38:28.063618
# Unit test for function timedelta_parse
def test_timedelta_parse():
    datetime_module.timedelta(seconds=1.5) == timedelta_parse('00:00:01.5')

try:
    from collections import ChainMap
except ImportError:
    try:
        from chainmap import ChainMap
    except ImportError:
        ChainMap = None

try:
    from weakref import WeakMethod
except ImportError:
    class WeakMethod(object):
        '''
        Emulate a weak reference to a bound method.

        Inspired in particular by
        https://gist.github.com/sjl/3207775#file-weakmethod-py-L31
        '''
        __slots__ = (
            'callback',
            '_alive',
            '_func',
            '_obj',
            '_class',
        )


# Generated at 2022-06-10 21:38:38.216235
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    ))) == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-10 21:38:39.872404
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(seconds=0.0000001))
    assert result == '00:00:00.000001'



# Generated at 2022-06-10 21:38:51.599326
# Unit test for function timedelta_format
def test_timedelta_format():
    if PY3:
        assert timedelta_format(timedelta_parse(timedelta_format(
            datetime_module.timedelta(days=1, seconds=2,
                                      microseconds=3)))) == \
               '24:00:02.000003'
        assert timedelta_format(timedelta_parse(timedelta_format(
            datetime_module.timedelta(seconds=2,
                                      microseconds=3)))) == \
               '00:00:02.000003'
        assert timedelta_format(timedelta_parse(timedelta_format(
            datetime_module.timedelta(microseconds=3)))) == \
               '00:00:00.000003'

# Generated at 2022-06-10 21:40:43.768078
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.1') == datetime_module.timedelta(seconds=0.1)
    assert timedelta_parse('-.1') == datetime_module.timedelta(seconds=-0.1)
    assert timedelta_parse('.1:02') == datetime_module.timedelta(
        seconds=0.1, minutes=2)
    assert timedelta_parse('.1:02:03') == datetime_module.timedelta(
        seconds=0.1, minutes=2, hours=3)
    assert timedelta_parse('-.1:02:03') == datetime_module.timedelta(
        seconds=-0.1, minutes=2, hours=3)



# Generated at 2022-06-10 21:40:52.422011
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == '01:00:01.000000'

# Generated at 2022-06-10 21:41:02.767884
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                            datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1))) == \
                                                            datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(10, 0))) == \
                                                            datetime_module.timedelta(10, 0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(10, 100))) == \
                                                            datetime_module.timedelta(10, 100)

# Generated at 2022-06-10 21:41:08.297956
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=5, seconds=5, microseconds=5)) == '05:05:05.000005'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=35, seconds=59, microseconds=999999)) == '23:35:59.999999'


# Generated at 2022-06-10 21:41:13.753867
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta, s in (
        (datetime_module.timedelta(days=3), '72:00:00.000000'),
        (datetime_module.timedelta(hours=2, minutes=30, seconds=20),
         '02:30:20.000000'),
        (datetime_module.timedelta(seconds=1, microseconds=500000),
         '00:00:01.500000'),
    ):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-10 21:41:17.450908
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'



# Generated at 2022-06-10 21:41:21.415523
# Unit test for function timedelta_format
def test_timedelta_format():
    x = datetime_module.timedelta(hours=1, minutes=2,
                                        seconds=3, microseconds=42)
    assert timedelta_format(x) == '01:02:03.000042'


# Generated at 2022-06-10 21:41:29.840937
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:00:01.999999') == datetime_module.timedelta(
        seconds=1, microseconds=999999
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('00:01:00.999999') == datetime_module.timedelta

# Generated at 2022-06-10 21:41:40.958740
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == \
                                            datetime_module.timedelta(
                                                microseconds=1)
    assert timedelta_parse('00:00:01.000001') == \
                                            datetime_module.timedelta(
                                                seconds=1, microseconds=1)
    assert timedelta_parse('00:01:01.000001') == \
                                            datetime_module.timedelta(
                                                minutes=1, seconds=1,
                                                microseconds=1)
    assert timedelta_parse('01:01:01.000001') == \
                                            datetime_module.timedelta(
                                                hours=1, minutes=1, seconds=1,
                                                microseconds=1)
    assert timed

# Generated at 2022-06-10 21:41:46.269278
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=32, seconds=34,
                                          microseconds=456789)
    assert timedelta_format(timedelta) == '05:32:34.456789'

