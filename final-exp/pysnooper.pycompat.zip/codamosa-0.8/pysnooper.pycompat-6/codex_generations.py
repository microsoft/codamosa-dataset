

# Generated at 2022-06-10 21:32:49.708458
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=123456)) == (
        '00:00:01.123456'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )

# Generated at 2022-06-10 21:32:57.631612
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )

    assert timedelta_parse('1:2:3.400000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )

    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

    assert timedelta_parse('01:02:03.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )



# Generated at 2022-06-10 21:33:06.828223
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=123456
    )

# Generated at 2022-06-10 21:33:10.427487
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                          '01:02:03.000004'


# Generated at 2022-06-10 21:33:17.621930
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('1:01:02.000000') == datetime_module.timedelta(0, 3662)
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(0, 3723)
    assert timedelta_parse('1:03:04.000000') == datetime_module.timedelta(0, 3784)
    assert timedelta_parse('1:04:05.000000') == datetime_module.timedelta(0, 3845)
    assert timedelta_parse('1:05:06.000000') == datetime_module.timedelta(0, 3906)

# Generated at 2022-06-10 21:33:28.609911
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4, microseconds=5)) == \
                                                      '02:03:04.000005'

# Generated at 2022-06-10 21:33:42.063484
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1:2:3.0') == datetime_module.timedelta(hours=1,
                                                                   minutes=2,
                                                                   seconds=3)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(microseconds=100)

# Generated at 2022-06-10 21:33:50.180001
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=23, seconds=34, microseconds=567_123
    )) == '01:23:34.567123'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=34, seconds=45, microseconds=678_234
    )) == '23:34:45.678234'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4_567
    )) == '01:02:03.004567'

# Generated at 2022-06-10 21:33:58.699451
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:1:1.000001')) == '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(days=3)) == '03:00:00.000000'
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=12, minutes=13, seconds=14,
                                  microseconds=4321)
    )) == datetime_module.timedelta(hours=12, minutes=13, seconds=14,
                                    microseconds=4321)

# Generated at 2022-06-10 21:34:06.464773
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                     '05:02:03:000004'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5, minutes=2, seconds=3, microseconds=4))) == \
        datetime_module.timedelta(hours=5, minutes=2, seconds=3,
                                  microseconds=4)

# Generated at 2022-06-10 21:34:14.933224
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('3:02:55.00005') == \
                                datetime_module.timedelta(hours=3, minutes=2,
                                                          seconds=55,
                                                          microseconds=5)

# Generated at 2022-06-10 21:34:27.049095
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:30:14.123456') == \
                          datetime_module.timedelta(hours=2, minutes=30,
                                                    seconds=14,
                                                    microseconds=123456)
    assert timedelta_parse('02:30:14') == \
           datetime_module.timedelta(hours=2, minutes=30, seconds=14)
    assert timedelta_parse('2:30:14') == \
           datetime_module.timedelta(hours=2, minutes=30, seconds=14)
    assert timedelta_parse('2:30:14.123456') == \
           datetime_module.timedelta(hours=2, minutes=30, seconds=14,
                                     microseconds=123456)

# Generated at 2022-06-10 21:34:36.061691
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)

test_timedelta_parse()

# Generated at 2022-06-10 21:34:42.406002
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == '24:00:01.000001'


# Generated at 2022-06-10 21:34:47.178452
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5, minutes=6, seconds=7, microseconds=8
    ))) == datetime_module.timedelta(hours=5, minutes=6, seconds=7,
                                     microseconds=8)



# Generated at 2022-06-10 21:35:02.631350
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == \
                           datetime_module.timedelta(hours=1, minutes=23,
                                                     seconds=45,
                                                     microseconds=678901)
    assert timedelta_parse('0:23:45.678901') == \
                           datetime_module.timedelta(hours=0, minutes=23,
                                                     seconds=45,
                                                     microseconds=678901)
    assert timedelta_parse('23:45.678901') == \
                           datetime_module.timedelta(hours=0, minutes=23,
                                                     seconds=45,
                                                     microseconds=678901)



# Generated at 2022-06-10 21:35:11.224783
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('0:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )
    assert timedelta_parse('0:10:00.000000') == datetime_module.timedelta(
        minutes=10
    )
    assert timedelta_parse('5:00:00.000000') == datetime_module.timedelta(
        hours=5
    )

# Generated at 2022-06-10 21:35:23.284680
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) ==\
            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) ==\
            '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) ==\
            '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) ==\
            '48:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(weeks=2)) ==\
            '336:00:00.000000'

# Generated at 2022-06-10 21:35:34.085893
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ))) == '1:02:03.456789'
    assert timedelta_format(timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=3,
                                  microseconds=456789)
    ))) == '00:00:03.456789'

# Generated at 2022-06-10 21:35:39.704413
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)



# Generated at 2022-06-10 21:35:57.186476
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4005)
    ) == '01:02:03.004005'



# Generated at 2022-06-10 21:36:00.702678
# Unit test for function timedelta_format
def test_timedelta_format():
    s = timedelta_format(datetime_module.timedelta(seconds=1.1))
    assert s == '00:00:01.100000'


# Generated at 2022-06-10 21:36:12.906441
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=2,
                                                                      minutes=3,
                                                                      seconds=4,
                                                                      microseconds=5))) == \
                                                                      datetime_module.timedelta(hours=2,
                                                                                                minutes=3,
                                                                                                seconds=4,
                                                                                                microseconds=5)


if PY3:
    def viewvalues(d):
        return d.values()
else:
    def viewvalues(d):
        return d.viewvalues()



# Generated at 2022-06-10 21:36:20.389500
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    ))

# Generated at 2022-06-10 21:36:25.341796
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:36:35.033488
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1)
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901)
    assert timedelta_parse('000001:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=678901)

# Generated at 2022-06-10 21:36:43.139840
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('0:10:00.000000') == datetime_module.timedelta(0, 10 * 60)
    assert timedelta_parse('0:00:10.000000') == datetime_module.timedelta(0, 10)
    assert timedelta_parse('0:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(0, 0, 1)

# Generated at 2022-06-10 21:36:49.103568
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:00:00.000000') == datetime_module.timedelta(
        hours=2
    )

    assert timedelta_parse('2:05:00.123456') == datetime_module.timedelta(
        hours=2, minutes=5, seconds=0, microseconds=123456
    )

# Generated at 2022-06-10 21:37:03.833672
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(12, 34, 56, 123456)
    assert timedelta_parse('12:34:56.123456') != datetime_module.timedelta(12, 34, 56, 0)
    assert timedelta_parse('12:34:56.123456') != datetime_module.timedelta(12, 34, 57, 123456)
    assert timedelta_parse('12:34:56.123456') != datetime_module.timedelta(12, 35, 56, 123456)
    assert timedelta_parse('12:34:56.123456') != datetime_module.timedelta(13, 34, 56, 123456)



# Generated at 2022-06-10 21:37:08.446955
# Unit test for function timedelta_parse
def test_timedelta_parse():

    test_pairs = [
        '00:00:00.000000',
        '01:02:03.040000',
        '01:02:03.040670',
    ]

    for s in test_pairs:
        assert s == timedelta_format(timedelta_parse(s))

# Generated at 2022-06-10 21:37:45.772131
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=8)) == '08:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      microseconds=300000)) == '08:00:00.300000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      microseconds=300000,
                                                      seconds=30)) == '08:00:30.300000'
    assert timedelta_format(datetime_module.timedelta(hours=8,
                                                      microseconds=300000,
                                                      seconds=30,
                                                      minutes=30)) == '08:30:30.300000'



# Generated at 2022-06-10 21:37:51.839299
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) ==\
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) ==\
                                                      '23:59:59.999999'



# Generated at 2022-06-10 21:37:56.593027
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3, minutes=50)) == \
                            "00:00:00.000000"
    assert timedelta_format(datetime_module.timedelta(
            days=3, hours=4, minutes=50, seconds=18,
            microseconds=123456
    )) == "04:50:18.123456"

# Generated at 2022-06-10 21:38:01.281152
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1,
                                   microseconds=1)
    assert timedelta_format(td) == '25:01:01.000001'


# Generated at 2022-06-10 21:38:05.088397
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(seconds=1.1234567)
    assert timedelta_format(timedelta) == '00:00:01.123456'


# Generated at 2022-06-10 21:38:14.728926
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
           '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'

# Generated at 2022-06-10 21:38:26.705667
# Unit test for function timedelta_format
def test_timedelta_format():
    # assert timedelta_format(datetime.timedelta(hours=1, minutes=2,
    #                                            seconds=3,
    #                                            microseconds=123456)) == \
    #     '01:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )) == '01:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=2, seconds=3, microseconds=123456
    )) == '25:02:03.123456'


# Unit test

# Generated at 2022-06-10 21:38:42.165574
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00') == datetime_module.timedelta()
    assert timedelta_parse('0:02:00') == datetime_module.timedelta(
        minutes=2
    )
    assert timedelta_parse('2:02:00') == datetime_module.timedelta(
        hours=2, minutes=2
    )
    assert timedelta_parse('0:02:30') == datetime_module.timedelta(
        minutes=2, seconds=30
    )
    assert timedelta_parse('0:02.1') == datetime_module.timedelta(
        minutes=2, seconds=0, milliseconds=100
    )

# Generated at 2022-06-10 21:38:44.507215
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:11:10.123456') == \
                                datetime_module.timedelta(hours=12,
                                                          minutes=11,
                                                          seconds=10,
                                                          microseconds=123456)

# Generated at 2022-06-10 21:38:54.196906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )

# Generated at 2022-06-10 21:40:36.265951
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
           '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
           '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
           '00:00:00.000002'


# Generated at 2022-06-10 21:40:47.409986
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)



# Generated at 2022-06-10 21:40:51.858351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.000789') == \
                             datetime_module.timedelta(hours=1, minutes=23,
                                                       seconds=45,
                                                       microseconds=789)

# Generated at 2022-06-10 21:40:56.997397
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_object = datetime_module.timedelta(days=1, hours=30, minutes=3,
                                                 seconds=4, microseconds=5)
    assert timedelta_parse('30:03:04.000005') == timedelta_object
    assert timedelta_parse('30:03:04') == timedelta_object

# Generated at 2022-06-10 21:41:07.443160
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(0,
                                                                        0,
                                                                        123456)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:0:2') == timedelta_parse('1:0:2.000000')

# Generated at 2022-06-10 21:41:11.738809
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                             '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=1)) == \
                             '00:00:00.000001'



# Generated at 2022-06-10 21:41:22.250829
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-10 21:41:29.556861
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == '01:02:03.400000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=0)) == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == '01:02:03.000004'



# Generated at 2022-06-10 21:41:38.400981
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=30)) == '00:30:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=44,
                                                      microseconds=2)) == \
           '00:00:44.000002'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345678)) == \
           '00:00:12.345678'



# Generated at 2022-06-10 21:41:41.626190
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

