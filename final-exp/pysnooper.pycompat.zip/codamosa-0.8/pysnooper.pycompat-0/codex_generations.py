

# Generated at 2022-06-10 21:32:39.083487
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=2, minutes=2, seconds=2,
                                          microseconds=86)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    assert (timedelta_parse(timedelta_format(timedelta)).total_seconds() ==
            timedelta.total_seconds())

# Generated at 2022-06-10 21:32:49.325960
# Unit test for function timedelta_format
def test_timedelta_format():
    first_timedelta = datetime_module.timedelta(hours=14, minutes=23,
                                                seconds=12,
                                                microseconds=1337)
    first_result = timedelta_format(first_timedelta)
    assert first_timedelta == timedelta_parse(first_result)

    second_timedelta = datetime_module.timedelta(hours=14, minutes=23,
                                                 seconds=12)
    second_result = timedelta_format(second_timedelta)
    assert second_timedelta == timedelta_parse(second_result)

    third_timedelta = datetime_module.timedelta(minutes=23, seconds=12,
                                                microseconds=1337)
    third_result = timedelta_format(third_timedelta)


# Generated at 2022-06-10 21:32:56.261522
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('15:54:23.678901') == datetime_module.timedelta(days=0, seconds=57263, microseconds=678901)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(days=0, seconds=0, microseconds=0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(days=0, seconds=86399, microseconds=999999)
    assert timedelta_parse('23:59:60.000000') == datetime_module.timedelta(days=1, seconds=0, microseconds=0)

# Generated at 2022-06-10 21:33:06.150367
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3)) == '02:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=3)) == '02:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, microseconds=3)) == '02:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(minutes=2, microseconds=3)) == '00:02:00.000003'

# Generated at 2022-06-10 21:33:14.414996
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
                                 datetime_module.timedelta(0, 0)
    assert timedelta_parse('00:00:00.000001') == \
                                 datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:10.000000') == \
                                 datetime_module.timedelta(0, 10)
    assert timedelta_parse('01:00:00.000000') == \
                                 datetime_module.timedelta(1, 0)
    assert timedelta_parse('01:00:00.000001') == \
                                 datetime_module.timedelta(1, 0, 1)

# Generated at 2022-06-10 21:33:25.409242
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:05.000000') == datetime_module.timedelta(
        seconds=5
    )
    assert timedelta_parse('00:05:00.000000') == datetime_module.timedelta(
        minutes=5
    )
    assert timedelta_parse('05:00:00.000000') == datetime_module.timedelta(
        hours=5
    )
    assert timedelta_parse('05:00:00.500000') == datetime_module.timedelta(
        hours=5,
        milliseconds=500,
    )

# Generated at 2022-06-10 21:33:30.988217
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(seconds=3723)
    assert timedelta_parse('1:2:3.45') == datetime_module.timedelta(seconds=3723, microseconds=450000)
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(seconds=3723, microseconds=456789)

# Generated at 2022-06-10 21:33:42.325237
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.141516') == \
           datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                     microseconds=141516)
    assert timedelta_parse('1:23:45.141516') == \
           datetime_module.timedelta(hours=1, minutes=23, seconds=45,
                                     microseconds=141516)
    assert timedelta_parse('20:4:4.141516') == \
           datetime_module.timedelta(hours=20, minutes=4, seconds=4,
                                     microseconds=141516)

# Generated at 2022-06-10 21:33:53.041037
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:00:00.001000') == datetime_module.timedelta(0, 0, 1e3)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-10 21:34:04.129328
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                          '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                          '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                          '01:00:00.000000'

# Generated at 2022-06-10 21:34:26.723854
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12345:07:08:09.123456') == \
                          datetime_module.timedelta(days=12345, hours=7,
                                                    minutes=8,
                                                    seconds=9,
                                                    microseconds=123456)
    assert timedelta_parse('1:01:01.010101') == \
                          datetime_module.timedelta(hours=1, minutes=1,
                                                    seconds=1,
                                                    microseconds=10101)

if PY3:
    from pickle import _Pickler as Pickler
    from pickle import _Unpickler as Unpickler
    from pickle import HIGHEST_PROTOCOL
    from pickle import PickleError
    from pickle import PicklingError
    from pickle import Unpickling

# Generated at 2022-06-10 21:34:37.867924
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-10 21:34:49.384320
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )


try:
    from typing import TYPE_CHECKING
except ImportError:
    TYPE_CHECKING = False

if TYPE_CHECKING:
    # Only importing `typing` when type-checking.
    from typing import Iterable, Text, ByteString, Any, Tuple3
    from typing import Union as UnionType
else:
    Iterable = Any
    Text = Any
    ByteString = Any
    UnionType = Any
    Tuple

# Generated at 2022-06-10 21:35:05.199392
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert datetime_module.timedelta(hours=1) == timedelta_parse('01:00:00:000000')
    assert datetime_module.timedelta(hours=1, minutes=2) == timedelta_parse('01:02:00:000000')
    assert datetime_module.timedelta(hours=1, minutes=2, seconds=3) == timedelta_parse('01:02:03:000000')
    assert datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4) == timedelta_parse('01:02:03:000004')
    assert datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4567) == timedelta_parse('01:02:03:04567')
    assert datetime_module.tim

# Generated at 2022-06-10 21:35:15.414336
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
        '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'

# Generated at 2022-06-10 21:35:17.993858
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == \
                                                datetime_module.timedelta(days=1)

# Generated at 2022-06-10 21:35:26.310034
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=5,
                                                      microseconds=6)) == \
                                                                  '00:00:05.000006'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=5,
                                                      microseconds=6)) == \
                                                                  '02:03:05.000006'



# Generated at 2022-06-10 21:35:35.854432
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=999,
                                                      hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) ==\
                                                      '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) ==\
                                                      '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) ==\
                                                      '00:59:59.999999'

# Generated at 2022-06-10 21:35:45.184324
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(
        microseconds=0
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1, microseconds=-1
    )

# Generated at 2022-06-10 21:35:52.419740
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040506') == \
                                 datetime_module.timedelta(1, 7223, 40506)
    assert timedelta_parse('-01:02:03.040506') == \
                                 datetime_module.timedelta(-2, 77576, 59494)
    assert timedelta_parse('01:02:03') == \
                                 datetime_module.timedelta(1, 7223)
    assert timedelta_parse('-01:02:03') == \
                                 datetime_module.timedelta(-2, 77576)

# Generated at 2022-06-10 21:36:20.371506
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == '00:00:00.999999'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000001)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'

# Generated at 2022-06-10 21:36:30.683838
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:36:38.582618
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(seconds=30, microseconds=250000)
    assert timedelta_format(timedelta) == '00:00:30.250000'
    timedelta = datetime_module.timedelta(minutes=2, seconds=7,
                                          microseconds=654321)
    assert timedelta_format(timedelta) == '00:02:07.654321'
    timedelta = datetime_module.timedelta(days=1, hours=6, minutes=3,
                                          seconds=2, microseconds=654321)
    assert timedelta_format(timedelta) == '30:03:02.654321'



# Generated at 2022-06-10 21:36:43.509287
# Unit test for function timedelta_format
def test_timedelta_format():
    # This is a round trip test.
    for i in range(10**4):
        timedelta = datetime_module.timedelta(microseconds=i)
        formatted_timedelta = timedelta_format(timedelta)
        parsed_timedelta = timedelta_parse(formatted_timedelta)
        assert parsed_timedelta == timedelta

# Generated at 2022-06-10 21:36:54.639071
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        ('00:00:00.000000', (0, 0)),
        ('00:00:00.000001', (0, 1)),
        ('00:00:00.123456', (123, 456)),
        ('00:00:01.000000', (1, 0)),
        ('00:01:00.000000', (60, 0)),
        ('01:00:00.000000', (3600, 0)),
    ]

    for string, microseconds in cases:
        duration = datetime_module.timedelta(microseconds=microseconds)
        assert timedelta_parse(string) == duration
        string2 = timedelta_format(duration)
        assert string == string2

# Generated at 2022-06-10 21:37:02.634782
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_format(expected, argument):
        assert expected == timedelta_format(argument)
    assert_format('00:00:00.000000', datetime_module.timedelta(seconds=0))
    assert_format('00:00:00.000001', datetime_module.timedelta(microseconds=1))
    assert_format('00:00:00.999999', datetime_module.timedelta(microseconds=999))
    assert_format('00:00:00.001000', datetime_module.timedelta(microseconds=1000))
    assert_format('00:00:01.000000', datetime_module.timedelta(seconds=1))
    assert_format('00:00:01.000001', datetime_module.timedelta(seconds=1, microseconds=1))

# Generated at 2022-06-10 21:37:09.673178
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    timedelta = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta) == '00:00:01.000000'
    timedelta = datetime_module.timedelta(hours=1)
    assert timedelta_format(timedelta) == '01:00:00.000000'



# Generated at 2022-06-10 21:37:16.593001
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(0, 0, 0))
    assert time == '00:00:00.000000'
    time = time_isoformat(datetime_module.time(11, 22, 33))
    assert time == '11:22:33.000000'
    time = time_isoformat(datetime_module.time(23, 59, 59, 999999))
    assert time == '23:59:59.999999'


# Generated at 2022-06-10 21:37:19.846279
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('-2:01:59:999999') == datetime_module.timedelta(
        days=-3, hours=21, minutes=59, seconds=59, microseconds=999999
    )



# Generated at 2022-06-10 21:37:28.545972
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
                                                               '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                               '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=20)) == \
                                                               '01:00:20.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      seconds=59,
                                                      microseconds=1)) == \
                                                               '01:00:59.000001'

# Generated at 2022-06-10 21:38:25.643347
# Unit test for function timedelta_parse
def test_timedelta_parse():
    pairs = (
        ('1:01', '1:01:00.000000'),
        ('1:01', '001:01:00.000000'),
        ('1:02:03.123456', '1:02:03.123456'),
        ('1:02:03.123456', '001:02:03.123456'),
        ('0:00:00.000000', '000:00:00.000000'),
        ('0:00:00.000001', '000:00:00.000001'),
    )
    for expected, input in pairs:
        assert timedelta_format(timedelta_parse(input)) == expected
    
    

# Generated at 2022-06-10 21:38:41.034321
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 2)) == '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(0, 1, 2, 3)) == '00:00:01.000002'



# Generated at 2022-06-10 21:38:52.402159
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.200') == datetime_module.timedelta(
        milliseconds=200
    )
    assert timedelta_parse('00:00:01.200645') == datetime_module.timedelta(
        seconds=1, microseconds=200645
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

# Generated at 2022-06-10 21:38:55.805351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:00.1234') == datetime_module.timedelta(
        minutes=1, seconds=0, microseconds=123
    )

# Generated at 2022-06-10 21:39:06.591743
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=365)) == \
                                            '8760:00:00.000000'

# Generated at 2022-06-10 21:39:13.599721
# Unit test for function timedelta_format
def test_timedelta_format():
    one_microsecond = datetime_module.timedelta(microseconds=1)
    for i in range(1000000):
        assert timedelta_format(datetime_module.timedelta(microseconds=i)) == (
            '{:02d}:{:02d}:{:02d}.{:06d}'.format(
                i // 1000000,
                i // 1000 % 60,
                i // 10 % 100,
                i % 100,
            )
        )

    assert timedelta_format(one_microsecond) == '00:00:00.000001'
    assert timedelta_format(one_microsecond + one_microsecond) == \
           '00:00:00.000002'

# Generated at 2022-06-10 21:39:24.989461
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.123400') == datetime_module.timedelta(0, 0, 123)
    assert timedelta_parse('00:00:01.003400') == datetime_module.timedelta(0, 1, 3)
    assert timedelta_parse('00:00:31.000000') == datetime_module.timedelta(0, 31)
    assert timedelta_parse('00:10:31.000000') == datetime_module.timedelta(0, 631)
    assert timedelta_parse('01:10:31.000000') == datetime_module.timedelta(0, 4230)

# Generated at 2022-06-10 21:39:30.951665
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=123456
    )
    assert timedelta_parse('12:34:56') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56
    )



# Generated at 2022-06-10 21:39:34.102356
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2, seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '47:48:03.000004'



# Generated at 2022-06-10 21:39:43.623467
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=0, microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=0, microseconds=99999)) == '00:00:00.099999'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=0, microseconds=100000)) == '00:00:00.100000'

# Generated at 2022-06-10 21:41:28.796688
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.123456789') == datetime_module.timedelta(
        microseconds=(1234567 / 100)
    )
    assert timedelta_parse('12:23:34.567890123') == datetime_module.timedelta(
        hours=12, minutes=23, seconds=34, microseconds=56789
    )

# Generated at 2022-06-10 21:41:34.024254
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        microseconds=100001
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        seconds=3723
    )

# Generated at 2022-06-10 21:41:42.379099
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1, 0)) == '24:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == '24:00:01.000001'


# Generated at 2022-06-10 21:41:54.717590
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=0)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=0,
                                                      microseconds=2)) == \
           '01:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=5,
                                                      seconds=0)) == \
           '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=5,
                                                      seconds=3,
                                                      microseconds=1)) == \
           '00:05:03.000001'


# Generated at 2022-06-10 21:42:03.294799
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import test_utils

# Generated at 2022-06-10 21:42:09.287949
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )
    assert timedelta_parse('12:34:56.654321') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=654321
    )

# Generated at 2022-06-10 21:42:18.814729
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.123456') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=123456
    )
    assert timedelta_parse('1000:23:45.123456') == datetime_module.timedelta(
        days=41, hours=23, minutes=45, seconds=123456
    )
    assert timedelta_format(timedelta_parse('1:23:45.123456')) == \
           '01:23:45.123456'
    assert timedelta_format(timedelta_parse('1000:23:45.123456')) == \
           '23:45:45.123456'



# Generated at 2022-06-10 21:42:21.080846
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'



# Generated at 2022-06-10 21:42:28.320298
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:02.000000')) == \
                           '00:00:02.000000'
    assert timedelta_format(timedelta_parse('0:01:02.000000')) == \
                           '00:01:02.000000'
    assert timedelta_format(timedelta_parse('0:00:02.100000')) == \
                           '00:00:02.100000'
    assert timedelta_format(timedelta_parse('0:01:02.100000')) == \
                           '00:01:02.100000'