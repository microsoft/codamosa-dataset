

# Generated at 2022-06-10 21:32:45.622044
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:30:15.000000') == \
           datetime_module.timedelta(hours=2, minutes=30, seconds=15)

    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(hours=0, minutes=0, seconds=0)

    assert timedelta_parse('01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)

    assert timedelta_parse('02:00:00.000123') == \
           datetime_module.timedelta(hours=2, minutes=0, seconds=0,
                                     microseconds=123)

# Generated at 2022-06-10 21:32:49.513590
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=23,
                                                      seconds=45,
                                                      microseconds=678)) \
           == '01:23:45.000678'



# Generated at 2022-06-10 21:32:56.744781
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def test(s, expected_timedelta):
        assert timedelta_parse(s) == expected_timedelta
    test('1:02:03.000004', datetime_module.timedelta(
                             hours=1, minutes=2, seconds=3, microseconds=4))
    test('1:02:03.000456', datetime_module.timedelta(
                             hours=1, minutes=2, seconds=3, microseconds=456))
    test('1:02:03.456789', datetime_module.timedelta(
                             hours=1, minutes=2, seconds=3, microseconds=456789))

test_timedelta_parse()

# Generated at 2022-06-10 21:33:03.293308
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:10.123456') == datetime_module.timedelta(
        seconds=10,
        microseconds=123456,
    )
    assert timedelta_parse('00:00:10') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:00:10.') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:00:10.23') == datetime_module.timedelta(
        seconds=10,
        microseconds=230000,
    )



# Generated at 2022-06-10 21:33:12.602941
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 3))) == datetime_module.timedelta(0, 0, 3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 3, 0))) == datetime_module.timedelta(0, 3, 0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(3, 0, 0))) == datetime_module.timedelta(3, 0, 0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(3, 3, 3))) == datetime_module.timedelta(3, 3, 3)



# Generated at 2022-06-10 21:33:16.026975
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(seconds=1)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-10 21:33:25.053411
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=55)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=55)) == '55:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=55)) == '00:55:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=55)) == '00:00:55.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=55)) == '00:00:00.000055'



# Generated at 2022-06-10 21:33:28.223123
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )



# Generated at 2022-06-10 21:33:32.811936
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=11, minutes=12,
                                                      seconds=13,
                                                      microseconds=145225)) == \
           '11:12:13.145225'



# Generated at 2022-06-10 21:33:46.436552
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=5)) == \
                                                                          '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=5,
                                                      microseconds=23)) == \
                                                                          '00:05:00.000023'
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=5,
                                                      microseconds=2399999)) == \
                                                                          '00:05:00.239999'

# Generated at 2022-06-10 21:34:07.399509
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=4,
                                                      minutes=6,
                                                      seconds=8,
                                                      microseconds=5,
                                                      milliseconds=3,
                                                      minutes=2)) == \
                                                      '04:06:08.003003'
    assert timedelta_parse('04:06:08.003003') == \
                                          datetime_module.timedelta(days=2,
                                                                    hours=4,
                                                                    minutes=6,
                                                                    seconds=8,
                                                                    microseconds=5,
                                                                    milliseconds=3,
                                                                    minutes=2)

test_timedelta_parse()

# Generated at 2022-06-10 21:34:10.275766
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=1,
                                          seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '01:01:01.000001'



# Generated at 2022-06-10 21:34:21.583750
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(0, 10)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1, 0)
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(1, 3661)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(1, 86399, 999999)

# Generated at 2022-06-10 21:34:29.485257
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-10 21:34:41.308618
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'

# Generated at 2022-06-10 21:34:51.815176
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """
    Unit test for function timedelta_parse.

    Returns `False` if the test failed, `True` if it succeeded.
    """

# Generated at 2022-06-10 21:35:02.589370
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:35:11.137680
# Unit test for function timedelta_format
def test_timedelta_format():
    from nose_parameterized import parameterized

# Generated at 2022-06-10 21:35:23.183784
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:01:02.000000') == datetime_module.timedelta(
        minutes=1, seconds=2)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000)

# Generated at 2022-06-10 21:35:28.175621
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3,
                                          minutes=33,
                                          seconds=33,
                                          microseconds=33333)
    assert timedelta_format(timedelta) == '03:33:33.03333300'



# Generated at 2022-06-10 21:35:52.124706
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:03:04.000555') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=555)
    assert timedelta_parse('02:03:04.000555') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=555)
    assert timedelta_parse('2:3:4.555') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=555000)
    assert timedelta_parse('02:03:04.555') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=555000)



# Generated at 2022-06-10 21:36:04.060881
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    equal = pytest.approx

    def assert_equal(a, b):
        assert a == b

    assert_equal(timedelta_parse('00:00:00.000000'), datetime_module.timedelta(0))
    assert_equal(timedelta_parse('00:00:00.999999'), datetime_module.timedelta(0))
    assert_equal(timedelta_parse('00:00:00.000001'), datetime_module.timedelta(0, 0, 1))
    assert_equal(timedelta_parse('00:00:00.999998'), datetime_module.timedelta(0, 0, 1))

# Generated at 2022-06-10 21:36:17.675093
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=9)) == (
        '00:00:09.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == (
        '00:00:10.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == (
        '00:00:59.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == (
        '00:01:00.000000'
    )

# Generated at 2022-06-10 21:36:25.333288
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) \
           == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) \
           == '01:02:03.000004'


# Generated at 2022-06-10 21:36:28.673319
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2, hours=3,
                                          minutes=4, seconds=5,
                                          microseconds=6)
    assert timedelta_format(timedelta) == '03:04:05.000006'

# Generated at 2022-06-10 21:36:31.335894
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=23, minutes=59,
                                          seconds=59, microseconds=999999)
    assert timedelta_format(timedelta) == '23:59:59.999999'


# Generated at 2022-06-10 21:36:41.375693
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == "00:00:00.000000"
    assert timedelta_format(datetime_module.timedelta(hours=1)) == "01:00:00.000000"
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == "00:00:00.000001"
    assert timedelta_format(datetime_module.timedelta(hours=1, microseconds=1)) == "01:00:00.000001"
    assert timedelta_format(datetime_module.timedelta(minutes=1, microseconds=1)) == "00:01:00.000001"

# Generated at 2022-06-10 21:36:45.858688
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
                                                      '01:02:03.400000'



# Generated at 2022-06-10 21:36:57.563592
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=100)) == '00:01:40.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=100)) == '00:00:00.100000'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=50)) == '00:00:00.000050'

    assert timedelta_format(datetime_module.timedelta(seconds=10000)) == '02:46:40.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=10000)) == '00:00:10.000000'
    assert timedelta

# Generated at 2022-06-10 21:37:09.245419
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    with pytest.raises(ValueError):
        timedelta_parse('foooo')
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:02:00.000000') == \
           datetime_module.timedelta(hours=1, minutes=2)
    assert timedelta_parse('1:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)

# Generated at 2022-06-10 21:37:35.200935
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:59:59.999999') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=59, microseconds=999999
    )



# Generated at 2022-06-10 21:37:45.774680
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=4)

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=3, seconds=5,
                                  microseconds=7)
    )) == datetime_module.timedelta(days=3, seconds=5,
                                    microseconds=7)


try:
    from contextlib import asynccontextmanager
except ImportError:
    asynccontextmanager = None
    from contextlib import contextmanager


# Generated at 2022-06-10 21:37:50.961413
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=12, minutes=52, seconds=9, microseconds=8123454
    ))) == datetime_module.timedelta(hours=12, minutes=52, seconds=9,
                                     microseconds=8123454)


try:
    from collections.abc import Sequence
except ImportError:
    from collections import Sequence



# Generated at 2022-06-10 21:37:59.775713
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:07:14.000000')
    assert timedelta == datetime_module.timedelta(hours=0, minutes=7, seconds=14)
    timedelta = timedelta_parse('00:07:14.123456')
    assert timedelta == datetime_module.timedelta(hours=0, minutes=7, seconds=14, microseconds=123456)
    timedelta = timedelta_parse('00:07:14.123456')
    assert timedelta == datetime_module.timedelta(hours=0, minutes=7, seconds=14, microseconds=123456)
test_timedelta_parse()



# Generated at 2022-06-10 21:38:11.427009
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import testing_tools
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1))) == datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1, 2))) == datetime_module.timedelta(0, 1, 2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1, 2, 3))) == datetime_module.timedelta(0, 1, 2, 3)

# Generated at 2022-06-10 21:38:23.899424
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
           '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=2,
                                                      microseconds=100)) == \
           '03:02:00.000100'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=2,
                                                      microseconds=100000)) == \
           '03:02:00.100000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=2,
                                                      microseconds=1000000)) == \
           '03:02:01.000000'

# Generated at 2022-06-10 21:38:29.242456
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=1, hours=9, minutes=2, seconds=22,
                                   microseconds=77)
    assert timedelta_format(td) == '09:02:22.000077'



# Generated at 2022-06-10 21:38:41.186192
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1,
                                                      microseconds=1)) == \
           '00:01:01.000001'


# Generated at 2022-06-10 21:38:51.747565
# Unit test for function timedelta_format
def test_timedelta_format():

    timedelta = datetime_module.timedelta(
        days=9, hours=8, minutes=7, seconds=6, microseconds=5
    )
    s = '0:08:07:06.000005'
    assert timedelta_format(timedelta) == s

    timedelta = datetime_module.timedelta(seconds=2, microseconds=10)
    s = '00:00:02.000010'
    assert timedelta_format(timedelta) == s

    timedelta = datetime_module.timedelta(seconds=1)
    s = '00:00:01.000000'
    assert timedelta_format(timedelta) == s

test_timedelta_format()



# Generated at 2022-06-10 21:39:03.351134
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:33:45.670000') == datetime_module.timedelta(
        minutes=33, seconds=45, microseconds=670000
    )
    assert timedelta_parse('2:33:45.670000') == datetime_module.timedelta(
        hours=2, minutes=33, seconds=45, microseconds=670000
    )
    assert timedelta_parse('0:0:33.670000') == datetime_module.timedelta(
        seconds=33, microseconds=670000
    )
    assert timedelta_parse('0:0:0.670000') == datetime_module.timedelta(
        microseconds=670000
    )


# Generated at 2022-06-10 21:40:05.597534
# Unit test for function timedelta_format
def test_timedelta_format():
    assert (timedelta_format(datetime_module.timedelta(microseconds=5)) ==
            '00:00:00.000005')
    assert (timedelta_format(datetime_module.timedelta(microseconds=500_500)) ==
            '00:00:00.500500')
    assert (timedelta_format(datetime_module.timedelta(microseconds=50_000_500)) ==
            '00:00:50.000500')
    assert (timedelta_format(datetime_module.timedelta(microseconds=5_000_000_500)) ==
            '00:83:20.500500')

# Generated at 2022-06-10 21:40:15.621129
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )


# Generated at 2022-06-10 21:40:24.561700
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1, 4, 5000)) == \
                                                           '00:00:01.000050'
    assert timedelta_format(datetime_module.timedelta(10, 5, 5000)) == \
                                                           '00:00:10.000050'
    assert timedelta_format(datetime_module.timedelta(1, 5, 0)) == \
                                                           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 5, 10)) == \
                                                           '00:00:01.000010'

# Generated at 2022-06-10 21:40:36.950585
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for x in (1, 1.1, 1.1, 1.111111111111111, 1.1111111111111111,
              1.11111111111111111, 1.111111111111111111, '1', '1.1',
              '1.11'):
        assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=x))) == \
               datetime_module.timedelta(seconds=x)


try:
    import importlib.resources as importlib_resources
except ImportError: # Python 3.6
    def importlib_resources_path(name):
        return inspect.getfile(sys.modules[name])
else:
    def importlib_resources_path(name):
        return str(importlib_resources.files(name))

# Generated at 2022-06-10 21:40:50.611443
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(123, 456789)
    )) == datetime_module.timedelta(123, 456789)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(0, 1)
    )) == datetime_module.timedelta(0, 1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(0, 0)
    )) == datetime_module.timedelta(0, 0)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(0, 0, 1)
    )) == datetime_module.timedelta(0, 0, 1)

# Generated at 2022-06-10 21:40:57.133410
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest

    timedelta = datetime_module.timedelta(days=7, hours=12, minutes=34,
                                          seconds=56, microseconds=789)
    assert timedelta_format(timedelta) == '12:34:56.000789'


if sys.version_info[:2] >= (3, 7):
    module_type = type(sys)
else:
    module_type = types.ModuleType



# Generated at 2022-06-10 21:41:07.550045
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
           '00:00:00.001000'

# Generated at 2022-06-10 21:41:10.918344
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for i in range(100):
        datetime = datetime_module.datetime.now()
        timedelta = datetime - datetime_module.datetime.min
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-10 21:41:17.659466
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=3, seconds=10, microseconds=500)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))


try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse


try:
    from urllib.parse import parse_qs
except ImportError:
    from urlparse import parse_qs


try:
    from collections.abc import Hashable
except ImportError:
    from collections import Hashable



# Generated at 2022-06-10 21:41:27.687301
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1.2') == datetime_module.timedelta(seconds=1,
                                                               milliseconds=200)
    assert timedelta_parse('1.23') == datetime_module.timedelta(seconds=1,
                                                                milliseconds=230)

    assert timedelta_parse('1.234567') == datetime_module.timedelta(
        seconds=1, milliseconds=234, microseconds=56700
    )
    assert timedelta_parse('1:23.456789') == datetime_module.timedelta(
        minutes=1, seconds=23, milliseconds=456, microseconds=789000
    )