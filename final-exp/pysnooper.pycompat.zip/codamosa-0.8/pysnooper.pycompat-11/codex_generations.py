

# Generated at 2022-06-10 21:32:47.372471
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5.5)) == \
                                                             '00:00:05.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=5.12345)) == \
                                                           '00:00:05.123456'
    assert timedelta_format(datetime_module.timedelta(hours=6,
                                                      seconds=5.12345)) == \
                                                           '06:00:05.123456'
    assert timedelta_format(datetime_module.timedelta(hours=6,
                                                      minutes=1,
                                                      seconds=5.12345)) == \
                                                           '06:01:05.123456'

# Generated at 2022-06-10 21:32:54.062759
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == \
           '00:01:01.000000'

# Generated at 2022-06-10 21:32:57.032114
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.0001') == datetime_module.timedelta(hours=1,
                                                                        minutes=2,
                                                                        seconds=3,
                                                                        microseconds=10)


# Generated at 2022-06-10 21:33:06.150286
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-10 21:33:13.569016
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
                                                    datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2))) == \
                                                    datetime_module.timedelta(1, 2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(-1, 0))) == \
                                                    datetime_module.timedelta(-1, 0)


# Making sure the functions work
test_timedelta_parse()



# Generated at 2022-06-10 21:33:24.707661
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
           '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=2)) == \
           '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=2)) == \
           '00:00:00.000002'

# Generated at 2022-06-10 21:33:30.154223
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(days=3),
                      datetime_module.timedelta(hours=1),
                      datetime_module.timedelta(minutes=2),
                      datetime_module.timedelta(seconds=3),
                      datetime_module.timedelta(microseconds=4)):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-10 21:33:38.875355
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=800)) == \
           '00:00:00.000800'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
           '00:00:00.000002'



# Generated at 2022-06-10 21:33:47.398457
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_equal(timedelta_1, timedelta_2):
        if timedelta_1 != timedelta_2:
            raise AssertionError(
                '{} != {}'.format(timedelta_1, timedelta_2)
            )
    assert_equal(timedelta_parse('00:00:00.000000'),
                 datetime_module.timedelta(seconds=0))
    assert_equal(timedelta_parse('00:00:00.000001'),
                 datetime_module.timedelta(microseconds=1))
    assert_equal(timedelta_parse('00:00:00.666666'),
                 datetime_module.timedelta(microseconds=666666))

# Generated at 2022-06-10 21:33:49.844380
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('1:02:03.000001')) == \
           '01:02:03.000001'



# Generated at 2022-06-10 21:34:05.055434
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest

    timedelta = datetime_module.timedelta(days=1, hours=1, seconds=1,
                                          microseconds=1)
    assert timedelta_format(timedelta) == '25:00:01.000001'



# Generated at 2022-06-10 21:34:12.252005
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime
    assert timedelta_format(datetime.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime.timedelta(
        microseconds=1
    )) == '00:00:00.000001'



# Generated at 2022-06-10 21:34:14.266204
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing import make_is
    assert make_is(timedelta_format, timedelta_parse)



# Generated at 2022-06-10 21:34:26.436077
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=15)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(hours=15)) == '15:00:00'
    assert timedelta_format(datetime_module.timedelta(minutes=15)) == '00:15:00'
    assert timedelta_format(datetime_module.timedelta(seconds=15)) == '00:00:15'
    assert timedelta_format(datetime_module.timedelta(microseconds=15)) == '00:00:00.000015'
    assert timedelta_format(datetime_module.timedelta(microseconds=1523)) == '00:00:00.001523'

# Generated at 2022-06-10 21:34:30.158309
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('12:34:56.123456')
    assert timedelta.total_seconds() == 45296.123456
    assert timedelta_parse('12:34:56.123456') == timedelta_parse('12:34:56.123456')



# Generated at 2022-06-10 21:34:33.199184
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.001002') == \
           datetime_module.timedelta(seconds=1 + 2 + 0.001 + 0.00002)

# Generated at 2022-06-10 21:34:45.443860
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('-0:00:01.0')) == '-00:00:01.000000'
    assert timedelta_format(timedelta_parse('-0:00:01.1')) == '-00:00:01.100000'
    assert timedelta_format(timedelta_parse('-0:00:01.2')) == '-00:00:01.200000'
    assert timedelta_format(timedelta_parse('-0:00:01.3')) == '-00:00:01.300000'
    assert timedelta_format(timedelta_parse('-0:00:01.4')) == '-00:00:01.400000'

# Generated at 2022-06-10 21:34:54.072143
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_equal(a, b):
        assert a == b
    assert_equal(timedelta_format(datetime_module.timedelta(0, 0, 0)),
                 '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(0, 0, 1)),
                 '00:00:00.000001')
    assert_equal(timedelta_format(datetime_module.timedelta(0, 0, 234567)),
                 '00:00:00.234567')
    assert_equal(timedelta_format(datetime_module.timedelta(0, 0, 5901234)),
                 '00:00:05.901234')

# Generated at 2022-06-10 21:35:04.364303
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) ==\
           '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) ==\
           '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) ==\
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) ==\
           '00:00:00.000001'

# Generated at 2022-06-10 21:35:14.636051
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=45678
    )) == '01:02:03.045678'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=123456
    )) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'

# Generated at 2022-06-10 21:35:54.459851
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=7*30*12*5, seconds=5)) == '03:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=7*30*12*5, seconds=5,
                                                      microseconds=5)) == '03:02:00.000005'



# Generated at 2022-06-10 21:36:06.860973
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) \
                                                      == '01:02:03.004567'
    assert timedelta_format(datetime_module.timedelta(hours=12,
                                                      minutes=34,
                                                      seconds=56,
                                                      microseconds=789123)) \
                                                      == '12:34:56.789123'
    assert timedelta_format(datetime_module.timedelta(minutes=5,
                                                      microseconds=1234)) \
                                                      == '00:05:00.000012'

# Generated at 2022-06-10 21:36:13.075121
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('07:08:09.001000') == datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=1000
    )
    assert timedelta_parse('07:08:09.100000') == datetime_module.timedelta(
        hours=7, minutes=8, seconds=9, microseconds=100000
    )



# Generated at 2022-06-10 21:36:24.244499
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('') == datetime_module.timedelta(0)
    assert timedelta_parse('0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('1.000100') == datetime_module.timedelta(1, 0, 100)
    assert timedelta_parse('01:02:03.000100') == datetime_module.timedelta(
        seconds=3723, microseconds=100
    )
    assert timedelta_parse('01:02:03.000100') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100
    )



# Generated at 2022-06-10 21:36:29.614061
# Unit test for function timedelta_format
def test_timedelta_format():
    assert '00:00:00.000000' == timedelta_format(datetime_module.timedelta())
    assert (
        '33:22:11.000999' ==
        timedelta_format(datetime_module.timedelta(days=1,
                                                   milliseconds=999,
                                                   hours=33,
                                                   minutes=22,
                                                   seconds=11))
    )



# Generated at 2022-06-10 21:36:39.829016
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=123)) == '02:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=123)) == '00:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=123)) == '00:00:00.123000'

# Generated at 2022-06-10 21:36:48.937404
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('5:5:5.5')) == '05:05:05.500000'
    assert timedelta_format(timedelta_parse('123:12:3.000500')) == '123:12:03.000500'
    assert timedelta_format(timedelta_parse('1:2:3.456678')) == '01:02:03.456678'



# Generated at 2022-06-10 21:36:56.566190
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                   seconds=3,
                                                   microseconds=4))
    assert timedelta_parse(s) == datetime_module.timedelta(hours=1,
                                                           minutes=2,
                                                           seconds=3,
                                                           microseconds=4)

# Generated at 2022-06-10 21:37:08.588363
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:23:00.000000') == datetime_module.timedelta(
        1, 60*60*1 + 60*23
    )
    assert timedelta_parse('01:23:45.000000') == datetime_module.timedelta(
        1, 60*60*1 + 60*23 + 45
    )
    assert timedelta_parse('12:34:56.654321') == datetime_module.timedelta(
        12, 60*60*12 + 60*34 + 56, 654321
    )

# Generated at 2022-06-10 21:37:11.699946
# Unit test for function timedelta_format
def test_timedelta_format():
     dt = datetime_module.timedelta(days=1)
     assert dt.total_seconds() == 86400
     assert timedelta_format(dt) == '00:00:00.000000'

# Generated at 2022-06-10 21:38:09.979203
# Unit test for function timedelta_format
def test_timedelta_format():
    # Make sure that timedelta_format is the inverse of timedelta_parse.
    for n in range(1000):
        delta = datetime_module.timedelta(seconds=n)
        assert timedelta_parse(timedelta_format(delta)) == delta

    # Test with a different microsecond
    timedelta = datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                          microseconds=40000)
    assert timedelta_format(timedelta) == '10:20:30.040000'


if PY3:
    from itertools import zip_longest
else:
    from itertools import izip_longest as zip_longest



# Generated at 2022-06-10 21:38:18.664294
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00'
    assert timedelta_format(datetime_module.timedelta(
        hours=7,
        minutes=23,
        seconds=42,
        microseconds=689,
    )) == '07:23:42.000689'



# Generated at 2022-06-10 21:38:24.334702
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(
            datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                      microseconds=123456)
        )
    ) == datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                   microseconds=123456)

# Generated at 2022-06-10 21:38:39.494890
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:38:45.098191
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) == (
                                                          '01:02:03.123456'
                                                      )


# Generated at 2022-06-10 21:38:56.407617
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    ) == '01:02:03.000004'
    assert timedelta_format(
        datetime_module.timedelta(hours=-1, minutes=-2, seconds=-3, microseconds=-4)
    ) == '-01:-02:-03.000004'
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'


if __name__ == '__main__':
    test_timedelta_format()


if PY3:
    def iteritems(d, **kwargs):
        return iter(d.items(**kwargs))

# Generated at 2022-06-10 21:39:07.056242
# Unit test for function timedelta_format
def test_timedelta_format():
    import random
    for i in range(100):
        td = datetime_module.timedelta(
            days=random.randint(0, 100),
            hours=random.randint(0, 23),
            minutes=random.randint(0, 59),
            seconds=random.randint(0, 59),
            microseconds=random.randint(0, 999999),
        )
        assert timedelta_parse(timedelta_format(td)) == td
        assert (
            timedelta_format(timedelta_parse(timedelta_format(td))) ==
            timedelta_format(td)
        )



if PY3:
    def get_executable():
        return os.path.realpath(sys.executable)
else:
    def get_executable():
        return os.path

# Generated at 2022-06-10 21:39:14.354768
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('10:00:00.000000') == datetime_module.timedelta(
        10 * 3600)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(60)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        0, 0, 1)
    assert timedelta_parse('1:01:01.000001') == datetime_module.timedelta(
        3661, 1)


# Generated at 2022-06-10 21:39:25.560717
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )
    assert timedelta_parse('1:1:1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=0
    )


if PY2:
    from __builtin__ import bytes
    import __builtin__ as builtins
    import itertools
    import __future__


    def exec_(expression, globals_, locals_):
        if locals is None:
            locals_ = globals_

        __exec__(
            compile(expression + '\n', '<string>', 'single'),
            globals_,
            locals_
        )

   

# Generated at 2022-06-10 21:39:36.128294
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=7,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '07:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=46,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:46:00.000000'

# Generated at 2022-06-10 21:41:27.575794
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(0,
                                                                         123456)
    assert timedelta_parse('0:0:0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:1') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:0:1.1') == datetime_module.timedelta(0, 1, 100000)
    assert timedelta_parse('0:0:1.1000000') == datetime_module.timedelta(0, 1,
                                                                         100000)
    assert timedelta_parse('0:1:0') == datetime_module.timedelta(0, 60)

# Generated at 2022-06-10 21:41:31.382734
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060)) == \
        '10:20:30.405060'
    assert timedelta_format(datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060,
        days=34)) == '10:20:30.405060'


# Generated at 2022-06-10 21:41:35.590048
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=12,
                                          minutes=34,
                                          seconds=56,
                                          microseconds=789)
    assert timedelta_format(timedelta) == '12:34:56.000789'



# Generated at 2022-06-10 21:41:38.316953
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:11:12.123456') == \
           datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                     microseconds=123456)



# Generated at 2022-06-10 21:41:45.491970
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=10**6 - 1,
    )) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=10**6,
    )) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
            '00:01:00.000000'

# Generated at 2022-06-10 21:41:57.643514
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=100000)
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(seconds=1, microseconds=1)


if hasattr(inspect, 'signature'):
    signature = inspect.signature
else:
    signature = inspect.getargspec

if hasattr(types, 'MappingProxyType'):
    MappingProxyType = types.MappingProxyType
else:
    MappingProxyType = dict

if hasattr(types, 'SimpleNamespace'):
    SimpleNamespace = types.SimpleNamespace

# Generated at 2022-06-10 21:42:02.208930
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('1:2:3.000456') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=456))



# Generated at 2022-06-10 21:42:11.997758
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'

    assert timedelta_format(datetime_module.timedelta(seconds=70)) == \
           '00:01:10.000000'

    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=10)) == \
           '00:02:10.000000'

    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=4, seconds=5)) == \
           '03:04:05.000000'

    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=4, seconds=5, microseconds=6)) == \
           '03:04:05.000006'


#

# Generated at 2022-06-10 21:42:20.530464
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 4, 5)) == '00:00:04.000005'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=1000)
    ) == '00:00:00.001000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=10)
    ) == '00:00:00.000010'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=1)
    ) == '00:00:00.000001'


# Generated at 2022-06-10 21:42:28.017450
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, milliseconds=0,
        microseconds=0
    )) == '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, milliseconds=0,
        microseconds=1
    )) == '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, milliseconds=1,
        microseconds=0
    )) == '00:00:00.001000'
