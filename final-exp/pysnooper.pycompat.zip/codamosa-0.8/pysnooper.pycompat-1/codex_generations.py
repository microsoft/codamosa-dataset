

# Generated at 2022-06-10 21:32:45.581655
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=111_000
    )) == '01:02:03.111111'



# Generated at 2022-06-10 21:32:52.684950
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3,
                                                      hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=123456)) == '01:01:01.123456'



# Generated at 2022-06-10 21:32:56.680217
# Unit test for function timedelta_parse
def test_timedelta_parse():
    parse = timedelta_parse
    assert parse('12:54:11.000002') == datetime_module.timedelta(
        hours=12,
        minutes=54,
        seconds=11,
        microseconds=2
    )
    assert parse('00:00:00.000000') == datetime_module.timedelta(0)



# Generated at 2022-06-10 21:33:06.150788
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=2, minutes=10, seconds=20,
                                  microseconds=3000)
    )) == datetime_module.timedelta(hours=2, minutes=10, seconds=20,
                                    microseconds=3000)


if hasattr(datetime_module, 'fromisoformat'):
    def datetime_from_string(string):
        return datetime_module.datetime.fromisoformat(string)
else:
    def datetime_from_string(string):
        return datetime_module.datetime.strptime(string, '%Y-%m-%dT%H:%M:%S.%f')



# Generated at 2022-06-10 21:33:14.977000
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-1)) == (
        '-1 day, 00:00:00'
    )
    assert timedelta_format(datetime_module.timedelta(days=4, hours=3,
                                                      minutes=2, seconds=1,
                                                      microseconds=500)) == (
        '4 days, 03:02:01.000500'
    )
    assert timedelta_format(
        datetime_module.timedelta(minutes=5, seconds=1, microseconds=500)
    ) == '00:05:01.000500'
    assert timedelta_format(datetime_module.timedelta(seconds=3,
                                                      microseconds=500)) == (
        '00:00:03.000500'
    )


# Generated at 2022-06-10 21:33:25.586106
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.123456')) == \
           '01:02:03.123456'
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == \
           '01:02:03.123456'
    assert timedelta_format(timedelta_parse('01:02:03.123')) == \
           '01:02:03.123000'
    assert timedelta_format(timedelta_parse('01:02:03.12')) == \
           '01:02:03.120000'
    assert timedelta_format(timedelta_parse('01:02:03.1')) == \
           '01:02:03.100000'

# Generated at 2022-06-10 21:33:34.253929
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0)

    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=1)

    assert timedelta_parse('01:00:00.999999') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=999999)

    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=1, microseconds=0)


# Generated at 2022-06-10 21:33:45.284510
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01') == datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_parse('1:01:01.000001') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)
    assert timedelta_parse('1:01:01.999999') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=999999)
    assert timedelta_parse('1:01:01.000000') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=0)

# Generated at 2022-06-10 21:33:48.325561
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=405060
    )) == '10:20:30.405060'


# Generated at 2022-06-10 21:33:53.805437
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:01:00.000000') == datetime_module.timedelta(hours=1, minutes=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(days=1)
    assert timedelta_parse('24:00:00.000000') == datetime_module.timedelta(days=1)
    assert timedelta_parse('24:00:00.000001') == datetime_module.timedelta(days=1, microseconds=1)
    assert timedelta_parse('24:00:00.999999') == datetime_module.timedelta(days=1, microseconds=999999)



# Generated at 2022-06-10 21:34:08.160774
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999,
    )
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )

# Generated at 2022-06-10 21:34:13.650111
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:04.000000') == datetime_module.timedelta(0, 4)
    assert timedelta_parse('00:03:00.000000') == datetime_module.timedelta(0, 3 * 60)
    assert timedelta_parse('00:00:04.123000') == datetime_module.timedelta(0, 4, 123000)
    assert timedelta_parse('03:03:03.123000') == datetime_module.timedelta(3, 3 * 3600 + 3 * 60 + 3, 123000)

# Generated at 2022-06-10 21:34:24.362440
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .third_party import six
    assert timedelta_parse('01:11:04.976') == \
           datetime_module.timedelta(hours=1, minutes=11, seconds=4,
                                     microseconds=976)
    assert timedelta_parse('03:30:00.000') == \
           datetime_module.timedelta(hours=3, minutes=30)
    assert timedelta_parse('00:00:05.123') == \
           datetime_module.timedelta(seconds=5, microseconds=123)
    assert timedelta_parse('00:00:00.123') == \
           datetime_module.timedelta(microseconds=123)

# Generated at 2022-06-10 21:34:28.287417
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4568
    )) == '01:02:03.004568'



# Generated at 2022-06-10 21:34:32.851788
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=5, seconds=5)) == '120:00:05.000000'

# Generated at 2022-06-10 21:34:45.086936
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=100)) \
                                                      == '00:00:01.000100'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=1,
                                                      minutes=2, seconds=3,
                                                      microseconds=1000)) \
                                                      == '01:02:03.001000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1,
                                                      microseconds=100)) \
                                                      == '24:00:01.000100'

# Generated at 2022-06-10 21:34:48.933083
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) == \
           '01:02:03.123456'



# Generated at 2022-06-10 21:35:04.659512
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import assert_equal
    assert_equal(timedelta_parse('0:0:0.000000'), datetime_module.timedelta(0))
    assert_equal(timedelta_parse('1:2:3.000000'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3))
    assert_equal(timedelta_parse('1:2:3.123456'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456))
    assert_equal(timedelta_parse('1:2:3.123456'), datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456))

# Generated at 2022-06-10 21:35:15.018171
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:20:00.000000') == \
                                               datetime_module.timedelta(hours=2,
                                                                minutes=20)
    assert timedelta_parse('02:20:00.0') == \
                                               datetime_module.timedelta(hours=2,
                                                                minutes=20)
    assert timedelta_parse('02:20:01.128901') == \
                                               datetime_module.timedelta(hours=2,
                                                                minutes=20,
                                                                seconds=1,
                                                                microseconds=128901)
    assert timedelta_parse('.128901') == \
                                               datetime_module.timedelta(microseconds=128901)

# Generated at 2022-06-10 21:35:20.505102
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.000456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456)
    assert timedelta_parse('0:00:00.000000') == \
           datetime_module.timedelta(seconds=0)

# Generated at 2022-06-10 21:35:43.811592
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=34,
                                                      seconds=23,
                                                      microseconds=21)) == \
                                                    '02:34:23.000021'


# Generated at 2022-06-10 21:35:57.680244
# Unit test for function timedelta_parse
def test_timedelta_parse():
    roundtrip = lambda timedelta: timedelta_parse(timedelta_format(timedelta))
    assert roundtrip(datetime_module.timedelta(0)) == datetime_module.timedelta(0)
    assert roundtrip(datetime_module.timedelta(nanoseconds=1)) == datetime_module.timedelta(microseconds=1)
    assert roundtrip(datetime_module.timedelta(microseconds=1)) == datetime_module.timedelta(microseconds=1)
    assert roundtrip(datetime_module.timedelta(milliseconds=1)) == datetime_module.timedelta(milliseconds=1)
    assert roundtrip(datetime_module.timedelta(seconds=1)) == datetime_module.timedelta(seconds=1)
    assert roundtrip

# Generated at 2022-06-10 21:36:02.734376
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=45,
                                                      seconds=1)) == \
                                                      '02:45:01.000000'



# Generated at 2022-06-10 21:36:05.978231
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=100000
    )) == '01:01:01.100000'



# Generated at 2022-06-10 21:36:18.389849
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                                '01:00:00'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                                  '00:01:00'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                  '00:00:01'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) \
                                                            == '01:01:00'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) \
                                                            == '01:00:01'

# Generated at 2022-06-10 21:36:29.258743
# Unit test for function timedelta_format
def test_timedelta_format():
    one_second = datetime_module.timedelta(seconds=1)
    assert timedelta_format(one_second - datetime_module.timedelta(microseconds=1)) == '00:00:00.999999'
    assert timedelta_format(one_second) == '00:00:01.000000'
    assert timedelta_format(one_second + datetime_module.timedelta(microseconds=1)) == '00:00:01.000001'

    one_minute = datetime_module.timedelta(minutes=1)
    assert timedelta_format(one_minute - datetime_module.timedelta(microseconds=1)) == '00:00:59.999999'
    assert timedelta_format(one_minute) == '00:01:00.000000'
    assert timedelta_

# Generated at 2022-06-10 21:36:39.514107
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=1))) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-10 21:36:51.888431
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:23:45.678901')
    assert time_isoformat(timedelta) == '01:23:45.678901'
    timedelta = timedelta_parse('123:45.678901')
    assert time_isoformat(timedelta) == '123:45.678901'
    timedelta = timedelta_parse('45.678901')
    assert time_isoformat(timedelta) == '45.678901'
    timedelta = timedelta_parse('1:23:45.678')
    assert time_isoformat(timedelta) == '01:23:45.678000'
    timedelta = timedelta_parse('1:23:45.6789')

# Generated at 2022-06-10 21:36:55.415465
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=7, minutes=8, seconds=9,
                                          microseconds=123456)

    assert timedelta == timedelta_parse(timedelta_format(timedelta))




# Generated at 2022-06-10 21:37:07.701184
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == \
                                                  '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == \
                                                  '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=2)) == \
                                                  '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(days=3)) == \
                                                  '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                                                  '02:00:00.000000'

# Generated at 2022-06-10 21:37:54.909710
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    delta = datetime_module.timedelta(hours=10, minutes=23, seconds=15,
                                      microseconds=912384)
    assert timedelta_format(delta) == '10:23:15.912384'
    delta = datetime_module.timedelta(days=5, hours=3, hours=4, seconds=5,
                                      microseconds=912384)
    assert timedelta_format(delta) == '52:04:05.912384'
    with pytest.raises(NotImplementedError):
        timedelta_format(delta, timespec='bla')


# Generated at 2022-06-10 21:38:07.754267
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=365)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=365, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=365, milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(days=365, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=365, minutes=1)) == '00:01:00.000000'

# Generated at 2022-06-10 21:38:17.110124
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) \
                                                      == '01:02:03.456789'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) \
                                                      == '23:00:00.000000'



# Generated at 2022-06-10 21:38:23.206596
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                   seconds=3,
                                                   microseconds=456789))
    ) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456789)

# Generated at 2022-06-10 21:38:31.294230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-10 21:38:38.532201
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = timedelta_parse('21:12:03.428452')
    assert timedelta_format(delta) == '21:12:03.428452'
    assert timedelta_format(delta + datetime_module.timedelta(1)) == \
        '21:12:03.428452' + '\x00' * 2
    assert timedelta_format(delta + datetime_module.timedelta(0, 0, 1)) == \
        '21:12:03.428452' + '\x00' * 5
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'



# Generated at 2022-06-10 21:38:44.996563
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        '-1:00:00.000100'
    ) == datetime_module.timedelta(hours=-1, microseconds=-100)

    assert timedelta_parse(
        '1:00:00.000100'
    ) == datetime_module.timedelta(hours=1, microseconds=100)

    assert timedelta_parse(
        '-00:01:00.000100'
    ) == datetime_module.timedelta(minutes=-1, microseconds=-100)

    assert timedelta_parse(
        '00:01:00.000100'
    ) == datetime_module.timedelta(minutes=1, microseconds=100)

    assert timedelta_parse(
        '00:00:01.000100'
    ) == datetime_module

# Generated at 2022-06-10 21:38:55.145734
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('01:00:01') == datetime_module.timedelta(hours=1, seconds=1)
    assert timedelta_parse('01:01:01') == datetime_module.timedelta(hours=1, minutes=1, seconds=1)

test_timedelta_parse()

# Generated at 2022-06-10 21:39:05.935282
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
        milliseconds=10)
    assert timedelta_

# Generated at 2022-06-10 21:39:11.785549
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-10 21:41:03.239635
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:21:23.123456'))[-6:] == '123456'
    assert timedelta_format(timedelta_parse('23.123456'))[-6:] == '123456'
    assert timedelta_format(timedelta_parse('.123456'))[-6:] == '123456'
    assert timedelta_format(timedelta_parse('1:21:23.000000'))[-6:] == '999999'
    assert timedelta_format(timedelta_parse('23.000000'))[-6:] == '999999'
    assert timedelta_format(timedelta_parse('.000000'))[-6:] == '000000'



# Generated at 2022-06-10 21:41:07.210080
# Unit test for function timedelta_format
def test_timedelta_format():
    for index in range(10000):
        timedelta = datetime_module.timedelta(microseconds=index)
        formatted = timedelta_format(timedelta)
        parsed = timedelta_parse(formatted)
        assert parsed == timedelta



# Generated at 2022-06-10 21:41:16.861434
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] >= (3, 6):
        assert timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123456)
        ) == datetime_module.time(hour=1, minute=2, second=3,
                                  microsecond=123456).isoformat()
    else:
        assert timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123456)
        ) == '01:02:03.123456'
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    ))

# Generated at 2022-06-10 21:41:27.017366
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') is datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == \
           datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(seconds=1, microseconds=1)

# Generated at 2022-06-10 21:41:36.617647
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=-1)) == (
        '00:00:00.000000'
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=-1))) == (
        datetime_module.timedelta(days=-1)
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == (
        datetime_module.timedelta(seconds=1)
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1))) == (
        datetime_module.timedelta(seconds=1, microseconds=1)
    )

test_timedelta_parse()

# Generated at 2022-06-10 21:41:48.489795
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:05.000000') == datetime_module.timedelta(0, 5)
    assert timedelta_parse('0:00:05.000500') == datetime_module.timedelta(
        0, 5, 500
    )
    assert timedelta_parse('0:00:05.000500') == datetime_module.timedelta(
        0, 5, 500
    )
    assert timedelta_parse('0:05:04.500500') == datetime_module.timedelta(
        0, 304, 500
    )

# Generated at 2022-06-10 21:41:59.420730
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == '00:00:00.001234'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345)) == '00:00:00.012345'

# Generated at 2022-06-10 21:42:09.326208
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
        '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
        '23:59:59.999999'


# Generated at 2022-06-10 21:42:15.839247
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(0, 0, 0, 123456))
    assert time == '00:00:00.123456'
    time = time_isoformat(datetime_module.time(1, 2, 3, 123456))
    assert time == '01:02:03.123456'
    time = time_isoformat(datetime_module.time(4, 5, 6, 123456))
    assert time == '04:05:06.123456'



# Generated at 2022-06-10 21:42:24.332557
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('01:02:03.000000') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3))
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000,
    )
    assert (timedelta_format(datetime_module.timedelta(hours=1,
                                                       minutes=2,
                                                       seconds=3,
                                                       microseconds=4000)) ==
            '01:02:03.004000')