

# Generated at 2022-06-10 21:32:49.326396
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_parse_equal(s, *args, **kwargs):
        assert timedelta_parse(s) == datetime_module.timedelta(*args, **kwargs)
    assert_parse_equal('1:23:45', hours=1, minutes=23, seconds=45)
    assert_parse_equal('1:23:45:67', hours=1, minutes=23, seconds=45,
                       microseconds=670000)
    assert_parse_equal('1:23:45.67', hours=1, minutes=23, seconds=45,
                       microseconds=67000)
    assert_parse_equal('1:23:45.678901', hours=1, minutes=23, seconds=45,
                       microseconds=678901)

# Generated at 2022-06-10 21:32:57.437174
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=4,
                                                      seconds=5,
                                                      microseconds=200)) == \
                                                              '02:04:05.000200'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=4,
                                                      seconds=5,
                                                      microseconds=20)) == \
                                                              '02:04:05.000020'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=4,
                                                      seconds=5,
                                                      microseconds=2)) == \
                                                              '02:04:05.000002'

# Generated at 2022-06-10 21:33:01.599956
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=7)) == (
        '07:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=7, seconds=1,
                                                      microseconds=2234)) == (
        '07:00:01.002234'
    )

# Generated at 2022-06-10 21:33:11.315858
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_1 = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                            microseconds=456789)
    timedelta_2 = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                            microseconds=45678)
    timedelta_3 = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                            microseconds=4567891)
    assert timedelta_parse(timedelta_format(timedelta_1)) == timedelta_1
    assert timedelta_parse(timedelta_format(timedelta_2)) == timedelta_2
    assert timedelta_parse(timedelta_format(timedelta_3)) == timedelta_3

# Generated at 2022-06-10 21:33:18.058711
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = datetime_module.time(
        hour=0, minute=0, second=0, microsecond=0,
    )
    assert time_isoformat(time) == '00:00:00.000000'

    zero_timedelta = datetime_module.timedelta()
    assert timedelta_format(zero_timedelta) == '00:00:00.000000'

    assert timedelta_format(timedelta_parse(timedelta_format(zero_timedelta))) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse(timedelta_format(zero_timedelta))) == timedelta_format(zero_timedelta)
    assert timedelta_parse(timedelta_format(zero_timedelta)) == zero_timedelta

# Generated at 2022-06-10 21:33:28.567796
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=24)) == '03:24:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=24, seconds=12)) == '03:24:12.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=24, seconds=12, microseconds=123000)) == '03:24:12.123000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123000)) == '00:00:00.123000'


# Generated at 2022-06-10 21:33:42.021217
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(minutes=2, microseconds=2)) == '00:02:00.000002'



# Generated at 2022-06-10 21:33:47.324019
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:00:00.000000') == datetime_module.timedelta(
        hours=2
    )
    assert timedelta_parse('0:05:00.000000') == datetime_module.timedelta(
        minutes=5
    )
    assert timedelta_parse('0:00:10.000000') == datetime_module.timedelta(
        seconds=10
    )
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )

# Generated at 2022-06-10 21:33:56.756637
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                   seconds=59,
                                                   microseconds=999999))
    ) == datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                   microseconds=999999)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                   seconds=0,
                                                   microseconds=0))
    ) == datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                   microseconds=0)

# Generated at 2022-06-10 21:34:07.494008
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
                                                            '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=11)) == \
                                                            '00:00:11.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=500000)) == \
                                                            '00:00:00.500000'

# Generated at 2022-06-10 21:34:28.158046
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(microseconds=1),
                      datetime_module.timedelta(seconds=1),
                      datetime_module.timedelta(minutes=1),
                      datetime_module.timedelta(hours=1)):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))


if PY2:
    import __builtin__
    get_next = __builtin__.next
else:
    get_next = __builtins__['next']

if PY2:
    try:
        # noinspection PyUnresolvedReferences
        from UserDict import IterableUserDict
    except ImportError: # Python 3.3-3.5
        from collections import UserDict as IterableUserDict

# Generated at 2022-06-10 21:34:31.162381
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

test_timedelta_parse()



# Generated at 2022-06-10 21:34:38.862395
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
        microseconds=456789,
    )
    assert timedelta_parse('00:00:00.0') == datetime_module.timedelta(
        milliseconds=0
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(
        milliseconds=0
    )

# Generated at 2022-06-10 21:34:45.908896
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000004') == \
           datetime_module.timedelta(hours=1, minutes=2,
                                     seconds=3,
                                     microseconds=4)
    assert timedelta_parse('01:02:03.000004') == \
           datetime_module.timedelta(hours=1, minutes=2,
                                     seconds=3,
                                     microseconds=4)



# Generated at 2022-06-10 21:34:54.291316
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest

    def test_case(timedelta, string):
        assert timedelta_parse(string) == timedelta

    test_case(datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                        microseconds=567),
              '2:03:04.00567')
    test_case(datetime_module.timedelta(seconds=0, microseconds=567),
              '0:00:00.00567')
    test_case(datetime_module.timedelta(hours=0, microseconds=567),
              '00:00:00.00567')

# Generated at 2022-06-10 21:35:02.748812
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('-01:00:00.000000') == datetime_module.timedelta(hours=-1)

# Generated at 2022-06-10 21:35:11.163851
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2))) == datetime_module.timedelta(hours=1, minutes=2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3)

# Generated at 2022-06-10 21:35:23.186397
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:35:33.997691
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("00:00:00.000000") == datetime_module.timedelta(0)
    assert timedelta_parse("00:00:00.000001") == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse("00:00:00.999999") == datetime_module.timedelta(
        microseconds=999999)
    assert timedelta_parse("00:00:01.000000") == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse("00:00:01.000001") == datetime_module.timedelta(
        seconds=1, microseconds=1)

# Generated at 2022-06-10 21:35:39.175433
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
                                                      '00:00:01.000001'



# Generated at 2022-06-10 21:36:07.786708
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.23)) == '00:00:01.002300'
    assert timedelta_format(datetime_module.timedelta(seconds=1.234321)) == '00:00:01.234321'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2, seconds=3.321)) == '26:00:03.321000'
    assert timedelta_format(datetime_module.timedelta(days=-1, hours=-2, seconds=-3.321)) == '02:00:03.321000'
    assert timedelta_format(datetime_module.timedelta(seconds=123123123.123123)) == '34:25:23.123123'



# Generated at 2022-06-10 21:36:14.970870
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1,
                                                                      seconds=2,
                                                                      microseconds=3))) == \
                                                                      datetime_module.timedelta(hours=1,
                                                                                                seconds=2,
                                                                                                microseconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1,
                                                                      seconds=2,
                                                                      microseconds=30))) == \
                                                                      datetime_module.timedelta(hours=1,
                                                                                                seconds=2,
                                                                                                microseconds=30)



# Generated at 2022-06-10 21:36:19.515629
# Unit test for function timedelta_format
def test_timedelta_format():
    """ Test the correct behaviour of the timedelta_format function.
    """
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3.7)) == \
        '01:02:03.700000'



# Generated at 2022-06-10 21:36:29.949281
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1) - datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)

# Generated at 2022-06-10 21:36:38.694176
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == timedelta_format(
        datetime_module.timedelta(days=1, hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    )
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == timedelta_

# Generated at 2022-06-10 21:36:44.836716
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == \
            '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
            '00:00:00.000001'



# Generated at 2022-06-10 21:36:49.215163
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=123456.789012)
    )) == datetime_module.timedelta(seconds=123456.789012)



# Generated at 2022-06-10 21:37:00.972777
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for input, output in (
        ('0:0:0', datetime_module.timedelta()),
        ('1:0:0', datetime_module.timedelta(hours=1, minutes=0, seconds=0)),
        ('0:0:0.1', datetime_module.timedelta(seconds=0, microseconds=100000)),
        ('1:1:1.1', datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                              microseconds=100000)),
    ):
        assert timedelta_parse(input) == output



# Generated at 2022-06-10 21:37:08.833846
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''
    Test that `timedelta_parse` can successfully parse timestamps in various
    formats.
    '''
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2') == datetime_module.timedelta(
        hours=1, minutes=2
    )
    assert timedelta_parse('1') == datetime_module.timedelta(hours=1)



# Generated at 2022-06-10 21:37:12.840654
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0))) \
           == datetime_module.timedelta(0, 0)
    # OK, that's enough


if PY2:
    import functools

    def get_arg_names(function):
        # In Python 2 we need to use `getargspec`, which we can't import from
        # the `inspect` module in the same line from the `functools.wraps`
        # decorator due to a PyLint bug; see
        # https://github.com/PyCQA/pylint/issues/414
        from inspect import getargspec
        return getargspec(function).args


# Generated at 2022-06-10 21:37:33.680860
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
                                                  '00:00:01.000000')


# Generated at 2022-06-10 21:37:41.559050
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # `timedelta_parse` should be the inverse of `timedelta_format`
    assert (timedelta_format(timedelta_parse('00:00:00.000000')) ==
            '00:00:00.000000')
    assert (timedelta_format(timedelta_parse('00:00:00.000000')) ==
            '00:00:00.000000')
    assert (timedelta_format(timedelta_parse('23:59:59.999999')) ==
            '23:59:59.999999')



# Generated at 2022-06-10 21:37:51.036798
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:01:15.000500') == \
           datetime_module.timedelta(seconds=75, microseconds=500)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00.000000') == \
           datetime_module.timedelta(hours=1)

# Generated at 2022-06-10 21:38:02.131992
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) == \
                                                              '01:02:03.456000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                              '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'

# Generated at 2022-06-10 21:38:05.929201
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4*1e4
    )

# Generated at 2022-06-10 21:38:20.109000
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, microseconds=2)) == '01:00:00.000002'

# Generated at 2022-06-10 21:38:29.472443
# Unit test for function timedelta_format
def test_timedelta_format():
    assert (
        timedelta_format(datetime_module.timedelta(hours=5)) ==
        '05:00:00.000000'
    )
    assert (
        timedelta_format(datetime_module.timedelta(hours=5, minutes=1)) ==
        '05:01:00.000000'
    )
    assert (
        timedelta_format(datetime_module.timedelta(hours=5, minutes=10)) ==
        '05:10:00.000000'
    )
    assert (
        timedelta_format(datetime_module.timedelta(hours=5, minutes=10, seconds=1)) ==
        '05:10:01.000000'
    )

# Generated at 2022-06-10 21:38:34.426008
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in range(-1, 86400001, 100000):
        delta = datetime_module.timedelta(microseconds=i)
        assert timedelta_parse(timedelta_format(delta)) == delta




# Generated at 2022-06-10 21:38:46.989109
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.001') == datetime_module.timedelta(
        milliseconds=1
    )
    assert timedelta_parse('0:0:1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:0:0') == datetime_module.timedelta(hours=1)



# Generated at 2022-06-10 21:38:58.568376
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=10,
                                                      seconds=59,
                                                      microseconds=2)) == \
           '03:10:59.000002'

    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=3,
                                                      minutes=10,
                                                      seconds=59,
                                                      microseconds=2)) == \
           '03:10:59.000002'

    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
           '00:00:00.000002'


# Generated at 2022-06-10 21:39:40.453676
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:39:51.661518
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:04.000000') == datetime_module.timedelta(
        seconds=4
    )
    assert timedelta_parse('00:00:04.000001') == datetime_module.timedelta(
        microseconds=100001
    )
    assert timedelta_parse('00:00:04.000010') == datetime_module.timedelta(
        microseconds=100010
    )
    assert timedelta_parse('00:00:04.000100') == datetime_module.timedelta(
        microseconds=100100
    )
    assert timedelta_parse('00:00:04.001000') == datetime_module.timedelta(
        microseconds=101000
    )

# Generated at 2022-06-10 21:40:05.440993
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0, milliseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0, microseconds=5)) == '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'

# Generated at 2022-06-10 21:40:17.416954
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5)) == \
           '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3)) == \
           '05:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, seconds=13)) == \
           '05:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, microseconds=13)) == \
           '05:00:00.000013'
    assert timedelta_format(datetime_module.timedelta(hours=0, microseconds=11)) == \
           '00:00:00.000011'

# Generated at 2022-06-10 21:40:20.304387
# Unit test for function timedelta_format
def test_timedelta_format():
    s = '03:04:05.939292'
    assert timedelta_format(timedelta_parse(s)) == s


real_type = (int, float, complex)



# Generated at 2022-06-10 21:40:27.077647
# Unit test for function timedelta_parse
def test_timedelta_parse():
    result_1 = timedelta_parse(timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=4)
        ))
    result_2 = timedelta_parse(timedelta_format(
            datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                      microseconds=5)
        ))
    assert result_1 == datetime_module.timedelta(hours=1, minutes=2,
                                                 seconds=3,
                                                 microseconds=4)
    assert result_2 == datetime_module.timedelta(days=1, hours=2, minutes=3,
                                                 seconds=4, microseconds=5)

# Generated at 2022-06-10 21:40:39.360905
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.111111') == \
           datetime_module.timedelta(microseconds=111111)
    assert timedelta_parse('00:01:22.333333') == \
           datetime_module.timedelta(seconds=82, microseconds=333333)
    assert timedelta_parse('00:00:00.664367') == \
           datetime_module.timedelta(microseconds=664367)
    assert timedelta_parse('01:23:45.678901') == \
           datetime_module.timedelta(seconds=5025, microseconds=678901)

# Generated at 2022-06-10 21:40:48.516398
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:05:15.123456') == \
           datetime_module.timedelta(hours=1, minutes=5,
                                     seconds=15, microseconds=123456)
    assert timedelta_parse('1:05:15.1234567') == \
           datetime_module.timedelta(hours=1, minutes=5,
                                     seconds=15, microseconds=123456)

    assert timedelta_parse('1:05:15.123') == \
           datetime_module.timedelta(hours=1, minutes=5,
                                     seconds=15, microseconds=123000)

# Generated at 2022-06-10 21:40:52.058949
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, minutes=14, seconds=15,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '03:14:15.123456'



# Generated at 2022-06-10 21:41:02.384391
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest

    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == '01:02:03.000004'

    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == '00:00:00.000003'

    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(hours=1), timespec='hours')

    large_timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                                seconds=5, microseconds=6)
    large_timedelta_string = timedelta_format(large_timedelta)
   

# Generated at 2022-06-10 21:42:24.017489
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:20:30.400500') == datetime_module.timedelta(
        hours=1, minutes=20, seconds=30, microseconds=400500
    )
    assert timedelta_parse('1:2:3.400500') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400500
    )
    assert timedelta_parse('1:2:3.4000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('1:2:3.0') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )

# Generated at 2022-06-10 21:42:30.480938
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    This test was written when there was a fundamental bug in
    `timedelta_format` causing it to return values one digit shorter. This
    would cause misaligned parsing, which in turn would cause `pickle` to fail
    to unpickle datetimes properly.

    """
    for timedelta in [datetime_module.timedelta(seconds=i) for i in range(1, 100)]:
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta