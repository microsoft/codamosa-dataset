

# Generated at 2022-06-10 21:32:43.982093
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(days=1,
                                                                        seconds=3661)


dumps = None
loads = None

try:
    import simplejson as json
except ImportError:
    import json
else:

    def dumps(obj, **kwargs):
        return json.dumps(obj, **kwargs).replace(': ', ':')

    def loads(s, **kwargs):
        return json.loads(s, **kwargs)

# Generated at 2022-06-10 21:32:47.933503
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=2, minutes=3, seconds=4,
        microseconds=567
    )
    assert timedelta_format(timedelta) == '02:03:04.00567'


# Generated at 2022-06-10 21:32:51.464044
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in ('0:0:13.123000', '0:0:13:123000'):
        assert timedelta_parse(s) == datetime_module.timedelta(seconds=13,
                                                               microseconds=123)
    assert timedelta_parse('0:0:13.123000') == datetime_parse('0:0:13.123000')



# Generated at 2022-06-10 21:32:54.477478
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                              '01:02:03.000004'



# Generated at 2022-06-10 21:33:02.620062
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=2,
                                                      seconds=2,
                                                      microseconds=2)) == \
                                                      '02:02:02.000002'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=2)) == '02:00:02'


test_timedelta_format()

# Generated at 2022-06-10 21:33:07.870756
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=1234567)) == '01:02:03.123456'



# Generated at 2022-06-10 21:33:15.084964
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(hours=14, minutes=35,
                                  seconds=6, microseconds=499999)
    assert timedelta_format(t) == '14:35:06.499999'
    t = datetime_module.timedelta(hours=14, minutes=35, seconds=6, microseconds=500000)
    assert timedelta_format(t) == '14:35:06.500000'
    t = datetime_module.timedelta(hours=14, minutes=35, seconds=6, microseconds=500001)
    assert timedelta_format(t) == '14:35:06.500001'



# Generated at 2022-06-10 21:33:25.729820
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if PY3 and sys.version_info[:2] >= (3, 6):
        datetime_timedelta_format = datetime_module.timedelta.isoformat
    else:
        datetime_timedelta_format = (
            lambda timedelta: timedelta_format(timedelta).lstrip('0:')
        )

    import random
    import math

# Generated at 2022-06-10 21:33:34.307129
# Unit test for function timedelta_parse

# Generated at 2022-06-10 21:33:43.804956
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=5,
                                                      minutes=15)) == \
           '05:15:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=15, minutes=13,
                                                      seconds=7, milliseconds=200)) == \
           '15:13:07.200000'
    assert timedelta_format(datetime_module.timedelta(hours=15, minutes=13,
                                                      seconds=7, microseconds=200)) == \
           '15:13:07.000200'



# Generated at 2022-06-10 21:34:01.475956
# Unit test for function timedelta_format
def test_timedelta_format():
    d1 = timedelta_parse('01:02:03.123456')
    d2 = timedelta_parse('-01:02:03.123456')
    s1 = timedelta_format(d1)
    s2 = timedelta_format(d2)
    assert s1 == '01:02:03.123456'
    assert s2 == '-01:02:03.123456'
    assert timedelta_parse(s1) == d1
    assert timedelta_parse(s2) == d2

# Generated at 2022-06-10 21:34:11.007252
# Unit test for function timedelta_format
def test_timedelta_format():
    '''Unit test for function timedelta_format'''
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'

# Generated at 2022-06-10 21:34:23.044615
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(hours=1, seconds=1)
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(hours=1, minutes=1, seconds=1)

# Generated at 2022-06-10 21:34:28.111688
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(hours=4,
                                                            minutes=20,
                                                            seconds=10,
                                                            microseconds=100)),
                 '04:20:10.000100')



# Generated at 2022-06-10 21:34:31.282782
# Unit test for function timedelta_format
def test_timedelta_format():
    if not (sys.version_info[:2] >= (3, 7)):
        return  # This test is only relevant for Python 3.7 and up
    for value in '980:12:34.456789', '5678:09:10.123456', '-123:04:05.987654':
        assert timedelta_format(timedelta_parse(value)) == value

test_timedelta_format()

# Generated at 2022-06-10 21:34:43.491616
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == \
           datetime_module.timedelta(microseconds=999999)


# Generated at 2022-06-10 21:34:48.053473
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == timedelta_parse('01:01:01.1')
    assert timedelta_parse('01:01:01.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=100
    )

# Generated at 2022-06-10 21:35:01.248300
# Unit test for function timedelta_format
def test_timedelta_format():
    for inp, out in [
        (datetime_module.timedelta(seconds=2), '00:00:02.000000'),
        (datetime_module.timedelta(seconds=2, minutes=3), '00:03:02.000000'),
        (datetime_module.timedelta(seconds=2, minutes=3, hours=4),
         '04:03:02.000000'),
        (datetime_module.timedelta(seconds=2, minutes=3, hours=4,
                                   microseconds=5),
         '04:03:02.000005'),
    ]:
        assert timedelta_format(inp) == out



# Generated at 2022-06-10 21:35:08.461501
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                               datetime_module.timedelta()
    assert timedelta_parse('02:03:04.056789') == \
                                        datetime_module.timedelta(hours=2,
                                                                 minutes=3,
                                                                 seconds=4,
                                                                 microseconds=56789)
    assert timedelta_parse('18:59:37.344000') == \
                                        datetime_module.timedelta(hours=18,
                                                                 minutes=59,
                                                                 seconds=37,
                                                                 microseconds=344000)

# Generated at 2022-06-10 21:35:20.504154
# Unit test for function timedelta_format
def test_timedelta_format():
    assert '123:45:67.890123' == timedelta_format(datetime_module.timedelta(123, 45, 67, 890123))
    assert '00:00:00.012345' == timedelta_format(datetime_module.timedelta(0, 0, 1, 2345))
    assert '00:00:00.000456' == timedelta_format(datetime_module.timedelta(0, 0, 0, 456))
    assert '00:00:00.000001' == timedelta_format(datetime_module.timedelta(0, 0, 0, 1))
    assert '00:00:00.000000' == timedelta_format(datetime_module.timedelta(0, 0, 0, 0))

# Generated at 2022-06-10 21:35:56.065519
# Unit test for function timedelta_format

# Generated at 2022-06-10 21:36:07.884144
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                            '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == \
                                            '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=1)) == \
                                            '01:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=123456789)) == '00:00:00.123457'


# Generated at 2022-06-10 21:36:13.997829
# Unit test for function timedelta_format
def test_timedelta_format():
    for delta in (
        0,
        1,
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(microseconds=1),
        datetime_module.timedelta(microseconds=1000),
        datetime_module.timedelta(minutes=1, microseconds=1000),
        datetime_module.timedelta(hours=1, minutes=1, microseconds=1000),
    ):
        assert timedelta_parse(timedelta_format(delta)) == delta



# Generated at 2022-06-10 21:36:21.259179
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=34,
                                                      seconds=59,
                                                      microseconds=654321)) == (
        '03:34:59:654321'
    )
    assert timedelta_format(datetime_module.timedelta(hours=116, minutes=34,
                                                      seconds=59,
                                                      microseconds=654321)) == (
        '116:34:59:654321'
    )



# Generated at 2022-06-10 21:36:31.362653
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0:0') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('0:0:0:1') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:1:0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0:0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:0:0:0') == datetime_module.timedelta(hours=1)

    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'

# Generated at 2022-06-10 21:36:41.375246
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:00:00.000000') == (
        datetime_module.timedelta(hours=23)
    )
    assert timedelta_parse('00:59:00.000000') == (
        datetime_module.timedelta(minutes=59)
    )
    assert timedelta_parse('00:00:59.000000') == (
        datetime_module.timedelta(seconds=59)
    )
    assert timedelta_parse('00:00:00.999999') == (
        datetime_module.timedelta(microseconds=999999)
    )

# Generated at 2022-06-10 21:36:45.867099
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4567)
    assert timedelta_format(timedelta) == \
        '01:02:03.004567'



# Generated at 2022-06-10 21:36:57.556887
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) \
                                                      == '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) \
                                                      == '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=1)) \
                                                      == '00:00:01.000001'


# Generated at 2022-06-10 21:37:08.862845
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=22,
                                                      seconds=33,
                                                      microseconds=444444)) == \
        '11:22:33.444444'
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=22,
                                                      seconds=33)) == \
        '11:22:33'
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=22)) == \
        '11:22:00'
    assert timedelta_format(datetime_module.timedelta(hours=11)) == \
        '11:00:00'



# Generated at 2022-06-10 21:37:14.182952
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=5,
                                                                      minutes=6,
                                                                      seconds=7,
                                                                      microseconds=8))) \
           == datetime_module.timedelta(hours=5, minutes=6, seconds=7, microseconds=8)

# Generated at 2022-06-10 21:38:06.684400
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.111111') == datetime_module.timedelta(microseconds=111111)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(hours=24) - datetime_module.timedelta(microseconds=1)



# Generated at 2022-06-10 21:38:12.255498
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=3, minutes=5,
                                          seconds=14, microseconds=525000)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-10 21:38:24.176577
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 9))) == datetime_module.timedelta(1, 9)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 0, 6, 2))) == datetime_module.timedelta(0, 0, 0, 6, 2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 0, 6, 21))) == datetime_module.timedelta(0, 0, 0, 6, 21)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 0, 6, 200))) == datetime_module.timedelta(0, 0, 0, 6, 200)

# Generated at 2022-06-10 21:38:39.352827
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(hours=1))
    ) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(minutes=1))
    ) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(seconds=1))
    ) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(microseconds=1))
    ) == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-10 21:38:51.294857
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=10)) == \
                            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5)) == \
                            '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == \
                            '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
                            '00:00:00.000005'

# Generated at 2022-06-10 21:39:02.799623
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
                                                        '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
                                                        '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
                                                        '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
                                                        '00:00:00.001000'

# Generated at 2022-06-10 21:39:06.590897
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4001)) == \
        '01:02:03.004001'


# Generated at 2022-06-10 21:39:09.265050
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.056789') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=56789
    )

# Generated at 2022-06-10 21:39:15.259055
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=20,
                                                      seconds=12)) == \
           '10:20:12.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=20,
                                                      seconds=12,
                                                      microseconds=99)) == \
           '10:20:12.000099'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=20,
                                                      seconds=12,
                                                      microseconds=999999)) == \
           '10:20:12.999999'



# Generated at 2022-06-10 21:39:25.987141
# Unit test for function timedelta_parse
def test_timedelta_parse():
    instances = [
        (datetime_module.timedelta(days=2, seconds=3, microseconds=4),
         '48:00:03.000004'),
        (datetime_module.timedelta(days=5, hours=6, minutes=7, seconds=8),
         '129:07:08'),
        (datetime_module.timedelta(microseconds=1),
         '00:00:00.000001'),
        (datetime_module.timedelta(),
         '00:00:00')
    ]

    for td, s in instances:
        assert timedelta_format(td) == s
        assert timedelta_parse(s) == td



# Generated at 2022-06-10 21:40:54.241798
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1, 2, 3)) == \
                                                        '00:00:01.000002'


# Generated at 2022-06-10 21:40:57.362844
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=7, minutes=23, seconds=5,
                                          microseconds=4000)
    assert timedelta_format(timedelta) == '07:23:05.004000'


# Generated at 2022-06-10 21:41:07.728562
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(seconds=123)) == '00:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=123)) == '00:00:00.123000'
    assert timedelta_format(datetime_module.timedelta(seconds=123, hours=1)) == '01:02:03.000000'
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(seconds=123, hours=1)
   

# Generated at 2022-06-10 21:41:14.295662
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('9:0:0.1234')) == '09:00:00.001234'
    assert timedelta_format(timedelta_parse('9:34:05.657')) == '09:34:05.000657'
    assert timedelta_format(timedelta_parse('9:34:05.657123')) == \
                                                           '09:34:05.657123'
    assert timedelta_format(timedelta_parse(':34:05.657123')) == '00:34:05.657123'

# Generated at 2022-06-10 21:41:24.955236
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('11:22:33.123456') == datetime_module.timedelta(
        hours=11, minutes=22, seconds=33, microseconds=123456
    )
    assert timedelta_parse('11:22:33.1234') == datetime_module.timedelta(
        hours=11, minutes=22, seconds=33, microseconds=123400
    )
    assert timedelta_parse('11:22:33.123') == datetime_module.timedelta(
        hours=11, minutes=22, seconds=33, microseconds=123000
    )
    assert timedelta_parse('11:22:33.12') == datetime_module.timedelta(
        hours=11, minutes=22, seconds=33, microseconds=120000
    )
    assert timedelta

# Generated at 2022-06-10 21:41:33.985452
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('01:02:03:456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)
    assert timedelta_parse('01:02:03.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)
    assert timedelta_parse('01:02:03.4560') == datetime_module.timedelta

# Generated at 2022-06-10 21:41:43.080350
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000001') == datetime_module.timedelta(
                                                  microseconds=1)
    assert timedelta_parse('00:00:00:000010') == datetime_module.timedelta(
                                                  microseconds=10)
    assert timedelta_parse('00:00:00:000100') == datetime_module.timedelta(
                                                  microseconds=100)
    assert timedelta_parse('00:00:00:001000') == datetime_module.timedelta(
                                                  microseconds=1000)
    assert timedelta_parse('00:00:00:010000') == datetime_module.timedelta(
                                                  milliseconds=10)
    assert timedelta_parse('00:00:00:100000') == datetime_

# Generated at 2022-06-10 21:41:56.136588
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=2,
                                                                      hours=3,
                                                                      minutes=4,
                                                                      seconds=8,
                                                                      microseconds=7))) == \
                                                                 datetime_module.timedelta(days=2,
                                                                                           hours=3,
                                                                                           minutes=4,
                                                                                           seconds=8,
                                                                                           microseconds=7)


# Generated at 2022-06-10 21:42:00.679964
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '26:00:03.000004'



# Generated at 2022-06-10 21:42:11.651948
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def check(s):
        assert timedelta_format(timedelta_parse(s)) == s

    check('00:00:00.000000')
    check('00:00:00.000001')
    check('00:00:00.000009')
    check('00:00:00.000010')
    check('00:00:00.000099')
    check('00:00:00.000100')
    check('00:00:00.000999')
    check('00:00:00.001000')
    check('00:00:00.009999')
    check('00:00:00.010000')
    check('00:00:00.099999')
    check('00:00:00.100000')
    check('00:00:00.999999')