

# Generated at 2022-06-16 19:14:49.047620
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-16 19:14:57.879238
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
                                                      '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
                                                      '01:02:03.000400'

# Generated at 2022-06-16 19:15:07.974320
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-16 19:15:15.815476
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:15:25.195336
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )

# Generated at 2022-06-16 19:15:35.504790
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
        milliseconds=10)
    assert timed

# Generated at 2022-06-16 19:15:44.877003
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:15:57.898264
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timed

# Generated at 2022-06-16 19:16:11.078460
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:16:22.059418
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:16:35.889283
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'


# Generated at 2022-06-16 19:16:48.571282
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
                                                      '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
                                                      '01:02:03.400000'

# Generated at 2022-06-16 19:17:00.095460
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )

# Generated at 2022-06-16 19:17:07.053739
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.1234567') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.12345678') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

# Generated at 2022-06-16 19:17:17.543782
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )

# Generated at 2022-06-16 19:17:28.278747
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'



# Generated at 2022-06-16 19:17:38.438470
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
           '01:02:03.400000'

# Generated at 2022-06-16 19:17:48.919169
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-16 19:18:00.573785
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'


# Generated at 2022-06-16 19:18:07.912703
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:18:35.541694
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1)) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=10)) == '01:01:01.000010'
    assert timedelta

# Generated at 2022-06-16 19:18:46.457958
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                            '01:01:00.000000'

# Generated at 2022-06-16 19:18:57.159803
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:19:07.997857
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:19:20.997123
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:19:32.575372
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000)) == '00:00:01.000000'
    assert timedelta_format

# Generated at 2022-06-16 19:19:42.825931
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:19:55.343031
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
                                                      '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
                                                      '01:02:03.400000'

# Generated at 2022-06-16 19:20:02.443147
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-16 19:20:12.507520
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:21:17.307622
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:21:28.756199
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'

# Generated at 2022-06-16 19:21:40.231152
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
                                                      '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
                                                      '01:02:03.000400'

# Generated at 2022-06-16 19:21:52.549282
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
           '01:02:03.400000'

# Generated at 2022-06-16 19:22:04.408095
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3)) == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=456789)) == '01:02:03.456789'
   

# Generated at 2022-06-16 19:22:11.142282
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'

# Generated at 2022-06-16 19:22:21.501312
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'



# Generated at 2022-06-16 19:22:33.533384
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) == \
                                                      '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                                      '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                      '01:00:00.000000'

# Generated at 2022-06-16 19:22:45.909347
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
           '01:02:03.400000'

# Generated at 2022-06-16 19:22:55.548526
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )