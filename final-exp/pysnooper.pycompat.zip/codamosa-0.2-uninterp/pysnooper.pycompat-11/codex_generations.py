

# Generated at 2022-06-16 19:14:54.713996
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                                            '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) == \
                                                            '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                            '01:02:03.000004'

# Generated at 2022-06-16 19:15:05.321214
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:15:15.839417
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
                                                      '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
                                                      '01:02:03.000400'

# Generated at 2022-06-16 19:15:25.224369
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3)) == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=40000)) == '01:02:03.040000'
    assert timed

# Generated at 2022-06-16 19:15:35.540071
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:15:44.955151
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:15:58.000376
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
                                                      '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
                                                      '01:02:03.000400'

# Generated at 2022-06-16 19:16:11.170930
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
                                                      '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
                                                      '01:02:03.000400'

# Generated at 2022-06-16 19:16:22.060897
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:16:33.523077
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
           '01:02:03.400000'

# Generated at 2022-06-16 19:16:52.056204
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:17:01.850926
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:17:07.433952
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                            '01:01:00.000000'

# Generated at 2022-06-16 19:17:17.773093
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:17:29.032454
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40)) == \
           '01:02:03.000040'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400)) == \
           '01:02:03.000400'

# Generated at 2022-06-16 19:17:38.524525
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:17:43.605339
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:17:54.079598
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
                                                      '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400000)) == \
                                                      '01:02:03.400000'

# Generated at 2022-06-16 19:18:01.932484
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:18:14.726970
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('1:2:3.400000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_parse('1:2:3.4000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_parse('1:2:3.400000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_

# Generated at 2022-06-16 19:18:33.040955
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:18:44.659788
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:18:50.076038
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                               '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                               '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                               '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                               '00:00:00.000001'

# Generated at 2022-06-16 19:19:01.170246
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-16 19:19:09.813990
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:19:21.991347
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:19:33.550552
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:19:44.014278
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
           '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1,
                                                      microseconds=1)) == \
           '00:01:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'

# Generated at 2022-06-16 19:19:56.059764
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-16 19:20:07.177004
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'



# Generated at 2022-06-16 19:20:52.724869
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:21:04.514787
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:21:16.147954
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:21:28.262134
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-16 19:21:39.765567
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-16 19:21:46.896563
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                            '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                            '00:00:00.000001'

# Generated at 2022-06-16 19:21:50.635223
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1)) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=123456)) == '01:01:01.123456'
    assert timed

# Generated at 2022-06-16 19:22:03.215929
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
                                                            '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=10)) == \
                                                            '00:00:01.000010'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=100)) == \
                                                            '00:00:01.000100'

# Generated at 2022-06-16 19:22:10.593872
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                              '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                              '01:01:00.000000'

# Generated at 2022-06-16 19:22:21.745343
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )

# Generated at 2022-06-16 19:24:38.425377
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )