

# Generated at 2022-06-22 18:12:24.140247
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)

    assert timedelta_parse('-0000:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('-0000:00:00.000001') == datetime_

# Generated at 2022-06-22 18:12:27.764257
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=12, minutes=22, seconds=33,
                                  microseconds=123456)
    ) == '12:22:33.123456'


# Generated at 2022-06-22 18:12:32.485321
# Unit test for function timedelta_format
def test_timedelta_format():
    '''Test that `timedelta_format` and `timedelta_parse` are inverses.'''
    import random
    for i in range(4):
        comma = random.randint(0, 1000000)
        delta = datetime_module.timedelta(microseconds=comma)
        assert timedelta_parse(timedelta_format(delta)) == delta

# Generated at 2022-06-22 18:12:39.291751
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:12:46.936023
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta_str, timedelta in (
        ('00:00:00.000', datetime_module.timedelta()),
        ('01:02:03.123456', datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)),
        ('01:02:03.123456789', datetime_module.timedelta(hours=1, minutes=2,
                                                         seconds=3,
                                                         microseconds=123456))
    ):
        assert timedelta == timedelta_parse(timedelta_str)
        assert timedelta_str == timedelta_format(timedelta)

# Generated at 2022-06-22 18:12:54.593813
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:13:01.298472
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=15)) == \
                                                          '00:15:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=15,
                                                       minutes=15)) == \
                                                          '15:15:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=15,
                                                       microseconds=5)) == \
                                                          '00:15:00.000005'


# Generated at 2022-06-22 18:13:11.291531
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3)) == \
                                '05:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3,
                                                      seconds=71)) == \
                                '05:03:71.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3,
                                                      seconds=71,
                                                      microseconds=200001)) == \
                                '05:03:71.200001'



# Generated at 2022-06-22 18:13:22.006326
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 9)) == '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 99)) == '00:00:00.000099'

# Generated at 2022-06-22 18:13:27.891395
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.004005') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4005)

    assert timedelta_parse('0:0:1.2') == datetime_module.timedelta(
        seconds=1, microseconds=2 * 100000)

# Generated at 2022-06-22 18:13:37.580625
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)

    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta()
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta

# Generated at 2022-06-22 18:13:49.224041
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 0)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0.1)) == '00:00:00.100000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'



# Generated at 2022-06-22 18:13:54.714136
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=3, seconds=5, microseconds=1
    )) == '01:03:05.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=3, seconds=5, microseconds=1
    )) == time_isoformat(
        datetime_module.time(hour=1, minute=3, second=5, microsecond=1)
    )


# Generated at 2022-06-22 18:14:04.847231
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123456000')

# Generated at 2022-06-22 18:14:13.293023
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:10.123456')) == '00:00:10.123456'
    assert timedelta_parse('0:00:10.123456').seconds == 10
    assert timedelta_parse('0:00:10.123456').microseconds == 123456


if PY3:
    def isidentifier(name):
        return name.isidentifier()
    def raise_from(exception, cause):
        return exception.with_traceback(cause.__traceback__)
else:
    def isidentifier(name):
        import keyword
        return name.isidentifier() and name not in keyword.kwlist
    def raise_from(exception, cause):
        raise exception

# Generated at 2022-06-22 18:14:22.409065
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:30:12.456') == datetime_module.timedelta(hours=2,
                                                                       minutes=30,
                                                                       seconds=12,
                                                                       microseconds=456000)
    
    
if PY2:
    string_types += (text_type,)  # noqa


if PY3:
    def is_string(x):
        return isinstance(x, str)
else:
    def is_string(x):
        return isinstance(x, (str, unicode))  # noqa

# Generated at 2022-06-22 18:14:26.475094
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == (
        '01:02:03.456789'
    )



# Generated at 2022-06-22 18:14:32.904614
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.1')) == '00:00:00.001000'
    assert timedelta_format(timedelta_parse('1:1:1.1')) == '01:01:01.001000'
    assert timedelta_format(timedelta_parse('12:2:2.123456789')) == '12:02:02.123456'
    assert timedelta_parse('0:0:0').total_seconds() == 0
    assert timedelta_parse('1:1:1').total_seconds() == 3661
    assert timedelta_parse('2:2:2').total_seconds() == 7322

# Generated at 2022-06-22 18:14:42.410082
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('5:5:5.001234') == datetime_module.timedelta(
        hours=5,
        minutes=5,
        seconds=5,
        microseconds=1234
    )
    assert timedelta_parse('56:56:56.123456') == datetime_module.timedelta(
        days=2,
        hours=4,
        minutes=56,
        seconds=56,
        microseconds=123456
    )
    assert timedelta_parse('0:0:0.000321') == datetime_module.timedelta(
        microseconds=321
    )

# Generated at 2022-06-22 18:14:47.101675
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
           '01:01:01.000001'



# Generated at 2022-06-22 18:14:57.197086
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-22 18:15:05.056961
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=99)) == \
           '99:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=99,
                                                      microseconds=13)) == \
           '01:39:00.000013'
    assert timedelta_format(datetime_module.timedelta(hours=99, minutes=99,
                                                      seconds=99,
                                                      microseconds=99)) == \
           '99:99:99.000099'



# Generated at 2022-06-22 18:15:10.071607
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(microseconds=100000)
    assert timedelta_format(timedelta) == '00:00:00.100000'



# Generated at 2022-06-22 18:15:22.304859
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.0000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.123456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:2:3.999999999') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=999999
    )



# Generated at 2022-06-22 18:15:29.000799
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      seconds=0)) == \
           '11:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      seconds=11)) == \
           '00:00:11.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      seconds=1,
                                                      microseconds=10)) == \
           '00:00:01.000010'

# Generated at 2022-06-22 18:15:35.072480
# Unit test for function timedelta_format
def test_timedelta_format():
    def check(timedelta, expected):
        assert timedelta_format(timedelta) == expected
    check(datetime_module.timedelta(days=1, hours=11, minutes=22,
                                    seconds=33, microseconds=444000),
          '11:22:33.444000')
    check(datetime_module.timedelta(days=1, hours=11, minutes=22,
                                    seconds=33, microseconds=444444),
          '11:22:33.444444')
    check(datetime_module.timedelta(days=0, hours=0, minutes=0, seconds=1,
                                    microseconds=0),
          '00:00:01.000000')



# Generated at 2022-06-22 18:15:38.950532
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=15, minutes=4,
                                          seconds=12, microseconds=325)
    assert timedelta_format(timedelta) == '15:04:12.000325'



# Generated at 2022-06-22 18:15:45.909637
# Unit test for function timedelta_format
def test_timedelta_format():
    from nose.tools import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(microseconds=1)),
                 '00:00:00.000001')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
                 '00:00:01.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=1)),
                 '00:01:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(hours=1)),
                 '01:00:00.000000')

# Generated at 2022-06-22 18:15:52.114409
# Unit test for function timedelta_format
def test_timedelta_format():
    '''Unit test for function `timedelta_format`.'''
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=1
    )) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=1, microseconds=0
    )) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=1, seconds=0, microseconds=0
    ))

# Generated at 2022-06-22 18:15:54.972137
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if sys.version_info[:2] == (3, 6):
        from pytest import skip
        skip("Cannot run on Python 3.6: that version's timedelta doesn't "
             "support microseconds")
    from datetime import timedelta
    assert timedelta_parse('3:04:05.123') == timedelta(hours=3, minutes=4,
                                                       seconds=5,
                                                       microseconds=123)



# Generated at 2022-06-22 18:16:05.225630
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=5, minutes=3, seconds=2, microseconds=123456
    )
    assert timedelta_format(timedelta) == '05:03:02.123456'
    timedelta = datetime_module.timedelta(
        hours=72, minutes=7, seconds=2, microseconds=123456
    )
    assert timedelta_format(timedelta) == '72:07:02.123456'
    timedelta = datetime_module.timedelta(
        hours=3, minutes=3, seconds=2, microseconds=123
    )
    assert timedelta_format(timedelta) == '03:03:02.000123'



# Generated at 2022-06-22 18:16:11.551681
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.max) == \
                                                '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
                                            '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
                                            '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=11)) == \
                                            '00:00:11.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=12))

# Generated at 2022-06-22 18:16:22.007341
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('') == datetime_module.timedelta(0)
    assert timedelta_parse('1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(':1') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('::1') == datetime_module.timedelta(hours=1)
    assert timedelta_parse(':::1') == \
                             datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('-1') == datetime_module.timedelta(seconds=-1)
    assert timedelta_parse('-:1') == datetime_module.timedelta(minutes=-1)
    assert timedelta_parse('-::1') == datetime_module.timed

# Generated at 2022-06-22 18:16:32.989015
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(1, 2 * 60 + 3)
    assert timedelta_parse('1:2:3.4') == (
        datetime_module.timedelta(seconds=3, microseconds=40000)
      + datetime_module.timedelta(minutes=2, hours=1)
    )
    assert timedelta_parse('1:2:3.4:5') == (
        datetime_module.timedelta(microseconds=5000)
      + datetime_module.timedelta(seconds=3, microseconds=40000)
      + datetime_module.timedelta(minutes=2, hours=1)
    )

# Generated at 2022-06-22 18:16:42.176543
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00:000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('10:00:00.000001') == datetime_module.timedelta(microseconds=100000001, hours=10)
    assert timedelta_parse('0:10:00.000001') == datetime_module.timedelta(microseconds=100001, minutes=10)

# Generated at 2022-06-22 18:16:45.094805
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=12, minutes=23, seconds=34,
                                          microseconds=56789)
    assert timedelta_format(timedelta) == '12:23:34.56789'


# Generated at 2022-06-22 18:16:48.748531
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=15, minutes=27, seconds=18,
                                          microseconds=234)
    assert timedelta_format(timedelta) == '15:27:18.000234'



# Generated at 2022-06-22 18:17:00.175591
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0') == datetime_module.timedelta()
    assert timedelta_parse('3:4') == datetime_module.timedelta(minutes=3,
                                                               seconds=4)
    assert timedelta_parse('3:4:5') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5
    )
    assert timedelta_parse('3:4:5.678999') == datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=678999
    )

# Generated at 2022-06-22 18:17:07.811519
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      microseconds=2)) == \
           '01:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=3)) == \
           '00:00:02.000003'
    assert timedelta_format(datetime_module.timedelta(seconds=20,
                                                      microseconds=3)) == \
           '00:00:20.000003'
    assert timedelta_format(datetime_module.timedelta(seconds=70,
                                                      microseconds=3)) == \
           '00:01:10.000003'

# Generated at 2022-06-22 18:17:18.303351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=4, minutes=8, seconds=23, microseconds=67890
    ))) == datetime_module.timedelta(
        hours=4, minutes=8, seconds=23, microseconds=67890)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    ))) == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)

# Generated at 2022-06-22 18:17:27.463377
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = (datetime_module.datetime.min + datetime_module.timedelta(
        hours=5, minutes=7, seconds=13, microseconds=777777)
    ).time()
    assert timedelta_parse(time_isoformat(td)) == datetime_module.timedelta(
        hours=5, minutes=7, seconds=13, microseconds=777777
    )

# Generated at 2022-06-22 18:17:30.785267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    t = timedelta_parse('12:03:04.056789')
    assert t == datetime_module.timedelta(hours=12, minutes=3, seconds=4,
                                          microseconds=56789)


# Generated at 2022-06-22 18:17:38.436270
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_string = timedelta_format
    for timedelta in [datetime_module.timedelta(seconds=.123456789),
                      datetime_module.timedelta(seconds=-.123456789),
                      datetime_module.timedelta(seconds=1.123456789),
                      datetime_module.timedelta(seconds=-1.123456789),
                      datetime_module.timedelta(seconds=60),
                      datetime_module.timedelta(seconds=-60),
                      datetime_module.timedelta(seconds=3600),
                      datetime_module.timedelta(seconds=-3600),
                      ]:
        assert timedelta == timedelta_parse(timedelta_string(timedelta))


# Generated at 2022-06-22 18:17:47.044907
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == \
           '00:00:00.010000'

# Generated at 2022-06-22 18:17:54.938928
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00:000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(
        seconds=0, microseconds=123456
    )
    assert timedelta_parse('0:00:07.123456') == datetime_module.timedelta(
        seconds=7, microseconds=123456
    )



# Generated at 2022-06-22 18:18:01.581391
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
                                                                  '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
                                                                  '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 9)) == \
                                                                  '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == \
                                                                  '00:00:00.000010'

    assert timedelta_format(datetime_module.timedelta(0, 0, 54)) == \
                                                                  '00:00:00.000054'


# Generated at 2022-06-22 18:18:05.023506
# Unit test for function timedelta_parse
def test_timedelta_parse():
    delta = timedelta_parse('01:00:01.123456')
    assert delta == datetime_module.timedelta(hours=1, seconds=1,
                                              microseconds=123456)

# Generated at 2022-06-22 18:18:09.841488
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:15.123456') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=15, microseconds=123456
    )
    assert timedelta_parse(
        time_isoformat(
            datetime_module.time(hour=1, minute=0, second=15, microsecond=123456)
        ),
    ) == datetime_module.timedelta(
        hours=1, minutes=0, seconds=15, microseconds=123456
    )



# Generated at 2022-06-22 18:18:21.559617
# Unit test for function timedelta_format
def test_timedelta_format():
    test_cases = (
        datetime_module.timedelta(0),
        datetime_module.timedelta(5),
        datetime_module.timedelta(0, 7),
        datetime_module.timedelta(0, 0, 5),
        datetime_module.timedelta(0, 0, 0, 6),
        datetime_module.timedelta(days=5, seconds=7, microseconds=5),
        datetime_module.timedelta(days=-5, seconds=-7, microseconds=-5),
        datetime_module.timedelta(days=5, hours=4, minutes=3, seconds=2,
                                  microseconds=1),
        datetime_module.timedelta(microseconds=999999),
    )


# Generated at 2022-06-22 18:18:28.039040
# Unit test for function timedelta_format
def test_timedelta_format():
    for time_delta in [
        datetime_module.timedelta(0),
        datetime_module.timedelta(1, 2, 3, 4),
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4),
    ]:
        assert timedelta_parse(timedelta_format(time_delta)) == time_delta
        assert timedelta_format(timedelta_parse(timedelta_format(time_delta))) == \
               timedelta_format(time_delta)

# Generated at 2022-06-22 18:18:39.428086
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=0
    )
    assert timedelta_parse('01:00:00.123456') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=123456
    )
    assert timedelta_parse('01:00:00') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=0
    )
    assert timedelta_parse('60:00:00') == datetime_module.timedelta(
        days=2, hours=12
    )

# Generated at 2022-06-22 18:18:52.108868
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=3660)) == \
                                        '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=3660)) == \
                                        '00:00:03.660000'
    roundtrip_timedeltas = (
        datetime_module.timedelta(seconds=10**i)
        for i in range(7)
    )
    for timedelta in roundtrip_timedeltas:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-22 18:19:02.085908
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-22 18:19:14.438480
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=400000)
    assert timedelta_format(timedelta) == '01:02:03.400000'

    timedelta = datetime_module.timedelta(hours=10, minutes=20,
                                          seconds=30, microseconds=400000)
    assert timedelta_format(timedelta) == '10:20:30.400000'

    timedelta = datetime_module.timedelta(minutes=2, seconds=3,
                                          microseconds=400000)
    assert timedelta_format(timedelta) == '00:02:03.400000'

    timedelta = datetime_module.timedelta(seconds=3, microseconds=400000)
   

# Generated at 2022-06-22 18:19:17.639822
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=12, microseconds=54321)
    assert timedelta_format(timedelta) == '02:03:12.054321'



# Generated at 2022-06-22 18:19:24.816850
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                            '01:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                            '01:02:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=23)) == \
                                            '01:00:23.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1, microseconds=456789)) == \
                                            '01:00:00.456789'


# Generated at 2022-06-22 18:19:35.632168
# Unit test for function timedelta_format
def test_timedelta_format():
    '''Test our `timedelta_format` function.'''
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                            '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=45, minutes=34,
                                                      seconds=23,
                                                      microseconds=1234)) == \
                            '45:34:23.001234'

# Generated at 2022-06-22 18:19:42.967445
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=2))) == datetime_module.timedelta(minutes=2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=3))) == datetime_module.timedelta(seconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(milliseconds=4))) == datetime_module.timedelta(milliseconds=4)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=5))) == dat

# Generated at 2022-06-22 18:19:46.385672
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta.max)) == \
           datetime_module.timedelta.max



# Generated at 2022-06-22 18:19:56.926432
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == dat

# Generated at 2022-06-22 18:20:02.448560
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)

# Generated at 2022-06-22 18:20:13.581630
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for string in (
        '00:00:00.000000',
        '01:00:00.000000',
        '00:01:00.000000',
        '00:00:01.000000',
        '00:00:00.000001',
        '01:00:00.000001',
        '00:01:00.000001',
        '00:00:01.000001',
        '01:01:01.000001',
    ):
        assert timedelta_parse(timedelta_format(timedelta_parse(string))) == (
            timedelta_parse(string)
        )

# Generated at 2022-06-22 18:20:23.281644
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:30:45.123456') == \
               datetime_module.timedelta(hours=1, minutes=30, seconds=45,
                                      microseconds=123456)
    assert timedelta_parse('0:0:5.5') == \
               datetime_module.timedelta(seconds=5, microseconds=500000)
    assert timedelta_parse('0:0:0.6') == \
               datetime_module.timedelta(microseconds=600000)

test_timedelta_parse()

# Generated at 2022-06-22 18:20:31.809534
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 1)) == '00:00:00.000001'


# Generated at 2022-06-22 18:20:43.605278
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40000)) == \
           '01:02:03.040000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=0)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=1)) == \
           '00:00:00.000001'


# Generated at 2022-06-22 18:20:53.412833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(0, 0, 999999)
    assert timedelta_parse('0:0:1.999999') == datetime_module.timedelta(0, 1, 999999)

# Generated at 2022-06-22 18:21:05.599020
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(days=365),
                      datetime_module.timedelta(hours=8),
                      datetime_module.timedelta(minutes=8),
                      datetime_module.timedelta(seconds=8),
                      datetime_module.timedelta(milliseconds=8),
                      datetime_module.timedelta(microseconds=8),
                      datetime_module.timedelta(0),
                     ):
        timedelta_str = timedelta_format(timedelta)
        assert isinstance(timedelta_str, str)
        assert timedelta == timedelta_parse(timedelta_str)

test_timedelta_format()
del test_timedelta_format

# Generated at 2022-06-22 18:21:12.243424
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=24, minutes=3,
                                                      seconds=2,
                                                      microseconds=123456)) \
                                                      == '24:03:02.123456'



# Generated at 2022-06-22 18:21:15.528683
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import case_time_delta
    for timedelta in case_time_delta:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-22 18:21:28.343183
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(1, 0)
    assert timedelta_parse('1:00:01.000000') == datetime_module.timedelta(1, 1)
    assert timedelta_parse('1:01:00.000000') == datetime_module.timedelta(1, 60)

# Generated at 2022-06-22 18:21:37.902534
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if PY2: # Python 2 can't parse sub-second timedeltas
        return

# Generated at 2022-06-22 18:21:50.140364
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def test(timedelta, s):
        assert timedelta_format(timedelta) == s
        assert timedelta_parse(s) == timedelta

    test(datetime_module.timedelta(0), '00:00:00.000000')
    test(datetime_module.timedelta(microseconds=1), '00:00:00.000001')
    test(datetime_module.timedelta(microseconds=10), '00:00:00.000010')
    test(datetime_module.timedelta(microseconds=100), '00:00:00.000100')
    test(datetime_module.timedelta(microseconds=1000), '00:00:00.001000')

# Generated at 2022-06-22 18:21:58.247257
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=456000)) \
                                                      == '02:03:04.456000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=456000)) \
                                                      == '00:00:00.456000'



# Generated at 2022-06-22 18:22:02.478394
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ) == '01:02:03.456789'



# Generated at 2022-06-22 18:22:08.886737
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=2)) == \
                               '00:00:01.000002'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=2, microseconds=3)) == \
                               '01:00:02.000003'
    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(hours=1, seconds=2, microseconds=3),
                         timespec='hours')


# Generated at 2022-06-22 18:22:16.854558
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=4)) == '00:00:01.000004'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=49)) == '00:00:01.000049'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=493)) == '00:00:01.000493'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=4939)) == '00:00:01.004939'

# Generated at 2022-06-22 18:22:27.882107
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                          seconds=5, microseconds=6)
    s = timedelta_format(timedelta)
    assert s == '03:04:05.000006'
    assert timedelta_parse(s) == timedelta
    timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                          seconds=5, microseconds=6006)
    s = timedelta_format(timedelta)
    assert s == '03:04:05.006006'
    assert timedelta_parse(s) == timedelta