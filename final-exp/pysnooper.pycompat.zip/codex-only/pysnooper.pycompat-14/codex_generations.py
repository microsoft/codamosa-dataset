

# Generated at 2022-06-22 18:12:24.140257
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=14,
                                                       microseconds=10)) == \
           '00:00:14.000010'
    assert timedelta_format(datetime_module.timedelta(minutes=5, seconds=3,
                                                       microseconds=9)) == \
           '00:05:03.000009'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                       seconds=3,
                                                       microseconds=9)) == \
           '04:05:03.000009'

# Generated at 2022-06-22 18:12:35.814526
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'


# Generated at 2022-06-22 18:12:46.476507
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123000
    )
    assert timedelta_parse('01:02:03.1') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100000
    )
    assert timedelta_parse('01:02:03.12') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=120000
    )
    assert timedelta_parse

# Generated at 2022-06-22 18:12:54.454664
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == (
        '00:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )

# Generated at 2022-06-22 18:12:58.220929
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        seconds=86400 - 1, microseconds=999999
    )

# Generated at 2022-06-22 18:13:06.984734
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_equals(s, timedelta):
        assert timedelta == timedelta_parse(s)
        assert s == timedelta_format(timedelta)

    assert_equals('00:00:00.000000', datetime_module.timedelta(0))
    assert_equals('00:00:01.000000', datetime_module.timedelta(seconds=1))
    assert_equals('01:00:01.000000', datetime_module.timedelta(hours=1,
                                                               seconds=1))
    assert_equals('01:01:01.000000', datetime_module.timedelta(hours=1,
                                                               minutes=1,
                                                               seconds=1))

# Generated at 2022-06-22 18:13:11.291391
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                             microseconds=131415))) == (
        datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                  microseconds=131415))



# Generated at 2022-06-22 18:13:15.294512
# Unit test for function timedelta_format
def test_timedelta_format():
    import random
    for _ in range(1000):
        hours = random.randint(0, 10 ** 20)
        timedelta = datetime_module.timedelta(hours=hours)
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-22 18:13:18.360443
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, seconds=2)
    assert timedelta_format(timedelta) == '86400:00:00.000000'

# Generated at 2022-06-22 18:13:26.691846
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )) == '01:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(
        seconds=86400, microseconds=  10000
    )) == '24:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(
        seconds=86400, microseconds=900000
    )) == '24:00:00.900000'

test_timedelta_parse()



if sys.version_info[:2] >= (3, 7):
    from datetime import timezone
else:
    from dateutil import tz as dateutil_tz


# Generated at 2022-06-22 18:13:36.710244
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000004') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4))
    assert timedelta_parse('1:2:3.4') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000))
    assert timedelta_parse('1:2:3') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3))
    assert timedelta_parse('1:2') == (
        datetime_module.timedelta(hours=1, minutes=2))
    assert timedelta_parse('1') == (
        datetime_module.timedelta(hours=1))


# Generated at 2022-06-22 18:13:39.730171
# Unit test for function timedelta_format
def test_timedelta_format():
    def timelike_foo():
        timedelta_format(datetime_module.timedelta(3, 666))
    def time_foo():
        time_isoformat(datetime_module.time(3, 10, 6, 666))
    assert timelike_foo() == time_foo()

# Generated at 2022-06-22 18:13:51.147690
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000)

    assert timedelta_parse('1:2:3.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1)

    assert timedelta_parse('1:2:3.000010') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=10)

    assert timedelta_parse('1:2:3.000100') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100)


# Generated at 2022-06-22 18:13:58.758534
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4:5:6') == \
           datetime_module.timedelta(seconds=123, microseconds=456)
    assert timedelta_parse('1.2') == \
           datetime_module.timedelta(seconds=1, microseconds=200000)
    assert timedelta_parse('1:2:3') == \
           datetime_module.timedelta(seconds=123)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta(seconds=0)

# Generated at 2022-06-22 18:14:04.642600
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
           == '1:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
           == '1:02:03.123456'


# Generated at 2022-06-22 18:14:07.401638
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=8,
                                                      microseconds=123456)) ==\
           '08:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(hours=8, minutes=30,
                                                      seconds=2,
                                                      microseconds=123456)) ==\
           '08:30:02.123456'



# Generated at 2022-06-22 18:14:12.105893
# Unit test for function timedelta_format
def test_timedelta_format():
    for useconds in range(1000000):
        timedelta = datetime_module.timedelta(microseconds=useconds)
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta
        assert timedelta_format(timedelta_parse(timedelta_format(timedelta))) == \
                                                            timedelta_format(timedelta)



# Generated at 2022-06-22 18:14:18.084015
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, seconds=2, microseconds=36)
    )) == datetime_module.timedelta(hours=1, seconds=2,
                                    microseconds=36)





###############################################################################
# ############################## Exceptions ###################################
###############################################################################

if PY3:
    PermissionError = PermissionError
else:
    PermissionError = IOError


###############################################################################
# ############################ String handling ################################
###############################################################################
if PY3:
    from functools import reduce
    from .stdlib_patch.os import fsdecode, fsencode
else:
    from .stdlib_patch.os import fsdecode, fsencode

# Generated at 2022-06-22 18:14:27.803667
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.2)) == '00:00:01.200000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=2)) == '01:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=0.2)) == '00:02:00.200000'
    assert timedelta_format(datetime_module.timedelta(minutes=2, microseconds=1)) == '00:02:00.000001'


# Generated at 2022-06-22 18:14:39.110321
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('5:00:00.000000') == (5 * 60 * 60)
    assert timedelta_parse('0:00:42.000000') == 42
    assert timedelta_parse('0:00:00.123456') == 123456 / 1000000
    assert timedelta_parse('0:00:00.1234567') == 123456 / 100000
    assert timedelta_parse('0:00:00.12345678') == 123456 / 10000
    assert timedelta_parse('0:00:00.123456789') == 123456 / 1000
    assert timedelta_parse('0:00:00.1234567890') == 123456 / 100
    assert timedelta_parse('0:00:00.12345678901') == 123456 / 10

# Generated at 2022-06-22 18:14:46.090233
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('-0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('-00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('-23:59:59.999999') == datetime_module.timedelta(
        days=-1, hours=23, minutes=59, seconds=59, microseconds=999999
    )
    
    

# Generated at 2022-06-22 18:14:50.467587
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
        '01:02:03.000004'



# Generated at 2022-06-22 18:14:54.322472
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=27, minutes=25,
                                          seconds=36, microseconds=321234)
    assert timedelta_format(timedelta) == '27:25:36.321234'



# Generated at 2022-06-22 18:15:05.013476
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '1:2:3.4'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '-1:2:3.4'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3.400000'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3.400001'
    assert timedelta_format(timedelta_parse(s)) == s
    s = '1:2:3.0'
    assert timedelta_format(timedelta_parse(s)) == s

# Generated at 2022-06-22 18:15:11.594648
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.045068') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=45068
    )
    assert timedelta_parse('-1:2:3.045068') == datetime_module.timedelta(
        days=-1, hours=20, minutes=59, seconds=56, microseconds=54932
    )
    assert timedelta_parse('-1:2:3') == datetime_module.timedelta(
        days=-1, hours=20, minutes=59, seconds=57
    )

# Generated at 2022-06-22 18:15:23.731859
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1e-9)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1, 1e-6)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(1, 1e-5)) == \
           '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(1, 1e-4)) == \
           '00:00:00.010000'

# Generated at 2022-06-22 18:15:28.546486
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelt

# Generated at 2022-06-22 18:15:38.584942
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(hours=0)
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(hours=0)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(hours=0,
                                     microseconds=1)
    assert timedelta_parse('01:00:00') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:15:44.607047
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(
        seconds=0
    )
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('24:0:0.000000') == datetime_module.timedelta(
        days=1
    )

# Generated at 2022-06-22 18:15:53.263832
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=1
    )
    assert timedelta_parse('01:00:01.010000') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=1, microseconds=10000
    )
    assert timedelta_parse('01:00:01.012345') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=1, microseconds=12345
    )
    assert timedelta_parse('01:00:01.0123456789') == datetime_module.timedelta(
        hours=1, minutes=0, seconds=1, microseconds=12345
    )



# Generated at 2022-06-22 18:15:59.545396
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.100').total_seconds() == 3661.1


if PY3:
    import itertools as builtins
else:
    import __builtin__ as builtins

if sys.version_info[:2] >= (3, 4):
    from inspect import getfullargspec as getargspec
else:
    from inspect import getargspec

# Generated at 2022-06-22 18:16:08.420533
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(10))) == \
                                           datetime_module.timedelta(10)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1))) == \
                                           datetime_module.timedelta(1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 2, 1))) == \
                                           datetime_module.timedelta(0, 2, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 1))) == \
                                           datetime_module.timedelta(0, 0, 1)

# Generated at 2022-06-22 18:16:12.479674
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=5, seconds=5,
                                          microseconds=5)
    assert timedelta_format(timedelta) == '05:05:05.000005'


# Generated at 2022-06-22 18:16:21.051241
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=2, minutes=3))) == datetime_module.timedelta(hours=2, minutes=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3, hours=2, minutes=3))) == datetime_module.timedelta(days=3, hours=2, minutes=3)

# Generated at 2022-06-22 18:16:30.248647
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.456000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
        microseconds=456000
    )
    assert timedelta_parse('01:02:03.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
        microseconds=456000
    )
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3,
    )
    assert timedelta_parse('01:02') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=0,
    )

# Generated at 2022-06-22 18:16:40.365763
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=12,
                                                      minutes=34,
                                                      seconds=56,
                                                      microseconds=789))=='12:34:56.000789'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=34,
                                                      seconds=0,
                                                      microseconds=50))=='00:34:00.000050'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=34,
                                                      seconds=0,
                                                      microseconds=50000))=='00:34:00.050000'

# Generated at 2022-06-22 18:16:45.773095
# Unit test for function timedelta_format
def test_timedelta_format():
    if not sys.version_info[:2] >= (3, 6):
        return

# Generated at 2022-06-22 18:16:49.526790
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'



# Generated at 2022-06-22 18:16:55.241926
# Unit test for function timedelta_format
def test_timedelta_format():
    random_timedelta = datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=4
    )
    expected = '01:02:03.000004'
    actual = timedelta_format(random_timedelta)
    assert actual == expected


# Generated at 2022-06-22 18:17:04.618900
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_equivalent(a, b):
        assert a == b
        assert timedelta_parse(timedelta_format(a)) == a

    assert_equivalent(timedelta_parse('00:00:00.000000'),
                       datetime_module.timedelta(seconds=0))

    assert_equivalent(timedelta_parse('00:00:00.000001'),
                       datetime_module.timedelta(microseconds=1))

    assert_equivalent(timedelta_parse('00:00:01.000000'),
                       datetime_module.timedelta(seconds=1))

    assert_equivalent(timedelta_parse('00:00:01.000001'),
                       datetime_module.timedelta(seconds=1, microseconds=1))


# Generated at 2022-06-22 18:17:08.425202
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=9, minutes=12, seconds=40, microseconds=1234)
    )) == datetime_module.timedelta(hours=9, minutes=12, seconds=40, microseconds=1234)



# Generated at 2022-06-22 18:17:20.412811
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60, microseconds=1)) == '00:01:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timed

# Generated at 2022-06-22 18:17:24.859040
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(0, 0, 2, 3)
    assert timedelta_format(td) == '00:00:00.000002'


# Generated at 2022-06-22 18:17:31.576453
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0, seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(days=1, seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(days=1, seconds=0,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(days=0, seconds=1,
                                                      microseconds=0)) == \
                                                      '00:00:01.000000'


# Generated at 2022-06-22 18:17:44.811751
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:0:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.00000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()

# Generated at 2022-06-22 18:17:52.488741
# Unit test for function timedelta_format
def test_timedelta_format():
    d = datetime_module.datetime.min
    for i in range(100_000):
        timedelta = datetime_module.timedelta(microseconds=i)
        formatted_timedelta = timedelta_format(timedelta)
        time = (d + timedelta).time()
        formatted_time = time_isoformat(time, timespec='microseconds')
        assert formatted_time == formatted_timedelta


# Generated at 2022-06-22 18:18:00.794808
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=90)
    assert timedelta_format(timedelta) == '00:00:00.0'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta(days=1)
    assert timedelta_format(timedelta) == '00:00:00.0'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta(days=1, hours=1)
    assert timedelta_format(timedelta) == '01:00:00.0'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta

# Generated at 2022-06-22 18:18:08.979701
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000004') == timedelta_parse(
        '1:02:03.000000004'
    ) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=4)
    assert timedelta_parse('01:02:03') == timedelta_parse('1:02:03') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('00:02:03.004000005') == datetime_module.timedelta(
        minutes=2, seconds=3, microseconds=4000005
    )

# Generated at 2022-06-22 18:18:11.969751
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '5:5:5.54321'
    timedelta = timedelta_parse(s)
    assert s == timedelta_format(timedelta)



# Generated at 2022-06-22 18:18:17.614935
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

# Generated at 2022-06-22 18:18:21.358628
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1,
        seconds=86399,
        microseconds=999999,
    )



# Generated at 2022-06-22 18:18:26.679774
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1,
                                          minutes=2,
                                          seconds=3,
                                          microseconds=456789)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


if PY3:
    def int2byte(i):
        return bytes((i,))
else:
    int2byte = chr



# Generated at 2022-06-22 18:18:33.573846
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:1.111111') == \
                                   datetime_module.timedelta(seconds=1,
                                                             microseconds=111111)
    assert timedelta_parse('2:3:4.555666') == \
                                   datetime_module.timedelta(hours=2, minutes=3,
                                                             seconds=4,
                                                             microseconds=555666)



# Generated at 2022-06-22 18:18:43.132666
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:10:0') == datetime_module.timedelta(minutes=10)
    assert timedelta_parse('3:0:0') == datetime_module.timedelta(hours=3)
    assert timedelta_parse('0:0:10') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('0:0:10.0') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('0:0:10.0000') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('0:0:10.000000') == datetime_module.timedelta(seconds=10)


# Generated at 2022-06-22 18:18:54.323694
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.123456') == \
           datetime_module.timedelta(seconds=0, microseconds=123456)
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:0:0.000') == datetime_module.timedelta(0)

# Generated at 2022-06-22 18:18:57.500512
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:37:01.473219') == datetime_module.timedelta(
        hours=1, minutes=37, seconds=1, microseconds=473219
    )

# Generated at 2022-06-22 18:19:00.897666
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=7, seconds=3,
                                          microseconds=63)
    assert timedelta_format(timedelta) == '05:07:03.000063'



# Generated at 2022-06-22 18:19:13.490060
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('1:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('01:2:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('01:02:3.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timed

# Generated at 2022-06-22 18:19:20.188619
# Unit test for function timedelta_parse
def test_timedelta_parse():
    cases = [
        (datetime_module.timedelta(seconds=1.23), '00:00:01.230000'),
        (datetime_module.timedelta(hours=1.23), '01:13:48.000000'),
        (datetime_module.timedelta(hours=1.234567), '01:13:42.781200'),
        (datetime_module.timedelta(days=1.234567), '29:06:26.956560')
    ]
    for timedelta, s in cases:
        assert timedelta_parse(s) == timedelta

test_timedelta_parse()

# Generated at 2022-06-22 18:19:32.169663
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
            '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2, seconds=3,
                                                      microseconds=786)) == \
            '01:02:03.000786'

# Generated at 2022-06-22 18:19:40.285938
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:19:52.406782
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1)
    assert timedelta_format(timedelta) == '01:00:00.000000'
    timedelta = datetime_module.timedelta(hours=1, minutes=1)
    assert timedelta_format(timedelta) == '01:01:00.000000'
    timedelta = datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_format(timedelta) == '01:01:01.000000'
    timedelta = datetime_module.timedelta(days=1)
    assert timedelta_format(timedelta) == '24:00:00.000000'
    timedelta = datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:19:55.512510
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:19:58.808620
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'



# Generated at 2022-06-22 18:20:07.279003
# Unit test for function timedelta_parse
def test_timedelta_parse():
    print('Testing function timedelta_parse')
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )

# Generated at 2022-06-22 18:20:12.445986
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('00:00:00.000000') ==
            datetime_module.timedelta(seconds=0))
    assert (timedelta_parse('01:00:00.000000') ==
            datetime_module.timedelta(hours=1))
    assert (timedelta_parse('01:00:00.100000') ==
            datetime_module.timedelta(hours=1, microseconds=100000))
    assert (timedelta_parse('01:02:00.100000') ==
            datetime_module.timedelta(hours=1, minutes=2, microseconds=100000))

# Generated at 2022-06-22 18:20:25.649665
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, milliseconds=1)) == '00:00:00.001000'

# Generated at 2022-06-22 18:20:36.538134
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('00:00:00.000000')
    timedelta_parse('01:02:03.000000')
    timedelta_parse('09:10:11.000234')
    timedelta_parse('10:11:12.000234')
    timedelta_parse('00:59:59.999999')
    timedelta_parse('24:00:00.000000')
    from pytest import raises
    with raises(ValueError):
        timedelta_parse('-00:00:00.000000')
    with raises(ValueError):
        timedelta_parse('01:02:03.000001')
    with raises(ValueError):
        timedelta_parse('01:02:03.0000001')
    with raises(ValueError):
        timedelta_parse('01:02:03.123456')

# Generated at 2022-06-22 18:20:43.745000
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('00:00:00.000000')
    assert timedelta == datetime_module.timedelta()
    timedelta = timedelta_parse('01:02:03.000000')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3)
    timedelta = timedelta_parse('01:02:03.000456')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3, microseconds=456)

# Generated at 2022-06-22 18:20:53.471895
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] == (3, 5):
        return # Known bug in Python 3.5

    cases = [
        timedelta_parse('00:00:00.000000'),
        timedelta_parse('12:34:56.789012'),
        timedelta_parse('23:59:59.999999'),
        timedelta_parse('-23:59:59.999998'),
    ]
    for case in cases:
        assert timedelta_parse(timedelta_format(case)) == case



# Generated at 2022-06-22 18:20:59.884759
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                       minutes=4,
                                                       seconds=5,
                                                       microseconds=6)) == (
        '03:04:05.000006'
    )



# Generated at 2022-06-22 18:21:08.812932
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=100)) == \
                                                      '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=0,
                                                      microseconds=1000000)) \
                                                      == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=0)) == \
                                                      '00:00:01.000000'

# Generated at 2022-06-22 18:21:19.282813
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(milliseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:01.000000') == dat

# Generated at 2022-06-22 18:21:28.865649
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('13:45:32.345678') == datetime_module.timedelta(hours=13, minutes=45,
                                                                           seconds=32,
                                                                           microseconds=345678)
    assert timedelta_parse('23:42:14.0349') == datetime_module.timedelta(hours=23, minutes=42,
                                                                           seconds=14,
                                                                           microseconds=349)
    assert timedelta_parse('00:01:32.000349') == datetime_module.timedelta(minutes=1,
                                                                           seconds=32,
                                                                           microseconds=349)

# Generated at 2022-06-22 18:21:39.282817
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23)) == '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=43)) == '00:43:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=12)) == '00:00:12.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(milliseconds=123)) == '00:00:00.123000'

# Generated at 2022-06-22 18:21:43.157033
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.456789') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789))

# Generated at 2022-06-22 18:21:52.895510
# Unit test for function timedelta_format
def test_timedelta_format():

    zero = datetime_module.timedelta(seconds=0)
    just_under_a_second = datetime_module.timedelta(microseconds=999999)
    one_second = datetime_module.timedelta(seconds=1)
    exactly_one_second = datetime_module.timedelta(seconds=1,
                                                   microseconds=0)
    just_over_one_second = datetime_module.timedelta(seconds=1,
                                                     microseconds=1)
    two_seconds = datetime_module.timedelta(seconds=2)


# Generated at 2022-06-22 18:22:02.066932
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01:000000'

    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2)) == \
           '00:00:02:000000'

    assert timedelta_format(datetime_module.timedelta(days=2, minutes=15,
                                                      seconds=19,
                                                      microseconds=12345)) == \
           '15:19:00:12345'


# Generated at 2022-06-22 18:22:10.735708
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                  microseconds=6)
    )) == datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                    microseconds=6)


# The `datetime` module that's part of Python 3.6+ doesn't contain this
# function:

# Generated at 2022-06-22 18:22:16.555814
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert datetime_module.timedelta(seconds=75) == timedelta_parse('0:1:15')
    assert datetime_module.timedelta(minutes=3, seconds=14,
                                     microseconds=500000) == timedelta_parse(
                                         '0:3:14.500000'
    )

# Generated at 2022-06-22 18:22:27.709636
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:10:000000') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:00:10.000000') == datetime_module.timedelta(seconds=10)
    assert timedelta_parse('00:00:10:123456') == datetime_module.timedelta(seconds=10, microseconds=123456)
    assert timedelta_parse('00:00:10.123456') == datetime_module.timedelta(seconds=10, microseconds=123456)
    assert timedelta_parse('00:00:10:123') == datetime_module.timedelta(seconds=10, microseconds=123000)