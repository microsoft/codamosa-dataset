

# Generated at 2022-06-22 18:12:21.519036
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=3210)

    formatted = timedelta_format(timedelta)

    assert formatted == '01:02:03.003210'



# Generated at 2022-06-22 18:12:26.119333
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for time in (
        datetime_module.time(),
        datetime_module.time(hour=5, minute=7, microsecond=10)
    ):
        assert time == (datetime_module.datetime.min +
                        timedelta_parse(time_isoformat(time))).time()

# Generated at 2022-06-22 18:12:35.328351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('0:0:0.312345') == datetime_module.timedelta(
        microseconds=312,
        milliseconds=345)
    assert timedelta_parse('0:2:1.000000') == datetime_module.timedelta(
        minutes=2, seconds=1)

# Generated at 2022-06-22 18:12:45.506302
# Unit test for function timedelta_parse
def test_timedelta_parse():

    import pytest

    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(microseconds=10**5)
    assert timedelta_parse('00:00:01.1') == datetime_module.timedelta(seconds=1, microseconds=10**5)
    assert timedelta_parse('01:10:01.1') == datetime_module.timedelta(hours=1, minutes=10, seconds=1, microseconds=10**5)

    with pytest.raises(AssertionError):
        timedelta_parse('00:00:00.1.2')

# Generated at 2022-06-22 18:12:54.080269
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('02:03:04.005678')) == (
        '02:03:04.005678'
    )



if hasattr(datetime_module.date, 'fromisoformat'):
    date_fromisoformat = datetime_module.date.fromisoformat
else:
    date_fromisoformat = datetime_module.datetime.strptime


if hasattr(datetime_module.time, 'fromisoformat'):
    time_fromisoformat = datetime_module.time.fromisoformat
else:
    time_fromisoformat = lambda s: datetime_module.datetime.strptime(
        s, '%H:%M:%S.%f').timetz()



# Generated at 2022-06-22 18:13:05.292805
# Unit test for function timedelta_parse
def test_timedelta_parse():
    examples = [
        ('00:00:00.000000', datetime_module.timedelta()),
        ('00:00:00.000001', datetime_module.timedelta(microseconds=1)),
        ('00:00:01.000000', datetime_module.timedelta(seconds=1)),
        ('00:01:00.000000', datetime_module.timedelta(minutes=1)),
        ('01:02:03.040510', datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40510)),
    ]
    for s, timedelta in examples:
        assert timedelta_parse(s) == timedelta



# Generated at 2022-06-22 18:13:15.186122
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.1') == \
           datetime_module.timedelta(seconds=1, microseconds=100000)
    assert timedelta_parse('00:00:01.100000') == \
           datetime_module.timedelta(seconds=1, microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.1000000') == \
           datetime_module.timedelta(seconds=1, microseconds=100000)

# Generated at 2022-06-22 18:13:24.524537
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_cases = [
        ('00:00:00.000000', 0),
        ('00:00:00:000000', 0),
        ('00:00:01.000000', 1),
        ('00:00:01:000000', 1),
        ('00:01:00.000000', 60),
        ('00:01:00:000000', 60),
        ('01:00:00.000000', 3600),
        ('01:00:00:000000', 3600),
        ('00:00:00.000001', 0.000001),
        ('00:00:00:000001', 0.000001),
    ]
    for string, expected_seconds in test_cases:
        assert timedelta_parse(string).total_seconds() == expected_seconds



# Generated at 2022-06-22 18:13:35.554987
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_pairs = [
        (datetime_module.timedelta(seconds=0), '00:00:00.000000'),
        (datetime_module.timedelta(seconds=1), '00:00:01.000000'),
        (datetime_module.timedelta(seconds=61), '00:01:01.000000'),
        (datetime_module.timedelta(seconds=3601), '01:00:01.000000'),
        (datetime_module.timedelta(seconds=36601), '10:10:01.000000'),
        (datetime_module.timedelta(microseconds=1),
         '00:00:00.000001'),
        (datetime_module.timedelta(microseconds=100),
         '00:00:00.000100'),
    ]

# Generated at 2022-06-22 18:13:38.685409
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=2,
                                                      microseconds=123)) \
           == '00:02:00.000123'



# Generated at 2022-06-22 18:13:50.149798
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_equal(a, b):
        assert a == b, '{} != {}'.format(a, b)


# Generated at 2022-06-22 18:14:00.816575
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=456789)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    assert timedelta_parse('01:02:03.456789') == timedelta
    assert timedelta_parse('1:02:03.456789') == timedelta
    assert timedelta_parse('01:2:03.456789') == timedelta
    assert timedelta_parse('1:2:03.456789') == timedelta
    assert timedelta_parse('01:02:3.456789') == timedelta
    assert timedelta_parse('1:02:3.456789') == timedelta

# Generated at 2022-06-22 18:14:09.122203
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:14:13.331001
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1337:0:0.001337') == datetime_module.timedelta(
        days=1337,
        milliseconds=1,
        microseconds=337
    )
    assert timedelta_parse('-1337:0:0.001337') == datetime_module.timedelta(
        days=-1337,
        milliseconds=-1,
        microseconds=-337
    )

# Generated at 2022-06-22 18:14:25.586608
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()), '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)), '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)), '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)), '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)), '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)), '00:00:00.000001'

# Generated at 2022-06-22 18:14:28.986469
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )) == '01:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(
        seconds=1, microseconds=2
    )) == '00:00:01.000002'



# Generated at 2022-06-22 18:14:35.653884
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(3, 4, 5, 6))
    assert time == '03:04:05.000006'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=4,
                                                      seconds=5,
                                                      microseconds=6)) == \
                                                                  '03:04:05.000006'



# Generated at 2022-06-22 18:14:44.263269
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                                               '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
                                                               '00:02:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=123456)
    ) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(microseconds=9)) == \
                                                           '00:00:00.000009'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == \
                                                           '00:00:00.001234'
   

# Generated at 2022-06-22 18:14:55.334186
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:11:32.123456') == \
                               datetime_module.timedelta(hours=1, minutes=11,
                                                        seconds=32,
                                                        microseconds=123456)


if sys.version_info[:2] >= (3, 6):
    datetime_module.datetime.fromisoformat = datetime_module.datetime.fromisoformat
else:
    def fromisoformat(dt_string):
        dt, microsecond_string = dt_string.split('.')
        dt = datetime_module.datetime.strptime(dt, '%Y-%m-%dT%H:%M:%S')
        microsecond = int(microsecond_string.ljust(6, '0')[:6])
        return dt

# Generated at 2022-06-22 18:15:05.891783
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )



# Generated at 2022-06-22 18:15:12.442518
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('1:01:00.000000') == datetime_module.timedelta(
        hours=1, minutes=1
    )
    assert timedelta_parse('100:00:00.000000') == datetime_module.timedelta(
        hours=100
    )

# Generated at 2022-06-22 18:15:21.729209
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == \
           datetime_module.timedelta(days=1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=1
    ))) == datetime_module.timedelta(seconds=1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=1
    ))) == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:15:25.523906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=5, minutes=37, seconds=14,
                                          microseconds=123456)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:15:36.664008
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-22 18:15:48.641714
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1,
    )
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:15:56.097077
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1, microseconds=1)) == '01:01:01.000001'

# Generated at 2022-06-22 18:16:06.502786
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:01.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('0:00:10.000000') == datetime_module.timedelta(seconds=10)

# Generated at 2022-06-22 18:16:11.793358
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_tools
    test_tools.assert_equivalent(
        timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                   seconds=3,
                                                   microseconds=4000)),
        '01:02:03.004000'
    )



# Generated at 2022-06-22 18:16:19.344956
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '01:02:03.123456'
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=12345)
    assert timedelta_format(timedelta) == '01:02:03.012345'

# Generated at 2022-06-22 18:16:25.574396
# Unit test for function timedelta_format
def test_timedelta_format():
    for delta in [3600, 60, 1, 0, 0.000001]:
        for timespec in [1, 1000000, 3600, 3600*60, 3600*60*24]:
            assert timedelta_parse(timedelta_format(
                datetime_module.timedelta(seconds=delta),
            )) == datetime_module.timedelta(seconds=delta)

# Generated at 2022-06-22 18:16:34.564718
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import make_sure

# Generated at 2022-06-22 18:16:40.366147
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.000400') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400)



# Generated at 2022-06-22 18:16:51.169833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.4')) == '01:02:03.000004'


if PY3:
    import contextlib
    @contextlib.contextmanager
    def reraise(exc_type=SystemExit, exc_value=None, traceback=None):
        try:
            yield
        except Exception as exc:
            raise exc

# Generated at 2022-06-22 18:17:01.783056
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
           '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-22 18:17:09.975629
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1, 0)) == '00:00:01'
    assert timedelta_format(datetime_module.timedelta(1)) == '1 day, 0:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '-1 day, 0:00:00.000000'


# Generated at 2022-06-22 18:17:17.050011
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3,
                                                                                    hours=4,
                                                                                    minutes=5,
                                                                                    seconds=6,
                                                                                    microseconds=7890))) == \
           datetime_module.timedelta(days=3,
                                                hours=4,
                                                minutes=5,
                                                seconds=6,
                                                microseconds=7890)

# Generated at 2022-06-22 18:17:23.722372
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=11, seconds=12, microseconds=131415
    ))) == datetime_module.timedelta(
        hours=1, minutes=11, seconds=12, microseconds=131415
    )

# Generated at 2022-06-22 18:17:33.878583
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
           '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=22, minutes=59, seconds=59, microseconds=999999
    )) == \
           '22:59:59.999999'

# Generated at 2022-06-22 18:17:36.230809
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )



# Generated at 2022-06-22 18:17:46.042837
# Unit test for function timedelta_format
def test_timedelta_format():
    def _assert_equal(timedelta, expected):
        assert timedelta_format(timedelta) == expected
    _assert_equal(datetime_module.timedelta(minutes=2, seconds=3,
                                            microseconds=123456),
                  '00:02:03.123456')
    _assert_equal(datetime_module.timedelta(hours=5, minutes=10, seconds=15,
                                            microseconds=123456),
                  '05:10:15.123456')
    _assert_equal(datetime_module.timedelta(days=3, hours=2, minutes=1,
                                            seconds=58, microseconds=123456),
                  '50:02:01.123456')



# Generated at 2022-06-22 18:17:57.500988
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2,
                                  seconds=3, microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2,
                                    seconds=3, microseconds=4)

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0,
                                  seconds=0, microseconds=0)
    )) == datetime_module.timedelta(hours=0, minutes=0,
                                    seconds=0, microseconds=0)


# Generated at 2022-06-22 18:18:05.838509
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-22 18:18:17.717177
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_timedelta_format(timedelta, expected):
        assert timedelta_format(timedelta) == expected
        assert timedelta_parse(expected) == timedelta
    assert_timedelta_format(datetime_module.timedelta(seconds=0),
                            '00:00:00.000000')
    for i in range(1, 60):
        assert_timedelta_format(datetime_module.timedelta(seconds=i),
                                '00:00:{:02d}.000000'.format(i))
    for i in range(1, 60):
        assert_timedelta_format(datetime_module.timedelta(seconds=60 + i),
                                '00:01:{:02d}.000000'.format(i))
    for i in range(1, 60):
        assert_

# Generated at 2022-06-22 18:18:27.829079
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:00:02.000001') == datetime_module.timedelta(
        seconds=2,
        microseconds=1
    )
    assert timedelta_parse('00:00:03.000002') == datetime_module.timedelta(
        seconds=3,
        microseconds=2
    )
    assert timedelta_parse('00:00:04.000003') == datetime_module.timedelta(
        seconds=4,
        microseconds=3
    )

# Generated at 2022-06-22 18:18:39.427057
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1, 1)) == '00:00:00.000101'
    assert timedelta_format(datetime_module.timedelta(1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1)) == '24:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == '24:00:00.000101'

# Generated at 2022-06-22 18:18:52.107234
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345)) == '00:00:00.012345'

# Generated at 2022-06-22 18:18:58.162057
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4))) == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)



# Generated at 2022-06-22 18:19:06.705304
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4)) == \
           '04:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=4)) == \
           '00:04:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=4)) == \
           '00:00:04.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == \
           '00:00:00.000004'

# Generated at 2022-06-22 18:19:16.655749
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 1)) == '24:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(1, 0, 1)) == '24:00:00.000001'

# Generated at 2022-06-22 18:19:27.936949
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-22 18:19:37.458268
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=35,
                                                      seconds=10,
                                                      microseconds=10)) == \
                                                     '01:35:10.000010'
    assert timedelta_format(datetime_module.timedelta(hours=20,
                                                      minutes=35,
                                                      seconds=10,
                                                      microseconds=10)) == \
                                                     '20:35:10.000010'
    assert timedelta_format(datetime_module.timedelta(hours=20,
                                                      minutes=35,
                                                      seconds=10,
                                                      microseconds=100000)) ==\
                                                     '20:35:10.100000'

test_timedelta_format()



# Generated at 2022-06-22 18:19:48.956839
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_python_toolbox.sham_datetime import ShamDatetime
    from .test_python_toolbox.sham_timedelta import ShamTimedelta
    assert timedelta_format(ShamTimedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(ShamTimedelta(minutes=3)) == '00:03:00.000000'
    assert timedelta_format(ShamTimedelta(seconds=5)) == '00:00:05.000000'
    assert timedelta_format(ShamTimedelta(microseconds=5)) == '00:00:00.000005'
    assert timedelta_format(ShamTimedelta(2, 3, 4, 5)) == '02:03:04.000005'



# Generated at 2022-06-22 18:19:56.978348
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                '00:00:01'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                                '01:00:00'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == \
                                                                '01:00:01'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                                '00:00:00.000001'



# Generated at 2022-06-22 18:20:02.145189
# Unit test for function timedelta_format
def test_timedelta_format():
    # Just to make sure.
    assert timedelta_format(datetime_module.timedelta(100, 100100)) == \
           '02:46:41.100100'

    # Make sure it works for negative deltas:
    assert timedelta_format(datetime_module.timedelta(-100, 100100)) == \
           '-01:13:18.899900'



# Generated at 2022-06-22 18:20:14.918570
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=456789,
    )
    assert timedelta_parse('2:3:4.56789') == datetime_module.timedelta(
        hours=2,
        minutes=3,
        seconds=4,
        microseconds=56789,
    )
    assert timedelta_parse('3:4:5.6789') == datetime_module.timedelta(
        hours=3,
        minutes=4,
        seconds=5,
        microseconds=6789,
    )

# Generated at 2022-06-22 18:20:20.367173
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      minutes=4, seconds=5,
                                                      microseconds=6)) ==\
                           '03:04:05.000006'

# Generated at 2022-06-22 18:20:27.050171
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0.0')) == '00:00:00.000000'

    assert timedelta_format(timedelta_parse('1:2:3.400500')) == '01:02:03.400500'

# Generated at 2022-06-22 18:20:36.619784
# Unit test for function timedelta_format
def test_timedelta_format():
    assert '00:00:00.000000' == timedelta_format(datetime_module.timedelta())
    assert '01:00:00.000000' == timedelta_format(
        datetime_module.timedelta(hours=1)
    )
    assert '01:15:00.000000' == timedelta_format(
        datetime_module.timedelta(minutes=75)
    )
    assert '00:00:15.000000' == timedelta_format(
        datetime_module.timedelta(seconds=15)
    )
    assert '00:00:00.000001' == timedelta_format(
        datetime_module.timedelta(microseconds=1)
    )



# Generated at 2022-06-22 18:20:45.185010
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:01.000200') == \
           datetime_module.timedelta(seconds=1, microseconds=200)
    assert timedelta_parse('00:01:00.000300') == \
           datetime_module.timedelta(minutes=1, microseconds=300)
    assert timedelta_parse('01:00:00.000400') == \
           datetime_module.timedelta(hours=1, microseconds=400)


try:
    import contextvars
except ImportError:
    ContextVar = None

# Generated at 2022-06-22 18:20:50.818292
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                      microseconds=7890)
    assert timedelta_format(delta) == '12:34:56.007890'



# Generated at 2022-06-22 18:21:02.072941
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == \
                                               datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == \
                                               datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1, hours=1))) == \
                                               datetime_module.timedelta(days=1, hours=1)
    zero = timedelta_format(datetime_module.timedelta(days=1, hours=1))
    assert timedelta_parse(zero) == datetime_module.timedelta(hours=1, minutes=1)

# Generated at 2022-06-22 18:21:09.550882
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
                            '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == \
                            '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(
                                            hours=3, minutes=30, seconds=15,
                                            microseconds=1000)) == \
                            '03:30:15.001000'
    assert timedelta_format(datetime_module.timedelta(days=3,
                                                      seconds=.5)) == \
                            '72:00:00.500000'



# Generated at 2022-06-22 18:21:17.805281
# Unit test for function timedelta_parse
def test_timedelta_parse():
    r'''Make sure that `timedelta_parse` does the job correctly.'''
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                  microseconds=456789)
    )) == datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=456789)


PY2_STR_TYPE = type(u'')
PY3_STR_TYPE = type('')

PY2_UNICODE_TYPE = type(u'')
PY3_UNICODE_TYPE = type('')

PY2_BYTES_TYPE = type('')
PY3_BYTES_TYPE = type(b'')


# Generated at 2022-06-22 18:21:28.435284
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
                                                datetime_module.timedelta(0)

    for i in range(-4, 4):
        assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=i))) == \
                                                datetime_module.timedelta(hours=i)

    for i in range(-4, 4):
        assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=i))) == \
                                                datetime_module.timedelta(minutes=i)


# Generated at 2022-06-22 18:21:38.986843
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1)
    )) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=1)
    )) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=1, seconds=1, microseconds=1)
    )) == datetime_module.timedelta(days=1, seconds=1, microseconds=1)



# Generated at 2022-06-22 18:21:50.492237
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-22 18:21:53.353414
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=567891)) == '02:03:04.567891'



# Generated at 2022-06-22 18:21:57.179502
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:45:59.123456') == \
           datetime_module.timedelta(hours=12, minutes=45, seconds=59,
                                     microseconds=123456)

# Generated at 2022-06-22 18:22:07.731487
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.123456') == \
           datetime_module.timedelta(
               hours=1, minutes=2, seconds=3, microseconds=123456
           )
    assert timedelta_parse('02:03.123456') == \
           datetime_module.timedelta(
               minutes=2, seconds=3, microseconds=123456
           )
    assert timedelta_parse('03.123456') == \
           datetime_module.timedelta(
               seconds=3, microseconds=123456
           )
    assert timedelta_parse('03.123') == \
           datetime_module.timedelta(
               seconds=3, microseconds=123000
           )
    assert timedelta_parse('03.1') == \
           datetime_module.timed

# Generated at 2022-06-22 18:22:16.525520
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse('00:00:01.100001') == datetime_module.timedelta(0, 1, 10000)

# Generated at 2022-06-22 18:22:27.100699
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                                    '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3, hours=4)) == \
                                                    '04:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5, hours=6)) == \
                                                    '06:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=7, hours=8,
                                                      minutes=9, seconds=10)) == \
                                                    '08:09:10.000007'
