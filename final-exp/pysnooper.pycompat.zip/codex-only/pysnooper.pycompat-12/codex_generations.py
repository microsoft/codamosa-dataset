

# Generated at 2022-06-22 18:12:34.478433
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '-1 day, 0:00:00'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == '-1:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=60)) == '1:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=61)) == '00:00:00.000061'

# Generated at 2022-06-22 18:12:45.581250
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:12:49.697382
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=4, hours=5, minutes=6,
                                          seconds=67, microseconds=89)
    assert timedelta_format(timedelta) == '117:06:07.000089'



# Generated at 2022-06-22 18:13:00.926303
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:05:45.6000000') == (
                                          datetime_module.timedelta(0, 345, 600000))
    assert timedelta_parse('00:05:45.60') == datetime_module.timedelta(0, 345, 600000)
    assert timedelta_parse('00:05:45.6') == datetime_module.timedelta(0, 345, 600000)
    assert timedelta_parse('00:05:45.06') == datetime_module.timedelta(0, 345, 60000)
    assert timedelta_parse('00:05:45.006') == datetime_module.timedelta(0, 345, 6000)

# Generated at 2022-06-22 18:13:06.618548
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('1:02:03.123456') == timedelta_parse(
        '1:02:03.123456789'
    )
    assert timedelta_parse('1:02:03') == timedelta_parse('1:02:03.0')
    assert timedelta_parse('1:02') == datetime_module.timedelta(
        minutes=62
    )
    assert timedelta_parse('1') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:13:14.775263
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00:000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00:000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01:000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00:000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01:000001'



# Generated at 2022-06-22 18:13:22.049041
# Unit test for function timedelta_format
def test_timedelta_format():
    # This needs to be the same for Python 2 and 3
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
                                                          '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
                                                          '00:00:03.000000'


# Generated at 2022-06-22 18:13:33.337221
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:13:41.037029
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:00:000000') == datetime_module.timedelta(
        seconds=60
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        seconds=60
    )
    assert timedelta_parse('00:00:00:999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(
        microseconds=999999
    )
    assert timedelta_parse('01:02:03:000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )

# Generated at 2022-06-22 18:13:52.816527
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import datetime_tools
    assert timedelta_format(
        timedelta_parse(timedelta_format(datetime_tools.timedelta_from_seconds(
            1.1234567
        )))
    ) == timedelta_format(datetime_tools.timedelta_from_seconds(1.1234567))


if PY3:
    import builtins
    integer_types = (int,)
    class_types = (type,)
    long = int
    unicode = str
    unichr = chr
    xrange = range
    izip = zip
    imap = map
    def byte_to_chr(b):
        return bytes([b]).decode('latin1')
    range = builtins.range

# Generated at 2022-06-22 18:13:56.191806
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=0)
    ) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=1, seconds=2, microseconds=3)
    ) == '00:01:02.000003'
    assert timedelta_format(
        datetime_module.timedelta(hours=0, minutes=1, seconds=2, microseconds=3000)
    ) == '00:01:02.003000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4000)
    ) == '01:02:03.004000'


# Generated at 2022-06-22 18:13:58.400327
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=1))



# Generated at 2022-06-22 18:14:07.487325
# Unit test for function timedelta_format
def test_timedelta_format():
    from garlicsim.general_misc import datetime_tools
    assert timedelta_format(datetime_module.timedelta(
        days=4, hours=6, minutes=11, seconds=53, milliseconds=621,
        microseconds=276)) == '06:11:53.062276'
    assert timedelta_format(datetime_module.timedelta(
        hours=6, minutes=11, seconds=53, milliseconds=621, microseconds=276)) == (
        '06:11:53.062276')
    assert timedelta_format(datetime_module.timedelta(
        minutes=11, seconds=53, milliseconds=621, microseconds=276)) == (
        '00:11:53.062276')

# Generated at 2022-06-22 18:14:13.782841
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        seconds=1,
        microseconds=1
    )
    assert timedelta_parse('00:01:01.000001') == datetime_module.timedelta(
        minutes=1,
        seconds=1,
        microseconds=1
    )

# Generated at 2022-06-22 18:14:23.857771
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:24.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=300)) == \
           '01:02:03.000300'
    assert timedelta_format(datetime_module.timedelta(days=400,
                                                      hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=300)) == \
           '09:02:03.000300'



# Generated at 2022-06-22 18:14:29.984508
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000') == datetime_module.timedelta(1)


from . import string_tools
from . import zip_tools

# Generated at 2022-06-22 18:14:40.320989
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=16, minutes=4,
                                                      seconds=31,
                                                      microseconds=1234)) == \
                                                      '16:04:31.001234'
    assert timedelta_format(datetime_module.timedelta(hours=16, minutes=4,
                                                      seconds=31,
                                                      microseconds=123456)) == \
                                                      '16:04:31.123456'
    assert timedelta_format(datetime_module.timedelta(hours=16, minutes=4,
                                                      seconds=31,
                                                      microseconds=12)) == \
                                                      '16:04:31.000012'

# Generated at 2022-06-22 18:14:45.444136
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:01:30.603883')) == '00:01:30.603883'
    assert timedelta_format(timedelta_parse('1:23:45.678912')) == '01:23:45.678912'

# Generated at 2022-06-22 18:14:56.398179
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=56789)) == \
                          '02:03:04.056789'

# Generated at 2022-06-22 18:15:03.848197
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(b'00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse(b'00:00:00.000001') == datetime_module.timedelta(0,
                                                                      0,
                                                                      1)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0,
                                                                      0,
                                                                      1)
    assert timedelta_parse(b'00:00:01.000000') == datetime_module.timedelta(0,
                                                                      1)

# Generated at 2022-06-22 18:15:09.842163
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=10, minutes=2, seconds=3, microseconds=456789))) == datetime_module.timedelta(hours=10, minutes=2, seconds=3, microseconds=456789)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=50, minutes=0, seconds=0, microseconds=0))) == datetime_module.timedelta(hours=50, minutes=0, seconds=0, microseconds=0)

# Generated at 2022-06-22 18:15:13.691050
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import datetime
    assert timedelta_parse('3:2:1.123456') == datetime.timedelta(
        hours=3, minutes=2, seconds=1, microseconds=123456
    )



# Generated at 2022-06-22 18:15:21.101596
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) == \
           '01:02:03.456000'
    assert timedelta_parse('01:02:03.456000'
                           ) == datetime_module.timedelta(hours=1, minutes=2,
                                                          seconds=3,
                                                          microseconds=456000)

# Generated at 2022-06-22 18:15:31.044490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000011') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=11)
    assert timedelta_parse('00:01:02.010000') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=10000)
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456)

# Generated at 2022-06-22 18:15:34.508862
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456)
    ) == '01:02:03.000456'



# Generated at 2022-06-22 18:15:42.864144
# Unit test for function timedelta_format
def test_timedelta_format():
    zero = datetime_module.timedelta()
    assert (timedelta_format(zero) ==
            '00:00:00.000000')
    one_microsecond = datetime_module.timedelta(microseconds=1)
    assert (timedelta_format(one_microsecond) ==
            '00:00:00.000001')
    one_second = datetime_module.timedelta(seconds=1)
    assert (timedelta_format(one_second) ==
            '00:00:01.000000')
    one_minute = datetime_module.timedelta(minutes=1)
    assert (timedelta_format(one_minute) ==
            '00:01:00.000000')
    one_hour = datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:15:51.199338
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=2)) == '00:01:02.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'

# Generated at 2022-06-22 18:16:02.967491
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=5,
                                                      seconds=5,
                                                      microseconds=5)) == \
                                                      '05:05:05.000005'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=5,
                                                      seconds=5,
                                                      microseconds=500000)) == \
                                                      '05:05:05.500000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=5,
                                                      seconds=5,
                                                      microseconds=5000000)) == \
                                                      '05:05:05.500000'

# Generated at 2022-06-22 18:16:06.147094
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=15,
                                                      seconds=2,
                                                      microseconds=10000)) == \
           '03:15:02.010000'



# Generated at 2022-06-22 18:16:18.557842
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == \
           '00:00:00.000000'

# Generated at 2022-06-22 18:16:25.149037
# Unit test for function timedelta_format
def test_timedelta_format():
    f = timedelta_format
    assert f(datetime_module.timedelta()) == '00:00:00.000000'
    assert f(datetime_module.timedelta(seconds=10)) == '00:00:10.000000'
    assert f(datetime_module.timedelta(hours=1)) == '01:00:00.000000'



# Generated at 2022-06-22 18:16:34.288651
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000')

# Generated at 2022-06-22 18:16:42.643521
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040000') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=40000))


if PY3:
    import traceback
    exec_ = getattr(traceback, 'clear_frames')
else:
    def exec_(code, globals=None, locals=None):
        """Execute code in a namespace."""
        if globals is None:
            frame = sys._getframe(1)
            globals = frame.f_globals
            if locals is None:
                locals = frame.f_locals
            del frame
        elif locals is None:
            locals = globals
        exec("""exec code in globals, locals""")

# Generated at 2022-06-22 18:16:47.422565
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '12:34:56.123456'
    assert timedelta_parse(s) == \
                            datetime_module.timedelta(hours=12, minutes=34,
                                                      seconds=56,
                                                      microseconds=123456)
    assert timedelta_format(timedelta_parse(s)) == s

# Generated at 2022-06-22 18:16:58.588953
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('00:00:01.200000') == datetime_module.timedelta(0, 1, 200000)
    assert timedelta_parse('00:01:02.300000') == datetime_module.timedelta(0, 62, 300000)

# Generated at 2022-06-22 18:17:02.074675
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                          microseconds=13)
    assert timedelta_format(timedelta) == '10:11:12.000013'


# Generated at 2022-06-22 18:17:10.920730
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4000)

    assert timedelta_parse('1:02:03.004000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4000)

    assert timedelta_parse('01:2:3.004000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4000)

    assert timedelta_parse('01:02:03.04') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=40000)

# Generated at 2022-06-22 18:17:19.868026
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3:4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )

test_timedelta_parse()

# Generated at 2022-06-22 18:17:26.380707
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=80, minutes=8, seconds=10, microseconds=2000000
    ))) == datetime_module.timedelta(
        hours=80, minutes=8, seconds=10, microseconds=2000000
    )



# Generated at 2022-06-22 18:17:35.449576
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1,
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1,
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1,
    )
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(
        hours=1, microseconds=1,
    )
    assert timedelta_parse('01:00:00.000010') == datetime_module.timedelta

# Generated at 2022-06-22 18:17:44.694203
# Unit test for function timedelta_format
def test_timedelta_format():
    '''
    This is a unit test for function `timedelta_format`.
    '''
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'



# Generated at 2022-06-22 18:17:57.014119
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00:000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
           '00:00:01:000000'
    assert timedelta_format(datetime_module.timedelta(days=1, minutes=1)) == \
           '00:01:00:000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == \
           '01:00:00:000000'

# Generated at 2022-06-22 18:18:01.361784
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=365)
    assert timedelta_format(timedelta) == '00:00:24:00:00:00.000000'



# Generated at 2022-06-22 18:18:10.311478
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
                                                      datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
                                                      datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    ))) == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )

# Generated at 2022-06-22 18:18:16.724390
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:20:30.555555') == datetime_module.timedelta(
        hours=1, minutes=20, seconds=30, microseconds=555555)
    assert timedelta_parse('-1:20:30.555555') == datetime_module.timedelta(
        hours=-1, minutes=-20, seconds=-30, microseconds=-555555)



# Generated at 2022-06-22 18:18:27.190337
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 1, 555)) == '00:00:01.000555'
    assert timedelta_format(datetime_module.timedelta(0, 1, 123456)) == '00:00:01.123456'
    assert timedelta_format(datetime_module.timedelta(0, 1, 123)) == '00:00:01.000123'
    assert timedelta_format(datetime_module.timedelta(0, 1, 999999)) == '00:00:01.999999'
    assert timedelta_format(datetime_module.timedelta(0, 1, 1)) == '00:00:01.000001'

# Generated at 2022-06-22 18:18:38.371920
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for input_string, expected_value in (
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('0:0:0.0', datetime_module.timedelta(0)),
        ('0:0:0.0:0:0:0', datetime_module.timedelta(0)),
        ('1:1:1.1', datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                              microseconds=100000)),
        ('11:11:11.11', datetime_module.timedelta(
            hours=11, minutes=11, seconds=11, microseconds=110000
        )),
    ):
        assert timedelta_parse(input_string) == expected_value

# Generated at 2022-06-22 18:18:41.492531
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=22, minutes=8,
                                                      seconds=15,
                                                      microseconds=25)) == \
           '22:08:15.000025'



# Generated at 2022-06-22 18:18:53.581661
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(milliseconds=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:00:01.000000') == dat

# Generated at 2022-06-22 18:18:57.864931
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4))) ==\
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)

# Generated at 2022-06-22 18:19:01.296048
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_format(timedelta) == '01:02:03.400000'


# Generated at 2022-06-22 18:19:06.897177
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(
        1, 7, 123000000
    )
    assert timedelta_parse('0:00:02.500000') == datetime_module.timedelta(
        0, 0, 2500000
    )
    assert timedelta_parse('0:00:02.000500') == datetime_module.timedelta(
        0, 0, 500
    )



# Generated at 2022-06-22 18:19:16.761676
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for i in range(100):
        seconds = i * i * i
        microseconds = i * i * (i + 1)
        timedelta = datetime_module.timedelta(seconds=seconds,
                                              microseconds=microseconds)
        s = timedelta_format(timedelta)
        restored_timedelta = timedelta_parse(s)
        assert restored_timedelta == timedelta



if sys.version_info[:2] >= (3, 5):
    # mypy doesn't understand the inspect.Signature stuff, so we need to
    # suppress these errors:
    from typing import Any, Callable, Tuple, TypeVar
    F0 = TypeVar('F0')
    F1 = TypeVar('F1', bound=Callable)

# Generated at 2022-06-22 18:19:21.102418
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=2, minutes=3, seconds=12,
                                  microseconds=345678))) == \
                                  datetime_module.timedelta(hours=2, minutes=3,
                                                            seconds=12,
                                                            microseconds=345678)



# Generated at 2022-06-22 18:19:26.080418
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40500,
    )) == '01:02:03.040500'



# Generated at 2022-06-22 18:19:30.146262
# Unit test for function timedelta_parse
def test_timedelta_parse():
    input_format = '40:30:20.123456'
    assert timedelta_parse(input_format) == datetime_module.timedelta(
        hours=40, minutes=30, seconds=20, microseconds=123456
    )



# Generated at 2022-06-22 18:19:39.046257
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1)
    result = timedelta_format(td)
    assert result == '01:00:00.000000', result
    td = datetime_module.timedelta(days=1, hours=1)
    result = timedelta_format(td)
    assert result == '25:00:00.000000', result
    td = datetime_module.timedelta(days=1, hours=1, minutes=1)
    result = timedelta_format(td)
    assert result == '25:01:00.000000', result
    td = datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1)
    result = timedelta_format(td)
    assert result == '25:01:01.000000', result

# Generated at 2022-06-22 18:19:41.663359
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=5, seconds=5,
                                          microseconds=5)
    assert timedelta_format(timedelta) == '05:05:05.000005'



# Generated at 2022-06-22 18:19:46.513277
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=7,
                                                 seconds=7,
                                                 microseconds=7))) == \
        datetime_module.timedelta(days=7, seconds=7, microseconds=7)



# Generated at 2022-06-22 18:19:55.562703
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    )) == '01:02:03.400000'

    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_format(td) == time_isoformat(td.time())

    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == '00:00:00.000002'

# Generated at 2022-06-22 18:20:05.383511
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == \
           '00:00:00.010000'

# Generated at 2022-06-22 18:20:09.446087
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(seconds=10000000)
    ) == '27:46:40.000000'



# Generated at 2022-06-22 18:20:17.455950
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(
        microseconds=(10**6 - 1)
    )
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(
        microseconds=1000001
    )
    assert timedelta_parse('0:1:1.000001') == datetime_module.timedelta(
        minutes=1, microseconds=1000001
    )

# Generated at 2022-06-22 18:20:28.784857
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5,
                                                      microseconds=43)) == '00:00:05:00:00.000043'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=5,
                                                      microseconds=43)) == '01:00:05:00:00.000043'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=5,
                                                      microseconds=43)) == '00:01:05:00:00.000043'

# Generated at 2022-06-22 18:20:35.681044
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:00:00.000009')) == '00:00:00.000009'
    assert timedelta_format(timedelta_parse('0:00:00.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('0:00:00.000099')) == '00:00:00.000099'

# Generated at 2022-06-22 18:20:47.089691
# Unit test for function timedelta_parse
def test_timedelta_parse():
    tests = (
        ('00:00:00:000000', 0),
        ('00:00:00.000001', 10**-6),
        ('00:00:00.100000', 100 * 10**-6),
        ('00:00:00.001000', 1000 * 10**-6),
        ('00:00:00.000000', 0),
        ('00:00:01.000000', 1),
        ('00:00:01.100000', 1.1),
        ('00:00:01.100001', 1.100001),
        ('00:01:00.000000', 60),
        ('01:00:00.000000', 60*60),
    )

    for string, number in tests:
        timedelta_parsed = timedelta_parse(string)

# Generated at 2022-06-22 18:20:51.300244
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:11:11.111111') == datetime_module.timedelta(
        hours=1, minutes=11, seconds=11, microseconds=111111
    )



# Generated at 2022-06-22 18:21:02.213188
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in '0:0:0:1000000', '0:0:0.1000000', '0:0:0.0':
        assert timedelta_parse(s) == datetime_module.timedelta(seconds=0)
    for s in '0:0:1:1000000', '0:0:1.1000000', '0:0:1.0':
        assert timedelta_parse(s) == datetime_module.timedelta(seconds=1)
    for s in '0:1:1:1000000', '0:1:1.1000000', '0:1:1.0':
        assert timedelta_parse(s) == datetime_module.timedelta(minutes=1, seconds=1)

# Generated at 2022-06-22 18:21:06.774408
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=2)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == '01:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-22 18:21:16.088319
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=43)) \
           == '00:00:01.000043'
    assert timedelta_format(datetime_module.timedelta(days=6, hours=5,
                                                      minutes=4, seconds=3,
                                                      microseconds=432)) \
           == '152:04:03.000432'


# Generated at 2022-06-22 18:21:28.487693
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=39,
                                                      seconds=43,
                                                      microseconds=987654)) == \
        '09:39:43.987654'
    assert timedelta_format(datetime_module.timedelta(seconds=239,
                                                      microseconds=123456)) == \
        '00:03:59.123456'
    assert timedelta_format(datetime_module.timedelta(seconds=239,
                                                      microseconds=123456)) == \
        '00:03:59.123456'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == \
        '00:00:00.123456'

# Generated at 2022-06-22 18:21:33.162899
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    td = datetime_module.timedelta(hours=4, minutes=5, seconds=6,
                                    microseconds=7)
    assert timedelta_format(td) == '04:05:06.000007'



# Generated at 2022-06-22 18:21:41.704854
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.002000')) \
                 == timedelta_format(timedelta_parse('2E-05'))
    assert timedelta_format(timedelta_parse('00:00:00.080000')) \
                 == timedelta_format(timedelta_parse('8E-06'))


if sys.version_info[:2] >= (3, 7):
    import contextlib
    class ContextStack(contextlib.AbstractContextManager):
        def __init__(self, context=None):
            self._context_stack = [context]
        def __enter__(self):
            return self.current_context
        def __exit__(self, *exc_details):
            self._context_stack.pop()

# Generated at 2022-06-22 18:21:44.635125
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-22 18:21:51.909011
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == \
                           '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=5)) == \
                           '00:03:05.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=5,
                                                      seconds=7,
                                                      microseconds=123456)) == \
                           '03:05:07.123456'



# Generated at 2022-06-22 18:21:56.376110
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for string in ('00:00:00.000000', '60:60:60.600000',
                   '12:11:10.012001'):
        assert timedelta_parse(string) == timedelta_parse(
            timedelta_format(timedelta_parse(string))
        )

# Generated at 2022-06-22 18:22:07.307063
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 1, 1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == '24:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(0, 3600, 1)) == '01:00:00.000001'



# Generated at 2022-06-22 18:22:11.704909
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(1, 2, 3)
    time = time_isoformat(timedelta)
    assert time == '00:00:01.000002'
    assert timedelta_parse(time) == timedelta



# Generated at 2022-06-22 18:22:23.796862
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == \
           '00:00:01.100000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.111)) == \
           '00:00:01.111000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1)) == \
           '24:00:00.000000'

# Generated at 2022-06-22 18:22:33.450915
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3600)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3600.123456)) == '01:00:00.123456'