

# Generated at 2022-06-22 18:12:29.019530
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                   microseconds=6789)
    assert timedelta_format(td) == '03:04:05.006789'


# Generated at 2022-06-22 18:12:37.853565
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') ==\
                                 datetime_module.timedelta(hours=1, minutes=2,
                                                           seconds=3,
                                                           microseconds=0)
    assert timedelta_parse('01:02:03.000001') ==\
                                 datetime_module.timedelta(hours=1, minutes=2,
                                                           seconds=3,
                                                           microseconds=1)
    assert timedelta_parse('01:02:03.100000') ==\
                                 datetime_module.timedelta(hours=1, minutes=2,
                                                           seconds=3,
                                                           microseconds=100000)
    assert timedelta_parse('01:02:03.010000') ==\
                                 datetime_module

# Generated at 2022-06-22 18:12:42.512897
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )


# Generated at 2022-06-22 18:12:52.684995
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=567)) == (
        '02:03:04.00567')
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=567)) == (
        '02:03:04.00567')
    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=4,
                                                      microseconds=567)) == (
        '00:03:04.00567'
    )

# Generated at 2022-06-22 18:12:57.419305
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=4,
                                                      seconds=3,
                                                      microseconds=200)) == \
                                                         '05:04:03.000200'



# Generated at 2022-06-22 18:13:06.715821
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(0, 0, 100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-22 18:13:15.097487
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0,1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(hours=23, minutes=59, seconds=59, microseconds=999999)



# Generated at 2022-06-22 18:13:22.983869
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import misc
    number_of_tests = 1000000
    timedelta = datetime_module.timedelta.min
    delta = datetime_module.timedelta(microseconds=1)
    for _ in range(number_of_tests):
        assert (timedelta_parse(timedelta_format(timedelta)) == timedelta)
        misc.assert_equality(
            timedelta_format(timedelta),
            timedelta.__str__().replace(' seconds, ', '.')
        )
        timedelta += delta
    assert timedelta == datetime_module.timedelta.max

# Generated at 2022-06-22 18:13:26.970034
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=2, minutes=50, seconds=18,
                                          microseconds=12137)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:13:34.131286
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == (datetime_module.timedelta())
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == (datetime_module.timedelta(days=1))
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1, microseconds=1))) == (datetime_module.timedelta(days=1, microseconds=1))

# Generated at 2022-06-22 18:13:41.487681
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import collections
    import itertools
    def microseconds(x):
        return datetime_module.timedelta(microseconds=x)
    
    # `timedelta_parse` should support not only positive times but also negative
    # times:
    
    assert timedelta_parse('-00:01:02.001234') == \
                                          timedelta_module.timedelta(-1, -2, -1234)
    
    # `timedelta_parse` should accept a single `int` argument which is the number
    # of microseconds, and return a `datetime.timedelta` for that:
    
    assert timedelta_parse(1234567) == microseconds(1234567)
    assert timedelta_parse(0) == microseconds(0)

# Generated at 2022-06-22 18:13:50.462570
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert '01:00:00.000000' == timedelta_format(datetime_module.timedelta(hours=1))
    assert '23:59:59.999999' == timedelta_format(datetime_module.timedelta(days=1) - datetime_module.timedelta(microseconds=1))
    with pytest.raises(AssertionError):
        timedelta_format(datetime_module.datetime.now())
        timedelta_format(datetime_module.timedelta(days=1, microseconds=1))



# Generated at 2022-06-22 18:13:58.343086
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                      microseconds=3)) == \
                                                          '000000:00:00:02.000003'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3, microseconds=4)) == \
                                                          '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) == \
                                                          '01:02:03.000000'

# Generated at 2022-06-22 18:14:07.451294
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.040000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('01:02:03.04000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('01:02:03.0400') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000
    )
    assert timedelta_parse('01:02:03.040') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400
    )
    assert timedelta_parse

# Generated at 2022-06-22 18:14:11.133943
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)

# Generated at 2022-06-22 18:14:12.997175
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=10)) == '00:10:00.000000'



# Generated at 2022-06-22 18:14:25.359761
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    def test_case(timedelta):
        s = timedelta_format(timedelta)
        assert timedelta == timedelta_parse(s)
        
    test_case(datetime_module.timedelta(seconds=1))
    test_case(datetime_module.timedelta(seconds=1, microseconds=10))
    test_case(datetime_module.timedelta(seconds=10, microseconds=100000))
    test_case(datetime_module.timedelta(minutes=1, microseconds=10))
    test_case(datetime_module.timedelta(hours=1, microseconds=10))
    test_case(datetime_module.timedelta(days=1, microseconds=10))

# Generated at 2022-06-22 18:14:33.111766
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('13:00:00.000000') == \
           datetime_module.timedelta(hours=13)
    assert timedelta_parse('13:20:00.000000') == \
           datetime_module.timedelta(hours=13, minutes=20)
    assert timedelta_parse('13:20:10.000000') == \
           datetime_module.timedelta(hours=13, minutes=20, seconds=10)
    assert timedelta_parse('13:20:10.456789') == \
           datetime_module.timedelta(hours=13, minutes=20, seconds=10,
                                     microseconds=456789)

# Generated at 2022-06-22 18:14:38.830884
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time_delta_1 = datetime_module.timedelta(hours=18, minutes=7,
                                             seconds=3, microseconds=600)
    time_delta_2 = timedelta_parse('18:07:03.000600')
    assert time_delta_1 == time_delta_2
    time_delta_2 = timedelta_parse('18:07:03.600')
    assert time_delta_1 == time_delta_2



# Generated at 2022-06-22 18:14:43.756598
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(
        microseconds=10000
    )
    assert timedelta_parse('00:00:01.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        microseconds=0
    )

# Generated at 2022-06-22 18:14:54.907834
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456000') == datetime_module.timedelta(
                                                   hours=1,
                                                   minutes=2,
                                                   seconds=3,
                                                   microseconds=456)
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
                                                   hours=1,
                                                   minutes=2,
                                                   seconds=3)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
                                                   hours=1,
                                                   minutes=2,
                                                   seconds=3,
                                                   microseconds=400000)

# Generated at 2022-06-22 18:15:05.482222
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
           '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

# Generated at 2022-06-22 18:15:09.391588
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=12,
        minutes=34,
        seconds=56,
        microseconds=7890
    )) == '12:34:56.007890'


# Generated at 2022-06-22 18:15:18.725256
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-2)) == '22:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == '00:00:59.000000'

# Generated at 2022-06-22 18:15:30.347238
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('-1:00:00.000000') == datetime_module.timedelta(
        hours=-1)
    assert timedelta_parse('-0:00:00.000001') == datetime_module.timedelta(
        microseconds=-1)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_

# Generated at 2022-06-22 18:15:33.449298
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.4') == (1 * 60 * 60 + 2 * 60 + 3) + \
                                            datetime_module.timedelta(microseconds=4)



# Generated at 2022-06-22 18:15:42.046692
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_timedelta_format(timedelta, expected_s):
        actual_s = timedelta_format(timedelta)
        assert actual_s == expected_s
    assert_timedelta_format(datetime_module.timedelta(12, 345, 678),
                            '12:00:00.003456')
    assert_timedelta_format(datetime_module.timedelta(0, 0, 0),
                            '00:00:00.000000')
    assert_timedelta_format(datetime_module.timedelta(-5, 213, 9980),
                            '-5:00:00.009980')

# Generated at 2022-06-22 18:15:51.529877
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(1, 3661)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(1, 3601)

# Generated at 2022-06-22 18:16:03.119722
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == \
                          datetime_module.timedelta(seconds=0)
    assert timedelta_parse('0:00:00.000001') == \
                          datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:01.000000') == \
                          datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:01:00.000000') == \
                          datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:00:00.000000') == \
                          datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:16:10.693817
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123000
    )
    assert timedelta_parse('01:02:03.1') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=100000
    )
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=0
    )

# Generated at 2022-06-22 18:16:20.698235
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.123456') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    )
    assert timedelta_parse('2:03.123456') == (
        datetime_module.timedelta(minutes=2, seconds=3, microseconds=123456)
    )
    assert timedelta_parse('3.123456') == (
        datetime_module.timedelta(seconds=3, microseconds=123456)
    )
    assert timedelta_parse('4') == (
        datetime_module.timedelta(seconds=4)
    )

# Generated at 2022-06-22 18:16:30.717127
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-22 18:16:40.700873
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:12:30.230000') == \
           datetime_module.timedelta(hours=1, minutes=12, seconds=30,
                                     microseconds=230000)
    assert timedelta_parse('1:12:30.230100') == \
           datetime_module.timedelta(hours=1, minutes=12, seconds=30,
                                     microseconds=230100)
    assert timedelta_parse('1:12:30') == \
           datetime_module.timedelta(hours=1, minutes=12, seconds=30)
    assert timedelta_parse('1:12:30.000001') == \
           datetime_module.timedelta(hours=1, minutes=12, seconds=30,
                                     microseconds=1)

# Generated at 2022-06-22 18:16:43.084483
# Unit test for function timedelta_parse
def test_timedelta_parse():
    d = datetime_module.timedelta(hours=8, minutes=14, seconds=10,
                                  microseconds=751806)
    assert timedelta_parse(timedelta_format(d)) == d

# Generated at 2022-06-22 18:16:54.696578
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:59:59.999999') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_parse('01:59:59.9999') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=59, microseconds=999900
    )
    assert timedelta_parse('01:59:59.999') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=59, microseconds=999000
    )
    assert timedelta_parse('01:59:59.99') == datetime_module.timedelta(
        hours=1, minutes=59, seconds=59, microseconds=990000
    )
    assert timedelta_parse

# Generated at 2022-06-22 18:17:04.225255
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.1') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:00:01.0') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.0') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:00:00.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:17:17.022502
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10.5)) == '00:00:10.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.5)) == '00:00:00.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.123456)) == '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(minutes=10)) == '00:10:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10)) == '10:00:00.000000'



# Generated at 2022-06-22 18:17:24.974056
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing_tools import assert_equal
    assert_equal(timedelta_parse('10:20:30.123456'),
                 datetime_module.timedelta(hours=10, minutes=20, seconds=30, microseconds=123456))
    assert len(timedelta_format(datetime_module.timedelta(seconds=10))) == 15



# Generated at 2022-06-22 18:17:29.001133
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == (
                                                          '01:02:03.456789'
                                                      )
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == (
                                                          '01:02:00.000000'
                                                      )


# Generated at 2022-06-22 18:17:37.692792
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=7)) == '00:00:07.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0, seconds=7, microseconds=1)) == '00:00:07.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1, seconds=7)) == '00:01:07.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=7)) == '01:01:07.000000'

# Generated at 2022-06-22 18:17:41.361049
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.100100') ==\
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=100100)

# Generated at 2022-06-22 18:17:48.088394
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
                            '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                            '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                            '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1)) == \
                            '01:00:01.000000'

# Generated at 2022-06-22 18:17:58.707213
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=56789)) == \
                                                      '02:03:04.056789'

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                      '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                      '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=0)) == \
                                                      '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(microseconds=-1))

# Generated at 2022-06-22 18:18:08.911028
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(days=2)) == \
                                                    '00:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    '01:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                    '00:00:00.000001'

    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
                                                    '00:00:00.001000'

    assert timedelta_format(datetime_module.timedelta(microseconds=1000000)) == \
                                                    '00:00:01.000000'


# Generated at 2022-06-22 18:18:20.884622
# Unit test for function timedelta_format
def test_timedelta_format():
    import timeit
    for _ in range(100):
        for microseconds in range(0, 1000000, 1000):
            td = datetime_module.timedelta(microseconds=microseconds)
            assert timedelta_format(td) == time_isoformat(td)
    print(timeit.timeit('timedelta_format(td)',
                        setup='from __main__ import timedelta_format;'
                              'td = datetime_module.timedelta(microseconds=50)',
                        number=10000))
    print(timeit.timeit('time_isoformat(td)',
                        setup='from __main__ import time_isoformat;'
                              'td = datetime_module.timedelta(microseconds=50)',
                        number=10000))



# Generated at 2022-06-22 18:18:29.436653
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_one_hour = datetime_module.timedelta(hours=1)
    assert timedelta_format(timedelta_one_hour) == '01:00:00.000000'
    timedelta_one_minute = datetime_module.timedelta(minutes=1)
    assert timedelta_format(timedelta_one_minute) == '00:01:00.000000'
    timedelta_one_second = datetime_module.timedelta(seconds=1)
    assert timedelta_format(timedelta_one_second) == '00:00:01.000000'
    timedelta_one_microsecond = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(timedelta_one_microsecond) == '00:00:00.000001'

    timed

# Generated at 2022-06-22 18:18:40.685022
# Unit test for function timedelta_format
def test_timedelta_format():
    if PY2:
        from pickle import loads, dumps
    else:
        from pickle import loads, dumps
    # (Try unpickling datetime.timedelta before running this test, because
    # if we don't, Python 3.6 will crash)
    loads(dumps(datetime_module.timedelta(hours=0, minutes=0, seconds=0)))
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0, microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-22 18:18:53.208007
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] >= (3, 6):
        assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
               datetime_module.timedelta(seconds=1).isoformat()
        assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
               datetime_module.timedelta(microseconds=1).isoformat()
        assert timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=4)
        ) == datetime_module.timedelta(hours=1, minutes=2,
                                       seconds=3,
                                       microseconds=4).isoformat()

# Generated at 2022-06-22 18:19:03.211974
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('00:00:30.000000') == datetime_module.timedelta(0, 30)
    assert timedelta_parse('00:00:30.123400') == datetime_module.timedelta(0, 30, 123400)

# Generated at 2022-06-22 18:19:15.377514
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                          microseconds=5)
    s = timedelta_format(timedelta)
    assert timedelta == timedelta_parse(s)
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4)
    s = timedelta_format(timedelta)
    assert timedelta == timedelta_parse(s)
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3)
    s = timedelta_format(timedelta)
    assert timedelta == timedelta_parse(s)
    timedelta = datetime_module.timedelta(days=1, hours=2)
    s = timed

# Generated at 2022-06-22 18:19:26.130067
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:19:36.229385
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:1.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('1:0:0.000001')) == '01:00:00.000001'
    assert timedelta_format(timedelta_parse('0:1:0.000001')) == '00:01:00.000001'
    assert timedelta_format(timedelta_parse('1:1:0.000001')) == '01:01:00.000001'
    assert timedelta_format(timedelta_parse('0:1:1.000001')) == '00:01:01.000001'

# Generated at 2022-06-22 18:19:44.863329
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=-1, minutes=2, seconds=3, microseconds=123456
    ))) == datetime_module.timedelta(
        hours=-1, minutes=2, seconds=3, microseconds=123456
    )



# Generated at 2022-06-22 18:19:55.997680
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1,
    )
    assert timedelta_parse('0:1:1.000000') == datetime_module.timedelta(
        minutes=1, seconds=1,
    )
    assert timedelta_parse('1:1:1.000000') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1,
    )
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1,
    )

# Generated at 2022-06-22 18:20:05.721362
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-22 18:20:11.993721
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    string = timedelta_format(timedelta)
    assert timedelta_parse(string) == timedelta
    assert timedelta_parse(string + '0') == timedelta



# Generated at 2022-06-22 18:20:18.347478
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=123456)
    assert timedelta_format(timedelta) == '01:02:03.123456'


# Unit te

# Generated at 2022-06-22 18:20:29.396422
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:23:45.123456') == datetime_module.timedelta(
        hours=1,
        minutes=23,
        seconds=45,
        microseconds=123456
    )
    assert timedelta_parse('23:58:00.0') == datetime_module.timedelta(
        hours=23,
        minutes=58
    )
    assert timedelta_parse('23:58:00.000001') == datetime_module.timedelta(
        hours=23,
        minutes=58,
        seconds=0,
        microseconds=1,
    )
    assert timedelta_parse('23:58') == datetime_module.timedelta(hours=23,
                                                                 minutes=58)

# Generated at 2022-06-22 18:20:34.016403
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.456789') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)

# Generated at 2022-06-22 18:20:46.761627
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1:2') == datetime_module.timedelta(
        minutes=1, seconds=2
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, milliseconds=4
    )
    assert timedelta_parse('1:2:3.4:5') == datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, milliseconds=5
    )
    assert timed

# Generated at 2022-06-22 18:20:50.725331
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
           datetime_module.timedelta(1)



# Generated at 2022-06-22 18:21:00.234569
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == datetime_module.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1))) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1000))) == datetime_module.timedelta(microseconds=1000)



# Generated at 2022-06-22 18:21:12.065988
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from garlicsim.general_misc import timestamping

    td0 = datetime_module.timedelta(microseconds=1)
    td1 = datetime_module.timedelta(days=10000)
    td2 = datetime_module.timedelta(microseconds=123444, seconds=12)
    td3 = datetime_module.timedelta(microseconds=123444, seconds=12,
                                    minutes=123, hours=1)

    assert timedelta_parse(timedelta_format(td0)) == td0
    assert timedelta_parse(timedelta_format(td1)) == td1
    assert timedelta_parse(timedelta_format(td2)) == td2
    assert timedelta_parse(timedelta_format(td3)) == td3


# Generated at 2022-06-22 18:21:17.041568
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, .1)
    assert timedelta_parse('00:00:00.100100') == datetime_module.timedelta(0, 0, .1001)
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(1, 7373, .123456)



# Generated at 2022-06-22 18:21:25.709680
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('10:20:30.405060')) == \
                                                              '10:20:30.405060'
    assert timedelta_format((datetime_module.datetime.min +
                             datetime_module.timedelta(
                                 hours=10, minutes=20, seconds=30,
                                 microseconds=4)).time()) == \
                                                             '10:20:30.000004'



# Generated at 2022-06-22 18:21:37.366262
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789000,
    ))) == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789000
    )
    assert timedelta_parse('12:34:56.789000') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789000
    )

test_timedelta_parse()



# Generated at 2022-06-22 18:21:43.037545
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(days=1, hours=1, seconds=1,
                                      microseconds=1)
    assert timedelta_format(delta) == '25:00:01.000001'



# Generated at 2022-06-22 18:21:52.795705
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:04:56:123456') == datetime_module.timedelta(
        days=1, hours=4, minutes=56, seconds=123, microseconds=456
    )
    assert (timedelta_parse('1:04:56:123456') ==
            timedelta_parse('1.04:56:123456'))
    return timedelta_parse  # for doctest


if PY2:
    class DictView(collections_abc.Set):
        """Dict view for Python 2.7."""
        def __init__(self, *args):
            self._set = set(*args)
        def __contains__(self, item):
            return item in self._set
        def __iter__(self):
            return iter(self._set)

# Generated at 2022-06-22 18:22:03.427569
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(days=1, minutes=2, seconds=3, microseconds=4),
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4),
        datetime_module.timedelta(minutes=1, seconds=2, microseconds=3),
        datetime_module.timedelta(seconds=1, microseconds=2),
        datetime_module.timedelta(microseconds=1),
    ):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

test_timedelta_parse()

# Generated at 2022-06-22 18:22:06.932935
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta, s = datetime_module.timedelta(days=1, seconds=2,
                                             microseconds=3), '24:00:02.000003'
    assert timedelta_format(timedelta) == s
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:22:15.822311
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1,
                                                      seconds=1, microseconds=1)) == '01:01:01.000001'


# Generated at 2022-06-22 18:22:26.610057
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
           '23:59:59.999999'
