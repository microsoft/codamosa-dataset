

# Generated at 2022-06-22 18:12:27.267925
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.7890') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=7890
    )



# Generated at 2022-06-22 18:12:33.580276
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('2:22:33.010203')
    assert timedelta == datetime_module.timedelta(hours=2, minutes=22,
                                                  seconds=33,
                                                  microseconds=10203)
    timedelta = timedelta_parse('12:11:22.333000')
    assert timedelta == datetime_module.timedelta(hours=12, minutes=11,
                                                  seconds=22,
                                                  microseconds=333000)



# Generated at 2022-06-22 18:12:44.873682
# Unit test for function timedelta_format
def test_timedelta_format():
    test_timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                               seconds=3, microseconds=456)
    assert timedelta_format(test_timedelta) == '01:02:03.004560'
    assert timedelta_parse(timedelta_format(test_timedelta)) == test_timedelta
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=1, hours=2,
                                  minutes=3, seconds=4, microseconds=56789)
    )) == datetime_module.timedelta(days=1, hours=2, minutes=3,
                                    seconds=4, microseconds=56789)

# Generated at 2022-06-22 18:12:54.023400
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('0:00:00.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-22 18:12:57.245827
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    ) == '25:01:01.000001'



# Generated at 2022-06-22 18:13:02.451622
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(hours=3,
                                                        minutes=5,
                                                        seconds=6,
                                                        microseconds=765432))
    assert result == '03:05:06.765432'



# Generated at 2022-06-22 18:13:09.372765
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                      '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3661)) == \
                                                      '01:01:01.000000'

test_timedelta_format()



# Generated at 2022-06-22 18:13:21.177079
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                                                   '02:00:00.000000'

    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                   '00:01:00.000000'

    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                   '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                   '00:00:00.001000'

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                   '00:00:00.000001'


test_timedelta_format()


# Unit

# Generated at 2022-06-22 18:13:24.232577
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=100)) == \
            '02:40:00.000000'


# Generated at 2022-06-22 18:13:35.246568
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('01:20:30.500000')) == \
        '01:20:30.500000'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
        '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.123456')) == \
        '00:00:00.123456'
    assert timedelta_format(timedelta_parse('01:20:30')) == \
        '01:20:30.000000'
    assert timedelta_format(timedelta_parse('01:20')) == \
        '01:20:00.000000'

# Generated at 2022-06-22 18:13:41.326886
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1,
                                                      seconds=2,
                                                      microseconds=300000)) == (
        '00:01:02.300000'
    )
    assert timedelta_parse('00:01:02.300000') == (
        datetime_module.timedelta(hours=0, minutes=1, seconds=2,
                                  microseconds=300000)
    )

# Generated at 2022-06-22 18:13:53.068502
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) ==\
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) ==\
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) ==\
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) ==\
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'


# Generated at 2022-06-22 18:14:04.432000
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_utils

    test_utils.assert_equal(timedelta_format(datetime_module.timedelta(0)),
                            '00:00:00.000000')
    test_utils.assert_equal(timedelta_format(
        datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                  days=-1)
    ), '23:59:59.000000')
    test_utils.assert_equal(timedelta_format(
        datetime_module.timedelta(hours=23, minutes=59, seconds=58,
                                  microseconds=999999)
    ), '23:59:58.999999')

# Generated at 2022-06-22 18:14:13.101849
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=1
    ))) == datetime_module.timedelta(microseconds=1)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        microseconds=123456789
    ))) == datetime_module.timedelta(microseconds=123456789)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    ))) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=456789)

# Generated at 2022-06-22 18:14:21.925322
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:00') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:01:10') == datetime_module.timedelta(seconds=70)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(hours=1, microseconds=1)
    assert timedelta_parse('01:00:00.000010') == datetime_module.timedelta(hours=1, microseconds=10)



# Generated at 2022-06-22 18:14:29.947563
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
                                datetime_module.timedelta(hours=12)
                           )) == datetime_module.timedelta(hours=12)
    assert timedelta_parse(timedelta_format(
                                datetime_module.timedelta(minutes=12)
                           )) == datetime_module.timedelta(minutes=12)
    assert timedelta_parse(timedelta_format(
                                datetime_module.timedelta(seconds=12)
                           )) == datetime_module.timedelta(seconds=12)

# Generated at 2022-06-22 18:14:32.622874
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for _ in range(100):
        timedelta = datetime_module.timedelta(hours=666, minutes=13,
                                              seconds=13, microseconds=13)
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-22 18:14:39.450384
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for string, expected_timedelta in (
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('0:0:0.0', datetime_module.timedelta(0)),
        ('1:1:1.1', datetime_module.timedelta(hours=1,
                                              minutes=1,
                                              seconds=1,
                                              microseconds=100000)),
    ):
        assert expected_timedelta == timedelta_parse(string)



# Generated at 2022-06-22 18:14:46.298705
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
        datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=10
    ))) == datetime_module.timedelta(seconds=10)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=10, microseconds=4
    ))) == datetime_module.timedelta(seconds=10, microseconds=4)

# Generated at 2022-06-22 18:14:56.801389
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:01.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('00:00:00.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('00:00:00.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('00:00:00.001000')) == '00:00:00.001000'

# Generated at 2022-06-22 18:15:02.029617
# Unit test for function timedelta_format
def test_timedelta_format():
    if sys.version_info[:2] < (3, 6):
        return
    from .test_timing import timedelta_format as standard_timedelta_format
    for delta in range(4):
        for microsecond in range(100000):
            assert timedelta_format(datetime_module.timedelta(
                days=delta, microseconds=microsecond
            )) == standard_timedelta_format(datetime_module.timedelta(
                days=delta, microseconds=microsecond
            ))


# Generated at 2022-06-22 18:15:09.876110
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 3, 1)) == '00:00:03.000001'
    assert timedelta_format(datetime_module.timedelta(0, 60, 1)) == '00:01:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 3600, 1)) == '01:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 10000, 1)) == '02:46:40.000001'


# Generated at 2022-06-22 18:15:14.481655
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=3, seconds=14,
                                          microseconds=56789)
    assert timedelta_format(timedelta) == '01:03:14.56789'

# Generated at 2022-06-22 18:15:22.525027
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'



# Generated at 2022-06-22 18:15:33.761176
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:15:37.092464
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                          microseconds=1_000_000)
    assert timedelta_format(timedelta) == '02:03:05.000000'



# Generated at 2022-06-22 18:15:44.668842
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:02:03.000004')) == \
                             '01:02:03.000004'
    assert timedelta_format(timedelta_parse('0:01:02.000003')) == \
                             '00:01:02.000003'
    assert timedelta_format(timedelta_parse('0:00:01.000002')) == \
                             '00:00:01.000002'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == \
                             '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                             '00:00:00.000000'


# Generated at 2022-06-22 18:15:53.299238
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=5, minutes=7, seconds=1)
    ) == '05:07:01.000000'

    assert timedelta_format(
        timedelta_parse('5:7:1')
    ) == '05:07:01.000000'

    assert timedelta_format(
        datetime_module.timedelta(seconds=1)
    ) == '00:00:01.000000'

    assert timedelta_format(
        timedelta_parse('0:0:1')
    ) == '00:00:01.000000'

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=5, minutes=7, seconds=1,
                                  microseconds=123456)
    )) == datetime

# Generated at 2022-06-22 18:15:57.007528
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )



# Generated at 2022-06-22 18:16:00.219992
# Unit test for function timedelta_format
def test_timedelta_format():
    """Unit test for timedelta_format."""
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'

# Generated at 2022-06-22 18:16:08.894967
# Unit test for function timedelta_format
def test_timedelta_format():

    def test(timedelta, expected):
        actual_result = timedelta_format(timedelta)
        assert actual_result == expected, (
            f'Expected `{expected}`, got `{actual_result}`.'
        )

    test(datetime_module.timedelta(hours=6, minutes=7, seconds=8,
                                   microseconds=9),
         '06:07:08.000009')

    test(datetime_module.timedelta(hours=6, minutes=7, seconds=8,
                                   microseconds=987_654),
         '06:07:08.987654')

    test(datetime_module.timedelta(hours=6, minutes=7, seconds=8,
                                   microseconds=0),
         '06:07:08.000000')


# Unit

# Generated at 2022-06-22 18:16:12.378959
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=9, minutes=30, seconds=12, microseconds=123456
    )) == '09:30:12.123456'
        


# Generated at 2022-06-22 18:16:20.408268
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(0, 0, 5))
    assert time == '00:00:05.000000'
    time = time_isoformat(datetime_module.time(0, 0, 0, 9))
    assert time == '00:00:00.000009'
    time = time_isoformat(datetime_module.time(0, 0, 0, 9),
                          timespec='milliseconds')
    assert time == '00:00:00.009000'



# Generated at 2022-06-22 18:16:25.323021
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(1, 8382, 678901)
    assert timedelta_parse('1:23:45.678901') == timedelta_parse('1:23:45.678901000')



# Generated at 2022-06-22 18:16:27.765541
# Unit test for function timedelta_format
def test_timedelta_format():
    timestamp = datetime_module.timedelta(seconds=1234.56789)
    assert timedelta_format(timestamp) == '00:20:34.56789'



# Generated at 2022-06-22 18:16:28.828605
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:16:31.812263
# Unit test for function timedelta_parse
def test_timedelta_parse():
    original = datetime_module.timedelta(days=1, seconds=2, microseconds=3)
    new = timedelta_parse(timedelta_format(original))
    assert original == new, (original, new)

# Generated at 2022-06-22 18:16:41.356776
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('7:13:14.444444')
    assert timedelta.days == 0
    assert timedelta.seconds == 26194
    assert timedelta.microseconds == 444444
    assert timedelta.total_seconds() == 26194.444444
    timedelta = timedelta_parse('0:0:2.3')
    assert timedelta.days == 0
    assert timedelta.seconds == 2
    assert timedelta.microseconds == 300000
    assert timedelta.total_seconds() == 2.3
    timedelta = timedelta_parse('2:30:40.500000')
    assert timedelta.days == 0
    assert timedelta.seconds == 9440
    assert timedelta.microseconds == 500000
    assert timedelta.total_seconds() == 9440.5
    timedelta = timedelta_

# Generated at 2022-06-22 18:16:52.251509
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                 '00:00:01.000000'

    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                                 '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == \
                                                                 '00:01:01.000000'

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                                 '01:00:00.000000'

# Generated at 2022-06-22 18:16:54.360377
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 3600 + 60 + 1, 999999)) == '01:01:01.999999'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == '00:00:00.000001'



# Generated at 2022-06-22 18:16:57.632169
# Unit test for function timedelta_format
def test_timedelta_format():
    f = datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                  microseconds=5)
    assert timedelta_format(f) == '02:03:04.000005'



# Generated at 2022-06-22 18:17:06.463213
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_case import TestCase
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00:000000'
    assert timedelta_format(datetime_module.timedelta(minutes=34)) == '00:34:00:000000'
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == '00:00:05:000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=12)) == '00:00:00:000012'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=34, seconds=5, microseconds=12)) == '01:34:05:000012'

# Generated at 2022-06-22 18:17:12.280502
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=15, minutes=30,
                                                      seconds=30,
                                                      microseconds=123456)) \
           == '15:30:30.123456'



# Generated at 2022-06-22 18:17:21.426627
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000011') == datetime_module.timedelta(
        microseconds=11
    )
    assert timedelta_parse('00:00:00.000111') == datetime_module.timedelta(
        microseconds=111
    )
    assert timedelta_parse('00:00:00.001111') == datetime_module.timedelta(
        microseconds=1111
    )

# Generated at 2022-06-22 18:17:26.102268
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '01:02:03.123456'

# Generated at 2022-06-22 18:17:35.259098
# Unit test for function timedelta_format
def test_timedelta_format():
    for time in datetime_module.time(), datetime_module.time(23, 59, 59):
        assert timedelta_format(datetime_module.timedelta(hours=1)) == (
            '01:00:00.000000'
        )
        assert timedelta_format(datetime_module.timedelta()) == (
            '00:00:00.000000'
        )
        assert timedelta_format(datetime_module.timedelta(
            hours=-1,
            minutes=-1,
            seconds=-1,
            microseconds=-1
        )) == ('-01:01:01.000001')
        assert timedelta_format(datetime_module.timedelta(
            microseconds=999999
        )) == ('00:00:01.000000')

# Generated at 2022-06-22 18:17:46.042819
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-22 18:17:56.843925
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(23, 59, 59, 999999))
    assert time == '23:59:59.999999'


if PY3:
    def is_string(x):
        return isinstance(x, str)
else:
    def is_string(x):
        return isinstance(x, basestring)

if PY3:

    def get_wrapped(wrapper):
        try:
            return wrapper.__wrapped__
        except AttributeError:
            return wrapper.__self__

    from functools import getfullargspec as getargspec

else:
    def get_wrapped(wrapper):
        return wrapper.__self__

    from inspect import getargspec

# Generated at 2022-06-22 18:18:08.078767
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
          '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
          '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
          '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=100)) == \
          '01:01:01.000100'



# Generated at 2022-06-22 18:18:20.276763
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def positive_test(string, hours, minutes, seconds, microseconds):
        assert timedelta_parse(string) == datetime_module.timedelta(
            hours=hours, minutes=minutes,
            seconds=seconds, microseconds=microseconds)

    def negative_test(string):
        with pytest.raises(ValueError):
            timedelta_parse(string)

    negative_test('2-03:04:05.06')
    negative_test('2:03:04:05.06')
    negative_test('2:03-04:05.06')
    negative_test('2:03:04:05.06')
    negative_test('2:03.04:05.06')
    negative_test('.2:03:04:05.06')

# Generated at 2022-06-22 18:18:29.127441
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=10000)) == '00:00:00.010000'
    assert timedelta_

# Generated at 2022-06-22 18:18:40.428971
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=10)) == \
           '01:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=10, seconds=10
    )) == '00:00:10.000010'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=10, seconds=10, minutes=10
    )) == '00:10:10.000010'

# Generated at 2022-06-22 18:18:52.965194
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == \
           datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:19:02.920522
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:19:15.038296
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                            '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=2)) == \
                                                            '00:00:02.000002'
    assert timedelta_format(datetime_module.timedelta(minutes=3,
                                                      seconds=2,
                                                      microseconds=2)) == \
                                                            '00:03:02.000002'

# Generated at 2022-06-22 18:19:19.941292
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=21)) == \
           '21:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=21)) == \
           '00:00:21.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=21)) == \
           '00:00:00.021000'



# Generated at 2022-06-22 18:19:29.312912
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(seconds=0)
    assert timedelta_parse('13:59:59.999999') == \
           datetime_module.timedelta(days=0, hours=13, minutes=59, seconds=59,
                                     microseconds=999999)
    assert timedelta_parse('86399:59:59.999999') == \
           datetime_module.timedelta(days=0, hours=23, minutes=59, seconds=59,
                                     microseconds=999999)



# Generated at 2022-06-22 18:19:36.380786
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=20)) == '02:00:20.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=2, seconds=20)) == '50:00:20.000000'
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'



# Generated at 2022-06-22 18:19:47.703708
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(days=1) +
                            datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
                                                            '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(days=1) +
                            datetime_module.timedelta(seconds=1,
                                                      microseconds=1000)) == \
                                                            '00:00:01.001000'
    assert timedelta_format(datetime_module.timedelta(days=1) +
                            datetime_module.timedelta(seconds=1,
                                                      microseconds=1000000)) == \
                                                            '00:00:02.000000'

# Generated at 2022-06-22 18:19:57.706684
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # This test also makes sure that microseconds are not cut out on Python 2
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        seconds=0,
        microseconds=123456
    )
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        hours=0,
        minutes=0,
        seconds=0,
        microseconds=123456
    )
    assert timedelta_parse('01:00:00.123456') == datetime_module.timedelta(
        hours=1,
        minutes=0,
        seconds=0,
        microseconds=123456
    )

# Generated at 2022-06-22 18:20:02.450062
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.023456') == datetime_module.timedelta(
        seconds=1, microseconds=23456
    )
    assert timedelta_parse('1:23:45.123456') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=123456
    )



# Generated at 2022-06-22 18:20:08.421471
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=6, seconds=6,
                                                      microseconds=6)) == \
                                                             '06:00:06.000006'



# Generated at 2022-06-22 18:20:15.449722
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('23:12:11.823719') == datetime_module.timedelta(
        hours=23, minutes=12, seconds=11, microseconds=823719)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)
    assert timedelta_parse('23:12:11.823719') == timedelta_parse(
        timedelta_format(timedelta_parse('23:12:11.823719')))

# Generated at 2022-06-22 18:20:27.202961
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1.2))) == datetime_module.timedelta(seconds=1.2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=23, minutes=45, seconds=1.01))) == datetime_module.timedelta(hours=23, minutes=45, seconds=1.01)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=12345))) == datetime_module.timedelta(microseconds=12345)

# Generated at 2022-06-22 18:20:31.918597
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=5, minutes=6, seconds=7,
                                   microseconds=54321)
    assert timedelta_format(td) == '05:06:07.054321'



# Generated at 2022-06-22 18:20:35.595119
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1)))

# Generated at 2022-06-22 18:20:46.823322
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:012345') == datetime_module.timedelta(microseconds=12345)
    assert timedelta_parse('00:00:01:123456') == datetime_module.timedelta(seconds=1,
                                                                           microseconds=123456)
    assert timedelta_parse('00:01:01:123456') == datetime_module.timedelta(minutes=1, seconds=1,
                                                                           microseconds=123456)
    assert timedelta_parse('01:01:01:123456') == datetime_module.timedelta(hours=1, minutes=1,
                                                                           seconds=1,
                                                                           microseconds=123456)



# Generated at 2022-06-22 18:20:51.417206
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('3:52:58.640342') == \
           datetime_module.timedelta(hours=3, minutes=52, seconds=58,
                                     microseconds=640342)



# Generated at 2022-06-22 18:21:02.201881
# Unit test for function timedelta_format
def test_timedelta_format():
    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(hours=1), timespec='hours')
    pytest.assertEqual(timedelta_format(datetime_module.timedelta(hours=1)),
                       '01:00:00:000000')
    pytest.assertEqual(timedelta_format(datetime_module.timedelta(minutes=1)),
                       '00:01:00:000000')
    pytest.assertEqual(timedelta_format(datetime_module.timedelta(seconds=1)),
                       '00:00:01:000000')
    pytest.assertEqual(timedelta_format(datetime_module.timedelta(microseconds=1)),
                       '00:00:00:000001')


# Generated at 2022-06-22 18:21:10.028877
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )
    assert timedelta_parse('00:10:00.123') == datetime_module.timedelta(
        minutes=10, seconds=0, microseconds=123000
    )
    assert timedelta_parse('00:00:00.001001') == datetime_module.timedelta(
        microseconds=1001
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse

# Generated at 2022-06-22 18:21:14.236230
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=4,
                                                      seconds=5, microseconds=123456)) == \
                                                      '03:04:05.123456'


# Generated at 2022-06-22 18:21:26.483846
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import my_assert
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=39, seconds=1, microseconds=1)
    ) == '39:00:01.000001'



# Generated at 2022-06-22 18:21:37.746455
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:21:44.992712
# Unit test for function timedelta_parse
def test_timedelta_parse():
    dt = datetime_module.timedelta(days=1, hours=1, minutes=1,
                                   seconds=1, microseconds=1)
    assert timedelta_parse(timedelta_format(dt)) == dt
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(seconds=1 + 60 + 60 + 3600 + 1)

# Generated at 2022-06-22 18:21:53.992426
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-22 18:22:05.916124
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('01:02:03.1') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=100000)
    assert timedelta_parse('01:02:03.2') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=200000)



# Generated at 2022-06-22 18:22:10.806841
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.10000') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=10000)

# Generated at 2022-06-22 18:22:23.101084
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == \
           '00:00:00.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
           '00:00:00.001000'

# Generated at 2022-06-22 18:22:26.901197
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(days=2, hours=10, minutes=12,
                                   seconds=43, microseconds=123456)
    assert timedelta_parse(timedelta_format(td)) == td