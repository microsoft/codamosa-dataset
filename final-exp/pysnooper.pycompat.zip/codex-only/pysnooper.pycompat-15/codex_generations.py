

# Generated at 2022-06-22 18:12:23.820977
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.000001') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=1
    )
    assert timedelta_parse('00:01:02.000010') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=10
    )
    assert timedelta_parse('00:01:02.000100') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=100
    )
    assert timedelta_parse('00:01:02.001000') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=1000
    )
    assert timedelta_parse('00:01:02.010000') == datetime_module.tim

# Generated at 2022-06-22 18:12:36.709703
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=123456
    )) == '01:02:03.123456'

    assert timedelta_format(datetime_module.timedelta(
        hours=33,
        minutes=22,
        seconds=11,
        microseconds=987654
    )) == '33:22:11.987654'

if __name__ == '__main__':
    test_timedelta_format()

# Generated at 2022-06-22 18:12:47.195199
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=5)) == \
           '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
           '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=1005)) == \
           '00:00:00.001005'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1005)) == \
           '00:00:00.100500'
    assert timedelta_format(datetime_module.timedelta(seconds=65)) == \
           '00:01:05.000000'

# Generated at 2022-06-22 18:12:50.967994
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000004') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )



# Generated at 2022-06-22 18:13:01.496431
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.010') == datetime_module.timedelta(
        microseconds=10)
    assert timedelta_parse('00:00:00.100') == datetime_module.timedelta(
        microseconds=100)
    assert timedelta_parse('00:00:00.123') == datetime_module.timedelta(
        microseconds=123)
    assert timedelta_parse('00:00:00.999') == datetime_module.timedelta(
        microseconds=999)

# Generated at 2022-06-22 18:13:06.732265
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('12:07:58.160000') ==
            datetime_module.timedelta(hours=12, minutes=7, seconds=58,
                                      microseconds=160000))



# Generated at 2022-06-22 18:13:15.674164
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:1.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('0:1:1.000001') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=1
    )
    assert timedelta_parse('1:1:1.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )

# Generated at 2022-06-22 18:13:25.187186
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_equals(timedelta_a, timedelta_b):
        assert timedelta_a == timedelta_b
        assert repr(timedelta_a) == repr(timedelta_b)
        assert str(timedelta_a) == str(timedelta_b)

    assert_timedelta_equals(timedelta_parse('0:00:00.000000'),
                            datetime_module.timedelta())
    assert_timedelta_equals(timedelta_parse('23:59:59.999999'),
                            datetime_module.timedelta(days=1) - datetime_module.timedelta(microseconds=1))

# Generated at 2022-06-22 18:13:36.034488
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:0:0.1')) == '00:00:00.100000'
    assert timedelta_format(timedelta_parse('1:1:1.1')) == '01:01:01.100000'
    assert timedelta_format(timedelta_parse('2:2:2.2')) == '02:02:02.200000'
    assert timedelta_format(timedelta_parse('3:3:3.3')) == '03:03:03.300000'
    assert timedelta_format(timedelta_parse('4:4:4.4')) == '04:04:04.400000'

# Generated at 2022-06-22 18:13:45.259872
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(
        datetime_module.datetime(2016, 9, 5, 12, 3, 45, 123456).timetz()
    )
    assert time == '12:03:45.123456'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=12, minutes=3, seconds=45,
                                  microseconds=123456)
    ) == '12:03:45.123456'


# Generated at 2022-06-22 18:13:54.024763
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) == \
           '01:02:03.456000'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == \
           '01:02:03.456789'



# Generated at 2022-06-22 18:14:00.028122
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for i in range(10):
        for j in range(10):
            for k in range(10):
                for l in range(10):
                    s = '{}:{}:{}.{}'.format(i, j, k, l)
                    assert timedelta_parse(s) == datetime_module.timedelta(
                        hours=i, minutes=j, seconds=k, milliseconds=l
                    )

# Generated at 2022-06-22 18:14:08.526307
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == \
           datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == \
           datetime_module.timedelta(microseconds=1000)

# Generated at 2022-06-22 18:14:14.466416
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.0000011') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000001') == timed

# Generated at 2022-06-22 18:14:25.759597
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(3600)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(3600, 1)

# Generated at 2022-06-22 18:14:30.171612
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_format(datetime_module.timedelta(hours=1,
                                               minutes=2,
                                               seconds=3,
                                               microseconds=123456))
    # Should raise an exception:
    timedelta_format(datetime_module.timedelta(hours=1,
                                               minutes=2,
                                               seconds=3,
                                               microseconds=1234567))

# Generated at 2022-06-22 18:14:34.558010
# Unit test for function timedelta_format
def test_timedelta_format():

    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'



# Generated at 2022-06-22 18:14:37.228655
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test.test_misc.test_misc_tools.test_timedelta_format import \
        test_timedelta_format
    test_timedelta_format(timedelta_format)

# Generated at 2022-06-22 18:14:45.266562
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
                                     datetime_module.timedelta(hours=1, minutes=2,
                                                               seconds=3,
                                                               microseconds=123456)
    assert timedelta_parse('01:02:03.000000') == \
                                     datetime_module.timedelta(hours=1, minutes=2,
                                                               seconds=3)
    assert timedelta_parse('1:2:3.000000') == \
                                     datetime_module.timedelta(hours=1, minutes=2,
                                                               seconds=3)
    assert timedelta_parse('1:2:3') == \
                                     datetime_module.timedelta(hours=1, minutes=2,
                                                               seconds=3)
   

# Generated at 2022-06-22 18:14:55.303226
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:00:01.000001') == datetime_module.timedelta(
        seconds=1, microseconds=1
    )
    assert timedelta_parse('0:01:02.000001') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=1
    )
    assert timedelta_parse('1:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )



# Generated at 2022-06-22 18:15:05.851329
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pickle

# Generated at 2022-06-22 18:15:12.422516
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=1))) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=10))) == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(microseconds=100))) == datetime_module.timed

# Generated at 2022-06-22 18:15:18.302918
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=22,
                                                      seconds=33,
                                                      microseconds=44)) == \
                           '11:22:33.000044'



# Generated at 2022-06-22 18:15:21.665504
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=2, microseconds=1234
    )) == (
        '00:00:02.001234'
    )


# Generated at 2022-06-22 18:15:26.527820
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=12, minutes=34,
                         seconds=56, microseconds=789012)
    )) == datetime_module.timedelta(hours=12, minutes=34,
                                    seconds=56, microseconds=789012)

# Generated at 2022-06-22 18:15:29.800939
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '100:00:00.123456'
    td = timedelta_parse(s)
    assert timedelta_format(td) == s

test_timedelta_parse()

# Generated at 2022-06-22 18:15:39.412715
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:15:46.144780
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=13)) == \
           '00:13:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=7)) == \
           '00:00:07.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
           '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(
        minutes=12, microseconds=5
    )) == '00:12:00.000005'
    assert timedelta_format(datetime_module.timedelta(
        seconds=5, microseconds=5
    )) == '00:00:05.000005'

# Generated at 2022-06-22 18:15:50.431754
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23, minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
           '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=1,
                                                      microseconds=500)) == \
           '00:00:01.000500'



# Generated at 2022-06-22 18:15:55.268754
# Unit test for function timedelta_format
def test_timedelta_format():
    d = datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=5
    )
    assert timedelta_format(d) == '50:03:04.000005'



# Generated at 2022-06-22 18:16:00.370569
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)

# Generated at 2022-06-22 18:16:05.924244
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format((datetime_module.datetime.min +
                             datetime_module.timedelta(seconds=1))) == \
           '00:00:01.000000'
    assert timedelta_format((datetime_module.datetime.min +
                             datetime_module.timedelta(seconds=1,
                                                       microseconds=1))) == \
           '00:00:01.000001'



# Generated at 2022-06-22 18:16:09.752561
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        '1:1:1.000001'
    ) == datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                   microseconds=1)

# Generated at 2022-06-22 18:16:20.912403
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                            datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == \
                                                            datetime_module.timedelta(days=1)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(seconds=0.123456)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(milliseconds=123.456)

# Generated at 2022-06-22 18:16:28.395199
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.67890') == datetime_module.timedelta(
        hours=1,
        minutes=23,
        seconds=45,
        microseconds=67890
    )
    assert timedelta_parse('0:10:12.467') == datetime_module.timedelta(
        minutes=10,
        seconds=12,
        microseconds=467
    )
    assert timedelta_parse('1.234') == datetime_module.timedelta(
        seconds=1,
        microseconds=234
    )

# Generated at 2022-06-22 18:16:38.429116
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == timedelta_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == timedelta_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == timedelta_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == timedelta_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:59.999999') == timedelta_module.timedelta(seconds=59, microseconds=999999)
    assert timedelta_parse('00:00:60.000000') == timedelta_module.timedelta(seconds=60)

# Generated at 2022-06-22 18:16:46.057575
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('2:5:3.5678998')) == '02:05:03.567899'


if PY2:
    import __builtin__ as builtins
else:
    import builtins

try:
    from contextlib import suppress
except ImportError: # Python < 3.4
    class suppress(object):
        """Context manager to suppress specified exceptions

        After the exception is suppressed, execution proceeds with the next
        statement following the with statement.

                 with suppress(FileNotFoundError):
                     os.remove(somefile)
        """

        def __init__(self, *exceptions):
            self._exceptions = exceptions

        def __enter__(self):
            pass


# Generated at 2022-06-22 18:16:51.281436
# Unit test for function timedelta_format
def test_timedelta_format():
    i = 0
    while True:
        timedelta = datetime_module.timedelta(hours=i)
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta
        i += 1
        if timedelta > datetime_module.timedelta(hours=10):
            break

# Generated at 2022-06-22 18:17:01.865248
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=4)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=0)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  milliseconds=4)
    )) == datetime_module

# Generated at 2022-06-22 18:17:03.683150
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(minutes=60)
    ) == '01:00:00.000000'

# Generated at 2022-06-22 18:17:07.197662
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-22 18:17:19.345536
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:17:29.356157
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=45)) == \
           '00:00:45.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=45,
                                                      microseconds=5000000)) == \
           '00:00:45.500000'

    assert timedelta_format(datetime_module.timedelta(minutes=45)) == \
           '00:45:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=45,
                                                      microseconds=5000000)) == \
           '00:45:00.500000'


# Generated at 2022-06-22 18:17:36.325961
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000
    )

# Generated at 2022-06-22 18:17:43.010572
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                  microseconds=987000)
    )) == datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                    microseconds=987000)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=9, minutes=42, seconds=42,
                                  microseconds=12000)
    )) == datetime_module.timedelta(hours=9, minutes=42, seconds=42,
                                    microseconds=12000)

# Generated at 2022-06-22 18:17:45.769502
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=10, hours=3, minutes=30,
                                          seconds=30, microseconds=404040)
    assert timedelta_format(timedelta) == '03:30:30.04040'


# Generated at 2022-06-22 18:17:57.307874
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=1000000)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=2,
                                                      microseconds=0)) == \
           '00:00:02.000000'

# Generated at 2022-06-22 18:18:08.117899
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.006000') == datetime_module.timedelta(
        microseconds=6000)
    assert timedelta_parse('0:0:1.006000') == datetime_module.timedelta(
        seconds=1, microseconds=6000)
    assert timedelta_parse('0:1:1.006000') == datetime_module.timedelta(
        minutes=1, seconds=1, microseconds=6000)
    assert timedelta_parse('1:1:1.006000') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=6000)

# Generated at 2022-06-22 18:18:20.328429
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1)
    )) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1)
    )) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=1)
    )) == datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:18:29.127210
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )) == '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(
        hours=36, minutes=50, seconds=20, microseconds=753948
    )) == '36:50:20.753948'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0
    )) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=9159
    )) == '00:00:00.009159'

# Generated at 2022-06-22 18:18:33.924203
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=3,
        minutes=3,
        seconds=3,
        microseconds=3
    )
    assert timedelta_format(timedelta) == '03:03:03.000003'



# Generated at 2022-06-22 18:18:35.140737
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        days=12, seconds=33, microseconds=55,
    )) == (
        '00:00:33.000055'
    )



# Generated at 2022-06-22 18:18:44.168522
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3, hours=20)) == \
           '20:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=3)) == \
           '00:00:02.000003'
    assert timedelta_format(datetime_module.timedelta(seconds=-2,
                                                      microseconds=-3)) == \
           '-00:00:02.000003'

# Generated at 2022-06-22 18:18:51.885062
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:04:05') == datetime_module.timedelta(hours=3,
                                                                    minutes=4,
                                                                    seconds=5)
    assert timedelta_parse('03:04:05.123456') == datetime_module.timedelta(hours=3,
                                                                           minutes=4,
                                                                           seconds=5,
                                                                           microseconds=123456)


# Generated at 2022-06-22 18:19:01.799090
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())
                           ) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        seconds=1)
                                            )
                           ) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        minutes=1)
                                            )
                           ) == datetime_module.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1)
                                            )
                           ) == datetime_module.timedelta(hours=1)
    assert timedelta_

# Generated at 2022-06-22 18:19:10.178768
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('0:0:0.000000')
    assert td == datetime_module.timedelta()
    td = timedelta_parse('1:2:3.000004')
    assert td == datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=4
    )

test_timedelta_parse()
del test_timedelta_parse

# Generated at 2022-06-22 18:19:13.900691
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from garlicsim.general_misc import string_tools
    for i in range(1000):
        s = string_tools.random_string(string_tools.DIGITS + '.')
        timedelta = timedelta_parse(s)

        assert s == timedelta_format(timedelta)

# Generated at 2022-06-22 18:19:23.462573
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00.0000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00.00000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00.000000000') == datetime_module.timedelta(hours=1)


# Generated at 2022-06-22 18:19:29.001904
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=5, minutes=2, seconds=10,
                                  microseconds=20)
    )) == datetime_module.timedelta(hours=5, minutes=2, seconds=10,
                                    microseconds=20)



# Generated at 2022-06-22 18:19:33.269241
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456000)) \
       == '01:02:03.456000'

test_timedelta_format()



# Generated at 2022-06-22 18:19:40.973904
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.123000')) == '01:02:03.123000'
    assert timedelta_format(timedelta_parse('1:2:3.1230')) == '01:02:03.123000'
    assert timedelta_format(timedelta_parse('1:2:3.123')) == '01:02:03.123000'
    assert timedelta_format(timedelta_parse('1:2:3.12')) == '01:02:03.120000'
    assert timedelta_format(timedelta_parse('1:2:3.1')) == '01:02:03.100000'

# Generated at 2022-06-22 18:19:52.818245
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3)) == '72:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == '00:00:00.000004'
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == '00:00:00.999999'
    if PY3:
        assert timedelta

# Generated at 2022-06-22 18:20:02.563571
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == (
        '01:02:03.456789'
    )
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=123456)) == (
        '00:00:00.123456'
    )
    assert timedelta_format(datetime_module.timedelta(hours=67,
                                                      minutes=89,
                                                      seconds=10,
                                                      microseconds=111213)) == (
        '67:89:10.111213'
    )


# Unit

# Generated at 2022-06-22 18:20:10.380091
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000004') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:20:17.740658
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_python_toolbox import _test_timedelta_format
    _test_timedelta_format(timedelta_format, timedelta_parse)


if PY3:
    import builtins
    exec_ = getattr(builtins, "exec")

    def reraise(exception, traceback=None):
        raise exception.with_traceback(traceback)

else:
    def exec_(code, globs=None, lcls=None):
        """Execute code in a namespace."""
        if globs is None:
            frame = sys._getframe(1)
            globs = frame.f_globals
            if lcls is None:
                lcls = frame.f_locals
            del frame
        elif lcls is None:
            lcls = gl

# Generated at 2022-06-22 18:20:28.936354
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456000)
    ) == '01:02:03.456000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=40000)
    ) == '01:02:03.040000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4000)
    ) == '01:02:03.004000'
    assert timedelta_parse('01:02:03.456000') == timedelta_parse(
        '01:02:03.456'
    ) == dat

# Generated at 2022-06-22 18:20:32.358624
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
                           == '01:02:03.123456'



# Generated at 2022-06-22 18:20:46.101906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('0:01:00.000001') == datetime_module.timedelta(
        minutes=1, microseconds=1)
    assert timedelta_parse('1:00:00.000001') == datetime_module.timedelta(
        hours=1, microseconds=1)
    assert timedelta_parse('1:01:00.000001') == datetime_module.timedelta(
        hours=1, minutes=1, microseconds=1)
    assert timedelta_parse('01:01:01.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1)



# Generated at 2022-06-22 18:20:55.171496
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=62)) == '00:01:02.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=2,
                                                      microseconds=10)) == '00:00:02.000010'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=2,
                                                      microseconds=10)) == '24:00:02.000010'
    assert timedelta_format(datetime_module.timedelta(microseconds=10)) == '00:00:00.000010'



# Generated at 2022-06-22 18:21:06.867165
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:21:17.716309
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(0, seconds=24 * 3600 * 1000000 - 1)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('24:00:00.000000') == datetime_module.timedelta(hours=24)
    assert timedelta_parse('48:00:00.000000') == datetime_module.timedelta(hours=48)

# Generated at 2022-06-22 18:21:28.407235
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_equal(first, second):
        assert first == second, '{!r} != {!r}'.format(first, second)

    assert_equal(timedelta_format(datetime_module.timedelta(seconds=0)),
                 '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
                 '00:00:01.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=60)),
                 '00:01:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=61)),
                 '00:01:01.000000')

# Generated at 2022-06-22 18:21:36.333086
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if sys.version_info < (3, 6):
        # This test is only meaningful on Python 3.6 and up
        return

    def test(s, expected_timedelta):
        assert timedelta_parse(s) == expected_timedelta

    test('00:00:00.000000', datetime_module.timedelta(0))
    test('12:34:56.789123',
         datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                   microseconds=789123))


# Generated at 2022-06-22 18:21:39.533298
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(4, 564649)) == \
                                                           '104:24:09.564649'



# Generated at 2022-06-22 18:21:50.618633
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                                                          '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.990000')) == \
                                                          '00:00:00.990000'
    assert timedelta_format(timedelta_parse('0:00:01.000000')) == \
                                                          '00:00:01.000000'
    assert timedelta_format(timedelta_parse('0:00:01.990000')) == \
                                                          '00:00:01.990000'

# Generated at 2022-06-22 18:21:59.069905
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=999)) == '00:00:00.000999'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'


# Generated at 2022-06-22 18:22:08.661813
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.004005')) == \
                                                   '01:02:03.004005'
    assert timedelta_format(timedelta_parse('1.02:03.004005')) == \
                                                 '01:02:03.004005'
    assert timedelta_format(timedelta_parse('01.02:03.004005')) == \
                                                 '01:02:03.004005'
    assert timedelta_format(timedelta_parse('1.02:03:004005')) == \
                                                 '01:02:03.004005'

# Generated at 2022-06-22 18:22:16.756553
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:22:27.882726
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        seconds=0
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('24:00:00.000000') == datetime_module.timedelta(
        days=1
    )