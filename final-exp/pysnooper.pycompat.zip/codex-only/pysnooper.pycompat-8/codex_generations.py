

# Generated at 2022-06-22 18:12:31.210010
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import __main__ as this_module
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 123456789)) == \
           '00:00:00.123456'
    assert timedelta_format(datetime_module.timedelta(0, 1, 23456789)) == \
           '00:00:01.234567'
    assert timedelta_format(datetime_module.timedelta(1, 23, 456789)) == \
           '24:00:00.456789'

    this_module.assert_raises(AssertionError, timedelta_format, 42)


# Generated at 2022-06-22 18:12:36.458218
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=6, hours=6,
                                                      minutes=6, seconds=6,
                                                      microseconds=6)) == \
           '06:06:06.000006'
    assert timedelta_format(datetime_module.timedelta(days=0, hours=0,
                                                      minutes=0, seconds=0,
                                                      microseconds=0)) == \
           '00:00:00.000000'

# Generated at 2022-06-22 18:12:46.971278
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == \
        datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == \
        datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == \
        datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == \
        datetime_module.timedelta(hours=1)

    assert timedelta_parse('00:00:01.000001') == \
        datetime_module.timedelta(0, 1, 1)
   

# Generated at 2022-06-22 18:12:54.616100
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:13:05.839786
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        0, 0, 1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        0, 1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        0, 60
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        3600
    )

# Generated at 2022-06-22 18:13:10.653607
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=5, minutes=5, seconds=5,
                                  microseconds=999999)
    )) == (datetime_module.timedelta(hours=5, minutes=5, seconds=5,
                                     microseconds=999999))



# Generated at 2022-06-22 18:13:15.722899
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(milliseconds=5000)
    assert timedelta_format(timedelta) == '00:00:05.000000'
    timedelta = datetime_module.timedelta(minutes=1,
                                          milliseconds=5000)
    assert timedelta_format(timedelta) == '00:01:05.000000'
    timedelta = datetime_module.timedelta(hours=1,
                                          minutes=1,
                                          milliseconds=5000)
    assert timedelta_format(timedelta) == '01:01:05.000000'
    timedelta = datetime_module.timedelta(days=1,
                                          hours=1,
                                          minutes=1,
                                          milliseconds=5000)

# Generated at 2022-06-22 18:13:25.217862
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import datetime
    assert timedelta_parse('0:0:0.000000') == datetime.timedelta()
    assert timedelta_parse('23:59:59.999999') == datetime.timedelta(days=1)
    assert timedelta_parse('00:00:00.1') == datetime.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.00001') == datetime.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000001') == datetime.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.1000000') == datetime.timedelta(microseconds=100)
    assert timedelta_parse('00:00:01.1000000') == datetime.timed

# Generated at 2022-06-22 18:13:30.307114
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        days=1,
        hours=2,
        minutes=3,
        seconds=4,
        microseconds=5,
    )
    assert timedelta_format(timedelta) == '26:03:04.000005'



# Generated at 2022-06-22 18:13:33.779180
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=3, minutes=4, seconds=5,
                                  microseconds=6)
    ) == '27:04:05.000006'



# Generated at 2022-06-22 18:13:36.914962
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('01:02:03.123456') ==
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123456))


# Generated at 2022-06-22 18:13:41.800189
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime
    timedelta = datetime.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                   microseconds=5)
    assert timedelta_format(timedelta) == '2:03:04.000005'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


# Generated at 2022-06-22 18:13:53.618403
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10)) == \
           '10:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=12)) == \
           '10:12:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      seconds=12)) == \
           '10:00:12.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      microseconds=12)) == \
           '10:00:00.000012'

# Generated at 2022-06-22 18:14:04.789295
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:14:11.938751
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.123456') == datetime_module.timedelta(0, 0, 123456)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:30:00.000000') == datetime_module.timedelta(0, 0, 0, 0, 30)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(0, 0, 0, 0, 60)
    assert timedelta_parse('1:00:01.000000') == datetime_module.timedelta(0, 1, 0, 0, 60)

# Generated at 2022-06-22 18:14:24.327451
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '00:00:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(seconds=0)

    s = '01:00:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(hours=1)

    s = '00:30:00.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(minutes=30)

    s = '00:00:10.000000'
    assert timedelta_parse(s) == datetime_module.timedelta(seconds=10)

    s = '00:00:00.000001'
    assert timedelta_parse(s) == datetime_module.timedelta(microseconds=1)


# Generated at 2022-06-22 18:14:26.817446
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.463789') == (
        datetime_module.timedelta(seconds=62, microseconds=463789))

# Generated at 2022-06-22 18:14:32.323754
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=147, hours=3,
                                          minutes=1, seconds=2,
                                          microseconds=3456789)
    assert timedelta_format(timedelta) == '03:01:02.3456789'



# Generated at 2022-06-22 18:14:36.205757
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(hours=4, minutes=3, seconds=2,
                                   microseconds=1)

    assert timedelta_parse(timedelta_format(td)) == td


# copied from six library, credit goes to them

# Generated at 2022-06-22 18:14:39.149718
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=123,
                                                      seconds=2,
                                                      microseconds=123456)) == \
                                                      '02:02:02.123456'



# Generated at 2022-06-22 18:14:46.081234
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def timedelta_parse_helper(x):
        return timedelta_parse(timedelta_format(x))
    assert timedelta_parse_helper(datetime_module.timedelta()) == datetime_module.timedelta()
    assert timedelta_parse_helper(datetime_module.timedelta(1)) == datetime_module.timedelta(1)
    assert timedelta_parse_helper(datetime_module.timedelta(1, 1)) == datetime_module.timedelta(1, 1)
    assert timedelta_parse_helper(datetime_module.timedelta(1, 1, 1)) == datetime_module.timedelta(1, 1, 1)

# Generated at 2022-06-22 18:14:50.862828
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:01:01.010000')
    time = (datetime_module.datetime.min + timedelta).time()
    assert time_isoformat(time, timespec='microseconds') == '01:01:01.010000'



# Generated at 2022-06-22 18:14:57.042634
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:01.000001') == datetime_module.timedelta(0, 1, 1)
    assert timedelta_parse('0:01:00.000001') == datetime_module.timedelta(0, 60, 1)
    assert timedelta_parse('1:00:00.000001') == datetime_module.timedelta(60 * 60, 1)



# Generated at 2022-06-22 18:15:07.149260
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Normal, simple cases:
    assert timedelta_parse('01:10:35.123456') == \
        datetime_module.timedelta(hours=1, minutes=10, seconds=35,
                                  microseconds=123456)
    assert timedelta_parse('00:00:00.000') == \
        datetime_module.timedelta(seconds=0)
    assert timedelta_parse('00:00:00.000') == \
        datetime_module.timedelta()

    # Edge cases:
    assert timedelta_parse('00:00:00.001') == \
        datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999') == \
        datetime_module.timedelta(microseconds=999)
    assert timedelta

# Generated at 2022-06-22 18:15:13.527356
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2, seconds=1, microseconds=5)
    )) == datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                    microseconds=5)

# Generated at 2022-06-22 18:15:24.011000
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                        '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1))

# Generated at 2022-06-22 18:15:34.820041
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=4, hours=17,
                                                      minutes=30, seconds=2,
                                                      microseconds=566)) == \
                            '17:30:02.000566'
    assert timedelta_format(datetime_module.timedelta(days=4, hours=17,
                                                      minutes=30, seconds=2,
                                                      microseconds=566)) == \
                            '17:30:02.000566'
    assert timedelta_format(datetime_module.timedelta(
        hours=2 ** 32 - 1, minutes=1, seconds=1,
        microseconds=1)) == '19:01:01.000001'


# Generated at 2022-06-22 18:15:39.525511
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                          minutes=7,
                                                          seconds=7,
                                                          microseconds=18))=='05:07:07.000018'



# Generated at 2022-06-22 18:15:48.745846
# Unit test for function timedelta_parse
def test_timedelta_parse():
    test_cases = [
        (datetime_module.timedelta(hours=22, minutes=23, seconds=24,
                                   microseconds=1234),
         '22:23:24.001234'),
        (datetime_module.timedelta(microseconds=1234), '00:00:00.001234'),
        (datetime_module.timedelta(microseconds=123), '00:00:00.000123'),
        (datetime_module.timedelta(microseconds=12), '00:00:00.000012'),
        (datetime_module.timedelta(microseconds=1), '00:00:00.000001'),
    ]
    for datetime_timedelta, text in test_cases:
        assert timedelta_parse(text) == datetime_timedelta

# Generated at 2022-06-22 18:15:54.714068
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('3:36:32.751222') == datetime_module.timedelta(
        hours=3, minutes=36, seconds=32, microseconds=751222,
    )
    assert timedelta_parse('0:00:00.020') == datetime_module.timedelta(
        microseconds=20,
    )
    assert timedelta_format(datetime_module.timedelta(
        hours=3, minutes=36, seconds=32, microseconds=751222,
    )) == '3:36:32.751222'

# Generated at 2022-06-22 18:16:05.692914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('1:2:3.0') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )

# Generated at 2022-06-22 18:16:12.480019
# Unit test for function timedelta_format
def test_timedelta_format():
    test_start_timedelta = datetime_module.timedelta(
        hours=0,
        minutes=2,
        seconds=36,
        microseconds=123456
    )
    assert timedelta_format(test_start_timedelta) == '00:02:36.123456'
    assert timedelta_parse(timedelta_format(test_start_timedelta)) == test_start_timedelta

# Generated at 2022-06-22 18:16:16.587971
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=6, seconds=27, microseconds=13000
    )) == '01:06:27.0130000'



# Generated at 2022-06-22 18:16:20.327969
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '03:25:45.000005'
    timedelta = datetime_module.timedelta(hours=3, minutes=25, seconds=45,
                                          microseconds=5)
    assert timedelta_parse(s) == timedelta



# Generated at 2022-06-22 18:16:30.451310
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=100)) == \
                                                                '100:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=100)) == \
                                                            '00:01:40'
    assert timedelta_format(datetime_module.timedelta(minutes=-100)) == \
                                                            '-01:40:00'
    assert timedelta_format(datetime_module.timedelta(milliseconds=500)) == \
                                                            '00:00:00.500000'
    assert timedelta_format(datetime_module.timedelta(microseconds=500)) == \
                                                            '00:00:00.000500'

# Generated at 2022-06-22 18:16:35.420337
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:3:12.345600')
    assert timedelta.total_seconds() == 1 * 60 * 60 + 3 * 60 + 12 + \
                                        345600 / 1000000


try:
    from collections.abc import Mapping
except ImportError: # Python 2.7
    from collections import Mapping

# Generated at 2022-06-22 18:16:39.428589
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      milliseconds=450,
                                                      microseconds=1450)) == \
           '01:02:03.045450'


# Generated at 2022-06-22 18:16:46.849755
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:34.123456') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=34, microseconds=123456)

    assert timedelta_parse('1:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)

    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)

    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)


# Generated at 2022-06-22 18:16:58.228729
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
           '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(seconds=86401,
                                                      milliseconds=500)) == \
           '24:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      milliseconds=500)) == \
           '24:00:00.500000'


# Test for timed

# Generated at 2022-06-22 18:17:05.502471
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=1, seconds=1)
    assert timedelta_format(td) == '24:00:01.000000'
    td2 = timedelta_parse(timedelta_format(td))
    assert td == td2


if PY3:
    from collections import UserList
    from collections import UserDict
    from collections import UserString
else:
    from UserList import UserList
    from UserDict import UserDict
    from UserString import UserString

# Generated at 2022-06-22 18:17:12.183083
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4)) == '01:02:03.000004'



# Generated at 2022-06-22 18:17:19.216567
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5,
                                                      seconds=5)) == '00:05:05.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5,
                                                      seconds=5,
                                                      microseconds=555)) == '00:05:05.000555'
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'

# Generated at 2022-06-22 18:17:29.313675
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
        '00:01:00.000000'

# Generated at 2022-06-22 18:17:33.800674
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:00:00:000000') == datetime_module.timedelta(
            hours=1)
    assert timedelta_parse('1:0:0:0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:00:00:000001') == datetime_module.timedelta(
        hours=1, microseconds=1)



# Generated at 2022-06-22 18:17:41.219495
# Unit test for function timedelta_format
def test_timedelta_format():
    
    assert timedelta_format(datetime_module.timedelta(hours=10)) == \
                                                        '10:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=10,
                                                      microseconds=10000)) == \
                                                        '00:10:00.010000'



# Generated at 2022-06-22 18:17:46.945317
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'

    # Checking that it's reversible:
    for p in range(4000):
        dt = datetime_module.timedelta(milliseconds=p)
        assert timedelta_parse(timedelta_format(dt)) == dt



# Generated at 2022-06-22 18:17:51.629551
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta, string in ( 
        (datetime_module.timedelta(hours=11, minutes=42, seconds=45,
                                   microseconds=938882),
         '11:42:45.093888'),
    ):
        assert timedelta_format(timedelta) == string



# Generated at 2022-06-22 18:17:56.546256
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (datetime_module.timedelta(milliseconds=i)
                      for i in range(10000)):
        text = timedelta_format(timedelta)
        assert type(text) is text_type
        timedelta_ = timedelta_parse(text)
        assert timedelta == timedelta_

# Generated at 2022-06-22 18:17:59.733608
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == \
           '00:00:00.000001'


# Generated at 2022-06-22 18:18:09.368792
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(1, 1e-6)
    assert timedelta_parse('01:00:00.000010') == datetime_module.timedelta(1, 1e-5)

# Generated at 2022-06-22 18:18:15.296971
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:00:00.000001') == datetime_module.timedelta(0, 0,
                                                                          1)
    assert timedelta_parse('0:00:00.999999') == datetime_module.timedelta(0, 0,
                                                                          999999)
    assert timedelta_parse('0:00:00.100000') == datetime_module.timedelta(0, 0,
                                                                          100000)
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:01:00.000000') == datetime_module.tim

# Generated at 2022-06-22 18:18:26.279958
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=1,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:01:00.000000'

# Generated at 2022-06-22 18:18:37.853506
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'

# Generated at 2022-06-22 18:18:48.747809
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=8, minutes=42, seconds=59,
                                          microseconds=9876)
    assert (timedelta_format(timedelta) ==
            '08:42:59.009876')


if PY2:
    from Queue import Queue, Full
else:
    from queue import Queue, Full

if PY3:
    from urllib.request import urlopen
else:
    from urllib2 import urlopen

if PY3:
    from io import StringIO
else:
    from io import StringIO

if PY3:
    from io import BytesIO
else:
    try:
        from cStringIO import StringIO as BytesIO
    except ImportError:
        from StringIO import StringIO as Bytes

# Generated at 2022-06-22 18:18:56.694448
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-22 18:19:05.859858
# Unit test for function timedelta_format
def test_timedelta_format():

    time = time_isoformat(datetime_module.time(1, 2, 3, 40000))
    assert time == '01:02:03.040000'

    time = time_isoformat(datetime_module.time(1, 2, 3, 400000))
    assert time == '01:02:03.400000'

    time = time_isoformat(datetime_module.time(1, 2, 3, 4000))
    assert time == '01:02:03.004000'

    time = time_isoformat(datetime_module.time(1, 2, 3, 40))
    assert time == '01:02:03.000040'

    time = time_isoformat(datetime_module.time(1, 2, 3, 4))
    assert time == '01:02:03.000004'

    time

# Generated at 2022-06-22 18:19:09.223370
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta.max) == (
        '23:59:59.999999'
    )


# Generated at 2022-06-22 18:19:12.614362
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=100500)) == \
           '01:02:03.100500'



# Generated at 2022-06-22 18:19:18.168906
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=7)) == \
                                                            '07:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, seconds=4)) == \
                                                            '05:00:04.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=4, seconds=2, microseconds=100
    )) == '05:04:02.000100'



# Generated at 2022-06-22 18:19:23.129577
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                      '00:00:00.000000'
    assert timedelta_format(timedelta_parse('14:23:12.345678')) == \
                                                      '14:23:12.345678'



# Generated at 2022-06-22 18:19:28.696116
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=23, minutes=12, seconds=34, microseconds=123456
    ))) == datetime_module.timedelta(
        days=1, hours=23, minutes=12, seconds=34, microseconds=123456
    )

# Generated at 2022-06-22 18:19:32.630129
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5)
    assert timedelta_format(timedelta) == '02:03:04.000005'


# Generated at 2022-06-22 18:19:40.576241
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:00:00.000000')) == \
                                                           '01:00:00.000000'
    assert timedelta_format(timedelta_parse('00:01:00.000000')) == \
                                                           '00:01:00.000000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == \
                                                           '00:00:01.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
                                                           '00:00:00.000001'

# Generated at 2022-06-22 18:19:52.682549
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_equal(x, y):
        assert x == y, (x, y)

    assert_equal(timedelta_format(datetime_module.timedelta(seconds=0)),
                 '00:00:00.000000')

    assert_equal(timedelta_format(datetime_module.timedelta(seconds=59)),
                 '00:00:59.000000')

    assert_equal(timedelta_format(datetime_module.timedelta(minutes=59)),
                 '00:59:00.000000')

    assert_equal(timedelta_format(datetime_module.timedelta(hours=23)),
                 '23:00:00.000000')


# Generated at 2022-06-22 18:19:59.154475
# Unit test for function timedelta_format
def test_timedelta_format(): # pragma: no cover
    dt = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=4)
    assert timedelta_format(dt) == '01:02:03.000004'
    dt = datetime_module.timedelta(hours=23, minutes=59, seconds=58,
                                   microseconds=999999)
    assert timedelta_format(dt) == '23:59:58.999999'


# Generated at 2022-06-22 18:20:04.858851
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=4,
                                  microseconds=80)
    ) == '01:02:04.000080'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=4,
                                  microseconds=10)
    ) == '01:02:04.000010'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=4,
                                  microseconds=5)
    ) == '01:02:04.000005'

# Generated at 2022-06-22 18:20:14.770306
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(1),
        datetime_module.timedelta(1, 2),
        datetime_module.timedelta(1, 2, 3),
        datetime_module.timedelta(1, 2, 3, 4),
        datetime_module.timedelta(1, 2, 3, 4, 5),
        datetime_module.timedelta(1, 2, 3, 4, 5, 6),
        datetime_module.timedelta(1, 2, 3, 4, 5, 6, 7),
    ):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-22 18:20:21.400241
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789
    )

    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)

# Generated at 2022-06-22 18:20:34.361829
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
           '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(microseconds=99)) == \
           '00:00:00.000099'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=101)) == \
           '00:00:00.000101'

# Generated at 2022-06-22 18:20:42.790210
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=456789)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

    timedelta = datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:20:54.718951
# Unit test for function timedelta_format
def test_timedelta_format():
    # Basic test:
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
                                                      '01:02:03.000004'

    # Test with some weird numbers:
    assert timedelta_format(datetime_module.timedelta(
        hours=2*24 + 3,
        minutes=2*60 + 4,
        seconds=6 + 50 + 40,
        microseconds=1
    )) == '51:06:50.000001'

    # Test with a zero timedelta:
    assert timedelta_format(datetime_module.timedelta(0)) == \
                                                          '00:00:00.000000'

    # Test with a zero microseconds timedelta

# Generated at 2022-06-22 18:20:59.883018
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:34:56.123456') == datetime_module.timedelta(hours=2, minutes=34,
                                                                          seconds=56,
                                                                          microseconds=123456)



# Generated at 2022-06-22 18:21:08.812677
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10)) == \
           '00:00:10.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=10,
                                                      microseconds=10)) == \
           '00:00:10.000010'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1,
                                                      microseconds=10)) == \
           '00:01:00.000010'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'

# Generated at 2022-06-22 18:21:19.279064
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) ==\
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) ==\
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) ==\
                                                              '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) ==\
                                                              '00:01:00.000000'

# Generated at 2022-06-22 18:21:30.075199
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=34,
                                                      seconds=23,
                                                      microseconds=123456)) == '10:34:23.123456'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=10,
                                                      seconds=0,
                                                      microseconds=123456)) == '00:10:00.123456'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=0,
                                                      seconds=30,
                                                      microseconds=123456)) == '00:00:30.123456'

# Generated at 2022-06-22 18:21:32.723181
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'



# Generated at 2022-06-22 18:21:41.115807
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse('12:34:56.123456')
    timedelta_parse('34:56.123456')
    timedelta_parse('56.123456')
    timedelta_parse('0.123456')
    timedelta_parse('.123456')
    timedelta_parse('00:00:00.000000')
    timedelta_parse('00:0:0.00')
    timedelta_parse('0:0:0.00')
    timedelta_parse('0:0:0.0')
    timedelta_parse('0:0:0')
    timedelta_parse('0:0')
    timedelta_parse('0')

test_timedelta_parse()

# Generated at 2022-06-22 18:21:51.454165
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:22:04.088360
# Unit test for function timedelta_format
def test_timedelta_format():
    from random import randint
    for _ in range(100):
        td = datetime_module.timedelta(seconds=randint(-100000, 100000))
        result = timedelta_format(td)
        assert timedelta_parse(result) == td


if PY3:
    from io import StringIO, BytesIO
else:
    from io import BytesIO as _BytesIO
    
    # Python 2's StringIO is used for reading and writing text;
    # io.BytesIO is used only for binary data.
    class StringIO(_BytesIO):
        def write(self, s):
            if isinstance(s, bytes):
                raise TypeError("unicode argument expected, got '%s'" % s.__class__.__name__)
            _BytesIO.write(self, s.encode())
        

# Generated at 2022-06-22 18:22:09.556971
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=19, minutes=53, seconds=37,
                                          microseconds=173219)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-22 18:22:13.666883
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=5, minutes=12, seconds=15,
                                  microseconds=123456)
    )) == datetime_module.timedelta(hours=5, minutes=12, seconds=15,
                                    microseconds=123456)



# Generated at 2022-06-22 18:22:26.064252
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:1.000010') == datetime_module.timedelta(0, 1, 10)
    assert timedelta_parse('0:0:1.000010') == datetime_module.timedelta(0, 1, 10)
    assert timedelta_parse('0:1:1.000010') == datetime_module.timedelta(0, 61, 10)
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)