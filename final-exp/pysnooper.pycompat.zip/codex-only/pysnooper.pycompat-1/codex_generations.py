

# Generated at 2022-06-22 18:12:26.734914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789)
    assert timedelta_parse('1:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)



# Generated at 2022-06-22 18:12:38.422945
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def t(args, result):
        assert timedelta_parse(args) == result
    t('1:00:00.000000', datetime_module.timedelta(hours=1))
    t('0:00:00.000001', datetime_module.timedelta(microseconds=1))
    t('0:00:01.000001', datetime_module.timedelta(seconds=1, microseconds=1))
    t('0:01:01.000001', datetime_module.timedelta(minutes=1,
                                                  seconds=1,
                                                  microseconds=1))
    t('1:01:01.000001', datetime_module.timedelta(hours=1,
                                                  minutes=1,
                                                  seconds=1,
                                                  microseconds=1))

# Generated at 2022-06-22 18:12:43.001185
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == '00:00:00.001234'



# Generated at 2022-06-22 18:12:48.341530
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
                                                    "00:00:00.000000"

    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                    "00:00:00.000001"

    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    "01:00:00.000000"

    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == \
                                                    "01:00:00.000000"


# Generated at 2022-06-22 18:12:59.245417
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(12345)) == (
        '03:25:45.000000'
    )
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == (
        '00:00:00.000004'
    )
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )) == '01:01:01.000001'



# Generated at 2022-06-22 18:13:03.173788
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=6,
                                          seconds=7, microseconds=89)
    assert timedelta_format(timedelta) == '05:06:07.000089'



# Generated at 2022-06-22 18:13:09.976018
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == '00:00:00.000002'


# Generated at 2022-06-22 18:13:19.580844
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('23:59:59.999999') == datetime_module.timedelta(
        days=1
    )
    assert timedelta_parse('01:02:03.000400') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400
    )
    assert timedelta_parse('03:03:03.000444') == datetime_module.timedelta(
        hours=3, minutes=3, seconds=3, microseconds=444
    )

# Generated at 2022-06-22 18:13:27.425737
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:13:37.249272
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:01:00') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000001') == \
                                          datetime_module.timedelta

# Generated at 2022-06-22 18:13:46.108779
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('11:22:33.123456') == \
           datetime_module.timedelta(hours=11, minutes=22, seconds=33,
                                     microseconds=123456)
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(seconds=0)



# Generated at 2022-06-22 18:13:56.048914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # Test negative
    assert timedelta_parse('-1:00:00.123456') == -datetime_module.timedelta(hours=1)
    assert timedelta_parse('-01:00:00.123456') == -datetime_module.timedelta(hours=1)
    assert timedelta_parse('-1:00:00.123456') == -datetime_module.timedelta(hours=1)
    assert timedelta_parse('-01:00:00.123456') == -datetime_module.timedelta(hours=1)
    assert timedelta_parse('-1:00:00.123456') == -datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:14:05.950614
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:01:00.000073') == datetime_module.timedelta(
        minutes=1, microseconds=73
    )
    assert timedelta_parse('00:01:00.000073') == datetime_module.timedelta(
        minutes=1, microseconds=73
    )
    assert timedelta_parse('34:17:00.000000') == datetime_

# Generated at 2022-06-22 18:14:14.476125
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        seconds=0, microseconds=0
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        seconds=0, microseconds=1
    )
    assert timedelta_parse('00:00:00.000009') == datetime_module.timedelta(
        seconds=0, microseconds=9
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        seconds=0, microseconds=10
    )
    assert timedelta_parse('00:00:00.000099') == datetime_module.timedelta(
        seconds=0, microseconds=99
    )


# Generated at 2022-06-22 18:14:19.747149
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3, hours=10,
                                              minutes=12, seconds=13,
                                              microseconds=156789)) == \
                                              '10:12:13.156789'


# Generated at 2022-06-22 18:14:29.534514
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'

# Generated at 2022-06-22 18:14:34.779928
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '01:01:01.123456'

    assert timedelta_format(datetime_module.timedelta.max) == \
                                                        '+999999999:59:59.999999'
    assert timedelta_format(datetime_module.timedelta.min) == \
                                                        '-999999999:59:59.999999'
    
    

# Generated at 2022-06-22 18:14:42.221240
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=10, minutes=5, seconds=30,
                                  microseconds=123456)
    ) == '10:05:30.123456'

    assert timedelta_format(
        datetime_module.timedelta(hours=11, minutes=21, seconds=51,
                                  microseconds=800000)
    ) == '11:21:51.800000'

    assert timedelta_format(
        datetime_module.timedelta(minutes=2, seconds=30)
    ) == '00:02:30.000000'



# Generated at 2022-06-22 18:14:52.217563
# Unit test for function timedelta_format
def test_timedelta_format():
    from .compatibility.test_case import TestCase
    from .context_manager import temp_file
    from . import temp_file_tools

    class MyTestCase(TestCase):
        def test_timedelta_format(self):
            self.assertEqual(timedelta_format(datetime_module.timedelta(
                hours=1, minutes=2, seconds=3, microseconds=456
            )), '01:02:03.000456')

    with temp_file_tools.temp_file_containing('', suffix='.py') as path:
        temp_file_tools.run_python_file(path, MyTestCase)

# Generated at 2022-06-22 18:15:02.798690
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-24)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-23)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-22)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0)) == '00:00:00.000000'

# Generated at 2022-06-22 18:15:10.801335
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('01:02:03.000001')) == \
                                                        '01:02:03.000001'
    assert timedelta_format(timedelta_parse('30:12:59.999000')) == \
                                                        '30:12:59.999000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == \
                                                        '00:00:01.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                        '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000001')) == \
                                                        '00:00:00.000001'
    assert timed

# Generated at 2022-06-22 18:15:15.433459
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('3:53:53.030201') == timedelta_module.timedelta(
                hours=3, minutes=53, seconds=53, microseconds=30201)

# Generated at 2022-06-22 18:15:24.620906
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:15:35.050722
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           time_isoformat(datetime_module.time(0, 0, 1, 0),
                          timespec='microseconds')
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400500
    )) == '01:02:03.400500'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=1
    )) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=1000000
    )) == '00:00:01.000000'



# Generated at 2022-06-22 18:15:38.066180
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4000)
    ) == '01:02:03.004000'



# Generated at 2022-06-22 18:15:43.916543
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def roundtrip(td):
        assert timedelta_parse(timedelta_format(td)) == td

    roundtrip(datetime_module.timedelta(seconds=0.123456))
    roundtrip(datetime_module.timedelta(seconds=-0.123456))
    roundtrip(datetime_module.timedelta(seconds=-1.123456))
    roundtrip(datetime_module.timedelta(seconds=1.123456))
    roundtrip(datetime_module.timedelta(hours=3, minutes=4, seconds=7,
                                        microseconds=123456))

# Generated at 2022-06-22 18:15:46.303184
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:00.000001') == \
           datetime_module.timedelta(minutes=1, seconds=0, microseconds=1)

# Generated at 2022-06-22 18:15:49.398606
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=8,
                                                      seconds=7,
                                                      microseconds=65432)) \
           == '09:08:07.006543'



# Generated at 2022-06-22 18:15:56.536526
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=40005)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                          microseconds=999999)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    timedelta = datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                          microseconds=0)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-22 18:16:05.610836
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=50)) == '00:00:50.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3600)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=500500)) == '00:00:00.500500'



# Generated at 2022-06-22 18:16:18.381059
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.5,
                                                      microseconds=400)) == '00:00:01.500400'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=400)) == '00:00:01.000400'
    assert timedelta_format(datetime_module.timedelta(seconds=11,
                                                      microseconds=4)) == '00:00:11.000004'

# Generated at 2022-06-22 18:16:26.987568
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    assert timedelta_parse('1:02:03.000004') == timedelta


if sys.version_info[:2] >= (3, 7):
    from importlib import metadata
else:
    import importlib_metadata as metadata

try:
    from importlib import resources
except ImportError:
    import importlib_resources as resources

# Generated at 2022-06-22 18:16:30.900062
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(hours=12, minutes=34,
                                                  seconds=56,
                                                  microseconds=789012))
    assert result == '12:34:56.789012'



# Generated at 2022-06-22 18:16:40.885127
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_timing import assert_almost_equal
    assert_almost_equal(
        timedelta_format(datetime_module.timedelta(microseconds=0)),
        timedelta_parse(timedelta_format(datetime_module.timedelta(0))),
        places=5
    )
    assert_almost_equal(
        timedelta_format(datetime_module.timedelta(microseconds=4)),
        timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 0, 4))),
        places=5
    )

# Generated at 2022-06-22 18:16:51.914615
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(0, 0, 123456)

    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=123456)

# Generated at 2022-06-22 18:16:58.408814
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing.supertypetest import supertype_test
    supertype_test(datetime_module.timedelta, timedelta_parse, timedelta_format)


if not PY3:
    try:
        from cPickle import loads, dumps
    except ImportError:
        from pickle import loads, dumps
else:
    try:
        from dill import loads, dumps
    except ImportError:
        from pickle import loads, dumps

# Generated at 2022-06-22 18:17:01.563348
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:37:30.100000') == datetime_module.timedelta(
        hours=1, minutes=37, seconds=30, microseconds=100000
    )



# Generated at 2022-06-22 18:17:09.256294
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('5:02:03.040050') == datetime_module.timedelta(
        hours=5, minutes=2, seconds=3, milliseconds=40, microseconds=50
    )
    assert timedelta_parse('2:03.040050') == datetime_module.timedelta(
        minutes=2, seconds=3, milliseconds=40, microseconds=50
    )
    assert timedelta_parse('3.040050') == datetime_module.timedelta(
        seconds=3, milliseconds=40, microseconds=50
    )

# Generated at 2022-06-22 18:17:15.426792
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=5, minutes=4, seconds=3,
                                  microseconds=555555)
    ) == '05:04:03.555555'



# Generated at 2022-06-22 18:17:27.651618
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta in (
        datetime_module.timedelta(0),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(microseconds=1),
        datetime_module.timedelta(microseconds=999999),
        datetime_module.timedelta(hours=1),
        datetime_module.timedelta(minutes=1),
        datetime_module.timedelta(days=1),
        datetime_module.timedelta(weeks=1),
        datetime_module.timedelta(seconds=1234567890),
    ):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:17:32.666278
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(2, 3, 4, 5)
    assert time_isoformat(time, timespec='microseconds') == '02:03:04.000005'

    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
           '02:03:04.000005'

# Generated at 2022-06-22 18:17:41.499008
# Unit test for function timedelta_parse
def test_timedelta_parse():
    x = timedelta_parse('2:3:4.123456')
    assert timedelta_format(x) == '02:03:04.123456'
    for i in range(1000000):
        assert timedelta_parse(timedelta_format(x)) == x
    assert timedelta_parse('12:34:56.404040') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=404040)



# Generated at 2022-06-22 18:17:48.656120
# Unit test for function timedelta_parse
def test_timedelta_parse():
    tests = [
        ('00:00:00.000001', 1),
        ('00:00:00.000100', 100),
        ('00:00:00.001000', 1000),
        ('00:00:00.010000', 10000),
        ('00:00:00.100000', 100000),
        ('00:00:01.000000', 1000000),
        ('00:01:00.000000', 60000000),
        ('01:00:00.000000', 3600000000),
    ]
    for s, microseconds in tests:
        assert timedelta_parse(s).microseconds == microseconds


if sys.version_info[:2] >= (3, 5):
    from typing import Any as _Any
    Any = _Any

# Generated at 2022-06-22 18:17:58.290105
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == \
           datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:01:01.000000') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1)

# Generated at 2022-06-22 18:18:08.619098
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') ==\
        datetime_module.timedelta(seconds=1 + 60 + 3600, microseconds=1)
    assert timedelta_format(timedelta_parse('1:1:1.000001')) == '01:01:01.000001'


if PY3:
    from reprlib import repr as repr_fallback
else:
    from repr import repr as repr_fallback


try:
    from reprlib import recursive_repr as recursive_repr_fallback
except ImportError:
    recursive_repr_fallback = repr_fallback



try:
    from contextlib import nullcontext
except ImportError:
    from contextlib import contextmanager
    @contextmanager
    def nullcontext(enter_result=None):
        yield enter

# Generated at 2022-06-22 18:18:20.790804
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=567)) == \
           '02:03:04.00567'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=0)) == \
           '02:03:04.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=0, seconds=0, microseconds=0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999)) == \
           '23:59:59.999999'

# Generated at 2022-06-22 18:18:29.407332
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
                                                            datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 1))) == \
                                                            datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0, 1, 100))) == \
                                                            datetime_module.timedelta(0, 0, 1, 100)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 1, 0))) == \
                                                            datetime_module.timedelta(0, 1, 0)

# Generated at 2022-06-22 18:18:40.642640
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=17)
    )) == datetime_module.timedelta(hours=1, minutes=17)

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=1, hours=1, minutes=17)
    )) == datetime_module.timedelta(days=1, hours=1, minutes=17)

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(days=1, hours=1, minutes=17, seconds=4)
    )) == datetime_module.timedelta(days=1, hours=1, minutes=17, seconds=4)


# Generated at 2022-06-22 18:18:53.170596
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:19:03.171326
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=0, minutes=0, microseconds=0)
    assert timedelta_format(td) == '00:00:00.000000'
    assert timedelta_format(td + td) == '00:00:00.000000'
    assert timedelta_format(td + td - td) == '00:00:00.000000'

    td = datetime_module.timedelta(hours=0, minutes=0, seconds=0)
    assert timedelta_format(td) == '00:00:00.000000'
    assert timedelta_format(td + td) == '00:00:00.000000'
    assert timedelta_format(td + td - td) == '00:00:00.000000'


# Generated at 2022-06-22 18:19:15.331506
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123456)
    assert timedelta_parse('01:02:03.123') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=123000)
    assert timedelta_parse('01:02:03') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)

# Generated at 2022-06-22 18:19:17.884659
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-22 18:19:26.790632
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:11:12.123456') == datetime_module.timedelta(
        hours=10, minutes=11, seconds=12, microseconds=123456
    )
    assert timedelta_parse('10:11:12.000000') == datetime_module.timedelta(
        hours=10, minutes=11, seconds=12, microseconds=0
    )
    assert timedelta_parse('10:11:12') == datetime_module.timedelta(
        hours=10, minutes=11, seconds=12, microseconds=0
    )



# Generated at 2022-06-22 18:19:35.246065
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3)) == \
                                                                    '05:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3,
                                                      seconds=7)) == \
                                                                    '05:03:07.000000'
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=3,
                                                      seconds=7,
                                                      microseconds=80000)) == \
                                                                    '05:03:07.080000'



# Generated at 2022-06-22 18:19:42.347066
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00:000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00:000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00:000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00:000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00:001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-22 18:19:50.361710
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.999999') == datetime_module.timedelta(microseconds=999999)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == dat

# Generated at 2022-06-22 18:19:55.746574
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                          microseconds=1)
    assert timedelta_format(timedelta) == '01:01:01.000001'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:20:05.574518
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
           datetime_module.timedelta(0)
    assert timedelta_parse('01:00:00.000000') == \
           datetime_module.timedelta(hours=1)
    assert timedelta_parse('01:01:00.000000') == \
           datetime_module.timedelta(hours=1, minutes=1)
    assert timedelta_parse('01:01:01.000000') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1)
    assert timedelta_parse('01:01:01.000001') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=1)

# Generated at 2022-06-22 18:20:13.256401
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:2:3.000000')
    assert timedelta.microseconds == 0
    assert timedelta.seconds == 1*3600 + 2*60 + 3
    assert timedelta.days == 0

    timedelta = timedelta_parse('1:2:3.123456')
    assert timedelta.microseconds == 123456
    assert timedelta.seconds == 1*3600 + 2*60 + 3
    assert timedelta.days == 0


# Generated at 2022-06-22 18:20:26.047341
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(10, 200)) == \
                                                             '00:00:10.002000'
    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=4,
                                                      microseconds=500)) == \
                                                             '00:03:04.000500'
    assert timedelta_format(datetime_module.timedelta(hours=10, minutes=34,
                                                      seconds=41,
                                                      microseconds=56)) == \
                                                             '10:34:41.000056'

# Generated at 2022-06-22 18:20:36.897478
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)
    assert timedelta_parse('1:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)
    assert timedelta_parse('01:2:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)

# Generated at 2022-06-22 18:20:42.482049
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_example = datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_format(timedelta_example) == '01:02:03.000004'


# Generated at 2022-06-22 18:20:54.618708
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('24:00:00.000000') == datetime_module.timedelta(
        hours=24
    )
    assert timedelta_parse('00:10:00.000000') == datetime_module.timedelta(
        minutes=10
    )
    assert timedelta_parse('00:00:05.000000') == datetime_module.timedelta(
        seconds=5
    )
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(
        seconds=0
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )

# Generated at 2022-06-22 18:21:06.620979
# Unit test for function timedelta_parse
def test_timedelta_parse():
    '''This tests `timedelta_parse` and `timedelta_format` against each other.'''

# Generated at 2022-06-22 18:21:12.748279
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                   microseconds=999999)
    assert timedelta_format(td) == '23:59:59.999999'


# Generated at 2022-06-22 18:21:20.081302
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(
        microseconds=10000)
    assert timed

# Generated at 2022-06-22 18:21:30.309045
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000001') == \
           timedelta_parse('00:00:00.0000010') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.01') == \
           datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:01') == \
           datetime_module.timedelta(microseconds=1000000)
    assert timedelta_parse('00:01') == \
           datetime_module.timedelta(microseconds=60000000)

# Generated at 2022-06-22 18:21:39.864282
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:02.000001') == datetime_module.timedelta(
        seconds=62, microseconds=1)
    assert timedelta_parse('0:23:57.989898') == datetime_module.timedelta(
        minutes=23, seconds=57, microseconds=989898)
    assert timedelta_parse('1:23:57.989898') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=57, microseconds=989898)
    assert timedelta_parse('123:57.989898') == datetime_module.timedelta(
        hours=123, minutes=57, seconds=0, microseconds=989898)
    assert timedelta_parse('123:57:98.989898') == datetime

# Generated at 2022-06-22 18:21:50.821419
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)

# Generated at 2022-06-22 18:22:03.202300
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:22:09.824910
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = time_isoformat(
        datetime_module.time(10, 11, 12, 123456)
    )
    assert timedelta_parse(time) == datetime_module.timedelta(
      hours=10, minutes=11, seconds=12, microseconds=123456
    )

# Generated at 2022-06-22 18:22:14.846747
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta, = map(timedelta_parse,
                     ('00:00:00.123456', '00:00:00.123456',
                      '00:00:00.000000'))
    assert timedelta.seconds == 0
    assert timedelta.microseconds == 123456
    timedelta, = map(timedelta_parse,
                     ('00:00:01.000000', '00:00:01.000000',
                      '00:00:01.000000'))
    assert timedelta.seconds == 1
    assert timedelta.microseconds == 0
    timedelta, = map(timedelta_parse,
                     ('00:01:00.000000', '00:01:00.000000',
                      '00:01:00.000000'))
    assert timedelta.seconds == 60
    assert timedelta.microseconds == 0
   

# Generated at 2022-06-22 18:22:18.361906
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.012345') == datetime_module.timedelta(
        minutes=1, seconds=2, microseconds=12345)



# Generated at 2022-06-22 18:22:22.382166
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=3, hours=5, minutes=23, seconds=11,
                                   microseconds=567)
    assert timedelta_format(td) == '123:23:11.00567'

