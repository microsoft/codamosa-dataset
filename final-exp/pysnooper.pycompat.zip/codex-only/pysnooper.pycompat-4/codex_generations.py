

# Generated at 2022-06-22 18:12:20.835037
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                   microseconds=56789)
    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-22 18:12:24.335493
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=4, minutes=30, seconds=1,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '04:30:01.123456'


# Generated at 2022-06-22 18:12:33.413515
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    assert timedelta_format(datetime_module.timedelta(seconds=123)) == \
           '00:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=456789
    )) == '01:02:03.456789'
    with pytest.raises(AssertionError):
        timedelta_format('abc')
    with pytest.raises(NotImplementedError):
        timedelta_format(datetime_module.timedelta(seconds=123),
                         timespec='milliseconds')



# Generated at 2022-06-22 18:12:45.388328
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:12:54.077226
# Unit test for function timedelta_format
def test_timedelta_format():
    zeroth_timedelta = datetime_module.timedelta()
    assert timedelta_format(zeroth_timedelta) == '00:00:00.000000'

    first_timedelta = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(first_timedelta) == '00:00:00.000001'

    second_timedelta = datetime_module.timedelta(microseconds=1000)
    assert timedelta_format(second_timedelta) == '00:00:00.001000'

    third_timedelta = datetime_module.timedelta(microseconds=3333333333)
    assert timedelta_format(third_timedelta) == '00:00:33.333333'


# Generated at 2022-06-22 18:13:03.083102
# Unit test for function timedelta_format
def test_timedelta_format():
    from python_toolbox import cute_testing
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'

# Generated at 2022-06-22 18:13:07.332559
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                        microseconds=456)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:13:15.835730
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                 '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2, seconds=1)) == \
                                                                 '00:02:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      minutes=4, seconds=5)) == \
                                                     '51:04:05.000000'
    assert timedelta_format(datetime_module.timedelta(days=2, hours=3,
                                                      minutes=4, seconds=5,
                                                      microseconds=678)) == \
                                                     '51:04:05.000678'



# Generated at 2022-06-22 18:13:25.281293
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:05.342342') == datetime_module.timedelta(seconds=5, microseconds=342342)
    assert timedelta_parse('00:00:05.342342') == datetime_module.timedelta(seconds=5, microseconds=342342)
    assert timedelta_parse('01:02:03.410410') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=410410)

# Generated at 2022-06-22 18:13:36.116121
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    td = datetime_module.timedelta(seconds=1.234)
    assert timedelta_format(td) == '00:00:01.234000'

    td = datetime_module.timedelta(seconds=10.234)
    assert timedelta_format(td) == '00:00:10.234000'

    td = datetime_module.timedelta(seconds=100.234)
    assert timedelta_format(td) == '00:01:40.234000'

    td = datetime_module.timedelta(seconds=999.234)
    assert timedelta_format(td) == '00:16:39.234000'

    td = datetime_module.timedelta(seconds=1000.234)

# Generated at 2022-06-22 18:13:48.066456
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(0, 0, 10000)

    assert timedelta_parse

# Generated at 2022-06-22 18:13:49.763290
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'



# Generated at 2022-06-22 18:13:59.367525
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(timedelta_parse('1:2:3.4')) == '01:02:03.004000'
    assert timedelta_format(timedelta_parse('0:0:0.0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:0:0.1')) == '00:00:00.001000'
    assert timedelta_format(timedelta_parse('0:0:0.01')) == '00:00:00.001000'
    assert timedelta_format(timedelta_parse('0:0:0.001')) == '00:00:00.001000'

# Generated at 2022-06-22 18:14:11.089838
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == '00:00:03'
    assert timedelta_format(datetime_module.timedelta(
        milliseconds=3
    )) == '00:00:00.003000'
    assert timedelta_format(datetime_module.timedelta(
        microseconds=3
    )) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(
        hours=3
    )) == '03:00:00'
    assert timedelta_format(datetime_module.timedelta(
        days=3
    )) == '72:00:00'

# Generated at 2022-06-22 18:14:17.683306
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=12)) == \
           '00:00:00.000012'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == \
           '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=1234)) == \
           '00:00:00.001234'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345)) == \
           '00:00:00.012345'

# Generated at 2022-06-22 18:14:21.427837
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=1, hours=2, minutes=3,
                                  seconds=4, microseconds=5)
    ) == '02:03:04.000005'


# Generated at 2022-06-22 18:14:29.789208
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(microseconds=1000)
    assert timedelta_parse('00:00:00.010000') == datetime_module.timedelta(microseconds=10000)

# Generated at 2022-06-22 18:14:33.363773
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=4,
                                                      microseconds=384)) == \
                                                      '00:00:04.000384'



# Generated at 2022-06-22 18:14:42.739339
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.1') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(microseconds=0)

# Generated at 2022-06-22 18:14:54.282493
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                             '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == \
                                                             '01:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) == \
                                                             '01:02:03.000000'
    assert (timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                       seconds=3,
                                                       milliseconds=4)) == \
                                                             '01:02:03.004000')

# Generated at 2022-06-22 18:14:58.348367
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=3, minutes=45, seconds=37,
                                   microseconds=123456)
    assert timedelta_format(td) == '03:45:37.123456'
    assert timedelta_parse(timedelta_format(td)) == td



# Generated at 2022-06-22 18:15:02.045047
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:00:00.043000') == datetime_module.timedelta(
        hours=3,
        seconds=4.3,
    )
    
    

# Generated at 2022-06-22 18:15:13.051961
# Unit test for function timedelta_format
def test_timedelta_format():
    one_day_timedelta = datetime_module.timedelta(days=1)
    assert timedelta_format(one_day_timedelta) == '00:00:00.000000'
    one_second_timedelta = datetime_module.timedelta(seconds=1)
    assert timedelta_format(one_second_timedelta) == '00:00:01.000000'
    one_hour_timedelta = datetime_module.timedelta(hours=1)
    assert timedelta_format(one_hour_timedelta) == '01:00:00.000000'
    one_microsecond_timedelta = datetime_module.timedelta(microseconds=1)
    assert timedelta_format(one_microsecond_timedelta) == '00:00:00.000001'

# Generated at 2022-06-22 18:15:23.951392
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == '01:02:03.123456'
    assert timedelta_format(timedelta_parse('0:2:3.123456')) == '00:02:03.123456'
    assert timedelta_format(timedelta_parse('0:0:3.123456')) == '00:00:03.123456'
    assert timedelta_format(timedelta_parse('0:0:0.123456')) == '00:00:00.123456'
    assert timedelta_format(timedelta_parse('0:0:0.000123')) == '00:00:00.000123'

# Generated at 2022-06-22 18:15:26.367737
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=10 * 60 * 60 +
                                                      20 * 60 +
                                                      3,
                                                      microseconds=123456)) \
                                                             == '10:20:03.123456'


# Generated at 2022-06-22 18:15:37.220688
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert '00:00' == timedelta_format(datetime_module.timedelta(seconds=0))
    assert '00:02' == timedelta_format(datetime_module.timedelta(seconds=2))
    assert '00:02.100000' == timedelta_format(
        datetime_module.timedelta(seconds=2, microseconds=100_000)
    )
    assert '00:02:02' == timedelta_format(
        datetime_module.timedelta(seconds=2*60+2)
    )
    assert '00:02:02.300000' == timedelta_format(
        datetime_module.timedelta(seconds=2*60+2, microseconds=300_000)
    )

# Generated at 2022-06-22 18:15:41.506166
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
        '03:00:00.000000'
    assert (timedelta_format(datetime_module.timedelta(hours=3,
                                                       minutes=7,
                                                       seconds=8,
                                                       microseconds=3)) ==
            '03:07:08.000003')


# Generated at 2022-06-22 18:15:45.693802
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(days=2, hours=7, seconds=23))) \
           == \
           datetime_module.timedelta(days=2, hours=7, seconds=23)

test_timedelta_parse()

# Generated at 2022-06-22 18:15:52.106872
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:0:1.000001')) == '00:00:01.000001'
    assert timedelta_format(timedelta_parse('0:1:0.000001')) == '00:01:00.000001'
    assert timedelta_format(timedelta_parse('1:0:0.000001')) == '01:00:00.000001'

# Generated at 2022-06-22 18:15:57.254669
# Unit test for function timedelta_format
def test_timedelta_format():
    # The format used for round-tripping has six digits after the period.
    # there are 86400 seconds in a day, so the last digit that can easily
    # be round tripped is day
    assert timedelta_format(datetime_module.timedelta(days=0)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=123)) == \
        '00:00:00.001230'
    assert timedelta_format(datetime_module.timedelta(days=123, hours=1)) == \
        '01:00:00.001230'
    assert timedelta_format(datetime_module.timedelta(days=123, minutes=1)) == \
        '00:01:00.001230'

# Generated at 2022-06-22 18:16:05.527780
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('07:05:06.123456') == datetime_module.timedelta(hours=7, minutes=5, seconds=6, microseconds=123456)
    assert timedelta_parse('07:05:06') == datetime_module.timedelta(hours=7, minutes=5, seconds=6)
    assert timedelta_parse('7:5:6') == datetime_module.timedelta(hours=7, minutes=5, seconds=6)
    assert timedelta_parse('7:5') == datetime_module.timedelta(hours=7, minutes=5)


# Generated at 2022-06-22 18:16:15.836893
# Unit test for function timedelta_format
def test_timedelta_format():
    # Making sure we don't have fractional seconds in the output:
    assert timedelta_format(datetime_module.timedelta(seconds=30.6)) == \
           '00:00:30.600000'

    assert timedelta_format(datetime_module.timedelta(
        seconds=61,
        microseconds=42
    )) == '00:01:01.000042'

    assert timedelta_format(datetime_module.timedelta(
        hours=13,
        minutes=24,
        seconds=61,
        microseconds=42
    )) == \
           '13:24:01.000042'



# Generated at 2022-06-22 18:16:19.141227
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

# Generated at 2022-06-22 18:16:29.946244
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2.3')) == '01:02:03.000000'
    assert timedelta_format(timedelta_parse('1:2')) == '01:02:00.000000'
    assert timedelta_format(timedelta_parse('1')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('.1')) == '00:00:00.100000'
    assert timedelta_format(timedelta_parse('1.2')) == '01:00:01.200000'
    assert timedelta_format(timedelta_parse('1.20')) == '01:00:01.200000'

# Generated at 2022-06-22 18:16:40.055882
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:0:1.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-22 18:16:43.450455
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=5)) == \
                           '02:03:04.000005'



# Generated at 2022-06-22 18:16:55.144007
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse('0:0:12') == datetime_module.timedelta(seconds=12)
    assert timedelta_parse('0:12:34') == datetime_module.timedelta(
        minutes=12, seconds=34
    )
    assert timedelta_parse('12:34:56') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56
    )
    assert timedelta_parse('0:0:12.345678') == datetime_module.timedelta(
        seconds=12, microseconds=345678
    )
    assert timedelta_parse('0:12:34.345678') == datetime_module.timedelta(
        minutes=12, seconds=34, microseconds=345678
    )

# Generated at 2022-06-22 18:16:59.057896
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3,
                                          minutes=15,
                                          seconds=25,
                                          microseconds=45)
    expected = '03:15:25.000045'
    assert timedelta_format(timedelta) == expected


# Generated at 2022-06-22 18:17:07.384916
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_python_toolbox
    test_python_toolbox.assert_equivalent(
        timedelta_format(datetime_module.timedelta(hours=2)),
        '02:00:00.000000'
    )
    test_python_toolbox.assert_equivalent(
        timedelta_format(datetime_module.timedelta(minutes=2, seconds=3)),
        '00:02:03.000000'
    )
    test_python_toolbox.assert_equivalent(
        timedelta_format(
            datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                      microseconds=400)
        ),
        '01:02:03.000400'
    )

# Generated at 2022-06-22 18:17:17.276090
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0, 0)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == \
           '25:00:00.000001'



# Generated at 2022-06-22 18:17:29.968807
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:17:36.609963
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('5.5')) == '05:00:05.500000'
    assert timedelta_format(timedelta_parse('5')) == '05:00:05.000000'
    assert timedelta_format(timedelta_parse('5:5')) == '00:05:05.000000'
    assert timedelta_format(timedelta_parse('5:5:5')) == '00:05:05.500000'
    assert timedelta_format(timedelta_parse('5:5:5.5')) == '00:05:05.500000'
    assert timedelta_format(timedelta_parse('0:0:05')) == '00:00:05.000000'

# Generated at 2022-06-22 18:17:44.062711
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '15:00:00.000000'
    timedelta = timedelta_parse(s)
    assert isinstance(timedelta, datetime_module.timedelta)
    assert timedelta.seconds == 15*60*60
    assert timedelta.microseconds == 0
    s = '15:00:00.000000'
    timedelta = timedelta_parse(s)
    assert isinstance(timedelta, datetime_module.timedelta)
    assert timedelta.seconds == 15*60*60
    assert timedelta.microseconds == 0

# Generated at 2022-06-22 18:17:54.608789
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
                                                      == \
           '01:02:03.123456'
    assert timedelta_parse(timedelta_format(
                           datetime_module.timedelta(hours=1,
                                                     minutes=2,
                                                     seconds=3,
                                                     microseconds=123456))) \
                                                     == \
           datetime_module.timedelta(hours=1,
                                     minutes=2,
                                     seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:18:04.036055
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(1, 73)) == \
           '01:00:00.000073'
    assert timedelta_format(datetime_module.timedelta(hours=7, minutes=12)) == \
           '07:12:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=7, minutes=12,
                                                      microseconds=123)) == \
           '07:12:00.000123'

test_timedelta_format()



# Generated at 2022-06-22 18:18:11.028521
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('7:30:00:000000') == datetime_module.timedelta(hours=7, minutes=30)
    assert timedelta_parse('7:30:00.000000') == datetime_module.timedelta(hours=7, minutes=30)
    assert timedelta_parse('07:30:00:000000') == datetime_module.timedelta(hours=7, minutes=30)
    assert timedelta_parse('07:30:00.000000') == datetime_module.timedelta(hours=7, minutes=30)
    assert timedelta_parse('07:30:00:123456') == datetime_module.timedelta(hours=7, minutes=30, microseconds=123456)

# Generated at 2022-06-22 18:18:21.903368
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('07:45:00.000000') == datetime_module.timedelta(
        hours=7, minutes=45
    )
    assert timedelta_parse('07:45:03.000000') == datetime_module.timedelta(
        hours=7, minutes=45, seconds=3
    )
    assert timedelta_parse('07:45:03.100000') == datetime_module.timedelta(
        hours=7, minutes=45, seconds=3, microseconds=100000
    )
    assert timedelta_parse('07:45:03.123456') == datetime_module.timedelta(
        hours=7, minutes=45, seconds=3, microseconds=123456
    )


# Generated at 2022-06-22 18:18:25.116776
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta



# Generated at 2022-06-22 18:18:36.529821
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=5)) == \
                                                        '00:05:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                        '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                        '00:00:00.001000'

# Generated at 2022-06-22 18:18:44.830411
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00:000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:01:000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('0:00:00:000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:00:99999') == datetime_module.timedelta(microseconds=9999)
    assert timedelta_parse('0:00:01.004999') == datetime_module.timedelta(seconds=1, microseconds=4999)
    assert timedelta_parse('0:05:01.004999') == datetime_module.timedelta(minutes=5, seconds=1, microseconds=4999)
    assert timedelta_parse

# Generated at 2022-06-22 18:18:49.165727
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000100') - datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds= 100
    ) < datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:18:54.429095
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1
    )
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )

# Generated at 2022-06-22 18:19:04.402468
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:0:59.999999') == datetime_module.timedelta(0, 59, 999999)

# Generated at 2022-06-22 18:19:15.780728
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.000001') == (
        datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                              microseconds=1)
    )
    assert timedelta_parse('0:0:0.000001') == (
        datetime_module.timedelta(microseconds=1)
    )
    assert timedelta_parse('0:0:1.000001') == (
        datetime_module.timedelta(seconds=1, microseconds=1)
    )
    assert not timedelta_parse('0:0:1.00001') > (
        datetime_module.timedelta(seconds=1, microseconds=1)
    )

# Generated at 2022-06-22 18:19:24.957771
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
           datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1))) == \
           datetime_module.timedelta(1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1, 1))) == \
           datetime_module.timedelta(1, 1, 1)

# Generated at 2022-06-22 18:19:31.051364
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2,
                                  seconds=3, microseconds=456000))) ==\
                                  datetime_module.timedelta(hours=1,
                                                            minutes=2,
                                                            seconds=3,
                                                            microseconds=456000)



# Generated at 2022-06-22 18:19:41.565708
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(s='00:00:01.000011') == datetime_module.timedelta(
        seconds=1, microseconds=11
    )

    assert timedelta_parse(s='00:01:00.000011') == datetime_module.timedelta(
        minutes=1, seconds=0, microseconds=11
    )

    assert timedelta_parse(s='01:00:01.000011') == datetime_module.timedelta(
        hours=1, seconds=1, microseconds=11
    )

    assert timedelta_parse(s='01:01:00.000011') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=0, microseconds=11
    )


# Generated at 2022-06-22 18:19:53.024961
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03:04') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4000))
    assert timedelta_parse('01:02:03.04') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4000))
    assert timedelta_parse('1:2:3.4') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=400000))
    assert timedelta_parse('1:2:3') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3))

# Generated at 2022-06-22 18:19:56.744879
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '01:02:03.123456'



# Generated at 2022-06-22 18:20:06.208778
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3')) == '01:02:03.000000'
    assert timedelta_format(timedelta_parse('1:2:3.4')) == '01:02:03.400000'
    assert timedelta_format(timedelta_parse('1:2:3.400')) == '01:02:03.400000'
    assert timedelta_format(timedelta_parse('1:2:3.400005')) == '01:02:03.400005'
    assert timedelta_format(timedelta_parse('1:2:3.4000000')) == '01:02:03.4000000'

# Generated at 2022-06-22 18:20:16.372919
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=2,
                                                      microseconds=3)) == \
           '00:01:02.000003'

# Generated at 2022-06-22 18:20:28.253617
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:20:37.503087
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
           datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2))) == \
           datetime_module.timedelta(1, 2)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3))) == \
           datetime_module.timedelta(1, 2, 3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 2, 3, 4))) == \
           datetime_module.timedelta(1, 2, 3, 4)


# Note: Currently there's no `abc.AsyncIterator` in

# Generated at 2022-06-22 18:20:47.741676
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.123456') == (
        datetime_module.timedelta(microseconds=123456))
        
    assert timedelta_parse('01:00:00.123456') == (
        datetime_module.timedelta(hours=1, microseconds=123456))
        
    assert timedelta_parse('01:01:00.123456') == (
        datetime_module.timedelta(hours=1, minutes=1, microseconds=123456))
        
    assert timedelta_parse('01:01:01.123456') == (
        datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=123456))
        

# Generated at 2022-06-22 18:20:53.209362
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=5, hours=3, minutes=123, seconds=40, microseconds=123456
    ))) == datetime_module.timedelta(
        days=5, hours=3, minutes=123, seconds=40, microseconds=123456
    )

# Generated at 2022-06-22 18:21:06.099567
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (timedelta_parse('00:00:00.000000')
            == datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                         microseconds=0))
    assert (timedelta_parse('01:02:03.000000')
            == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                         microseconds=0))
    assert (timedelta_parse('01:02:03.000004')
            == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                         microseconds=4))

# Generated at 2022-06-22 18:21:15.957998
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=56)) == \
           '00:00:56.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=3661)) == \
           '01:01:01.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=3, seconds=24,
                                  microseconds=5)
    ) == '01:03:24.000005'



# Generated at 2022-06-22 18:21:27.012608
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789)
    assert timedelta_parse('1:2:3.123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123000)
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)

# Generated at 2022-06-22 18:21:37.828910
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('0:1:0.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('1:0:0.000000') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:21:42.718427
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('01:20:30.123456')
    assert (timedelta.days, timedelta.seconds,
            timedelta.microseconds) == (0, 4500, 123456)

# Generated at 2022-06-22 18:21:47.002128
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=23,
                                          microseconds=456789)
    assert timedelta_format(timedelta) == '01:02:23.0456789'



# Generated at 2022-06-22 18:21:55.659519
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:00:00') == datetime_module.timedelta(hours=2)
    assert timedelta_parse('02:03:00') == datetime_module.timedelta(hours=2,
                                                                     minutes=3)
    assert timedelta_parse('02:03:04') == datetime_module.timedelta(hours=2,
                                                                     minutes=3,
                                                                     seconds=4)
    assert timedelta_parse(
        '02:03:04.123456'
    ) == datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                   microseconds=123456)

# Generated at 2022-06-22 18:22:03.589863
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == \
                                                      '23:59:59.999999'

    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=42)) \
                                                      == '00:00:01.000042'



# Generated at 2022-06-22 18:22:11.575486
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:01.000001') == datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('00:00:01.2') == datetime_module.timedelta(seconds=1, microseconds=200000)

# Generated at 2022-06-22 18:22:23.669962
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(hours=0, minutes=0, seconds=0),
        datetime_module.timedelta(hours=0, minutes=0, seconds=1),
        datetime_module.timedelta(hours=0, minutes=1, seconds=0),
        datetime_module.timedelta(hours=1, minutes=0, seconds=0),
        datetime_module.timedelta(hours=1, minutes=1, seconds=1),
        datetime_module.timedelta(hours=10, minutes=20, seconds=30,
                                  microseconds=123456),
    ):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta



if PY2:
    from itertools import izip_longest
