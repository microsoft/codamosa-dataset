

# Generated at 2022-06-22 18:12:33.953885
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('8:30:12.123456')) == \
                                                          '08:30:12.123456'

if PY3:
    def get_from_module(module_name, attr_name):
        module = __import__(module_name)
        return getattr(module, attr_name)
else:
    def get_from_module(module_name, attr_name):
        module = __import__(module_name)
        return getattr(module, attr_name)



# Generated at 2022-06-22 18:12:45.505721
# Unit test for function timedelta_parse
def test_timedelta_parse():

    def check(input_string, expected_result):
        actual_result = timedelta_parse(input_string)
        assert actual_result == expected_result

    check('02:03:04.005678',
          datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=500_678))

    check('02:03:04.056780',
          datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=567_800))

    check('00:00:00.000000',
          datetime_module.timedelta(0))

    check('00:00:00.000001',
          datetime_module.timedelta(microseconds=1))


# Generated at 2022-06-22 18:12:54.080107
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.123456') == datetime_module.timedelta(
        seconds=0,
        microseconds=123456
    )
    assert timedelta_parse('0:0:1.123456') == datetime_module.timedelta(
        seconds=1,
        microseconds=123456
    )
    assert timedelta_parse('0:1:1.123456') == datetime_module.timedelta(
        minutes=1,
        seconds=1,
        microseconds=123456
    )
    assert timedelta_parse('1:1:1.123456') == datetime_module.timedelta(
        hours=1,
        minutes=1,
        seconds=1,
        microseconds=123456
    )

# Generated at 2022-06-22 18:12:56.651313
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:13:04.470292
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=1234)) \
                                                      == '01:02:03.001234'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=12345)) \
                                                      == '01:02:03.012345'



# Generated at 2022-06-22 18:13:13.949736
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(12, 1200)) == \
                                                           '00:00:12.001200'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
                                                           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(1234, 100000)) == \
                                                            '34:17:40.100000'
    assert timedelta_format(datetime_module.timedelta(0, 2, 5)) == \
                                                            '00:00:02.000005'



# Generated at 2022-06-22 18:13:21.570230
# Unit test for function timedelta_parse
def test_timedelta_parse():
    tests = [
        ['0:0:0.000000', datetime_module.timedelta(0)],
        ['0:0:0.000001', datetime_module.timedelta(microseconds=1)],
        ['0:0:10.000000', datetime_module.timedelta(seconds=10)],
        ['0:55:55.000000', datetime_module.timedelta(minutes=55, seconds=55)],
    ]
    for s, expected_result in tests:
        result = timedelta_parse(s)
        assert result == expected_result

# Generated at 2022-06-22 18:13:33.251221
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 5)) == '00:00:05.000000'
    assert timedelta_format(datetime_module.timedelta(1, 5, 3)) == '24:00:05.000003'
    assert timedelta_format(datetime_module.timedelta(0, 5, 59)) == '00:00:05.000059'
    assert timedelta_format(datetime_module.timedelta(0, 5, 1599)) == '00:00:05.001599'
    assert timedelta_format(datetime_module.timedelta(0, 5, 5999)) == '00:00:05.005999'

# Generated at 2022-06-22 18:13:41.800234
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:13:53.617072
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=5)) == \
                    '00:00:00.000005'
    assert timedelta_format(datetime_module.timedelta(microseconds=55)) == \
                    '00:00:00.000055'
    assert timedelta_format(datetime_module.timedelta(microseconds=555)) == \
                    '00:00:00.000555'
    assert timedelta_format(datetime_module.timedelta(microseconds=5555)) == \
                    '00:00:00.005555'
    assert timedelta_format(datetime_module.timedelta(microseconds=55555)) == \
                    '00:00:00.055555'

# Generated at 2022-06-22 18:14:05.181833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == \
                                                       '01:02:03.123456'


if PY3:
    string_types += (bytes, PathLike)
    integer_types = (int,)
    class_types = (type,)
    text_repr = lambda s: s
    binary_repr = lambda s: s
    from io import BytesIO as StringIO
else:
    string_types += (unicode, PathLike)
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_repr = lambda s: s.encode('utf-8')
    binary_repr = lambda s: s.decode('utf-8')

# Generated at 2022-06-22 18:14:14.069003
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=42)) == \
                                                           '00:00:00.000042'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == \
                                                           '00:00:00.000123'
    assert timedelta_format(datetime_module.timedelta(microseconds=4242)) == \
                                                           '00:00:00.004242'
    assert timedelta_format(datetime_module.timedelta(microseconds=12345)) == \
                                                           '00:00:00.012345'
   

# Generated at 2022-06-22 18:14:20.714914
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123450') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=12345
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )


# Generated at 2022-06-22 18:14:30.209137
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4))\
                                                              == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=400))\
                                                              == '01:02:03.000400'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=40))\
                                                              == '01:02:03.000040'

# Generated at 2022-06-22 18:14:33.220682
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.400005') == \
           datetime_module.timedelta(1, 2*60 + 3, 400005)



# Generated at 2022-06-22 18:14:37.998418
# Unit test for function timedelta_format
def test_timedelta_format():
    for time in [
        datetime_module.time(10, 15, 30, 40),
        datetime_module.time(5, 2, 3, 40000),
        datetime_module.time(0, 0, 0, 100),
    ]:
        assert timedelta_format(time - datetime_module.time(0)) == time_isoformat(time)



# Generated at 2022-06-22 18:14:45.688539
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
           '02:03:04.000005'

    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=50000)) == \
           '02:03:04.050000'

    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=500043)) == \
           '02:03:04.050043'

    assert timedelta

# Generated at 2022-06-22 18:14:54.445376
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:15:02.092309
# Unit test for function timedelta_format
def test_timedelta_format():
    from .random_tools import seed
    seed('timedelta_format')
    for _ in range(1000):
        import random
        time = datetime_module.time(
            hour=random.randrange(24),
            minute=random.randrange(60), 
            second=random.randrange(60),
            microsecond=random.randrange(1000000),
        )
        assert timedelta_format(time - datetime_module.time(0)) == \
                                time_isoformat(time)
            


# Generated at 2022-06-22 18:15:11.624268
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10)) == '10:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=30)) == '01:30:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=30,
                                                      seconds=17,
                                                      microseconds=200)) == '01:30:17.000200'



# Generated at 2022-06-22 18:15:23.732595
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.000000') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=0)
    assert timedelta_parse('1:01:01.000001') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=1)
    assert timedelta_parse('1:01:01.999999') == \
           datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                     microseconds=999999)

    assert timedelta_parse('0:07:19.043000') == \
           datetime_module.timedelta(minutes=7, seconds=19, microseconds=43000)

# Generated at 2022-06-22 18:15:30.121221
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'

# Generated at 2022-06-22 18:15:37.053158
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.004005') == \
           datetime_module.timedelta(seconds=3723, microseconds=4005)
    assert timedelta_parse('1:02:03.000010') == \
           datetime_module.timedelta(seconds=3723, microseconds=10)
    assert timedelta_parse('1:02:03.000000') == \
           datetime_module.timedelta(seconds=3723)

test_timedelta_parse()



# Generated at 2022-06-22 18:15:46.174885
# Unit test for function timedelta_parse
def test_timedelta_parse():
    if sys.version_info[:2] < (3, 6):
        return

    import pytest
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
           datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1))) == \
           datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=1,
                                                                      microseconds=1))) == \
           datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=1))) == \
           datetime_

# Generated at 2022-06-22 18:15:49.917688
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=5, minutes=42, seconds=17,
                                  microseconds=23)) == (
                                      '05:42:17.000023'
                                  )
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'



# Generated at 2022-06-22 18:16:01.348288
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(0, 60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'


# Generated at 2022-06-22 18:16:02.851443
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02.003456') == datetime_module.timedelta(
        hours=0, minutes=1, seconds=2, microseconds=3456
    )

# Generated at 2022-06-22 18:16:10.568979
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=42)) == '00:00:42.000000'
    assert timedelta_format(datetime_module.timedelta(
        seconds=42, microseconds=1
    )) == '00:00:42.000001'
    assert timedelta_format(datetime_module.timedelta(
        seconds=42, microseconds=999999
    )) == '00:00:42.999999'
    assert timedelta_format(datetime_module.timedelta(
        minutes=42, seconds=12, microseconds=3
    )) == '00:42:12.000003'

# Generated at 2022-06-22 18:16:16.372356
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '12:34:56.123456'
    time = datetime_module.datetime.strptime(s, '%H:%M:%S.%f').time()

    timedelta = timedelta_parse(s)
    time2 = (datetime_module.datetime.min + timedelta).time()
    assert time == time2

# Generated at 2022-06-22 18:16:23.910036
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0,
                                                      hours=0,
                                                      minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == (
                                                          '00:00:00.000000')
    assert timedelta_format(datetime_module.timedelta(days=0,
                                                      hours=0,
                                                      minutes=0,
                                                      seconds=1,
                                                      microseconds=0)) == (
                                                          '00:00:01.000000')

# Generated at 2022-06-22 18:16:27.663151
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=4,
                                                      seconds=5,
                                                      microseconds=123456)) == (
        '03:04:05.123456'
    )

# Generated at 2022-06-22 18:16:32.105772
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(seconds=123)) == \
           '00:02:03.000000'


# Generated at 2022-06-22 18:16:35.271158
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.678901') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45,
        microseconds=678901
    )

# Generated at 2022-06-22 18:16:40.882911
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:01:00.123456') == datetime_module.timedelta(minutes=1, seconds=0, microseconds=123456)
    assert timedelta_parse('0:00:01.123456') == datetime_module.timedelta(seconds=1, microseconds=123456)



# Generated at 2022-06-22 18:16:51.913626
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:16:58.759018
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=12)) == \
           '12:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=24)) == \
           '00:24:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=12, minutes=24, seconds=36, microseconds=123456
    )) == '12:24:36.123456'



# Generated at 2022-06-22 18:17:01.910012
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

# Generated at 2022-06-22 18:17:08.665117
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .contextmanagers import assert_equal
    assert_equal(timedelta_parse('00:00:00.000000'), datetime_module.timedelta())
    assert_equal(timedelta_parse('01:00:00.000000'), datetime_module.timedelta(hours=1))
    assert_equal(timedelta_parse('00:01:00.000000'), datetime_module.timedelta(minutes=1))
    assert_equal(timedelta_parse('00:00:01.000000'), datetime_module.timedelta(seconds=1))
    assert_equal(timedelta_parse('00:00:00.000001'), datetime_module.timedelta(microseconds=1))

# Generated at 2022-06-22 18:17:20.487875
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('10:00:00.000000') == datetime_module.timedelta(
        minutes=10
    )
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
   

# Generated at 2022-06-22 18:17:26.886356
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=100)) == '01:40:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=10)) == '240:00:00.000000'


# Generated at 2022-06-22 18:17:35.861503
# Unit test for function timedelta_format
def test_timedelta_format():
    from collections import namedtuple
    case = namedtuple('Case', 'timedelta expected')

# Generated at 2022-06-22 18:17:46.284645
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0:0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0:0.00000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0.0000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0.00000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0.1') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_

# Generated at 2022-06-22 18:17:54.657707
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:30.000000') == datetime_module.timedelta(seconds=30)
    assert timedelta_parse('00:00:00.050000') == datetime_module.timedelta(microseconds=50000)
    assert timedelta_parse('00:00:30.050000') == datetime_module.timedelta(seconds=30, microseconds=50000)

# Generated at 2022-06-22 18:18:01.567309
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta1 = datetime_module.timedelta(seconds=100.8,
                                           microseconds=35000)
    assert timedelta_format(timedelta1) == '00:01:40.083500'
    timedelta2 = datetime_module.timedelta(days=1, seconds=100.8,
                                           microseconds=35000)
    assert timedelta_format(timedelta2) == '01:00:01:40.083500'



# Generated at 2022-06-22 18:18:10.439038
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_equal(a, b):
        assert timedelta_format(a) == timedelta_format(b)
    assert_timedelta_equal(timedelta_parse('00:00:00.000000'),
                           datetime_module.timedelta())
    assert_timedelta_equal(timedelta_parse('10:59:59.999999'),
                           datetime_module.timedelta(hours=10, minutes=59,
                                                     seconds=59,
                                                     microseconds=999999))
    assert_timedelta_equal(timedelta_parse('10:59:59.999999'),
                           datetime_module.timedelta(hours=10, minutes=59,
                                                     seconds=59,
                                                     microseconds=999999))

# Generated at 2022-06-22 18:18:13.151199
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(1, 2,
                                                                3.123456)



# Generated at 2022-06-22 18:18:16.036184
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                          '00:01:00.000000'


# Generated at 2022-06-22 18:18:26.720830
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3)) == \
                                                       '03:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=4)) == \
                                                       '03:04:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=4,
                                                      seconds=5)) == \
                                                       '03:04:05.000000'
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=4,
                                                      seconds=5,
                                                      microseconds=6)) == \
                                                       '03:04:05.000006'
    assert timedelta_

# Generated at 2022-06-22 18:18:32.864644
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:01:01.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1,
        microseconds=1
    )
    assert timedelta_parse('12:45:15.254734') == datetime_module.timedelta(
        hours=12, minutes=45, seconds=15,
        microseconds=254734
    )

# Generated at 2022-06-22 18:18:36.671345
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                       minutes=0,
                                                       seconds=0,
                                                       microseconds=10)) == \
                                                        '00:00:00.000010'

# Generated at 2022-06-22 18:18:40.599749
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
                                                      == '01:02:03.123456'



# Generated at 2022-06-22 18:18:53.131280
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_3_14159 = datetime_module.timedelta(seconds=3,
                                                  microseconds=14159)
    assert timedelta_parse('00:00:03.000014') == timedelta_3_14159
    assert timedelta_parse('00:00:03.1415') == timedelta_3_14159
    assert timedelta_parse('00:00:03.14159') == timedelta_3_14159
    assert timedelta_parse('00:00:03.141590') == timedelta_3_14159
    assert timedelta_parse('00:00:03.1415900') == timedelta_3_14159
    assert timedelta_parse('00:00:03.14159000') == timedelta_3_14159

# Generated at 2022-06-22 18:19:00.455960
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('01:02:03.000001')
    assert timedelta.total_seconds() == (1 * 60 * 60 + 2 * 60 + 3 + 1 / 1000000)
    assert timedelta_format(timedelta) == '01:02:03.000001'
    timedelta = timedelta_parse('00:00:03.004001')
    assert timedelta.total_seconds() == (3 + 4 / 1000000 + 1 / 10000000)
    assert timedelta_format(timedelta) == '00:00:03.004001'

# Generated at 2022-06-22 18:19:07.796958
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:2') == datetime_module.timedelta(hours=1,
                                                               minutes=2)
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(hours=1,
                                                                 minutes=2,
                                                                 seconds=3)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)
    assert timedelta_parse('1:2:3.400000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)
   

# Generated at 2022-06-22 18:19:17.138641
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000001') == timedelta_parse('1:2:3.1') == \
                                              timedelta_parse('1:2:3.010') == \
                                              timedelta_parse('1:2:3.010000')
    assert timedelta_parse('1:2:3.000001') != timedelta_parse('1:2:3.100001')
    assert timedelta_parse('1:2:3.000001') != timedelta_parse('1:2:3.000010')
    assert timedelta_parse('1:2:3.000001') != timedelta_parse('1:2:3.000001.1')

# Generated at 2022-06-22 18:19:24.443043
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456789)
    assert timedelta_parse('1:2:3.456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456000)
    assert timedelta_parse('1:2:3.45') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=450000)
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000)

# Generated at 2022-06-22 18:19:28.190720
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000004') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4))

# Generated at 2022-06-22 18:19:36.727171
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2,
                                          seconds=3, microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'
    timedeltas = [
        datetime_module.timedelta(0),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(hours=10),
        datetime_module.timedelta(weeks=12),
        datetime_module.timedelta(microseconds=999999),
    ]
    for timedelta in timedeltas:
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:19:39.007952
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.123456') == datetime_module.timedelta(
        1, 2*60+3, 123456
    )



# Generated at 2022-06-22 18:19:48.456185
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.001') == datetime_module.timedelta(milliseconds=1)
    assert timedelta_parse('00:00:00.01') == datetime_module.timedelta(microseconds=10)
    assert timedelta_parse('00:00:00.1') == datetime_module.timedelta(microseconds=100)
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-22 18:19:53.894326
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                          microseconds=13)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:19:58.660702
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:01.000001') == datetime_module.timedelta(
        hours=1, seconds=1, milliseconds=1, microseconds=1
    )
    assert timedelta_parse('01:01:01.010101') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=10, microseconds=10
    )



# Generated at 2022-06-22 18:20:01.202443
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, microseconds=949)) == \
         '01:00:00:000949'


# Generated at 2022-06-22 18:20:14.014759
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('4:30:00.000000') == datetime_module.timedelta(
        hours=4, minutes=30
    )
    assert timedelta_parse('4:30:05.000000') == datetime_module.timedelta(
        hours=4, minutes=30, seconds=5
    )
    assert timedelta_parse('4:30:05.112233') == datetime_module.timedelta(
        hours=4, minutes=30, seconds=5, microseconds=112233
    )
    assert timedelta_parse('04:30:05.112233') == datetime_module.timedelta(
        hours=4, minutes=30, seconds=5, microseconds=112233
    )

# Generated at 2022-06-22 18:20:21.809832
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.000001') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1)
    assert timedelta_parse('-1:02:03.000001') == datetime_module.timedelta(
        hours=-1, minutes=-2, seconds=-3, microseconds=-1)

# Generated at 2022-06-22 18:20:34.479351
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:20:42.790166
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=123456)
    ) == '01:02:03.123456'
    assert timedelta_format(
        datetime_module.timedelta(hours=24, seconds=1)
    ) == '24:00:01.000000'



# Generated at 2022-06-22 18:20:49.273907
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=14,
                                                      seconds=15,
                                                      microseconds=975000)) \
                                                      == '03:14:15.975000'



# Generated at 2022-06-22 18:20:56.504061
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.12345') == datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=12345)
    assert timedelta_parse('1:1:1.12345') == timedelta_parse(
        '0001:0001:0001.0000012345')
    assert timedelta_parse('-1:1:1.12345') == timedelta_parse(
        '-0001:0001:0001.0000012345')
    assert timedelta_parse('-0:0:0.0') == datetime_module.timedelta(
        days=0, hours=0, minutes=0, seconds=0, microseconds=0)

# Generated at 2022-06-22 18:21:00.757567
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(10, 23, 45, 567891))
    assert time == '10:23:45.567891'



# Generated at 2022-06-22 18:21:06.700216
# Unit test for function timedelta_parse
def test_timedelta_parse():
    # `datetime` doesn't have a dedicated parser for `timedelta` in 2.x, so
    # we have to make our own.
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456))) == \
        datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)



# Generated at 2022-06-22 18:21:18.777797
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('5:5:5.5') == datetime_module.timedelta(
        hours=5, minutes=5, seconds=5, microseconds=500000)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1)
    assert timedelta_parse('0:0:0.000001') != datetime_module.timedelta()
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('0:0:1.000000') != datetime_module.timedelta()



# Generated at 2022-06-22 18:21:29.909974
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ) == '01:02:03.456789'

    assert timedelta_format(
        datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                  microseconds=789987)
    ) == '12:34:56.789987'

    assert timedelta_format(
        datetime_module.timedelta(hours=23, minutes=59, seconds=58,
                                  microseconds=999999)
    ) == '23:59:58.999999'


# Generated at 2022-06-22 18:21:34.156951
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=456789)
    assert time_isoformat(time, timespec='microseconds') == \
                                                      '01:02:03.456789'



# Generated at 2022-06-22 18:21:41.662462
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('3:14:15.926535') == (
        datetime_module.timedelta(hours=3, minutes=14, seconds=15,
                                  microseconds=926535)
    )
    assert timedelta_parse('12:34:56.789') == (
        datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                  microseconds=789000)
    )


# This is needed for argument parsing in Python 2:

# Generated at 2022-06-22 18:21:47.493027
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1,
        microseconds=123456,
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3,
        microseconds=123456,
    )

# Generated at 2022-06-22 18:21:54.673809
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=1234)
    ) == '01:02:03.001234'
    assert timedelta_format(
        datetime_module.timedelta(seconds=2, microseconds=1234)
    ) == '00:00:02.001234'
    assert timedelta_format(
        datetime_module.timedelta(seconds=2)
    ) == '00:00:02.000000'
    assert timedelta_format(
        datetime_module.timedelta(microseconds=2)
    ) == '00:00:00.000002'


# Generated at 2022-06-22 18:22:06.250247
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'

    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse

# Generated at 2022-06-22 18:22:10.584072
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)


# Generated at 2022-06-22 18:22:22.825866
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00') == datetime_module.timedelta()
    assert timedelta_parse('00:30') == datetime_module.timedelta(seconds=30)
    assert timedelta_parse('01:00:00') == datetime_module.timedelta(minutes=60)
    assert (timedelta_parse('00:01:02.000003') ==
            datetime_module.timedelta(seconds=62, microseconds=3))


if hasattr(datetime_module.time, 'fromisoformat'):
    time_fromisoformat = datetime_module.time.fromisoformat
else:
    def time_fromisoformat(s):
        return datetime_module.datetime.strptime(s, '%H:%M:%S.%f').time()

# Generated at 2022-06-22 18:22:26.981682
# Unit test for function timedelta_format
def test_timedelta_format():
    test_case = datetime_module.timedelta(seconds=1)
    if timedelta_format(test_case) != '00:00:01.000000':
        raise Exception('Wrong timedelta format: %s' % timedelta_format(test_case))

