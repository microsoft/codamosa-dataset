

# Generated at 2022-06-22 18:12:28.152851
# Unit test for function timedelta_format
def test_timedelta_format():
    timedeltas = [
        datetime_module.timedelta(hours=1),
        datetime_module.timedelta(minutes=1),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(microseconds=1),
    ]
    for timedelta in timedeltas:
        assert timedelta_format(timedelta) == timedelta_format(timedelta)



# Generated at 2022-06-22 18:12:37.013944
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import nose.tools as nose_tools
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                            '00:00:00.000000'
    nose_tools.assert_raises(ValueError, timedelta_parse, '00:00:00')
    nose_tools.assert_raises(ValueError, timedelta_parse, '00:00')
    nose_tools.assert_raises(ValueError, timedelta_parse, '00')
    nose_tools.assert_raises(ValueError, timedelta_parse, 'etc')
    nose_tools.assert_raises(ValueError, timedelta_parse, '')
    nose_tools.assert_raises(ValueError, timedelta_parse, '-00:00:00.000000')


# Generated at 2022-06-22 18:12:42.299616
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456789)
    ) == '01:02:03.456789'



# Generated at 2022-06-22 18:12:52.649580
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 987654)) == '00:00:00.987654'
    assert timedelta_format(datetime_module.timedelta(0, 3, 987654)) == '00:00:03.987654'
    assert timedelta_format(datetime_module.timedelta(0, 59, 987654)) == '00:00:59.987654'
    assert timedelta_format(datetime_module.timedelta(0, 60, 987654)) == '00:01:00.987654'
    assert timedelta_format(datetime_module.timedelta(0, 3 * 60 + 59, 987654)) == '00:03:59.987654'

# Generated at 2022-06-22 18:12:55.996249
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('12:34:56.789012')
    assert timedelta == datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                                  microseconds=789012)

# Generated at 2022-06-22 18:13:04.254564
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=3, minutes=10,
                                          seconds=23, microseconds=123456)
    assert timedelta_format(timedelta) == '03:10:23.123456'
    timedelta = datetime_module.timedelta(hours=0, minutes=10,
                                          seconds=23, microseconds=123456)
    assert timedelta_format(timedelta) == '00:10:23.123456'
    timedelta = datetime_module.timedelta(hours=0, minutes=0,
                                          seconds=23, microseconds=123456)
    assert timedelta_format(timedelta) == '00:00:23.123456'

# Generated at 2022-06-22 18:13:15.069143
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 1, 1))) == datetime_module.timedelta(1, 1, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 60, 1))) == datetime_module.timedelta(0, 60, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1, 0, 1234567))) == datetime_module.timedelta(1, 0, 123456)

# Generated at 2022-06-22 18:13:24.735912
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=43,
                                                      seconds=21)) \
           == '03:43:21.000000'

    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      hours=3,
                                                      minutes=43,
                                                      seconds=21,
                                                      microseconds=84)) \
           == '03:43:21.000084'

    assert timedelta_format(datetime_module.timedelta(microseconds=70)) \
           == '00:00:00.000070'

# Generated at 2022-06-22 18:13:31.675607
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(123,
                                                                      1000,
                                                                      100))) == \
           datetime_module.timedelta(123, 1000, 100)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0))) == \
           datetime_module.timedelta(0, 0)



# Generated at 2022-06-22 18:13:35.552486
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=4, minutes=7, seconds=12, microseconds=56789
    ))) == datetime_module.timedelta(
        hours=4, minutes=7, seconds=12, microseconds=56789
    )

# Generated at 2022-06-22 18:13:47.530341
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:13:56.517812
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                   microseconds=56789)
    assert timedelta_format(td) == '02:03:04.056789'
    assert timedelta_parse(timedelta_format(td)) == td

    td = datetime_module.timedelta(days=-2, hours=3, minutes=4, seconds=5,
                                   microseconds=6789)
    assert timedelta_format(td) == '-1 day, 03:04:05.006789'
    assert timedelta_parse(timedelta_format(td)) == td

    td = datetime_module.timedelta(days=2, hours=3, minutes=4, seconds=5,
                                   microseconds=6789)
    assert timedelta

# Generated at 2022-06-22 18:13:59.356137
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=4)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:14:08.170334
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == (
        datetime_module.timedelta(microseconds=1)
    )
    assert timedelta_parse('00:00:00.001000') == (
        datetime_module.timedelta(microseconds=1000)
    )
    assert timedelta_parse('00:00:00.010000') == (
        datetime_module.timedelta(microseconds=10000)
    )
    assert timedelta_parse('00:00:00.100000') == (
        datetime_module.timedelta(microseconds=100000)
    )

# Generated at 2022-06-22 18:14:11.189467
# Unit test for function timedelta_format
def test_timedelta_format():
    for s in ('00:00:00.000000', '01:23:45.678901',
              '23:59:59.999999'):
        assert timedelta_format(timedelta_parse(s)) == s


# Generated at 2022-06-22 18:14:23.308258
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.0') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.0000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timed

# Generated at 2022-06-22 18:14:31.949809
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)) \
            == '01:02:03.123456'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123)) \
            == '01:02:03.000123'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123000)) \
            == '01:02:03.123000'

# Generated at 2022-06-22 18:14:41.844161
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
                                                                '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                                '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
                                                                '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                                '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=61)) == \
                                                                '00:01:01.000000'

# Generated at 2022-06-22 18:14:45.478606
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:14:52.830400
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .asserting import assert_almost_equal
    assert_almost_equal(
        timedelta_parse(timedelta_format(datetime_module.timedelta(hours=3,
                                                                   minutes=2,
                                                                   seconds=8,
                                                                   microseconds=165))),
        datetime_module.timedelta(hours=3, minutes=2, seconds=8,
                                  microseconds=165)
    )

# Generated at 2022-06-22 18:15:03.040892
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert (
        timedelta_parse(timedelta_format(datetime_module.timedelta(
            hours=5,
            minutes=6,
            seconds=7,
            microseconds=8
        ))) ==
        datetime_module.timedelta(
            hours=5,
            minutes=6,
            seconds=7,
            microseconds=8
        )
    )
    assert (
        timedelta_format(timedelta_parse(
            '01:02:03.004000'
        )) ==
        '01:02:03.004000'
    )
    assert (
        timedelta_parse(
            '01:02:03.004000'
        ).total_seconds() ==
        3723.004
    )



# Generated at 2022-06-22 18:15:10.491437
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=8,
                                                      seconds=17,
                                                      microseconds=123456)) == \
                                                          '03:08:17.123456'
    assert timedelta_format(datetime_module.timedelta(hours=15, minutes=58,
                                                      seconds=37,
                                                      microseconds=123456)) == \
                                                          '15:58:37.123456'
    assert timedelta_format(datetime_module.timedelta(hours=9, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                          '09:00:00.000000'



# Generated at 2022-06-22 18:15:16.996488
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'



# Generated at 2022-06-22 18:15:21.016177
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import testing_tools
    for i in range(1000):
        assert timedelta_format(testing_tools.random_timedelta()) == \
               testing_tools.random_timedelta().isoformat()

test_timedelta_format()


# Generated at 2022-06-22 18:15:30.149881
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))

__all__ = [
    'string_types',
    'text_type',
    'binary_type',
    'PY3',
    'PY2',
    'ABC',
    'PathLike',
    'iscoroutinefunction',
    'isasyncgenfunction',
    'test_timedelta_parse',
] + [
    'collections_abc',
]

# Generated at 2022-06-22 18:15:39.654389
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) \
           == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) \
           == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) \
           == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) \
           == '00:00:00.000001'

# Generated at 2022-06-22 18:15:49.828732
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)
    assert timedelta_parse('01:02:03.0') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=0)
    assert timedelta_parse('01:02:03') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=0)
    assert timedelta_parse('01:02') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=0,
                                     microseconds=0)

# Generated at 2022-06-22 18:16:02.796012
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'

# Generated at 2022-06-22 18:16:06.037704
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('100:32:56.999999') == datetime_module.timedelta(
        days=4, hours=4, minutes=32, seconds=56, microseconds=999999
    )



# Generated at 2022-06-22 18:16:18.557602
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:03:04.000000') == \
                        datetime_module.timedelta(hours=2, minutes=3,
                                                  seconds=4)
    assert timedelta_parse('02:03:04.123456') == \
                        datetime_module.timedelta(hours=2, minutes=3,
                                                  seconds=4,
                                                  microseconds=123456)
    assert timedelta_parse('02:03:04.1234567') == \
                        datetime_module.timedelta(hours=2, minutes=3,
                                                  seconds=4,
                                                  microseconds=123456)

# Generated at 2022-06-22 18:16:29.604755
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=1))) == datetime_module.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(3))) == datetime_module.timedelta(3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(3.1))) == datetime_module.timedelta(3.1)
    assert timedelta_parse

# Generated at 2022-06-22 18:16:39.741937
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing.timing import delay
    microseconds = 1
    timedelta = datetime_module.timedelta(microseconds=microseconds)
    assert timedelta_format(timedelta) == '00:00:00.000001'
    microseconds = 2
    timedelta = datetime_module.timedelta(microseconds=microseconds)
    assert timedelta_format(timedelta) == '00:00:00.000002'
    microseconds = 3
    timedelta = datetime_module.timedelta(microseconds=microseconds)
    assert timedelta_format(timedelta) == '00:00:00.000003'
    microseconds = 123456
    timedelta = datetime_module.timedelta(microseconds=microseconds)

# Generated at 2022-06-22 18:16:46.644674
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta, string in (
        (datetime_module.timedelta(microseconds=1), '00:00:00.000001'),
        (datetime_module.timedelta(seconds=1, microseconds=1), '00:00:01.000001'),
        (datetime_module.timedelta(minutes=1, seconds=1, microseconds=1),
         '00:01:01.000001'),
        (datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                    microseconds=1),
         '01:01:01.000001'),
    ):
        assert timedelta_format(timedelta) == string
        assert timedelta == timedelta_parse(string)



# Generated at 2022-06-22 18:16:58.093310
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = [
        (datetime_module.timedelta(0), '00:00:00.000000'),
        (datetime_module.timedelta(minutes=23), '00:23:00.000000'),
        (datetime_module.timedelta(microseconds=3), '00:00:00.000003'),
        (datetime_module.timedelta(days=365), '365:00:00.000000'),
        (datetime_module.timedelta(days=365, minutes=23), '365:23:00.000000'),
        (datetime_module.timedelta(days=365, milliseconds=26),
         '365:00:00.026000'),
    ]

    for timedelta, s in cases:
        assert timedelta_format(timedelta) == s
        assert timedelta_

# Generated at 2022-06-22 18:17:00.538075
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.123456') == timedelta_parse('1:2:3.123456')

# Generated at 2022-06-22 18:17:06.430531
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                       '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                       microseconds=1)) == \
                                                       '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1,
                                                       microseconds=1)) == \
                                                       '01:00:01.000001'



# Generated at 2022-06-22 18:17:19.117797
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == \
                                                              '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                              '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'

# Generated at 2022-06-22 18:17:30.497391
# Unit test for function timedelta_format
def test_timedelta_format():
    for original_timedelta, original_isoformat in [
        (datetime_module.timedelta(hours=12, minutes=4, seconds=5,
                                   microseconds=957123),
         '12:04:05.957123'),
        (datetime_module.timedelta(hours=0, minutes=0, seconds=0,
                                   microseconds=0),
         '00:00:00.000000'),
        (datetime_module.timedelta(hours=0, minutes=0, seconds=59,
                                   microseconds=999999),
         '00:00:59.999999'),
    ]:
        assert timedelta_format(original_timedelta) == original_isoformat
        assert timedelta_parse(original_isoformat) == original_timedelta



# Generated at 2022-06-22 18:17:32.502803
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse("1.23:45:67.890123")) == \
           "01:23:45.890123"



# Generated at 2022-06-22 18:17:39.639397
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00'


# Generated at 2022-06-22 18:17:47.529149
# Unit test for function timedelta_format
def test_timedelta_format():
    import math


# Generated at 2022-06-22 18:17:53.101257
# Unit test for function timedelta_parse
def test_timedelta_parse():
    duration = timedelta_parse('1:32:23.649211')
    assert duration, datetime_module.timedelta(hours=1, minutes=32,
                                               seconds=23,
                                               microseconds=649211)
    assert timedelta_format(duration) == '01:32:23.649211'



# Generated at 2022-06-22 18:18:01.069954
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1')) == '00:00:01.000000'
    assert timedelta_format(timedelta_parse('1.1')) == '00:00:01.100000'
    assert timedelta_format(timedelta_parse('-1.1')) == '23:59:58.900000'
    assert timedelta_format(timedelta_parse('-1:0:1.1')) == '22:59:58.900000'
    assert timedelta_format(timedelta_parse('-1:1:1.1')) == '22:58:58.900000'


# Generated at 2022-06-22 18:18:10.162195
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=-1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=-1)) == '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=-1)) == '23:59:00.000000'

# Generated at 2022-06-22 18:18:16.979972
# Unit test for function timedelta_format
def test_timedelta_format():
    for i in range(100_000):
        timedelta = datetime_module.timedelta(
            # `days` is ignored
            days=1 + (i & 1),
            hours=(i + 1) % 24,
            minutes=(i + 2) % 60,
            seconds=(i + 3) % 60,
            microseconds=(i + 4) % 100_000
        )
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-22 18:18:20.832828
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:18:28.242041
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

# todo: test all the small numbers
import random
for _ in range(100):
    random_int = random.randrange(1, 10 ** 6)
    random_float = random_int / 10 ** 6
    random_int2 = random.randrange(1, 10 ** 6)
    random_float2 = random_int2 / 10 ** 6

# Generated at 2022-06-22 18:18:34.214868
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours = 12,
                                          minutes = 34,
                                          seconds = 56,
                                          microseconds = 123456)
    s = timedelta_format(timedelta)
    assert s == '12:34:56.123456'
    assert timedelta == timedelta_parse(s)


# Generated at 2022-06-22 18:18:43.571151
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:18:54.569625
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_time_tools import timedelta_eq
    assert timedelta_eq(timedelta_parse('2:10:22.123'),
                        datetime_module.timedelta(hours=2, minutes=10,
                                                  seconds=22,
                                                  microseconds=123000))
    assert timedelta_eq(timedelta_parse('2:10:22'),
                        datetime_module.timedelta(hours=2, minutes=10,
                                                  seconds=22,
                                                  microseconds=0))
    assert timedelta_eq(timedelta_parse('2:10'),
                        datetime_module.timedelta(hours=2, minutes=10,
                                                  seconds=0,
                                                  microseconds=0))

# Generated at 2022-06-22 18:19:04.517530
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_timedelta_format(timedelta, expected_string):
        assert timedelta_format(timedelta) == expected_string
    assert_timedelta_format(datetime_module.timedelta(), '00:00:00.000000')
    assert_timedelta_format(datetime_module.timedelta(microseconds=1),
                            '00:00:00.000001')
    assert_timedelta_format(datetime_module.timedelta(minutes=1),
                            '00:01:00.000000')
    assert_timedelta_format(datetime_module.timedelta(hours=1),
                            '01:00:00.000000')

# Generated at 2022-06-22 18:19:11.889484
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = [
        (-1, '-23:59:59.999999'),
        (0, '00:00:00.000000'),
        (0.5, '00:00:00.500000'),
        (1, '00:00:01.000000'),
        (datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=4), '01:02:03.000004'),
        (datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                   microseconds=999999),
         '23:59:59.999999'),
    ]
    
    for x, y in cases:
        assert timedelta_format(x) == y
        assert timedelta_parse(y) == x
        

# Generated at 2022-06-22 18:19:17.424664
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '01:02:03.123456'



# Generated at 2022-06-22 18:19:23.080271
# Unit test for function timedelta_parse
def test_timedelta_parse():

    s = timedelta_format(datetime_module.timedelta(hours=1,
                                                   minutes=17,
                                                   seconds=32,
                                                   microseconds=123456))
    assert timedelta_parse(s) == datetime_module.timedelta(hours=1,
                                                           minutes=17,
                                                           seconds=32,
                                                           microseconds=123456)

# Generated at 2022-06-22 18:19:27.292250
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.timedelta(days=1, hours=3, seconds=5,
                                     microseconds=7)
    assert '03:00:05.000007' == timedelta_format(time)



# Generated at 2022-06-22 18:19:30.956344
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=4, hours=3, minutes=2, seconds=1,
                                   microseconds=10)
    assert timedelta_format(td) == '03:02:01.000010'

# Generated at 2022-06-22 18:19:35.025975
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
                                                              '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                              '00:01:00.000000'



# Generated at 2022-06-22 18:19:42.040056
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('08:15:30.123456') == datetime_module.timedelta(
        hours=8, minutes=15, seconds=30, microseconds=123456
    )
    assert timedelta_parse('8:15:30.123456') == datetime_module.timedelta(
        hours=8, minutes=15, seconds=30, microseconds=123456
    )
    assert timedelta_parse('8:15:30.123') == datetime_module.timedelta(
        hours=8, minutes=15, seconds=30, microseconds=123000
    )
    assert timedelta_parse('8:15:30.1') == datetime_module.timedelta(
        hours=8, minutes=15, seconds=30, microseconds=100000
    )
    assert timedelta_

# Generated at 2022-06-22 18:19:50.211813
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == timedelta_module.timedelta(0)
    assert timedelta_parse('00:00:00.000037') == timedelta_module.timedelta(0, 0, 37)
    assert timedelta_parse('00:00:01.000000') == timedelta_module.timedelta(0, 1)
    assert timedelta_parse('00:00:01.000037') == timedelta_module.timedelta(0, 1, 37)
    assert timedelta_parse('00:01:00.000000') == timedelta_module.timedelta(0, 60)
    assert timedelta_parse('00:01:00.000037') == timedelta_module.timedelta(0, 60, 37)

# Generated at 2022-06-22 18:19:57.258225
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=45)) == \
                                                             '00:00:45.000000'
    assert timedelta_format(datetime_module.timedelta(hours=10,
                                                      minutes=175,
                                                      seconds=855,
                                                      microseconds=123456)) == \
                                                             '12:55:55.123456'



# Generated at 2022-06-22 18:20:06.480806
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1:2:3.000000')) == '01:02:03.000000'
    assert timedelta_format(timedelta_parse('1:2:3.001000')) == '01:02:03.001000'
    assert timedelta_format(timedelta_parse('1:2:3.456789')) == '01:02:03.456789'
    assert timedelta_format(timedelta_parse('1:2:3.456789')) == '01:02:03.456789'

# Generated at 2022-06-22 18:20:16.465983
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000345') == datetime_module.timedelta(
        microseconds=345
    )
    assert timedelta_parse('00:00:00.000345') == datetime_module.timedelta(
        seconds=0.000345
    )

    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )

# Generated at 2022-06-22 18:20:20.743799
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1)
    assert timedelta_format(timedelta) == '00:00:00.000000'


# Generated at 2022-06-22 18:20:33.975779
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('23:59:59.999999') == \
           datetime_module.timedelta(days=1, microseconds=-1)

    assert timedelta_parse('00:00:00') == datetime_module.timedelta()

    assert timedelta_parse('00:00:00.111111') == \
           datetime_module.timedelta(microseconds=11111)

    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)

    assert timedelta_parse('00:01:00') == datetime_module.timedelta(
        minutes=1
    )

    assert timedelta_parse('01:00:00') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:20:45.242874
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == (
        '00:00:00.000001'
    )



# Generated at 2022-06-22 18:20:47.369204
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=23, minutes=57, seconds=45,
                                          microseconds=123456)
    s = timedelta_format(timedelta)
    assert s == '23:57:45.123456'
    assert timedelta == timedelta_parse(s)



# Generated at 2022-06-22 18:20:56.113876
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.123456') == datetime_module.timedelta(hours=1,
                                                                        minutes=1,
                                                                        seconds=1,
                                                                        microseconds=123456)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('.123456') == datetime_module.timedelta(microseconds=123456)
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                                      microseconds=123456)) == '01:01:01.123456'

# Generated at 2022-06-22 18:21:07.253820
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
                            '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == \
                            '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
                            '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=2)) == \
                            '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2)) == \
                            '26:00:00.000000'

# Generated at 2022-06-22 18:21:17.217627
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:10.123456') == datetime_module.timedelta(
        seconds=10, microseconds=123456
    )
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )



# Generated at 2022-06-22 18:21:21.753253
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse("09:30:00.123456") == datetime_module.timedelta(
        hours=9, minutes=30, seconds=0, microseconds=123456
    )

# Generated at 2022-06-22 18:21:26.740857
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.045670') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=456700)

    assert timedelta_parse('0:00:00.000001') == \
        datetime_module.timedelta(microseconds=1)

# Generated at 2022-06-22 18:21:34.896665
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1.1)) == '00:00:01.100000'
    assert timedelta_format(datetime_module.timedelta(seconds=3600)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'


# Generated at 2022-06-22 18:21:42.751143
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == (
        datetime_module.timedelta(1))

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        23, 59, 59, 999_999
    ))) == datetime_module.timedelta(23, 59, 59, 999_999)

    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        23, 59, 59, 0
    ))) == datetime_module.timedelta(23, 59, 59, 0)


# Generated at 2022-06-22 18:21:52.575238
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(1))) == \
                                                 datetime_module.timedelta(1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0))) == \
                                                 datetime_module.timedelta(0)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0,
                                                                     1))) == \
                                         datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(0, 0,
                                                                     1, 1))) == \
                                         datetime_module.timedelta(0, 0, 1, 1)
    assert timed

# Generated at 2022-06-22 18:22:05.061145
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) \
                            == '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3)) \
                            == '01:02:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      microseconds=3)) \
                            == '01:02:00.000003'

# Generated at 2022-06-22 18:22:11.950250
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta, expected_string in (
        (datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=456789),
         '01:02:03.456789'),
    ):
        assert timedelta_format(timedelta) == expected_string



# Generated at 2022-06-22 18:22:18.372933
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = time_isoformat(datetime_module.time(hour=12, minute=34,
                                               second=56, microsecond=789000))
    assert datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                     microseconds=789000) == timedelta_parse(time)



# Generated at 2022-06-22 18:22:24.593091
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=123,
                                                      microseconds=456789)) == \
        "00:02:03.456789"
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=5,
                                                      seconds=6,
                                                      microseconds=789123)) == \
        "04:05:06.789123"



# Generated at 2022-06-22 18:22:27.565266
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_timedelta
    for test_delta, test_string in test_timedelta.test_pairs:
        assert timedelta_format(test_delta) == test_string
