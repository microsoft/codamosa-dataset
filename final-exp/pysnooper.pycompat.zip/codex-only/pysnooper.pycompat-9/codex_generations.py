

# Generated at 2022-06-22 18:12:35.694255
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-22 18:12:40.465371
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) \
                                                      == '01:02:03.000004'


# Generated at 2022-06-22 18:12:45.034104
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('2:3:4.123456')) == \
                                                         '02:03:04.123456'
    assert timedelta_parse('2:3:4.123456') == \
        datetime_module.timedelta(hours=2, minutes=3,
                                  seconds=4, microseconds=123456)

# Generated at 2022-06-22 18:12:51.898144
# Unit test for function timedelta_format
def test_timedelta_format():
    from .timing import (timedelta_format, timedelta_parse)
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('''
    23:59:58.999999
    ''')) == '23:59:58.999999'

# Generated at 2022-06-22 18:12:56.329680
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)

# Generated at 2022-06-22 18:13:02.000708
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('02:03:04.056789')
    assert timedelta == datetime_module.timedelta(hours=2, minutes=3,
                                                  seconds=4, microseconds=56789)


# Generated at 2022-06-22 18:13:04.931866
# Unit test for function timedelta_format
def test_timedelta_format():
    t = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  milliseconds=4, microseconds=5)
    assert timedelta_format(t) == '01:02:03.004005'


# Generated at 2022-06-22 18:13:15.157630
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest
    for i in range(-1439, 1440, 1):
        for j in range(0, 1000000, 1):
            timedelta = datetime_module.timedelta(minutes=i, microseconds=j)
            assert timedelta == timedelta_parse(timedelta_format(timedelta))


if hasattr(os, 'scandir'):
    scandir = os.scandir
else:
    def scandir(path='.'):
        """scandir('.') -> iterator of DirEntry objects for given directory.

        The elements are yielded in arbitrary order.
        The special entries '.' and '..' are not returned."""
        from collections import namedtuple
        from os import stat

        scandir_entry = namedtuple('scandir_entry', 'name, stat')


# Generated at 2022-06-22 18:13:19.064973
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=567890
    )) == '02:03:04.567890'


# Generated at 2022-06-22 18:13:22.263099
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=12, minutes=24,
                                          seconds=4, microseconds=180)
    assert timedelta_format(timedelta) == '12:24:04.000180'



# Generated at 2022-06-22 18:13:33.511233
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.100000') == datetime_module.timedelta(microseconds=100000)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(
        hours=1, seconds=1
    )

# Generated at 2022-06-22 18:13:41.145640
# Unit test for function timedelta_format
def test_timedelta_format():
    from python_toolbox import cute_testing
    assert timedelta_format(datetime_module.timedelta(seconds=2.3)) == \
           '00:00:02.300000'
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == \
           '00:00:02.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.5)) == \
           '00:00:00.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=0.1234)) == \
           '00:00:00.123400'

# Generated at 2022-06-22 18:13:52.100302
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == \
                                              datetime_module.timedelta(0)
    assert timedelta_parse('00:01:02.012345') == \
                                             datetime_module.timedelta(seconds=62,
                                                                       microseconds=12345)
    assert timedelta_parse('03:00:00.000000') == \
                                             datetime_module.timedelta(seconds=3 * 60 * 60)
    assert timedelta_parse('03:02:01.112233') == \
                                             datetime_module.timedelta(seconds=3 * 60 * 60 +
                                                                       2 * 60 + 1,
                                                                       microseconds=112233)

# Generated at 2022-06-22 18:14:03.377088
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)

    assert timedelta_parse('0:0:1.000000') == datetime_module.timedelta(
        seconds=1)
    
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1)
    
    assert timedelta_parse('0:0:0.010000') == datetime_module.timedelta(
        microseconds=10000)
    
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10)
    

# Generated at 2022-06-22 18:14:10.977997
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=5,
        minutes=6,
        seconds=7,
        microseconds=654321
    )) == '05:06:07.654321'
    import timeit
    timeit_result_timeit = timeit.timeit(
        'timedelta_format(datetime_module.timedelta(hours=5, minutes=6, '
        'seconds=7, microseconds=654321))',
        'from __main__ import timedelta_format, datetime_module',
        number=100000,
    )

# Generated at 2022-06-22 18:14:23.220322
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=7)
    assert timedelta_format(timedelta) == '168:00:00.000000'
    timedelta = datetime_module.timedelta(hours=5, minutes=3, seconds=7,
                                          microseconds=66)
    assert timedelta_format(timedelta) == '05:03:07.000066'
    timedelta = datetime_module.timedelta(hours=5, minutes=3, seconds=7,
                                          microseconds=667777)
    assert timedelta_format(timedelta) == '05:03:07.667777'
    timedelta = datetime_module.timedelta(hours=5, minutes=3, seconds=7,
                                          microseconds=66777788)

# Generated at 2022-06-22 18:14:31.884641
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4)) == \
            '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=45)) == \
            '01:02:03.000045'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456)) == \
            '01:02:03.000456'

# Generated at 2022-06-22 18:14:37.716047
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=3,
                                                      seconds=4,
                                                      microseconds=5)) == \
                                                      '02:03:04.000005'
    assert timedelta_parse('02:03:04.000005') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=5
    )

# Generated at 2022-06-22 18:14:45.570742
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
                                                        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                        '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                        '01:00:00.000000'

# Generated at 2022-06-22 18:14:52.824706
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(hours=1, seconds=1, minutes=1,
                                  microseconds=1)
    ) == '01:01:01.000001'
    assert timedelta_format(
        datetime_module.timedelta(hours=0, seconds=0, minutes=0,
                                  microseconds=0)
    ) == '00:00:00.000000'



# Generated at 2022-06-22 18:15:03.413453
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1)
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456)
    assert timedelta_parse('01:02:03.123000') == datetime_module.tim

# Generated at 2022-06-22 18:15:06.758013
# Unit test for function timedelta_parse
def test_timedelta_parse():
    """Make sure that timedelta_parse() properly parses a string."""
    timedelta = datetime_module.timedelta(days=12, seconds=23.123456789)
    string = timedelta_format(timedelta)
    assert timedelta == timedelta_parse(string)

# Generated at 2022-06-22 18:15:17.584011
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert str(timedelta_parse('1:2:3.456789')) == '1:02:03.456789'
    assert str(timedelta_parse('1:2:3.45')) == '1:02:03.045000'
    assert str(timedelta_parse('1:2:3.4')) == '1:02:03.004000'
    assert str(timedelta_parse('1:2:3')) == '1:02:03'
    assert str(timedelta_parse('1:2')) == '1:02:00'
    assert str(timedelta_parse('1')) == '0:01:00'
    assert str(timedelta_parse('1:2:3:4')) == '1:02:03:04'
   

# Generated at 2022-06-22 18:15:21.624830
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=5, minutes=2, seconds=3, microseconds=123456
    ))) == datetime_module.timedelta(hours=5, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:15:33.323916
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1,
                                                      microseconds=1)) == '00:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                                      microseconds=1)) == '01:01:01.000001'

# Generated at 2022-06-22 18:15:38.391211
# Unit test for function timedelta_parse
def test_timedelta_parse():
    dt = timedelta_parse('3:56:10.000001')
    assert dt == datetime_module.timedelta(hours=3, minutes=56, seconds=10,
                                           microseconds=1)
    dt_alt = datetime_module.timedelta(hours=3, minutes=56, seconds=10,
                                       microseconds=1)
    assert dt == dt_alt


# Generated at 2022-06-22 18:15:45.108677
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '24:00:00.000000'



# Generated at 2022-06-22 18:15:53.642808
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = [
        datetime_module.timedelta(seconds=0),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(microseconds=1),
        datetime_module.timedelta(microseconds=10),
        datetime_module.timedelta(microseconds=100),
        datetime_module.timedelta(seconds=1, microseconds=1),
        datetime_module.timedelta(seconds=1, microseconds=10),
        datetime_module.timedelta(seconds=1, microseconds=100),
        datetime_module.timedelta(minutes=1, seconds=1),
        datetime_module.timedelta(hours=1, minutes=1, seconds=1),
    ]

# Generated at 2022-06-22 18:16:04.755904
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:16:17.095267
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('00:00:01.000000')) == \
           '00:00:01.000000'
    assert timedelta_format(timedelta_parse('01:00:01.000000')) == \
           '01:00:01.000000'
    assert timedelta_format(timedelta_parse('01:00:01.000001')) == \
           '01:00:01.000001'
    assert timedelta_format(timedelta_parse('01:02:03.000004')) == \
           '01:02:03.000004'

# Generated at 2022-06-22 18:16:23.456565
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(weeks=1, days=6, hours=5, minutes=4,
                                   seconds=3, microseconds=2000002)
    assert timedelta_format(td) == '115:04:03.000002'



# Generated at 2022-06-22 18:16:28.355675
# Unit test for function timedelta_parse
def test_timedelta_parse():
    delta1 = timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1
    )))
    delta2 = datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1,
                                       microseconds=1)
    assert delta1 == delta2

# Generated at 2022-06-22 18:16:38.428538
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=1, minutes=1,
                                          seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '25:01:01.000001'
    timedelta = datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                          microseconds=1)
    assert timedelta_format(timedelta) == '01:01:01.000001'
    timedelta = datetime_module.timedelta(minutes=1, seconds=1, microseconds=1)
    assert timedelta_format(timedelta) == '00:01:01.000001'
    timedelta = datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_

# Generated at 2022-06-22 18:16:46.021638
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.123456') == datetime_module.timedelta(
        microseconds=123456
    )
    assert timedelta_parse('00:00:01.123456') == datetime_module.timedelta(
        seconds=1,
        microseconds=123456
    )
    assert timedelta_parse('00:01:00.123456') == datetime_module.timedelta(
        minutes=1,
        seconds=0,
        microseconds=123456
    )

# Generated at 2022-06-22 18:16:57.586449
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert repr(timedelta_parse('00:01:02.123456')) == \
        'datetime.timedelta(seconds=62, microseconds=123456)'
    assert repr(timedelta_parse('00:01:02.123456789')) == \
        'datetime.timedelta(seconds=62, microseconds=123456)'
    assert repr(timedelta_parse('00:01:02.123')) == \
        'datetime.timedelta(seconds=62, microseconds=123000)'
    assert repr(timedelta_parse('00:01:02.12')) == \
        'datetime.timedelta(seconds=62, microseconds=120000)'

# Generated at 2022-06-22 18:17:02.158883
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=2, minutes=3, seconds=4, microseconds=1
    ))) == datetime_module.timedelta(days=1, hours=2, minutes=3, seconds=4,
                                     microseconds=1)

# Generated at 2022-06-22 18:17:06.332959
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = timedelta_parse('1:1:1.000001')
    assert timedelta == datetime_module.timedelta(hours=1, minutes=1,
                                                  seconds=1, microseconds=1)

    timedelta = timedelta_parse('0:0:0.000001')
    assert timedelta == datetime_module.timedelta(microseconds=1)


# Generated at 2022-06-22 18:17:17.552134
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=1)) == \
           '00:00:01.000001'

# Generated at 2022-06-22 18:17:27.109349
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('01:00:01.000001') == datetime_module.timedelta(
        hours=1, seconds=1, microseconds=1
    )

# Generated at 2022-06-22 18:17:31.858608
# Unit test for function timedelta_format
def test_timedelta_format():
    for timedelta_value in range(100_000):
        assert timedelta_parse(timedelta_format(
            datetime_module.timedelta(microseconds=timedelta_value)
        )) == datetime_module.timedelta(microseconds=timedelta_value)


delimiters = (' ', '\t', ',', ':', '.')


# Generated at 2022-06-22 18:17:39.562870
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        milliseconds=1004
    ))) == datetime_module.timedelta(milliseconds=1004)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        milliseconds=3.004
    ))) == datetime_module.timedelta(milliseconds=3.004)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1004, seconds=3
    ))) == datetime_module.timedelta(hours=1004, seconds=3)


try:
    from itertools import zip_longest
except ImportError:
    from itertools import izip_longest as zip_longest



# Generated at 2022-06-22 18:17:46.609770
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:34:56.789012') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789012)
    assert timedelta_parse('-12:34:56.789012') == datetime_module.timedelta(
        hours=-12, minutes=-34, seconds=-56, microseconds=-789012)
    assert timedelta_parse('.789012') == datetime_module.timedelta(
        microseconds=789012)

# Generated at 2022-06-22 18:17:50.384247
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:14:15.675813') == (
        datetime_module.timedelta(hours=2, minutes=14, seconds=15,
                                  microseconds=675813)
    )



# Generated at 2022-06-22 18:17:59.927832
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) == \
           '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(days=0, hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    ) == '01:02:03.000004'



# Generated at 2022-06-22 18:18:08.693700
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=2, minutes=35, seconds=6,
                                  microseconds=937)
    )) == datetime_module.timedelta(hours=2, minutes=35, seconds=6,
                                    microseconds=937)


if PY3:
    def get_next_method(method):
        return method.__func__.__get__(method.__self__, method.__self__.__class__)
else:
    def get_next_method(method):
        return method.im_func.__get__(method.im_self, method.im_class)

# Generated at 2022-06-22 18:18:20.783344
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
           '01:02:03.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
           '01:01:00.000000'

# Generated at 2022-06-22 18:18:24.852444
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=3, minutes=8, seconds=12, microseconds=34567
    ))) == datetime_module.timedelta(hours=3, minutes=8, seconds=12,
                                     microseconds=34567)



# Generated at 2022-06-22 18:18:27.680971
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) == \
        '01:02:03.000004'



# Generated at 2022-06-22 18:18:39.295957
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:1.100000') == datetime_module.timedelta(
        microseconds=100000
    )
    assert timedelta_parse('0:0:1.120000') == datetime_module.timedelta(
        microseconds=120000
    )
    assert timedelta_parse('0:0:1.123000') == datetime_module.timedelta(
        microseconds=123000
    )
    assert timedelta_parse('0:0:1.123400') == datetime_module.timedelta(
        microseconds=123400
    )
    assert timedelta_parse('0:0:1.123450') == datetime_module.timedelta(
        microseconds=123456
    )

# Generated at 2022-06-22 18:18:51.929003
# Unit test for function timedelta_format
def test_timedelta_format():
    import pytest

# Generated at 2022-06-22 18:19:01.898175
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1,
        minutes=1,
        seconds=1,
        microseconds=100000,
    )
    assert timedelta_parse('1:1:1.0100') == datetime_module.timedelta(
        hours=1,
        minutes=1,
        seconds=1,
        microseconds=10000,
    )
    assert timedelta_parse('1:1:1.010100') == datetime_module.timedelta(
        hours=1,
        minutes=1,
        seconds=1,
        microseconds=10010,
    )

# Generated at 2022-06-22 18:19:08.421291
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(days=10, hours=3, minutes=14, seconds=5,
                                  microseconds=2)
    ) == '03:14:05.000002'

    assert timedelta_format(
        datetime_module.timedelta(days=10, hours=3, minutes=14, seconds=5)
    ) == '03:14:05.000000'

    assert timedelta_format(
        datetime_module.timedelta(days=10, hours=3, minutes=14)
    ) == '03:14:00.000000'

    assert timedelta_format(
        datetime_module.timedelta(days=10, hours=3)
    ) == '03:00:00.000000'


# Generated at 2022-06-22 18:19:15.122728
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2)) == \
           '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=15)) == \
           '02:15:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=15,
                                                      microseconds=123456)) == \
           '02:15:00.123456'



# Generated at 2022-06-22 18:19:25.722866
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.100000') == datetime_module.timedelta(0, 0, 100000)
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:1.0') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:1:0.0') == datetime_module.timedelta(0, 60)

# Generated at 2022-06-22 18:19:28.951911
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    assert timedelta_format(td) == '01:02:03.000004'

# Generated at 2022-06-22 18:19:32.862375
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=8, minutes=4, seconds=3,
                                          microseconds=1234)
    assert timedelta_format(timedelta) == '08:04:03.001234'


# Generated at 2022-06-22 18:19:42.144367
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=3))) == datetime_module.timedelta(days=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=3))) == datetime_module.timedelta(seconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=3, microseconds=3))) == datetime_module.timedelta(seconds=3, microseconds=3)


if hasattr(datetime_module.timezone, 'utc'):
    tz_utc = datetime_module.time

# Generated at 2022-06-22 18:19:50.258420
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=60))) == datetime_module.timedelta(hours=60)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=60))) == datetime_module.timedelta(minutes=60)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=60))) == datetime_module.timedelta(seconds=60)

# Generated at 2022-06-22 18:20:01.501537
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=4, seconds=3, microseconds=2002
    )) == '01:04:03.002002'
    assert timedelta_format(datetime_module.timedelta(
        seconds=65, microseconds=2002
    )) == '00:01:05.002002'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, microseconds=1
    )) == '01:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format

# Generated at 2022-06-22 18:20:14.785507
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3,
                                                      minutes=30,
                                                      seconds=30,
                                                      microseconds=123456)) == \
           '03:30:30.123456'
    assert timedelta_format(datetime_module.timedelta(hours=25,
                                                      minutes=10,
                                                      seconds=50,
                                                      microseconds=450678)) == \
           '25:10:50.450678'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      minutes=15,
                                                      seconds=0,
                                                      microseconds=0)) == \
           '00:15:00.000000'

# Generated at 2022-06-22 18:20:26.789383
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.0') == datetime_module.timedelta(hours=0)
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(hours=0)
    assert timedelta_parse('0:0:0.000000000') == datetime_module.timedelta(hours=0)
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:0:0.1') == datetime_module.timedelta(hours=1)
    assert timedelta_parse('1:0:0.000001') == datetime_module.timedelta(hours=1)

# Generated at 2022-06-22 18:20:36.992451
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('01:00:00.000000') ==\
                                            datetime_module.timedelta(hours=1)
    assert timedelta_parse('00:01:00.000000') ==\
                                            datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:00:01.000000') ==\
                                            datetime_module.timedelta(seconds=1)
    assert timedelta_parse('00:00:00.000001') ==\
                                            datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00.000010') ==\
                                            datetime_module.tim

# Generated at 2022-06-22 18:20:41.478416
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(0, 0, 0, 999999),
                          timespec='microseconds')
    assert time == '00:00:00.999999'



# Generated at 2022-06-22 18:20:48.047870
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=5
    )) == '02:03:04.000005'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=12345
    )) == '02:03:04.012345'
    assert timedelta_format(datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=123456
    )) == '02:03:04.123456'


# Generated at 2022-06-22 18:20:55.299171
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:10:03.000001') == datetime_module.timedelta(0,
                                                     seconds=603,
                                                     microseconds=1)

if sys.version_info < (3, 6):

    def datetime_isoformat(datetime):
        assert isinstance(datetime, datetime_module.datetime)
        return '{}T{}'.format(
            datetime.date().isoformat(),
            time_isoformat(datetime.time(), 'microseconds').rstrip('0')
        )
else:
    datetime_isoformat = datetime_module.datetime.isoformat


# Generated at 2022-06-22 18:21:01.997418
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=123456)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta
    assert timedelta_format(timedelta_parse('1:02:03.123456')) == '01:02:03.123456'

# Generated at 2022-06-22 18:21:07.568979
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == \
           '00:00:01.000002'
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
                                                seconds=1,
                                                microseconds=2)
                                            )
                           ) == datetime_module.timedelta(seconds=1,
                                                          microseconds=2)

# Generated at 2022-06-22 18:21:14.396943
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=23,
                                                      seconds=45,
                                                      microseconds=86)) == \
        '02:23:45.000086'


# Generated at 2022-06-22 18:21:27.098266
# Unit test for function timedelta_parse
def test_timedelta_parse():
    dt = datetime_module.timedelta(hours=1, minutes=3, seconds=55,
                                  microseconds=123456)
    assert timedelta_parse(timedelta_format(dt)) == dt
    assert timedelta_format(timedelta_parse('01:03:55.123456')) == \
                                                 '01:03:55.123456'
    assert timedelta_parse('01:03:55.123456'.replace('.', ':')) == dt
    assert timedelta_format(dt.replace(seconds=0)) == '01:03:00.000000'
    assert timedelta_parse('1:03:55.123456') == dt
    assert timedelta_format(dt.replace(microseconds=0)) == '01:03:55.000000'
    assert timedelta_

# Generated at 2022-06-22 18:21:31.216332
# Unit test for function timedelta_parse
def test_timedelta_parse():
    dt = datetime_module.datetime.now()
    assert timedelta_format(dt - dt - datetime_module.timedelta(days=1)) == \
           '-1:00:00:00.000000'



# Generated at 2022-06-22 18:21:39.573609
# Unit test for function timedelta_format
def test_timedelta_format():
    """
    Test `timedelta_format` and `timedelta_parse` on all timedeltas that can
    be represented by `datetime.datetime.min + datetime.timedelta`
    """
    check_timedelta_format(datetime_module.timedelta(0))
    for hours in range(24):
        for minutes in range(60):
            for seconds in range(60):
                for microseconds in range(0, 1000000, 10000):
                    check_timedelta_format(
                        datetime_module.timedelta(hours=hours,
                                                  minutes=minutes,
                                                  seconds=seconds,
                                                  microseconds=microseconds)
                    )



# Generated at 2022-06-22 18:21:50.617612
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:22:00.605174
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (
        datetime_module.timedelta(hours=0, minutes=0, seconds=0, microseconds=1),
        datetime_module.timedelta(hours=0, minutes=0, seconds=1, microseconds=1),
        datetime_module.timedelta(hours=0, minutes=1, seconds=1, microseconds=1),
        datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1),
    ):
        assert timedelta_format(timedelta) == timedelta_parse(
            timedelta_format(timedelta)
        )

# Generated at 2022-06-22 18:22:04.082988
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:11:12.123456') == datetime_module.timedelta(
        hours=10, minutes=11, seconds=12, microseconds=123456
    )



# Generated at 2022-06-22 18:22:15.293181
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('1:2:3.012345') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=12345)
    assert timedelta_parse('1:2:3.0123') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=12300)

# Generated at 2022-06-22 18:22:26.862197
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0,   1)
    assert timedelta_parse('0:0:0.000009') == datetime_module.timedelta(0, 0,   9)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(0, 0,  10)
    assert timedelta_parse('0:0:0.000099') == datetime_module.timedelta(0, 0,  99)
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(0, 0, 100)