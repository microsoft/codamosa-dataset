

# Generated at 2022-06-22 18:12:30.046908
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=2)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
           '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=123)) == \
           '00:00:00.000123'


# Generated at 2022-06-22 18:12:38.593763
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == (
        '01:00:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(miniutes=1)) == (
        '00:01:00.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=2)) == (
        '00:00:01.000002'
    )

# Generated at 2022-06-22 18:12:44.750877
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('01:01:00.000000') == datetime_module.timedelta(
        hours=1, minutes=1
    )
    assert timedelta_parse('01:01:01.000000') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1
    )
    assert timedelta_parse('01:01:01.000001') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )

# Generated at 2022-06-22 18:12:54.023706
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('12:13:14.151617') == datetime_module.timedelta(
        hours=12, minutes=13, seconds=14, microseconds=151617)
    assert timedelta_parse('12:13:14.000000') == datetime_module.timedelta(
        hours=12, minutes=13, seconds=14)
    assert timedelta_parse('00:13:14.000000') == datetime_module.timedelta(
        minutes=13, seconds=14)
    assert timedelta_parse('00:00:14.000000') == datetime_module.timedelta(
        seconds=14)

# Generated at 2022-06-22 18:13:03.025110
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == '00:00:00.000001'
    assert timedelta_format(timedelta_parse('0:00:00.000010')) == '00:00:00.000010'
    assert timedelta_format(timedelta_parse('0:00:00.000100')) == '00:00:00.000100'
    assert timedelta_format(timedelta_parse('0:00:00.001000')) == '00:00:00.001000'

# Generated at 2022-06-22 18:13:14.142959
# Unit test for function timedelta_format
def test_timedelta_format():
    time_regex = r'^\d\d:\d\d:\d\d\.\d*$'
    datetime_pattern = datetime_module.datetime.strptime(
        '00:00:00.0',
        time_regex
    )
    datetime_regex = datetime_pattern.strftime(time_regex)
    import re
    assert re.match(datetime_regex, timedelta_format(datetime_module.timedelta()))
    assert re.match(datetime_regex, timedelta_format(datetime_module.timedelta(microseconds=1)))
    assert re.match(datetime_regex, timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)))

# Generated at 2022-06-22 18:13:20.718629
# Unit test for function timedelta_format
def test_timedelta_format():
    delta = datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_format(delta) == '01:02:03.000004'

    delta = datetime_module.timedelta(
        hours=-1, minutes=-2, seconds=-3, microseconds=-4
    )
    assert timedelta_format(delta) == '-01:-02:-03.-000004'



# Generated at 2022-06-22 18:13:33.025352
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=1234567
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )

# Generated at 2022-06-22 18:13:35.768935
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000001') == (
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=1))



# Generated at 2022-06-22 18:13:42.272405
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=70)) == '00:01:10.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=120)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2)) == '02:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '72:00:00.000000'

# Generated at 2022-06-22 18:13:54.018309
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.0') ==  datetime_module.timedelta(microseconds=0)
    assert timedelta_parse('.6') ==  datetime_module.timedelta(microseconds=6)
    assert timedelta_parse('.06') == datetime_module.timedelta(microseconds=60)
    assert timedelta_parse('.006') == datetime_module.timedelta(microseconds=6)
    assert timedelta_parse('.0006') == datetime_module.timedelta(microseconds=6)

    assert timedelta_parse(':0.0') ==  datetime_module.timedelta(seconds=0)
    assert timedelta_parse(':0.6') ==  datetime_module.timedelta(seconds=0, microseconds=600000)
    assert timedelta

# Generated at 2022-06-22 18:14:02.237378
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, hours=1, seconds=1)) == '01:00:01.000000'


# Generated at 2022-06-22 18:14:06.578713
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for s in (
        '0:00:00.000000',
        '12:36:08.439222',
        '-12:36:08.439222',
    ):
        assert timedelta_format(timedelta_parse(s)) == s

# Generated at 2022-06-22 18:14:10.549829
# Unit test for function timedelta_parse
def test_timedelta_parse():
    s = '03:04:05.006'
    dt = timedelta_parse(s)
    assert dt.seconds == 11_445
    assert dt.microseconds == 6
    assert dt == datetime_module.timedelta(hours=3, minutes=4, seconds=5,
                                           microseconds=6)


# Generated at 2022-06-22 18:14:13.293127
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                           seconds=3, microseconds=123456)) == '01:02:03.123456'

# Generated at 2022-06-22 18:14:19.535763
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == (
        datetime_module.timedelta(1) +
        datetime_module.timedelta(minutes=2) +
        datetime_module.timedelta(seconds=3) +
        datetime_module.timedelta(microseconds=123456)
    )

# Generated at 2022-06-22 18:14:29.330179
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(8, 3, 29, 1))
    assert time == "08:03:29.000001"
    assert timedelta_format(datetime_module.timedelta(seconds=42)) == \
           "00:00:42.000000"
    assert timedelta_format(datetime_module.timedelta(seconds=42,
                                                      microseconds=1)) == \
           "00:00:42.000001"
    assert timedelta_format(datetime_module.timedelta(seconds=42,
                                                      microseconds=123)) == \
           "00:00:42.000123"

# Generated at 2022-06-22 18:14:32.656032
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=500000)) == \
           '00:00:01.500000'



# Generated at 2022-06-22 18:14:36.911304
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)
    )) == datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                    microseconds=1)

# Generated at 2022-06-22 18:14:45.052395
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=6,
                                                      seconds=25)) == \
                                                          '03:06:25.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=37,
                                                      seconds=28,
                                                      microseconds=183782)) == \
                                                          '02:37:28.183782'
    assert timedelta_format(datetime_module.timedelta(minutes=5, seconds=12,
                                                      microseconds=854823)) == \
                                                          '00:05:12.854823'

# Generated at 2022-06-22 18:14:54.167854
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=3)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(minutes=2)) == '00:02:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=3,
                                                      microseconds=500)) == \
                           '04:03:00.000500'


# Generated at 2022-06-22 18:15:04.829302
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(
        datetime_module.timedelta(
            days=0, hours=0, minutes=0, seconds=0, microseconds=0,
        )
    ) == '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(
            days=0, hours=1, minutes=2, seconds=3, microseconds=456,
        )
    ) == '01:02:03.000456'
    assert timedelta_format(
        datetime_module.timedelta(
            days=1, hours=2, minutes=3, seconds=4, microseconds=567,
        )
    ) == '26:02:03.000567'

# Generated at 2022-06-22 18:15:11.889105
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_parse_is_inverse_of_format(timedelta):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))
    assert_timedelta_parse_is_inverse_of_format(datetime_module.timedelta(0))
    assert_timedelta_parse_is_inverse_of_format(
        datetime_module.timedelta(days=1)
    )
    assert_timedelta_parse_is_inverse_of_format(
        datetime_module.timedelta(hours=1)
    )
    assert_timedelta_parse_is_inverse_of_format(
        datetime_module.timedelta(minutes=1)
    )
    assert_timedelta_parse_is_in

# Generated at 2022-06-22 18:15:20.974337
# Unit test for function timedelta_format
def test_timedelta_format():

    time_isoformat_old_function = time_isoformat
    try:
        time_isoformat = lambda *args, **kwargs: NotImplemented
        assert timedelta_format(datetime_module.timedelta(hours=6,
                                                          minutes=7,
                                                          seconds=8,
                                                          microseconds=9)) == '06:07:08.000009'
    finally:
        time_isoformat = time_isoformat_old_function



# Generated at 2022-06-22 18:15:32.534654
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40000
    )
    assert timedelta_parse('1:2:3.040') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=40
    )
    assert timedelta_parse('1:2:3') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3
    )
    assert timedelta_parse('1:2') == datetime_module.timedelta(
        hours=1, minutes=2
    )
    assert timedelta_parse('1') == datetime_module.timedelta(
        hours=1
    )


#

# Generated at 2022-06-22 18:15:41.322479
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('00:00:00.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('00:00:00.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-22 18:15:50.402967
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
            hours=1, minutes=10, seconds=20, microseconds=5000000
        )) == '01:10:20.500000'
    assert timedelta_format(datetime_module.timedelta(
            hours=-2, minutes=10, seconds=20, microseconds=-5000000
        )) == '-02:10:20.500000'
    assert timedelta_format(datetime_module.timedelta(
            hours=24, minutes=60, seconds=60, microseconds=1000000
        )) == '24:60:60.000000'



# Generated at 2022-06-22 18:16:02.170799
# Unit test for function timedelta_format
def test_timedelta_format():
    all_cases = [
        (datetime_module.timedelta(seconds=1), '00:00:01.000000'),
        (datetime_module.timedelta(seconds=1, microseconds=123456),
         '00:00:01.123456'),
        (datetime_module.timedelta(seconds=1, microseconds=1234560),
         '00:00:01.123456'),
        (datetime_module.timedelta(seconds=61), '00:01:01.000000'),
        (datetime_module.timedelta(minutes=61), '01:01:00.000000'),
    ]
    for timedelta, expected in all_cases:
        assert timedelta_format(timedelta) == expected


# Generated at 2022-06-22 18:16:05.808473
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                   seconds=5, microseconds=6)
    assert (timedelta_format(td) ==
            '03:04:05.000006')


# Generated at 2022-06-22 18:16:18.514244
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=12,
                                                      microseconds=999999)) == '26:03:12.999999'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=12,
                                                      microseconds=999999)) == '02:03:12.999999'
    assert timedelta_format(datetime_module.timedelta(minutes=3, seconds=12,
                                                      microseconds=999999)) == '00:03:12.999999'

# Generated at 2022-06-22 18:16:24.199897
# Unit test for function timedelta_format
def test_timedelta_format():
    microseconds = 3722
    timedelta = datetime_module.timedelta(microseconds=microseconds)
    assert timedelta_format(timedelta) == '00:00:00.003722'
    assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-22 18:16:26.666622
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(seconds=9001)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:16:29.858198
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(microseconds=645660)
    assert timedelta_format(timedelta) == '00:01:04.5660'



# Generated at 2022-06-22 18:16:38.576557
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(0, 0, 10)
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(0, 0, 100)
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(0, 0, 1000)
    assert timedelta_parse('0:0:0.010000') == datetime_module.timedelta(0, 0, 10000)
    assert timedelta_parse

# Generated at 2022-06-22 18:16:43.096094
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest

    assert timedelta_parse('1:01:01.010101') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=10101
    )

    with pytest.raises(ValueError):
        timedelta_parse('1:01:01.0101011')

    with pytest.raises(TypeError):
        timedelta_parse(None)

# Generated at 2022-06-22 18:16:48.353787
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=1, hours=2, minutes=3,
                                          seconds=4, microseconds=5)

    assert timedelta_format(timedelta) == '50:03:04.000005'
    assert timedelta_format(timedelta.total_seconds()) == '50:03:04.000005'



# Generated at 2022-06-22 18:16:51.596774
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:02:003005') == \
           datetime_module.timedelta(minutes=1, seconds=2, microseconds=3005)

# Generated at 2022-06-22 18:17:02.120319
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for time in (
        '00:00:00.000000',
        '01:02:03.000004',
        '1:2:3.4',
        '1:2:3.400000',
        '1:2:3.40000',
        '1:2:3.4000',
        '1:2:3.400',
        '1:2:3.40',
        '1:2:3.4',
        '0:0:0.000000',
        '123:59:59.999999',
        '12:34:56.789012',
    ):
        parsed_time = timedelta_parse(time)
        formatted_time = timedelta_format(parsed_time)
        assert time == formatted_time

if __name__ == '__main__':
    import py

# Generated at 2022-06-22 18:17:09.565765
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=59,
                                                      seconds=59,
                                                      microseconds=999999)) == '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(hours=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      seconds=1,
                                                      microseconds=123456)) == '00:00:01.123456'



# Generated at 2022-06-22 18:17:20.107737
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('00:02:30.000000') == datetime_module.timedelta(
        minutes=2, seconds=30
    )
    assert timedelta_parse('02:00:00.000000') == datetime_module.timedelta(
        hours=2
    )
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('00:00:30.000000') == datetime_module.timedelta(
        seconds=30
    )

# Generated at 2022-06-22 18:17:29.445165
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                          seconds=5,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '03:04:05.123456'
    timedelta = datetime_module.timedelta(days=2, hours=3, minutes=4,
                                          seconds=5,
                                          microseconds=0)
    assert timedelta_format(timedelta) == '03:04:05.000000'



# Generated at 2022-06-22 18:17:32.212220
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:45:00.123456') == datetime_module.timedelta(
        hours=12, minutes=45, seconds=0, microseconds=123456
    )


# Generated at 2022-06-22 18:17:44.852410
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:17:48.963425
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(minutes=10))) == datetime_module.timedelta(minutes=10)

test_timedelta_parse()

# Generated at 2022-06-22 18:17:59.261337
# Unit test for function timedelta_format
def test_timedelta_format():
    from .testing import assert_equal
    assert_equal(timedelta_format(datetime_module.timedelta(0)),
                 '00:00:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=1)),
                 '00:00:01.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(seconds=60)),
                 '00:01:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=1)),
                 '00:01:00.000000')
    assert_equal(timedelta_format(datetime_module.timedelta(minutes=60)),
                 '01:00:00.000000')

# Generated at 2022-06-22 18:18:09.116760
# Unit test for function timedelta_format
def test_timedelta_format():
    # These are taken from Python 3.6 manual, see
    # <https://docs.python.org/3.6/library/datetime.html?highlight=timedelta#datetime.timedelta>
    assert timedelta_format(datetime_module.timedelta(
        days=0, seconds=0, microseconds=0,
        milliseconds=0, minutes=0, hours=0, weeks=0)
    ) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        days=1, seconds=2, microseconds=3,
        milliseconds=0, minutes=0, hours=0, weeks=0)
    ) == '1 day, 00:00:02.000003'

# Generated at 2022-06-22 18:18:13.484128
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=10, minutes=12, seconds=13,
                                          microseconds=876)
    assert timedelta_format(timedelta) == '10:12:13.000876'



# Generated at 2022-06-22 18:18:24.712613
# Unit test for function timedelta_parse
def test_timedelta_parse(): 
    assert timedelta_parse('0:00:00.123000') == datetime_module.timedelta(0, 0, 123)
    assert timedelta_parse('0:00:00.000') == datetime_module.timedelta(0, 0, 0) 
    assert timedelta_parse('0:02:00.210000') == datetime_module.timedelta(0, 120, 210000)
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0, 0, 0)
    assert timedelta_parse('-0:01:00.000000') == datetime_module.timedelta(0, -60, 0)
    assert timedelta_parse('1:00:00.000000') == datetime_module.timedelta(0, 3600, 0)

# Generated at 2022-06-22 18:18:35.986577
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(weeks=1)) == '168:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format

# Generated at 2022-06-22 18:18:44.388605
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=56789
    )
    assert timedelta_format(timedelta) == '02:03:04.056789'
    timedelta = datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=789012
    )
    assert timedelta_format(timedelta) == '12:34:56.789012'
    timedelta = datetime_module.timedelta(
        hours=23, minutes=59, seconds=59, microseconds=999999
    )
    assert timedelta_format(timedelta) == '23:59:59.999999'



# Generated at 2022-06-22 18:18:55.078918
# Unit test for function timedelta_parse
def test_timedelta_parse():
    def assert_timedelta_parse(s, timedelta):
        assert timedelta == timedelta_parse(s)
        assert s == timedelta_format(timedelta)

    assert_timedelta_parse('0:00:00.000000',
                           datetime_module.timedelta(seconds=0))
    assert_timedelta_parse('1:00:00.000000',
                           datetime_module.timedelta(hours=1))
    assert_timedelta_parse('2:00:00.000000',
                           datetime_module.timedelta(hours=2))
    assert_timedelta_parse('3:00:00.000000',
                           datetime_module.timedelta(hours=3))

# Generated at 2022-06-22 18:19:04.708349
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                    '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(milliseconds=1)) == \
                                                    '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                    '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                    '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                    '01:00:00.000000'

# Generated at 2022-06-22 18:19:15.821249
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                  microseconds=4)
    )) == datetime_module.timedelta(hours=3, minutes=2, seconds=1,
                                    microseconds=4)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2, seconds=1)
    )) == datetime_module.timedelta(hours=3, minutes=2, seconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=3, minutes=2)
    )) == datetime_module.timedelta(hours=3, minutes=2)
    assert timedelta_

# Generated at 2022-06-22 18:19:18.776966
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=10, minutes=5, seconds=2,
                                          microseconds=42)

    assert timedelta == timedelta_parse(timedelta_format(timedelta))



# Generated at 2022-06-22 18:19:24.284342
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.123456') == \
                                 datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('2:3:4.567890') == datetime_module.timedelta(
        hours=2, minutes=3, seconds=4, microseconds=567890)



# Generated at 2022-06-22 18:19:35.199554
# Unit test for function timedelta_format
def test_timedelta_format():
    def assert_format_passed(timedelta, expected_result):
        assert timedelta_format(timedelta) == expected_result
    def assert_format_failed(timedelta):
        try:
            timedelta_format(timedelta)
        except NotImplementedError:
            pass
        else:
            assert 0, 'Expected NotImplementedError'

    assert_format_passed(datetime_module.timedelta(hours=23, minutes=11,
                                                   seconds=20,
                                                   microseconds=1),
                         '23:11:20.000001')

# Generated at 2022-06-22 18:19:41.275902
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:0:0.000000')) == \
                                                  '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1:2:3.456000')) == \
                                                  '01:02:03.456000'
    assert timedelta_format(timedelta_parse('2:3:4.567000')) == \
                                                  '02:03:04.567000'

# Generated at 2022-06-22 18:19:47.028827
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1,
    ))) == datetime_module.timedelta(
        days=1, hours=1, minutes=1, seconds=1, microseconds=1,
    )



# Generated at 2022-06-22 18:19:53.584516
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(hour=1, minute=2, second=3, microsecond=4)
    assert time_isoformat(time) == '01:02:03.000004'


if PY3:
    def safe_repr(x):
        try:
            return '`{}`'.format(repr(x))
        except Exception:
            return '{!r}'.format(x)
else:
    def safe_repr(x):
        return repr(x)

# Generated at 2022-06-22 18:20:03.239173
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == '00:00:00.999999'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'



# Generated at 2022-06-22 18:20:09.912327
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(
        timedelta_format(datetime_module.timedelta(weeks=100, seconds=100.5))
    ) == datetime_module.timedelta(weeks=100, seconds=100.5)



# Generated at 2022-06-22 18:20:17.605494
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                             '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(
                                 hours=1, minutes=1, seconds=1,
                                 microseconds=1
                             )) == '01:01:01.000001'



# Generated at 2022-06-22 18:20:23.757093
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:1:1.1') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=100
    )
    assert timedelta_parse('1:1:1.10') == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, milliseconds=100
    )



# Generated at 2022-06-22 18:20:32.047807
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                             '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=3)) == \
                             '00:03:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=15)) == \
                             '15:00:00.000000'


# Generated at 2022-06-22 18:20:45.242828
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:2:3.000004')) == '01:02:03.000004'
    assert timedelta_format(timedelta_parse('1:2:3.000055')) == '01:02:03.000055'
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == '01:02:03.123456'
    assert timedelta_format(timedelta_parse('1:2:3.123456')) == '01:02:03.123456'
    assert timedelta_format(timedelta_parse('10:20:30.405060')) == '10:20:30.405060'

# Generated at 2022-06-22 18:20:49.287431
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:20:56.503790
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(1, 86399, 999999)) == \
                           '23:59:59.999999'
    assert timedelta_format(datetime_module.timedelta(0, 1, 2)) == \
                           '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(0, 1)) == \
                           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 1)) == \
                           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == \
                           '00:00:00.000000'



# Generated at 2022-06-22 18:21:07.992855
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000') == \
                 datetime_module.timedelta(0)
    assert timedelta_parse('02:15:59.000') == \
                 datetime_module.timedelta(hours=2, minutes=15, seconds=59)
    assert timedelta_parse('00:00:00.123') == \
                 datetime_module.timedelta(microseconds=123)
    assert timedelta_parse('00:00:00.000123') == \
                 datetime_module.timedelta(microseconds=123)
    assert timedelta_parse('00:00:00.0123') == \
                 datetime_module.timedelta(microseconds=123)
    assert timedelta_parse('00:00:00.123000') == \
                 datetime_

# Generated at 2022-06-22 18:21:18.091376
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:00.000000')) == \
                                                   '00:00:00.000000'
    assert timedelta_format(timedelta_parse('01:02:03.000000')) == \
                                                   '01:02:03.000000'
    assert timedelta_format(timedelta_parse('01:02:03.0000009')) == \
                                                   '01:02:03.0000009'
    assert timedelta_format(timedelta_parse('01:02:03.00000099')) == \
                                                   '01:02:03.00000099'



# Generated at 2022-06-22 18:21:26.263619
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.000010') == datetime_module.timedelta(seconds=1, microseconds=10)
    assert timedelta_parse('00:01:01.000010') == datetime_module.timedelta(minutes=1, seconds=1, microseconds=10)
    assert timedelta_parse('01:01:01.000010') == datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=10)



# Generated at 2022-06-22 18:21:37.618565
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.4') == datetime_module.timedelta(hours=1,
                                                                    minutes=2,
                                                                    seconds=3,
                                                                    microseconds=4)
    assert timedelta_parse('1:02:03.000400') == datetime_module.timedelta(hours=1,
                                                                          minutes=2,
                                                                          seconds=3,
                                                                          microseconds=400)
    assert timedelta_parse('01:02:03.400000') == datetime_module.timedelta(hours=1,
                                                                           minutes=2,
                                                                           seconds=3,
                                                                           microseconds=400000)

# Generated at 2022-06-22 18:21:50.094859
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime
    assert timedelta_format(datetime.timedelta(hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=50000)) == \
           '02:03:04.050000'
    assert timedelta_format(datetime.timedelta(hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=5000)) == \
           '02:03:04.005000'
    assert timedelta_format(datetime.timedelta(hours=2, minutes=3,
                                               seconds=4,
                                               microseconds=500)) == \
           '02:03:04.000500'

# Generated at 2022-06-22 18:22:02.273990
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0,
                                                      microseconds=1)) == '00:00:00:000001'
    assert timedelta_format(datetime_module.timedelta(minutes=5,
                                                      microseconds=2)) == '00:05:00:000002'
    assert timedelta_format(datetime_module.timedelta(seconds=59,
                                                      microseconds=3)) == '00:00:59:000003'
    assert timedelta_format(datetime_module.timedelta(microseconds=4)) == '00:00:00:000004'

# Generated at 2022-06-22 18:22:09.266845
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
                                                       '00:00:00.000000'
    assert timedelta_format(timedelta_parse('0:00:12.000001')) == \
                                                       '00:00:12.000001'
    assert timedelta_format(timedelta_parse('12:34:56.123456')) == \
                                                       '12:34:56.123456'
    assert timedelta_format(timedelta_parse('23:59:59.999999')) == \
                                                       '23:59:59.999999'

# Generated at 2022-06-22 18:22:17.245470
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_format(timedelta_parse('1:00:00.000000')) == '01:00:00.000000'
    assert timedelta_format(timedelta_parse('1:01:00.000000')) == '01:01:00.000000'
    assert timedelta_format(timedelta_parse('1:01:01.000000')) == '01:01:01.000000'
    assert timedelta_format(timedelta_parse('1:01:01.000001')) == '01:01:01.000001'
    assert timedelta_format(timedelta_parse('1:01:01.000010')) == '01:01:01.000010'

# Generated at 2022-06-22 18:22:20.246656
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in map(datetime_module.timedelta, range(100)):
        assert timedelta_parse(timedelta_format(timedelta)) == timedelta