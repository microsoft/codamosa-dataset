

# Generated at 2022-06-22 18:12:30.578889
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=4,
                                          minutes=3,
                                          seconds=2,
                                          microseconds=1)
    assert timedelta_format(timedelta) == '04:03:02.000001'
    timedelta = datetime_module.timedelta(hours=4,
                                          minutes=3,
                                          seconds=2,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '04:03:02.123456'
    timedelta = datetime_module.timedelta(hours=23,
                                          minutes=59,
                                          seconds=59,
                                          microseconds=999999)
    assert timedelta_format(timedelta) == '23:59:59.999999'

# Generated at 2022-06-22 18:12:38.939354
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    from .timing_tools import time_function
    if sys.version_info[:2] == (3, 6):
        input_string = '1:34:05.123456'
        output_timedelta = datetime_module.timedelta(
            hours=1, minutes=34, seconds=5, microseconds=123456
        )
    else:
        input_string = '01:34:05.123456'
        output_timedelta = datetime_module.timedelta(
            hours=1, minutes=34, seconds=5, microseconds=123456
        )
    assert timedelta_parse(input_string) == output_timedelta

# Generated at 2022-06-22 18:12:42.519238
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=12, minutes=34,
                                                      seconds=54,
                                                      microseconds=86)) \
                           == '12:34:54.000086'
    assert timedelta_parse('12:34:54.000086') \
           == datetime_module.timedelta(hours=12, minutes=34,
                                        seconds=54,
                                        microseconds=86)



# Generated at 2022-06-22 18:12:50.087242
# Unit test for function timedelta_format
def test_timedelta_format():
    from .test_pregun import assert_equivalent
    assert_equivalent(
        timedelta_format(datetime_module.timedelta(hours=10, minutes=23,
                                                   seconds=42,
                                                   microseconds=3)),
        (datetime_module.datetime.min +
         datetime_module.timedelta(hours=10, minutes=23, seconds=42,
                                   microseconds=3)).time().isoformat('microseconds')
    )



# Generated at 2022-06-22 18:12:55.436736
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=4, minutes=4,
                                                      seconds=4,
                                                      microseconds=4)) == \
                                                      '04:04:04.000004'


# Generated at 2022-06-22 18:13:02.380289
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(seconds=123456789.123456789)
    assert timedelta_format(timedelta) == '34:17:36.123456'
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta


try:
    if PY2:
        import mock
    else:
        import unittest.mock as mock
except ImportError:
    # Do you want to test me, pretty baby?
    import unittest.mock as mock

# Generated at 2022-06-22 18:13:07.494420
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1,
        minutes=2,
        seconds=3.456,
    )) == '01:02:03.456000'



# Generated at 2022-06-22 18:13:10.724167
# Unit test for function timedelta_parse
def test_timedelta_parse():
    
    td = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                   microseconds=123000)
    
    assert timedelta_parse(timedelta_format(td)) == td

# Generated at 2022-06-22 18:13:15.761196
# Unit test for function timedelta_format
def test_timedelta_format():
    # Some weird values to test over:
    timedeltas = (
        datetime_module.timedelta(seconds=0),
        datetime_module.timedelta(seconds=1),
        datetime_module.timedelta(hours=24, minutes=59, seconds=59,
                                  microseconds=999999),
        datetime_module.timedelta(hours=24, minutes=59, seconds=59,
                                  microseconds=1),
        datetime_module.timedelta(hours=24, minutes=59, seconds=59,
                                  microseconds=0),
    )
    for timedelta in timedeltas:
        assert timedelta == timedelta_parse(timedelta_format(timedelta))

# Generated at 2022-06-22 18:13:25.250901
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(
        days=123, hours=22, minutes=44, seconds=16, microseconds=1234
    )
    formatted = timedelta_format(timedelta)
    assert formatted == '22:44:16.012340'
    assert timedelta_format(timedelta_parse(formatted)) == formatted
    assert timedelta_parse(formatted) == timedelta


if PY3:
    from collections.abc import Mapping, ItemsView, KeysView, ValuesView
    def sorted_values(dictionary):
        return sorted(dictionary.values())
else:
    from collections import Mapping, ItemsView, KeysView, ValuesView
    def sorted_values(dictionary):
        return sorted(dictionary.viewvalues())



# Generated at 2022-06-22 18:13:36.078771
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:23:45.100100') == datetime_module.timedelta(
        hours=1, minutes=23, seconds=45, microseconds=100100
    )
    assert timedelta_parse('0:0:0.1') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(
        microseconds=0
    )
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('1:0:0.0') == datetime_module.timedelta(
        hours=1
    )

# Generated at 2022-06-22 18:13:39.535741
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                          microseconds=4)
    assert timedelta_format(timedelta) == '01:02:03.000004'



# Generated at 2022-06-22 18:13:50.895532
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(seconds=1.1))
    assert result == '00:00:01.100000'

    result = timedelta_format(datetime_module.timedelta(seconds=1))
    assert result == '00:00:01.000000'

    result = timedelta_format(datetime_module.timedelta(seconds=59.999))
    assert result == '00:00:59.999000'

    result = timedelta_format(datetime_module.timedelta(seconds=60))
    assert result == '00:01:00.000000'

    result = timedelta_format(datetime_module.timedelta(
        seconds=60*60*24 - 1
    ))
    assert result == '23:59:59.000000'


# Generated at 2022-06-22 18:13:54.362693
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:02:03.004000') == \
        datetime_module.timedelta(hours=1, minutes=2, seconds=3, microseconds=4)


# Generated at 2022-06-22 18:14:04.513405
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
           '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=6)) == \
           '00:00:00.000006'
    assert timedelta_format(datetime_module.timedelta(microseconds=65)) == \
           '00:00:00.000065'

# Generated at 2022-06-22 18:14:09.072287
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:5.5') == datetime_module.timedelta(seconds=5.5)
    assert timedelta_parse('00:01:00.012345') == \
                           datetime_module.timedelta(minutes=1,
                                                     seconds=0.012345)

# Generated at 2022-06-22 18:14:12.450108
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == (
        '00:00:00.000000'
    )
    assert timedelta_format(timedelta_parse('0:00:00.000001')) == (
        '00:00:00.000001'
    )
    assert timedelta_format(timedelta_parse('0:00:01.000000')) == (
        '00:00:01.000000'
    )
    assert timedelta_format(timedelta_parse('0:01:00.000000')) == (
        '00:01:00.000000'
    )
    assert timedelta_format(timedelta_parse('1:00:00.000000')) == (
        '01:00:00.000000'
    )

# Generated at 2022-06-22 18:14:24.853348
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == '01:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1)) == '01:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1, seconds=1, microseconds=1)) == '01:01:01.000001'
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(seconds=0)
    assert timedelta_parse('00:00:00.000001') == datetime

# Generated at 2022-06-22 18:14:32.781673
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, hours=13, minutes=42, seconds=23, microseconds=1
    ))) == datetime_module.timedelta(
        days=1, hours=13, minutes=42, seconds=23, microseconds=1
    )


try:
    from typing import Dict, Any
    Dict[Any, Any]
except (ImportError, NameError):
    # If we have no type-hints, then we're in Python 2 or before `typing`
    # was installed
    pass

# Generated at 2022-06-22 18:14:40.320442
# Unit test for function timedelta_format
def test_timedelta_format():
    time = time_isoformat(datetime_module.time(11, 2, 3, 456),
                          timespec='microseconds')
    assert time == '11:02:03.000456'
    assert timedelta_parse(time) == datetime_module.timedelta(
        hours=11,
        minutes=2,
        seconds=3,
        microseconds=456
    )
    assert timedelta_format(datetime_module.timedelta(hours=11,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=456)) == time



# Generated at 2022-06-22 18:14:43.047365
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000001') == \
                        datetime_module.timedelta(hours=1, minutes=2,
                                                  seconds=3, microseconds=1)


# Generated at 2022-06-22 18:14:54.362486
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:15:05.056845
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:00:00.000000') == datetime_module.timedelta(
        hours=2,
    )
    assert timedelta_parse('00:00:00.000010') == datetime_module.timedelta(
        microseconds=10,
    )
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(
        seconds=1,
    )
    assert timedelta_parse('00:00:01.000010') == datetime_module.timedelta(
        seconds=1, microseconds=10,
    )
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1,
    )

# Generated at 2022-06-22 18:15:09.660910
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:01:00.000001') == datetime_module.timedelta(
        minutes=1, seconds=0, microseconds=1
    )

# Generated at 2022-06-22 18:15:21.768358
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import datetime
    assert timedelta_parse(timedelta_format(datetime.timedelta(days=1))) ==\
        datetime.timedelta(days=1)
    assert timedelta_parse(timedelta_format(datetime.timedelta(hours=1))) ==\
        datetime.timedelta(hours=1)
    assert timedelta_parse(timedelta_format(datetime.timedelta(minutes=1))) ==\
        datetime.timedelta(minutes=1)
    assert timedelta_parse(timedelta_format(datetime.timedelta(seconds=1))) ==\
        datetime.timedelta(seconds=1)

# Generated at 2022-06-22 18:15:33.407238
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03:000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_parse('01:02:03.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_parse('1:2:3.000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )
    assert timedelta_parse('1:2:3:000456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=456
    )

# Generated at 2022-06-22 18:15:40.185222
# Unit test for function timedelta_format
def test_timedelta_format():
    for t in (
        datetime_module.timedelta(microseconds=5),
        datetime_module.timedelta(seconds=5),
        datetime_module.timedelta(seconds=78, microseconds=123456),
        datetime_module.timedelta(minutes=5),
        datetime_module.timedelta(hours=5),
        datetime_module.timedelta(days=5, hours=12, minutes=34,
                                  microseconds=123456),
    ):
        assert timedelta_parse(timedelta_format(t)) == t

# Generated at 2022-06-22 18:15:43.158460
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert TimedeltaToString(datetime_module.timedelta(
        hours=3, minutes=2, seconds=1, microseconds=1000
    )) == '03:02:01.001000'



# Generated at 2022-06-22 18:15:52.107693
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('0:00:00.000000')) == \
           '00:00:00.000000'
    assert timedelta_format(timedelta_parse('1:02:03.123456')) == \
           '01:02:03.123456'


if PY2:
    import __builtin__
    builtin_module = __builtin__
else:
    import builtins
    builtin_module = builtins


try:
    Memoryview = memoryview
    asciistr = memoryview
except NameError:
    def asciistr(string):
        return string
    class Memoryview:
        def __init__(self, data):
            self.data = data
        def __eq__(self, other):
            return self.data == other.data

# Generated at 2022-06-22 18:15:59.350550
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23,
                                                      minutes=42,
                                                      seconds=1,
                                                      microseconds=5321)) == '23:42:01.005321'
    assert timedelta_format(datetime_module.timedelta(seconds=1,
                                                      microseconds=5321)) == '00:00:01.005321'


# Generated at 2022-06-22 18:16:04.094135
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=100)) == '00:00:01.760000'
    assert timedelta_format(datetime_module.timedelta(days=100.25)) == '00:00:01.750000'
    assert timedelta_format(datetime_module.timedelta(days=-100)) == '23:59:58.240000'
    assert timedelta_format(datetime_module.timedelta(days=-100.25)) == '23:59:58.250000'

    assert timedelta_format(datetime_module.timedelta(seconds=1.5)) == '00:00:01.500000'
    assert timedelta_format(datetime_module.timedelta(seconds=-1.5)) == '23:59:58.500000'

# Generated at 2022-06-22 18:16:11.054229
# Unit test for function timedelta_format
def test_timedelta_format():
    times = (
        datetime_module.time(0, 0, 0),
        datetime_module.time(1, 2, 3),
        datetime_module.time(10, 11, 12),
        datetime_module.time(0, 0, 0, 1),
        datetime_module.time(1, 2, 3, 4),
        datetime_module.time(10, 11, 12, 13),
    )
    for time in times:
        assert timedelta_format(datetime_module.timedelta(
            hours=time.hour, minutes=time.minute, seconds=time.second,
            microseconds=time.microsecond
        )) == time_isoformat(time, timespec='microseconds')



# Generated at 2022-06-22 18:16:21.719150
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(
        hours=5, minutes=6, seconds=7, microseconds=890123
    ))
    assert result == '05:06:07.890123'


if PY3:
    def reraise(exc_info):
        raise exc_info[1].with_traceback(exc_info[2])
else:
    exec('''def reraise(exc_info):
    raise exc_info[0], exc_info[1], exc_info[2]
''')


if PY3:
    from contextlib import redirect_stdout, redirect_stderr
else:
    import io
    import contextlib

    @contextlib.contextmanager
    def redirect_stdout(new_target):
        old_target = sys.stdout

# Generated at 2022-06-22 18:16:30.687036
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:11:12') == \
           datetime_module.timedelta(hours=10, minutes=11, seconds=12)

    assert timedelta_parse('10:11:12.123456') == \
           datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                     microseconds=123456)

    assert timedelta_parse('10:11:12.123') == \
           datetime_module.timedelta(hours=10, minutes=11, seconds=12,
                                     microseconds=123000)

# Generated at 2022-06-22 18:16:40.700376
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(
        minutes=1
    )
    assert timedelta_parse('00:01:00') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('00:01') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:00') == datetime_module.timedelta(minutes=1)
    assert timedelta_parse('1:00:00') == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-22 18:16:43.010303
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('''
06:00:44.282780
'''.strip())) == '06:00:44.282780'

# Generated at 2022-06-22 18:16:49.095579
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(5, 4, 3)) == '05:00:04.000003'
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 59, 59)) == '00:59:59.999999'


# Generated at 2022-06-22 18:16:53.991153
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=13,
                                                      minutes=24,
                                                      seconds=25,
                                                      microseconds=123456)) == \
                                                      '13:24:25.123456'


# Generated at 2022-06-22 18:17:02.406070
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import datetime

    timedelta = timedelta_parse('1:2:3.000010')
    assert timedelta == datetime.timedelta(hours=1, minutes=2, seconds=3,
                                           microseconds=10)

    timedelta = timedelta_parse('4:5:6.020')
    assert timedelta == datetime.timedelta(hours=4, minutes=5, seconds=6,
                                           microseconds=20)

    timedelta = timedelta_parse('7:8:9.020000')
    assert timedelta == datetime.timedelta(hours=7, minutes=8, seconds=9,
                                           microseconds=200)

# Generated at 2022-06-22 18:17:07.887826
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse(timedelta_format(datetime_module.timedelta())) == \
                                                      datetime_module.timedelta()
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(days=2))) == \
                                                      datetime_module.timedelta(days=2)


if sys.version_info[:2] >= (3, 7):
    from datetime import time as Time, date as Date # for mypy
else:
    Time = datetime_module.time
    Date = datetime_module.date

# Generated at 2022-06-22 18:17:19.517343
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                              '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                              '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'

# Generated at 2022-06-22 18:17:28.434400
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('2:03:04.005678') == \
          datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=5678)
    assert timedelta_parse('2:03:04.005678') == \
          datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=5678)
    assert timedelta_parse('2:03:04.005678') == \
          datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                    microseconds=5678)

# Generated at 2022-06-22 18:17:37.081863
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(1, 0, 1)

# Generated at 2022-06-22 18:17:40.890147
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )) == '01:02:03.000004'



# Generated at 2022-06-22 18:17:46.329062
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    ))) == datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1
    )


try:
    from functools import lru_cache
except ImportError:
    from backports.functools_lru_cache import lru_cache
    
    

# Generated at 2022-06-22 18:17:57.687909
# Unit test for function timedelta_format
def test_timedelta_format():
    cases = (
        (datetime_module.timedelta(), '00:00:00.000000'),
        (datetime_module.timedelta(hours= 1), '01:00:00.000000'),
        (datetime_module.timedelta(hours=-1), '-01:00:00.000000'),
        (datetime_module.timedelta(minutes=-1), '-00:01:00.000000'),
        (datetime_module.timedelta(seconds=-1), '-00:00:01.000000'),
        (datetime_module.timedelta(microseconds=-1), '-00:00:00.000001'),
    )
    for timedelta, expected_time_isoformat in cases:
        assert timedelta_format(timedelta) == expected_time_isoformat


# Unit test

# Generated at 2022-06-22 18:18:05.881997
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=3,
                                                      hours=12,
                                                      minutes=25,
                                                      seconds=17,
                                                      microseconds=123456)) == \
           '12:25:17.123456'

# Generated at 2022-06-22 18:18:14.145112
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'
    assert timedelta_format(
        datetime_module.timedelta(seconds=5, microseconds=123)
    ) == '00:00:05.000123'
    assert timedelta_format(
        datetime_module.timedelta(hours=12, minutes=34, seconds=56,
                                  microseconds=789012)
    ) == '12:34:56.789012'



# Generated at 2022-06-22 18:18:17.030181
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2)) == '01:02:00.000000'



# Generated at 2022-06-22 18:18:20.831988
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

# Generated at 2022-06-22 18:18:22.671455
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        0, 718, 598000
    )) == '00:11:58.598000'


# Generated at 2022-06-22 18:18:26.152641
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                          microseconds=123456)
    assert timedelta_format(timedelta) == '02:03:04.123456'



# Generated at 2022-06-22 18:18:37.705592
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=3,
                                                      microseconds=0)) == '00:00:03.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=3,
                                                      microseconds=1)) == '00:00:03.000001'

# Generated at 2022-06-22 18:18:44.691412
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=3)) == \
           '00:00:00.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=10, minutes=15, seconds=30)
    ) == '10:15:30.000000'
    assert timedelta_format(
        datetime_module.timedelta(hours=10, minutes=15, seconds=30,
                                  microseconds=123456)
    ) == '10:15:30.123456'


# Generated at 2022-06-22 18:18:54.780203
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=2,
                                                      microseconds=456789)) == \
           '00:00:02.0456789'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=15,
                                                      microseconds=0)) == \
           '02:03:15.000000'
    assert timedelta_format(datetime_module.timedelta(hours=2, minutes=3,
                                                      seconds=15,
                                                      microseconds=6789)) == \
           '02:03:15.006789'


# Generated at 2022-06-22 18:19:00.551410
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=3))) \
           == datetime_module.timedelta(seconds=3)
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        days=1, seconds=3, microseconds=5
    ))) == datetime_module.timedelta(days=1, seconds=3, microseconds=5)



# Generated at 2022-06-22 18:19:07.841408
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:19:17.138262
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == (
        '00:00:01.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=2)) == (
        '00:00:02.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=3)) == (
        '00:00:03.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=30)) == (
        '00:00:30.000000'
    )
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == (
        '00:00:59.000000'
    )

# Generated at 2022-06-22 18:19:28.492101
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=1)
    )) == datetime_module.timedelta(seconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(seconds=-1)
    )) == datetime_module.timedelta(seconds=-1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=1)
    )) == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(microseconds=-1)
    )) == datetime_module.timedelta(microseconds=-1)

# Generated at 2022-06-22 18:19:37.854766
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000)) == '00:00:00.001000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000)) == '00:00:01.000000'

# Generated at 2022-06-22 18:19:48.289111
# Unit test for function timedelta_format
def test_timedelta_format():
    for time in (
        datetime_module.time(hour=1, minute=1, second=1),
        datetime_module.time(hour=1, minute=1, second=1, microsecond=1),
        datetime_module.time(hour=2, minute=3, second=4, microsecond=5),
        datetime_module.time(hour=23, minute=59, second=59, microsecond=999999)
    ):
        assert timedelta_parse(timedelta_format(time - datetime_module.time(0))) \
            == time


# Generated at 2022-06-22 18:19:58.019633
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(hours=10)) == '10:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=10)) == '00:10:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=10, seconds=15)) == '00:10:15.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=10, seconds=15, microseconds=30000)) == '00:10:15.030000'
    assert timedelta_format(datetime_module.timedelta(minutes=10, seconds=15, microseconds=30030)) == '00:10:15.300300'

# Generated at 2022-06-22 18:20:06.893095
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
                                                     '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
                                                     '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                     '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                     '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=1)) == \
                                                     '01:01:00.000000'

# Generated at 2022-06-22 18:20:16.648547
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time_value = time_isoformat(datetime_module.time(hour=1, minute=2, second=3,
                                                     microsecond=4))
    assert timedelta_parse(time_value) == datetime_module.timedelta(
                                                                hours=1,
                                                                minutes=2,
                                                                seconds=3,
                                                                microseconds=4)
    time_value = time_isoformat(datetime_module.time(hour=1, minute=2, second=3,
                                                     microsecond=0))
    assert timedelta_parse(time_value) == datetime_module.timedelta(
                                                                hours=1,
                                                                minutes=2,
                                                                seconds=3)

# Generated at 2022-06-22 18:20:28.383464
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:20:32.050096
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=6, hours=5,
                                                      minutes=4,
                                                      seconds=3,
                                                      microseconds=2)) == \
                                                      '150:04:03.000002'



# Generated at 2022-06-22 18:20:45.902612
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(1, 0, 1)
    assert timedelta_parse('00:01:01.000000') == dat

# Generated at 2022-06-22 18:20:55.497325
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.999999') == datetime_module.timedelta(0, 0, 1)
    assert timedelta_parse('0:0:1') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('0:1:0') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('1:0:0') == datetime_module.timedelta(0, 3600)
    assert timedelta_parse('1:2:3.1') == datetime_module.timedelta(0,
                                                                    3600 + 120 + 3,
                                                                    100000)


_is_inst

# Generated at 2022-06-22 18:21:07.002374
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('12:34:56.123456') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=123456)
    assert timedelta_parse('12:34:56.12345') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=12345)
    assert timedelta_parse('12:34:56.1234') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=1234)
    assert timedelta_parse('12:34:56.123') == datetime_module.timedelta(
        hours=12, minutes=34, seconds=56, microseconds=123)

# Generated at 2022-06-22 18:21:17.042172
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0, 0, 0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(0, 0, 2)) == '00:00:00.000002'
    assert timedelta_format(datetime_module.timedelta(0, 0, 2, 3)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(0, 0, 2, 3, 4)) == '00:00:00.000003'
    assert timedelta_format(datetime_module.timedelta(1, 0, 0)) == '24:00:00.000000'

# Generated at 2022-06-22 18:21:28.120649
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1)) == '00:01:01.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=123456)) == '00:00:01.123456'
    assert timedelta_format(datetime_module.timedelta(microseconds=123456)) == '00:00:00.123456'

# Generated at 2022-06-22 18:21:32.824020
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2,
                                                      minutes=5,
                                                      seconds=1,
                                                      microseconds=123456)) \
                                                      == '02:05:01.123456'


# Generated at 2022-06-22 18:21:38.605427
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == \
                          datetime_module.timedelta(hours=1, minutes=2,
                                                    seconds=3,
                                                    milliseconds=456)
    assert timedelta_parse('-1:2:3.456789') == \
                          datetime_module.timedelta(hours=-1, minutes=2,
                                                    seconds=3,
                                                    milliseconds=456)

# Generated at 2022-06-22 18:21:50.362145
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=123456
    )
    assert timedelta_parse('34:56.7890') == datetime_module.timedelta(
        hours=34, minutes=56, seconds=0, microseconds=789000
    )
    assert timedelta_parse('0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0.000000') == datetime_module.timedelta(
        microseconds=0
    )
    assert timedelta_parse('0:0') == datetime_module.timedelta()
    assert timedelta_parse('0:01') == datetime

# Generated at 2022-06-22 18:22:02.576573
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
                                                              '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
                                                              '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000)) == \
                                                              '00:16:40.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000000))\
                                                           == '02:46:40.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1000000000000))\
                                                           == '27:46:40.000000'


# Unit test

# Generated at 2022-06-22 18:22:11.082372
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:22:23.249940
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == \
                            datetime_module.timedelta(seconds=0)
    assert timedelta_parse('0:0:0.123456') == \
                            datetime_module.timedelta(microseconds=123456)
    assert timedelta_parse('0:0:1.123456') == \
                            datetime_module.timedelta(seconds=1,
                                                      microseconds=123456)
    assert timedelta_parse('0:1:1.123456') == \
                            datetime_module.timedelta(minutes=1,
                                                      seconds=1,
                                                      microseconds=123456)
    assert timedelta_parse('1:1:1.123456') == \
                            datetime_module.timedelta

# Generated at 2022-06-22 18:22:28.962688
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.000000') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)
    assert timedelta_parse('02:04:06.000123') == \
           datetime_module.timedelta(hours=2, minutes=4, seconds=6,
                                     microseconds=123)

test_timedelta_parse()

