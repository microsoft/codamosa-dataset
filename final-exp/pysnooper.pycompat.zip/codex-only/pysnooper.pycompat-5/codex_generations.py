

# Generated at 2022-06-22 18:12:23.258167
# Unit test for function timedelta_format
def test_timedelta_format():
    for s in (
        r'00:00:00.000000',
        r'11:12:13.345678',
        r'23:59:59.999999',
    ):
        timedelta = timedelta_parse(s)
        assert timedelta_format(timedelta) == s

# Generated at 2022-06-22 18:12:34.428616
# Unit test for function timedelta_format
def test_timedelta_format():
    result = timedelta_format(datetime_module.timedelta(hours=3, minutes=2,
                                                        seconds=1,
                                                        microseconds=500))
    assert result == '03:02:01.000500'



# Generated at 2022-06-22 18:12:39.714839
# Unit test for function timedelta_parse
def test_timedelta_parse():
    seconds_since_epoch = 738865.789
    td = datetime_module.timedelta(seconds=seconds_since_epoch)
    assert timedelta_format(td) == timedelta_parse('{}'.format(seconds_since_epoch))

# Generated at 2022-06-22 18:12:44.083814
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
        '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(days=-1, seconds=-1)) == \
        '-1 day, 23:59:58.999999'

    assert timedelta_format(datetime_module.timedelta(days=-1)) == '-1 day, 00:00:00'
    assert timedelta_format(datetime_module.timedelta(seconds=-1)) == '-1 day, 23:59:59'




# Generated at 2022-06-22 18:12:53.652269
# Unit test for function timedelta_parse

# Generated at 2022-06-22 18:13:02.994762
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == '00:00:01.000000'

# Generated at 2022-06-22 18:13:14.142678
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta_tuple_list = [
        (1, 2, 3, 4),  # hours, minutes, seconds, microseconds
        (10, 20, 30, 40),
        (100, 200, 300, 400),
    ]
    for hours, minutes, seconds, microseconds in timedelta_tuple_list:
        timedelta = datetime_module.timedelta(
            hours=hours, minutes=minutes, seconds=seconds,
            microseconds=microseconds
        )
        s = timedelta_format(timedelta)
        assert s.startswith('{:02d}:{:02d}:{:02d}.'.format(hours, minutes, seconds))
        assert len(s) == 15
        assert int(s[-6:]) == microseconds
        assert timedelta_parse(s) == timedelta



# Generated at 2022-06-22 18:13:22.750644
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:01.000000') == datetime_module.timedelta(0, 1)
    assert timedelta_parse('00:01:00.000000') == datetime_module.timedelta(0, 60)
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(1)
    assert timedelta_parse('10:10:10.100000') == datetime_module.timedelta(
        hours=10, minutes=10, seconds=10, microseconds=100000
    )

# Generated at 2022-06-22 18:13:33.731490
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('02:18:28.876543') == \
                          datetime_module.timedelta(
                              hours=2,
                              minutes=18,
                              seconds=28,
                              microseconds=876543
                          )
    assert timedelta_parse('04:11:28.876543') == \
                          datetime_module.timedelta(
                              hours=4,
                              minutes=11,
                              seconds=28,
                              microseconds=876543
                          )
    assert timedelta_parse('00:00:00.000000') == \
                          datetime_module.timedelta(
                              hours=0,
                              minutes=0,
                              seconds=0,
                              microseconds=0
                          )
    assert timedelta_

# Generated at 2022-06-22 18:13:40.362472
# Unit test for function timedelta_parse
def test_timedelta_parse():
    td = timedelta_parse('1:02:03.234567')
    assert td.seconds == 3723
    assert td.microseconds == 234567


if PY3:
    def is_classmethod(method):
        return isinstance(method, classmethod)
    def is_staticmethod(method):
        return isinstance(method, staticmethod)
else:
    def is_classmethod(method):
        if isinstance(method, staticmethod):
            return False
        if isinstance(method, classmethod):
            return True
        return method.__name__ == '__dict__'

    def is_staticmethod(method):
        return isinstance(method, staticmethod)

# Generated at 2022-06-22 18:13:45.261519
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:19:48.845102') == \
           datetime_module.timedelta(hours=1, minutes=19, seconds=48,
                                     microseconds=845102)



# Generated at 2022-06-22 18:13:51.419454
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    timedelta = datetime_module.timedelta(days=12, hours=21, minutes=14,
                                          seconds=42, microseconds=1337)
    assert timedelta == timedelta_parse(timedelta_format(timedelta))
    with pytest.raises(ValueError):
        timedelta_parse('abc')


if PY3:
    from shlex import quote as shell_quote
else:
    from pipes import quote as shell_quote

# Generated at 2022-06-22 18:14:02.733562
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('00:00:01.123456')) == '00:00:01.123456'
    assert timedelta_format(timedelta_parse('00:01:00.123456')) == '00:01:00.123456'
    assert timedelta_format(timedelta_parse('01:00:00.123456')) == '01:00:00.123456'

    assert timedelta_format(timedelta_parse('00:00:00.123456')) == '00:00:00.123456'
    assert timedelta_format(timedelta_parse('00:00:00.12345')) == '00:00:00.012345'
    assert timedelta_format(timedelta_parse('00:00:00.1234'))

# Generated at 2022-06-22 18:14:05.301946
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(weeks=1, microseconds=1)
    assert timedelta_format(timedelta) == '168:00:00:00.000001'



# Generated at 2022-06-22 18:14:14.068823
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=0)) == \
          '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
          '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == \
          '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == \
          '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
          '24:00:00.000000'

# Generated at 2022-06-22 18:14:18.520935
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(minutes=4, seconds=55,
                                                      microseconds=1234)) == \
           '00:04:55.012'



# Generated at 2022-06-22 18:14:28.656646
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(microseconds=100)) == \
           '00:00:00.000100'
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == \
           '00:00:00.999999'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == \
           '00:00:01.000000'

# Generated at 2022-06-22 18:14:34.275214
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
           '01:01:01.000001'


# Generated at 2022-06-22 18:14:40.360821
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=5, minutes=48, seconds=3,
                                          microseconds=232559)
    assert timedelta_format(timedelta) == '05:48:03.232559'
    timedelta = datetime_module.timedelta(hours=3, minutes=0, seconds=45,
                                          microseconds=0)
    assert timedelta_format(timedelta) == '03:00:45.000000'


# Generated at 2022-06-22 18:14:45.370456
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=2, seconds=13)) == \
                                                              '02:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(days=5, hours=2,
                                                      seconds=13)) == \
                                                              '02:00:13.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=97)) == \
                                                              '00:00:00.000097'

# Generated at 2022-06-22 18:14:50.043089
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import my_clock
    x = timedelta_parse(timedelta_format(my_clock.HOUR * 64.5 + my_clock.MINUTE))
    assert x == my_clock.HOUR * 64.5 + my_clock.MINUTE

# Generated at 2022-06-22 18:14:53.615828
# Unit test for function timedelta_format
def test_timedelta_format():
    x = datetime_module.timedelta(hours=23, minutes=59, seconds=59,
                                  microseconds=999999)
    assert timedelta_format(x) == '23:59:59.999999'


# Generated at 2022-06-22 18:14:58.390246
# Unit test for function timedelta_format
def test_timedelta_format():
    z = datetime_module.timedelta()
    assert timedelta_format(z) == '00:00:00.000000'
    z = datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=4)
    assert timedelta_format(z) == '01:02:03.000004'



# Generated at 2022-06-22 18:15:06.128478
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == \
           time_isoformat(datetime_module.time(microsecond=1))
    assert timedelta_format(datetime_module.timedelta(0, 1, 2)) == \
           time_isoformat(datetime_module.time(0, 1, 2))
    assert timedelta_format(datetime_module.timedelta(1, 1, 1)) == \
           time_isoformat(datetime_module.time(1, 1, 1))



# Generated at 2022-06-22 18:15:12.556333
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .test_python_toolbox.nifty_collections import OrderedDict

# Generated at 2022-06-22 18:15:23.901764
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(days=1)) == \
        '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1, microseconds=1)) == \
        '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(days=1, seconds=1)) == \
        '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(days=1,
                                                      seconds=1,
                                                      microseconds=1)) == \
        '00:00:01.000001'

# Generated at 2022-06-22 18:15:28.223252
# Unit test for function timedelta_format
def test_timedelta_format():
    td = datetime_module.timedelta(days=18, hours=6, minutes=24,
                                   seconds=12, microseconds=123456)
    assert timedelta_format(td) == '06:24:12.123456'



# Generated at 2022-06-22 18:15:38.386245
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for timedelta in (datetime_module.timedelta(days=1, hours=2, minutes=3,
                                                seconds=4, microseconds=5),
                      datetime_module.timedelta(hours=1, microseconds=1)):
        assert timedelta == timedelta_parse(timedelta_format(timedelta))



if hasattr(sys, '_getframe'):
    getframe = sys._getframe

# Generated at 2022-06-22 18:15:45.533858
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:00:00.000000') == datetime_module.timedelta(
        hours=1
    )
    assert timedelta_parse('01:01:00.000000') == datetime_module.timedelta(
        minutes=61
    )
    assert timedelta_parse('01:00:01.000000') == datetime_module.timedelta(
        seconds=61
    )
    assert timedelta_parse('01:00:00.000001') == datetime_module.timedelta(
        microseconds=1000001
    )
    assert timedelta_parse('01:00:00.000010') == datetime_module.timedelta(
        microseconds=1000010
    )
    assert timedelta_parse('01:00:00.000100') == datetime_module.tim

# Generated at 2022-06-22 18:15:49.657822
# Unit test for function timedelta_format
def test_timedelta_format():
    if not sys.version_info[:2] == (3, 6):
        return
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=456789)) == \
           '01:02:03.456789'


# Generated at 2022-06-22 18:16:01.987983
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=3, minutes=2,
                                                      seconds=1,
                                                      microseconds=123456)) == \
                                                      '03:02:01.123456'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)) == \
                                                      '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=1)) == \
                                                      '00:00:00.000001'

# Generated at 2022-06-22 18:16:10.002756
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:22:33.123123') == timedelta_parse(
        '01:22:33.123123'
    )
    assert timedelta_parse('1:22:33.123123') == datetime_module.timedelta(
        hours=1, minutes=22, seconds=33, microseconds=123123
    )
    assert timedelta_parse('1.123123') == datetime_module.timedelta(
        seconds=1, microseconds=123123
    )
    assert timedelta_parse('1') == datetime_module.timedelta(seconds=1)
    assert timedelta_parse('1:00') == datetime_module.timedelta(minutes=1)

# Generated at 2022-06-22 18:16:15.782435
# Unit test for function timedelta_format

# Generated at 2022-06-22 18:16:23.618744
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1, microseconds=1)) == '00:00:01.000001'
    assert timedelta_format(datetime_module.timedelta(minutes=1, seconds=1, microseconds=1)) == '00:01:01.000001'
    assert timedelta_format(datetime_module.timedelta(hours=23, microseconds=1)) == '23:00:00.000001'

# Generated at 2022-06-22 18:16:26.873290
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5, minutes=6,
                              seconds=7, microseconds=890123)) == '05:06:07.890123'



# Generated at 2022-06-22 18:16:32.379554
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1, seconds=1,
                                                      microseconds=2)) == '01:00:01.000002'


# Generated at 2022-06-22 18:16:41.739833
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(timedelta_parse('1:23:45.6789')) == '01:23:45.006789'
    assert timedelta_format(timedelta_parse('-1:23:45.6789')) == '-01:23:45.006789'
    assert timedelta_format(timedelta_parse('12:34:56.7890')) == '12:34:56.007890'
    assert timedelta_format(timedelta_parse('-12:34:56.7890')) == '-12:34:56.007890'
    assert timedelta_format(timedelta_parse('17:12:34')) == '17:12:34'

# Generated at 2022-06-22 18:16:53.120614
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert '00:00:00.000000' == timedelta_parse('0:0:0.0')
    assert '00:00:00.000000' == timedelta_parse('0:0:0.0.0')
    assert '00:00:02.490000' == timedelta_parse('0:0:2.49')
    assert '00:00:02.490000' == timedelta_parse('0:0:2.4900000')
    assert '00:00:00.400000' == timedelta_parse('0:0:0.4')
    assert '00:01:00.000000' == timedelta_parse('0:1:0.0')
    assert '01:00:00.000000' == timedelta_parse('1:0:0.0')
    assert '01:01:00.000000'

# Generated at 2022-06-22 18:16:56.275188
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(2, 3, 4)
    assert timedelta_format(timedelta) == '48:00:02.000003'



# Generated at 2022-06-22 18:17:04.881542
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                                      microseconds=4)) == '01:02:03.000004'


# Generated at 2022-06-22 18:17:12.280156
# Unit test for function timedelta_format
def test_timedelta_format():
    from . import test_utils

# Generated at 2022-06-22 18:17:17.599482
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta = datetime_module.timedelta(hours=1, minutes=23,
                                          seconds=34, microseconds=56)
    assert timedelta_parse(timedelta_format(timedelta)) == timedelta

# Generated at 2022-06-22 18:17:22.476351
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('10:20:30.400000') == datetime_module.timedelta(
        hours=10, minutes=20, seconds=30, microseconds=400000
    )



# Generated at 2022-06-22 18:17:28.647603
# Unit test for function timedelta_parse
def test_timedelta_parse():
    timedelta_parse(timedelta_format(datetime_module.timedelta(seconds=5))) == datetime_module.timedelta(seconds=5)

if PY2:
    from backports.datetime_fromisoformat import MonkeyPatcher
    MonkeyPatcher.patch_fromisoformat()
    from datetime import fromisoformat
else:
    from datetime import fromisoformat


# Generated at 2022-06-22 18:17:33.918050
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(hours=3,
                                                                      minutes=5,
                                                                      seconds=7,
                                                                      microseconds=15))) == \
                                                                       datetime_module.timedelta(hours=3,
                                                                                                 minutes=5,
                                                                                                 seconds=7,
                                                                                                 microseconds=15)

# Generated at 2022-06-22 18:17:45.648976
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=23)) == \
                                                              '23:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=59)) == \
                                                               '00:59:00.000000'
    assert timedelta_format(datetime_module.timedelta(seconds=59)) == \
                                                               '00:00:59.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=999999)) == \
                                                               '00:00:00.999999'

# Generated at 2022-06-22 18:17:57.222330
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('0:00:01.000000') == datetime_module.timedelta(
        seconds=1
    )
    assert timedelta_parse('1:01:01.010101') == datetime_module.timedelta(
        hours=1, seconds=1, microseconds=10101
    )
    assert timedelta_parse('1:01:01:010101') == datetime_module.timedelta(
        days=1, microseconds=10101
    )


if PY3:
    from time import perf_counter
    from time import monotonic
    perf_counter_no_monotonic = perf_counter
    perf_counter_and_monotonic = None


# Generated at 2022-06-22 18:18:01.561872
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=123,
                                                      microseconds=555555)) == '00:02:03.555555'



# Generated at 2022-06-22 18:18:10.439348
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.000000') == datetime_module.timedelta(seconds=3723)
    assert timedelta_parse('1:2:3.000001') == datetime_module.timedelta(seconds=3723, microseconds=1)
    assert timedelta_parse('1:2:3.000010') == datetime_module.timedelta(seconds=3723, microseconds=10)
    assert timedelta_parse('1:2:3.000100') == datetime_module.timedelta(seconds=3723, microseconds=100)
    assert timedelta_parse('1:2:3.001000') == datetime_module.timedelta(seconds=3723, microseconds=1000)
    assert timedelta_parse('1:2:3.010000') == datetime_

# Generated at 2022-06-22 18:18:14.944218
# Unit test for function timedelta_format
def test_timedelta_format():
    from string import digits

    assert all(c in digits for c in timedelta_format(
        datetime_module.timedelta(seconds=1, microseconds=1)
    ))

    assert all(c in digits for c in timedelta_format(
        datetime_module.timedelta.max
    ))

# Generated at 2022-06-22 18:18:19.371028
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from . import py_compat
    assert timedelta_parse(timedelta_format(
        py_compat.timedelta(1, 2, 3)
    )) == py_compat.timedelta(1, 2, 3)

# Generated at 2022-06-22 18:18:24.072011
# Unit test for function timedelta_parse
def test_timedelta_parse():

    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                  microseconds=40000)
    )) == datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                    microseconds=40000)

# Generated at 2022-06-22 18:18:30.966897
# Unit test for function timedelta_parse
def test_timedelta_parse():
    time = time_isoformat(datetime_module.time(1, 2, 3, 456000), 'microseconds')
    assert timedelta_parse(time) == datetime_module.timedelta(hours=1,
                                                               minutes=2,
                                                               seconds=3,
                                                               microseconds=456)

    time = time_isoformat(datetime_module.time(1, 2, 3, 456000), 'seconds')
    assert timedelta_parse(time) == datetime_module.timedelta(hours=1,
                                                               minutes=2,
                                                               seconds=3,
                                                               microseconds=456000)

    time = time_isoformat(datetime_module.time(1, 2, 3, 0), 'microseconds')

# Generated at 2022-06-22 18:18:41.877708
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:0:0.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('0:0:0.000001') == datetime_module.timedelta(
        microseconds=1
    )
    assert timedelta_parse('0:0:0.000010') == datetime_module.timedelta(
        microseconds=10
    )
    assert timedelta_parse('0:0:0.000100') == datetime_module.timedelta(
        microseconds=100
    )
    assert timedelta_parse('0:0:0.001000') == datetime_module.timedelta(
        milliseconds=1
    )

# Generated at 2022-06-22 18:18:53.804450
# Unit test for function timedelta_parse
def test_timedelta_parse():
    for string, truth in [
        ('01:02:03.123456', datetime_module.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=123456)),
        ('14:34:32.246826', datetime_module.timedelta(hours=14, minutes=34,
                                                      seconds=32,
                                                      microseconds=246826)),
        ('00:00:00.000000', datetime_module.timedelta(0)),
        ('-72:00:00.000000', datetime_module.timedelta(0)),
    ]:
        assert timedelta_parse(string) == truth


if PY3:
    import functools
    _total_ordering = functools.total_ordering

# Generated at 2022-06-22 18:18:57.755120
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=25, seconds=11,
                                          microseconds=456789)
    assert timedelta_format(timedelta) == '02:25:11.456789'



# Generated at 2022-06-22 18:19:06.487293
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:01.001001') == datetime_module.timedelta(seconds=1, microseconds=1001)


if PY2:
    from backports.datetime_fromisoformat import MonkeyPatch
    MonkeyPatch.patch_fromisoformat()


try:
    FileExistsError = FileExistsError # Python 3
except NameError:
    FileExistsError = OSError # Python 2


try:
    PermissionError = PermissionError # Python 3
except NameError:
    PermissionError = OSError # Python 2


try:
    IsADirectoryError = IsADirectoryError # Python 3
except NameError:
    IsADirectoryError = OSError # Python 2



# Generated at 2022-06-22 18:19:16.543778
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('.123456') == datetime_module.timedelta(
        microseconds=123456)
    assert timedelta_parse('00.123456') == datetime_module.timedelta(
        microseconds=123456)
    assert timedelta_parse('01.123456') == datetime_module.timedelta(
        seconds=1, microseconds=123456)
    assert timedelta_parse('01.00') == datetime_module.timedelta(
        seconds=1)
    assert timedelta_parse('01:00') == datetime_module.timedelta(
        minutes=1)
    assert timedelta_parse('01:02:03') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)

# Generated at 2022-06-22 18:19:26.840899
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('1:2:3.456789') == datetime_module.timedelta(hours=1,
                                                 minutes=2, seconds=3,
                                                 microseconds=456789)


if ((3, 4) <= sys.version_info < (3, 7)):
    # See https://docs.python.org/3/library/inspect.html#types-and-members # noqa
    def getfullargspec(func):
        '''Get the arguments of a function'''
        return inspect.getfullargspec(func)
else:
    def getfullargspec(func):
        '''Get the arguments of a function'''
        return inspect.getfullargspec(func)._asdict()

# Generated at 2022-06-22 18:19:35.461456
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(days=1, hours=2,
                                                      minutes=3, seconds=4,
                                                      microseconds=5)) == '02:03:04.000005'

# Generated at 2022-06-22 18:19:42.967706
# Unit test for function timedelta_format
def test_timedelta_format():
    import datetime

    def assert_equals(a, b):
        assert a == b, (a, b)

    assert_equals(timedelta_format(datetime.timedelta(hours=0, minutes=0,
                                                      seconds=0,
                                                      microseconds=0)),
                   '00:00:00.000000')
    assert_equals(timedelta_format(datetime.timedelta(hours=1, minutes=2,
                                                      seconds=3,
                                                      microseconds=4)),
                   '01:02:03.000004')

# Generated at 2022-06-22 18:19:53.880846
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('01:02:03.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

    assert timedelta_parse('1:2:3.123456') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123456)

    assert timedelta_parse('1:2:3.123') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3,
                                     microseconds=123000)

    assert timedelta_parse('1:2:3') == \
           datetime_module.timedelta(hours=1, minutes=2, seconds=3)


# Generated at 2022-06-22 18:20:02.393541
# Unit test for function timedelta_parse
def test_timedelta_parse():
    import pytest
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4
    )
    assert timedelta_parse(timedelta_format(datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=405060
    ))) == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=405060
    )

test_timedelta_parse()

# Generated at 2022-06-22 18:20:11.174138
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('03:04:05.006000') == (datetime_module.timedelta(
        hours=3, minutes=4, seconds=5, microseconds=6
    ))
    assert timedelta_parse('1:2:3.4') == (datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=400000
    ))

# Generated at 2022-06-22 18:20:23.026905
# Unit test for function timedelta_parse
def test_timedelta_parse():
    from .testing import assert_equal
    test_pairs = [
        ('0:00:00.000000', datetime_module.timedelta(0)),
        ('1:23:34.123456', datetime_module.timedelta(hours=1, minutes=23,
                                                     seconds=34,
                                                     microseconds=123456)),
    ]
    for input_, expected_output in test_pairs:
        actual_output = timedelta_parse(input_)
        assert_equal(actual_output, expected_output)
        assert_equal(actual_output.total_seconds(),
                     expected_output.total_seconds())



# Generated at 2022-06-22 18:20:33.091873
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000001') == \
           datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01.000001') == \
           datetime_module.timedelta(seconds=1, microseconds=1)
    assert timedelta_parse('04:57:02.000001') == \
           datetime_module.timedelta(hours=4, minutes=57, seconds=2,
                                     microseconds=1)



# Generated at 2022-06-22 18:20:46.511588
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta()
    assert timedelta_parse('01:02:03.000000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3)
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, milliseconds=4)
    assert timedelta_parse('01:02:03.004000') == datetime_module.timedelta(
        hours=1, minutes=2, seconds=3, microseconds=4000)

# Generated at 2022-06-22 18:20:55.704558
# Unit test for function timedelta_format
def test_timedelta_format():
    # Test zero:
    assert timedelta_format(datetime_module.timedelta(0)) == '00:00:00.000000'
    assert timedelta_format(datetime_module.timedelta()) == '00:00:00.000000'
    # Test going into negatives:
    assert timedelta_format(datetime_module.timedelta(-1)) == '-1 day, 23:59:59.000000'
    assert timedelta_format(datetime_module.timedelta(-2)) == '-2 days, 23:59:59.000000'
    # Test going into positives:
    assert timedelta_format(datetime_module.timedelta(1)) == '1 day, 00:00:00.000000'

# Generated at 2022-06-22 18:21:04.593491
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('00:00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000001') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:00:01') == datetime_module.timedelta(microseconds=1)
    assert timedelta_parse('00:00:01') == datetime_module.timedelta(seconds=1)

# Generated at 2022-06-22 18:21:12.591515
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse(timedelta_format(
        datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                  microseconds=1)
    )) == datetime_module.timedelta(hours=1, minutes=1, seconds=1,
                                    microseconds=1)



# Generated at 2022-06-22 18:21:17.906973
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(days=3, hours=4, minutes=5,
                                          seconds=6, microseconds=789)
    assert timedelta_format(timedelta) == '127:06:06.000789'

    assert timedelta.total_seconds() == timedelta_parse(
        timedelta_format(timedelta)
    ).total_seconds()



# Generated at 2022-06-22 18:21:24.391587
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(seconds=60)) == \
           '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(microseconds=123000)) == \
           '00:00:00.123000'



# Generated at 2022-06-22 18:21:36.594209
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_format(datetime_module.timedelta(
        hours=0, minutes=1, seconds=0, microseconds=1000000
    )) == '00:01:00.100000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=0, seconds=0, microseconds=100000
    )) == '01:00:00.100000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=0, microseconds=10000
    )) == '01:01:00.010000'
    assert timedelta_format(datetime_module.timedelta(
        hours=1, minutes=1, seconds=1, microseconds=1000
    )) == '01:01:01.001000'
   

# Generated at 2022-06-22 18:21:44.019774
# Unit test for function timedelta_format
def test_timedelta_format():
    time = datetime_module.time(13, 59, 58, 999999)
    timedelta = datetime_module.datetime.combine(datetime_module.date(1, 1, 1),
                                                 time) - datetime_module.datetime.min
    assert timedelta_format(timedelta) == '13:59:58.999999'
    time = datetime_module.time(5, 45, 3, 18)
    timedelta = datetime_module.datetime.combine(datetime_module.date(1, 1, 1),
                                                 time) - datetime_module.datetime.min
    assert timedelta_format(timedelta) == '05:45:03.000018'
    time = datetime_module.time(22, 0, 0, 0)
    timedelta = dat

# Generated at 2022-06-22 18:21:47.931568
# Unit test for function timedelta_format
def test_timedelta_format():
    timedelta = datetime_module.timedelta(hours=2, minutes=3, seconds=4,
                                          microseconds=5)
    assert timedelta_format(timedelta) == '02:03:04.000005'



# Generated at 2022-06-22 18:21:55.300962
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(microseconds=1)) == '00:00:00.000001'
    assert timedelta_format(datetime_module.timedelta(seconds=1)) == '00:00:01.000000'
    assert timedelta_format(datetime_module.timedelta(minutes=1)) == '00:01:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=1)) == '01:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(hours=250)) == '250:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(days=1)) == '24:00:00.000000'

# Generated at 2022-06-22 18:22:03.982803
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(hours=5,
                                                      minutes=10,
                                                      seconds=12,
                                                      microseconds=4)) \
                                                      == '05:10:12.000004'
    assert timedelta_format(datetime_module.timedelta(hours=1,
                                                      minutes=2,
                                                      seconds=3,
                                                      microseconds=4)) \
                                                      == '01:02:03.000004'


# Generated at 2022-06-22 18:22:15.226590
# Unit test for function timedelta_parse
def test_timedelta_parse():
    assert timedelta_parse('0:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.0000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.000') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.00') == datetime_module.timedelta(0)
    assert timedelta_parse('00:00:00.0') == datetime_module.timedelta(0)
    assert timed

# Generated at 2022-06-22 18:22:26.820845
# Unit test for function timedelta_format
def test_timedelta_format():
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=0, seconds=0, microseconds=0
    )) == '05:00:00.000000'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=4, seconds=3, microseconds=2
    )) == '05:04:03.000002'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=4, seconds=3, microseconds=200000
    )) == '05:04:03.200000'
    assert timedelta_format(datetime_module.timedelta(
        hours=5, minutes=4, seconds=3, microseconds=2000000
    )) == '05:04:03.200000'
    assert timedelta_