

# Generated at 2022-06-24 18:57:38.300205
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1162.1
    str_0 = 'Received HTTP error for %s : %s'
    list_0 = []
    playbook_executor_0 = PlaybookExecutor(float_0, str_0, list_0, list_0, list_0)
    playbook_executor_0.run()
    assert playbook_executor_0._loader.module_loader is None
    assert playbook_executor_0._loader is not None
    assert playbook_executor_0.passwords is not None
    assert playbook_executor_0._unreachable_hosts is not None


# Generated at 2022-06-24 18:57:51.140314
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = []
    float_0 = 1003.0
    float_1 = 1346.9
    float_2 = 1353.7
    float_3 = 1372.8
    float_4 = 1391.9
    str_0 = 'Received HTTP error for %s : %s'
    str_1 = '&JTzd?g\n&nukU6I'
    str_2 = '<mW(!8s'
    str_3 = '9'
    str_4 = 'D'
    str_5 = 'g0TMneh4H'
    str_6 = '|t3q'
    float_5 = 1003.0
    float_6 = 1003.0
    float_7 = 1003.0
    float_8 = 1003.0
   

# Generated at 2022-06-24 18:57:53.562364
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    list_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, list_0, list_0, list_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:57:54.276173
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 18:57:55.409294
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-24 18:58:00.635013
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        assert False
        result = PlaybookExecutor.run()
        assert result == -1
    except Exception:
        raise
    else:
        pass
    finally:
        pass


# Generated at 2022-06-24 18:58:03.662972
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except:
        print("constructor of class PlaybookExecutor failed")
        display_exception(sys.exc_info())
    else:
        print("constructor of class PlaybookExecutor passed")


# Generated at 2022-06-24 18:58:14.969022
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 12312.021603
    list_0 = []
    str_0 = 'CnQZ(:_n>|b;aU%BH+-)&#k'
    list_1 = []
    str_1 = 'asyncpolicy'
    list_2 = []
    str_2 = 'pNd+xSJ'
    list_3 = []
    str_3 = 'free-form'
    list_4 = []
    str_4 = 'pNd+xSJ'
    list_5 = []
    str_5 = 'IqsWT=V$z&t'
    list_6 = []
    str_6 = 'Invalid connection type specified for %s: %s'
    list_7 = []
    str_7 = 'callback'
    list_8

# Generated at 2022-06-24 18:58:23.058614
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_path_0 = 'S.py'
    loader_0 = None
    parser_0 = None
    str_0 = 'SSH Error'
    list_0 = []
    playbook_executor_0 = PlaybookExecutor(playbook_path_0, str_0, list_0, loader_0, list_0)
    int_0 = playbook_executor_0.run()
    list_0 = []
    parser_0 = PlaybookParser(list_0, list_0)
    str_0 = 'SSH Error'
    list_0 = []
    playlist_0 = PlaybookExecutor(playlist_0, play_0, parser_0, loader_0, list_0)
    int_0 = playlist_0.run()
    list_0 = []

# Generated at 2022-06-24 18:58:26.183576
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(1.06614, '3YW', [], [], [])
    assert isinstance(playbook_executor_0, PlaybookExecutor) == True
    assert playbook_executor_0.passwords == []
    assert playbook_executor_0._unreachable_hosts == {}


# Generated at 2022-06-24 18:59:01.315384
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbooks_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    # AssertionError: <ansible.executor.playbook_executor.PlaybookExecutor object at 0x7f8c5b5f5d68> != 0
    # assert result_0 == 0
    # The line below throws an exception and prevents further execution
    # assert result_0 == 0


# Generated at 2022-06-24 18:59:02.112502
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 18:59:10.469707
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)

# Generated at 2022-06-24 18:59:12.375961
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:59:18.353878
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    # call run ()
    return int_0


# Generated at 2022-06-24 18:59:20.565800
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test case 0
    try:
        test_case_0()
    except:
        display.error(traceback.format_exc())
        display.display('')
        display.display('Unit test case for run failed')


# Generated at 2022-06-24 18:59:27.495748
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    result_0 = playbook_executor_0.run()
    return result_0

    # Test for method _get_serialized_batches of class PlaybookExecutor

# Generated at 2022-06-24 18:59:29.315366
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:30.547364
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print(test_case_0.__doc__)


# Generated at 2022-06-24 18:59:37.909885
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # try:
    test_case_setup()
    test_case_0()
    # except Exception:
    #     raise AssertionError('test_PlaybookExecutor_run() failed')


# Generated at 2022-06-24 19:00:06.039798
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Declarations
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    # PlaybookExecutor.run()
    #assert playbook_executor_0.run() == 0, "Error, PlaybookExecutor.run() should return 0"


# Generated at 2022-06-24 19:00:06.898619
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:00:11.105870
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)


# Generated at 2022-06-24 19:00:19.709131
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:30.883829
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)

    #test first branch
    entrylist_0 = []
    result_0 = 0
    entry_0 = {}

# Generated at 2022-06-24 19:00:33.777231
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except Excetion as e:
        print("test_PlaybookExecutor_run failed: " + str(e))

# Generated at 2022-06-24 19:00:39.509456
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(17, 17, [], [], [])
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:44.313835
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, var_0, var_0, var_0)
    result = playbook_executor_0.run()
    assert result == 0
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:00:46.545384
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("test_PlaybookExecutor_run")

    test_case_0()

# Generated at 2022-06-24 19:00:47.717635
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:01:13.551972
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    print(test_case_0.__doc__)

    result = test_case_0()

    assert type(result) == int

# Generated at 2022-06-24 19:01:17.397858
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result_0 = playbook_executor_0.run()
    return (result_0 == 17)


# Generated at 2022-06-24 19:01:22.803016
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor([], int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()

# Generated at 2022-06-24 19:01:27.855432
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    if result ==  int_0:
        display.display(to_text(result))
    else:
        display.error(to_text(result))


# Generated at 2022-06-24 19:01:30.016274
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int, int, int, int, int)
    int_0 = playbook_executor_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 19:01:34.399754
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # setup
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    with patch.object(playbook_executor_0, '_tqm', return_value = int_0):
        with patch.object(playbook_executor_0, '_unreachable_hosts', new = {}):
            playbook_executor_0.run()



# Generated at 2022-06-24 19:01:37.334929
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    assert result is None

###


# Generated at 2022-06-24 19:01:42.615628
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # try:
    result = PlaybookExecutor(None, None, None, None, None).run()
    # except Exception as e:
    #     print(to_text(e))
    #     raise(e)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:46.328952
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:01:51.879687
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0._playbooks == int_0
    assert playbook_executor_0._inventory == int_0
    assert playbook_executor_0._variable_manager == int_0
    assert playbook_executor_0._loader == int_0
    assert playbook_executor_0.passwords == int_0
    assert playbook_executor_0._unreachable_hosts == {}
    assert playbook_executor_0._tqm == None

    int_1 = 18
    playbook_executor_1 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_exec

# Generated at 2022-06-24 19:02:16.214977
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except AssertionError:
        print(traceback.print_exc())

# Generated at 2022-06-24 19:02:19.254699
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("STUB: Test template for PlaybookExecutor.run() called")
    print("STUB: If this fails consider adding @patch to the test method")

# Generated at 2022-06-24 19:02:27.826163
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)

    retval = playbook_executor_0.run()
    #assert retval == 0

tvals = [ [17, 17, 17, 17, 17], [17, None, 17, None, 17], [17, 17, 17, None, 17], [17, 17, 17, 17, None] ]


# Generated at 2022-06-24 19:02:29.360753
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:02:31.363401
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

import unittest


# Generated at 2022-06-24 19:02:38.196176
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Python3 can not handle bytearray
    # for example: bytearray(128), bytearray("xx", 'ascii') etc.
    # this is a bug of python.
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:48.279335
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 19:02:52.618564
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except Exception as e:
        print("unexpected exception")
        print(e)

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:01.567108
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    t_input = {'start_at_task': 'GET /', 'syntax': False, 'listhosts': False, 'listtags': False, 'listtasks': False, 'list-tasks': False, 'list-tags': False, 'forks': 5, 'start_at': None, 'step': False, 'inventory': '', 'vault_password_file': '~/.ansible/vault', 'vault_password': None, 'tags': []}
    context.CLIARGS = t_input
    test_case_0()


# Generated at 2022-06-24 19:03:06.223902
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test_PlaybookExecutor:")
    try:
        test_case_0()
    except Exception as err:
        print("Exception: ", err)
    print()

test_case_1 = "ansible-playbook -i hosts test.yaml"

# Generated at 2022-06-24 19:03:34.683855
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:03:36.944167
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int(), int(), int(), int(), int())
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:49.163316
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import os
    import json

    # ansible-playbook.yml:
    # - hosts: 1
    #   gather_facts: true
    #   tasks:
    #     - ping:

    test_file_dir = 'test_case/test_PlaybookExecutor_run'
    with open(test_file_dir + '/ansible-playbook.yml', 'r') as file_handle:
        test_case_0_array_0 = []
        for line in file_handle:
            test_case_0_array_0.append(line)
    test_case_0_str_0 = ''.join(test_case_0_array_0)
    test_case_0_str_1 = ''

# Generated at 2022-06-24 19:03:52.390329
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(17, 17, 17, 17, 17)


# Generated at 2022-06-24 19:03:55.892715
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0.run() == 0

# Generated at 2022-06-24 19:04:06.570266
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Verify that your test case has initialized all the necessary objects
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("Unit test case not initialized")
 
    # Verify that your test case has initialized all the necessary objects
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("Unit test case not initialized")
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test case 0
    # Test

# Generated at 2022-06-24 19:04:08.372720
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Unit tests for class PlaybookExecutor are executed when this module is run as main
if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:15.233391
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0._playbooks == int_0
    assert playbook_executor_0._inventory == int_0
    assert playbook_executor_0._variable_manager == int_0
    assert playbook_executor_0._loader == int_0
    assert playbook_executor_0.passwords == int_0
    assert playbook_executor_0._unreachable_hosts == {}
    assert playbook_executor_0._tqm is None


# Generated at 2022-06-24 19:04:25.251079
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 1
    str_0 = ''
    str_1 = 'QQ'
    str_2 = 'a'
    str_3 = 'b'
    list_0 = []
    list_1 = []
    dict_0 = {}
    dict_1 = {}

    playbook_executor_0 = PlaybookExecutor(list_1, list_1, list_1, list_1, list_1)

    assert playbook_executor_0._get_serialized_batches(list_1) == list_1

    playbook_executor_0.passwords = dict_0
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.passwords = dict_1

    playbook_executor_0._unreach

# Generated at 2022-06-24 19:04:29.411814
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(
        int(),
        int(),
        int(),
        int(),
        int()
    )

    # Call method
    ret = playbook_executor_0.run()

    # Check the result
    if ret != 0:
        print('Test failed')


# Generated at 2022-06-24 19:04:57.034877
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:05:00.504244
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    assert result == 0



# Generated at 2022-06-24 19:05:06.556364
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:05:07.570015
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:05:13.503376
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    return_value_0 = playbook_executor_0.run()
    assert return_value_0 == 0


# Generated at 2022-06-24 19:05:23.736601
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Default entry point for the script.
    # Setup the variables required for execution
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader, shell_loader, become_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Define the fixtures.
    # 1. Create Mocks
    # 2. Setup Test Data
    # 3. Setup Test Objects
    # 4. Test

    mocker, mock_module = get_mock_fixtures('utils', 'display')
    mocker, mock_playbook_executor = get_m

# Generated at 2022-06-24 19:05:31.276746
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # No error in PlaybookExecutor.run
    int_0 = 17
    playbook_executor_1 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_1.run()
    assert result == 0


# Generated at 2022-06-24 19:05:34.199075
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    display.warning('Testing constructor of class PlaybookExecutor')
    test_case_0()
    display.warning('Testing constructor of class PlaybookExecutor is finished')


# Generated at 2022-06-24 19:05:37.211613
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(int, int, int, int, int)
    playbook_executor_1.run()


# Generated at 2022-06-24 19:05:39.187319
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:10.817010
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:06:11.721433
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:06:16.283106
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        print ("test_PlaybookExecutor: " + str(e))
        assert 1 == 0,\
            "Failed when test_PlaybookExecutor"

#

# Generated at 2022-06-24 19:06:21.114305
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int, int, int, int, int)
    playbook_executor_0.run()


if __name__ == '__main__':

    test_case_0()
    # test_PlaybookExecutor_run()
    # Please proceed to unit test after code changes

# Generated at 2022-06-24 19:06:25.454489
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-24 19:06:30.573032
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int(), int(), int(), int(), int())
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:32.816178
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Unit test for method run of class PlaybookExecutor
    test_case_0()

# Generated at 2022-06-24 19:06:39.412911
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 17
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:42.978172
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Testing constructor of class PlaybookExecutor")
    test_case_0()
    print("Passed test case 0")

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:06:48.425795
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
