

# Generated at 2022-06-24 18:57:34.169297
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Unit test driver for PlaybookExecutor

# Generated at 2022-06-24 18:57:36.189993
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:57:44.105585
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    str_0 = 'R'
    int_0 = 8192
    tuple_0 = (int_0,)
    dict_0 = {tuple_0: tuple_0, int_0: str_0}
    playbook_executor_0 = PlaybookExecutor(str_0, tuple_0, str_0, dict_0, str_0)
    playbook_executor_1 = PlaybookExecutor(str_0, tuple_0, str_0, dict_0, str_0)
    if (playbook_executor_1.run() == False):
        print('test_PlaybookExecutor_run(): AssertionError')
    else:
        print('test_PlaybookExecutor_run(): Success')


# Generated at 2022-06-24 18:57:52.513553
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = dict()
    dict_0[1] = '1'
    dict_0[2] = '2'
    dict_0[3] = '3'
    dict_0[4] = '4'

    def my_func_0(num):
        if num == 0:
            return False
        elif num % 2 == 0:
            return True
        else:
            return False

    def my_func_1(num):
        return num

    list_0 = [1, 2, 3, 4, 5, 6]
    list_1 = [2, 4, 6, 8, 10]
    list_2 = [1, 3, 5, 7, 9]

    def my_func_2(num):
        if num == 1:
            return False

# Generated at 2022-06-24 18:57:58.320772
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_1 = ')bY'
        int_1 = 2147483647
        tuple_1 = (int_1,)
        dict_1 = {tuple_1: tuple_1, int_1: str_1}
        playbook_executor_1 = PlaybookExecutor(str_1, tuple_1, str_1, dict_1, str_1)
        val_1 = playbook_executor_1.run()
        return val_1
    except UnboundLocalError as err_1:
        display.warning(err_1)
    except TypeError as err_2:
        display.warning(err_2)
    except Exception as err_3:
        display.warning(err_3)


# Generated at 2022-06-24 18:58:03.136926
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    func_0 = sys._getframe().f_code.co_name

# Generated at 2022-06-24 18:58:10.121462
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '1'
    int_0 = 65536
    tuple_0 = (int_0,)
    dict_0 = {tuple_0: tuple_0, int_0: str_0}
    playbook_executor_0 = PlaybookExecutor(str_0, tuple_0, str_0, dict_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:19.048318
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'm5e'
    int_0 = -960437738
    int_1 = -903349091
    str_1 = 'w'
    int_2 = 1047890224
    str_2 = '+'
    int_3 = -261873770
    str_3 = 'q'
    str_4 = 'n1'
    str_5 = 'Jt'
    int_4 = 1314168774
    int_5 = 1002964066
    int_6 = -1822176776
    int_7 = -1613473126
    int_8 = -1491833772
    int_9 = -1624187599
    str_6 = '_p'
    int_10 = -1243466989
    int_11 = -108899

# Generated at 2022-06-24 18:58:25.142073
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'ZR'
    int_0 = 65536
    tuple_0 = (int_0,)
    dict_0 = {tuple_0: tuple_0, int_0: str_0}
    playbook_executor_0 = PlaybookExecutor(str_0, tuple_0, str_0, dict_0, str_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:58:32.483146
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'F#'
    int_0 = -41
    tuple_0 = (str_0, int_0)
    tuple_1 = (int_0,)
    dict_0 = {tuple_0: tuple_1, int_0: int_0}
    playbook_executor_0 = PlaybookExecutor(str_0, tuple_0, str_0, dict_0, str_0)
    result = playbook_executor_0.run()
    assert result is None


# Generated at 2022-06-24 18:59:09.079823
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    result = playbook_executor_0.run()
    print('result:', result)


if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:12.877573
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = ''
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)


# Generated at 2022-06-24 18:59:19.280717
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_0 = 'z,A:C'
        int_0 = 4245
        playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
        result = playbook_executor_0.run()
    except BaseException as e:
        print(e)


# Generated at 2022-06-24 18:59:30.916925
# Unit test for constructor of class PlaybookExecutor

# Generated at 2022-06-24 18:59:32.724089
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:36.440431
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = ')bH2GY'
    int_0 = -3856
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:43.255566
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'lj#l'
    int_0 = -14
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    playbook_executor_0.run()
 

# Generated at 2022-06-24 18:59:48.309336
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = ')bH2GY'
    int_0 = -3856
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 18:59:54.707390
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '9XZ*C'
    int_0 = -3856
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    print(playbook_executor_0.run())


# Generated at 2022-06-24 19:00:00.286700
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create a PlaybookExecutor object
    str_0 = ')bH2GY'
    int_0 = -3856
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)

    # Run method
    result = playbook_executor_0.run()
    # Check the result
    if None is not result:
        print("PlaybookExecutor.run() test passed")
    else:
        print("PlaybookExecutor.run() test failed")

# Start testing    
test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:38.643735
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = Playbook.load('../ansible/playbooks/test.yaml')
    passwords = {}
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    playbook_executor = PlaybookExecutor(playbooks=[playbook], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords)
    ret = playbook_executor.run()
    print(ret)

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:46.375484
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'result:'
    pl_executor = PlaybookExecutor([], Inventory(), VariableManager(), DataLoader(), {})
    result = pl_executor.run()
    assert_equal(result, 0)
    print(str_0)


# Generated at 2022-06-24 19:00:54.296983
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    msg = '''
    This is the primary class for executing playbooks, and thus the
    '''
    # Init
    playbooks = []
    inventory = None
    variable_manager = None
    loader = None
    passwords = None
    score = 0.0
    test_case_0(str_0)
    return score

# Generated at 2022-06-24 19:00:55.052062
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:01:02.689407
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # setup imports and mocks
    sys.path.append("../..")
    sys.path.append("..")
    sys.path.append(".")
    sys.modules['_ansible_version'] = MagicMock()
    sys.modules['ansible.module_utils.six.moves'] = MagicMock()
    sys.modules['ansible.module_utils.six'] = MagicMock()
    sys.modules['ansible.module_utils.six.moves.configparser'] = MagicMock()
    sys.modules['ansible.utils.collection_loader'] = MagicMock()
    sys.modules['ansible.utils.plugins'] = MagicMock()
    sys.modules['ansible.errors'] = MagicMock()
    sys.modules['ansible.module_utils.six.moves.queue'] = Magic

# Generated at 2022-06-24 19:01:08.712806
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    _inventory = Inventory()
    _variable_manager = VariableManager()
    _loader = DataLoader()
    _passwords = dict()
    _playbooks=[md5 + '.yml']

    # Call method
    pbe = PlaybookExecutor(_playbooks=_playbooks, inventory=_inventory, variable_manager=_variable_manager, loader=_loader, passwords=_passwords)
    pbe.run()


# Generated at 2022-06-24 19:01:18.800922
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # if the line below generates a no attribute error make sure that you have the latest ANSIBLE_CORE installed
    # pip install -r ansible-core/requirements.txt

    # instantiate base objects
    loader = DataLoader()
    VariableManager = VariableManager()

    my_vars = VariableManager()
    my_vars.extra_vars = {'hosts': 'hosts-test'}
    playbook_path = '../../library/test/test_playbooks/playbook.yml'
    playbook_path = os.path.abspath(playbook_path)
    playbook_path = load_playbook_relative_path(playbook_path)

    # create the Inventory and pass to var manager
    inventory = InventoryManager(loader=loader, variable_manager=my_vars,  host_list=[])
   

# Generated at 2022-06-24 19:01:24.221512
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    loader_0 = BaseLoader()
    playbook_executor_0 = PlaybookExecutor('/root/.ansible/tmp/ansible-tmp-1564603467.77-68195636347330/test_playbook.yml', [Localhost()], loader_0, {'become_pass': ''})
    result = playbook_executor_0.run()
    str_0 = 'result:'
    print(str_0, result)


# Generated at 2022-06-24 19:01:27.580763
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Init
    playbooks = None
    inventory = Inventory()
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict()
    # End

    # Assertions
    # End



# Generated at 2022-06-24 19:01:29.488699
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbookExecutor = PlaybookExecutor(["../test/test2.yml"], "", "", "", "")
    assert playbookExecutor is not None


# Generated at 2022-06-24 19:02:10.221279
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    if C.DEFAULT_VAULT_ID_MATCH:
        raise NotImplementedError()
    else:
        pass

    if C.DEFAULT_VAULT_ID_MATCH:
        raise NotImplementedError()
    else:
        pass

    str_0 = 'p'
    int_0 = 9
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)

    if context.CLIARGS.get('listhosts'):
        raise NotImplementedError()
    else:
        pass

    if context.CLIARGS.get('listhosts') :
        raise NotImplementedError()
    else:
        pass

    if context.CLIARGS.get('listhosts'):
        raise

# Generated at 2022-06-24 19:02:13.880606
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:02:16.257637
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('*', '9-', '&', 0, '.')
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:21.371998
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'S(1y'
    int_0 = -28885
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    assert playbook_executor_0.run() == -2

if __name__ == '__main__':
    test_PlaybookExecutor_run()
    test_case_0()

# Generated at 2022-06-24 19:02:24.675317
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = 'input/playbook_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(playbook, None, None, None, None)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:02:26.013465
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:02:28.904523
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    if __name__ == '__main__':
        try:
            test_case_0()
        except KeyboardInterrupt as e:
            print(e)

# Generated at 2022-06-24 19:02:39.474057
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '1\x7f\x19\x0e\x1c*'
    int_0 = -3856
    str_1 = '\x03\x00\x1a\x02\x1d'
    int_1 = -82
    str_2 = '\x03\x00\x1a\x02\x1d'
    int_2 = -82
    str_3 = '\x03\x00\x1a\x02\x1d'
    int_3 = -82
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_1, int_1, str_2)
    #playbook_executor_0.run()

# Generated at 2022-06-24 19:02:45.013715
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_arg_0 = ')'
    test_arg_1 = -3856
    test_arg_2 = ')'
    test_arg_3 = -3856
    test_arg_4 = ')'
    playbook_executor_0 = PlaybookExecutor(test_arg_0, test_arg_1, test_arg_2, test_arg_3, test_arg_4)
    # Should print 3
    print(playbook_executor_0.run())



# Generated at 2022-06-24 19:02:51.201730
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'FZq9z)'
    int_0 = -4680
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, str_0, int_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:35.933420
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    str_1 = 'input/playbooV_syntax.yml'
    str_2 = 'input/playbooV_syntax.yml'
    str_3 = 'input/playbooV_syntax.yml'
    str_4 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, str_2, str_3, str_4)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:40.831186
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:46.072831
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = 'input/playbooV_syntax.yml'
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, str_1, str_1, str_1)

    playbook_executor_1.run()


# Generated at 2022-06-24 19:03:48.131442
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as err:
        print(err)


# Generated at 2022-06-24 19:03:53.459118
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # init
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    # test
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:59.901906
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    e = PlaybookExecutor('','','','','')
    pb = Playbook.load(str_0, variable_manager=e._variable_manager, loader=e._loader)
    play = pb.get_plays()
    play.post_validate(Templar(loader=e._loader, variables=e._variable_manager.extra_vars))
    play.serialize()
    e._get_serialized_batches(play)


# Generated at 2022-06-24 19:04:10.472386
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Test -1: check default value")
    str_0 = "~/a_playbook.yml"
    str_1 = "~/a_playbook1.yml:/playbooks/a_playbook.yml"
    passwords = {}
    str_3 = "Inventory"
    str_4 = "VariableManager(loader=None, inventory=Inventory(loader=None, sources=[], hosts=None, groups=None, cache=None, platform_parser=None, basedir=None), extra_vars=None)"
    str_5 = 'input/playbooV_syntax.yml'
    str_6 = 'input/test/test6/'
    str_7 = '..'
    str_8 = "input/test/test6/test6.yml"

# Generated at 2022-06-24 19:04:13.494718
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:04:24.198145
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_list = playbook_executor_0.run()

    for result in result_list:
        print("       Playbook file: " + result['playbook'])
        for play in result['plays']:
            print("           Name: " + play.get_name())
            print("           Hosts: " + " ".join(play.hosts))
            print("           Tasks:")
            for task in play.tasks:
                print("               " + task.get_name())



# Generated at 2022-06-24 19:04:28.187022
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()



# Generated at 2022-06-24 19:05:06.793625
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = 'input/playbooV_syntax.yml'
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, str_1, str_1, str_1)
    assert playbook_executor_1.run() == 0
    str_2 = 'input/playbooV_syn_check.yml'
    playbook_executor_2 = PlaybookExecutor(str_2, str_2, str_2, str_2, str_2)
    assert playbook_executor_2.run() == 0


# Generated at 2022-06-24 19:05:13.916640
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    result = 0
    entrylist = []
    entry = {}

    from ansible import context
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.cli import CLI
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.errors import AnsibleParserError
    from ansible.parsing.splitter import parse_kv

    # create a parser
    parser = CLI.base_parser(
        constants.DEFAULT_MODULE_PATH,
        constants.DEFAULT_MODULE_NAME,
        constants.DEFAULT_MODULE_PATH,
    )
    parser.add_option('-i', '--inventory-file', dest='inventory', help="specify inventory host path or comma separated host list.")


# Generated at 2022-06-24 19:05:18.956196
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    try:
        ansible_playbook_0 = playbook_executor_0.run()
        return
    except Exception as e:
        raise


# Generated at 2022-06-24 19:05:22.035382
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor([], "", "", "", "")
    playbook_executor_0.run()
# test case0
test_case_0()

# Generated at 2022-06-24 19:05:24.693183
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except:
        print('\nAn exception has been raised. Check your code')
        return


test_PlaybookExecutor()

# Generated at 2022-06-24 19:05:32.027601
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    arg_0 = 'input/playbooV_syntax.yml'
    arg_1 = 'input/playbooV_syntax.yml'
    arg_2 = 'input/playbooV_syntax.yml'
    arg_3 = 'input/playbooV_syntax.yml'
    arg_4 = 'input/playbooV_syntax.yml'
    playbk_executor = PlaybookExecutor(arg_0, arg_1, arg_2, arg_3, arg_4)


# Generated at 2022-06-24 19:05:40.644842
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    str_1 = 'input/playbooV_syntax.yml'
    str_2 = 'input/playbooV_syntax.yml'
    str_3 = 'input/playbooV_syntax.yml'
    str_4 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, str_2, str_3, str_4)
    playbook_executor_0.run()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:48.128228
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Test against single playbook
    str_0 = 'input/playbook_syntax.yml'
    inventory_0 = InventoryManager('input/inventory.ini')
    variable_manager_0 = VariableManager()
    loader_0 = loader.DataLoader()
    passwords_0 = None
    playbook_executor_0 = PlaybookExecutor(str_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    try:
        result_0 = playbook_executor_0.run()
    except:
        assert False, 'Unexpected exception thrown from method run of PlaybookExecutor class.'

    # Test against list of playbooks
    list_0 = []
    list_0.append('input/playbook_syntax.yml')

# Generated at 2022-06-24 19:05:58.009007
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('input/playbooV_syntax.yml', 'input/playbooV_syntax.yml', 'input/playbooV_syntax.yml', 'input/playbooV_syntax.yml', 'input/playbooV_syntax.yml')
    result = playbook_executor_0.run()
    if isinstance(result, int):
        print("PASSED: PlaybookExecutor_run()")
    else:
        print("FAILED: PlaybookExecutor_run()")


if __name__ == '__main__':
    # test_PlaybookExecutor_run()
    test_case_0()

# Generated at 2022-06-24 19:06:01.571901
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'input/playbooV_syntax.yml'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:06:52.831421
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    arguments = {}
    arguments['syntax'] = False
    arguments['connection'] = 'local'
    arguments['module_path'] = None
    arguments['forks'] = 5
    arguments['remote_user'] = None
    arguments['private_key_file'] = None
    arguments['ssh_common_args'] = None
    arguments['ssh_extra_args'] = None
    arguments['sftp_extra_args'] = None
    arguments['scp_extra_args'] = None
    arguments['become'] = None
    arguments['become_method'] = None
    arguments['become_user'] = None
    arguments['verbosity'] = 5
    arguments['check'] = False
    arguments['diff'] = False
    arguments['listhosts'] = False
    arguments['listtasks'] = False