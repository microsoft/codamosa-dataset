

# Generated at 2022-06-24 18:57:33.927161
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    _playbooks = {2073}
    _inventory = {'a', 2073}
    _variable_manager = {2073, 'a', 'a'}
    _loader = 2073
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(_playbooks, _inventory,
                                           _variable_manager, _loader, float_0)
    int_0 = playbook_executor_0.run()
    assert int_0 == 2073

# Test class PlaybookExecutor


# Generated at 2022-06-24 18:57:36.009249
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    # Unit test
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:57:40.008363
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test of method run of class PlaybookExecutor
    # Invoke testing cases:
    # test_case_0()
    # test_case_1()
    test_case_0()

# Generated at 2022-06-24 18:57:41.952855
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:51.738978
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
  import types
  import sys
  import ansible.playbook.play
  import ansible.vars.manager
  import ansible.inventory.manager
  import ansible.cli
  import ansible.inventory
  import ansible.playbook
  import ansible.playbook.play
  import ansible.playbook.role
  import ansible.playbook.task
  import ansible.template
  import ansible.parsing.dataloader
  import ansible.executor.task_queue_manager
  import ansible.constants
  import ansible.utils.plugin_docs
  import ansible.utils.display
  import ansible.utils.path
  import ansible.utils.ssh_functions
  import ansible.utils.display
  import ansible.utils.collection_loader
  import ansible.plugins

# Generated at 2022-06-24 18:57:56.309974
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    assert (playbook_executor_0.run() == None)


# Generated at 2022-06-24 18:58:05.624136
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    float_1 = float()
    float_0 = float()
    float_2 = float()
    float_3 = float()
    set_0 = {dict_0, dict_0, dict_0}
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    assert playbook_executor_0._playbooks == dict_0
    assert playbook_executor_0._inventory == dict_0
    assert playbook_executor_0._variable_manager == set_0
    assert playbook_executor_0._loader == dict_0
    assert playbook_executor_0.passwords == float_0
    assert playbook_executor_0._unreachable_hosts == dict_0
    assert playbook_executor_0

# Generated at 2022-06-24 18:58:07.188831
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()



# Generated at 2022-06-24 18:58:15.000879
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    playbook_executor_0.run()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-24 18:58:22.007178
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 18:58:47.496361
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
        print('test_PlaybookExecutor_run: ok')
    except Exception as ex:
        print('test_PlaybookExecutor_run: error')

# Generated at 2022-06-24 18:58:49.270548
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # test case 0
    test_case_0()

test_PlaybookExecutor()

# Generated at 2022-06-24 18:58:52.031723
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    exec = PlaybookExecutor('playbook.yml', 'inventory', 'variable_manager', 'loader', 'passwords')
    result = exec.run()
    assert result == 0

# Generated at 2022-06-24 18:59:00.443541
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 18:59:01.723151
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:04.611662
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:07.848888
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.executor.playbook_executor import PlaybookExecutor

    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 18:59:13.705254
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    playbook_executor_0.run()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:23.236510
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 18:59:26.915508
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = None
    set_0 = {dict_0, dict_0, dict_0}
    float_0 = 2073.0
    playbook_executor_0 = PlaybookExecutor(dict_0, dict_0, set_0, dict_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:51.682390
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:52.917471
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    pass


# Generated at 2022-06-24 18:59:54.438879
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('inventory', 'inventory', 'inventory', 'inventory', 'inventory')
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:59:58.234326
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 19:00:05.367350
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    display.display("Test 0: test case 0")
    test_case_0()
    display.display("Test 0: finished")

try:
    if len(sys.argv) > 1 and sys.argv[1] == 'unit_test':
        # A function call to unit test this class
        display.display("Call test_PlaybookExecutor_run()")
        test_PlaybookExecutor_run()

except Exception as e:
    traceback.print_exc()
    display.display(str(e))

# Generated at 2022-06-24 19:00:12.099263
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:23.304208
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # The first set of parameters correspond to the private fields of an object of this class.
    # We mock these private fields with arbitrary values.
    # The second set of parameters correspond to the local variables inside the 'run' method.
    # We mock these variables with arbitrary values.
    inventory_0 = mock.Mock()
    variable_manager_0 = mock.Mock()
    loader_0 = mock.Mock()
    passwords_0 = mock.Mock()
    context.CLIARGS = {'syntax': False, 'listhosts': False, 'listtasks': False, 'listtags': False, 'start_at_task': False}
    playbook_executor_0 = PlaybookExecutor(['test_0'], inventory_0, variable_manager_0, loader_0, passwords_0)
    result_0 = playbook_

# Generated at 2022-06-24 19:00:25.087890
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:00:31.420989
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    a = 'inventory'
    b = 'inventory'
    c = 'inventory'
    d = 'inventory'
    e = 'inventory'
    pbe = PlaybookExecutor(a,b,c,d,e)
    assert pbe == pbe
    assert pbe.__class__ == PlaybookExecutor


# Generated at 2022-06-24 19:00:35.080791
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-24 19:01:43.238948
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        str_0 = 'inventory'
        playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

        del playbook_executor_0
        print('# unit test for PlaybookExecutor.PlaybookExecutor() # Passed')
    except:
        print('# unit test for PlaybookExecutor.PlaybookExecutor() # Failed')


# Generated at 2022-06-24 19:01:52.945300
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    str_1 = 'variable_manager'
    str_2 = 'loader'
    str_3 = 'passwords'
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, str_2, str_2, str_3)
    if __name__ == '__main__':
        test_PlaybookExecutor_run()
    else:
        test_case_0()

# Generated at 2022-06-24 19:01:58.742964
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

if __name__ == '__main__':
    #test_case_0()
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:02.215889
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = 'inventory'
    loader = 'loader'
    variable_manager = 'variable_manager'
    passwords = 'passwords'
    # Test for correct argument count
    assert(not hasattr(PlaybookExecutor, 'run'))


# Generated at 2022-06-24 19:02:06.570380
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Method arguments
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:08.199099
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:02:09.753609
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    playbook_executor_0.run()



# Generated at 2022-06-24 19:02:15.713323
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:16.553858
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:02:20.601236
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0._playbooks = inventory
    playbook_executor_0.run()
   

# Generated at 2022-06-24 19:03:32.284480
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        # Test case 0
        test_case_0()
    except Exception as e:
        raise e
    else:
        pass


if __name__ == "__main__":
    try:
        test_PlaybookExecutor()
    except Exception as e:
        raise e

# Generated at 2022-06-24 19:03:36.987744
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:42.594548
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    str_1 = 'playbook_executor_0'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:48.747606
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Usual python file code
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:53.618440
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:03:55.785158
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass # test_case_0()

# Testing if the class PlaybookExecutor is working correctly

# Generated at 2022-06-24 19:04:04.497867
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0._playbooks == 'inventory'
    assert playbook_executor_0._inventory == 'inventory'
    assert playbook_executor_0._variable_manager == 'inventory'
    assert playbook_executor_0._loader == 'inventory'
    assert playbook_executor_0.passwords == 'inventory'
    assert playbook_executor_0._unreachable_hosts == {}
    assert playbook_executor_0._tqm == None


# Generated at 2022-06-24 19:04:08.997834
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Setup of variables needed to test call of run method
    str_0 = 'inventory'
    playbook_executor = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    # Call of run method
    playbook_executor.run()

    # Output of results
    display.display("RESULTS: run call")

# Generated at 2022-06-24 19:04:14.015142
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()
    test_case_0()

# Generated at 2022-06-24 19:04:15.359735
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except Exception as msg:
        print(msg)



# Generated at 2022-06-24 19:05:28.656906
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:05:39.939585
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    res = None

# Generated at 2022-06-24 19:05:40.901203
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:05:47.614653
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Unit test for PlaybookExecutor.run()
    # create a fixture for PlaybookExecutor class
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    # call method PlaybookExecutor.run() of class PlaybookExecutor
    result = playbook_executor_0.run()
    # check the result
    if result is not None:
        print("Method run of class PlaybookExecutor() returned value: " + repr(result))
        print("Result type: " + repr(type(result)))
    else:
        print("Method run of class PlaybookExecutor() returned value: None")



# Generated at 2022-06-24 19:05:49.179985
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:53.671736
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Unit test entry point
if __name__ == "__main__":
    print("Start unit test for PlaybookExecutor")
    test_PlaybookExecutor_run()
    print("Finish unit test for PlaybookExecutor")

# Generated at 2022-06-24 19:05:55.880010
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('inventory', 'inventory', 'inventory', 'inventory', 'inventory')
    playbook_executor_0.run()

# Generated at 2022-06-24 19:06:04.757646
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test case with str_0 and str_0
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        playbook_executor_0.run()
    except SystemExit:
        pass

    # Test case with str_0 and int_0
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        playbook_executor_0.run()
    except SystemExit:
        pass

    # Test case with str_1 and int_0
    str_0 = 'inventory'
    str_1 = 'playbooks'
    playbook_executor_0

# Generated at 2022-06-24 19:06:07.514685
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'inventory'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:06:08.451419
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()