

# Generated at 2022-06-24 18:57:36.280337
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    var_0 = playbook_executor_0.run()
    assert 'xdvp.sw' in str_0
    assert 'W7P\\x0bD7R3:xdvp.sw' in str_0


# Generated at 2022-06-24 18:57:41.937971
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    var_0 = playbook_executor_0.run()


# Generated at 2022-06-24 18:57:43.832093
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:49.070764
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    var_0 = playbook_executor_0.run()


test_case_0()

# Generated at 2022-06-24 18:57:49.979183
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 18:57:50.804350
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:55.694340
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    var_0 = playbook_executor_0.run()
    return var_0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:02.659665
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    assert type(playbook_executor_0) == PlaybookExecutor


# Generated at 2022-06-24 18:58:06.437713
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Test for PlaybookExecutor class.
    '''
    test_case_0()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:16.488345
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 956.748
    set_0 = set()
    str_0 = 'W7P\x0bD7R3:xdvp.sw'
    playbook_executor_0 = PlaybookExecutor(float_0, set_0, str_0, float_0, str_0)
    playbook_executor_0.run()
    float_1 = 857.2818
    str_1 = 'y=X\x1c\x1e\x16\x03\x0f\x19\x1a6\x1f\x1e\x1c'
    playbook_executor_0 = PlaybookExecutor(float_1, set_0, str_1, float_1, str_1)
    int_0 = playbook_executor_0.run()
    assert int

# Generated at 2022-06-24 18:58:53.513326
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from modules.connection.persistent import PersistentConnection
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import become_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

# Generated at 2022-06-24 18:59:02.818928
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    #pylint: disable=protected-access

    # test with no params
    collection_name = 'some_valid_collection_name'
    collection_path = '/some/valid/collection/path'
    playbook_path = '/some/valid/playbook/path'
    def mock_collection_finder_get_collection_playbook_path(collection_name):
        if collection_name == 'some_valid_collection_name':
            return (collection_path, playbook_path)
        return (None, None)

    def mock_collection_finder_get_collection_name_from_path(playbook_path):
        if playbook_path == '/some/valid/collection/path/playbook.yml':
            return 'some_valid_collection_name'
        return None


# Generated at 2022-06-24 18:59:13.922118
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        assert str_0 is not None
    finally:
        pass
    try:
        assert str_0 is not None
    finally:
        pass

    # Creation of the object PlaybookExecutor
    test_PlaybookExecutor = PlaybookExecutor(
        playbooks = [],
        inventory = None,
        variable_manager = None,
        loader = None,
        passwords = None
    )

    # Test case for the method run of the class PlaybookExecutor
    assert test_PlaybookExecutor.run() == 0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:19.074513
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # PlaybookExecutor class
    playbookExecutor = PlaybookExecutor(playbooks=playbooks, inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords)
    result = playbookExecutor.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:23.802506
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # This one is tricky as it would be nice to test it with a real playbook
    # but that would require building the CLI options into the test case.  This
    # test is here because I was getting coverage pain.
    runner = PlaybookExecutor(playbooks=[], inventory=InventoryManager(loader=None, sources=['']), variable_manager=VariableManager(), loader=None, passwords={})
    assert runner.run() == 0
    assert runner._generate_retry_inventory('', []) == False

# Generated at 2022-06-24 18:59:26.973328
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '\n    Test for PlaybookExecutor class.\n    '
    # gt is a global variable for global trace, set to True or False
    # When set to True, print out all traces
    gt = False
    if not gt: return
    print(str_0)


# Generated at 2022-06-24 18:59:38.604858
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Test for PlaybookExecutor class.
    '''
    # Test with different values of context_obj.CLIARGS and expected result
    res_0 = 0
    res_1 = 0
    res_2 = 0
    res_3 = 0
    res_4 = 0

    # Test with different value of passwords, inventory, variable_manager, loader and arg
    pl_executor_obj = PlaybookExecutor(playbook_0, inventory_0, var_manager_0, loader_0, passwords_0)

    # execute the run method
    res_0 = pl_executor_obj.run()
    res_1 = pl_executor_obj.run()
    res_2 = pl_executor_obj.run()
    res_3 = pl_executor_obj.run()
    res_4

# Generated at 2022-06-24 18:59:44.957367
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print('\n')
    print('Testing PlaybookExecutor class')

    print('\n')
    print('Testing PlaybookExecutor constructor')
    pbex = PlaybookExecutor()

    print('\n')
    print('Testing PlaybookExecutor run method')
    pbex.run()

# Generated at 2022-06-24 18:59:48.827816
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# if __name__ == '__main__':
#     test_PlaybookExecutor()
#     pass

# Generated at 2022-06-24 18:59:51.389331
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    args_0 = {}
    args_0[str_0] = 1
    result_0 = PlaybookExecutor.run(args_0)
    assert result_0 == 0

# Generated at 2022-06-24 19:00:21.638377
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        hush_py_logging = logging.getLogger("paramiko").setLevel(logging.WARNING)
        playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
        result = playbook_executor_0.run()
    except Exception as e:
        f = None
    else:
        f = 0
    assert f == 0


# Generated at 2022-06-24 19:00:31.552862
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    var_5 = []
    var_6 = []
    var_7 = []
    var_8 = []
    var_9 = []
    playbook_executor_1 = PlaybookExecutor(var_5, var_6, var_7, var_8, var_9)
    var_10 = []
    var_11 = []
    var_12 = []
    var_13 = []
    var_14 = []

# Generated at 2022-06-24 19:00:33.090824
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass
#
#
#
#



# Generated at 2022-06-24 19:00:43.819760
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Local variable for test
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbooks_0 = ['playbooks/testplaybook.yml']
    inventory_0 = Inventory(var_0)
    var_manager_0 = VariableManager(var_0, var_0)
    loader_0 = DataLoader()
    passwords_0 = dict()
    playbook_executor_1 = PlaybookExecutor(playbooks_0, inventory_0, var_manager_0, loader_0, passwords_0)
    playbook_executor_1.run()

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:51.650473
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = []
    var_7 = []
    var_8 = []
    var_9 = []
    var_10 = []
    var_11 = []
    var_12 = []
    var_13 = []
    var_14 = []
    var_15 = []
    var_16 = []
    var_17 = []
    var_18 = []
    var_19 = []
    var_20 = []
    var_21 = []
    var_22 = []
    var_23 = []
    var_24 = []
    var_25 = []
    var_26 = []
    var_27 = []
    var_

# Generated at 2022-06-24 19:00:54.906129
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_0)
    # call the method
    playbook_executor_0.run()

# Generated at 2022-06-24 19:01:00.837453
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ['/root/ansible/lib/ansible/playbooks/reboot-server.yml', '/root/ansible/lib/ansible/playbooks/copy-csv-data.yml']
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:04.858437
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = playbook_executor_0.run()
    pass



# Generated at 2022-06-24 19:01:06.663527
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 19:01:10.081221
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:01:46.807593
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    
    # Call test_case_0
    test_case_0()
    # Assertion for method run of class PlaybookExecutor
    assert(result == expected_result)



# Generated at 2022-06-24 19:01:49.805029
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    ret = playbook_executor_0.run()
    print(ret)


# Generated at 2022-06-24 19:02:01.903464
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = []
    var_7 = []
    var_8 = []
    var_9 = []
    var_10 = []
    var_11 = []
    var_12 = []
    var_13 = []
    var_14 = []
    var_15 = []
    var_16 = []
    var_17 = []
    var_18 = []
    var_19 = []
    var_20 = []
    var_21 = []
    var_22 = []
    var_23 = []
    var_24 = []
    var_25 = []
    var_26 = []
    var_27 = []
    var_28 = []
    var_

# Generated at 2022-06-24 19:02:07.693293
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    # PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, passwords=None)
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-24 19:02:14.964768
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    try:
        playbook_executor_0.run()
    except AnsibleEndPlay as e:
        var_1 = e.result
        var_0.append(var_1)
    return var_0


# Generated at 2022-06-24 19:02:18.318880
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:02:24.415625
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_1 = PlaybookExecutor(var_1, var_2, var_3, var_4, var_1)
    try:
        var_5 = playbook_executor_1.run()
    except:
        var_5 = None
    assert var_5 is None


# Generated at 2022-06-24 19:02:29.267088
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    # (retval, result) = playbook_executor_0.run()


# Generated at 2022-06-24 19:02:34.777069
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Test case for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:02:41.514525
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    host_0 = Host('ubuntu1604')
    var_0 = [host_0]
    var_1 = [host_0]
    var_2 = [host_0]
    var_3 = [host_0]
    var_4 = [host_0]
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    assert playbook_executor_0.run() == 0
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:17.793771
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:20.260954
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    assert playbook_executor_0.run() == 0

# Generated at 2022-06-24 19:03:26.639740
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    obj = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    obj.run()


# Generated at 2022-06-24 19:03:32.391603
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """ PlaybookExecutor.run() Exceptions cases """
    try:
        test_case_0()
    except Exception as e:
        print("Exception in PlaybookExecutor.run(): " + str(e))
        raise e

    print("PlaybookExecutor.run() test cases passed")

# Test for generating retry inventory

# Generated at 2022-06-24 19:03:36.330061
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    result_0 = playbook_executor_0.run()
    assert type(result_0) is int


# Generated at 2022-06-24 19:03:48.767811
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    var_6 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    var_7 = 0
    var_8 = []
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_

# Generated at 2022-06-24 19:03:57.242282
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    try:
        var_5 = False
        if (not var_5):
            raise AnsibleError
        var_6 = None
        if (var_6 is None):
            raise AnsibleError
        if (var_6 is None):
            raise AnsibleError
        if (var_2 is None):
            raise AnsibleError
        if (var_3 is None):
            raise AnsibleError
        if (var_4 is None):
            raise AnsibleError
    except AnsibleError as e:
        var_7 = e
       

# Generated at 2022-06-24 19:04:07.863316
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    var_5 = []
    playbook_executor_1 = PlaybookExecutor(var_1, var_2, var_3, var_4, var_5)
    var_6 = None
    var_7 = False
    var_8 = []
    var_9 = []
    var_10 = []
    var_11 = [TestAnsibleModule_10]
    var_12 = False
    var_13 = False
    var_14 = 'my_test.yml'
    var_15 = False
    var_16 = False
    var_17 = False
    var_18 = ['my_test.yml']
    var_19 = False
    var_20 = False
    var_

# Generated at 2022-06-24 19:04:13.730848
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print('')
    print('Testing PlaybookExecutor.run')
    print('')

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:16.544480
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Unit test for method run of class PlaybookExecutor.
    '''
    pass


# Generated at 2022-06-24 19:04:56.366565
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:04:59.541177
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:05:02.239720
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except Exception as e:
        print('test_PlaybookExecutor_run error: ', e)

# Generate a test case for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:05:04.741248
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:05:08.622682
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    try:
        var_1 = playbook_executor_0.run()
    except:
        var_1 = None

    return var_1


# Generated at 2022-06-24 19:05:11.022599
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:05:14.750889
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:05:18.654063
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    result = playbook_executor_0.run()

    assert result == 0


# Generated at 2022-06-24 19:05:24.707892
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    try:
        assert playbook_executor_0.run() == 0
    except Exception as err:
        print ("Test failled: %s" % err)
    else:
        print ("Test passed")


# Generated at 2022-06-24 19:05:29.036506
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = []
    playbook_executor_1 = PlaybookExecutor(var_1, var_1, var_1, var_1, var_1)
    playbook_executor_1.run()


# Generated at 2022-06-24 19:06:08.583911
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    assert isinstance(playbook_executor_0, PlaybookExecutor)


# Generated at 2022-06-24 19:06:15.997943
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.callback.default import CallbackModule
    from ansible.errors import AnsibleError
    from ansible.vars.hostvars import HostV

# Generated at 2022-06-24 19:06:20.473058
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    result = playbook_executor_0.run()


# Generated at 2022-06-24 19:06:31.299247
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    all_hosts_len = 0
    base_dir = 'base_dir'
    batched_hosts = ['batched_hosts', 'batched_hosts-2']
    batches = [batched_hosts]
    basedir = "basedir"
    become = "become"
    become_path = 'become_path'
    become_user = "become_user"
    become_method = "become_method"
    forks = 0
    cur_item = 0
    group = "group"
    group_vars = "group_vars"
    host = "host"
    host_vars = "host_vars"
    inventory = "inventory"
    loader = "loader"
    loader_0 = "loader_0"

# Generated at 2022-06-24 19:06:37.250352
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = PlaybookExecutor(('/Users/xormedia/PycharmProjects/pyansibleplaybook/playbook/playbook', ),
                             InventoryManager(var_0, var_0),
                             VariableManager(var_0, var_0, var_0, var_0),
                             DataLoader(), {'ansible_connection': 'local'})
    var_0.run()


# Generated at 2022-06-24 19:06:39.992626
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test with a vararg param
    var_0 = 1
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    if playbook_executor_0:
        playbook_executor_0.run()

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:41.184584
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-24 19:06:49.499122
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        var_0 = []
        var_0 = []
        var_0 = []
        var_0 = []
        var_0 = []
        playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
        # These asserts are checking the type of the object.
        assert isinstance(playbook_executor_0, PlaybookExecutor)

        # Test for __main__.PlaybookExecutor.run
        # The method was not tested.
    except:
        raise

# Generated at 2022-06-24 19:06:52.721586
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = []
    var_1 = []
    var_2 = []
    var_3 = []
    var_4 = []
    playbook_executor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    playbook_executor_0.run()