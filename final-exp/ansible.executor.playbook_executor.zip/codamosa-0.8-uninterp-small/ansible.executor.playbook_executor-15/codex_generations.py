

# Generated at 2022-06-24 18:57:31.990324
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    list_0 = []
    bool_0 = True
    str_0 = '}pZ/^\n['
    float_0 = -98.69
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    assert playbook_executor_0


# Generated at 2022-06-24 18:57:34.152782
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 18:57:38.526794
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    list_0 = []
    bool_0 = False
    str_0 = ';"mF'
    float_0 = 3.92
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    playbook_executor_0.run()
    test_case_0()

# Generated at 2022-06-24 18:57:42.550494
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = []
    list_1 = []
    bool_0 = False
    str_0 = '}[S'
    float_0 = 78.34
    playbook_executor_0 = PlaybookExecutor(list_0, list_1, bool_0, str_0, float_0)
    result = playbook_executor_0.run()
    assert              result == 0


# Generated at 2022-06-24 18:57:49.941326
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print('# Unit test for method run of class PlaybookExecutor')
    list_0 = []
    bool_0 = False
    str_0 = ';}$\nD'
    float_0 = None
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    playbook_executor_0.run()
    print('# Unit test for method run of class PlaybookExecutor end')

test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:57:57.157543
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = []
    bool_0 = False
    str_0 = ';}$\nD'
    float_0 = None
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    # AttributeError: 'PlaybookExecutor' object has no attribute '_tqm'
    # assert playbook_executor_0.run() == 0
    # assert playbook_executor_0.run() == 1


# Generated at 2022-06-24 18:58:00.085283
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = [None]
    bool_0 = True
    str_0 = '4dR/T'
    float_0 = None
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    int_0 = playbook_executor_0.run()
    assert int_0 == 0

# Generated at 2022-06-24 18:58:08.623961
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pytest.skip("Skipped; no escape sequence is supported in a string")
    # Initialization code
    list_0 = []
    bool_0 = False
    str_0 = ';}$\nD'
    float_0 = None
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)

    # Try expected case
    result = playbook_executor_0.run() # pass in test case parameter here
    assert result == 0


# Generated at 2022-06-24 18:58:13.563583
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = []
    bool_0 = False
    str_0 = ''
    float_0 = None
    playbook_executor_0 = PlaybookExecutor(list_0, list_0, bool_0, str_0, float_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 0


# Generated at 2022-06-24 18:58:26.302074
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_0 = [_get_collection_playbook_path('playbook_executor.py')]
    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager()
    loader = DataLoader()
    playbook_executor_0 = PlaybookExecutor(list_0, inventory, variable_manager, loader, None)
    playbook_executor_0._inventory.clear_pattern_cache()
    playbook_executor_0._tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=None,
        forks=10
    )
    playbook_executor_0._tqm.load_callbacks()
    return_value = playbook_executor_0.run()
    print(return_value)


# Unit

# Generated at 2022-06-24 18:59:06.780885
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()
    #try:
    #    test_case_0()
    #except:
    #    return False
    return True

# main()
if __name__ == "__main__":
    if test_PlaybookExecutor():
        print('PlaybookExecutor.py: test run OK')
    else:
        print('PlaybookExecutor.py: test run FAIL')

# Generated at 2022-06-24 18:59:07.922522
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Setup the test case
    test_case_0()


# Generated at 2022-06-24 18:59:10.292512
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'playbook_executor.py'
    var_0 = None
    int_0 = 10


# Generated at 2022-06-24 18:59:16.682505
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    _loader = DataLoader()
    _inventory = InventoryManager(loader=_loader, sources='')
    _variable_manager = VariableManager(loader=_loader, inventory=_inventory)
    _passwords = dict()
    executor = PlaybookExecutor(playbooks=str_0, inventory=_inventory, variable_manager=_variable_manager, loader=_loader, passwords=_passwords)
    int_1 = executor.run()
    assert int_1 == int_0
    assert executor._tqm == var_0

# Generated at 2022-06-24 18:59:18.737684
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pytest.skip("Test case for Class PlaybookExecutor is not implemented.")

# Generated at 2022-06-24 18:59:19.817241
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    obj = PlaybookExecutor.run()


# Generated at 2022-06-24 18:59:26.431918
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    runner = PlaybookExecutor(
    [],
    '''
    [inventory_hostname_0]
    [inventory_hostname_1]
    [inventory_hostname_2]
    ''',
    None,
    None,
    None
    )
    runner.run()

# Generated at 2022-06-24 18:59:31.998615
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = get_random_string()
    list_0 = get_random_list()
    str_1 = get_random_string()
    dict_0 = get_random_dict()
    str_2 = get_random_string()
    dict_1 = get_random_dict()
    obj_0 = PlaybookExecutor(str_0, list_0, str_1, dict_0, dict_1)
    return


# Generated at 2022-06-24 18:59:36.200087
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 10
    str_0 = 'playbook_executor.py'
    var_0 = None
    var_1 = None
    dict_0 = {}
    obj_0 = PlaybookExecutor(var_1, var_0, var_0, var_0, dict_0)
    assert isinstance(obj_0, PlaybookExecutor)
    assert obj_0._playbooks == []
    assert obj_0._inventory is None
    assert obj_0._variable_manager is None
    assert obj_0._loader is None
    assert obj_0.passwords == {}
    assert obj_0._unreachable_hosts == {}
    assert obj_0._tqm is None


# Generated at 2022-06-24 18:59:40.486934
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = PlaybookExecutor()
    var_1 = {}
    var_1["playbook"] = "playbook_executor.py"
    var_1["plays"] = []
    var_2 = True
    assert var_0.run(var_1) == var_2


# Generated at 2022-06-24 19:00:20.027515
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    PlaybookExecutor.run()

if __name__ == '__main__':
    print('Running unit tests')
    test_array = [test_PlaybookExecutor_run]
    for i in range(len(test_array)):
        test_array[i]()
        print('test case ', i, ' passed')

# Generated at 2022-06-24 19:00:28.275334
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    n = PlaybookExecutor()

    p = Playbook()
    n._playbooks = [p]

    i = C.DEFAULT_HOST_LIST
    n._inventory = i

    v = VariableManager()
    n._variable_manager = v

    l = DataLoader.FilePreProcessor()
    n._loader = l

    assert n.run() == 0

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:38.838290
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor()
    playbook_executor._playbooks = [os.path.join(os.path.sep, 'var', 'lib', 'awx', 'projects', '6')]
    playbook_executor._inventory = Hosts()
    playbook_executor._variable_manager = VariableManager()
    playbook_executor._loader = DataLoader()
    playbook_executor.passwords = {'_ansible': {'transport': 'ssh', 'user': 'root', 'ssh_pass': 'toor', 'become_pass': 'toor', 'become_user': 'root'}}

# Generated at 2022-06-24 19:00:45.056766
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks_0 = ["test"]
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=None)
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    passwords_0 = {"key": "value"}
    PlaybookExecutor_0 = PlaybookExecutor(playbooks_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    PlaybookExecutor_0.run()
    test_case_0()


test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:45.811069
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:00:52.616727
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test task 1
    test_case_0()
    # Test task 2
    # Test task 3
    # Test task 4
    # Test task 5
    # Test task 6
    # Test task 7
    # Test task 8
    # Test task 9
    # Test task 10
    # Test task 11
    # Test task 12
    # Test task 13
    # Test task 14
    # Test task 15
    # Test task 16
    # Test task 17
    # Test task 18
    # Test task 19
    # Test task 20
    # Test task 21
    # Test task 22

# Generated at 2022-06-24 19:00:55.056266
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Instantiate a test object
    obj = PlaybookExecutor()

    # Invoke the run method
    test_case_0()

# a = PlaybookExecutor()
# a.run()

# Generated at 2022-06-24 19:01:02.048517
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ['/tmp/ansible-test/test_case_0/test_case_0.yml']
    inventory = '/tmp/ansible-test/test_case_0/ansible.cfg'
    variable_manager = '/tmp/ansible-test/test_case_0/ansible.cfg'
    loader = '/tmp/ansible-test/test_case_0/ansible.cfg'
    passwords = '/tmp/ansible-test/test_case_0/ansible.cfg'
    playbookexecutor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    playbookexecutor.run()
# end of test_PlaybookExecutor_run

# Generated at 2022-06-24 19:01:04.753722
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    unit test for method PlaybookExecutor.run
    '''
    p0 = PlaybookExecutor()
    test_case_0()


# Generated at 2022-06-24 19:01:12.760396
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # load the test case data
    data = load_test_data("data/test_playbook_executor.json")
    # create an instance of PlaybookExecutor
    test_PlaybookExecutor = PlaybookExecutor()
    # call method run of test_PlaybookExecutor
    test_PlaybookExecutor.run()
    # check if the expected_result and the return value are identical
    assert test_PlaybookExecutor.run() == data['return_value']
    # verify the returned value
    #assert test_PlaybookExecutor.run() == return_value
    # make the other assertions
    #assert test_PlaybookExecutor.run() == return_value
    #assert test_PlaybookExecutor.run() == return_value
    #assert test_PlaybookExecutor.run() == return_value
    #assert test

# Generated at 2022-06-24 19:01:54.398214
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_1 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_2 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_3 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '

# Generated at 2022-06-24 19:02:01.943467
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 0, str(result_0)


# Generated at 2022-06-24 19:02:07.437701
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:02:14.395779
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:20.700691
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:34.690255
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_1 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_2 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    str_3 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '

# Generated at 2022-06-24 19:02:40.396587
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-24 19:02:48.400992
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    print(playbook_executor_0)
    #assert playbook_executor_0.run() == 0
    #assert playbook_executor_0.run() == 1
    #assert playbook_executor_0.run() == 0
    #assert playbook_executor_0.run() == 1
    #assert playbook_executor_0.run() == 0
    #assert playbook_executor_0.run() == 1
    #assert playbook_executor_0.run() == 0

# Unit test

# Generated at 2022-06-24 19:02:56.426268
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0.run() == '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '


# Generated at 2022-06-24 19:03:02.147900
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:03:40.273057
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Testing PlaybookExecutor...")
    test_case_0()
    print("PlaybookExecutor passed unit test.")


# Generated at 2022-06-24 19:03:44.390733
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print('[*] Testing PlaybookExecutor')
    print('**** Testing constructor of class PlaybookExecutor')
    test_case_0()

# Main function for unit testing

# Generated at 2022-06-24 19:03:51.961594
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run() # expected No exception


# Generated at 2022-06-24 19:03:55.960958
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:03:57.029064
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:04:07.644988
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    result = PlaybookExecutor('\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    ', '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    ', '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    ', '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    ', '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    ')


# Generated at 2022-06-24 19:04:14.105691
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        PlaybookExecutor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:04:20.467215
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    entrylist_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:04:23.817305
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    assert "Parameter 'playbooks' has no default value" in str(excinfo.value)
    

# Generated at 2022-06-24 19:04:25.559279
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:05:04.373305
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:05:08.634405
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as err:
        print("[FAIL]\ttest_PlaybookExecutor()\t->\t" + repr(err))
    else:
        print("[PASS]\ttest_PlaybookExecutor()")



# Generated at 2022-06-24 19:05:13.196859
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_0 = playbook_executor_0.run()
    assert result_0 < 2


# Generated at 2022-06-24 19:05:17.900886
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:19.811796
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:05:24.883118
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:05:33.160187
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    str_1 = 'pfq3Mw'
    str_2 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0.run(str_1, str_2)


# Generated at 2022-06-24 19:05:39.628882
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    entrylist_0 = playbook_executor_0.run()
    print(entrylist_0)

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:42.354508
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Output is supposed to be an int and it is
    result = test_case_0()
    assert type(result) == int, 'Return value is of type %s which is not of type int.' % type(result)

# Generated at 2022-06-24 19:05:48.119682
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print ("Test PlaybookExecutor.run() with low coverage")
    # TODO Done
    # TODO Done
    # TODO Done
    # TODO Done
    # TODO Done

    with patch('importlib.import_module', side_effect=mock_import_module) as mockImportModule:
        def mockAnsibleModule(*args, **kwargs):
            def mockJson(*args, **kwargs):
                return {'changed': True}

            def mockGetJson(*args, **kwargs):
                return {}

            def mockExitJson(*args, **kwargs):
                pass

            def mockFailJson(*args, **kwargs):
                pass

            module = Mock()
            module.jsonify = mockJson
            module.get_bin_path = mockGetJson
            module.exit_json

# Generated at 2022-06-24 19:06:30.803218
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:06:38.618603
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Input parameters
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    # Output parameters
    str_2 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_1 = PlaybookExecutor(str_2, str_2, str_2, str_2, str_2)


# Generated at 2022-06-24 19:06:40.551767
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:06:46.774178
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    #test_case_0()
    #print("function run of PlaybookExecutor called")
    #playbook_executor_0.run()
    return True


# Generated at 2022-06-24 19:06:50.627253
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '\n    [inventory_hostname_0]\n    [inventory_hostname_1]\n    [inventory_hostname_2]\n    '
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()
