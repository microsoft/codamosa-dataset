

# Generated at 2022-06-24 18:57:35.363121
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    bytes_0 = None
    dict_0 = {int_0: float_0, int_0: bool_0, float_0: float_0, bytes_0: int_0}
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, dict_0)
    test_case_0()

if __name__ == '__main__':
    try:
        test_PlaybookExecutor_run()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 18:57:44.054208
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible import context
    from ansible.plugins.loader import connection_loader, shell_loader, become_loader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.utils.boolean import boolean
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.utils.path import makedirs_safe
    from ansible.utils.ssh_functions import set_default_transport
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-24 18:57:54.705093
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1211.56641
    int_0 = 538
    bool_0 = False
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    dict_0 = {int_0: float_0, int_0: bool_0, float_0: float_0, bytes_0: int_0}
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, dict_0)
    result_0 = playbook_executor_0.run()
    assert result_0 is None

# Generated at 2022-06-24 18:58:03.165108
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    bytes_0 = None
    dict_0 = {int_0: float_0, int_0: bool_0, float_0: float_0, bytes_0: int_0}
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, dict_0)


# Generated at 2022-06-24 18:58:12.228291
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory_0 = {"all": {}, "children": [], "vars": {}}
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(loader_0, inventory_0)
    bytes_0 = None
    list_0 = [bytes_0]
    playbook_executor_0 = PlaybookExecutor(list_0, inventory_0, variable_manager_0, loader_0, bytes_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:13.910594
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float, int, bool, int, dict)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:20.016450
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    dict_0 = {int_0: int_0, int_0: bool_0, float_0: int_0, bool_0: bool_0}
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, dict_0)
    test_case_0()

if __name__ == '__main__':
    # simple fuzz test for PlaybookExecutor.run
    #test_PlaybookExecutor_run()
    
    test_case_0()

# Generated at 2022-06-24 18:58:22.046305
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()
    test_case_1()
    

# Generated at 2022-06-24 18:58:30.584172
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    bytes_0 = None
    dict_0 = {int_0: float_0, int_0: bool_0, float_0: float_0, bytes_0: int_0}
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, dict_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:31.808979
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:58:59.881262
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    assert playbook_executor_0.run() == 0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:59:06.596877
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = -1523.7654
    int_1 = -1248
    bool_0 = True
    bool_1 = False
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_1, bool_0, bool_0)
    playbook_executor_0.run()
    #pylint: disable=protected-access
    #print(playbook_executor_0._tqm)
    #print(playbook_executor_0._inventory)
    #print(playbook_executor_0._variable_manager)
    #print(playbook_executor_0._loader)
    #print(playbook_executor_0._loader.list_templates())
    #print(playbook_executor_0._loader.list_plugins('.py'))


# Generated at 2022-06-24 18:59:10.626161
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    result = playbook_executor_0.run()



# Generated at 2022-06-24 18:59:18.487634
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Generate random parameters
    playbooks_0 = random.randint(0, 9223372036854775807)
    inventory_0 = random.randint(0, 9223372036854775807)
    variable_manager_0 = random.randint(0, 9223372036854775807)
    loader_0 = random.randint(0, 9223372036854775807)
    passwords_0 = random.randint(0, 9223372036854775807)
    # Configure object
    playbook_executor_0 = PlaybookExecutor(playbooks_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    # Execute method
    result_0 = playbook_executor_0.run()
    assert result_0 is None

#

# Generated at 2022-06-24 18:59:27.085092
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Define variables for test_case_0
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

    # Call method run of class PlaybookExecutor
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:30.204545
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
    except Exception as err:
        #print(err)
        assert False
        #assert to_text(err) == ""

    #assert False


# Generated at 2022-06-24 18:59:38.778904
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    result_0 = playbook_executor_0.run()
    assert isinstance(result_0, list)
    assert isinstance(result_0[0], dict)
    assert 'plays' in result_0[0]
    assert 'playbook' in result_0[0]
    assert isinstance(result_0[0]['playbook'], str)
    assert '/home/vagrant/ansible/lib/ansible/playbooks/' in result_0[0]['playbook']
    assert isinstance(result_0[0]['plays'], list)


# Generated at 2022-06-24 18:59:45.413983
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == -1523.7654


# Generated at 2022-06-24 18:59:54.158327
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # start a timer and call the run method of class PlaybookExecutor
    start = time.clock()

# Generated at 2022-06-24 18:59:57.075206
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Run the given playbook, based on the settings in the play which may limit the runs to serialized groups, etc.
    '''
    # Test case for not implemented run method
    pass


# Generated at 2022-06-24 19:00:23.995013
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("")
    return


# Generated at 2022-06-24 19:00:28.281111
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0._PlaybookExecutor__generate_retry_inventory()
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:35.934726
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    int_0 = 0
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, bool_0, int_0, bool_0)
    result = playbook_executor_0.run()
    assert result is not None

    # test with an error

    # test with no args
    playbook_executor_1 = PlaybookExecutor()
    result = playbook_executor_1.run()
    assert result is not None


# Generated at 2022-06-24 19:00:41.722572
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    int_1 = playbook_executor_0.run()
    assert int_1==0


# Generated at 2022-06-24 19:00:43.433478
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:00:47.669931
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)


# Generated at 2022-06-24 19:00:55.138112
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)


# Generated at 2022-06-24 19:00:59.827567
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Arrange
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

    # Act
    result = playbook_executor_0.run()

    # Assert
    assert result == 0


# Generated at 2022-06-24 19:01:05.243390
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Testing PlaybookExecutor class constructor...")
    test_case_0()
    print("PlaybookExecutor class constructor test passed.")
    print("Testing PlaybookExecutor class methods...")
    print("PlaybookExecutor class methods test passed.")

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:09.149478
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(-1248.7654, -1248, False, -1248, False)
    playbook_executor_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:44.787274
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

    test_case_0()


# Generated at 2022-06-24 19:01:46.718650
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    result = playbook_executor_0.run()
    print(result)


# Generated at 2022-06-24 19:01:50.230777
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:54.530416
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)



# Generated at 2022-06-24 19:01:57.105018
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Test for __init__(self, playbooks, inventory, variable_manager, loader, passwords)
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

# Generated at 2022-06-24 19:02:05.218719
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = -1334
    float_0 = -1278.68
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    result = playbook_executor_0.run()

if __name__ == '__main__':

    start = time.time()

# Generated at 2022-06-24 19:02:11.971810
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)

    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:15.071189
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0.run()
    return playbook_executor_0


# Generated at 2022-06-24 19:02:21.179043
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = -1523.7654
    int_0 = -1248
    bool_0 = True
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, bool_0, int_0, bool_0)
    bool_0 = playbook_executor_0.run()
    assert bool_0 == bool.frozenset(['deleted', 'pending_deletion', 'running', 'rejected', 'error', 'terminated', 'stopping', 'stopped', 'failed'])


# Generated at 2022-06-24 19:02:24.045017
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:02:59.459930
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:03:07.850192
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:03:13.294007
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as err:
        print(err)

# __main__
if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:03:21.662869
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:03:28.797212
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = bytearray(1)
    bytes_0[0:1] = b'\xf7\xdf\xec\x1b\xef*\x0e\xef4\xbc\x05\x9f'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:32.066391
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)

    int_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:03:44.395826
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8e\xdd\x03\xf9\xe9\x8d\xa1\x14\n"\x11\xf8\x98\xce\xee\x83\r'
    bytes_1 = b'\x1e\x8e\x86\xf6\x98\x0b\xa8\x1d\xad\xdb\xcf\x0c\x17\x1c\x04\x19'
    set_0 = {bytes_0}
    set_1 = {bytes_1}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_1)
    assert_raises(Exception, playbook_executor_0.run)



# Generated at 2022-06-24 19:03:51.412651
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)
    assert callable(playbook_executor_0.run)
    result_0 = playbook_executor_0.run()
    assert result_0 is None



# Generated at 2022-06-24 19:03:59.236031
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Test A: construct PlaybookExecutor with valid args
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)

    # Test B: construct PlaybookExecutor with invalid args

# Generated at 2022-06-24 19:04:05.290873
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    set_0 = {bytes_0}
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, set_0, set_0)
    result_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:04:45.594170
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Intantiate a PlaybookExecutor object
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    # Call the method run of class PlaybookExecutor
    try:
        result = playbook_executor_0.run()
    except Exception as e:
        print('Error in executing PlaybookExecutor.run():')
        print(str(e))


# Generated at 2022-06-24 19:04:53.175294
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0


# Generated at 2022-06-24 19:04:55.557048
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# vim: syntax=python:set ts=4 sw=4 sts=4 et:

# Generated at 2022-06-24 19:05:01.233188
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = PlaybookExecutor.run(playbook_executor_0)
    # test the value of the result
    assert result is None


# Generated at 2022-06-24 19:05:05.662263
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    with raises(Exception):
        playbook_executor_0.run()


# Generated at 2022-06-24 19:05:13.839374
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = playbook_executor_0._get_serialized_batches(bytes_0)
    assert result[0][0] == b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'

# Generated at 2022-06-24 19:05:23.738085
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    with pytest.raises(AttributeError) as excinfo:
        bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
        playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
        retval = playbook_executor_0.run()
        # pylint raises warning that there is no unit test for this method.
        # pylint: disable=no-member
        assert not hasattr(playbook_executor_0, 'playbook_executor_run')
    excinfo.match(r"has no attribute 'playbook_executor_run'")

# Generated at 2022-06-24 19:05:32.803759
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    try:
        playbook_executor_0.run()
    except:
        pass


if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:33.493745
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:05:36.094015
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Test python code of constructor of class PlaybookExecutor
    assert True == True

# Unit tests for PlaybookExecutor.run

# Generated at 2022-06-24 19:06:22.352580
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = playbook_executor_0.run()


# Generated at 2022-06-24 19:06:23.074257
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test for run method
    pass


# Generated at 2022-06-24 19:06:30.214137
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = playbook_executor_0.run()
    assert result == 0

if __name__=='__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:35.399446
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0.run( ) == 0

# Generated at 2022-06-24 19:06:41.766973
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    playbook_executor_1.run()

    #assert 1 == 1, "Test Failed"


# Generated at 2022-06-24 19:06:46.813905
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xb3\x16\\\xb7\xae\xa5\xb1\xe54d\xf6j\xb0\xd0\xa1ep'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    int_0 = playbook_executor_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 19:06:49.911843
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 0



# Generated at 2022-06-24 19:06:55.284270
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x17\x85\xde\x81\x97\xafP\x9a\x1a\xdd\xa8\x99\xf1\xea\xc4\xa23\x8e\xaa\xd4\xef\xee\x1b\xba\xc5\xdb\n\x95\x03\xec\x89\x05\xd8'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    # begin test code
    playbook_executor_0.run()
    # end test code
    #assert result == expected, "Expected different result value."


if __name__ in ('main', '__main__'):
    test_Playbook