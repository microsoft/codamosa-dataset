

# Generated at 2022-06-24 18:57:26.926356
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()



# Generated at 2022-06-24 18:57:37.335274
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/home/aaron/'
    str_1 = 'Inventory'
    str_2 = 'site.yml'
    str_3 = 'vars_prompt'
    str_4 = 'create_failure_file'
    str_5 = 'name'
    str_6 = 'default_collection'
    str_7 = 'name'
    str_8 = 'failed_host_string'
    str_9 = 'task_ok'
    str_10 = 'name'
    str_11 = 'task_start.name'
    str_12 = 'name'
    str_13 = 'name'
    str_14 = 'task_path'
    str_15 = 'executor_config'
    str_16 = 'id'
    str_17 = 'task_executor'


# Generated at 2022-06-24 18:57:41.637734
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 18:57:45.023249
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
	test_case_0()

# main program
if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:57:46.237336
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:57:51.534267
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_0 = 'YE3fu\t.'
        int_0 = 1283
        list_0 = [str_0]
        playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
        playbook_executor_0.run()
    except:
        pass


# Generated at 2022-06-24 18:57:56.530720
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'i'
    int_0 = -914
    list_0 = [str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)

    # Invoke method
    output = playbook_executor_0.run()
    print('output: %s' % output)


# Generated at 2022-06-24 18:57:57.872999
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test case data
    run_data = []
    assert run_data == []


# Generated at 2022-06-24 18:58:03.557950
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'YE3fu\t.'
    int_0 = 1283
    list_0 = [str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
    assert playbook_executor_0._playbooks == str_0, "_playbooks"
    assert playbook_executor_0._inventory == str_0, "_inventory"
    assert playbook_executor_0._variable_manager == int_0, "_variable_manager"
    assert playbook_executor_0._loader == list_0, "_loader"
    assert playbook_executor_0.passwords == list_0, "passwords"
    assert playbook_executor_0._tqm == None, "_tqm"
    assert playbook_executor_0._

# Generated at 2022-06-24 18:58:07.357480
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:40.330552
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Case 0
    test_case_0()


# Generated at 2022-06-24 18:58:41.064350
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:58:47.642343
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    # test that the function throws an AssertionError when it is passed an incorrect param
    with pytest.raises(AssertionError):
        playbook_executor_0.run()


# Generated at 2022-06-24 18:58:51.351400
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'rL'
    int_0 = 880
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result_0 = playbook_executor_0.run()


# Generated at 2022-06-24 18:58:55.615077
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '3A'
    int_0 = 4496
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    try:
        result = playbook_executor_0.run()
    except Exception  as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:58.510807
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str(), str(), int(), str(), str())
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:03.020340
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()
    print("Test completed successfully!")

# Generated at 2022-06-24 18:59:06.955029
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('YE3#u\t.', 'YE3#u\t.', 1320, 'YE3#u\t.', 'YE3#u\t.')
    playbook_executor_0.run()


if __name__ == '__main__':
    cases = [0]

    for case in cases:
        if case == 0:
            test_case_0()
        elif case == 1:
            test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:08.101007
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:13.552210
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('', '', 0, '', '')
    assert playbook_executor_0._get_serialized_batches('') == []
    assert playbook_executor_0._generate_retry_inventory('', []) == True
    assert playbook_executor_0.run() is None

# Generated at 2022-06-24 18:59:48.376671
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = ';6O*'
    int_0 = 1293
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    playbook_executor_0.run()

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:52.821246
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result = playbook_executor_0.run()
    print(result)

tracer = Trace()
tracer.runfunc(test_PlaybookExecutor_run)

# Generated at 2022-06-24 18:59:57.397115
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    try:
        playbook_executor_0.run()
    except Exception as e:
        display.warning("Could not create retry file '%s'.\n\t%s" % (retry_path, to_text(e)))
        return False
    return


# Generated at 2022-06-24 19:00:01.705768
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:00:10.496480
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:00:15.847071
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('Ye.\t,', '4G6f', 459, 'Z,i=', '0hS.')
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:20.659223
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result = playbook_executor_0.run()
    print(to_text(result))


# Generated at 2022-06-24 19:00:29.580338
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert(not isinstance(playbook_executor_0, PlaybookExecutor))
    assert(playbook_executor_0.__init__.__doc__ == None)
    assert(playbook_executor_0.__dict__ != {})
    assert(playbook_executor_0.__module__ == 'ansible.executor.playbook_executor')


# Generated at 2022-06-24 19:00:37.502456
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'ye3\t.'
    int_0 = 72
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result = playbook_executor_0.run()

# Testing the method run of class PlaybookExecutor
# run()
test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:41.824587
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'yP}XiwvD8W'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert isinstance(playbook_executor_0.run(), int)


# Generated at 2022-06-24 19:01:16.195435
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:01:20.867746
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:01:26.429500
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    playbook_executor_0.run()
    playbook_executor_0.run()

# Generated at 2022-06-24 19:01:27.839283
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    test_case_0()


# Generated at 2022-06-24 19:01:32.380044
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    if __name__ == '__main__':
        profile.run('playbook_executor_0.run()')
    else:
        playbook_executor_0.run()


# Generated at 2022-06-24 19:01:34.273941
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(None, None, None, None, None)
    playbook_executor_0.run()



# Generated at 2022-06-24 19:01:37.972154
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = 'YE3#u\t.'
    int_1 = 1320
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, int_1, str_1, str_1)
    result_1 = playbook_executor_1.run()
    assert result_1 == 0

if __name__ == "__main__":
    test_PlaybookExecutor_run()
    test_case_0()

# Generated at 2022-06-24 19:01:46.770256
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    for i in range(4):
        # try:
            # str_0 = 'YE3#u\t.'
            # str_0 = 'YE3#u\t.'
            # int_0 = 1320
            # str_0 = 'YE3#u\t.'
            # str_0 = 'YE3#u\t.'
            # playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
            # playbook_executor_0.run()
            # break
        # except BaseException as e:
        #     print()
        #     print(e)
        #     print(playbook_executor_0)
        pass

test_case_0()
#test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:47.665327
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()



# Generated at 2022-06-24 19:01:52.337739
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Input paramaters valid
    str_0 = 'YE3#u\t.'
    int_0 = 1320
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result_0 = playboo

# Generated at 2022-06-24 19:02:24.580337
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = None
    with pytest.raises(TypeError):
        test_case_0()
# vim: set et sts=4 sw=4 ts=4 :

# Generated at 2022-06-24 19:02:36.195441
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)

    assert var_0 == var_0
    assert var_0 == var_0
    assert isinstance(playbook_executor_0, PlaybookExecutor)
    assert isinstance(playbook_executor_0, PlaybookExecutor)
    assert isinstance(playbook_executor_0, object)
    assert isinstance(playbook_executor_0, object)
    assert isinstance(playbook_executor_0, object)
    assert isinstance(playbook_executor_0, object)
    assert isinstance(playbook_executor_0, object)
    assert isinstance(playbook_executor_0, object)
    assert isinstance

# Generated at 2022-06-24 19:02:40.032281
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(None, None, None, None, None)
    try:
        playbook_executor_0.run()
    except (ValueError) as exc:
        assert str(exc) == "PlaybookExecutor object must have a playbook"


# Generated at 2022-06-24 19:02:43.876048
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = playbook_executor_0.run()
    print(var_1)

# Generated at 2022-06-24 19:02:48.454216
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = [random.choice('abc')]
    var_2 = InventoryManager(var_1)
    var_3 = VariableManager(var_1, var_2)
    var_4 = DataLoader()
    var_5 = {random.choice('abc'): random.choice(['a', 'b', 'c'])}
    playbook_executor_0 = PlaybookExecutor(var_1, var_2, var_3, var_4, var_5)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:52.518853
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = test_case_0()
    assert playbook_executor_0 == var_1


# Generated at 2022-06-24 19:02:57.032924
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("testing run of PlaybookExecutor")
    test_case_0()


# Generated at 2022-06-24 19:02:58.256672
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:03:00.176819
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    assert playbook_executor_0.run() is None


# Generated at 2022-06-24 19:03:06.749853
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print('Unit test for constructor of class PlaybookExecutor')
    # Create empty object of class PlaybookExecutor
    try:
        test_case_0()
    except NotImplementedError as e:
        print('NotImplementedError:', e)
    except Exception as e:
        print('An exception occurred:', e)



# Generated at 2022-06-24 19:03:41.112417
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except NameError:
        print("fail")


# Generated at 2022-06-24 19:03:52.007845
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_0 = None
    test_case_0()
    test_case_0()
    test_case_0()
    var_0 = playbook_executor_0.run()
    print(var_0)
    assert var_0 == 0
    return

# Generated at 2022-06-24 19:03:54.093747
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(None, None, None, None, None)


test_case_0()
test_PlaybookExecutor()

# Generated at 2022-06-24 19:03:58.351425
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    try:
        playbook_executor_0.run()
    except SystemExit:
        expectedException()


# Generated at 2022-06-24 19:04:08.671889
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Instance of class PlaybookExecutor for testing
    playbook_executor_0 = PlaybookExecutor(None, None, None, None, None)
    # Declaring variables

# Generated at 2022-06-24 19:04:16.437697
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = load_inventory()
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}
    
    playbooks = ['test.yml']
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    #var_0 = inventory
    #var_1 = variable_manager
    #var_2 = loader
    #var_3 = passwords
    #var_4 = playbooks
    #playbook_executor = PlaybookExecutor(var_4, var_0, var_1, var_2, var_3)
    result = playbook_executor.run()

# Generated at 2022-06-24 19:04:21.962099
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Run a playbook and return the stats (number of plays run,
    # number of tasks run, number of failed tasks, etc.)
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:04:27.803884
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_1 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = 824
    # Run the method
    playbook_executor_1.run()

# Generated at 2022-06-24 19:04:33.569977
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None

    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    val1 = playbook_executor_0.run()
    if val1 == 0:
        print("Success")
    else:
        print("Failure")


# Generated at 2022-06-24 19:04:37.145473
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = playbook_executor_0.run()
    print(var_1)



# Generated at 2022-06-24 19:05:41.830241
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print('Running test_PlaybookExecutor_run')
    test_case_0()


if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:45.635425
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    playbook_executor_1 = PlaybookExecutor(var_1, var_2, var_3, var_4, var_5)
    assert playbook_executor_1.run() == None


# Generated at 2022-06-24 19:05:49.890844
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    playbook_executor_1 = PlaybookExecutor(var_1, var_2, var_3, var_4, var_5)
    assert playbook_executor_1.run() == 0

# Generated at 2022-06-24 19:05:54.506106
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = None
    playbook_executor_1 = PlaybookExecutor(var_1, var_1, var_1, var_1, var_1)
    result_0 = playbook_executor_1.run()
    assert (result_0 == 0)


# Generated at 2022-06-24 19:05:58.168365
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    playbook_executor_0.run(var_1)


# Generated at 2022-06-24 19:06:02.603327
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    var_0 = None
    playbook_executor_0 = PlaybookExecutor(var_0, var_0, var_0, var_0, var_0)
    class_name = str(type(playbook_executor_0))
    assert(class_name == "<class 'ansible.executor.playbook_executor.PlaybookExecutor'>")

# Generated at 2022-06-24 19:06:05.459453
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0.run()


if __name__ == '__main__':

    # Run unit tests
    # test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:13.539514
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    test_PlaybookExecutor_0 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    test_PlaybookExecutor_1 = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    assert test_PlaybookExecutor_0._playbooks is None
    assert test_PlaybookExecutor_0._inventory is None
    assert test_PlaybookExecutor_0._variable_manager is None
    assert test_PlaybookExecutor_0._loader is None
    assert test_PlaybookExecutor_0.passwords is None
    assert test_PlaybookExecutor_0._unreach

# Generated at 2022-06-24 19:06:27.030796
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = None
    playbook_executor_1 = PlaybookExecutor(var_1, var_1, var_1, var_1, var_1)
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24

# Generated at 2022-06-24 19:06:30.621058
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = PlaybookExecutor(None, None, None, None, None)
    assert var_0.run() == 0