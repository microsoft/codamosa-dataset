

# Generated at 2022-06-24 18:57:33.802494
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    tuple_0 = ()
    int_2 = -6645
    float_1 = -5813.366935
    float_0 = 9471.423902
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_2, int_2, float_1, tuple_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:36.199465
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(tuple(), int(), int(), float(), tuple())
    assert None is playbook_executor_0.run()


# Generated at 2022-06-24 18:57:44.531402
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    string_0 = "*"
    map_0 = {}
    list_0 = []
    tuple_0 = ()
    var__0 = -5422
    string_1 = "8"
    list_1 = [
        {
            "F": "7",
            "T": 0,
            "vars": {},
            "hosts": list_0,
            "roles": tuple_0,
            "tasks": list_0,
            "gather_facts": ".",
            "_hosts": tuple_0,
            "_name": "m",
            "_parent": "f",
            "_play_name": "u",
            "_loader": list_0,
            "_tasks": list_0
        }
    ]
    int_0 = -5197

# Generated at 2022-06-24 18:57:49.279041
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    tuple_0 = ()
    int_0 = 7135
    float_0 = 3176.49612
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)
    #
    with pytest.raises(TypeError):
        playbook_executor_0.run()


# Generated at 2022-06-24 18:57:55.199695
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    tuple_0 = ()
    int_0 = 7135
    float_0 = 3176.49612
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)
    int_1 = playbook_executor_0.run()
    assert int_1 == 0

# Generated at 2022-06-24 18:58:01.246178
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    tuple_0 = ()
    int_0 = 811
    float_0 = 1586.734405
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)


# Generated at 2022-06-24 18:58:03.579411
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    tuple_0 = ()
    int_0 = 8389
    float_0 = 28.1067
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:58:06.642293
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 18:58:12.586169
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Arrange
    tuple_0 = ()
    int_0 = 7135
    float_0 = 3176.49612
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)

    # Act
    result_0 = playbook_executor_0.run()

    # Assert
    assert result_0 == None


# Generated at 2022-06-24 18:58:20.070407
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    tuple_0 = ()
    int_0 = 7135
    float_0 = 3176.49612
    playbook_executor_0 = PlaybookExecutor(tuple_0, int_0, int_0, float_0, tuple_0)

    assert isinstance(playbook_executor_0, PlaybookExecutor)
    assert playbook_executor_0._playbooks == ()
    assert playbook_executor_0._inventory == 7135
    assert playbook_executor_0._variable_manager == 7135
    assert playbook_executor_0._loader == 3176.49612
    assert playbook_executor_0.passwords == ()
    assert playbook_executor_0._unreachable_hosts == {}

    assert playbook_executor_0._tqm is None



# Generated at 2022-06-24 18:58:48.213666
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 8389
    float_0 = 28.1067
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, int_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:51.147432
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:58:52.654974
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:58.542423
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, int_0, float_0, float_0)
    result = playbook_executor_0.run()
    assert result == False


# Generated at 2022-06-24 18:59:05.174551
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0._variable_manager = VariableManager()

    playbook_executor_0._loader = DataLoader()
    playbook_executor_0._playbooks = ["playbook_executor"]

    Inventory(playbook_executor_0._loader, playbook_executor_0._variable_manager, playbook_executor_0._playbooks)
    playbook_executor_0._inventory = Inventory(playbook_executor_0._loader, playbook_executor_0._variable_manager, playbook_executor_0._playbooks)



    context.CLIARGS['listhosts'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['listtags'] = False

# Generated at 2022-06-24 18:59:11.246514
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, int_0, int_0, float_0, float_0)
    assert type(playbook_executor_0) == PlaybookExecutor
    playbook_executor_1 = PlaybookExecutor(float_0, int_0, int_0, float_0, float_0)
    assert type(playbook_executor_1) == PlaybookExecutor
    int_0 = 8389
    float_0 = 28.1067
    playbook_executor_2 = PlaybookExecutor(float_0, int_0, int_0, float_0, float_0)
    assert type(playbook_executor_2) == PlaybookExecutor
    int_0 = 8389
    float_0 = 28.1067
    playbook_executor_3

# Generated at 2022-06-24 18:59:13.737104
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:16.710806
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO: Implement unit test for method run, which is the entry point for this class
    playbook_executor_0 = PlaybookExecutor(0, 0, 0, 0, 0)
    playbook_executor_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:59:17.381747
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:59:23.755137
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(1.9870221437097725e+308, 1.9870221437097725e+308, 1.9870221437097725e+308, 1.9870221437097725e+308, 1.9870221437097725e+308)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:59.718099
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Define mock objects and method mocks
    float_0 = 1e309
    pb = Playbook.load(float_0, variable_manager=float_0, loader=float_0)
    mock_pb = MagicMock()
    mock_pb.get_plays.return_value = pb
    mock_play = MagicMock()

    # Instantiate mock class
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_0._loader = mock_loader
    playbook_executor_0._tqm = mock_tqm
    playbook_executor_0._tqm.send_callback = mock_send_callback

# Generated at 2022-06-24 19:00:02.209273
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:00:08.070009
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # We know that this test case should check the following conditions:
    # 1. playbook_executor_0.run() == 0

    # In this test case we don't need to check the correctness of the run results
    # because we assume that the evaluation of the run results is already checked
    # in the previous test cases.
    # We only need to check that we can run the run function here.

    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:12.097826
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)


# Generated at 2022-06-24 19:00:22.119756
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Arrange
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)

    # Act
    # Return type is a dictionary
    result_dictionary = playbook_executor_0.run()

    # Assert
    assert type(result_dictionary) is list
    assert len(result_dictionary) == 0


if __name__ == "__main__":

    # Running tests on certain methods

    print("\nTesting method run of class PlaybookExecutor")
    test_PlaybookExecutor_run()
    print("\nDone testing method run of class PlaybookExecutor")

# Generated at 2022-06-24 19:00:25.201590
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    # assert playbook_executor_0.run()
    pass


# Generated at 2022-06-24 19:00:37.447144
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 0.4538852511989868
    float_1 = 3.3935222787755886
    float_2 = 2e-06
    float_3 = 4.078034802034214
    float_4 = 7.302385074649718
    float_5 = 5.329595297326985
    float_6 = 2.918976937373873
    float_7 = 2.8175376794702037
    float_8 = 1.9894813731532826
    float_9 = 3.848818953586779
    float_10 = 1.973529238841368
    float_11 = 4.833727859734066
    float_12 = 7.271093501061113
    float_13 = 8

# Generated at 2022-06-24 19:00:44.789095
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)


# Generated at 2022-06-24 19:00:47.637398
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float(), float(), float(), float(), float())
    assert playbook_executor_0.run() == 0



# Generated at 2022-06-24 19:00:54.425590
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    assert playbook_executor_1.run() == True


# Generated at 2022-06-24 19:01:23.228756
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    ret_val_0 = playbook_executor_0.run()
    print(ret_val_0)


# Generated at 2022-06-24 19:01:26.146349
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:29.629386
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 1


# Generated at 2022-06-24 19:01:32.220392
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:38.740027
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # create file which serves as inventory
    tmp_file_prefix = tempfile.mktemp()
    tmp_file_name = tmp_file_prefix + ".conf"
    with open(tmp_file_name, "w") as f:
        f.write("dummyhost\n")

# Generated at 2022-06-24 19:01:45.572665
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    ansible_cfg = r'./ansible.cfg'
    inventory = r'./hosts'
    playbook = r'./playbooks/test.yaml'
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'webservers'}
    playbooks = [playbook]
    pd = PlaybookExecutor(playbooks, inventory, variable_manager, loader, None)
    pd.run()


# Generated at 2022-06-24 19:01:48.594859
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_, float_, float_, float_, float_)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:00.852024
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    import tempfile

    # set up a simple test playbook to use in the test
    TEMP_PLAYBOOK = tempfile.NamedTemporaryFile(mode='w', suffix='.yml')
    TEMP_PLAYBOOK.write("""
- hosts: all
  tasks:
  - name: task 1
    ping:
    - name: task 2
      ping:
    - name: task 3
      ping:
    - name: task 4
      ping:
""")
    TEMP_PLAYBOOK.seek(0)

    # test that the run method of a playbook executor
    # returns zero when the playbook executes successfully

# Generated at 2022-06-24 19:02:09.269547
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    args = [
            #   host_list,       playbook_path,      password
            (["host1", "host2"], "/home/ansible/test.yml", "password"),
            (["host1", "host2"], "/home/ansible/test.yml", "password"),
            (["host1", "host2"], "/home/ansible/test.yml", None),
            ]
    for host_list, playbook_path, password in args:
        inventory_source, host_list = host_list, playbook_path, password
        # ansible.utils.display.Display.verbosity = 2
        # ansible.cli.CLI.options = {'listhosts': False, 'listtasks': False, 'listtags': False, 'syntax': True, 'connection': 'smart', 'module_path': None,

# Generated at 2022-06-24 19:02:15.494907
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    entrylist_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:02:43.401644
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_5 = 1e309
    playbook_executor_5 = PlaybookExecutor(float_5, float_5, float_5, float_5, float_5)
    result = playbook_executor_5.run()
    assert True


# Generated at 2022-06-24 19:02:46.725728
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_0 = PlaybookExecutor(2.718281828459045, 3.141592653589793, 1.4142135623730951, 1.4142135623730951, 1.4142135623730951)

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:51.378349
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # testing for constructor of class PlaybookExecutor
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:56.236261
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    result = playbook_executor_0.run()

if __name__ == '__main__':
    # Unit test for PlaybookExecutor class
    test_PlaybookExecutor_run()
    # Unit test for run of method test_case_0
    test_case_0()

# Generated at 2022-06-24 19:03:00.061919
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result = playbook_executor_0.run()
    print("test_PlaybookExecutor_run: ", result)

# Generated at 2022-06-24 19:03:01.454694
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Valid test cases
    test_case_0()
    # Invalid test cases

# Generated at 2022-06-24 19:03:06.172910
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        print(f"Failed to run test_case_0: {str(e)}")
        raise e


if __name__ == '__main__':
    import sys
    sys.exit(main())

# Generated at 2022-06-24 19:03:08.999484
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result = playbook_executor_0.run()


# Generated at 2022-06-24 19:03:10.290020
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:17.764243
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result = playbook_executor_0.run()
    print(result)
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:45.424429
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)

    assert(playbook_executor_0.run() == 0)


# Generated at 2022-06-24 19:03:55.542221
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    # PlaybookExecutor.run(playbooks=[], inventory=None, variable_manager=None, loader=None, passwords=None)
    assert playbook_executor_0.run() == float_0


test_case_test_PlaybookExecutor_run = 0
try:
    test_case_test_PlaybookExecutor_run = test_PlaybookExecutor_run()
    test_case_test_PlaybookExecutor_run = 1
except Exception as e:
    print("exception at 'test_PlaybookExecutor_run' of PlaybookExecutor.py", str(e))


# Generated at 2022-06-24 19:03:57.746854
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor
    result = playbook_executor_0.run()
    assert result == None


# Generated at 2022-06-24 19:04:00.764071
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(0.0, 0.0, 0.0, 0.0, 0.0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:04:08.509962
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    # Uncomment and implement as necessary.
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler import Handler
    """
    pass


# Generated at 2022-06-24 19:04:11.286363
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create object of class PlaybookExecutor
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)

# Generated at 2022-06-24 19:04:16.792683
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks_0 = ['/etc/ansible/ansible.cfg', '/etc/ansible/ansible.cfg', '/etc/ansible/ansible.cfg']
    inventory_0 = dict()
    variable_manager_0 = dict()
    loader_0 = dict()
    passwords_0 = dict()
    playbook_executor_0 = PlaybookExecutor(playbooks_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor()
# TEST: /usr/local/lib/python2.7/dist-packages/ansible/playbook/__init__.py::test_case_0
# Python 2.7.15 (default,

# Generated at 2022-06-24 19:04:25.963500
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    class Args(object):
        pass

    # Setup
    context.CLIARGS = Args()
    context.CLIARGS.start_at_task = None
    context.CLIARGS.listhosts = False
    context.CLIARGS.listtasks = False
    context.CLIARGS.listtags = False
    context.CLIARGS.syntax = False
    context.CLIARGS.tags = []
    context.CLIARGS.skip_tags = []
    context.CLIARGS.forks = 1
    context.CLIARGS.diff = False
    context.CLIARGS.start_at_task = None
    context.CLIARGS.step = None
    context.CLIARGS.force_handlers = False

# Generated at 2022-06-24 19:04:30.668905
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_path = "test1.yaml"
    variable_manager = VariableManager([], inventory=None)
    loader = DataLoader()
    passwords = dict()
    playbook_executor_0 = PlaybookExecutor(playbook_path, variable_manager, loader, passwords)

    # test with no parameters
    try:
        playbook_executor_0.run()
    except TypeError:
        pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:04:34.747760
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_2 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    assert isinstance(playbook_executor_2.run(), int)


# Generated at 2022-06-24 19:05:01.563057
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        assert(False)
    else:
        assert(True)

# test case to test _get_serialized_batches method of PlaybookExecutor

# Generated at 2022-06-24 19:05:05.337111
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    log.info("test_PlaybookExecutor")
    try:
        test_case_0()
        log.info("Passed test_PlaybookExecutor")
    except Exception as err:
        log.error(to_text(err))
        log.error("Failed test_PlaybookExecutor")
        raise ValueError('test_PlaybookExecutor')

# Generated at 2022-06-24 19:05:12.238425
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = "plugin/inventory/ec2.yml"
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    inventory_0 = Inventory(loader_0, variable_manager_0)
    playbook_executor_1 = PlaybookExecutor(playbook, inventory_0, variable_manager_0, loader_0, None)
    try:
        playbook_executor_1.run()
    except AnsibleConnectionFailure as error_0:
        print(error_0.message)
    except AnsibleOptionsError as error_1:
        print(error_1.message)



if test_case_0():
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:17.473282
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("test method PlaybookExecutor.run()")
    
    # Arrange
    
    # Pre-Arrange
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    
    # Act
    result = playbook_executor_0.run()
    
    # Assert
    assert result == 0


# Generated at 2022-06-24 19:05:21.416686
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    assert playbook_executor_0.run() == 0

# Generated at 2022-06-24 19:05:31.532495
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    serialized_batches_1 = []
    play_0 = {}
    serial_batch_list_0 = []
    cur_item_0 = 0
    serial_batch_list_0 = []
    for x_0 in serial_batch_list_0:
        play_0 = 'futile_loop'
        float_0 = 1.3424905e308
        play_0 = r'ansible-playbook   -i hosts  test.yaml -vvvv'
        serial_batch_list_0 = []
        play_1 = 'futile_loop'
        play_1 = 'futile_loop'

# Generated at 2022-06-24 19:05:35.196594
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:39.182189
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result = playbook_executor_0.run()
    print(result)


# Generated at 2022-06-24 19:05:43.988549
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    # Assert the return value of the method run
    assert playbook_executor_0.run() == 0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:47.064027
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        import unittest
        p = unittest.TestProgram()
        p.test_case_0()
    except Exception as e:
        pass

# Generated at 2022-06-24 19:06:20.548137
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
        print('SUCCESS')
    except:
        print('FAILED')

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:30.585577
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    # Code coverage for branch 'if self._tqm is not None: play.post_validate(templar)'
    # The method is called without required args
    result = playbook_executor_0.run()
    assert (result == 0) == True
    assert (result == 1) == False
    assert (result == 2) == False
    assert (result == 3) == False
    assert (result == 4) == False
    assert (result == 5) == False
    assert (result == 6) == False

# Generated at 2022-06-24 19:06:32.861344
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test __init__")
    test_case_0()


# Generated at 2022-06-24 19:06:45.531500
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_1 = PlaybookExecutor(str_0, int_0, str_1, str_2, int_1)
    playbook_executor_2 = PlaybookExecutor(str_3, int_2, str_4, str_5, int_3)
    playbook_executor_3 = PlaybookExecutor(str_6, int_4, str_7, str_8, int_5)
    playbook_executor_4 = PlaybookExecutor(str_9, int_6, str_10, str_11, int_7)

# Generated at 2022-06-24 19:06:48.849629
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    playbook_executor_0.run()

# Test for class PlaybookExecutor

# Generated at 2022-06-24 19:06:51.646224
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1e309
    playbook_executor_0 = PlaybookExecutor(float_0, float_0, float_0, float_0, float_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:06:53.557409
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(1e309, 1e309, 1e309, 1e309, 1e309)
    playbook_executor_0.run()
