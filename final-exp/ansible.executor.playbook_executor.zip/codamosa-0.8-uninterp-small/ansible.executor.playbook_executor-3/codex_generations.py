

# Generated at 2022-06-24 18:57:41.384314
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('', '', 0, [], [])
    res = playbook_executor_0.run()
    assert res is None

# Generated at 2022-06-24 18:57:47.951005
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 2594
    list_0 = [str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
    assert not playbook_executor_0.run()


# Generated at 2022-06-24 18:57:50.708804
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print(PlaybookExecutor.__doc__)
    try:
        test_case_0()
    except Exception as err:
        print(err)

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:57:57.093948
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 2594
    list_0 = [str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
    result = playbook_executor_0.run()
    assert result is None

test_PlaybookExecutor_run()
test_case_0()

# Generated at 2022-06-24 18:58:05.677315
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    list_int_0 = [int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0), int(0)]
    playbook

# Generated at 2022-06-24 18:58:10.853842
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_1 = 1656
    list_1 = [str_1, str_1]
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, int_1, list_1, list_1)
    result = playbook_executor_1.run()
    assert isinstance(result, list)
    assert result == []


# Generated at 2022-06-24 18:58:15.345056
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 10
    list_0 = [str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
    runner = Runner()
    t = runner.load_task_plugins('./lib/ansible/plugins/tasks')
    print(dir(t))
    print(playbook_executor_0.run())


# Generated at 2022-06-24 18:58:20.199023
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = str(123)
    playbooks = str(123)
    loader = list(str(123))
    variable_manager = int(123)
    passwords = list(str(123))
    playbook_executor_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    result = playbook_executor_0.run()
    assert type(result) == int


# Generated at 2022-06-24 18:58:30.296702
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 2594
    list_0 = [str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, list_0, list_0)
    value_0 = str_0
    value_1 = [int_0, int_0]
    value_2 = str_0
    value_3 = str_0
    value_4 = [int_0, int_0, int_0]
    value_5 = int_0
    value_6 = list_0
    value_7 = list_0
    value_8 = [list_0, list_0, list_0]
    value_9 = list_0
    value_10

# Generated at 2022-06-24 18:58:36.279689
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '@'
    str_1 = 'U_'
    str_2 = '9'
    int_0 = 7
    list_0 = [str_0, str_1, str_2]
    int_1 = 1
    dict_0 = {'d': list_0, 'a': int_0, 'b': list_0, 'c': list_0, 'f': str_2, 'e': list_0}

    # Verify if the following lines are printed.
    str_3 = 'playbook_executor_0.run'
    str_4 = 'playbook_executor_0.run'
    str_5 = 'playbook_executor_0.run'
    str_6 = 'playbook_executor_0.run'

# Generated at 2022-06-24 18:59:08.476810
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 1656
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    result_0 = playbook_executor_0.run()
    print('result_0 = ', result_0)
    print('type(result_0) = ', type(result_0))


# Generated at 2022-06-24 18:59:13.453968
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    int_0 = playbook_executor_0.run()
    assert int_0 == 0

# Generated at 2022-06-24 18:59:23.235364
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 1656
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    len_0 = len(str_0)
    str_1 = str_0 + '{action}: AnsibleConnectionFailure caught and handled: {error}'
    str_2 = str_1 + '{action}: AnsibleConnectionFailure caught and handled: {error}'
    str_3 = str_0 + '{action}: AnsibleConnectionFailure caught and handled: {error}'
    str_4 = str_1 + '{action}: AnsibleConnectionFailure caught and handled: {error}'

# Generated at 2022-06-24 18:59:26.962503
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    playbook_executor = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    playbook_executor.run()

# Generated at 2022-06-24 18:59:30.243028
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()
    ans = PlaybookExecutor(str, str, int, str, str)
    assert ans.passwords == 'test_ans.passwords'
    assert ans.run() is None


# Generated at 2022-06-24 18:59:37.771568
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create instance of class with parameters
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    # Invoke method
    result = playbook_executor_0.run()
    # Check result
    assert result is None

test_cases = [
    test_case_0,
]
test_set = [
    {
        "setup" : test_PlaybookExecutor_run,
        "test"  : test_PlaybookExecutor_run,
        "teardown" : test_PlaybookExecutor_run,
        "number" : "0"
    }
]

# Generated at 2022-06-24 18:59:47.202459
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 1431
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert(playbook_executor_0.run() == 0)

test_case_0()


# test code for method _get_serialized_batches of class PlaybookExecutor

# Generated at 2022-06-24 18:59:49.654939
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught and handled: {error}'
    int_0 = 1656
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, int_0, str_0, str_0)
    assert(playbook_executor_0.run() is None)

# Generated at 2022-06-24 18:59:50.859329
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str, str, int, str, str)
    playbook_executor_0.run()

# Generated at 2022-06-24 18:59:56.157807
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    #This is to test the case of a directory or file not being present
    playbook_executor_0 = PlaybookExecutor('~/ansible_dir', 'inventory', 1000, 'ansible_loader', '~/ansible_passwords')
    playbook_executor_0.run()

    #This is to test the case where the file is present
    playbook_executor_0 = PlaybookExecutor('ansible_dir', 'inventory', 1000, 'ansible_loader', '~/ansible_passwords')
    playbook_executor_0.run()

    #This is to test the case of a directory or file not being present
    playbook_executor_0 = PlaybookExecutor('~/ansible_dir', 'inventory', 1000, 'ansible_loader', '~/ansible_passwords')

# Generated at 2022-06-24 19:00:33.934635
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:00:38.429629
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    int_0 = playbook_executor_0.run()
    print(int_0)


# Generated at 2022-06-24 19:00:43.971068
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        int_0 = playbook_executor_0.run()
    except AnsibleError:
        print('AnsibleError')
    except KeyError:
        print('KeyError')

# Generated at 2022-06-24 19:00:47.474844
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        test_case_0()
        return True
    except Exception as e:
        display.error(e)
        display.display(traceback.format_exc())
        return False

# Generated at 2022-06-24 19:00:58.489353
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_

# Generated at 2022-06-24 19:01:03.309701
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '{action}: AnsibleConnectionFailure caught ynd handled: {error}'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:12.110620
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'ansible-playbook foo_playbook_0.yaml'
    list_0 = ['foo_playbook_0.yaml']
    str_1 = 'foo_playbook_0.yaml'
    str_2 = 'foo_playbook_0.yaml'
    str_3 = 'foo_playbook_0.yaml'
    dict_0 = {'foo_0':0}
    str_4 = 'foo_playbook_0.yaml'
    str_5 = 'foo_playbook_0.yaml'
    str_6 = 'foo_playbook_0.yaml'
    str_7 = 'foo_playbook_0.yaml'
    str_8 = 'foo_playbook_0.yaml'

# Generated at 2022-06-24 19:01:13.229176
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:01:18.388589
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor([], None, None, None, '{') # Should fail during initialization
    with pytest.raises(UnboundLocalError):
        playbook_executor_0.run()

    #playbook_executor_0 = PlaybookExecutor([], None, None, None, '') # Should fail during assignment
    #with pytest.raises(TypeError):
    #    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:23.254452
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_list = []
    playbook_executor._playbooks = playbook_list
    playbook_executor._loader = None
    playbook_executor.run()


# Generated at 2022-06-24 19:02:06.192212
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("Running test case: test_PlaybookExecutor_run")

    # Initialize ansible config
    work_dir = "/home/nfs/ci/workspace/ansible-daily/temp_ansible"
    config_path = os.path.join(work_dir, 'config_file')
    result = ANSIConfig(config_path)

    # Initialize ansible inventory
    inventory_path = os.path.join(work_dir, 'hosts')
    target_host = "appserver"
    target_group = "appserver"
    result = Inventory(inventory_path, target_host, target_group)

    # Initialize ansible passwords
    passwords = {}

    # Initialize ansible playbook path

# Generated at 2022-06-24 19:02:08.200369
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("Test: run...")
    test_case_0()

# Generated at 2022-06-24 19:02:19.768103
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    settings.CLIARGS = AttrDict()

# Generated at 2022-06-24 19:02:21.778375
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbookExecutor_0 = PlaybookExecutor(None, None, None, None, None)
    # method run return type is int
    assert isinstance(playbookExecutor_0.run(), int)


# Generated at 2022-06-24 19:02:29.668810
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_path = '/root/infrastructure-ansible/playbooks/ping.yml'
    #ansible.config.loader.set_basedir('/root/infrastructure-ansible')
    loader, passwords = AnsibleLoader(playbook_path)
    if loader == None:
        print('AnsibleLoader Failed.')
        return
    print('AnsibleLoader SUCCEEDED.')

    inventory = Inventory(loader=loader, host_list=playbook_path, cache=None)
    if inventory == None:
        print('Inventory Failed.')
        return
    print('Inventory SUCCEEDED.')

    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=ForceVersionInfo())
    if variable_manager == None:
        print('VariableManager Failed.')
        return
    print

# Generated at 2022-06-24 19:02:35.137125
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = []
    inventory = inventory_loader.get_inventory()
    variable_manager = variable_manager.VariableManager()
    loader = DataLoader()
    passwords = {}
    test_case_0()
    #Test when no exceptions are raised
    test_playbookExecutor_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)


# Generated at 2022-06-24 19:02:40.215677
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # See if an exception was raised and if so, see if it was a SystemExit exception
    # The code to do this should be in a 'try' block, but this test case should throw an exception, so it shouldn't be necessary
    # The assertRaises() context manager only catches exception subclasses of Exception and not SystemExit
    with pytest.raises(SystemExit):
        test_case_0()

# Generated at 2022-06-24 19:02:48.153919
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:02:54.320605
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("###### Unit test of PlaybookExecutor ######")
    print("Unit test of PlaybookExecutor constructor")
    PlaybookExecutor(test_case_0(), test_case_0(), test_case_0(), test_case_0(), test_case_0())

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:57.983083
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ["./my-playbook.yml"]
    inventory = Inventory()
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    result = playbook_executor.run()
    assert not result

# Generated at 2022-06-24 19:03:36.810404
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # for python2 and python3
    try:
        from StringIO import StringIO
    except:
        from io import StringIO

    # stdout
    capturedOutput = StringIO()
    sys.stdout = capturedOutput

    # test case
    bool_0 = True
    test_case_0()
    sys.stdout = sys.__stdout__
    assert bool_0, "test_PlaybookExecutor_run() failed"

# Generated at 2022-06-24 19:03:49.129713
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    display_obj = Display()
    display_obj.set_verbosity(2)
    context.CLIARGS = {'connection': 'smart', 'module_path': None, 'forks': 5, 'private_key_file': None, 'ssh_common_args': '-o StrictHostKeyChecking=no', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': True, 'become_method': 'sudo', 'become_user': None, 'verbosity': True, 'check': False, 'listhosts': None, 'listtasks': None, 'listtags': None, 'syntax': None, 'diff': False, 'start_at_task': None}

    var_manager_obj = VariableManager()

    loader_obj = Data

# Generated at 2022-06-24 19:03:55.024032
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    display.warning("######### Test of method run of class PlaybookExecutor ######")
    test_case_0()


# Generated at 2022-06-24 19:03:56.403497
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:03:58.726053
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor()
    result = playbook_executor.run()
    assert result == 0


# Generated at 2022-06-24 19:04:02.409711
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    result = PlaybookExecutor("''' arg1 arg2 arg3 ''", "arg2", "arg3", "False", "''' arg1 arg2 arg3 ''")
    test_case_0()
    #check if result is equal to True
    assert result == True


# Generated at 2022-06-24 19:04:08.623590
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # run with default args
    playbook_executor = PlaybookExecutor(
        playbooks=['test_cases/test_case_0.yml'],
        inventory='test_cases/test_case_0.ini',
        variable_manager=None,
        loader=None,
        passwords=None,
    )
    playbook_executor.run()


# Generated at 2022-06-24 19:04:13.989211
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbookExecutor_0  = PlaybookExecutor("", "", "", "", "")
    test_case_0()

    print("Test_Case_0: Test_Ansible_Pass")

# Generated at 2022-06-24 19:04:24.841685
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    args = [
            "test/integration/inventory/0/0",
            "test/integration/inventory/0/1",
            "test/integration/inventory/0/2",
            "test/integration/inventory/0/3",
            "test/integration/inventory/0/4"
    ]
    parser = argparse.ArgumentParser()
    parser = CLI.base_parser(parser)
    parser = CLI.parse_json_inventory_argument(parser)
    parser = CLI.parse_inventory(parser)
    parser = CLI.parse_listtasks(parser)
    parser = CLI.parse_listtags(parser)
    parser = CLI.parse_syntax(parser)
    parser = CLI.parse_connection(parser)
    parser = CLI.parse_timeout(parser)
    parser = CLI.parse

# Generated at 2022-06-24 19:04:32.267419
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # test_case 01, test the pb list
    print(sys.argv[1])
    print(sys.argv[1].split())
    # g.do_parser(sys.argv[1].split())
    pb_e = PlaybookExecutor(playbooks=['ansible/playbooks/kubernetes_install.yml'],
                            inventory=None, variable_manager=None, loader=None, passwords=None)
    try:
        pb_e.run()
    except SystemExit as e:
        print(e)
    # test_case 02, parse the playbook
    # pb_e = PlaybookExecutor(playbooks=['virtualization.yml'],
    #                         inventory=None, variable_manager=None, loader=None, passwords=None)
    # try:
   

# Generated at 2022-06-24 19:05:07.044123
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:05:11.344470
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

test_PlaybookExecutor()

# Generated at 2022-06-24 19:05:13.480232
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    try:
        playbook_executor_0.run()
    except:
        pass


# Generated at 2022-06-24 19:05:23.699537
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    context.CLIARGS = {'listhosts':False}
    context.CLIARGS = {'listtasks':False}
    context.CLIARGS = {'listtags':False}
    context.CLIARGS = {'syntax':False}
    context.CLIARGS = {'forks':0}
    context.CLIARGS = {'start_at_task':False}
    context.CLIARGS = {'verbosity':0}
    loader_0 = DataLoader()
    passwords_0 = dict()
    inventory_0 = InventoryManager(loader=loader_0, sources='localhost,')
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)

# Generated at 2022-06-24 19:05:24.419564
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-24 19:05:34.231508
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Running unit tests for method PlaybookExecutor.__init__()")
    try:
        playbooks = ["playbooks/playbook1.yml", "playbooks/playbook2.yml"]
        loader = DataLoader()
        passwords = dict()
        inventory = Inventory(loader, None, "inventory.ini")
        variable_manager = VariableManager(loader, inventory)
        pbe = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
        assert(isinstance(pbe, PlaybookExecutor))
    except:
        traceback.print_exc()
        print("__init__() test failed")
        return False
    print("__init__() test passed successfully")
    print("Finished unit tests for method PlaybookExecutor.__init__()")
    return True


# Generated at 2022-06-24 19:05:36.478306
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    assert None != PlaybookExecutor(['hello.yaml'], None, None, None, None)


# Generated at 2022-06-24 19:05:37.875590
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:42.895972
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create an instance of a class
    y = test_case_0()
    # Set method argument
    y.playbooks = 1
    y.inventory = 1
    y.variable_manager = 1
    y.loader = 1
    y.passwords = 1
    # Execute the method
    x = y.run()
    # Check the state of the variable after execution
    assert x == 0

# Generated at 2022-06-24 19:05:48.776387
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:06:27.684325
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    ansible.utils.plugin_docs.basic.AnsiblePlugin.run(dict(), dict(), dict(), dict(), dict())

# Generated at 2022-06-24 19:06:29.409749
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:06:33.080983
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    assert playbook_executor_0.run(None) == 0


# Generated at 2022-06-24 19:06:38.851031
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor('str', 'str', 'str', 'str', 'str')
    playbook_executor.run()

# Generated at 2022-06-24 19:06:47.978225
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    ret_val = playbook_executor_0.run()
    assert isinstance(ret_val, int)

    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    ret_val = playbook_executor_0.run()
    assert isinstance(ret_val, int)

    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    ret_val = playbook_executor_0.run()
    assert isinstance(ret_val, int)


# Generated at 2022-06-24 19:06:51.740371
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '#'
    str_1 = '`s'
    str_2 = 'al'
    str_3 = '~'
    str_4 = '-'
    str_5 = '`s'
    playbook_executor_0 = PlaybookExecutor(str_4, str_4, str_4, str_4, str_4)
    print(playbook_executor_0)
    assert playbook_executor_0.run() == 0
