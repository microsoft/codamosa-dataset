

# Generated at 2022-06-24 18:57:28.273022
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("Testing PlaybookExecutor class constructor")
    test_case_0()
    print("Completed testing PlaybookExecutor class constructor")


# Generated at 2022-06-24 18:57:39.937913
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'Ga39#PkK#@'
    int_0 = 1732
    float_0 = 0.0
    str_1 = '!lB!D'
    list_0 = [str_0, str_1]
    playbook_executor_0 = PlaybookExecutor(int_0, str_0, float_0, list_0, int_0)
    str_0 = 'p~w3~YyP'
    int_0 = 0
    str_1 = '7v@r#'
    dict_0 = {str_0: int_0, str_1: int_0}
    str_1 = '|'
    str_2 = 'j'
    list_0 = [str_0, str_1, str_2]
    float_0 = -0.

# Generated at 2022-06-24 18:57:47.590509
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '~uyNu$7'
    int_0 = 1812
    list_0 = [str_0, int_0, int_0]
    float_0 = 0.0
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, int_0, list_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:51.881458
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '#aN5ZM3lnFXw~knl@'
    int_0 = 1584
    list_0 = [str_0, int_0, int_0]
    float_0 = 0.0
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, int_0, list_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:52.662411
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:58:03.099097
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '4bWx-8*Kzm@0wypZv|'
    int_0 = 627
    list_0 = [str_0, int_0]
    float_0 = 0.0
    playbook_executor_0 = PlaybookExecutor(str_0, int_0, int_0, list_0, float_0)
    str_0 = 'DV7E^'
    str_1 = '#'
    test_PlaybookExecutor_run.playbooks = [str_0, str_1]
    int_0 = 1087
    float_0 = 0.0
    test_PlaybookExecutor_run.inventory = int_0
    int_0 = 526
    test_PlaybookExecutor_run.variable_manager = int_0
    list_0

# Generated at 2022-06-24 18:58:08.688652
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    playbook_executor_1 = PlaybookExecutor('test', 'test', 'test', 'test', 'test')
    playbook_executor_1.run()
    # FIXME: create a test case
    #assert playbook_executor_1.run() == expected



# Generated at 2022-06-24 18:58:18.104164
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '^j4iA'
    int_0 = 1275
    list_0 = [str_0, int_0]
    float_0 = 17.126
    playbook_executor_0 = PlaybookExecutor(float_0, list_0, str_0, int_0, int_0)
    str_0 = 'G'
    bool_0 = bool(str_0)
    bool_1 = bool(int_0)
    bool_2 = bool(float_0)
    int_0 = len(str_0)
    len_0 = len(float_0)
    dict_0 = dict(float_0)
    len_1 = len(dict_0)
    tuple_0 = tuple(str_0)
    len_2 = len(tuple_0)
    bool

# Generated at 2022-06-24 18:58:23.381007
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '6UZC'
    int_0 = 89
    int_1 = 0
    list_0 = ['8Y4q0qIu4PQFmW0M8S0z', int_0, int_1]
    int_2 = 8
    playbook_executor_0 = PlaybookExecutor(str_0, int_1, int_2, list_0, int_2)
    result_0 = playbook_executor_0.run()
    print(result_0)


# Generated at 2022-06-24 18:58:25.063416
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    global display
    test_case_0()
    test_PlaybookExecutor_run.name = 'test_PlaybookExecutor_run'
    display.warning(test_PlaybookExecutor_run.name)

test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:09.734803
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        import __main__
        main_dict = __main__.__dict__
    except ImportError:
        main_dict = globals()

    main_dict['_display'] = Display()
    main_dict['_playbooks'] = '*'
    main_dict['_inventory'] = '*'
    main_dict['_variable_manager'] = '*'
    main_dict['_loader'] = '*'

    playbooks = __main__.__dict__['_playbooks']
    inventory = __main__.__dict__['_inventory']
    variable_manager = __main__.__dict__['_variable_manager']
    loader = __main__.__dict__['_loader']
    passwords = dict()

# Generated at 2022-06-24 18:59:15.109861
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = '*'
    str_2 = '*'
    str_3 = '*'
    str_4 = '*'
    str_5 = '*'
    playbook_executor = PlaybookExecutor(str_1, str_2, str_3, str_4, str_5)
    assert playbook_executor.run() == 0

# Generated at 2022-06-24 18:59:22.830637
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('*', '*', '*', '*', '*')
    try:
        result = playbook_executor_0.run()
        assert False # should throw exception
    except Exception:
        assert True



if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:32.878511
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    list_0 = ['k*Q', 'zKK', '{!R', '<22', '2"B', '1=v']
    str_1 = 'nqv'
    list_1 = ['rp(Z', '`T{', 'TtV', 's-m', 'XsX', 'D:R']
    str_2 = 'Q0|'
    list_2 = ['y8=', 'ujj', '!pG', '7}u', "'r.", 'xT&', '98s', 'V]\t']
    str_3 = ':%2'

# Generated at 2022-06-24 18:59:40.589553
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '^'
    str_1 = '~'
    str_2 = '#'
    str_3 = '|'
    str_4 = ';'
    inventory_0 = Inventory(str_0)
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    playbook_executor_0 = PlaybookExecutor(str_1, inventory_0, variable_manager_0, loader_0, str_2)
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run()
    playbook_executor_0.run

# Generated at 2022-06-24 18:59:44.262458
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    r = playbook_executor_0.run()



# Generated at 2022-06-24 18:59:46.422735
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Variables
    str_0 = '*'
    int_0 = 0
    # Run
    rtnval = test_case_0().run()
    # AssertionError
    if (rtnval != int_0):
        raise AssertionError

test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:47.987820
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:59:51.111327
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor("abc", "def", "ghi", "jkl", "mno")
    assert playbook_executor.run() == 0, "Test failed"


# Generated at 2022-06-24 18:59:53.605158
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory_0 = InventoryCreator(str_0)
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager(str_0, str_0, str_0)
    passwords_0 = dict()
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 19:00:34.258651
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import os
    import sys
    import json
    import pytest
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.utils import context
    from ansible.errors import AnsibleError
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.module_utils.six.moves import StringIO
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-24 19:00:43.753560
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    var_0 = [ '/home/zj/test/test/ansible/examples/test.yaml' ]
    var_1 = 'all'
    var_2 = VariableManager()
    var_3 = 'ansible'
    var_4 = None
    obj = PlaybookExecutor(var_0, var_1, var_2, var_3, var_4)
    assert isinstance(obj._playbooks, list)
    assert obj._inventory == var_1
    assert obj._variable_manager == var_2
    assert obj._loader == var_3
    assert obj.passwords == var_4
    assert isinstance(obj._unreachable_hosts, dict)
    assert obj._unreachable_hosts == {}
    assert obj._tqm is not None


# Generated at 2022-06-24 19:00:49.116118
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Test case for constructor of class PlaybookExecutor
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    inventory = Inventory()
    loader = Loader()

    passwords = dict()
    playbooks = ['tests/resources/playbook.yml']

    # Test case for constructor of class PlaybookExecutor
    test_tasks = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

# Generated at 2022-06-24 19:00:52.861175
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # test_case_0
    var_0 = PlaybookExecutor(["/home/fcui/workdir/ipython/matchbox/ansible/playbooks/arista_eos.yml"], "/home/fcui/workdir/ipython/matchbox/ansible/hosts", "var_manager", "loader", "passwords")
    test_case_0()

# Unit test

# Generated at 2022-06-24 19:01:01.243540
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = dict()
    # Configure ansible to use the test_collection in the current directory
    var_0['display'] = display
    ansible_repository_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
    #os.environ['ANSIBLE_COLLECTIONS_PATHS'] = "/home/kyle/code/ansible/ansible-test-collection/:/home/kyle/code/ansible/ansible-test-collection/test_collection/:" + ansible_repository_path
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ansible_repository_path + ":" + os.getcwd()
    # os.environ['ANSIBLE_COLLECTIONS_PAT

# Generated at 2022-06-24 19:01:03.170544
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__=="__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:08.786489
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    args = dict()
    args['playbooks'] = dict()
    args['inventory'] = dict()
    args['variable_manager'] = dict()
    args['loader'] = dict()
    args['passwords'] = dict()
    playbookexecutor = PlaybookExecutor(**args)
    result = playbookexecutor.run()
    assert result == 0


# Generated at 2022-06-24 19:01:12.997041
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

    assert var_0.run() == None

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:15.265718
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_0 = PlaybookExecutor()
    var_0.run()

# Generated at 2022-06-24 19:01:19.670834
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Initialize a instance of class PlaybookExecutor
    pbx = PlaybookExecutor()
    # Call method run of PlaybookExecutor
    pbx.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:01:56.557626
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('a', 'b', 'c', 'd', 'e')
    try:
        result = playbook_executor_0.run()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 19:02:02.064785
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0.run() == 0
    assert playbook_executor_0._tqm is not None
    assert playbook_executor_0._playbooks == str_0


# Generated at 2022-06-24 19:02:04.369958
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor('*', '*', '*', '*', '*')
    playbook_executor.run()


# Generated at 2022-06-24 19:02:06.352108
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    global str_0
    global playbook_executor_0
    # Create an instance of Class PlaybookExecutor
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)



# Generated at 2022-06-24 19:02:14.918949
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Build PlaybookExecutor
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        # Call method
        result = playbook_executor_0.run()
    except Exception:
        # Call method with exception
        result = playbook_executor_0.run()
        # TypeError
        raise TypeError


# Generated at 2022-06-24 19:02:20.653423
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    inventory_0 = Inventory(host_list=str_0)
    loader_0 = DataLoader()
    passwords_0 = dict()
    playbook_path_0 = 'playbook.yml'
    result = PlaybookExecutor(playbooks=playbook_path_0, inventory=inventory_0,
                              variable_manager=str_0, loader=loader_0, passwords=passwords_0).run()
    assert result is None


# Generated at 2022-06-24 19:02:24.492852
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:27.323244
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

    playbook_executor_0.run()

# Generated at 2022-06-24 19:02:30.104945
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('*', '*', '*', '*', '*')
    playbook_executor_0.run()

# Generated at 2022-06-24 19:02:34.120962
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:13.784382
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        result = playbook_executor_0.run()
    except:
        pass

    assert result == 0


# Generated at 2022-06-24 19:03:21.816034
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '~J/'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-24 19:03:30.942553
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_0 = '*'
        playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
        playbook_executor_0.run()
    except Exception as e:
        print("playbook_executor_0.run() failed: " + str(e))
    else:
        print("playbook_executor_0.run() passed!")


# Generated at 2022-06-24 19:03:35.256623
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    unit test for method run of class PlaybookExecutor
    """
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:38.379327
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '*'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-24 19:03:42.321007
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        print("Fail")
        print(e.__doc__)
    else:
        print("Success")


# Generated at 2022-06-24 19:03:46.580392
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO:
    assert True == True
    test_case_0()


# Generated at 2022-06-24 19:03:52.634287
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    Test case for method run of class PlaybookExecutor
    """
    # initialize the test suite
    test_case_0()

if __name__ == '__main__':
    for f in [x for x in dir() if x.startswith('test_')]:
        print(f)
        eval(f)()

# Generated at 2022-06-24 19:03:56.776327
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:59.441396
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:04:39.868988
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'ansible/playbook'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:04:41.998674
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('*', '*', '*', '*', '*')
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:44.043027
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print('Running unit test for PlaybookExecutor:run')
    test_case_0()

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:47.207444
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor("", "", "", "", "")
    str_0 = '*'
    str_1 = '**'
    str_2 = '***'
    playbook_executor.run(str_0, str_1, str_2)

# Generated at 2022-06-24 19:04:48.624595
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO
    pass


# Generated at 2022-06-24 19:04:49.780983
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()



# Generated at 2022-06-24 19:04:56.726146
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    results_0 = playbook_executor_0.run()
    print(results_0)


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 1:
        test_case_0()
    else:
        test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:02.956252
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create an instance of class PlaybookExecutor
    try:
        playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    except NameError:
        playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)

        # Call method run of playbook_executor_0
    return_value_0 = playbook_executor_0.run()

    assert return_value_0 == 0

# Generated at 2022-06-24 19:05:07.860581
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Data model for test.
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    # Call the test.
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:08.807926
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()
    pass

# Generated at 2022-06-24 19:05:44.223566
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:05:47.973532
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    retval_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:05:50.022506
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    global str_0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-24 19:05:52.150318
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor()
    playbook_executor.run()

# Generated at 2022-06-24 19:05:58.245605
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '*'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0) # [0, '', '', '', '', [], [], False, False, '', '']
    playbook_executor_0.run() # [0, '', '', '', '', [], [], False, False, '', '']
    return playbook_executor_0.run()


# Generated at 2022-06-24 19:06:00.860938
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(" * ", " [ ! ", " \t1 ", " = ", " ')")
    playbook_executor_0.run()



# Generated at 2022-06-24 19:06:09.169802
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '$'
    int_0 = 0
    playground_treasure_hunt = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert isinstance(playground_treasure_hunt, PlaybookExecutor)
    assert isinstance(PlaybookExecutor, type)
    assert playground_treasure_hunt._inventory._inventory != None
    assert playground_treasure_hunt._inventory.inventory.inventory != None
    assert playground_treasure_hunt._inventory.inventory.inventory.inventory != None
    assert playground_treasure_hunt._inventory.inventory.inventory.inventory.inventory != None
    assert playground_treasure_hunt._playbooks == str_0
    assert playground_treasure_hunt.passwords == str_0

# Generated at 2022-06-24 19:06:15.179017
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    str_1 = '*'
    str_2 = '*'
    str_3 = '*'
    str_4 = '*'
    str_5 = '*'
    playbook_executor_1 = PlaybookExecutor(str_1, str_2, str_3, str_4, str_5)
    playbook_executor_0.run()
    playbook_executor_1.run()
    assert playbook_executor_1.run() == 0


# Generated at 2022-06-24 19:06:19.437430
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:06:23.035988
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()
