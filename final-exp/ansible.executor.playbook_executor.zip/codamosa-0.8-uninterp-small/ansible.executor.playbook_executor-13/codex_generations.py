

# Generated at 2022-06-24 18:57:38.749874
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '"('
    str_1 = '&5 u'
    dict_0 = None
    int_0 = 4287
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:57:39.321408
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-24 18:57:43.740529
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()
    print('PlaybookExecutor constructor passed')


# Generated at 2022-06-24 18:57:45.389657
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    result = PlaybookExecutor().run()
    assert result == 0


# Generated at 2022-06-24 18:57:49.880876
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '!b'
    str_1 = '|'
    dict_0 = None
    int_0 = None
    dict_1 = dict_0
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_1)
    assert False == playbook_executor_0.run()

# Generated at 2022-06-24 18:57:53.172638
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '"('
    str_1 = '&5 u'
    dict_0 = None
    int_0 = 4287
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_0)
    ret_0 = playbook_executor_0.run()


# Generated at 2022-06-24 18:57:57.279467
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '"('
    str_1 = '&5 u'
    dict_0 = None
    int_0 = 4287
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_0)
    playbook_executor_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:57:58.347462
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:00.984030
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '"('
    str_1 = '&5 u'
    dict_0 = None
    int_0 = 4287
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_0)
    int_1 = playbook_executor_0.run()
    print(int_1)


# Generated at 2022-06-24 18:58:07.117009
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_0 = '"('
        str_1 = '&5 u'
        dict_0 = None
        int_0 = 4287
        playbook_executor_0 = PlaybookExecutor(str_0, str_1, dict_0, int_0, dict_0)
        playbook_executor_0.run()
        print('test passed')
    except Exception as e:
        print(e)


# Generated at 2022-06-24 18:58:38.595175
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    #playbook_executor_0.run()


# Generated at 2022-06-24 18:58:42.147845
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    int_result_0 = playbook_executor_0.run()
    assert int_result_0 == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:58:51.323513
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 18:58:56.986119
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    dict_3 = {}
    dict_3 = {}
    dict_3 = {}
    dict_1 = {}
    dict_1 = {}
    bytes_2 = b''
    dict_1 = {}
    dict_1 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2 = {}
    dict_2 = {}
    dict_2 = {}
    playground = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:59:02.742515
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    assert_equals(playbook_executor_0._loader, dict_0)
    assert_equals(playbook_executor_0.passwords, tuple_0)
    assert_equals(playbook_executor_0._tqm, None)
    assert_equals(playbook_executor_0._playbooks, dict_0)
    assert_equals(playbook_executor_0._unreachable_hosts, dict_0)
    assert_equals(playbook_executor_0._inventory, bytes_0)

# Generated at 2022-06-24 18:59:15.072009
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # create object PlaybookExecutor
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    _dict_5 = {'encrypt': '0', 'salt': '', 'unsafe': '0'}
    _dict_6 = {'default': '', 'name': 'vault_password', 'prompt': 'Vault password:', 'unsafe': '0', 'confirm': '0', 'encrypt': '0', 'salt_size': '32', 'salt': ''}
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    # run method PlaybookExecutor


# Generated at 2022-06-24 18:59:26.739856
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    try:
        playbook_executor_0.run()
        print("[OK]")
    except Exception as e:
        print("[FAILED]")
        print("[EXCEPTION] ", e)
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)

# Generated at 2022-06-24 18:59:33.392852
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_0 = {}
    bytes_0 = b''
    tuple_0 = ()
    playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_0, dict_0, tuple_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 18:59:40.909512
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    if sys.version_info.major == 3 and \
       sys.version_info.minor >= 7:
        dict_0 = {'run': True}
        bytes_0 = b'localhost'
        dict_1 = {'run': True}
        dict_2 = {'run': True}
        tuple_0 = (b'password',)
        with unittest.mock.patch('ansible.cli.playbook.CLI.parse') as parse_mock:
            playbook_executor_0 = PlaybookExecutor(dict_0, bytes_0, dict_1, dict_2, tuple_0)
            parse_mock.return_value = parse_mock
            parse_mock.verbosity = 0
            assert isinstance(parse_mock, unittest.mock.Mock)

# Generated at 2022-06-24 18:59:45.606100
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    dict_1 = {}
    bytes_1 = b''
    tuple_1 = ()
    obj_PlaybookExecutor = PlaybookExecutor(dict_1, bytes_1, dict_1, dict_1, tuple_1)
    obj_PlaybookExecutor._unreachable_hosts = dict_1
    obj_PlaybookExecutor._tqm = dict_1
    entry = obj_PlaybookExecutor.run()
    print(entry)

# Generated at 2022-06-24 19:00:23.596113
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    bytes_1 = b'\x96\x0c\x11|\x0c'
    bytes_2 = b'\x8d\x06\x14p\x04'
    int_0 = 0
    bytes_3 = b'\x88\x04\x11s\x02'
    bytes_4 = b'\x9c\x03\x15j\x10'
    bytes_5 = b'\x88\x06\x1b|\x0c'
    int_1 = 1
    bytes_6 = b'\x84\x06\x0c{\x06'

# Generated at 2022-06-24 19:00:29.241120
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:00:34.991259
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    result = playbook_executor_0.run()
    print("result: ", result)

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:38.732591
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    bytes_0 = b'G\xfb\xae\x16\xe2\xbb\xcf\xbf'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)


# Generated at 2022-06-24 19:00:43.419114
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:48.743239
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = 'playbooks'
    inventory = 'inventory'
    variable_manager = 'variable_manager'
    loader = 'loader'
    passwords = 'passwords'
    test_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)


# Generated at 2022-06-24 19:00:56.184981
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:01:00.968010
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    playbook_executor_0.run()

if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:06.376312
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:01:15.465007
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # initialization
    bytes_0 = b'\xbd\x0f\x12p\x0e'
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bool_0, bytes_0, bool_0)
    assert_equal(playbook_executor_0.run(), 0)

# Generated at 2022-06-24 19:01:50.257455
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # testing for 'if playbook_collection:'
    playbook_executor_0 = PlaybookExecutor(['playbook_00', 'playbook_01'], 'inventory_0', 'variable_manager_0', 'loader_0', 'passwords_0')
    playbook_executor_1 = PlaybookExecutor(['playbook_00', 'playbook_01'], 'inventory_0', 'variable_manager_0', 'loader_0', 'passwords_0')
    playbook_executor_0.run()
    playbook_executor_1.run()

# Generated at 2022-06-24 19:01:52.989791
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor("p", "p", "p", "p", b"p")
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:55.791021
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:05.104705
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    bytes_1 = b"L\xed"
    bytes_2 = b"\\"
    bytes_3 = b"\x01"
    bytes_4 = b"Inventory"
    bytes_5 = b"0.9.3"
    bytes_6 = b"0.9.0"
    bytes_7 = b"0.9.4"
    bytes_8 = b"0.9.4"
    bytes_9 = b"0.9.4"
    bytes_10 = b"-G"
    bytes_11 = b"abcd"
    bytes_12 = b"^A-z"
    bytes_13 = b"\x7f\x7f"
    bytes_14 = b"\\"
    bytes_15 = b"0.9.3"

# Generated at 2022-06-24 19:02:12.290561
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # 测试正常情况
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert type(playbook_executor_0.run()) == int


# Generated at 2022-06-24 19:02:16.763221
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    try:
        playbook_executor_0.run()

    except Exception as e:
        print('test_PlaybookExecutor_run Failed: ', e)


# Generated at 2022-06-24 19:02:22.558570
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b".."
    bytes_1 = b".."
    bytes_2 = b".."
    bytes_3 = b".."
    bytes_4 = b".."
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_1, bytes_2, bytes_3, bytes_4)
    result = playbook_executor_0.run()

    try:
        assert False
    except AssertionError as e:
        pass

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:24.173695
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:02:27.793250
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(b'/test/playbook', b'', b'', b'', b'')
    test_case_0()


del PlaybookExecutor

# Generated at 2022-06-24 19:02:36.194249
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = b'\x00' * 3
    inventory = b'\x00' * 3
    variable_manager = b'\x00' * 3
    loader = b'\x00' * 3
    passwords = b'\x00' * 3
    test_case_0()
    # Try Except to prevent Process finished with exit code -1073741819 (0xC0000005)
    try:
        playbook_executor_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    except:
        pass


# Generated at 2022-06-24 19:03:21.230196
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    data_fname = "test_data/test-data.yml"

# Generated at 2022-06-24 19:03:22.923113
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:03:28.573073
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0.run() == int_0


# Generated at 2022-06-24 19:03:39.771256
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_path = "./tests/"
    inventory = Inventory('')
    display.verbosity = 3
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-24 19:03:46.256391
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(
        b"//",
        b"//",
        b"//",
        b"//",
        b"//"
    )

    playbook_executor_0.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:50.742187
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:03:56.589798
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = playbook_executor_0.run()


# Generated at 2022-06-24 19:04:00.808435
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Declare objects and variables
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)

    # From generated test
    result = playbook_executor_0.run()


# Generated at 2022-06-24 19:04:11.286650
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test case 0
    task_queue_manager_0 = TaskQueueManager( inventory=bytes_0, variable_manager=bytes_0, loader=bytes_0, passwords=bytes_0, forks=bytes_0)
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    playbook_executor_0._tqm = task_queue_manager_0
    playbook_executor_0._playbooks = bytes_0
    playbook_executor_0._inventory = bytes_0
    playbook_executor_0._variable_manager = bytes_0
    playbook_executor_0._loader = bytes_0
    playbook_executor_0._passwords = bytes_0
    playbook_executor_0._unreachable_hosts = dict()
   

# Generated at 2022-06-24 19:04:13.054342
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)



# Generated at 2022-06-24 19:04:52.626749
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:04:56.633551
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:04:59.119591
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as err:
        print('Test failed: ')
        print(err)
        return False

    return True


# Generated at 2022-06-24 19:05:00.098958
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:05:08.896021
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        bytes_0 = b'mv'
        bytes_1 = b'<'
        bytes_2 = b'*'
        bytes_3 = b'l+'
        bytes_4 = b'{'
        playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_1, bytes_2, bytes_3, bytes_4)
    except Exception as exception_0:
        print ('Exception caught: ' + str(exception_0))


# Generated at 2022-06-24 19:05:15.193669
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    try:
        playbook_executor_0.run()
    except Exception as exception_0:
        assert(False)



# Generated at 2022-06-24 19:05:17.090967
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()

    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:05:23.029008
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''test_PlaybookExecutor_run'''
    # Setup test data
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)

    # Invoke method
    # Assert
    try:
        playbook_executor_0.run()
    except Exception:
        pass


# Generated at 2022-06-24 19:05:27.434569
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'"'
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:30.389620
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():


    test_PlaybookExecutor__get_serialized_batches()

    test_PlaybookExecutor__generate_retry_inventory()



# Generated at 2022-06-24 19:06:05.751348
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Make sure the run method has the correct signature
    # Test the run() of PlaybookExecutor method OK
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:08.528439
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:06:10.371853
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Unit tests for PlaybookExecutor
if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:06:17.305383
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.config.manager import ConfigManager
    c = ConfigManager(["/etc/ansible/ansible.cfg", "~/.ansible.cfg", "ansible.cfg"]).get_config()
    # This creates a config object, which is a collection of configuration settings.
    # configure_logging(c.log_path)
    # This sets the logging configuration.
    default_vars = set()
    var_manager = VariableManager(loader=None, inventory=None, version_info=None, included_file=None, extra_vars=None, use_include=None, pass_vars=None, module_vars=None, default_vars=default_vars, vault_password=None, directory=None)
    loader = DataLoader()
    passwords = dict()
    playbooks = list("'")
    inventory

# Generated at 2022-06-24 19:06:21.557236
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    ##
    # @todo
    ##
    ##
    ##
    ##
    ##

    return

##

# Generated at 2022-06-24 19:06:26.272591
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:06:30.573030
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor("byte_0", bytes_0, bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-24 19:06:32.457804
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:06:42.551833
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"'"
    ansible_playbook_executor = PlaybookExecutor(bytes_0, bytes_0, bytes_0, bytes_0, bytes_0)
    try:
        # FIXME: missing test for ansible_playbook_executor.run()
        pass
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-24 19:06:50.829249
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b"/"