

# Generated at 2022-06-24 18:57:31.989526
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = 1204.0
    tuple_0 = ()
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, tuple_0, bool_0, bool_0, float_0)
    assert isinstance(playbook_executor_0, PlaybookExecutor)


# Generated at 2022-06-24 18:57:37.251756
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1204.0
    tuple_0 = ()
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, tuple_0, bool_0, bool_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:42.887696
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    display.warning("***** BEGIN UNIT TEST - test_PlaybookExecutor_run *****")
    float_0 = 1204.0
    tuple_0 = ()
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, tuple_0, bool_0, bool_0, float_0)
    display.warning("***** END UNIT TEST - test_PlaybookExecutor_run *****\n")
    return 0


# Generated at 2022-06-24 18:57:45.801162
# Unit test for constructor of class PlaybookExecutor

# Generated at 2022-06-24 18:57:49.592027
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    float_0 = 1204.0
    tuple_0 = ()
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, tuple_0, bool_0, bool_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:50.440892
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:55.124405
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    float_0 = 1204.0
    tuple_0 = ()
    bool_0 = False
    playbook_executor_0 = PlaybookExecutor(float_0, tuple_0, bool_0, bool_0, float_0)


# Generated at 2022-06-24 18:58:00.267854
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # params
    playbook_executor_obj_0 = PlaybookExecutor(0, 0, 0, 0, 0)
    assert not playbook_executor_obj_0.run()

# Generated at 2022-06-24 18:58:04.574388
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(float, tuple, bool, bool, float)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:07.056143
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:58:29.884609
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # pb = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    # r = pb.run()
    test_case_0()


# Generated at 2022-06-24 18:58:31.527263
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 18:58:35.455779
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0 is not None

# Generated at 2022-06-24 18:58:40.300065
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    t0 = 0
    t1 = 1
    t2 = 2
    t3 = 3
    t4 = 4
    t5 = 5
    t6 = 6
    t7 = 7
    t8 = 8
    t9 = 9
    t10 = 10
    t11 = 11
    t12 = 12
    t13 = 13
    t14 = 14
    t15 = 15
    t16 = 16
    t17 = 17
    t18 = 18
    t19 = 19
    t20 = 20
    t21 = 21
    t22 = 22
    t23 = 23
    t24 = 24
    t25 = 25
    t26 = 26
    t27 = 27
    t28 = 28
    t29 = 29
    t30 = 30
    t31 = 31
    t32 = 32
   

# Generated at 2022-06-24 18:58:42.489119
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-24 18:58:47.149441
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:58:51.646716
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 0


# Generated at 2022-06-24 18:58:54.803688
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 1
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    return_value_0 = playbook_executor_0.run()
    assert return_value_0 == 0


# Generated at 2022-06-24 18:58:55.804025
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:58:59.771173
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(0, 0, 0, 0, 0)
    playbook_executor_0.run()
    return playbook_executor_0

# Local Variables:
# compile-command: "python -m py_compile PlaybookExecutor.py"
# End:

# Generated at 2022-06-24 18:59:21.686315
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(0, 0, 0, 0, 0)
    playbook_executor_0._get_serialized_batches(0)
    playbook_executor_0.run()
    return


# Unit test driver for PlaybookExecutor class

# Generated at 2022-06-24 18:59:22.756366
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 18:59:23.755016
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 18:59:25.801693
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 18:59:29.980798
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    test_case_0()
    test_case_1()



# Generated at 2022-06-24 18:59:33.074143
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:34.637054
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

test_PlaybookExecutor()

# Generated at 2022-06-24 18:59:36.196472
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 18:59:38.341565
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:59:39.292378
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    assert True


# Generated at 2022-06-24 19:00:11.135698
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    DEBUG = False
    if DEBUG:
        display.set_verbosity(9)
        import AnsibleLogConfig
        AnsibleLogConfig.configure_logging(level=9)

    int_0 = 0
    inventory_0 = None
    variable_manager_0 = None
    loader_0 = None
    passwords_0 = None
    # Test configuration:
    # Test PlaybookExecutor.run() with no arguments

    playbook_executor_0 = PlaybookExecutor(int_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    playbook_executor_0.run()

    # only checks that the method does not raise an exception.
    # Test configuration:
    # Test PlaybookExecutor.run() with a single argument:
    # The inventory is a custom data structure.
    # Test

# Generated at 2022-06-24 19:00:20.884936
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 0
    try:
        # print out dict
        dict_0 = {}
        dict_0['key'] = "value"
        print(dict_0)
        # print out set
        set_0 = {}
        print(set_0)
        # print out list
        list_0 = []
        list_0.append(1)
        print(list_0)

        # print out int
        print(int_0)
        print(1)

    except Exception as e:
        print(e)
        pass



# Generated at 2022-06-24 19:00:22.445311
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible import constants as C
    C.HOST_KEY_CHECKING = False
    test_case_0()



# Generated at 2022-06-24 19:00:24.396234
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # 1. let the test case to run
    test_case_0()


# Generated at 2022-06-24 19:00:27.679538
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:00:33.727333
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    ret_val = playbook_executor_0.run()
    print(ret_val)

PlaybookExecutor.playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-24 19:00:40.251603
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:00:41.581178
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:00:46.862366
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    assert result == 0


# Generated at 2022-06-24 19:00:49.448280
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Main method:
if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:21.190429
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 1
    playbook_executor_0 = PlaybookExecutor(int_1, int_1, int_1, int_1, int_1)
    playbook_executor_0.run()
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:30.286995
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int(), int(), int(), int(), int())
    playbook_path_0 = ''
    collection_name_0 = ''
    collection_name_1 = ''
    ansible_collection_config_default_collection_0 = AnsibleCollectionConfig.default_collection
    ansible_collection_config_default_source_0 = AnsibleCollectionConfig.default_source
    ansible_collection_config_source_paths_0 = AnsibleCollectionConfig.source_paths
    ansible_collection_config_collection_paths_0 = AnsibleCollectionConfig.collection_paths
    ansible_collection_config_collection_playbook_paths_0 = AnsibleCollectionConfig.collection_playbook_paths
    ansible_collection_config_collection_module_paths_0 = AnsibleCollectionConfig

# Generated at 2022-06-24 19:01:33.931122
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:01:35.765258
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:45.976483
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    if result == int_0:
        display.display('\tBranch 0.0')
    if result == int_1:
        display.display('\tBranch 0.1')
    if result == int_2:
        display.display('\tBranch 0.2')
    if result == int_3:
        display.display('\tBranch 0.3')
    if result == int_4:
        display.display('\tBranch 0.4')
    if result == int_5:
        display.display('\tBranch 0.5')


# Generated at 2022-06-24 19:01:51.721831
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 1
    int_5 = 5
    int_10 = 10
    int_11 = 11
    int_15 = 15
    int_20 = 20
    int_25 = 25
    int_30 = 30
    int_35 = 35
    int_40 = 40
    int_45 = 45
    int_50 = 50
    int_55 = 55
    int_60 = 60
    int_65 = 65
    int_70 = 70
    int_75 = 75
    int_80 = 80
    int_90 = 90
    int_100 = 100
    int_105 = 105
    int_110 = 110
    int_115 = 115
    int_120 = 120
    int_130 = 130
    int_140 = 140
    int_145 = 145
    int_

# Generated at 2022-06-24 19:02:03.247414
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #
    # Set up test inputs
    #
    # Create a PlaybookExecutor object
    test_case_PlaybookExecutor_run_playbooks_0 = []
    test_case_PlaybookExecutor_run_inventory_0 = []
    test_case_PlaybookExecutor_run_variable_manager_0 = []
    test_case_PlaybookExecutor_run_loader_0 = []
    test_case_PlaybookExecutor_run_passwords_0 = []

# Generated at 2022-06-24 19:02:08.271602
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    int_1 = 1
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0._loader == int_0
    assert playbook_executor_0.run() == int_1
    assert playbook_executor_0._loader != int_0


# Generated at 2022-06-24 19:02:09.967177
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # with parameters
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0 is not None


# Generated at 2022-06-24 19:02:19.578156
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print(">>> play_executor.py test_PlaybookExecutor_run begins")
    playbook_path = "/Users/smak/PycharmProjects/test-ansible/vuln_checker_test/test.yml"
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_file = Hosts(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-24 19:02:52.947717
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    print('PlaybookExecutor.run : %s' % playbook_executor_0.run())

if __name__ == "__main__":
    # execute only if run as a script
    test_PlaybookExecutor_run()
    # test_case_0()

# Generated at 2022-06-24 19:02:58.139198
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    res = playbook_executor_0.run()
    #assert res == 0


# Generated at 2022-06-24 19:03:00.576473
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    rv = PlaybookExecutor.run(test_PlaybookExecutor_run)
    assert isinstance(rv, int)

# Generated at 2022-06-24 19:03:06.486894
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #playbooks = 1
    #inventory = 1
    #variable_manager = 1
    #loader = 1
    #passwords = 1
    playbook_executor_0 = PlaybookExecutor(1,1,1,1,1)

    # test raises
    with pytest.raises(Exception):
        playbook_executor_0.run()

# Generated at 2022-06-24 19:03:11.557387
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test_PlaybookExecutor")
    test_case_0()
    print("----test_PlaybookExecutor() over------")

# Generated at 2022-06-24 19:03:17.310719
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0._playbooks == 0
    assert playbook_executor_0._inventory == 0
    assert playbook_executor_0._variable_manager == 0
    assert playbook_executor_0._loader == 0
    assert playbook_executor_0.passwords == 0
    try:
        assert playbook_executor_0._tqm == 0
    except:
        assert playbook_executor_0._unreachable_hosts == {}


# Generated at 2022-06-24 19:03:18.410019
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Stub implementation for:
    # method run of class PlaybookExecutor
    pass


# Generated at 2022-06-24 19:03:26.551025
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("\tTESTING unit test for method run of class PlaybookExecutor")
    # setup
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)

    # testing
    # TODO: assert method run of class PlaybookExecutor
    #playbook_executor_0.run()
    print("\tUnit test for method run of class PlaybookExecutor success!!!")


# Generated at 2022-06-24 19:03:31.970828
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_2 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    try:
        result = playbook_executor_2.run()
    except Exception:
        result = False
    return result


# Generated at 2022-06-24 19:03:34.683442
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(1, 1, 1, 1, 1)
    r = playbook_executor_0.run()

# Generated at 2022-06-24 19:04:06.986671
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    result = playbook_executor_0.run()
    assert(result == 0)


# Generated at 2022-06-24 19:04:13.887377
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert playbook_executor_0


# Generated at 2022-06-24 19:04:19.298589
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    pb = Playbook.load("Null", variable_manager=int_0, loader=int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:04:20.258552
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:04:23.413191
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_obj = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    test_obj.run()


# Generated at 2022-06-24 19:04:25.397932
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:04:34.141501
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    assert len(playbook_executor_0._playbooks) == int_0
    assert playbook_executor_0._inventory == int_0
    assert playbook_executor_0._variable_manager == int_0
    assert playbook_executor_0._loader == int_0
    assert playbook_executor_0.passwords == int_0
    assert playbook_executor_0._tqm == int_0

# Generated at 2022-06-24 19:04:35.894939
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:42.333159
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Argument of type 'int'
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    int_0 = playbook_executor_0.run()
    # Type/Integrity verification of return value
    if isinstance(int_0, int):
        print("0: PASS")
    else:
        print("0: FAIL")


# Generated at 2022-06-24 19:04:43.350799
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:05:15.641611
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    entrylist = playbook_executor_0.run()
    print('Output: ' + str(entrylist))


# Generated at 2022-06-24 19:05:21.087020
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int(0), int(0), int(0), int(0), int(0))
    result = playbook_executor_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:24.742041
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:27.537324
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print('Test function Executor.run')
    test_case_0()


# Generated at 2022-06-24 19:05:32.597628
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    # Output path: ..
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:41.155582
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    status = 0
    # None as a parameter
    try:
        if test_case_0() == 0:
            status += 1
    except:
        #print traceback.format_exc()
        #print sys.exc_info()[0]
        raise Exception("PlaybookExecutor: run failed")
    # Successfully executed
    if status == 1:
        print("Success in running PlaybookExecutor: run()")
    else:
        raise Exception("Failure in running PlaybookExecutor: run()")


# Main function to execute all test cases
if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:43.599771
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test execution of run method of class PlaybookExecutor
    int_0 = 0
    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:44.581389
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass  # No code to test for PlaybookExecutor.run()


# Generated at 2022-06-24 19:05:46.053486
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:05:51.638283
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    inventory_0 = Inventory(loader=int_0, variable_manager=int_0, host_list="test_inventory")
    variable_manager_0 = VariableManager(loader=int_0, inventory=inventory_0)
    loader_0 = DataLoader()
    passwords_0 = dict()
    playbook_executor_0 = PlaybookExecutor(int_0, inventory_0, variable_manager_0, loader_0, passwords_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:33.234620
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0
    result = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0).run()
    assert result == 0

# Generated at 2022-06-24 19:06:36.972803
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:06:38.616484
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:06:42.649855
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Tests run when no '--extra-vars=@' or 
    # '--extra-vars=@/' are specified.

    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:49.775430
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    int_0 = 0

    playbook_executor_0 = PlaybookExecutor(int_0, int_0, int_0, int_0, int_0)

    # Invoking method
    int_1 = playbook_executor_0.run()
    # Verifying method outputs
    assert int_1 == 0
