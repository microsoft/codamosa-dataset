

# Generated at 2022-06-24 18:57:37.259301
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    str_1 = '[vars]'
    str_2 = ';<%\n$vPCjQ>aEY=9|EVc%j!l5&DNUp3wB^C#n4=g|_<y*Hx,bX9oRr+guYaAtF{j'
    str_3 = '[defaults]\nstdout_callback = tasks'
    str_4 = '#'
    str_5 = ':'
    str_6 = '::'
    str_7 = '-p'
    str_8 = ' --'
    str_9 = '-'
    str_10 = '-c'
    str_11 = '-v'

# Generated at 2022-06-24 18:57:44.980297
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = 'winrm'
    playbook_executor_1 = PlaybookExecutor(str_1, list_0, str_0, str_0, list_0)
    list_1 = ['sudo', 'winrm', '-k', 'runas', '-U', 'root', '-H', '%(host)s']
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    assert [str_1, list_1, int_0, int_1, int_2] == playbook_executor_1.run()
    
    str_2 = 'ssh'
    str_3 = 'ansible_connection'
    list_2 = [str_2, str_3, str_2]
    playbook_executor_2 = PlaybookExecutor

# Generated at 2022-06-24 18:57:52.747848
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_0 = [str_0, str_0, str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, list_0, str_0, str_0, list_0)
    # Generate a random variable name
    random_variable_name = get_random_variable_name()
    # Put a new value for this variable
    setattr(C, random_variable_name, True)
    # Run the method
    result = playbook_executor_0.run()
    # Check the result
    assert result == 0
    # Delete the variable we created
    delattr(C, random_variable_name)


# Generated at 2022-06-24 18:58:03.550870
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("Running PlaybookExecutor.run()...")

    #Load the config
    context.CLIARGS = ImmutableDict(listtags=False, listtasks=False, listhosts=False,
                                    syntax=False, connection='local',
                                    module_path=None, forks=100, become=True,
                                    become_method='sudo', become_user='root',
                                    check=False,
                                    diff=False)

    context._init_global_context(context.CLIARGS)
    playbooks = ["ansible/test/integration/targets/unconfigured"]
    passwords = dict(vault_pass='secret')

    # create the variable manager, which will be shared throughout
    # the code, ensuring a consistent view of global variables
    variable_manager = VariableManager()
    loader = Data

# Generated at 2022-06-24 18:58:14.875714
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_0 = [str_0, str_0, str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, list_0, str_0, str_0, list_0)
    str_1 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_1 = [str_0, str_1, str_0, str_0]
    str_2 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_2 = [str_1, str_0, str_2, str_0]
    int_0 = playbook_executor_0.run()

# Generated at 2022-06-24 18:58:19.218351
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_0 = [str_0, str_0, str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, list_0, str_0, str_0, list_0)



# Generated at 2022-06-24 18:58:20.651540
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()
    print('SUCCESS: test_PlaybookExecutor')

# Unit testing main

# Generated at 2022-06-24 18:58:22.517626
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_1 = PlaybookExecutor(str(123), list(range(11)), str(123), list(range(11)), str(123))



# Generated at 2022-06-24 18:58:25.922673
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    list_0 = [str_0, str_0, str_0, str_0]
    playbook_executor_0 = PlaybookExecutor(str_0, list_0, str_0, str_0, list_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:58:31.363805
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_path = "./tests/test_cases/PlaybookExecutor_run_0.yaml"
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "hosts": "localhost",
        "_playbook_dir": os.path.dirname(playbook_path)
    } # type: ansible.vars.manager.VariableManager
    display.verbosity = 4
    loader = DataLoader() # type: ansible.parsing.dataloader.DataLoader
    passwords = dict()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='./hosts')
    variable_manager.set_inventory(inventory)
    playbooks = [playbook_path]

# Generated at 2022-06-24 18:59:01.566558
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'SUCCESS: test_PlaybookExecutor'
    var_0 = print(str_0)


# Generated at 2022-06-24 18:59:07.744377
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    var_1 = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, passwords=None)
    var_2 = var_1.run()
    assert var_2 == 0
test_PlaybookExecutor_run.__dict__.__setitem__('stypy_localization', {'__file__': 'test.py'})
test_PlaybookExecutor_run.__dict__.__setitem__('stypy_type_of_self', type(None))
test_PlaybookExecutor_run.__dict__.__setitem__('stypy_type_store', module_type_store)
test_PlaybookExecutor_run.__dict__.__setitem__('stypy_function_name', 'test_PlaybookExecutor_run')
test_PlaybookExec

# Generated at 2022-06-24 18:59:16.593992
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = []
    inventory = Inventory([])
    variable_manager = VariableManager(loader=DataLoader())
    loader = DataLoader()
    passwords = dict()

    # Test class PlaybookExecutor is defined
    var_1 = PlaybookExecutor
    assert var_1

    # Test instance PlaybookExecutor is defined
    obj_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert obj_0

    # Test method run is defined
    var_2 = PlaybookExecutor.run
    assert var_2

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor()
    print('{0}: success!'.format(__file__))

# Generated at 2022-06-24 18:59:22.741147
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:
        str_2 = PlaybookExecutor()
        try:
            if str_2.run() != 0:
                test_case_0()
        except Exception as e:
            display.error(to_text(e))
    except Exception as e:
        display.error(to_text(e))

# Generated at 2022-06-24 18:59:23.796628
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    run(self)


# Generated at 2022-06-24 18:59:27.053726
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'SUCCESS: test_PlaybookExecutor'
    var_0 = print(str_0)

# Testing Function

# Generated at 2022-06-24 18:59:30.916118
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'SUCCESS: test_PlaybookExecutor'
    var_0 = print(str_0)


# Generated at 2022-06-24 18:59:38.381109
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Initialize mocked object
    test_obj = PlaybookExecutor(
    )

    # Mock the run method
    test_obj.run = test_case_0

    # Run the unit test
    test_obj.run()

# Generated at 2022-06-24 18:59:40.205463
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# End of PlaybookExecutor class

# Class for retrieving hosts from inventory

# Generated at 2022-06-24 18:59:44.299702
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = None
    inventory = None
    variable_manager = None
    loader = None
    passwords = {}
    obj_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    test_case_0()

test_PlaybookExecutor()

# Generated at 2022-06-24 19:00:17.416336
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:25.994919
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:33.272887
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # test case 1
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    dict_0 = {}
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    int_0 = playbook_executor_0.run()
    assert int_0 == 0
    assert dict_0 == {}


# Generated at 2022-06-24 19:00:36.247711
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:00:39.785978
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert False


# Generated at 2022-06-24 19:00:44.006296
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    # Case 1:
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)


# Unit test case class

# Generated at 2022-06-24 19:00:49.524036
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    #playbook_executor = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    pass


# Generated at 2022-06-24 19:00:58.880269
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'host_vars'
    str_1 = 'y'
    str_2 = 'open_shell'
    str_3 = 'bac_km_S6ITI5A5C5zcdNQbL0j'
    str_4 = 'virtualenv_hosts'
    str_5 = 'failed'
    str_6 = 'lXmO6Qc3q'
    str_7 = 'inventory_file'
    str_8 = '_private'

# Generated at 2022-06-24 19:01:02.551329
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pbex = PlaybookExecutor(playbooks=None, inventory=None, variable_manager=None, loader=None, passwords=None)
    assert pbex.run() == 0


# Generated at 2022-06-24 19:01:07.561538
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result = playbook_executor_0.run()

# Generated at 2022-06-24 19:01:44.519034
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:01:51.451068
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:01:53.650661
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:59.813712
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_0 = playbook_executor_0.run()
    assert result_0 == 0

# Generated at 2022-06-24 19:02:05.705975
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:02:07.473083
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:02:13.034184
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    assert (PlaybookExecutor('playbook_executor', 'inventory', 'variable_manager', 'loader', 'passwords').run() == 0 or PlaybookExecutor('playbook_executor', 'inventory', 'variable_manager', 'loader', 'passwords').run() == 1)


# Generated at 2022-06-24 19:02:15.106002
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:02:18.097347
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor = PlaybookExecutor(str, str, str, str, str)
    display.display(playbook_executor)
# end of test_PlaybookExecutor()



# Generated at 2022-06-24 19:02:21.422078
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:02:57.641619
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    print(playbook_executor_0)


# Generated at 2022-06-24 19:03:02.226538
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    arguments = str("Z")
    load_0 = load(None, arguments)
    load_1 = load(load_0, arguments)
    set_loader(load_1)
    assert callable(PlaybookExecutor.run)
    assert isinstance(PlaybookExecutor.run(), int)


# Generated at 2022-06-24 19:03:11.288298
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Run method of PlaybookExecutor class
    playbook_executor_0 = PlaybookExecutor('test_playbook_executor_0', 'test_playbook_executor_1', 'test_playbook_executor_2', 'test_playbook_executor_3', 'test_playbook_executor_4')
    # TypeError: __init__() takes 3 positional arguments but 5 were given
    try:
        playbook_executor_0.run()
    except Exception as e:
        display.error(to_text(e))
    # TypeError: __init__() takes 5 positional arguments but 3 were given
    try:
        playbook_executor_0.run()
    except Exception as e:
        display.error(to_text(e))
    # TypeError: __init__() takes 5 positional arguments but 4 were

# Generated at 2022-06-24 19:03:14.254726
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = ''
    str_1 = 'foo'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    #playbook_executor_0.run()


# Generated at 2022-06-24 19:03:22.925254
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # setup test
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    # perform test
    result = playbook_executor_0.run()
    # verify result
    assert result == 0

# Generated at 2022-06-24 19:03:28.388724
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))
        error = True
    assert not error



# Generated at 2022-06-24 19:03:31.538363
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('playbooks', str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:36.989219
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    try:
        playbook_executor_0.run()
    except AnsibleConnectionFailure:
        print('AnsibleConnectionFailure')


# Generated at 2022-06-24 19:03:49.195448
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # Test 1
    #playbooks = ['playbook_file_0']
    #inventory = 'inventory_0'
    #variable_manager = VariableManager()
    #loader = DataLoader()
    #passwords = 'passwords_0'
    #context.CLIARGS = {'listhosts': 0, 'listtasks': 0, 'listtags': 0, 'syntax': 0}
    #playbook_executor_0 = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    #entrylist = playbook_executor_0.run()
    #assert entrylist == 0

    # Test 2
    #playbooks = ['playbook_file_1']
    #inventory =

# Generated at 2022-06-24 19:03:54.197714
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0.run() == None


# Generated at 2022-06-24 19:04:34.477888
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(
        str_0, str_0, str_0, str_0, str_0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:04:39.517175
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('str', 'str', 'str', 'str', 'str')

# Generated at 2022-06-24 19:04:44.086695
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result = playbook_executor_0.run()
    print(result)

test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:46.418897
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('', '', '', '', '')
    ret = playbook_executor_0.run()
    # assert my code



# Generated at 2022-06-24 19:04:50.388735
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    # BEGIN of test code for method run of class PlaybookExecutor
    # END of test code for method run of class PlaybookExecutor


# Generated at 2022-06-24 19:04:54.237542
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    int_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:04:58.024615
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    assert playbook_executor_0.run() == 0, "Error with the PlaybookExecutor.run() :%s" % str(playbook_executor_0.run())

# Generated at 2022-06-24 19:05:01.817711
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor_0 = PlaybookExecutor(str, str, str, str, str)
    playbook_executor_0.run()
    assert playbook_executor_0._tqm._inventory._hosts['ip-10-0-0-156'] == dummy_host


# Generated at 2022-06-24 19:05:05.566001
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:05:09.174975
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:44.711505
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    # Calling run method on class PlaybookExecutor
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:47.376491
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    result = playbook_executor_0.run()

# Generated at 2022-06-24 19:05:49.823086
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # 1. Test case with a positive result
    test_case_0()
    # 2. Test case with a negative result


if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:53.571432
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    playbook_executor_0 = PlaybookExecutor()
    result_pl = playbook_executor_0.run()

    assert result_pl == 0 or result_pl == 1


# Generated at 2022-06-24 19:05:57.728688
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    return playbook_executor_0


# Generated at 2022-06-24 19:06:00.707311
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:04.973074
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'WINRM FETCH "%s" to "%s" (offset=%d)'
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, str_0, str_0, str_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:09.908174
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import os
    os.environ['ANSIBLE_REMOTE_TEMP'] = "/home/user/ansible/tmp"
    os.environ['ANSIBLE_LOCAL_TEMP'] = "/home/user/ansible/tmp"

    playbook_executor_0 = PlaybookExecutor("[--syntax]", str_0, str_0, str_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:11.370310
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:06:15.278953
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Assign expected value
    playbook_executor_0 = PlaybookExecutor('playbooks_0', 'inventory_0', 'variable_manager_0', 'loader_0', 'passwords_0')
    int_expected_0 = 0
    # Invoke method
    int_result_0 = playbook_executor_0.run()
    assert int_result_0 == int_expected_0

