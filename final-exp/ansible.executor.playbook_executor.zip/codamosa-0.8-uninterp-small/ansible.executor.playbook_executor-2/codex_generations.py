

# Generated at 2022-06-24 18:57:36.211961
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_2 = '/sys/block/*/slaves/*'
    dict_2 = {str_2: str_2, str_2: str_2}
    tuple_2 = (dict_2,)
    bytes_2 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_2 = 1.0
    playbook_executor_2 = PlaybookExecutor(tuple_2, dict_2, bytes_2, float_2, tuple_2)
    str_3 = 'A'
    dict_3 = {str_3: str_2, str_2: str_2}
    tuple_3 = (dict_2,)

# Generated at 2022-06-24 18:57:37.468429
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 18:57:38.457476
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:51.139955
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test case with valid arguments
    str_0 = '/sys/block/*/slaves/*'
    dict_0 = {str_0: str_0, str_0: str_0}
    tuple_0 = (dict_0,)
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    try:
        playbook_executor_0.run()
    except Exception as e:
        print(e)

    # Test case with valid arguments
    str_0 = '/sys/block/*/slaves/*'

# Generated at 2022-06-24 18:57:53.928433
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:57:58.744706
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    dict_0 = {str_0: str_0, str_0: str_0}
    tuple_0 = (dict_0,)
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    test_case_0()


# Generated at 2022-06-24 18:58:06.410302
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    dict_0 = {str_0: str_0, str_0: str_0}
    tuple_0 = (dict_0,)
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    playbook_executor_1 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    playbook_executor_2 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    playbook

# Generated at 2022-06-24 18:58:07.532238
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO: This unit test needs work
    pass


# Generated at 2022-06-24 18:58:09.379187
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

################################################################################


# Generated at 2022-06-24 18:58:17.371299
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    dict_0 = {str_0: str_0, str_0: str_0}
    tuple_0 = (dict_0,)
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(tuple_0, dict_0, bytes_0, float_0, tuple_0)
    # Test of assert with test operation
    assertEqual(playbook_executor_0.run(), 0)


# Generated at 2022-06-24 18:58:49.858100
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, bytes_0, float_0, str_0)
    entrylist = playbook_executor_0.run()
    print(entrylist)

if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:55.761188
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    obj_0 = PlaybookExecutor(str_0, str_0, bytes_0, float_0, str_0)
    obj_0.run()

# Generated at 2022-06-24 18:59:02.378316
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Init.
    playbook_path = '/sys/block/*/slaves/*'
    inventory_file = '/sys/block/*/slaves/*'
    variable_manager = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    loader = 1.0
    passwords = '/sys/block/*/slaves/*'
    playbooks = [playbook_path]
    pbex = PlaybookExecutor(playbooks, inventory_file, variable_manager, loader, passwords)
    pbex.run()


# Generated at 2022-06-24 18:59:08.184236
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, bytes_0, float_0, str_0)
    result = playbook_executor_0.run()
    assert result == 1.0


# Generated at 2022-06-24 18:59:10.246286
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 18:59:18.313037
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = "\xa1\xc1\x9b\xd6\x1c\xb1\xeb\xf2Q\x8c\xc3\xb7\xe3\x16\x9c\x93\x1cw\x16\x8f\xd5\x0e\xaf\xce\x9cF4\x18"
    str_1 = "\\xA1\\xC1\\x9B\\xD6\\x1C\\xB1\\xEB\\xF2q\\x8C\\xC3\\xB7\\xE3\\x16\\x9C\\x93\\x1Cw\\x16\\x8F\\xD5\\x0E\\xAF\\xCE\\x9CF4\\x18"

# Generated at 2022-06-24 18:59:21.628393
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = '/sys/class/net'
    inventory = '/sys/class/net'
    passwords = {}
    vars = 'tb9z8gm5'
    loader = 'o52rmkj2'
    playbook_executor_0 = PlaybookExecutor(playbook, inventory, vars, loader, passwords)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:24.181353
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    def test_function(playbooks, inventory, variable_manager, loader, passwords):
        test_case_0()
    test_function(None, None, None, None, None)


# Generated at 2022-06-24 18:59:33.438610
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, bytes_0, float_0, str_0)
    list_0 = list(map(int, ['']))
    result_0 = playbook_executor_0.run()
    assert isinstance(result_0, list)



# Generated at 2022-06-24 18:59:38.299455
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    bytes_0 = b"\x15\x08'\xf0r\x80)\xcb+\xfa\xe2"
    float_0 = 1.0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, bytes_0, float_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:21.608688
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:00:24.859210
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()
# end of class PlaybookExecutor

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:00:30.258501
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)


# Generated at 2022-06-24 19:00:32.750802
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    return_0 = PlaybookExecutor.run(str_0, float_0, float_0, str_0)
    assert return_0 == 0

# Generated at 2022-06-24 19:00:43.514065
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_1 = '/sys/block/*/slaves/*'
    float_1 = -7.533704340467036
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, float_1, float_1, str_1)
    playbook_executor_1.run()

# Unit tests for class PlaybookExecutor

# Generated at 2022-06-24 19:00:48.192344
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:55.438647
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Note that the first parameter to PlaybookExecutor is used as a list
    playbook_executor_0 = PlaybookExecutor([], [], [], [], [])
    int_0 = playbook_executor_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 19:00:58.300668
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pb_executor = PlaybookExecutor('test_playbook', 'test_inventory', 1, 1, 'test_password')
    assert pb_executor.run() == 0


# Generated at 2022-06-24 19:01:04.392561
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    entrylist_0 = playlist_executor_0.run()
    assert entrylist_0 == []


# Generated at 2022-06-24 19:01:09.345512
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = './module_utils/basic.py'
    float_0 = 3.0664260896156483
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()
    return playbook_executor_0


# Generated at 2022-06-24 19:01:46.296358
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0.run()

# Generated at 2022-06-24 19:01:49.579269
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)


# Generated at 2022-06-24 19:01:53.942406
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)


if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:01:56.559241
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:58.683965
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:07.547548
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    result = playbook_executor_0.run()
    print(result)

if __name__ == "__main__":

    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:15.240909
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()



if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:20.829287
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    assert playbook_executor_0.run() == []

# Uncomment the line below to start the unit tests
# test_case_0()
# test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:02:26.603635
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    assert playbook_executor_0 is not None

    str_1 = '*'
    float_1 = -3.9062223014624226
    playbook_executor_1 = PlaybookExecutor(str_1, str_1, float_1, float_1, str_1)
    assert playbook_executor_1 is not None

# Testcase:

# Generated at 2022-06-24 19:02:32.292967
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.errors import AnsibleError
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # make sure there is no ansible.cfg file
    test_config = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible.cfg')
    if os.path.isfile(test_config):
        os.unlink(test_config)


# Generated at 2022-06-24 19:03:09.269689
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:16.827902
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    print(playbook_executor_0)
    

# Generated at 2022-06-24 19:03:21.177757
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create a new instance of PlaybookExecutor
    playbook_executor_0 = PlaybookExecutor()

    # Call method run of playbook_executor_0
    playbook_executor_0.run()

# Generated at 2022-06-24 19:03:28.330198
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # create test object
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    # call to method run
    result = playbook_executor_0.run()
    print(result)

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:33.987409
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    global str_0, float_0, playbook_executor_0
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:38.908852
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/etc/passwd'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:48.212532
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor('playbooks/playbook_1.yml', '/etc/ansible/hosts', -7.533704340467036, -7.533704340467036, 'playbooks/playbook_1.yml')
    playbook_executor_0._generate_retry_inventory('playbooks/playbook_1.yml', ['-7.533704340467036'])
    playbook_executor_0.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:03:49.338357
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()



# Generated at 2022-06-24 19:03:54.750517
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = ''
    float_1 = 9.824741522607792e+307
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_1, float_1, str_0)

    try:
        int_0 = playbook_executor_0.run()
    except RuntimeError:
        pass


# Generated at 2022-06-24 19:03:59.710687
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:04:42.545935
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test_PlaybookExecutor")
    test_case_0()
    print("logging")
    logger_0 = logging
    logger_0.info('test_PlaybookExecutor')
    logger_0.debug('ansible')
    logger_0.warning('test_PlaybookExecutor')
    print("logger")


test_PlaybookExecutor()

# Generated at 2022-06-24 19:04:49.853130
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create an object of the PlaybookExecutor class
    # Assign None to str_0
    # Assign None to str_1
    # Assign None to float_0
    # Assign None to float_1
    # Assign None to str_2
    str_0 = None
    str_1 = None
    float_0 = None
    float_1 = None
    str_2 = None
    playbook_executor_0 = PlaybookExecutor(str_0, str_1, float_0, float_1, str_2)
    # Call method run of playbook_executor_0
    playbook_executor_0.run()
    
if __name__ == '__main__':
    test_PlaybookExecutor_run()
    print("Done.")

# Generated at 2022-06-24 19:04:52.282449
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:04:57.808685
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    try:
        playbook_executor_0.run()
    except Exception:
        pass


# Generated at 2022-06-24 19:05:03.863275
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_0.run()

# save off for later
_check_mode = getattr(clicmd, 'check')

# Generated at 2022-06-24 19:05:05.038217
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    assert test_case_0() == None



# Generated at 2022-06-24 19:05:08.023722
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Simple test, just run one test case
    test_case_0()
    # test_case_1()
    # test_case_2()

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:14.752654
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_regex = r'[a-zA-Z]{1,}'
    str_pattern = re.compile(str_regex)
    for _ in range(100):
        str_0 = str_pattern.get_random_string(16)
        str_1 = str_pattern.get_random_string(16)
        str_2 = str_pattern.get_random_string(16)
        int_0 = random.randint(0, 1000)
        float_0 = random.random()
        float_1 = random.random()
        bool_0 = bool(random.getrandbits(1))
        bool_1 = bool(random.getrandbits(1))
        bool_2 = bool(random.getrandbits(1))
        bool_3 = bool(random.getrandbits(1))

# Generated at 2022-06-24 19:05:17.706315
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# End of testing for method run of class PlaybookExecutor
# Start testing for method _get_serialized_batches of class PlaybookExecutor


# Generated at 2022-06-24 19:05:27.321021
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/'
    float_0 = -5.372003696196642
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_1 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_2 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_3 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_4 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    playbook_executor_

# Generated at 2022-06-24 19:06:02.055460
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 19:06:05.105170
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # set up
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    # execution
    result = playbook_executor_0.run()
    # verification
    assertEqual(result, 0)


# Generated at 2022-06-24 19:06:10.054763
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    assert playbook_executor_0.run() == 0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:11.838891
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # FIXME - Add unit test to verify a `int` return value
    # FIXME - Add unit test to verify the exception handling
    pass


# Generated at 2022-06-24 19:06:14.049697
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

# Generated at 2022-06-24 19:06:21.211624
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    ret_val = playbook_executor_0.run()
    assert ret_val is None


# Generated at 2022-06-24 19:06:27.162230
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = 'test_value_4'
    float_1 = -10.0
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_1, str_0, str_0)
    playbook_executor_0._playbooks = str_0
    playbook_executor_0._inventory = str_0
    playbook_executor_0._variable_manager = float_1
    playbook_executor_0.passwords = str_0
    playbook_executor_0._loader = str_0
    playbook_executor_0._unreachable_hosts = {}
    playbook_executor_0.run()


# Generated at 2022-06-24 19:06:29.538782
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor(str(), str(), float(), float(), str())
    test_case_0()


# Generated at 2022-06-24 19:06:35.093776
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    with pytest.raises(PlaybookParserException):
        playbook_executor_0.run()


# Generated at 2022-06-24 19:06:42.748471
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    str_0 = '/sys/block/*/slaves/*'
    float_0 = -7.533704340467036
    playbook_executor_0 = PlaybookExecutor(str_0, str_0, float_0, float_0, str_0)
    with pytest.raises(IOError):
        playbook_executor_0.run()
