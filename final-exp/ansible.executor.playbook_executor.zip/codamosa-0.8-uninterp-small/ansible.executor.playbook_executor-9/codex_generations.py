

# Generated at 2022-06-24 18:57:39.066538
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    loader = DataLoader()
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:57:48.189471
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Run the given playbook, based on the settings in the play which
    may limit the runs to serialized groups, etc.
    '''
    playbook_executor_0 = PlaybookExecutor(False, b'\xcd4\x96!E\xbe\xee/T\x8b\xb2\x1e\xac', False, {False, False, False}, 100.0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:57:51.823323
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(True, b'\xcd4\x96!E\xbe\xee/T\x8b\xb2\x1e\xac', True, set([True, True, True]), 100.0)
    result = playbook_executor_0.run()
    assert isinstance(result, int)


# Generated at 2022-06-24 18:57:52.632523
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# Generated at 2022-06-24 18:57:57.804173
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bool_0 = True
    bytes_0 = b'\xcd4\x96!E\xbe\xee/T\x8b\xb2\x1e\xac'
    set_0 = {bool_0, bool_0, bool_0}
    float_0 = 100.0
    playbook_executor_0 = PlaybookExecutor(bool_0, bytes_0, bool_0, set_0, float_0)
    # Calling method run of class PlaybookExecutor
    result = playbook_executor_0.run()

# Generated from PlaybookExecutor on Wed. Dec. 5, 2018

# Generated at 2022-06-24 18:58:02.643878
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bool_0 = False
    bytes_0 = b'\x8fzu\x19\x9d\x7f\xf1\xa5\x04\xc6\x16\xcc\x9b\xcd5\xe2\x84\xab\x85\xc0\x88\x1b\x13\x93\x9c\x81\x16\xbd\x17\xf2@\x96\xf3\x8f\xbe\x1f\x10\x8d\xb6\x83\xd5\x94\x1f\xd6'
    set_0 = {bool_0, bool_0, bool_0}
    float_0 = 100.0

# Generated at 2022-06-24 18:58:07.524629
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(True, b'\xaa\x8a\x8f\x97', True, {True}, 100.0)
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:58:14.222516
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bool_0 = True
    bytes_0 = b'\xcd4\x96!E\xbe\xee/T\x8b\xb2\x1e\xac'
    float_0 = 100.0
    set_0 = {bool_0, bool_0, bool_0}
    playbook_executor_0 = PlaybookExecutor(bool_0, bytes_0, bool_0, set_0, float_0)
    assert(playbook_executor_0.run() == 0)


# Generated at 2022-06-24 18:58:15.781542
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 18:58:21.660399
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bool_0 = True
    bytes_0 = b'\xcd4\x96!E\xbe\xee/T\x8b\xb2\x1e\xac'
    set_0 = {bool_0, bool_0, bool_0}
    float_0 = 100.0
    playbook_executor_0 = PlaybookExecutor(bool_0, bytes_0, bool_0, set_0, float_0)
    result_0 = playbook_executor_0.run()


# Generated at 2022-06-24 18:59:02.981356
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    result = playbook_executor_0.run()
    if result == 0:
        print('test_PlaybookExecutor_run')
        print('PASSED')
        return 0
    else:
        print('test_PlaybookExecutor_run')
        print('FAILED')
        return -1


# Generated at 2022-06-24 18:59:05.662959
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = test_case_0()
    playbook_executor.run()


# Generated at 2022-06-24 18:59:11.177206
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(186.61698, b'r\xcc\x1b\xcb\x888', b'\x9c\xba\x1b\x9c\x1e\x7f\xc0\xdf', 39.254605, b'\xb0\x9e\x9c')
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 18:59:18.316686
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    assert int_0 == -1


# Generated at 2022-06-24 18:59:19.683256
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
  test_PlaybookExecutor()

# Generated at 2022-06-24 18:59:23.829761
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():    
    bytes_0 = b'\x0f'
    float_0 = 112.836448
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:27.085041
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    global playbook_executor_0
    test_case_0()
    playbook_executor_0.run()


# Generated at 2022-06-24 18:59:28.983755
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()



# Generated at 2022-06-24 18:59:34.091696
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()
    # Test.assert_raises(exception_type, "raise exception_type('Test')", globals=globals())


# Generated at 2022-06-24 18:59:38.217531
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    assert isinstance(playbook_executor.run(), tuple)


# Generated at 2022-06-24 19:00:16.559774
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:19.345892
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()
    # Complete verification for method run of class PlaybookExecutor
    assert True

# Complete class for PlaybookExecutor

# Generated at 2022-06-24 19:00:21.856905
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    i = 0
    while i < 100:
        test_case_0()
        i += 1

if __name__ == '__main__':
    # Unit test for method run of class PlaybookExecutor
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:00:27.108351
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    res_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:00:32.336302
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    int_0 = playbook_executor_0.run()


# Generated at 2022-06-24 19:00:37.665367
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor()
    playbook_executor.run()


# Generated at 2022-06-24 19:00:44.798635
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_1.run()


# Generated at 2022-06-24 19:00:50.719436
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:00:54.290208
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(b'\x8a\x8f\x97', b'\x8a\x8f\x97', b'\x8a\x8f\x97', 267.59732, 267.59732)
    result = playbook_executor_0.run()
    display.display(result)


# Generated at 2022-06-24 19:00:56.134979
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-24 19:01:39.750639
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Config file for Playbook.
    # FIXME: the default values of "inventory" and "variable_manager" should not be "None".
    config = ConfigParser()
    # Set playbooks to run.
    config.read("../ansible.cfg")
    playbooks = ["../test/test.yml"]
    # Construct Inventory.
    path_to_inventory = None
    host_list = ["ansible-test", "ansible-test-suite", "test_playbook_executor"]
    inventory = Inventory(host_list)
    # TODO: Construct Variable manager.
    variable_manager = None
    # Construct loader.
    loader = DataLoader()
    # Construct passwords.
    passwords = {}
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    #

# Generated at 2022-06-24 19:01:43.464952
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    var_0 = playbook_executor_0.run()
    assert to_text(var_0) == to_text('')

# Generated at 2022-06-24 19:01:50.505808
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_1 = PlaybookExecutor()
    var_1 = playbook_executor_1.run()
    print("Result: ",var_1)
    assert len(var_1) > 0


# Generated at 2022-06-24 19:01:51.162019
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()


# Generated at 2022-06-24 19:01:52.990969
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor()
    var = playbook_executor.run()
    assert var == 0

# Generated at 2022-06-24 19:01:55.844319
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

# unit test function "run" in class PlaybookExecutor

# Generated at 2022-06-24 19:01:58.193739
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    var_0 = playbook_executor_0.run()

# Generated at 2022-06-24 19:02:00.533241
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test_PlaybookExecutor: ")
    test_case_0()


# Generated at 2022-06-24 19:02:04.237380
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    var_0 = playbook_executor_0.run()
    assert_equals(var_0, 0)

# Generated at 2022-06-24 19:02:06.335877
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    var_0 = playbook_executor_0.run()
    return var_0


# Generated at 2022-06-24 19:02:44.720190
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # test_case_0
    playbook_executor_0 = PlaybookExecutor()

    # test_case_1
    playbook_executor_1 = PlaybookExecutor()

    # test_case_2
    playbook_executor_2 = PlaybookExecutor()

# Generated at 2022-06-24 19:02:49.857939
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    if not test_case_0():
        return False

    return True



# Generated at 2022-06-24 19:02:55.675278
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook = ['TestPlaybook']
    inventory = None
    variable_manager = None
    loader = None
    passwords = None
    playbook_executor = PlaybookExecutor(playbooks=playbook, inventory=inventory,
                                         variable_manager=variable_manager, loader=loader, passwords=passwords)
    assert type(playbook_executor) == PlaybookExecutor


# Generated at 2022-06-24 19:02:56.572051
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-24 19:02:58.477381
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("test_PlaybookExecutor")
    test_case_0()


# Generated at 2022-06-24 19:03:05.091087
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    output = playbook_executor_0.run()
    assert output==0


# Generated at 2022-06-24 19:03:12.815339
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    def fake_get_collection_name_from_path(path):
        return ""

    def fake_get_collection_playbook_path(path):
        return (False, path, "")

    with patch("ansible.utils.collection_loader._collection_finder._get_collection_name_from_path", fake_get_collection_name_from_path):
        with patch("ansible.utils.collection_loader._collection_finder._get_collection_playbook_path", fake_get_collection_playbook_path):
            playbook_executor_0 = PlaybookExecutor(playbooks=[], inventory=inventory, variable_manager=variable_manager, loader=None, passwords=None)

            ansible_play

# Generated at 2022-06-24 19:03:16.176218
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor()
    playbook_executor_0.run()


# Generated at 2022-06-24 19:03:25.078677
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """ Unit test for method PlaybookExecutor.run."""
    # Get the command line args

# Generated at 2022-06-24 19:03:30.452312
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_case_0()

test_PlaybookExecutor_run()

# ansible.playbook.play_context.PlayContext

# Generated at 2022-06-24 19:04:08.358411
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x9e\xe8'
    float_0 = 568.7
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    assert playbook_executor_0.run() == 568.7


# Generated at 2022-06-24 19:04:16.437639
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # setUp
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    path_0 = 'W6J8KvU'

# Generated at 2022-06-24 19:04:20.329055
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    try:

        bytes_0 = b'\x8a\x8f\x97'
        float_0 = 267.59732
        playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
        # Set verbosity to 1, for testing purposes.
        context.CLIARGS = {
            "verbosity": 1,
        }

        # Start test
        playbook_executor_0.run()
        # FIXME: need a more comprehensive test
        assert 1 != 1

    except Exception:
        assert 1 != 1


# Generated at 2022-06-24 19:04:22.116147
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:04:26.009049
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()

# Generated at 2022-06-24 19:04:30.242567
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Arrange
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)

    # Act
    result_0 = playbook_executor_0.run()

    # Assert
    assert(result_0 == 0)

# Generated at 2022-06-24 19:04:36.138977
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-24 19:04:41.148220
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    result_0 = playbook_executor_0.run()



# Generated at 2022-06-24 19:04:46.272193
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    result_0 = playbook_executor_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:04:49.908890
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)

    # Call method run of class PlaybookExecutor
    assert playbook_executor_0.run() == 0


# Generated at 2022-06-24 19:05:31.917006
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    monitor_0 = Monitor()
    monitor_0.start()
    result_0 = playbook_executor_0.run()
    monitor_0.stop()

# Generated at 2022-06-24 19:05:37.122818
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()


# Generated at 2022-06-24 19:05:42.649682
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_1 = b'\x8a\x8f\x97'
    float_1 = 267.59732
    playbook_executor_1 = PlaybookExecutor(bytes_1, bytes_1, bytes_1, float_1, float_1)
    playbook_executor_1.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:43.657437
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    r = main()
    # Display output
    print(r)


# Generated at 2022-06-24 19:05:47.049153
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:05:48.245324
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    test_case_0()


# Generated at 2022-06-24 19:05:54.985441
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\xad\x90\x82\x8a\x8f\x97'
    float_0 = 1.0262897010943833e+30
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    playbook_executor_0.run()
    return playbook_executor_0


# Generated at 2022-06-24 19:05:59.086022
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor_0 = PlaybookExecutor(os.path.realpath('test_playbook_executor_run.yml'), bytes, bytes, bytes, bytes)
    # print(playbook_executor_0.run())

test_case_0()
test_PlaybookExecutor_run()

# Generated at 2022-06-24 19:06:02.021215
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_0 = b'\x8a\x8f\x97'
    float_0 = 267.59732
    playbook_executor_0 = PlaybookExecutor(bytes_0, bytes_0, bytes_0, float_0, float_0)
    try:
        # playbooks is null, should raise exception
        playbook_executor_0.run()
    except:
        pass


# Generated at 2022-06-24 19:06:04.750155
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    bytes_1 = b'\xf8\xe0'
    float_1 = 600.304
    playbook_executor_1 = PlaybookExecutor(bytes_1, bytes_1, bytes_1, float_1, float_1)

    retval_0 = playbook_executor_1.run()
    assert retval_0 == 0
