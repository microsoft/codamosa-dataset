

# Generated at 2022-06-20 14:15:55.949389
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:16:00.809990
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    assert PlaybookExecutor(
        playbooks=[],
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        options=None,
    )

# Generated at 2022-06-20 14:16:03.846030
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    me = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    me.run()
    return 0

# Generated at 2022-06-20 14:16:07.081187
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_PlaybookExecutor = PlaybookExecutor(playbooks = ["test_playbooks.yml"], inventory = "", variable_manager = "", loader = None, passwords = {})
    test_PlaybookExecutor.run()


# Generated at 2022-06-20 14:16:15.395068
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-20 14:16:23.407694
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    # Set up a loader
    loader = DataLoader()

    # Set up some paths
    playbook_path = '../test/sanity/playbook.yml'
    inventory_path = '../test/sanity/inventory.yml'

    # Set up a mock passwords file
    passwords = dict(conn_pass='bacon',
                     become_pass='steak')

    # Set up a mock options dict
    Options = collections.namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method',
                                                 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])

# Generated at 2022-06-20 14:16:37.520395
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    import ansible.constants as C
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    AnsibleCollectionConfig.configured = False
    AnsibleCollectionConfig.default_collection = None
    # initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    # create inventory, use path to host config file as source or hosts in a comma separated string
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.extra_vars = {'inventory_hostname': 'localhost', 'name': 'test_PlaybookExecutor'}
    variable_manager.options_vars = {'foo': ['bar'], 'bat': 'baz'}
    passwords = {'conn_pass': 'password', 'become_pass': 'password'}


# Generated at 2022-06-20 14:16:40.092808
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pb = PlaybookExecutor("playbooks/hello_world.yml", None, None, None, None)
    assert pb is not None


# Generated at 2022-06-20 14:16:41.253924
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Constructor test for class PlaybookExecutor
    '''
    pass

# Generated at 2022-06-20 14:16:48.463504
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Create inventory
    inventory = Inventory()
    inventory.parse_inventory_file("/etc/ansible/hosts")
    # Create playbook
    playbook = PlaybookExecutor(playbooks=['/etc/ansible/playbook.yaml'], inventory=inventory, variable_manager=None, loader=None, passwords=None)
    # Run it
    playbook.run()


# Generated at 2022-06-20 14:17:21.035314
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = 'playbooks/play.yml'
    passwords = {}

    #Loader and variable manager are not needed when we are just listing playbooks
    loader = DataLoader()
    variable_manager = VariableManager()

    # Create inventory, use path to host config file as source or hosts in a comma seperated string
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    #Create playbook executor
    pbex = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

    #List the playbook contents
    result = pbex.run()
    assert  result == 0

# Generated at 2022-06-20 14:17:30.137938
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """
    Run a playbook with the given options and opens output
    """
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'Collection': 'nsweb'}
    display.debug('Loading inventory')
    inventory = InventoryManager(loader=loader, sources=['/usr/local/etc/ansible/inventory/hosts'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-20 14:17:33.542814
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ["/etc/ansible/hosts"]
    inventory = "hosts"
    variable_manager = "Variables"
    loader = "loader"
    passwords = "ansible"
    obj = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert obj.run is not None

# Generated at 2022-06-20 14:17:46.507771
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """
    Unit test for constructor of class PlaybookExecutor
    """
    inventory = Inventory(loader=None, variable_manager=None, host_list='localhost')
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict(vault_pass='secret')

    playbook_executor = PlaybookExecutor(playbooks=['playbook.yml'], inventory=inventory,
                                         variable_manager=variable_manager, loader=loader, passwords=passwords)

    assert playbook_executor._playbooks == ['playbook.yml']
    assert playbook_executor._inventory == inventory
    assert playbook_executor._variable_manager == variable_manager
    assert playbook_executor._loader == loader
    assert playbook_executor.passwords == passwords
    assert playbook_executor._unreachable_hosts == dict()

# Generated at 2022-06-20 14:17:48.593749
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    Test if the method run of class PlaybookExecutor can
    be executed as expected.
    """

    pass



# Generated at 2022-06-20 14:17:55.380581
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Setup dependencies
    playbooks = ['/app/task/workspace/noconfig/test.yml']
    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    variable_manager = VariableManager(loader, inventory)
    passwords = {}
    p = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

    # Set up test data
    context.CLIARGS = {'syntax': False, 'listhosts': True}
    p._tqm = None

    # Run method under test
    result = p.run()

    assert result != 0


# Generated at 2022-06-20 14:18:06.867048
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """
    Unit test for constructor of class PlaybookExecutor
    """

    C.config.load_config_file()
    passwords = dict()
    playbooks = ['/test/test.yml']
    loader = DataLoader()
    inventory = Inventory(loader, host_list=['/test/test.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert playbook_executor._playbooks == playbooks
    assert playbook_executor._inventory == inventory
    assert playbook_executor._variable_manager == variable_manager
    assert playbook_executor._loader == loader
    assert playbook_executor.passwords == passwords
    assert playbook_executor._unreachable_hosts == dict()

# Generated at 2022-06-20 14:18:09.079619
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    This method is used to test constructor of class PlaybookExecutor
    '''
    pe = PlaybookExecutor('a', 'b', 'c', 'd', 'e')

# Generated at 2022-06-20 14:18:19.701553
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    playbook_file = "playbook"
    inventory = None
    variable_manager = None
    loader = None
    passwords = None

    obj = PlaybookExecutor([playbook_file], inventory, variable_manager, loader, passwords)
    assert obj
    assert obj._playbooks == [playbook_file]
    assert obj._inventory == inventory
    assert obj._variable_manager == variable_manager
    assert obj._loader == loader
    assert obj.passwords == passwords
    assert obj._unreachable_hosts == dict()
    assert obj._tqm == None



# Generated at 2022-06-20 14:18:20.506438
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:19:37.497395
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = os.path.realpath("/home/monty/Documents/Ansible/test/test.yml")

# Generated at 2022-06-20 14:19:47.325401
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for constructor of class PlaybookExecutor
    '''
    import tempfile
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    def module_name_for_host(host):
        '''
        Unit test function
        '''
        return 'shell'

    # create a temporary directory
    tmp_path = tempfile.mkdtemp()

    # create a fake inventory file
    inv_path = os.path.join(tmp_path, 'hosts')
    with open(inv_path, 'w') as f:
        f.write('localhost ansible_connection=local')

    # create a

# Generated at 2022-06-20 14:20:00.256796
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # create a playbook
    content = '''
    - hosts: all
      tasks:
        - name: hello world
          debug: msg="hello world"
    '''
    dir_path = os.path.dirname(os.path.realpath(__file__))
    fd, fp = tempfile.mkstemp(dir=dir_path)
    with os.fdopen(fd, 'w') as f:
        f.write(content)
    playbook = fp

    # create inventory
    dir_path = os.path.dirname(os.path.realpath(__file__))
    fd, fp = tempfile.mkstemp(dir=dir_path)
    with os.fdopen(fd, 'w') as f:
        f.write("localhost ansible_connection=local")
    inventory

# Generated at 2022-06-20 14:20:02.464529
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pb_e = PlaybookExecutor([], [], [], [])
    result = pb_e.run()
    assert result == 0


# Generated at 2022-06-20 14:20:07.710214
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ["test/demo1.yml"]
    inventory = Inventory("localhost")
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict()
    obj = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    obj.run()
    assert obj._playbooks == playbooks


# Test cases for class PlaybookExecutor

# Generated at 2022-06-20 14:20:21.279945
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    # initialize needed objects
    cli = CLI()
    cli.options = dict()
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader)
    inventory.get_hosts(pattern='all')
    variable_manager = VariableManager

# Generated at 2022-06-20 14:20:29.094664
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    class Playbook:
        def load():
            return 0
    class AnsibleEndPlay:
        def __init__(self,a):
            self.result = a
    class VariableManager:
        def get_vars(self,play=None):
            return 0
    class Inventory:
        def remove_restriction():
            return
        def restrict_to_hosts(a):
            return
        def get_hosts(a,order=0):
            return 0
    class TaskQueueManager:
        def __init__(self,inventory,variable_manager,loader,passwords):
            return
        def load_callbacks():
            return
        def send_callback(a,b):
            return

# Generated at 2022-06-20 14:20:40.978081
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    yaml_file = StringIO(YAML_STRING)
    playbook_config_data = {}     # type: dict
    playbook_config_data.update(yaml.load(yaml_file))
    playbooks = playbook_config_data['playbooks']
    inventory_file_path = playbook_config_data['inventory']
    C.RETRY_FILES_ENABLED = False
    loader, inventory, variable_manager = AnsibleUtils.AnsibleUtils.initialize_module(inventory_file_path)
    pe = PlaybookExecutor(playbooks, inventory, variable_manager, loader, {})
    pe.run()


# Generated at 2022-06-20 14:20:48.584272
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader, shell_loader, become_loader


    loader = DataLoader()
    inventory = InventoryManager(loader, None, None)
    variable_manager = VariableManager(loader, inventory, None)
    playbooks = ["/usr/share/ansible/openshift-ansible/playbooks/deploy_cluster.yml"]
    passwords = {}
    tqm = TaskQueueManager(inventory,variable_manager,loader,passwords)
    entrylist = []
    entry = {}
   

# Generated at 2022-06-20 14:20:49.401774
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:22:03.585398
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Test with no options
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, "hosts")
    playbooks = ['test/test_playbook_executor.yml']
    passwords = {}
    pexecutor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert pexecutor

    # Test with option: --list-hosts
    context.CLIARGS = ImmutableDict(listhosts=True)
    pexecutor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert pexecutor

    # Test with option: --list-tasks
    context.CLIARGS = ImmutableDict(listtasks=True)
    pexecutor = Playbook

# Generated at 2022-06-20 14:22:04.651803
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass  # TODO

# Generated at 2022-06-20 14:22:17.275531
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_path = os.path.join('/home/lien/ansible-2.9.2/test/units/file/playbook.yml')
    my_sshkey = '/home/lien/ansible-2.9.2/test/units/sshkeys/id_rsa'
    password = 'secret'
    vault_password = 'secret'

    loader, inventory, variable_manager = init_vars(
        playbook_path,
        my_sshkey,
        password,
        vault_password
    )
    pbex = PlaybookExecutor(
        playbooks=[playbook_path],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=dict()
    )
    print(pbex.run())

# Generated at 2022-06-20 14:22:18.961044
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor('playbook', 'inventory', 'variable_manager', 'loader', 'passwords')
    result = playbook_executor.run()


# Generated at 2022-06-20 14:22:25.627604
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    inventory = InventoryManager(loader=InventoryManager.construct_loader(context.CLIARGS['inventory']))
    variable_manager = VariableManager(loader=InventoryManager.construct_loader(context.CLIARGS['inventory']),
                                       inventory=inventory)
    loader = DataLoader()
    passwords = {}
    pbex = PlaybookExecutor(playbooks=['/etc/ansible/test.yml'], inventory=inventory,
                            variable_manager=variable_manager, loader=loader,
                            passwords=passwords)
    return pbex

if __name__ == '__main__':
    pbex = test_PlaybookExecutor()
    pbex.run()

# Generated at 2022-06-20 14:22:30.404886
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbookExecutor = PlaybookExecutor(['/Users/siddhartha.ray/Documents/ansible-default/playbooks/test.yaml'],None,None,None,None)
    playbookExecutor.run()


test_PlaybookExecutor_run()

# Generated at 2022-06-20 14:22:36.266592
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    ###############################################################################################################
    # This testcase verifies if the run() method returns 0 for no error or not.
    ###############################################################################################################
    # Setup
    my_playbook = PlaybookExecutor([], [], [], [], [])
    # Exercise
    result = my_playbook.run()
    # Verify
    assert result == 0

# Generated at 2022-06-20 14:22:50.499215
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import xmltodict as xmltodict
    import json
    inventory = InventoryManager(loader=C.DEFAULT_LOADER, sources='hosts.yml')
    variable_manager = VariableManager(loader=C.DEFAULT_LOADER, inventory=inventory)
    passwords = {}
    loader = DataLoader()
    playbooks = ['setup.yml']
    pbex = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    result = pbex.run()
    print(json.dumps(xmltodict.parse(result), indent=4))
    assert(type(result) == list)

# Generated at 2022-06-20 14:23:01.228966
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    context.CLIARGS = ImmutableDict(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh', module_path=None, forks=100,
                                    remote_user='skyline', private_key_file=None,
                                    sudo=False, sudo_user='root', ask_sudo_pass=False,
                                    verbosity=4, check=False, start_at_task=None)
    inventory_file = '/home/skyline/ansible-repos/ansible-test/test/test_inventory/test_inventory'
    password = dict(vault_pass='')
    playbooks = ['/home/skyline/ansible-repos/ansible/test/test_playbook_executor/test_playbook.yml']
    loader = DataLoader()

# Generated at 2022-06-20 14:23:14.321157
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # playbook_executor.py
    # Test Case: Invalid playbook path
    display.verbosity = 0
    context.CLIARGS = ImmutableDict(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='smart',
                                    module_path=None, forks=100, remote_user='ansible', private_key_file=None,
                                    ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                                    become=False, become_method=None, become_user='root', verbosity=0, check=False,
                                    diff=False, start_at_task=None)

    # Back up current variables
    cur_sys_argv = sys.argv
    cur_os_

# Generated at 2022-06-20 14:24:17.746728
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:24:23.320282
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    loader = PluginLoader(
        'Error',
        'Test',
        C.DEFAULT_ERROR_PATH,
        'error_',
    )
    error_plugins = _get_all_plugins(loader)
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager()
    passwords = {}

    playbooks = "playbooks/playbook.yml"
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

    playbooks = "playbooks/playbook.yml"
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert playbook_executor.run()

# Generated at 2022-06-20 14:24:34.925094
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    hosts1 = get_hosts_for_test(1)
    hosts2 = get_hosts_for_test(1)
    mock_playbook = get_playbook_for_test(hosts1)
    mock_playbook.set_connection('smart')
    mock_playbook.set_forks(10)
    mock_playbook.set_timeout(60)
    mock_playbook.set_transport('paramiko')
    mock_playbook.set_remote_user('ansible')
    mock_playbook.set_sudo(True)
    mock_playbook.set_sudo_user('root')
    mock_playbook.set_become(True)
    mock_playbook.set_become_method('sudo')
    mock_playbook.set_become_user('root')
    mock

# Generated at 2022-06-20 14:24:49.254117
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    context.CLIARGS = MagicMock()
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['listtasks'] = True
    context.CLIARGS['listtags'] = True
    context.CLIARGS['syntax'] = True
    context.CLIARGS['forks'] = True
    context.CLIARGS['start_at_task'] = True
    context.CLIARGS['start_at_task'] = True
    context.CLIARGS['retry_files_enabled'] = True
    context.CLIARGS['retry_files_save_path'] = True
    context.CLIARGS['retry_files_save_path'] = True
    context.CLIARGS['retry_files_enabled'] = True
    context.CL

# Generated at 2022-06-20 14:24:50.600848
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    Test PlaybookExecutor.run
    """
    pass

# Generated at 2022-06-20 14:24:59.660112
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory_obj = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory_obj)
    loader = DataLoader()
    passwords = dict()
    exec = PlaybookExecutor(playbooks='localhost',
                            inventory=inventory_obj,
                            variable_manager=variable_manager,
                            loader=loader,
                            passwords=passwords)
    assert exec.run() == 0

# Generated at 2022-06-20 14:25:00.375275
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:25:09.082187
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    plays, inventory, loader, variable_manager, passwords, tqm = (
        [
            '/home/student/ansible/playbooks/test.yml'
        ],
        '',
        '',
        '',
        '',
        '',
    )
    PB=PlaybookExecutor(
        plays, inventory, variable_manager, loader, passwords
    )
    pb = PB.run()
    assert pb is not None

if __name__ == "__main__":
    test_PlaybookExecutor_run()

# Generated at 2022-06-20 14:25:14.289232
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    import unittest
    import ansible.constants as C
    p = {
        'inventory_path': 'test',
        'variable_manager': 'test',
        'loader': 'test',
        'passwords': 'test',
        'playbooks': [
            'playbook.yml'
        ]
    }
    C.RETRY_FILES_ENABLED = True
    PlaybookExecutor(p)

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-20 14:25:23.159184
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    def __init__(self):
        self.variable_manager = VariableManager()
        self.passwords = dict(conn_pass=None, become_pass=None)
        self.loader = DataLoader()

    def run():
        pass

    import os
    import tempfile
    import shutil
    import yaml

    # create a sample playbook
    dir_path = tempfile.mkdtemp()
    playbook = os.path.join(dir_path, 'test.yml')
    hosts = ['test_hosts']
