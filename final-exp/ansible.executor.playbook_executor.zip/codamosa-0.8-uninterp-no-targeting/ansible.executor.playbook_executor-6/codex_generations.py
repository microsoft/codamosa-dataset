

# Generated at 2022-06-20 14:16:05.457764
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    import os
    from ansible.playbook import PlayBook
    from ansible.plugins.loader import become_loader, connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import sys
    # initialize needed objects
    connection_loader.all(class_only=True)
    become_loader.all(class_only=True)
    passwords = dict(conn_pass=None, become_pass=None)
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=['localhost'])
    # create an executor with the PlayBook and inventory

# Generated at 2022-06-20 14:16:16.690995
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("test_PlaybookExecutor_run")
    class Foo:
        def __init__(self, value):
            self.value = value
    class Playbook:
        def __init__(self, value):
            self.value = value
    class AnsibleEndPlay:
        def __init__(self, result):
            self.result = result
    inventory = Foo(1)
    variable_manager = Foo(2)
    loader = Foo(3)
    passwords = Foo(4)
    playbooks = ['playbook1']
    Playbook.load = lambda x, variable_manager, loader: Foo(x)
    pb = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    pb._get_serialized_batches = lambda x: [Foo(1)]
    pb._

# Generated at 2022-06-20 14:16:28.199417
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for constructor of class PlaybookExecutor
    '''
    display.verbosity = 4

    print("testing constructor of class PlaybookExecutor")
    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    passwords = {'conn_pass': 'pass', 'become_pass': 'pass'}

    pe = PlaybookExecutor(playbooks=["/etc/ansible/README.md"], inventory=inventory,
                          variable_manager=variable_manager, loader=loader,
                          passwords=passwords)
    result = pe.run()
    print("expected result: %s" % (1))
    print("current result: %s" % (result))

# Generated at 2022-06-20 14:16:28.983189
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:16:40.022850
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = ['../examples/playbook.yml']
    inventory = Inventory('hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    passwords = {'become_pass': None}
    pb_ex = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    # _inventory.set_playbook_basedir(os.path.realpath(os.path.dirname(playbook_path)))
    pb_ex._inventory.set_playbook_basedir('/Users/zhangxin/dev/ansible/ansible-2.8.0/examples')
    for playbook in pb_ex._playbooks:
        resource = _get_collection_playbook_path(playbook)

# Generated at 2022-06-20 14:16:42.075365
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print ("Test 1: Empty constructor")
    ansible_playbook = PlaybookExecutor(playbooks,inventory,variable_manager,loader,passwords)


# Generated at 2022-06-20 14:16:50.805704
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    import ansible.playbook
    import ansible.inventory

    p1 = ansible.playbook.Playbook.load("./test_playbook_executor.yml")
    i1 = ansible.inventory.Inventory()
    e1 = PlaybookExecutor(p1, i1, ansible.vars.VariableManager(), ansible.utils.loader.set_loader(None), ansible.parsing.dataloader.DataLoader())
    print(e1.run())

# Generated at 2022-06-20 14:16:51.796870
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:16:52.534557
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:16:55.833236
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    p = PlaybookExecutor(
        playbooks=['example.yml'],
        inventory=InventoryManager(host_list='playbooks/hosts'),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        passwords=dict()
    )
    print(p)

# Generated at 2022-06-20 14:17:23.222450
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = ['test.yml']
    inventory = Inventory(host_list='tests/hosts')
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict()
    pbex = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert pbex



# Generated at 2022-06-20 14:17:25.509978
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass


if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-20 14:17:31.026973
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    # setup the playbook objects to execute
    pb1 = Playbook.load(
        os.path.join(os.path.dirname(__file__), '../demos', 'test.yml'),
        variable_manager=variable_manager,
        loader=loader
        )

    pe = PlaybookExecutor(pb1, inventory, variable_manager, loader, [])
    assert pe._playbooks == pb1



# Generated at 2022-06-20 14:17:44.969026
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-20 14:17:46.187528
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass  # nothing to test

# Generated at 2022-06-20 14:17:47.563782
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor = PlaybookExecutor()


# Generated at 2022-06-20 14:17:54.905777
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pb_executor = PlaybookExecutor(['test.yml'], None, None, None, None)

    # case 1:
    # pb_executor._tqm is None
    # pb_executor._playbooks = ['test.yml']
    pb_executor._tqm = None
    pb_executor._playbooks = ['test.yml']
    pb_executor._inventory = Mock()
    pb_executor._inventory.set_playbook_basedir = Mock()
    # pb_executor._inventory.restrict_to_hosts = Mock(return_value=None)
    pb_executor._inventory.remove_restriction = Mock(return_value=None)
    # pb_executor._inventory.get_hosts = Mock(return_value=[

# Generated at 2022-06-20 14:18:06.608293
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    class Options(object):
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        connection = 'ssh'
        module_path = None
        forks = 10
        remote_user = 'root'
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        verbosity = 0
        check = False
        start_at_task = None

        def __init__(self):
            self.inventory = 'ansible/tests/inventory'


# Generated at 2022-06-20 14:18:22.582761
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Debug function cannot be invoked from command line.
    '''
    from ansible import context
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    CLI.parser.parse_args([])
    loader = DataLoader()
    #inventories = args.inventory if args.inventory else '-i hosts'
    inventories = './test/unit/ansible/test_inventory.yaml'
    #inventories = './test/test_inventory.yaml'
    #inventories = './test/test_inventory.ini'
    #inventories = './test/test_inventory.sh'
    inventory = InventoryManager(loader=loader, sources=inventories)

    #playbooks = args.

# Generated at 2022-06-20 14:18:23.310634
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:18:54.987555
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    class fake_self_inventory:
        def __init__(self):
            self._hosts = []
    class fake_self_variable_manager:
        def __init__(self):
            self._vars = []

    class fake_self_loader:
        class fake_self_env:
            class fake_self_collection_list:
                def __init__(self):
                    self.all = []
                def all(self):
                    self.all = True
                    return []

            def __init__(self):
                self.collection_list = fake_self_collection_list()
        def __init__(self):
            self.env = fake_self_env()

    class fake_passwords:
        def __init__(self):
            self.all = []

# Generated at 2022-06-20 14:19:05.626410
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Constructor calls .load on each path in playbooks
    # just make sure those work without errors
    mock_loader = MockLoaderModule()
    mock_inventory = MockInventory()
    mock_variable_manager = MockVarsModule()

    # AnsibleCoreCI - begin
    # TODO: define mock passwords and mock callback plugin
    # passwords = dict()
    # callback_plugin = None
    # AnsibleCoreCI - end

    # AnsibleCoreCI - begin
    # TODO: restore the following line; it's removed for now so that our unit tests pass
    # p = PlaybookExecutor(["test.yml"], mock_inventory, mock_variable_manager, mock_loader, passwords)
    p = PlaybookExecutor(["test.yml"], mock_inventory, mock_variable_manager, mock_loader)
    # Ansible

# Generated at 2022-06-20 14:19:12.010914
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    This is the unittest for unit test of method run of class PlaybookExecutor
    '''
    # Replace the global variable 'C' with a mock object
    # because the global variable 'C' is a module object
    # which make the unit test cannot be controlled.
    class MockModuleC(object):
        '''
        This is a mock class to replace the global variable 'C'
        '''
        def __init__(self):
            pass
        def __getattr__(self, key):
            if key == 'RETRY_FILES_ENABLED':
                return False
            if key == 'RETRY_FILES_SAVE_PATH':
                return None
    c_mock_obj = MockModuleC()
    context.CLIARGS['syntax'] = False
    context.CLIARGS

# Generated at 2022-06-20 14:19:19.176903
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.module_utils.common._collections_compat import MutableMapping

    # fake inventory object
    class FakeInventory(MutableMapping):
        def __init__(self, inventory, loader, variable_manager):
            self

# Generated at 2022-06-20 14:19:21.382400
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    module = AnsibleModule(argument_spec={})
    module.exit_json(changed=False)


if __name__ == '__main__':

    test_PlaybookExecutor()

# Generated at 2022-06-20 14:19:37.815298
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import unittest
    import ansible.module_utils.facts.system.distribution as distro
    from ansible.module_utils.facts.system.distribution import Distribution
    class TestCLIArgs:
        def __init__(self):
            self.ask_pass = True
            self.ask_sudo_pass = True
            self.ask_vault_pass = True
            self.become = True
            self.become_ask_pass = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.connection = 'ssh'
            self.diff = False
            self.extra_vars = []
            self.flush_cache = None
            self.forks = 1
            self.inventory = []
            self.listhosts

# Generated at 2022-06-20 14:19:38.515029
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:19:43.290750
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook = []
    inventory = None
    variable_manager = None
    loader = None
    passwords = {}

    # TEST: constructor without parameters
    res = PlaybookExecutor(playbook, inventory, variable_manager, loader, passwords)
    assert res


# make sure the play tree is correctly constructed when loading playbooks

# Generated at 2022-06-20 14:19:50.401629
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # 该构造方法，仅仅是在环境无法初始化的情况下，完成环境初始化
    if utils.is_ansible_proper():
        return
    pe = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, passwords={})
    pe.run()
    """
    # 构造方法调用链
    pbex = PlaybookExecutor(None, None, None, None, None)
    run(self):
        _run(self):
            _run_playbook()
            _do_cleanup()
    """



# Generated at 2022-06-20 14:19:50.991274
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-20 14:20:26.339456
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    class TaskQueueManager:
        def __init__(self, inventory, variable_manager, loader, passwords=None, forks=None):
            self._inventory = inventory
            self._variable_manager = variable_manager
            self._loader = loader
            self._passwords = passwords
            self._forks = forks

            self._tasks = None
            self._notified_handlers = dict()
            self._failed_hosts = dict()
            self._unreachable_hosts = dict()
            self._stats = dict(processed=dict(failures=0, ok=0, ignored=0, processed=0),
                               dark=dict(failures=0, ok=0, ignored=0, processed=0),
                               failures={}, ok={}, ignored={})
            self.callbacks = defaultdict(list)
            self.list

# Generated at 2022-06-20 14:20:39.295600
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbook_executor = PlaybookExecutor(
        playbooks = path_dwim("YAML_VALID/test.yaml"),
        inventory = InventoryManager(loader=DataLoader()),
        variable_manager = VariableManager(),
        loader = DataLoader(),
        passwords = dict()
    )

    assert playbook_executor.__class__.__name__ == 'PlaybookExecutor'
    assert playbook_executor._playbooks == path_dwim("YAML_VALID/test.yaml")
    assert playbook_executor._inventory.__class__.__name__ == 'InventoryManager'
    assert playbook_executor._variable_manager.__class__.__name__ == 'VariableManager'
    assert playbook_executor._loader.__class__.__name__ == 'DataLoader'
    assert playbook_executor

# Generated at 2022-06-20 14:20:46.329595
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pbex = PlaybookExecutor(playbooks=['/root/ansible/playbook'], inventory=None, variable_manager=None, loader=None, passwords=None)
    pbex1 = pbex.run()
    return pbex1

# Generated at 2022-06-20 14:20:57.636147
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    context.CLIARGS = ImmutableDict(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='smart',
                                    module_path=None, forks=5, private_key_file=None, ssh_common_args=None, ssh_extra_args=None,
                                    sftp_extra_args=None, scp_extra_args=None, become=True, become_method=None,
                                    become_user=None, verbosity=None, check=False, start_at_task=None)
    context.BECOME_PASSWORDS = ImmutableDict()
    playbook = PlaybookExecutor(['test_playbook'], None, None, None, None)
    assert playbook.run() == 0

# Test case for method run of class PlaybookExecutor
#

# Generated at 2022-06-20 14:21:10.400774
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Test method run of class PlaybookExecutor
    '''
    CLIARGS = dict(
        help=1,
        verbosity=3,
        syntax=1,
        step=0,
        force_handlers=0,
        start_at_task=False,
        start_at_play=False,
        listhosts=1,
        listtasks=1,
        listtags=1,
        step_children=0,
        tagging_extra_vars=0,
        forks=5,
        module_path=None,
        diff=0
        )
    context.CLIARGS = CLIARGS
    my_playbook = []
    my_inventory = []
    my_variable_manager = []
    my_loader = None
    my_passwords = {}

# Generated at 2022-06-20 14:21:11.044934
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:21:19.643514
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    passwords = {}
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Test passing empty playbooks
    playbooks = []
    pbex = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert pbex.run() is None
    # Test passing playbooks with empty tasks
    playbooks = ['playbook.yml']

# Generated at 2022-06-20 14:21:26.587167
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    executor = PlaybookExecutor(
        playbooks=['/some/ansible/path'],
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords={}
    )

    assert executor._playbooks == ['/some/ansible/path']
    assert executor._inventory is None
    assert executor._variable_manager is None
    assert executor._loader is None
    assert executor.passwords == {}
    assert executor._unreachable_hosts == {}
    assert executor._tqm is None

# Generated at 2022-06-20 14:21:43.296974
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test method.
    '''
    inv = Sequence()
    inv.add_host('localhost')
    inv.add_host('remote')
    inv.get_host('localhost').set_variable('ansible_connection', 'local')
    inv.get_host('remote').set_variable('ansible_connection', 'ssh')
    inv.get_host('remote').set_variable('ansible_ssh_user', 'root')
    inv.get_host('remote').set_variable('ansible_ssh_pass', 'pass')
    inv.get_host('remote').set_variable('ansible_become', True)
    inv.get_host('remote').set_variable('ansible_become_user', 'becomeuser')

# Generated at 2022-06-20 14:21:44.235632
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:22:23.519770
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
	import unittest
	from unittest import mock
	import os.path
	
	test_inventory = mock.MagicMock(spec=Inventory)
	test_variable_manager = mock.MagicMock(spec=BaseVariableManager)
	test_loader = mock.MagicMock(spec=DataLoader)
	test_passwords = mock.MagicMock()
	
	test_playbook_path = './test_playbooks/test_play.yml'
	if os.path.isfile(test_playbook_path):
		test_playbooks = [test_playbook_path]
	else:
		test_playbooks = ['']
	
	test_executor = PlaybookExecutor(test_playbooks, test_inventory, test_variable_manager, test_loader, test_passwords)

# Generated at 2022-06-20 14:22:32.803215
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """ Unit test for constructor of class PlaybookExecutor """
    test_instance = PlaybookExecutor('fake_playbook_path', 'fake_inventory', 'fake_variable_manager', 'fake_loader', 'fake_password')
    assert test_instance._playbooks == 'fake_playbook_path'
    assert test_instance._inventory == 'fake_inventory'
    assert test_instance._variable_manager == 'fake_variable_manager'
    assert test_instance._loader == 'fake_loader'
    assert test_instance.passwords == 'fake_password'
    assert test_instance._tqm == None


# Generated at 2022-06-20 14:22:43.589692
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # pbex = PlaybookExecutor('playbook', 'inventory', 'variable_manager', 'loader', 'passwords')
    pbex = PlaybookExecutor('playbook', 'inventory', 'variable_manager', 'loader', 'passwords')
    assert isinstance(pbex, PlaybookExecutor)
    assert isinstance(pbex._playbooks, str)
    assert isinstance(pbex._inventory, str)
    assert isinstance(pbex._variable_manager, str)
    assert isinstance(pbex._loader, str)
    assert isinstance(pbex.passwords, str)
    assert isinstance(pbex._unreachable_hosts, dict)
    assert not isinstance(pbex._tqm, None)

# Generated at 2022-06-20 14:22:56.664801
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.listify import listify_lookup_plugin_terms

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    #host_list = ['/home/ganesh/Documents/ansible/ansible-playbook/test_hosts']
    host_list = ['/home/ganesh/Documents/ansible/ansible-playbook/inventory']
    for host in host_list:
        inventory.add_host(host)

# Generated at 2022-06-20 14:23:04.851260
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    module_loader = DictDataLoader({'test': 'hello'})
    playbook_path = u'test.yml'
    inventory = InventoryManager(loader=module_loader, sources=u'/dev/null')
    variable_manager = VariableManager(loader=module_loader, inventory=inventory)

    pbex = PlaybookExecutor(
        playbooks=[playbook_path],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=module_loader,
        passwords={}
    )
    assert pbex is not None

# Generated at 2022-06-20 14:23:08.535534
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbookExecutor = PlaybookExecutor("", "", "", "", "")
    playbookExecutor._generate_retry_inventory("abc", "abc")
    playbookExecutor.run()

# Generated at 2022-06-20 14:23:10.201471
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for constructor of class PlaybookExecutor
    '''
    pass

# Generated at 2022-06-20 14:23:16.307703
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #mock_loader = mock.MagicMock()
    #mock_loader.list_templates.return_value = []
    #p = PlaybookExecutor(playbooks=['/tmp/playbook.yaml'], inventory='/tmp/inventory.yaml', variable_manager=None, loader=mock_loader, passwords=None)
    #p.run()
    #mock_loader.list_templates.assert_called()
    pass

# Generated at 2022-06-20 14:23:19.350803
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    PBexec = PlaybookExecutor()
    PBexec.run()
    

# Generated at 2022-06-20 14:23:26.693869
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    """
    Test that the public method `run` of
    :class:`ansible.executor.playbook.PlaybookExecutor()`
    does not raise any exceptions.
    """
    # Create an instace of PlaybookExecutor and call method `run`.
    PlaybookExecutor(
        playbooks=None,
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
    ).run()

# Generated at 2022-06-20 14:24:02.051567
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # mock_playbooks = [
    #     {'tasks': [{'include': 'include_me.yml'}]},
    #     {'tasks': [{'include': 'include_me.yml'},
    #                {'include': 'include_me_too.yml'}]}
    # ]

    mock_playbooks = [
        'playbook.yml'
    ]

    mock_inventory = {
        'file': 'file.yml',
        'hosts': [],
        'vars': {}
    }

    mock_variable_manager = {
        'hosts': 'hosts.yml',
        'vars': 'vars.yml'
    }

    mock_loader = 'loader'


# Generated at 2022-06-20 14:24:10.058500
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    This test will call constructor of class PlaybookExecutor and check it is created properly
    '''
    # pylint: disable=W0613
    playbooks = ''
    inventory = ''
    variable_manager = ''
    loader = ''
    passwords = ''
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert playbook_executor is not None


# Generated at 2022-06-20 14:24:16.981521
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create a empty test instance
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._options = {'listtasks': True }
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'dummy'}
    passwords = {}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/unit/inventory_export')
    playbooks = ["test_playbook.yml"]
    playbookExecutor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    playbookExecutor.run()


# Generated at 2022-06-20 14:24:23.321556
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    def test_class_PlaybookExecutor():
        print("\n{0}".format("*"*80))
        print("{0}".format("*"*80))
        print("\n{1}\nTest PlaybookExecutor Class\n{0}\n{2}".format('*'*80, '*'*80, '*'*80))

        # Create a variables class to hold the variables for the inventory.
        # We need to do this so that we can create our inventory..
        variables = VariableManager()
        # Create a loader class to load our plugins.
        loader = DataLoader()
        # Create the inventory.
        inventory = Inventory(loader=loader, variable_manager=variables, host_list='/Users/dylan/PycharmProjects/ansible_task/inventory')

# Generated at 2022-06-20 14:24:34.897536
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader

    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lib','ansible','modules', 'core'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lib','ansible','modules', 'extras'))

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-20 14:24:43.856962
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    PlaybookExecutor(playbooks=["/opt/ansible-runner/tests/data/playbook"], inventory=None, variable_manager=None, loader=None, passwords=False)
    test_PlaybookExecutor = PlaybookExecutor(playbooks=["/opt/ansible-runner/tests/data/playbook"], inventory=None, variable_manager=None, loader=None, passwords=False)
    test_PlaybookExecutor.run()

# Generated at 2022-06-20 14:24:54.795269
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #These are the parameters we have to pass to PlaybookExecutor.__init__
    #FIXME - playbooks will throw exception if no file exists
    #      - inventory - creates the invetory we need to run tests
    
    #a temporary file to store a playbook
    playbook_file = tempfile.NamedTemporaryFile(delete=False)
    # The playbook that is written to the tempfile
    playbook_file.write(b'---\n- hosts: test\n  tasks:\n    - name: test fn\n      debug:\n        msg: \'hello there\'\n')
    playbook_file.close()
    # the list of playbooks to run
    playbooks = [playbook_file.name]

    #an inventory file - to be passed to create an inventory

# Generated at 2022-06-20 14:25:07.506309
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    playbooks = ['test.yml']
    inventory = Inventory()
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}

    # create a PlaybookExecutor object
    x = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    # test _playbooks
    assert x._playbooks == playbooks
    # test _inventory
    assert x._inventory == inventory
    # test _variable_manager
    assert x._variable_manager == variable_manager
    # test _loader
    assert x._loader == loader
    # test _tqm
    assert x._tqm == None
    # test _unreachable_hosts
    assert type(x._unreachable_hosts) is dict
    assert x._unreachable_hosts == {}


# Generated at 2022-06-20 14:25:13.835303
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    
    # Variables initialization
    inventory = 'inventory'
    variable_manager = 'variable_manager'
    loader = 'loader'
    passwords = 'passwords'
    playbooks = ['playbooks1']
    # Execute the method under test
    result = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords).run()

    # Check the result
    print('--- The result of unit test on PlaybookExecutor_run is: ' + str(result))
    assert result != 0


# Generated at 2022-06-20 14:25:20.167549
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for constructor of class PlaybookExecutor
    '''
    pb_executor = PlaybookExecutor([], [], [], [], [])
    if pb_executor is not None:
        return True
    else:
        return False