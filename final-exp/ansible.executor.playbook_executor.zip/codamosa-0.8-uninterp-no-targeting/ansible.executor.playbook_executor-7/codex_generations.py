

# Generated at 2022-06-20 14:15:59.696757
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Might need these when testing
    #from ansible.plugins.loader import vault_secrets, module_loader

    # Initialize values that are used in later tests
    playbook_file_name = 'test_playbook1.yml'
    playbooks = [playbook_file_name]
    inventory = None
    variable_manager = None
    loader = None
    passwords = None

    # Create test variables
    obj = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    pb_executor = obj.run()
    assert pb_executor == 0

    # Delete test variables
    del obj
    del pb_executor


# Generated at 2022-06-20 14:16:14.332693
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # the ansible-playbook command needs a list of playbooks
    # check if the command line argument is a list
    assert type([]) == type(context.CLIARGS['args'])

    # check if the command line argument is a list of file paths
    for arg in context.CLIARGS['args']:
        assert os.path.isfile(arg)

    # get variables from the inventory file
    variable_manager = VariableManager(loader=context.CLIARGS['loader'], inventory=context.CLIARGS['inventory'])
    # get the passwords from the CLI options
    passwords = {}

    # create a PlaybookExecutor object

# Generated at 2022-06-20 14:16:21.826284
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import collections
    import sys
    import os
    import tempfile
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # In Python 2, StringIO also has a close method

# Generated at 2022-06-20 14:16:33.049952
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-20 14:16:36.315463
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pb_e = PlaybookExecutor()
    pb_e.run()


if __name__ == '__main__':
    pb_e = PlaybookExecutor()
    pb_e.run()

# Generated at 2022-06-20 14:16:50.427122
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    myPlaybookExecutor = PlaybookExecutor()
    assert myPlaybookExecutor._playbooks == []
    assert myPlaybookExecutor._inventory == ''
    assert myPlaybookExecutor._variable_manager == ''
    assert myPlaybookExecutor._loader == ''
    assert myPlaybookExecutor.passwords == {}
    assert myPlaybookExecutor._unreachable_hosts == {}
    assert myPlaybookExecutor._tqm == None

    myPlaybookExecutor = PlaybookExecutor([], [], [], [], {})
    assert myPlaybookExecutor._playbooks == []
    assert myPlaybookExecutor._inventory == []
    assert myPlaybookExecutor._variable_manager == []
    assert myPlaybookExecutor._loader == []
    assert myPlaybookExecutor.passwords == {}
    assert myPlaybook

# Generated at 2022-06-20 14:16:52.319874
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO: implement test_PlaybookExecutor_run
    pass

# Generated at 2022-06-20 14:16:52.837218
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:17:08.250267
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    def test_display_do_var_prompt():
        display.do_var_prompt = Mock()
        return display.do_var_prompt

    playbook_path = 'playbook.yml'
    play = Mock()
    play.post_validate = Mock()
    play.get_plays = Mock(return_value=[play])
    pb = Mock()
    pb.get_plays = Mock(return_value=[play])
    pb.load = Mock(return_value=pb)
    # tests for when tqm is None
    loader = Mock()
    loader.list_templates = Mock(return_value=[])
    loader.list_roles = Mock(return_value=[])
    runner = Mock()
    runner._tqm = None
    runner.task_executor = Mock()

   

# Generated at 2022-06-20 14:17:18.226557
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader
    connection_loader.all()

    # test failing playbook
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost", "localhost"])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-20 14:17:47.315723
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook = ['localhost.yml','salt-master','salt-minion','salt-syndic','salt-ssh','salt','salt-cloud']
    inventory = Hosts.all()
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}
    pb = PlaybookExecutor(playbook=playbook, inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords)
    pb.run()
    #assert playbook == PlaybookExecutor.playbooks, 'Playbook variable test passed'


# Generated at 2022-06-20 14:18:03.725441
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import json
    import logging

    logger = logging.getLogger('test_PlaybookExecutor_run')
    logger.setLevel(logging.DEBUG)

    log_file_name = 'test_PlaybookExecutor_run.log'
    log_handler = logging.FileHandler(log_file_name)
    log_handler.setLevel(logging.DEBUG)

    log_formatter = logging.Formatter(
        '%(asctime)s - %(funcName)s:%(lineno)s - %(levelname)s - %(message)s',
        datefmt='%m/%d/%Y %I:%M:%S %p'
    )
    log_handler.setFormatter(log_formatter)
    logger.addHandler(log_handler)

# Generated at 2022-06-20 14:18:11.653847
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import os
    import sys
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import connection_loader, shell_loader, become_loader
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

    display = Display()

    # Create playbooks
    current_dir = os.getcwd()
    playbook_dir = os.path.join(current_dir, 'tests/integration/playbooks')

# Generated at 2022-06-20 14:18:23.246465
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #playbooks = "../test/test_data/test_ansible_playbook.yml"
    #inventory = "../test/test_data/pattern_hosts"
    #variable_manager = "../test/test_data/pattern_hosts"
    #loader = "../test/test_data/pattern_hosts"
    #password = "../test/test_data/pattern_hosts"
    # PlaybookExecutor(playbooks,inventory,variable_manager,loader,password)
    # PlaybookExecutor.run(PlaybookExecutor)
    # pass
    assert 1 == 1


# test case for class PlaybookExecutor

# Generated at 2022-06-20 14:18:32.717121
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Run normal run.
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    class Display:
        def warning(self, msg):
            print(msg)

    display = Display()

    playbooks = ['../../../test/ansible-starter/ansible-starter-master/site.yml']
    inventory = InventoryManager(loader='ansible.parsing.dataloader.DataLoader', sources=['../../../test/ansible-starter/ansible-starter-master/inventory/'])
    variable_manager = VariableManager(loader='ansible.parsing.dataloader.DataLoader', inventory=inventory)
    loader = Data

# Generated at 2022-06-20 14:18:45.551909
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """
    This is a test of the PlaybookExecutor class. It checks the correct
    initialization of the object.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory

    def dummysend_callback(command):
        pass

    def dummyload_callbacks():
        pass

    def dummy_cleanup():
        pass

    def dummy_cleanup_all_tmp_files():
        pass

    display = Display()
    play_context = PlayContext(play_context=PlayContext())

# Generated at 2022-06-20 14:19:01.763237
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    ### initialize options
    options = Options()

    options.listhosts = False
    options.listtasks = False
    options.listtags = False
    options.syntax = False
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 5
    options.remote_user = 'root'
    options.private_key_file = None
    options.ssh_common_args = ''
    options.ssh_extra_args = ''
    options.sftp_extra_args = ''
    options.scp_extra_args = ''
    options.become = False
    options.become_method = 'sudo'
    options.become_user = ''
    options.verbosity = 0
    options.check = False
    options.extra_vars = []
    options.extra

# Generated at 2022-06-20 14:19:12.044396
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    """
    This is the test case for testing the constructor of class PlaybookExecutor
    :return:
    """
    playbooks = ['/home/ansible/playbooks/simple.yml']
    inventory_path = '/etc/ansible/hosts'
    variable_manager = VariableManager(loader=None)
    loader = DataLoader()
    passwords = []
    pbex = PlaybookExecutor(playbooks, inventory_path, variable_manager, loader, passwords)
    assert pbex


# Generated at 2022-06-20 14:19:12.927791
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


#

# Generated at 2022-06-20 14:19:22.836692
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Test with valid parameter
    playbooks = ["../../docs/playbook_structure.rst"]
    # Create inventory object
    test_inventory = InventoryManager(loader=None, sources=["localhost,"])
    # Create variable manager object
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}
    pbex = PlaybookExecutor(playbooks, test_inventory, variable_manager, loader, passwords)
    assert pbex.run() == 0, "Successfully ran the playbook_structure.rst playbook"
    # Test with invalid parameter
    playbooks = ["NotValidPlaybook"]
    # Create inventory object
    test_inventory = InventoryManager(loader=None, sources=["localhost,"])
    # Create variable manager object
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords

# Generated at 2022-06-20 14:19:50.022391
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("testing playbookexecutor")
    loader = DataLoader()
    passwords = dict(vault_pass='secret')

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = PlaybookExecutor(
        playbooks=['site.yml'],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords
    )

    playbook.run()

if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-20 14:19:58.082877
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    import ansible.utils.plugin_docs

    playbook = ''
    inventory = ansible.inventory.InventoryManager(loader=ansible.loader.DataLoader(), sources='')
    variable_manager = ansible.vars.VariableManager(loader=ansible.loader.DataLoader(), inventory=inventory)
    loader = ansible.loader.DataLoader()
    passwords = {}

    pbe = PlaybookExecutor(playbook, inventory, variable_manager, loader, passwords)
    assert pbe != None

# Generated at 2022-06-20 14:20:08.295572
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # 实现需求
    # 1、执行playbooks，并且返回结果
    # 2、有可能附带--list-hosts、--list-tasks、--list-tags、--syntax

    # 创建实例
    playbooks = ['playbook1.yml']
    inventory_path = '/etc/ansible/hosts'
    inventory = Inventory(loader=None, variable_manager=None, host_list=inventory_path)
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}

# Generated at 2022-06-20 14:20:21.584454
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    cur_dir = os.getcwd()
    path = os.path.join(cur_dir, 'playbook.yml')
    inventory_path = os.path.join(cur_dir, 'inventory')
    loader = DataLoader()
    passwords = {}
    variable_manager = VariableManager()

    # read ansible.cfg
    #config_file = ansible.constants.CONFIG_FILE_PATH
    config_file = '/etc/ansible/ansible.cfg'
    default_vars = VariableManager()
    default_vars._extra_vars = {
        'ansible_config': config_file,
        'ansible_config_file': config_file
    }

# Generated at 2022-06-20 14:20:24.924757
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    def func():
        pass

    e = PlaybookExecutor(
        [],
        Inventory("/tmp/"),
        VariableManager(),
        func,
        func,
    )
    assert isinstance(e, PlaybookExecutor)
# ----

# Generated at 2022-06-20 14:20:33.679634
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = InventoryManager(loader=None, sources="")
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None
    passwords = None
    playbooks = [ "../../tests/test_playbook_executor.yml" ]
    pe = PlaybookExecutor(playbooks=playbooks, inventory=inventory, variable_manager=variable_manager, loader=loader, passwords=passwords)
    print(pe.run())


# Generated at 2022-06-20 14:20:34.526154
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-20 14:20:35.682928
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass



# Generated at 2022-06-20 14:20:36.502184
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:20:50.278346
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible.constants import DEFAULT_TRANSPORT
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)
    transport = DEFAULT_TRANSPORT


# Generated at 2022-06-20 14:21:20.493946
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    #set up playbooks
    all_playbooks = []
    Inventory = None
    VariableManager = None
    loader = None
    inventory = None
    pbex = PlaybookExecutor(all_playbooks, Inventory, VariableManager, loader, None)
    #if call method run without setting playbooks
    try:
        pbex.run()
    except SystemExit as e:
        assert e.code == 4
    except Exception as e:
        assert e.args[0] == 'No playbook specified'
    #set up playbooks
    all_playbooks = ['test_playbook']
    pbex = PlaybookExecutor(all_playbooks, Inventory, VariableManager, loader, None)
    try:
        pbex.run()
    except SystemExit as e:
        assert e.code == 4

# Generated at 2022-06-20 14:21:23.565202
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # create a test PlaybookExecutor
    pe = PlaybookExecutor([], None, None, None, None)
    
    # TODO:
    # Add assertions
    
    return 0

# Generated at 2022-06-20 14:21:24.715409
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    assert PlaybookExecutor.run()

# Generated at 2022-06-20 14:21:32.292398
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    args_list = [ "-i", "./test_inventory", "-e", "test_extra_vars", "./test_playbooks/test_playbook1.yml", "./test_playbooks/test_playbook2.yml"  ]
    cliargs = parser.parse_args(args_list)
    loader = DataLoader()
    host_list = loader.load_from_file(cliargs['inventory'])

    inventory = Inventory(loader=loader, host_list=host_list, vault_password=None)

    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-20 14:21:45.780814
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():

    # Prompt
    def my_do_var_prompt(vname, private, prompt, encrypt, confirm, salt_size, salt, default, unsafe):
        return  "value"

    # stats callback
    def v2_playbook_on_stats(stats):
        x = 0

    # Run failed hosts callback
    def v2_playbook_on_no_hosts_matched():
        x = 0

    # Inventory restriction callback
    def v2_playbook_on_play_start(play):
        x = 0

    # on_vars_prompt callback
    def v2_playbook_on_vars_prompt(vname, private, prompt, encrypt, confirm, salt_size, salt, default, unsafe):
        x = 0

    # handlers callback

# Generated at 2022-06-20 14:21:57.365087
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-20 14:21:58.087271
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:22:06.893578
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import builtins
    builtins.display = Display()
    # FIXME: Create inventory object
    fake_inventory={}
    # FIXME: Create variable manager object
    fake_variable_manager={}
    # FIXME: Create loader object
    fake_loader={}
    # FIXME: Create passwords object
    fake_passwords={}

    from ansible.parsing.dataloader import DataLoader
    fake_loader = DataLoader()

    from ansible.vars.manager import VariableManager
    fake_variable_manager = VariableManager()


    playbook_executor = PlaybookExecutor(
        [{}],fake_inventory,fake_variable_manager,fake_loader,fake_passwords
    )

    # FIXME: Add tests
    assert playbook_executor.run() == 0

test_PlaybookExecutor

# Generated at 2022-06-20 14:22:17.158333
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    inventory = InventoryManager()
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory.add_host(Host("127.0.0.1"))
    inventory.add_host(Host("127.0.0.2"))
    inventory.add_host(Host("127.0.0.3"))

    pb = PlaybookExecutor(
        playbooks=[
            "../tests/test_playbook.yml"
        ],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords={}
    )
    pb.run()


if __name__ == '__main__':
    test_PlaybookExecutor()

# Generated at 2022-06-20 14:22:22.737180
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    test_executor = PlaybookExecutor("test_playbook.yml","test_inventory.yml",None,None,None)
    #Test with retry file save path 
    context.CLIARGS['retry_files_save_path']=True
    result = test_executor.run()
    assert result == 0


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-20 14:22:59.814388
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # Create a PlaybookExecutor for testing
    playbooks = ['C:\\Users\\Administrator\\Desktop\\FLE\\Ansible\\ansible-2.8\\test.yml']
    inventory = Inventory(host_list='C:\\Users\\Administrator\\Desktop\\FLE\\Ansible\\ansible-2.8\\hosts')
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    pe = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    # Get the result of tests
    pe.run()

# Generated at 2022-06-20 14:23:13.058737
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    This method unit test the run method of the PlaybookExecutor class
    '''
    display = Display()
    display.verbosity = 2

    # mocked inventory
    inventory = mock.MagicMock()
    # mocked loader
    loader = mock.MagicMock()
    # mocked variable manager
    variable_manager = mock.MagicMock()
    # mocked passwords
    passwords = mock.MagicMock()
    # mocked task queue manager
    tqm = mock.MagicMock()

    # Initializing the object
    pe = PlaybookExecutor(playbooks=[], inventory=inventory, loader=loader,
                          variable_manager=variable_manager, passwords=passwords)
    pe._tqm = tqm

    # Testing the run method
    pe.run()
    tqm.cleanup.assert_called

# Generated at 2022-06-20 14:23:13.730319
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-20 14:23:24.691920
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    # FIXME: need to mock TaskQueueManager and _get_serialized_batches()
    # FIXME: need to test return codes
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    passwords = dict()
    playbooks = ['../../../test/integration/targets/inventory_hostname/hostname.yml']
    # FIXME: What is wrong with Ansible 2.9, 2.10 that this is failing?
    #        Should this be using the FixtureLoader?


# Generated at 2022-06-20 14:23:32.929397
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import AnsibleRunner.run
    import sys

    # Set arguments

# Generated at 2022-06-20 14:23:37.071714
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
        fail()



# Generated at 2022-06-20 14:23:42.806431
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    p = PlaybookExecutor(
        playbooks=['example.yml'],
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=None,
        passwords=None
    )
    '''
    pass


# Generated at 2022-06-20 14:23:44.074134
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass


# Generated at 2022-06-20 14:23:51.594895
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = Inventory('localhost,127.0.0.1,')
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = {}
    playbooks = ['tests/fixtures/test_playbook.yml']
    playbook_executor = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    assert playbook_executor.run() == [{'playbook': 'tests/fixtures/test_playbook.yml', 'plays': []}]

# Generated at 2022-06-20 14:23:56.336831
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    assert PlaybookExecutor

# Generated at 2022-06-20 14:24:39.512963
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''unit test for class PlaybookExecutor
    '''
    # empty setup
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    # test when inventory is empty
    pbex = PlaybookExecutor([BASE_CODE_DIR + "/examples/playbook.yml"], inventory, variable_manager, loader, None)
    assert pbex is not None

    # try real setup
    hosts = 'localhost,'
    variable_manager.extra_vars = {'hosts': hosts}

    # test when inventory is not empty
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=hosts.split(','))

# Generated at 2022-06-20 14:24:51.592853
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Init playbook_executor
    playbooks = {'playbook': 'test.yml'}

# Generated at 2022-06-20 14:25:01.949783
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print(">>>>>>>>>>>>>>>>>>>>  test_PlaybookExecutor START  >>>>>>>>>>>>>>>>>>>>")

    # playbooks = ["./linux-setup-tasks.yml"]
    # inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    # variable_manager = VariableManager()
    # loader = None
    # passwords = {}

    playbooks = ["./linux-setup-tasks.yml"]
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    variable_manager = VariableManager()
    loader = None
    passwords = {}

    # PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    pbexec = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)

    # pbexec.run()
    pbexec.run()

   

# Generated at 2022-06-20 14:25:10.350118
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    PLAYBOOK = os.path.join(os.path.dirname(__file__), 'test_playbooks/playbook_test.yml')
    INVENTORY = os.path.join(os.path.dirname(__file__), 'test_playbooks/inventory_test.yml')
    VARIABLE = {'host': 'host_test'}

    play = PlaybookExecutor(playbooks=[PLAYBOOK], inventory=Inventory(INVENTORY),
                            variable_manager=VariableManager(), loader=None, passwords=None)
    assert not play._tqm

# Generated at 2022-06-20 14:25:24.609426
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory_dir = os.path.dirname(os.path.dirname(__file__)) + os.sep + 'inventory'
    inventory = InventoryManager(loader=DataLoader(), sources=inventory_dir)
    variables = VariableManager()
    loader = DataLoader(inventory=inventory)
    passwords = {'conn_pass': '', 'become_pass': '', 'become_method': ''}

    repo_path = os.path.dirname(__file__)
    playbook_path = repo_path + os.sep + "playbook.yml"
    playbooks = [playbook_path]

    playbook_executor = PlaybookExecutor(playbooks=playbooks, inventory=inventory, variable_manager=variables,
                                              loader=loader, passwords=passwords)
    res = playbook_executor.run()