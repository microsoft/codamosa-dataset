

# Generated at 2022-06-10 23:23:40.340437
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    loader=DictDataLoader({
        "test.yml": """
---
- name: test
  hosts: localhost
  tasks:
    - debug:
        msg: "This is a test"
"""
    })
    inventory = InventoryManager([
        'localhost',
    ], loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    passwords = dict()

    pb = PlaybookExecutor([
        'test.yml',
    ], inventory, variable_manager, loader, passwords)

    res = pb.run()



# Generated at 2022-06-10 23:23:41.667686
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-10 23:23:48.455987
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    print("testing PlaybookExecutor")
    class FakeInventory:
        def __init__(self, * ,host_list):
            self.host_list = host_list

        def get_hosts(self, pattern="all"):
            return self.host_list

    class FakeOptions:
        def __init__(self, playbook_path, tags, start_at_task, limit, forks):
            self.playbook_path = playbook_path
            self.tags = tags
            self.start_at_task = start_at_task
            self.limit = limit
            self.forks = forks


# Generated at 2022-06-10 23:23:49.184513
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:23:50.066119
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:23:55.798493
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.playbook.playbook import Playbook
    Playbook_instance = Playbook.load()
    PlaybookExecutor_instance = PlaybookExecutor(playbook_instance)
    PlaybookExecutor_instance.run()


if __name__ == '__main__':
    # Unit test for class PlaybookExecutor
    #test_PlaybookExecutor_ctor()
    # Unit test for method run of class PlaybookExecutor
    test_PlaybookExecutor_run()

# Generated at 2022-06-10 23:23:57.206207
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:24:10.179409
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Initialize the Ansible inventory
    init_ansible_test_inventory()

    # Initialize the Ansible loader
    init_ansible_test_loader()

    # Get the Ansible global variables
    ansible_global_vars = context.CLIARGS.get('extra_vars')

    # Create the variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = ansible_global_vars

    # Initialize the Ansible configuration
    init_ansible_test_config()

    # Set C.RETRY_FILES_ENABLED to False
    C.RETRY_FILES_ENABLED = False
    # Set C.RETRY_FILES_SAVE_PATH to empty string
    C.RETRY_FILES_SAVE_PATH = ''

    # Create an empty

# Generated at 2022-06-10 23:24:16.943026
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pbex = PlaybookExecutor(
        './test/unit/ansible_module_meta/',
        './test/unit/ansible_module_meta/',
        'test',
    )

    assert pbex.pb is not None
    assert pbex.pb.inventory._basedir is not None
    assert pbex.pb.inventory._loader is not None
    assert pbex.pb.inventory.get_groups() is not None

# Generated at 2022-06-10 23:24:22.095501
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ['test.yaml']
    inventory = ''
    variable_manager = ''
    loader = ''
    passwords = ''
    pbex = PlaybookExecutor(playbooks,inventory,variable_manager,loader,passwords)
    # Test with valid input
    assert pbex.run() == 0
    # Test with invalid input
    assert pbex.run() == 0

# Generated at 2022-06-10 23:24:50.847422
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:24:59.800626
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    host = Host('test_host')
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'hosts': 'test_host'}
    playbooks = ['test_host']
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=playbooks)

    passwords = dict()
    p = PlaybookExecutor(
        playbooks,
        inventory,
        variable_manager,
        loader,
        passwords,
    )
    assert p.run() == 0


# Generated at 2022-06-10 23:25:02.584485
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    result = 2
    playbook_executor = None
    playbook_executor = PlaybookExecutor(None, None, None, None, None)
    assert result == playbook_executor.run()


# Generated at 2022-06-10 23:25:07.344935
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    playbook = PlaybookExecutor(playbooks=['/home/wanghao/learning/python_learning/ansible/playbooks/learning_playbook.yml'], inventory=inventory, variable_manager=variable_manager, loader=None, passwords=None)
    playbook.run()

if __name__ == '__main__':
    test_PlaybookExecutor_run()

# Generated at 2022-06-10 23:25:20.350548
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print ("Running unit test for method run of class PlaybookExecutor")
  
    # Set up mock inventory and variable manager
    mock_inventory = Mock(spec=InventoryManager)
    mock_variable_manager = Mock(spec=VariableManager)
    mock_loader = Mock(spec=DataLoader)
    mock_password = dict(conn_pass=dict())
    mock_passwords = Mock(spec=dict)
    mock_passwords.copy.return_value = mock_password
    
    # Create mock objects and set instance variables
    mock_playbook = Mock(spec=Playbook)
    mock_playbook.get_plays.return_value = [mock_playbook]
    mock_playbook.post_validate.return_value = None
    mock_playbook._included_path = None
    mock_playbook._based

# Generated at 2022-06-10 23:25:30.576379
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # We need to define some classes that are required in the method call.
    # Since the method reads from local files, we can use a directory containing example ansible files
    test_dir = '/home/will/workspace/ansible/test/integration/targets'
    assert os.path.isdir(test_dir)

    # First we need a loader
    loader = DataLoader()

    # No we need a variable manager
    variable_manager = VariableManager()

    # Now we need an inventory
    inventory = InventoryManager(loader, None, None)
    inventory_path = os.path.join(test_dir, 'inventory')
    assert os.path.isfile(inventory_path)
    inventory.read_inventory_from_file(inventory_path)
    # Now we need an array of playbooks

# Generated at 2022-06-10 23:25:42.899083
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for PlaybookExecutor class constructor
    '''

    args = ['./test_data/test_playbook_adhoc_1.yml']
    context.CLIARGS = ImmutableDict(connection='smart',
                                       forks=10,
                                       become=False,
                                       become_method=None,
                                       become_user=None,
                                       check=False,
                                       diff=False,
                                       listhosts=False,
                                       listtasks=False,
                                       listtags=False,
                                       syntax=False,
                                       verbosity=0)
    passwords = {}
    exec_once = True
    playbooks = []

# Generated at 2022-06-10 23:25:43.611031
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:25:55.660781
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStdin

    test_data_path = os.path.realpath(os.path.join(__file__, u'../../../data'))
   

# Generated at 2022-06-10 23:25:58.177662
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Test whether the task queue manager of the executor can return a queue from the run of the executor.
    '''
    pass

# Generated at 2022-06-10 23:26:31.208181
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass


# Generated at 2022-06-10 23:26:36.972435
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Check execution without any input args
    playbooks = [None]
    inventory = None
    variable_manager = None
    loader = None
    passwords = None
    test_obj = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    try:
        test_obj.run()
    except Exception as err:
        # This is expected when there is no playbook provided
        #assert False, "Unexpected Exception: {}".format(err)
        assert True

# Generated at 2022-06-10 23:26:47.428277
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # ansible-playbook playbook/t.yml -i inventory/t.ini -t web
    playbooks = ['playbook/t.yml']
    inventory_file = InventoryManager(loader=Loader(), sources=['inventory/t.ini'])
    variable_manager = VariableManager(loader=Loader(), inventory=inventory_file)
    passwords = dict(vault_pass='secret')
    loader = DataLoader()
    pbex = PlaybookExecutor(playbooks, inventory_file, variable_manager, loader, passwords)
    res = pbex.run()
    # print(json.dumps(res))


# Generated at 2022-06-10 23:26:55.727401
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    # Create dummy inventory
    class Host(object):
        def __init__(self, name):
            super(Host, self).__init__()
            self.name = name

    class Group(object):
        def __init__(self):
            super(Group, self).__init__()
            self.hosts = dict()

        def add_host(self, host):
            self.hosts[host.name] = host

    class Inventory(object):
        def __init__(self, host_group=None):
            super(Inventory, self).__init__()
            self.groups = dict()
            self.vars = dict()
            if host_group is not None:
                self.groups[host_group] = Group()


# Generated at 2022-06-10 23:27:07.043479
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    print("Testing PlaybookExecutor.run()")
    import ansible.inventory
    import ansible.vars
    import ansible.parsing.dataloader
    import ansible.playbook
    print("---| test case 1: |---")
    print("Testing with valid input data")
    print("---| Expected result: |---")
    print("600")
    print("---| Actual result: |---")
    data = ansible.vars.VariableManager()
    ansible_inventory = ansible.inventory.Inventory(loader=ansible.parsing.dataloader.DataLoader())

# Generated at 2022-06-10 23:27:15.087386
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    import os
    import sys

    # Ansible options

# Generated at 2022-06-10 23:27:15.707165
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:27:16.271941
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:27:27.446160
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    # prepare all fixtures
    context.CLIARGS = ImmutableDict(connection='smart', forks=10, become=False,
                                    become_method=None, become_user=None, check=False, diff=False,
                                    syntax=False, start_at_task=False)

    display.verbosity = 3
    inventory = InventoryManager(loader=None, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()

    passwords = {}
    # instantiate ansible playbook executor
    pbex = PlaybookExecutor(playbooks=['tests/playbook_syntax.yml'], inventory=inventory,
                            variable_manager=variable_manager, loader=loader, passwords=passwords)
    # run ansible playbook

# Generated at 2022-06-10 23:27:38.230641
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Inject a mocked AnsibleOptions object into the context to prevent
    # the creation of an instance of the class.
    options = mock.Mock()
    context.CLIARGS = options
    # Inject a mocked AnsibleConfig object into the context to prevent
    # the creation of an instance of the class.
    config = mock.Mock()
    context.CLICONF = config
    # Inject the mocked AnsibleOptions object into the context again
    # but with a specific set of values.
    options.listhosts = False
    options.listtasks = False
    options.listtags = False
    options.syntax = False
    options.ask_pass = False
    options.ask_su_pass = False
    options.ask_sudo_pass = False
    options.ask_vault_pass = False
    options

# Generated at 2022-06-10 23:28:09.202300
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pbex = PlaybookExecutor()
    pbex.run()


# Generated at 2022-06-10 23:28:10.742882
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    This is the test of class PlaybookExecutor.
    '''
    assert False

# Generated at 2022-06-10 23:28:12.576802
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    unit test to test the method run of class PlaybookExecutor
    '''
    pass


# Generated at 2022-06-10 23:28:24.133954
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbooks = ['~/ansible/ansible/lib/ansible/modules/net_tools/checkpoint/fw1_rulebase.py']
    inventory = [{'hosts': ['inventory'], 'vars': {'a': 'b'}}]
    variable_manager = ['~/ansible/ansible/plugins/callback/__init__.py']
    loader = ['~/ansible/ansible/plugins/__init__.py']
    passwords = ['~/ansible/ansible/plugins/inventory/script.py']

    # Run the method under test
    ansible_result = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)


###############
# BEGIN UNIT TESTS
###############

# Generated at 2022-06-10 23:28:34.262213
# Unit test for method run of class PlaybookExecutor

# Generated at 2022-06-10 23:28:46.674720
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.ssh_functions import set_default_transport
    inventory_file_path = os.path.join(os.getcwd(), 'tests', 'inventory')
    host_file_path = os.path.join(inventory_file_path, 'hosts.yml')
    loader = DataLoader()
    passwords = {}
    inv_manager = InventoryManager(loader=loader, sources=[host_file_path])
    inv_manager.clear_pattern_cache()
    inv_manager.parse_inventory()
    display = Display()
    set_default_transport()
    variable_manager

# Generated at 2022-06-10 23:28:56.886405
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_executor = PlaybookExecutor(["test_file.txt"],"inventory","variable_manager","loader","password")
    playbook_executor._inventory = "inventory"
    playbook_executor._variable_manager = "variable_manager"
    playbook_executor._loader = "loader"
    playbook_executor.passwords = "password"
    playbook_executor._unreachable_hosts = {"unreachable_hosts":"unreachable_hosts"}
    playbook_executor._tqm = TaskQueueManager(inventory="inventory",variable_manager="variable_manager",loader="loader",passwords="password")
    playbook_executor._tqm.load_callbacks()
    playbook_executor._tqm.send_callback('v2_playbook_on_start', "test_file.txt")
    playbook_exec

# Generated at 2022-06-10 23:29:09.480361
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    playbook_list_path = 'playbook_list'
    hosts_list_path = 'hosts_list'
    playbook_list = [playbook_list_path]
    fake_playbook_obj = FakePlaybook(playbook_list)
    fake_inventory_obj = FakeInventory(hosts_list_path)
    fake_variable_manager_obj = FakeVariableManager()
    fake_loader_obj = FakeLoader()
    fake_passwords_obj = FakePasswords()
    fake_playbook_executor_obj = PlaybookExecutor(fake_playbook_obj.playbooks, fake_inventory_obj.inventory, fake_variable_manager_obj.variable_manager, fake_loader_obj.loader, fake_passwords_obj.passwords)
    fake_playbook_executor_obj.run()

# Testing

# Generated at 2022-06-10 23:29:17.092948
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=[])
    inventory.set_variable("ansible_ssh_host", "localhost")

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    p = PlaybookExecutor([], inventory, variable_manager, loader, "")
    assert type(p) == PlaybookExecutor
    assert p._playbooks == []
    assert p._inventory == inventory
    assert p._variable_manager == variable_manager
    assert p._loader == loader
    assert p.passwords == ""
    assert p._unreachable_hosts == {}
    assert p._tqm == None

# Generated at 2022-06-10 23:29:17.693885
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:30:26.962076
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError

        # create variable manager
    variable_manager = VariableManager()
    
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    passwords = {}


# Generated at 2022-06-10 23:30:34.128848
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-10 23:30:36.405299
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    args = context.CLIARGS
    p = PlaybookExecutor(["test.yml"], None, None, None, args)
    p.run()

# Generated at 2022-06-10 23:30:37.207359
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:30:47.004121
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
   from ansible.module_utils.common.collections import ImmutableDict
   from ansible.plugins.action import ActionBase
   from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
   from ansible.playbook.play import Play
   from ansible.playbook.task.include import Include
   from ansible.playbook.task.task import Task
   from ansible.playbook.task_include import TaskInclude
   from ansible.playbook.block import Block
   from ansible.cli.arguments import OptionParser
   #from ansible.utils.display import Display
   #display = Display()

# Generated at 2022-06-10 23:30:50.678457
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    module_args = dict(
        playbook='~/ansible/playbook.yml',
        inventory='~/ansible/inventory.ini',
        variable_manager='~/ansible/var_manager',
        loader='~/ansible/loader',
        passwords=dict(foo='bar'),
    )
    instance = PlaybookExecutor(**module_args)
    assert type(instance.run()) == int



# Generated at 2022-06-10 23:30:54.679524
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # instantiate an object
    pl = PlaybookExecutor([], [], [], [], [])
    # call the method
    try:
        res = pl.run()
        assert(res == 0)
    except NotImplementedError:
        pass


# Generated at 2022-06-10 23:30:55.376319
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    PlaybookExecutor.run()

# Generated at 2022-06-10 23:30:56.713756
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-10 23:31:05.430526
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # set args
    args = mock.Mock()
    args.syntax = False
    args.listhosts = False
    args.listtasks = False
    args.listtags = False
    args.start_at_task = None
    args.step = False
    args.connection = 'paramiko'
    args.module_path = None
    args.forks = 10
    args.remote_user = None
    args.private_key_file = None
    args.ssh_common_args = None
    args.ssh_extra_args = None
    args.sftp_extra_args = None
    args.scp_extra_args = None
    args.become = False
    args.become_method = 'sudo'
    args.become_user = None
    args.verbosity = None
   

# Generated at 2022-06-10 23:32:08.270352
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # Create object
    pbe = PlaybookExecutor(playbooks=None, inventory=None, variable_manager=None, loader=None, passwords=None)
    # Call method
    pbe.run()
    assert True # no exception


# Generated at 2022-06-10 23:32:22.391492
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.invocation import PlaybookExecutionContext
    import os
    current_path = os.path.dirname(__file__)
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'mywebserver'}
    passwords = {}
    context = PlaybookExecutionContext(variable_manager, loader, passwords)
    playbooks = [current_path + "/ansible_playbook.yml"]
    inventory = variable_manager.get_inventory()
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-10 23:32:23.470665
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    pass

# Generated at 2022-06-10 23:32:32.650068
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create an instance of PlaybookExecutor
    pbexecutor = PlaybookExecutor(
        playbooks=['tests/test_playbooks/test_playbook_executor.yml'],
        inventory=InventoryManager(loader=DataLoader(), sources=['localhost,']),
        variable_manager=None,
        loader=DataLoader(),
        passwords=None
    )

    # Run the playbook
    pbexecutor.run()

# Generated at 2022-06-10 23:32:39.691380
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    # set up the test
    inventory = Inventory("localhost,")
    variable_manager = VariableManager()
    passwords = dict()
    loader = DataLoader()
    playbooks = "./test/test-data/test_playbook.yml"

    pbe = PlaybookExecutor(playbooks, inventory, variable_manager, loader, passwords)
    pbe.run()

# Generated at 2022-06-10 23:32:46.801000
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    '''
    Unit test for method run of class PlaybookExecutor
    '''
    # Init some variables
    context.CLIARGS = {'listhosts': True,
                       'listtasks': True,
                       'listtags': True,
                       'syntax': True,
                       'forks': 100}

    # Init the AnsibleFacts
    af = AnsibleFacts()

    # Make a variable data structure
    variable_manager = af.variable_manager

    # Init the loader
    loader = af.loader

    # Init the passwords storage
    passwords = af.passwords

    # Init the inventory
    inventory = af.inventory

    # Init the task queue manager
    tqm = af.tqm

    # Init the playbooks list

# Generated at 2022-06-10 23:32:53.196868
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    from ansible.cli.playbook import PlaybookCLI

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor import playbook_executor
    from ansible.utils.display import Display
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path
    from ansible.utils.path import makedirs_safe
    from ansible.utils.ssh_functions import set_default_transport

    # init Ansible config
    args = ["ansible-playbook", "--version"]
    p = PlaybookCLI(args)
    p.parse()

# Generated at 2022-06-10 23:32:53.756228
# Unit test for method run of class PlaybookExecutor
def test_PlaybookExecutor_run():
    pass

# Generated at 2022-06-10 23:33:03.284184
# Unit test for constructor of class PlaybookExecutor
def test_PlaybookExecutor():
    '''
    Unit test for constructor of class PlaybookExecutor
    '''

    playbook = "/Users/shiv/Documents/ansible/ansible-for-devops/ansible_for_devops/1st-chapter/test.yml"
    inventory = "/Users/shiv/Documents/ansible/ansible-for-devops/ansible_for_devops/1st-chapter/hosts"
    variable_manager = VariableManager()
    passwords = {}
    loader = DataLoader()

    playbooks_exe = PlaybookExecutor(
        playbooks=[playbook],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
    )
    playbooks_exe.run()