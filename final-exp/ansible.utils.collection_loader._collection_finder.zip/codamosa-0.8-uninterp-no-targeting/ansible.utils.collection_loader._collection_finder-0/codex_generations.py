

# Generated at 2022-06-21 08:13:19.784493
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import_paths = ['tests/data/collections/collections-redir', 'tests/data/collections/collections-redir/ansible_collections',
                    'tests/data/collections/collections-redir/ansible_collections/not-real-collection']
    ext_paths = [os.path.join(p, 'extras') for p in import_paths if p.endswith('ansible_collections')]


# Generated at 2022-06-21 08:13:26.881331
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # test valid inputs
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir

# Generated at 2022-06-21 08:13:36.593454
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    runtime_test_dir = './test_dir'
    runtime_test_dir_path = './test_dir/ansible'
    mkdirs(runtime_test_dir_path)
    write_data({'__init__.py': '#!/usr/bin/env python',
                'module.py': '#!/usr/bin/env python\n\nprint("hello, world!")',
                'module_empty.py': '',
                'module_empty.pyc': b''},
               runtime_test_dir_path)
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(
        'ansible', path_list=[runtime_test_dir])

# Generated at 2022-06-21 08:13:41.129908
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    for path in [r'C:\Ansible\ansible_collections\test\test_collection']:
        pkg_loader = _AnsibleCollectionPkgLoader(path)
        assert pkg_loader._fullname == 'ansible_collections.test.test_collection'
        assert pkg_loader._package_to_load == 'test_collection'
        assert pkg_loader._candidate_paths[0] == r'C:\Ansible\ansible_collections\test\test_collection\plugins'
        assert pkg_loader._subpackage_search_paths[0] == r'C:\Ansible\ansible_collections\test\test_collection\plugins'
    for path in [r'C:\Ansible\ansible_collections\test']:
        pkg_loader = _An

# Generated at 2022-06-21 08:13:53.693424
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert(loader._fullname == 'ansible_collections')
    assert(loader._split_name == ['ansible_collections'])
    assert(loader._parent_package_name == '')
    assert(loader._package_to_load == 'ansible_collections')
    assert(loader._source_code_path == None)
    assert(loader._decoded_source == None)
    assert(loader._compiled_code == None)
    assert(loader._validate_args() == None)
    assert(loader._candidate_paths == None)
    assert(loader._subpackage_search_paths == None)
  


# Generated at 2022-06-21 08:13:58.209223
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # validate load_module. raise exception if no.
    ns_loader = _AnsibleCollectionPkgLoader(path_list=[], fullname='ansible_collections')
    loader = _AnsibleCollectionPkgLoader(path_list=[], fullname='ansible_collections')
    try:
        loader.load_module('ansible.builtin')
    except Exception as ex:
        assert(ex is None)
    try:
        loader.load_module('ansible_collections')
    except Exception as ex:
        assert(ex is None)
    try:
        loader.load_module('ansible_collections.some_ns')
    except Exception as ex:
        assert(ex is None)

# Generated at 2022-06-21 08:14:08.982985
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:14:13.255869
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('foo', ['a', 'b'])
    assert loader._package_to_load == 'foo'
    assert loader._parent_package_name == ''
    assert loader._candidate_paths == ['a', 'b']
    assert loader._subpackage_search_paths is None
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._fullname == 'foo'
    assert loader._split_name == ['foo']

    loader = _AnsibleCollectionPkgLoader('foo.bar', ['a', 'b'])
    assert loader._package_to_load == 'bar'
    assert loader._parent_package_name == 'foo'

# Generated at 2022-06-21 08:14:19.281590
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    cwd = os.getcwd()
    test_package_root = os.path.join(cwd, 'test/loader/test_collection_pkg_loader')
    loader = _AnsibleCollectionPkgLoaderBase(
        'col1.test_pkg_loader.test_module1',
        path_list=[test_package_root]
    )
    # test absolute path
    test_module1_data = loader.get_data('{0}/col1/test_pkg_loader/test_module1.py'.format(test_package_root))
    assert test_module1_data.decode() == '#!/usr/bin/python\n\nprint 2\n'

# Generated at 2022-06-21 08:14:25.247596
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    # the goal is to test the get_source of an object of the class _AnsibleCollectionPkgLoaderBase
    # in two different contexts:
    #   - when module path is defined
    #   - when module path is not defined

    # creation of an object of type _AnsibleCollectionPkgLoaderBase
    # in this test we are in the first context
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.builtin_plugins', 'tests/unit/loader/test_loaders/ansible_collections/ansible/builtin_plugins')

    # the method to test
    result = obj.get_source('ansible_collections.ansible.builtin_plugins')

    # we expect it returns a string
    assert isinstance(result,str)
    # we expect it returns the content of

# Generated at 2022-06-21 08:15:35.044792
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.spam.eggs')


# Generated at 2022-06-21 08:15:48.248978
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():

    with tempfile.TemporaryDirectory() as td:
        # Create a namespace package directories
        os.mkdir(os.path.join(td, 'awx', 'plugins', 'modules'))
        os.mkdir(os.path.join(td, 'awx', 'plugins', 'modules', 'monitoring'))

        # Create a synthetic module
        with open(os.path.join(td, 'awx', 'plugins', 'modules', 'monitoring', '__synthetic__'), 'wb') as f:
            f.write(b'__import__')

        name = 'awx.plugins.modules.monitoring'
        path_list = [os.path.join(td, 'awx')]
        loader = _AnsibleCollectionNSPkgLoader(name, path_list)

        # Check if the loader instance is

# Generated at 2022-06-21 08:15:49.310354
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    fqcr = Ansi

# Generated at 2022-06-21 08:15:52.832925
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert _AnsiblePathHookFinder(None, 'foo/bar').__repr__() == '_AnsiblePathHookFinder(path=\'foo/bar\')'


# Implements path based iter_modules for _AnsiblePathHookFinder

# Generated at 2022-06-21 08:16:00.034551
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    # Given
    pkg_name = 'ansible.collections.foo.bar'
    path_list = ['/tmp/foo/bar', '/tmp/baz/bar']
    loader = _AnsibleCollectionPkgLoaderBase(pkg_name, path_list)

    # When
    loader.load_module(pkg_name)

    # Then
    assert pkg_name in sys.modules
    assert sys.modules[pkg_name].__loader__ == loader


# Generated at 2022-06-21 08:16:13.107485
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # fqcn: filters
    ref = AnsibleCollectionRef.from_fqcr(u'ansible.builtin.filters', u'filter')
    assert ref.collection == u'ansible.builtin'
    assert ref.ref_type == u'filter'
    assert ref.resource == u'filters'
    assert ref.subdirs == u''

    # fqcn: test plugins.filter (with no subdirs)
    ref = AnsibleCollectionRef.from_fqcr(u'ansible.builtin.plugins.filter', u'filter')
    assert ref.collection == u'ansible.builtin'
    assert ref.ref_type == u'filter'
    assert ref.resource == u'plugins.filter'
    assert ref.subdirs == u''

    # fqcn: test plugins.

# Generated at 2022-06-21 08:16:19.272492
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    with mock.patch('sys.path_hooks', [_AnsibleCollectionFinder._ansible_collection_path_hook]):
        mock_collection_finder = mock.MagicMock()
        mock_collection_finder.find_module.return_value = 'some_value'
        apf = _AnsiblePathHookFinder(collection_finder=mock_collection_finder, pathctx=os.getcwd())
        assert apf.find_module('ansible_collections.some_collection') == 'some_value'



# Generated at 2022-06-21 08:16:23.057093
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # this import must not blow up
    from ansible import constants


# This hooks in for top level imports of Ansible Python modules, intercepting them if we have a redirection for them
# in the ansible.builtin metadata. If we don't have a redirection, this returns None (causing the import machinery
# to use the default Python loader)

# Generated at 2022-06-21 08:16:32.421227
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():

    import ansible_collections.ansible
    # get the local test dir as a list (for path_list) and as a string
    pwd = os.path.abspath(os.path.dirname(__file__))
    # we don't need the abspath if we are using realpath
    local_test_dir = os.path.realpath(os.path.join(pwd, "..", "test", "units", "loader"))
    path_list = [local_test_dir]
    # set up the path for the test directory as a list
    path_list = [os.path.join(local_test_dir, 'ansible_collections', 'my_namespace', 'my_collection')]

# Generated at 2022-06-21 08:16:39.496209
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsiblePathHookFinder('', [])
    assert finder.find_module('ansible.plugins.lookup.ipaddr') is not None
    assert finder.find_module('ansible.plugins.lookup.ipaddr', []) is not None
    assert finder.find_module('ansible.plugins.lookup.ipaddr', None) is not None

    with pytest.raises(ValueError):
        finder.find_module('ansible.plugins.lookup.ipaddr', None)


# Generated at 2022-06-21 08:17:33.997196
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Prepare input data
    input_path = 'ansible_collections/foo/bar'
    input_prefix = 'ansible_collections.foo.bar'

    # Mock pkgutil.iter_modules
    pkgutil.iter_modules = MagicMock(return_value=[])

    # Call function
    obj = _AnsiblePathHookFinder(None, input_path)
    obj.iter_modules(input_prefix)

    # Validate
    pkgutil.iter_modules.assert_called_once_with([input_path], input_prefix)


# Generated at 2022-06-21 08:17:42.659382
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Should be true
    assert AnsibleCollectionRef.is_valid_fqcr('') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') is True
    # Should be false
    assert AnsibleCollectionRef.is_valid_fqcr(None) is False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2..resource') is False

# Generated at 2022-06-21 08:17:55.848780
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import tempfile

    # 
    # 1. Testing in case fullname is correct
    # 
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar', path_list=[tempfile.gettempdir()])

    # 1.1. Testing in case is_package false
    # 1.1.1. Testing in case _source_code_path is None
    loader._source_code_path = None
    assert loader.get_filename(fullname='ansible_collections.foo.bar') == None
    # 1.1.2. Testing in case _source_code_path is not None
    loader._source_code_path = '/tmp/test.py'

# Generated at 2022-06-21 08:17:57.995567
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    l = _AnsibleCollectionNSPkgLoader('ansible_collections.somens')
    assert l is not None

# Generated at 2022-06-21 08:18:11.265212
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    d1tmp = tempfile.TemporaryDirectory()
    d2tmp = tempfile.TemporaryDirectory()
    import shutil
    f1tmp = tempfile.NamedTemporaryFile(mode="w", delete=False)
    f1tmp.write('#write anything')
    f1tmp.close()
    f2tmp = tempfile.NamedTemporaryFile(mode="w", delete=False)
    f2tmp.write('#write anything')
    f2tmp.close()
    f3tmp = tempfile.NamedTemporaryFile(mode="w", delete=False)
    f3tmp.write('#write anything')
    f3tmp.close()

# Generated at 2022-06-21 08:18:16.242155
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    fqcr = 'ns.coll.subdir1.subdir2.resource'
    ref = AnsibleCollectionRef.from_fqcr(fqcr,'role')
    assert repr(ref) == "AnsibleCollectionRef(collection='ns.coll', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-21 08:18:25.783982
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # create a _AnsibleCollectionFinder object
    acf = _AnsibleCollectionFinder()

    # create a path hook finder
    achf = _AnsiblePathHookFinder(acf, '/dev/null')

    # assert the find_module of achf
    assert achf.find_module('ansible_collections')
    assert achf.find_module('ansible')

    # assert the iter_modules of achf
    assert achf.iter_modules('ansible')
    assert achf.iter_modules('ansible_collections')


_collection_loader_cache = {}


# Implements a collection loader, that also has its own path hook for serving up Python-level collection modules
# (packages and modules).

# Generated at 2022-06-21 08:18:29.099296
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder(paths=['./tests/unit/loader/data/ansible_collections'], scan_sys_paths=False)
    # noinspection PyCallingNonCallable
    hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx='./tests/unit/loader/data/ansible_collections/collection_name')
    module_loader = hook_finder.find_module("collection_name.namespace.collection_name.plugins.module_utils.some_utils")
    assert isinstance(module_loader, _AnsibleCollectionLoader)



# Generated at 2022-06-21 08:18:33.366997
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile

    # Given the following scenario:
    #   - The ansible collection finder is created.
    #   - A playbook path is set.
    #   - A new playbook path is set.
    #
    # When the second playbook path is set:
    #   - Then The record of the first playbook path will be removed.
    #   - And the record of the second playbook path will remain.
    #
    # This class will use a temporary directory as the playbook path.
    # This is so that the test can create multiple versions of the directory
    # and set the path accordingly. This is needed because of the caching done
    # by the _AnsibleCollectionFinder class.
    temp_dir = tempfile.TemporaryDirectory()

    # Create the collection finder
    collection_finder = _AnsibleCollectionFinder()

# Generated at 2022-06-21 08:18:36.163521
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    """Unit test for method __repr__ of class _AnsiblePathHookFinder"""
    # _AnsibleCollectionLoader().__repr__()
    x = _AnsiblePathHookFinder(collection_finder = None, pathctx = "/a/b/c")
    assert x.__repr__() == '_AnsiblePathHookFinder(path=\'/a/b/c\')'



# Generated at 2022-06-21 08:19:08.750788
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='foo', ref_type='module') == AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='foo', ref_type='module')
    assert AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='foo', ref_type='module') != 'foo'


# Generated at 2022-06-21 08:19:10.734488
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert _AnsibleCollectionFinder._remove() is None


# Generated at 2022-06-21 08:19:21.802019
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    class TestParams:
        def __init__(self):
            self.collection_finder = _AnsibleCollectionFinder()
            self.pathctx = self.collection_finder._n_collection_paths[0]

    params = TestParams()
    path_hook_finder = _AnsiblePathHookFinder(params.collection_finder, params.pathctx)
    assert isinstance(path_hook_finder._collection_finder, _AnsibleCollectionFinder)
    assert isinstance(path_hook_finder._pathctx, str)
    assert path_hook_finder._pathctx == params.pathctx


# Implements path-based import for a package or namespace package
# May be added to sys.path_hooks when a collection path is seen

# Generated at 2022-06-21 08:19:29.138045
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # Arrange
    collection_finder = _AnsibleCollectionFinder()
    mocked_path = 'mocked_path'

    def my_find_module(fullname, path=None):
        raise Exception('Not mocked')

    collection_finder.find_module = my_find_module

    # Act
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, mocked_path)
    ansible_path_hook_finder.find_module('fullname', 'another_mocked_path')

    # Assert
    assert True, "This is just a place holder for a test to ensure the find_module method of _AnsiblePathHookFinder " \
                 " class is called as expected. Please do not remove this test"



# Generated at 2022-06-21 08:19:40.852236
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    print("\nTESTING AnsibleCollectionRef.is_valid_fqcr")

    # Case 1 - Invalid entry
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll') is False
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource .name') is False
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.name. something') is False

    # Case 2 - Valid entry
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.name') is True

# Generated at 2022-06-21 08:19:51.378789
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    """Unit test for method find_module of class _AnsiblePathHookFinder"""
    import json
    import shutil
    try:
        from tempfile import TemporaryDirectory
    except ImportError:
        from shutil import rmtree
        from tempfile import mkdtemp

        @contextmanager
        def TemporaryDirectory():
            name = mkdtemp()
            try:
                yield name
            finally:
                rmtree(name)

    with TemporaryDirectory() as tmp:
        tmp = to_native(tmp)
        playbook_path = os.path.join(tmp, 'collections')
        os.makedirs(playbook_path)
        collection_path = os.path.join(playbook_path, 'my_collection')
        module_path = os.path.join(collection_path, 'docs')
        os

# Generated at 2022-06-21 08:19:56.190029
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    """Unit test for method find_module of class _AnsiblePathHookFinder"""

    mock_CollFinder = Mock(spec=_AnsibleCollectionFinder)
    mock_pathctx = 'to_native(os.path.dirname(to_bytes(sys.modules[ansible.__file__])))'

    # testing 'else' part in the below code segment
    # else:
        # Something else; we'd normally restrict this to `ansible` descendent modules so that any weird loader
        # behavior that arbitrary Python modules have can be serviced by those loaders. In some dev/test
        # scenarios (eg a venv under a collection) our path_hook signs us up to load non-Ansible things, and
        # it's too late by the time we've reached this point, but also too expensive for the path_hook to figure

# Generated at 2022-06-21 08:20:06.606839
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import os
    import tempfile
    import sys
    import shutil
    from importlib import util

    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _AnsibleInternalRedirectLoader

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-21 08:20:17.602760
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Setup
    import sys
    import ansible.module_utils.basic
    import ansible.module_utils.collection_loader
    from ansible.module_utils.collection_loader import _AnsibleInternalRedirectLoader
    split_name = 'ansible.module_utils.basic'.split('.')
    toplevel_pkg = split_name[0]
    module_to_load = split_name[-1]
    fullname = 'ansible.module_utils.basic'
    fullname_main = 'ansible.module_utils.basic.main'
    AnsibleCollectionConfig.max_collection_plugins = len(AnsibleCollectionConfig.collection_dirs)
    AnsibleCollectionConfig.collections_paths = AnsibleCollectionConfig.collection_dirs

# Generated at 2022-06-21 08:20:19.144308
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Placeholder, we need to have unit tests for every function
    assert True == True


# Generated at 2022-06-21 08:20:44.194215
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:20:53.339782
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
  path = '/home/user/code/ansible/test/integration/collection_configs/somens.somecoll'
  fullname = 'ansible_collections.somens.somecoll'
  collection_finder = None
  _ansible_path_hook_finder_object = _AnsiblePathHookFinder(collection_finder, path)
  try:
    _ansible_path_hook_finder_object.find_module(fullname)
  except ImportError:
    return False
  else:
    return True

# Generated at 2022-06-21 08:20:54.413676
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pass



# Generated at 2022-06-21 08:21:05.345233
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:21:09.554228
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import ansible
    # test validate args
    # len 1, raise ValueError
    loader = _AnsibleCollectionLoader(fullname='ansible')
    # len 2, raise ValueError
    loader = _AnsibleCollectionLoader(fullname='ansible.collection')
    # len 3, raise ValueError
    loader = _AnsibleCollectionLoader(fullname='ansible.collection.namespace')
    # len 4, right
    loader = _AnsibleCollectionLoader(fullname='ansible.collection.namespace.package')
    # py2, new style module - default is raise ValueError
    loader = _AnsibleCollectionLoader(fullname='ansible.collection.namespace.package', sourceless_modules=[])
    # py2, new style module - not raise ValueError

# Generated at 2022-06-21 08:21:12.217232
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # load_module of class _AnsibleCollectionPkgLoader
    # TODO: Offer an example of using this method.
    raise NotImplementedError('Please, test this method with your data and remove this line.')


# Generated at 2022-06-21 08:21:19.547979
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    ref = 'ansible.foo.documentation.role2'
    ref_type = 'role'
    print(ref, ref_type)
    a = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    print(a)
    ref = 'ansible.foo.documentation.role2'
    ref_type = 'doc_fragment'
    print(ref, ref_type)
    a = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    print(a)


# Generated at 2022-06-21 08:21:22.249482
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    try:
        _AnsibleCollectionNSPkgLoader('ansible_collections')
    except ImportError:
        pass
    except:
        assert False, '_AnsibleCollectionNSPkgLoader constructor cannot load the ansible_collections toplevel package'
    try:
        _AnsibleCollectionNSPkgLoader('ansible_collections.foo')
    except:
        assert False, '_AnsibleCollectionNSPkgLoader constructor cannot handle collections namespace packages'



# Generated at 2022-06-21 08:21:26.372420
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/fake/path'])
    assert loader._fullname == 'ansible_collections'
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', '', 'ansible_collections')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._validate_args() is None
    assert loader._get_candidate_paths(['/fake/path']) == ['/fake/path/ansible_collections']
    assert loader._get_sub

# Generated at 2022-06-21 08:21:34.994419
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible_collections.foo.bar', 'ansible', '')
    assert loader.fullname == 'ansible_collections.foo.bar'
    assert loader.package_to_load == 'bar'
    assert loader.parent_package == 'ansible_collections.foo'
    assert loader.parent_package_name == 'ansible_collections.foo'
    assert loader.split_name == ['ansible_collections', 'foo', 'bar']

    loader = _AnsibleCollectionPkgLoader('ansible_collections.foo.bar', '/tmp/ansible_collections', '')
    assert loader.fullname == 'ansible_collections.foo.bar'
    assert loader.package_to_load == 'bar'