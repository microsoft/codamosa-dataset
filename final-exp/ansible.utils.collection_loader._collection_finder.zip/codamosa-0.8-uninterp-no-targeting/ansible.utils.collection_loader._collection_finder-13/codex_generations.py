

# Generated at 2022-06-21 08:13:16.549932
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import_module('_collection_loader')

    # expected success
    a = _AnsibleCollectionFinder()
    # expected failure
    try:
        a = _AnsibleCollectionFinder([])
        raise AssertionError('expected failure on empty paths')
    except ValueError:
        pass

    # expected success
    a = _AnsibleCollectionFinder(['/tmp'])
    # expected failure
    try:
        a = _AnsibleCollectionFinder(1)
        raise AssertionError('expected failure on non-list of paths')
    except ValueError:
        pass



# Generated at 2022-06-21 08:13:19.657948
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'

    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('NOT_A_PLUGIN') == 'NOT_A_PLUGIN'
    raises(ValueError, AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type, 'not_a_plugin')



# Generated at 2022-06-21 08:13:31.618378
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.ns1')
    assert loader._fullname == 'ansible_collections.ns1'
    assert loader._split_name == ['ansible_collections', 'ns1']
    assert loader._rpart_name == ('ansible_collections', '.', 'ns1')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ns1'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == [os.path.join(p, 'ns1') for p in DEFAULT_COLLECTION_PATHS]
    assert loader._subpackage

# Generated at 2022-06-21 08:13:40.034716
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # create a test directory
    base_path = tempfile.mkdtemp()
    os.mkdir(os.path.join(base_path, 'ansible_collections'))
    os.mkdir(os.path.join(base_path, 'ansible_collections', 'collection_dot_separated_namespace'))
    os.mkdir(os.path.join(base_path, 'ansible_collections', 'collection2_dot_separated_namespace'))

    os.mkdir(os.path.join(base_path, 'ansible_collections', 'collection_dot_separated_namespace', 'plugins'))
    os.mkdir(os.path.join(base_path, 'ansible_collections', 'collection2_dot_separated_namespace', 'plugins'))

    os

# Generated at 2022-06-21 08:13:46.328116
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    for b in [True, False]:
        c = _AnsibleCollectionFinder(scan_sys_paths=b)
        c._n_playbook_paths = ['/tmp/a', '/tmp/b']
        c.set_playbook_paths(['/tmp/b', '/tmp/c', '/tmp/a'])
        assert c._n_playbook_paths == ['/tmp/b', '/tmp/c', '/tmp/a']



# Generated at 2022-06-21 08:13:47.406876
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    pass


# Generated at 2022-06-21 08:13:59.352273
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # assert that a valid FQCR is parsed correctly
    fqcr_parts = AnsibleCollectionRef.try_parse_fqcr(u'mymodule', u'module')
    assert fqcr_parts.collection == u'mycollection', 'Invalid collection name'
    assert fqcr_parts.resource == u'mymodule', 'Invalid collection name'
    assert fqcr_parts.ref_type == u'module', 'Invalid collection name'
    # assert that a non-valid FQCR is parsed incorrectly
    fqcr_parts = AnsibleCollectionRef.try_parse_fqcr(u'mymodule.foo', u'module')
    assert fqcr_parts == None, 'Invalid collection name not detected'


# Generated at 2022-06-21 08:14:04.936913
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import ansible.release
    import ansible_collections

    # Remove any pre-existing _AnsibleCollectionFinder
    _AnsibleCollectionFinder._remove()

    # Create _AnsibleCollectionFinder and _AnsiblePathHookFinder
    af = _AnsibleCollectionFinder()
    af._install()
    achf = _AnsiblePathHookFinder(af, ansible.release.__path__[0])

    # Test the iter_modules() function
    iter_modules = achf.iter_modules()
    try:
        iter(iter_modules)
    except:
        sys.exit(1)

    # Test the repr() function
    try:
        achf.__repr__()
    except:
        sys.exit(1)

    # Test the find_

# Generated at 2022-06-21 08:14:14.396491
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    TestAnsibleCollectionRef = AnsibleCollectionRef
    assert TestAnsibleCollectionRef.from_fqcr('ns.coll.mymod', 'module').fqcr == 'ns.coll.mymod'
    assert TestAnsibleCollectionRef.from_fqcr('ns.coll.mymod.ext1', 'module').fqcr == 'ns.coll.mymod.ext1'
    assert TestAnsibleCollectionRef.from_fqcr('ns.coll.mymod.ext1', 'module').resource == 'mymod.ext1'
    assert TestAnsibleCollectionRef.from_fqcr('ns.coll.mymod.ext1', 'module').n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert TestAnsibleCollectionRef.from_fqcr

# Generated at 2022-06-21 08:14:25.174899
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():

    def make_module(path, name):
        with open(os.path.join(path, '{0}.py'.format(name)), 'w') as f:
            f.write('\n')

    def make_package(path, name):
        path = os.path.join(path, name)
        os.mkdir(path)
        initpy = os.path.join(path, '__init__.py')
        with open(initpy, 'w') as f:
            f.write('\n')

    # make sure the module returns nothing for a non-Ansible path
    with tempfile.TemporaryDirectory() as tempdir:
        # finder for path-hook
        finder = _AnsiblePathHookFinder(None, tempdir)

# Generated at 2022-06-21 08:15:28.937808
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    print('Testing method try_parse_fqcr of class AnsibleCollectionRef... ', end='')
    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.d', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c', 'module').n_python_package_name == 'ansible_collections.a.b.plugins.modules.c'
    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c', 'module').fqcr == 'a.b.c'

# Generated at 2022-06-21 08:15:38.506254
# Unit test for constructor of class _AnsibleCollectionFinder

# Generated at 2022-06-21 08:15:44.914695
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase(None)
    path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'test_data', 'foo.txt')
    result = loader.get_data(path)
    assert result == b'bar'



# Generated at 2022-06-21 08:15:47.459793
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', ['/tmp/'])
    assert loader is not None
    assert loader._fullname == 'ansible_collections'
    assert loader._source_code_path is None

    loader = _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar', ['/tmp/'])
    assert loader is None
    assert loader is None



# Generated at 2022-06-21 08:15:56.170903
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # test invalid fqcr with no ref type
    assert_raises(ValueError, AnsibleCollectionRef.try_parse_fqcr, 'not-valid', None)
    # test valid fqcr with no ref type
    assert_is_none(AnsibleCollectionRef.try_parse_fqcr('ns.collection.resource', None))
    # test valid fqcr w/ role type
    assert_is_not_none(AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'role'))
    # test invalid fqcr with role type
    assert_raises(ValueError, AnsibleCollectionRef.try_parse_fqcr, 'ns.coll.resource', 'module')
    # test valid fqcr w/ module type

# Generated at 2022-06-21 08:16:07.891983
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    import sys
    import pkgutil

    class Obj:
        pass
    # mock imported context
    my_context = Obj()
    my_context.path = ['/a/b', '/c/d']
    my_context.__name__ = 'ansible_collections'

    # normal invocation
    assert isinstance(
        _AnsibleCollectionNSPkgLoader(fullname='ansible_collections.some_ns', path_list=my_context.path),
        _AnsibleCollectionNSPkgLoader
    )

    # wrong name
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader(fullname='not_ansible_collections.some_ns', path_list=my_context.path)

    # multiple parts to name

# Generated at 2022-06-21 08:16:18.404114
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import tempfile
    import os.path
    import pytest
    import shutil

    def _test(basename, expected_code_object, module_code, **kwargs):
        # create a temp dir to work in
        tmpdir = tempfile.mkdtemp()
        # create a file in the temp dir with the expected contents
        filename = os.path.join(tmpdir, '{0}.py'.format(basename))
        with open(filename, 'w') as fh:
            fh.write(module_code)

        # instantiate the class
        loader = _AnsibleCollectionPkgLoaderBase(basename, path_list=[tmpdir])
        loader._validate_final()

        # call the method to get its output
        result = loader.get_code(basename)

        # compare

# Generated at 2022-06-21 08:16:29.155381
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # test with valid input data
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin

# Generated at 2022-06-21 08:16:34.363688
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collectionFinder_object = _AnsibleCollectionFinder()
    result_object = _AnsiblePathHookFinder(collectionFinder_object, '/path/to/Ansible_role')
    assert result_object._pathctx == '/path/to/Ansible_role'

# Test for class _AnsiblePathHookFinder

# Generated at 2022-06-21 08:16:42.945641
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import types

    assert isinstance(AnsibleCollectionConfig.collection_finder, _AnsibleCollectionFinder)
    assert isinstance(sys.meta_path[0], _AnsibleCollectionFinder)

    # Check that the hook has been installed in sys.path_hooks,
    # and that the hook is called for paths that start with
    # either ansible_collections or ansible_collections/
    for p in [b'/bar/baz', b'/bar/baz/ansible_collections', b'/bar/baz/ansible_collections/foo/bar']:
        found = False
        for hook in sys.path_hooks:
            if hook(p):
                found = True
                break
        assert found, 'Hook not found for path: %s' % p

    # Check that a hook is

# Generated at 2022-06-21 08:17:08.588357
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader(os.getcwd())
    assert isinstance(loader, _AnsibleCollectionRootPkgLoader)



# Generated at 2022-06-21 08:17:13.624674
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'library') == u'module'


# Generated at 2022-06-21 08:17:26.060809
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class TestPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            pass
        def _get_subpackage_search_paths(self, candidate_paths):
            pass

    # fullname and path_list must be supplied
    with pytest.raises(TypeError):
        TestPkgLoader()
    with pytest.raises(TypeError):
        TestPkgLoader(fullname='test_fullname')

    # sanity check for some attribute values
    pkg_loader = TestPkgLoader(fullname='test_fullname', path_list=[])
    assert pkg_loader._fullname == 'test_fullname'

# Generated at 2022-06-21 08:17:37.676162
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['/var/lib/awx/lib/ansible/collections/'])
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None

# Generated at 2022-06-21 08:17:48.944482
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.six', path_list=None)
    assert loader._redirect == 'ansible.module_utils.six.moves'


if not PY3:
    import imp

    class _AnsiblePython26PathImporter:
        def find_module(self, fullname, path=None):
            if path is None:
                path = sys.path
            try:
                imp.find_module(fullname, path)
            except ImportError:
                return None

            return _AnsibleInternalRedirectLoader(fullname, path)

    _ansible_importer = _AnsiblePython26PathImporter()
    sys.meta_path.append(_ansible_importer)

    # Unit test for method find_module of class _An

# Generated at 2022-06-21 08:18:00.127104
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    from ansible.plugins.loader import PluginLoader

    # initialize collection components
    collection_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'test/collections/ansible_collections/community/plugins/module_utils')
    paths = [collection_path]
    collection_finder = _AnsibleCollectionFinder(paths=paths, scan_sys_paths=False)
    collection_finder._install()

    # get collection path
    collection_path = collection_finder._get_collection_path('community/plugins/module_utils')
    assert collection_path.endswith(os.path.join('test', 'collections', 'ansible_collections', 'community', 'plugins', 'module_utils'))

    # find collection loader

# Generated at 2022-06-21 08:18:09.653040
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Setup
    pkg_loader_base = _AnsibleCollectionPkgLoaderBase('fake_fullname', [os.path.sep])
    pkg_loader_base._source_code_path = 'fake_source_code_path'
    if pkg_loader_base._source_code_path is None:
        # Should not happen
        raise AnotherError()
    # Exercise and validate
    val = pkg_loader_base.get_code('fake_fullname')
    if val is not None:
        raise AnotherError()

# Generated at 2022-06-21 08:18:20.474450
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll') is True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll.subcoll') is False
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll.subcoll.subcoll2') is False
    assert AnsibleCollectionRef.is_valid_collection_name('ns') is False
    assert AnsibleCollectionRef.is_valid_collection_name('coll') is False
    assert AnsibleCollectionRef.is_valid_collection_name('') is False
    assert AnsibleCollectionRef.is_valid_collection_name('a') is False
    assert AnsibleCollectionRef.is_valid_collection_name('a.b') is True
    assert AnsibleCollectionRef.is_valid_collection_name('Abc') is True


# Generated at 2022-06-21 08:18:29.495075
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # legacy plugin
    assert AnsibleCollectionRef.is_valid_fqcr('packet.plugins.action.copy') == True
    assert AnsibleCollectionRef.is_valid_fqcr('packet.plugins.action.copy', 'action') == True
    assert AnsibleCollectionRef.is_valid_fqcr('packet.plugins.action.copy', 'action') == True
    assert AnsibleCollectionRef.is_valid_fqcr('packet.plugins.action.copy.j2', 'action') == False
    assert AnsibleCollectionRef.is_valid_fqcr('packet.plugins.action.copy.yaml', 'action') == False

    # legacy modules, library
    assert AnsibleCollectionRef.is_valid_fqcr('packet.library.copy') == True
    assert AnsibleCollectionRef.is_

# Generated at 2022-06-21 08:18:33.745631
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import shutil
    from ansible_collections.testns.under_test._internal import demo
    from ansible_collections.testns.under_test._internal.plugins import action
    from ansible_collections.testns.under_test._internal.plugins.strategies import linear
    p = os.path.join(os.path.dirname(demo.__file__), '..', '..')
    p = os.path.realpath(p)
    p2 = os.path.join(p, 'ansible_collections/testns/under_test')
    f = _AnsibleCollectionFinder(paths=[p])
    f._install()
    # Top-level package
    assert f.find_module('ansible')
    assert f.find_module('ansible_collections')

    #

# Generated at 2022-06-21 08:19:08.732940
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # HACK: stash this in a better place
    _AnsibleCollectionLoader._redirected_package_map = {
        'ansible.builtin.async_wrapper': 'ansible.module_utils.basic',
    }

    # Unit: _AnsibleInternalRedirectLoader.load_module
    #     def load_module(self, fullname):
    #         """Load Python module ``fullname`` and return it."""
    #         if not self._redirect:
    #             raise ValueError('no redirect found for %s' % fullname)
    #
    #         mod = import_module(self._redirect)
    #         sys.modules[fullname] = mod
    #         return mod
    #
    fullname = 'ansible.builtin.async_wrapper'
    sys.modules = {}


# Generated at 2022-06-21 08:19:15.910461
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # _AnsibleCollectionLoader(self, fullname, path_list, collection_name, package_name):
    path_list = []
    collection_name = 'foo'
    package_name = 'bar'
    collection_loader = _AnsibleCollectionLoader(collection_name, path_list, collection_name, package_name)
    assert collection_loader._fullname == collection_name
    assert collection_loader._path_list == path_list
    assert collection_loader._package_to_load == package_name
    assert collection_loader._split_name == [collection_name]
    assert collection_loader._candidate_paths == []
    assert collection_loader._subpackage_search_paths is None
    assert collection_loader._source_code_path is None
    assert collection_loader._compiled_code is None

# Generated at 2022-06-21 08:19:25.906579
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    __AnsibleInternalRedirectLoader_load_module = _AnsibleInternalRedirectLoader.load_module
    def _AnsibleInternalRedirectLoader_load_module(fullname):
        mod = __AnsibleInternalRedirectLoader_load_module(fullname)
        print('load_module: fullname=%s -> mod=%s' % (fullname, mod))
        return mod
    _AnsibleInternalRedirectLoader.load_module = _AnsibleInternalRedirectLoader_load_module
    try:
        import ansible
    finally:
        _AnsibleInternalRedirectLoader.load_module = __AnsibleInternalRedirectLoader_load_module

# Generated at 2022-06-21 08:19:38.680608
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    import shutil
    import os

    collection_name = 'test'
    namespace_name = 'ansible'
    path_to_collection = os.path.join(tempfile.gettempdir(), collection_name)

    p1 = os.path.join(path_to_collection, 'plugins')
    os.makedirs(p1)
    open(os.path.join(p1, '__init__.py'), 'a').close()
    open(os.path.join(p1, 'action.py'), 'a').close()

    p2 = os.path.join(path_to_collection, 'module_utils')
    os.makedirs(p2)
    open(os.path.join(p2, '__init__.py'), 'a').close()

# Generated at 2022-06-21 08:19:50.407948
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import tempfile
    import shutil

    from ansible.errors import AnsibleError

    # Simple doctest

    # Create a temporary package directory to test load_module
    test_pkg_dir = tempfile.mkdtemp()
    test_pkg_dir_init = os.path.join(test_pkg_dir, "__init__.py")
    with open(test_pkg_dir_init, "w") as init_file:
        init_file.write("")


# Generated at 2022-06-21 08:19:55.725681
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    class TestArgs:
        def __init__(self, arg):
            self.arg = arg

    class TestKwargs:
        def __init__(self):
            self.kwargs = {}

        def __getitem__(self, key):
            return self.kwargs.get(key, 'N/A')

    # Test fullname starts with ansible
    test_fullname = 'ansible.module_utils.module_utils'
    test_args = TestArgs(test_fullname)
    test_kwargs = TestKwargs()
    test_kwargs['path'] = []
    path_hook_finder = _AnsiblePathHookFinder(None, None)
    path_hook_finder.find_module(*test_args, **test_kwargs) == _AnsibleInternalRedirectLoader

    #

# Generated at 2022-06-21 08:20:06.478999
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # For empty candidate_paths, test for proper handling of situation when
    # collection package to load is present in some but not all candidate_paths.
    loader = _AnsibleCollectionPkgLoader(['ansible.collections.my_namespace'], [], ['my_namespace'], '')
    assert loader._candidate_paths == [], '_candidate_paths should be empty'
    loader._validate_args()
    loader._validate_final()

    # For non-empty candidate_paths, test for proper handling of situation when
    # collection package to load is present in some but not all candidate_paths.

# Generated at 2022-06-21 08:20:14.595586
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    path = os.path.realpath(__file__).rsplit(os.path.sep, 2)[0]
    prefix = "ansible_collections.somens"
    _collection_finder = _AnsibleCollectionFinder(paths=[path])
    path_hook_finder = _AnsiblePathHookFinder(_collection_finder, path)
    assert path_hook_finder.iter_modules(prefix) == ["somecoll"]
    assert path_hook_finder.iter_modules(None) == []


# Generated at 2022-06-21 08:20:22.173871
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    ansible_collection_finder_instance = _AnsibleCollectionFinder()
    ansible_collection_finder_instance.set_playbook_paths(['/root/mycollections', '/root/mycollections'])
    assert ansible_collection_finder_instance._n_playbook_paths == ['/root/mycollections/collections']
    ansible_collection_finder_instance.set_playbook_paths(['/root/mycollections'])
    assert ansible_collection_finder_instance._n_playbook_paths == ['/root/mycollections/collections']
    ansible_collection_finder_instance.set_playbook_paths(['/root/mycollections', '/root/mycollections/collections'])
    assert ansible_collection_finder_instance._n_playbook_path

# Generated at 2022-06-21 08:20:30.944751
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subcoll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.col_name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns..coll')



# Generated at 2022-06-21 08:21:34.479528
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ans = AnsibleCollectionRef("ns.collname", "subdir1.subdir2", "resource", "module")
    assert ans.is_valid_fqcr("ns.collname.resource") == True
    assert ans.is_valid_fqcr("ns.collname.subdir1.subdir2.resource") == True
    assert ans.is_valid_fqcr("ns.collname.resource.action") == False
    assert ans.is_valid_fqcr("ns.collname,resource") == False


# Generated at 2022-06-21 08:21:45.594143
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible.errors import AnsibleError as AError
    from collections import namedtuple as CTuple
    from ansible.module_utils._text import to_native as to_text
    from ansible.module_utils._text import to_bytes as to_byte
    from ansible.module_utils._text import to_text as to_str
    from ansible.parsing.vault import VaultLib as VLib
    from ansible.utils.vars import combine_vars as c_vars
    from ansible.vars import combine_vars as comb_vars
    import base64 as b64
    import ansible.module_utils.facts as mod_facts
    import ansible.plugins.loader as plug_loader
    from ansible.utils.display import Display as AnsDisplay