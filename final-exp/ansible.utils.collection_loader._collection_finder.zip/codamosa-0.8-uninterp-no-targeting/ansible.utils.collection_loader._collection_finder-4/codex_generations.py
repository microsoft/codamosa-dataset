

# Generated at 2022-06-21 08:12:43.666182
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef("ansible.base", None, "mymodule", "module").__repr__() == "AnsibleCollectionRef(collection='ansible.base', subdirs='', resource='mymodule')"



# Generated at 2022-06-21 08:12:48.635182
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    acr = AnsibleCollectionRef.from_fqcr("my.collection", "action")
    assert acr.collection == "my.collection"
    assert acr.subdirs == ""
    assert acr.resource == "action"
    assert acr.ref_type == "action"
    assert acr.n_python_package_name == "ansible_collections.my.collection.plugins.action"
    acr = AnsibleCollectionRef.from_fqcr("my.collection.subdir1", "action")
    assert acr.collection == "my.collection"
    assert acr.subdirs == "subdir1"
    assert acr.resource == "action"
    assert acr.ref_type == "action"

# Generated at 2022-06-21 08:12:51.044632
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    cur = AnsibleCollectionRef(collection_name='collection_name', subdirs='subdirs', resource='resource',ref_type='ref_type')
    assert isinstance(cur, AnsibleCollectionRef)
    expected = 'AnsibleCollectionRef(collection=\'collection_name\', subdirs=\'subdirs\', resource=\'resource\')'
    actual = cur.__repr__()
    assert expected == actual


# Generated at 2022-06-21 08:12:56.630265
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    test__AnsibleCollectionPkgLoaderBase_get_filename__module = 'ansible_collections.example.collection'
    test__AnsibleCollectionPkgLoaderBase_get_filename__package = 'ansible_collections.example.collection.subpackage'
    test1 = test__AnsibleCollectionPkgLoaderBase_get_filename__module
    test2 = test__AnsibleCollectionPkgLoaderBase_get_filename__package
    test__AnsibleCollectionPkgLoaderBase_get_filename__loader_classes = [
            _AnsibleCollectionPkgLoader1,
            _AnsibleCollectionPkgLoader2,
            _AnsibleCollectionPkgLoader3,
            _AnsibleCollectionPkgLoader4,
            _AnsibleCollectionPkgLoader5,
    ]
    test__AnsibleCollectionPkg

# Generated at 2022-06-21 08:13:03.760122
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    test_object = _AnsiblePathHookFinder(
        collection_finder=_AnsibleCollectionFinder(),
        pathctx='/tmp/pathctx'
    )
    try:
        assert repr(test_object) == "{0}(path='{1}')".format(test_object.__class__.__name__, test_object._pathctx)
    except AssertionError as e:
        pytest.fail(e.args[0])


# Generated at 2022-06-21 08:13:11.499843
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # No redirection
    with pytest.raises(ImportError) as exc_info:
        _AnsibleInternalRedirectLoader('ansible.builtin.rds', None)

    # Redirection to unknown target
    with pytest.raises(ImportError) as exc_info:
        _AnsibleInternalRedirectLoader('ansible.builtin.rds', None)


# loads ansible_collections.<collection namespace> packages
_AnsibleCollectionRootPkgLoader.register_type(type_name='ansible_collections', loader_class=_AnsibleCollectionRootPkgLoader)
_AnsibleCollectionNSPkgLoader.register_type(type_name='ansible_collections', loader_class=_AnsibleCollectionNSPkgLoader)
# loads ansible_collections.<collection namespace>.<collection name>

# Generated at 2022-06-21 08:13:21.846815
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import imp
    import pkgutil
    import sys
    # create a new Finder
    my_finder = _AnsibleCollectionFinder(['/tmp', '/tmp2'])
    assert my_finder._n_configured_paths == ['/tmp', '/tmp2']

    my_finder._install()
    assert len(sys.meta_path) >= 1
    assert isinstance(sys.meta_path[0], _AnsibleCollectionFinder)
    assert len(sys.path_hooks) >= 1
    assert callable(sys.path_hooks[0])
    assert len(sys.path_importer_cache) >= 1
    assert isinstance(sys.path_importer_cache[0], imp.NullImporter)

    my_finder._remove()
    assert len(sys.meta_path) >= 1


# Generated at 2022-06-21 08:13:29.242503
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'become_plugins') == u'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cliconf_plugins') == u'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'doc_fragments') == u'doc_fragments'

# Generated at 2022-06-21 08:13:38.514239
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    """
    _AnsibleCollectionPkgLoaderBase:iter_modules: Return a tuple containing all submodules of a package
    """
    from ansible.module_utils._text import to_text
    from tempfile import TemporaryDirectory
    from os import makedirs
    from shutil import copytree
    from ansible.module_utils.six import StringIO

    # create base test dir
    with TemporaryDirectory(prefix='ansible-test-collection-') as test_basedir:
        # grab the prefix and create some nested subdirs
        test_basedir_prefix = os.path.join(test_basedir, '')
        makedirs(os.path.join(test_basedir, 'foo', 'bar', 'baz'))

# Generated at 2022-06-21 08:13:38.978984
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    pass

# Generated at 2022-06-21 08:14:16.589646
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('jdoe.my_collection', '', 'my_module', 'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='jdoe.my_collection', subdirs='', resource='my_module')"


# Generated at 2022-06-21 08:14:17.895949
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Setup
    collection_loader = _AnsibleCollectionFinder()

    # Test
    assert collection_loader != None



# Generated at 2022-06-21 08:14:27.541923
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import UserDict

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO

    # mock class for path hook finder
    class _MockPathHookFinder(object):
        def find_module(self, fullname, path=None):
            return None

    # mock class for FileFinder hook
    class _MockFileFinderHook(object):
        def __init__(self, path):
            self.path = path

        def find_spec(self, fullname):
            return None

    # HACK: make sure path hook finder doesn't call the real FileFinder hook
    _Ansible

# Generated at 2022-06-21 08:14:39.750720
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test the case collection ref with namespace, collection and subdir and resource
    ref = 'collec.tion.subdir.modulename'
    ref_type = 'module'
    result = AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)
    assert result, 'Case 1 failed'

    # Test the case collection ref with namespace, collection and resource
    ref = 'coll.ec.tion.modulename'
    ref_type = 'module'
    result = AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)
    assert result, 'Case 2 failed'
    # Test the case collection ref with namespace, collection and resource
    ref = 'collec.tion.subdir.rolename'
    ref_type = 'role'
    result = AnsibleCollectionRef.is_valid

# Generated at 2022-06-21 08:14:46.519199
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import tempfile
    import os
    import sys
    from shutil import rmtree

    # Test method get_code - Source Code is not available
    tmpdir = tempfile.mkdtemp()
    try:
        test_dir = os.path.join(tmpdir, "test")
        os.mkdir(test_dir)
        test_file_name = os.path.join(test_dir, "__init__.py")
        with open(test_file_name, "w") as test_module:
            test_module.write("def test_func(): return True")
        loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.test", [test_dir])
        assert loader.get_code("ansible_collections.test") == None
    finally:
        rmtree(tmpdir)

# Generated at 2022-06-21 08:14:57.987144
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Create a deepcopy of AnsibleCollectionRef.VALID_REF_TYPES
    ref_types = copy.deepcopy(AnsibleCollectionRef.VALID_REF_TYPES)

    # Add 'playbooks' to ref_types
    ref_types.add(u'playbook')

    # Create a list of collection names
    collections = list()

    # For each ref_type in ref_types, add ref_type and collection to collections
    for ref_type in ref_types:
        collections.append(ref_type)
        collections.append(u'spam.eggs')

    # Create a data structure for storing results
    results = dict()

    # For each ref_type in ref_types, create a dictionary with ref_type as a key and empty list as a value

# Generated at 2022-06-21 08:15:03.262258
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    t = AnsibleCollectionRef(
        'ansible.builtin',
        None,
        'doc_generator',
        'doc_fragment'
    )
    assert t.__repr__() == "AnsibleCollectionRef(collection='ansible.builtin', subdirs=None, resource='doc_generator')"

# Generated at 2022-06-21 08:15:10.242218
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    """
    Test for method load_module of class _AnsibleCollectionPkgLoaderBase

    See:
        - ansible.module_utils._AnsibleCollectionPkgLoaderBase.load_module
    """
    # test object creation
    loader = _AnsibleCollectionPkgLoaderBase('', path_list=[])
    # test __file__
    assert not loader.get_filename('')
    # test get_code
    assert not loader.get_code('')

    # test __file__
    assert loader.get_filename('ansible_collections.my.package') == '<ansible_synthetic_collection_package>'
    # test get_code
    assert not loader.get_code('ansible_collections.my.package')



# Generated at 2022-06-21 08:15:18.150481
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # this test is to make sure that the base class works fine
    my_loader_base = _AnsibleCollectionPkgLoaderBase('ansible_collections.apt.jdauphant.mongodb', path_list=[])
    my_loader_base._get_candidate_paths(['./'])  # no problem
    my_loader_base._get_subpackage_search_paths([])  # no problem
    my_loader_base._validate_final()  # no problem


# Generated at 2022-06-21 08:15:24.805236
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    pkg_loaders = AnsibleCollectionFinder.get_pkg_loaders()
    for pkg_loader in pkg_loaders:
        if isinstance(pkg_loader, _AnsibleCollectionPkgLoaderBase):
            fullname = pkg_loader._fullname
            filename = pkg_loader.get_filename(fullname)
            assert filename is not None, "%s.get_filename(%s) is None" % (pkg_loader, fullname)


# Generated at 2022-06-21 08:15:58.224003
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.builtin_module', [])
    assert isinstance(loader, _AnsibleInternalRedirectLoader)
    assert loader._redirect == 'ansible.builtin.plugins.module'

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.module_utils.builtin_module', [])
    assert isinstance(loader, _AnsibleInternalRedirectLoader)
    assert loader._redirect == 'ansible.builtin.plugins.module_utils'

    loader = _AnsibleInternalRedirectLoader('ansible.plugins.muexec', [])
    assert isinstance(loader, _AnsibleInternalRedirectLoader)
    assert loader._redirect == 'ansible.builtin.plugins.muexec'

    loader = _Ansible

# Generated at 2022-06-21 08:16:06.859068
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import _AnsibleInternalRedirectLoader
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.ping', None)
    loader._redirect = 'ansible.legacy.builtin.ping'
    import ansible.builtin.ping as ping
    module = loader.load_module('ansible.builtin.ping')
    assert module.__name__ == ping.__name__

# Generated at 2022-06-21 08:16:17.699365
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Check a well formed collection reference
    acr = AnsibleCollectionRef.from_fqcr(u'geerlingguy.mycollection.mymodule', u'module')

    assert(acr.collection == u'geerlingguy.mycollection')
    assert(acr.subdirs == u'')
    assert(acr.resource == u'mymodule')
    assert(acr.ref_type == u'module')

    # Check a valid collection reference with sub directory
    acr = AnsibleCollectionRef.from_fqcr(u'geerlingguy.mycollection.subdir.mymodule', u'module')

    assert(acr.collection == u'geerlingguy.mycollection')
    assert(acr.subdirs == u'subdir')

# Generated at 2022-06-21 08:16:22.724292
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # testing a correct case
    try:
        _AnsibleCollectionNSPkgLoader("ansible_collections.test", ["/tmp"])
    except Exception:
        raise AssertionError("_AnsibleCollectionNSPkgLoader could not be constructed")
    # testing a wrong case
    try:
        _AnsibleCollectionNSPkgLoader("ansible_collections.test.a.b", ["/tmp"])
    except Exception:
        pass



# Generated at 2022-06-21 08:16:32.914311
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile
    import shutil

    # create the directory structure /tmp/collections/ansible_collections/foo/bar

# Generated at 2022-06-21 08:16:35.293806
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('')
    filename = loader.get_filename(loader._fullname)


# Generated at 2022-06-21 08:16:43.461599
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(test_dir, 'test_data')
    pkg_loader = _AnsibleCollectionPkgLoaderBase(test_data_dir, None)
    modules = pkg_loader.iter_modules("")

# Generated at 2022-06-21 08:16:46.743037
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('foo.bar.baz', ['/tmp'])
    assert loader._fullname == 'foo.bar.baz'
    assert loader._split_name == ['foo', 'bar', 'baz']
    assert loader._package_to_load == 'bar.baz'
    assert loader._search_paths == ['/tmp']
    assert loader._candidate_paths == ['/tmp/foo']
    assert loader._subpackage_search_paths == ['/tmp/foo/bar']



# Generated at 2022-06-21 08:16:56.151111
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_col.my_mod', u'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_col.my_mod.yml', u'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_col.myaction', u'action') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_col.subdir.my_mod', u'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_col.my_role', u'role') == True
    assert AnsibleCollectionRef.is_valid_

# Generated at 2022-06-21 08:17:04.935924
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Prepare
    p = os.path.dirname(__file__) + '/mock_collection_package'
    pkg = _AnsibleCollectionPkgLoaderBase(p)

    # Execute
    got = pkg.iter_modules(prefix=None)

    # Verify
    want = ['__init__', 'foo']
    got = [entry[1] for entry in got]
    assert got == want

    # Execute
    got = pkg.iter_modules(prefix='ansible_collections.mock_collection_package')

    # Verify
    want = ['ansible_collections.mock_collection_package.__init__',
            'ansible_collections.mock_collection_package.foo']
    got = [entry[1] for entry in got]
    assert got == want

    # Exec

# Generated at 2022-06-21 08:17:33.670881
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    expected = "_AnsiblePathHookFinder(path='/foo/bar')"
    actual = _AnsiblePathHookFinder(None, '/foo/bar').__repr__()
    assert expected == actual, 'should be equals'

# Generated at 2022-06-21 08:17:41.876263
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    class DummyAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        pass
    loader_base = DummyAnsibleCollectionPkgLoaderBase()
    try:
        loader_base.is_package('ansible_collections.my_ns.my_collection')
    except Exception as e:
        assert False
    try:
        loader_base.is_package('ansible_collections.my_ns.my_collec')
    except ValueError as e:
        assert str(e) == 'this loader cannot answer is_package for ansible_collections.my_ns.my_collec, only ansible_collections.my_ns.my_collection'


# Generated at 2022-06-21 08:17:54.778984
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from mock import patch, MagicMock
    from ansible import collection
    from ansible.utils.collection_loader import _meta_yml_to_dict, _AnsibleCollectionPkgLoader
    with patch('ansible.utils.collection_loader.AnsibleCollectionConfig', spec=collection.AnsibleCollectionConfig) as mock_AnsibleCollectionConfig:
        with patch('ansible.utils.collection_loader._meta_yml_to_dict',
                   spec=_meta_yml_to_dict) as mock_meta_yml_to_dict:
            mock_meta_yml_to_dict.return_value = dict(a='a', b='b')
            mock_AnsibleCollectionConfig.on_collection_load = MagicMock()

# Generated at 2022-06-21 08:18:02.722471
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    base_path = "test_path"

    # Cannot import a module
    with pytest.raises(ImportError) as exc_info:
        loader = _AnsibleCollectionNSPkgLoader("ansible_collections.module", base_path)
    assert exc_info.match("this loader can only load collections namespace packages, not ansible_collections.module")

    # Cannot import a module with a relative path
    try:
        loader = _AnsibleCollectionNSPkgLoader("ansible_collections.module", base_path)
    except Exception as exc:
        assert isinstance(exc, ImportError)


# Implements the behavior of Ansible's collection package loader
# This is the third level of package loading and is the first package found on the collection root path. It
# is a normal Python package and its package init code is executed in

# Generated at 2022-06-21 08:18:04.941588
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    ansible_collection_test_pkg_loader = _AnsibleCollectionPkgLoader()
    return True


# Generated at 2022-06-21 08:18:08.206964
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    _AnsibleCollectionFinder.test__AnsibleCollectionFinder_find_module()


# Generated at 2022-06-21 08:18:09.725273
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    import doctest
    results = doctest.testmod(verbose=False)
    if results.failed == 0:
        print('OK')
    else:
        exit(results.failed)


# Generated at 2022-06-21 08:18:20.523796
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    ansible_meta_path = "../../../meta/"
    import_ansible_meta_path = "../../../meta/runtime.yml"
    meta_dict = {'plugin_routing': {'/usr': [{'redirect': '../../../meta/runtime.yml'}],
                                    '../../../meta/runtime.yml': [{'redirect': '../../../meta/runtime.yml'}]}}
    ns_name = '.'.join((_AnsibleCollectionPkgLoader._split_name)[0:2])
    collection_name = '.'.join((_AnsibleCollectionPkgLoader._split_name)[0:3])

    def test_load_module(self):
        plugin_routing = {}

# Generated at 2022-06-21 08:18:23.518140
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert False
    # TODO: test to rollback all methods
    # TODO: import from mypy "
    # from mypy.test.helpers import test_case_to_suite"


# Generated at 2022-06-21 08:18:31.813089
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Positive tests
    # (1) With a valid fqcr with a plugin type
    assert AnsibleCollectionRef.try_parse_fqcr(u'my-ns.my-coll.module', u'module') == AnsibleCollectionRef(u'my-ns.my-coll', u'', u'module', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'my-ns.my-coll.my-module', u'module') == AnsibleCollectionRef(u'my-ns.my-coll', u'', u'my-module', u'module')

# Generated at 2022-06-21 08:19:07.548578
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    def test_try(ref, ref_type, expected):
        ref = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
        if ref != expected:
            raise AssertionError('{0!r} != {1!r} (ref_type: {2!r})'.format(ref, expected, ref_type))

    test_try('collections.ns.coll.resource', 'module', AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'module'))
    test_try('collections.ns.coll.subdir.resource', 'module', AnsibleCollectionRef(u'ns.coll', u'subdir', u'resource', u'module'))

# Generated at 2022-06-21 08:19:17.533670
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Basic negative case
    sd = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace', path_list=['/whatever/path'])
    assert sd.get_code('whatever') is None

    # Basic positive case
    # - simple module (no init or anything)
    # - handled by base class
    sd = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace.collection.plugins.module_utils.foo', path_list=[
        '/whatever/path',
    ])
    source_code = sd.get_source('ansible_collections.namespace.collection.plugins.module_utils.foo')
    assert source_code



# Generated at 2022-06-21 08:19:26.582725
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    ref1_str = 'ns.collname'
    assert AnsibleCollectionRef.is_valid_collection_name(ref1_str)
    ref2_str = 'ns..collname'
    assert not AnsibleCollectionRef.is_valid_collection_name(ref2_str)
    ref3_str = 'ns.${coll}'
    assert not AnsibleCollectionRef.is_valid_collection_name(ref3_str)
    ref4_str = 'ns.int'
    assert not AnsibleCollectionRef.is_valid_collection_name(ref4_str)
    ref5_str = 'ns.coll.collname'
    assert not AnsibleCollectionRef.is_valid_collection_name(ref5_str)


# Generated at 2022-06-21 08:19:28.883110
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
  # TODO: implement real test
  _AnsibleCollectionPkgLoaderBase()



# Generated at 2022-06-21 08:19:40.686176
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.resource.py') == True
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdir1.subdir2.resource.py') == True
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection') == False
    assert AnsibleCollectionRef.is_valid_fqcr('namespace.collection.subdir1.subdir2.subdir3') == False

# Generated at 2022-06-21 08:19:51.259554
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile
    import shutil
    import os.path
    import pkgutil

    # Create a tmp dir with a single collection (somens.somecoll)
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'somens/somecoll/plugins/filter'))
    with open(os.path.join(temp_dir, 'somens/somecoll/plugins/filter/test_plugin.py'), 'w') as f:
        f.write('class FilterModule: pass')

    # Create the collection finder and associated path hook finder
    ccf = _AnsibleCollectionFinder()
    ccf.set_playbook_paths([])


# Generated at 2022-06-21 08:20:03.576285
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('foo.bar.baz', ['/tmp/foo/bar/baz'])
    assert loader.get_filename('foo.bar.baz') == '/tmp/foo/bar/baz/__synthetic__'

    loader = _AnsibleCollectionPkgLoaderBase('foo.bar.baz', ['/tmp/foo/bar/baz/'])
    assert loader.get_filename('foo.bar.baz') == '/tmp/foo/bar/baz/__synthetic__'

    loader = _AnsibleCollectionPkgLoaderBase('foo.bar.baz', ['/tmp/foo/bar/baz/__synthetic__'])

# Generated at 2022-06-21 08:20:15.797914
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # This test should not be executed if ansible_collections is not available
    try:
        import ansible_collections # pylint: disable=unused-import
    except ImportError:
        return

    import ansible.module_utils.collection_loader as loader

    # Only test collection relative path
    search_path = ['.']

    # Test with a toplevel package
    toplevel_package = loader._AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.my_namespace',
        path_list=search_path,
    )
    expected_modules = [
        ('ansible_collections.my_namespace.my_collection', True),
        ('ansible_collections.my_namespace.my_collection.plugins', True),
    ]

# Generated at 2022-06-21 08:20:19.944409
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.not_ns.not_ns2')
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.ansible.not_ns2')
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.not_ns.not_ns2', path_list=['/not/a/valid/path'])
    with pytest.raises(ImportError):
        _AnsibleCollectionNSPkgLoader('ansible_collections.not_ns.not_ns2', path_list=['/not/a/valid/path'])
    # FIXME: this would probably be a better test if we

# Generated at 2022-06-21 08:20:25.280469
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('.')
    assert not loader.is_package('.')
    loader = _AnsibleCollectionPkgLoaderBase('__synthetic__')
    assert not loader.is_package('__synthetic__')
