

# Generated at 2022-06-21 08:13:24.229238
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Arrange
    fullname = 'ansible_collections.valid_ns'
    decoded_source = '# this is a valid ns package'
    collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(fullname)

    # Act
    collection_pkg_loader_base._decoded_source = decoded_source
    code_obj = collection_pkg_loader_base.get_code(fullname)

    # Assert
    assert code_obj.co_filename == '<string>'
    # Note: co_name is only available in the module scope in Python 3.
    # assert code_obj.co_name == '<module>'
    assert code_obj.co_argcount == 0
    assert code_obj.co_kwonlyargcount == 0
    assert code_obj.co_varn

# Generated at 2022-06-21 08:13:28.133646
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_collection_name = "f5networks.f5_modules"
    test_subdirs = None
    test_resource = "f5_bigip"
    test_ref_type = "module"
    expected_output = "AnsibleCollectionRef(collection=u'f5networks.f5_modules', subdirs=None, resource=u'f5_bigip')"

    ansible_collection_ref = AnsibleCollectionRef(test_collection_name, test_subdirs, test_resource, test_ref_type)
    output = ansible_collection_ref.__repr__()

    assert output == expected_output, "test AnsibleCollectionRef.__repr__() failed"



# Generated at 2022-06-21 08:13:38.514161
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-21 08:13:43.002893
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(path=['/tmp/ansible_collections/collection1/collection2/collection3/'],
                                         package='package1')
    assert loader._package_to_load == 'package1'
    assert loader._candidate_paths[0] == '/tmp/ansible_collections/collection1/collection2/collection3/package1'
    assert loader._fullname == 'ansible_collections.collection1.collection2.collection3.package1'
    assert loader._split_name == ['ansible_collections', 'collection1', 'collection2', 'collection3', 'package1']


__all__ = [
    'AnsibleCollectionRoute',
    'AnsibleCollectionConfig',
    'AnsibleCollectionLoader',
]

# Generated at 2022-06-21 08:13:48.081066
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert isinstance(collection_finder, _AnsibleCollectionFinder)
    assert len(collection_finder._n_playbook_paths) == 0
    assert len(collection_finder._n_configured_paths) == 0
    assert collection_finder._n_cached_collection_paths is None
    assert collection_finder._n_cached_collection_qualified_paths is None


# Generated at 2022-06-21 08:14:00.807696
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Create a dummy collection path
    collection_path = os.path.join(tempfile.gettempdir(), 'ansible_collections')
    os.mkdir(collection_path)
    # Create a dummy collection in the newly created path
    collection_name = 'awx.awx'
    collection_path = os.path.join(collection_path, collection_name)
    os.mkdir(collection_path)
    # Create a dummy collection module in the newly created path
    module_name = 'test_module'
    module_path = os.path.join(collection_path, module_name + '.py')
    open(module_path, 'a').close()
    # Create a dummy namespace package in the newly created path
    namespace_path = os.path.join(collection_path, '__init__.py')
    open

# Generated at 2022-06-21 08:14:11.515988
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import doctest
    test_result_test__AnsiblePathHookFinder___repr__ = doctest.testmod(
        name='test__AnsiblePathHookFinder___repr__',
        globs={
            '_AnsiblePathHookFinder': _AnsiblePathHookFinder,
            '_AnsibleCollectionFinder': _AnsibleCollectionFinder,
            'fullname': 'ansible_collections.my_ns.my_coll',
            'pathctx': '/foo/ansible_collections/my_ns/my_coll/',
            'collection_finder': _AnsibleCollectionFinder()
        },
        optionflags=doctest.NORMALIZE_WHITESPACE
    )
    assert test_result_test__AnsiblePathHookFinder___

# Generated at 2022-06-21 08:14:16.515010
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    _AnsibleCollectionLoader(fullname='ansible.test.test_loader', path=['/test/test_loader1'])


# Internal ansible-specific loader for things that can be found in collections, third party packages and builtin
# (this loader does not handle things only found in the collections namespace per se, that's handled by the
#  _AnsiblePluginLoaderBase class)

# Generated at 2022-06-21 08:14:19.232423
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # Test method __repr__ of class _AnsiblePathHookFinder
    finder = _AnsiblePathHookFinder(object, 'my/path')
    repr_str = repr(finder).format()
    assert repr_str == "_AnsiblePathHookFinder(path='my/path')"


# Base class for all ansible-specific loaders

# Generated at 2022-06-21 08:14:22.758649
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.is_valid_collection_name('n.c')
    assert not AnsibleCollectionRef.is_valid_collection_name('n.c.d')
    assert not AnsibleCollectionRef.is_valid_collection_name('')
    assert not AnsibleCollectionRef.is_valid_collection_name('n')
    assert not AnsibleCollectionRef.is_valid_collection_name('n.c.mor')



# Generated at 2022-06-21 08:15:11.768716
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    try:
        _AnsibleInternalRedirectLoader('foo', '')
        assert False, "Failed to raise error ImportError"
    except ImportError as e:
        pass  # Expected

    try:
        _AnsibleInternalRedirectLoader('foo.bar', '')
        assert False, "Failed to raise error ImportError"
    except ImportError as e:
        pass  # Expected

    try:
        _AnsibleInternalRedirectLoader('foo.bar.baz', '')
        assert False, "Failed to raise error ImportError"
    except ImportError as e:
        pass  # Expected

    try:
        _AnsibleInternalRedirectLoader('ansible.baz', '')
        assert False, "Failed to raise error ImportError"
    except ImportError as e:
        pass 

# Generated at 2022-06-21 08:15:15.468398
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from . import collection_loader
    from .collection_loader import AnsibleCollectionConfig, AnsibleCollectionMeta
    from .collection_loader import iter_collections
    from .collection_loader import locate_collections
    from .collection_loader import load_collections
    from .collection_loader import path_hook_factory

    fullname = 'ansible.module_utils.facts'
    path_list = None

    loader = collection_loader._AnsibleInternalRedirectLoader(fullname=fullname, path_list=path_list)
    loader.load_module(fullname=fullname)



# Generated at 2022-06-21 08:15:26.107120
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import sys
    # version = sys.version_info[0]*10 + sys.version_info[1]
    # if version < 36:
    #     raise Exception('Need current version of Python. Must be >= 3.6, is ',str(version))

    import io
    import tempfile
    import shutil

    import ansible.module_utils.six as six

    def test_ansible_collections_pkg_path():
        collection_finder = _AnsibleCollectionFinder()
        collection_finder._install()

# Generated at 2022-06-21 08:15:36.944350
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Create a dummy collection path
    dummy_path = mkdtemp(suffix='collections')
    # Create a dummy collection package
    dummy_package = 'dummy_package'
    dummy_path_package = os.path.join(dummy_path, dummy_package)
    os.mkdir(dummy_path_package)
    # Create a dummy file
    dummy_file = 'dummy_file.py'
    with open(os.path.join(dummy_path_package, dummy_file), 'w') as f:
        f.write('')
    # Create a dummy package
    dummy_package_dir = 'dummy_package_dir'
    dummy_path_package_dir = os.path.join(dummy_path_package, dummy_package_dir)

# Generated at 2022-06-21 08:15:38.300492
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    pass



# Generated at 2022-06-21 08:15:45.171090
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('test.test')
    assert AnsibleCollectionRef.is_valid_collection_name('test.test_test')
    assert not AnsibleCollectionRef.is_valid_collection_name('test-test.test')
    assert not AnsibleCollectionRef.is_valid_collection_name('test.test.test')



# Generated at 2022-06-21 08:15:46.437641
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('namespace.collection.subpackage')
    if len(loader._split_name) != 3:
        return False
    return True


# Generated at 2022-06-21 08:15:55.466670
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    print("Testing method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef")
    ref = AnsibleCollectionRef('', '', '', '')
    assert ref.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert ref.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert ref.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    try:
        assert ref.legacy_plugin_dir_to_plugin_type('my_plugin_type')
        assert 0
    except ValueError:
        pass
    print("unit test for AnsibleCollectionRef's method legacy_plugin_dir_to_plugin_type: OK !")

# Generated at 2022-06-21 08:16:01.220508
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import_redirection = {}
    import_redirection['ansible.collections.test.test_collection.test_plugin'] = {'redirect':'ansible.collections.test.test_collection_plugins.test_plugin'}
    _AnsibleCollectionConfig._routing['ansible.builtin'] = import_redirection
    loader = _AnsibleInternalRedirectLoader('ansible.collections.test.test_collection.test_plugin', [])
    result = loader.load_module('ansible.collections.test.test_collection.test_plugin')
    result_name = result.__name__
    expected = 'ansible.collections.test.test_collection.test_plugin'

# Generated at 2022-06-21 08:16:13.893106
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    path_list = ['/path/to/somewhere']
    fullname = 'ansible_collections.somewhere.somenamespace.somemodule'
    pkg = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert pkg.get_code(fullname) is None
    pkg = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert pkg.get_code(fullname) is None
    pkg = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert pkg.get_code(fullname) is None
    pkg = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert pkg.get_code(fullname) is None
    pkg = _Ansible

# Generated at 2022-06-21 08:16:46.931364
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # TODO: Complete unit test
    pass

# Generated at 2022-06-21 08:16:51.755691
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = "paloaltonetworks.panos.panos_template.j2"
    type = "lookup"
    success = "paloaltonetworks.panos"
    ans_ref = AnsibleCollectionRef.from_fqcr(ref, type)
    assert str(ans_ref) == success


# Generated at 2022-06-21 08:16:54.634725
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    try:
        _AnsibleCollectionRootPkgLoader('ansible_collections')
    except:
        raise AssertionError('test__AnsibleCollectionRootPkgLoader() failed.')



# Generated at 2022-06-21 08:17:04.802037
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # test data
    pathctx = '/path/to/ansible_collections/ansible_collections_mfg_test/__init__.py'
    collection_finder = AnsibleCollectionConfig.collection_finder
    collection_finder._n_cached_collection_qualified_paths = ['ansible_collections']
    fullname = 'ansible_collections'
    path = []
    # call find_module
    res = _AnsiblePathHookFinder(collection_finder, pathctx).find_module(fullname, path)
    # assert module is loaded
    assert res.load_module(fullname) is not None

    # test data
    pathctx = '/path/to/ansible_collections/ansible_collections_mfg_test/__init__.py'
    collection_finder = AnsibleCollection

# Generated at 2022-06-21 08:17:14.782839
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import ast
    import tempfile
    import shutil
    import sys
    import os

    simple_source = '''
        def test_func():
            return 'test string'

        '''

    simple_import = '''
        import test_module

        def test_func():
            return test_module.test_func()
    '''

    class TestSubclass(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]
            self._package_to_load = self

# Generated at 2022-06-21 08:17:26.603724
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    import inspect
    import unittest
    import ansible.module_utils.ansible_collection_finder

    def mock_collection_finder_find_module(fullname, path=None):
        return _AnsiblePathHookFinder(mock_collection_finder_instance, '/path/to/find/module')

    def mock_collection_finder_iter_modules(prefix):
        return []

    mock_collection_finder_instance = unittest.mock.MagicMock()
    mock_collection_finder_instance.find_module = unittest.mock.MagicMock(side_effect=mock_collection_finder_find_module)

# Generated at 2022-06-21 08:17:30.672049
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(path='/var/lib/awx/venv3/lib/python3.6/site-packages/ansible_collections/ansible/builtin')
    assert loader is not None


# Generated at 2022-06-21 08:17:41.063960
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    with pytest_plugins.allow_modules(['pytest_plugins']):
        from ansible_collections.community.network.tests.unit.test_utils import load_test_plugins
        load_test_plugins()

    # VALID REFERENCES
    # valid FQCRs with module ref_type
    assert AnsibleCollectionRef.is_valid_fqcr('ansible.builtin.ping')
    assert AnsibleCollectionRef.is_valid_fqcr('ansible.builtin.copy', 'module')
    # valid FQCRs with module ref_type and subdirs
    assert AnsibleCollectionRef.is_valid_fqcr('ansible.builtin.subdir1.subdir2.ping')

# Generated at 2022-06-21 08:17:45.990095
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    path_list = ['/etc/ansible/ansible.cfg']
    fullname = 'a.b.c.d.e'
    module = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    module.get_code(fullname)


# Generated at 2022-06-21 08:17:50.321461
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    sys.modules['ansible.module_utils'] = 1
    p = _AnsibleInternalRedirectLoader('ansible.module_utils', None)
    p.load_module('ansible.module_utils')
# Tests for loaders

# Generated at 2022-06-21 08:19:08.136827
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.random.plugin', ['foo/bar'])
    obj._get_candidate_paths = Mock(return_value=['foo/bar/random/plugin'])
    obj._get_subpackage_search_paths = Mock(return_value=['foo/bar/random/plugin'])
    obj.get_filename = Mock(return_value='foo/bar/random/plugin/__init__.py')
    result = obj.load_module('ansible_collections.random.plugin')
    assert result == 'ansible_collections.random.plugin'
    result = obj.load_module('ansible_collections.random.plugin')
    assert result == 'ansible_collections.random.plugin'


# Generated at 2022-06-21 08:19:12.867735
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(u'ns.coll', u'', u'mod1', u'module')
    assert ref.__repr__() == "AnsibleCollectionRef(collection='ns.coll', subdirs='', resource='mod1')"



# Generated at 2022-06-21 08:19:17.583768
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    self_object = _AnsibleCollectionFinder()
    self_object.set_playbook_paths(playbook_paths=['/path/collections'])
    assert self_object._n_playbook_paths == ['/path/collections/collections']


# Generated at 2022-06-21 08:19:21.552859
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # Test that the _filefinder_path_hook attribute is correctly set.
    filefinder_path_hook = _AnsiblePathHookFinder._filefinder_path_hook

    assert(filefinder_path_hook is not None)


# Generated at 2022-06-21 08:19:23.595375
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    l = _AnsibleInternalRedirectLoader('ansible.module_utils', None)
    assert l is not None


# Generated at 2022-06-21 08:19:30.378912
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    try:
        _AnsibleCollectionPkgLoaderBase(fullname='x.x', path_list=['y'])
    except ImportError:
        pass
    else:
        assert False, 'Expected ImportError exception'

    try:
        _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.x.x', path_list=['y'])
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError exception'

    try:
        _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.x.x', path_list=['y'])
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError exception'

    # loaders are compared by loader_namespace
    a = _Ansible

# Generated at 2022-06-21 08:19:41.542196
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    print('Test function load_module of class _AnsibleCollectionPkgLoader')

    test_module_name = 'AnsibleCollectionPkgLoader_test_module'
    test_package_name = test_module_name + '.package'

    # Setup metadata store
    metadata_cache = {}
    _meta_yml_to_dict = lambda data, filename: metadata_cache

    # Setup module store
    module_store = {}
    sys.modules = module_store

    test_package_path = 'test_package_path'
    ansible_all_test_path = 'ansible_test_path'
    test_meta_data = 'test_meta_data'

    # Test 1 - Test with __path__ variable filled and metdata file present

# Generated at 2022-06-21 08:19:42.554625
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    pass

# Generated at 2022-06-21 08:19:43.920405
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    finder = _AnsiblePathHookFinder(None, '/ansible_path')
    assert finder._pathctx == '/ansible_path'
    assert finder._collection_finder is None


# Generated at 2022-06-21 08:19:52.794809
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:20:23.716151
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    class IterModuleTestCase(unittest.TestCase):
        def test(self):
            class ModuleMock:
                def __init__(self, fullname):
                    self._fullname = fullname

            loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test')
            loader._subpackage_search_paths = ['/blah1', '/blah2', '/blah3']
            loader._redirect_module = ModuleMock('ansible_collections.redirected')
            module_mocks = [ModuleMock('ansible_collections.test.{0}'.format(i)) for i in ['123', 'abc', '456']]


# Generated at 2022-06-21 08:20:35.525879
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    valid_fqcr = AnsibleCollectionRef.is_valid_fqcr
    assert valid_fqcr(u'my_collection.my_module') is True
    assert valid_fqcr(u'my_collection.some_playbook') is True
    assert valid_fqcr(u'my_collection.my_role') is True
    assert valid_fqcr(u'my_collection.my_plugin') is True
    assert valid_fqcr(u'my_collection.my_playbook.yml') is True
    assert valid_fqcr(u'my_collection.my_playbook.yamll') is True
    assert valid_fqcr(u'my_collection.my_playbook.yaml') is True

# Generated at 2022-06-21 08:20:38.239316
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_finder = _AnsibleCollectionFinder()
    collection_finder.set_playbook_paths(['/foo/bar', '/baz'])



# Generated at 2022-06-21 08:20:48.096562
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    cf = _AnsibleCollectionFinder()
    cf._install()
    filename = 'ansible_collections/foo/bar/plugins/modules/create_user.py'
    apthf = _AnsiblePathHookFinder(cf, 'foo')
    # ensure _AnsiblePathHookFinder is a callable that returns an _AnsiblePathHookFinder
    assert callable(_AnsiblePathHookFinder)
    assert isinstance(apthf, _AnsiblePathHookFinder)
    # ensure _AnsiblePathHookFinder._get_filefinder_path_hook is a callable
    assert callable(_AnsiblePathHookFinder._get_filefinder_path_hook)
    # ensure _AnsiblePathHookFinder.find_module is a callable


# Generated at 2022-06-21 08:20:59.351099
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', 'module')
    assert ref.collection == u'ns.coll'
    assert ref.subdirs == u''
    assert ref.resource == u'resource'
    assert ref.ref_type == u'module'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.subdir.resource', 'module')
    assert ref.collection == u'ns.coll'
    assert ref.subdirs == u'subdir'
    assert ref.resource == u'resource'
    assert ref.ref_type == u'module'

    ref = AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role')
    assert ref.collection == u'ns.coll'
    assert ref.subdirs == u

# Generated at 2022-06-21 08:21:09.682941
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections', path_list=[dir_path])
    assert loader.get_source('ansible_collections') is None
    assert loader.get_source('ansible_collections.acme_infra_plugins') == '# ansible_collections.acme_infra_plugins'
    assert loader.get_source('ansible_collections.acme_infra_plugins.robots') == '# ansible_collections.acme_infra_plugins.robots'
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme_infra_plugins', path_list=[dir_path])

# Generated at 2022-06-21 08:21:18.285323
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys


    class _TestLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass


        def _validate_final(self):
            self._decoded_source = '''print(__loader__)
print(__file__)
print(__package__)
print(sys.modules['__loader__'])
print(sys.modules['__file__'])
print(sys.modules['__package__'])
'''
            self._compiled_code = compile(self._decoded_source, 'module_file.py', 'exec', 0, True)
            self._source_code_path = 'module_file.py'


    module_ns = {}
    loader = _TestLoader('ansible.maths.add')

# Generated at 2022-06-21 08:21:28.518265
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid inputs
    import pytest
    from ansible.errors import AnsibleError
    from ansible.parsing.plugin_docs import read_docstring


# Generated at 2022-06-21 08:21:31.733447
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    path_hook_finder = _AnsiblePathHookFinder(collection_finder='collection_finder', pathctx='pathctx')
    assert repr(path_hook_finder) == "_AnsiblePathHookFinder(path='pathctx')"



# Generated at 2022-06-21 08:21:43.342080
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _TestAnsiblePkgLoader(_AnsibleCollectionPkgLoaderBase):
        pass
    __loader__ = _TestAnsiblePkgLoader('ansible_collections.ns1.foo')
    assert __loader__._fullname == 'ansible_collections.ns1.foo'
    assert __loader__._split_name == ['ansible_collections', 'ns1', 'foo']
    assert __loader__._rpart_name == ('ansible_collections.ns1', '.', 'foo')
    assert __loader__._parent_package_name == 'ansible_collections.ns1'
    assert __loader__._package_to_load == 'foo'

