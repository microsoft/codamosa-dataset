

# Generated at 2022-06-21 08:13:38.513615
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    global _meta_yml_to_dict
    _meta_yml_to_dict = lambda x, y: {}
    path = ['/test/test']
    split_name = ['ansible_collections', 'alt_namespace', 'alt_collection', 'test']
    loader = _AnsibleCollectionLoader(path, split_name)
    assert loader._fullname == 'ansible_collections.alt_namespace.alt_collection.test'
    assert loader._split_name == ['ansible_collections', 'alt_namespace', 'alt_collection', 'test']
    assert loader._package_to_load == 'test'
    assert loader._candidate_paths == ['/test/test']
    assert loader._subpackage_search_paths is None
    assert loader._redirect_module is None
    assert loader

# Generated at 2022-06-21 08:13:47.777052
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # rfe: replace with testinfra test

    # fixtures
    class _Module:
        def __init__(self, name, init_file=''):
            self.__name__ = name
            self._init_file = init_file

        def __init__subclass__(cls, **kwargs):
            return None

        def __getattr__(self, value):
            return None


# Generated at 2022-06-21 08:14:00.550680
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
  
    # This is the path from which we are gonna load the code
    path = "ansible_collections/juniper/junos/plugins/module_utils/network/junos/junos.py"
    # From 'sys' we get the module name
    module_name = sys.modules["ansible_collections.juniper.junos.plugins.module_utils.network.junos.junos"].__name__
   
    # Instantiate the _AnsibleCollectionPkgLoaderBase class
    cl = _AnsibleCollectionPkgLoaderBase(module_name, path)
   
    # Test get_source
    source_code = cl.get_source(module_name)
    assert source_code
    # Check the presence of the 'Copyright' word in the source code
    assert "Copyright" in source_code
# Unit

# Generated at 2022-06-21 08:14:04.667826
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible.utils import path_dwim
    import os
    import tempfile
    import base64

# Generated at 2022-06-21 08:14:07.142234
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    _AnsibleCollectionPkgLoader('foo', 'bar')

# local loader implementations used by this module
_loader_implementations = dict(
    root_pkg=_AnsibleCollectionRootPkgLoader,
    ns_pkg=_AnsibleCollectionNSPkgLoader,
    coll_pkg=_AnsibleCollectionPkgLoader,
    coll_ns_pkg=_AnsibleCollectionNSPkgLoader
)



# Generated at 2022-06-21 08:14:15.806100
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _AnsibleInternalRedirectLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    class TestObj:
        def __init__(self):
            self.collections = AnsibleCollectionConfig([])
            self.redirected_package_map = {}
            self.redirect = None
            self.fullname = 'ansible.builtin.some_random_module'
            self.path_list = []

    obj = TestObj()
    AnsibleCollectionConfig._config = obj.collections
    obj.collections.collection_import_paths = []
    obj.collections.collection_paths = ['./collection']
    obj.collections.collection_ignore_dirs = []


# Generated at 2022-06-21 08:14:21.408038
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Test valid path_list:
    tl_path = ['/va/va/va']
    valid_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.va.va.va', path_list=tl_path)
    assert valid_loader is not None
    assert valid_loader._fullname == 'ansible_collections.va.va.va'
    assert valid_loader._split_name == ['ansible_collections', 'va', 'va', 'va']
    assert valid_loader._rpart_name == ('ansible_collections.va.va', 'va', None)
    assert valid_loader._parent_package_name == 'ansible_collections.va.va'
    assert valid_loader._package_to_load == 'va'

# Generated at 2022-06-21 08:14:23.721063
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import ansible
    # Currently ansible has many modules and is difficult to add test.
    # If the module is not found, we raise an exception.
    assert_raises(ImportError, _AnsibleCollectionPkgLoaderBase(ansible).load_module, 'ansible.module.not_found')



# Generated at 2022-06-21 08:14:29.928938
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    acr = AnsibleCollectionRef('my.collection', 'subdir1.subdir2', 'mymodule', 'module')
    res = repr(acr)
    assert res == "AnsibleCollectionRef(collection='my.collection', subdirs='subdir1.subdir2', resource='mymodule')"

# Generated at 2022-06-21 08:14:39.949611
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    # Testing arguments of the method
    # Declaring the arguments by replacing the actual values with dummy values
    # For the argument path, assigning a dummy value
    dummy_path = '/dummy path'
    # For the argument fullname, assigning a dummy value
    dummy_fullname = 'dummy fullname'
    # Declaring the class instance
    dummy_instance = _AnsibleCollectionPkgLoaderBase(dummy_fullname)
    # Calling the method with given arguments on the class instance
    dummy_instance.get_data(path=dummy_path)
    # Testing the arguments passed by the method
    # Checking if the argument path passed by the called method is equal to the given argument path
    assert dummy_path == dummy_path



# Generated at 2022-06-21 08:15:17.800201
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    print("in test__AnsibleCollectionPkgLoaderBase_get_filename()")
    # test get_filename()
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.a.b.c');
    ret = obj.get_filename(obj._fullname)
    assert(ret == obj._synthetic_filename(obj._fullname))
    print("assert(ret == obj._synthetic_filename(obj._fullname)) OK")


# Generated at 2022-06-21 08:15:24.887009
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    with open('module.py') as module_file:
        module_code = module_file.read()
    loader = _AnsibleCollectionPkgLoaderBase(None, None)
    loader._compiled_code = compile(source=module_code, filename='<string>', mode='exec', flags=0, dont_inherit=True)
    generated_code = loader.get_code(None)
    assert(generated_code is not None)
    assert(isinstance(generated_code, object))

# Generated at 2022-06-21 08:15:35.976543
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Create a new instance of _AnsibleCollectionFinder class
    ansible_collection_finder = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)

# Generated at 2022-06-21 08:15:41.757976
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoaderBase(None, None, None, None).load_module('ansible.collections.foo')

    _meta_yml_to_dict_invalid = lambda raw_data, origin: dict()
    _meta_yml_to_dict_valid = lambda raw_data, origin: dict(plugin_routing=dict(connection=dict(winrm1=dict(redirect='winrm'))))
    with pytest.raises(ValueError):
        with patch.object(AnsibleCollectionConfig, 'on_collection_load') as on_collection_load:
            _AnsibleCollectionPkgLoader('ansible', 'ansible.collections', 'mycoll', ['mycoll']) \
            ._AnsibleCollectionPkgLoader__canonicalize_

# Generated at 2022-06-21 08:15:52.308061
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from ansible.utils.collection_loader import _AnsibleCollectionFinder

    c = _AnsibleCollectionFinder()
    c._n_cached_collection_paths = None

    # T1
    c._n_playbook_paths = None
    c.set_playbook_paths('test_playbook_paths')
    assert c._n_playbook_paths == ['test_playbook_paths']

    # T2
    c._n_playbook_paths = []
    c.set_playbook_paths('test_playbook_paths')
    assert c._n_playbook_paths == ['test_playbook_paths']

    # T3
    c._n_playbook_paths = ['test_playbook_paths_1']
    c.set_

# Generated at 2022-06-21 08:15:56.430298
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Given
    ref = 'Colref.resource'
    ref_type = 'modules'
    # When
    ansibref = AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
    # Then
    assert ansibref is None

# Generated at 2022-06-21 08:16:00.301040
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('test')
    assert loader._fullname == 'test'
    assert loader._package_to_load == 'test'
    assert loader._source_code_path is None
    assert loader._subpackage_search_paths is None
    assert loader._split_name == ['test']
    assert loader._candidate_paths == []
    try:
        loader.load_module(None)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-21 08:16:13.389295
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    import sys
    import types
    import pwd
    import tempfile
    import pytest

    def get_uid(user_name):
        try:
            return pwd.getpwnam(user_name).pw_uid
        except KeyError:
            return None

    # Create the collection finder with no path to search
    apf = _AnsiblePathHookFinder(_AnsibleCollectionFinder(paths=[]),
                                 'test__AnsiblePathHookFinder_find_module')

    # 1. Test find ansible module, ansible_collections module
    assert apf.find_module('ansible', None) is None
    assert apf.find_module('ansible_collections', None) is None

    # 2. Test find ansible module, ansible_collections

# Generated at 2022-06-21 08:16:21.581821
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    print('\nUNIT TEST for method is_valid_fqcr of class AnsibleCollectionRef')
    acr = AnsibleCollectionRef('namespace1.collection1', None, 'library', 'module')
    assert acr.is_valid_fqcr('namespace1.collection1.modulename', 'module')
    assert not acr.is_valid_fqcr('namespace1.collection1.rolename')
    assert acr.is_valid_fqcr('namespace1.collection1.rolename', 'role')
    assert not acr.is_valid_fqcr('namespace1.collection1.rolename', 'module')
    assert acr.is_valid_fqcr('namespace1.collection1.rolename.yml')

# Generated at 2022-06-21 08:16:27.476411
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ansible')
    assert loader._package_to_load == 'ansible'


# Implements Python namespace package support for collection packages. This is the same as the standard PEP420 namespace
# package loader, but allows packages with no code and uses a more reliable directory existence check instead of relying
# on getting lucky with the OS directory enumeration and imp.find_module.

# Generated at 2022-06-21 08:18:01.611689
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    base_collection_finder = _AnsibleCollectionFinder([])
    assert base_collection_finder.__class__ == _AnsibleCollectionFinder



# Generated at 2022-06-21 08:18:04.024134
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('mycollection.mynamespace') == True


# Generated at 2022-06-21 08:18:08.457650
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import warnings
    warnings.warn("test code needs to be copied over", DeprecationWarning)
    return True


# main-level import machinery
_ansible_collection_finder = None



# Generated at 2022-06-21 08:18:19.479149
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    path_list = [
        '/usr/share/ansible/collections/ansible_collections/somename/somesubpackage',
        '/my/custom/collection/path/somename/somesubpackage'
    ]
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.somename.somesubpackage',
        path_list=path_list
    )

    assert_equals(loader.get_filename(loader._fullname), loader._source_code_path)
    assert_equals(loader.get_filename(loader._fullname), '/my/custom/collection/path/somename/somesubpackage')

    assert_true(loader.is_package(loader._fullname))

# Generated at 2022-06-21 08:18:26.036407
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('', [])
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('foo', [])

    # non-existent module to load, empty collection routing config
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('ansible.random_module', [])

    # TODO: mock up some routing with a redirect, and make sure it gets used....


# the path hook implementation that our import hook uses

# Generated at 2022-06-21 08:18:33.693625
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # Test implementation of iter_modules
    import collections

    class _TestAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(_TestAnsibleCollectionPkgLoaderBase, self).__init__(fullname, path_list)

        def _validate_final(self):
            pass

    loader = _TestAnsibleCollectionPkgLoaderBase('ansible_collections.foobar')
    assert collections.Callable(loader.iter_modules)

    # TODO: test to iter_modules with path_list value
    # TODO: test to iter_modules with prefix value
    # TODO: test to iter_modules without path_list and prefix



# Generated at 2022-06-21 08:18:35.753523
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fullname = 'ansible.module_utils'
    path_list = []
    _ansible_internal_redirect_loader = _AnsibleInternalRedirectLoader(fullname,path_list)
    _ansible_internal_redirect_loader.load_module('ansible.module_utils')



# Generated at 2022-06-21 08:18:41.058211
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("namespace.collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("some.bad.namespace.collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespacebad.collection")
    assert not AnsibleCollectionRef.is_valid_collection_name("namespace.collectionbad")
