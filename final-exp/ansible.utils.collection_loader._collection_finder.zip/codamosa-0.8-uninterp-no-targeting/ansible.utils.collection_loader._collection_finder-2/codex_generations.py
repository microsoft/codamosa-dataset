

# Generated at 2022-06-21 08:13:24.230319
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    path_list = ['/a/b/c', '/a/b/d']
    fullname = 'foo.bar'
    split_name = fullname.split('.')
    toplevel_pkg_name = split_name[0]
    toplevel_pkg_file_name = toplevel_pkg_name + '.py'
    fullname_module_file_name = fullname.replace('.', '/') + '.py'
    fullname_module_file_path = os.path.join(path_list[0], fullname_module_file_name)

    # Test the case that a module is imported without path_list parameter (i.e. no namespace/collection/module directory structure).
    with pytest.raises(Exception):
        _AnsibleCollectionPkgLoaderBase(fullname)


# Generated at 2022-06-21 08:13:36.730219
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class_under_test = _AnsibleInternalRedirectLoader
    split_name = []
    path_list = []
    redirect = None
    ansible_meta = {}

# Generated at 2022-06-21 08:13:40.536852
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import doctest
    import collections
    g = globals()
    l = locals()
    doctest.testmod(collections, globs=g, verbose=True, optionflags=doctest.ELLIPSIS)

############################################################
# _AnsibleCollectionPkgFoundLoaderBase
#
# A base class for collection package loaders that have successfully found a location for the package on disk
############################################################

# Generated at 2022-06-21 08:13:48.951751
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    collection_name = 'collections'
    if collection_name != 'collections':
        raise Exception(collection_name + ' is not equal to collections')

    # Test case where if "collection_name" is collections, an exception is thrown
    fullname = 'ansible_collections.collections'
    if fullname != 'ansible_collections.collections':
        raise Exception(fullname + ' is not equal to ansible_collections.collections')

    pkg_name = '__init__'
    if collection_name != 'collections':
        raise Exception(collection_name + ' is not equal to collections')

    loader = _AnsibleCollectionLoader(collection_name, pkg_name)
    loader._validate_args()
    loader = _AnsibleCollectionLoader(collection_name, '__init__')
    loader

# Generated at 2022-06-21 08:13:52.475563
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible_collections.somens.myns.mynspkg import my_pkg_ns_var

    assert my_pkg_ns_var == 42



# Generated at 2022-06-21 08:14:04.217485
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    from ansible.plugins.loader import find_plugin_filter

    expected_results = {
        '': False,
        'a': False,
        'a.b': False,
        'a.b.c': True,
        'a.b.c.d': True,
        '.a.b.c.d': False,
        'a.b.c.d.': False,
        'a.b.c.d.e.f': True,
    }

    for test_string in expected_results.keys():
        result = AnsibleCollectionRef.is_valid_fqcr(test_string)
        assert result == expected_results[test_string]

    # plugin_type-specific tests
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c', 'filter') is False
   

# Generated at 2022-06-21 08:14:13.829542
# Unit test for method find_module of class _AnsibleCollectionFinder

# Generated at 2022-06-21 08:14:24.594353
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import imp
    import shutil
    import tempfile


# Generated at 2022-06-21 08:14:28.909221
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    try:
        # test invalid arguments
        loader = _AnsibleCollectionPkgLoaderBase('ansible.plugins.meta')
    except ImportError:
        pass
    else:
        raise AssertionError('ImportError was not raised')

    # find_module/create loader test
    base_path = os.path.dirname(__file__)
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible_internal.cc', path_list=[base_path])

    assert loader._fullname == 'ansible_collections.ansible_internal.cc'
    assert loader._package_to_load == 'cc'
    assert loader._parent_package_name == 'ansible_collections.ansible_internal'

# Generated at 2022-06-21 08:14:38.570897
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    def test_func(body, filename, **kwargs):
        class _TestLoader(_AnsibleCollectionPkgLoaderBase):
            _source_code_path = filename
            def get_source(this, name):
                return body

        loader = _TestLoader('ansible.collections.ns.pkg')
        assert loader.get_code('ansible.collections.ns.pkg') is not None

    testcases = [
        '',  # empty init
        '#'  # commented-out init
    ]

    for body in testcases:
        yield test_func, body, '__init__.py'



# Generated at 2022-06-21 08:15:07.903566
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Passing valid values as arguments
    AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'module')
    AnsibleCollectionRef('ns.coll', None, 'resource', 'module')
    AnsibleCollectionRef('ns.coll', '', 'resource', 'module')
    AnsibleCollectionRef('ns.coll', '', None, 'module')
    AnsibleCollectionRef('ns.coll', None, None, 'module')
    # Passing invalid values as arguments
    try:
        AnsibleCollectionRef('ns', 'subdir1.subdir2', 'resource', 'module')
    except ValueError:
        pass
    try:
        AnsibleCollectionRef('ns.coll.coll2', 'subdir1.subdir2', 'resource', 'module')
    except ValueError:
        pass

# Generated at 2022-06-21 08:15:10.326323
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=[os.path.join(EXAMPLE_COLLECTIONS_PATH, 'ansible_collections')])
    assert loader is not None, 'Something went wrong in the constructor of _AnsibleCollectionRootPkgLoader which is the foundation'



# Generated at 2022-06-21 08:15:12.083755
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    finder = _AnsiblePathHookFinder(None, '/some/path')
    assert finder.__repr__() == "_AnsiblePathHookFinder(path='/some/path')"


# Generated at 2022-06-21 08:15:14.498668
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import inspect
    assert inspect.isclass(_AnsibleCollectionFinder)


# Generated at 2022-06-21 08:15:25.542771
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():

    paths = [
        '~/.ansible/collections',
        '/my/path/ansible_collections',
        '/other/path',
        '~/more/ansible_collections'
    ]

    expected_paths = [
        '~/.ansible/collections',
        '/my/path/ansible_collections',
        '/other/path',
        '~/more/ansible_collections'
    ]

    ansible_collection_finder = _AnsibleCollectionFinder(paths=paths)
    assert ansible_collection_finder._n_playbook_paths == []
    assert ansible_collection_finder._n_cached_collection_paths is None
    assert ansible_collection_finder._n_cached_collection_qualified_paths is None

    ansible_collection_

# Generated at 2022-06-21 08:15:36.595094
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print('#'*10 + 'Start test__AnsibleCollectionPkgLoaderBase_get_data')
    loader = _AnsibleCollectionPkgLoaderBase('myns', path_list=[])
    # Case: path not specified
    try:
        loader.get_data('')
    except ValueError as e:
        assert e.args == ('a path must be specified',)
    # Case: path not in search paths
    assert loader.get_data('/tmp/test.txt') is None
    # Case: file exist and could be found
    with open('/tmp/test.txt', 'wb') as f:
        f.write(b'hello world!')
    assert loader.get_data('/tmp/test.txt') == b'hello world!'
    # Case: file exist but couldn't be found
    # No

# Generated at 2022-06-21 08:15:46.976474
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    collections = ['dummy.dummy', 'dummy.dummy.dummy', 'dummy.dummy-dummy']
    for collection in collections:
        assert True == AnsibleCollectionRef.is_valid_collection_name(collection)
    collections = ['dummy.dummy.dummy.dummy', 'dummy-dummy.dummy', 'dummydummy.dummy']
    for collection in collections:
        assert False == AnsibleCollectionRef.is_valid_collection_name(collection)


# Generated at 2022-06-21 08:15:48.807988
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    _AnsibleInternalRedirectLoader('ansible.builtin.jmespath', '')



# Generated at 2022-06-21 08:15:51.844748
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    f = _AnsiblePathHookFinder(collection_finder=None, pathctx='abc')
    assert f._pathctx == 'abc'
    assert f._collection_finder is None



# Generated at 2022-06-21 08:15:53.266319
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections', ['/path/to/place'])
    assert loader._fullname == 'ansible_collections'
    assert loader._source_code_path is None


# Generated at 2022-06-21 08:16:32.666715
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    try:
        # constructor
        finder = _AnsibleCollectionFinder()  # pylint:disable=import-outside-toplevel
    except Exception as e:
        print("_AnsibleCollectionFinder constructor failed %s" % e)
        raise e
    else:
        print("_AnsibleCollectionFinder constructor passed")



# Generated at 2022-06-21 08:16:36.330397
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    _AnsibleCollectionPkgLoaderBase_iter_modules_result = _AnsibleCollectionPkgLoaderBase().iter_modules(prefix=None)
    print(_AnsibleCollectionPkgLoaderBase_iter_modules_result)

# Generated at 2022-06-21 08:16:40.560654
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_path = '/usr/local/share/ansible/collections'
    collection_finder = _AnsibleCollectionFinder()
    collection_finder.set_playbook_paths(collection_path)
    assert collection_finder._n_playbook_paths == [os.path.join(collection_path, 'collections')]

# Generated at 2022-06-21 08:16:46.976484
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    collection_finder = _AnsibleCollectionFinder()
    assert collection_finder is not None
    assert collection_finder._ansible_pkg_path == os.path.dirname(sys.modules['ansible'].__file__)
    collection_finder.set_playbook_paths(['test_root_path'])
    assert collection_finder._n_playbook_paths == ['test_root_path/collections/']


# Generated at 2022-06-21 08:16:49.084086
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    path_hook_finder = _AnsiblePathHookFinder(_AnsibleCollectionFinder(), "/path/to/collections")
    assert repr(path_hook_finder) == "_AnsiblePathHookFinder(path='/path/to/collections')"



# Generated at 2022-06-21 08:16:53.827846
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import importlib.machinery
    import pkgutil

    root_path = "tests/fixtures/collection/redirect/ansible_collections/test_namespace_only/plugins/modules"
    sys.path.append(root_path)
    sys.path_hooks.append(_AnsibleCollectionFinder._ansible_collection_path_hook)

    # test the finder
    fullname = "ansible_collections.test_namespace_only.plugins.modules.test_name_only"
    path = [root_path]
    finder = _AnsiblePathHookFinder(None, root_path)
    loader = finder.find_module(fullname, path)
    assert isinstance(loader, importlib.machinery.SourceFileLoader)

    # test the finder for a child module


# Generated at 2022-06-21 08:16:55.967429
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    c = _AnsibleCollectionPkgLoader('path', 'fullname', 'package_to_load')
    c.load_module('fullname')


# Generated at 2022-06-21 08:17:07.741621
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    paths = _AnsibleCollectionFinder(['test/units/test_plugins_d/', 'test/units/test_plugins_d2/'])
    paths._install()
    paths._n_playbook_paths = ['test/units/test_plugins_d/', 'test/units/test_plugins_d2/']
    assert len(paths._n_collection_paths) == 2
    paths._reload_hack('ansible_collections.testns.testcoll1')
    paths._reload_hack('ansible_collections.testns2.testcoll2')

    assert paths.find_module('ansible_collections.testns.testcoll1.plugins.test_module') is not None



# Generated at 2022-06-21 08:17:12.892479
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class MyLoader(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return path_list
    loader = MyLoader('ansible.collections.myns')
    loader._subpackage_search_paths = ['.']
    loader.get_data('test_data/test_data_0') == b'bar\n'


# Generated at 2022-06-21 08:17:25.880594
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ar = AnsibleCollectionRef.from_fqcr('namespace.collection.resource', 'module')
    assert ar.n_python_package_name == 'ansible_collections.namespace.collection.plugins.module'
    assert ar.n_python_collection_package_name == 'ansible_collections.namespace.collection'
    assert ar.fqcr == 'namespace.collection.resource'
    assert ar.collection == 'namespace.collection'
    assert ar.subdirs == ''
    assert ar.resource == 'resource'
    assert ar.ref_type == 'module'

    ar = AnsibleCollectionRef.from_fqcr('namespace.collection.subdir1.subdir2.resource', 'module')

# Generated at 2022-06-21 08:17:59.762033
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import ansible.utils
    import ansible.utils.collection_loader as CL

    ### _AnsibleCollectionLoader.__init__() ###
    # Test 1
    # test inputs:
    # 1. fullname: 'ansible_collections.mycollections.my_collection'
    # 2. path: ['.../my_collection']
    # test output:
    # 1. excpected:
    #    1. _AnsibleCollectionLoader.__init__.__doc__: 'Load modules from a collection.
    #                                                   This loader handles loading modules from collections
    #                                                   (including redirecting modules to a different location).'
    #    2. _AnsibleCollectionLoader.__init__.__name__: '_AnsibleCollectionLoader'
    #    3. _AnsibleCollectionLoader._fullname:

# Generated at 2022-06-21 08:18:12.705753
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    p1 = AnsibleCollectionConfig.collection_paths[0]
    p2 = AnsibleCollectionConfig.collection_paths[1]
    p3 = AnsibleCollectionConfig.collection_paths[2]
    p4 = AnsibleCollectionConfig.collection_paths[3]
    p5 = AnsibleCollectionConfig.collection_paths[4]

    loader = _AnsibleCollectionPkgLoader('ansible.awxr.test_module',[p1, p2, p3, p4, p5])
    module = loader.load_module('ansible.awxr.test_module')
    module = loader.load_module('ansible.awxr.test_module')

    # test case 1
    # path = '^.*total_counts.json$'
    # expected = '^.*total_count

# Generated at 2022-06-21 08:18:18.157082
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # BEGIN TESTS
    module = _AnsiblePathHookFinder(None, '/tmp')
    assert repr(module), "{0}(path='{1}')".format(module.__class__.__name__, '/tmp')
    # END TESTS


# NB: this is *not* an import loader; it's provided to pkgutil.iter_modules

# Generated at 2022-06-21 08:18:27.668646
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    """
    Method: _AnsibleCollectionPkgLoader.load_module
    """
    import ansible
    from ansible.plugins.loader import action_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _AnsibleCollectionPkgLoader, _meta_yml_to_dict

    name ="test.module"
    ansible_on_collection_load_called = False
    def ansible_on_collection_load(collection_name='', collection_path=''):
        nonlocal ansible_on_collection_load_called
        ansible_on_collection_load_called = True
    AnsibleCollectionConfig.on_collection_load = ansible_on_collection_load
    _meta_yml_to_dict = lambda a,b: None

    module = _AnsibleCollectionPkgLoader

# Generated at 2022-06-21 08:18:32.740728
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = 'foo.bar.baz'
    spath = 'random/path'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list=[spath])
    assert loader.get_code(fullname) is None, "get_code should return None and not a code object if source is not readable"
    assert loader.get_code(fullname) is None, "get_code should return None and not a code object if source is not readable"


# Generated at 2022-06-21 08:18:40.168036
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:18:42.613439
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('ansible_collections.foo.bar.baz', collection_search_paths=[])
    assert loader._package_to_load == 'baz'
    assert loader._subpackage_search_paths is None
    assert loader._candidate_paths == []



# Generated at 2022-06-21 08:18:47.451301
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import os
    path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    collection_finder = _AnsibleCollectionFinder(paths=[path])
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, path)
    assert ansible_path_hook_finder.__repr__() == f"{_AnsiblePathHookFinder.__name__}(path='{path}')"
# END UNIT TEST
