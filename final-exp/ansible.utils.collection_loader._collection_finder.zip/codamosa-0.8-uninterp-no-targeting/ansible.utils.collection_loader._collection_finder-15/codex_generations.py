

# Generated at 2022-06-21 08:12:50.755695
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    # Positive test case

    # namespace.collection.resource is valid
    result = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'module')
    assert result.collection == 'namespace.collection'
    assert result.subdirs == ''
    assert result.resource == 'resource'
    assert result.ref_type == 'module'

    # namespace.collection.subdir.resource is valid
    result = AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir.resource', 'role')
    assert result.collection == 'namespace.collection'
    assert result.subdirs == 'subdir'
    assert result.resource == 'resource'
    assert result.ref_type == 'role'

    # namespace.collection.subdir1.subdir2.resource is valid
    result

# Generated at 2022-06-21 08:12:58.964402
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # _AnsibleCollectionPkgLoaderBase._get_candidate_paths(...)
    # test call of method get_source with no arguments
    # test that return value is None
    assert _AnsibleCollectionPkgLoaderBase().get_source() is None
    
    # test call of method get_source with one argument
    # test that return value is None
    assert _AnsibleCollectionPkgLoaderBase('arg1').get_source() is None
    

# Generated at 2022-06-21 08:13:07.012216
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():

    # test special case "ansible"
    loader1 = _AnsibleCollectionNSPkgLoader('ansible_collections.ansible', path_list=[None])
    assert loader1._split_name == ['ansible_collections', 'ansible']
    assert loader1._package_to_load == 'ansible'
    assert loader1._subpackage_search_paths is None

    # test general case namespace_package
    loader2 = _AnsibleCollectionNSPkgLoader('ansible_collections.foo', path_list=['/bar/baz'])
    assert loader2._split_name == ['ansible_collections', 'foo']
    assert loader2._package_to_load == 'foo'
    # just faking out the code that sets _subpackage_search_paths so we can get past this assertion
    loader

# Generated at 2022-06-21 08:13:19.105263
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class MockAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            if self._split_name[-1] == 'somemod':
                raise ImportError('this loader can only load packages from the '
                                  'ansible_collections package, not {0}'.format(self._fullname))
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

    mock_path_list = ['./test_data/ansible_collections/ns/collection/somens']
    clazz = MockAnsibleCollectionPkgLoaderBase('ansible_collections.ns.collection.somens')

# Generated at 2022-06-21 08:13:23.395210
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.yml')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.json')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.j2')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.resource')

# Generated at 2022-06-21 08:13:30.539829
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    expected_result = ['collections']
    acf = _AnsibleCollectionFinder()
    acf.set_playbook_paths(expected_result)
    actual_result = acf._n_playbook_paths
    assert expected_result == actual_result, 'expected_result: {0}, actual_result: {1}'.format(expected_result, actual_result)



# Generated at 2022-06-21 08:13:38.942593
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource1.resource2')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.resource.')

    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns_not.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll_not.resource')
   

# Generated at 2022-06-21 08:13:40.576127
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    obj = _AnsibleCollectionLoader
    obj.load_module(self, fullname)

# Generated at 2022-06-21 08:13:53.693542
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    '''Test if is_valid_fqcr return expected results.'''
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz', 'module')

    refs = [
        'foo',
        'foo.',
        'foo..bar',
        'foo.bar.',
        'foo.bar.baz.',
    ]
    for ref in refs:
        assert not AnsibleCollectionRef.is_valid_fqcr(ref, 'module')

    refs = [
        'foo.bar.baz',
        'foo.bar.baz/',
        'foo.bar.baz.',
    ]
    for ref in refs:
        assert not AnsibleCollectionRef.is_valid_fqcr(ref)


# Generated at 2022-06-21 08:13:58.857514
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible_collections.test.dummy.loading_utils import _AnsibleCollectionPkgLoaderBase
    parent = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.dummy.a')
    assert parent.is_package('ansible_collections.test.dummy.a') == True



# Generated at 2022-06-21 08:14:29.436650
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder()
    finder.set_playbook_paths(['/path/to/playbook/dir1', '/path/to/playbook/dir2'])
    paths = finder._n_playbook_paths
    assert paths[0] == '/path/to/playbook/dir1/collections'
    assert paths[1] == '/path/to/playbook/dir2/collections'


# Generated at 2022-06-21 08:14:31.393603
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():

    assert _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase__repr__()



# Generated at 2022-06-21 08:14:41.574195
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('demo.webservers.yaml')
    assert AnsibleCollectionRef.is_valid_fqcr('demo.webservers.yaml', ref_type='doc_fragment')
    assert AnsibleCollectionRef.is_valid_fqcr('demo.webservers.yaml', ref_type='module') is False
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar', ref_type='module')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz', ref_type='module')

# Generated at 2022-06-21 08:14:47.922714
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test good data
    assert AnsibleCollectionRef(collection_name="namespace.collection", subdirs=None, resource="resourcename", ref_type='module')
    assert AnsibleCollectionRef(collection_name="namespace.collection", subdirs="subdir1.subdir2", resource="resourcename", ref_type='module')
    assert AnsibleCollectionRef(collection_name="namespace.collection",
                                subdirs="subdir1.subdir2.subdir3.subdir4.subdir5.subdir6.subdir7.subdir8.subdir9.subdir10",
                                resource="resourcename", ref_type="module")

    # Test bad data

# Generated at 2022-06-21 08:14:57.988374
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None

# Iterates available collections modules under a given path.
#
# * Skips all private modules (the files which names start with ``_``).
# * If the ``prefix`` is given, skips all modules which do not start with
#   the prefix.
# * If the ``names_only`` is True, yields only the module names. Otherwise,
#   yields a tuple (module name, is package) for every module.
# * If the ``path`` is a string, yields only modules under that path. Otherwise
#   yields modules under all paths.
#
# NOTE: this represents only what's on disk, and does not handle package redirection

# Generated at 2022-06-21 08:15:01.563941
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    base_import_loader_instance = _AnsibleCollectionPkgLoaderBase("ansible_collections.foo")
    # TODO: add tests
    assert True



# Generated at 2022-06-21 08:15:09.382779
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    acr = AnsibleCollectionRef
    assert acr.is_valid_collection_name('namespace.collectionname')
    assert not acr.is_valid_collection_name('namespace.')
    assert not acr.is_valid_collection_name('.collectionname')
    assert not acr.is_valid_collection_name('namespace.collection name')
    assert not acr.is_valid_collection_name('namespace.collection-name')
    assert not acr.is_valid_collection_name('namespace.collection1.collection2')
    assert not acr.is_valid_collection_name('ansible')
    assert not acr.is_valid_collection_name('ansible.mycollection')
    assert not acr.is_valid_collection_name('ansible.my-collection')
    assert not ac

# Generated at 2022-06-21 08:15:13.759887
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Unit test for constructor of class _AnsibleInternalRedirectLoader
    # find_module will return _AnsibleInternalRedirectLoader if the import is redirected
    assert _AnsibleInternalRedirectLoader('ansible.module_utils.six', [])

    # find_module will return _AnsibleInternalRedirectLoader if the import is redirected
    # _get_ancestor_redirect in class _AnsibleCollectionLoader
    assert _AnsibleInternalRedirectLoader('ansible.module_utils.six.moves.input', [])


# TODO: should we be using importlib.machinery.PathFinder?

# Generated at 2022-06-21 08:15:22.337908
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # a source code string:
    source = "foo='bar'"
    # A python module instance:
    module = ModuleType('test_module')
    collection_loader = _AnsibleCollectionPkgLoaderBase(fullname='test_module', path_list=[''])
    # gets executed in the module's namespace:
    exec(collection_loader.get_code('test_module'), module.__dict__)
    # Testing the result:
    assert module.foo == 'bar', 'get_code method of _AnsibleCollectionPkgLoaderBase failed'



# Generated at 2022-06-21 08:15:34.363424
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # case: file: roles/foo
    pkg_loader = _AnsibleCollectionPkgLoader(name='ansible_collections.bar.foo.roles.foo',
                                             path=['/some/collection/path/bar-1.0.0/roles/foo'])
    assert pkg_loader._source_code_path is None
    assert pkg_loader._subpackage_search_paths is None

    # case: file: modules/foo
    pkg_loader = _AnsibleCollectionPkgLoader(name='ansible_collections.bar.foo.modules.foo',
                                             path=['/some/collection/path/bar-1.0.0/plugins/modules/foo'])
    assert pkg_loader._source_code_path is None
    assert pkg_loader._subpackage_

# Generated at 2022-06-21 08:16:14.437171
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Valid collection reference
    good_ref = AnsibleCollectionRef('ns.coll', 'subdir', 'res', 'type')
    good_ref_no_subdir = AnsibleCollectionRef('ns.coll', None, 'res', 'type')
    assert good_ref.collection == u'ns.coll'
    assert good_ref_no_subdir.collection == u'ns.coll'
    assert good_ref.subdirs == u'subdir'
    assert good_ref_no_subdir.subdirs == u''
    assert good_ref.resource == u'res'
    assert good_ref.ref_type == u'type'
    assert good_ref.fqcr == u'ns.coll.subdir.res'

# Generated at 2022-06-21 08:16:18.623223
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _meta_yml_to_dict
    
    @contextmanager
    def _new_or_existing_module(name, **kwargs):
        # handle all-or-nothing sys.modules creation/use-existing/delete-on-exception-if-created behavior
        created_module = False
        module = sys.modules.get(name)

# Generated at 2022-06-21 08:16:29.366815
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:16:39.858014
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:16:43.756057
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection = "test_collection.test_collection2"
    subdirs = "test_subdir"
    resource = "test_resource"
    ref_type = "module"

    assert repr(AnsibleCollectionRef(collection, subdirs, resource, ref_type)) == "AnsibleCollectionRef(collection='test_collection.test_collection2', subdirs='test_subdir', resource='test_resource')"

# Generated at 2022-06-21 08:16:48.423855
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import sys
    import os

    dirname = os.path.dirname
    pkgname = 'ansible_collections'
    path_list = [os.path.join(dirname(dirname(dirname(__file__)))),
                 os.path.join(dirname(dirname(dirname(dirname(__file__)))), 'ansible_collections')]
    loader = _AnsibleInternalRedirectLoader(pkgname, path_list)

    test_module = loader.load_module(pkgname)
    assert test_module == sys.modules[pkgname]


# handles locating collection metadata and performing namespace routing

# Generated at 2022-06-21 08:16:57.413793
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    obj = AnsibleCollectionRef(collection_name='ns.coll', subdirs='subdir1.subdir2', resource='res', ref_type='module')
    assert obj is not None
    assert obj.fqcr == u'ns.coll.subdir1.subdir2.res'
    assert obj.subdirs == u'subdir1.subdir2'
    assert obj.collection == u'ns.coll'
    assert obj.resource == u'res'
    assert obj.ref_type == u'module'

    with pytest.raises(ValueError):
        AnsibleCollectionRef(collection_name='ns.coll.', subdirs='subdir1.subdir2', resource='res', ref_type='module')


# Generated at 2022-06-21 08:17:10.296927
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import os
    import stat
    import tempfile

# Generated at 2022-06-21 08:17:23.684104
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    """
    Test _AnsibleInternalRedirectLoader class
    """
    global _get_collection_metadata
    saved_get_collection_metadata = _get_collection_metadata
    global _nested_dict_get
    saved_nested_dict_get = _nested_dict_get

    # Test when no import redirection is defined
    def mock_get_collection_metadata(collection_name):
        """
        mock _get_collection_metadata

        :arg collection_name: name of collection
        :returns: empty dictionary
        """
        return {}

    def mock_nested_dict_get(dict_, path):
        """
        mock _nested_dict_get

        :arg dict_:
        :arg path:
        :returns: None
        """
        return None

    _get_collection_metadata

# Generated at 2022-06-21 08:17:26.879410
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.ping', None)
    assert loader._redirect == 'ansible.network.ping'
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.any', None)
    assert loader._redirect is None


# Generated at 2022-06-21 08:18:01.218788
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase.__repr__(None) == '_AnsibleCollectionPkgLoaderBase(path=None)'


# Generated at 2022-06-21 08:18:13.868055
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    class Loader:
        def load_module(fullname):
            raise NotImplementedError('Please test with a real module, not a mock')

        def __init__(self, fullname):
            self._fullname = fullname

    hook = _AnsiblePathHookFinder(None, 'ansible_collections/test_col/test_ns')
    hook.find_module = lambda fullname, path: Loader(fullname)
    hook.iter_modules = lambda prefix: [(fullname, True, None) for fullname in ['test_col', 'test_ns.test_coll', 'test_ns.test_coll.test_module']]

    # is ansible_collections module?
    assert hook.find_module('ansible_collections')
    # is test_col namespace?
    assert hook.find

# Generated at 2022-06-21 08:18:24.444903
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.acme.foobar', ['/some/path/here'])

    assert loader._fullname == 'ansible_collections.acme.foobar'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections', 'acme', 'foobar']
    assert loader._rpart_name == ('ansible_collections.acme', '.', 'foobar')
    assert loader._parent_package_name == 'ansible_collections.acme'
    assert loader._package_to_load == 'foobar'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None


# Generated at 2022-06-21 08:18:25.309809
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('ansible.builtin.argument_spec')
    print(loader)

# Generated at 2022-06-21 08:18:33.652868
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Test for root level package, import error
    try:
        _AnsibleInternalRedirectLoader('test', 'test_path_list')
        assert False
    except ImportError:
        assert True

    # Test for builtin package, import error
    try:
        _AnsibleInternalRedirectLoader('ansible.test', 'test_path_list')
        assert False
    except ImportError:
        assert True

    # Test for builtin module, import error
    try:
        _AnsibleInternalRedirectLoader('ansible.builtin.test', 'test_path_list')
        assert False
    except ImportError:
        assert True

    # Test for builtin module, no import error

# Generated at 2022-06-21 08:18:36.527289
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import io
    import sys
    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out

        # setup
        cls = _AnsibleCollectionFinder()

        cls.set_playbook_paths(['bar.foo/things/collections', 'bar.foo/stuff/collections'])
        assert out.getvalue() == ''

    finally:
        sys.stdout = saved_stdout



# Generated at 2022-06-21 08:18:48.756849
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('shell') == 'shell'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('strategy') == 'strategy'
    assert Ansible

# Generated at 2022-06-21 08:19:00.206778
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError) as excinfo:
        _AnsibleCollectionRootPkgLoader(fullname='ansible_collections.foo')
        assert 'this loader can only load the ansible_collections toplevel package, not ansible_collections.foo' in str(excinfo.value)

    loader = _AnsibleCollectionRootPkgLoader(fullname='ansible_collections')
    assert loader
    assert loader._package_to_load == 'ansible_collections'
    assert loader._fullname == 'ansible_collections'
    assert loader._split_name == ['ansible_collections']
    assert loader._rpart_name == ('', 'ansible_collections', '')
    assert loader._parent_package_name == ''
    assert loader._redirect_module is None
    assert loader

# Generated at 2022-06-21 08:19:08.752653
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible_collections
    import ansible_collections.ansible
    import ansible_collections.ansible.builtin
    import ansible_collections.ansible.builtin.plugins

    def _test_paths(hook, paths):
        for m in [ansible_collections, ansible_collections.ansible, ansible_collections.ansible.builtin, ansible_collections.ansible.builtin.plugins, os]:
            assert hook.find_module(m.__name__) is not None

        # test a few random invalid imports
        assert hook.find_module('ansible_collections.some_namespace.some_collection.invalid_module') is None
        assert hook.find_module('invalid_module') is None

# Generated at 2022-06-21 08:19:20.731170
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    if False:
        pkg1 = 'ansible_collections.ns'
        pkg2 = 'ansible_collections.ns.module1'
        pkg3 = 'ansible.module_utils.compat.os'
        subfolder = 'module1'
        modules_path = './modules'
        module_path = './modules/module1'
        module_path2 = './library/module1'
        module_file = './modules/module1/__init__.py'
        module_file2 = './library/module1/__init__.py'
        root_module_file = './__init__.py'
        
        m_path_finder = _AnsibleModulePathFinder('', path=modules_path)
        m_path_finder.find_module(pkg1)


# Generated at 2022-06-21 08:19:50.690425
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module')
    print(loader.get_filename('ansible_collections.ns.module'))


# Generated at 2022-06-21 08:20:00.707235
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Test if it throws an error when playbook_paths is not a string or list
    with pytest.raises(TypeError):
        AnsibleCollectionConfig.collection_finder.set_playbook_paths(True)
    # Test if playbook_paths is a string
    # Test if playbook_paths is a list
    # Test if playbook_path is set correctly
    # Test if it throws an error when playbook_path is not a string
    with pytest.raises(TypeError):
        AnsibleCollectionConfig.collection_finder.set_playbook_paths(['path/to/playbook/', 1])

# Generated at 2022-06-21 08:20:09.463176
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import collections
    import json
    import time
    import random

    class Mock_Random:
        def __init__(self):
            self.random_call_count = 0

        def random(self):
            self.random_call_count += 1
            return 0.5

    class Test_AnsibleCollectionPkgLoaderBase(
        collections.namedtuple('Test_AnsibleCollectionPkgLoaderBase',
                               ['test_name',
                                'test_type',
                                'test_file',
                                'test_return_expectation',
                                'test_expected_random_calls']),
        _AnsibleCollectionPkgLoaderBase
    ):
        @staticmethod
        def _get_data_random_wrap(path):
            mock_random = Mock_Random()
            random_method = random

# Generated at 2022-06-21 08:20:18.644192
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Preconditions
    pass

    # Test
    results = []
    for item in _AnsiblePathHookFinder(None, '/tmp/ansible_collections/ns/coll').iter_modules(''):
        results.append(item)

    # Postconditions
    assert results == [
        ('ns/coll/hack/plugins/action/test_action', 'test_action', True),
        ('ns/coll/hack/plugins/action/test_action2', 'test_action2', True),
        ('ns/coll/test_plugin', 'test_plugin', True),
        ('ns/coll/test_plugin_symlink', 'test_plugin_symlink', True)
    ]



# Generated at 2022-06-21 08:20:30.326794
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    ###############################################################################################
    # create variable for unit test
    ###############################################################################################
    import logging
    import os
    import shutil
    log = logging.getLogger()
    log_fh = logging.FileHandler('_AnsibleCollectionPkgLoader_load_module.log')
    log_fh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    log.addHandler(log_fh)
    log.setLevel(logging.DEBUG)
    ROOT_DIR = os.path.dirname(os.path.realpath(__file__))
    dir_collections = os.path.join(ROOT_DIR, 'collections')
    collection_name = 'foo_bar'
    collection_name

# Generated at 2022-06-21 08:20:32.787557
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
  c = _AnsiblePathHookFinder('pathctx')
  assert c._pathctx == 'pathctx'


# Generated at 2022-06-21 08:20:42.630324
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    print('\n## test__AnsibleCollectionPkgLoaderBase_get_filename')
    _ansible_collections = '/usr/share/ansible/collections'
    filename = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.nsupdate.plugins.modules.module_utils.module_utils',
        path_list=[_ansible_collections]
    ).get_filename('ansible_collections.nsupdate.plugins.modules.module_utils.module_utils')
    assert filename == '/usr/share/ansible/collections/ansible_collections/nsupdate/plugins/modules/module_utils/module_utils/__init__.py'

# Generated at 2022-06-21 08:20:55.109621
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():

    # _meta_yml_to_dict is a variable that is not initialized.
    def test__AnsibleCollectionPkgLoader_load_module__no_meta_yml_to_dict():
        loader = _AnsibleCollectionPkgLoader(path=None, package_to_load='foo.bar', parent_package_name='foo')

        with pytest.raises(ValueError) as e:
            loader.load_module('foo.bar')

    # _meta_yml_to_dict is a variable that is initialized.
    def test__AnsibleCollectionPkgLoader_load_module__meta_yml_to_dict():
        loader = _AnsibleCollectionPkgLoader(path=None, package_to_load='foo.bar', parent_package_name='foo')

        # Expecting that the load_module

# Generated at 2022-06-21 08:21:05.940666
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    with pytest.raises(ValueError):
        AnsibleCollectionRef('aws', 'library', 's3', 'module')

    with pytest.raises(ValueError):
        AnsibleCollectionRef('aws', None, 's3', 'module')

    with pytest.raises(ValueError):
        AnsibleCollectionRef('aws', 'library', 's3', 'action')

    with pytest.raises(ValueError):
        AnsibleCollectionRef('aws', 'library', 's3', None)

    ref = AnsibleCollectionRef('aws', 'library', 's3', 'module')
    assert ref.collection == 'aws'
    assert ref.subdirs == 'library'
    assert ref.resource == 's3'
    assert ref.ref_type == 'module'

# Generated at 2022-06-21 08:21:11.118063
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import ansible_collections.somens.subns.subsubns
    l = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.subns.subsubns', [])
    assert l.load_module('ansible_collections.somens.subns.subsubns') == sys.modules['ansible_collections.somens.subns.subsubns']

# Generated at 2022-06-21 08:21:45.425524
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    try:
        '''Simple test of get_source method'''
        # Instantiate class with the necessary parameters
        path_list = ['/code/mazer/test/unit/fixtures/compat/import_test/ansible_collections']
        fullname = "ansible_collections.test"
        loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
        # Call get_source method
        loader.get_source(fullname)
    except Exception as err:
        print('Test failed!')
        print(err)
        return 1
    else:
        print('Test succeeded!')
        return 0

# Execute test method
test__AnsibleCollectionPkgLoaderBase_get_source()
