

# Generated at 2022-06-21 08:12:36.674114
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    pass

# Generated at 2022-06-21 08:12:48.368617
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import tempfile

# Generated at 2022-06-21 08:12:55.462687
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    acr = AnsibleCollectionRef
    assert acr.is_valid_collection_name(u'ns.name')
    assert not acr.is_valid_collection_name(u'ns.name.subdir')
    assert not acr.is_valid_collection_name(u'ns')
    assert not acr.is_valid_collection_name(u'')
    assert not acr.is_valid_collection_name(u'n.n')
    assert not acr.is_valid_collection_name(u'ns.n.n')
    assert not acr.is_valid_collection_name(u'ns.my-collection')
    assert not acr.is_valid_collection_name(u'ns.my.collection')

# Generated at 2022-06-21 08:13:03.535842
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    test = "test__AnsiblePathHookFinder___repr__()"
    try:
        assert _AnsiblePathHookFinder(None, 'hello') == str(_AnsiblePathHookFinder(None, 'hello'))
    except Exception as ex:
        print('{0} -- FAILED: "{1}"'.format(test, ex))
        return False
    else:
        print('{0} -- passed'.format(test))
        return True


# Generated at 2022-06-21 08:13:15.431306
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.collection_loader import _get_collection_metadata
    from ansible.utils.collection_loader import _nested_dict_get
    import sys
    import importlib
    # Test expected path when toplevel_pkg is not 'ansible'
    fullname = 'not.ansible.module'
    path_list = ['/ansible/lib/ansible']
    loader_obj = _AnsibleInternalRedirectLoader(fullname, path_list)
    try:
        loader_obj.load_module(fullname)
        raise AssertionError("Expected ImportError")
    except ImportError as e:
        assert "not interested" in str(e)
    # Test expected path when no redirection found
    fullname

# Generated at 2022-06-21 08:13:16.542911
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    pass


# Generated at 2022-06-21 08:13:24.892330
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    target_path = "./test_data/pkg_loader_base_test/target_path"
    loader = _AnsibleCollectionPkgLoaderBase("test.test", [target_path,])
    assert loader.get_data("target_file") == b"test file"
    assert loader.get_data("target_file.py") == b"test file"

# Generated at 2022-06-21 08:13:33.038801
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # invalid fullname
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase('foo.bar')
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase(None)
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase('ansible_collections', None)

    # loaders for ansible_collections top-level packages
    # TODO: test the remaining loader methods
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns')
    assert loader._split_name[0] == 'ansible_collections'
    assert loader._split_name[1] == 'test_ns'
    assert len(loader._split_name) == 2
    assert loader._rpart_name

# Generated at 2022-06-21 08:13:42.312780
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    fqcr = "ansible_collections.ns.coll.plugins.action.resource"
    ref = AnsibleCollectionRef.from_fqcr(fqcr)
    # expect ansible_collections.ns.coll.plugins.action.resource
    expected_n_python_package_name = "ansible_collections.ns.coll.plugins.action.resource"
    assert ref.n_python_package_name == expected_n_python_package_name
    # expect fqcr
    expected_fqcr = "ns.coll.resource"
    assert ref.fqcr == expected_fqcr
    # expect resource
    expected_resource = "resource"
    assert ref.resource == expected_resource
    # expect collection
    expected_collection = "ns.coll"
    assert ref.collection == expected_collection
   

# Generated at 2022-06-21 08:13:49.867942
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns', path_list=["non-existent-path"])
    assert loader._fullname == 'ansible_collections.ns'
    assert loader._redirect_module is None
    assert loader._split_name == ['ansible_collections', 'ns']
    assert loader._rpart_name == ('ansible_collections', '.', 'ns')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ns'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == ['non-existent-path/ns']
    assert loader._subpackage_search_

# Generated at 2022-06-21 08:14:25.247420
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    my_path_hook = _AnsiblePathHookFinder('/dev/null')
    assert my_path_hook
    assert isinstance(my_path_hook._collection_finder, _AnsibleCollectionFinder)
    assert my_path_hook._pathctx == '/dev/null'



# Generated at 2022-06-21 08:14:28.249271
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """ Unit tests for class _AnsiblePathHookFinder """
    test_path_finder = _AnsiblePathHookFinder(None, "data")

    if test_path_finder:
        assert test_path_finder
    else:
        assert not test_path_finder


# Generated at 2022-06-21 08:14:30.937929
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert isinstance(AnsibleCollectionConfig.collection_finder._n_configured_paths, list)



# Generated at 2022-06-21 08:14:37.049290
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    try:
        import collections
    except ImportError:
        return
    loader = _AnsibleCollectionPkgLoaderBase(fullname="collections",
                                             path_list=["/usr/lib/python3.7/"])
    assert repr(loader) == "_AnsibleCollectionPkgLoaderBase(path=['/usr/lib/python3.7/collections'])"



# Generated at 2022-06-21 08:14:44.932735
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test the basic functionality of the collections ref constructor
    test_obj = AnsibleCollectionRef(u"my.collection", u"", u"myres", u"action")
    assert test_obj.collection == u"my.collection"
    assert test_obj.subdirs == u""
    assert test_obj.resource == u"myres"
    assert test_obj.ref_type == u"action"
    assert test_obj.n_python_collection_package_name == "ansible_collections.my.collection"
    assert test_obj.n_python_package_name == "ansible_collections.my.collection.plugins.action"
    assert test_obj.fqcr == u"my.collection.myres"


# Generated at 2022-06-21 08:14:57.154509
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('become_plugins') == 'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doc_fragments') == 'doc_fragments'
    assert AnsibleCollectionRef.legacy_plugin_dir

# Generated at 2022-06-21 08:15:07.000910
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    module_name_1 = 'test_module_name_1'
    module_path = '/dummy/path/module_name_1.py'
    # _PackagePathFinder mock object
    package_path_finder_mock_object = Mock(spec=_PackagePathFinder)
    package_path_finder_mock_object.find_module.return_value = None
    # Importer mock object
    importer_mock_object = Mock(spec=Importer)
    importer_mock_object.find_module.return_value = None
    # _AnsiblePathHookFinder object
    import_path = '/tmp/'

# Generated at 2022-06-21 08:15:19.153507
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:15:23.522660
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test = AnsibleCollectionRef('namespace.collection', 'subdir1', 'resource', 'module')
    assert str(test) == 'AnsibleCollectionRef(collection="namespace.collection", subdirs="subdir1", resource="resource")'


# Generated at 2022-06-21 08:15:27.094427
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert AnsibleCollectionRef('ansible.builtin', '', 'ping', 'module') == getattr(sys.modules[__name__], 'AnsibleCollectionRef')('ansible.builtin', '', 'ping', 'module')



# Generated at 2022-06-21 08:16:30.826030
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # test a normal py2 package
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.myns.mypkg")
    assert loader._fullname == "ansible_collections.myns.mypkg"
    assert loader._parent_package_name == "ansible_collections.myns"
    assert loader._package_to_load == "mypkg"
    assert loader._split_name == ["ansible_collections", "myns", "mypkg"]

    # test a normal py2 module
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.myns.mypkg.mymod")
    assert loader._fullname == "ansible_collections.myns.mypkg.mymod"

# Generated at 2022-06-21 08:16:40.815520
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    """
    Check if the method is_valid_fqcr of class AnsibleCollectionRef works.

    The function returns True if the ref passed is well-formed.
    """
    ref1 = 'foo.bar.example'
    ref2 = 'foo.bar.example.txt'
    ref3 = 'foo.bar.2example'

    # ref1: True
    assert AnsibleCollectionRef.is_valid_fqcr(ref1)

    # ref2: False
    assert not AnsibleCollectionRef.is_valid_fqcr(ref2)

    # ref3: False
    assert not AnsibleCollectionRef.is_valid_fqcr(ref3)

    # ref1, ref_type='module': True
    assert AnsibleCollectionRef.is_valid_fqcr(ref1, 'module')

    # ref

# Generated at 2022-06-21 08:16:46.385142
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    acf = _AnsibleCollectionFinder(paths=['collection_root'], scan_sys_paths=False)
    assert acf._n_configured_paths == ['collection_root']
    assert acf._n_cached_collection_paths is None
    assert acf._n_cached_collection_qualified_paths is None



# Generated at 2022-06-21 08:16:55.855750
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import ansible_collections
    assert hasattr(ansible_collections.foo, 'plugins')

    # before patching, the original code returns the path of the module
    assert ansible_collections.foo.plugins.__file__.endswith('ansible_collections/foo/plugins.py')

    # after patching, the path of the module is returned
    with patch.object(ansible_collections.foo.plugins.__loader__, '_subpackage_search_paths', None):
        assert ansible_collections.foo.plugins.__file__.endswith('ansible_collections/foo/plugins.py')

    os.environ['ANSIBLE_COLLECTIONS_PATH'] = os.path.join(os.getcwd(), 'ansible_collections')
    importb_init = ImpImporter

# Generated at 2022-06-21 08:17:04.873994
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    x1 = AnsibleCollectionRef(collection_name='ansible.builtin', subdirs=None, resource='cli', ref_type='module')
    x2 = AnsibleCollectionRef(collection_name='ansible.builtin', subdirs='', resource='cli', ref_type='module')
    x3 = AnsibleCollectionRef(collection_name='ansible.builtin', subdirs='', resource='cli', ref_type='module')
    x4 = AnsibleCollectionRef(collection_name='ansible.builtin', subdirs='test', resource='cli', ref_type='module')
    assert str(x1) == "'ansible.builtin.cli'"
    assert str(x2) == "'ansible.builtin.cli'"
    assert str(x3) == "'ansible.builtin.cli'"
    assert str

# Generated at 2022-06-21 08:17:14.846321
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    subpackage_search_paths = [
        "/home/user/ansible_collections/ansible/os",
        "/home/user/ansible_collections/ansible/netconf"
    ]
    class _AnsibleCollectionPkgLoaderBaseExtended(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def _is_package(self, fullname):
            pass
        def _is_package_path(self, package_path):
            pass
        def _synthetic_filename(self, fullname):
            return ""
    
    cl

# Generated at 2022-06-21 08:17:26.654705
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # We use as input paths the list of paths found in _AnsibleCollectionFinder.__init__
    sys.path_hooks.insert(0, _AnsibleCollectionFinder._ansible_collection_path_hook)
    try:
        sys.path = [os.path.expanduser(path) for path in sys.path]
        path = os.path.join(os.path.dirname(sys.modules['ansible'].__file__), 'modules/packaging/os')
    finally:
        sys.path_hooks.remove(_AnsibleCollectionFinder._ansible_collection_path_hook)

    # In this test we cannot use the class _AnsibleCollectionFinder as we do not know its __init__ arguments
    # We create an instance of the class _AnsibleCollectionFinder.
    ac

# Generated at 2022-06-21 08:17:38.267873
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(path='/tmp/ansible_collections:/tmp', fullname='ansible_collections.namespace1.collection1',
                                         package_to_load='collection1')
    assert loader._package_to_load == 'collection1'
    assert loader._fullname == 'ansible_collections.namespace1.collection1'
    assert loader._parent_package_name == 'ansible_collections.namespace1'
    assert loader._path == '/tmp/ansible_collections:/tmp'
    assert loader._candidate_paths == ['/tmp/ansible_collections/namespace1/collection1', '/tmp/namespace1/collection1']
    assert loader._subpackage_search_paths == ['/tmp/ansible_collections/namespace1/collection1']


# Generated at 2022-06-21 08:17:50.381031
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:17:52.164442
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # TODO: Implement test_load_module()
    pass

# Generated at 2022-06-21 08:19:20.636715
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # TODO
    pass



# Generated at 2022-06-21 08:19:28.682358
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    subdir = Any()
    subdir_path_list = []
    def mock_isdir(path):
        if path in subdir_path_list:
            return True
        return False


# Generated at 2022-06-21 08:19:37.098730
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Check that we expect an exception
    with pytest.raises(ValueError):
        loader = _AnsibleCollectionPkgLoaderBase('foo')
        loader.is_package('bar')

    # Check that we expect a false return
    loader = _AnsibleCollectionPkgLoaderBase('foo')
    assert loader.is_package('foo') is False

    loader = _AnsibleCollectionPkgLoaderBase('foo')
    loader._subpackage_search_paths = []
    assert loader.is_package('foo') is False

# Generated at 2022-06-21 08:19:39.348464
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader(None, None, None)
    assert loader
    assert loader._allows_package_code is True
    assert loader._redirected_package_map is _AnsibleCollectionLoader._redirected_package_map

# Generated at 2022-06-21 08:19:50.647096
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    import ansible_collections
    import ansible_collections.namespace
    import ansible_collections.somens.somesubpkg

    # test importing an Ansible namespace package from the path
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.namespace', [os.path.dirname(ansible_collections.__file__)])
    assert loader.get_code('ansible_collections.namespace') is None
    assert loader.get_data('/foo/bar') is None
    assert loader.get_data('ansible_collections/namespace') == ''
    assert loader.get_filename('ansible_collections.namespace') == 'ansible_collections/namespace/__synthetic__'
    assert loader.is_package('ansible_collections.namespace')

# Generated at 2022-06-21 08:19:59.273099
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    base_class_name = _AnsibleCollectionFinder.__name__

    # Verify that the class is derived from the required class.
    assert issubclass(_AnsibleCollectionFinder, object), '{0} is not a derived class of {1}'.format(
        base_class_name, 'object')

    # Verify that the class has been created.
    assert isinstance(_AnsibleCollectionFinder, type), '{0} is not a class'.format(base_class_name)



# Generated at 2022-06-21 08:20:07.682795
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    from importlib import PathFinder
    from types import SimpleNamespace

    _AnsiblePathHookFinder._filefinder_path_hook = None
    importer = SimpleNamespace(loader=None, is_package=None, path='')
    try:
        _AnsiblePathHookFinder._filefinder_path_hook = lambda path_hook: PathFinder
        assert _AnsiblePathHookFinder._get_filefinder_path_hook() is PathFinder
    finally:
        _AnsiblePathHookFinder._filefinder_path_hook = None

    # If a path hook fails, an exception is raised.
    with pytest.raises(Exception):
        _AnsiblePathHookFinder._get_filefinder_path_hook()

    # find_module for non-collection modules works


# Generated at 2022-06-21 08:20:12.428833
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(path_list=['/path/ansible_collections/collection1/collection2/'],
                                         package_to_load='collection2')
    assert 'collection2' == loader._package_to_load
    assert [] == loader._subpackage_search_paths

# Generated at 2022-06-21 08:20:20.816365
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # This test case will be delete after fix bug https://github.com/ansible/ansible/issues/33248
    import unittest
    from ansible_collections.ansible.internal.collection_loader._collection_finder import _AnsibleCollectionFinder
    from ansible_collections.ansible.internal.collection_loader._collection_finder import _AnsibleCollectionPathHook
    from ansible_collections.ansible.internal.collection_loader._collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible_collections.ansible.internal.collection_loader._collection_loader import _AnsibleCollectionPkgLoader
    import sys
    import os

# Generated at 2022-06-21 08:20:33.205043
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('x.y.z', ['/path/to/x/y/z'])
    assert loader.is_package('x.y.z'), 'is_package() should return True for x.y.z'
    assert not loader.is_package('x.y.z.a'), 'is_package() should return False for x.y.z.a'
    loader = _AnsibleCollectionPkgLoaderBase('x.y.z', ['/path/to/x/y/z/a'])
    assert not loader.is_package('x.y.z'), 'is_package() should return False for x.y.z'
    assert loader.is_package('x.y.z.a'), 'is_package() should return True for x.y.z.a'



# Generated at 2022-06-21 08:21:31.260082
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # test _AnsibleCollectionPkgLoaderBase class
    from ansible_collections.ansible.builtin.plugins.loader import AnsibleCollectionModuleLoader as ACL
    loader_inst = ACL('ansible.builtin')
    assert isinstance(loader_inst, _AnsibleCollectionPkgLoaderBase)

    # test _AnsiblePathHookFinder class
    from ansible_collections.ansible.builtin.plugins.loader import AnsiblePathHookFinder as APHF
    path_hook_finder_inst = APHF('ansible.builtin', loader_inst)
    assert isinstance(path_hook_finder_inst, _AnsiblePathHookFinder)

    # test _AnsiblePathContextFinder class
    from ansible_collections.ansible.builtin.plugins.loader import AnsiblePathContext

# Generated at 2022-06-21 08:21:38.222025
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    print('testing _AnsibleCollectionPkgLoaderBase.get_source()...')

    print('\tcreating a stub collection package loader...')

# Generated at 2022-06-21 08:21:43.879551
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Call method
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.org.example.collection', ['./test/unit/import_fqcr/test_data/collections/ansible_collections/org/example/collection'])
    result = loader.get_code('ansible_collections.org.example.collection')

    # Check results
    assert result is not None
