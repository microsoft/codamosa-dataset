

# Generated at 2022-06-21 08:13:02.574065
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import sys
    import os
    import tempfile
    import contextlib
    @contextlib.contextmanager
    def temp_path(prefix, path=""):
        with tempfile.TemporaryDirectory(prefix=prefix, dir=path) as temp_dir:
            yield temp_dir
    # Test cases

# Generated at 2022-06-21 08:13:14.231751
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    """Unit test for constructor of class _AnsibleCollectionRootPkgLoader"""
    with pytest.raises(ImportError) as err:
        # This will raise an error because it does not start with ansible_collections.
        _AnsibleCollectionRootPkgLoader('stdlib.system')
    # Check if the error message is correct
    assert 'this loader can only load the ansible_collections toplevel package, not stdlib.system' in str(err.value)

    with pytest.raises(ImportError) as err:
        # This will raise an error because it does not start with ansible_collections.
        _AnsibleCollectionRootPkgLoader('stdlib.system')
    # Check if the error message is correct

# Generated at 2022-06-21 08:13:18.650747
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import AnsibleCollectionConfig, _meta_yml_to_dict
    from ansible.utils.collection_loader._AnsibleCollectionNSPkgLoader import _AnsibleCollectionPkgLoader

    nspkgloader = _AnsibleCollectionNSPkgLoader('ansible_collections', ['/foo/bar'])
    pkgloader = _AnsibleCollectionPkgLoader('ansible_collections.zoo.bear', ['/foo/bar'], nspkgloader)

    _meta_yml_to_dict = pkgloader._meta_yml_to_dict
    old_on_collection_load = AnsibleCollectionConfig.on_collection_load

    load_not_fired = {'collection_name': None}

# Generated at 2022-06-21 08:13:27.083830
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    class TestArgs(object):
        arg1 = 'test:test_import.test_collection_loader.test__AnsiblePathHookFinder___repr__.<locals>.TestArgs object'
        def __init__(self, arg1):
            self.arg1 = arg1
    foo = _AnsiblePathHookFinder.__repr__(TestArgs(1))
    assert foo == "TestArgs(path='1')"


# This is the path hook loader for packages under ansible_collections.

# Generated at 2022-06-21 08:13:31.367407
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    collection_loader = _AnsibleCollectionPkgLoader('ansible_collections')
    if isinstance(collection_loader, _AnsibleCollectionPkgLoader):
        print('Test 1 passed!')
    else:
        print('Test 1 failed!')

    collection_loader = _AnsibleCollectionPkgLoader('ansible_collections.coll_ns')
    if isinstance(collection_loader, _AnsibleCollectionPkgLoader):
        print('Test 2 failed. Should be _AnsibleCollectionNSPkgLoader')
    else:
        print('Test 2 passed!')

    collection_loader = _AnsibleCollectionPkgLoader('ansible_collections.not_valid_module')
    if collection_loader is None:
        print('Test 3 passed!')
    else:
        print('Test 3 failed!')

#

# Generated at 2022-06-21 08:13:42.767530
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    ansible_collection_finder = _AnsibleCollectionFinder(
        paths=[
            'path-1',
            'path-2',
            'path-3'
        ],
        scan_sys_paths=False
    )

    assert ansible_collection_finder._ansible_pkg_path == to_native(os.path.dirname(to_bytes(sys.modules['ansible'].__file__)))
    assert ansible_collection_finder._n_configured_paths == ['path-1', 'path-2', 'path-3']
    assert ansible_collection_finder._n_cached_collection_paths == None
    assert ansible_collection_finder._n_cached_collection_qualified_paths == None
    assert ansible_collection_finder._n_playbook_paths == []



# Generated at 2022-06-21 08:13:46.102573
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
   assert _AnsibleCollectionPkgLoaderBase.__repr__(ansible.module_utils.collection_loader._AnsibleCollectionPkgLoaderBase()) == '_AnsibleCollectionPkgLoaderBase(path=None)'


# Generated at 2022-06-21 08:13:50.538031
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Testing the case when get_data method is called on a path that doesn't exist.
    # Expected to return None
    assert _AnsibleCollectionPkgLoaderBase().get_data('/non/existing/path') is None

# Generated at 2022-06-21 08:13:56.956905
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    fullname = 'ansible_collections.somecoll.somenamespace.someplugin'
    subpackage_search_paths = ["/random/dir"]
    _AnsibleCollectionPkgLoaderBase._subpackage_search_paths = subpackage_search_paths
    assert(fullname == _AnsibleCollectionPkgLoaderBase.get_filename(fullname))


# Generated at 2022-06-21 08:14:01.214224
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'

# Generated at 2022-06-21 08:15:07.818222
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():

    class _AnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):

        def _validate_final(self):
            if not self._subpackage_search_paths and not self._source_code_path:
                raise ImportError('no {0} found at {1} (or any parent paths)'.format(self._package_to_load, self._candidate_paths[0]))
            return

    loader = _AnsibleCollectionPkgLoader('ansible_collections.foo', [os.path.dirname(__file__)])
    assert loader.iter_modules('ansible_collections') is not None
    assert loader.iter_modules('ansible_collections.foo') is not None
    assert loader.iter_modules('') == []



# Generated at 2022-06-21 08:15:20.086264
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("connection_plugins") == "connection"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("vars_plugins") == "vars"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "modules"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("module_utils") == "module_utils"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("callback_plugins") == "callback"

# Generated at 2022-06-21 08:15:25.540936
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    dir_path = os.path.dirname(os.path.realpath(__file__)).replace("\collections\loader", "").replace("\\", "/") + "/lib/ansible/plugins/collection/test"
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('test.py', dir_path)[0] == dir_path + '/test.py'


# Generated at 2022-06-21 08:15:36.598021
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(
        split_name=('ansible_collections', 'my.namespace', 'my_collection'),
        path=
        [
            '/home/syntaqx/Ansible2/workspace/galaxy/ansible_collections/my/namespace/my_collection/',
            '/home/syntaqx/Ansible2/workspace/galaxy/ansible_collections/my/namespace/',
            '/home/syntaqx/Ansible2/workspace/galaxy/ansible_collections/my/',
            '/home/syntaqx/Ansible2/workspace/galaxy/ansible_collections/'
        ])

# Generated at 2022-06-21 08:15:49.726098
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print("test__AnsibleCollectionPkgLoaderBase_get_data")
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somespam.eggs', path_list=['/tmp'])
    try:
        loader._get_resource_code_path = lambda x: '/tmp/somespam/eggs'
        loader.get_data('somespam/eggs')
    except Exception as e:
        print("Error in get_data, path should be checked. Error: "+str(e))
        assert(False)
    try:
        loader.get_data('somespam/eggs/__init__.py')
    except Exception as e:
        print("Error in get_data, path should be checked. Error: "+str(e))
        assert(False)
   

# Generated at 2022-06-21 08:15:57.768899
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible_collections.ansible.builtin.plugins.module_utils.common.collections import AnsibleCollectionRef
    ansible_collections_ansible_builtin_plugins_module_utils_common_collections = __import__('ansible_collections.ansible.builtin.plugins.module_utils.common.collections', fromlist=[''])
    # NOTE: these are based on values we get out of the __init__ method
    ref = AnsibleCollectionRef(u'ansible.builtin', u'', u'', u'')
    assert repr(ref) == "AnsibleCollectionRef(collection='ansible.builtin', subdirs='', resource='')"
    ref.collection = u'ansible.builtin'

# Generated at 2022-06-21 08:16:09.708924
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll..resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.sub.dir.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yml')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource.yaml')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yml')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yaml')

# Generated at 2022-06-21 08:16:19.691593
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    assert AnsibleCollectionRef.from_fqcr("test-collection.module", "module") == AnsibleCollectionRef("test-collection.module", "", "module", "module")
    assert AnsibleCollectionRef.from_fqcr("test-collection.mymodule", "module") == AnsibleCollectionRef("test-collection.module", "", "mymodule", "module")
    assert AnsibleCollectionRef.from_fqcr("test-collection.module.mymodule", "module") == AnsibleCollectionRef("test-collection.module", "module", "mymodule", "module")
    assert AnsibleCollectionRef.from_fqcr("test-collection.module.mymodule", "role") == AnsibleCollectionRef("test-collection.module", "module", "mymodule", "role")


# Generated at 2022-06-21 08:16:30.090920
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    class TestLoader(Loader):
        def get_data(self, fullname):
            return 'data'

    import tempfile
    test_dir = tempfile.TemporaryDirectory()
    test_dir_path = test_dir.name
    test_dir_file = os.path.join(test_dir_path, 'test_file')
    test_dir_subdir = os.path.join(test_dir_path, 'test_subdir')
    test_dir_subdir_file = os.path.join(test_dir_subdir, 'test_file')

    os.mkdir(test_dir_subdir)
    with open(test_dir_file, 'w') as original:
        original.write('original')
    with open(test_dir_subdir_file, 'w') as original:
        original

# Generated at 2022-06-21 08:16:40.288492
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-21 08:17:13.368461
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import sys
    import mock

    sys.path = ['/foo/bar', '/foo/bar/baz']
    fake_module = mock.MagicMock()
    fake_module.__name__ = 'ansible_collections.somens.somesubmodule'
    fake_module.__path__ = ['/foo/bar/baz', '/foo/bar/baz1']

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.somesubmodule', path_list=sys.path)
    assert loader.get_filename(fake_module.__name__) == '/foo/bar/baz/somesubmodule/__synthetic__'


# Generated at 2022-06-21 08:17:19.956543
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(fullname)
    assert _ansible_collection_pkg_loader_base._is_package(fullname) == True

# Unit Test for method _validate_args of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:17:27.196090
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    collection_ref = AnsibleCollectionRef(None, None, None, None)

    # Valid collection name
    collection_name = 'ansible.test'
    assert collection_ref.is_valid_collection_name(collection_name)

    # Invalid collection name
    collection_name = 'ansible test'
    assert not collection_ref.is_valid_collection_name(collection_name)

    collection_name = 'ansible*.test'
    assert not collection_ref.is_valid_collection_name(collection_name)


# Generated at 2022-06-21 08:17:38.642833
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
  import sys
  import os
  import tempfile
  import random
  import string
  import tarfile
  from ansible import context
  from ansible_collections.somedeps.somenamespace.other_collections.anotherns.tasks.main import TaskModule
  from ansible_collections.somedeps.somenamespace.other_collections.anotherns.tasks.test_pkg_data.test_pkg_data_data import test_pkg_data
  from ansible_collections.somedeps.somenamespace.other_collections.anotherns.tasks.test_pkg_data.test_pkg_data_data import test_pkg_data_data
  if not os.path.exists(test_pkg_data_data.test_pkg_data_full_path):
    test_pkg_data

# Generated at 2022-06-21 08:17:40.489113
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(path_list=[],fullname='')


# Generated at 2022-06-21 08:17:53.281625
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # package init file
    pkg_path = '/path/to/pkg'
    source_path = os.path.join(pkg_path, '__init__.py')
    module_name = 'pkg'
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname=module_name,
        path_list=[pkg_path]
    )
    assert loader.get_filename(module_name) == source_path
    # package module file
    pkg_path = '/path/to/pkg'
    source_path = os.path.join(pkg_path, 'mod.py')
    module_name = 'pkg.mod'
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname=module_name,
        path_list=[pkg_path]
    )
    assert loader.get_

# Generated at 2022-06-21 08:18:02.162468
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # no path given or specified
    loader = _AnsibleCollectionFinder()
    assert loader._n_playbook_paths == []
    assert loader._n_configured_paths
    assert loader._n_collection_paths
    assert loader._n_collection_paths == loader._n_configured_paths

    # test with a path given
    path = os.path.join(os.path.expanduser('~'), "ansible_collections")
    loader = _AnsibleCollectionFinder(paths=path)
    assert loader._n_playbook_paths == []
    assert loader._n_configured_paths
    assert loader._n_collection_paths
    assert loader._n_collection_paths == loader._n_configured_paths
    assert path in loader._n_configured_

# Generated at 2022-06-21 08:18:14.429312
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    class _MockAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return [
                os.path.join(p, self._package_to_load) for p in path_list
            ]

        def _get_subpackage_search_paths(self, candidate_paths):
            return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]

    base_dir_name = os.path.dirname(__file__)
    module_dir = os.path.join(base_dir_name, 'ansible', 'collections',
                              'ns', 'collection')
    module_data_dir = os.path.join(module_dir, 'plugins')

# Generated at 2022-06-21 08:18:24.744685
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename.yml') is True

    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'action') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'action') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.rolename', 'role') is True


# Generated at 2022-06-21 08:18:33.074053
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    fullname = 'ansible_collections.namespace.collection'
    path_list = ['/path/to/my/collection', '/path/to/my/collection/plugins']

    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    loader._validate_final = MagicMock()
    loader.get_filename = MagicMock(return_value='/path/to/my/collection/plugins/module.py')
    assert repr(loader) == '_AnsibleCollectionPkgLoaderBase(path=/path/to/my/collection/plugins/module.py)'

    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    loader._validate_final = MagicMock()

# Generated at 2022-06-21 08:19:04.531778
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder(scan_sys_paths=False)
    assert finder._n_cached_collection_paths is None
    assert finder._n_cached_collection_qualified_paths is None

    playbook_path = [u'/path/to/playbook', u'/path/to/playbook2/']
    finder.set_playbook_paths(playbook_path)

    expected_paths = [u'ansible_collections']
    expected_paths.extend(u'{0}/ansible_collections'.format(path) for path in playbook_path)

    assert set(finder._n_collection_paths) == set(expected_paths)

# Generated at 2022-06-21 08:19:06.580699
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.test_col')



# Generated at 2022-06-21 08:19:18.194524
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    '''
    Unit tests for the iter_modules method of class _AnsiblePathHookFinder

    Unit tests for the iter_modules method of class _AnsiblePathHookFinder

    Parameters:
        None

    Returns:
        None

    Raises:
        failedAssertion
    '''
    # get the current path of the ansible module
    ansible_module_path = os.path.dirname(os.path.abspath(sys.modules['ansible'].__file__))
    ansible_module_path = ansible_module_path.replace('/ansible/__init__.py', '')

    # make a collection path to test with
    collection_path = os.path.join(ansible_module_path, 'my_collection')
    os.mkdir(collection_path)

   

# Generated at 2022-06-21 08:19:27.482914
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from ansible_collections._import_shim import _AnsibleCollectionFinder
    collection_finder = _AnsibleCollectionFinder([])

    # test playbook_paths of type string
    playbook_paths = 'test_path'
    collection_finder.set_playbook_paths(playbook_paths)
    assert len(collection_finder._n_playbook_paths) == 1 and collection_finder._n_playbook_paths[0] == 'test_path/collections'

    # test playbook_paths of type list of strings
    playbook_paths = ['test_path', 'test_path']
    collection_finder.set_playbook_paths(playbook_paths)
    assert len(collection_finder._n_playbook_paths) == 1 and collection_finder._n_playbook

# Generated at 2022-06-21 08:19:32.838829
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    a = _AnsiblePathHookFinder(None, '/tmp/')
    assert a._pathctx == '/tmp/'
    assert a._collection_finder is None
    # NEXT: make sure _file_finder is None
    try:
        a.find_module('')
    except AttributeError:
        pass
    except Exception:
        assert False, 'find_module method should raise AttributeError'
    else:
        assert False, 'find_module method should raise AttributeError'

    a = _AnsiblePathHookFinder(None, '/tmp/')
    try:
        a.iter_modules('')
    except AttributeError:
        pass
    except Exception:
        assert False, 'iter_modules method should raise AttributeError'

# Generated at 2022-06-21 08:19:42.780634
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    _AnsibleCollectionPkgLoader("my_collection", '/path/to/my_collection', "my_plugin")
    _AnsibleCollectionPkgLoader("ansible_collections.my_collection", '/path/to/my_collection', "my_plugin")

    try:
        _AnsibleCollectionPkgLoader("my_collection", '/path/to/my_collection', "my_plugin/s")
        raise AssertionError("my_plugin/s is not a valid subpackage path, should raise exception")
    except ValueError:
        pass


# Generated at 2022-06-21 08:19:52.210236
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class _AnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            if self._rpart_name[2] != 'somens':
                raise ImportError('this loader can only load ansible_collections.somens')
        def _get_candidate_paths(self, path_list):
            return ['/path/to/ansible_collections/somens']
        def _get_subpackage_search_paths(self, candidate_paths):
            return [os.path.join(candidate_paths[0], 'ansible_collections', 'somens')]


# Generated at 2022-06-21 08:19:56.761696
# Unit test for method iter_modules of class _AnsiblePathHookFinder

# Generated at 2022-06-21 08:20:06.666872
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    old_modules = sys.modules.copy()
    # make sure the system is clean first
    try:
        del sys.modules['ansible.builtin.things']
        del sys.modules['ansible']
    except KeyError:
        pass

    # this should not error
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.things', [])
    loader.load_module('ansible.builtin.things')
    assert sys.modules['ansible.builtin.things'].__name__ == 'ansible_collections.ansible.builtin.things'

    # reset sys.modules to just what it was before this unit test
    sys.modules.clear()
    sys.modules.update(old_modules)
    assert 'ansible.builtin.things' not in sys.modules



# Generated at 2022-06-21 08:20:12.854159
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("bad.coll.name", 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("bad.coll.name_with_.underscore", 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("bad.coll.name.with-dash", 'module')
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("bad.coll.name.with-dots", 'module')

    # too short
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr("coll", 'module')
    with pytest.raises(ValueError):
        Ans

# Generated at 2022-06-21 08:20:41.276798
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible.module_utils.six.moves import reload_module as reload

    class TempModule(object):
        def __init__(self, name):
            self.name = name

    class TempMethod(object):
        def __init__(self, name):
            self.name = name

        def __call__(self, *args, **kwargs):
            # returns the name of the first arg or the name of the first kwarg if provided
            return (args[0].name if args else kwargs.get('kwarg').name) if len(args) == 1 else self.name


# Generated at 2022-06-21 08:20:47.532924
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # test_dir is an ephemeral directory that's traversed by Ansible upon import so that it can find its code.
    with tempfile.TemporaryDirectory() as test_dir:
        # collection_path is a directory that Ansible should not traverse.
        with tempfile.TemporaryDirectory() as collection_path:
            collection_path_hook_finder = \
                _AnsiblePathHookFinder(
                    _AnsibleCollectionFinder(paths=[collection_path]),
                    test_dir
                )
            assert collection_path_hook_finder.__repr__() == \
                '_AnsiblePathHookFinder(path=\'' + test_dir + '\')'
            assert collection_path_hook_finder._pathctx == test_dir

# Implements a file system based loader for ansible_col

# Generated at 2022-06-21 08:20:58.910436
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """
    Run test for _AnsibleCollectionPkgLoaderBase_get_data
    """

    class _Loader(_AnsibleCollectionPkgLoaderBase):
        pass

    loader = _Loader('ansible_collections.zeta.zeta')

    loader._subpackage_search_paths = [
            '/tmp/ansible_collections/ansible_collections/zeta/zeta',
            '/tmp1/ansible_collections/ansible_collections/zeta/zeta'
        ]

    # Test 1: Given the path of a single file, the content of the file is returned
    file_content = 'test-data'
    file_path = '/tmp/ansible_collections/ansible_collections/zeta/zeta/test-data.py'

# Generated at 2022-06-21 08:21:03.806459
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # test with len(_split_name) = 2
    # _validate_args should not raise an exception
    # _validate_final should not raise an exception
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.somens')
    loader = _AnsibleCollectionNSPkgLoader('ansible.builtin.somemodule')
    # test with len(_split_name) != 2
    # _validate_args should raise an exception
    with pytest.raises(ImportError):
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.some.thing')

    with pytest.raises(ImportError):
        loader = _AnsibleCollectionNSPkgLoader('ansible.builtin.some.thing')


# Implements the first-found behavior for collection packages

# Generated at 2022-06-21 08:21:06.339945
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # No error if no error
    # FIXME: Add tests
    pass

#
# Utility functions
#

_path_hook_imp_obj = None


# Generated at 2022-06-21 08:21:14.137709
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():

    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_config import AnsibleCollectionConfig
    import os

    def test_set_paths_called_with_no_path():
        acf = _AnsibleCollectionFinder()
        acf.set_playbook_paths(None)
        assert acf._n_playbook_paths == []
        assert acf._n_cached_collection_paths == None

    def test_set_paths_called_with_single_path():
        acf = _AnsibleCollectionFinder()
        acf.set_playbook_paths(os.getcwd())

# Generated at 2022-06-21 08:21:24.976889
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """Unit test for class _AnsiblePathHookFinder constructor

    """
    import ansible.module_utils._text as t
    from collections import namedtuple

    ModRecord = namedtuple("ModRecord", "name load path")

    AnsibleFileFinderMock = namedtuple("AnsibleFileFinderMock", "find_spec")

    AnsibleSpecMock = namedtuple("AnsibleSpecMock", "loader")

    AnsibleDirMock = namedtuple("AnsibleDirMock", "name")

    ansible_path = os.path.join(os.path.dirname(t.__file__), "ansible_collections")

    if sys.version_info[0] == 3:
        def _get_filefinder_path_hook(self=None):
            _file_finder

# Generated at 2022-06-21 08:21:34.128435
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import tempfile
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionPathFinder
    from ansible.utils.collection_loader import _AnsibleCollectionHookContext
    from ansible.utils.collection_loader import _AnsiblePathHookFinder
    from ansible.utils.collection_loader import _AnsiblePathFinder
    import os
    import shutil
    import sys

# Generated at 2022-06-21 08:21:45.562866
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible.utils.collection_loader import AnsibleCollectionLoader, _AnsibleCollectionFinder, _AnsiblePathHookFinder, \
    _AnsibleCollectionPkgLoader

    loader = AnsibleCollectionLoader()
    finder = _AnsibleCollectionFinder(loader)
    pkgfinder = _AnsiblePathHookFinder(finder, 'ansible.playbooks.plugins')
    pkgloader = _AnsibleCollectionPkgLoader('ansible.playbooks.plugins')
    path_list = pkgfinder._get_candidate_paths(['/home/ansible-tests/ansible/playbooks/plugins'])
    pkgloader._subpackage_search_paths = pkgloader._get_subpackage_search_paths(path_list)
    pkgload