

# Generated at 2022-06-21 08:12:36.235977
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():

    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns')
    source = """
import os
print(os.path.isdir('/'))
"""

    def test_source_is_bytes():
        obj.get_data = lambda path: b'bytes'
        code = obj.get_code('ansible_collections.ns')
        assert(code is not None)
        assert(code.co_filename == '<string>')
        exec(code)

    def test_source_is_string():
        obj.get_data = lambda path: 'line1\nline2'
        code = obj.get_code('ansible_collections.ns')
        assert(code is not None)
        assert(code.co_filename == '<string>')
        exec(code)

    test

# Generated at 2022-06-21 08:12:48.281500
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # The method from_fqcr should behave the same as the constructor
    for _ in range(10):
        ref = random_collection_ref(min_subdirs=0, max_subdirs=10, min_resources=1, max_resources=1)
        ref_copy = AnsibleCollectionRef.from_fqcr(ref.fqcr, ref.ref_type)
        assert ref.collection == ref_copy.collection
        assert ref.subdirs == ref_copy.subdirs
        assert ref.resource == ref_copy.resource
        assert ref.ref_type == ref_copy.ref_type

        # We also should be able to check resource types

# Generated at 2022-06-21 08:12:59.578075
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    root_path = '.fixtures'
    paths = [os.path.join(root_path, 'ansible_collections', 'a_namespace', 'a_collection'),
             os.path.join(root_path, 'ansible_collections', 'a_namespace', 'another_collection'),
             os.path.join(root_path, 'ansible_collections', 'another_namespace', 'a_collection'),
             os.path.join(root_path, 'ansible_collections', 'another_namespace', 'another_collection'),
             os.path.join(root_path, 'ansible_collections', 'another_namespace', 'a_collection', 'plugins'),
             ]
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections', path_list=paths)

# Generated at 2022-06-21 08:13:03.718839
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from Ansible.utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    def _get_source(self):
        return self.get_source('abc.abc')

    #
    # Verify method _AnsibleCollectionPkgLoaderBase.get_source is returning None
    #

    # Source file content
    file_content = to_bytes('import abc\n')
    # Mock the module class
    module_class = unittest.mock.MagicMock(spec=ModuleType)
    module_class.__name__ = 'abc'
    # Initialize the _AnsibleCollectionPkgLoaderBase class object
    pkg_loader_base_obj = _AnsibleCollectionPkgLoaderBase('abc.abc')
    # Verify that get_source is returning None if

# Generated at 2022-06-21 08:13:13.405705
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Check toplevel package, fails if not 'ansible'
    not_interested = _AnsibleInternalRedirectLoader('not_interested.path', None)
    assert not_interested._redirect is None

    # Load module
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.language', '/tmp')
    assert loader._redirect == 'ansible.builtin.language'


# this class is a meta-importer which handles the custom path hooks for the ansible_collections package, as well
# as creating a special ansible_collections module for the toplevel namespace that handles namespace package
# aggregation/searching

# Generated at 2022-06-21 08:13:18.475592
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    """ test case for _AnsibleCollectionNSPkgLoader"""
    test_cases = [
        {
            'fullname': 'ansible_collections.acme.awesome_collection',
            'path_list': [
                '/home/michael/.ansible/collections',
                '/usr/share/ansible/collections',
            ],
        },
        {
            'fullname': 'ansible_collections.awesome_collection.acme',
            'path_list': [],
        },
    ]

    for test_case in test_cases:
        loader = _AnsibleCollectionNSPkgLoader(test_case['fullname'], test_case['path_list'])
        assert loader.is_package(test_case['fullname'])



# Generated at 2022-06-21 08:13:24.229254
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    paths = ['.']
    collection_finder = _AnsibleCollectionFinder(paths, scan_sys_paths=False)
    collection_finder.find_module('ansible_collections.my_namespace.my_collection.plugins.modules.my_module')
    collection_finder.find_module('ansible_collections.my_namespace.my_collection.plugins.module_utils.my_module')


# Generated at 2022-06-21 08:13:32.259438
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test case 1 from is_valid_fqcr in class AnsibleCollectionRef:
    # Input str: 'collection.filename'
    # Output: True
    # Reason: Valid ref string
    assert AnsibleCollectionRef.is_valid_fqcr("collection.filename") == True

    # Test case 2 from is_valid_fqcr in class AnsibleCollectionRef:
    # Input str: 'collection.filename.py'
    # Output: True
    # Reason: Valid ref string
    assert AnsibleCollectionRef.is_valid_fqcr("collection.filename.py") == True

    # Test case 3 from is_valid_fqcr in class AnsibleCollectionRef:
    # Input str: 'collection.directory.filename'
    # Output: True
    # Reason: Valid ref string
    assert AnsibleCollectionRef.is_valid_

# Generated at 2022-06-21 08:13:43.817350
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    from imp import find_module
    from collections import namedtuple
    import types
    import os
    import tempfile

    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    import_root = None
    with tempfile.TemporaryDirectory(prefix='fake_collections_') as tmpdir:
        import_root = os.path.join(tmpdir, 'ansible_collections')
        os.makedirs(import_root)
        # Test the simple case
        finder = _AnsiblePathHookFinder(None, import_root)

# Generated at 2022-06-21 08:13:50.869113
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class TestClass(_AnsibleCollectionPkgLoaderBase):
        pass

    t = TestClass(fullname='ansible_collections.my_col.my_ns.my_pkg', path_list=['/path/to/my_col/my_ns/my_pkg'])
    assert repr(t) == 'TestClass(path=[/path/to/my_col/my_ns/my_pkg])'



# Generated at 2022-06-21 08:15:27.073516
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    class _SubclassTest(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(_SubclassTest, self).__init__(fullname, path_list)
            self._source_code_path = os.path.join(self._candidate_paths[0], 'module1.py')

        def _validate_final(self):
            # add some extra attributes to test the module init when we're done
            self._redirect_module = dict(__name__='plugins.module_utils.foo', __loader__='foobar')

        def get_source(self, fullname):
            return '# source for %s' % fullname

    # create a dir
    tmpdir = tempfile.mkdtemp()
    # create the loader

# Generated at 2022-06-21 08:15:36.715203
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    colref = AnsibleCollectionRef(u"ansible.builtin", "myplugin", "myplugin", "module")
    colref.collection == u"ansible.builtin"
    colref.subdirs == u"myplugin"
    colref.resource == u"myplugin"
    colref.ref_type == u"module"
    colref.n_python_collection_package_name == u"ansible_collections.ansible.builtin"
    colref.n_python_package_name == u"ansible_collections.ansible.builtin.plugins.myplugin.module"
    colref.fqcr == u"ansible.builtin.myplugin.myplugin"


# Generated at 2022-06-21 08:15:49.726417
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import sys, os
    sys.modules['ansible_collections'] = ModuleType('ansible_collections')
    sys.modules['ansible_collections.my_namespace'] = ModuleType(
        'ansible_collections.my_namespace')
    my_loader = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.my_namespace.my_collection.my_module',
        path_list=['/foo/bar/my_collection/my_module'])
    result = my_loader.get_code('ansible_collections.my_namespace.my_collection.my_module')
    assert result is not None

# Generated at 2022-06-21 08:15:56.667697
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test is_package method with package and with non-package.
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=['/bar/baz'])
    loader._subpackage_search_paths = ['/bar/baz/foo']
    assert loader.is_package('ansible_collections.foo') == True

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=['/bar/baz'])
    loader._subpackage_search_paths = None
    assert loader.is_package('ansible_collections.foo') == False



# Generated at 2022-06-21 08:16:05.565299
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_loader.test__AnsibleCollectionPkgLoaderBase_get_code', path_list=['ansible_collections/test/test_loader/test__AnsibleCollectionPkgLoaderBase_get_code/'])
    assert loader.get_code('ansible_collections.test.test_loader.test__AnsibleCollectionPkgLoaderBase_get_code') is not None
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_loader.test__AnsibleCollectionPkgLoaderBase_get_code_2', path_list=['ansible_collections/test/test_loader/test__AnsibleCollectionPkgLoaderBase_get_code_2/'])
    assert loader.get_

# Generated at 2022-06-21 08:16:11.469287
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Creator
    c = AnsibleCollectionRef('namespace.collectionname', 'subdir1.subdir2', 'resource_name', 'type')
    assert repr(c) == 'AnsibleCollectionRef(collection=\'namespace.collectionname\', subdirs=\'subdir1.subdir2\', resource=\'resource_name\')'


# Generated at 2022-06-21 08:16:20.456857
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    collection_name = 'test_collection'
    module_name = 'test_module'
    module_source = 'def test():\n    pass'

    p = MockPath(collection_name)
    p.mkdir(exist_ok=True)

    m = create_mocked_file_path(p, module_name + '.py')
    m.write_text(module_source)

    m = create_mocked_file_path(p, module_name + '.json')
    m.write_text('{}')

    p = MockPath(collection_name, '__init__.py')
    p.touch(exist_ok=True)

    p = MockPath(collection_name, '__init__.pyc')
    p.touch(exist_ok=True)


# Generated at 2022-06-21 08:16:30.430377
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    valid_call = functools.partial(_AnsibleCollectionPkgLoader, fullname='ansible_collections.some.name')

    # no args
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoader()

    # fullname only
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoader(fullname='ansible_collections.some.name')

    # path only
    with pytest.raises(ValueError):
        _AnsibleCollectionPkgLoader(path='/path/to/collection/package')

    # both
    pkg_loader = _AnsibleCollectionPkgLoader('ansible_collections.some.name', '/path/to/collection/package')

# Generated at 2022-06-21 08:16:33.532221
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    import ansible.collection_loader  # pylint: disable=C0413

    _AnsibleCollectionFinder()
    # TODO: add more unit tests for class _AnsibleCollectionFinder


# Generated at 2022-06-21 08:16:35.350551
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_out = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert test_out == 'action'

# Generated at 2022-06-21 08:17:09.333739
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    sys.path.append('')
    collection_finder = _AnsibleCollectionFinder(paths=sys.path, scan_sys_paths=True)
    assert collection_finder.find_module('ansible.module_utils.math') is not None, "Failed to find_module for 'ansible.module_utils.math'"
    assert collection_finder.find_module('ansible_collections.notexisting') is None, "find_module for 'ansible_collections.notexisting' should have returned None"
    assert collection_finder.find_module('pkg_without_ansible_collections.some', path=['mypath']) is None, "find_module for 'pkg_without_ansible_collections.some' should have returned None"

# Generated at 2022-06-21 08:17:17.639400
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    def test(name, **kwargs):
        try:
            loader = _AnsibleCollectionPkgLoader(name, **kwargs)
        except Exception as ex:
            return '{0} failed to initialize with kwargs {1}: {2}'.format(name, kwargs, ex)

        loader_dict = loader.__dict__.copy()
        del loader_dict['_fullname']
        expected_dict = dict([(k, v) for k, v in iteritems(kwargs) if not k.startswith('_')])
        if loader_dict != expected_dict:
            return '{0} failed to initialize with kwargs {1}, expected {2} but got {3}'.format(name, kwargs, expected_dict, loader_dict)


# Generated at 2022-06-21 08:17:28.902975
# Unit test for method find_module of class _AnsiblePathHookFinder

# Generated at 2022-06-21 08:17:39.831068
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.utils.collection_loader._collection_config import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionFinder
    from ansible.utils.collection_loader._collection_meta import _meta_yml_to_dict
    import os
    import tempfile
    import shutil
    import io

    tmpdir = None

    def setup():
        global tmpdir
        tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-21 08:17:46.704018
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    __test__ = True
    collection_finder = _AnsibleCollectionFinder()
    pathctx = os.path.expanduser('~/ansible')
    res = _AnsiblePathHookFinder(collection_finder, pathctx)
    assert repr(res) == "_AnsiblePathHookFinder(path='{0}')".format(pathctx)
    return res



# Generated at 2022-06-21 08:17:58.646600
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    collection_name = 'ansible_collections'
    namespace_name = 'namespace'
    plugin_name = 'plugin'
    subpackage_name = 'subpackage'
    subsubpackage_name = 'subsubpackage'

    loader = _AnsibleCollectionPkgLoaderBase('.'.join([collection_name, namespace_name]))
    loader._subpackage_search_paths = [os.path.join(collection_name, namespace_name)]

    assert loader.is_package(loader._fullname) is True
    assert loader.is_package('.'.join([loader._fullname, plugin_name])) is False
    assert loader.is_package('.'.join([loader._fullname, subpackage_name])) is True

# Generated at 2022-06-21 08:18:11.929424
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import types

    with tempfile.TemporaryDirectory() as tmpdir:
        # expected code:
        x = "def test_scope(): print('scope')"
        test_path = os.path.join(tmpdir, 'test.py')
        with open(to_bytes(test_path), 'w') as f:
            f.write(x)

        loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo', path_list=[tmpdir])
        code = loader.get_code('ansible_collections.foo')
        assert isinstance(code, types.CodeType)
        # exec the code and see if it runs
        globals = {'__name__': 'ansible_collections.foo'}
        locals = {}
        exec(code, globals, locals)

# Generated at 2022-06-21 08:18:23.652211
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    import unittest
    import tempfile

    class test_AnsibleCollectionLoader(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.testdir = tempfile.mkdtemp(dir=self.tmpdir)
            self.testdir_pkg = tempfile.mkdtemp(dir=self.testdir)
            self.testdir_mod = os.path.join(self.testdir, 'test')
            self.testdir_mod_py = self.testdir_mod + '.py'
            self.testdir_pkg_init = os.path.join(self.testdir_pkg, '__init__.py')


# Generated at 2022-06-21 08:18:25.695234
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None

test__AnsiblePathHookFinder()



# Generated at 2022-06-21 08:18:33.998132
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.role_name')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.mymodule')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.subdir3.subdir4.subdir5.subdir6.subdir7.subdir8.subdir9.subdir10.subdir11.subdir12.subdir13.subdir14.subdir15.subdir16')

# Generated at 2022-06-21 08:18:55.381604
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Test for the case when load_module was not called
    test_loader=_AnsibleCollectionPkgLoader(None, '/path/to/collection', 'x.y')
    test_loader._package_to_load = 'example'
    test_loader._validate_args()
    test_loader._validate_final()
    test_loader._get_subpackage_search_paths([])
    test_loader.is_package('x.y.example')
    test_loader.get_source('x.y.example')
    test_loader.get_filename('x.y.example')
    test_loader.get_code('x.y.example')
    ans_collection_loader = AnsibleCollectionLoader(test_loader, 'ansible', path='/path/to/collection')
    test_loader.module_finder

# Generated at 2022-06-21 08:18:58.282624
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    test_playbook_path='/home/test/playbook'
    finder = _AnsibleCollectionFinder(['not_a_playbook_path'])
    file_finder = _AnsiblePathHookFinder(finder, test_playbook_path)
    assert file_finder.find_module('ansible_collections.foo') == None


# Implements a module loader for top-level packages (which we need so that we can redirect to a qualified NS name,
# eg ansible_collections instead of just ansible).

# Generated at 2022-06-21 08:19:08.136884
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():

    #Test for invalid values of collection_name
    test_data_for_invalid_collection_name = [
        'namespace.coll;ection', 'namespace.collection',
        '.', 'namespace.', '.collection', 'namespace.collection.',
        'namespace.dot.in.name', 'namespace.1collection',
        'invalid.name', 'ansible.collections.invalid.name'
    ]

    for test_case in test_data_for_invalid_collection_name:
        assert AnsibleCollectionRef.is_valid_collection_name(test_case) == False

    #Test for valid values of collection_name
    test_data_for_valid_collection_name = [
        'namespace.collection', 'ansible.collections.namespace.collection'
    ]


# Generated at 2022-06-21 08:19:15.646253
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    m = module_loader.ModuleLoader(None)
    c = _AnsibleCollectionPkgLoaderBase('a.b.c', m._construct_mod_path(['/a/b/c']))
    assert(c.is_package('a.b.c') == False)
    assert(c.is_package('a.b') == False)
    assert(c.is_package('a') == False)
    assert(c.is_package('asdf') == False)



# Generated at 2022-06-21 08:19:26.020407
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:19:38.369262
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ANSIBLE_COLLECTIONS_PATH = ['/path/to/collections']
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_ns', path_list=ANSIBLE_COLLECTIONS_PATH)
    result = loader.__repr__()
    assert result == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/collections/some_ns])'

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_ns.some_collection', path_list=ANSIBLE_COLLECTIONS_PATH)
    result = loader.__repr__()
    assert result == '_AnsibleCollectionPkgLoaderBase(path=[/path/to/collections/some_ns/some_collection])'



# Generated at 2022-06-21 08:19:42.506587
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    a = _AnsibleInternalRedirectLoader(sys.modules['ansible'].__file__, 'BBB')
    assert a._redirect is None


# Generated at 2022-06-21 08:19:52.081345
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    def test_impl(paths_to_search, prefix_to_match, expected_modules, expected_error):
        # No error
        if not expected_error:
            found_modules = [x[0] for x in _AnsibleCollectionPkgLoaderBase.iter_modules(paths_to_search, prefix_to_match)]
            assert set(found_modules) == set(expected_modules)
        else:
            try:
                found_modules = [x[0] for x in _AnsibleCollectionPkgLoaderBase.iter_modules(paths_to_search, prefix_to_match)]
            except Exception as e:
                assert type(e) is expected_error

    # Test cases for _AnsibleCollectionPkgLoaderBase.iter_modules

# Generated at 2022-06-21 08:19:56.218321
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    loader = _AnsibleCollectionLoader('galaxy.collection.test', ['my_path'])
    assert loader._fullname == 'galaxy.collection.test'
    assert loader._split_name == ['galaxy', 'collection', 'test']
    assert loader._package_to_load == 'test'
    assert loader._candidate_paths[0] == 'my_path'
    assert loader._subpackage_search_paths[0] == 'my_path'
    assert loader._source_code_path == 'my_path/test.py'
    assert hasattr(loader, '_redirected_package_map') == True
    assert loader._allows_package_code == True

    loader = _AnsibleCollectionLoader('galaxy.collection.test.sub', ['my_path'])

# Generated at 2022-06-21 08:20:06.606983
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collections_path = 'test_data/ansible_collections/test_ns'

# Generated at 2022-06-21 08:20:35.027304
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import pkgutil

    # create a _AnsiblePathHookFinder
    acf = AnsibleCollectionConfig.collection_finder
    aph = _AnsiblePathHookFinder(acf, 'nested/collection/directory')

    # test iter_modules()
    filelist = []
    for _, name, _ in aph.iter_modules(''):
        filelist.append(name)

    assert isinstance(pkgutil.iter_modules([acf._ansible_pkg_path]), type(apf.iter_modules('')))
    assert filelist == []

    # test find_module(): ok, this gets a bit tricky. It is not possible to test on a non-existant module, because
    # pkgutil.ImpImporter.find_module() will raise an ImportError. So instead, we are going to test


# Generated at 2022-06-21 08:20:41.317857
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # pylint: disable=import-error,unused-import
    import sys, importlib
    import ansible
    import ansible.module_utils.basic
    # pylint: enable=import-error,unused-import
    assert str(isinstance(sys.path_hooks[0], type(importlib.machinery.PathFinder))) == "True"
    assert str(isinstance(sys.path_hooks[1], type(_AnsiblePathHookFinder))) == "True"



# Generated at 2022-06-21 08:20:54.975421
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-21 08:21:05.817419
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    assert _AnsibleCollectionPkgLoaderBase.get_filename(
        _AnsibleCollectionPkgLoaderBase('ansible_collections.foo'),
        'ansible_collections.foo') == '<ansible_synthetic_collection_package>'
    assert _AnsibleCollectionPkgLoaderBase.get_filename(
        _AnsibleCollectionPkgLoaderBase('ansible_collections.foo'),
        'ansible_collections.foo') == '<ansible_synthetic_collection_package>'
    assert _AnsibleCollectionPkgLoaderBase.get_filename(
        _AnsibleCollectionPkgLoaderBase('ansible_collections.foo'),
        'ansible_collections.foo') == '<ansible_synthetic_collection_package>'


# Generated at 2022-06-21 08:21:13.829409
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible_collections.ansible._collections_loader import _AnsibleCollectionPkgLoaderBase
    _loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.plugins.modules.test_module')
    _loader._source_code_path = '/path/to/test_module.py'
    _loader._decoded_source = "def main(): pass"
    _loader._compiled_code = compile(source=_loader._decoded_source, filename=_loader._source_code_path, mode='exec', flags=0, dont_inherit=True)
    assert _loader.get_code('ansible_collections.ansible.plugins.modules.test_module') == _loader._compiled_code

# Generated at 2022-06-21 08:21:16.922769
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # NOT YET IMPLEMENTED
    # TODO: implement test__AnsibleCollectionPkgLoader_load_module
    exit_unchanged()


# Generated at 2022-06-21 08:21:21.145260
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader("ansible_collections.col1", path_list=[])
    assert loader.is_package("ansible_collections.col1")
    assert loader.get_source("ansible_collections.col1") is None
    assert loader.get_filename("ansible_collections.col1") == '<ansible_synthetic_collection_package>'
    assert loader.get_code("ansible_collections.col1") is None
    assert loader.load_module("ansible_collections.col1")


# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured collection roots. The collection package (two levels down) is the first one found
# on

# Generated at 2022-06-21 08:21:27.155285
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # Using data from test_data.py
    expected = "_AnsiblePathHookFinder(path='{0}')".format(test__AnsiblePathHookFinder___repr___data)
    actual = _AnsiblePathHookFinder(collection_finder=None, pathctx=test__AnsiblePathHookFinder___repr___data).__repr__()
    assert expected == actual



# Generated at 2022-06-21 08:21:33.406908
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    paths = ['/tmp', '/tmp/collections', '/tmp/collections2']
    playbook_paths = ['/tmp/playbook', '/tmp/playbook/collections']
    finder = _AnsibleCollectionFinder(paths)
    finder.set_playbook_paths(playbook_paths)
    assert finder._n_cached_collection_paths == ['/tmp/playbook', '/tmp/playbook/collections', '/tmp', '/tmp/collections', '/tmp/collections2']


# Generated at 2022-06-21 08:21:38.989645
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    test = _AnsiblePathHookFinder('collection_finder', 'pathctx')
    assert "{0}(path='{1}')".format(test.__class__.__name__, test._pathctx) == test.__repr__()

