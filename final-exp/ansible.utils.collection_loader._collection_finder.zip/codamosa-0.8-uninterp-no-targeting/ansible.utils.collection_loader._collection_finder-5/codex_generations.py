

# Generated at 2022-06-21 08:12:40.594952
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import os, os.path
    import tempfile

    def prepDir(parent, pathname):
        child = os.path.join(parent, pathname)
        if os.path.isdir(child):
            return child
        os.makedirs(child)
        return child

    def prepPath(parent, pathname):
        child = os.path.join(parent, pathname)
        if os.path.isfile(child):
            return child
        # Write a few bytes to create the file
        with open(child, 'w') as fd:
            fd.write('test')
        return child

    # Create a temp dir
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 08:12:44.802992
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import_module('ansible')
    assert _AnsibleCollectionFinder._remove() is None
    # Replace _AnsiblePathHookFinder._filefinder_path_hook with a function to bypass the search for the FileFinder module
    _AnsiblePathHookFinder._filefinder_path_hook = lambda x: None
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None
    # Force _AnsiblePathHookFinder.find_module() to return None
    assert _AnsiblePathHookFinder.find_module('some_module') is None


# Generated at 2022-06-21 08:12:50.483621
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # ansible_collections
    root_pkg_loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert root_pkg_loader._candidate_paths == []

    # ansible_collections.foo
    with pytest.raises(ImportError) as import_error:
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo')
    assert import_error.match(r'^this loader can only load the ansible_collections toplevel package, not ansible_collections\.foo$')



# Generated at 2022-06-21 08:12:56.071810
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = 'ansible.builtin.ping'
    expected_ref_type = 'module'
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr(ref, expected_ref_type)
    # Test collection
    assert ansible_collection_ref.collection == 'ansible.builtin'
    # Test subdirs
    assert ansible_collection_ref.subdirs == ''
    # Test resource
    assert ansible_collection_ref.resource == 'ping'
    # Test ref_type
    assert ansible_collection_ref.ref_type == 'module'
    # Test fqcr
    assert ansible_collection_ref.fqcr == 'ansible.builtin.ping'
    # Test try_parse_fqcr
    ansible_collection_ref = None
    ansible_collection_

# Generated at 2022-06-21 08:13:07.538286
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.subdir1.resource") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll") == False
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.subdir1.subdir2.resource") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource!123") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource.123") == True
    assert AnsibleCollectionRef.is_valid_fqcr("ns.coll.resource/123") == True

# Generated at 2022-06-21 08:13:12.849721
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    from ansible.module_utils._text import to_native
    acf = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
    assert acf._ansible_pkg_path == to_native(os.path.dirname(os.path.dirname(__file__)))
    assert acf._n_configured_paths == []
    assert acf._n_cached_collection_paths is None
    assert acf._n_cached_collection_qualified_paths is None
    assert acf._n_playbook_paths == []
    # not sure if we need to test paths...


# Generated at 2022-06-21 08:13:22.779074
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    fl = _AnsibleCollectionPkgLoaderBase('ansible_collections.zartan.fantastic')
    path_to_test = os.path.dirname(__file__)

    if os.path.exists(os.path.join(path_to_test, 'test_data', 'spam.py')):
        loaded_data = fl.get_data(os.path.join('test_data', 'spam.py'))

        assert type(loaded_data) == bytes
        assert loaded_data == b'eggs\n'
        assert fl.get_data(os.path.join('test_data', 'nope.py')) is None
    else:
        warnings.warn('Could not run <get_data> unit test because the file was not present')



# Generated at 2022-06-21 08:13:30.355894
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # good collection refs
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.resource')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.rolename', u'role')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.playbookname', u'playbook')

    # bad collection refs
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll')

# Generated at 2022-06-21 08:13:38.882263
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text, to_bytes
    from ansible_collections.rubrik.vsphere.plugins.modules import vcenter_folder

    fqrc_git = ['rubrik.vsphere.module.vcenter_folder', 'rubrik.vsphere.module.vcenter_folder.subdir1.subdir2.vcenter_folder', 'rubrik.vsphere.module.vcenter_folder.vcenter_folder']

    vcenter_folder_ref = AnsibleCollectionRef.from_fqcr('rubrik.vsphere.vcenter_folder', 'module')
    assert fqrc_git[0] == vcenter_folder_ref.fqcr

    vcenter_folder_ref = AnsibleCollectionRef.from_fq

# Generated at 2022-06-21 08:13:47.994860
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # Set an empty collection path, so we can assume we only read the ansible.builtin collection metadata
    test_root_path = '/tmp/test_root_path'
    AnsibleCollectionConfig.set_collection_paths(test_root_path)

    test_metadata = {
        "namespace": "namespace",
        "name": "name",
        "version": "1.0.0",
        "plugin_routing": {
            "lookup_plugins": {
                "redirect_lookup_me": {
                    "redirect": "namespace.collection.redirect_lookup_me"
                }
            }
        }
    }


# Generated at 2022-06-21 08:14:20.361938
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    '''
    Test that _AnsibleCollectionLoader is working as expected
    '''
    class TestArgs(object):
        pass
    dummy_args = TestArgs()
    dummy_args.name = 'foo'
    dummy_args.path = '/bar'
    dummy_loader = _AnsibleCollectionLoader(dummy_args)
    assert dummy_loader._fullname == 'foo'
    assert dummy_loader._path == '/bar'
    assert dummy_loader._split_name == ['foo']
    assert dummy_loader._package_to_load == 'foo'


# Generated at 2022-06-21 08:14:26.946989
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Instanciation of _AnsibleCollectionPkgLoader
    # The goal is to test the method load_module that calls the parent class
    class RequriedFakeClass(object):
        pass
    fake_class_instance = RequriedFakeClass()
    with patch('ansible.utils.collection_loader.CollectionLoader._AnsibleCollectionPkgLoaderBase.load_module',
            return_value=fake_class_instance) as mock_load_module:
        fake_name = 'test_fake_name'
        fake_parent_loader = 'fake_parent_loader'
        fake_candidate_paths = ['fake_path1', 'fake_path2']
        fake_package_to_load = 'fake_package'
        fake_parent_package_name = 'fake_parent_package'
        fake_real_

# Generated at 2022-06-21 08:14:35.806012
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # Test for method get_filename (path, fullname)
    path = ['/usr/lib/python3.5/site-packages/ansible']
    fullname = 'ansible_collections.to_load'
    ldr = _AnsibleCollectionPkgLoader(fullname, path)
    assert ldr.get_filename(fullname) == '/usr/lib/python3.5/site-packages/ansible/ansible_collections/to_load'



# Generated at 2022-06-21 08:14:38.043530
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert isinstance(AnsibleCollectionRef('ns.coll', 'subdir', 'resource', 'type'), AnsibleCollectionRef)


# Generated at 2022-06-21 08:14:42.285439
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'become_plugins') == u'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cache_plugins') == u'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'callback_plugins') == u'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cliconf_plugins') == u'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'connection_plugins') == u'connection'
   

# Generated at 2022-06-21 08:14:45.187375
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansi_col = AnsibleCollectionRef("ansible_namespace.collection", None, "resource", "module")
    assert repr(ansi_col) == 'AnsibleCollectionRef(collection=\'ansible_namespace.collection\', subdirs=\'\', resource=\'resource\')'
    

# Generated at 2022-06-21 08:14:57.202390
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u"ansible.builtin.copy", u'module') == AnsibleCollectionRef(u"ansible.builtin", u"", u"copy", u'module')
    assert AnsibleCollectionRef.from_fqcr(u"ansible.builtin.copy", u'role') == AnsibleCollectionRef(u"ansible.builtin", u"", u"copy", u'role')
    assert AnsibleCollectionRef.from_fqcr(u"ansible.builtin.package.yum", u'module') == AnsibleCollectionRef(u"ansible.builtin", u"package", u"yum", u'module')

# Generated at 2022-06-21 08:15:01.545113
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader('not_allowed', '/foo', package_to_load='bar')
    assert loader._fullname == 'not_allowed'
    assert loader._parent_package_name == ''
    assert loader._root_dirs == ['/foo']
    assert loader._package_to_load == 'bar'
    assert loader._split_name == ['not_allowed']


# Generated at 2022-06-21 08:15:13.584491
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    given = {
        'ns.coll.modname': ('ns', 'coll', '', 'modname', 'module'),
        'ns.coll.subdir.modname': ('ns', 'coll', 'subdir', 'modname', 'module'),
        'ns.coll.rolename': ('ns', 'coll', '', 'rolename', 'role'),
        'ns.coll.subdir.rolename': ('ns', 'coll', 'subdir', 'rolename', 'role'),
        'ns.coll.playbookname.yml': ('ns', 'coll', '', 'playbookname', 'playbook'),
        'ns.coll.subdir.playbookname.yml': ('ns', 'coll', 'subdir', 'playbookname', 'playbook'),
    }

# Generated at 2022-06-21 08:15:25.177689
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-21 08:16:09.249110
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    loader = _AnsibleCollectionPkgLoaderBase('.', ['.'])
    loader._subpackage_search_paths = ['.']
    loader.load_module('.')

# Generated at 2022-06-21 08:16:14.748552
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase"""
    loader = _AnsibleCollectionPkgLoaderBase(fullname='foo.bar')
    filename = loader.get_filename(fullname='foo.bar')
    assert filename == '<ansible_synthetic_collection_package>'


# Generated at 2022-06-21 08:16:23.669550
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _AnsibleCollectionPkgLoaderBaseSubClass(_AnsibleCollectionPkgLoaderBase):
        # FIXME: do we want to validate the path here at all?
        def _get_subpackage_search_paths(self, candidate_paths):
            if self._package_to_load == TEST_DIRECTORY:  # FIXME: do we want a toplevel subdir?
                return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]
            else:
                return None

        def _validate_final(self):
            self._subpackage_search_paths = self._get_subpackage_search_paths(self._candidate_paths)

    # Make a collection
    coll = dict()

# Generated at 2022-06-21 08:16:34.500095
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    acf = _AnsibleCollectionFinder()
    acf.set_playbook_paths([])
    assert acf._n_playbook_paths == [], 'Did not get proper _n_playbook_paths list.'
    assert acf._n_cached_collection_paths == [], 'Did not get proper _n_cached_collection_paths list.'
    acf.set_playbook_paths(['./collections'])
    assert acf._n_playbook_paths == ['./collections'], 'Did not get proper _n_playbook_paths list.'
    assert acf._n_cached_collection_paths == ['./collections'], 'Did not get proper _n_cached_collection_paths list.'
    acf.set_playbook_paths

# Generated at 2022-06-21 08:16:36.432667
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible.plugins.loader import AnsibleCollectionRef
    obj = AnsibleCollectionRef('collection_name',subdirs='subdirs',resource='resource')
    result = obj.__repr__()
    assert isinstance(result, str)

# Generated at 2022-06-21 08:16:40.368126
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Create a _AnsibleCollectionFinder instance
    ansible_collection_finder = _AnsibleCollectionFinder()
    # Call method set_playbook_paths of class _AnsibleCollectionFinder
    ansible_collection_finder.set_playbook_paths([])


# Generated at 2022-06-21 08:16:51.492850
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import unittest
    from unittest import mock
    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def _create_return_value(self, path_list):
            loader = _AnsibleCollectionPkgLoaderBase('ansible.test', path_list)
            return repr(loader)

        def test__AnsibleCollectionPkgLoaderBase___repr__(self):
            self.assertEqual(self._create_return_value(None), '_AnsibleCollectionPkgLoaderBase(path=None)')
            self.assertEqual(self._create_return_value([]), '_AnsibleCollectionPkgLoaderBase(path=None)')

# Generated at 2022-06-21 08:16:54.003268
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None
    assert hasattr(_AnsiblePathHookFinder._filefinder_path_hook, '__code__')


# Generated at 2022-06-21 08:17:03.693591
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import tempfile
    import shutil
    import textwrap
    import ansible.module_utils.common

    # create a test module in a temporary directory
    test_module_name = 'test_module.py'
    test_module_contents = textwrap.dedent('''\
        def test():
            print('hi')
    ''')

    tmpdir = None

# Generated at 2022-06-21 08:17:09.912744
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    global _meta_yml_to_dict
    _meta_yml_to_dict = lambda x: dict()
    import ansible
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    loader = _AnsibleInternalRedirectLoader('ansible.utils.foo','bar')
    assert loader.load_module('ansible') is ansible

# Generated at 2022-06-21 08:17:40.563152
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.collection_pack.plugin_type')
    loader._source_code_path = './test-data/collections/ns/collection_pack/plugins/module_utils/ns/collection_pack/submodule.py'
    data = loader.get_data('./test-data/collections/ns/collection_pack/plugins/module_utils/ns/collection_pack/submodule.py')
    assert(data is not None)
    assert(len(data) > 0)
    return "test__AnsibleCollectionPkgLoaderBase_get_data(): PASS"


# Generated at 2022-06-21 08:17:44.257963
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    fqcr = 'ns.coll.resource'
    ref_type = u'module'
    assert AnsibleCollectionRef.is_valid_fqcr(fqcr, ref_type) == True


# Generated at 2022-06-21 08:17:57.133388
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Test basic import of a python module
    def test_import_python_module(self):
        self.assertEqual(self.name, "test.test_files.test_test_files")
        self.assertEqual(self.path_list, ["/test/test_files"])
        self.assertEqual(self.fullname, "test.test_files.test_test_files")
        self.assertEqual(self.split_name, ["test", "test_files", "test_test_files"])
        self.assertEqual(self.rpart_name, ("test.test_files", ".", "test_test_files"))
        self.assertEqual(self.parent_package_name, "test.test_files")

# Generated at 2022-06-21 08:18:10.403757
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import sys
    import ansible.module_utils.common
    sys.modules['ansible.module_utils'] = ansible.module_utils
    sys.modules['ansible.module_utils.common'] = ansible.module_utils.common
    sys.modules['ansible.module_utils.common'].__loader__ = ansible.module_utils.common  # simulate the module is loaded
    sys.modules['ansible.module_utils.common.__loader__'] = ansible.module_utils.common  # simulate the module is loaded
    # Execute the code to be tested
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.common', [])

# Generated at 2022-06-21 08:18:21.080707
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _AnsibleCollectionConfig._initialize_if_not_initialized()

    # test with wrong package
    with pytest.raises(ImportError):
        _AnsibleInternalRedirectLoader('not_ansible.test', ['.'])

    # test with empty config
    _AnsibleCollectionConfig.config = AnsibleCollectionConfig()

    redirect_loader = _AnsibleInternalRedirectLoader('ansible.test_collection.test_redirect', ['.'])

    # test with empty routing/not found
    redirect_loader._redirect = None
    with pytest.raises(ImportError):
        redirect_loader.load_module('ansible.test_collection.test_redirect')

    # test with collection in builtin

# Generated at 2022-06-21 08:18:29.929414
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible.module_utils.common.collections import _AnsibleCollectionPkgLoaderBase
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar.baz')
    loader._source_code_path = os.path.join(os.getcwd(), 'bar.py')
    assert not loader.is_package('ansible_collections.foo.bar.baz')
    assert loader.is_package('ansible_collections.foo.bar')
    loader._source_code_path = os.path.join(os.getcwd(), 'bar')
    assert loader.is_package('ansible_collections.foo.bar.baz')
    assert loader.is_package('ansible_collections.foo.bar')

# Generated at 2022-06-21 08:18:38.267361
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # Test that _AnsibleCollectionRootPkgLoader() raises exception when called with non-toplevel package
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar')

    # Test that _AnsibleCollectionRootPkgLoader() raises exception when called with non-ansible_collections
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('foo.bar')

    # Test that _AnsibleCollectionRootPkgLoader() doesn't raise an exception when called with ansible_collections
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')

    # Test that _AnsibleCollectionRootPkgLoader's get_source() method raises exception with non-ansible_collections

# Generated at 2022-06-21 08:18:50.104993
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_name.some.invalid.dir')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_name.')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_ns.my_name.invalid_name')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_ns.invalid_name.someresource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_collection.someresource')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my_ns')


# Generated at 2022-06-21 08:18:55.832170
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert_raises(ValueError, AnsibleCollectionRef, 'bogus', '', 'name', '')
    assert_raises(ValueError, AnsibleCollectionRef, '', '', 'name', '')
    assert_raises(ValueError, AnsibleCollectionRef, 'bogus.namespace', '', 'name', '')
    assert_raises(ValueError, AnsibleCollectionRef, 'name.space', '', 'name', '')
    assert_raises(ValueError, AnsibleCollectionRef, 'bogus.namespace.collection-name', '', 'name', '')
    assert_raises(ValueError, AnsibleCollectionRef, 'name.space.collection-name', '', 'name', '')

# Generated at 2022-06-21 08:19:06.662151
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef

# Generated at 2022-06-21 08:19:32.935681
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    fqcr = AnsibleCollectionRef(u'namespace.collection', u'subdir1.subdir2', u'foo', u'action')
    assert repr(fqcr) == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='foo')"



# Generated at 2022-06-21 08:19:40.557475
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():

    # Arrange
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._n_playbook_paths = []
    collection_finder._n_cached_collection_paths = None
    new_playbook_paths = ["/etc/ansible/collections"]

    # Act
    collection_finder.set_playbook_paths(new_playbook_paths)

    # Assert
    assert collection_finder._n_cached_collection_paths == new_playbook_paths

# Generated at 2022-06-21 08:19:51.189853
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    test_case = unittest.TestCase()

    test_loader = _AnsibleCollectionPkgLoader('test_loader', 'foo', '/test/bar', [])
    test_case.assertEqual(test_loader._fullname, 'test_loader')
    test_case.assertEqual(test_loader._package_to_load, 'foo')
    test_case.assertEqual(test_loader._source_code_path, '/test/bar')
    test_case.assertEqual(test_loader._subpackage_search_paths, [])

    test_loader = _AnsibleCollectionPkgLoader('', None, '/test/bar', [])
    test_case.assertEqual(test_loader._fullname, '')

# Generated at 2022-06-21 08:19:53.766900
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert repr(_AnsiblePathHookFinder(None, '/some/path')) == "_AnsiblePathHookFinder(path='/some/path')"

# Represents a loader that handles redirections under the ansible package. This is particularly useful for dealing with
# 2.9 deprecations and future removals, but also allows us to evolve the package structure without breaking old code.

# Generated at 2022-06-21 08:20:05.643806
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():

    # Test that method raises an exception when argument collection_name
    # is of type None
    no_collection_name = None
    try:
        AnsibleCollectionRef.is_valid_collection_name(no_collection_name)
    except TypeError:
        pass
    else:
        assert False, "'AnsibleCollectionRef.is_valid_collection_name' does not fail when argument collection_name is of type None"

    # Test that method returns False when argument collection_name
    # is of type int
    invalid_collection_name = 0
    assert AnsibleCollectionRef.is_valid_collection_name(invalid_collection_name) is False, "'AnsibleCollectionRef.is_valid_collection_name' returns True when argument collection_name is of type int"

    # Test that method returns False when argument collection_name
    # is

# Generated at 2022-06-21 08:20:14.383454
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.collection.subdir.subdir.resource', 'role') == AnsibleCollectionRef('ns.collection', 'subdir.subdir', 'resource', 'role')

    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource.path', 'role')

    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ns.collection.subdir1.subdir2.resource', None)


# Generated at 2022-06-21 08:20:20.596455
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class TestLoader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(TestLoader, self).__init__(fullname, path_list)
            self._subpackage_search_paths = ['path1', 'path2']
            self._source_code_path = 'source_path'

    test_loader = TestLoader('collection_name')
    assert test_loader._subpackage_search_paths == ['path1', 'path2']
    assert test_loader._source_code_path == 'source_path'



# Generated at 2022-06-21 08:20:29.998547
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # This test uses the code in _AnsiblePathHookFinder for constructing and returning the
    # _filefinder_path_hook. This code does not use self, so test__AnsiblePathHookFinder()
    # does not use the self argument.
    _AnsiblePathHookFinder._filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()


# Base class for our loaders. This mostly handles a few things that'd be better in the Python core import machinery,
# but aren't.

# Generated at 2022-06-21 08:20:40.582688
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    '''
    unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
    '''
    # test pkg_loader's variable of _AnsibleCollectionPkgLoaderBase
    pkg_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.somens', path_list=['/usr/share/ansible/ansible_collections/somens'])
    pkg_loader._source_code_path = '/usr/share/ansible/ansible_collections/somens/a.py'
    pkg_loader._decoded_source = 'abcdefg'

# Generated at 2022-06-21 08:20:42.198399
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    pass

# implements the custom path_hook interceptor for all names in the ansible_collections namespace

# Generated at 2022-06-21 08:21:11.907047
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import inspect

    # this test is intended to check the _filefinder_path_hook is sane.
    # if it fails it is most likely that there is a FileFinder hook that is named differently
    # or there are two or more FileFinder Hooks
    _AnsiblePathHookFinder._filefinder_path_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    assert inspect.isclass(_AnsiblePathHookFinder._filefinder_path_hook)
    assert 'file' in _AnsiblePathHookFinder._filefinder_path_hook.__name__.lower()
    assert 'finder' in _AnsiblePathHookFinder._filefinder_path_hook.__name__.lower()



# Generated at 2022-06-21 08:21:16.575439
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    pass

    # TODO: write unit tests for _AnsibleCollectionFinder.find_module
    #
    # Hint:
    #   - The constructor of class _AnsibleCollectionFinder should accept only one input argument.
    #   - def find_module(self, fullname, path=None):

# Base class for all PathHookFinder subclasses

# Generated at 2022-06-21 08:21:25.454793
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    #  _AnsiblePathHookFinder(self, collection_finder, pathctx)
    collection_finder = _AnsibleCollectionFinder()
    apf = _AnsiblePathHookFinder(collection_finder, '/tmp')
    assert apf._pathctx == '/tmp'
    assert apf._collection_finder == collection_finder
    if PY3:
        assert apf._file_finder == None

###
# Internal traversal of the filesystem to find Ansible collection and package content.
#
# The API uses the generator pattern to return objects representing the packages and modules discovered.
#
# The API is only used internally, and subject to change at any time.
#



# Generated at 2022-06-21 08:21:34.438483
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # TODO: more check for future
    assert(AnsibleCollectionRef.is_valid_fqcr('ansible.builtin.ping') == True)
    assert(AnsibleCollectionRef.is_valid_fqcr('ansible.collections.test.ping') == True)
    assert(AnsibleCollectionRef.is_valid_fqcr('ansible.collections.test.ping.py') == True)
    assert(AnsibleCollectionRef.is_valid_fqcr('ansible.collections.test.ping.yml') == True)
    assert(AnsibleCollectionRef.is_valid_fqcr('ansible.collections.test.ping.ini') == True)

# Generated at 2022-06-21 08:21:45.022321
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    path = 'path'
    subpackage_search_paths = 'subpackage_search_paths'
    source_code_path = 'source_code_path'
    o = _AnsibleCollectionPkgLoaderBase('fullname', path_list=[to_native(p) for p in path])
    o._subpackage_search_paths = subpackage_search_paths
    o._source_code_path = source_code_path
    assert repr(o) == '_AnsibleCollectionPkgLoaderBase(path=subpackage_search_paths)'
    del o._subpackage_search_paths
    assert repr(o) == '_AnsibleCollectionPkgLoaderBase(path=source_code_path)'

