

# Generated at 2022-06-21 08:12:51.623160
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # Test that invalid collection names fail
    for bad_name in [u'', u'one', u'one.two.three', u'invalid.namespace', u'invalid.collection.name']:
        with pytest.raises(ValueError):
            AnsibleCollectionRef(bad_name, None, 'no_matter_resource', 'no_matter_type')

    # Test that invalid subdirs fail
    with pytest.raises(ValueError):
        AnsibleCollectionRef('valid.collection', 'invalid.subdirs', 'no_matter_resource', 'no_matter_type')

    # Test that invalid ref_types fail
    with pytest.raises(ValueError):
        AnsibleCollectionRef('valid.collection', None, 'no_matter_resource', 'invalid_type')

    # Test that no resource fails

# Generated at 2022-06-21 08:12:52.511943
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pass


# Generated at 2022-06-21 08:13:05.228540
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible.utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    class MockModule():
        def __init__(self, path):
            self.path = path
            self.called = False
            self.b_path = to_bytes(path)
            self.fd = StringIO()
        def isfile(self, p):
            self.called = True
            f = self.fd
            f.seek(0,0)
            return f.name == p or p == self.path
        def isdir(self, p):
            d = self.fd.name
            return os.path.dirname(d) == p
        def open(self, p, mode):
            if mode == 'rb':
                f = self.fd
                f.seek(0,0)
               

# Generated at 2022-06-21 08:13:15.545196
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    ansible_collection_finder = _AnsibleCollectionFinder(paths=['/path1', '/path2'])
    assert ansible_collection_finder._n_configured_paths == ['/path1', '/path2']
    assert ansible_collection_finder._n_cached_collection_paths is None
    assert ansible_collection_finder._n_cached_collection_qualified_paths is None
    assert ansible_collection_finder._n_playbook_paths == []
    # TODO: add a test for _ansible_pkg_path
    assert ansible_collection_finder._n_collection_paths == ['/path1', '/path2']


# Generated at 2022-06-21 08:13:17.069021
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('')


# Generated at 2022-06-21 08:13:25.168519
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    """Unit test for constructor of class _AnsibleCollectionPkgLoaderBase"""

    path_list = []
    fullname = 'ansible_collections.my.type.name'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert loader._fullname == fullname
    assert loader._split_name == fullname.split('.')
    assert loader._rpart_name[0] == 'ansible_collections.my.type'
    assert loader._rpart_name[1] == '.'
    assert loader._rpart_name[2] == 'name'
    assert loader._parent_package_name == 'ansible_collections.my.type'
    assert loader._package_to_load == 'name'
    assert loader._candidate_paths == []
    assert loader._sub

# Generated at 2022-06-21 08:13:33.412511
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:13:44.888000
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.utils.collection_loader import _AnsiblePathHookFinder
    from ansible.utils.collection_loader import _AnsibleCollectionFinder

    import sys
    import pkgutil
    _AnsiblePathHookFinder._filefinder_path_hook = lambda self=None: pkgutil.ImpImporter(sys.modules['ansible'].__path__[0])

    ctx = _AnsibleCollectionFinder()
    ctx._install()

    ctx.set_playbook_paths([os.path.dirname(os.path.realpath(__file__))])  # provides ansible_collections.testns.testcoll
    assert(isinstance(ctx.find_module('ansible_collections.testns.testcoll'), _AnsibleCollectionLoader))


# Generated at 2022-06-21 08:13:56.023138
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    path = '/collection_root/toplevel/ansible_collections/my_namespace/my_collection'
    collection_finder = _AnsibleCollectionFinder()
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, path)
    expected_result = {(
        'ansible_collections', ('/collection_root/toplevel/ansible_collections/my_namespace/my_collection/ansible_collections', None, False)
    )}
    result = None
    try:
        result = set(path_hook_finder.iter_modules())
    except ImportError:
        pass
    assert result == expected_result



# Generated at 2022-06-21 08:14:06.864594
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # Given
    path = [os.environ['ANSIBLE_COLLECTIONS_PATH'].split(os.pathsep)[-1]]
    finder = _AnsibleCollectionFinder(paths=path)

    # When
    loader = finder.find_module('ansible_collections.acme.terminal')

    # Then
    assert loader is not None


    # Given
    path = [os.environ['ANSIBLE_COLLECTIONS_PATH'].split(os.pathsep)[-1]]
    finder = _AnsibleCollectionFinder(paths=path)

    # When
    loader = finder.find_module('ansible_collections.acme.terminal.plugins.modules.config')

    # Then
    assert loader is not None



# Generated at 2022-06-21 08:14:49.184484
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:14:50.970116
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # _AnsibleCollectionPkgLoader()
    assert False

# _find_module implementation for all three custom namespace package loaders

# Generated at 2022-06-21 08:14:57.331615
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    repr_value = repr(_AnsiblePathHookFinder(None, '/fake_path/'))
    assert repr_value == "_AnsiblePathHookFinder(path='/fake_path/')"


try:
    # the internal PathEntryImporter was made public in py37
    _PathEntryImporter = importlib.machinery.PathEntryFinder
except AttributeError:
    _PathEntryImporter = None



# Generated at 2022-06-21 08:15:04.250909
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    logger.info("test__AnsibleCollectionPkgLoaderBase_get_filename")
    path_list = ['/home/mrocha/ansible/ansible_collections/ungit/ansible_test/plugins']
    fullname = 'ansible_collections.ungit.ansible_test.plugins.lookup.fib'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    logger.info(loader.get_filename(fullname))
# end of Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase


# Generated at 2022-06-21 08:15:08.461042
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """
    Initialize a class _AnsiblePathHookFinder
    """

    # Setup
    hook_finder = _AnsiblePathHookFinder()

    # Exercise
    hook_finder_repr = repr(hook_finder)

    # Verify
    assert hook_finder_repr == '_AnsiblePathHookFinder(path=\'"{0}"\')'.format(hook_finder._pathctx)



# Generated at 2022-06-21 08:15:20.503410
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    r = AnsibleCollectionRef.from_fqcr('foo.bar.baz', 'role')
    assert r.fqcr == 'foo.bar.baz'
    assert r.collection == 'foo.bar'
    assert r.subdirs == ''
    assert r.resource == 'baz'
    assert r.ref_type == 'role'

    r = AnsibleCollectionRef.from_fqcr('foo.bar.baz.quux', 'role')
    assert r.fqcr == 'foo.bar.baz.quux'
    assert r.collection == 'foo.bar'
    assert r.subdirs == 'baz'
    assert r.resource == 'quux'
    assert r.ref_type == 'role'


# Generated at 2022-06-21 08:15:32.195076
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import tempfile

    with _AnsiblePathHookFinder.__get_path_context__() as pathctx:
        os.mkdir(os.path.join(pathctx.basedir, 'test_collections'))
        os.mkdir(os.path.join(pathctx.basedir, 'not_collections'))
        os.mkdir(os.path.join(pathctx.basedir, 'test_collections', 'test_namespace'))
        os.mkdir(os.path.join(pathctx.basedir, 'test_collections', 'test_namespace', 'test_collection'))
        os.mkdir(os.path.join(pathctx.basedir, 'test_collections', 'test_namespace', 'test_collection', 'plugins'))

# Generated at 2022-06-21 08:15:39.080491
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
  ref = 'a.b.c'
  ref_type = 'module'
  ansiblecollectionref = AnsibleCollectionRef.from_fqcr(ref, ref_type)
  assert(ansiblecollectionref.collection == 'a.b')
  assert(ansiblecollectionref.subdirs == '')
  assert(ansiblecollectionref.resource == 'c')
  assert(ansiblecollectionref.ref_type == 'module')
  assert(ansiblecollectionref.n_python_collection_package_name == 'ansible_collections.a.b')
  assert(ansiblecollectionref.n_python_package_name == 'ansible_collections.a.b.plugins.module')
  assert(ansiblecollectionref.fqcr == 'a.b.c')
  return 0


# Generated at 2022-06-21 08:15:51.234333
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert not AnsibleCollectionRef.try_parse_fqcr(None, ref_type=None)
    assert not AnsibleCollectionRef.try_parse_fqcr(None, ref_type='foo')
    assert not AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.plugin_name', ref_type=None)
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.plugin_name', ref_type='foo')
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.subdir2.plugin_name', ref_type='foo').fqcr == 'ns.coll.subdir1.subdir2.plugin_name'
    assert AnsibleCollectionRef.try_parse_fq

# Generated at 2022-06-21 08:16:01.914020
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.coll_b.pkg_a')
    loader._subpackage_search_paths = ['/path/to/ns/coll_b/pkg_a']
    loader.get_code('ansible_collections.ns.coll_b.pkg_a')
    assert 'src/ansible_collections/ns/coll_b/pkg_a/__init__.py' in loader._source_code_path

    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns.coll_b.pkg_a')
    loader._subpackage_search_paths = ['/path/to/ns/coll_b/pkg_a']

# Generated at 2022-06-21 08:16:46.387891
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()

    # Create a temp file
    file_handler = tempfile.NamedTemporaryFile(mode='w')

    # Get the filename
    tmp_file = file_handler.name

    # Playbook paths
    playbook_paths = [tmp_file, tmp_dir.name]

    # Create _AnsibleCollectionFinder
    finder = _AnsibleCollectionFinder()

    # Call set_playbook_paths method
    finder.set_playbook_paths(playbook_paths)

    # Check the _AnsibleCollectionFinder's _n_playbook_paths

# Generated at 2022-06-21 08:16:50.613119
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder._get_filefinder_path_hook()


# this is a wrapper around the internal ansible package, to provide
# partial support for 2.x -> 2.x+1 package name transitions, where
# old names in 2.x+1 can be redirected to the new names (eg
# ansible.plugins.vars is redirected to ansible.plugins.vars.vars)
# Since we can't reasonably take over import for ansible, we use
# a meta_path hook that is consulted both before the builtin (sys.meta_path)
# and after the python path (sys.path_hooks)

# Generated at 2022-06-21 08:16:58.493546
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    split_name = ['ansible_collections', 'mynamespace', 'mycollection']
    package_to_load = 'mycollection'
    candidate_paths = ['/usr/share/ansible/collections', '/etc/ansible/collections', '/usr/share/ansible/collections']
    create_subpackage_search_paths = _create_subpackage_search_paths

    loader = _AnsibleCollectionPkgLoader(split_name, package_to_load, candidate_paths, create_subpackage_search_paths)

    candidate_paths = ['/usr/share/ansible/collections', '/etc/ansible/collections', '/usr/share/ansible/collections']
    create_subpackage_search_paths = _create_subpackage_search_paths

    loader.candidate

# Generated at 2022-06-21 08:17:07.931958
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test case data
    fullname = 'ansible_collections.myns.mypkg'
    subpackage_search_paths = None
    result = {'success': True, 'exception': None, 'return': False}
    # Perform the test
    try:
        obj = _AnsibleCollectionPkgLoaderBase(fullname, subpackage_search_paths)
        result['return'] = obj.is_package(fullname)
    except Exception as e:
        result['success'] = False
        result['exception'] = str(e)
    return result



# Generated at 2022-06-21 08:17:16.363013
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # A unit test for method load_module of class _AnsibleCollectionPkgLoader
    # that depended on a global function _meta_yml_to_dict which is not defined
    # anywhere in ansible source code. 
    # For the test to pass, we define the global function here as an anonymous function
    # returning an empty dictionary.
    global _meta_yml_to_dict
    _meta_yml_to_dict = lambda _, __: {}

    import ansible
    ansible_path = os.path.dirname(ansible.__file__)
    meta_path =  os.path.join(ansible_path, 'config/ansible_builtin_runtime.yml')
    with open(to_bytes(meta_path), 'rb') as fd:
        raw_routing = fd.read

# Generated at 2022-06-21 08:17:27.599129
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    s_path = ['/path/to/ansible_collections/my_namespace/my_collection']
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.my_namespace.my_collection", path_list=s_path)
    assert loader.is_package("ansible_collections.my_namespace.my_collection") is True
    assert loader.is_package("ansible_collections.my_namespace.my_collection.my_module") is False
    assert loader.is_package("ansible_collections.my_namespace.my_collection.my_package") is True
    assert loader.is_package("ansible_collections.my_namespace.my_collection.my_package.my_module") is False

# Generated at 2022-06-21 08:17:38.899986
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible
    def mock__AnsibleCollectionPkgLoaderBase_load_module(self, module_name):
        return None
    def mock_get_collection_version(collection_name):
        return '0.0.0'
    setattr(_AnsibleCollectionPkgLoaderBase, '_load_module', mock__AnsibleCollectionPkgLoaderBase_load_module)
    import ansible
    setattr(ansible, 'get_collection_version', mock_get_collection_version)
    import ansible.utils.collection_loader
    import yaml
    class _MockLoader:
        def _meta_yml_to_dict(self, raw_data, path_hint):
            return yaml.safe_load(raw_data)


# Generated at 2022-06-21 08:17:44.998397
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    if not AnsibleCollectionRef.is_valid_fqcr('test_ns.test_coll.test_plugin'):
        pytest.fail('test_ns.test_coll.test_plugin should be a valid plugin reference')

    if not AnsibleCollectionRef.is_valid_fqcr('test_ns.test_coll.subdir.test_plugin'):
        pytest.fail('test_ns.test_coll.subdir.test_plugin should be a valid plugin reference')

    if not AnsibleCollectionRef.is_valid_fqcr('test_ns.test_coll.role_dir.test_role'):
        pytest.fail('test_ns.test_coll.role_dir.test_role should be a valid role reference')


# Generated at 2022-06-21 08:17:57.681453
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    collection_name = 'namespace.collectionname'
    subdirs = 'subdir1.subdir2'
    resource = 'mymodule'
    ref_type = 'module'
    ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    test_result = ref.is_valid_fqcr('namespace.collectionname.subdir1.subdir2.mymodule')
    assert test_result == True
    test_result = ref.is_valid_fqcr('namespace.collectionname.subdir1.subdir2.test.py')
    assert test_result == False
    test_result = ref.is_valid_fqcr('namespace.collectionname.subdir1.subdir2.test.js')
    assert test_result == False
    test_result = ref

# Generated at 2022-06-21 08:18:10.759977
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Test for the case where ref is valid and ref_type is provided
    ref = 'col.nsp.module'
    ref_type = 'module'
    assert True == AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)

    # Test for the case where ref is valid and ref_type is not provided
    ref = 'col.nsp.module'
    ref_type = None
    assert True == AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)

    # Test for the case where ref is invalid and ref_type is provided
    ref = 'nsp.module'
    ref_type = 'module'
    assert False == AnsibleCollectionRef.is_valid_fqcr(ref, ref_type)

    # Test for the case where ref is invalid and ref_type is not

# Generated at 2022-06-21 08:18:45.943412
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    path_list = []
    fullname = 'ansible_collections.my.my_test_content.test_module_1'
    loader = _AnsibleCollectionPkgLoaderBase(fullname = fullname , path_list = path_list)
    path = '/Users/yiliu/Desktop/ansible/examples/ansible_collections/my/my_test_content/plugins/modules/test_module_1.py'
    print(loader.get_data(path))
    
test__AnsibleCollectionPkgLoaderBase_get_data()


# Generated at 2022-06-21 08:18:56.438742
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # Case 1: Testing with valid legacy_plugin_dir_name and ref_type
    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert result == 'action'

    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert result == 'modules'

    result = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')
    assert result == 'lookup'

    # Case 2: Testing with invalid legacy_plugin_dir_name and ref_type
    with pytest.raises(ValueError, match=r'utility_plugins cannot be mapped to a valid collection ref type'):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('utility_plugins')
   

# Generated at 2022-06-21 08:19:07.209493
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    def _fake_get_candidate_paths(*_, **__):
        return []

    def _fake_load_module(_, m):
        return m

    _test_cases = [
        (['toplevel', 'subpkg'], None, TypeError, 'can only load', None),
        (['ansible_collections', 'subpkg'], None, TypeError, 'can only load', None),
        (['ansible_collections'], None, ImportError, 'no collection paths have been configured', None)
    ]

    for args, kwargs, exp_exc, exp_err_str, exp_redir_mod in _test_cases:
        with pytest.raises(exp_exc) as excinfo:
            _AnsibleCollectionRootPkgLoader(*args, **kwargs)

# Generated at 2022-06-21 08:19:18.821079
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subdir2') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subdir2.subdir3.resource') == True
    assert AnsibleCollectionRef

# Generated at 2022-06-21 08:19:27.757820
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import doctest
    failures, tests = doctest.testmod(m=_AnsibleCollectionPkgLoaderBase)
    assert not failures


# NB: this loader will redirect a module to another module if it exists, in cases where a collection namespace package
# is layering over a toplevel namespace, such as ansible.module_utils over ansible_module_utils. This is to allow
# behavior like the following to work:
# - No code in the in the collection (eg, user collection layer)
# - Python code in the toplevel module which is being layered over
# - Unspecified order of namespace declaration (can be toplevel, collection, or a mix)
# - Python code in the collection that depends on the toplevel code working (can depend on behavior and/or __file__)
#
# This will also attempt to load a matching module (based on

# Generated at 2022-06-21 08:19:32.400307
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    collection_ref = AnsibleCollectionRef('mycollection.mymodule',None,'mymodule',None)

    assert collection_ref.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'



# Generated at 2022-06-21 08:19:42.500479
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    '''Test for method set_playbook_paths of class _AnsibleCollectionFinder.'''

    import tempfile
    from ansible_collections.ansible.community.plugins.module_utils.common.text.converters import to_bytes
    from ansible_collections.ansible.community.tests.unit.test_collection_loader._collection_config import AnsibleCollectionConfig

    tmpdir = tempfile.TemporaryDirectory()
    # Create a directory where Ansible Collection data can be held
    playbook_dir = os.path.join(tmpdir.name, 'ansible_collections', 'ansible', 'community', 'plugins')
    os.makedirs(playbook_dir)
    c_config_path = os.path.join(playbook_dir, '__init__.py')

# Generated at 2022-06-21 08:19:46.238838
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    l = _AnsibleCollectionPkgLoaderBase('foo.bar', path_list=[])
    assert l.is_package('foo.bar') is True
    assert l.is_package('bar.baz') is False

# Generated at 2022-06-21 08:19:55.180036
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert_raises(ValueError, AnsibleCollectionRef.from_fqcr, 'ansible.builtin.role.foo', 'module')
    assert_raises(ValueError, AnsibleCollectionRef.from_fqcr, 'ansible.builtin.rolename', 'role')
    assert_raises(ValueError, AnsibleCollectionRef.from_fqcr, 'ansible.builtin.rolename.yaml', 'role')
    assert_raises(ValueError, AnsibleCollectionRef.from_fqcr, 'ansible.builtin.rolename.yaml', 'module')
    assert_raises(ValueError, AnsibleCollectionRef.from_fqcr, 'ansible.builtin.rolename.yaml.yaml', 'role')

# Generated at 2022-06-21 08:20:05.265085
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    expected_repr = {}
    expected_repr[{'pathctx': 'some_path'}] = '_AnsiblePathHookFinder(path=\'some_path\')'

    pathctx = 'some_path'
    collection_finder = mock.Mock()
    object_class = _AnsiblePathHookFinder
    arg_dict = {
        'pathctx': pathctx,
        'collection_finder': collection_finder,
    }
    object_instance = object_class(**arg_dict)
    tested_repr = repr(object_instance)
    assert tested_repr == expected_repr[arg_dict]



# Generated at 2022-06-21 08:20:40.462929
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # pylint: disable=no-member
    # pylint: disable=protected-access
    from ansible_collections.testns.testcoll import test_plugin
    import ansible_collections
    import ansible_collections.testns.testcoll
    from ansible_collections.testns import testcoll
    test_coll_path = to_native(os.path.dirname(to_bytes(test_plugin.__file__)))
    test_coll_base = to_native(os.path.basename(test_coll_path))
    test_coll_ns = 'testns'
    test_coll_name = 'testcoll'
    test_coll_full_name = '{0}.{1}'.format(test_coll_ns, test_coll_name)
    test_coll_pkg_mod_

# Generated at 2022-06-21 08:20:44.938595
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'

    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections.foo.bar')


# Generated at 2022-06-21 08:20:54.386962
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # Arrange
    paths = ['/opt/ansible_collections/ansible_collections',
             '/usr/local/share/ansible/collections',
             '/usr/share/ansible/collections']
    expected = ['/opt/ansible_collections',
                '/usr/local/share/ansible/collections',
                '/usr/share/ansible/collections']

    # Act
    ansible_finder = _AnsibleCollectionFinder(paths)

    # Assert
    assert ansible_finder._n_configured_paths == expected



# Generated at 2022-06-21 08:21:02.900064
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test that get_code returns None when there is no code to return

    class _AnsibleCollectionPkgLoaderBaseChild(_AnsibleCollectionPkgLoaderBase):
        # this method will always return None
        def get_source(self, fullname):
            return None

    loader = _AnsibleCollectionPkgLoaderBaseChild(fullname='ansible.utils.vault', path_list=['/this/path/does/not/exist'])
    assert loader.get_code('ansible.utils.vault') is None

# end of test__AnsibleCollectionPkgLoaderBase_get_code



# Generated at 2022-06-21 08:21:12.018259
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    all_modules = ['__init__', 'ansible', 'foo', 'bar']
    class _AnsibleCollectionPkgLoaderBase(object):
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def _get_candidate_paths(self, path_list):
            return path_list
        def _validate_args(self):
            pass
        def _validate_final(self):
            pass
        def load_module(self, fullname):
            pass
        def is_package(self, fullname):
            return True
        def get_source(self, fullname):
            pass
        def get_data(self, path):
            pass
        def get_filename(self, fullname):
            pass

# Generated at 2022-06-21 08:21:20.835525
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name = "/tmp/ansible_collections/ansible/test_collection"
    subdirs = "/tmp/ansible_collections/ansible/test_collection/plugins/modules"
    resource = "ansible_collections"
    ref_type = "module"

    ansible_collection_ref = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert ansible_collection_ref.__repr__() == "AnsibleCollectionRef(collection='/tmp/ansible_collections/ansible/test_collection', subdirs='/tmp/ansible_collections/ansible/test_collection/plugins/modules', resource='ansible_collections')"



# Generated at 2022-06-21 08:21:30.122653
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():

    # Example method
    import os
    import sys
    module_name = 'ansible_collections.somens.somecoll.plugins.module_utils'
    path_list = ['/path/to/ansible_collection_root']
    collection_finder = _AnsibleCollectionFinder()
    path_context = os.path.join(path_list[0], 'ansible_collections', 'somens', 'somecoll')
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, path_context)
    loader = path_hook_finder.find_module(module_name, path_list)

    # Verify the results
    assert loader

# Generated at 2022-06-21 08:21:44.069498
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    from ansible_collections.ansible.builtin import load_collections
    collections = load_collections('ansible.builtin')

    for collection in collections:
        for plugin in collection.plugins:
            for subdir in plugin.subdirs:
                for plugin_obj in plugin.packages.get(subdir, []):
                    name = plugin_obj.get(u'name')
                    collection_name = plugin_obj.get(u'collection')
                    # FUTURE: handle debug flags here?
                    ref = AnsibleCollectionRef(collection_name, subdir, name, plugin.name)

                    assert ref.collection == to_text(collection_name)
                    assert ref.subdirs == to_text(subdir)
                    assert ref.resource == to_text(name)
                    assert ref.ref_type == to_text