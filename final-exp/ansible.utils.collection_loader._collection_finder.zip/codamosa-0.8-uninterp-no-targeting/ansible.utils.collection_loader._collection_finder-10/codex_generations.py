

# Generated at 2022-06-21 08:12:55.095412
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import sys
    import os
    import imp
    import ansible.utils.collection_loader
    import ansible.utils.collection_list
    path = os.path.dirname(ansible.utils.collection_list.__file__)
    file_, pathname, descr = imp.find_module('collection_list', [path])
    module = imp.load_module('collection_list', file_, pathname, descr)
    ansible_collections_paths = module.list_collections()
    file_, pathname, descr = imp.find_module('collection_loader', [path])
    module = imp.load_module('collection_loader', file_, pathname, descr)
    ansible.utils.collection_loader._meta_yml_to_dict = module.meta_yml_to_dict

# Generated at 2022-06-21 08:13:04.138740
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    target_func = _AnsibleCollectionPkgLoaderBase.iter_modules

    # basic cases:
    prefix = 'ansible'
    paths = ['path1', 'path2']
    tests = [
        ({'prefix': prefix, 'paths': paths}, {'expected': ('path1', 'path2')}),
        ({}, {'expected': tuple()})
    ]
    for t in tests:
        res = target_func(t['args']['prefix'], t['args']['paths'])
        assert res == t['expected']



# Generated at 2022-06-21 08:13:08.189767
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection_name')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.not-valid')
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.')




# Generated at 2022-06-21 08:13:17.646264
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    ansible_collections_path = os.path.join(os.getcwd(), 'test_support/units/collection')
    pathlist = [ansible_collections_path]
    name = 'ansible_collections.somens'
    expected = '_AnsibleCollectionPkgLoaderBase(path=[\'/home/ec2-user/ansible/test_support/units/collection/somens\'])'
    actual = _AnsibleCollectionPkgLoaderBase(name, pathlist).__repr__()
    assert expected == actual



# Generated at 2022-06-21 08:13:22.514458
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # Arrange
    mocked_fullname = 'mocked_fullname'
    mocked_path = None
    loader_base = _AnsibleCollectionPkgLoaderBase(mocked_fullname, mocked_path)

    # Act
    result = loader_base.__repr__()

    # Assert
    assert result == '_AnsibleCollectionPkgLoaderBase(path=None)'



# Generated at 2022-06-21 08:13:35.418808
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    _AnsibleCollectionFinder._remove()
    sys.path.append('tests/support/test_output')
    assert _AnsibleCollectionConfig.collection_finder is None
    c_finder = _AnsibleCollectionFinder()
    c_finder._install()
    # Necessary step to set paths correctly
    c_finder.set_playbook_paths(['tests/support'])
    assert _AnsibleCollectionConfig.collection_finder is c_finder
    assert c_finder.find_module('ansible_collections.test.test_collection') is not None
    assert c_finder.find_module('ansible_collections.test.test_collection.test') is not None
    assert c_finder.find_module('ansible_collections.test.test_collection.test.test_foo') is not None


# Generated at 2022-06-21 08:13:36.705532
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test logic of the method try_parse_fqcr
    pass



# Generated at 2022-06-21 08:13:41.314318
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    c = _AnsibleCollectionFinder()
    c._install()
    f = _AnsiblePathHookFinder(c, pathctx="test")
    assert repr(f) == "_AnsiblePathHookFinder(path='test')"
    c._remove()


# Generated at 2022-06-21 08:13:45.839411
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible
    import ansible.utils.import_module as import_module
    import ansible.utils.collection_loader as collection_loader
    import ansible.plugins as plugins
    import ansible.plugins.action as action
    import ansible.plugins.action.copy as copy
    import ansible.plugins.connection as connection
    import ansible.plugins.connection.ssh as ssh
    import ansible.plugins.executor as executor
    import ansible.plugins.filter as filter
    import ansible.plugins.inventory_plugin as inventory_plugin
    import ansible.plugins.lookup as lookup
    import ansible.plugins.perftool as perftool
    import ansible.plugins.strategy as strategy
    import ansible.plugins.test_module as test_module
    import ansible.plugins.test_module.unit_test

# Generated at 2022-06-21 08:13:58.499595
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Get instance of class
    ansible_path_hook_finder = _AnsiblePathHookFinder(
        '',
        '/Users/shubham.arora/ansible/lib/ansible/module_utils'
    )
    # Assert the output from method iter_modules by providing some module name
    assert ansible_path_hook_finder.iter_modules(prefix='ansible.module_utils') == \
        (('ansible.module_utils', '', False),)


# search the passed in paths for modules matching the passed in prefix;
# TODO: this is re-implemented here instead of just calling pkgutil.iter_modules because pkgutil's one ignores
# non-matching prefixes if a matching prefix is found under the path (eg, ansible.galaxy.foo and ansible_collections.

# Generated at 2022-06-21 08:14:52.582652
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    """Unit test for method load_module of class _AnsibleInternalRedirectLoader"""
    # TODO - implement
    assert False


# fallback importer that handles normal import mechanisms

# Generated at 2022-06-21 08:15:02.807049
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    fullname = 'ansible.foo'
    path_list = []
    path = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert path.__dict__['_redirect'] == None

    fullname = 'ansible_foo'
    path_list = []
    path = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert path.__dict__['_redirect'] == None

    fullname = 'ansible.builtin.foo'
    path_list = []
    path = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert path.__dict__['_redirect'] == None


# implements Ansible internal module redirection

# Generated at 2022-06-21 08:15:10.302545
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    print("in test__AnsibleCollectionFinder_set_playbook_paths ")
    finder = _AnsibleCollectionFinder(scan_sys_paths=False)
    assert not finder._n_playbook_paths
    finder.set_playbook_paths(['/one', '/two'])
    assert finder._n_playbook_paths == ['/one/collections', '/two/collections']


# Generated at 2022-06-21 08:15:14.797040
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('namespace.collection', None, 'resource', 'playbook')
    assert ref.__repr__() == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'\', resource=\'resource\')'



# Generated at 2022-06-21 08:15:17.471334
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # given
    fullname = 'ansible.builtin.foo'
    path_list = ['ansible.builtin.foo']
    redirect_to = 'ansible.builtin.foo'

    test_loader = _AnsibleInternalRedirectLoader(fullname, path_list)

    # when
    load_module(test_loader, fullname, redirect_to)

    # then
    # assert nothing

# Generated at 2022-06-21 08:15:19.240260
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    ffh = _AnsiblePathHookFinder(None, 'some_path')
    assert repr(ffh) == "{0}(path='{1}')".format(ffh.__class__.__name__, 'some_path')



# Generated at 2022-06-21 08:15:22.230793
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    acf = _AnsibleCollectionFinder()
    assert acf._ansible_pkg_path
    assert to_native(acf._ansible_pkg_path).startswith(to_native(os.path.dirname(sys.executable)))

########################################################################################################################
# Loader for things under the ansible package
########################################################################################################################
# NB: Loader constructors are called with a parent loader and a fullname, so the parent must be made to understand
#  the names this loader can handle


# Generated at 2022-06-21 08:15:30.178831
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
        coll_path = '/path/to/my/collection-1.0.0'
        coll_name = 'my.collection'
        coll_module = 'my.collection.submodule'
        coll_synthetic = 'my.collection.fakemodule'
        coll_package = 'my.collection.subpackage'
        fp = Path('/path/to/my/collection-1.0.0/submodule.py')
        loader = _AnsibleCollectionPkgLoaderBase(coll_module, [coll_path])
        assert loader.get_filename(coll_module) == str(fp)
        # test that is_package(fullname) works
        assert loader.is_package(coll_module) == False
        loader2 = _AnsibleCollectionPkgLoaderBase(coll_package, [coll_path])
        # test

# Generated at 2022-06-21 08:15:31.285428
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # FIXME: tests for iter_modules should occur under integration tests; this is a hard thing for unit tests
    assert True



# Generated at 2022-06-21 08:15:39.474418
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _TestClass(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            if self._package_to_load != 'somens':
                raise ImportError('this loader can only load the ansible_collections.somens package, not {0}'.format(self._fullname))

        def _get_candidate_paths(self, path_list):
            return [os.path.join(p, 'somens') for p in path_list]

        def _get_subpackage_search_paths(self, candidate_paths):
            # filter candidate paths for existence (NB: silently ignoring package init code and same-named modules)
            return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]


# Generated at 2022-06-21 08:16:56.225959
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    a = AnsibleCollectionRef.is_valid_fqcr('not.a.fqcr')
    assert a == False
    a = AnsibleCollectionRef.is_valid_fqcr('a.b.c')
    assert a == True
    a = AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e')
    assert a == True
    a = AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e.f.g')
    assert a == True
    a = AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e.f.g.')
    assert a == False

# Generated at 2022-06-21 08:17:07.128832
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    split_name = ['ansible_collections', 'my_namespace', 'my_collection', 'my_module']
    path_list = ['/foo/bar/baz']
    candidate_paths = path_list

    loader = _AnsibleCollectionLoader(split_name, path_list)
    assert loader._split_name == split_name
    assert loader._fullname == '.'.join(split_name)
    assert loader._package_to_load == '.'.join(split_name[2:])
    assert loader._candidate_paths == candidate_paths
    assert loader._subpackage_search_paths == candidate_paths


# Generated at 2022-06-21 08:17:14.330066
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    valid_names = [
        u'ansible.parsing',
        u'ansible_collections.my_namespace.my_collection',
        u'test.test_collection',
    ]
    for name in valid_names:
        assert AnsibleCollectionRef.is_valid_collection_name(name)

    invalid_names = [
        u'',
        u'ansible',
        u'ansible.collection',
        u'collection',
    ]
    for name in invalid_names:
        assert not AnsibleCollectionRef.is_valid_collection_name(name)


# Generated at 2022-06-21 08:17:23.691896
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Create instance of class
    obj = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.test')
    # Create module
    module = ModuleType('ansible_collections.test')
    # Run the method under test
    with patch.object(obj, '_new_or_existing_module'):
        assert obj.load_module(fullname='ansible_collections.test') == module



# Generated at 2022-06-21 08:17:29.734987
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():

    _test_fqcr = 'ns1.collection1.plugins.module.mymodule'

    _res = AnsibleCollectionRef.try_parse_fqcr(_test_fqcr, ref_type='module')

    assert _res.collection == 'ns1.collection1'
    assert _res.subdirs == 'plugins'
    assert _res.resource == 'mymodule'
    assert _res.ref_type == 'module'
    assert _res.fqcr == 'ns1.collection1.plugins.module.mymodule'
    assert _res.n_python_package_name == 'ansible_collections.ns1.collection1.plugins.module'
    assert _res.n_python_collection_package_name == 'ansible_collections.ns1.collection1'

    assert AnsibleCollectionRef.try_

# Generated at 2022-06-21 08:17:40.484312
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    import sys
    import tempfile
    import textwrap
    import unittest

    def source_file(filename, source):
        """
        :type filename: str
        :type source: str
        """
        bfilename = to_bytes(filename)
        bsource = to_bytes(source)
        with open(bfilename, 'wb') as fobj:
            fobj.write(bsource)
        return bfilename

    def fake_collection_module_source(collection_name, collection_version, module_name):
        """
        :type collection_name: str
        :type collection_version: str
        :type module_name: str
        """

# Generated at 2022-06-21 08:17:50.321544
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsibleCollectionFinder(paths=[])
    # Test find_module without path
    path_hook = _AnsiblePathHookFinder(finder, '/some/path')
    assert path_hook.find_module("ansible.random") is None
    assert path_hook.find_module("ansible_collections.another.random") is None
    assert path_hook.find_module("ansible_collections.another_ns.random") is None
    assert path_hook.find_module("ansible_collections.another_ns.random.path") is None



# Generated at 2022-06-21 08:17:52.108658
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    assert  True
# Unit tests for class _AnsibleInternalRedirectLoader

# Generated at 2022-06-21 08:18:01.667289
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef(collection_name='ns.coll', subdirs='subdir1.subdir2', resource='resource', ref_type='module')
    assert ref.collection == 'ns.coll'
    assert ref.subdirs == 'subdir1.subdir2'
    assert ref.resource == 'resource'
    assert ref.ref_type == 'module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.module'
    assert ref.fqcr == 'ns.coll.subdir1.subdir2.resource'

    # parses from_fqcr()
    ref = AnsibleCollectionRef.from_f

# Generated at 2022-06-21 08:18:14.212700
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    tlp = 'fungible'
    tns = tlp + '.collection'
    tc = tns + '.fungible_collection'
    lm = 'library'
    lm_impl = lm + '_mod'
    tlm = tc + '.' + lm
    tlm_impl = tlm + '_impl'
    tlm_nested = tlm + '.nested'
    tlm_nested_impl = tlm_nested + '_impl'
    tpm = 'plugins'
    tpm_impl = tpm + '_mod'
    ttpm = tc + '.' + tpm
    ttpm_impl = ttpm + '_impl'
    ttpm_nested = ttpm + '.nested'
    ttpm_n

# Generated at 2022-06-21 08:19:53.889262
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    class _InitLessLoader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            # code adapted from _AnsibleCollectionPkgLoaderBase.__init__()
            self._fullname = fullname

            assert fullname == 'ansible_collections.testing.anett_a8'

            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for ansible_collections.somens

            # code adapted

# Generated at 2022-06-21 08:20:05.681354
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    from ansible_collections.mycollection.myns.plugins.module_utils.my_utils import my_package
    import ansible_collections.mycollection.another_ns.plugins.module_utils.my_utils as my_package2
    expected_pkg_names = ['ansible_collections.mycollection.another_ns.plugins.module_utils.my_utils', 'ansible_collections.mycollection.myns.plugins.module_utils.my_utils']
    expected_pkg_names.sort()
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(to_bytes(temp_dir), b'__init__.py'), mode='w') as pkg_file:
            pkg_file.write('package init code')

# Generated at 2022-06-21 08:20:17.014448
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import sys
    import pkgutil
    import tempfile

    original_sys_modules = sys.modules.copy()

    # create fake ansible_collections.test, test.subpackage, test.subpackage.sub_subpackage  (no __init__.py, so obviously no modules)
    test_dir = tempfile.mkdtemp()

    # create root package dir
    os.mkdir(os.path.join(test_dir, 'ansible_collections'))
    # create collection dir
    os.mkdir(os.path.join(test_dir, 'ansible_collections', 'test'))
    # create collection subpackage dir
    os.mkdir(os.path.join(test_dir, 'ansible_collections', 'test', 'subpackage'))

    # add test_dir

# Generated at 2022-06-21 08:20:23.242683
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # when there are three or more fields
    assert AnsibleCollectionRef.is_valid_collection_name(u'a.b.c') is False

    # when there is one field
    assert AnsibleCollectionRef.is_valid_collection_name(u'abc') is False

    # when there are two fields
    assert AnsibleCollectionRef.is_valid_collection_name(u'a.b') is True
    assert AnsibleCollectionRef.is_valid_collection_name(u'a-b') is True
    assert AnsibleCollectionRef.is_valid_collection_name(u'_a.b') is True
    assert AnsibleCollectionRef.is_valid_collection_name(u'!a.b') is False
    assert AnsibleCollectionRef.is_valid_collection_name(u'a.b-') is False

# Generated at 2022-06-21 08:20:30.428968
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('my.collection')  # keyword

    try:
        AnsibleCollectionRef.is_valid_collection_name('my.1collection')  # invalid name
        raise AssertionError('should have raised a ValueError')
    except ValueError:
        pass

    assert AnsibleCollectionRef.is_valid_collection_name('1ns.collection')  # valid name, invalid namespace name



# Generated at 2022-06-21 08:20:40.935224
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # Avoid raising error during testing.
    import ansible.module_utils.common.text.converters
    ansible.module_utils.common.text.converters.to_native = lambda x: x

    from ansible.collection import finder
    from ansible.module_utils.common.text.converters import to_text

    # Create a fake tempdir for our test
    import tempfile
    tmp = tempfile.mkdtemp()
    # Get the path for our fake tempdir for the test
    tmp_path = tmp

    # Create a fake collection path
    collection_path = os.path.join(os.path.realpath(tmp_path), 'ansible_collections')

    # Create path to fake collection
    fake_collection_path = os.path.join(collection_path, 'fake_collection')



# Generated at 2022-06-21 08:20:43.677061
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    name = 'ansible.internalged'  # mocked name
    loader = _AnsibleInternalRedirectLoader(name, [])
    loader._redirect = 'ansible.internalged'
    loader.load_module(name)
    assert True



# Generated at 2022-06-21 08:20:46.583935
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name("f5networks.f5ansible") == True


# Generated at 2022-06-21 08:20:53.206894
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    prefix = 'foo'
    collection_finder = _AnsibleCollectionFinder()
    pathctx = 'C:/Users/dongj/Desktop/ansible/lib/ansible/plugins/action'
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    ansible_path_hook_finder.find_module(prefix)



# Generated at 2022-06-21 08:21:02.900721
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    class _Test_AnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return ['/some/path/__init__.py']
        def _validate_final(self):
            self._subpackage_search_paths = ['/some/sub/path']
    # load_module with None query string
    test_obj = _Test_AnsibleCollectionPkgLoaderBase('dummy_fullname', '/some/path')
    assert test_obj.load_module(None) == None


# Generated at 2022-06-21 08:21:32.956331
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    # test data
    pathctx = os.path.join(os.path.dirname(__file__), 'data', 'ansible_collections')
    ansible_collection_finder = _AnsibleCollectionFinder()

    # test different prefixes
    assert sum(1 for _ in _AnsiblePathHookFinder(ansible_collection_finder, pathctx).iter_modules('')) == 2
    assert sum(1 for _ in _AnsiblePathHookFinder(ansible_collection_finder, pathctx).iter_modules('ansible_collections')) == 1
    assert sum(1 for _ in _AnsiblePathHookFinder(ansible_collection_finder, pathctx).iter_modules('ansible_collections.mynamespace')) == 1

# Generated at 2022-06-21 08:21:45.172032
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Instantiate the _AnsibleCollectionPkgLoaderBase class with arguments and check the results
    test_obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar.baz', path_list=['/some/path'])
    assert test_obj._fullname == 'ansible_collections.foo.bar.baz'
    assert test_obj._redirect_module is None
    assert test_obj._split_name == ['ansible_collections', 'foo', 'bar', 'baz']
    assert test_obj._rpart_name == ('ansible_collections.foo.bar', 'baz')
    assert test_obj._parent_package_name == 'ansible_collections.foo.bar'
    assert test_obj._package_to_load == 'baz'
    assert test_