

# Generated at 2022-06-21 08:13:20.866055
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import os
    import tempfile
    from ansible_collections.foo.bar.plugins.modules import baz
    test_path = os.path.dirname(tempfile.mkstemp()[1])
    test_path = os.path.join(test_path, "foo", "bar")
    test_module1 = os.path.join(test_path, "dummy.py")
    test_module2 = os.path.join(test_path, "plugins", "modules", "baz.py")
    temp_module1 = open(test_module1, "w+")
    temp_module2 = open(test_module2, "w+")
    temp_module1.close()
    temp_module2.close()
    search_paths = [test_path]

# Generated at 2022-06-21 08:13:23.660292
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    assert repr(_AnsiblePathHookFinder(None, 'some/path')) == \
           "_AnsiblePathHookFinder(path='some/path')"



# Generated at 2022-06-21 08:13:36.640273
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    if PY3:
        raise SkipTest('Python 3 not supported')

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.nondefault')
    assert loader._fullname == 'ansible_collections.nondefault'
    assert loader._split_name == ['ansible_collections', 'nondefault']
    assert loader._rpart_name == ('ansible_collections', '.', 'nondefault')
    assert loader._parent_package_name == 'ansible_collections' and loader._package_to_load == 'nondefault'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None

# Generated at 2022-06-21 08:13:42.447197
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.')
    assert not AnsibleCollectionRef.is_valid_collection_name('1.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.123')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.sub')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.123')

# Generated at 2022-06-21 08:13:46.887927
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader as cl_module
    collection_loader = cl_module._AnsibleCollectionPkgLoader(fullname='ansible_collections.barking.barking_dog')
    scalar = TestAllScalar()
    target_object = scalar.load_module('ansible_collections.barking.barking_dog')

    assertion_list = ['__loader__', '__file__', '__package__', '__path__', '_collection_meta']
    for assertion in assertion_list:
        if assertion in target_object.__dict__:
            continue
        else:
            raise Exception("The attribute '%s' was not found in target_object" % assertion)


# Generated at 2022-06-21 08:13:52.528196
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    af = _AnsibleCollectionFinder()
    af._install()
    try:
        assert repr(af._ansible_collection_path_hook('fake value')) == "_AnsiblePathHookFinder(path='fake value')"
    finally:
        af._remove()



# Generated at 2022-06-21 08:13:56.939569
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    class AnsibleCollectionPkgLoader_subclass(_AnsibleCollectionPkgLoader):
        _subpackage_search_paths = None
        pass

    # _AnsibleCollectionPkgLoader subclass should set the _subpackage_search_paths attribute of 
    # class AnsibleCollectionPkgLoader_subclass, since AnsibleCollectionPkgLoader_subclass does not have 
    # default value for _subpackage_search_paths attribute
    loader = AnsibleCollectionPkgLoader_subclass('ns.coll', 'mod', None)
    assert not AnsibleCollectionPkgLoader_subclass._subpackage_search_paths

    # _AnsibleCollectionPkgLoader subclass should not set the _subpackage_search_paths attribute of 
    # class AnsibleCollectionPkgLoader_subclass, since AnsibleCollectionPkgLoader_subclass

# Generated at 2022-06-21 08:14:06.497455
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    # TODO: testing and rewriting __repr__
    pass


# Implements a generic loader for an ansible_collections path. This loader supports package redirection
# (imports pointing at a different on-disk location than the path used to get here). Each level can
# redirect, so eg:
#
# ansible_collections.myns.mycoll.plugins.module_utils.my_module_utils -> ansible_collections.myns.mycoll.plugins.modules.$redirected_module_utils.my_module_utils
#
# This is used by the collection and namespace package loaders, since they're "a" package and not "the"
# package (which are handled by separate loaders)

# Generated at 2022-06-21 08:14:15.441055
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # import json
    # import copy
    LS = C._AnsibleInternalRedirectLoader
    # with open('/Users/joey/github/ansible/lib/ansible/builtin/meta/runtime.yml', 'r') as f:
    #     json.dump(yaml.load(f), open('/Users/joey/github/ansible/lib/ansible/builtin/meta/runtime.json', 'w'), indent=4, separators=(',', ': '), sort_keys=True)
    # del sys.modules['ansible.builtin.meta.runtime.yml']

    # first use case: load a module
    collection_module = import_module('ansible.builtin.meta.runtime.yml')
    sys.modules['ansible.builtin.meta.runtime.yml']

# Generated at 2022-06-21 08:14:26.013093
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import os
    import unittest
    import tempfile
    import shutil
    import sys

    #Creating a module which will be imported as a test case of find_module method.
    content = '''
    def test_function():
        pass
    '''
    class_name = 'test_module'
    module_name = 'test_package'
    collection_name = 'test_collection'
    namespace_path = tempfile.mkdtemp()

    if PY3:
        ns_file = open(os.path.join(namespace_path, module_name, '__init__.py'), 'w')
    else:
        ns_file = open(os.path.join(namespace_path, module_name, '__init__.py'), 'wb')
    ns_file.close()

    collection_path

# Generated at 2022-06-21 08:14:55.562602
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    global _meta_yml_to_dict
    import ansible.utils.collection_loader
    _meta_yml_to_dict = ansible.utils.collection_loader._meta_yml_to_dict

    from ansible.collection.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader._data_context import DATA_CTX

    DATA_CTX.collection_package_name = 'test'
    DATA_CTX.collection_package_split = ['test']
    DATA_CTX.collection_paths = ['.']

    loader = _AnsibleCollectionPkgLoader('test', '.')
    m = loader.load_module('test')
    
    # The assertion of module m
    assert m


# Generated at 2022-06-21 08:15:04.362381
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # NOTE: this test could be expanded to test all constructors, but it is not necessary since
    #       the class is so simple.
    assert isinstance(_AnsibleCollectionFinder(), _AnsibleCollectionFinder)
    assert isinstance(_AnsibleCollectionFinder(paths=['/path']), _AnsibleCollectionFinder)
    assert isinstance(_AnsibleCollectionFinder(paths=['/path'], scan_sys_paths=False), _AnsibleCollectionFinder)
    assert isinstance(_AnsibleCollectionFinder(scan_sys_paths=False), _AnsibleCollectionFinder)


# Generated at 2022-06-21 08:15:17.012649
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible.utils.collection_loader._collection_finder import _AnsibleCollectionPkgLoaderBase

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.loader = _AnsibleCollectionPkgLoaderBase(self.tempdir)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = list(self.loader.iter_modules(prefix=''))
            self.assertEqual(result, [])


# Generated at 2022-06-21 08:15:27.041176
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import test_utils as tu
    import test_runner
    import tempfile
    arg_names = ['path_hook']
    args = tu.prepare_mock_args(arg_names, path_hook=_AnsiblePathHookFinder)
    test_ids = ['get_filename should handle a case when loader module does not exist',
                'get_filename should handle a case when loader module exists']
    with tempfile.TemporaryDirectory() as temp_path:
        os.mkdir(os.path.join(temp_path, 'community.general'))
        args['path_hook']._pathctx = temp_path
        tested_modules = [None, os.path.join(temp_path, 'community.general', 'my_module.py')]

# Generated at 2022-06-21 08:15:37.521935
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Dummy class to be able to call get_source
    class DummyLoader(_AnsibleCollectionPkgLoaderBase):
        def get_source(self, fullname):
            return "class Foo:\n    pass\n"

    # Testing with source code
    source_code = "class Foo:\n    pass\n"
    loader = DummyLoader("ansible_collections.parent.child")
    code_obj = loader.get_code("ansible_collections.parent.child")
    # Getting the code object generated by compilation of the source code
    code_obj_2 = compile(source=source_code, filename="<string>", mode='exec', flags=0, dont_inherit=True)
    # Testing on the code objects generated by get_code and by the compiler from source code

# Generated at 2022-06-21 08:15:47.072970
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    import inspect
    # Test case with parameters of type: String, String
    ap = _AnsiblePathHookFinder(collection_finder=test__AnsiblePathHookFinder___repr__.__name__, pathctx=test__AnsiblePathHookFinder___repr__.__name__)
    assert ap.__repr__() == "{0}(path='{1}')".format(ap.__class__.__name__, test__AnsiblePathHookFinder___repr__.__name__)


# Generated at 2022-06-21 08:15:51.238310
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import os
    import sys
    import types

    if '__file__' in globals():
        # Running from a file
        base_path = os.path.join(os.path.dirname(__file__), "..")
        root = os.path.abspath(base_path)
        os.environ["ANSIBLE_COLLECTIONS_PATH"] = root

        import ansible
        from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
        from ansible.utils.collection_loader import AnsibleCollectionConfig
        from ansible.utils.collection_loader import AnsiblePluginConfig

        loader = _AnsibleCollectionPkgLoader([], 'demo', 'demo')
        module = loader.load_module('ansible_collections.demo.demo')

        assert module._collection_meta

# Generated at 2022-06-21 08:16:01.914444
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import os
    import os.path
    import sys
    import ansible_collections.ansible.community.plugins.module_utils.facts.system.package_manager
    module_path = os.path.dirname(ansible_collections.ansible.community.plugins.module_utils.facts.system.package_manager.__file__)
    module_name = '.'.join(module_path.split(os.path.sep)[-2:])
    result = _AnsibleCollectionPkgLoaderBase._module_file_from_path(module_name, module_path)
    subpackage_search_paths = [result[2]] if result[2] else None
    loader = _AnsibleCollectionPkgLoaderBase(module_name, [module_path])
    loader._subpackage_search_paths = subpackage

# Generated at 2022-06-21 08:16:12.597982
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    import pkgutil
    import os
    from ansible.module_utils.common.text.converters import to_text
    test_path = os.path.join(os.path.dirname(to_text(__file__, errors='surrogate_or_strict')), 'path_hook_imp_test')
    obj = _AnsiblePathHookFinder(None, test_path)
    assert obj._filefinder_path_hook == pkgutil.FileFinder

_AnsiblePathHookFinder.test__AnsiblePathHookFinder = test__AnsiblePathHookFinder



# Generated at 2022-06-21 08:16:21.107705
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert not AnsibleCollectionRef.is_valid_fqcr("test.test.test.test")
    assert AnsibleCollectionRef.is_valid_fqcr("test.test.test")
    assert AnsibleCollectionRef.is_valid_fqcr("test.test.test", "module")
    assert not AnsibleCollectionRef.is_valid_fqcr("test.test.test", "role")
    assert AnsibleCollectionRef.is_valid_fqcr("test.test.test.yml", "playbook")
    assert not AnsibleCollectionRef.is_valid_fqcr("test.test.yml", "playbook")
    assert AnsibleCollectionRef.is_valid_fqcr("test.test.test", "vars")

# Generated at 2022-06-21 08:17:14.478967
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # _AnsibleCollectionPkgLoaderBase
    base = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace.collection')
    assert base._split_name == ['ansible_collections', 'namespace', 'collection']
    assert base._package_to_load == 'collection'
    assert base._path_to_package == ['namespace']


    expected_candidate_paths = [
        os.path.join(r, 'ansible_collections', 'namespace', 'collection')
        for r in _COLLECTION_PATHS
    ]


    assert base._candidate_paths == expected_candidate_paths

    base = _AnsibleCollectionPkgLoaderBase('ansible_collections.namespace.collection', path=_COLLECTION_PATHS[0])
   

# Generated at 2022-06-21 08:17:19.680526
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    expected_output = 'action'
    plugin_dir_name = 'action_plugins'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(plugin_dir_name) == expected_output


# Generated at 2022-06-21 08:17:30.516766
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    test_cases = [
        ('action_plugins', 'action'),
        ('cache_plugins', 'cache'),
        ('callback_plugins', 'callback'),
        ('connection_plugins', 'connection'),
        ('doc_fragments', 'doc_fragments'),
        ('filter_plugins', 'filter'),
        ('inventory_plugins', 'inventory'),
        ('lookup_plugins', 'lookup'),
        ('library', 'modules'),
        ('module_utils', 'module_utils'),
        ('modules', 'modules'),
        ('netconf_plugins', 'netconf'),
        ('shell_plugins', 'shell'),
        ('strategy_plugins', 'strategy'),
        ('terminal_plugins', 'terminal'),
        ('test', 'test'),
        ('vars_plugins', 'vars'),
    ]


# Generated at 2022-06-21 08:17:32.534368
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    """Unit test for method set_playbook_paths of class _AnsibleCollectionFinder."""
    pass



# Generated at 2022-06-21 08:17:42.113794
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Passed
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.collections.mycollection.mymodule") is True
    assert AnsibleCollectionRef.is_valid_fqcr("mycollection.mymodule") is True
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.collections.mycollection.some.subdir.mymodule") is True
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.collections.mycollection.some.subdir.mymodule.py") is True
    assert AnsibleCollectionRef.is_valid_fqcr("ansible.collections.mycollection.some.subdir.my_module.py") is True

# Generated at 2022-06-21 08:17:55.272430
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    import unittest
    import platform
    import tempfile
    import shutil
    import os

    class Test__AnsiblePathHookFinder_iter_modules(unittest.TestCase):
        def setUp(self):
            self.linux_path = '/tmp/ansible/'
            self.windows_path = 'C:\\tmp\\ansible\\'
            self.tempdir = None
            if platform.system() == 'Windows':
                self.path = self.windows_path
            else:
                self.path = self.linux_path
            self.path_hook = _AnsiblePathHookFinder(self, self.path)
            self.subdir1 = 'subdir1'
            self.subdir2 = 'subdir2'

# Generated at 2022-06-21 08:17:59.205178
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj = AnsibleCollectionRef(collection_name='ansible.test', subdirs=None, resource='testplugin',
                               ref_type='modules')
    assert obj.__repr__() == "AnsibleCollectionRef(collection='ansible.test'," \
                             " subdirs=None, resource='testplugin')"



# Generated at 2022-06-21 08:18:12.286496
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    """ Test method is_valid_collection_name of class AnsibleCollectionRef """
    import pytest

    # Test valid names
    valid_names = [
        'namespace.collection',
        'namespace.collection_33',
        'namespace_a.collection_b',
        'namespace_a.collection_b.1.2_3',

    ]
    for valid_name in valid_names:
        assert AnsibleCollectionRef.is_valid_collection_name(valid_name) is True

    # Test invalid names

# Generated at 2022-06-21 08:18:17.876423
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Test to create an AnsibleCollectionRef from components
    """
    collection_name = 'ansible.mycollection'
    resource = 'mymodule'
    ref_type = 'module'
    acr = AnsibleCollectionRef(collection_name, None, resource, ref_type)
    assert acr.fqcr == collection_name + '.' + resource
    assert acr.collection == collection_name
    assert acr.resource == resource
    assert acr.ref_type == ref_type
    assert acr.n_python_package_name == 'ansible_collections.ansible.mycollection.plugins.module'
    assert acr.n_python_collection_package_name == 'ansible_collections.ansible.mycollection'

    collection_name = 'ansible.mycollection'

# Generated at 2022-06-21 08:18:23.229301
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    def test(name):
        try:
            _AnsibleCollectionRootPkgLoader(name)
            assert False, "Test should fail"
        except ImportError:
            pass

    test("ansible_collections.foo.bar")
    test("ansible_collections.foo.bar.baz")
    _AnsibleCollectionRootPkgLoader("ansible_collections")



# Generated at 2022-06-21 08:21:30.520379
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import os, shutil
    import tempfile
    import pytest

    test_data_dir = 'test/unit/lib/ansible/module_utils/collection_loader/data'
    temp_dir = tempfile.mkdtemp()
    for f in os.listdir(test_data_dir):
        if os.path.isfile(os.path.join(test_data_dir, f)):
            shutil.copy(os.path.join(test_data_dir, f), os.path.join(temp_dir, f))
    os.chdir(temp_dir)

    # Module with source but no package
    fullname = 'test_module'

# Generated at 2022-06-21 08:21:44.470371
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # Test: IF the input is action_plugins THEN it should return action
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    # Test: IF the input is cache_plugins THEN it should return cache
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins') == 'cache'
    # Test: IF the input is callback_plugins THEN it should return callback
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    # Test: IF the input is cliconf_plugins THEN it should return cliconf
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    # Test: IF the input