

# Generated at 2022-06-21 08:13:22.324351
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import sys
    import imp
    import os
    import tempfile
    import shutil
    module_name = 'ansible_collections.test.test__AnsibleCollectionPkgLoaderBase_getsource'
    test_path = os.path.dirname(os.path.abspath(__file__))
    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, module_name)
    os.makedirs(tmp_path)
    with open(os.path.join(tmp_path, '__init__.py'), 'w') as f:
        f.write('')
    sys.path.insert(0, tmp_dir)

    def get_source(name):
        return imp.find_module(name)[0].read()

    loader = _

# Generated at 2022-06-21 08:13:23.886929
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    cl = _AnsibleCollectionPkgLoader('collections.ansible_collections.apache.tcp.apache')
    cl.load_module('collections.ansible_collections.apache.tcp.apache')


# Generated at 2022-06-21 08:13:26.516715
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # TODO: mock `is_package` and `get_source`
    # TODO: test case where __init__.py is absent, but parent dir exists
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.foo.bar', path_list=[])



# Generated at 2022-06-21 08:13:38.797000
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader._collection_finder import *

    collection_finder = _AnsibleCollectionFinder.instance
    collection_finder._install()

    path = '/tmp/ansible_collections'
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, path)

    file_finder_path_hook = _AnsiblePathHookFinder._filefinder_path_hook
    if not file_finder_path_hook:
        raise Exception('need exactly one FileFinder import hook (found{0})'.format(_filefinder_path_hook))

    # Test constructor of class _AnsiblePathHookFinder
    assert path == path_hook_finder._pathctx
    assert collection_finder == path_hook_finder._collection_

# Generated at 2022-06-21 08:13:41.416627
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns1')
    assert loader is not None, 'Didnt create loader instance'


# Generated at 2022-06-21 08:13:44.545961
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    hook = _AnsiblePathHookFinder(None, '/foo/bar')
    assert(repr(hook) == "_AnsiblePathHookFinder(path='/foo/bar')")
    return



# Generated at 2022-06-21 08:13:57.575881
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # load_module(self, fullname)
    print('====Method: load_module')

    # get_data(self, path)
    print('====Method: get_data')

    # _validate_args(self)
    print('====Method: _validate_args')

    # _synthetic_filename(self, fullname)
    print('====Method: _synthetic_filename')

    # _get_candidate_paths(self, path_list)
    print('====Method: _get_candidate_paths')

    # _validate_final(self)
    print('====Method: _validate_final')

    # get_source(self, fullname)
    print('====Method: get_source')

    # _new_or_existing_module(name, **kwargs)
    print

# Generated at 2022-06-21 08:13:59.102445
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # This is just a test of the class constructor.
    assert(True)



# Generated at 2022-06-21 08:14:09.872341
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert str(AnsibleCollectionRef('foo.bar', 'baz', 'qux', 'role')) == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'baz\', resource=\'qux\')'
    assert repr(AnsibleCollectionRef('foo.bar', 'baz', 'qux', 'role')) == 'AnsibleCollectionRef(collection=\'foo.bar\', subdirs=\'baz\', resource=\'qux\')'

    # argument ref_type is required
    with pytest.raises(ValueError):
        AnsibleCollectionRef('foo.bar', 'baz', 'qux', '')

    # argument collection_name and resource should be text

# Generated at 2022-06-21 08:14:13.992795
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    global_val1 = 'ansible'
    global_val2 = 'ansible_collections.somens.somename'
    global_val3 = 'somens'

    def create_obj():
        loader = _AnsibleCollectionPkgLoaderBase(global_val2, [ansible_path])
        return loader

    obj = create_obj()

    # 1. should raise a ValueError since get_filename can only be called with its own fullname
    with pytest.raises(ValueError, match='this loader cannot find files for {0}, only {1}'.format(global_val1, global_val2)):
        obj.get_filename(global_val1)
    # 2. should return proper filename
    str_obj2 = obj.get_filename(global_val2)
    assert str_obj2

# Generated at 2022-06-21 08:16:40.328180
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('foo')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz')
    assert AnsibleCollectionRef.is_valid_fqcr('foo.bar.baz.1')
    assert AnsibleCollectionRef.is_valid_fqcr('f.o.o.b.a.r.b.a.z')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.role', 'role')

# Generated at 2022-06-21 08:16:44.012306
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test of method get_data by passing value from method get_filename
    _AnsibleCollectionPkgLoaderBase().get_data(_AnsibleCollectionPkgLoaderBase().get_filename('test'))



# Generated at 2022-06-21 08:16:47.529838
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    ansible_path = "ansible"
    ansible_collection_path = "ansible_collection"
    test_obj = _AnsiblePathHookFinder(collection_finder=ansible_collection_path, pathctx=ansible_path)
    expected_string = "test__AnsiblePathHookFinder___repr__ of class _AnsiblePathHookFinder"
    assert repr(test_obj) == expected_string, \
        'Incorrect __repr__ string returned: actual: {0}, expected: {1}'.format(
        repr(test_obj), expected_string)



# Generated at 2022-06-21 08:16:50.918980
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    assert _AnsibleCollectionPkgLoaderBase('test', path_list=['/test1', '/test2'])._candidate_paths == ['/test1/test', '/test2/test']


# Generated at 2022-06-21 08:16:52.273165
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert isinstance(loader, _AnsibleCollectionRootPkgLoader)



# Generated at 2022-06-21 08:16:59.470153
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.rsc')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir.rsc')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.rsc')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'nscoll.rsc')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir.subdir.rsc')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir-.rsc')

# Generated at 2022-06-21 08:17:05.385337
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # Test a path which is not a package
    loader = _AnsibleCollectionPkgLoaderBase('test', ['mytest'])
    assert loader.is_package('test') == False
    # Test a path which is a package
    loader = _AnsibleCollectionPkgLoaderBase('test', ['mytest/test'])
    assert loader.is_package('test') == True

# Generated at 2022-06-21 08:17:15.124009
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    '''Test _AnsibleCollectionPkgLoaderBase.get_source.'''
    # Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
    # This is the test case provided by the developer in https://github.com/ansible/ansible/pull/28240

    # This is the test data provided by the developer in https://github.com/ansible/ansible/pull/28240

# Generated at 2022-06-21 08:17:20.945614
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    l = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar')
    assert l.is_package('ansible_collections.foo.bar') == False
    assert l.is_package('ansible_collections.foo') == True


# Generated at 2022-06-21 08:17:26.084240
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Test when the loader is used
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.my.ns.my_pkg", ["/path/to/my/ns"])
    assert loader.load_module("ansible_collections.my.ns.my_pkg") == sys.modules["ansible_collections.my.ns.my_pkg"]


# Generated at 2022-06-21 08:18:32.813168
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    import os
    from ansible_collections.my.my_namespace.plugins.module_utils.predicate import get_relative_path
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath

    try:
        import ansible.utils.collection_loader
    except ImportError:
        raise SkipTest

    test_path = os.path.normpath(f"{os.path.dirname(__file__)}/../../../lib/ansible/")
    # This is the namespace of what you are loading.
    # In order to test, you would need to have a test directory structure that matches the namespace.
    # This is the base of the namespace (not including collection name)

# Generated at 2022-06-21 08:18:40.191857
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    tpl = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.foo.bar', path_list=[])
    assert tpl._fullname == 'ansible_collections.ns.foo.bar'
    assert tpl._redirect_module is None
    assert tpl._split_name == ['ansible_collections', 'ns', 'foo', 'bar']
    assert tpl._rpart_name == ('ansible_collections.ns.foo', 'bar')
    assert tpl._parent_package_name == 'ansible_collections.ns.foo'
    assert tpl._package_to_load == 'bar'
    assert tpl._candidate_paths is None
    assert tpl._subpackage_search_paths is None
    assert tpl._source_code_path is None
    assert t

# Generated at 2022-06-21 08:18:49.490349
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    # Testing the constructor with valid fullname and path_list
    _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['path0', 'path1'])

    # Testing the constructor with invalid fullname
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collection')

    # Testing the constructor with invalid path_list
    with pytest.raises(ImportError):
        _AnsibleCollectionRootPkgLoader('ansible_collections', path_list=['path0'])


# Generated at 2022-06-21 08:18:55.477697
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    import ansible.utils.collection_loader
    loader = ansible.utils.collection_loader._AnsibleCollectionPkgLoader(
        ['ansible', 'collections', 'foo.bar'],
        collection_paths=['/tmp/foo', '/tmp/bar/', '/tmp/baz']
    )

    assert loader._package_to_load == 'foo.bar'
    assert loader._candidate_paths == ['/tmp/foo/foo.bar', '/tmp/bar/foo.bar', '/tmp/baz/foo.bar']
    assert loader._split_name == ['ansible', 'collections', 'foo.bar']
    assert loader._fullname == 'ansible.collections.foo.bar'
    assert loader._parent_package_name == 'ansible.collections.foo'


# Generated at 2022-06-21 08:19:04.127567
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
	test_obj = _AnsibleCollectionPkgLoaderBase('test_fullname')
	assert test_obj.get_code('test_fullname') == None
	assert test_obj._fullname == 'test_fullname'
	assert test_obj._package_to_load == 'test_fullname'
	assert test_obj._parent_package_name == ''
	assert test_obj._redirect_module == None
	assert test_obj._split_name == ['test_fullname']
	assert test_obj._rpart_name == ('', '', 'test_fullname')



# Generated at 2022-06-21 08:19:08.529491
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # setup test
    acr = AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'ref_type')

    # execute method under test
    result = acr.__repr__()

    # verify results
    assert result == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'subdirs\', resource=\'resource\')'



# Generated at 2022-06-21 08:19:18.427073
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    # test with good collection name
    acr = AnsibleCollectionRef('example.dummy', '', '', 'modules')
    assert acr.is_valid_collection_name('example.dummy') == True
    # test with bad collection name (1)
    acr = AnsibleCollectionRef('example dummy', '', '', 'modules')
    assert acr.is_valid_collection_name('example dummy') == False
    # test with bad collection name (2)
    acr = AnsibleCollectionRef('example.dummy.dummy', '', '', 'modules')
    assert acr.is_valid_collection_name('example.dummy.dummy') == False


# Generated at 2022-06-21 08:19:27.608157
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    #assert False, 'Test Not Implemented'
    loader = _AnsibleCollectionLoader(name='ansible_collections.194893.test', path=[], ns_package=True)
    loader = _AnsibleCollectionLoader(name='ansible_collections.194893.test.factory', path=[], ns_package=False)
    loader = _AnsibleCollectionLoader(name='ansible_collections.194893.test.factory.dir1', path=[], ns_package=False)
    loader = _AnsibleCollectionLoader(name='ansible_collections.194893.test.factory.dir1.dir2', path=[], ns_package=False)


from ansible.module_utils.six.moves import reload_module

# Generated at 2022-06-21 08:19:31.250075
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    class MockAnsibleCollectionFinder:

        def find_module(self, fullname, path=None):
            return "ansible_collections"

    assert _AnsiblePathHookFinder(MockAnsibleCollectionFinder(), "path").find_module("ansible_collections")
    assert _AnsiblePathHookFinder(MockAnsibleCollectionFinder(), "path").find_module("ansible") is None


# Base class for all of our specific collection root loaders

# Generated at 2022-06-21 08:19:41.965919
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # test four things:
    #
    # 1. does it fail when it should?
    # 2. does it pass when it should?
    # 3. does it not care about module_utils & lookup
    # 4. does it understand playbooks
    #
    # NOTE: testing the actual error message is handled with the normal AnsibleCollectionRef tests

    # 1.
    # failures

    # invalid FQCRs
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'modules')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.resource')

# Generated at 2022-06-21 08:20:06.586853
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fullname = 'ansible.builtin.FileModule'
    # path_list = []
    # instance = _AnsibleInternalRedirectLoader(fullname, path_list)
    # assert instance.load_module(fullname) is not None


# _BuiltinAnsibleModulePathHookProxy detects `ansible.builtin` as a special case and calls the corresponding module
# loader directly instead of falling back to the normal import mechanism, bypassing the normal import mechanisms and
# allowing us to inject the synthetic ansible.builtin collection into sys.modules.

# Generated at 2022-06-21 08:20:13.646398
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    repr_str = _AnsiblePathHookFinder.__repr__
    assert repr_str(repr_str) == '<unbound method _AnsiblePathHookFinder.__repr__>'

    finder = _AnsiblePathHookFinder(None, '/path/example')
    assert finder.__repr__() == "_AnsiblePathHookFinder(path='/path/example')"



# Generated at 2022-06-21 08:20:21.478459
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Make sure that we can't initialize loader without path
    try:
        _AnsibleCollectionPkgLoader('test', 'test')
        raise AssertionError('_AnsibleCollectionPkgLoader() should fail __init__ for path being None')
    except ValueError:
        pass
    try:
        _AnsibleCollectionPkgLoader('test', '')
        raise AssertionError('_AnsibleCollectionPkgLoader() should fail __init__ for path being empty string')
    except ValueError:
        pass

    # Make sure that we can't initialize loader without package to load

# Generated at 2022-06-21 08:20:32.968952
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    def create_test(legacy_plugin_dir_name, return_value):
        def test():
            assert_equal(AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name), return_value)
        return test

    class_atr = AnsibleCollectionRef(collection_name="test.test2",
                                     subdirs=None,
                                     resource="testresource",
                                     ref_type="test_type")

    yield create_test, "action_plugins", "action"
    yield create_test, "library", "modules"
    yield create_test, "callback_plugins", "callback"
    yield create_test, "vars_plugins", "vars"



# Generated at 2022-06-21 08:20:42.777228
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    test_dir = os.path.dirname(__file__)
    # check if the function iter_modules works well
    ansible_path_hook_finder = _AnsiblePathHookFinder(None, test_dir)
    result = ansible_path_hook_finder.iter_modules(None)
    assert result == []

    # check if iter_modules return a list contains the module
    file_name = 'ansible_test.py'
    module = ('ansible_test', False, '.')
    ansible_test = os.path.join(test_dir, '_ansible_test__AnsiblePathHookFinder_iter_modules', file_name)
    # create a new file
    os.makedirs(os.path.dirname(ansible_test))

# Generated at 2022-06-21 08:20:55.201332
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    parse_fqcr = AnsibleCollectionRef.try_parse_fqcr
    assert parse_fqcr(u"a.b.c", None) is None
    assert parse_fqcr(u"a.b.c", "") is None
    assert parse_fqcr(u"a.b.c", u"") is None
    assert parse_fqcr(u"a.b.c", "foo") is None
    assert parse_fqcr(u"a.b.c", u"foo") is None
    assert parse_fqcr(u"a.b.c", "foo") is None
    assert parse_fqcr(u"a.b.c", None) is None
    assert parse_fqcr(u"a.b.c", None) is None
    assert parse_fq

# Generated at 2022-06-21 08:21:05.978937
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    assert _AnsibleCollectionFinder(paths=['/my/path'], scan_sys_paths=True)._n_configured_paths == ['/my/path']
    assert _AnsibleCollectionFinder(paths=['/my/path'], scan_sys_paths=False)._n_configured_paths == ['/my/path']

    assert _AnsibleCollectionFinder()._n_configured_paths == sys.path
    _AnsibleCollectionFinder._remove()
    assert _AnsibleCollectionConfig._collection_finder is None

    finder = _AnsibleCollectionFinder(paths=['/my/path'], scan_sys_paths=True)
    finder._install()
    assert _AnsibleCollectionConfig._collection_finder == finder

    assert finder

# Generated at 2022-06-21 08:21:07.207629
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin.action', ('/tmp',))
    assert loader._redirect == 'ansible.plugins.action'


# Generated at 2022-06-21 08:21:09.992123
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    inst = _AnsibleCollectionPkgLoaderBase(None)
    repr_ = repr(inst)
    assert repr_ == "_AnsibleCollectionPkgLoaderBase(path=None)"



# Generated at 2022-06-21 08:21:15.906017
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder(
        paths=[os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'collection_loader', 'data_collection_loader')],
    )
    collection_finder._install()
    assert 'ansible_collections' in sys.modules
    assert 'ansible_collections.acme' in sys.modules
    assert 'ansible_collections.acme.acme_annoying_pkg' in sys.modules
    assert 'ansible_collections.acme.acme_annoying_pkg.plugins.module_utils' in sys.modules
    assert 'ansible_collections.acme.acme_annoying_pkg.plugins.module_utils.module_utils_module' in sys.modules

# Generated at 2022-06-21 08:21:42.611398
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name='geng.filter'
    subdirs='.subj'
    resource='sub.sub'
    ref_type='filter'
    ansible_collection_ref=AnsibleCollectionRef(collection_name,subdirs,resource,ref_type)
    print(ansible_collection_ref)

# Generated at 2022-06-21 08:21:46.005742
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder is not None

# TODO: implement for py2 for pkgutil.get_data
# Patches pkgutil to get the data from a module only if it's been loaded, otherwise
# falls back to the ansible_collections loader to get the data

