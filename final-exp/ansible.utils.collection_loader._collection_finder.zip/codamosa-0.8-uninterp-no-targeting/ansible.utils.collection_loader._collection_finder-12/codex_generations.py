

# Generated at 2022-06-21 08:12:37.595880
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import sys, os
    import tempfile

# Generated at 2022-06-21 08:12:46.064181
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    with pytest.raises(ValueError):
        ansible_collections_loader = _AnsibleCollectionPkgLoader(module_name="", module_path='')

    # Test for non existing path
    module_path = '/tmp'
    module_name = 'foo'
    ansible_collections_loader = _AnsibleCollectionPkgLoader(module_name=module_name, module_path=module_path)
    assert ansible_collections_loader._parent_package_name == 'foo'
    assert ansible_collections_loader._package_to_load == 'foo'


# Generated at 2022-06-21 08:12:54.150492
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # Fails with ValidationError exception
    # validation fails with None type
    try:
        AnsibleCollectionRef.is_valid_fqcr(None)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    # validation fails with non-string type
    try:
        AnsibleCollectionRef.is_valid_fqcr(0)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    # validation fails with empty string
    try:
        AnsibleCollectionRef.is_valid_fqcr('')
    except ValueError:
        pass
    else:
        assert False, 'ExpectedValueError'

    # validation fails with non-fully qualified string

# Generated at 2022-06-21 08:13:04.819809
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    assert_raises(ImportError, _AnsibleInternalRedirectLoader, 'ansible.builtin.foo', ['/some/path'])
    assert_raises(ImportError, _AnsibleInternalRedirectLoader, 'something.foo', ['/some/path'])
test__AnsibleInternalRedirectLoader.unittest = ['facts']


Ansible_Loader = collections.namedtuple('Ansible_Loader', ['fullname', 'loader'])

# NOTE: this is intentionally left as a list, since we're not allowing nested collections with the same name
# to exist in the future
_loaders = []



# Generated at 2022-06-21 08:13:16.754977
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # pylint: disable=protected-access
    # chain our hook to a FileFinder hook to delegate to
    file_finder_hook = _AnsiblePathHookFinder._get_filefinder_path_hook()
    sys.path_hooks.insert(0, _AnsiblePathHookFinder)
    sys.path_hooks.insert(1, file_finder_hook)
    pathctx = '/some/path'
    af = _AnsiblePathHookFinder(None, pathctx)
    assert af._pathctx == pathctx, '_AnsiblePathHookFinder: initialization of _pathctx failed'
    assert af._collection_finder is None, '_AnsiblePathHookFinder: initialization of _collection_finder failed'

    if PY3:
        assert _AnsiblePathH

# Generated at 2022-06-21 08:13:19.777593
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    paths = ['ansible_collections']
    collection_finder = _AnsibleCollectionFinder(paths)
    assert isinstance(collection_finder._n_configured_paths, list)



# Generated at 2022-06-21 08:13:31.776995
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader._collection_finder import AnsibleCollectionFinder

    loader = AnsibleCollectionLoader(None, None, None, None)
    finder = AnsibleCollectionFinder(loader)
    test_path = ['/path/to/python/namespace/package/test']
    test_fullname = 'test_fullname'

    acnspl = _AnsibleCollectionNSPkgLoader(test_fullname, test_path)
    assert acnspl._fullname == test_fullname
    assert acnspl._redirect_module is None
    assert acnspl._split_name == test_fullname.split('.')
    assert acnspl._rpart_name == test_fullname.rpartition('.')
    assert ac

# Generated at 2022-06-21 08:13:40.200437
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping','module')._fqcr == u'ansible.builtin.ping'
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping','module') == AnsibleCollectionRef('ansible.builtin','','ping','module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping.py', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping.j2', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.builtin.ping.yml', 'module')

# Generated at 2022-06-21 08:13:48.760497
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder(paths=C.COLLECTIONS_PATHS)
    collection_finder._install()
    paths = collection_finder._n_collection_paths
    path_hook = collection_finder._ansible_collection_path_hook(paths[0])
    module = path_hook.find_module(fullname='ansible.module_utils.parsing.convert_bool')
    assert module
    module = path_hook.find_module(fullname='ansible_collections.somespace.somecollection.plugins.modules.ls')
    assert module
    module = path_hook.find_module(fullname='ansible_collections.somespace.somecollection.plugins.module_utils.misc.misc_utils')
    assert module
    module = path_hook.find_

# Generated at 2022-06-21 08:13:56.096056
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('', [])
    assert not loader.is_package('ansible_collections.my_ns.my_coll')

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_ns', ['/foo/bar'])
    assert loader.is_package('ansible_collections.my_ns')


# Generated at 2022-06-21 08:14:25.560830
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    capi = _AnsibleCollectionFinder()
    capi.set_playbook_paths(['test_path','test_path','test_path','test_path'])
    assert len(capi._n_playbook_paths) == 1


# Generated at 2022-06-21 08:14:29.975527
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():

    def _make_file_tree(paths):
        base = tempfile.mkdtemp()
        for path in paths:
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(base + dirname)
            open(base + path, 'w').close()
        return base

    # empty dir
    base = tempfile.mkdtemp()
    assert list(_AnsibleCollectionPkgLoaderBase('').iter_modules('')) == []

    # no packages
    paths = ['__init__.py', 'test1.py', 'test2.py']
    base = _make_file_tree(paths)
    assert list(_AnsibleCollectionPkgLoaderBase('').iter_modules('')) == []

    # one package

# Generated at 2022-06-21 08:14:40.593556
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    P = _AnsibleCollectionPkgLoader(package_name='namespace', package_to_load='collection', candidate_paths=['path1', 'path2'])
    assert type(P) == _AnsibleCollectionPkgLoader
    assert P._fullname == 'namespace.collection'
    assert P._split_name == ['namespace', 'collection']
    assert P._package_to_load == 'collection'
    assert P._candidate_paths == ['path1', 'path2']
    assert P._parent_package_name == 'namespace'
    assert P._subpackage_search_paths == ['path1', 'path2']
    assert P._redirect_module == None
    assert P._compiled_code == None
    assert P._decoded_source == None
    assert P._source_code_path

# Generated at 2022-06-21 08:14:53.833562
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.file import ensure_dir
    from ansible.module_utils.parsing.convert_bool import boolean

    # save off the existing meta_path and path hooks so we can restore them later
    # TODO: should we do this?
    original_meta_path = sys.meta_path
    original_path_hooks = sys.path_hooks
    original_path_importer_cache = sys.path_importer_cache.copy()


# Generated at 2022-06-21 08:14:56.725074
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():  # pylint: disable=invalid-name
    # TODO: this will require some mocking of the collection config object to properly test
    pass

# Generated at 2022-06-21 08:15:06.719948
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    import pytest
    failed = AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource.type", "action")
    assert failed is None
    failed2 = AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource.type", "dummy")
    assert failed2 is None
    failed3 = AnsibleCollectionRef.try_parse_fqcr("namespace.collection.resource.type.module", "action")
    assert failed3 is None
    namens = "namespace.collection"
    assert (isinstance(AnsibleCollectionRef.try_parse_fqcr(namens, "dummy"), AnsibleCollectionRef))
    namensres = "namespace.collection.resource"

# Generated at 2022-06-21 08:15:13.330026
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    try:
        cls = _get_collection_metadata('ansible.builtin')
    except ValueError:
        cls = _get_collection_metadata('ansible_collections.ansible.builtin')
    r = cls.__repr__()
    assert r == 'CollectionRef(namespace=ansible, name=builtin)', 'Actual: {}'.format(r)



# Generated at 2022-06-21 08:15:24.805566
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import collections.abc
    from ansible.parsing.loader import _AnsibleCollectionPkgLoaderBase, _AnsiblePathHookFinder

    _test_dirs = [to_bytes(os.path.dirname(os.path.abspath(__file__)))]
    _finder = _AnsiblePathHookFinder(_test_dirs[0], None)
    _loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections', path_list=_test_dirs)

    import ansible_collections
    module = _loader.load_module('ansible_collections')
    assert module == ansible_collections

    import ansible_collections.foo.bar.stub

# Generated at 2022-06-21 08:15:35.933873
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.a') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.__new__') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.abc') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.abc1') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns._abc2') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.abc_') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.abc__') == True
    assert AnsibleCollectionRef.is_valid_collection_name('ns.__') == True

# Generated at 2022-06-21 08:15:49.311281
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-21 08:16:38.404628
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    # simple test for a single source

    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.some.module')

    source_code_path1 = '/path/to/module.py'

    def _get_source(path):
        return "some_source"

    loader.get_data = _get_source
    loader._source_code_path = source_code_path1
    loader.get_source(loader._fullname)
    assert loader._decoded_source == "some_source"

    # test a second source file

    source_code_path2 = '/path/to/module2.py'
    loader._source_code_path = source_code_path2
    loader.get_source(loader._fullname)
    assert loader._decoded_source == "some_source"


# Unit

# Generated at 2022-06-21 08:16:41.239065
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    c = _AnsibleCollectionPkgLoaderBase('foo')
    with pytest.raises(ValueError):
        c.get_source('foobar')

test__AnsibleCollectionPkgLoaderBase_get_source()

# Generated at 2022-06-21 08:16:46.817898
# Unit test for constructor of class _AnsibleCollectionRootPkgLoader
def test__AnsibleCollectionRootPkgLoader():
    pkg_path = 'ansible_collections'
    loader = _AnsibleCollectionRootPkgLoader('ansible_collections')
    assert loader._fullname == 'ansible_collections'
    assert loader._redirect_module is None
    assert loader._split_name[0] == 'ansible_collections'
    assert loader._rpart_name[0] == ''
    assert loader._rpart_name[2] == 'ansible_collections'
    assert loader._parent_package_name == ''
    assert loader._package_to_load == 'ansible_collections'
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._candidate_paths == [pkg_path]
    assert loader._subpackage

# Generated at 2022-06-21 08:16:48.606012
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    finder = _AnsiblePathHookFinder(None, '/path/to/ansible/collections')
    assert finder._get_filefinder_path_hook() is not None



# Generated at 2022-06-21 08:16:50.008357
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    collection_finder = _AnsibleCollectionFinder()
    _AnsiblePathHookFinder(collection_finder, '/foo')
# Testing ends.


# Generated at 2022-06-21 08:16:52.144764
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    assert _AnsibleCollectionPkgLoaderBase().is_package('ansible_collections.some_ns.some_collection') is False

# Generated at 2022-06-21 08:16:59.402239
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Test for module with valid source code
    _system_path = [os.path.join(os.path.dirname(__file__), 'fixtures/collection-plugin/ansible_collections/a/b/c')]
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.a.b.c', _system_path)
    source = loader.get_source('ansible_collections.a.b.c')
    assert source == '# source code for a/b/c'

    # Test for module with no source code
    _system_path = [os.path.join(os.path.dirname(__file__), 'fixtures/collection-plugin/ansible_collections/a/b')]

# Generated at 2022-06-21 08:17:06.136075
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == u'modules'

    # invalid plugin directory
    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('badplugin_dir_name')


# Generated at 2022-06-21 08:17:15.518602
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # test valid collection ref constructor
    fqcr = AnsibleCollectionRef(collection_name='ns.coll',
                                subdirs=u'',
                                resource=u'module',
                                ref_type=u'module')
    assert fqcr is not None

    # test invalid collection ref constructor
    with pytest.raises(ValueError):
        AnsibleCollectionRef(collection_name='ns.coll.invalid',
                             subdirs=u'',
                             resource=u'module',
                             ref_type=u'module')

    # test invalid collection ref constructor

# Generated at 2022-06-21 08:17:21.235375
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # given
    legacy_plugin_dir_name = 'action_plugins'

    # when
    actual_plugin_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name)

    # then
    assert actual_plugin_type == 'action'

# Generated at 2022-06-21 08:17:59.854731
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    with pytest.raises(ValueError):
        x = _AnsibleCollectionPkgLoaderBase(Mock())
        x.get_source(Mock())
    with pytest.raises(ValueError):
        x = _AnsibleCollectionPkgLoaderBase('test', 'test')
        x.get_source('test')
    with pytest.raises(ValueError):
        x = _AnsibleCollectionPkgLoaderBase('test.test', 'test')
        x.get_source('test')
    x = _AnsibleCollectionPkgLoaderBase('test.test', 'test')
    assert x.get_source('test.test') is None


# Generated at 2022-06-21 08:18:01.024565
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import collections
    pass


# Generated at 2022-06-21 08:18:09.596833
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    path = os.path.dirname(__file__)
    collection_path = os.path.join(os.path.dirname(path), 'ansible_collections')
    path_finder = _AnsiblePathHookFinder(collection_finder=False, pathctx=collection_path)
    path_finder_iter_modules = path_finder.iter_modules(prefix=False)
    assert next(path_finder_iter_modules)[1] == 'ansible'


# Generated at 2022-06-21 08:18:13.221887
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'

# Generated at 2022-06-21 08:18:15.038059
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder(object(), '/path/')


# Generated at 2022-06-21 08:18:19.818391
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ar = AnsibleCollectionRef('test.collection', 'subdir.subdir2', 'name', 'type')
    assert ar.collection == u'test.collection'
    assert ar.subdirs == u'subdir.subdir2'
    assert ar.resource == u'name'
    assert ar.ref_type == u'type'


# Generated at 2022-06-21 08:18:28.334020
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    test_fullnames = [
        'ansible_collections.ns1.coll1.empty_root_pkg',
        'ansible_collections.ns1.coll1.empty_interior_pkg.subpkg',
        'ansible_collections.ns1.coll1.pkg_with_init.subpkg',
        'ansible_collections.ns1.coll1.pkg_with_init'
    ]
    for fullname in test_fullnames:
        _AnsibleCollectionPkgLoaderBase(fullname)
    # test that incorrect argument raises exception
    with pytest.raises(ImportError):
        _AnsibleCollectionPkgLoaderBase('ansible_collections.not_a_ns')


# Generated at 2022-06-21 08:18:36.497252
# Unit test for method iter_modules of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_iter_modules():
    from shutil import rmtree
    import tempfile
    import os
    import sys
    from ansible_collections.foo.bar.plugins.collection_loader_test import example_module_1, example_module_2

    loader = sys.meta_path[0]

    path = tempfile.mkdtemp()

# Generated at 2022-06-21 08:18:43.369253
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.blah')
    assert loader
    assert loader._fullname
    assert loader._validate_args() is None
    assert loader._candidate_paths is None
    assert loader._subpackage_search_paths is None
    assert loader._validate_final() is None

test__AnsibleCollectionPkgLoaderBase()



# Generated at 2022-06-21 08:18:54.302448
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    from ansible.utils.vars import combine_vars
    loader = _AnsibleInternalRedirectLoader('a.b.c', ['path_list'])
    from ansible.utils.module_docs import get_docstring
    from ansible.utils.module_docs import get_docstring
    assert get_docstring('', '', '') == ''
    assert get_docstring('', '', None) == ''
    assert get_docstring('', '', 'foobar') == 'foobar'
    assert get_docstring('', '', ['a','b']) == 'a\nb'
    assert get_docstring('', '', None) == ''
    assert get_docstring('', '', 'foo') == 'foo'
   

# Generated at 2022-06-21 08:19:33.784387
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    test_path_list = ['temp/', 'temp1/']
    subpackage_paths = ['temp/test_coll/test_ns/test_subpkg/', 'temp1/test_subpkg1/']
    # test 1
    cls = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_coll.test_ns.test_subpkg', test_path_list)
    assert cls._fullname == 'ansible_collections.test_coll.test_ns.test_subpkg'
    assert cls._rpart_name[0] == 'ansible_collections.test_coll.test_ns'
    assert cls._rpart_name[2] == 'test_subpkg'

# Generated at 2022-06-21 08:19:43.233670
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    # Example 1
    src = _AnsibleCollectionFinder()
    src._n_playbook_paths = ['/tmp/collections1']
    src.set_playbook_paths(['/tmp/collections2'])
    assert src._n_playbook_paths == ['/tmp/collections2']

    # Example 2
    src = _AnsibleCollectionFinder()
    src._n_playbook_paths = ['/tmp/collections1']
    src.set_playbook_paths(['/tmp/collections1', '/tmp/collections2'])
    assert src._n_playbook_paths == ['/tmp/collections2', '/tmp/collections1']

test__AnsibleCollectionFinder_set_playbook_paths()


# Generated at 2022-06-21 08:19:52.332938
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    r = AnsibleCollectionRef.from_fqcr('ns.coll.rolename', 'role')
    assert r.fqcr == 'ns.coll.rolename'
    assert r.collection == 'ns.coll'
    assert r.resource == 'rolename'
    assert r.ref_type == 'role'
    assert r.subdirs == ''

    r = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.rolename', 'role')
    assert r.fqcr == 'ns.coll.subdir1.rolename'
    assert r.collection == 'ns.coll'
    assert r.resource == 'rolename'
    assert r.ref_type == 'role'
    assert r.subdirs == 'subdir1'

    # skip bad namespace

# Generated at 2022-06-21 08:20:04.681762
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # NOTE: This test is here to assert the behavior of the method iter_modules() of class _AnsibleCollectionPkgLoaderBase
    # It is not an exhaustive test for the loader.

    path_hook_finder = _AnsiblePathHookFinder(
        '/Users/username/my/ansible/test/test_collections',
        AnsibleCollectionConfig(None)._get_collection_path_infos())

    loader_finder = _AnsibleCollectionFinder(path_hook_finder=path_hook_finder)
    loader = loader_finder.find_module('ansible_collections.testns.testcoll')
    assert loader is not None
    assert 'ansible_collections.testns.testcoll' == loader._fullname

# Generated at 2022-06-21 08:20:16.867197
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-21 08:20:23.168582
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    mod = import_module('ansible.builtin')
    sys.modules['ansible.builtin'] = mod
    try:
        module_to_test = _AnsibleInternalRedirectLoader('ansible.builtin.mytest', [])
        module_to_test.load_module('ansible.builtin.mytest')
    except:
        # if any exception was raised, don't consider that the test failed
        pass
    finally:
        # Clean up the module otherwise it could impact other tests
        sys.modules.pop('ansible.builtin.mytest')


# We need a custom path_hook to control exactly where we look for collections and core modules,
# and also to work around Python's implicit package support. The default path_hook behavior imports
# the first file it finds on sys.path as a module, rather than following the normal

# Generated at 2022-06-21 08:20:26.268145
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # Call method load_module of class _AnsibleCollectionPkgLoaderBase
    # TODO write this test
    pass

# Generated at 2022-06-21 08:20:37.612471
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_path = os.path.join(os.path.dirname(__file__), 'data', 'collection')
    loader = _AnsibleCollectionPkgLoader('ansible_collections.test.test_collection',
            candidate_paths = [collection_path])
    module = loader.load_module('ansible_collections.test.test_collection')
    assert module.__file__ == os.path.join(collection_path, '__init__.py')
    assert module.__path__ == [collection_path]
    assert module.__name__ == 'ansible_collections.test.test_collection'
    assert module.__loader__ == loader
    assert module.__package__ == 'ansible_collections.test.test_collection'
    assert module._collection_meta == {'plugin_routing': {}}

# Generated at 2022-06-21 08:20:45.275720
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    """ Iterating through modules under a package should provide them in an iterable """
    loader = _AnsibleCollectionPkgLoaderBase(
        'ansible_collections.test1.test2',
        path_list=['/foo/path'])
    loader._subpackage_search_paths = ['/foo/path/ansible_collections/test1/test2']
    modules = []
    for module in loader.iter_modules(''):
        modules.append(module)
    assert len(modules) == 2
    assert modules[0][0] == 'foo'
    assert modules[0][1] == '/foo/path/ansible_collections/test1/test2/foo.py'
    assert modules[0][2] == 'source'



# Generated at 2022-06-21 08:20:50.370705
# Unit test for method __repr__ of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder___repr__():
    testloader = _AnsiblePathHookFinder(object, '/some/path')
    assert testloader.__repr__() == "{0}(path='/some/path')".format(testloader.__class__.__name__)


# Generated at 2022-06-21 08:21:36.290781
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible_collections.ansible.community.plugins.loader import _AnsibleCollectionPkgLoaderBase
    def _mock_get_data():
        data = to_bytes(b"Hello World")
        return data

    def _mock_get_data1():
        data = to_bytes(b"abcdefg")
        return data

    def _mock_get_data2():
        data = to_bytes(b"1234567")
        return data

    def _mock_get_data3():
        data = to_bytes(b"7890")
        return data


# Generated at 2022-06-21 08:21:40.561972
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader

    _loader = _AnsibleInternalRedirectLoader(fullname='ansible.module_utils.b', path_list=[])

    assert _loader is not None


# Generated at 2022-06-21 08:21:47.545078
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    loader = _AnsibleCollectionPkgLoader(ns_name='my.collection', pkg_name='my_package', parent_loader=None)
    assert loader._namespace_name == 'my.collection'
    assert loader._package_name == 'my_package'
    assert loader._parent_package_name == 'my.collection'
    assert loader._package_to_load == 'my_package'
    assert loader._fullname == 'my.collection.my_package'
    assert loader._split_name == ['my', 'collection', 'my_package']
    assert loader._candidate_paths == ['/home/wilk/.ansible/collections/ansible_collections/my/collection/my_package']
