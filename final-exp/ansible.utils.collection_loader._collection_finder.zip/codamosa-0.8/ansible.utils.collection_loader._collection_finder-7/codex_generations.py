

# Generated at 2022-06-11 17:35:28.407215
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # test for method get_code of class _AnsibleCollectionPkgLoaderBase
    # mockup the class self
    self = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.somens.somecoll', path_list=[])
    self._source_code_path = '<some_file_name>'
    self._decoded_source = 'some_source'
    # mockup the code object
    self._compiled_code = 'some_code_object'

    ansible_collections.somens.somecoll.__loader__ = self
    # test for get_code
    assert self.get_code(fullname='ansible_collections.somens.somecoll') == 'some_code_object'
    # test for cached get_code
    # 2nd time get_code,

# Generated at 2022-06-11 17:35:31.283808
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    file_name = _AnsibleCollectionPkgLoaderBase.get_filename('a')
    print(file_name)
    

# Generated at 2022-06-11 17:35:40.243674
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    Test = collections.namedtuple('Test', 'args ansible_builtin_meta expected')

# Generated at 2022-06-11 17:35:51.814142
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import unittest
    import os
    import os.path

    import ansible_collections.somens.somecoll.plugins.modules
    import ansible_collections.somens.somecoll.plugins.module_utils

    class Test_AnsibleCollectionFinder(unittest.TestCase):
        def assertModule(self, fullname, module_class, module_paths):
            finder = _AnsibleCollectionFinder([os.path.dirname(ansible_collections.somens.somecoll.plugins.modules.__file__)])
            loader = finder.find_module(fullname)

            self.assertIsInstance(loader, module_class)
            self.assertEqual(loader.path, module_paths)


# Generated at 2022-06-11 17:35:59.913808
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # role dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('roles') == 'role'
    # action dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    # connection dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    # lookups dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    # library dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    # cache dir
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache_plugins')

# Generated at 2022-06-11 17:36:01.452215
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # _AnsibleCollectionPkgLoaderBase.is_package()
    # TODO: implement your test here
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-11 17:36:09.875333
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    print('In test__AnsibleCollectionPkgLoaderBase_get_source')
    class subclass(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            pass
        def _get_subpackage_search_paths(self, candidate_paths):
            pass
        def _validate_final(self):
            pass
    obj = subclass('')
    with pytest.raises(ValueError):
        obj.get_source('')


# Generated at 2022-06-11 17:36:17.879663
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.notvalid')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.notvalid.resource')



# Generated at 2022-06-11 17:36:30.078835
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    assert _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase('ansible_collections.n0s.collection1').get_filename('ansible_collections.n0s.collection1') == '/path1/n0s/collection1'
    assert _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase('ansible_collections.n0s.collection1').get_filename('ansible_collections.n0s.collection2') == '/path2/n0s/collection2'
    assert _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase('ansible_collections.n0s.collection1').get_filename('ansible_collections.n0s.collection3') == '/path3/n0s/collection3'



# Generated at 2022-06-11 17:36:35.743914
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    mock_fullname = AnonymousMock()
    mock_self = AnonymousMock(get_filename=lambda fullname: '<ansible_synthetic_collection_package>')
    fun_retval = _AnsibleCollectionPkgLoaderBase.get_code(mock_self, mock_fullname)
    assert fun_retval is mock_self._compiled_code


# Generated at 2022-06-11 17:37:23.657878
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    finder = MockFinder()
    loader = _AnsibleCollectionPkgLoaderBase('ansible.collections.foo.bar', '/path/to/something')
    loader.is_package = Mock(return_value=True)
    loader.get_code = Mock()

    loader.load_module('ansible.collections.foo.bar')

    loader.is_package.assert_called_once_with('ansible.collections.foo.bar')
    assert loader.get_code.called, loader.get_code.call_args_list



# Generated at 2022-06-11 17:37:28.247146
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import ansible_collections
    ansible_collections._initialize_collections_loader()
    path = [os.path.join(os.path.dirname(ansible_collections.__file__), 'somens')]
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.somens", path)
    assert loader.iter_modules("") is not None
    assert isinstance(loader.iter_modules(""), list) is True

# Generated at 2022-06-11 17:37:32.964846
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # import
    # import
    fullname = 'any_fullname'
    path_list = ['path_list_1', 'path_list_2']
    _AnsibleInternalRedirectLoader_object = _AnsibleInternalRedirectLoader(fullname, path_list)
    # execute
    try:
        _AnsibleInternalRedirectLoader_object.load_module(fullname)
    except:
        pass


# Generated at 2022-06-11 17:37:43.615108
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    finder = _AnsibleCollectionFinder()
    # Case 1:
    # Case 1.1: fullname is non-ansible toplevel package
    assert finder.find_module('package', path='/x/x/x/x/') is None

    # Case 1.2: fullname is ansible package
    assert finder.find_module('ansible', path=None) is not None

    # Case 2: fullname is ansible_collections package
    assert finder.find_module('ansible_collections', path=None) is not None

    # Case 3: fullname is a subpackage of ansible
    assert finder.find_module('ansible.module_utils.basic') is not None

# Generated at 2022-06-11 17:37:49.356084
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref = AnsibleCollectionRef(collection_name=u'a.b', subdirs=u'subdir1.subdir2', resource=u'abc', ref_type=u'module')
    assert ansible_collection_ref.__repr__() == "AnsibleCollectionRef(collection='a.b', subdirs='subdir1.subdir2', resource='abc')"


# Generated at 2022-06-11 17:37:55.866715
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # _AnsibleInternalRedirectLoader only answers for intercepted Ansible Python modules.
    # test1: no such name
    loader = _AnsibleInternalRedirectLoader('ansible.no_such_module', None)
    with pytest.raises(ImportError) as e:
        loader.load_module('ansible.no_such_module')
    assert to_native(e.value) == 'not redirected, go ask path_hook'

# Generated at 2022-06-11 17:37:56.885761
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    assert True, 'Test stub not implemented'


# Generated at 2022-06-11 17:38:05.336259
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import unittest
    import unittest.mock
    import ansible.utils.module_docs_fragments

    # Populate the sys.modules with module under test
    mock_modules = unittest.mock.MagicMock()
    mock_modules.__contains__.return_value = False
    mock_modules.__getitem__.side_effect = KeyError
    sys.modules = mock_modules

    # instance to test
    mock_parent_package_name = unittest.mock.MagicMock(spec_set=str, autospec=True)
    mock_package_to_load = unittest.mock.MagicMock(spec_set=str, autospec=True)

# Generated at 2022-06-11 17:38:15.813856
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.yml') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.yaml') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.yaml.j2') == True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource.j2') == True


# Generated at 2022-06-11 17:38:26.202891
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # Unit test: __AnsibleCollectionPkgLoaderBase.get_source
    #  -test that attempts to load an ansible_collection package from a module in a package
    #   that sets __package__
    # -test that attempts to load an ansible_collection package from a module in a package
    #   that sets __package__
    # -test that attempts to load an ansible_collection package from a module in a package
    #   that sets __package__

    def run_test(_AnsibleCollectionPkgLoaderBase, **kwargs):
        cplb = _AnsibleCollectionPkgLoaderBase(**kwargs)

# Generated at 2022-06-11 17:39:05.964364
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.example.ns")
    
    # Get a real implementation to call
    loader.is_package = ansible.utils.collection_loader._AnsibleNamespacePackageLoader.is_package
    
    loader._source_code_path = None
    loader._decoded_source = None
    loader._compiled_code = None
    
    res = loader.get_code("ansible_collections.example.ns")
    assert res is None
    
    loader._source_code_path = "fake_path"
    loader._decoded_source = "fake_source"
    loader._compiled_code = "fake_code"
    
    res = loader.get_code("ansible_collections.example.ns")

# Generated at 2022-06-11 17:39:17.398740
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    # init
    module_path_map = {
        'one': os.path.join(MODULE_PATH, 'one'),
        'collections.one.two': os.path.join(MODULE_PATH, 'two')
    }
    path_list = [os.path.join(MODULE_PATH, 'one')]
    path_list.append(os.path.join(MODULE_PATH, 'two'))
    loader = _AnsibleCollectionPkgLoaderBase('one', path_list)

    # test passing file
    with open(os.path.join(MODULE_PATH, 'one', '__init__.py'), 'rb') as f:
        assert loader.get_data('__init__.py') == f.read()

    # test passing a non-existent file
    assert loader.get_data

# Generated at 2022-06-11 17:39:27.690137
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.subdir1.subdir2.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'subdir1.subdir2', u'resource', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.resource', u'module') == AnsibleCollectionRef(u'ns.coll', u'', u'resource', u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.subdir1.subdir2.resource', u'role') == AnsibleCollectionRef(u'ns.coll', u'subdir1.subdir2', u'resource', u'role')
    assert AnsibleCollectionRef.try_parse_f

# Generated at 2022-06-11 17:39:38.742278
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """
    Test get_data returns the contents of a file, and returns an empty string
    for a collection __init__.py file.
    """
    test_data = b'test_data'
    with tempfile.NamedTemporaryFile() as f:
        f.write(test_data)
        f.flush()
        loader = _AnsibleCollectionPkgLoaderBase('test', path_list=[f.name])
        content = loader.get_data(os.path.basename(f.name))
        assert content == test_data
        content = content = loader.get_data(os.path.join(os.path.basename(f.name), '__init__.py'))
        assert content == b''

# Generated at 2022-06-11 17:39:48.357672
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    try: 
        AnsibleCollectionRef.from_fqcr(None, 'module')
        success = False
        print('fail - no exception thrown')
    except Exception as e:
        if 'Must be a string' in str(e):
            success = True
            print('pass - exception thrown')
        else:
            print('fail - wrong exception thrown')
            success = False
    if success:
        print('test pass')
    else:
        print('test fail')
    print()

    try: 
        AnsibleCollectionRef.from_fqcr('a.b.c', 'modu')
        success = False
        print('fail - no exception thrown')
    except Exception as e:
        if 'invalid collection ref_type' in str(e):
            success = True
            print('pass - exception thrown')


# Generated at 2022-06-11 17:39:59.348443
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible_collections.somearns.subns.subsubns.plugin1 import basic_plugin
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('basic_plugin', os.path.dirname(basic_plugin.__path__[0])) == ('/tmp/source/ansible_collections/somearns/subns/subsubns/plugin1.py', True, None)

# Generated at 2022-06-11 17:40:09.390849
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:40:15.732178
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # _AnsibleCollectionPkgLoaderBase is an abstract base class, and can't be instantiated directly
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    loader = _AnsibleCollectionPkgLoader('ansible_collections.ns.a.b.c')
    assert loader.is_package('ansible_collections.ns.a.b.c')



# Generated at 2022-06-11 17:40:21.351374
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible_collections.ansible.collection_loader.collection_loader import AnsibleCollectionRef
    ref = AnsibleCollectionRef("test_namespace.test_name", None, "test_resource", "test_type")
    assert ref.__repr__() == "AnsibleCollectionRef(collection='test_namespace.test_name', subdirs=None, resource='test_resource')"


# Generated at 2022-06-11 17:40:29.048878
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
  fullname = 'ansible.module_utils.connection_plugins.aiohttp.aiohttp'
  path_list = []
  obj = _AnsibleInternalRedirectLoader(fullname, path_list)
  mod = obj.load_module(fullname)
  assert mod
  assert mod.__name__ == 'aiohttp'
  assert mod.__path__[0] == '/usr/local/lib/python3.6/dist-packages/ansible/module_utils/connection_plugins/aiohttp/aiohttp'


# Generated at 2022-06-11 17:41:01.375101
# Unit test for method find_module of class _AnsiblePathHookFinder

# Generated at 2022-06-11 17:41:05.897158
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder._get_filefinder_path_hook()

# Path-based import hook for iter_modules, for when the collection finder hasn't been called yet. Used for some
# pkgutil operations.

# Generated at 2022-06-11 17:41:14.954934
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid collection refs
    valid_collection_refs = ['foo.bar.mymodule', 'ansible.builtin.mymodule', 'ansible_collections.namespace.mycol.mymodule',
                             'ansible_collections.namespace.mycol.my_plugins.mymodule', 'ansible_collections.namespace.mycol.some_plugins.mysubdir.mymodule',
                             'ansible_collections.namespace.mycol.roles.myrole', 'ansible_collections.namespace.mycol.playbooks.mypb.yml',
                             'ansible_collections.namespace.mycol.playbooks.mypb.txt', 'ansible_collections.namespace.mycol.playbooks.mypb.hosts']


# Generated at 2022-06-11 17:41:19.911390
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    # When:
    #   a) the path context is ansible root,
    #   b) the path context is a collection path context
    #   c) fullname is a module name
    #   d) fullname is an internal module name
    #   e) fullname is a non module name
    # Then:
    #   ansible_collections module loader should be returned.

    # Case: a) path context is ansible root
    # Given
    test_path = os.path.dirname(ansible.__file__)
    test_collections_paths = [
        os.path.dirname(test_path)
    ]
    test_prefix = ''
    test_fullname = 'ansible'
    test_path_list = [test_path]
    test_module = 'ansible'
    collection_

# Generated at 2022-06-11 17:41:24.792981
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import pkgutil
    import os
    from operator import itemgetter
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import AnsibleCollectionConfig

    ns_name = 'myns'
    collection_name = 'mycollection'

    # Setup a command line option
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', '--path', action='append')
    args = parser.parse_args()

    # Create a dummy namespace collection under a temporary directory
    tmp_dir = tempfile.mkdtemp()
    os.makedirs('{}/ansible_collections/{}/{}/plugins'.format(tmp_dir, ns_name, collection_name), exist_ok=True)

# Generated at 2022-06-11 17:41:33.360952
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'module'
    assert not AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('blah')
    assert not AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('blah_plugins')
    assert not AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('blah_blah_plugins')

# Generated at 2022-06-11 17:41:36.006645
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    collection_finder = _AnsibleCollectionFinder()
    assert collection_finder
    assert collection_finder._n_configured_paths
    assert collection_finder._n_playbook_paths



# Generated at 2022-06-11 17:41:46.662931
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    with pytest.raises(ImportError) as excinfo:
        loader = _AnsibleInternalRedirectLoader('ansible.foo', [])
    assert 'not interested' in str(excinfo.value)

    with pytest.raises(ImportError) as excinfo:
        loader = _AnsibleInternalRedirectLoader('foo.bar', [])
    assert 'not redirected, go ask path_hook' in str(excinfo.value)

    loader = _AnsibleInternalRedirectLoader('ansible.galaxy', [])
    assert loader._redirect == 'ansible_collections.ansible.builtin.galaxy'


# NB: this is not the actual path hook, this is a replacement for the built-in import mechanism that validates we
# only answer for intercepted Ansible Python modules, otherwise it delegates to the built-in import

# Generated at 2022-06-11 17:41:57.549064
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = AnsibleCollectionRef(u'ansible.builtin', u'subdir1.subdir2', u'b_module', u'module')
    assert ref.collection == u'ansible.builtin'
    assert ref.subdirs == u'subdir1.subdir2'
    assert ref.resource == u'b_module'
    assert ref.ref_type == u'module'
    assert ref.n_python_collection_package_name == u'ansible_collections.ansible.builtin'
    assert ref.n_python_package_name == u'ansible_collections.ansible.builtin.plugins.subdir1.subdir2.module'
    assert ref.fqcr == u'ansible.builtin.subdir1.subdir2.b_module'
    assert Ans

# Generated at 2022-06-11 17:42:06.581598
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import string
    import random
    import sys

    # create fullname
    def _get_fullname():
        # create fullname
        fullname = '.'.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(1,128)))
        return fullname

    # create filepath
    def _get_filepath():
        # create filepath
        filepath = ''.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(1,128)))
        return filepath

    # create source_code_path

# Generated at 2022-06-11 17:42:35.404344
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef(collection_name='ns.coll', subdirs=None, resource='res', ref_type='role') == \
           AnsibleCollectionRef(collection_name='ns.coll', subdirs='', resource='res', ref_type='role')
    assert AnsibleCollectionRef(collection_name='ns.coll', subdirs='a.b.c', resource='res', ref_type='role') == \
           AnsibleCollectionRef(collection_name='ns.coll', subdirs='a.b.c', resource='res', ref_type='role')

# Generated at 2022-06-11 17:42:43.352806
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    myAnsibleCollectionRef = AnsibleCollectionRef(None, None, None, None)

    assert myAnsibleCollectionRef.is_valid_fqcr(None) == False
    assert myAnsibleCollectionRef.is_valid_fqcr('foo') == False
    assert myAnsibleCollectionRef.is_valid_fqcr('foo.') == False
    assert myAnsibleCollectionRef.is_valid_fqcr('.foo') == False
    assert myAnsibleCollectionRef.is_valid_fqcr('foo.bar') == True
    assert myAnsibleCollectionRef.is_valid_fqcr('foo.bar.baz') == True
    assert myAnsibleCollectionRef.is_valid_fqcr('foo.bar.baz1.baz2') == True

    assert myAn

# Generated at 2022-06-11 17:42:54.121905
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # pylint: disable=protected-access
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    # all supported plugin types
    plugin_ref_types = list(AnsibleCollectionRef.VALID_REF_TYPES)

    # ref_types that can be interpreted as a subdir or plugin
    dirs_or_plugins = [u'module_utils', u'modules', u'plugins']

    # ref_types that can be interpreted as types of the 'plugins' subdir, where a subdir is allowed

# Generated at 2022-06-11 17:42:55.605310
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    sys.meta_path.append(_AnsibleCollectionFinder())
    import ansible_collections



# Generated at 2022-06-11 17:43:05.792480
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    def _test_path(path, expected_path):
        assert path == expected_path
        loader.get_filename(fullname)
        assert "get_filename(" in str(w), str(w[-1].message)
        assert "only" in str(w[-1].message)
    tmpdir = tempfile.mkdtemp("_test_AnsibleCollectionPkgLoaderBase_get_filename")
    package_dir = os.path.join(tmpdir, "ansible_collections", "collection")
    os.makedirs(package_dir)
    open(os.path.join(package_dir, "file.py"), 'w').close()
    open(os.path.join(package_dir, "memo.yaml"), 'w').close()

# Generated at 2022-06-11 17:43:17.390985
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    class _AnsibleCollectionPkgLoaderBase_UnitTest(unittest.TestCase):
        def setUp(self):
            self.loader = _AnsibleCollectionPkgLoaderBase('test_paths', path_list=['/tmp'])
            self.test_prefix = os.path.join('/home', 'users', 'bsmith')

        def test__iter_modules_impl(self):
            # test with no path argument
            self.assertEqual([], list(_iter_modules_impl()))

            # test with empty path argument
            self.assertEqual([], list(_iter_modules_impl([''], self.test_prefix)))

            # test with non-empty path argument
            self.assertEqual([], list(_iter_modules_impl(['/tmp'], self.test_prefix)))

            # test with

# Generated at 2022-06-11 17:43:20.962281
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    assert 0

# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-11 17:43:26.386036
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    print('Test AnsibleCollectionRef.is_valid_fqcr()')
    print('Test AnsibleCollectionRef.is_valid_fqcr() with valid collection reference')
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.my_coll.my_resource') == True


# Generated at 2022-06-11 17:43:36.838726
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile

    tmp_dir = tempfile.TemporaryDirectory()
    tmp_dir_name = tmp_dir.name

    def _cleanup():
        tmp_dir.cleanup()

    open(os.path.join(tmp_dir_name, 'fake_ns_package.py'), 'a').close()
    open(os.path.join(tmp_dir_name, 'fake_ns_package2.py'), 'a').close()
    os.mkdir(os.path.join(tmp_dir_name, 'fake_ns_package3'))
    open(os.path.join(tmp_dir_name, 'fake_ns_package3', '__init__.py'), 'a').close()


# Generated at 2022-06-11 17:43:49.229722
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.resource', u'module') and \
           AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.resource').fqcr == u'ns.coll.resource'
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.subdir1.resource', u'module') and \
           AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.subdir1.resource').fqcr == u'ns.coll.subdir1.resource'
    assert AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.playbook', u'playbook') and \
           AnsibleCollectionRef.try_parse_fqcr(u'ns.coll.playbook').fq

# Generated at 2022-06-11 17:44:28.370068
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    test_path = '/tmp/ansible_collections/notns/collection/plugins/module_utils'
    test_module = 'notns.collection.plugins.module_utils.math'
    test_module_code = "foo='bar'\n"
    test_module_name = 'math'
    # test_module_dir_name = 'math'
    loader = _AnsibleCollectionPkgLoaderBase(test_module, [test_path])
    mock_module = MagicMock()
    mock_module.__file__ = '__file__'
    mock_module.__package__ = '__package__'