

# Generated at 2022-06-11 17:35:30.730306
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from collections import namedtuple
    from importlib import machinery
    from importlib.util import spec_from_loader
    from ansible_collections.community.general.tests.unit import mock
    from ansible_collections.community.general.tests.unit.compat import unittest

    TestModule = namedtuple('TestModule', 'name fullname')
    TestLoader = namedtuple('TestLoader', 'name module_list')
    TestSpec = namedtuple('TestSpec', 'name loader is_package')
    mock_factory = mock.MockFactory(spec=machinery)


# Generated at 2022-06-11 17:35:34.853814
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test when ref is not valid
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('abc', None)

    # Test when a valid ref is given
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource', None)
    assert isinstance(ansible_collection_ref, AnsibleCollectionRef)

    # Test when an invalid ref is passed
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr('ns.coll.resource.test', None)
    assert not isinstance(ansible_collection_ref, AnsibleCollectionRef)


# Generated at 2022-06-11 17:35:41.095150
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    mod = sys.modules[__name__]
    loader = _AnsibleCollectionPkgLoaderBase(mod.__name__, [os.path.dirname(mod.__file__)])
    assert loader.get_data(os.path.basename(mod.__file__)) == inspect.getsource(mod)
test__AnsibleCollectionPkgLoaderBase_get_data()



# Generated at 2022-06-11 17:35:51.814769
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():

    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cliconf_plugins') == 'cliconf'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('terminal_plugins') == 'terminal'


# Generated at 2022-06-11 17:35:59.942419
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    #
    # __repr__(prefix) method tests

    # _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase

    class DummyCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):
        """
        Unit test dummy class for class AnsibleCollectionPkgLoaderBase
        """
        pass

    dummy = DummyCollectionPkgLoader('ansible.collections.foo', path_list=['/path/to/collections'])
    assert str(dummy) == "_AnsibleCollectionPkgLoaderBase(path=['/path/to/collections/foo'])"

    dummy = DummyCollectionPkgLoader('ansible.collections.foo.bar')

# Generated at 2022-06-11 17:36:04.901027
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    # Test case: the fullname of this loader instance is 'ansible_collections.ns.test'
    fullname = 'ansible_collections.ns.test'  # this is different from self._fullname
    path_list = ['path1', 'path2', 'path3']

    loader = _AnsibleCollectionPkgLoaderBase(fullname, path_list)

    assert loader._fullname == 'ansible_collections.ns.test'
    assert loader._split_name == ['ansible_collections', 'ns', 'test']
    assert loader._parent_package_name == 'ansible_collections.ns'
    assert loader._package_to_load == 'test'

    assert loader._candidate_paths == ['path1/test', 'path2/test', 'path3/test']

    # Test case:

# Generated at 2022-06-11 17:36:14.899096
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.name')
    assert AnsibleCollectionRef.is_valid_collection_name('namespace.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('n.c')
    assert AnsibleCollectionRef.is_valid_collection_name('n.c')

    # each part of the name has to be a valid Python identifier
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.with space')  # space is not a valid Python identifier
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.with-hypen')  # hypen is not a valid Python identifier
    assert not AnsibleCollectionRef.is_valid_collection_name('namespace.123')  # 123 is not a valid Python identifier

    # the name

# Generated at 2022-06-11 17:36:27.864689
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:36:36.685453
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # pylint: disable=protected-access

    # Call method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef with invalid args
    # Test with invalid value for legacy_plugin_dir_name
    try:
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('')
        raise AssertionError('Expected ValueError to be raised')
    except ValueError:
        pass

    # Call method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef with valid args
    # Test with valid value for legacy_plugin_dir_name
    AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')



# Generated at 2022-06-11 17:36:40.833297
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import unittest
    import tempfile
    import shutil
    import os
    import sys
    pkg = 'test_users_test_test'
    version = '1.0.0'
    ns = 'test_test'
    coll = 'test_users'
    coll_pkg = '.'.join([ns, coll, pkg])
    coll_dir = os.sep.join([ns, coll])
    path = '_'.join([ns, coll, version])
    coll_ns_dir = os.sep.join([ns])
    test_dir = tempfile.mkdtemp()
    # create in test directory the following dir tree
    # <test_dir>
    #   |__ansible_collections
    #      |__test_test
    #         |__test_users
    #            |

# Generated at 2022-06-11 17:37:16.017898
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = 'my.package'
    package_path = '/path/to/my/package'
    loader_class = _AnsibleCollectionPkgLoaderBase(
        fullname, path_list=[package_path]
    )

    # Test valid cases where code has code
    loader_class._source_code_path = os.path.join(package_path, '__init__.py')
    assert loader_class._compiled_code is None
    assert isinstance(loader_class.get_code(fullname), CodeType)
    assert loader_class._compiled_code is not None

    # Test package with no code
    loader_class._source_code_path = None
    assert loader_class._compiled_code is None
    assert loader_class.get_code(fullname) is None
    assert loader_class._

# Generated at 2022-06-11 17:37:27.404895
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Setup
    loader = _AnsibleCollectionPkgLoader('ansible.collections.test_collection.plugins.action', '')
    loader.load_module('ansible.collections.test_collection')
    with patch('ansible.utils.collection_loader.import_module') as import_module_mock:
        # Exercise
        loader.load_module('ansible.collections.test_collection.plugins.action')
    # Assert
    assert import_module_mock.call_count == 1
    assert import_module_mock.call_args[0] == ('ansible.utils.collection_loader',)
    # Test teardown
    _AnsibleCollectionPkgLoader.load_module('ansible.collections.test_collection.plugins', '')
    _AnsibleCollectionPkgLoader.load_

# Generated at 2022-06-11 17:37:35.164923
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    fullpath = '/Users/tony/Documents/work/ansible_collections/ansible_collections/mycollection/mycollection/mypkg/__init__.py'
    p = os.path.split(fullpath)[0]
    loader = _AnsibleCollectionPkgLoader(fullpath)
    assert loader.is_package('ansible_collections.mycollection.mycollection.mypkg') is True
    assert loader.is_package('ansible_collections.mycollection.mycollection.mypkg.mymodule') is False
    assert loader.is_package('ansible_collections.mycollection.mycollection') is False
    assert loader.is_package('ansible_collections.mycollection') is False
    assert loader.is_package('ansible_collections') is False

# Generated at 2022-06-11 17:37:43.061355
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == u'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('terminal') == u'terminal'

    with pytest.raises(ValueError):
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('doesnotexist')



# Generated at 2022-06-11 17:37:46.385694
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('ns.pkg', path_list=['/path/to/ns/pkg/'])
    assert loader.is_package('ns.pkg')



# Generated at 2022-06-11 17:37:48.069251
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert isinstance(_AnsibleCollectionPkgLoaderBase(), _AnsibleCollectionPkgLoaderBase)



# Generated at 2022-06-11 17:37:55.810464
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    def assert_repr_is_as_expected(mock_obj, expected_repr):
        assert repr(mock_obj) == expected_repr

    mock_obj = _AnsibleCollectionPkgLoaderBase("ansible_collections.randomnamespace.randomcollectionname")
    mock_obj.__class__.__name__ = "MockAnsibleCollectionPkgLoader"
    expected_repr = "MockAnsibleCollectionPkgLoader()"
    assert_repr_is_as_expected(mock_obj, expected_repr)

    mock_obj = _AnsibleCollectionPkgLoaderBase("ansible_collections.randomnamespace.randomcollectionname", None)
    mock_obj.__class__.__name__ = "MockAnsibleCollectionPkgLoader"

# Generated at 2022-06-11 17:38:04.489474
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    test_fqcr_values = [u'foo.bar', u'foo.bar.baz', u'foo.bar.baz.baz']
    test_ref_types = [u'action', u'become', u'cache', u'callback', u'cliconf', u'connection', u'doc_fragments', u'filter',
                      u'httpapi', u'inventory', u'lookup', u'module_utils', u'modules', u'netconf', u'role', u'shell',
                      u'strategy', u'terminal', u'test', u'vars', u'playbook']

    for test_fqcr in test_fqcr_values:
        assert AnsibleCollectionRef.is_valid_fqcr(test_fqcr) is True


# Generated at 2022-06-11 17:38:15.196830
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:38:26.143990
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # build a signature
    signature = AnsibleCollectionRef("my_namespace.my_collection", "subdir1.subdir2", "name_of_plugin", "plugin_type")

    # test the signature
    assert signature.__repr__() == "AnsibleCollectionRef(collection='my_namespace.my_collection', subdirs='subdir1.subdir2', resource='name_of_plugin')"
    assert signature.subdirs == "subdir1.subdir2"
    assert signature.collection == "my_namespace.my_collection"
    assert signature.resource == "name_of_plugin"
    assert signature.ref_type == "plugin_type"
    assert signature.n_python_collection_package_name == "ansible_collections.my_namespace.my_collection"

# Generated at 2022-06-11 17:38:57.066130
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    test_collection_finder = _AnsibleCollectionFinder()
    fullname = 'ansible'
    path = test_collection_finder._n_collection_paths
    assert test_collection_finder.find_module(fullname, path) is not None


# Generated at 2022-06-11 17:39:04.854848
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Create _AnsibleCollectionPkgLoader object
    test_obj = _AnsibleCollectionPkgLoader(['foo', 'bar', 'baz'], ['/tmp/foo'])

    test_obj._redirect_module = ''
    test_obj._split_name = ['foo', 'bar', 'baz']
    test_obj._fullname = 'foo.bar.baz'
    test_obj._parent_package_name = ''
    test_obj._package_to_load = 'baz'
    test_obj._candidate_paths = []
    test_obj._subpackage_search_paths = []
    test_obj._source_code_path = '/tmp/foo/baz/__init__.py'
    test_obj._compiled_code = ''
    test_obj._decoded_source

# Generated at 2022-06-11 17:39:16.030899
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    import ansible.utils.collection_loader
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import read_docsting
    from ansible.plugins.loader import action_loader
    _meta_yml_to_dict = ansible.utils.collection_loader._meta_yml_to_dict # make it a global variable

# Generated at 2022-06-11 17:39:19.001292
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    try:
        AnsibleCollectionRef.from_fqcr('ns.coll.resource.name', 'role')

    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 17:39:29.042998
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:39:39.624028
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # test expected conversions
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'action_plugins') == u'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'become_plugins') == u'become'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cache_plugins') == u'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'callback_plugins') == u'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(u'cliconf_plugins') == u'cliconf'

# Generated at 2022-06-11 17:39:42.103924
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    assert repr(AnsibleCollectionRef('arrow', 'subdirs', 'resource', 'ref_type')) == "AnsibleCollectionRef(collection='arrow', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-11 17:39:42.789715
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    pass

# Generated at 2022-06-11 17:39:50.486835
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1', 'role'))
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1', 'playbook'))
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1', 'module'))
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1', 'action'))
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1', 'filter'))
    print(AnsibleCollectionRef.from_fqcr('ns1.coll1.res1.py', 'playbook'))

# Generated at 2022-06-11 17:39:56.784435
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.ver.coll.mod',
                                             path_list=['ansible_collections/ns/ver/coll/'])
    with open('ansible_collections/ns/ver/coll/__init__.py') as f:
        result = loader.get_data('__init__.py')
        assert result == f.read()



# Generated at 2022-06-11 17:41:30.023271
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource')
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns.coll.')
    assert not AnsibleCollectionRef.is_valid_fqcr('ns..coll')


# Generated at 2022-06-11 17:41:38.708311
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # test correct return of data on disk
    leaf_name = 'test.py'
    path = os.path.join(os.getcwd(), 'test')
    test_module = _AnsibleCollectionPkgLoaderBase('ansible_collections.some.ns', path_list=[path])
    test_module._source_code_path = os.path.join(path, leaf_name)
    assert test_module.get_data(test_module._source_code_path) == b'result = 2 + 3\n'

    # test correct return of data for package init in directory
    leaf_name = 'test'
    path = os.path.join(os.getcwd(), 'test')

# Generated at 2022-06-11 17:41:43.130574
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_collection_loader = _AnsibleCollectionPkgLoader(package=None, package_to_load='ansible_collections')

    test_collection_loader.load_module('ansible_collections')
    assert 1 == 1

# Generated at 2022-06-11 17:41:53.026520
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    try:
        import ansible_collections
        # Try to import ansible_collections twice to simulate a crash.
        # It should not crash on the second import.
        # We need this test to be executed before other tests.
        # This is not included in the example tests.
        import ansible_collections
    except ImportError:
        # ansible_collections is not installed. Skip the test.
        return
    import inspect
    import sys
    import os

    test_path = os.path.abspath(os.path.join(os.path.dirname(inspect.getfile(inspect.currentframe())), ".."))
    collection_loader_path = os.path.join(test_path, "..", "lib", "ansible", "utils", "collection_loader")
    collection_metadata_path = os

# Generated at 2022-06-11 17:42:03.514570
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    from ansible.plugins.loader import find_plugin

# Generated at 2022-06-11 17:42:10.320683
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    src1 = '''#!/usr/bin/python
    import sys
    import os
    import time
    '''
    src2 = '''#!/usr/bin/python
    import sys
    import time
    import os
    '''
    filename1 = '/tmp/test1.py'
    filename2 = '/tmp/test2.py'
    code1 = None
    code2 = None
    with open(filename1, 'wb') as fd:
        fd.write(src1)
    with open(filename2, 'wb') as fd:
        fd.write(src2)
    code1 = _AnsibleCollectionPkgLoaderBase.get_code(filename1)
    code2 = _AnsibleCollectionPkgLoaderBase.get_code(filename2)

# Generated at 2022-06-11 17:42:20.180923
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:42:30.983767
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ansible_collection_ref = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'resource', 'doc_fragment')
    assert ansible_collection_ref.collection == 'ns.coll'
    assert ansible_collection_ref.subdirs == 'subdir1.subdir2'
    assert ansible_collection_ref.resource == 'resource'
    assert ansible_collection_ref.ref_type == 'doc_fragment'
    assert ansible_collection_ref.n_python_package_name == 'ansible_collections.ns.coll.plugins.subdir1.subdir2.doc_fragment'
    assert ansible_collection_ref.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ansible_collection_ref.f

# Generated at 2022-06-11 17:42:41.143238
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import ansible
    import ansible_collections
    import ansible_collections.ansible
    import ansible_collections.testns.anothertestcoll
    import ansible_collections.testns.testcoll
    from ansible_collections.testns.testcoll.plugins.module_utils import testcoll_utils, testcoll_utils2
    from ansible_collections.testns.testcoll2.plugins import module_utils
    from ansible_collections.testns.testcoll2.plugins import modules
    from ansible_collections.testns.testcoll2.plugins.module_utils import testcoll_utils
    from ansible_collections.testns.testcoll3.plugins import module_utils
    import ansible_collections.testns.testcoll3.plugins.module_utils.testcoll_utils

# Generated at 2022-06-11 17:42:51.292619
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    file_path = os.path.dirname(os.path.realpath(__file__))
    # Make sure ansible is in the system path.
    sys.path.append(os.path.join(file_path, '..', '..', '..', '..', '..'))
    sys.path.append(os.path.join(file_path, '..', '..', '..', '..'))
    import ansible
    # Set ansible.utils.collection_loader._meta_yml_to_dict as a global variable.
    from ansible.utils.collection_loader import _meta_yml_to_dict
    _meta_yml_to_dict = ansible.utils.collection_loader._meta_yml_to_dict
    # Set ansible.utils.collection_loader.AnsibleCollection

# Generated at 2022-06-11 17:43:23.698232
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = AnsibleCollectionRef('namespace.collection', 'subdirs', 'resource', 'doc_fragments')
    assert True == ref.is_valid_fqcr('namespace.collection.resource', 'doc_fragments')
    assert False == ref.is_valid_fqcr('namespace.collection.resource', 'doc_')
    assert False == ref.is_valid_fqcr('namespace.collection', 'doc_fragments')
    assert False == ref.is_valid_fqcr('namespace.collection.doc_fragments', 'doc_fragments')
    assert True == ref.is_valid_fqcr('namespace.collection.doc_fragments.resource', 'doc_fragments')

# Generated at 2022-06-11 17:43:35.424417
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():

    # Setup
    fullname = "ansible.plugins.connection.docker.DockerConnection"
    # Expected result
    expected = ansible.plugins.connection.docker.DockerConnection()

    # Run method
    actual = ansible.utils.plugin_loader._AnsibleInternalRedirectLoader(fullname, None).load_module(fullname)

    # Basic test
    assert actual.__name__ == expected.__name__
    assert actual.__doc__ == expected.__doc__
    assert actual.__package__ == expected.__package__
    assert actual.__loader__ == expected.__loader__
    assert actual.__spec__ == expected.__spec__


# The importer which is added to sys.meta_path. Handles matching the fullname (and optionally path) to an appropriate
# loader. The ansible_collections package

# Generated at 2022-06-11 17:43:47.786342
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys, importlib
    import ansible.module_utils.parsing.convert_bool as convert_bool
    split_name = 'ansible.module_utils.parsing.convert_bool'
    fullname = '.'.join(split_name.split('.')[0:3])
    # init
    _AnsibleInternalRedirectLoader(fullname, sys.path)
    # load_module
    ansible_utils_parsing_convert_bool = importlib.import_module('ansible.utils.parsing.convert_bool')
    # test
    assert(importlib.import_module('ansible.module_utils.parsing.convert_bool')==ansible_utils_parsing_convert_bool)

# Generated at 2022-06-11 17:43:58.321561
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    fail_msg = 'AnsibleCollectionRef instance .__repr__ method is not working properly'
    fqcr = 'foo.bar.baz'
    cr = collection_loader.ansible_collections.get(fqcr)
    assert isinstance(cr, collection_loader.AnsibleCollectionRef), fail_msg
    # NOTE: fqcr represents a plugin and not a role
    assert cr.__repr__() == "AnsibleCollectionRef(collection='foo.bar', subdirs='', resource='baz')", fail_msg
    # NOTE: fqcr represents a role
    fqcr = 'foo.bar.baz.role'
    cr = collection_loader.ansible_collections.get(fqcr)

# Generated at 2022-06-11 17:44:08.587593
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # ansible_collections.ansible.builtin is a synthetic collection, get its routing config from the Ansible distro
    ansible_pkg_path = os.path.dirname(import_module('ansible').__file__)
    metadata_path = os.path.join(ansible_pkg_path, 'config/ansible_builtin_routing.yml')
    with open(to_bytes(metadata_path), 'rb') as fd:
        raw_routing = fd.read()
    _meta_yml_to_dict = getattr(yaml, 'CSafeLoader', yaml.SafeLoader)
    routing_dict = _meta_yml_to_dict(raw_routing, [])
    # HACK: stash this in a better place
    _AnsibleCollectionLoader._redirected_package

# Generated at 2022-06-11 17:44:13.158756
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # We test that an action plugin directory will map to action, a connection plugin directory will map to connection
    # and a library plugin directory will map to modules.
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("action_plugins") == "action"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("connection_plugins") == "connection"
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type("library") == "modules"


# Generated at 2022-06-11 17:44:24.006339
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ans_ref_1 = AnsibleCollectionRef('ansible.builtin', 'filter', 'to_yaml', 'filter')
    assert isinstance(ans_ref_1, AnsibleCollectionRef)
    assert ans_ref_1.collection == 'ansible.builtin'
    assert ans_ref_1.subdirs == 'filter'
    assert ans_ref_1.resource == 'to_yaml'
    assert ans_ref_1.ref_type == 'filter'
    assert ans_ref_1.n_python_collection_package_name == 'ansible_collections.ansible.builtin'
    assert ans_ref_1.n_python_package_name == 'ansible_collections.ansible.builtin.plugins.filter.filter.to_yaml'
    assert ans_ref_1.fqcr

# Generated at 2022-06-11 17:44:31.683884
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # this code is executed once for each module...
    # so do not do any side effects in it, like module-level imports

    # reload the module under test to get a fresh new class object
    importlib.reload(sys.modules['ansible.module_utils.ansible_release'])
    importlib.reload(sys.modules['ansible.module_utils.common._collections_compat'])

    class TestMe(_AnsibleCollectionPkgLoaderBase):
        def get_filename(self, fullname):
            return 'testme-filename'
        def get_data(self, path):
            return ''
        pass

    obj = TestMe("test.testme")
    assert "path=...testme-filename" in str(obj)

    obj = TestMe("test.testme")
    obj._subpackage_