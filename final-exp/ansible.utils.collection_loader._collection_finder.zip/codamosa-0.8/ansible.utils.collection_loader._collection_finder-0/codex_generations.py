

# Generated at 2022-06-11 17:35:26.570988
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef(
        collection="test_collection",
        subdirs="test_subdirs",
        resource="test_resource",
        ref_type="test_ref_type"
    )
    assert repr(ref) == 'AnsibleCollectionRef(collection=\'test_collection\', subdirs=\'test_subdirs\', resource=\'test_resource\')'



# Generated at 2022-06-11 17:35:29.459600
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
  # invoked to verify that the module was successfully installed
  _AnsibleCollectionPkgLoaderBase()
  assert 1 == 1


# Generated at 2022-06-11 17:35:39.513678
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader as collection_loader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader

    collection_loader._meta_yml_to_dict = None

    # test without meta_yml_to_dict
    try:
        _AnsibleCollectionPkgLoader(None, None, None)
    except ValueError:
        pass

    # test with meta_yml_to_dict = None
    collection_loader._meta_yml_to_dict = None
    loader = _AnsibleCollectionPkgLoader(None, None, None)
    try:
        loader.load_module(None)
    except ValueError as e:
        if str(e) != 'ansible.utils.collection_loader._meta_yml_to_dict is not set':
            raise



# Generated at 2022-06-11 17:35:41.449034
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    assert False, "TODO: Implement this!"



# Generated at 2022-06-11 17:35:45.073175
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.ns').__repr__() == "_AnsibleCollectionPkgLoaderBase(path=None)"

# Generated at 2022-06-11 17:35:55.270348
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:36:06.531001
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    with pytest.raises(ImportError) as e:
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections', None)
        assert e.args == ("this loader can only load collections namespace packages, not ansible_collections",)

    with pytest.raises(ImportError) as e:
        loader = _AnsibleCollectionNSPkgLoader('ansible_collections.somens.sosubns', None)
        assert e.args == ("this loader can only load collections namespace packages, not ansible_collections.somens.sosubns",)

    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.somens', None)
    assert loader._fullname == 'ansible_collections.somens'
    assert loader._redirect_module == None
   

# Generated at 2022-06-11 17:36:14.817547
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # NOTE: we can't directly instantiate this class because it requires a fullname argument- so we'll use a subclass
    class myloader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            return
    cases = [
        (myloader('ns.name'), '_AnsibleCollectionPkgLoaderBase(path=/ns/name)'),
        (myloader('ns.name', path_list=['/my/path']), '_AnsibleCollectionPkgLoaderBase(path=/my/path/name)'),
    ]
    for (instance, expected) in cases:
        assert instance.__repr__() == expected
    pass



# Generated at 2022-06-11 17:36:27.774064
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class Mock:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            self.called = True
            self.called_args = args
            self.called_kwargs = kwargs

    import_module = Mock()
    m = _AnsibleInternalRedirectLoader('test_redirect', 'test_path')

    sys.modules['test_redirect'] = 'test_module'
    m.load_module('test_redirect')
    assert import_module.called
    assert import_module.called_args == ('test_path',)
    assert import_module.called_kwargs == {}

    import_module.called = False


# Generated at 2022-06-11 17:36:32.207693
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with patch.object(sys.modules, '__getitem__', return_value=None):
        loader = _AnsibleInternalRedirectLoader('ansible.module_utils.facts', '/some/path')
        loader._redirect = 'ansible.module_utils.facts'
        assert loader.load_module('ansible.module_utils.facts') == None


# Generated at 2022-06-11 17:37:26.719362
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Valid reference
    test_ref = AnsibleCollectionRef('ns.collection', None, 'mymodule', 'module')

    # Invalid collection reference
    try:
        test_ref = AnsibleCollectionRef(None, None, 'mymodule', 'module')
    except ValueError as value_err:
        assert u'ValueError' in to_text(value_err)

    try:
        test_ref = AnsibleCollectionRef('ns.collection', 'ansible.some_mod', 'mymodule', 'module')
    except ValueError as value_err:
        assert u'ValueError' in to_text(value_err)


# Generated at 2022-06-11 17:37:34.741879
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.subdir2.resource', 'role').fqcr == 'namespace.collection.subdir1.subdir2.resource'
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'role').fqcr == 'namespace.collection.resource'
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.subdir1.resource', 'role').fqcr == 'namespace.collection.subdir1.resource'
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.resource', 'role').fqcr == 'namespace.collection.resource'

# Generated at 2022-06-11 17:37:39.182487
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsiblePathHookFinder(None, '/path/to/collections')

    assert finder.find_module('ansible_collections.test.test_module') is not None
    assert finder.find_module('any.other.module') is None


# Generated at 2022-06-11 17:37:49.735906
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test_path = os.path.join(test_dir, "files", "t")
    loader = _AnsibleCollectionPkgLoaderBase("t.__init__", [test_path])
    assert loader.get_filename("t.__init__") == os.path.join(test_path, "__init__.py")
    
    loader = _AnsibleCollectionPkgLoaderBase("t.__init__", [])
    assert loader.get_filename("t.__init__") == '<ansible_synthetic_collection_package>'
    loader = _AnsibleCollectionPkgLoaderBase("t", [])

# Generated at 2022-06-11 17:37:53.972505
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert repr(_AnsibleCollectionPkgLoaderBase([], None)) == '_AnsibleCollectionPkgLoaderBase(path=None)'
    assert repr(_AnsibleCollectionPkgLoaderBase([], [])) == '_AnsibleCollectionPkgLoaderBase(path=[])'
    assert repr(_AnsibleCollectionPkgLoaderBase([], ['foo'])) == '_AnsibleCollectionPkgLoaderBase(path=foo)'



# Generated at 2022-06-11 17:38:02.749425
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    import os

    import pytest

    class TestableAnsibleCollectionPkgLoaderBase(_AnsibleCollectionPkgLoaderBase):

        _subpackage_search_paths = None

        def _validate_args(self):
            return

        def _get_subpackage_search_paths(self, candidate_paths):
            return self._subpackage_search_paths

    def make_loader(paths):
        return TestableAnsibleCollectionPkgLoaderBase('foo.bar', paths)

    @pytest.fixture(autouse=True)
    def _cleanup_sys_modules(request):
        modules = sys.modules.copy()
        yield

        for modname in modules:
            if modname not in sys.modules:
                continue
            # PY3: allow anything loaded with importlib._bootstrap to

# Generated at 2022-06-11 17:38:13.268665
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref1 = 'ns.coll.resource'
    ref_type = 'module'
    assert AnsibleCollectionRef.is_valid_fqcr(ref1, ref_type) == True
    assert AnsibleCollectionRef.is_valid_fqcr(ref1) == True

    ref2 = 'ns.coll.subdir1.subdir2.resource'
    assert AnsibleCollectionRef.is_valid_fqcr(ref2, ref_type) == True
    assert AnsibleCollectionRef.is_valid_fqcr(ref2) == True

    ref3 = 'ns.coll.rolename'
    ref_type = 'role'
    assert AnsibleCollectionRef.is_valid_fqcr(ref3, ref_type) == True

# Generated at 2022-06-11 17:38:20.887249
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    '''
    Test _AnsibleCollectionPkgLoaderBase:is_package()
    '''
    try:
        # Test a class which is not a _AnsibleCollectionPkgLoaderBase subclass
        test_class = _AnsibleModuleFinder()
        test_class.is_package('ansible.module_utils')
        assert False, '_AnsibleModuleFinder.is_package() should raise exception "ValueError: this loader cannot answer is_package" but it did not'
    except ValueError as exp:
        assert len(exp.args) == 1, '_AnsibleModuleFinder.is_package(ansible.module_utils) ValueError should have a single argument, but it does not'

# Generated at 2022-06-11 17:38:32.019005
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # test for fqcr of type TEST.TEST.TEST
    test_try_parse_fqcr = AnsibleCollectionRef.try_parse_fqcr(BASE_FQCR, BASE_REF_TYPE)
    assert test_try_parse_fqcr.fqcr == BASE_FQCR
    assert test_try_parse_fqcr.collection == BASE_COLLECTION_NAME
    assert test_try_parse_fqcr.subdirs == BASE_SUBDIRS
    assert test_try_parse_fqcr.resource == BASE_RESOURCE
    assert test_try_parse_fqcr.ref_type == BASE_REF_TYPE
    # test for fqcr of type TEST.TEST.TEST.TEST
    test_try_parse_fqcr_additional_subdir

# Generated at 2022-06-11 17:38:44.899759
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    for collection in ['', '.', '..', 'ns..coll', 'ns.coll', 'ns.coll.', '.ns.coll', 'ns.coll.test', 'ns.coll.test.module']:
        if AnsibleCollectionRef.is_valid_collection_name(collection):
            ref = AnsibleCollectionRef('ns.coll.test.module', u'', u'ns.coll.test.module', u'role')
            assert ref.collection == 'ns.coll'
            assert ref.resource == 'test.module'
            assert ref.ref_type == 'role'
            assert ref.subdirs == ''
            assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll'

# Generated at 2022-06-11 17:39:26.289218
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:39:34.282008
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    fullname = 'ansible_collections.my.my_path'
    with _AnsibleCollectionPkgLoaderBase._new_or_existing_module(fullname, abc=123) as module:
        assert module.abc == 123
        assert sys.modules[fullname] is module
        module.xyz = 456
        assert module.xyz == 456
    assert fullname not in sys.modules
    with _AnsibleCollectionPkgLoaderBase._new_or_existing_module(fullname, abc=123) as module:
        assert module.abc == 123
        assert sys.modules[fullname] is module
        module.xyz = 456
        assert module.xyz == 456
    assert fullname not in sys.modules

# Generated at 2022-06-11 17:39:42.526334
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    def _test_parse_fqcr(fqcr_input, ref_type, expected_ns, expected_name, expected_subdirs, expected_resource):
        fqcr_obj = AnsibleCollectionRef.try_parse_fqcr(fqcr_input, ref_type)
        assert fqcr_obj.collection == expected_ns + '.' + expected_name
        assert fqcr_obj.subdirs == expected_subdirs
        assert fqcr_obj.resource == expected_resource
        assert fqcr_obj.ref_type == ref_type

    _test_parse_fqcr('ns1.coll1.resource1', 'module', 'ns1', 'coll1', '', 'resource1')

# Generated at 2022-06-11 17:39:50.366949
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible_collections.ansible.collections.plugins import module_utils as base_module_utils
    data = {}
    _ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(name='ansible_collections.ansible.collection_one.plugins.modules.test_module',
                                                                          path_list=[base_module_utils.__path__[0]])
    _ansible_collection_pkg_loader_base._source_code_path = None
    _ansible_collection_pkg_loader_base._compiled_code = None
    data['not_found'] = _ansible_collection_pkg_loader_base.get_code(name='ansible_collections.ansible.collection_one.plugins.modules.test_module') is None
    _ansible_collection_

# Generated at 2022-06-11 17:39:56.804797
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    finder = _AnsibleCollectionFinder()
    # Let's create a collection to test
    basedir = os.path.join(finder._ansible_pkg_path,'ansible_collections')
    collection = 'my.collection'
    collection_path = os.path.join(basedir, collection)

    os.makedirs(collection_path)

    # The path is already in sys.path_importer_cache (since we created it) so we need to update it
    sys.path_importer_cache[collection_path] = _AnsiblePathHookFinder(finder, collection_path)
    # Let's try to find a module under the collection
    module_path = os.path.join(collection_path, 'plugins', 'modules')
    os.makedirs(module_path)

# Generated at 2022-06-11 17:39:58.922569
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    import doctest
    doctest.testmod(verbose=True, extraglob='AnsibleCollectionRef')


# Generated at 2022-06-11 17:40:09.176657
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class TestClass(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            super(TestClass, self).__init__(
                fullname='ansible_collections.fake_ns.fake_coll',
                path_list=['/usr/share/ansible/collection_path']
            )

        def _get_candidate_paths(self, path_list):
            return [os.path.join(p, 'fake_ns', 'fake_coll') for p in path_list]

        def _get_subpackage_search_paths(self, candidate_paths):
            return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]


# Generated at 2022-06-11 17:40:16.001180
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible.utils.collection_loader import _PkgFinder
    collection_finder = _PkgFinder('ansible')
    all_loader = collection_finder.find_module('ansible_collections').load_module('ansible_collections')
    assert all_loader.is_package('ansible_collections')
    assert not all_loader.is_package('ansible_collections.somens')

# Generated at 2022-06-11 17:40:24.698137
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # sys.modules = {}
    loader = _AnsibleCollectionPkgLoaderBase(fullname='abc.abc')
    # test get_source
    assert loader.get_source(fullname='abc.abc') == None
    class fake_tree(object):
        pass
    fake_tree.rootdir = 'fake_dir_name'
    import_tree = fake_tree()
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.apple.test', path_list=[import_tree.rootdir])
    with pytest.raises(ValueError):
        loader.get_data('abcdef')
    with pytest.raises(ValueError):
        loader.get_data('abcdef/abcdef')
    # test _get_candidate_paths
    rtn = loader._get_

# Generated at 2022-06-11 17:40:35.990931
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    # Test case 1: normal case
    pkg_loader = _AnsibleCollectionPkgLoader(path=['/a/b/c'], fullname='foo.bar.baz')
    assert pkg_loader._path == ['/a/b/c'], pkg_loader._path
    assert pkg_loader._fullname == 'foo.bar.baz', pkg_loader._fullname
    assert pkg_loader._split_name == ['foo', 'bar', 'baz'], pkg_loader._split_name
    assert pkg_loader._package_to_load == 'baz', pkg_loader._package_to_load
    assert pkg_loader._parent_package_name == 'foo.bar', pkg_loader._parent_package_name

    # Test case 2: fullname is None
    pkg

# Generated at 2022-06-11 17:41:41.121647
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    from __main__ import _AnsibleCollectionPkgLoaderBase
    assert '_AnsibleCollectionPkgLoaderBase(path=None)' == repr(_AnsibleCollectionPkgLoaderBase(fullname='', path_list=None))


# this loader should load from the disk, in case there's a redirect

# Generated at 2022-06-11 17:41:48.799307
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # try a package loader
    ldr = _AnsibleCollectionPkgLoaderBase('foo.bar', ['/tmp'])
    ldr._subpackage_search_paths = ['/tmp/foo/bar']
    # package
    assert ldr.is_package('foo.bar')
    # non-package
    assert not ldr.is_package('foo.bar.baz')
    # try a module loader
    ldr = _AnsibleCollectionPkgLoaderBase('foo.bar', ['/tmp'])
    ldr._source_code_path = '/tmp/foo/bar/__init__.py'
    # package
    assert ldr.is_package('foo.bar')
    # non-package
    assert not ldr.is_package('foo.bar.baz')

# Generated at 2022-06-11 17:41:51.179954
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    _AnsibleCollectionPkgLoaderBase.get_source("ansible.module_utils.argspec_fail")

# Generated at 2022-06-11 17:42:02.248537
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    test_module_name_1 = 'ansible.builtin'
    test_module_name_2 = 'ansible.builtin.test'
    test_module_name_3 = 'ansible.test'
    test_module_name_4 = 'ansible'
    test_module_name_5 = 'ansible.builtin.ereg'

    test_load_module_1 = _AnsibleInternalRedirectLoader(test_module_name_1, path_list=_ANSIBLE_COLLECTIONS_PATH)
    test_load_module_2 = _AnsibleInternalRedirectLoader(test_module_name_2, path_list=_ANSIBLE_COLLECTIONS_PATH)

# Generated at 2022-06-11 17:42:11.966576
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    print('testing _AnsibleCollectionPkgLoaderBase.get_filename()')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.mynamespace.mycoll',
                                               path_list=['/usr/local/ansible_collections/mynamespace/mycoll/myplugin'])
    assert loader.get_filename('ansible_collections.mynamespace.mycoll') == '/usr/local/ansible_collections/mynamespace/mycoll/myplugin/__init__.py'
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.mynamespace.mycoll',
                                               path_list=['/usr/local/ansible_collections/mynamespace/mycoll/myplugin/mymodule'])

# Generated at 2022-06-11 17:42:15.579863
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    pl = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.subns.package', path_list=['/'])
    pl.get_source('ansible_collections.somens.subns.package')

# Generated at 2022-06-11 17:42:21.994726
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import collections
    import os
    import sys

    class TestLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths
        def _validate_final(self):
            pass

    def _set_sys_modules(files):
        for file in files:
            sys.modules['anstest.'+os.path.basename(file)] = ModuleType('anstest.'+os.path.basename(file))

    test_name = 'anstest'

    sys.meta_path = []
    del sys.modules['anstest']

    # Test:

# Generated at 2022-06-11 17:42:32.629218
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # Declare variables that will be used in the test
    #
    # A synthetic package, meant only to represent a namespace.
    # ansible_collections.ns_pkg
    ns_pkg_mock = MagicMock()
    # A collection directory, that contains the <collection>/ansible_collections/namespace/collection/plugins/module_utils/module_utils.py file
    # ansible_collections.somens.somerc.plugins.module_utils.module_utils.py
    #
    # os.path.join(base_module_utils_path, 'module_utils.py')
    module_utils_file_path_mock = MagicMock(return_value=os.path.join(base_module_utils_path, 'module_utils.py'))
    # A collection directory, that contains the

# Generated at 2022-06-11 17:42:37.458870
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ansible_collection_ref = AnsibleCollectionRef("collection", "subdirs", "resource", "ref_type")
    assert repr(ansible_collection_ref) == "AnsibleCollectionRef(collection='collection', subdirs='subdirs', resource='resource')"


# Generated at 2022-06-11 17:42:44.320943
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import os
    import tempfile

    # create two nested directories `parent` and `child` in the temp directory
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'parent', 'child'))
    os.mkdir(os.path.join(temp_dir, 'parent', 'child', 'extra_pkg'))
    os.mkdir(os.path.join(temp_dir, 'parent', 'child', 'extra_module'))
    os.mkdir(os.path.join(temp_dir, 'parent', 'child', 'extra_module2'))
    os.mkdir(os.path.join(temp_dir, 'parent', 'child', 'extra_module3'))

# Generated at 2022-06-11 17:44:30.488371
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():

    # generated code to create an instance of a class with attributes set to
    # the parameters passed into the class
    class _AnsibleCollectionPkgLoaderBase_load_module:
        def __init__(self, fullname, path_list=[]):
            self.fullname = fullname
            self.path_list = path_list
            self._fullname = fullname
            self._redirect_module = None
            self._split_name = fullname.split('.')
            self._rpart_name = fullname.rpartition('.')
            self._parent_package_name = self._rpart_name[0]  # eg ansible_collections for ansible_collections.somens, '' for toplevel
            self._package_to_load = self._rpart_name[2]  # eg somens for