

# Generated at 2022-06-11 17:35:43.527789
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref = AnsibleCollectionRef.from_fqcr(u'namespace.collname.resource', u'role')
    assert len(ref.subdirs) == 0
    assert ref.ref_type == 'role'
    assert ref.collection == u'namespace.collname'
    assert ref.resource == u'resource'

    # alternate spelling
    ref = AnsibleCollectionRef.from_fqcr(to_text(u'namespace.collname.resource', errors='surrogate_or_strict'), u'role')
    assert len(ref.subdirs) == 0
    assert ref.ref_type == 'role'
    assert ref.collection == u'namespace.collname'
    assert ref.resource == u'resource'

    # alternate spelling

# Generated at 2022-06-11 17:35:53.998709
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # This is a test for:
    #   class _AnsibleCollectionPkgLoaderBase
    #       def __repr__(self):
    #           return '{0}(path={1})'.format(self.__class__.__name__, self._subpackage_search_paths or self._source_code_path)

    # Arrange
    class Loader(object):
        # Arrange
        #   class Loader(object):
        #       def __init__(self, path):
        #           self.path = path

        # Act
        def __init__(self, path):
            #   class Loader(object):
            #       def __init__(self, path):
            #           self.path = path
            self.path = path

        # Arrange
        #   class Loader(object):


# Generated at 2022-06-11 17:35:56.425556
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    ref = 'ns.coll.res'
    ref_type = 'module'
    assert AnsibleCollectionRef.is_valid_fqcr(ref, ref_type) is True


# Generated at 2022-06-11 17:36:08.077032
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    import sys
    import os
    import six

    # Setup the test environment
    fake_ansible_filename = 'test.py'
    fake_ansible_path = 'test_data/test_files'
    fake_ansible_fullpath = os.path.join(fake_ansible_path, fake_ansible_filename)
    fake_ansible_namespace = 'namespace'
    fake_ansible_collections_path = 'test_data/ansible_collections'
    fake_collection_name = 'collection_name'
    fake_collection_name2 = 'collection_name2'
    expected_fullname = 'ansible_collections.namespace.collection_name'

    # Create a fake script inside the fake ansible path
    os.makedirs(fake_ansible_path)

# Generated at 2022-06-11 17:36:15.434618
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    ansible_collections = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test', [os.path.join(ansible_collections, 'collections')])
    module = loader.load_module('ansible_collections.test')
    assert module.__name__ == 'ansible_collections.test'
    assert module.foo == 'bar'



# Generated at 2022-06-11 17:36:22.698028
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    # empty path list
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.any_ns')
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths is None
    assert loader._source_code_path is None
    assert loader._decoded_source is None
    assert loader._compiled_code is None
    assert loader._fullname == 'ansible_collections.any_ns'
    assert loader._split_name == ['ansible_collections', 'any_ns']
    assert loader._rpart_name == ('ansible_collections', '.', 'any_ns')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'any_ns'

    # empty path list, with existing package


# Generated at 2022-06-11 17:36:32.756301
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    test_path1 = '/path/to/weird/collect/file.py'
    test_path2 = '/path/to/weird/collect/file2.py'
    test_path3 = '/path/to/weird/collect/file3.py'

    test_path_list1 = [test_path1, test_path2, test_path3]
    test_path_list2 = [test_path1]
    test_path_list3 = []

    loader1 = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.weird.collect.file', path_list=test_path_list1)

    assert loader1.__repr__() == '_AnsibleCollectionPkgLoaderBase(path=/path/to/weird/collect/file)'

    loader2 = _An

# Generated at 2022-06-11 17:36:41.573731
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ansible')
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._package_to_load == 'ansible'
    assert loader._split_name == ['ansible_collections', 'ansible']
    assert loader._rpart_name == ('ansible_collections.', 'ansible', '')
    assert loader._candidate_paths == []
    assert loader._subpackage_search_paths == None
    assert loader._validate_final() == None
# End unit test for constructor of class _AnsibleCollectionNSPkgLoader

# Implements Ansible's custom namespace package support.
# The ansible_collections package and one level down (collections namespaces) are Python namespace packages
# that search across all configured

# Generated at 2022-06-11 17:36:44.238210
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    # __repr__ should create a repr string with class name and path
    loader = _AnsibleCollectionPkgLoaderBase('name', path_list=['/path'])
    assert '_AnsibleCollectionPkgLoaderBase(path=/path)' == repr(loader)



# Generated at 2022-06-11 17:36:49.712143
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    legacy_plugin_direction = dict()
    legacy_plugin_direction['action_plugins'] = 'action'
    legacy_plugin_direction['connection_plugins'] = 'connection'
    legacy_plugin_direction['lookup_plugins'] = 'lookup'
    legacy_plugin_direction['callback_plugins'] = 'callback'
    legacy_plugin_direction['filter_plugins'] = 'filter'
    legacy_plugin_direction['test_plugins'] = 'test'
    legacy_plugin_direction['inventory_plugins'] = 'inventory'
    legacy_plugin_direction['library'] = 'modules'
    legacy_plugin_direction['vars_plugins'] = 'vars'
    legacy_plugin_direction['terminal_plugins'] = 'terminal'
    legacy_plugin_direction['become_plugins'] = 'become'

# Generated at 2022-06-11 17:37:32.529842
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    # this loader does not work for any other imports
    assert _AnsibleInternalRedirectLoader('test', None) is None
    assert _AnsibleInternalRedirectLoader('test.test', None) is None
    assert _AnsibleInternalRedirectLoader('ansible.test', None) is None
    assert _AnsibleInternalRedirectLoader('ansible.builtin', None) is None
    assert _AnsibleInternalRedirectLoader('ansible.builtin.test', None) is None
    assert _AnsibleInternalRedirectLoader('ansible.builtin.modules', None) is None

    path_hook_fake_path = [b'/foo/bar']

    # Ansible module loader will always redirect ansible.builtin.modules.xxx

# Generated at 2022-06-11 17:37:43.138466
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef

# Generated at 2022-06-11 17:37:50.417499
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    results = {}
    results['action_plugins'] = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    results['shell_plugins'] = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('shell_plugins')
    results['library'] = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    expected = {'action_plugins': 'action', 'shell_plugins': 'shell', 'library': 'modules'}
    assert results == expected, "Mapping of plugin dir name to plugin type failed"

# Generated at 2022-06-11 17:37:58.421314
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # We test every class method.
    # Exception raised if invalid reference.
    with pytest.raises(ValueError):
        AnsibleCollectionRef.try_parse_fqcr("Ansible.Collecction.Fail", None)

    # We create a new AnsibleCollectionRef.
    assert AnsibleCollectionRef.try_parse_fqcr("Ansible.Collecction.Module", "module") == AnsibleCollectionRef(
        "Ansible.Collecction", "", "Module", "module"
    )
    # We test the to_string class method.

# Generated at 2022-06-11 17:38:02.408073
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.utils.collection_loader._any_v1 import _AnsibleCollectionPkgLoaderBase

    loader = _AnsibleCollectionPkgLoaderBase('ns', ['/I/M/A/PATH'])
    assert loader.get_filename('ns') == '/I/M/A/PATH/__synthetic__'

# Generated at 2022-06-11 17:38:08.765749
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    parent_package_name = 'ansible_collections'
    package_name = 'my_pkg'
    package_fullname = parent_package_name + '.' + package_name
    module_name = 'my_module'
    module_fullname = package_fullname + '.' + module_name
    package_path = '/path'
    module_path = os.path.join(package_path, module_name + '.py')

    # Setup test data
    # We will create a 'my_module.py' file with a simple content to compile in
    text = u'import os'
    with open(to_bytes(module_path), 'w') as f:
        f.write(text)

    # Exercise
    test_loader = _AnsibleCollectionPkgLoaderBase(module_fullname, [package_path])

# Generated at 2022-06-11 17:38:17.800669
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible_collections.ansible.builtin import _AnsibleCollectionPkgLoaderBase
    import tempfile
    import os
    import random
    import string
    import shutil
    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))

    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'test'))
    os.mkdir(os.path.join(tmpdir, 'test', 'sub'))
    test_str = randomString(10)

# Generated at 2022-06-11 17:38:26.779083
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    collection_finder = _AnsibleCollectionFinder(paths=None, scan_sys_paths=True)
    _ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, '/tmp')
    assert _ansible_path_hook_finder.find_module("ansible_collections.ns1.coll1.plugins.module_utils.foo") == AnsibleCollectionLoader


# Implements a Python importer that allows us to redirect to other collection content based on a configuration file.
# This is used to redirect the `ansible` package to the collection content when the correct context is detected.
#
# This is not a public API, it is only intended to be used by Ansible.
#
# It is not safe to use this loader directly,

# Generated at 2022-06-11 17:38:32.616659
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # Mocking _meta_yml_to_dict method
    mock_meta_yml_to_dict = MagicMock()
    # Mocking arbitrary return value of _meta_yml_to_dict
    mock_meta_yml_to_dict.return_value = 'Mocked data'
    # Mocking AnsibleCollectionConfig.on_collection_load.fire with a MagicMock
    mock_on_collection_load = MagicMock()
    # Mocking arbitrary return value of AnsibleCollectionConfig.on_collection_load.fire
    mock_on_collection_load.return_value = 'Mocked data'
    # Mocking the import_module method of module ansible.utils.collection_loader
    mock_import_module = MagicMock()
    # Mocking arbitrary return value of import_module

# Generated at 2022-06-11 17:38:45.607528
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    cl = _AnsibleCollectionPkgLoader('collections.ns1.pkg1', '/some/collection/root')
    _meta_yml_to_dict = cl._meta_yml_to_dict = lambda x,y: {}
    AnsibleCollectionConfig.on_collection_load = isinstance(cl, dict)
    with mock.patch.object(cl, 'get_data') as mock_get_data:
        mock_get_data.return_value = ''
        with pytest.raises(ValueError, match='ansible.utils.collection_loader._meta_yml_to_dict is not set'):
            cl.load_module('collections.ns1.pkg1')

    _meta_yml_to_dict = cl._meta_yml_to_dict = lambda x, y: {}
    Ansible

# Generated at 2022-06-11 17:39:24.131379
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _meta_yml_to_dict
    def _meta_yml_to_dict(string, source):
        return {'plugin_routing':{'action': {'test_plugin': {'redirect': 'test_plugin_redirect'},
                                             'test_plugin_no_redirect': {}}}}
    _AnsibleCollectionPkgLoader._meta_yml_to_dict = _meta_yml_to_dict
    meta_dict = _AnsibleCollectionPkgLoader('', ['', 'ansible_collections', 'namespace1', 'collection1'])._canonicalize_meta({})
    assert not meta_dict
    meta_dict = _AnsibleCollectionP

# Generated at 2022-06-11 17:39:25.851889
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import sys
    import io
    from io import FileIO
    from importlib._bootstrap_external import _Ansib

# Generated at 2022-06-11 17:39:33.937662
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.resource', u'module').fqcr == u'ns.coll.subdir1.resource'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'module').fqcr == u'ns.coll.resource'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.resource', u'role').fqcr == u'ns.coll.resource'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.rolename', u'role').fqcr == u'ns.coll.rolename'
    assert AnsibleCollectionRef.from_fqcr(u'ns.coll.playbook.yml', u'playbook').fqcr == u

# Generated at 2022-06-11 17:39:42.345989
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref_type = 'module'
    ref = 'test.test.testmodule'
    result = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    expected = AnsibleCollectionRef('test.test', '', 'testmodule', 'module')
    assert result == expected

    ref_type = 'module'
    ref = 'test.test.testdir1.testdir2.testmodule'
    result = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    expected = AnsibleCollectionRef('test.test', 'testdir1.testdir2', 'testmodule', 'module')
    assert result == expected

    ref_type = 'role'
    ref = 'test.test.testrole'
    result = AnsibleCollectionRef.from_fqcr(ref, ref_type)
    expected

# Generated at 2022-06-11 17:39:50.291234
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():

    # Test cases:
    # 1. Test case where there is a package search path, a sub class which overrides the _synthetic_filename function
    # 2. Test case where there is a package search path, a sub class which does not override the _synthetic_filename function
    # 3. Test case where there is no package search path, a sub class which overrides the _synthetic_filename function
    # 4. Test case where there is no package search path, a sub class which does not override the _synthetic_filename function

    # Test case where there is a package search path, a sub class which overrides the _synthetic_filename function
    target_class = _AnsibleCollectionPkgLoaderBase
    target_class._subpackage_search_paths = ['/collection_root/collection/namespace/package/']
    target_class._

# Generated at 2022-06-11 17:39:56.473104
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = lambda x: {}
    ACPL = _AnsibleCollectionPkgLoader(is_spam=True)
    ACPL.load_module(fullname='ansible.builtin.spam')
    assert ACPL.load_module(fullname='ansible.builtin.spam').__loader__.load_module(fullname='ansible.builtin.spam')
    assert ACPL.load_module(fullname='ansible.builtin.spam').__loader__.load_module(fullname='ansible.builtin.spam', is_spam=False).__loader__.load_module(fullname='ansible.builtin.spam')



# Generated at 2022-06-11 17:40:04.040715
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    try:
        AnsibleCollectionRef.from_fqcr('myns.mycoll.myresource', 'role')
    except:
        assert(False)
    else:
        assert(True)

    try:
        AnsibleCollectionRef.from_fqcr('myns.mycoll.mysubdir.myresource', 'role')
    except:
        assert(False)
    else:
        assert(True)
    
    try:
        AnsibleCollectionRef.from_fqcr('myns.mycoll.myresource', 'modules')
    except:
        assert(False)
    else:
        assert(True)

    try:
        AnsibleCollectionRef.from_fqcr('myns.mycoll.mysubdir.myresource', 'modules')
    except:
        assert(False)

# Generated at 2022-06-11 17:40:06.290010
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    try:
        _AnsibleCollectionPkgLoaderBase().get_data(None)
    except ValueError:
        pass
    assert 1 == 1


# Generated at 2022-06-11 17:40:18.357681
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Test case where no fqcr is provided
    try:
        x = AnsibleCollectionRef.from_fqcr('', 'module')
        assert False, 'A ValueError should have been raised for missing fqcr arg'
    except ValueError:
        pass

    # No reference type is provided
    try:
        x = AnsibleCollectionRef.from_fqcr('ns.coll.resource', '')
        assert False, 'A ValueError should have been raised for missing reference type'
    except ValueError:
        pass

    # Reference is not a fully qualified collection reference
    try:
        x = AnsibleCollectionRef.from_fqcr('ns.coll', 'module')
        assert False, 'A ValueError should have been raised for an invalid fully qualified collection reference'
    except ValueError:
        pass

    # Test case where ref

# Generated at 2022-06-11 17:40:25.799910
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    param_fqcr = ['ns.coll.resource', 'ns.coll.playbook', 'ns.coll.role', 'ns.coll.subdir1.resource', 'ns.coll.subdir1.playbook', 'ns.coll.subdir1.role']
    param_ref_type = [None, 'module', 'doc_fragment', 'action', 'become', 'cache', 'callback', 'cliconf', 'connection', 'filter', 'httpapi', 'inventory', 'lookup', 'module_utils', 'modules', 'netconf', 'shell', 'strategy', 'terminal', 'test', 'vars', 'role', 'playbook']

# Generated at 2022-06-11 17:40:51.363948
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.builtin', ['ansible_collections/ansible/builtin/library'])
    assert loader is not None


# Generated at 2022-06-11 17:41:01.807551
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class TestArgs(AnsibleCollectionConfig):
        def __init__(self):
            super(TestArgs, self).__init__()
            self.refresh()

        def refresh(self):
            self.COLLECTIONS_PATHS = [os.path.join('data', 'collections')]
            self.ansible_pkg_name = 'ansible'

    t = TestArgs()


# Generated at 2022-06-11 17:41:12.841077
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    print('Testing method get_filename of class _AnsibleCollectionPkgLoaderBase')
    source_code_name = '__init__.py'
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible.netcommon', path_list=['/tmp/ansible_collections/ansible/netcommon'])
    assert loader.get_filename(fullname='ansible.netcommon') == '/tmp/ansible_collections/ansible/netcommon/__init__.py'
    assert not loader.get_source('ansible.netcommon')
    with open(source_code_name, 'w') as source_file:
        source_file.write('#!/usr/bin/python3\n')
    assert loader.get_source('ansible.netcommon')

# Generated at 2022-06-11 17:41:22.479618
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Unit test for method try_parse_fqcr of class AnsibleCollectionRef
    # Successfully parsed with type as role
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', ref_type='role')
    # Successfully parsed with type as module
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', ref_type='module')
    # Successfully parsed with type as module very long reference

# Generated at 2022-06-11 17:41:33.624991
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    #
    import unittest
    import ansible.utils.collection_loader as cl
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader as acpl
    from ansible.utils.collection_loader import _AnsibleCollectionImport
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRefList
    from ansible.utils.collection_loader import AnsibleCollectionRefProp
    from ansible.utils.collection_loader import AnsibleCollectionRefProps
    from ansible.utils.collection_loader import AnsibleCollectionRefListProp
    from ansible.utils.collection_loader import _meta_yml_to_dict
    print('#' * 80)


# Generated at 2022-06-11 17:41:40.495777
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr('ns.coll.some_mod', 'module') == AnsibleCollectionRef('ns.coll', u'', 'some_mod', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.some_mod.py', 'module') == AnsibleCollectionRef('ns.coll', u'', 'some_mod', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.some_mod', 'playbook') == AnsibleCollectionRef('ns.coll', u'', 'some_mod', 'playbook')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.some_mod.yml', 'playbook') == AnsibleCollectionRef('ns.coll', u'', 'some_mod', 'playbook')
    assert AnsibleCollectionRef

# Generated at 2022-06-11 17:41:48.518534
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader_vars = []

    class TestLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            loader_vars.append(self._fullname)

    for testcase in (
        # Test Case with no args, expect exception
        {},
        # Test Case with fullname
        {'fullname': 'ansible_collections.my_ns.my_coll.package'}
    ):
        loader = TestLoader(**testcase)
        try:
            if testcase:
                loader.is_package('ansible_collections.my_ns.my_coll.package')
            else:
                loader.is_package('ansible_collections.my_ns.my_coll.package')
        except Exception as ex:
            assert isinstance(ex, ValueError)


#

# Generated at 2022-06-11 17:41:59.837423
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    original_sys_modules = sys.modules.copy()

# Generated at 2022-06-11 17:42:05.415267
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    test_fqcr = 'collection.subdir1.subdir2.resource'
    test_ref_type = 'module'
    test_AnsibleCollectionRef = AnsibleCollectionRef.from_fqcr(test_fqcr, test_ref_type)
    expected_output = "AnsibleCollectionRef(collection='collection', subdirs='subdir1.subdir2', resource='resource')"
    assert str(test_AnsibleCollectionRef.__repr__()) == expected_output

# Generated at 2022-06-11 17:42:14.028449
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    with tempfile.TemporaryDirectory() as resource_dir:
        pkg_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible', path_list=[resource_dir])
        subpackage_path = os.path.join(resource_dir, 'ansible', 'module_utils', 'basic')
        os.makedirs(subpackage_path)
        open(os.path.join(subpackage_path, '__init__.py'), 'w+')
        open(os.path.join(subpackage_path, 'basic.py'), 'w+')
        assert sorted(['module_utils.basic'] ) == sorted([x[1] for x in pkg_loader.iter_modules(['ansible.module_utils'])])


# Generated at 2022-06-11 17:42:49.267863
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    acr = AnsibleCollectionRef.from_fqcr(u'a.b.c', u'module')
    assert acr.collection == u'a.b'
    assert acr.subdirs == u''
    assert acr.resource == u'c'
    assert acr.ref_type == u'module'
    assert acr.fqcr == u'a.b.c'
    assert acr.n_python_package_name == u'ansible_collections.a.b.plugins.module.c'
    assert acr.n_python_collection_package_name == u'ansible_collections.a.b'

    acr = AnsibleCollectionRef.from_fqcr(u'a.b.c', u'role')

# Generated at 2022-06-11 17:42:58.444332
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    testdir = os.path.dirname(os.path.realpath(__file__))
    testdir = os.path.join(testdir, 'test_data', 'ansible_collections', 'test_ns', 'test_coll')
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test_ns.test_coll', path_list=[testdir])
    modules = loader.iter_modules(prefix='')
    assert next(modules) == ('', False, None)
    assert next(modules) == ('namespace_package_empty', False, None)
    assert next(modules) == ('directory_resource', True, None)
    assert next(modules) == ('namespace_package_populated.in_populated', True, None)

# Generated at 2022-06-11 17:43:04.231052
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class _AnsibleCollectionPkgLoaderBase_sub_class(_AnsibleCollectionPkgLoaderBase):
        def get_filename(self, fullname):
            return '/some/file/path'
        def get_source(self, fullname):
            return 'something()'
    loader = _AnsibleCollectionPkgLoaderBase_sub_class('foo.bar')
    assert loader.get_code('foo.bar')

# Generated at 2022-06-11 17:43:12.378668
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr("ns.coll.subdir1.subdir2.resource", ref_type="module") == AnsibleCollectionRef("ns.coll", "subdir1.subdir2", "resource", ref_type="module")
    assert AnsibleCollectionRef.from_fqcr("ns.coll.subdir1.subdir2.resource", ref_type="role") == AnsibleCollectionRef("ns.coll", "subdir1.subdir2", "resource", ref_type="role")


# Generated at 2022-06-11 17:43:22.559253
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.subdir1.resource', 'module') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'role') is not None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename', 'module') is None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename.yml', 'role') is None
    assert AnsibleCollectionRef.try_parse_fqcr('ns.coll.rolename.yml', 'playbook') is not None



# Generated at 2022-06-11 17:43:34.530691
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    fullname = 'ansible_collections.ns.module'
    path_list = ['/var/lib/awx/lib/ansible_collections/ns/module/docs','/var/lib/awx/lib/ansible_collections/ns/module/examples','/var/lib/awx/lib/ansible_collections/ns/module/library','/var/lib/awx/lib/ansible_collections/ns/module/module_utils']
    cls = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    result = cls.__repr__()

# Generated at 2022-06-11 17:43:47.018692
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:43:57.720941
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible.collections.ansible_collections.space.spacepkg.baz import bar
    from ansible.collections.ansible_collections.space.spacepkg import baz
    from ansible.collections.ansible_collections.space import spacepkg
    test_q = Queue()
    test_q.put([])
    methods_order = []
    methods_order.append(inspect.stack()[0][3])

    test_obj = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.space.spacepkg')
    is_method = ismethod(test_obj.iter_modules)
    methods_order.append(inspect.stack()[0][3])
    if is_method == True:
        test_q.get()
        test

# Generated at 2022-06-11 17:44:08.340660
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    collection_name_list = [
        'a.a',
        'a.a1',
        'a1.b1',
        'a.a_a',
        'a_a.a_a',
        'a1.b1_a1',
        'a.a.',
        '.a.a',
        'a.a.a',
        'a-a.b-a1',
        'a+a.b+a1',
        '1.a',
        'a.1',
        'a b.a',
        'a.a b',
        'a.a.a',
        'a.a$a',
        'a a.a',
        'a.a a',
        'a$a.a',
        'a.a$a'
    ]

   

# Generated at 2022-06-11 17:44:11.881677
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    import ansible_collections.somens.subns.subsubns
    loader = ansible_collections.somens.subns.subsubns.__loader__
    package_name = 'ansible_collections.somens.subns.subsubns'
    assert loader.is_package(package_name)