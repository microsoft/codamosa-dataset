

# Generated at 2022-06-11 17:35:58.725859
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import pkgutil, ModuleUtil
    if not hasattr(ModuleUtil, '_AnsibleCollectionPkgLoaderBase'):
        pytest.skip('ModuleUtil._AnsibleCollectionPkgLoaderBase is not available')
    apglb = ModuleUtil._AnsibleCollectionPkgLoaderBase('collections.some.module', ['/etc/ansible/collections'])
    expected = '/etc/ansible/collections/some/module.py'
    assert apglb.get_filename('collections.some.module') == expected
    apglb = ModuleUtil._AnsibleCollectionPkgLoaderBase('collections.some.package', ['/etc/ansible/collections'])

# Generated at 2022-06-11 17:36:03.900854
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from unittest.mock import Mock

    # test with empty fullname
    finder = _AnsiblePathHookFinder(Mock(), '_')
    assert finder.find_module('') is None

    # test with fullname starting with 'ansible_collections' and path is None
    finder = _AnsiblePathHookFinder(Mock(), '_')
    assert finder.find_module('ansible_collections.some.collection') is None

    # test with fullname starting with 'ansible_collections' and path is not None
    finder = _AnsiblePathHookFinder(Mock(), '_')
    assert finder.find_module('ansible_collections.some.collection', path=['_']) is None

    # test with fullname not starting with 'ansible

# Generated at 2022-06-11 17:36:13.001432
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():

    # test valid and invalid collections
    valid_collections=["ns.col", "ns1.col1", "myns.mycollection", "my_ns.my_collection"]
    invalid_collections=["col", "ns..col", "ns.col.", ".col", "ns1.col1.ns2.col2"]

    for c in valid_collections:
        acr = AnsibleCollectionRef(c, None, "test", "module")
        assert acr.collection == c

    for c in invalid_collections:
        try:
            acr = AnsibleCollectionRef(c, None, "test", "module")
            raise Exception("Should have thrown a ValueError.")
        except ValueError:
            pass


# Generated at 2022-06-11 17:36:21.305991
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # create a file under a test directory with a simple JSON payload
    content_path = os.path.join(test_data_loader.TEST_FIXTURE_PATH, 'test_resource.json')
    test_data_loader.makedirs(os.path.dirname(content_path), exist_ok=True)
    with open(content_path, 'w') as f:
        f.write(u'{"msg": "hello"}')

    # instantiate the loader, add our test fixture directory as the only path it can find things in
    test_loader = _AnsibleCollectionPkgLoaderBase('test_resource',
        path_list=[test_data_loader.TEST_FIXTURE_PATH])

    # get the source code for all of our expected paths

# Generated at 2022-06-11 17:36:23.698622
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    print(_AnsibleCollectionPkgLoaderBase.__repr__(object))

# Generated at 2022-06-11 17:36:33.315196
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    """Unit tests for class _AnsiblePathHookFinder
    """
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._install()

    pathctx = "/foo/bar/ansible_collections/ns"
    finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    # pathctx is normalized by init method
    assert finder._pathctx == os.path.normpath(pathctx), "pathctx was not normalized"
    assert finder._collection_finder == collection_finder, "collection_finder is not matching"

    # the _file_finder should not be defined
    assert not hasattr(finder, '_file_finder'), "the _file_finder should not be defined"

    #_filefinder_path_hook should be found
    assert finder._filefinder_path

# Generated at 2022-06-11 17:36:35.789985
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    im = _AnsibleInternalRedirectLoader("ansible.builtin.bcrypt_utils", None)
    assert im



# Generated at 2022-06-11 17:36:43.421075
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.collection import AnsibleCollectionConfig
    AnsibleCollectionConfig.configured = False
    AnsibleCollectionConfig('', [])
    AnsibleCollectionConfig.configured = True

    class MockModule(object):
        def __init__(self, name):
            self.name = name
            self.__file__ = os.path.join(AnsibleCollectionConfig.config.collection_paths[0], 'ansible_collections/foo/bar', name + '.py')
            self.__path__ = []
    ansible = MockModule('ansible')
    collections = MockModule('collections')
    collections.__path__ = [os.path.join(AnsibleCollectionConfig.config.collection_paths[0], 'ansible_collections')]
    ansible.collections = collections

# Generated at 2022-06-11 17:36:47.632065
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():

    # Case: ImportError - is returned when fullname is not found
    def execute(self, fullname, path=None):
        split_name = fullname.split('.')
        toplevel_pkg = split_name[0]
        if toplevel_pkg == 'ansible_collections':

            raise ImportError()

        else:
            if PY3:
                if not self._file_finder:
                    try:
                        self._file_finder = _AnsiblePathHookFinder._filefinder_path_hook(self._pathctx)
                    except ImportError:
                        return None

                spec = self._file_finder.find_spec(fullname)
                if not spec:
                    return None
                return spec.loader
            else:
                return pkgutil.ImpImporter(self._pathctx).find_module

# Generated at 2022-06-11 17:36:52.012150
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase('my_fullname')
    assert not loader.is_package('my_fullname')
    loader._subpackage_search_paths = ['path1', 'path2']
    assert not loader.is_package('not_my_fullname')
    assert loader.is_package('my_fullname')


# Generated at 2022-06-11 17:37:50.205313
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    dummy_module = "dummy_module"
    ansible_collection_pkg_loader_base = _AnsibleCollectionPkgLoaderBase(dummy_module)
    # Creating empty module if it's not present in sys.modules otherwise return the module.
    with ansible_collection_pkg_loader_base._new_or_existing_module(dummy_module, __file__=ansible_collection_pkg_loader_base.get_filename(dummy_module)) as module:
        assert module.__file__ == ansible_collection_pkg_loader_base.get_filename(dummy_module)
        assert module.__name__ == dummy_module
        sys.modules.pop(dummy_module)



# Generated at 2022-06-11 17:37:57.927043
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock
    filename = Mock()
    source_code = Mock()
    loader = _AnsibleCollectionPkgLoaderBase(None, filename)
    loader._get_source = Mock(return_value=source_code)
    loader._compile = Mock()

    loader._AnsibleCollectionPkgLoaderBase__get_code(filename)

    loader._get_source.assert_called_once_with(filename)
    loader._compile.assert_called_once_with(source=source_code, filename=filename, mode='exec', flags=0, dont_inherit=True)
# END OF Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase


# Generated at 2022-06-11 17:38:06.006676
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # test valid arguments
    assert AnsibleCollectionRef('ns.collection', None, 'resource', 'module')
    assert AnsibleCollectionRef('ns.collection', 'subdir1.subdir2', 'resource', 'role')
    assert AnsibleCollectionRef(u'ns.collection', None, u'resource', u'module')
    assert AnsibleCollectionRef(u'ns.collection', u'subdir1.subdir2', u'resource', u'role')

    # test invalid collection names

# Generated at 2022-06-11 17:38:16.348215
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from tempfile import TemporaryDirectory
    from tempfile import mkstemp
    import os
    import ansible_collections
    import sys

    class TestModuleLoader(object):
        def module_repr(self, module):
            return '<module {name} from {path}>'.format(name=module[0], path=module[1])

        def __str__(self):
            return self.__class__.__name__

        def get_loader(self, name):
            return self

    def strip_path(path):
        return path.replace(f"{os.path.sep}__pycache__{os.path.sep}", os.path.sep)

    # WARNING: this test function currently assumes that all_namespace_packages is 1,
    #          and will fail if you set it to 0 in any

# Generated at 2022-06-11 17:38:24.475629
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import os
    import os.path
    import tempfile
    import stat
    def _prep_dir(dir_name):
        if os.path.exists(dir_name):
            for root, dirs, files in os.walk(dir_name):
                for dir in dirs:
                    os.chmod(os.path.join(root, dir), stat.S_IRWXU)
                for file in files:
                    os.chmod(os.path.join(root, file), stat.S_IRWXU)
            shutil.rmtree(dir_name)
        os.mkdir(dir_name)
    r2_dir = tempfile.mkdtemp()
    r1_dir = tempfile.mkdtemp()
    _prep_dir(r2_dir)
    p2 = os

# Generated at 2022-06-11 17:38:35.190599
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    test_pkg = 'ansible_collections.ns'
    test_loader = _AnsibleCollectionPkgLoaderBase(test_pkg, ['/path/to/dir'])
    code = test_loader.get_filename(test_pkg)
    #assert code == '/path/to/dir/ns/__synthetic__', 'get_filename internal error'
    assert code == '/path/to/dir/ns/__init__.py', 'get_filename internal error'

    test_module = 'ansible_collections.ns.module'
    test_loader = _AnsibleCollectionPkgLoaderBase(test_module, ['/path/to/dir'])
    code = test_loader.get_filename(test_module)

# Generated at 2022-06-11 17:38:47.486108
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    file_mock = MagicMock(name='file_mock')
    open_mock = MagicMock(name='open_mock')
    open_mock.return_value = file_mock
    with patch('builtins.open', open_mock):
        with patch('ansible.utils.collection_loader.to_bytes', lambda x: x):
            with patch.object(ModuleType, '__init__', lambda *args, **kwargs: None):
                loader = _AnsibleCollectionPkgLoaderBase('my.pkg', path_list=['/path/to/my/pkg', '/other/path'])
            # Make sure the file is read as binary
            assert_equal(file_mock.read.call_args[0][0], 'rb')
            # Make sure the file is closed
            assert_

# Generated at 2022-06-11 17:38:57.679005
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:39:05.930459
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # valid FQCR
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subdir2.resource', 'module'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'module'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.resource', 'module'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'action'))
    assert(AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir1.subdir2.resource', 'lookup'))

# Generated at 2022-06-11 17:39:17.397997
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.acme.test')
    assert  loader.get_filename('ansible_collections.acme.test')=='<ansible_synthetic_collection_package>'
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.acme.test',path_list=['/home/junaid/work/ansible/ansible/ansible_collections/acme/test'])
    assert  loader.get_filename('ansible_collections.acme.test')=='/home/junaid/work/ansible/ansible/ansible_collections/acme/test/__synthetic__'

# Generated at 2022-06-11 17:40:04.509269
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pkg_collection = 'test_col1'
    pkg_name = 'test_pkg1'
    pkg_version = 'test_version1'
    pkg_namespace = 'testns'

    pkgs_dir = tempfile.mkdtemp(dir='/tmp')
    test_dir = os.path.join(pkgs_dir, pkg_collection, pkg_namespace, pkg_name, pkg_version)
    os.makedirs(test_dir)

    test_mod = 'test'
    test_mod_code = 'test = "test"'
    test_mod_file_path = os.path.join(test_dir, test_mod + ".py")

# Generated at 2022-06-11 17:40:08.593655
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    m = _AnsibleCollectionPkgLoaderBase("ansible_collections.my.collection", [
        "/root/ansible_collections/my/collection"])
    assert m.get_data("/root/ansible_collections/my/collection/mypackage/__init__.py") == b''



# Generated at 2022-06-11 17:40:13.966290
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create a file in the directory
    filepath = os.path.join(tmp_dir, 'file.txt')
    with open(filepath, 'w') as f:
        f.write('some text')

    # create a subdirectory in the directory
    subdir = os.path.join(tmp_dir, 'subdir')
    os.mkdir(subdir)

    # create a file in the subdirectory
    subfilepath = os.path.join(subdir, 'subfile.txt')
    with open(subfilepath, 'w') as f:
        f.write('some more text')

    # create a sibling directory in the directory
    siblingdir = os.path.join(tmp_dir, 'siblingdir')
    os

# Generated at 2022-06-11 17:40:23.831120
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():

    from ansible_collections.my.mycollection.plugins.module_utils import myutils

    name = 'ansible_collections.my.mycollection.plugins.module_utils.myutils'
    l = _AnsibleCollectionPkgLoaderBase(name, [os.path.join(os.path.dirname(myutils.__file__), '..')])
    # test __file__ case
    assert l.get_data(myutils.__file__) == str(myutils).encode('utf-8')
    # test __init__.py case
    modpath = os.path.dirname(myutils.__file__)
    assert l.get_data(os.path.join(modpath, '__init__.py')) == b''
    # test __synthetic__ case
    assert l.get_

# Generated at 2022-06-11 17:40:33.251378
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    pkg_loader = _AnsibleCollectionPkgLoaderBase('/path/to/dir/__init__.py')
    assert pkg_loader.get_data('/path/to/dir/__init__.py') is None
    assert pkg_loader.get_data('/path/to/dir/fake.py') is None
    assert pkg_loader.get_data('/path/to/dir/__init__.py') == ''
    assert pkg_loader.get_data('/path/to/dir/fake.py') == '/path/to/dir/fake.py'


# Generated at 2022-06-11 17:40:41.767987
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import tempfile
    from . import AnsiblePathHookFinder
    from . import AnsibleFileFinder
    from . import AnsibleFileLoader
    from . import AnsibleCollectionPkgLoaderBase
    from . import AnsibleCollectionFileLoader
    from . import AnsibleCollectionPkgLoader
    from . import AnsibleCollectionPkgSpecFinder
    from . import AnsibleCollectionPkgSpecLoader
    from . import AnsiblePathHookFinder
    from . import AnsibleImportError
    from . import AnsibleModuleUtils
    from . import AnsiblePackageUtils

    mock_module = 'mock_module'
    mock_fullname = 'mock_fullname'
    mock_path = '/mock/path/name'
    mock_package = 'mock_package'
    mock_name = 'mock_name'


# Generated at 2022-06-11 17:40:48.161098
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    """
    Test for the correct behaviour of is_package for class
    _AnsibleCollectionPkgLoaderBase.

    It should be loading the object and assert the correct
    behavior of the method.
    """
    full_name = 'my_fullname'
    loader = _AnsibleCollectionPkgLoaderBase(full_name)
    assert loader.is_package(full_name) is False
    loader._subpackage_search_paths = ['/data']
    assert loader.is_package(full_name) is True
    with pytest.raises(ValueError):
        loader.is_package('other_fullname')



# Generated at 2022-06-11 17:40:53.761620
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import doctest
    import sys

    class AnsibleCollectionFinder(object):
        def find_module(self, fullname, path=None):
            if fullname == 'ansible_collections.some.ns.some_collection.some_plugin':
                return self
            return None

    def load_module(self, fullname):
        return self

    # this is for py2 compat; as of py3, loaders do not have to be callable
    AnsibleCollectionFinder.__call__ = load_module

    class AnsibleCollectionPathHookFinder(object):
        # pylint: disable=redefined-outer-name
        def __init__(self, collection_finder, path):
            self._collection_finder = collection_finder
            self._path = to_native(path)


# Generated at 2022-06-11 17:40:54.770106
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    assert True


# Generated at 2022-06-11 17:41:00.632977
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Given
    import ansible.plugins.action
    
    redirect_loader = _AnsibleInternalRedirectLoader('ansible.plugins.action', path_list=None)
    # When
    loaded_module = redirect_loader.load_module(fullname='ansible.plugins.action')
    # Then
    assert(loaded_module == ansible.plugins.action)
test__AnsibleInternalRedirectLoader_load_module()



# Generated at 2022-06-11 17:42:15.292830
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert not AnsibleCollectionRef.is_valid_fqcr(u'')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'placeholder.coll')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'short.name')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'a.b.c.d.e.f')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'a.b.c.d.e.f.g')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'my.coll.role')
    assert not AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.bogus_type')
    assert not AnsibleCollectionRef.is_valid_f

# Generated at 2022-06-11 17:42:19.687159
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Every module needs a name
    fullname = 'test'
    # Every module needs a path
    path_list = []
    a = _AnsibleInternalRedirectLoader(fullname, path_list)
    output = a.load_module(fullname)
    assert output is not None, 'test__AnsibleInternalRedirectLoader_load_module has failed!'


_redirect_exception_class = None


# internal helper for generating an ImportError for a not

# Generated at 2022-06-11 17:42:25.225191
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    path = '/home/centos/.ansible/collections/ansible_collections/test_org/test_collection'
    top_level_module = 'ansible_collections.test_org.test_collection'

    loader = _AnsibleCollectionPkgLoaderBase(top_level_module, path_list=[path])
    assert loader.get_filename(top_level_module) == path



# Generated at 2022-06-11 17:42:36.624204
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.mod') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.mod') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subsubdir.mod') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subsubdir.role') is True
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll.subdir.subsubdir.playbook') is True

    assert AnsibleCollectionRef.is_valid_fqcr('') is False
    assert AnsibleCollectionRef.is_valid_fqcr('ns.coll') is False
    assert AnsibleCollectionRef.is_valid_f

# Generated at 2022-06-11 17:42:43.928490
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible.module_utils.six import PY3
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.vars import combine_vars
    from ansible.collection_loader._collection_finder import get_collection_directory
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.srv.config import CONFIG, _CONFIG_DEFAULTS
    path_list = ['/usr/share/ansible/collections', '/home/user/.ansible/collections']
    path_list = ['{0}'.format(get_collection_directory())]

# Generated at 2022-06-11 17:42:53.537338
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    mod = import_module('ansible.builtin.collections.ansible_collections.tests.collection2.plugins.module_utils.test_plugins')
    assert mod.__name__ == 'ansible_collections.tests.collection2.plugins.module_utils.test_plugins'
    assert mod.__loader__.__class__.__name__ == '_AnsibleCollectionLoader'
    assert mod.__file__ == '/home/roman/ansible/ansible/test/units/module_utils/test_plugins.py'


# our custom path_hook that handles a few special cases for Ansible
_CUSTOM_HOOK_PREFIX = '_ansible_custom_hook.'

# Generated at 2022-06-11 17:42:56.346383
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    test_collection_finder = _AnsibleCollectionFinder()
    test_playbook_paths = 'test_playbook_path'
    test_collection_finder.set_playbook_paths(test_playbook_paths)


# Generated at 2022-06-11 17:43:06.647290
# Unit test for method __repr__ of class AnsibleCollectionRef

# Generated at 2022-06-11 17:43:18.247254
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('strategy_plugins') == 'strategy'

# Generated at 2022-06-11 17:43:19.332297
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    assert True

# Generated at 2022-06-11 17:44:19.634809
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    from collections import namedtuple
    from ansible.utils.collection_loader import _meta_yml_to_dict, _AnsibleCollectionPkgLoader

    class ImportModuleMock(object):
        def __init__(self, module_name, module_path):
            self.module_name = module_name
            self.directory = module_path

    class OpenMock(object):
        def __init__(self, file_path, file_content):
            self.file_path = file_path
            self.file_content = file_content

        def __call__(self, *args):
            return self

        def read(self):
            return self.file_content

        def __enter__(self):
            return self


# Generated at 2022-06-11 17:44:29.283181
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    import os
    import sys
    import shutil
    import tempfile
    import collections
    import ansible.utils.collection_loader

    tf = tempfile.mkdtemp()

    # mock ansible distribution
    os.makedirs(os.path.join(tf, 'ansible', 'builtin'))
    with open(os.path.join(tf, 'ansible', 'builtin', 'meta', 'runtime.yml'), 'w') as fd:
        fd.write("""
        plugin_routing:
          module:
            foo:
              redirect: ansible.builtin.bar
        
        """)

    # mock some other collection
    foo_coll_base = os.path.join(tf, 'baz', 'foo')
    os.makedirs(foo_coll_base)