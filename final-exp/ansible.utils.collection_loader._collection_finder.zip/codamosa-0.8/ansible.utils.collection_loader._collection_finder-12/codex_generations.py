

# Generated at 2022-06-11 17:35:51.229061
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    # We setup a fake package in a temporary directory
    test_dir = tempfile.gettempdir()
    test_package_path = os.path.join(test_dir, 'test_package')

# Generated at 2022-06-11 17:35:56.131571
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    _fqcr = AnsibleCollectionRef.is_valid_fqcr(u'not.a.real.collection.module')
    _fqcr = AnsibleCollectionRef.is_valid_fqcr(u'not.a.real.collection.module', u'module')
    if _fqcr:
        print('success: %s' % _fqcr)


# Generated at 2022-06-11 17:36:02.245201
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.path import unfrackpath

    # test get_data with nonexistent path
    loader = _AnsibleCollectionPkgLoaderBase('some.collection.some_module', path_list=['/path/to/collection.some.collection'])
    assert loader.get_data('/path/to/collection.some.collection/non_existing_path') is None

    # test get_data with non-existing resource path
    loader = _AnsibleCollectionPkgLoaderBase('some.collection.some_module', path_list=['/path/to/collection.some.collection'])

# Generated at 2022-06-11 17:36:12.484013
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.some_ns', path_list=[u'/foo/bar'])
    assert loader._fullname == 'ansible_collections.some_ns'
    assert loader._parent_package_name == 'ansible_collections'
    assert loader._candidate_paths == [u'/foo/bar/some_ns']
    assert loader._subpackage_search_paths == []
    assert loader._package_to_load == 'some_ns'

# Implements Ansible's custom namespace package support for Py2.
# Python2 does not support implicit namespace packages, so in that case we need to synthesize a module
# for each namespace. This loader works only for the toplevel or one-level-under `ansible_collections`
# namespace module (it does not work

# Generated at 2022-06-11 17:36:24.205355
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    ansible_collection_loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.myns.mycoll')
    test_data = 'test data'
    with pytest.raises(ValueError):
        ansible_collection_loader.get_data(path='')
    with pytest.raises(ValueError):
        ansible_collection_loader.get_data(path='__init__.py')
    with pytest.raises(ValueError):
        ansible_collection_loader.get_data(path='__init__.py')

    mypath = '/tmp/mypath'
    if os.path.isdir(mypath):
        shutil.rmtree(mypath)
    os.makedirs(mypath)

# Generated at 2022-06-11 17:36:30.657488
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    test_module_name = "ansible_collections.test_collection.test_module"
    test_module_path = os.path.join(os.path.dirname(__file__), "test_data/test_import/test_collection/test_module")
    test_module_path_init = os.path.join(test_module_path, "__init__.py")
    test_module_path_meta = os.path.join(test_module_path, "meta/runtime.yml")
    test_module_path_meta_content = "plugin_routing:\n  module:\n    test_module:\n      redirect: test_collection.plugin_module"

    # Prepare the test_module

# Generated at 2022-06-11 17:36:40.404938
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    assert None != _AnsibleCollectionRootPkgLoader(path=[], package_name='ansible_collections')
    assert None != _AnsibleCollectionNSPkgLoader(path=['/some/path'], package_name='ansible_collections.ns')

    assert None != _AnsibleCollectionPkgLoader(path=['/some/path'], package_name='ansible_collections.ns.collection')
    assert None != _AnsibleCollectionPkgLoader(path=['/some/path'], package_name='ansible.builtin')
    assert None != _AnsibleCollectionPkgLoader(path=[], package_name='ansible.builtin')


# Generated at 2022-06-11 17:36:47.088871
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
  test_cases = [
    { 'input': {'fullname': 'ansible.builtin.hello_world' }, 'expected': None },
    { 'input': {'fullname': 'ansible.other.hello_world' }, 'expected': None, 'error': True },
  ]
  for test_case in test_cases:
    tester = _AnsibleInternalRedirectLoader(test_case['input']['fullname'], None)
    if 'error' in test_case and test_case['error']:
      with pytest.raises(Exception):
        tester.load_module(test_case['input'])
    else:
      assert tester.load_module(test_case['input']) == test_case['expected']

# This loader only answers for Ansible Python modules that existed in previous versions but

# Generated at 2022-06-11 17:36:51.354114
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    # test for import string
    import_str = 'ansible.collections.namespace.collection_pkg.module_name'
    loader = _AnsibleCollectionLoader(import_str, ['list of paths'])
    assert loader._fullname == 'ansible.collections.namespace.collection_pkg.module_name'
    assert loader._split_name == ['ansible', 'collections', 'namespace', 'collection_pkg', 'module_name']
    assert loader._package_to_load == 'namespace.collection_pkg.module_name'
    assert loader._metadata_search_paths == ['list of paths']
    assert loader._candidate_paths == []
    assert loader._source_code_path == None


# NOTE: This is used for the ansible.builtin tasks and filters, which are synthetic "collections"


# Generated at 2022-06-11 17:36:59.739273
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    class_ = _AnsibleInternalRedirectLoader(
        fullname = 'ansible.module_utils.my',
        path_list = []
    )
    assert class_._redirect == 'ansible.module_utils.my'
    # assert class_.load_module('fullname') == 'ansible.module_utils.my'
    # assert sys.modules[fullname] == 'module'


# This is the hook function we install on path_hook to handle imports for Ansible Python modules

# Generated at 2022-06-11 17:37:28.704917
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'


# Unit tests for class AnsibleCollectionRef

# Generated at 2022-06-11 17:37:37.031849
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    try:
        _AnsibleInternalRedirectLoader('TestCollection.module', 'path_list')
        assert False
    except ImportError:
        pass

    loader_target_class = _AnsibleInternalRedirectLoader('ansible.module_utils.module_a.module_a', None).__class__.__name__
    assert (loader_target_class == "_AnsibleCollectionLoader")

    loader_target_class = _AnsibleInternalRedirectLoader('ansible.module_utils.module_b.module_b', None).__class__.__name__
    assert (loader_target_class == "_AnsibleCollectionLoader")


# this handles all the metadata associated with Ansible's collection loader integration, as well as
# the "config" and "doc" subpackages for collections

# Generated at 2022-06-11 17:37:48.203114
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    import tempfile
    import shutil
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from lib.collection_loader import _AnsibleCollectionPkgLoaderBase
    testdir = tempfile.mkdtemp()
    foo = os.path.join(testdir, 'foo')
    os.mkdir(foo)
    bar = os.path.join(testdir, 'bar')
    with open(os.path.join(testdir, 'testfile'), 'w') as f:
        f.write('somerandomstuff')
    os.mkdir(bar)

# Generated at 2022-06-11 17:37:58.498723
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_name = 'test_col'
    collection_path = './test_col'
    module_name = 'ansible_collections.{}.test_col'.format(collection_name)

    with open(os.path.join(collection_path, 'meta/runtime.yml'), 'r') as f:
        raw_routing = f.read()

    def test_meta_yml_to_dict(*args, **kwargs):
        return yaml.load(raw_routing, **kwargs)

    old_on_collection_load = AnsibleCollectionConfig.on_collection_load
    events = []

    def on_collection_load_mock(collection_name=None, collection_path=None):
        events.append((collection_name, collection_path))

    AnsibleCollectionConfig.on_collection_load

# Generated at 2022-06-11 17:37:59.867200
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    pass


# Helper to load collections/namespaces via the path hook

# Generated at 2022-06-11 17:38:08.665023
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    try:
        # path: str
        collection_loader = _AnsibleCollectionFinder(paths=to_native(__file__))
        collection_loader.find_module('ansible.module_utils.somemodule')
        collection_loader.find_module('ansible_collections.somens')
    except ImportError:
        pass
    finally:
        collection_loader._remove()

# Unit tests for function _AnsibleCollectionFinder._ansible_collection_path_hook

# Generated at 2022-06-11 17:38:17.740034
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('connection_plugins') == 'connection'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'modules'

# Generated at 2022-06-11 17:38:19.435689
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('test.test', ['test'])

# Generated at 2022-06-11 17:38:27.435890
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    in_test = True
    import ansible.utils.collection_loader

    class FakeModule(object):
        class FakeLoader(object):
            def __init__(self):
                self.package_to_load = 'test_collection'
                self.subpackage_search_paths = ['/tmp']
                self.redirect_module = None
                self.candidate_paths = ['/tmp/test_collection']
                self.source_code_path = '/tmp/test_collection/__init__.py'
                self.fullname = 'ansible.collections.ns.test_collection'

            def get_filename(self, fullname):
                return '/tmp/test_collection'

            def get_source(self, fullname):
                return '# this is a test'

    module = FakeModule()
    ansible

# Generated at 2022-06-11 17:38:36.616548
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # There are a large number of possible inputs, so we can't just check the output in a single run.
    # Instead we'll try to check all possible inputs for a given ref_type
    for ref_type in AnsibleCollectionRef.VALID_REF_TYPES:
        for valid_fqcr in [
            'ns1.coll1.subdir1.subdir2.subdir3.res1',
            'ns1.coll1.subdir1.subdir2.res2',
            'ns1.coll1.subdir1.res3',
            'ns1.coll1.res4',
        ]:
            assert AnsibleCollectionRef.is_valid_fqcr(valid_fqcr, ref_type)


# Generated at 2022-06-11 17:39:05.446800
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    fqcr = 'namespacetest.collectiontest.subdir1.subdir2.resourcetest'
    acr = AnsibleCollectionRef.from_fqcr(fqcr, 'module')
    assert repr(acr) == "AnsibleCollectionRef(collection='namespacetest.collectiontest', " \
                        "subdirs='subdir1.subdir2', resource='resourcetest')"


# Generated at 2022-06-11 17:39:16.851035
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    fqcr1 = AnsibleCollectionRef(collection_name='ns.coll', subdirs='subdir1.subdir2', resource='resource_name', ref_type='module')
    assert fqcr1.collection == 'ns.coll'
    assert fqcr1.subdirs == 'subdir1.subdir2'
    assert fqcr1.resource == 'resource_name'
    assert fqcr1.ref_type == 'module'

    fqcr2 = AnsibleCollectionRef.from_fqcr('ns.coll.subdir1.subdir2.resource_name', 'module')
    assert fqcr2.collection == 'ns.coll'
    assert fqcr2.subdirs == 'subdir1.subdir2'
    assert fqcr2.resource == 'resource_name'
   

# Generated at 2022-06-11 17:39:27.239355
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class _Loader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            return

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

        def _validate_final(self):
            return
    # test with _subpackage_search_paths
    loader = _Loader('prefix')
    loader._subpackage_search_paths = ['path1', 'path2', 'path3']
    assert repr(loader) == "_Loader(path=['path1', 'path2', 'path3'])"
    # test with _source_code_path
    loader = _Loader('prefix')

# Generated at 2022-06-11 17:39:34.882583
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import os
    test_dir = os.path.dirname(__file__)
    
    ansible_collection_dir = os.path.join(test_dir, 'ansible_collections')
    ansible_collections_awx_dir = os.path.join(ansible_collection_dir, 'awx')
    ansible_collections_awx_tasks__init__py = os.path.join(ansible_collections_awx_dir, 'tasks', '__init__.py')
    ansible_collections_awx_tasks_deploy_dir = os.path.join(ansible_collections_awx_dir, 'tasks', 'deploy')

# Generated at 2022-06-11 17:39:40.774243
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    """Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase"""
    collection_token = 'ansible.netcommon'
    path = 'ansible_collections/ansible/netcommon/plugins/modules'
    fullname = 'ansible_collections.ansible.netcommon.plugins'
    basemodule = _AnsibleCollectionPkgLoaderBase(fullname, [path])

    assert basemodule.get_filename(fullname) == '<ansible_synthetic_collection_package>'


# Generated at 2022-06-11 17:39:49.317087
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():

    ansible_collection_ref = AnsibleCollectionRef(collection_name='', subdirs='', resource='', ref_type='')
    repr = repr(ansible_collection_ref)
    assert repr == "AnsibleCollectionRef(collection='', subdirs='', resource='')"

    ansible_collection_ref = AnsibleCollectionRef(collection_name='namespace.collection', subdirs='', resource='', ref_type='')
    repr = repr(ansible_collection_ref)
    assert repr == "AnsibleCollectionRef(collection='namespace.collection', subdirs='', resource='')"

    ansible_collection_ref = AnsibleCollectionRef(collection_name='namespace.collection', subdirs='', resource='', ref_type='rolename')
    repr = repr(ansible_collection_ref)


# Generated at 2022-06-11 17:39:50.860724
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    tester = _AnsibleCollectionFinder()
    tester._ansible_collection_path_hook(".")
    tester.__repr__()



# Generated at 2022-06-11 17:40:02.419506
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    with pytest.raises(ValueError):
        AnsibleCollectionRef.from_fqcr('ansible.builtin', 'role')
    # failure to find a resource in the collection should raise an ImportError,
    # not a ValueError (see comment in AnsibleCollectionRef.from_fqcr)
    with pytest.raises(ImportError):
        AnsibleCollectionRef.from_fqcr('acme.collection.failure', 'role')

    assert AnsibleCollectionRef.from_fqcr('acme.collection.role', 'role').resource == u'role'
    assert AnsibleCollectionRef.from_fqcr('acme.collection.playbook', 'playbook').resource == u'playbook'

# Generated at 2022-06-11 17:40:12.442712
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class test_AnsibleInternalRedirectLoader(object):
        def __init__(self, fullname, path_list):
            self._redirect = None
            self._fullname = fullname
            self._path_list = path_list
            self._name = fullname.split('.')[-1]

        def load_module(self, fullname):
            # since we're delegating to other loaders, this should only be called for internal redirects where we answered
            # find_module with this loader, in which case we'll just directly import the redirection target, insert it into
            # sys.modules under the name it was requested by, and return the original module.
            if not self._redirect:
                raise ValueError('no redirect found for {0}'.format(fullname))

            # FIXME: smuggle redirection context, provide warning

# Generated at 2022-06-11 17:40:22.525467
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = None
    try:
        loader = _AnsibleInternalRedirectLoader('ansible.foo', None)
    except ImportError as ex:
        assert 'not interested' in str(ex)

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.test', None)
    assert loader
    assert loader._redirect == 'ansible_collections.test.builtin.tests.test_plugin'


# handles rewriting python imports at runtime according to the loader/module
# configuration, so that "ansible.builtin.foobar" or "ansible.foobar" ends up becoming
# "ansible_collections.test.builtin.foobar" or "ansible_collections.test.foobar"

# Generated at 2022-06-11 17:40:54.071124
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    module_name = 'ansible_collections.test.test_collection'
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    path_list = [os.path.join(base_dir, 'test/integration/ansible_collections/test/test_collection/plugins')]
    package = _AnsibleCollectionPkgLoaderBase(module_name, path_list)

    # file existence check
    assert package.get_data('/test_data.yaml') == 'a: 1\n'
    with pytest.raises(ValueError):
        package.get_data('not_exist_file')
    with pytest.raises(ValueError):
        package.get_

# Generated at 2022-06-11 17:41:02.912692
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class TestClass:
        def get_data(self, path):
            if path == 'path1':
                return '''def foo():
    print('bar')'''
            elif path == 'path2':
                return '''def foo():
    print('baz')'''
            elif path == 'path3':
                return ''
            elif path == 'path4':
                pass
            elif path == 'path5':
                raise ValueError('custom-error')

        def get_source(self, fullname):
            if fullname == 'fullname1':
                return '''def foo():
    print('bar')'''
            elif fullname == 'fullname2':
                return '''def foo():
    print('baz')'''
            elif fullname == 'fullname3':
                return ''

# Generated at 2022-06-11 17:41:13.223319
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import io
    from ansible.compat.six import StringIO
    from ansible.compat.tests import unittest
    class TestModule(unittest.TestCase):
        def test_load_module(self):
            class Foo:
                def method_a():
                    pass
            original_stdout = sys.stdout
            sys.stdout = StringIO()
            target = _AnsibleCollectionPkgLoaderBase(Foo.__name__)
            result = target.load_module(Foo.__name__)
            sys.stdout = original_stdout
            self.assertEqual(result, Foo)

    exit_code = unittest.main('test', failfast=True, exit=False)
    assert exit_code == 0

# Generated at 2022-06-11 17:41:22.601659
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase."""
    class _AnsibleCollectionPkgLoaderBaseSubclass(_AnsibleCollectionPkgLoaderBase):
        """AnsibleCollectionPkgLoaderBase with callable fields."""
        def _get_candidate_paths(self, path_list):
            return path_list
        def _get_subpackage_search_paths(self, candidate_paths):
            return [p for p in candidate_paths if os.path.isdir(to_bytes(p))]

    filename1 = '__init__.py'
    filename2 = 'module1.py'
    filename3 = 'module2.py'
    data1 = 'foo'
    data2 = 'bar'
    data3 = 'baz'
    path = os

# Generated at 2022-06-11 17:41:33.753174
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ref_type = 'module'
    ref = 'ansible.test_collection.module_utils.test_module_utils'
    fqcr = AnsibleCollectionRef.from_fqcr(ref, ref_type)

    assert fqcr.collection == 'ansible.test_collection'
    assert fqcr.subdirs == 'module_utils'
    assert fqcr.resource == 'test_module_utils'
    assert fqcr.ref_type == 'module_utils'
    assert fqcr.n_python_collection_package_name == 'ansible_collections.ansible.test_collection'
    assert fqcr.n_python_package_name == 'ansible_collections.ansible.test_collection.plugins.module_utils.module_utils.test_module_utils'
    assert fq

# Generated at 2022-06-11 17:41:40.517975
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    old_redirects = copy.deepcopy(_AnsibleCollectionLoader._redirected_package_map)
    _AnsibleCollectionLoader._redirected_package_map = {}
    _AnsibleCollectionLoader._redirected_package_map['ansible.module_utils.foo'] = 'ansible.module_utils.other.foo'
    _AnsibleCollectionLoader._redirected_package_map['ansible.module_utils.other.foo'] = 'ansible.module_utils.other.foo'
    _AnsibleCollectionLoader._redirected_package_map['ansible.module_utils.other.foo.submodule'] = 'ansible.module_utils.other.foo.submodule'
    _AnsibleInternalRedirectLoader('ansible.module_utils.bar', None)
    _Ansible

# Generated at 2022-06-11 17:41:43.950841
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    fullname = 'ansible_collections.ns1.coll1.plugins'
    loader = _AnsibleCollectionPkgLoaderBase(fullname)
    assert loader.is_package(fullname) == True


# Generated at 2022-06-11 17:41:53.796609
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    import tempfile
    class CollectionPkgLoader( _AnsibleCollectionPkgLoaderBase):
        def __init__(self, name):
            super(CollectionPkgLoader, self).__init__(name, [])
            # Code for test (not for real collections)
            self._source_code_path = tempfile.mktemp(prefix=name, suffix='.py')
            self._decoded_source = 'def foo(): return "bar"'
            self.get_code(self._fullname)

    loader = CollectionPkgLoader('my_collection.my_ns.my_pkg')
    if loader.get_code(loader._fullname).co_filename != loader._source_code_path:
        raise Exception("Failed to get_code for collection package")

test__AnsibleCollectionPkgLoaderBase_get_code()



# Generated at 2022-06-11 17:42:00.338075
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    try:
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('something_else')
        raise AssertionError('An exception was not thrown.')
    except ValueError:
        pass



# Generated at 2022-06-11 17:42:07.589997
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader

    # load ansible.builtin collection
    ansible_builtin_coll_loader = _AnsibleCollectionPkgLoader(fullname='ansible_collections.ansible.builtin', path=['/usr/lib/python3.7/site-packages/ansible'])
    ansible_builtin_coll_loader.load_module('ansible_collections.ansible.builtin')
    assert False

    # load an invalid collection
    ansible_builtin_coll_loader = _AnsibleCollectionPkgLoader(fullname='ansible_collections.ansible.builtin', path=['/usr/lib/python3.7/site-packages/ansible'])

    return "hello"

# Generated at 2022-06-11 17:42:39.316390
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    dummy_paths = [
        # FUTURE: add a relative pathname
        # FUTURE: add a regular file
        # FUTURE: add a directory
        # FUTURE: add a non-existent pathname
    ]
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.test', path_list=dummy_paths)
    for path in dummy_paths:
        # TODO: add code to test if each path is a file or directory
        loader.get_data(path)
        # TODO: ensure that get_data raises ValueError if the path is outside the loader's search path

test__AnsibleCollectionPkgLoaderBase_get_data()


# Generated at 2022-06-11 17:42:49.267067
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    import os.path
    import tempfile
    import shutil
    import random

    base_path = tempfile.mkdtemp()

    # create a basic file structure with some files to load
    def create_files(base_path, depth, width, min_filesize, max_filesize, top_level=True):
        files = set()

        if random.choice([True, False]) and top_level:
            # add some metadata files, which we should skip
            for x in range(random.randint(1, 3)):
                files.add('{0}.meta.{1}'.format(random.choice(['author', 'readme', 'metadata', 'dependencies']),
                                                random.choice(['txt', 'ini', 'yaml', 'yml'])))

        # create a file full of random content

# Generated at 2022-06-11 17:42:58.443159
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import os
    import imp
    import inspect
    import shutil
    import tempfile
    import unittest

    from ansible_collections.ansible.foo.plugins import module_utils

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def setUp(self):
            TEST_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')

            self.test_dir = tempfile.mkdtemp()
            fixtures_path = os.path.join(TEST_DATA_DIR, 'ansible_collections', 'ansible', 'foo')

# Generated at 2022-06-11 17:43:09.652048
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from test.support import run_unittest, captured_stdout
    from ansible.module_utils.six import PY3, StringIO
    from ansible.module_utils._text import to_text

    # Base loader that tracks invocations and validates arguments
    class Helper1(object):
        def __init__(self):
            self.reset()

        def reset(self):
            self.invocations = []

        def load_module(self, fullname):
            self.invocations.append(dict(fullname=fullname))
            mod = ModuleType(fullname)
            sys.modules[fullname] = mod
            return mod

    # Base loader that returns a module created in advance

# Generated at 2022-06-11 17:43:20.796139
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # Single test for invalid ref_type
    try:
        AnsibleCollectionRef.from_fqcr(u'x.test.test', u'bad_type')
        assert False, 'Should have raised a ValueError because ref_type is invalid'
    except ValueError:
        pass

    # Single test for invalid fqcr
    try:
        AnsibleCollectionRef.from_fqcr(u'bad fqcr', u'module')
        assert False, 'Should have raised a ValueError because ref is invalid'
    except ValueError:
        pass

    # Single test for valid fqcr
    ref = AnsibleCollectionRef.from_fqcr(u'x.test.test', 'module')
    assert ref.collection == u'x.test'
    assert ref.resource == u'test'
    assert ref.ref

# Generated at 2022-06-11 17:43:28.756988
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    reference = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert reference == 'action', "AnsibleCollectionRef fails to map 'action_plugins' to plugin type action"

    reference = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert reference == 'modules', "AnsibleCollectionRef fails to map 'library' to plugin type modules"


# Generated at 2022-06-11 17:43:37.745666
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    base = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_namespace.some_collection')
    
    # is_package check
    assert base.is_package('ansible_collections.some_namespace.some_collection')
    assert not base.is_package('ansible_collections.some_namespace.some_collection.module_name')
    assert not base.is_package('ansible_collections.some_namespace.some_collection.sub_package.module_name')
    
    # is_module_or_subpackage check
    assert not base.is_module_or_subpackage('ansible_collections.some_namespace.some_collection')

# Generated at 2022-06-11 17:43:50.139118
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    loader_b = None
    loader = None

# Generated at 2022-06-11 17:43:59.639899
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():

    ansible_modules_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'files'))
    collection_finder = _AnsibleCollectionFinder(paths=[ansible_modules_path], scan_sys_paths=False)

    # Find ansible module action plugin
    result_loader = collection_finder.find_module('ansible.plugins.action.copy')
    assert isinstance(result_loader, _AnsibleInternalRedirectLoader)

    # Find ansible_collections.somens.somecoll.plugins.action.copy module
    result_loader = collection_finder.find_module('ansible_collections.somens.somecoll.plugins.action.copy')
    assert isinstance(result_loader, _AnsibleCollectionLoader)

    # Find ans

# Generated at 2022-06-11 17:44:05.078868
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    fullname = 'ansible_collections.mytest'
    path_list = '/home/ansible/ansible_collections'
    obj = _AnsibleCollectionPkgLoaderBase(fullname, path_list)
    assert repr(obj) == '_AnsibleCollectionPkgLoaderBase(path=/home/ansible/ansible_collections/mytest)'



# maintains fs state for collection package loading