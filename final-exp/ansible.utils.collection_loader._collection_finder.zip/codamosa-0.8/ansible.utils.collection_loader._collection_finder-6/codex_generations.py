

# Generated at 2022-06-11 17:35:25.882462
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    import ansible.collection_loader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase

    # Find a default Ansible collection repository (based on default collection path)
    default_collection_paths = ansible.collection_loader.get_collection_paths()
    default_collection_path = ansible.collection_loader.get_collection_paths()[0]
    default_collection_repo = os.path.split(os.path.split(default_collection_path)[0])[1]

    # Basic test
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.' + default_collection_repo + '.foo',
                                             [default_collection_path])
    assert loader.get_source('ansible_collections.' + default_collection_repo + '.foo')

# Generated at 2022-06-11 17:35:30.958012
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():

    # Test default behavior
    fqcr = 'ns.coll.resource'
    ref_type = 'module'
    actual = AnsibleCollectionRef.from_fqcr(fqcr, ref_type)
    assert actual.resource == 'resource'
    assert actual.ref_type == 'module'
    assert actual.n_python_package_name == 'ansible_collections.ns.coll.plugins.module'
    assert actual.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert actual.collection == 'ns.coll'
    assert actual.subdirs == ''
    assert actual.fqcr == 'ns.coll.resource'

    # Test default behavior
    fqcr = 'ns.coll.sub.resource'
    ref_type = 'module'
    actual = Ans

# Generated at 2022-06-11 17:35:31.396616
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    pass

# Generated at 2022-06-11 17:35:40.272611
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.module_utils.six as six
    import ansible.utils.collection_loader as collection_loader
    import builtins

    import_ = getattr(builtins, '__import__')
    def _import_(name, globals=None, locals=None, fromlist=(), level=-1):
        if name == 'ansible.builtin':
            return import_('ansible', globals, locals, fromlist, level)
        else:
            return import_(name, globals, locals, fromlist, level)

    def mock_import_module(name):
        if name == 'ansible':
            return AnsibleModuleMock()
        else:
            return import_module(name)


# Generated at 2022-06-11 17:35:47.118752
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Parameters
    fqcr = 'ns.coll.subdir1.subdir2.my_module'
    ref_type = 'module'

    # Test code
    assert AnsibleCollectionRef.is_valid_fqcr(fqcr, ref_type)

    # This is required to make sure the class is initialized
    assert AnsibleCollectionRef.from_fqcr(fqcr, ref_type)



# Generated at 2022-06-11 17:35:49.934703
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    import pprint
    loader = _AnsibleCollectionLoader('.collection.namespace.package')
    pprint.pprint(loader.__dict__)
    assert loader.__dict__['_path_list'] == _COLLECTION_PATH_LIST


# Generated at 2022-06-11 17:35:58.795255
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:36:03.758895
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    _AnsibleCollectionPkgLoaderBase._allows_package_code = True
    try:
        _loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.test', ['/'])
    except ImportError:
        return

    try:
        assert _loader
        module = _loader.load_module('ansible_collections.ansible.test')
        assert module
        assert module.__package__ == 'ansible_collections.ansible.test'
        assert module.__file__ == '/ansible_collections/ansible/test/__init__.py'
        assert module.__loader__ is _loader
    finally:
        _AnsibleCollectionPkgLoaderBase._allows_package_code = False



# Generated at 2022-06-11 17:36:14.042795
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    class AnsibleInternalRedirectLoader(unittest.TestCase):
        @patch.multiple('sys', modules=DEFAULT)
        @patch('ansible.utils.collection_loader.AnsibleCollectionConfig')
        @patch('ansible.utils.collection_loader.import_module')
        def test__redirect_to_module(self, mock_import_module, mock_AnsibleCollectionConfig, mock_sys_modules):
            mock_sys_modules['ansible.builtin'] = {}
            mock_AnsibleCollectionConfig.get_plugin_cache_dir.return_value = None
            with patch.dict(os.environ,  **{'ANSIBLE_INTEGRATION_TEST_FILE': 'test__AnsibleInternalRedirectLoader_load_module.py'}):
                import_module('ansible')


# Generated at 2022-06-11 17:36:21.663123
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    # For test purposes, we need to create the following structures
    # <name of the plugin>.py
    # |-> __init__.py
    # |-> <related file>.py
    # |-> <related file>
    tmp_dir = tempfile.mkdtemp()
    tmp_file1 = os.path.join(tmp_dir, "__init__.py")
    tmp_file1_handler = open(tmp_file1, 'w')
    tmp_file1_handler.close()
    tmp_file2 = os.path.join(tmp_dir, "<plugin_name>.py")
    tmp_file2_handler = open(tmp_file2, 'w')
    tmp_file2_handler.close()
    tmp_file3 = os.path.join(tmp_dir, "<related_file>.py")
   

# Generated at 2022-06-11 17:37:43.518343
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    module = _AnsibleInternalRedirectLoader('ansible.module_utils.six', None)
    assert module._redirect is not None


# convenience function that returns a loader instance that proxies to the loader of the module we're redirecting to

# Generated at 2022-06-11 17:37:48.642039
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _AnsibleInternalRedirectLoader(fullname='ansible.builtin.copy', path_list='.').load_module(fullname='ansible.builtin.copy')

# This loader only answers for intercepted Ansible Python modules. Normal imports will fail here and be picked up later
# by our path_hook importer (which proxies the built-in import mechanisms, allowing normal caching etc to occur)

# Generated at 2022-06-11 17:37:58.773978
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    class EmptyClass():
        pass
    # test_new_module
    name = 'test'
    loader = _AnsibleCollectionPkgLoader(name=name, subpackage_search_paths=[])
    with loader._new_or_existing_module(name) as module:
        if module.__name__ != name:
            raise AssertionError('Expected {0}, got {1}'.format(name, module.__name__))
    # test_existing_module
    name = 'ansible'
    loader = _AnsibleCollectionPkgLoader(name=name, subpackage_search_paths=[])

# Generated at 2022-06-11 17:38:06.540340
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module_utils') == 'module_utils'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('modules') == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'

# Generated at 2022-06-11 17:38:10.304034
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    c = _AnsibleCollectionFinder()
    c.find_module('ansible_collections.somens.somecoll.plugins.module_utils.some_module')
    assert c._n_collection_paths == []


# Generated at 2022-06-11 17:38:18.423739
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    """
    Test _AnsibleInternalRedirectLoader()

    This test assumes that the following is true:
    - platforms/_redhat.py imports ansible.plugins.strategies.strategy_map
    - platforms/_redhat.py exists in ansible.builtin
    """
    fullname = 'ansible.plugins.strategy.strategy_map'
    path_list = []
    mod = _AnsibleInternalRedirectLoader(fullname, path_list)
    assert mod._redirect == 'crochet.setup', "Redirect to crochet.setup failed"



# Generated at 2022-06-11 17:38:27.708721
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
   test_finder = _AnsibleCollectionFinder()
   result = test_finder.find_module('ansible_collections.ansible')
   assert result is not None
   assert isinstance(result, _AnsibleCollectionPkgLoader)
   result = test_finder.find_module('ansible_collections')
   assert result is not None
   assert isinstance(result, _AnsibleCollectionRootPkgLoader)
   assert result._n_path_list == []
   assert result._n_fullname == "ansible_collections"
   assert result._n_parent_finder is test_finder
   result = test_finder.find_module('ansible_collections.ansible.test')
   assert result is not None
   assert isinstance(result, _AnsibleCollectionLoader)

# Generated at 2022-06-11 17:38:34.288655
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # Create an instance of _AnsibleInternalRedirectLoader
    # This method requires 4 arguments:
    #   - fullname: string - the full package name of the loader
    #   - path_list: list of strings - the list of paths to be searched for the package
    #
    # There is no good way to test this, as it does a bunch of importing and only returns a module if it has been redirected.
    # Skip test for now.
    pass



# Generated at 2022-06-11 17:38:36.451002
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    _AnsibleInternalRedirectLoader('ansible.test', [])
    return True


# Generated at 2022-06-11 17:38:47.302948
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('org.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('org')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('org.coll.ns2.coll2')
    assert not AnsibleCollectionRef.is_valid_collection_name('org.2coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('org.coll.ns2.coll2')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir')


# Generated at 2022-06-11 17:39:48.426316
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    """
    The function _AnsibleCollectionPkgLoaderBase._get_data changed in PR #69018.
    The new logic is called only when a path is relative.
    Here we write tests for:
    - the old logic for absolute paths
    - the new logic for relative paths
    """

    test_path_absolute = os.path.dirname(__file__)

    # Create a deep directory structure.
    # This is used to contain an Ansible module and ensure we can load
    # its content with the old logic for an absolute path.
    test_path_absolute_deep = os.path.join(test_path_absolute, 'foo', 'bar')
    os.makedirs(test_path_absolute_deep)

    # Create a file with some content to be loaded by the loader.
    # Note that the file name is a valid

# Generated at 2022-06-11 17:39:59.348029
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # setup
    loader = _AnsibleInternalRedirectLoader('ansible.ansible_collections.my.collection.my_module', [])
    loader._redirect = 'ansible.builtin.my_module'

    # noinspection PyShadowingNames
    def _import_module(name):
        return name

    monkeypatch.setattr(_AnsibleInternalRedirectLoader, 'import_module', _import_module)

    # test
    sys.modules['ansible.builtin.my_module'] = 'ansible.builtin.my_module'

    assert loader.load_module('ansible.ansible_collections.my.collection.my_module') == 'ansible.builtin.my_module'

# Generated at 2022-06-11 17:40:09.389619
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import inspect
    import tempfile

    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible.utils.collection_loader import _meta_yml_to_dict


# Generated at 2022-06-11 17:40:11.053751
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    assert False, "No test for this class"

# Generated at 2022-06-11 17:40:19.523018
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    from ansible.utils.collection_loader import _AnsibleCollectionRef
    collection_name = 'namespace.collection'
    subdirs = 'subdir1.subdir2'
    resource = 'resource'
    ref_type = 'action'
    obj = _AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)
    assert repr(obj) == 'AnsibleCollectionRef(collection=\'namespace.collection\', subdirs=\'subdir1.subdir2\', resource=\'resource\')'


# Generated at 2022-06-11 17:40:29.919898
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('foo.bar.some_role', 'role')
    assert not AnsibleCollectionRef.try_parse_fqcr('foo.bar.some_role', 'module')
    assert not AnsibleCollectionRef.try_parse_fqcr('some.col.action_plugin.thingy', 'action')
    assert AnsibleCollectionRef.try_parse_fqcr('some.col.action_plugin.thingy', 'module')
    assert not AnsibleCollectionRef.try_parse_fqcr('some.col.action_plugin.thingy', 'lookup')

    # incompatible types with the subdirs
    assert not AnsibleCollectionRef.try_parse_fqcr('some.col.my_subdir.myaction', 'action')

# Generated at 2022-06-11 17:40:36.707095
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    tests = [
        {'test': 'Test1',
         'expected_return': "_AnsibleCollectionPkgLoaderBase(path=['/ansible'])",
         'instance': _AnsibleCollectionPkgLoaderBase(fullname="ansible_collection.org.ansible_collections", path_list=['/ansible']),
         'validate': lambda self: True},
    ]

    err_msg = ""

    for test in tests:
        try:
            assert test['instance'].__repr__() == test['expected_return']
        except AssertionError as err:
            err_msg += "\n-------------------------------\n"
            err_msg += "Test {0} raised an exception\n".format(test['test'])
            err_msg += "Traceback:\n"

# Generated at 2022-06-11 17:40:45.317365
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    expected = AnsibleCollectionRef(u'foo.bar', u'subdir1.subdir2', u'resource', u'module')
    actual = AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.subdir1.subdir2.resource', u'module')
    assert actual == expected
    assert actual.subdirs == u'subdir1.subdir2'
    assert actual.resource == u'resource'
    assert actual.fqcr == u'foo.bar.subdir1.subdir2.resource'
    assert actual.ref_type == u'module'
    assert actual.collection == u'foo.bar'

    expected = AnsibleCollectionRef(u'foo.bar', u'', u'resource', u'module')
    actual = AnsibleCollectionRef.try_parse_

# Generated at 2022-06-11 17:40:55.167306
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.module', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.module', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.module', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.module', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr('a.b.c.module', 'module') == None

    assert AnsibleCollectionRef.try_parse_fqcr(u'foo.bar.module', 'module').f

# Generated at 2022-06-11 17:41:01.233424
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    class_ = AnsibleCollectionRef
    assert class_.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert class_.legacy_plugin_dir_to_plugin_type('action') == 'action'
    assert class_.legacy_plugin_dir_to_plugin_type('library') == 'module'
    assert_raises(ValueError, class_.legacy_plugin_dir_to_plugin_type, 'not_valid')



# Generated at 2022-06-11 17:41:29.491303
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert str(_AnsibleCollectionPkgLoaderBase('')) == "_AnsibleCollectionPkgLoaderBase(path=None)"

# Generated at 2022-06-11 17:41:38.418178
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    module_name = 'ansible.plugins.loader'
    # We do not need to provide a full implementation of _AnsibleInternalRedirectLoader because
    # load_module() is tested by itself.
    class _AnsibleInternalRedirectLoaderMock(object):
        def load_module(self, fullname):
            self.fullname = fullname
            self.module_name = module_name
            self._redirect = 'ansible.plugins.loader'
            return _AnsibleInternalRedirectLoaderMock()
    loaderMock = _AnsibleInternalRedirectLoaderMock()
    # We also do not need to provide a real fullname, because it is assigned to module_name in load_module().
    fullname = 'mocked fullname'
    loaderMock.load_module(fullname)
    assert loaderMock

# Generated at 2022-06-11 17:41:48.072050
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible_collections
    import ansible_collections.tamnun
    import ansible_collections.tamnun.test

    # Test find_module without path
    ansible_collections_path_hook_finder_obj = _AnsiblePathHookFinder(None, os.path.dirname(ansible_collections.__file__))
    assert (type(ansible_collections_path_hook_finder_obj.find_module("ansible_collections")) is _AnsibleCollectionRootPkgLoader)
    assert (isinstance(ansible_collections_path_hook_finder_obj.find_module("ansible_collections.tamnun"), _AnsibleCollectionNSPkgLoader))

# Generated at 2022-06-11 17:41:52.739604
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    from ansible.utils.collection_loader import _get_collection_base_path
    from ansible.module_utils.facts import is_executable
    import os
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 17:42:03.278990
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
	result1 = AnsibleCollectionRef.try_parse_fqcr(ref='namespace.collection.subdir1.subdir2.resource', ref_type='role')
	result2 = AnsibleCollectionRef.try_parse_fqcr(ref='namespace.collection.subdir1.subdir2.resource', ref_type='role')
	assert (result1 == result2)

	result1 = AnsibleCollectionRef.try_parse_fqcr(ref='namespace.collection.resource', ref_type='role')
	result2 = AnsibleCollectionRef.try_parse_fqcr(ref='namespace.collection.resource', ref_type='role')
	assert (result1 == result2)

	result1 = AnsibleCollectionRef.try_parse_fqcr(ref='namespace.collection', ref_type='role')


# Generated at 2022-06-11 17:42:10.151946
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('module') == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'module'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('cache') == 'cache'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('inventory') == 'inventory'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup') == 'lookup'
    assert AnsibleCollectionRef

# Generated at 2022-06-11 17:42:16.893586
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    reload(sys.modules['ansible_collections.ansible.builtin.plugins.module_utils._text'])
    test_instance = _AnsibleInternalRedirectLoader('ansible.module_utils._text', None)
    test_instance.load_module('ansible.module_utils._text')

# a custom path_hook implementation that allows us to have our own loader types

# Generated at 2022-06-11 17:42:23.574213
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection_name = 'namespace.name'
    subdirs = 'sub1.sub2'
    resource = 'myresource'
    ref_type = 'mytype'

    acr = AnsibleCollectionRef(collection_name, subdirs, resource,  ref_type)

    assert repr(acr) == "AnsibleCollectionRef(collection='namespace.name', subdirs='sub1.sub2', resource='myresource')"


# Generated at 2022-06-11 17:42:34.594394
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import sys
    import tempfile
    import shutil
    import os

    import ansible_collections
    loader = ansible_collections.__loader__
    module_name = 'ansible_collections.test.test_collection_loader'
    collection, name = module_name.split('.', 1)

    root_path = os.path.join(os.path.dirname(__file__), collection)
    version_paths = [os.path.join(root_path, version)
                     for version in os.listdir(root_path)
                     if name in os.listdir(os.path.join(root_path, version))]
    path = version_paths[0]

    try:
        sys.modules.pop(module_name)
    except KeyError:
        pass

    # create a fake

# Generated at 2022-06-11 17:42:39.592045
# Unit test for method set_playbook_paths of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_set_playbook_paths():
    finder = _AnsibleCollectionFinder()
    finder._install()
    try:
        finder.set_playbook_paths("foo:bar:baz")
        assert finder._n_playbook_paths == ["foo/collections", "bar/collections", "baz/collections"]
    finally:
        finder._remove()


# Generated at 2022-06-11 17:43:27.732691
# Unit test for constructor of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder():
    # 1. Test __init__
    # 1.1. Test with no arguments
    # 1.1.1. Test collection_finder instance
    assert isinstance(AnsibleCollectionConfig.collection_finder, _AnsibleCollectionFinder)
    # 1.1.2. Test it has one of the paths
    assert any(p for p in AnsibleCollectionConfig.collection_finder._n_configured_paths if '/ansible_collections/' in p)

    # 1.2 Test with specific path
    # 1.2.1. Test collection_finder instance
    assert isinstance(AnsibleCollectionConfig.collection_finder, _AnsibleCollectionFinder)
    # 1.2.2. Test it has the specific paths
    assert '/etc/ansible/collections' in AnsibleCollectionConfig.collection_finder._n_configured

# Generated at 2022-06-11 17:43:37.297311
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Test setup
    base_dir = tempfile.mkdtemp()

    # Run test

# Generated at 2022-06-11 17:43:43.486089
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from . import _AnsiblePathHookFinder
    loader = _AnsibleCollectionPkgLoaderBase('/etc/ansible')
    assert type(loader) == _AnsibleCollectionPkgLoaderBase

    # _AnsibleCollectionPkgLoaderBase.get_data(loader, '/etc/ansible')
    # loader.get_data('/etc/ansible')


# Generated at 2022-06-11 17:43:50.510949
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:43:59.913518
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    import io
    import sys
    import tempfile

    # parameter 'self' is not used, but I cannot write with self = Mock(), because 'self' is not a variable
    # so I will use variable 'self' to hold the Mock() and use it as 'self'
    self = Mock()
    # create a file and write some text, then get its path
    tmp_file = tempfile.NamedTemporaryFile(prefix='ansible_test_', suffix='_test__AnsibleCollectionPkgLoaderBase_load_module', delete=False)
    with io.open(tmp_file.name, 'w') as f:
        f.write(u"I'm a file with content")
    tmp_file_path = tmp_file.name
    # set _fullname, _rpart_name, _parent_package_name, _package

# Generated at 2022-06-11 17:44:09.942435
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    from ansible.collections.ansible.builtin.plugins.filter import skip_when

    import ansible_collections.acme.example.plugins.module_utils.my_utils
    import ansible_collections.acme.example.plugins.lookup.mylookup

    # ansible_collections.acme.example.plugins.module_utils.my_utils

    # FQCR
    # ansible_collections.acme.example.plugins.module_utils.my_utils

# Generated at 2022-06-11 17:44:15.064419
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
  class _AnsibleCollectionPkgLoaderBase_get_data_Dummy(object):
    def __init__(self):
      self.data = ''
  obj = _AnsibleCollectionPkgLoaderBase_get_data_Dummy()
  assert 'a' == _AnsibleCollectionPkgLoaderBase.get_data(obj, '/a/b/c')


# Generated at 2022-06-11 17:44:26.155005
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins') == 'action'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins') == 'lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('terminal_plugins') == 'terminal'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins') == 'callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'

# Generated at 2022-06-11 17:44:30.434266
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder(None, 'ansible_collections/somecollection/somefolder')

# Implement our own iter_modules that does not rely on the path_hook implementation for our namespace pkg
# We do this to allow for package redirection (eg, ansible_collections.<namespace>.foo -> ansible_collections.ns.<namespace>.foo)
# which will not be handled by the path_hook's pkg.__path__.