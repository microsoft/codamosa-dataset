

# Generated at 2022-06-11 17:35:22.261438
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    path = '.'
    name = 'ansible_collections.mycollection.mymodule'
    loader = _AnsibleCollectionPkgLoaderBase(name, path)
    assert loader._fullname == name
    assert loader._split_name[0] == 'ansible_collections'
    assert loader._rpart_name[0] == 'ansible_collections.mycollection'
    assert loader._rpart_name[2] == 'mymodule'
    assert loader._parent_package_name == 'ansible_collections.mycollection'
    assert loader._package_to_load == 'mymodule'
    assert loader._candidate_paths[0] == name.replace('.', '/')
    assert loader._subpackage_search_paths is None


# Generated at 2022-06-11 17:35:28.929424
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:35:37.557320
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    instance = _AnsibleCollectionNSPkgLoader('ansible_collections.foo')
    assert_equal(instance._package_to_load, 'foo')
    assert_equal(instance._parent_package_name, 'ansible_collections')

# Implements a non-root collection package and its subpackages. A collection package is the first encountered
# on the configured collection root path. Python namespace package aggregation is not permitted at or below
# the collection package. Implements implicit package (package dir) support for both Py2/3. Package init code
# is ignored by this loader.

# Generated at 2022-06-11 17:35:49.354481
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    temp_directory = tempfile.mkdtemp(suffix="_ansible_collections")
    test_collection_name = "test_collection"
    test_collection_path = os.path.join(temp_directory, test_collection_name)
    os.makedirs(test_collection_path)

    base_loader_with_subpackage_obj = _AnsibleCollectionPkgLoaderBase("ansible_collections.test_collection", path_list=[])
    base_loader_with_subpackage_obj._subpackage_search_paths = [test_collection_path]
    assert str(base_loader_with_subpackage_obj) == "_AnsibleCollectionPkgLoaderBase(path=['" + test_collection_path + "'])"

    base_loader_with_module_obj = _AnsibleCollectionPkg

# Generated at 2022-06-11 17:35:58.329975
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    from ansible.plugins.loader.collections_loader import _AnsibleCollectionPathHook
    #_collections_path = [os.path.dirname(__file__)] + os.environ['ANSIBLE_COLLECTIONS_PATHS'].split(os.pathsep)
    _collections_path = os.environ['ANSIBLE_COLLECTIONS_PATHS'].split(os.pathsep)
    _AnsibleCollectionPathHook.add_paths(_collections_path)
    sys.meta_path = [_AnsibleCollectionPathHook()]
    module = import_module('paloalto.panos.panos_network')
    assert module
    
    #import_module('ansible_collections.paloalto.panos.panos_network')
# Unit test

# Generated at 2022-06-11 17:36:05.179153
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    arg1 = 'collection1'
    arg2 = u'subdirs1.subdir2'
    arg3 = u'resource1'
    obj = AnsibleCollectionRef(arg1, arg2, arg3, 'module')
    result = obj.__repr__()
    assert result == "AnsibleCollectionRef(collection='collection1', subdirs='subdirs1.subdir2', resource='resource1')"



# Generated at 2022-06-11 17:36:08.386938
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    ref_test = AnsibleCollectionRef('ansible.collections.test', None,'role','role')
    assert ref_test.is_valid_collection_name(ref_test.collection)


# Generated at 2022-06-11 17:36:18.099187
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:36:26.938969
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    with patch.object(sys.modules[__name__], '_iter_modules_impl', return_value=[]) as _iter_modules_impl:
        _AnsibleCollectionPkgLoaderBase('').iter_modules('')
    assert _iter_modules_impl.call_count == 1
    assert _iter_modules_impl.call_args == (([], ''),)



# Generated at 2022-06-11 17:36:31.141111
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder(paths=[os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_framework', 'test_collections')])
    path_hook_finder = _AnsiblePathHookFinder(collection_finder, path="ansible_collections.test.test_filter_plugins")
    fullname = "ansible_collections.test.test_filter_plugins.test_to_nice_json"
    path = None
    loader = path_hook_finder.find_module(fullname, path)
    assert (loader is not None)
    fullname = "ansible_collections.test.test_filter_plugins.to_nice_json"
    path = "ansible_collections/test/test_filter_plugins"
    loader

# Generated at 2022-06-11 17:37:14.452108
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import unittest
    loader = _AnsibleCollectionPkgLoaderBase('some.ns')

    class TestModule(unittest.TestCase):
        def test_package_without_search_paths(self):
            loader._source_code_path = None
            loader._subpackage_search_paths = None
            self.assertIsNone(loader.get_filename('some.ns'))

        def test_package_with_search_paths_and_no_source_path(self):
            loader._source_code_path = None
            loader._subpackage_search_paths = ['/path/to/ns/some']
            self.assertEqual(loader.get_filename('some.ns'), '/path/to/ns/some/__synthetic__')


# Generated at 2022-06-11 17:37:23.042607
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    _an_source_code_path = 'UnitTest'
    _an_subpackage_search_paths = ['UnitTest']
    _an_fullname = 'ansible_collections.unitTest'
    acplb = _AnsibleCollectionPkgLoaderBase(_an_fullname)
    acplb._source_code_path = _an_source_code_path
    acplb._subpackage_search_paths = _an_subpackage_search_paths
    assert acplb.get_filename(_an_fullname) == _an_source_code_path

# Generated at 2022-06-11 17:37:26.024141
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    with pytest.raises(ValueError):
        _AnsibleInternalRedirectLoader(fullname='ansible.foo.boo', path_list=['123'])



# Generated at 2022-06-11 17:37:34.370261
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    # create mock object MockCollectionLoader with all its original methods changed to Mocks
    mock_object = MockCollectionLoader()

    # We change all its methods to Mocks
    mock_object.get_filename = Mock(return_value='<collection>')

    # we add a method to return a mock for the new method we want to test
    mock_object.get_source = Mock(return_value='xyz')

    # we add another method for the method we want to test
    mock_object.get_filename = lambda fullname: 'xyz'

    # we add a third method to return a mock for the new method we want to test
    mock_object.get_code = Mock(return_value='xyz')

    # we add another method for the method we want to test
    mock_object.get_filename = lambda fullname: 'xyz'

# Generated at 2022-06-11 17:37:43.329420
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    path = '/path/to/playbook.yml'
    coll_finder = _AnsibleCollectionFinder()
    finder = _AnsiblePathHookFinder(coll_finder, path)
    assert finder._pathctx == path


# Implements a path_hook finder for iter_modules (since it's only path based). This finder does not need to actually
# function as a finder in most cases, since our meta_path finder is consulted first for *almost* everything, except
# pkgutil.iter_modules, and under py2, pkgutil.get_data if the parent package passed has not been loaded yet.

# Generated at 2022-06-11 17:37:52.333489
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class DummyLoader(_AnsibleCollectionPkgLoaderBase):
        def __init__(self):
            super(DummyLoader, self).__init__('test_namespace', ['/foo/bar'])
            self._candidate_paths = ['/foo/bar/test_namespace']

        def _validate_args(self):
            pass

        def _validate_final(self):
            pass

        def _get_candidate_paths(self, path_list):
            return self._candidate_paths

        def _get_subpackage_search_paths(self, candidate_paths):
            return [candidate_paths[0]]

        def _synthetic_filename(self, fullname):
            return '__synthetic__'


# Generated at 2022-06-11 17:38:00.939949
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    """
    Test the from_fqcr method of class AnsibleCollectionRef with different inputs
    """
    from ansible_collections.ansible.builtin.plugins.action import ping
    a_ref_type = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(ping.__module__)
    fqcr_list = [
        AnsibleCollectionRef.from_fqcr('ansible.builtin.ping', a_ref_type),
        AnsibleCollectionRef.from_fqcr('ansible.builtin.ping.win_ping', a_ref_type),
        AnsibleCollectionRef.from_fqcr('ansible.builtin.ping.win_ping.yml', a_ref_type),
    ]

# Generated at 2022-06-11 17:38:07.030846
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    fake_fullname = 'foo.bar'
    fake_path = 'fake_path'
    _loader = _AnsibleInternalRedirectLoader(fake_fullname, fake_path)
    try:
        _loader.load_module(fake_fullname)
    except Exception:
        pass
    else:
        assert False, 'test did not fail'



# Generated at 2022-06-11 17:38:16.926792
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import ansible
    ansible_dir = os.path.dirname(ansible.__file__)
    collection_finder = _AnsibleCollectionFinder()
    collection_finder._install()
    ansible_version = "{0}.{1}.{2}".format(ansible.__version__,ansible.__version_info__[0],ansible.__version_info__[1])
    assert ansible_version == ansible.__version__


# Generated at 2022-06-11 17:38:22.041553
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
  path_list = ['partial/path', 'another/path']
  argobj = _AnsibleCollectionPkgLoaderBase('some_collection.some_name')
  ret = argobj.get_filename('some_collection.some_name')

  assert ret is None
test__AnsibleCollectionPkgLoaderBase_get_filename()

# Generated at 2022-06-11 17:38:46.066876
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins')=='filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('lookup_plugins')=='lookup'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('callback_plugins')=='callback'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')=='modules'
    try:
        AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('invalid_')
        assert False, 'AnsibleCollection Ref should have raised a ValueError'
    except ValueError:
        pass


# Generated at 2022-06-11 17:38:56.308347
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.subdir')

    from ansible_collections.namespace.coll.plugins.module_utils import bar
    from ansible_collections.namespace.coll2.plugins.module_utils import bar

    bare_collection = AnsibleCollectionRef.from_fqcr(u'ns.coll.bar', u'module_utils')
    assert bare_collection.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert bare_collection.n_python_package_name == 'ansible_collections.ns.coll.plugins.module_utils'
   

# Generated at 2022-06-11 17:39:03.706076
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    EXTENSIONS = ('.cfg', '.yml', '.yaml')

    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('ansible.foo')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.ext')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.ext1.ext2')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll.ext1.ext2.ext3')

# Generated at 2022-06-11 17:39:07.082341
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # create a mock loader object
    loader = _AnsibleCollectionPkgLoader('.', 'foo', 'bar')
    # create a mock module
    loader.load_module(fullname = 'ansible.collections.foo.bar')


# Generated at 2022-06-11 17:39:14.095655
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.geerlingguy.collection')
    loader._subpackage_search_paths = ['/path/to/package']
    assert loader.is_package(fullname='ansible_collections.geerlingguy.collection') is True
    loader._subpackage_search_paths = None
    assert loader.is_package(fullname='ansible_collections.geerlingguy.collection') is False



# Generated at 2022-06-11 17:39:24.868698
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:39:33.481057
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.resource') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource.py') == False
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns_coll.resource') == False

    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.resource', ref_type=u'module') == True
    assert AnsibleCollectionRef.is_valid_fqcr(u'ns.coll.subdir1.subdir2.resource', ref_type=u'module') == True

# Generated at 2022-06-11 17:39:42.073924
# Unit test for constructor of class AnsibleCollectionRef

# Generated at 2022-06-11 17:39:50.127229
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible_collections.shapeblue.spt_azure.plugins.modules import azure_rm_appservice
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.shapeblue.spt_azure.plugins.modules", __path__)
    assert loader.get_filename("ansible.builtin.win_command") == "ansible/modules/windows/win_command.py"
    assert loader.get_filename("ansible_collections.shapeblue.spt_azure.plugins.modules") == "ansible_collections/shapeblue/spt_azure/plugins/modules/__init__.py"

# Generated at 2022-06-11 17:39:52.651221
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # TODO: Unit test for method load_module of class _AnsibleInternalRedirectLoader
    raise SkipTest  # Implement your test here


# Generated at 2022-06-11 17:40:39.763581
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # import the test class and its methods
    from test.lib.test_common_unit._test__AnsibleCollectionLoader_test_cases import (
        TestAnsibleCollectionLoader_testFindModule,
        TestAnsibleCollectionLoader_testFindModuleB,
        TestAnsibleCollectionLoader_testFindModuleC,
        TestAnsibleCollectionLoader_testFindModuleD,
        TestAnsibleCollectionLoader_testFindModuleE,
        TestAnsibleCollectionLoader_testFindModuleF,
    )

    # These variables are required for the TestAnsibleCollectionLoader_testFindModule class
    # to work without the TestLoader class
    _MODULE_FILE = os.path.join(os.path.dirname(__file__), '_AnsibleCollectionFinder.py')

# Generated at 2022-06-11 17:40:47.686593
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader, _meta_yml_to_dict
    from ansible.utils.collection_loader import get_collection_cache_paths, get_collection_package_data_path
    from ansible.utils.collection_loader import _AnsibleCollectionConfig as ACC
    from ansible.utils.collection_loader import get_collection_root_package_path
    import mock
    import os

    def _load_meta_yml(collection_path):
        meta_path = os.path.join(collection_path, 'meta/main.yml')
        with open(to_bytes(meta_path), 'rb') as fd:
            content = fd.read()

# Generated at 2022-06-11 17:40:53.373564
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import unittest
    class Test__AnsiblePathHookFinder(unittest.TestCase):
        def setUp(self):
            path_context = os.path.abspath('./ansible_collections/somens/somecoll')
            os.chdir(path_context)
            self.collection_finder = _AnsibleCollectionFinder()
            self.path_hook_finder = _AnsiblePathHookFinder(self.collection_finder, path_context)
            self.module_name = "ansible_collections.somens.somecoll.plugins.modules.something"
            self.reload_module_name = "ansible_collections.somens.somecoll.plugins.module_utils.something"


# Generated at 2022-06-11 17:41:00.559191
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    fqcr = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('action_plugins')
    assert(fqcr == u'action')
    fqcr = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library')
    assert(fqcr == u'modules')
    try:
        fqcr = AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('some_invalid')
        assert(False)
    except ValueError:
        pass


# Generated at 2022-06-11 17:41:12.084205
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # Test 1
    input1 = 'a.b.resource'
    ref1 = AnsibleCollectionRef.try_parse_fqcr(input1, 'module')
    assert ref1.collection == 'a.b'
    assert ref1.subdirs == ''
    assert ref1.resource == 'resource'
    assert ref1.ref_type == 'module'

    # Test 2
    input2 = 'a.b.subdir1.subdir2.resource'
    ref1 = AnsibleCollectionRef.try_parse_fqcr(input2, 'module')
    assert ref1.collection == 'a.b'
    assert ref1.subdirs == 'subdir1.subdir2'
    assert ref1.resource == 'resource'
    assert ref1.ref_type == 'module'

    # Test 3


# Generated at 2022-06-11 17:41:18.961307
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('os', '/home/ansible')[0] == '/home/ansible/os.py'
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('os', '/home/ansible')[1]
    assert _AnsibleCollectionPkgLoaderBase._module_file_from_path('os', '/home/ansible')[2] == None



# Generated at 2022-06-11 17:41:21.889963
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    result = _AnsibleCollectionPkgLoaderBase(path_list=[]).__repr__()
    assert result == '_AnsibleCollectionPkgLoaderBase(path=None)', result

# Generated at 2022-06-11 17:41:32.970323
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # for _AnsibleCollectionPkgLoaderBase.is_package(fullname)
    # we are not yet ready to setup the subpackage_search_paths,
    # so we need to stub that out for this test
    class _AnsibleCollectionPkgLoaderBaseStub(object):
        def __init__(self, fullname, path_list=None):
            self._fullname = fullname
            self._subpackage_search_paths = path_list

        def is_package(self, fullname):
            if fullname != self._fullname:
                raise ValueError('this loader cannot answer is_package for {0}, only {1}'.format(fullname, self._fullname))
            return self._subpackage_search_paths is not None

    if PY3:
        host_platform = 'posix'


# Generated at 2022-06-11 17:41:40.164154
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestAnsibleCollectionPkgLoaderBase(unittest.TestCase):

        def test_relative_resource_paths_are_not_supported(self):
            # Test scenario: we should get a value error when loading a relative resource path

            # Arrange
            test_self = _AnsibleCollectionPkgLoaderBase(None, None)
            test_path = ''
            test_data = ''
            expected_error_message = ('relative resource paths not supported', 1)

            # Act
            try:
                actual_data = test_self.get_data(test_path)
            except ValueError as actual_error:
                actual_error_message = (actual_error.args[0], actual_error.args[1])


# Generated at 2022-06-11 17:41:48.327126
# Unit test for method find_module of class _AnsiblePathHookFinder