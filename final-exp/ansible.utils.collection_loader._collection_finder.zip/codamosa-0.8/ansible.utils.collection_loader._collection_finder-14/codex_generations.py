

# Generated at 2022-06-11 17:35:31.600803
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class loader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass

        def _get_candidate_paths(self, path_list):
            return []

        def _get_subpackage_search_paths(self, path_list):
            return path_list

        def _validate_final(self):
            pass
    expected = "this is my source code"
    l = loader("ansible_collections.my_ns.my_coll.my_pkg")
    l._source_code_path = "/some/path"

# Generated at 2022-06-11 17:35:36.316442
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.facts.system.virtual.pyVmomi', None)
    if loader._redirect is None or loader._redirect != 'ansible.module_utils.facts.system.virtual_pyVmomi':
        raise ValueError()


# Generated at 2022-06-11 17:35:48.189983
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    from ansible_collections.ansible.tests.unit.vars import ExpectedModuleSubpackage
    from ansible_collections.ansible.tests.unit.vars import ExpectedModuleMidSubpackage
    import ansible_collections.ansible.tests.unit.vars as vars
    import os
    import shutil
    import sys

    temp_dir = tempfile.mkdtemp()

    modulepath = temp_dir
    # Use the same collections dir as ansible_collections.ansible.tests.unit.vars.collection_dir
    collectiondir = os.path.join(os.path.dirname(os.path.dirname(vars.collection_dir)), 'test_collections')
    # Create the test_collections/ansible_collections/ansible/test/ directory structure
   

# Generated at 2022-06-11 17:35:53.394917
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import importlib
    import ansible
    import ansible.utils
    import ansible.utils.collection_loader
    import ansible.collections

    import types
    import mock

    loader = ansible.utils.collection_loader._AnsibleCollectionPkgLoader(
        search_paths = ['a/b/c/d'],
        package_to_load = 'e',
        parent_package_name = 'ansible.collections'
    )
    package = types.ModuleType('ansible.collections.e')
    package.__path__ = ['a/b/c/d']
    package.__loader__ = loader
    with mock.patch.object(loader, 'load_module') as mock_load_module:
        mock_load_module.return_value = package
        assert package == loader.load_module

# Generated at 2022-06-11 17:36:04.671348
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    # first, we test the good FQCRs
    for good_fqcr in ['ns.coll.resource',
                      'ns.coll.subdir1.subdir2.resource',
                      'ns.coll.subdir1.subdir2.res_name.ext']:
        assert AnsibleCollectionRef.is_valid_fqcr(good_fqcr)

    # then, we test the bad FQCRs

# Generated at 2022-06-11 17:36:14.748858
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    # FIXME: for now, just a simple unit test for pytest
    i = DummyInstaller()
    c = i.add_collection('testns.testcoll')
    i.add_directory(c, 'plugins')
    i.add_directory(c, 'plugins/action')
    i.add_directory(c, 'docs')
    i.add_file(c, 'README.md')
    i.add_file(c, 'plugins/__init__.py')
    i.add_file(c, 'docs/__init__.py')
    i.add_file(c, 'plugins/action/main.py', b'module')

    li = i.list()
    print(li)


# Generated at 2022-06-11 17:36:27.667009
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from io import open

    def setup_func(tmpdir):
        # create a file with a module and a collection
        #    tmpdir/__init__.py
        #    tmpdir/file_with_module.py
        #    tmpdir/file_with_module/__init__.py
        #    tmpdir/file_with_module/module.py
        #    tmpdir/file_with_module/module.yml
        #    tmpdir/file_with_collection/collection.yml
        pkg_dir = to_bytes(tmpdir.join('file_with_module'))

# Generated at 2022-06-11 17:36:37.396365
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    class __AnsibleCollectionPkgLoaderBase(unittest.TestCase):
        def test__repr___no_subpackage_search_paths(self):
            # init source_code_path, subpackage_search_paths
            source_code_path = '/usr/share/ansible_collections/ns/collection/plugins/module_utils/foo.py'
            subpackage_search_paths = []
            # init expected obj
            expected_obj = "_AnsibleCollectionPkgLoaderBase(path='{0}')".format(
                source_code_path
            )
            # init instance object
            instance = _AnsibleCollectionPkgLoaderBase(
                'ns.collection.plugins.module_utils.foo',
                [source_code_path]
            )
            # set instance attributes to the specific values for

# Generated at 2022-06-11 17:36:44.815830
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _AnsibleCollectionPkgLoaderBaseTest(object):
        def _validate_args(self):
            self.assertEqual(self._split_name[0], 'ansible_collections')

        def _get_candidate_paths(self, path_list):
            return path_list

        def _get_subpackage_search_paths(self, path_list):
            return path_list

        def test__init_empty_path(self):
            try:
                _AnsibleCollectionPkgLoaderBase(
                    fullname='ansible_collections.some.name',
                    path_list=None
                )
                self.fail('expected exception')
            except ImportError:
                pass
            except Exception as e:
                self.fail(e)


# Generated at 2022-06-11 17:36:47.897880
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # create an AnsibleCollectionRef using the default constructor
    ref = AnsibleCollectionRef('namespace.name', 'subdirs', 'resoource', 'reference_type')
    assert ref.__repr__() == 'AnsibleCollectionRef(collection=\'namespace.name\', subdirs=\'subdirs\', resource=\'resoource\')'
    # cleanup
    del ref


# Generated at 2022-06-11 17:37:32.397969
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    arf = AnsibleCollectionRef.from_fqcr(u'ns.coll.subdir1.subdir2.resource', 'module')
    assert repr(arf) == "AnsibleCollectionRef(collection=u'ns.coll', subdirs=u'subdir1.subdir2', resource=u'resource')"

# Generated at 2022-06-11 17:37:42.851030
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    #Tests if the class is able to return the correct filename even when it is provided with a collection name that
    #does not exist
    test_dir = tempfile.mkdtemp()
    test_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ns.module', path_list=[test_dir])
    test_loader._validate_final = Mock()
    test_loader._validate_final.return_value = None
    test_loader._validate_args = Mock()
    test_loader._validate_args.return_value = None

    test_loader._get_candidate_paths = Mock()
    test_loader._get_candidate_paths.return_value = [test_dir + '/ns/module']
    test_loader._get_subpackage_search_paths = Mock()
   

# Generated at 2022-06-11 17:37:47.351951
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    _AnsibleCollectionRef = AnsibleCollectionRef('', '', '', '')
    legacy_plugin_dir_name = "action_plugins"
    assert _AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type(legacy_plugin_dir_name) == 'action'



# Generated at 2022-06-11 17:37:52.658798
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    pkg_loader = _AnsibleCollectionPkgLoader('a.b.c', [])
    pkg_loader.load_module('a.b.c')
    assert pkg_loader.load_module('a.b.c')._collection_meta == {}


# Generated at 2022-06-11 17:38:01.302891
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    assert AnsibleCollectionRef(collection_name=u'ns.coll', subdirs=u'subdir1.subdir2', resource=u'resource_name', ref_type=u'doc_fragments')
    assert AnsibleCollectionRef(collection_name=u'ns.coll', subdirs=None, resource=u'resource_name', ref_type=u'doc_fragments')
    assert AnsibleCollectionRef(collection_name=u'ns.coll', subdirs=u'subdir1.subdir2', resource=u'resource_name', ref_type=u'role')
    assert AnsibleCollectionRef(collection_name=u'ns.coll', subdirs=u'subdir1.subdir2', resource=u'resource_name', ref_type=u'action')

# Generated at 2022-06-11 17:38:08.056454
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    collection_name_strs = ('namespace.collection', 'namespace.collection-name')

# Generated at 2022-06-11 17:38:17.493704
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.foo.bar',
        path_list=['/my/package/foo/bar/path']
    )
    assert loader.get_filename('ansible_collections.foo.bar') == '/my/package/foo/bar/path/__synthetic__'
    loader = _AnsibleCollectionPkgLoaderBase(
        fullname='ansible_collections.foo.bar',
        path_list=[
            '/my/package/foo/bar/path',
            '/my/package/foo/bar/path/__init__.py',
        ]
    )
    assert loader.get_filename('ansible_collections.foo.bar') == '<ansible_synthetic_collection_package>'
    loader = _An

# Generated at 2022-06-11 17:38:21.293508
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    obj = AnsibleCollectionRef("ansible.concat", "", "concat", "lookup")
    assert repr(obj) == "AnsibleCollectionRef(collection='ansible.concat', subdirs='', resource='concat')"

# Generated at 2022-06-11 17:38:32.627172
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    f = _AnsibleCollectionPkgLoaderBase._AnsibleCollectionPkgLoaderBase._module_file_from_path
    assert f('__init__', '') == ('__init__.py', True, '/')
    assert f('a.py', '') == ('a.py', True, None)
    assert f('a', '/') == ('/a/__init__.py', True, '/a')
    assert f('a', '') == ('a/__init__.py', True, 'a')
    assert f('a', 'a') == ('a/__init__.py', True, 'a')
    assert f('a', '/a') == ('/a/__init__.py', True, '/a')

# Generated at 2022-06-11 17:38:34.619313
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.action.builtin.foo', None)

# Generated at 2022-06-11 17:39:18.226368
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    ref1 = AnsibleCollectionRef('ansible.builtin', None, 'ping', 'module')
    assert ref1.is_valid_collection_name('ansible.builtin')
    ref2 = AnsibleCollectionRef('ansible_collections.acme.foobar', None, 'ping', 'module')
    assert ref2.is_valid_collection_name('ansible_collections.acme.foobar')


# Generated at 2022-06-11 17:39:28.394225
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    from ansible_collections.foo.bar.plugins.module_utils import SOME_CONSTANT_HERE
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar.plugins.module_utils', path_list=['.'])
    assert [m[0] for m in loader.iter_modules()] == [
        'ansible_collections/foo/bar/plugins/module_utils/__init__',
        'ansible_collections/foo/bar/plugins/module_utils/some_module'
    ]

# Generated at 2022-06-11 17:39:34.938519
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    loader = _AnsibleInternalRedirectLoader('ansible.modules.test','')
    assert (loader._redirect == 'ansible.builtin.test')
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.test','')
    assert (loader._redirect == 'ansible.builtin.plugins.test')


# Generated at 2022-06-11 17:39:42.793078
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    tmp = fixture_path('tmp')
    res = os.path.join(tmp, 'res')
    path1 = os.path.join(res, 'ns1', 'coll1', 'plugins')
    path2 = os.path.join(res, 'ns2', 'coll2')
    path3 = os.path.join(res, 'ns2', 'coll3')
    path4 = os.path.join(res, 'randomdir')
    path5 = os.path.join(res, 'ns2', 'coll2', '__init__')


# Generated at 2022-06-11 17:39:52.894028
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _get_collection_metadata
    from ansible.utils.collection_loader import _nested_dict_get
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import sys

    py_version = sys.version_info

    collection_name = "ansible.builtin"

    # init
    fullname = "ansible.builtin.test"
    redirected_module = "ansible_collections.ansible.builtin.test"
    redirected_module_name = redirected_module.split('.')[-1]
    path_list = ["/tmp"]
    loader = _AnsibleInternalRedirectLoader(fullname, path_list)

    # check redirect
    assert loader._redirect == redirected_module
    # check load_module

# Generated at 2022-06-11 17:40:02.128027
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll_name2')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll_name.subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll_name2.subdir2')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll_name..subdir')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.coll_name2..subdir')



# Generated at 2022-06-11 17:40:12.188994
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # We create a loader to redirect module ansible.utils.module_docs to the module ansible.utils.module_docs_fr.
    # The reason is that we want to load the french version of the ansible.utils.module_docs. It is not important
    # that we load a module with the name ansible.utils.module_docs_fr as we are going to save the module under the
    # name ansible.utils.module_docs.

    # We create a _AnsibleInternalRedirectLoader object with fullname ansible.utils.module_docs
    loader = _AnsibleInternalRedirectLoader('ansible.utils.module_docs', [])
    # We check that the redirection is ansible.utils.module_docs_fr
    assert 'ansible.utils.module_docs_fr' == loader._redirect
    # We load

# Generated at 2022-06-11 17:40:18.305628
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # _AnsibleCollectionPkgLoaderBase_get_source(fullname)
    fullname = 'ansible_collections.ansible.builtin'
    pkg_loader = _AnsibleCollectionPkgLoaderBase(fullname)
    print(pkg_loader.get_source(fullname))

test__AnsibleCollectionPkgLoaderBase_get_source()



# Generated at 2022-06-11 17:40:25.773899
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    path = os.path.abspath(os.path.join(__file__, "..", "..", ".."))
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections", path_list=[path])

    module = loader.load_module("ansible_collections.ns.a.b")

    # Asserts for the newly imported module
    assert(module.__loader__ == loader)
    assert(module.__file__ == loader.get_filename("ansible_collections.ns.a.b"))
    assert(module.__package__ == "ansible_collections.ns.a")

    # Asserts for the already imported module
    module.__name__ = "ansible_collections.ns.a.b"

# Generated at 2022-06-11 17:40:36.776621
# Unit test for method find_module of class _AnsibleCollectionFinder

# Generated at 2022-06-11 17:42:36.625990
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    _module = importlib.import_module('ansible.module_utils.ansible_path_finder._ansible_collections_packages')
    _class = getattr(_module, '_AnsibleCollectionPkgLoaderBase')
    _module._AnsibleCollectionPkgLoaderBase = None

    _method = getattr(_class, '__repr__')
    _class.__repr__ = lambda x: 'fake_repr_value'

    try:
        assert _method(None) == 'fake_repr_value'
    finally:
        _class.__repr__ = _method
        _module._AnsibleCollectionPkgLoaderBase = _class

# Generated at 2022-06-11 17:42:43.928662
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import ansible.utils.metadata as metadata
    try:
        metadata.__loader__._meta_yml_to_dict = lambda x: {'import_redirection': {'ansible.config.utils.lookup': {'redirect': 'ansible.utils.lookup_loader'}}}
        test_obj = _AnsibleInternalRedirectLoader('ansible.config.utils.lookup', None)
        test_obj.load_module('ansible.config.utils.lookup')
    except Exception as e:
        print('ERROR: {0}'.format(e))
    finally:
        metadata.__loader__._meta_yml_to_dict = None


# WARNING: this modifies the global import mechanism! This is only supported/intended for use by methods that
# explicitly wrap their modifications (including unloading all registered hooks)

# Generated at 2022-06-11 17:42:54.578618
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():

    import tempfile
    import shutil
    import os
    import sys

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create a module in the temporary directory
    module_file_path = os.path.join(tmp_dir, "example_module.py")
    module_content = textwrap.dedent(
    '''
    #!/usr/bin/python

    def function():
        return 'Example function'

    def function_with_parameter(param):
        return param

    class ClassExample:
        def __init__(self, param):
            self.param = param

        def method(self):
            return self.param
    ''').strip()

    with open(module_file_path, 'w') as fh:
        fh.write(module_content)



# Generated at 2022-06-11 17:43:04.124030
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    obj = _AnsibleCollectionPkgLoaderBase('foo', ['bar'])
    obj._source_code_path = 'foo/bar/hello'
    obj._subpackage_search_paths = ['bar']
    assert obj.get_filename('foo') == 'foo/bar/hello'
    obj._source_code_path = 'foo/bar/hello'
    obj._subpackage_search_paths = ['bar', 'baz']
    assert obj.get_filename('foo') == '<ansible_synthetic_collection_package>'
    obj._source_code_path = None
    obj._subpackage_search_paths = None
    assert obj.get_filename('foo') == None
    obj._source_code_path = 'foo/bar/hello'
    obj._subpackage_search_paths = None

# Generated at 2022-06-11 17:43:15.942661
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    test_collection_pack_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.test_module', path_list=None)
    assert test_collection_pack_loader.get_filename('ansible_collections.test.test_module') == '/home/nitesh/workspace/kushal/ansible/lib/ansible_collections/test/test_module/__init__.py'

    test_collection_pack_loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.test.plugins.modules.test_module', path_list=None)

# Generated at 2022-06-11 17:43:24.768484
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # fake package path
    package_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'collection_loader_test_package')

    # _AnsibleCollectionPkgLoaderBase._module_file_from_path needs a leaf name and a path in native strings
    module_name = 'test_package'
    package_path_native = to_native(package_path)

    mock_module_path, has_code, package_path = _AnsibleCollectionPkgLoaderBase._module_file_from_path(module_name, package_path_native)

    if has_code:
        mock_loader_class = _AnsibleCollectionPkgLoaderBase
    else:
        mock_loader_class = _AnsibleCollectionPkgLoaderBase._AnsibleCollectionSyntheticPackageLoaderBase



# Generated at 2022-06-11 17:43:36.139013
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():

    class FileSystemFinder(object):
        def __init__(self, search_path):
            # foo/bar/baz.py
            self.search_path = search_path

        def find_module(self, fullname, path=None):
            if fullname != 'foo.bar.baz':
                raise Exception('Unexpected fullname: {0}'.format(fullname))
            if path != [self.search_path]:
                raise Exception('Unexpected path: {0}'.format(path))
            return self

        def load_module(self, fullname):
            # We should never be called
            raise Exception('Unexpected load_module invocation')

        def get_code(self, fullname):
            # We should never be called
            raise Exception('Unexpected get_code invocation')


# Generated at 2022-06-11 17:43:38.290463
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    _AnsiblePathHookFinder(None, None)


# Base class for collection loaders

# Generated at 2022-06-11 17:43:49.382029
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    print("test_AnsibleCollectionPkgLoaderBase_get_data")
    test_path_name = "test_path_name"
    loader = _AnsibleCollectionPkgLoaderBase("test_fullname")
    try:
        loader.get_data(test_path_name)
        print("Unexpected: no ValueError exception")
        return False
    except ValueError as e:
        if e.args[0] == "a path must be specified":
            print("Expected ValueError for an absent path")
            return True
    except Exception:
        print("Unexpected exception")
        return False

    print("end test_AnsibleCollectionPkgLoaderBase_get_data")
    return False


# Generated at 2022-06-11 17:43:59.111150
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # init
    _meta_yml_to_dict = MagicMock()
    _meta_yml_to_dict.return_value = {'plugin_routing': {'action': 'redirect0'}}
    AnsibleCollectionConfig = MagicMock()

    # create an instance of _AnsibleCollectionPkgLoader
    ansible_collection_pkg_loader = _AnsibleCollectionPkgLoader(['/root/ansible_collections/my_namespace/my_collections', '/root/ansible_collections/my_namespace/my_collections2'], 'my_namespace.my_collections', 'my_module')

    # create a module object
    module = MagicMock()
    # set value for method get_filename of class _AnsibleCollectionPkgLoader
    ansible_collection_pkg_