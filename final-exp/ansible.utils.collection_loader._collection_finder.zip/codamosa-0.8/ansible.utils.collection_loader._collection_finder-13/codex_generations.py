

# Generated at 2022-06-11 17:36:06.838174
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    assert True

# Generated at 2022-06-11 17:36:16.621201
# Unit test for method is_valid_collection_name of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_collection_name():
    assert AnsibleCollectionRef.is_valid_collection_name('ns.coll')
    assert AnsibleCollectionRef.is_valid_collection_name('Ansible.collection')
    assert AnsibleCollectionRef.is_valid_collection_name('ns.collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collection_name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collection_')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collection.')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collection.name')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns..collection')
    assert not AnsibleCollectionRef.is_valid_collection_name('ns.collection.sub.')

# Generated at 2022-06-11 17:36:29.157346
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    class _TestLoader(_AnsibleCollectionPkgLoaderBase):
        def _get_candidate_paths(self, path_list):
            return [os.path.join(p, self._package_to_load) for p in path_list]

        def _get_subpackage_search_paths(self, candidate_paths):
            raise Exception('this shouldn\'t be called')

    class _SinglePkgTestLoader(_TestLoader):
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths

    class _MultiPkgTestLoader(_TestLoader):
        def _get_subpackage_search_paths(self, candidate_paths):
            return candidate_paths + [os.path.join(candidate_paths[0], 'subpkg')]


# Generated at 2022-06-11 17:36:38.340783
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from unittest import TestCase
    import os

    # Fake data
    fullname = 'ansible_collections.test.new_plugin.tasks.main'
    test_dir = '/usr/share/ansible_collections/test/new_plugin/tasks'
    test_file = '/usr/share/ansible_collections/test/new_plugin/tasks/main.py'

    # Init _AnsibleCollectionPkgLoaderBase with the fake data
    ldr = _AnsibleCollectionPkgLoaderBase(fullname, [test_dir])
    # Check that get_filename return the fake data
    assert ldr.get_filename(fullname) == test_file



# Generated at 2022-06-11 17:36:45.531060
# Unit test for constructor of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase():
    class _AnsibleCollectionsLoaderTmpl(_AnsibleCollectionPkgLoaderBase):
        def __init__(self, fullname, path_list=None):
            super(_AnsibleCollectionsLoaderTmpl, self).__init__(fullname, path_list)
            self._candidate_paths.sort()
            self._subpackage_search_paths.sort()

    class _AnsibleCollectionsLoader(_AnsibleCollectionsLoaderTmpl):
        def _get_candidate_paths(self, path_list):
            return [os.path.join(p, 'ansible_collections/{0}'.format(self._package_to_load)) for p in path_list]

        def _validate_args(self):
            super(_AnsibleCollectionsLoader, self)._validate

# Generated at 2022-06-11 17:36:54.141773
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    test_path = 'ansible_collections/test_namespace/test_plugin_type/test_plugin'

    def _run_test_data(test_data):
        # test that the test data we created is what we expect
        assert(len(test_data) == 3)
        assert(test_data[0] == b'This is __init__.py for ansible_collections.test_namespace.test_plugin_type.test_plugin')
        assert(test_data[1] == b'This is test_plugin.py for ansible_collections.test_namespace.test_plugin_type.test_plugin')

# Generated at 2022-06-11 17:37:04.384142
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    import pkgutil
    import shutil
    import tempfile


# Generated at 2022-06-11 17:37:12.517240
# Unit test for method iter_modules of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_iter_modules():
    class TestAssertion(object):
        def __init__(self, cb_func):
            self._cb_func = cb_func

        def __call__(self, *args):
            assert self._cb_func(*args)

    class _AnsibleCollectionPkgLoaderBase_iter_modules_mock(object):
        def __init__(self, mock_path):
            self._path_started = False
            self._compiled_code = False
            self._parent_package_name = os.path.basename(mock_path)
            self._subpackage_search_paths = [mock_path]

        def is_package(self, fname):
            return not self._compiled_code

        def get_code(self, fname):
            assert self.is_package(fname)


# Generated at 2022-06-11 17:37:23.396885
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    def call_try_parse_fqcr(ref, ref_type):
        if AnsibleCollectionRef.try_parse_fqcr(ref, ref_type) is not None:
            return True
        return False

    assert call_try_parse_fqcr(u'ns.coll.resource', u'role')
    assert call_try_parse_fqcr(u'ns.coll.subdir1.resource', u'role')
    assert call_try_parse_fqcr(u'ns.coll.resource', u'playbook')
    assert not call_try_parse_fqcr(u'ns.coll.resource', u'role')
    assert not call_try_parse_fqcr(u'ns.coll', u'role')

# Generated at 2022-06-11 17:37:27.946158
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # Test when collection name is invalid
    try:
        AnsibleCollectionRef('name.space.coll', 'subdir1.subdir2', 'resource', 'module')
        assert False
    except ValueError:
        assert True

    # Test when ref_type is invalid
    try:
        AnsibleCollectionRef('name.space', 'subdir1.subdir2', 'resource', 'abc')
        assert False
    except ValueError:
        assert True

    # Test when subdirs is valid
    ref = AnsibleCollectionRef('name.space', 'subdir1.subdir2', 'resource', 'module')
    assert ref.subdirs == 'subdir1.subdir2'

    # Test when subdirs is invalid

# Generated at 2022-06-11 17:37:51.579588
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    clslb = _AnsibleCollectionPkgLoaderBase('c.d.e', path_list=[
        'a',
        'b',
        'c',
    ])
    print(clslb._get_candidate_paths(['a', 'b', 'c']))
    print(clslb._get_subpackage_search_paths(clslb._get_candidate_paths(['a', 'b', 'c'])))
    
    

# Generated at 2022-06-11 17:38:00.003203
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    cases = [
        # source_code, expected_compiled_code
        (None, None),   # None source_code => None compiled_code
        ('', None),     # empty source_code (eg, empty __init__.py) => None compiled_code
        ('a=1', None),  # non-empty source_code => compiled_code
    ]

    for source_code, expected_compiled_code in cases:
        class Tested(_AnsibleCollectionPkgLoaderBase):
            pass

        tested = Tested('ansible_collections.myns.mycoll')
        tested._get_candidate_paths = lambda l: ['']
        tested._get_subpackage_search_paths = lambda l: ['']
        tested.get_source = lambda f: source_code

# Generated at 2022-06-11 17:38:10.617933
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    path = os.path.join(os.path.dirname(__file__), "../../../")
    path = path + "/lib/ansible_collections/test_collection/plugins/modules/test_module.py"

    loader = _AnsibleCollectionPkgLoaderBase(fullname="foo", path_list=[path])
    assert(loader.get_source(fullname="foo") == None)

    loader = _AnsibleCollectionPkgLoaderBase(fullname="test_collection.plugins.modules.test_module", path_list=[path])
    assert(loader.get_source(fullname="test_collection.plugins.modules.test_module") is not None)



# Generated at 2022-06-11 17:38:13.749380
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
  # TO BE COMPLETED LATER (do it only if necessary)
  pass


# import hook that does the heavy lifting for resolving what loader to use for a given import
# expects to live at the front of sys.meta_path

# Generated at 2022-06-11 17:38:25.077865
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoader

    # set import to a mock object
    collection_loader_mock = MagicMock()
    ansible.utils.collection_loader.import_module = collection_loader_mock

    # set collection loader with a mock object
    ansible_collection_config_mock = MagicMock()
    ansible.utils.collection_loader.AnsibleCollectionConfig = ansible_collection_config_mock
    ansible_collection_config_mock.on_collection_load.fire = MagicMock()

    # set to_bytes to a mock object
    iotw_mock = MagicMock()
    ansible.utils.collection_loader

# Generated at 2022-06-11 17:38:31.235233
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    fullname = 'ansible_collections.collection_ns.collection_name.module_name'
    loader = _AnsibleCollectionPkgLoaderBase(fullname, [])
    loader._source_code_path = b'/path/to/file/module_name.py'
    code_obj = loader.get_code(fullname)
    assert isinstance(code_obj, types.CodeType)



# Generated at 2022-06-11 17:38:43.480394
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    """
    check all possible ways to construct an _AnsibleInternalRedirectLoader
    """
    # should raise ImportError, not have a redirect
    try:
        _AnsibleInternalRedirectLoader('not_ansible', [])
        assert False
    except ImportError:
        pass

    # should not raise an error, should have a redirect of 'foo:bar'
    loader = _AnsibleInternalRedirectLoader('ansible.plugins.bar', [])
    assert loader._redirect == 'foo:bar'

    # should raise an ImportError, not have a redirect
    try:
        _AnsibleInternalRedirectLoader('ansible.plugins.bar.not_baz', [])
        assert False
    except ImportError:
        pass

    # should not raise an error, should have a redirect of 'ansible.plugins.foo

# Generated at 2022-06-11 17:38:45.312499
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    """ sanity check test function """
    return 1 == 1


# Generated at 2022-06-11 17:38:55.363250
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    def get_routing_meta(collection_name):
        for i in range(0, 4):
            routing_meta_path = os.path.join(data_context().content.collections_paths[i], collection_name, 'meta/runtime.yml')
            if os.path.isfile(routing_meta_path):
                with open(routing_meta_path, 'rb') as fd:
                    return fd.read()
        return ''

    _meta_yml_to_dict = __all__['_meta_yml_to_dict']


# Generated at 2022-06-11 17:39:03.123802
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    ansible_collection_ref = AnsibleCollectionRef.from_fqcr("ns1.coll1.module1", "module")
    assert ansible_collection_ref.n_python_package_name == "ansible_collections.ns1.coll1.plugins.module"
    assert ansible_collection_ref.n_python_collection_package_name == "ansible_collections.ns1.coll1"
    assert ansible_collection_ref.resource == "module1"
    assert ansible_collection_ref.subdirs == ""
    assert ansible_collection_ref.fqcr == "ns1.coll1.module1"

    ansible_collection_ref = AnsibleCollectionRef.from_fqcr("ns1.coll1.module1", "module")
    assert ansible_collection_ref.n_python

# Generated at 2022-06-11 17:40:23.831093
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    # pylint: disable=too-many-branches
    ref_type = 'module'
    ref = AnsibleCollectionRef('ns.coll', 'subdir1.subdir2', 'mymod', ref_type)
    assert ref.collection == 'ns.coll', 'collection should be ns.coll'
    assert ref.subdirs == 'subdir1.subdir2', 'subdirs should be subdir1.subdir2'
    assert ref.resource == 'mymod', 'resource should be mymod'
    assert ref.ref_type == 'module', 'ref_type should be module'
    assert ref.n_python_collection_package_name == 'ansible_collections.ns.coll', 'n_python_collection_package_name should be ansible_collections.ns.coll'
    assert ref.n_python

# Generated at 2022-06-11 17:40:31.559321
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    """
    Ensure that the code object returned by get_code is the correct one
    """
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.my_namespace.my_collection', [])
    loader._source_code_path = "my_collection.py"
    loader._decoded_source = "def hello():\n    print('Hello')\n"
    assert loader.get_code('ansible_collections.my_namespace.my_collection') == loader._compiled_code



# Generated at 2022-06-11 17:40:39.627731
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
  def t(ref, ref_type):
    return AnsibleCollectionRef.try_parse_fqcr(ref, ref_type)
  assert t('ns.coll.resource', 'module')
  assert t('ns.coll.subdir1.subdir2.resource', 'module')
  assert t('ns.coll.role-name', 'role')
  assert t('ns.coll.subdir1.subdir2.role-name', 'role')
  assert t('ns.coll.playbook-filename', 'playbook')
  assert t('ns.coll.subdir1.subdir2.playbook-filename', 'playbook')
  assert t('ns.coll.subdir1.subdir2.playbook-filename.yml', 'playbook')

# Generated at 2022-06-11 17:40:44.844913
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    from ansible.utils.collection_loader import _AnsibleCollectionPkgLoaderBase

    coll_name = 'ns'
    coll_path = '/usr/share/ansible_collections/ns/collection/'

    loader = _AnsibleCollectionPkgLoaderBase(coll_name, [coll_path])
    assert loader.get_filename(coll_name) == '/usr/share/ansible_collections/ns/collection/__synthetic__'



# Generated at 2022-06-11 17:40:46.542518
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr('namespace.collection.name') is not None

# Generated at 2022-06-11 17:40:56.940471
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    assert AnsibleCollectionRef.is_valid_fqcr('a.b') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c.d') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e') == True
    assert AnsibleCollectionRef.is_valid_fqcr('a.b.c.d.e.f') == True

# Generated at 2022-06-11 17:41:04.410496
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    import unittest
    import copy

    # FIXME: use imp instead of using the collections in the filesystem


# Generated at 2022-06-11 17:41:14.069688
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:41:20.957827
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    my_fullname = 'ansible.module_utils.foo'
    my_path_list = ['/home/yako/prog/github/ansible/lib/ansible/module_utils/foo']

    obj = _AnsibleInternalRedirectLoader(my_fullname, my_path_list)
    # _AnsibleInternalRedirectLoader.load_module(obj, my_fullname)


# This loader uses a hardcoded import redirection map to handle internal imports.

# Generated at 2022-06-11 17:41:24.890065
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    loader = _AnsibleCollectionPkgLoaderBase('test')
    try:
        loader.get_data('/path/to/file/that/doesnt/exist.py')
        assert False
    except ValueError:
        pass
    assert loader.get_data('/dev/null') == b''


# Generated at 2022-06-11 17:42:06.547582
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    obj = _AnsibleCollectionPkgLoaderBase('ansible_collections.some_ns.some_collection')
    obj._source_code_path = '/tmp/foo'
    obj._package_to_load = 'some_collection'
    obj._parent_package_name = 'ansible_collections.some_ns'
    obj._split_name = ['ansible_collections', 'some_ns', 'some_collection']
    obj._rpart_name = ('ansible_collections.some_ns', '.', 'some_collection')
    obj._candidate_paths = ['/tmp/foo']
    obj._subpackage_search_paths = ['/tmp/foo']
    obj._fullname = 'ansible_collections.some_ns.some_collection'

# Generated at 2022-06-11 17:42:12.518875
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    # test valid FQCRs
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.base.module', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.base.library.module', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.base.library.module.a_module', 'module')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.base', 'role')
    assert AnsibleCollectionRef.try_parse_fqcr('ansible.base.a_role', 'role')
    # test invalid FQCRs
    assert not AnsibleCollectionRef.try_parse_fqcr('ansible', 'module')

# Generated at 2022-06-11 17:42:20.203213
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    plugin_dir = "/tmp/ansible_collections/ns/collection/plugins/modules"
    os.makedirs(plugin_dir)
    target_file = "/tmp/ansible_collections/ns/collection/plugins/modules/module.py"
    with open(target_file, "w") as fp:
        fp.write("#!/usr/bin/python")
    file_name = os.path.basename(target_file)
    module_name = 'ns.collection.plugins.modules.module'
    # 1. Test to get a existing module source code
    loader1 = _AnsibleCollectionPkgLoaderBase(module_name, path_list=[plugin_dir])
    assert loader1.get_source(module_name) == "#!/usr/bin/python"
    # 2. Test to get a non

# Generated at 2022-06-11 17:42:30.983888
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    assert AnsibleCollectionRef.try_parse_fqcr("ns.coll.resource", "module")
    assert AnsibleCollectionRef.try_parse_fqcr("ns.coll.subdir1.resource", "module")
    assert AnsibleCollectionRef.try_parse_fqcr("ns.coll.rolename", "role")
    assert AnsibleCollectionRef.try_parse_fqcr("ns.coll.playbook.yml", "playbook")

    assert not AnsibleCollectionRef.try_parse_fqcr("ns.coll", "module")
    assert not AnsibleCollectionRef.try_parse_fqcr("ns.coll.playbook.yml", "role")
    assert not AnsibleCollectionRef.try_parse_fqcr("ns.coll.rolename", "module")


# Generated at 2022-06-11 17:42:35.406898
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    import os
    import sys
    import pytest
    from types import ModuleType
    from tempfile import mkdtemp
    from shutil import rmtree
    from textwrap import dedent

    from ansible.utils.plugin_docs import read_docstring

    tmpdir = mkdtemp(prefix='ansible_test__AnsiblePathHookFinder_find_module')

# Generated at 2022-06-11 17:42:42.453735
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    # with path pointing to a collection package
    with patch.object(sys, 'modules', {}):
        with patch('io.open', mock_open(read_data='# generated module content')) as m:
            loader = _AnsibleCollectionPkgLoaderBase('ns.col.pkg')
            loader._subpackage_search_paths = ['some/path']
            m.side_effect = lambda p, m: open(p, m)
            loader.load_module('ns.col.pkg')
            m.assert_called_once_with('some/path/__init__.py', 'rb')
    # with path pointing to a collection module
    with patch.object(sys, 'modules', {}):
        with patch('io.open', mock_open(read_data='# generated module content')) as m:
            loader = _

# Generated at 2022-06-11 17:42:53.031019
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Mock a loader
    loader = _AnsibleCollectionPkgLoaderBase(fullname='ansible_collections.foo.bar',
                                             path_list=['/'])

    # Test existing file with absolute path
    assert loader.get_data('/etc/passwd') == to_bytes(open('/etc/passwd', 'rb').read())

    # Test existing file with relative path
    assert loader.get_data('/etc/passwd') == to_bytes(open('/etc/passwd', 'rb').read())

    # Test non-existing file with absolute path
    with pytest.raises(IOError):
        loader.get_data('/nonexisting')

    # Test non-existing file with relative path
    with pytest.raises(IOError):
        loader.get_data('nonexisting')

# Generated at 2022-06-11 17:43:00.071716
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
    # The following path is for test purpose. In fact, 'find_module' will never be called
    # with this path.
    path = ['./tox/py_test/test__AnsibleCollectionFinder/']
    import __init__ as asf
    asf.paths = None
    asf.scan_sys_paths = True
    asf._AnsibleCollectionFinder__n_configured_paths = ['./tox/py_test/test__AnsibleCollectionFinder/ansible_collections/']
    asf._AnsibleCollectionFinder__n_cached_collection_paths = None
    asf._AnsibleCollectionFinder__n_cached_collection_qualified_paths = None

# Generated at 2022-06-11 17:43:11.392159
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
  import pytest
  from collections import namedtuple
  from ansible.module_utils._text import to_bytes, to_text
  from types import ModuleType
  
  loader = _AnsibleCollectionPkgLoaderBase(fullname = "ansible.collections.namespace", path = "/tmp")
  loader.__class__.__name__ = "_AnsibleCollectionPkgLoaderBase"
  loader.__class__._synthetic_filename = lambda self, fullname: "no_file.py"
  loader._redirect_module = None
  loader._split_name = ['ansible_collections', 'namespace', '']
  loader._rpart_name = ('ansible_collections', '.', 'namespace')
  loader._parent_package_name = 'ansible_collections'
  loader._package_to

# Generated at 2022-06-11 17:43:21.446595
# Unit test for constructor of class AnsibleCollectionRef
def test_AnsibleCollectionRef():
    ref = 'ns.coll.resource'
    collection_name = 'ns.coll'
    subdirs = u''
    resource = 'resource'
    ref_type = 'test'

    ar = AnsibleCollectionRef(collection_name, subdirs, resource, ref_type)

    assert ar.collection == collection_name
    assert ar.subdirs == subdirs
    assert ar.resource == resource
    assert ar.ref_type == ref_type

    assert ar.n_python_collection_package_name == 'ansible_collections.ns.coll'
    assert ar.n_python_package_name == 'ansible_collections.ns.coll.plugins.test.resource'
    assert ar.fqcr == ref



# Generated at 2022-06-11 17:43:55.479556
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import types
    loader = _AnsibleInternalRedirectLoader('ansible.module_utils.basic', [])
    sys.modules['ansible.module_utils.basic'] = 'fake'

    def setup_mock_module(module, path, name=None):
        mock_module = types.ModuleType(module)
        mock_module.__name__ = name if name else module
        mock_module.__path__ = path
        return mock_module

    mock_1 = setup_mock_module('ansible.module_utils.basic', ['fake_path'])
    mock_2 = setup_mock_module('ansible.module_utils.basic', ['fake_path'])

# Generated at 2022-06-11 17:44:02.524485
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    assert _AnsiblePathHookFinder._filefinder_path_hook is not None

_EXTENSION_TO_LOADER_CLASS = {
    '.py': _AnsiblePyLoader,
    '.zip': _AnsibleZipLoader,
}

# TODO: provide an internal pkgutil-based loader for _meta files, or some such thing for better caching, to enable
# file-based import of these, to avoid having to probe ZIP archives all the time

# Generated at 2022-06-11 17:44:11.916713
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class MockModule:
        _collection_meta = None
        __path__ = None
    mock_module = MockModule()

    class MockMetaYmlToDict:
        def __call__(self, raw_routing, namespace):
            return raw_routing
    mock_meta_yml_to_dict = MockMetaYmlToDict()

    mock_path = '/path/to/module'
    mock_package_to_load = 'package'
    mock_candidate_paths = []

    loader = _AnsibleCollectionPkgLoader(path=mock_candidate_paths, package_to_load=mock_package_to_load)
    loader.get_filename = MagicMock(return_value=mock_path)

# Generated at 2022-06-11 17:44:18.221223
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    collection = AnsibleCollectionRef(
        collection_name=u'namespace.collection',
        subdirs=u'subdir1.subdir2',
        resource=u'resource',
        ref_type=u'module'
    )
    assert collection.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"


# Generated at 2022-06-11 17:44:26.545784
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    loader = _AnsibleCollectionPkgLoaderBase('ansible_collections.ansible.plugins.lookup.echo.echo', ['/Users/travis/build/ansible/ansible'])
    module = loader.load_module('ansible_collections.ansible.plugins.lookup.echo.echo')
    expected = '<module ansible_collections.ansible.plugins.lookup.echo.echo from /Users/travis/build/ansible/ansible/lib/ansible/plugins/lookup/echo/echo.py>'
    assert str(module) == expected

