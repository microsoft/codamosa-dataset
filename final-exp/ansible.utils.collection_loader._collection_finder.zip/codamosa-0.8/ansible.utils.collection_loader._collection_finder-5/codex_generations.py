

# Generated at 2022-06-11 17:35:28.258337
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_is_package():
    from ansible.module_utils.common._collections_compat import Path

    fpath_1 = Path("/home/user")
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.somens", path_list=[fpath_1])
    loader._subpackage_search_paths = [fpath_1]
    assert loader.is_package("ansible_collections.somens") == True

    fpath_2 = Path("/home/user/__init__.py")
    loader = _AnsibleCollectionPkgLoaderBase("ansible_collections.somens", path_list=[fpath_2])
    loader._subpackage_search_paths = None
    assert loader.is_package("ansible_collections.somens") == False

    loader = _Ansible

# Generated at 2022-06-11 17:35:35.984210
# Unit test for constructor of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder():
    # the following is the type of info that sys.path_hooks passes to path hook functions
    _expected_type_of_info = 'test_path'

    # Initialize an instance of class _AnsibleCollectionFinder
    # The class' __init__() sets collection_finder._n_configured_paths to be the first argument passed to __init__(...)
    test_paths = '/test_paths'
    test_collection_finder = _AnsibleCollectionFinder(paths=[test_paths])

    # Initialize an instance of class _AnsiblePathHookFinder, which expects two arguments
    #   - collection_finder: an instance of class _AnsibleCollectionFinder
    #   - pathctx: string-like info that sys.path_hooks passes to path hook functions
    test_ansible_path

# Generated at 2022-06-11 17:35:38.250820
# Unit test for constructor of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader():
    internal_redirect_loader = _AnsibleInternalRedirectLoader("ansible.plugins.foo", ["ansible/plugins"])
    assert internal_redirect_loader._redirect == "ansible.collections.foo"

# Generated at 2022-06-11 17:35:42.367771
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    ref = AnsibleCollectionRef('tag.content', None, 'name', 'type')
    assert repr(ref) == "AnsibleCollectionRef(collection='tag.content', subdirs='', resource='name')"



# Generated at 2022-06-11 17:35:49.263117
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    import sys
    import inspect
    import ansible_collections.ansible.builtin.plugins.module_utils.facts.system.distribution as test_mod
    expected_mod = import_module('.ansible.builtin.plugins.module_utils.facts.system.distribution', 'ansible_collections')
    if expected_mod is not test_mod:
        raise AssertionError('Redirection Failed')

# Generated at 2022-06-11 17:35:58.255438
# Unit test for method is_package of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:35:59.396600
# Unit test for method __repr__ of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase___repr__():
    obj = _AnsibleCollectionPkgLoaderBase(fullname='', path_list=None)
    assert obj.__repr__()



# Generated at 2022-06-11 17:36:03.599631
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    _interface_collection_loader_unit_test('_AnsibleInternalRedirectLoader', 'load_module')


# wrapper around all _AnsibleCollectionPkgLoaderBase implementations, does some checks for valid usage
# and handles collection routing for Py2/3

# Generated at 2022-06-11 17:36:13.832270
# Unit test for method from_fqcr of class AnsibleCollectionRef

# Generated at 2022-06-11 17:36:16.735097
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    # setup
    try:
        loader = _AnsibleCollectionPkgLoader(name)
    except ImportError as ex:
        assert False, 'Error creating loader: {0}'.format(ex)



# Generated at 2022-06-11 17:36:54.702661
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    from ansible_collections.__main__ import AnsibleCollectionConfig
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule
    ansible_collection_config = AnsibleCollectionConfig()
    ansible_collection_config.set_collection_paths(['/path/1', '/path/2'])
    kwargs = dict(
        split_name=['ansible_collections', 'namespace', 'collection'],
        parent_package_name='ansible_collections.namespace',
        package_to_load='collection',
        ansible_collection_config=ansible_collection_config
    )
    p = _AnsibleCollectionPkgLoader(**kwargs)
    assert p._split_name == ['ansible_collections', 'namespace', 'collection']


# Generated at 2022-06-11 17:37:00.987938
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    try:
        # noinspection PyProtectedMember
        _ = _AnsibleCollectionPkgLoaderBase._new_or_existing_module('ansible_collections.foo.bar')
    except ImportError:
        pass
    except Exception as ex:
        print(ex)

# Generated at 2022-06-11 17:37:07.794407
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    # FIXME: Run with salt-run for consistency?
    # FIXME: test_package_with_synthetic_init
    from packaging.version import Version
    from importlib import abc
    from ansible_collections.ansible.test.test_data import test_collection_data_path
    from ansible_collections.ansible.test.test_data import test_packages_path

    tmp_directory = tempfile.TemporaryDirectory()
    tmp_path = tmp_directory.name

    # Set up a fake collection under tmp_path, including a path and a versioned path
    collection_paths = [os.path.join(tmp_path, 'ns', 'test_version'), os.path.join(tmp_path, 'ns', 'test_version', '1.2.3')]

# Generated at 2022-06-11 17:37:17.417736
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    collection_path = './lib/ansible/modules/clustering/corosync'
    package_name = 'ansible.modules.clustering.corosync'

# Generated at 2022-06-11 17:37:28.622389
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    import tempfile
    import shutil
    from ansible.module_utils.common._collections_compat import BasePathHookFinder
    from ansible.module_utils.common._collections_compat import BaseCollectionPackageLoader

    # create a temp dir (it will be rmtreed in tearDownModule())
    # build a dummy collection called 'test'
    tempdir = tempfile.mkdtemp()
    test_path = tempfile.mkdtemp(dir=tempdir)
    collection_root = os.path.join(test_path, 'ansible_collections', 'test')
    os.makedirs(collection_root)

    # create the init.py at root of the collection
    with open(os.path.join(collection_root, '__init__.py'), 'a') as f:
        f.write

# Generated at 2022-06-11 17:37:35.903839
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    # Arrange
    expected_results = {'action_plugins': 'action',
                        'become_plugins': 'become',
                        'cache_plugins': 'cache',
                        'callback_plugins': 'callback',
                        'cliconf_plugins': 'cliconf',
                        'connection_plugins': 'connection',
                        'filter_plugins': 'filter',
                        'httpapi_plugins': 'httpapi',
                        'inventory_plugins': 'inventory',
                        'lookup_plugins': 'lookup',
                        'module_utils': 'module_utils',
                        'modules': 'modules',
                        'netconf_plugins': 'netconf',
                        'shell_plugins': 'shell',
                        'strategy_plugins': 'strategy',
                        'terminal_plugins': 'terminal',
                        'test_plugins': 'test'
                        }


# Generated at 2022-06-11 17:37:45.663856
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    # Create a mocker for method get_data
    mock_get_data = mocker.patch.object(_AnsibleCollectionPkgLoaderBase, 'get_data')
    # Get the mock return value of method get_data
    mock_get_data_return_value = mock_get_data.return_value

    obj = _AnsibleCollectionPkgLoaderBase('fullname', 'path_list')
    # Call get_data
    with pytest.raises(ValueError):
        obj.get_data('path')

    mock_get_data.assert_called_once_with('path')
    assert mock_get_data_return_value == None

# Generated at 2022-06-11 17:37:53.502712
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    collection_finder = _AnsibleCollectionFinder()
    pathctx = os.path.join(TEST_DATA_ROOT, 'ansible_collections', 'ns1', 'coll1')
    ansible_path_hook_finder = _AnsiblePathHookFinder(collection_finder, pathctx)
    fullname = 'ansible_collections.ns1.coll1.plugins.module_utils.network'
    assert ansible_path_hook_finder.find_module(fullname, path=None) == _AnsibleCollectionLoader
    fullname = 'ansible_collections.ns1.modules.network.nxos'
    assert ansible_path_hook_finder.find_module(fullname, path=None) == _AnsibleCollectionLoader



# Generated at 2022-06-11 17:37:57.482865
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    a = AnsibleCollectionRef("namespace.collection_name", "subdirs", "resource", "ref_type")
    assert a.__repr__() == 'AnsibleCollectionRef(collection=\'namespace.collection_name\', subdirs=\'subdirs\', resource=\'resource\')'


# Generated at 2022-06-11 17:38:05.648528
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    try:
        collection_finder = _AnsibleCollectionFinder()
        # There is no ansible_collection, so the import fails.
        assert collection_finder.find_module('ansible.module_utils.basic') == None
    finally:
        _AnsibleCollectionFinder._remove()


# pkgutil's standard implementation of iter_modules has two problems for our purposes:
# 1. It refuses to return modules without .py files present; this isn't a huge problem, but it means we
#    can't transparently use the stub collection files that Python's zipimporter can. This is manageable;
#    pkgutil's iter_modules is only used by Ansible's import-related infrastructure currently. But
#    this is a limitation we'd like to lift in the future.
# 2. It doesn't play well with load_module; if the code that

# Generated at 2022-06-11 17:38:47.263601
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    from ansible_collections.ansible.collection_loader import _iter_modules_impl
    from ansible_collections.ansible.collection_loader import _AnsibleCollectionPkgLoaderBase
    from ansible_collections.ansible.collection_loader import _AnsibleCollectionFinder

    collection_root_dir_name = '/home/vagrant/pytest/test_collection_loader/collection_root'
    collection_root_dir = os.path.join(os.getcwd(), collection_root_dir_name)
    collection_ns = 'ansible_collections.test_collections'
    collection_paths = [collection_root_dir]

    path_hook_cls = _AnsiblePathHookFinder

    collection_finder_cls = _AnsibleCollectionFinder
    collection_loader_cl

# Generated at 2022-06-11 17:38:51.154950
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    loader = _AnsibleCollectionPkgLoaderBase('ansible.plugins.filter.ipaddr')
    # verify the get_code method returns a code object
    assert (loader.get_code('ansible.plugins.filter.ipaddr') != None)



# Generated at 2022-06-11 17:38:55.375986
# Unit test for method find_module of class _AnsiblePathHookFinder
def test__AnsiblePathHookFinder_find_module():
    def _make_mock_module(fullname=None, path=[]):
        class MockModule(object):
            def __init__(self, fullname=None, path=[]):
                self.__name__ = fullname
                self.__path__ = path
                self.__loader__ = None

        return MockModule(fullname, path)

    ansible_collections_mock_module = _make_mock_module(fullname='ansible_collections', path=['/foo/somedir', ])
    anslib_mock_module = _make_mock_module(fullname='ansible', path=['/foo/somedir', ])

# Generated at 2022-06-11 17:38:59.937756
# Unit test for method get_filename of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_filename():
    r = _AnsibleCollectionPkgLoaderBase('ansible_collections.somens.somemod')
    assert isinstance(r, _AnsibleCollectionPkgLoaderBase)
    r._source_code_path = '/some/path'
    filename = r.get_filename('ansible_collections.somens.somemod')
    assert filename == '/some/path'


# Generated at 2022-06-11 17:39:03.137496
# Unit test for constructor of class _AnsibleCollectionLoader
def test__AnsibleCollectionLoader():
    """"""
    import ansible.utils.collection_loader
    loader = ansible.utils.collection_loader._AnsibleCollectionLoader('ansible.collection1', None)


# Generated at 2022-06-11 17:39:13.544939
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    # Valid in all cases
    assert AnsibleCollectionRef.from_fqcr('ns.coll.roles.rolename', 'role') == AnsibleCollectionRef('ns.coll', 'roles', 'rolename', 'role')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.plugins.module_utils.module1', 'module_utils') == AnsibleCollectionRef('ns.coll', 'plugins.module_utils', 'module1', 'module_utils')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.plugins.library.module1', 'module') == AnsibleCollectionRef('ns.coll', 'plugins.library', 'module1', 'module')
    assert AnsibleCollectionRef.from_fqcr('ns.coll.plugins.module_utils.module1', 'module_utils') == AnsibleCollectionRef

# Generated at 2022-06-11 17:39:24.422586
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    class TestCollectionRef(unittest.TestCase):

        def test_collection_ref_from_fqcr(self):
            result = AnsibleCollectionRef.from_fqcr("ansible_namespace.python", "module")
            self.assertEquals(result.collection, "ansible_namespace.python")
            self.assertEquals(result.subdirs, "")
            self.assertEquals(result.resource, "")
            self.assertEquals(result.ref_type, "module")

        def test_collection_ref_from_fqcr_invalid_collection(self):
            with self.assertRaises(ValueError):
                AnsibleCollectionRef.from_fqcr("ansible_namespace.python.some_dir", "module")


# Generated at 2022-06-11 17:39:33.182670
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    def fail(msg):
        utils.fail_json(msg=msg)

    import types

    # setup
    valid_fqcr = ['test.test.test', 'test.test.test.test.test', 'test.test.test.test', 'test.test.test.test.test.test.test']
    invalid_fqcr = ['test.test.test.', '.test', '.test.test', 'test.test.', 'test..test', '.test.test.test', 't.e.s.t', 'test..test.test']

    for ref in valid_fqcr:
        if not AnsibleCollectionRef.is_valid_fqcr(ref):
            fail("test_is_valid_fqcr: Failed to validate good FQCR '%s'" % ref)


# Generated at 2022-06-11 17:39:41.979043
# Unit test for method try_parse_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_try_parse_fqcr():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    # Positive Test Cases
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.role", u'role')
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.role2", u'role')
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.role3", u'role')
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.module", u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.module2", u'module')
    assert AnsibleCollectionRef.try_parse_fqcr(u"ns.my.module3", u'module')

# Generated at 2022-06-11 17:39:50.070420
# Unit test for method __repr__ of class AnsibleCollectionRef
def test_AnsibleCollectionRef___repr__():
    # Test for collection, subdirs and resource are all valid
    instance = AnsibleCollectionRef('namespace.collection', 'subdir1.subdir2', 'resource', 'module')
    assert instance.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='subdir1.subdir2', resource='resource')"
    # Test for 'subdirs' is None
    instance = AnsibleCollectionRef('namespace.collection', None, 'resource', 'module')
    assert instance.__repr__() == "AnsibleCollectionRef(collection='namespace.collection', subdirs='', resource='resource')"
    # Test for 'subdirs' is empty
    instance = AnsibleCollectionRef('namespace.collection', '', 'resource', 'module')

# Generated at 2022-06-11 17:41:12.480484
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    import ansible.utils.collection_loader
    ansible.utils.collection_loader._meta_yml_to_dict = None
    try:
        # Name of the collection package
        collection_name = 'ansible_collections.azure.azcollection'
        # Name of the loader of the collections package
        collection_loader = _AnsibleCollectionPkgLoader(collection_name, '/')
    except ValueError as value_error:
        assert isinstance(value_error, ValueError)
    _meta_yml_to_dict = lambda content, path: {}
    ansible.utils.collection_loader._meta_yml_to_dict = _meta_yml_to_dict
    collection_loader = _AnsibleCollectionPkgLoader(collection_name, '/')

# Generated at 2022-06-11 17:41:22.439230
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():

    class _AnsibleCollectionPkgLoaderBaseTester(object):
        '''
        This is a class to test get_code method of _AnsibleCollectionPkgLoaderBase class
        '''
        
        def __init__(self, fullname):
            self._fullname = fullname

        def test_get_code(self, fullname):
            '''
            call get_code method and return the result
            '''
            return _AnsibleCollectionPkgLoaderBase.get_code(self, fullname)



    class _AnsibleCollectionPkgLoaderBaseTester_no_fullname(object):
        '''
        This is a class to test the case where fullname is None
        '''
        def __init__(self):
            self._fullname = None


# Generated at 2022-06-11 17:41:29.338182
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    class _AnsibleCollectionPkgLoaderBaseDerived(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            pass
        def _validate_final(self):
            pass
    loader = _AnsibleCollectionPkgLoaderBaseDerived(None, None)
    result = loader.get_code(None)
    assert result is None


# Generated at 2022-06-11 17:41:38.322729
# Unit test for method load_module of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader_load_module():
    class _AnsibleCollectionPkgLoader2(_AnsibleCollectionPkgLoader):
        def __init__(self, package_to_load, candidate_paths, syntax_version, *args, **kwargs):
            super(_AnsibleCollectionPkgLoader2, self).__init__(package_to_load, candidate_paths, syntax_version, *args, **kwargs)
            self._decoded_source = None
            self._source_code_path = None
            self._compiled_code = None
    #
    def _meta_yml_to_dict2(raw, path):
        return {'plugin_routing': {'lookup': {'vault': {'plugin': 'myplugin'}}}}
    #

# Generated at 2022-06-11 17:41:44.163575
# Unit test for constructor of class _AnsibleCollectionNSPkgLoader
def test__AnsibleCollectionNSPkgLoader():
    loader = _AnsibleCollectionNSPkgLoader('ansible_collections.ns_test1')
    actual_value = loader.is_package('ansible_collections.ns_test1')
    assert actual_value


# Implements normal package support for both Py2/3. Package init code is required for Python 3.

# Generated at 2022-06-11 17:41:46.910535
# Unit test for method legacy_plugin_dir_to_plugin_type of class AnsibleCollectionRef
def test_AnsibleCollectionRef_legacy_plugin_dir_to_plugin_type():
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('filter_plugins') == 'filter'
    assert AnsibleCollectionRef.legacy_plugin_dir_to_plugin_type('library') == 'modules'


# Generated at 2022-06-11 17:41:53.510463
# Unit test for method get_data of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_data():
    p = _AnsibleCollectionPkgLoaderBase("fullname")
    print(p.get_data("/tmp/package/__init__.py"))
    print(p.get_data("/tmp/package/__init__.py"))
    print(p.get_data("/tmp/package"))
    try:
        print(p.get_data("package"))
    except ValueError as e:
        print("ValueError exception: {0}".format(e))


# Generated at 2022-06-11 17:42:02.332485
# Unit test for constructor of class _AnsibleCollectionPkgLoader
def test__AnsibleCollectionPkgLoader():
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '/home/test/ansible/cc/'
    loader = _AnsibleCollectionPkgLoader('ansible_collections.cc.abc')
    assert loader._package_to_load == 'abc'
    assert loader._parent_package_name == ''
    assert loader._candidate_paths[0] == '/home/test/ansible/cc/ansible_collections/cc/abc'
    assert loader._split_name == ['ansible_collections', 'cc', 'abc']


# Implements the canonical collection package NS path for a given prefix/module name

# Generated at 2022-06-11 17:42:12.078384
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    from ansible.utils.collection_loader import _AnsibleInternalRedirectLoader
    import importlib
    import sys
    # Example of use, see test_loader.py test function test__AnsibleInternalRedirectLoader_load_module
    fullname = 'ansible.module_utils.connection_plugins.network_cli.network_cli'
    path_list = ['/usr/share/ansible/plugins/module_utils']
    module_name = fullname.split('.')[-1]
    module_names = list()
    module_load_count = len(list(filter(lambda x: x.startswith(module_name), sys.modules.keys())))

# Generated at 2022-06-11 17:42:20.174933
# Unit test for method find_module of class _AnsibleCollectionFinder
def test__AnsibleCollectionFinder_find_module():
  # We need to do a bit of setup to make the same thing work both in the test load_collection and in
  # the ansible-test import sanity test

  # When tested as part of load_collection, the finder itself has been set as the collection finder.
  # This is used to cause the ansible_collections loader to work.
  #
  # When tested as part of the ansible-test import sanity test, we have to create a finder here
  # and install it so it's available to the ansible_collections loader.
  import_test = False
  if AnsibleCollectionConfig.collection_finder is None or not isinstance(AnsibleCollectionConfig.collection_finder,
                                                                         _AnsibleCollectionFinder):
    AnsibleCollectionConfig.collection_finder = _AnsibleCollectionFinder()
    AnsibleCollectionConfig

# Generated at 2022-06-11 17:43:19.941502
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_source():
    class _AnsibleCollectionPkgLoader(_AnsibleCollectionPkgLoaderBase):
        def _validate_args(self):
            pass
        def _get_candidate_paths(self, path_list):
            self._subpackage_search_paths = [to_native(p) for p in path_list]
            return []
        def _get_subpackage_search_paths(self, candidate_paths):
            pass
        def _validate_final(self):
            pass
    #_AnsibleCollectionPkgLoaderBase.get_source(self, fullname):
    loader = _AnsibleCollectionPkgLoader('this.is.a.test')

# Generated at 2022-06-11 17:43:32.408071
# Unit test for method is_valid_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_is_valid_fqcr():
    import pytest

# Generated at 2022-06-11 17:43:39.598936
# Unit test for method get_code of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_get_code():
    code_obj = _AnsibleCollectionPkgLoaderBase.get_code('ansible_collections.somens.someserver')
    passcode = code_obj.co_code
    code_obj = _AnsibleCollectionPkgLoaderBase.get_code('ansible_collections.somens.someserver.utils')
    passcode = code_obj.co_code
    code_obj = _AnsibleCollectionPkgLoaderBase.get_code('ansible_collections.somens.someserver.utils.json_utils')
    passcode = code_obj.co_code
    # bytecode of a python file is generated in compiling time.
    # bytecode of a python file is PABCDEFG
    # when the bytecode contains '\x85', it will be identified as a python file.
    #

# Generated at 2022-06-11 17:43:51.864680
# Unit test for method get_source of class _AnsibleCollectionPkgLoaderBase

# Generated at 2022-06-11 17:44:00.530648
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    dummy_sut = _AnsibleCollectionPkgLoaderBase('ansible_collections.__dummy__', path_list=[])
    dummy_sut._subpackage_search_paths = None
    dummy_sut._source_code_path = '/usr/share/ansible_collections/__dummy__/__init__.py'
    dummy_sut._redirect_module = None
    sys.modules.pop('ansible_collections.__dummy__', None)
    from ansible_collections import __dummy__
    assert isinstance(__dummy__, ModuleType)
    assert __dummy__.__name__ == 'ansible_collections.__dummy__'
    assert __dummy__.__loader__ == dummy_sut

# Generated at 2022-06-11 17:44:10.503129
# Unit test for method load_module of class _AnsibleInternalRedirectLoader
def test__AnsibleInternalRedirectLoader_load_module():
    # HACK: use a mock builtin collection config to provide routing data
    bict = _builtin_collection_config_mock.BuiltinCollectionConfigMock()
    bict.add_routing_entry('ansible.builtin.foo', {'redirect': 'real.foo'})

    loader = _AnsibleInternalRedirectLoader('ansible.builtin.foo', [])
    mod = loader.load_module('ansible.builtin.foo')

    assert mod.__name__ == 'real.foo'


# TODO: we need to implement a way to intercept imports, so we can route them to collection code dynamically.
# at the moment we require a config file that stores all supported import redirects.
# we need to instead do our own workaround for the lack of import hooks in Py2/3, so all imports are routed
# through

# Generated at 2022-06-11 17:44:21.452453
# Unit test for method from_fqcr of class AnsibleCollectionRef
def test_AnsibleCollectionRef_from_fqcr():
    assert AnsibleCollectionRef.from_fqcr(u'ansible.builtin.get_url', u'module') == \
           AnsibleCollectionRef(u'ansible.builtin', u'', u'get_url', u'module')

    assert AnsibleCollectionRef.from_fqcr(u'ansible.builtin.network.cisco.ios.ping', u'module') == \
           AnsibleCollectionRef(u'ansible.builtin', u'network.cisco.ios', u'ping', u'module')

    assert AnsibleCollectionRef.from_fqcr(u'ansible.builtin.copy', u'module') == \
           AnsibleCollectionRef(u'ansible.builtin', u'', u'copy', u'module')


# Generated at 2022-06-11 17:44:30.488474
# Unit test for method load_module of class _AnsibleCollectionPkgLoaderBase
def test__AnsibleCollectionPkgLoaderBase_load_module():
    '''Test load_module method of class _AnsibleCollectionPkgLoaderBase'''
    fullname='ansible.test'
    module_attrs=dict(
                         __loader__=self,
                         __file__=self.get_filename(fullname),
                         __package__=self._parent_package_name  # sane default for non-packages
                     )
    sys.modules[fullname] = module_attrs